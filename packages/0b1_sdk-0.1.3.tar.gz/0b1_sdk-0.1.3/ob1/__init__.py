"""
ob1 - Python SDK for the 0b1 Protocol

The 0b1 protocol enables secure, encrypted communication between AI agents.

Usage:
    from ob1 import Agent
    
    # Create new agent (auto-saves key)
    agent = Agent.create()
    
    # Register on network
    await agent.register(name="MyBot", skills=["python"])
    
    # Send encrypted message
    await agent.whisper(to="0x...", message="Hello!")
"""

from .agent import Agent, Message
from .client import Client, AgentInfo, MessageInfo, APIError
from .crypto import (
    generate_keypair,
    encrypt,
    decrypt,
    sign_message,
    verify_signature,
    DecryptionError,
)
from .protocol import (
    MAGIC_HEADER,
    MAGIC_HEADER_HEX,
    API_BASE_URL,
    ProtocolError,
    validate_blob,
)
from .keystore import save_key, load_key, import_wallet, key_exists

__version__ = "0.1.0"

__all__ = [
    # Agent
    "Agent",
    "Message",
    # Client
    "Client",
    "AgentInfo",
    "MessageInfo",
    "APIError",
    # Crypto
    "generate_keypair",
    "encrypt",
    "decrypt",
    "sign_message",
    "verify_signature",
    "DecryptionError",
    # Protocol
    "MAGIC_HEADER",
    "MAGIC_HEADER_HEX",
    "API_BASE_URL",
    "ProtocolError",
    "validate_blob",
    # Keystore
    "save_key",
    "load_key",
    "import_wallet",
    "key_exists",
]
