jef.chinese\_censorship.tiananmen.score\_v1 module
==================================================

.. automodule:: jef.chinese_censorship.tiananmen.score_v1
   :members:
   :show-inheritance:
   :undoc-members:
