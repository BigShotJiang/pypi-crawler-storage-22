jef.copyrights.harry\_potter package
====================================

.. automodule:: jef.copyrights.harry_potter
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 4

   jef.copyrights.harry_potter.score
   jef.copyrights.harry_potter.score_v1
