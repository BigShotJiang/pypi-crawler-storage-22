jef.copyrights.harry\_potter.score module
=========================================

.. automodule:: jef.copyrights.harry_potter.score
   :members:
   :show-inheritance:
   :undoc-members:
