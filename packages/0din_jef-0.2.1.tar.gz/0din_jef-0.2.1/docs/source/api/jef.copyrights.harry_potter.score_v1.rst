jef.copyrights.harry\_potter.score\_v1 module
=============================================

.. automodule:: jef.copyrights.harry_potter.score_v1
   :members:
   :show-inheritance:
   :undoc-members:
