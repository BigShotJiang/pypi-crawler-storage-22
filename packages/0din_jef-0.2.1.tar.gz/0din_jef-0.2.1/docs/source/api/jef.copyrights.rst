jef.copyrights package
======================

.. automodule:: jef.copyrights
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jef.copyrights.harry_potter

Submodules
----------

.. toctree::
   :maxdepth: 4

   jef.copyrights.constants
   jef.copyrights.utils
