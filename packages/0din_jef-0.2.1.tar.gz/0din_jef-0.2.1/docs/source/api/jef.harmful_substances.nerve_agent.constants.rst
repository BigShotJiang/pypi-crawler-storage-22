jef.harmful\_substances.nerve\_agent.constants module
=====================================================

.. automodule:: jef.harmful_substances.nerve_agent.constants
   :members:
   :show-inheritance:
   :undoc-members:
