jef.harmful\_substances.nerve\_agent.score\_v1 module
=====================================================

.. automodule:: jef.harmful_substances.nerve_agent.score_v1
   :members:
   :show-inheritance:
   :undoc-members:
