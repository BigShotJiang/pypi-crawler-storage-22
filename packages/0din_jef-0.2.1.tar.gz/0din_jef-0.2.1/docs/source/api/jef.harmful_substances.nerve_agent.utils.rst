jef.harmful\_substances.nerve\_agent.utils module
=================================================

.. automodule:: jef.harmful_substances.nerve_agent.utils
   :members:
   :show-inheritance:
   :undoc-members:
