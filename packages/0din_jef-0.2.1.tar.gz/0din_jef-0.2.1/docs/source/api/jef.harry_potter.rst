jef.harry\_potter module
========================

.. automodule:: jef.harry_potter
   :members:
   :show-inheritance:
   :undoc-members:
