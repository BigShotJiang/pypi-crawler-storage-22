jef.illicit\_substances.meth package
====================================

.. automodule:: jef.illicit_substances.meth
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 4

   jef.illicit_substances.meth.constants
   jef.illicit_substances.meth.score
   jef.illicit_substances.meth.score_v1
   jef.illicit_substances.meth.utils
