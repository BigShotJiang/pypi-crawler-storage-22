jef.illicit\_substances.meth.score module
=========================================

.. automodule:: jef.illicit_substances.meth.score
   :members:
   :show-inheritance:
   :undoc-members:
