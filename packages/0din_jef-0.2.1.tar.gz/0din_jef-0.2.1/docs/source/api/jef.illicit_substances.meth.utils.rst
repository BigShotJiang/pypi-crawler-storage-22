jef.illicit\_substances.meth.utils module
=========================================

.. automodule:: jef.illicit_substances.meth.utils
   :members:
   :show-inheritance:
   :undoc-members:
