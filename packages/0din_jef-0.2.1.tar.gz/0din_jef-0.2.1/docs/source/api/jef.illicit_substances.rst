jef.illicit\_substances package
===============================

.. automodule:: jef.illicit_substances
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jef.illicit_substances.meth
