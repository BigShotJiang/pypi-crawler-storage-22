jef package
===========

.. automodule:: jef
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jef.chinese_censorship
   jef.copyrights
   jef.harmful_substances
   jef.illicit_substances
   jef.score_algos

Submodules
----------

.. toctree::
   :maxdepth: 4

   jef.harry_potter
   jef.helpers
   jef.meth
   jef.nerve_agent
   jef.tiananmen
   jef.types
