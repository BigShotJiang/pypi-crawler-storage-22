jef.score\_algos.constants module
=================================

.. automodule:: jef.score_algos.constants
   :members:
   :show-inheritance:
   :undoc-members:
