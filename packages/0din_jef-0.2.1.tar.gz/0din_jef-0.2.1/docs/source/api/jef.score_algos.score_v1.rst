jef.score\_algos.score\_v1 module
=================================

.. automodule:: jef.score_algos.score_v1
   :members:
   :show-inheritance:
   :undoc-members:
