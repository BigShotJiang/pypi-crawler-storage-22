# 102303803-Topsis

A robust Python implementation for the Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS), widely used for Multi-Criteria Decision Making (MCDM).

## Installation

Easily install the package using pip:

```bash
pip install 102303803-Topsis
```

## Usage

Run the package directly from the command line interface (CLI):

```bash
topsis <InputDataFile> <Weights> <Impacts> <OutputResultFileName>
```

### Example Usage

```bash
topsis data.csv "1,1,1,2,1" "+,+,+,-,+" result.csv
```

## Parameters Explained

1.  **InputDataFile**: Compatibility with CSV format. The file must include a header. The first column is treated as the object identifier and excluded from calculations. All subsequent columns must contain numeric data.
2.  **Weights**: A comma-separated string of numeric weights corresponding to each criterion (e.g., "1,1,1,2,1").
3.  **Impacts**: A comma-separated string indicating the direction of impact for each criterion ('+' for beneficial, '-' for non-beneficial) (e.g., "+,+,+,-,+").
4.  **OutputResultFileName**: The desired filename for the output CSV, which will include the original data augmented with Topsis Score and Rank.

## License

MIT License
