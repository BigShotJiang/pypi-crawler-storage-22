import sys
import pandas as pd
import numpy as np
import os

def validate_numeric_columns(dataframe):
    """
    Validates that all columns from the 2nd one onwards contain numeric values.
    Returns True if valid, False otherwise.
    """
    try:
        # Attempt to cast the dataframe slice to float
        dataframe.iloc[:, 1:].astype(float)
        return True
    except ValueError:
        return False

def topsis(input_file_path, weight_string, impact_string, output_file_path):
    """
    Main function to execute the TOPSIS methodology.
    
    Args:
        input_file_path (str): Path to the input CSV file.
        weight_string (str): Comma-separated string of weights.
        impact_string (str): Comma-separated string of impacts ('+' or '-').
        output_file_path (str): Path where the result CSV will be saved.
    """
    try:
        # Step 1: Data Ingestion
        try:
            dataset = pd.read_csv(input_file_path)
        except FileNotFoundError:
            print(f"Error: The file '{input_file_path}' does not exist.")
            return

        # Step 2: Input Validation
        # Ensure sufficient columns are present
        if dataset.shape[1] < 3:
            print("Error: The input file must have at least 3 columns.")
            return

        # Ensure numeric data in relevant columns
        if not validate_numeric_columns(dataset):
            print("Error: Columns from the 2nd position onwards must contain only numeric values.")
            return

        num_criteria = dataset.shape[1] - 1  # First column is identifier
        
        # Parse weights and impacts
        try:
            weights = [float(w) for w in weight_string.split(',')]
            impacts = impact_string.split(',')
        except ValueError:
             print("Error: Weights must be numeric.")
             return

        # Consistency check for dimensions
        if len(weights) != num_criteria or len(impacts) != num_criteria:
            print(f"Error: Expected {num_criteria} weights and impacts, but got {len(weights)} and {len(impacts)} respectively.")
            return

        # Validate impact symbols
        valid_impacts = {'+', '-'}
        if not all(imp in valid_impacts for imp in impacts):
            print("Error: Impacts must be either '+' or '-'.")
            return

        # Step 3: TOPSIS Algorithm Implementation
        
        # 3.1: Vector Normalization
        # Create a copy for calculation to avoid modifying the original dataframe in memory immediately
        calc_df = dataset.iloc[:, 1:].copy().astype(float)
        
        # Calculate Root Sum of Squares for each column
        root_sum_squares = np.sqrt((calc_df**2).sum())
        
        # Normalize the decision matrix
        normalized_decision_matrix = calc_df / root_sum_squares

        # 3.2: Weighted Normalization
        weighted_normalized_matrix = normalized_decision_matrix * weights

        # 3.3: Determine Ideal Best and Ideal Worst Solutions
        ideal_best_values = []
        ideal_worst_values = []

        for col_idx in range(num_criteria):
            column_data = weighted_normalized_matrix.iloc[:, col_idx]
            if impacts[col_idx] == '+':
                # For beneficial criteria, max is best, min is worst
                ideal_best_values.append(column_data.max())
                ideal_worst_values.append(column_data.min())
            else:
                # For non-beneficial criteria, min is best, max is worst
                ideal_best_values.append(column_data.min())
                ideal_worst_values.append(column_data.max())

        # 3.4: Calculate Euclidean Distances
        # Distance from Ideal Best
        distance_positive = np.sqrt(((weighted_normalized_matrix - ideal_best_values) ** 2).sum(axis=1))
        # Distance from Ideal Worst
        distance_negative = np.sqrt(((weighted_normalized_matrix - ideal_worst_values) ** 2).sum(axis=1))

        # 3.5: Calculate Performance Score
        # Avoid division by zero if total distance is 0 (though theoretically rare in this context)
        total_distance = distance_positive + distance_negative
        topsis_score = distance_negative / total_distance
        
        # Step 4: Result Generation
        dataset['Topsis Score'] = topsis_score
        dataset['Rank'] = dataset['Topsis Score'].rank(ascending=False).astype(int)

        dataset.to_csv(output_file_path, index=False)
        print(f"Success: Output file saved to '{output_file_path}'.")

    except Exception as error_msg:
        print(f"An unexpected error occurred: {error_msg}")

def main():
    """
    Entry point for the console script. Validates command line arguments.
    """
    if len(sys.argv) != 5:
        print("Usage: python <program.py> <InputDataFile> <Weights> <Impacts> <OutputResultFileName>")
        print('Example: python topsis.py data.csv "1,1,1,2,1" "+,+,+,-,+" result.csv')
        return

    # Unpack arguments
    input_file_param = sys.argv[1]
    weights_param = sys.argv[2]
    impacts_param = sys.argv[3]
    result_file_param = sys.argv[4]

    if not os.path.exists(input_file_param):
         print(f"Error: The input file '{input_file_param}' was not found.")
         return

    topsis(input_file_param, weights_param, impacts_param, result_file_param)

if __name__ == "__main__":
    main()
