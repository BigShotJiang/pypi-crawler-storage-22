from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name="102303803-Topsis",
    version="1.0.0",
    author="Pulkit Srivastava",
    author_email="pulkitsriv30@gmail.com",
    description="A Python package to implement TOPSIS technique for Multi-Criteria Decision Making (MCDM)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pulkit/assignment1_DS",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    entry_points={
        "console_scripts": [
            "topsis=Topsis_Pulkit_102303803.topsis:main",
        ],
    },
)
