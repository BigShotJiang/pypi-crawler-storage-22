# Checkpointer schemas
