# A2A Lite 🚀

**Build A2A agents in 8 lines. Add enterprise features when you need them.**

Wraps the official A2A SDKs ([Python](https://github.com/a2aproject/a2a-python), [TypeScript](https://github.com/a2aproject/a2a-js), [Java](https://github.com/a2aproject/a2a-java)) with a simple, intuitive API.

<table>
<tr>
<th>Python</th>
<th>TypeScript</th>
<th>Java</th>
</tr>
<tr>
<td>

```python
from a2a_lite import Agent

agent = Agent(
    name="Bot",
    description="My bot"
)

@agent.skill("greet")
async def greet(name: str):
    return f"Hello, {name}!"

agent.run()
```

</td>
<td>

```typescript
import { Agent } from 'a2a-lite';

const agent = new Agent({
  name: 'Bot',
  description: 'My bot'
});

agent.skill('greet', async ({ name }) =>
  `Hello, ${name}!`
);

agent.run();
```

</td>
<td>

```java
var agent = Agent.builder()
    .name("Bot")
    .description("My bot")
    .build();

agent.skill("greet", params ->
    "Hello, " + params.get("name") + "!"
);

agent.run();
```

</td>
</tr>
</table>

That's it. You have a running A2A agent.

---

## Installation

### Python
```bash
pip install a2a-lite
```

### TypeScript
```bash
npm install a2a-lite
# or
yarn add a2a-lite
```

### Java (Gradle)
```groovy
dependencies {
    implementation 'com.a2alite:a2a-lite:0.1.0'
    implementation 'io.javalin:javalin:5.6.3'  // For standalone mode
}
```

### Java (Maven)
```xml
<dependency>
    <groupId>com.a2alite</groupId>
    <artifactId>a2a-lite</artifactId>
    <version>0.1.0</version>
</dependency>
```

---

## The Philosophy

| Need | A2A Lite |
|------|----------|
| Hello World | 8 lines |
| Testing | 3 lines |
| Pydantic models | Just works |
| Auth | Add when needed |
| Files | Add when needed |
| Human-in-the-loop | Add when needed |
| Task tracking | Add when needed |

**Everything is optional except the basics.**

---

## Progressive Complexity

### Level 1: Just Works (No Setup)

```python
from a2a_lite import Agent

agent = Agent(name="Bot", description="A bot")

@agent.skill("greet")
async def greet(name: str) -> str:
    return f"Hello, {name}!"

agent.run()
```

### Level 2: Use Pydantic (Just Works)

```python
from pydantic import BaseModel

class User(BaseModel):
    name: str
    email: str

@agent.skill("create_user")
async def create_user(user: User) -> dict:
    # 'user' is already a User instance - auto-converted!
    return {"id": 1, "name": user.name}
```

### Level 3: Stream Responses (Just Yield)

```python
@agent.skill("chat", streaming=True)
async def chat(message: str):
    for word in message.split():
        yield word + " "
```

### Level 4: Add Middleware (When Needed)

```python
@agent.middleware
async def log_requests(ctx, next):
    print(f"Calling: {ctx.skill}")
    return await next()
```

### Level 5: Human-in-the-Loop (When Needed)

```python
from a2a_lite import InteractionContext

@agent.skill("wizard")
async def wizard(ctx: InteractionContext) -> dict:
    name = await ctx.ask("What's your name?")
    role = await ctx.ask("Role?", options=["Dev", "Manager"])

    if await ctx.confirm(f"Create {name} as {role}?"):
        return {"created": name}
    return {"cancelled": True}
```

### Level 6: Handle Files (When Needed)

```python
from a2a_lite import FilePart

@agent.skill("summarize")
async def summarize(doc: FilePart) -> str:
    content = await doc.read_text()
    return f"Summary: {content[:100]}..."
```

### Level 7: Track Task Progress (When Needed)

```python
from a2a_lite import TaskContext

agent = Agent(name="Bot", task_store="memory")

@agent.skill("process")
async def process(data: str, task: TaskContext) -> str:
    await task.update("working", "Starting...", progress=0.0)

    for i in range(10):
        await task.update("working", f"Step {i}/10", progress=i/10)

    return "Done!"
```

### Level 8: Add Authentication (When Needed)

```python
from a2a_lite import Agent, APIKeyAuth

agent = Agent(
    name="SecureBot",
    auth=APIKeyAuth(keys=["secret-key"]),
)
```

---

## Testing (3 Lines)

<table>
<tr>
<th>Python</th>
<th>TypeScript</th>
<th>Java</th>
</tr>
<tr>
<td>

```python
from a2a_lite import TestClient

client = TestClient(agent)
assert client.call("greet", name="World") == "Hello, World!"
```

</td>
<td>

```typescript
import { TestClient } from 'a2a-lite';

const client = new TestClient(agent);
expect(await client.call('greet', { name: 'World' })).toBe('Hello, World!');
```

</td>
<td>

```java
var client = new TestClient(agent);
assertThat(client.call("greet", Map.of("name", "World")))
    .isEqualTo("Hello, World!");
```

</td>
</tr>
</table>

---

## CLI

```bash
a2a-lite init my-agent          # Create new project
a2a-lite inspect http://...     # View agent capabilities
a2a-lite test http://... skill  # Test a skill
a2a-lite discover               # Find local agents
```

---

## Full Feature List

| Feature | Import | Complexity |
|---------|--------|------------|
| Basic skills | `Agent` | Just works |
| Pydantic models | `BaseModel` | Just works |
| Streaming | `streaming=True` | Just works |
| Testing | `TestClient` | Just works |
| Middleware | `@agent.middleware` | Add when needed |
| Webhooks | `@agent.on_complete` | Add when needed |
| Human-in-the-loop | `InteractionContext` | Add when needed |
| Conversation memory | `ConversationMemory` | Add when needed |
| File handling | `FilePart` | Add when needed |
| Structured data | `DataPart` | Add when needed |
| Rich outputs | `Artifact` | Add when needed |
| Task tracking | `TaskContext` | Add when needed |
| API Key auth | `APIKeyAuth` | Add when needed |
| Bearer/JWT auth | `BearerAuth` | Add when needed |
| Multiple auth | `CompositeAuth` | Add when needed |

---

## Examples

| Example | What it shows |
|---------|---------------|
| [01_hello_world.py](examples/01_hello_world.py) | Simplest agent (8 lines) |
| [02_calculator.py](examples/02_calculator.py) | Multiple skills |
| [06_pydantic_models.py](examples/06_pydantic_models.py) | Auto Pydantic conversion |
| [08_streaming.py](examples/08_streaming.py) | Streaming responses |
| [09_testing.py](examples/09_testing.py) | Testing your agents |
| [11_human_in_the_loop.py](examples/11_human_in_the_loop.py) | Ask user questions |
| [12_file_handling.py](examples/12_file_handling.py) | Handle files |
| [13_task_tracking.py](examples/13_task_tracking.py) | Progress updates |
| [14_with_auth.py](examples/14_with_auth.py) | Authentication |

---

## For AI Coding Assistants

See [AGENT.md](AGENT.md) for a quick reference guide optimized for AI coding assistants implementing A2A agents.

---

## 100% A2A Protocol Compatible

A2A Lite wraps the official A2A SDKs. Every feature maps to real A2A protocol concepts:

| A2A Lite | A2A Protocol |
|----------|--------------|
| `@agent.skill()` / `agent.skill()` | Agent Skills |
| `streaming=True` / `SkillConfig.withStreaming()` | SSE Streaming |
| `InteractionContext.ask()` | `input-required` state |
| `TaskContext.update()` | Task lifecycle states |
| `FilePart` | A2A File parts |
| `APIKeyAuth` / `BearerAuth` | Security schemes |

---

## Language-Specific Documentation

| Language | Package | Documentation |
|----------|---------|---------------|
| Python | [`a2a-lite`](https://pypi.org/project/a2a-lite/) | [packages/python/README.md](packages/python/README.md) |
| TypeScript | [`a2a-lite`](https://www.npmjs.com/package/a2a-lite) | [packages/typescript/README.md](packages/typescript/README.md) |
| Java | `com.a2alite:a2a-lite` | [packages/java/README.md](packages/java/README.md) |

---

## License

Apache 2.0
