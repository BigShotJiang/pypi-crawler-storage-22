"""
mDNS-based local agent discovery using Zeroconf.
"""
from __future__ import annotations

import asyncio
import socket
from typing import Dict, List, Optional
from dataclasses import dataclass

from zeroconf import ServiceBrowser, ServiceListener, Zeroconf, ServiceInfo
from zeroconf.asyncio import AsyncZeroconf, AsyncServiceBrowser


SERVICE_TYPE = "_a2a-agent._tcp.local."


@dataclass
class DiscoveredAgent:
    """Information about a discovered A2A agent."""
    name: str
    host: str
    port: int
    url: str
    properties: Dict[str, str]


class AgentDiscovery:
    """
    Discover A2A agents on the local network using mDNS.
    """

    def __init__(self):
        self._discovered: Dict[str, DiscoveredAgent] = {}
        self._zeroconf: Optional[Zeroconf] = None
        self._service_info: Optional[ServiceInfo] = None

    async def discover(self, timeout: float = 5.0) -> List[DiscoveredAgent]:
        """
        Discover agents on the local network.

        Args:
            timeout: How long to wait for discoveries

        Returns:
            List of discovered agents
        """
        self._discovered.clear()

        async with AsyncZeroconf() as azc:
            listener = _DiscoveryListener(self._discovered)
            browser = AsyncServiceBrowser(
                azc.zeroconf, SERVICE_TYPE, listener
            )

            await asyncio.sleep(timeout)
            await browser.async_cancel()

        return list(self._discovered.values())

    def register(
        self,
        name: str,
        port: int,
        properties: Optional[Dict[str, str]] = None,
    ) -> ServiceInfo:
        """
        Register this agent for discovery.

        Args:
            name: Agent name
            port: Port the agent is running on
            properties: Additional properties to advertise

        Returns:
            ServiceInfo for unregistration
        """
        hostname = socket.gethostname()
        local_ip = self._get_local_ip()

        # Sanitize name for mDNS (remove spaces and special chars)
        safe_name = "".join(c if c.isalnum() or c == "-" else "-" for c in name)

        info = ServiceInfo(
            SERVICE_TYPE,
            f"{safe_name}.{SERVICE_TYPE}",
            addresses=[socket.inet_aton(local_ip)],
            port=port,
            properties=properties or {},
            server=f"{hostname}.local.",
        )

        self._zeroconf = Zeroconf()
        self._zeroconf.register_service(info)
        self._service_info = info

        return info

    def unregister(self) -> None:
        """Unregister this agent from discovery."""
        if self._zeroconf and self._service_info:
            self._zeroconf.unregister_service(self._service_info)
            self._zeroconf.close()
            self._zeroconf = None
            self._service_info = None

    def _get_local_ip(self) -> str:
        """Get local IP address."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"


class _DiscoveryListener(ServiceListener):
    """Internal listener for mDNS service discovery."""

    def __init__(self, discovered: Dict[str, DiscoveredAgent]):
        self.discovered = discovered

    def add_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        info = zc.get_service_info(type_, name)
        if info:
            agent_name = name.replace(f".{SERVICE_TYPE}", "")
            host = socket.inet_ntoa(info.addresses[0]) if info.addresses else "localhost"
            port = info.port

            self.discovered[name] = DiscoveredAgent(
                name=agent_name,
                host=host,
                port=port,
                url=f"http://{host}:{port}",
                properties={
                    k.decode() if isinstance(k, bytes) else k:
                    v.decode() if isinstance(v, bytes) else str(v)
                    for k, v in info.properties.items()
                },
            )

    def remove_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self.discovered.pop(name, None)

    def update_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self.add_service(zc, type_, name)
