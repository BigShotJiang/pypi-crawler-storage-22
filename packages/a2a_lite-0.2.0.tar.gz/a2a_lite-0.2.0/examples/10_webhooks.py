"""
Example: Webhooks and push notifications.

Send notifications when tasks complete or progress.

Run: python examples/10_webhooks.py
"""
import asyncio
from a2a_lite import Agent


agent = Agent(
    name="WebhookDemo",
    description="Shows webhook notifications",
)


# Register completion handler - called after every successful skill
@agent.on_complete
async def notify_completion(skill_name: str, result, context):
    """
    Called after any skill completes successfully.
    Use this to send webhooks, log analytics, etc.
    """
    print(f"✅ Skill '{skill_name}' completed!")
    print(f"   Result: {result}")

    # Example: Send to webhook (if configured)
    callback_url = context.metadata.get("callback_url")
    if callback_url:
        await agent.webhook.post(
            callback_url,
            {"skill": skill_name, "result": result},
            retry=3,
        )


@agent.skill("long_task", description="A task that takes time")
async def long_task(duration: float = 2.0, callback_url: str = None) -> dict:
    """
    Simulates a long-running task.
    If callback_url is provided, we'll notify when done.
    """
    # Store callback in context for on_complete handler
    # (In real use, you'd pass this through the request)

    print(f"Starting long task ({duration}s)...")
    await asyncio.sleep(duration)

    return {
        "status": "completed",
        "duration": duration,
    }


@agent.skill("process_with_progress", description="Task with progress updates")
async def process_with_progress(
    items: int = 10,
    callback_url: str = None,
) -> dict:
    """Process items and send progress updates."""

    if callback_url:
        # Register for notifications
        task_id = f"task-{id(callback_url)}"
        agent.notifications.register(task_id, callback_url)

        for i in range(items):
            await asyncio.sleep(0.5)  # Simulate work

            # Send progress notification
            await agent.notifications.notify_progress(
                task_id,
                progress=(i + 1) / items,
                message=f"Processed {i + 1}/{items}",
            )

        # Notify completion
        result = {"processed": items, "status": "done"}
        await agent.notifications.notify_complete(task_id, result)
        return result

    else:
        # No webhook, just process
        for i in range(items):
            await asyncio.sleep(0.5)
        return {"processed": items, "status": "done"}


if __name__ == "__main__":
    agent.run(port=8787)
