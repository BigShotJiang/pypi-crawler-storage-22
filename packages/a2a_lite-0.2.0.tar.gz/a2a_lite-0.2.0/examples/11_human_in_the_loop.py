"""
Example: Human-in-the-loop (agent asks user questions).

This is the 'input-required' A2A feature - super simple to use!

Run: python examples/11_human_in_the_loop.py
"""
from a2a_lite import Agent, InteractionContext

agent = Agent(name="Wizard", description="Interactive wizard")


@agent.skill("setup_wizard")
async def setup_wizard(ctx: InteractionContext) -> dict:
    """
    Multi-step wizard that asks user questions.
    Just use `await ctx.ask()` - that's it!
    """
    # Ask questions one by one
    name = await ctx.ask("What's your name?")

    # Ask with options
    role = await ctx.ask(
        "What's your role?",
        options=["Developer", "Designer", "Manager", "Other"]
    )

    # Confirm
    if await ctx.confirm(f"Create profile for {name} ({role})?"):
        return {
            "status": "created",
            "name": name,
            "role": role,
        }
    else:
        return {"status": "cancelled"}


@agent.skill("book_flight")
async def book_flight(destination: str, ctx: InteractionContext) -> dict:
    """Book a flight with user confirmation."""

    # Ask for date
    date = await ctx.ask("What date do you want to travel? (YYYY-MM-DD)")

    # Ask for class
    travel_class = await ctx.ask(
        "Which class?",
        options=["Economy", "Business", "First"]
    )

    # Confirm booking
    if await ctx.confirm(
        f"Book {travel_class} flight to {destination} on {date}?"
    ):
        return {
            "status": "booked",
            "destination": destination,
            "date": date,
            "class": travel_class,
            "confirmation": "ABC123",
        }

    # User said no - ask if they want to change
    change = await ctx.ask(
        "What would you like to change?",
        options=["Date", "Class", "Cancel"]
    )

    if change == "Cancel":
        return {"status": "cancelled"}

    # Let them try again
    return await book_flight(destination, ctx)


if __name__ == "__main__":
    agent.run(port=8787)
