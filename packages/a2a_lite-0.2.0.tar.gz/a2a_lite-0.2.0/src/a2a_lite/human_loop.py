"""
Human-in-the-loop support (OPTIONAL).

Allows agents to ask users for clarification mid-task.
Uses A2A's "input-required" task state.

Example (simple - no human loop needed):
    @agent.skill("greet")
    async def greet(name: str) -> str:
        return f"Hello, {name}!"

Example (with human-in-the-loop - opt-in):
    @agent.skill("book_flight")
    async def book_flight(destination: str, ctx: InteractionContext) -> str:
        # Ask user for date
        date = await ctx.ask("What date do you want to travel?")

        # Ask for confirmation with options
        confirm = await ctx.ask(
            f"Book flight to {destination} on {date}?",
            options=["Yes", "No", "Change date"]
        )

        if confirm == "Yes":
            return f"Booked flight to {destination} on {date}!"
        elif confirm == "Change date":
            new_date = await ctx.ask("Enter new date:")
            return f"Booked flight to {destination} on {new_date}!"
        else:
            return "Booking cancelled."
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union
from uuid import uuid4
import asyncio


@dataclass
class InputRequest:
    """Request for user input."""
    id: str
    prompt: str
    options: Optional[List[str]] = None
    input_type: str = "text"  # text, choice, confirm, file
    required: bool = True
    default: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "prompt": self.prompt,
            "options": self.options,
            "type": self.input_type,
            "required": self.required,
            "default": self.default,
            "metadata": self.metadata,
        }


@dataclass
class InputResponse:
    """User's response to input request."""
    request_id: str
    value: Any
    metadata: Dict[str, Any] = field(default_factory=dict)


class InteractionContext:
    """
    Context for human-in-the-loop interactions.

    Passed to skills that need to ask users questions.

    Example:
        @agent.skill("wizard")
        async def wizard(ctx: InteractionContext) -> str:
            name = await ctx.ask("What's your name?")
            age = await ctx.ask("How old are you?", input_type="number")
            confirm = await ctx.confirm(f"Create profile for {name}, age {age}?")

            if confirm:
                return f"Created profile for {name}!"
            return "Cancelled."
    """

    def __init__(
        self,
        task_id: str,
        event_queue=None,
        response_handler: Optional[Callable] = None,
    ):
        self.task_id = task_id
        self._event_queue = event_queue
        self._response_handler = response_handler
        self._pending_requests: Dict[str, asyncio.Future] = {}

    async def ask(
        self,
        prompt: str,
        options: Optional[List[str]] = None,
        input_type: str = "text",
        required: bool = True,
        default: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> str:
        """
        Ask the user a question and wait for response.

        Args:
            prompt: Question to ask
            options: List of options (for choice type)
            input_type: "text", "choice", "number", "file"
            required: Whether input is required
            default: Default value if not required
            timeout: Timeout in seconds

        Returns:
            User's response

        Example:
            name = await ctx.ask("What's your name?")
            choice = await ctx.ask("Pick one:", options=["A", "B", "C"])
        """
        request = InputRequest(
            id=uuid4().hex,
            prompt=prompt,
            options=options,
            input_type="choice" if options else input_type,
            required=required,
            default=default,
        )

        # Create future for response
        future: asyncio.Future = asyncio.Future()
        self._pending_requests[request.id] = future

        # Send input-required event
        await self._send_input_request(request)

        # Wait for response
        try:
            if timeout:
                response = await asyncio.wait_for(future, timeout=timeout)
            else:
                response = await future
            return response.value
        except asyncio.TimeoutError:
            if default is not None:
                return default
            raise TimeoutError(f"No response received for: {prompt}")
        finally:
            self._pending_requests.pop(request.id, None)

    async def confirm(
        self,
        prompt: str,
        yes_label: str = "Yes",
        no_label: str = "No",
    ) -> bool:
        """
        Ask for yes/no confirmation.

        Example:
            if await ctx.confirm("Are you sure?"):
                do_something()
        """
        response = await self.ask(
            prompt,
            options=[yes_label, no_label],
            input_type="choice",
        )
        return response == yes_label

    async def choose(
        self,
        prompt: str,
        options: List[str],
        allow_multiple: bool = False,
    ) -> Union[str, List[str]]:
        """
        Ask user to choose from options.

        Example:
            color = await ctx.choose("Pick a color:", ["Red", "Blue", "Green"])
        """
        response = await self.ask(prompt, options=options, input_type="choice")
        if allow_multiple and isinstance(response, str):
            return [response]
        return response

    async def _send_input_request(self, request: InputRequest) -> None:
        """Send input-required event via SSE."""
        if self._event_queue:
            from a2a.utils import new_agent_text_message
            import json

            msg = json.dumps({
                "_type": "input_required",
                "task_id": self.task_id,
                "request": request.to_dict(),
            })
            await self._event_queue.enqueue_event(new_agent_text_message(msg))

    def handle_response(self, request_id: str, value: Any) -> bool:
        """
        Handle incoming response from user.

        Called by the executor when user responds.
        """
        future = self._pending_requests.get(request_id)
        if future and not future.done():
            response = InputResponse(request_id=request_id, value=value)
            future.set_result(response)
            return True
        return False


class ConversationMemory:
    """
    Simple conversation memory for multi-turn interactions.

    Example:
        @agent.skill("chat")
        async def chat(message: str, memory: ConversationMemory) -> str:
            # Get conversation history
            history = memory.get_messages()

            # Add user message
            memory.add_user(message)

            # Generate response (using history for context)
            response = await generate_response(message, history)

            # Add assistant response
            memory.add_assistant(response)

            return response
    """

    def __init__(self, max_messages: int = 100):
        self._messages: List[Dict[str, str]] = []
        self._max_messages = max_messages
        self._metadata: Dict[str, Any] = {}

    def add_user(self, content: str) -> None:
        """Add user message."""
        self._add_message("user", content)

    def add_assistant(self, content: str) -> None:
        """Add assistant message."""
        self._add_message("assistant", content)

    def add_system(self, content: str) -> None:
        """Add system message."""
        self._add_message("system", content)

    def _add_message(self, role: str, content: str) -> None:
        self._messages.append({"role": role, "content": content})
        # Trim if over limit
        if len(self._messages) > self._max_messages:
            self._messages = self._messages[-self._max_messages:]

    def get_messages(self) -> List[Dict[str, str]]:
        """Get all messages."""
        return list(self._messages)

    def get_last(self, n: int = 10) -> List[Dict[str, str]]:
        """Get last n messages."""
        return self._messages[-n:]

    def clear(self) -> None:
        """Clear all messages."""
        self._messages.clear()

    def set_metadata(self, key: str, value: Any) -> None:
        """Set metadata."""
        self._metadata[key] = value

    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Get metadata."""
        return self._metadata.get(key, default)
