"""
Webhook and push notification support for A2A Lite.

Simplifies sending notifications when tasks complete:

    @agent.on_complete
    async def notify(task_id, result):
        await webhook.post(callback_url, result)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional
import asyncio
import json


@dataclass
class WebhookConfig:
    """Configuration for a webhook endpoint."""
    url: str
    headers: Dict[str, str] = None
    retry_count: int = 3
    retry_delay: float = 1.0
    timeout: float = 30.0

    def __post_init__(self):
        if self.headers is None:
            self.headers = {}


class WebhookClient:
    """
    Simple webhook client for sending notifications.

    Example:
        webhook = WebhookClient()

        # Send a notification
        await webhook.post("https://example.com/callback", {"status": "done"})

        # With retries
        await webhook.post(url, data, retry=3)
    """

    def __init__(self, default_headers: Optional[Dict[str, str]] = None):
        self.default_headers = default_headers or {}

    async def post(
        self,
        url: str,
        data: Any,
        headers: Optional[Dict[str, str]] = None,
        retry: int = 0,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """
        Send a POST request to a webhook URL.

        Args:
            url: The webhook URL
            data: Data to send (will be JSON serialized)
            headers: Additional headers
            retry: Number of retries on failure
            timeout: Request timeout in seconds

        Returns:
            Response data
        """
        import httpx

        all_headers = {**self.default_headers, **(headers or {})}
        all_headers.setdefault("Content-Type", "application/json")

        last_error = None
        for attempt in range(retry + 1):
            try:
                async with httpx.AsyncClient(timeout=timeout) as client:
                    response = await client.post(
                        url,
                        json=data if isinstance(data, (dict, list)) else {"data": data},
                        headers=all_headers,
                    )
                    response.raise_for_status()
                    return {
                        "status": response.status_code,
                        "success": True,
                        "data": response.json() if response.content else None,
                    }
            except Exception as e:
                last_error = e
                if attempt < retry:
                    await asyncio.sleep(1.0 * (attempt + 1))

        return {
            "success": False,
            "error": str(last_error),
            "attempts": retry + 1,
        }

    async def notify(
        self,
        config: WebhookConfig,
        event: str,
        data: Any,
    ) -> Dict[str, Any]:
        """
        Send a notification using a WebhookConfig.

        Args:
            config: Webhook configuration
            event: Event name
            data: Event data

        Returns:
            Response data
        """
        payload = {
            "event": event,
            "data": data,
        }
        return await self.post(
            config.url,
            payload,
            headers=config.headers,
            retry=config.retry_count,
            timeout=config.timeout,
        )


class NotificationManager:
    """
    Manages push notifications for agent tasks.

    Example:
        notifications = NotificationManager()

        # Register a callback URL for a task
        notifications.register("task-123", "https://example.com/callback")

        # Later, when task completes
        await notifications.notify_complete("task-123", result)
    """

    def __init__(self):
        self._callbacks: Dict[str, WebhookConfig] = {}
        self._client = WebhookClient()

    def register(
        self,
        task_id: str,
        callback_url: str,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """Register a callback URL for a task."""
        self._callbacks[task_id] = WebhookConfig(
            url=callback_url,
            headers=headers,
        )

    def unregister(self, task_id: str) -> None:
        """Remove a callback registration."""
        self._callbacks.pop(task_id, None)

    async def notify_complete(
        self,
        task_id: str,
        result: Any,
    ) -> Optional[Dict[str, Any]]:
        """
        Notify that a task has completed.

        Args:
            task_id: The task ID
            result: The task result

        Returns:
            Webhook response or None if no callback registered
        """
        config = self._callbacks.get(task_id)
        if not config:
            return None

        response = await self._client.notify(
            config,
            event="task.completed",
            data={"task_id": task_id, "result": result},
        )

        # Clean up after notification
        self.unregister(task_id)
        return response

    async def notify_error(
        self,
        task_id: str,
        error: str,
    ) -> Optional[Dict[str, Any]]:
        """Notify that a task has failed."""
        config = self._callbacks.get(task_id)
        if not config:
            return None

        response = await self._client.notify(
            config,
            event="task.failed",
            data={"task_id": task_id, "error": error},
        )

        self.unregister(task_id)
        return response

    async def notify_progress(
        self,
        task_id: str,
        progress: float,
        message: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Notify task progress (0.0 to 1.0)."""
        config = self._callbacks.get(task_id)
        if not config:
            return None

        return await self._client.notify(
            config,
            event="task.progress",
            data={
                "task_id": task_id,
                "progress": progress,
                "message": message,
            },
        )
