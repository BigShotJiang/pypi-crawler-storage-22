"""
Tests for discovery functionality.
"""
import pytest
from a2a_lite.discovery import DiscoveredAgent, AgentDiscovery


def test_discovered_agent_creation():
    """Test DiscoveredAgent dataclass."""
    agent = DiscoveredAgent(
        name="TestAgent",
        host="192.168.1.100",
        port=8787,
        url="http://192.168.1.100:8787",
        properties={"version": "1.0.0"},
    )

    assert agent.name == "TestAgent"
    assert agent.host == "192.168.1.100"
    assert agent.port == 8787
    assert agent.url == "http://192.168.1.100:8787"
    assert agent.properties == {"version": "1.0.0"}


def test_agent_discovery_initialization():
    """Test AgentDiscovery initialization."""
    discovery = AgentDiscovery()
    assert discovery._discovered == {}
    assert discovery._zeroconf is None
    assert discovery._service_info is None


@pytest.mark.asyncio
async def test_discover_empty_network():
    """Test discovery on network with no agents."""
    discovery = AgentDiscovery()
    # Quick timeout for testing
    agents = await discovery.discover(timeout=0.1)
    # Should return empty list (no agents broadcasting)
    assert isinstance(agents, list)


def test_get_local_ip():
    """Test local IP retrieval."""
    discovery = AgentDiscovery()
    ip = discovery._get_local_ip()

    # Should return a valid IP string
    assert isinstance(ip, str)
    # Should have IP format (x.x.x.x)
    parts = ip.split(".")
    assert len(parts) == 4
    for part in parts:
        assert part.isdigit()
        assert 0 <= int(part) <= 255
