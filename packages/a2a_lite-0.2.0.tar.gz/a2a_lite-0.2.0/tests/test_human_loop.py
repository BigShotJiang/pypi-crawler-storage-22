"""
Tests for human-in-the-loop functionality.
"""
import pytest
import asyncio
from a2a_lite.human_loop import (
    InputRequest,
    InputResponse,
    InteractionContext,
    ConversationMemory,
)


class TestInputRequest:
    def test_creation(self):
        request = InputRequest(
            id="req-123",
            prompt="What's your name?",
            options=["Alice", "Bob"],
        )
        assert request.id == "req-123"
        assert request.prompt == "What's your name?"
        assert request.options == ["Alice", "Bob"]

    def test_to_dict(self):
        request = InputRequest(
            id="req-123",
            prompt="Choose:",
            options=["A", "B"],
            input_type="choice",
        )
        result = request.to_dict()

        assert result["id"] == "req-123"
        assert result["prompt"] == "Choose:"
        assert result["options"] == ["A", "B"]
        assert result["type"] == "choice"


class TestInputResponse:
    def test_creation(self):
        response = InputResponse(request_id="req-123", value="Alice")
        assert response.request_id == "req-123"
        assert response.value == "Alice"


class TestInteractionContext:
    def test_creation(self):
        ctx = InteractionContext(task_id="task-123")
        assert ctx.task_id == "task-123"

    def test_handle_response(self):
        ctx = InteractionContext(task_id="task-123")

        # Simulate pending request
        future = asyncio.Future()
        ctx._pending_requests["req-123"] = future

        # Handle response
        handled = ctx.handle_response("req-123", "Alice")

        assert handled is True
        assert future.done()
        assert future.result().value == "Alice"

    def test_handle_response_unknown(self):
        ctx = InteractionContext(task_id="task-123")

        # No pending request
        handled = ctx.handle_response("unknown", "value")

        assert handled is False


class TestConversationMemory:
    def test_add_messages(self):
        memory = ConversationMemory()

        memory.add_user("Hello")
        memory.add_assistant("Hi there!")
        memory.add_user("How are you?")

        messages = memory.get_messages()

        assert len(messages) == 3
        assert messages[0] == {"role": "user", "content": "Hello"}
        assert messages[1] == {"role": "assistant", "content": "Hi there!"}

    def test_add_system(self):
        memory = ConversationMemory()
        memory.add_system("You are a helpful assistant.")

        messages = memory.get_messages()
        assert messages[0]["role"] == "system"

    def test_get_last(self):
        memory = ConversationMemory()

        for i in range(20):
            memory.add_user(f"Message {i}")

        last_5 = memory.get_last(5)
        assert len(last_5) == 5
        assert last_5[0]["content"] == "Message 15"

    def test_clear(self):
        memory = ConversationMemory()
        memory.add_user("Hello")
        memory.add_assistant("Hi")

        memory.clear()

        assert memory.get_messages() == []

    def test_max_messages(self):
        memory = ConversationMemory(max_messages=5)

        for i in range(10):
            memory.add_user(f"Message {i}")

        messages = memory.get_messages()
        assert len(messages) == 5
        assert messages[0]["content"] == "Message 5"  # Oldest kept

    def test_metadata(self):
        memory = ConversationMemory()

        memory.set_metadata("user_id", "123")
        memory.set_metadata("session", "abc")

        assert memory.get_metadata("user_id") == "123"
        assert memory.get_metadata("session") == "abc"
        assert memory.get_metadata("nonexistent") is None
        assert memory.get_metadata("nonexistent", "default") == "default"
