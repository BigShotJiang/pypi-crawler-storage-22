"""Initialize the app"""

__version__ = "1.3.4"
__title__ = "Markettracker"
