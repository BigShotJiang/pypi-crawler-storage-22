"""Initialize the app"""

__version__ = "1.3.5"
__title__ = "Markettracker"
