"""Initialize the app"""

__version__ = "1.3.7"
__title__ = "Markettracker"
