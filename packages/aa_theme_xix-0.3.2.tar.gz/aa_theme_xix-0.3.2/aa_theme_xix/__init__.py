"""
Initialize the app
"""

__version__ = "0.3.2"
__title__ = "The Legion Of Death Theme for Alliance Auth"
