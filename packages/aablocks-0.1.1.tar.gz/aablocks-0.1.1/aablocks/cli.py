"""Command-line interface for A-Alpha Bio Data Portal.

Usage:
    aablocks login              Log in to the Data Portal
    aablocks logout             Log out and clear cached credentials
    aablocks list               List all accessible datasets
    aablocks details <id>       Show dataset metadata
    aablocks readme <id>        Show dataset README
    aablocks get <id>           Download dataset data
    aablocks config [key] [val] Get or set configuration

Options:
    -v, --version           Show version and exit
    --verbose               Enable verbose output (echo log messages)
    --help                  Show help and exit

Configuration (stored in ~/.aab/config.json):
    base_url        API endpoint URL (default: https://data-api.aalphabio.tools)
    auth_domain     Cognito auth domain (default: data-auth.aalphabio.tools)
    pool_id         Cognito user pool ID
    client_id       Cognito app client ID
    api_format      Default format for Python API: csv, pandas, polars (default: pandas)
    cli_format      Default format for CLI output: csv, table (default: csv)
    progress        Show progress bars: true, false (default: true)
    cli_verbose     Echo CLI activity to console: true, false (default: false)
    api_verbose     Echo API calls to console: true, false (default: false)

Files:
    ~/.aab/config.json                  User configuration
    ~/.aab/token.json                   Cached authentication tokens (per environment)
    ~/.aab/logs/<domain>/activity.log   API activity logs (UTC timestamps)
"""

from __future__ import annotations

import csv
import io
import json
import sys
import traceback

import click
import requests

from .auth import login, logout, set_client_type
from .client import get_dataset, get_details, get_readme, list_datasets
from .config import (
    get_api_format,
    get_api_verbose,
    get_auth_domain,
    get_base_url,
    get_cli_format,
    get_cli_verbose,
    get_client_id,
    get_pool_id,
    get_progress,
    set_config,
)
from .logging import log_error


def _format_error(e: Exception) -> str:
    """Format an exception into a user-friendly error message."""
    if isinstance(e, requests.exceptions.ConnectionError):
        return "Connection error: Unable to reach the API server. Check your network connection."
    if isinstance(e, requests.exceptions.Timeout):
        return "Request timed out. The server may be slow or unreachable."
    if isinstance(e, requests.exceptions.HTTPError):
        resp = e.response
        if resp is not None:
            if resp.status_code == 401:
                return "Authentication failed. Try running: aablocks login"
            if resp.status_code == 403:
                return (
                    "Access denied. You don't have permission to access this resource."
                )
            if resp.status_code == 404:
                return "Not found. The requested dataset or resource doesn't exist."
            if resp.status_code >= 500:
                return f"Server error ({resp.status_code}). Please try again later."
            return f"HTTP error {resp.status_code}: {resp.reason}"
    if isinstance(e, ValueError):
        return str(e)
    if isinstance(e, RuntimeError):
        return str(e)
    # Generic fallback
    return f"{type(e).__name__}: {e}"


def _handle_error(e: Exception) -> None:
    """Print a formatted error message, log full details, and exit."""
    # Log full traceback to file
    log_error(traceback.format_exc())

    # Show friendly message to user
    click.secho(f"Error: {_format_error(e)}", fg="red", err=True)
    sys.exit(1)


HELP_TEXT = """
A-Alpha Bio Data Portal CLI

Access AlphaSeq datasets from the command line.

\b
GETTING STARTED
  aablocks login              Open browser to log in
  aablocks list               Show available datasets
  aablocks get <id>           Download dataset data

\b
COMMANDS
  login       Log in to the Data Portal (opens browser)
  logout      Log out and clear cached credentials
  list        List all accessible datasets
  details     Show metadata for a dataset
  readme      Show the README for a dataset
  get         Download CSV data for a dataset
  config      Get or set configuration options

\b
EXAMPLES
  aablocks list                       List datasets as a table
  aablocks list -f json               List as JSON
  aablocks details ab1001             Show dataset metadata
  aablocks readme ab1001              Show dataset README
  aablocks get ab1001                 Print CSV to stdout
  aablocks get ab1001 -n 100          Limit to 100 rows (max 10,000)
  aablocks get ab1001 -o data.csv.gz  Download to file
  aablocks get ab1001 --mode ml       Get ML-ready variant
  aablocks --verbose list               Verbose output (show log messages)

\b
CONFIGURATION
  aablocks config                     Show current settings
  aablocks config base_url            Show API endpoint
  aablocks config auth_domain         Show Cognito auth domain
  aablocks config pool_id             Show Cognito user pool ID
  aablocks config client_id           Show Cognito app client ID
  aablocks config api_format pandas   Set Python API default format
  aablocks config cli_format table    Set CLI default output format
  aablocks config progress false      Disable progress bars
  aablocks config cli_verbose true    Enable CLI verbose logging
  aablocks config api_verbose true    Enable API verbose logging

\b
FILES
  ~/.aab/config.json                  User configuration
  ~/.aab/token.json                   Cached tokens (per environment)
  ~/.aab/logs/<domain>/activity.log   API activity logs

For more information, visit: https://atlas.aalphabio.com
"""


@click.group(help=HELP_TEXT)
@click.version_option("-v", "--version", package_name="aablocks")
@click.option(
    "--verbose",
    is_flag=True,
    default=None,
    help="Enable verbose output (echo log messages)",
)
@click.pass_context
def main(ctx: click.Context, verbose: bool | None) -> None:
    """A-Alpha Bio Data Portal CLI."""
    ctx.ensure_object(dict)

    # Set client type for API headers
    set_client_type("cli")

    # Use config value if --verbose not explicitly passed
    if verbose is None:
        verbose = get_cli_verbose()

    ctx.obj["verbose"] = verbose

    # Enable verbose if cli_verbose or api_verbose is set
    if verbose or get_api_verbose():
        from .logging import set_verbose

        set_verbose(True)


@main.command("login")
@click.option(
    "--no-callback",
    is_flag=True,
    help="Manual login for when the client cannot open the callback port",
)
def login_cmd(no_callback: bool) -> None:
    """Log in to the Data Portal."""
    try:
        login(no_callback=no_callback)
    except Exception as e:
        _handle_error(e)


@main.command("logout")
def logout_cmd() -> None:
    """Log out and clear cached credentials."""
    logout()


@main.command("config")
@click.argument("key", required=False)
@click.argument("value", required=False)
def config_cmd(key: str | None, value: str | None) -> None:
    """Get or set configuration options.

    \b
    Examples:
        aablocks config                     # Show current config
        aablocks config default_format      # Show default_format value
        aablocks config default_format csv  # Set default_format to csv

    \b
    Options:
        base_url: API endpoint URL (default: https://data-api.aalphabio.tools)
        auth_domain: Cognito auth domain (default: data-auth.aalphabio.tools)
        pool_id: Cognito user pool ID
        client_id: Cognito app client ID
        api_format: csv, pandas, or polars (default format for Python API)
        cli_format: csv or table (default format for CLI output)
        progress: true or false
        cli_verbose: true or false (echo CLI activity to console)
        api_verbose: true or false (echo API calls to console)
    """
    if key is None:
        # Show all config
        click.echo(f"base_url: {get_base_url()}")
        click.echo(f"auth_domain: {get_auth_domain()}")
        click.echo(f"pool_id: {get_pool_id()}")
        click.echo(f"client_id: {get_client_id()}")
        click.echo(f"api_format: {get_api_format()}")
        click.echo(f"cli_format: {get_cli_format()}")
        click.echo(f"progress: {str(get_progress()).lower()}")
        click.echo(f"cli_verbose: {str(get_cli_verbose()).lower()}")
        click.echo(f"api_verbose: {str(get_api_verbose()).lower()}")
    elif value is None:
        # Show specific key
        if key == "base_url":
            click.echo(get_base_url())
        elif key == "auth_domain":
            click.echo(get_auth_domain())
        elif key == "pool_id":
            click.echo(get_pool_id())
        elif key == "client_id":
            click.echo(get_client_id())
        elif key == "api_format":
            click.echo(get_api_format())
        elif key == "cli_format":
            click.echo(get_cli_format())
        elif key == "progress":
            click.echo(str(get_progress()).lower())
        elif key == "cli_verbose":
            click.echo(str(get_cli_verbose()).lower())
        elif key == "api_verbose":
            click.echo(str(get_api_verbose()).lower())
        else:
            click.echo(f"Unknown config key: {key}")
    else:
        # Set value
        if key == "base_url":
            if not value.startswith("https://"):
                click.echo(f"Invalid value for base_url: {value}")
                click.echo("Must be a valid HTTPS URL")
                return
            set_config(key, value)
            click.echo(f"Set {key} to {value}")
        elif key in ("auth_domain", "pool_id", "client_id"):
            set_config(key, value)
            click.echo(f"Set {key} to {value}")
        elif key == "api_format":
            if value not in ("csv", "pandas", "polars"):
                click.echo(f"Invalid value for api_format: {value}")
                click.echo("Must be one of: csv, pandas, polars")
                return
            # Check if the required library is installed
            if value == "pandas":
                try:
                    import pandas  # noqa: F401
                except ImportError:
                    click.secho("Error: pandas is not installed.", fg="red", err=True)
                    click.echo("You can install it with: pip install pandas")
                    return
            elif value == "polars":
                try:
                    import polars  # noqa: F401
                except ImportError:
                    click.secho("Error: polars is not installed.", fg="red", err=True)
                    click.echo("You can install it with: pip install polars")
                    return
            set_config(key, value)
            click.echo(f"Set {key} to {value}")
        elif key == "cli_format":
            if value not in ("csv", "table"):
                click.echo(f"Invalid value for cli_format: {value}")
                click.echo("Must be one of: csv, table")
                return
            set_config(key, value)
            click.echo(f"Set {key} to {value}")
        elif key == "progress":
            if value.lower() not in ("true", "false"):
                click.echo(f"Invalid value for progress: {value}")
                click.echo("Must be one of: true, false")
                return
            set_config(key, value.lower() == "true")
            click.echo(f"Set {key} to {value.lower()}")
        elif key == "cli_verbose":
            if value.lower() not in ("true", "false"):
                click.echo(f"Invalid value for cli_verbose: {value}")
                click.echo("Must be one of: true, false")
                return
            set_config(key, value.lower() == "true")
            click.echo(f"Set {key} to {value.lower()}")
        elif key == "api_verbose":
            if value.lower() not in ("true", "false"):
                click.echo(f"Invalid value for api_verbose: {value}")
                click.echo("Must be one of: true, false")
                return
            set_config(key, value.lower() == "true")
            click.echo(f"Set {key} to {value.lower()}")
        else:
            click.echo(f"Unknown config key: {key}")


@main.command("list")
@click.option(
    "--all-versions", is_flag=True, help="Include all versions of each dataset"
)
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["table", "csv", "json"]),
    default="table",
    help="Output format (default: table)",
)
def list_cmd(all_versions: bool, fmt: str) -> None:
    """List all accessible datasets."""
    try:
        datasets = list_datasets(all_versions=all_versions, format="list")
    except Exception as e:
        _handle_error(e)

    if fmt == "json":
        output = [
            {
                "id": d.id,
                "name": d.name,
                "version": d.version,
                "modes": d.modes,
                "release_date": d.release_date,
                "locked": d.locked,
                "url": d.url,
            }
            for d in datasets
        ]
        click.echo(json.dumps(output, indent=2))
    elif fmt == "csv":
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            [
                "id",
                "name",
                "version",
                "modes",
                "release_date",
                "locked",
                "url",
            ]
        )
        for d in datasets:
            writer.writerow(
                [
                    d.id,
                    d.name,
                    d.version,
                    ";".join(d.modes),
                    d.release_date,
                    d.locked,
                    d.url,
                ]
            )
        click.echo(output.getvalue(), nl=False)
    else:  # table
        if not datasets:
            click.echo("No datasets found.")
            return

        click.echo(
            f"{'ID':<12} {'Name':<30} {'Version':<8} {'Released':<12} {'Modes':<20}"
        )
        click.echo("-" * 82)
        for d in datasets:
            modes = ", ".join(d.modes)
            release = d.release_date or ""
            click.echo(
                f"{d.id:<12} {d.name:<30} {d.version:<8} {release:<12} {modes:<20}"
            )


@main.command("details")
@click.argument("dataset_id")
@click.option("--version", "-v", help="Specific version to retrieve")
def details_cmd(dataset_id: str, version: str | None) -> None:
    """Show detailed metadata for a dataset."""
    try:
        dataset = get_details(dataset_id, version=version)
    except Exception as e:
        _handle_error(e)

    click.echo(f"ID:           {dataset.id}")
    click.echo(f"Name:         {dataset.name}")
    click.echo(f"Version:      {dataset.version}")
    click.echo(f"Released:     {dataset.release_date or 'N/A'}")
    click.echo(f"Modes:        {', '.join(dataset.modes)}")
    click.echo(f"URL:          {dataset.url or 'N/A'}")
    if dataset.experiment:
        click.echo(f"Experiment:   {dataset.experiment}")
    if dataset.details:
        click.echo("Details:")
        try:
            from rich.console import Console
            from rich.markdown import Markdown

            console = Console()
            console.print(Markdown(dataset.details))
        except ImportError:
            click.echo(dataset.details)


@main.command("readme")
@click.argument("dataset_id")
@click.option("--version", "-v", help="Specific version to retrieve")
@click.option("--raw", is_flag=True, help="Output raw markdown without rendering")
def readme_cmd(dataset_id: str, version: str | None, raw: bool) -> None:
    """Show the README for a dataset."""
    try:
        readme = get_readme(dataset_id, version=version)
    except Exception as e:
        _handle_error(e)

    # Output raw markdown if --raw flag, or if not a TTY (e.g. piping/redirecting)
    if raw or not sys.stdout.isatty():
        click.echo(readme)
        return

    try:
        from rich.console import Console
        from rich.markdown import Markdown

        console = Console()
        console.print(Markdown(readme))
    except ImportError:
        click.echo(readme)


@main.command("get")
@click.argument("dataset_id")
@click.option("--version", "-v", help="Specific version to retrieve")
@click.option("--mode", "-m", help="Data mode (e.g., default, ml)")
@click.option("--max-rows", "-n", type=int, help="Maximum number of rows to return")
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["csv", "table", "gz"]),
    help="Output format: csv, table, or gz (compressed)",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path (use with -f csv or -f gz)",
)
@click.option(
    "--progress/--no-progress",
    default=None,
    help="Show download progress bar (default: from config)",
)
def get_cmd(
    dataset_id: str,
    version: str | None,
    mode: str | None,
    max_rows: int | None,
    fmt: str | None,
    output: str | None,
    progress: bool | None,
) -> None:
    """Get CSV data for a dataset."""
    # gz format only makes sense with -o
    if fmt == "gz" and not output:
        click.secho("Error: -format gz requires -o <output_file>", fg="red", err=True)
        sys.exit(1)

    try:
        # Write to file if output specified
        if output:
            # Determine if we should write compressed based on format
            write_compressed = fmt == "gz"
            get_dataset(
                dataset_id,
                version=version,
                mode=mode,
                max_rows=max_rows,
                output_path=output,
                output_compressed=write_compressed,
                progress=progress,
            )
            click.echo(f"Data written to {output}")
            return

        # Fetch as CSV for terminal output
        csv_data = get_dataset(
            dataset_id,
            version=version,
            mode=mode,
            max_rows=max_rows,
            format="csv",
        )
    except Exception as e:
        _handle_error(e)

    # Determine output format
    if not sys.stdout.isatty():
        use_table = False
    elif fmt:
        use_table = fmt == "table"
    else:
        # Use config default for terminal output
        use_table = get_cli_format() == "table"

    if use_table:
        try:
            from io import StringIO

            import pandas as pd

            df = pd.read_csv(StringIO(csv_data))  # type: ignore[arg-type]
            click.echo(df.to_string(index=False))
        except ImportError:
            click.echo(csv_data)
    else:
        click.echo(csv_data)


if __name__ == "__main__":
    main()
