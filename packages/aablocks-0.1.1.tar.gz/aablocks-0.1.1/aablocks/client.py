"""API client for the A-Alpha Bio Data Portal.

Provides programmatic access to AlphaSeq datasets.
"""

from __future__ import annotations

import gzip
import io
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import requests
from tqdm import tqdm

from .auth import get_token_header
from .config import get_api_format, get_base_url, get_progress
from .logging import log_request

MAX_ROWS_LIMIT = 10_000

# Import for type hints only - actual imports are done lazily in functions
# to avoid slow import times and allow use without these dependencies
if TYPE_CHECKING:
    import pandas as pd
    import polars as pl


@dataclass
class Dataset:
    """Dataset metadata."""

    id: str
    name: str
    experiment: str
    details: str
    modes: list[str]
    version: str
    release_date: str | None
    locked: bool
    url: str | None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Dataset:
        """Create a Dataset from API response dict."""
        return cls(
            id=data["id"],
            name=data["name"],
            experiment=data["experiment"],
            details=data["details"],
            modes=[m["name"] if isinstance(m, dict) else m for m in data["modes"]],
            version=data["version"],
            release_date=data.get("release_date"),
            locked=data.get("locked", False),
            url=data.get("url"),
        )


def list_datasets(
    all_versions: bool = False,
    format: str | None = None,
) -> list[Dataset] | str | pd.DataFrame | pl.DataFrame:
    """List all datasets accessible to the current user.

    Args:
        all_versions: If True, return all versions of each dataset.
                     If False (default), return only the latest version.
        format: Output format - "csv", "list" (Dataset objects), "pandas" (DataFrame), or "polars" (DataFrame).
                If None, uses the default from ~/.aab/config.json (defaults to "pandas").

    Returns:
        CSV string, list of Dataset objects, pandas DataFrame, or polars DataFrame depending on format.

    Raises:
        ValueError: If format is not one of "csv", "list", "pandas", or "polars".
        ImportError: If pandas/polars is required but not installed.
        requests.HTTPError: If the API request fails.

    Examples:
        >>> datasets = list_datasets()
        >>> for d in datasets:
        ...     print(f"{d.id}: {d.name}")

        >>> df = list_datasets(format="pandas")
        >>> df[["id", "name", "version"]]

        >>> df = list_datasets(all_versions=True, format="polars")
    """
    if format is None:
        format = get_api_format()

    if format not in ("csv", "list", "pandas", "polars"):
        raise ValueError(
            f"format must be 'csv', 'list', 'pandas', or 'polars', got '{format}'"
        )

    headers = get_token_header()
    params = {"all_versions": "true"} if all_versions else {}

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET", "/datasets", params or None, status_code, error_msg, latency_ms
        )

    data = resp.json()
    objects = data.get("objects", [])

    if format == "csv":
        import csv
        import io

        output = io.StringIO()
        if objects:
            writer = csv.DictWriter(output, fieldnames=objects[0].keys())
            writer.writeheader()
            writer.writerows(objects)
        return output.getvalue()

    if format == "pandas":
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError("pandas is required: pip install pandas") from e
        return pd.DataFrame(objects)

    if format == "polars":
        try:
            import polars
        except ImportError as e:
            raise ImportError("polars is required: pip install polars") from e
        return polars.DataFrame(objects)

    return [Dataset.from_dict(obj) for obj in objects]


def get_details(dataset_id: str, version: str | None = None) -> Dataset:
    """Get metadata for a specific dataset.

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.

    Returns:
        Dataset object with metadata.

    Raises:
        requests.HTTPError: If the API request fails or dataset not found.

    Examples:
        >>> dataset = get_details("ab1001")
        >>> print(dataset.name)
        >>> print(dataset.modes)  # ['default', 'ml']
        >>> print(dataset.release_date)

        >>> dataset = get_details("ab1001", version="1")
    """
    headers = get_token_header()
    params: dict[str, str] = {}
    if version:
        params["version"] = version

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets/{dataset_id}",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}",
            params or None,
            status_code,
            error_msg,
            latency_ms,
        )

    data = resp.json()
    return Dataset.from_dict(data["dataset"])


def get_readme(dataset_id: str, version: str | None = None) -> str:
    """Get the README content for a dataset.

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.

    Returns:
        README content as markdown string.

    Raises:
        requests.HTTPError: If the API request fails or dataset not found.

    Examples:
        >>> readme = get_readme("ab1001")
        >>> print(readme)

        >>> readme = get_readme("ab1001", version="1")
    """
    headers = get_token_header()
    params: dict[str, str] = {}
    if version:
        params["version"] = version

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets/{dataset_id}/readme",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}/readme",
            params or None,
            status_code,
            error_msg,
            latency_ms,
        )

    return resp.text


def get_dataset(
    dataset_id: str,
    version: str | None = None,
    mode: str | None = None,
    max_rows: int | None = None,
    format: str | None = None,
    output_path: str | None = None,
    output_compressed: bool = False,
    progress: bool | None = None,
) -> str | pd.DataFrame | pl.DataFrame | None:
    """Get CSV data for a dataset.

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.
        mode: Data mode (e.g., "default", "ml"). If not specified, uses "default".
        max_rows: Maximum number of data rows to return (max 10,000). If not specified, returns all.
        format: Output format - "csv" (string), "pandas" (DataFrame), or "polars" (DataFrame).
                If None, uses the default from ~/.aab/config.json (defaults to "pandas").
        output_path: If specified, writes to this path and returns None.
        output_compressed: If True, write gzipped data; if False, decompress first.
        progress: If True, show download progress bar.
                  If None, uses the default from ~/.aab/config.json (defaults to True).

    Returns:
        CSV data as string, pandas DataFrame, or polars DataFrame depending on format.
        Returns None if output_path is specified.

    Raises:
        ValueError: If format is not one of "csv", "pandas", or "polars".
        ImportError: If pandas/polars is required but not installed.
        requests.HTTPError: If the API request fails or dataset not found.

    Examples:
        >>> df = get_dataset("ab1001", format="pandas")
        >>> df.head()

        >>> df = get_dataset("ab1001", mode="ml", format="polars")

        >>> csv = get_dataset("ab1001")
        >>> print(csv[:100])

        >>> get_dataset("ab1001", output_path="data.csv.gz")  # Download to file
    """
    if format is None:
        format = get_api_format()

    if format not in ("csv", "pandas", "polars"):
        raise ValueError(f"format must be 'csv', 'pandas', or 'polars', got '{format}'")

    if max_rows is not None and max_rows > MAX_ROWS_LIMIT:
        raise ValueError(f"max_rows cannot exceed {MAX_ROWS_LIMIT:,}")

    if progress is None:
        progress = get_progress()

    headers = get_token_header()
    params: dict[str, str | int] = {}
    if version:
        params["version"] = version
    if mode:
        params["mode"] = mode
    if max_rows is not None:
        params["max_rows"] = max_rows

    # First get the redirect URL without downloading data
    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets/{dataset_id}/data",
            headers=headers,
            params=params,
            timeout=30,
            allow_redirects=False,  # Don't follow redirect yet
        )
        status_code = resp.status_code

        # If redirected, get the S3 URL
        if resp.status_code == 302:
            s3_url = resp.headers.get("Location")
            if not s3_url:
                raise RuntimeError("Server returned redirect without Location header")
        else:
            resp.raise_for_status()
            # No redirect - data is in response (max_rows case, already decompressed)
            s3_url = None
            data_text = resp.text
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}/data",
            dict(params) if params else None,
            status_code,
            error_msg,
            latency_ms,
        )

    # Helper to download with optional progress bar
    def _download_bytes(url: str) -> bytes:
        with requests.get(url, stream=True, timeout=300) as r:
            r.raise_for_status()
            total = int(r.headers.get("Content-Length", 0))
            chunks = []
            if progress and total:
                try:
                    with tqdm(
                        total=total, unit="B", unit_scale=True, desc="Downloading"
                    ) as pbar:
                        for chunk in r.iter_content(chunk_size=8192):
                            chunks.append(chunk)
                            pbar.update(len(chunk))
                except ImportError:
                    for chunk in r.iter_content(chunk_size=8192):
                        chunks.append(chunk)
            else:
                for chunk in r.iter_content(chunk_size=8192):
                    chunks.append(chunk)
            return b"".join(chunks)

    # Write file to disk if output_path specified
    # S3 files are always .csv.gz
    if output_path:
        if s3_url:
            data = _download_bytes(s3_url)
            if not output_compressed:
                data = gzip.decompress(data)
            with open(output_path, "wb") as f:
                f.write(data)
        else:
            # Non-redirect response is already decompressed CSV text
            with open(output_path, "w") as f:
                f.write(data_text)
        return None

    if format == "pandas":
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError("pandas is required: pip install pandas") from e
        if s3_url:
            if progress:
                data = _download_bytes(s3_url)
                return pd.read_csv(io.BytesIO(data), compression="gzip")
            return pd.read_csv(s3_url, compression="gzip")
        return pd.read_csv(io.StringIO(data_text))

    if format == "polars":
        try:
            import polars
        except ImportError as e:
            raise ImportError("polars is required: pip install polars") from e
        if s3_url:
            data = _download_bytes(s3_url)
            # polars auto-detects gzip from content
            return polars.read_csv(io.BytesIO(data))
        return polars.read_csv(io.StringIO(data_text))

    # For csv format, decompress
    if s3_url:
        data = _download_bytes(s3_url)
        return gzip.decompress(data).decode("utf-8")
    return data_text
