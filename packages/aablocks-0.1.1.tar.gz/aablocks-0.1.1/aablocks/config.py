"""Configuration management for aablocks.

Handles reading and writing settings from ~/.aab/config.json.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

CONFIG_DIR = Path("~/.aab").expanduser()
CONFIG_FILE_PATH = CONFIG_DIR / "config.json"


def get_config() -> dict[str, Any]:
    """Load config from ~/.aab/config.json."""
    if CONFIG_FILE_PATH.exists():
        with open(CONFIG_FILE_PATH) as f:
            return json.load(f)
    return {}


def write_secure_file(path: Path, data: dict[str, Any]) -> None:
    """Write JSON data to a file with restrictive permissions (0600 on Unix)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    # Set restrictive permissions before writing content to avoid race condition
    # Windows (i.e. `nt`) relies on user directory ACLs
    if os.name != "nt":
        # Create empty file with secure permissions, then write
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
    else:
        with open(path, "w") as f:
            json.dump(data, f, indent=2)


def set_config(key: str, value: Any) -> None:
    """Set a config value in ~/.aab/config.json."""
    config = get_config()
    config[key] = value
    write_secure_file(CONFIG_FILE_PATH, config)


def get_api_format() -> str:
    """Get the default Python API format from config, defaults to 'pandas'.

    Valid values: csv, pandas, polars
    """
    return get_config().get("api_format", "pandas")


def get_cli_format() -> str:
    """Get the default CLI format from config, defaults to 'csv'.

    Valid values: csv, table
    """
    return get_config().get("cli_format", "csv")


def get_progress() -> bool:
    """Get whether to show progress bars, defaults to True."""
    return get_config().get("progress", True)


def get_cli_verbose() -> bool:
    """Get whether to show verbose log output in CLI, defaults to False."""
    return get_config().get("cli_verbose", False)


def get_api_verbose() -> bool:
    """Get whether to show verbose log output for API calls, defaults to False."""
    return get_config().get("api_verbose", False)


def get_auth_domain() -> str:
    """Get the Cognito auth domain, defaults to production."""
    return get_config().get("auth_domain", "data-auth.aalphabio.tools")


def get_pool_id() -> str:
    """Get the Cognito user pool ID, defaults to production."""
    return get_config().get("pool_id", "us-east-2_18ZA7hgrh")


def get_client_id() -> str:
    """Get the Cognito app client ID, defaults to production."""
    return get_config().get("client_id", "7vh1h6kfah3qf9inb4q79bfl0c")


def get_base_url() -> str:
    """Get the API base URL from config, defaults to production.

    Valid values: any URL, or use set_config("base_url", url) to configure.
    """
    return get_config().get("base_url", "https://data-api.aalphabio.tools/api/v1")
