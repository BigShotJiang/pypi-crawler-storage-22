"""A-Alpha Bio Data Portal client for accessing AlphaSeq datasets.

Python API:
    from aablocks import list_datasets, get_dataset, get_details, get_readme, login, logout

    # List all datasets (as pandas DataFrame by default)
    df = list_datasets()

    # Get dataset as pandas DataFrame
    df = get_dataset("ab1001", format="pandas")

    # Get dataset metadata
    details = get_details("ab1001")

    # Get dataset README
    readme = get_readme("ab1001")

CLI:
    aablocks login          Log in to the Data Portal
    aablocks logout         Log out and clear cached credentials
    aablocks list           List all accessible datasets
    aablocks details <id>   Show dataset metadata
    aablocks readme <id>    Show dataset README
    aablocks get <id>       Download dataset data
    aablocks structures <id> Download structure files as zip
    aablocks config         Get or set configuration options

Configuration:
    Settings stored in ~/.aab/config.json
    Tokens cached in ~/.aab/token.json (per environment)
    Logs written to ~/.aab/logs/<domain>/activity.log
"""

__version__ = "0.1.7"

from .auth import login, logout
from .config import set_config
from .client import (
    Dataset,
    download_structures,
    get_dataset,
    get_details,
    get_readme,
    get_schema,
    list_datasets,
    pandas_schema_to_polars,
)

__all__ = [
    "Dataset",
    "download_structures",
    "get_dataset",
    "get_details",
    "get_readme",
    "get_schema",
    "list_datasets",
    "login",
    "logout",
    "pandas_schema_to_polars",
    "set_config",
]
