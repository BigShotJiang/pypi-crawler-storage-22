"""OAuth2 authentication with AWS Cognito using PKCE flow.

Handles browser-based login, token caching, and automatic token refresh.
"""

from __future__ import annotations

import base64
import errno
import hashlib
import html
import json
import os
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from time import time
from typing import Any
from urllib.parse import parse_qs, urlparse

import requests
from oauthlib.oauth2 import WebApplicationClient

from .cached_token import clear_cached_token, get_cached_token, set_cached_token
from .config import (
    CONFIG_DIR,
    get_auth_domain,
    write_secure_file,
)
from .config import (
    get_client_id as _config_client_id,
)
from .logging import log_auth

SCOPE: list[str] = []


def _get_cognito_urls() -> tuple[str, str]:
    """Get authorize and token URLs for current environment."""
    domain = get_auth_domain()
    authorize_url = f"https://{domain}/login"
    token_url = f"https://{domain}/oauth2/token"
    return authorize_url, token_url


def _get_client_id() -> str:
    """Get Cognito client ID for current environment."""
    return _config_client_id()


REDIRECT_HOST = "localhost"
REDIRECT_PORT = 6565
REDIRECT_PATH = "/callback"
REDIRECT_URI = f"http://{REDIRECT_HOST}:{REDIRECT_PORT}{REDIRECT_PATH}"

TOKEN_FILE_PATH = CONFIG_DIR / "token.json"

TOKEN_EXPIRY_BUFFER_SECONDS = 60  # Refresh tokens this many seconds before expiry

# Client type for headers (can be set by CLI to override default "api")
_client_type: str = "api"


def get_token() -> dict[str, Any]:
    """Get the current token, loading from cache or triggering login if needed."""
    token = _load_token()
    if token:
        return token
    login()
    token = get_cached_token(get_auth_domain())
    if token is None:
        raise RuntimeError("Login failed to cache token")
    return token


def set_client_type(client_type: str) -> None:
    """Set the client type for API request headers.

    Args:
        client_type: The client type identifier ("api", "cli", or "webapp").
    """
    global _client_type
    _client_type = client_type


def get_token_header() -> dict[str, str]:
    """Return headers for API requests including auth and client identification.

    Returns:
        Dict with Authorization, X-Client-Type, and X-Client-Version headers.
    """
    from . import __version__

    token = get_token()
    id_token = token.get("id_token")
    if not id_token:
        raise RuntimeError("No id_token available in token response")
    return {
        "Authorization": f"Bearer {id_token}",
        "X-Client-Type": _client_type,
        "X-Client-Version": __version__,
    }


def login(no_callback: bool = False) -> None:
    """Run OAuth2 authorization-code + PKCE flow against Cognito.

    If already logged in with a valid token, this is a no-op.

    Args:
        no_callback: If True, use manual flow where user pastes the redirect URL.
                     Useful when the client cannot open the callback port.
    """
    token = _load_token()
    if token:
        return

    client_id = _get_client_id()
    authorize_url, token_url = _get_cognito_urls()

    client = WebApplicationClient(client_id)
    state_out = str(uuid.uuid4())

    # PKCE
    code_verifier = _generate_code_verifier()
    code_challenge = _generate_code_challenge(code_verifier)

    # Build authorization URL with PKCE params
    authorization_url = client.prepare_request_uri(
        authorize_url,
        redirect_uri=REDIRECT_URI,
        scope=SCOPE,
        state=state_out,
        code_challenge=code_challenge,
        code_challenge_method="S256",
    )

    if no_callback:
        code = _manual_login_flow(authorization_url, state_out)
    else:
        code = _browser_login_flow(authorization_url, state_out)

    # Exchange code for token
    _exchange_code_for_token(client, token_url, code, code_verifier)


def _browser_login_flow(authorization_url: str, expected_state: str) -> str:
    """Run the browser-based login flow with local callback server.

    Falls back to manual flow if the callback port cannot be opened
    or if no browser is available (e.g., headless environment).

    Returns the authorization code.
    """
    # Start local HTTP server (handles 1 request)
    try:
        httpd: HTTPServer = HTTPServer(
            (REDIRECT_HOST, REDIRECT_PORT), _OAuthCallbackHandler
        )
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            print(
                f"Warning: Cannot open callback port {REDIRECT_PORT} (already in use).\n"
                f"         Falling back to manual login.\n"
            )
            return _manual_login_flow(authorization_url, expected_state)
        raise
    httpd.timeout = 300  # 5 minute timeout for the socket

    def serve() -> None:
        """Handle a single OAuth callback request."""
        httpd.handle_request()

    server_thread = threading.Thread(target=serve, daemon=True)
    server_thread.start()

    print("Opening browser for authentication...")
    print("If it doesn't open automatically, visit this URL:")
    print(authorization_url)

    browser_opened = webbrowser.open(authorization_url, new=1, autoraise=True)

    if not browser_opened:
        httpd.server_close()
        print(
            "\nWarning: Could not open browser.\n"
            "         Falling back to manual login.\n"
        )
        return _manual_login_flow(authorization_url, expected_state)

    # Wait for redirect with timeout
    server_thread.join(timeout=300)
    if server_thread.is_alive():
        httpd.shutdown()
        raise RuntimeError("Authentication timed out after 5 minutes")

    auth_error = getattr(httpd, "auth_error", None)
    if auth_error:
        raise RuntimeError(f"OAuth error: {auth_error}")

    code = getattr(httpd, "auth_code", None)
    if not code:
        raise RuntimeError("No authorization code received")

    return code


def _manual_login_flow(authorization_url: str, expected_state: str) -> str:
    """Run the manual login flow for headless environments.

    User visits the URL in a browser elsewhere, then pastes the redirect URL.

    Returns the authorization code.
    """
    print("Visit this URL in a browser to log in:")
    print()
    print(f"  {authorization_url}")
    print()
    print("After logging in, you'll be redirected to a URL starting with:")
    print(f"  {REDIRECT_URI}?code=...")
    print()
    print("Copy the entire URL from your browser's address bar and paste it below.")
    print("(The page may show an error - that's expected)")
    print()

    redirect_input = input("Paste redirect URL: ").strip()

    # Parse the redirect URL to extract code and state
    parsed = urlparse(redirect_input)
    query = parse_qs(parsed.query)

    code = query.get("code", [None])[0]
    if not code:
        raise RuntimeError(
            "Could not find authorization code in the URL. "
            "Make sure you copied the entire redirect URL."
        )

    state = query.get("state", [None])[0]
    if state != expected_state:
        raise RuntimeError("Authorization state mismatch. Please try again.")

    return code


def _exchange_code_for_token(
    client: WebApplicationClient,
    token_url: str,
    code: str,
    code_verifier: str,
) -> None:
    """Exchange an authorization code for tokens and save them."""
    final_token_url, headers, body = client.prepare_token_request(
        token_url,
        redirect_url=REDIRECT_URI,
        code=code,
        include_client_id=True,
        code_verifier=code_verifier,
    )

    headers["Content-Type"] = "application/x-www-form-urlencoded"

    token_response = requests.post(
        final_token_url,
        headers=headers,
        data=body,
        timeout=30,
    )
    token_response.raise_for_status()

    client.parse_request_body_response(token_response.text)

    _save_token(client.token)

    log_auth("login", success=True)

    print("\nLogged in successfully.")


def logout() -> None:
    """Clear cached token for the current auth domain."""
    auth_domain = get_auth_domain()
    clear_cached_token(auth_domain)

    if TOKEN_FILE_PATH.exists():
        with open(TOKEN_FILE_PATH) as f:
            stored = json.load(f)

        if auth_domain in stored:
            del stored[auth_domain]
            if stored:
                write_secure_file(TOKEN_FILE_PATH, stored)
            else:
                TOKEN_FILE_PATH.unlink()
            log_auth("logout", success=True)
            print("Logged out successfully.")
        else:
            print("No active session.")
    else:
        print("No active session.")


def _generate_code_verifier(length: int = 64) -> str:
    """Generate a high-entropy PKCE code_verifier (43-128 chars)."""
    verifier = base64.urlsafe_b64encode(os.urandom(length)).decode("ascii")
    return verifier.rstrip("=")


def _generate_code_challenge(verifier: str) -> str:
    """Generate an S256 PKCE code_challenge from a verifier."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).decode("ascii")
    return challenge.rstrip("=")


PAGES_DIR = Path(__file__).parent / "pages"


def _load_image_base64(filename: str) -> str:
    """Load an image file and return its base64-encoded contents."""
    path = PAGES_DIR / "images" / filename
    if path.exists():
        return base64.b64encode(path.read_bytes()).decode("ascii")
    return ""


def _load_svg_content(filename: str) -> str:
    """Load an SVG file and return its contents."""
    path = PAGES_DIR / "images" / filename
    if path.exists():
        return path.read_text()
    return ""


def _render_page(name: str, **kwargs: str) -> str:
    """Load an HTML template and substitute {{key}} placeholders with escaped values.

    Newlines in values are converted to <br> tags after escaping.
    """
    template = (PAGES_DIR / name).read_text()
    template = template.replace("{{logo_base64}}", _load_image_base64("logo.png"))
    template = template.replace("{{favicon_base64}}", _load_image_base64("favicon.png"))

    # Add status icon based on status
    status = kwargs.get("status", "")
    if status == "success":
        template = template.replace("{{status_icon}}", _load_svg_content("success.svg"))
    elif status == "error":
        template = template.replace("{{status_icon}}", _load_svg_content("error.svg"))

    for key, value in kwargs.items():
        escaped = html.escape(value).replace("\n", "<br>")
        template = template.replace("{{" + key + "}}", escaped)

    return template


class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    """Handle the redirect back to REDIRECT_URI.

    Stores the auth code + state (or an error) on the HTTPServer instance.
    """

    def do_GET(self) -> None:
        """Process the OAuth callback request and extract query parameters."""
        parsed = urlparse(self.path)

        if parsed.path != REDIRECT_PATH:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")
            return

        query = parse_qs(parsed.query)

        # Attach data to the server instance
        self.server.auth_code = query.get("code", [None])[0]  # type: ignore[attr-defined]
        self.server.auth_error = query.get("error", [None])[0]  # type: ignore[attr-defined]
        self.server.auth_state = query.get("state", [None])[0]  # type: ignore[attr-defined]

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        if self.server.auth_error:  # type: ignore[attr-defined]
            page = _render_page(
                "auth_complete.html",
                title="Authentication Failed",
                message="Authentication failed.\nYou may close this window.",
                status="error",
            )
        else:
            page = _render_page(
                "auth_complete.html",
                title="Authentication Complete",
                message="Authentication complete.\nYou may close this window.",
                status="success",
            )
        self.wfile.write(page.encode("utf-8"))

    def log_message(self, format: str, *args: Any) -> None:
        """Silence the default HTTP request logging."""


def _load_token() -> dict[str, Any] | None:
    """Load a token from disk and refresh it if expired (or about to expire)."""
    auth_domain = get_auth_domain()

    # Check in-memory cache first
    cached = get_cached_token(auth_domain)
    if cached:
        expires_at_raw = cached.get("expires_at")
        if expires_at_raw is not None:
            expires_at = int(expires_at_raw)
            if float(expires_at - TOKEN_EXPIRY_BUFFER_SECONDS) >= time():
                return cached

    # Load from disk
    token: dict[str, Any] | None = None
    if TOKEN_FILE_PATH.exists():
        with open(TOKEN_FILE_PATH) as f:
            stored = json.load(f)

        token = stored.get(auth_domain)

        if token:
            expires_at_raw = token.get("expires_at")
            if expires_at_raw is not None:
                expires_at = int(expires_at_raw)
                # Refresh if expired or expiring within buffer period
                if float(expires_at - TOKEN_EXPIRY_BUFFER_SECONDS) < time():
                    token = _refresh(token)
            else:
                # If we don't have an expires_at, assume refresh is needed if possible
                token = _refresh(token)

    if token:
        set_cached_token(auth_domain, token)
    return token


def _save_token(token: dict[str, Any]) -> None:
    """Persist the token to disk and update the in-memory cache."""
    auth_domain = get_auth_domain()

    # Ensure we have an absolute expiry timestamp for local caching.
    if "expires_at" not in token:
        expires_in = token.get("expires_in")
        if expires_in is not None:
            token["expires_at"] = int(time()) + int(expires_in)

    set_cached_token(auth_domain, token)

    # Merge into existing token file (preserving other domains' tokens)
    stored: dict[str, Any] = {}
    if TOKEN_FILE_PATH.exists():
        with open(TOKEN_FILE_PATH) as f:
            stored = json.load(f)
    stored[auth_domain] = token
    write_secure_file(TOKEN_FILE_PATH, stored)


def _refresh(old_token: dict[str, Any]) -> dict[str, Any] | None:
    """Refresh an existing token using its refresh_token, if present.

    Returns None if refresh fails (e.g., token expired, revoked, or no refresh_token).
    The caller should trigger a new login flow when this returns None.
    """
    refresh_token = old_token.get("refresh_token")
    if not refresh_token:
        log_auth("refresh", success=False, error="no refresh_token")
        return None

    _, token_url = _get_cognito_urls()
    client_id = _get_client_id()

    try:
        res = requests.post(
            token_url,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "refresh_token",
                "client_id": client_id,
                "refresh_token": refresh_token,
            },
            timeout=30,
        )
    except requests.RequestException as e:
        log_auth("refresh", success=False, error=str(e))
        print(f"Token refresh failed: {e}. You may need to log in again.")
        return None

    if not res.ok:
        log_auth("refresh", success=False, error=f"status={res.status_code}")
        print(
            f"Token refresh failed (status {res.status_code}). You may need to log in again."
        )
        return None

    new_token: dict[str, Any] = res.json()

    # Cognito may omit refresh_token on refresh; carry it forward.
    if "refresh_token" not in new_token:
        new_token["refresh_token"] = refresh_token

    # Compute expires_at for local caching.
    if "expires_in" in new_token:
        new_token["expires_at"] = int(time()) + int(new_token["expires_in"])

    _save_token(new_token)
    log_auth("refresh", success=True)
    return new_token
