"""API client for the A-Alpha Bio Data Portal.

Provides programmatic access to AlphaSeq datasets.
"""

from __future__ import annotations

import gzip
import io
import time
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

import requests
from tqdm import tqdm

from .auth import get_token_header
from .config import get_api_format, get_base_url, get_progress
from .logging import log_request

# Import for type hints only - actual imports are done lazily in functions
# to avoid slow import times and allow use without these dependencies
if TYPE_CHECKING:
    import pandas as pd
    import polars as pl


@dataclass
class Dataset:
    """Dataset metadata."""

    id: str
    name: str
    experiment: str
    details: str
    modes: list[str]
    version: str
    release_date: str | None
    locked: bool
    url: str | None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Dataset:
        """Create a Dataset from API response dict."""
        return cls(
            id=data["id"],
            name=data["name"],
            experiment=data["experiment"],
            details=data["details"],
            modes=[m["name"] if isinstance(m, dict) else m for m in data["modes"]],
            version=data["version"],
            release_date=data.get("release_date"),
            locked=data.get("locked", False),
            url=data.get("url"),
        )


def list_datasets(
    all_versions: bool = False,
    format: str | None = None,
) -> list[Dataset] | str | pd.DataFrame | pl.DataFrame:
    """List all datasets accessible to the current user.

    Args:
        all_versions: If True, return all versions of each dataset.
                     If False (default), return only the latest version.
        format: Output format - "csv", "list" (Dataset objects), "pandas" (DataFrame), or "polars" (DataFrame).
                If None, uses the default from ~/.aab/config.json (defaults to "pandas").

    Returns:
        CSV string, list of Dataset objects, pandas DataFrame, or polars DataFrame depending on format.

    Raises:
        ValueError: If format is not one of "csv", "list", "pandas", or "polars".
        ImportError: If pandas/polars is required but not installed.
        requests.HTTPError: If the API request fails.

    Examples:
        >>> datasets = list_datasets()
        >>> for d in datasets:
        ...     print(f"{d.id}: {d.name}")

        >>> df = list_datasets(format="pandas")
        >>> df[["id", "name", "version"]]

        >>> df = list_datasets(all_versions=True, format="polars")
    """
    if format is None:
        format = get_api_format()

    if format not in ("csv", "list", "pandas", "polars"):
        raise ValueError(
            f"format must be 'csv', 'list', 'pandas', or 'polars', got '{format}'"
        )

    headers = get_token_header()
    params = {"all_versions": "true"} if all_versions else {}

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET", "/datasets", params or None, status_code, error_msg, latency_ms
        )

    data = resp.json()
    objects = data.get("objects", [])

    if format == "csv":
        import csv
        import io

        output = io.StringIO()
        if objects:
            writer = csv.DictWriter(output, fieldnames=objects[0].keys())
            writer.writeheader()
            writer.writerows(objects)
        return output.getvalue()

    if format == "pandas":
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError("pandas is required: pip install pandas") from e
        return pd.DataFrame(objects)

    if format == "polars":
        try:
            import polars
        except ImportError as e:
            raise ImportError("polars is required: pip install polars") from e
        return polars.DataFrame(objects)

    return [Dataset.from_dict(obj) for obj in objects]


def get_details(dataset_id: str, version: str | None = None) -> Dataset:
    """Get metadata for a specific dataset.

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.

    Returns:
        Dataset object with metadata.

    Raises:
        requests.HTTPError: If the API request fails or dataset not found.

    Examples:
        >>> dataset = get_details("ab1001")
        >>> print(dataset.name)
        >>> print(dataset.modes)  # ['default', 'ml']
        >>> print(dataset.release_date)

        >>> dataset = get_details("ab1001", version="1")
    """
    headers = get_token_header()
    params: dict[str, str] = {}
    if version:
        params["version"] = version

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets/{dataset_id}",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}",
            params or None,
            status_code,
            error_msg,
            latency_ms,
        )

    data = resp.json()
    return Dataset.from_dict(data["dataset"])


def get_readme(dataset_id: str, version: str | None = None) -> str:
    """Get the README content for a dataset.

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.

    Returns:
        README content as markdown string.

    Raises:
        requests.HTTPError: If the API request fails or dataset not found.

    Examples:
        >>> readme = get_readme("ab1001")
        >>> print(readme)

        >>> readme = get_readme("ab1001", version="1")
    """
    headers = get_token_header()
    params: dict[str, str] = {}
    if version:
        params["version"] = version

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets/{dataset_id}/readme",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}/readme",
            params or None,
            status_code,
            error_msg,
            latency_ms,
        )

    return resp.text


def get_schema(
    dataset_id: str,
    version: str | None = None,
    mode: str | None = None,
) -> dict[str, Any]:
    """Get the CSV schema for a dataset.

    The returned dict can be unpacked directly into pd.read_csv():
        schema = get_schema("ab1001")
        df = pd.read_csv("data.csv", **schema)

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.
        mode: Data mode (e.g., "default", "ml"). Defaults to server default.

    Returns:
        Dict with 'dtype' (column name -> pandas dtype) and 'parse_dates' (list of column names).

    Raises:
        requests.HTTPError: If the API request fails or schema not found.

    Examples:
        >>> schema = get_schema("ab1001")
        >>> schema
        {'dtype': {'id': 'Int64', 'name': 'string'}, 'parse_dates': ['created_at']}

        >>> schema = get_schema("ab1001", mode="ml")
        >>> df = pd.read_csv("data.csv", **schema)
    """
    headers = get_token_header()
    params: dict[str, str] = {}
    if version:
        params["version"] = version
    if mode:
        params["mode"] = mode

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets/{dataset_id}/schema",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}/schema",
            params or None,
            status_code,
            error_msg,
            latency_ms,
        )

    return resp.json()


def get_dataset(
    dataset_id: str,
    version: str | None = None,
    mode: str | None = None,
    format: str | None = None,
    output_path: str | None = None,
    output_compressed: bool = False,
    progress: bool | None = None,
    schema: bool = True,
) -> str | pd.DataFrame | pl.DataFrame | None:
    """Get CSV data for a dataset.

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.
        mode: Data mode (e.g., "default", "ml"). If not specified, uses "default".
        format: Output format - "csv" (string), "pandas" (DataFrame), or "polars" (DataFrame).
                If None, uses the default from ~/.aab/config.json (defaults to "pandas").
        output_path: If specified, writes to this path and returns None.
        output_compressed: If True, write gzipped data; if False, decompress first.
        progress: If True, show download progress bar.
                  If None, uses the default from ~/.aab/config.json (defaults to True).
        schema: If True (default), fetch and apply the dataset's column schema
                for proper dtype handling. Set to False to skip schema fetching.

    Returns:
        CSV data as string, pandas DataFrame, or polars DataFrame depending on format.
        Returns None if output_path is specified.

    Raises:
        ValueError: If format is not one of "csv", "pandas", or "polars".
        ImportError: If pandas/polars is required but not installed.
        requests.HTTPError: If the API request fails or dataset not found.

    Examples:
        >>> df = get_dataset("ab1001", format="pandas")
        >>> df.head()

        >>> df = get_dataset("ab1001", mode="ml", format="polars")

        >>> csv = get_dataset("ab1001")
        >>> print(csv[:100])

        >>> get_dataset("ab1001", output_path="data.csv.gz")  # Download to file
    """
    if format is None:
        format = get_api_format()

    if format not in ("csv", "pandas", "polars"):
        raise ValueError(f"format must be 'csv', 'pandas', or 'polars', got '{format}'")

    if progress is None:
        progress = get_progress()

    headers = get_token_header()
    params: dict[str, str] = {"redirect": "false"}
    if version:
        params["version"] = version
    if mode:
        params["mode"] = mode

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}/datasets/{dataset_id}/data",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}/data",
            dict(params) if params else None,
            status_code,
            error_msg,
            latency_ms,
        )

    body = resp.json()
    s3_url: str = body["url"]
    schema_data: dict[str, Any] = body.get("schema", {}) if schema else {}

    log_request(
        "GET",
        f"/datasets/{dataset_id}/data",
        {
            "id": dataset_id,
            "version": version or "latest",
            "url": s3_url,
            "schema": str(schema_data) if schema_data else "none",
        },
    )

    # Helper to download with optional progress bar
    def _download_bytes(url: str) -> bytes:
        with requests.get(url, stream=True, timeout=300) as r:
            r.raise_for_status()
            total = int(r.headers.get("Content-Length", 0))
            chunks = []
            if progress and total:
                try:
                    with tqdm(
                        total=total, unit="B", unit_scale=True, desc="Downloading"
                    ) as pbar:
                        for chunk in r.iter_content(chunk_size=8192):
                            chunks.append(chunk)
                            pbar.update(len(chunk))
                except ImportError:
                    for chunk in r.iter_content(chunk_size=8192):
                        chunks.append(chunk)
            else:
                for chunk in r.iter_content(chunk_size=8192):
                    chunks.append(chunk)
            return b"".join(chunks)

    # Write file to disk if output_path specified
    if output_path:
        data = _download_bytes(s3_url)
        if not output_compressed:
            data = gzip.decompress(data)
        with open(output_path, "wb") as f:
            f.write(data)
        return None

    if format == "pandas":
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError("pandas is required: pip install pandas") from e
        # low_memory=False: read entire file at once to avoid spurious DtypeWarning
        # from chunked inference. Safe because the file is already fully downloaded.
        read_kwargs = {"compression": "gzip", "low_memory": False, **schema_data}
        if progress:
            data = _download_bytes(s3_url)
            return pd.read_csv(io.BytesIO(data), **read_kwargs)
        return pd.read_csv(s3_url, **read_kwargs)

    if format == "polars":
        try:
            import polars
        except ImportError as e:
            raise ImportError("polars is required: pip install polars") from e
        polars_kwargs = pandas_schema_to_polars(schema_data)
        data = _download_bytes(s3_url)
        return polars.read_csv(io.BytesIO(data), **polars_kwargs)

    # For csv format, decompress
    data = _download_bytes(s3_url)
    return gzip.decompress(data).decode("utf-8")


def download_structures(
    dataset_id: str,
    version: str | None = None,
    output_path: str | None = None,
    progress: bool | None = None,
) -> str:
    """Download all structure files for a dataset as a zip archive.

    Args:
        dataset_id: The dataset identifier (e.g., "ab1001").
        version: Optional version number. If not specified, returns latest.
        output_path: Output file path. Defaults to the filename from the S3 URL.
        progress: If True, show download progress bar.
                  If None, uses the default from ~/.aab/config.json.

    Returns:
        The output file path.

    Raises:
        requests.HTTPError: If the API request fails or dataset not found.

    Examples:
        >>> download_structures("ab1614")
        >>> download_structures("ab1614", output_path="my_structures.zip")
    """
    if progress is None:
        progress = get_progress()

    headers = get_token_header()
    params: dict[str, str] = {}
    if version:
        params["version"] = version

    endpoint = f"/datasets/{dataset_id}/structures/download"

    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        resp = requests.get(
            f"{get_base_url()}{endpoint}",
            headers=headers,
            params=params,
            timeout=30,
        )
        status_code = resp.status_code
        resp.raise_for_status()
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request("GET", endpoint, params or None, status_code, error_msg, latency_ms)

    s3_url: str = resp.json()["url"]

    if output_path is None:
        output_path = PurePosixPath(urlparse(s3_url).path).name

    # Stream download from S3 to file
    start_time = time.time()
    error_msg = None
    status_code = None
    try:
        with requests.get(s3_url, stream=True, timeout=600) as r:
            status_code = r.status_code
            r.raise_for_status()
            total = int(r.headers.get("Content-Length", 0))
            with open(output_path, "wb") as f:
                if progress and total:
                    try:
                        with tqdm(
                            total=total, unit="B", unit_scale=True, desc="Downloading"
                        ) as pbar:
                            for chunk in r.iter_content(chunk_size=8192):
                                f.write(chunk)
                                pbar.update(len(chunk))
                    except ImportError:
                        for chunk in r.iter_content(chunk_size=8192):
                            f.write(chunk)
                else:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
    except requests.RequestException as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms = int((time.time() - start_time) * 1000)
        log_request(
            "GET",
            f"/datasets/{dataset_id}/structures/download (S3)",
            {"output_path": output_path},
            status_code,
            error_msg,
            latency_ms,
        )

    return output_path


def pandas_schema_to_polars(schema: dict[str, Any]) -> dict[str, Any]:
    """Convert a pandas CSV schema dict to polars-compatible kwargs.

    Takes the schema dict from get_schema() (designed for pd.read_csv) and
    converts it to kwargs suitable for polars.read_csv().

    Args:
        schema: Pandas schema dict with 'dtype' and optionally 'parse_dates'.

    Returns:
        Dict with 'schema_overrides' and 'try_parse_dates' for polars.read_csv().

    Examples:
        >>> schema = get_schema("ab1001")
        >>> polars_kwargs = pandas_schema_to_polars(schema)
        >>> df = polars.read_csv("data.csv", **polars_kwargs)
    """
    import polars as pl

    PANDAS_TO_POLARS = {
        "int64": pl.Int64,
        "Int64": pl.Int64,
        "int32": pl.Int32,
        "Int32": pl.Int32,
        "int16": pl.Int16,
        "Int16": pl.Int16,
        "int8": pl.Int8,
        "Int8": pl.Int8,
        "uint64": pl.UInt64,
        "UInt64": pl.UInt64,
        "uint32": pl.UInt32,
        "UInt32": pl.UInt32,
        "uint16": pl.UInt16,
        "UInt16": pl.UInt16,
        "uint8": pl.UInt8,
        "UInt8": pl.UInt8,
        "float64": pl.Float64,
        "Float64": pl.Float64,
        "float32": pl.Float32,
        "Float32": pl.Float32,
        "bool": pl.Boolean,
        "boolean": pl.Boolean,
        "string": pl.Utf8,
        "object": pl.Utf8,
        "str": pl.Utf8,
        "category": pl.Categorical,
    }

    overrides: dict[str, Any] = {}
    for col, pd_dtype in schema.get("dtype", {}).items():
        overrides[col] = PANDAS_TO_POLARS.get(pd_dtype, pl.Utf8)

    result: dict[str, Any] = {}
    if overrides:
        result["schema_overrides"] = overrides
    if schema.get("parse_dates"):
        result["try_parse_dates"] = True
    return result
