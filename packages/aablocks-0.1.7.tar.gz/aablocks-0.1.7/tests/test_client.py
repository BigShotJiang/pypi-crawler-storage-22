"""Tests for aablocks.client module."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests

from aablocks.client import Dataset, get_dataset, get_details, get_readme, list_datasets

from .conftest import SAMPLE_DATASET_DICT, SAMPLE_DATASETS_RESPONSE


# ---------------------------------------------------------------------------
# Dataset dataclass
# ---------------------------------------------------------------------------
class TestDataset:
    def test_from_dict(self):
        """Constructs a Dataset with all fields from a complete API response dict."""
        ds = Dataset.from_dict(SAMPLE_DATASET_DICT)
        assert ds.id == "ab1001"
        assert ds.name == "Test Dataset"
        assert ds.experiment == "Yeast Display"
        assert ds.modes == ["default", "ml"]
        assert ds.version == "3"
        assert ds.release_date == "2025-01-15"
        assert ds.locked is False
        assert ds.url == "https://data.example.com/ab1001"

    def test_from_dict_optional_fields(self):
        """Optional fields default to None/False when missing from the dict."""
        minimal = {
            "id": "ab9999",
            "name": "Minimal",
            "experiment": "",
            "details": "",
            "modes": [],
            "version": "1",
        }
        ds = Dataset.from_dict(minimal)
        assert ds.release_date is None
        assert ds.locked is False
        assert ds.url is None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _json_response(data, status_code=200):
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status_code
    resp.ok = status_code < 400
    resp.json.return_value = data
    resp.text = json.dumps(data)
    resp.raise_for_status.return_value = None
    return resp


# ---------------------------------------------------------------------------
# list_datasets
# ---------------------------------------------------------------------------
class TestListDatasets:
    def test_invalid_format_raises(self):
        """Passing an unsupported format raises ValueError before any API call."""
        with pytest.raises(ValueError, match="format must be"):
            list_datasets(format="xml")

    @patch("aablocks.client.requests.get")
    def test_list_format(self, mock_get):
        """format='list' returns a list of Dataset objects."""
        mock_get.return_value = _json_response(SAMPLE_DATASETS_RESPONSE)
        result = list_datasets(format="list")
        assert len(result) == 2
        assert isinstance(result[0], Dataset)
        assert result[0].id == "ab1001"
        assert result[1].id == "ab1002"

    @patch("aablocks.client.requests.get")
    def test_csv_format(self, mock_get):
        """format='csv' returns a CSV string containing all dataset IDs."""
        mock_get.return_value = _json_response(SAMPLE_DATASETS_RESPONSE)
        result = list_datasets(format="csv")
        assert isinstance(result, str)
        assert "ab1001" in result
        assert "ab1002" in result

    @patch("aablocks.client.requests.get")
    def test_pandas_format(self, mock_get):
        """format='pandas' returns a pandas DataFrame with correct columns."""
        pd = pytest.importorskip("pandas")
        mock_get.return_value = _json_response(SAMPLE_DATASETS_RESPONSE)
        result = list_datasets(format="pandas")
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert list(result["id"]) == ["ab1001", "ab1002"]

    @patch("aablocks.client.requests.get")
    def test_polars_format(self, mock_get):
        """format='polars' returns a polars DataFrame with the right row count."""
        pl = pytest.importorskip("polars")
        mock_get.return_value = _json_response(SAMPLE_DATASETS_RESPONSE)
        result = list_datasets(format="polars")
        assert isinstance(result, pl.DataFrame)
        assert len(result) == 2

    @patch("aablocks.client.requests.get")
    def test_all_versions_param(self, mock_get):
        """all_versions=True sends all_versions=true as a query parameter."""
        mock_get.return_value = _json_response({"objects": []})
        list_datasets(all_versions=True, format="list")
        _, kwargs = mock_get.call_args
        assert kwargs["params"] == {"all_versions": "true"}

    @patch("aablocks.client.requests.get")
    def test_empty_response(self, mock_get):
        """An empty objects array returns an empty list."""
        mock_get.return_value = _json_response({"objects": []})
        result = list_datasets(format="list")
        assert result == []

    @patch("aablocks.client.requests.get")
    def test_http_error_propagates(self, mock_get):
        """HTTP errors from the API are re-raised to the caller."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 401
        resp.raise_for_status.side_effect = requests.HTTPError(response=resp)
        mock_get.return_value = resp
        with pytest.raises(requests.HTTPError):
            list_datasets(format="list")


# ---------------------------------------------------------------------------
# get_details
# ---------------------------------------------------------------------------
class TestGetDetails:
    @patch("aablocks.client.requests.get")
    def test_returns_dataset(self, mock_get):
        """Returns a Dataset object populated from the API response."""
        mock_get.return_value = _json_response({"dataset": SAMPLE_DATASET_DICT})
        ds = get_details("ab1001")
        assert ds.id == "ab1001"
        assert ds.name == "Test Dataset"

    @patch("aablocks.client.requests.get")
    def test_with_version_param(self, mock_get):
        """Passing a version sends it as a query parameter."""
        mock_get.return_value = _json_response({"dataset": SAMPLE_DATASET_DICT})
        get_details("ab1001", version="2")
        _, kwargs = mock_get.call_args
        assert kwargs["params"] == {"version": "2"}

    @patch("aablocks.client.requests.get")
    def test_404_raises(self, mock_get):
        """A 404 response raises HTTPError for a nonexistent dataset."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 404
        resp.raise_for_status.side_effect = requests.HTTPError(response=resp)
        mock_get.return_value = resp
        with pytest.raises(requests.HTTPError):
            get_details("nonexistent")


# ---------------------------------------------------------------------------
# get_readme
# ---------------------------------------------------------------------------
class TestGetReadme:
    @patch("aablocks.client.requests.get")
    def test_returns_text(self, mock_get):
        """Returns the raw markdown text from the API response."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 200
        resp.text = "# Test README\n\nSome content."
        resp.raise_for_status.return_value = None
        mock_get.return_value = resp
        result = get_readme("ab1001")
        assert result == "# Test README\n\nSome content."

    @patch("aablocks.client.requests.get")
    def test_with_version_param(self, mock_get):
        """Passing a version sends it as a query parameter."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 200
        resp.text = "readme v1"
        resp.raise_for_status.return_value = None
        mock_get.return_value = resp
        get_readme("ab1001", version="1")
        _, kwargs = mock_get.call_args
        assert kwargs["params"] == {"version": "1"}


# ---------------------------------------------------------------------------
# get_dataset
# ---------------------------------------------------------------------------
class TestGetDataset:
    def test_invalid_format_raises(self):
        """Passing an unsupported format raises ValueError before any API call."""
        with pytest.raises(ValueError, match="format must be"):
            get_dataset("ab1001", format="xml")

    def test_max_rows_exceeds_limit_raises(self):
        """Requesting more than 10,000 rows raises ValueError."""
        with pytest.raises(ValueError, match="max_rows cannot exceed"):
            get_dataset("ab1001", max_rows=20_000, format="csv")

    @patch("aablocks.client.requests.get")
    def test_csv_non_redirect(self, mock_get):
        """Non-redirect response (max_rows case) returns CSV text from the response body."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 200
        resp.text = "col1,col2\na,b\nc,d\n"
        resp.raise_for_status.return_value = None
        resp.headers = {}
        mock_get.return_value = resp

        result = get_dataset("ab1001", max_rows=100, format="csv", progress=False)
        assert result == "col1,col2\na,b\nc,d\n"

    @patch("aablocks.client.requests.get")
    def test_csv_s3_redirect(self, mock_get):
        """A 302 redirect downloads gzipped data from S3 and decompresses it."""
        csv_data = "col1,col2\nx,y\n"
        gz_data = gzip.compress(csv_data.encode())

        # First call: 302 redirect
        redirect_resp = MagicMock(spec=requests.Response)
        redirect_resp.status_code = 302
        redirect_resp.headers = {"Location": "https://s3.example.com/data.csv.gz"}
        redirect_resp.raise_for_status.return_value = None

        # Second call: S3 download (streaming)
        s3_resp = MagicMock()
        s3_resp.__enter__ = MagicMock(return_value=s3_resp)
        s3_resp.__exit__ = MagicMock(return_value=False)
        s3_resp.raise_for_status.return_value = None
        s3_resp.headers = {"Content-Length": str(len(gz_data))}
        s3_resp.iter_content.return_value = [gz_data]

        mock_get.side_effect = [redirect_resp, s3_resp]

        result = get_dataset("ab1001", format="csv", progress=False)
        assert result == csv_data

    @patch("aablocks.client.requests.get")
    def test_output_path_non_redirect(self, mock_get, tmp_path: Path):
        """Writing to file with a non-redirect response writes CSV text directly."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 200
        resp.text = "col1,col2\na,b\n"
        resp.raise_for_status.return_value = None
        resp.headers = {}
        mock_get.return_value = resp

        out = tmp_path / "data.csv"
        result = get_dataset(
            "ab1001", max_rows=10, output_path=str(out), progress=False
        )
        assert result is None
        assert out.read_text() == "col1,col2\na,b\n"

    @patch("aablocks.client.requests.get")
    def test_output_path_s3_redirect_compressed(self, mock_get, tmp_path: Path):
        """Writing to file with output_compressed=True keeps the gzip encoding."""
        csv_data = "col1,col2\nx,y\n"
        gz_data = gzip.compress(csv_data.encode())

        redirect_resp = MagicMock(spec=requests.Response)
        redirect_resp.status_code = 302
        redirect_resp.headers = {"Location": "https://s3.example.com/data.csv.gz"}

        s3_resp = MagicMock()
        s3_resp.__enter__ = MagicMock(return_value=s3_resp)
        s3_resp.__exit__ = MagicMock(return_value=False)
        s3_resp.raise_for_status.return_value = None
        s3_resp.headers = {"Content-Length": str(len(gz_data))}
        s3_resp.iter_content.return_value = [gz_data]

        mock_get.side_effect = [redirect_resp, s3_resp]

        out = tmp_path / "data.csv.gz"
        result = get_dataset(
            "ab1001", output_path=str(out), output_compressed=True, progress=False
        )
        assert result is None
        assert gzip.decompress(out.read_bytes()).decode() == csv_data

    @patch("aablocks.client.requests.get")
    def test_output_path_s3_redirect_decompressed(self, mock_get, tmp_path: Path):
        """Writing to file with output_compressed=False decompresses before writing."""
        csv_data = "col1,col2\nx,y\n"
        gz_data = gzip.compress(csv_data.encode())

        redirect_resp = MagicMock(spec=requests.Response)
        redirect_resp.status_code = 302
        redirect_resp.headers = {"Location": "https://s3.example.com/data.csv.gz"}

        s3_resp = MagicMock()
        s3_resp.__enter__ = MagicMock(return_value=s3_resp)
        s3_resp.__exit__ = MagicMock(return_value=False)
        s3_resp.raise_for_status.return_value = None
        s3_resp.headers = {"Content-Length": str(len(gz_data))}
        s3_resp.iter_content.return_value = [gz_data]

        mock_get.side_effect = [redirect_resp, s3_resp]

        out = tmp_path / "data.csv"
        result = get_dataset(
            "ab1001", output_path=str(out), output_compressed=False, progress=False
        )
        assert result is None
        assert out.read_text() == csv_data

    @patch("aablocks.client.requests.get")
    def test_pandas_non_redirect(self, mock_get):
        """format='pandas' with a non-redirect response returns a DataFrame."""
        pd = pytest.importorskip("pandas")
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 200
        resp.text = "col1,col2\na,b\nc,d\n"
        resp.raise_for_status.return_value = None
        resp.headers = {}
        mock_get.return_value = resp

        result = get_dataset("ab1001", max_rows=10, format="pandas", progress=False)
        assert isinstance(result, pd.DataFrame)
        assert list(result.columns) == ["col1", "col2"]
        assert len(result) == 2

    @patch("aablocks.client.requests.get")
    def test_params_sent_correctly(self, mock_get):
        """Version, mode, and max_rows are forwarded as query parameters."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 200
        resp.text = "col1\na\n"
        resp.raise_for_status.return_value = None
        resp.headers = {}
        mock_get.return_value = resp

        get_dataset(
            "ab1001",
            version="2",
            mode="ml",
            max_rows=500,
            format="csv",
            progress=False,
        )
        _, kwargs = mock_get.call_args
        assert kwargs["params"] == {"version": "2", "mode": "ml", "max_rows": 500}

    @patch("aablocks.client.requests.get")
    def test_missing_location_header_raises(self, mock_get):
        """A 302 without a Location header raises RuntimeError."""
        resp = MagicMock(spec=requests.Response)
        resp.status_code = 302
        resp.headers = {}
        resp.raise_for_status.return_value = None
        mock_get.return_value = resp

        with pytest.raises(RuntimeError, match="Location header"):
            get_dataset("ab1001", format="csv", progress=False)
