# Adobe Analytics for Team ACT v0.0.2.4

This module is designed to provide a more efficient and stable analysis environment
for Adobe Analytics analysts in Team ACT, with internal performance optimizations
and extended data retrieval capabilities.

## New in 0.0.2.4

### 1. 데이터 최대 추출 개수 (5만 > 전체)


## New in 0.0.2.2

### 1. max_retries 기능 수정


## New in 0.0.2.1

### 1. RS INPUT 변수에 EU-VRS (6개국, ES, DE, NL, PT, BE) 추가 및 UK RS 명칭 변경
- VRS 명칭 : sitecode ex) uk vrs > uk
- 국RS 명칭 : sitecode_old ex) uk rs > uk_old


## New in 0.0.2

### 1. retrieve_by_RS_parallel 함수 추가
- `ThreadPoolExecutor`를 활용한 동시 실행 구조 적용
- 사용 방식에는 변경 없음
- 성능 및 처리 효율 개선

### 2. max_retries 기능 수정
- `"oberon_client_http_error"` 감지하도록 로직 수정


## New in 0.0.1.60
- pandas, sqlalchemy 버전 업그레이드에 따른 업데이트


## New in 0.0.1.59

### 기능 추가
- retrieve_by_RS_breakdownTotal / retrieve_SecondLevelTotal 함수 추가
  - Dimension과 Breakdown 값을 동시에 추출 가능

### 버그 수정
- `'No data returned & lastPage is False'`로 인한 무한 루프 해결
  - 데이터 추출 시 수치가 없으면 다음 행으로 넘어가도록 수정

### 기능 개선
- retrieve_SecondLevel, retrieve_FirstLevel에 limit 기능 추가 및 수정
  - retrieve_SecondLevel / retrieve_SecondLevelTotal에 limit1, limit2 적용
  - 1st Dimension과 Breakdown의 limit을 각각 지정 가능
  - retrieve_FirstLevel의 limit 기능 수정

### 데이터 범위 변경
- MST Site Code Filter 203개로 축소
  - [Site Code] 103개 사이트 (Evar 세그먼트 기준 APP 포함 총 206 site code)
  - `[site code]`, `[site code]-app`


## New in 0.0.1.58
- `max_retries` 기능 추가 (default = 5)
  - AttributeError, ConnectionError 등 발생 시
  - 최대 `max_retries` 횟수만큼 재시도


## New in 0.0.1.57

### Site Code 확장
- Site Code Filter에 Site Code 추가
  - v0.0.1.57 이전: `[site code]`, `[site code]-smb` (총 137개)
  - v0.0.1.57 이후:
    - `[site code]-app`
    - `[site code]-epp`
    - `[site code]-epp-app`
    - `[site code]-smb-app`
  - 총 636개

### 기능 추가
- retrieve_by_RS, retrieve_by_RS_breakdown에서 MST 데이터 추출 가능
- `extra1` 기능 추가
  - 기존 `extra` 외 추가 구분자 사용 가능 (최대 2개)

### 구조 개선
- 데이터 추출 Loop 순서 변경
  - Date > RS → RS > Date


## New in 0.0.1.53
- RS INPUT 변수에 UK-VRS 추가
  - uk → UK VRS
  - uk_epp → UK RS


## New in 0.0.1.52

### 기능 추가 및 개선
- limit 기능 추가
- retrieve_by_RS_breakdown에 limit1, limit2 추가
- retrieve_by_RS에 limit 기능 추가
- limit 변수 순서 변경 및 option화
  - 필수 → 선택 변수
  - 미지정 시 전체 데이터 추출

### 버그 수정
- Encoding error 수정
- 특수문자 데이터 저장 오류 수정

### 데이터 추가
- Semiconductor RS 7개 추가
- ds-global, ds-cn, ds-us, ds-kr, ds-emea, ds-jp, ds-total


## New in 0.0.1.48
- API 동시 추출 기능 추가
  - sqlalchemy 패키지 활용

---

More functionalities will be added in the near future.
