@abstract
class SomethingAbstract:
    pass


__version__ = "dummy"
__xml_namespace__ = "https://dummy.com"
