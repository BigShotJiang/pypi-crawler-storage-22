f"a{x}b"
