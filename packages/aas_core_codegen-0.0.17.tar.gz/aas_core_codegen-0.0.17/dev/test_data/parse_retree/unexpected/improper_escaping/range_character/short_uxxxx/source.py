"[\\uabc]"
