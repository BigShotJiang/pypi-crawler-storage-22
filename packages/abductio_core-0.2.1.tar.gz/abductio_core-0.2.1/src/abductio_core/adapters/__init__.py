"""External service adapters for abductio-core."""
