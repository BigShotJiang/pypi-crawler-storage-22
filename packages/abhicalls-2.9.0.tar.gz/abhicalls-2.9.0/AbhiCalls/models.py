class Song:
    def __init__(
        self,
        title,
        url,
        duration,
        views,
        stream,
        requested_by,
        loop_left=0,
    ):
        self.title = title
        self.url = url
        self.duration = duration
        self.views = views
        self.stream = stream
        self.requested_by = requested_by
        self.loop_left = loop_left
        self.duration_sec = self._to_seconds(duration)

    def _to_seconds(self, d):
        try:
            if ":" in d:
                m, s = map(int, d.split(":"))
                return m * 60 + s
            return int(d)
        except Exception:
            return 0

