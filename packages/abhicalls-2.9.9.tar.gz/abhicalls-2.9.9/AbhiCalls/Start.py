import requests
from colorama import init, Fore, Style
from AbhiCalls import __version__, __author__

init(autoreset=True)

def check_latest_version(pkg_name="AbhiCalls"):
    try:
        response = requests.get(f"https://pypi.org/pypi/{pkg_name}/json", timeout=3)
        if response.status_code == 200:
            return response.json()["info"]["version"]
    except Exception:
        return None

def print_startup_message():
    print(Fore.GREEN + "✅ AbhiCalls started...\n")

    print(Fore.CYAN + f"Version : {__version__}")
    print(Fore.CYAN + f"Author  : {__author__}")
    print(Fore.CYAN + "License : Abhishek Special")
    print(Fore.CYAN + "GitHub  : https://github.com/YouTubeMusicAPI/AbhiCalls")
    print(Fore.CYAN + "Telegram : https://t.me/WhyAbhishek")

    latest = check_latest_version("AbhiCalls")
    if latest and latest != __version__:
        print(Fore.YELLOW + "\nUpdate Available!")
        print(Fore.YELLOW + f"New AbhiCalls v{latest} is now available!")
    else:
        print(Fore.GREEN + "\nYou are using the latest version!")
