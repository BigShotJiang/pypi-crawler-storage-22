from pytgcalls import PyTgCalls, filters
from pytgcalls.types import MediaStream, AudioQuality, StreamEnded

class _NativeEngine:
    def __init__(self, app):
        self._core = PyTgCalls(app)
        self.on_end = None

        @self._core.on_update(filters.stream_end())
        async def _ended(_, update: StreamEnded):
            if self.on_end:
                await self.on_end(update.chat_id)

    async def start(self):
        await self._core.start()

    async def play(self, chat_id, stream):
        await self._core.play(
            chat_id,
            MediaStream(
                media_path=stream,
                audio_parameters=AudioQuality.STUDIO,
                video_flags=MediaStream.Flags.IGNORE,
            )
        )

    async def stop(self, chat_id):
        await self._core.leave_call(chat_id)

    async def pause(self, chat_id):
        await self._core.pause(chat_id)

    async def resume(self, chat_id):
        await self._core.resume(chat_id)

    async def mute(self, chat_id):
        await self._core.mute(chat_id)

    async def unmute(self, chat_id):
        await self._core.unmute(chat_id)

    async def change_volume(self, chat_id, volume: int = 200):
        await self._core.change_volume(chat_id, volume)
        
