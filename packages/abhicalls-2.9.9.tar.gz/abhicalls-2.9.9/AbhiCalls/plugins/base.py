class Plugin:
    name = "base"

    def __init__(self, app):
        self.app = app  # pyrogram Client

    # =========================
    # ▶️ NOW PLAYING / AUTO-SKIP
    # =========================
    async def on_song_start(self, chat_id, song):
        caption = (
            "▶️ **Now Playing**\n\n"
            f"🎵 **Title:** {song.title}\n"
            f"⏱ **Duration:** {song.duration}\n"
            f"🙋 **Requested by:** {song.requested_by}"
        )

        if song.thumb:
            await self.app.send_photo(
                chat_id,
                photo=song.thumb,
                caption=caption
            )
        else:
            await self.app.send_message(chat_id, caption)

    # =========================
    # ⏹ SONG END (optional hook)
    # =========================
    async def on_song_end(self, chat_id, song):
        # Usually no message needed here
        pass

    # =========================
    # ➕ ADDED TO QUEUE
    # =========================
    async def on_queue_add(self, chat_id, song, position):
        # First song ka message already on_song_start bhej dega
        if position == 1:
            return

        caption = (
            "➕ **Added to Queue**\n\n"
            f"🎵 **Title:** {song.title}\n"
            f"⏱ **Duration:** {song.duration}\n"
            f"🙋 **Requested by:** {song.requested_by}\n"
            f"📍 **Position:** {position}"
        )

        if song.thumb:
            await self.app.send_photo(
                chat_id,
                photo=song.thumb,
                caption=caption
            )
        else:
            await self.app.send_message(chat_id, caption)
