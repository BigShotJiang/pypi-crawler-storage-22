import logging
import sys
import os
from contextlib import contextmanager
from pytgcalls import idle as _idle

# ─────────────────────────────
# Mute pytgcalls logs
# ─────────────────────────────
logging.getLogger("pytgcalls").setLevel(logging.CRITICAL)
logging.getLogger("ntgcalls").setLevel(logging.CRITICAL)


@contextmanager
def _suppress_stdout():
    """
    Temporarily suppress stdout/stderr
    (used to hide pytgcalls banner)
    """
    with open(os.devnull, "w") as devnull:
        old_out = sys.stdout
        old_err = sys.stderr
        sys.stdout = devnull
        sys.stderr = devnull
        try:
            yield
        finally:
            sys.stdout = old_out
            sys.stderr = old_err


async def idle():
    """
    Keep app running (pytgcalls idle hidden)
    """
    with _suppress_stdout():
        await _idle()
