from AbhiCalls._engine.native import _NativeEngine
from AbhiCalls.controller import VoiceController

class VoiceEngine:
    def __init__(self, app):
        self._engine = _NativeEngine(app)
        self.vc = VoiceController(self._engine)

    async def start(self):
        await self._engine.start()
      
