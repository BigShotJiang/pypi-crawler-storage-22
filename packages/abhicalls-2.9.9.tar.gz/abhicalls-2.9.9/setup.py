from setuptools import setup, find_packages

setup(
    name="AbhiCalls",
    version="2.9.9",
    description="Telegram Voice Chat Music Engine with Queue, Loop, ETA support",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",

    author="Abhishek Thakur",
    author_email="abhishekbanshiwal2005@gmail.com",
    url="https://github.com/YouTubeMusicAPI/TgCall",

    packages=find_packages(),
    include_package_data=True,

    install_requires=[
        "py-tgcalls>=2.1.1",
        "pyrofork",
        "telethon>=1.34.0",
        "aiohttp"
    ],

    python_requires=">=3.9",

    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Multimedia :: Sound/Audio",
        "Topic :: Software Development :: Libraries"
    ],
)
