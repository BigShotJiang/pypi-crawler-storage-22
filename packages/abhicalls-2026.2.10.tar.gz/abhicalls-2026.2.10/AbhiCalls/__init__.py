from AbhiCalls.vc import VoiceEngine
from AbhiCalls.runtime import idle
#from .controller import VoiceController
from .player import Player
from .plugins import Plugin

__all__ = ["VoiceEngine", "idle"]

__version__ = "2026.2.10"
__author__ = "ABHISHEK THAKUR"

try:
    from .Start import print_startup_message
    print_startup_message()
except Exception:
    pass
