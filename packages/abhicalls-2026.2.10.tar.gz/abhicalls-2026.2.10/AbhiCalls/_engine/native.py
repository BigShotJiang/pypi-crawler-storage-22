from pytgcalls import PyTgCalls, filters
from pytgcalls.types import MediaStream, AudioQuality, StreamEnded, ChatUpdate


class _NativeEngine:
    def __init__(self, app):
        self._core = PyTgCalls(app)
        self.on_end = None
        self.on_vc_closed = None

        # ==========================
        # STREAM END
        # ==========================
        @self._core.on_update(filters.stream_end())
        async def _ended(_, update: StreamEnded):
            if self.on_end:
                try:
                    await self.on_end(update.chat_id)
                except Exception as e:
                    print(f"[Engine:on_end] {e}")

        # ==========================
        # VC CLOSED
        # ==========================
        @self._core.on_update(
            filters.chat_update(ChatUpdate.Status.CLOSED_VOICE_CHAT)
        )
        async def _vc_closed(_, update: ChatUpdate):
            if self.on_vc_closed:
                try:
                    await self.on_vc_closed(update.chat_id)
                except Exception as e:
                    print(f"[Engine:on_vc_closed] {e}")

    # ==========================
    # START CORE
    # ==========================
    async def start(self):
        try:
            await self._core.start()
            print("[Engine] PyTgCalls started")
        except Exception as e:
            raise Exception(f"[Engine:Start] {e}")

    # ==========================
    # PLAY
    # ==========================
    async def play(self, chat_id, stream):
        if not stream:
            raise Exception("[Engine:Play] Stream is empty")

        try:
            await self._core.play(
                chat_id,
                MediaStream(
                    media_path=stream,
                    audio_parameters=AudioQuality.STUDIO,
                    video_flags=MediaStream.Flags.IGNORE,
                )
            )
            print(f"[Engine:Play] Started in {chat_id}")
            return True, None

        except Exception as e:
            raise Exception(f"[Engine:Play] {chat_id} → {e}")

    # ==========================
    # STOP
    # ==========================
    async def stop(self, chat_id):
        try:
            await self._core.leave_call(chat_id)
            print(f"[Engine:Stop] Left {chat_id}")
        except Exception as e:
            raise Exception(f"[Engine:Stop] {chat_id} → {e}")

    # ==========================
    # PAUSE
    # ==========================
    async def pause(self, chat_id):
        try:
            await self._core.pause(chat_id)
            print(f"[Engine:Pause] {chat_id}")
        except Exception as e:
            raise Exception(f"[Engine:Pause] {chat_id} → {e}")

    # ==========================
    # RESUME
    # ==========================
    async def resume(self, chat_id):
        try:
            await self._core.resume(chat_id)
            print(f"[Engine:Resume] {chat_id}")
        except Exception as e:
            raise Exception(f"[Engine:Resume] {chat_id} → {e}")

    # ==========================
    # MUTE
    # ==========================
    async def mute(self, chat_id):
        try:
            await self._core.mute(chat_id)
            print(f"[Engine:Mute] {chat_id}")
        except Exception as e:
            raise Exception(f"[Engine:Mute] {chat_id} → {e}")

    # ==========================
    # UNMUTE
    # ==========================
    async def unmute(self, chat_id):
        try:
            await self._core.unmute(chat_id)
            print(f"[Engine:Unmute] {chat_id}")
        except Exception as e:
            raise Exception(f"[Engine:Unmute] {chat_id} → {e}")

    # ==========================
    # VOLUME
    # ==========================
    async def change_volume(self, chat_id, volume: int = 200):
        try:
            await self._core.change_volume_call(chat_id, volume)
            print(f"[Engine:Volume] {chat_id} → {volume}")
        except Exception as e:
            raise Exception(f"[Engine:Volume] {chat_id} → {e}")
            
