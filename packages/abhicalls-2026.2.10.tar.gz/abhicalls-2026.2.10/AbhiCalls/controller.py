import asyncio

from AbhiCalls.yt import resolve_query
from AbhiCalls.models import Song
from AbhiCalls.player import Player
from AbhiCalls.settings import settings


class VoiceController:
    def __init__(self, engine, cookies: str | None = None):
        print("[Controller] init")

        self.cookies = cookies or settings.cookies
        print("[Controller] cookies:", self.cookies)

        self.engine = engine
        self.player = Player(engine)

        self.engine.on_end = self._on_end
        self.engine.on_vc_closed = self._on_vc_closed

        self.plugins = []

    # =========================
    # PLUGINS
    # =========================
    def load_plugin(self, plugin):
        print(f"[Controller] plugin loaded → {plugin}")
        self.plugins.append(plugin)

    async def _hook(self, name, *args):
        for p in self.plugins:
            fn = getattr(p, name, None)
            if fn:
                try:
                    print(f"[Controller:Hook] {name}")
                    await fn(*args)
                except Exception as e:
                    print(f"[Plugin:{getattr(p, 'name', p)}:{name}] {e}")

    # =========================
    # PLAY QUERY
    # =========================
    async def play(self, chat_id, query, requested_by):
        print(f"\n[Controller:Play] chat={chat_id} query={query}")

        try:
            results = await resolve_query(query, self.cookies)
        except Exception as e:
            print(f"[Controller:ResolverError] {e}")
            return False, str(e)

        if not results:
            print("[Controller] no results")
            return None, "No results found"

        print(f"[Controller] resolver returned {len(results)} item(s)")

        first_pos = None
        last_song = None

        for data in results:
            song = Song(
                title=data["title"],
                url=data["url"],
                duration=data["duration"],
                views=data["views"],
                stream=data["stream"],
                requested_by=requested_by,
                video_id=data.get("video_id"),
                thumb=data.get("thumb"),
            )

            try:
                pos = await self.player.play(chat_id, song)
            except Exception as e:
                print(f"[Controller:PlayerError] {e}")
                q = self.player.queues.get(chat_id)
                if q:
                    q.pop_last()
                return False, str(e)

            print(f"[Controller] queued → pos={pos} title={song.title}")

            await self._hook("on_queue_add", chat_id, song, pos)

            if first_pos is None:
                first_pos = pos
            last_song = song

        # start hook
        if first_pos == 1 and last_song:
            await asyncio.sleep(1)

            if chat_id in self.player.start_time:
                print("[Controller] confirmed start")
                await self._hook("on_song_start", chat_id, last_song)

        return last_song, first_pos

    # =========================
    # PLAY FILE
    # =========================
    async def play_file(self, chat_id, file_path, requested_by, reply=None):
        print(f"\n[Controller:PlayFile] chat={chat_id}")

        duration = 0

        if reply:
            if reply.voice and reply.voice.duration is not None:
                duration = reply.voice.duration
            elif reply.audio and reply.audio.duration is not None:
                duration = reply.audio.duration

        try:
            duration = int(duration)
        except Exception:
            duration = 0

        song = Song(
            title="Telegram Audio",
            url=None,
            duration=duration,
            views=None,
            stream=file_path,
            requested_by=requested_by,
            video_id=None,
            thumb=None,
        )

        try:
            pos = await self.player.play(chat_id, song)
        except Exception as e:
            print(f"[Controller:PlayerError] {e}")
            q = self.player.queues.get(chat_id)
            if q:
                q.pop_last()
            return False, str(e)

        print(f"[Controller] queued file → pos={pos}")

        await self._hook("on_queue_add", chat_id, song, pos)

        if pos == 1:
            await asyncio.sleep(1)

            if chat_id in self.player.start_time:
                print("[Controller] confirmed start")
                await self._hook("on_song_start", chat_id, song)

        return song, pos

    # =========================
    # CONTROLS
    # =========================
    async def skip(self, chat_id):
        print(f"[Controller:Skip] {chat_id}")
        await self.player.skip(chat_id)

    async def previous(self, chat_id):
        print(f"[Controller:Previous] {chat_id}")
        return await self.player.previous(chat_id)

    async def pause(self, chat_id):
        print(f"[Controller:Pause] {chat_id}")
        await self.player.pause(chat_id)

    async def resume(self, chat_id):
        print(f"[Controller:Resume] {chat_id}")
        await self.player.resume(chat_id)

    async def stop(self, chat_id):
        print(f"[Controller:Stop] {chat_id}")
        await self.player.stop(chat_id)

    async def mute(self, chat_id):
        print(f"[Controller:Mute] {chat_id}")
        await self.player.mute(chat_id)

    async def unmute(self, chat_id):
        print(f"[Controller:Unmute] {chat_id}")
        await self.player.unmute(chat_id)

    async def volume(self, chat_id, volume: int):
        print(f"[Controller:Volume] {chat_id} → {volume}")
        await self.player.volume(chat_id, volume)

    def loop(self, chat_id, count=None):
        print(f"[Controller:Loop] {count}")
        return self.player.set_loop(chat_id, count)

    def eta(self, chat_id):
        return self.player.eta(chat_id)

    # =========================
    # AUTO SKIP
    # =========================
    async def _on_end(self, chat_id):
        print(f"[Controller] stream ended → {chat_id}")

        q = self.player.queues.get(chat_id)

        old_song = q.current() if q else None
        if old_song:
            await self._hook("on_song_end", chat_id, old_song)

        await self.player.skip(chat_id)

        q = self.player.queues.get(chat_id)
        next_song = q.current() if q else None

        if next_song:
            await asyncio.sleep(1)
            if chat_id in self.player.start_time:
                await self._hook("on_song_start", chat_id, next_song)
        else:
            await self._on_vc_closed(chat_id)

    # =========================
    # VC CLOSED
    # =========================
    async def _on_vc_closed(self, chat_id):
        print(f"[Controller] vc closed → {chat_id}")

        q = self.player.queues.get(chat_id)
        if q:
            q.clear()

        try:
            await self.player.stop(chat_id)
        except Exception as e:
            print(f"[Controller:StopError] {e}")

        await self._hook("on_vc_closed", chat_id)
        print(f"[Controller] cleaned {chat_id}")
        
