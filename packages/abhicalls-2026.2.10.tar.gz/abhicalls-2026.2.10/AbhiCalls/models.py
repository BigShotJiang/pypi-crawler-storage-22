class Song:
    def __init__(
        self,
        title,
        url,
        duration,
        views,
        stream,
        requested_by,
        loop_left=0,
        video_id=None,
        thumb=None,
    ):
        self.title = title or "Unknown"
        self.url = url
        self.duration = duration
        self.views = views
        self.stream = stream
        self.requested_by = requested_by or "Unknown"
        self.loop_left = loop_left or 0

        self.video_id = video_id
        self.thumb = thumb

        if not self.stream:
            print(f"[Song] WARNING → stream empty for {self.title}")

    # ==========================
    # SAFE SECONDS
    # ==========================
    @property
    def duration_sec(self):
        return self._to_seconds(self.duration)

    # ==========================
    # DISPLAY TIME
    # ==========================
    @property
    def duration_text(self):
        sec = self.duration_sec

        m, s = divmod(sec, 60)
        h, m = divmod(m, 60)

        if h:
            return f"{h}:{m:02d}:{s:02d}"
        return f"{m}:{s:02d}"

    # ==========================
    # CONVERTER
    # ==========================
    def _to_seconds(self, d):
        try:
            if d is None:
                return 0

            if isinstance(d, int):
                return d

            if isinstance(d, str):
                if ":" in d:
                    parts = [int(p) for p in d.split(":")]

                    if len(parts) == 3:
                        h, m, s = parts
                        return h * 3600 + m * 60 + s

                    if len(parts) == 2:
                        m, s = parts
                        return m * 60 + s

                return int(d)

            return int(d)

        except Exception:
            print(f"[Song] duration parse fail → {d}")
            return 0

    # ==========================
    # DEBUG STRING
    # ==========================
    def __repr__(self):
        return f"<Song title={self.title} duration={self.duration_text}>"
