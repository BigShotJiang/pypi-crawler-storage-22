import time
from AbhiCalls.queue import SongQueue


class Player:
    def __init__(self, engine):
        self.engine = engine
        self.queues = {}
        self.start_time = {}

    def _queue(self, chat_id):
        return self.queues.setdefault(chat_id, SongQueue())

    # ==========================
    # PLAY
    # ==========================
    async def play(self, chat_id, song):
        q = self._queue(chat_id)
        pos = q.add(song)

        print(f"[Player:Play] chat={chat_id} pos={pos} title={song.title}")

        if pos == 1:
            try:
                self.start_time[chat_id] = time.time()
                await self.engine.play(chat_id, song.stream)
            except Exception as e:
                print(f"[Player:Play:Error] {chat_id} → {e}")
                q.pop_last()
                self.start_time.pop(chat_id, None)
                raise

        return pos

    # ==========================
    # SKIP
    # ==========================
    async def skip(self, chat_id):
        q = self.queues.get(chat_id)
        if not q:
            print(f"[Player:Skip] no queue in {chat_id}")
            return None

        nxt = q.next()
        if nxt:
            print(f"[Player:Skip] chat={chat_id} next={nxt.title}")
            self.start_time[chat_id] = time.time()
            await self.engine.play(chat_id, nxt.stream)
            return nxt
        else:
            print(f"[Player:Skip] queue ended in {chat_id}")
            self.start_time.pop(chat_id, None)
            await self.engine.stop(chat_id)
            return None

    # ==========================
    # PREVIOUS
    # ==========================
    async def previous(self, chat_id):
        q = self.queues.get(chat_id)
        if not q:
            print(f"[Player:Previous] no queue in {chat_id}")
            return None

        prev = q.previous()
        if prev:
            print(f"[Player:Previous] chat={chat_id} → {prev.title}")
            self.start_time[chat_id] = time.time()
            await self.engine.play(chat_id, prev.stream)
        return prev

    # ==========================
    # STOP
    # ==========================
    async def stop(self, chat_id):
        print(f"[Player:Stop] chat={chat_id}")

        if chat_id in self.queues:
            self.queues[chat_id].clear()

        self.start_time.pop(chat_id, None)
        await self.engine.stop(chat_id)

    # ==========================
    # BASIC CONTROLS
    # ==========================
    async def pause(self, chat_id):
        print(f"[Player:Pause] {chat_id}")
        await self.engine.pause(chat_id)

    async def resume(self, chat_id):
        print(f"[Player:Resume] {chat_id}")
        await self.engine.resume(chat_id)

    async def mute(self, chat_id):
        print(f"[Player:Mute] {chat_id}")
        await self.engine.mute(chat_id)

    async def unmute(self, chat_id):
        print(f"[Player:Unmute] {chat_id}")
        await self.engine.unmute(chat_id)

    async def volume(self, chat_id, volume: int):
        print(f"[Player:Volume] {chat_id} → {volume}")
        await self.engine.change_volume(chat_id, volume)

    # ==========================
    # LOOP
    # ==========================
    def set_loop(self, chat_id, count=None):
        q = self._queue(chat_id)

        if count is None:
            q.infinite_loop = not q.infinite_loop
            print(f"[Player:Loop] infinite={q.infinite_loop}")
            return q.infinite_loop

        cur = q.current()
        if cur:
            cur.loop_left = count - 1
            print(f"[Player:Loop] {cur.title} × {count}")
            return count
        return 0

    # ==========================
    # ETA
    # ==========================
    def eta(self, chat_id):
        q = self.queues.get(chat_id)
        if not q or not q.current():
            return None

        elapsed = int(time.time() - self.start_time.get(chat_id, 0))
        dur = getattr(q.current(), "duration_sec", 0)
        return max(dur - elapsed, 0)
        
