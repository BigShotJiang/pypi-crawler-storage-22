import os
import asyncio
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

QUEUE_DELETE_AFTER = 30
VC_END_DELETE_AFTER = 10


def control_buttons():
    text = os.getenv("TEXT")
    link = os.getenv("LINK")

    buttons = [
        [
            InlineKeyboardButton("⏮", callback_data="vc_previous"),
            InlineKeyboardButton("▶", callback_data="vc_resume"),
            InlineKeyboardButton("⏹", callback_data="vc_end"),
            InlineKeyboardButton("⏸", callback_data="vc_pause"),
            InlineKeyboardButton("⏭", callback_data="vc_skip"),
        ]
    ]

    if text and link:
        buttons.append([InlineKeyboardButton(text, url=link)])

    return InlineKeyboardMarkup(buttons)


class Plugin:
    name = "base"

    def __init__(self, app):
        self.app = app
        self.now_playing_msg = {}

    # =================================
    # SONG START
    # =================================
    async def on_song_start(self, chat_id, song):
        print(f"[Plugin] now playing → {song.title}")

        caption = (
            "▶️ Nᴏᴡ Pʟᴀʏɪɴɢ\n\n"
            f"🎵 Tɪᴛʟᴇ : [{song.title[:19]}]({song.url})\n"
            f"⏱ Dᴜʀᴀᴛɪᴏɴ : {song.duration_text}\n"
            f"🙋 Rᴇǫᴜᴇsᴛᴇᴅ Bʏ : {song.requested_by}"
        )

        # delete old
        old = self.now_playing_msg.get(chat_id)
        if old:
            try:
                await old.delete()
            except Exception as e:
                print(f"[Plugin:DeleteOld] {e}")

        try:
            if song.thumb:
                msg = await self.app.send_photo(
                    chat_id,
                    photo=song.thumb,
                    caption=caption,
                    reply_markup=control_buttons()
                )
            else:
                msg = await self.app.send_message(
                    chat_id,
                    caption,
                    reply_markup=control_buttons()
                )

            self.now_playing_msg[chat_id] = msg

        except Exception as e:
            print(f"[Plugin:NowPlayingSend] {e}")

    # =================================
    # SONG END
    # =================================
    async def on_song_end(self, chat_id, song):
        msg = self.now_playing_msg.pop(chat_id, None)
        if msg:
            try:
                await msg.delete()
            except Exception as e:
                print(f"[Plugin:EndDelete] {e}")

    # =================================
    # QUEUE ADD
    # =================================
    async def on_queue_add(self, chat_id, song, position):
        if position == 1:
            return

        print(f"[Plugin] queue add → {song.title} pos={position}")

        caption = (
            "➕ Aᴅᴅᴇᴅ Tᴏ Qᴜᴇᴜᴇ\n\n"
            f"🎵 Tɪᴛʟᴇ : [{song.title[:19]}]({song.url})\n"
            f"⏱ Dᴜʀᴀᴛɪᴏɴ : {song.duration_text}\n"
            f"🙋 Rᴇǫᴜᴇsᴛᴇᴅ Bʏ : {song.requested_by}\n"
            f"📍 Pᴏsɪᴛɪᴏɴ : {position}"
        )

        try:
            if song.thumb:
                msg = await self.app.send_photo(
                    chat_id,
                    photo=song.thumb,
                    caption=caption
                )
            else:
                msg = await self.app.send_message(chat_id, caption)

            asyncio.create_task(self._auto_delete(msg, QUEUE_DELETE_AFTER))

        except Exception as e:
            print(f"[Plugin:QueueSend] {e}")

    # =================================
    # VC CLOSED
    # =================================
    async def on_vc_closed(self, chat_id):
        print(f"[Plugin] vc closed → {chat_id}")

        msg = self.now_playing_msg.pop(chat_id, None)
        if msg:
            try:
                await msg.delete()
            except Exception as e:
                print(f"[Plugin:CloseDelete] {e}")

        try:
            msg = await self.app.send_message(
                chat_id,
                "🔴 Vᴏɪᴄᴇ Cʜᴀᴛ Eɴᴅᴇᴅ\n\n"
                "🧹 Qᴜᴇᴜᴇ Cʟᴇᴀʀᴇᴅ & Pʟᴀʏᴇʀ Sᴛᴏᴘᴘᴇᴅ."
            )
            asyncio.create_task(self._auto_delete(msg, VC_END_DELETE_AFTER))
        except Exception as e:
            print(f"[Plugin:CloseMsg] {e}")

    # =================================
    # NOT ACTIVE
    # =================================
    async def on_vc_not_active(self, chat_id):
        try:
            await self.app.send_message(
                chat_id,
                "❌ Vᴏɪᴄᴇ Cʜᴀᴛ ɪꜱ ɴᴏᴛ ᴀᴄᴛɪᴠᴇ.\n\n"
                "Sᴛᴀʀᴛ ᴀ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ ғɪʀꜱᴛ."
            )
        except Exception as e:
            print(f"[Plugin:NotActive] {e}")

    # =================================
    # AUTO DELETE
    # =================================
    async def _auto_delete(self, msg, delay):
        try:
            await asyncio.sleep(delay)
            await msg.delete()
        except Exception as e:
            print(f"[Plugin:AutoDelete] {e}")
