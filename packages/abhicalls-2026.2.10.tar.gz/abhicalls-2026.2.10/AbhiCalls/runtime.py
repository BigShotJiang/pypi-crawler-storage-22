import logging
import sys
import os
from contextlib import contextmanager
from pytgcalls import idle as _idle

try:
    from AbhiCalls.settings import settings
    DEBUG = getattr(settings, "debug", False)
except Exception:
    DEBUG = False


# ─────────────────────────────
# Reduce pytgcalls noise
# ─────────────────────────────
logging.getLogger("pytgcalls").setLevel(logging.CRITICAL)
logging.getLogger("ntgcalls").setLevel(logging.CRITICAL)


@contextmanager
def _suppress_stdout():
    """
    Hide noisy libraries output.
    In debug mode → do nothing.
    """
    if DEBUG:
        yield
        return

    with open(os.devnull, "w") as devnull:
        old_out = sys.stdout
        old_err = sys.stderr
        sys.stdout = devnull
        sys.stderr = devnull
        try:
            yield
        finally:
            sys.stdout = old_out
            sys.stderr = old_err


async def idle():
    """
    Keep app running.
    """
    if DEBUG:
        print("[Idle] running in debug mode")

    with _suppress_stdout():
        await _idle()
