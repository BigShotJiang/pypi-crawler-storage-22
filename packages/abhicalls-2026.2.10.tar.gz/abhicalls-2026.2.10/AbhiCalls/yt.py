import re
import asyncio
from YouTubeMusic.Search import Search
from YouTubeMusic.Stream import get_stream
from YouTubeMusic.Playlist import get_playlist_songs
from AbhiCalls.settings import settings

PLAYLIST_REGEX = re.compile(r"(list=)")
YOUTUBE_REGEX = re.compile(r"(youtube\.com|youtu\.be|music\.youtube\.com)")


def sec_to_mmss(sec):
    try:
        sec = int(sec)
        return f"{sec // 60}:{sec % 60:02d}"
    except Exception:
        return "Unknown"


def extract_video_id(url: str):
    try:
        if "watch?v=" in url:
            return url.split("watch?v=")[1].split("&")[0]
        elif "youtu.be/" in url:
            return url.split("youtu.be/")[1].split("?")[0]
    except Exception:
        pass
    return None


def yt_thumbnail(url: str):
    vid = extract_video_id(url)
    if not vid:
        return None
    return f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"


# ==============================
# MAIN RESOLVER
# ==============================
async def resolve_query(query: str, cookies: str | None = None):
    print(f"[Resolver] query={query}")

    if not cookies:
        cookies = settings.cookies

    print(f"[Resolver] cookies={bool(cookies)}")

    if settings.require_cookies and not cookies:
        raise RuntimeError("[Resolver] Cookies required but missing")

    songs = []

    # ==============================
    # PLAYLIST
    # ==============================
    if PLAYLIST_REGEX.search(query):
        print("[Resolver] mode=playlist")

        try:
            playlist = await get_playlist_songs(query)
        except Exception as e:
            raise RuntimeError(f"[Resolver:Playlist] {e}")

        for item in playlist:
            url = item["url"]
            print(f"[Resolver] extracting → {url}")

            try:
                stream = await asyncio.to_thread(get_stream, url, cookies)
            except Exception as e:
                print(f"[Resolver:StreamError] {url} → {e}")
                continue

            if not stream:
                print(f"[Resolver:StreamFail] {url}")
                continue

            vid = extract_video_id(url)

            songs.append({
                "title": item.get("title", "Unknown"),
                "url": url,
                "duration": sec_to_mmss(item.get("duration", "0")),
                "views": item.get("views", "Unknown"),
                "video_id": vid,
                "thumb": yt_thumbnail(url),
                "stream": stream,
            })

        return songs or None

    # ==============================
    # DIRECT LINK
    # ==============================
    if YOUTUBE_REGEX.search(query):
        print("[Resolver] mode=direct")

        try:
            stream = await asyncio.to_thread(get_stream, query, cookies)
        except Exception as e:
            raise RuntimeError(f"[Resolver:StreamError] {e}")

        if not stream:
            raise RuntimeError(f"[Resolver] Stream extraction failed → {query}")

        vid = extract_video_id(query)

        return [{
            "title": "YouTube Audio",
            "url": query,
            "duration": "Unknown",
            "views": "Unknown",
            "video_id": vid,
            "thumb": yt_thumbnail(query),
            "stream": stream,
        }]

    # ==============================
    # SEARCH
    # ==============================
    print("[Resolver] mode=search")

    try:
        res = await Search(query, limit=1)
    except Exception as e:
        raise RuntimeError(f"[Resolver:Search] {e}")

    if not res or not res.get("main_results"):
        print("[Resolver] search empty")
        return None

    i = res["main_results"][0]

    try:
        stream = await asyncio.to_thread(get_stream, i["url"], cookies)
    except Exception as e:
        raise RuntimeError(f"[Resolver:StreamError] {e}")

    if not stream:
        raise RuntimeError(f"[Resolver] Stream extraction failed → {i['url']}")

    vid = extract_video_id(i["url"])

    return [{
        "title": i["title"],
        "url": i["url"],
        "duration": i.get("duration", "Unknown"),
        "views": i.get("views", "Unknown"),
        "video_id": vid,
        "thumb": i.get("thumbnail") or yt_thumbnail(i["url"]),
        "stream": stream,
    }]
    
