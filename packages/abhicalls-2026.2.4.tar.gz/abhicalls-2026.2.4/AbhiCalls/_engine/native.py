from pytgcalls import PyTgCalls, filters
from pytgcalls.types import (
    MediaStream,
    AudioQuality,
    VideoQuality,
    StreamEnded,
    ChatUpdate,
)


VIDEO_QUALITY_MAP = {
    "SD_360P": VideoQuality.SD_360p,
    "SD_480P": VideoQuality.SD_480p,
    "HD_720P": VideoQuality.HD_720p,
    "FHD_1080P": VideoQuality.FHD_1080p,
}


class _NativeEngine:
    def __init__(self, app):
        self._core = PyTgCalls(app)
        self.on_end = None
        self.on_vc_closed = None

        # 🔹 STREAM END
        @self._core.on_update(filters.stream_end())
        async def _ended(_, update: StreamEnded):
            if self.on_end:
                await self.on_end(update.chat_id)

        # 🔹 VC CLOSED
        @self._core.on_update(
            filters.chat_update(ChatUpdate.Status.CLOSED_VOICE_CHAT)
        )
        async def _vc_closed(_, update):
            chat_id = update.chat_id
            if self.on_vc_closed:
                try:
                    await self.on_vc_closed(chat_id)
                except Exception as e:
                    print("[NativeEngine] on_vc_closed error:", e)

    async def start(self):
        await self._core.start()

    # =========================
    # 🔊 AUDIO ONLY PLAY
    # =========================
    async def play_audio(self, chat_id, stream: str):
        media = MediaStream(
            media_path=stream,
            audio_parameters=AudioQuality.STUDIO,
            video_flags=MediaStream.Flags.IGNORE,
        )

        try:
            await self._core.play(chat_id, media)
        except Exception:
            # fallback: replace stream if already in VC
            await self._core.change_stream(chat_id, media)

    # =========================
    # 🎥 VIDEO + AUDIO PLAY
    # =========================
    async def play_video(
        self,
        chat_id,
        stream: str,
        quality: str | VideoQuality = "HD_720P",
    ):
        # 🔒 normalize quality
        if isinstance(quality, str):
            quality = VIDEO_QUALITY_MAP.get(
                quality.upper(),
                VideoQuality.HD_720p,
            )

        media = MediaStream(
            media_path=stream,
            audio_parameters=AudioQuality.STUDIO,
            video_parameters=quality,
        )

        try:
            # fresh play (join VC with video)
            await self._core.play(chat_id, media)
        except Exception:
            # 🔥 IMPORTANT FALLBACK (audio → video, video → video)
            await self._core.change_stream(chat_id, media)

    async def stop(self, chat_id):
        await self._core.leave_call(chat_id)

    async def pause(self, chat_id):
        await self._core.pause(chat_id)

    async def resume(self, chat_id):
        await self._core.resume(chat_id)

    async def mute(self, chat_id):
        await self._core.mute(chat_id)

    async def unmute(self, chat_id):
        await self._core.unmute(chat_id)

    async def change_volume(self, chat_id, volume: int = 200):
        await self._core.change_volume(chat_id, volume)
        
