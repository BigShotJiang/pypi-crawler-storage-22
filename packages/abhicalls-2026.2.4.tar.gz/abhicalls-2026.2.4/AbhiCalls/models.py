class Song:
    def __init__(
        self,
        title,
        url,
        duration,
        views,
        stream,
        requested_by,
        loop_left=0,
        video_id=None,
        thumb=None,
        is_video: bool = False,      # 🔹 NEW
        video_quality=None,          # 🔹 OPTIONAL (HD_720p default later)
    ):
        self.title = title
        self.url = url
        self.duration = duration          # raw duration (int or str)
        self.views = views
        self.stream = stream              # file path (mp3 / mp4)
        self.requested_by = requested_by
        self.loop_left = loop_left

        self.video_id = video_id
        self.thumb = thumb

        # 🔹 VIDEO FLAGS
        self.is_video = is_video
        self.video_quality = video_quality

    # 🔹 ALWAYS SAFE: seconds (engine / ETA)
    @property
    def duration_sec(self):
        return self._to_seconds(self.duration)

    # 🔹 DISPLAY FRIENDLY: m:ss or h:mm:ss
    @property
    def duration_text(self):
        sec = self.duration_sec

        m, s = divmod(sec, 60)
        h, m = divmod(m, 60)

        if h:
            return f"{h}:{m:02d}:{s:02d}"
        return f"{m}:{s:02d}"

    def _to_seconds(self, d):
        try:
            if d is None:
                return 0

            if isinstance(d, int):
                return d

            if isinstance(d, str):
                parts = [int(p) for p in d.split(":")]

                if len(parts) == 3:
                    h, m, s = parts
                    return h * 3600 + m * 60 + s

                if len(parts) == 2:
                    m, s = parts
                    return m * 60 + s

            return int(d)
        except Exception:
            return 0
