import os
import asyncio
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

QUEUE_DELETE_AFTER = 30      # seconds
VC_END_DELETE_AFTER = 10    # seconds

def control_buttons():
    text = os.getenv("TEXT")
    link = os.getenv("LINK")
    print("POWERED:", os.getenv("TEXT"), os.getenv("LINK"))
    

    buttons = [
        [
            InlineKeyboardButton("⏮", callback_data="vc_previous"),
            InlineKeyboardButton("▶", callback_data="vc_resume"),
            InlineKeyboardButton("⏹", callback_data="vc_end"),
            InlineKeyboardButton("⏸", callback_data="vc_pause"),
            InlineKeyboardButton("⏭", callback_data="vc_skip"),
        ]
    ]

    if text and link:
        buttons.append(
            [InlineKeyboardButton(text, url=link)]
        )

    return InlineKeyboardMarkup(buttons)

class Plugin:
    name = "base"

    def __init__(self, app):
        self.app = app
        self.now_playing_msg = {}  # chat_id -> message

    async def on_song_start(self, chat_id, song):
        caption = (
            "▶️ Nᴏᴡ Pʟᴀʏɪɴɢ\n\n"
            f"🎵 Tɪᴛʟᴇ : [{song.title[:19]}]({song.url})\n"
            f"⏱ Dᴜʀᴀᴛɪᴏɴ : {song.duration_text}\n"
            f"🙋 Rᴇǫᴜᴇsᴛᴇᴅ Bʏ : {song.requested_by}"
        )

        # delete old now-playing msg if exists
        old = self.now_playing_msg.get(chat_id)
        if old:
            try:
                await old.delete()
            except:
                pass

        if song.thumb:
            msg = await self.app.send_photo(
                chat_id,
                photo=song.thumb,
                caption=caption,
                reply_markup=control_buttons()
            )
        else:
            msg = await self.app.send_message(
                chat_id,
                caption,
                reply_markup=control_buttons()
            )

        self.now_playing_msg[chat_id] = msg

    async def on_song_end(self, chat_id, song):
        msg = self.now_playing_msg.pop(chat_id, None)
        if msg:
            try:
                await msg.delete()
            except:
                pass

    async def on_queue_add(self, chat_id, song, position):
        if position == 1:
            return

        caption = (
            "➕ Aᴅᴅᴇᴅ Tᴏ Qᴜᴇᴜᴇ\n\n"
            f"🎵 Tɪᴛʟᴇ : [{song.title[:19]}]({song.url})\n"
            f"⏱ Dᴜʀᴀᴛɪᴏɴ : {song.duration_text}\n"
            f"🙋 Rᴇǫᴜᴇsᴛᴇᴅ Bʏ : {song.requested_by}\n"
            f"📍 Pᴏsɪᴛɪᴏɴ : {position}"
        )

        if song.thumb:
            msg = await self.app.send_photo(
                chat_id,
                photo=song.thumb,
                caption=caption
            )
        else:
            msg = await self.app.send_message(chat_id, caption)

        asyncio.create_task(self._auto_delete(msg, QUEUE_DELETE_AFTER))

    async def on_vc_closed(self, chat_id):
        try:
            msg = await self.app.send_message(
                chat_id,
                "🔴 Vᴏɪᴄᴇ Cʜᴀᴛ Eɴᴅᴇᴅ\n\n"
                "🧹 Qᴜᴇᴜᴇ Cʟᴇᴀʀᴇᴅ & Pʟᴀʏᴇʀ Sᴛᴏᴘᴘᴇᴅ."
            )
            asyncio.create_task(self._auto_delete(msg, VC_END_DELETE_AFTER))
        except:
            pass

    async def _auto_delete(self, msg, delay):
        try:
            await asyncio.sleep(delay)
            await msg.delete()
        except:
            pass
