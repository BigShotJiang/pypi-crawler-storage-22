from textblob import TextBlob
import spacy

# Load the model carefully
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    print("Warning: Model not found. Run: python -m spacy download en_core_web_sm")

def analyze_sentiment(text):
    """Returns the polarity score and sentiment label."""
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    
    if polarity > 0:
        sentiment = "Positive"
    elif polarity < 0:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"
        
    return {"polarity": polarity, "sentiment": sentiment}

def extract_entities(text):
    """Returns a dictionary of entity counts."""
    doc = nlp(text)
    entity_count = {}
    
    for ent in doc.ents:
        current_count = entity_count.get(ent.label_, 0)
        entity_count[ent.label_] = current_count + 1
        
    return entity_count