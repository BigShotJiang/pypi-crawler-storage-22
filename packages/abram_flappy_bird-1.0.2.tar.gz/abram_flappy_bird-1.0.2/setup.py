from setuptools import setup

setup(
    name="abram_flappy_bird",
    version="1.0.2",
    description="A realistic Flappy Bird game engine with pixel-perfect collision",
    author="Abram Jindal",
    py_modules=["flappybird"],
    install_requires=["pygame"]
)