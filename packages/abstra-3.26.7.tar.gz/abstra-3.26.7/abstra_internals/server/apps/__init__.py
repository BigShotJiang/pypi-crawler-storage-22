from .cloud import get_cloud_app
from .local import get_local_app

__all__ = ["get_local_app", "get_cloud_app"]
