from imports import *



input(escape_velocity_at('earth'))
