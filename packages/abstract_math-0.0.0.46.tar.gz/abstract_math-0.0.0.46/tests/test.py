from imports import *



input(escape_velocity_at('earth',output_dist_unit='mi',output_time_unit='hr'))
