# AbstractDatabaseService

Abstract base class for domain-specific database services. This package provides the foundation for building database services tailored to specific domains (Legal, Finance, etc.).

## Installation

```bash
# From git
pip install git+https://github.com/NlpFisTeam/AbstractDBService.git

# From local
pip install -e ./modules/AbstractDBService
```

## Usage

```python
from AbstractDBService import AbstractDBService, ProcessingResult

class LegalDocumentService(AbstractDBService):
    """Legal document database service."""
    
    def _init_connections(self, **kwargs):
        # Initialize legal-specific connections
        self.arango_connector = kwargs.get("arango_connector")
    
    def process_document(self, file_path, doc_id, metadata, **kwargs):
        # Legal-specific document processing
        pass
    
    # ... implement other abstract methods
```

## Abstract Methods

All inheriting classes must implement:

- `_init_connections(**kwargs)` - Initialize domain-specific connections
- `process_document(file_path, doc_id, metadata, **kwargs)` - Process a document
- `extract_metadata(document, raw_metadata)` - Extract domain-specific metadata
- `create_chunks(document, doc_id, metadata)` - Create chunks with domain-specific logic
- `embed_text(texts)` - Create embeddings
- `create(file_path, metadata, **kwargs)` - Create/ingest a new document
- `update(doc_id, updates, **kwargs)` - Update an existing document
- `delete(doc_id, **kwargs)` - Delete a document
- `init_databases(tenant_id)` - Initialize databases for a new tenant
- `cleanup_databases(tenant_id)` - Cleanup databases for a tenant
