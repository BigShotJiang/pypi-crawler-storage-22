"""AbstractReasoner - Leverages AbstractMemory semantic temporal graph to enable semantic reasoning."""

__version__ = "0.0.1"
