import sys
from . import _config

_no_proxy_done = False

def _no_proxy():
    global _no_proxy_done
    if _no_proxy_done:
        return
    import urllib.request
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    urllib.request.install_opener(opener)
    _no_proxy_done = True

def _client_log(msg: str, level: str = "INFO"):
    try:
        import os
        line = f"{msg}\n"
        log_path = os.path.join(_config._config_dir(), "solver_client.log")
        os.makedirs(_config._config_dir(), exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass

def _get_url():
    cfg = _config.load()
    if cfg and cfg.get("url"):
        return cfg["url"]
    print("First run: enter server URL.")
    url = input("Server URL (e.g. http://your-server:8001): ").strip()
    if not url:
        raise RuntimeError("Server URL is required")
    _config.save_url(url)
    return url

def _request(base_url: str, path: str, method: str = "GET", data: dict | None = None) -> dict:
    _no_proxy()
    import urllib.request
    import urllib.error
    import json
    url = f"{base_url.rstrip('/')}{path}"
    req = urllib.request.Request(url, method=method)
    if data is not None:
        req.data = json.dumps(data).encode("utf-8")
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace") if e.fp else ""
        raise RuntimeError(f"HTTP {e.code}: {body[:200]}" if body else str(e)) from e

def solve(task: str, lang: str, out_file: str | None = None, server_url: str | None = None, out_dir: str = "solutions") -> str:
    """
    Отправить задачу на сервер, вернуть решение (код). Результат всегда сохраняется у клиента.
    task: текст задания, lang: язык (python, c++, ...).
    out_file: дополнительно сохранить в этот файл.
    out_dir: папка для автосохранения (по умолчанию solutions/); результат пишется в out_dir/solution_YYYYMMDD_HHMMSS.txt.
    server_url: URL сервера; если не указан — берётся из конфига.
    """
    import os
    from datetime import datetime
    base_url = (server_url or "").strip() or _get_url()
    data = _request(base_url, "/solve", method="POST", data={"task": task, "lang": lang})
    if not data.get("ok"):
        raise RuntimeError(data.get("detail", "Solve failed"))
    content = data.get("content", "")
    os.makedirs(out_dir, exist_ok=True)
    default_path = os.path.join(out_dir, datetime.now().strftime("solution_%Y%m%d_%H%M%S.txt"))
    with open(default_path, "w", encoding="utf-8") as f:
        f.write(content)
    if out_file:
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(content)
    return content

def send_to_saved(text: str, server_url: str | None = None, out_dir: str = "telegram_sent") -> None:
    """
    Отправить текст в «Избранное» Telegram через сервер. Копия отправленного сохраняется у клиента.
    server_url: URL сервера; если не указан — берётся из конфига.
    out_dir: папка для сохранения копии отправленного (по умолчанию telegram_sent/).
    """
    import os
    from datetime import datetime
    base_url = (server_url or "").strip() or _get_url()
    data = _request(base_url, "/telegram_send", method="POST", data={"text": text})
    if not data.get("ok"):
        raise RuntimeError(data.get("detail", "Send failed"))
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, datetime.now().strftime("sent_%Y%m%d_%H%M%S.txt"))
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def get_saved_messages(limit: int = 50, server_url: str | None = None, out_dir: str = "telegram_saved") -> list[dict]:
    """
    Последние сообщения из «Избранное» — запрос к серверу. Результат сохраняется у клиента в out_dir.
    Возвращает [{"text": ..., "date": ..., "id": ...}, ...].
    out_dir: папка для сохранения каждого сообщения в отдельный .txt (по умолчанию telegram_saved/).
    server_url: URL сервера; если не указан — берётся из конфига.
    """
    import os
    base_url = (server_url or "").strip() or _get_url()
    data = _request(base_url, f"/telegram_saved_messages?limit={limit}")
    raw = data.get("messages", [])
    msgs = [{"id": m.get("id", 0), "text": m.get("text", ""), "date": m.get("date", "")} for m in raw]
    os.makedirs(out_dir, exist_ok=True)
    for m in msgs:
        date_part = (m.get("date", "") or "").replace(":", "-").replace("T", "_")[:19] or "no_date"
        path = os.path.join(out_dir, f"{date_part}_{m.get('id', 0)}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(m.get("text", "") or "(медиа/пусто)")
    return msgs

def listen_and_save_telegram(out_dir: str = "telegram_saved", server_url: str | None = None) -> None:
    """
    Опрашивает сервер и сохраняет каждое новое сообщение из «Избранное» у клиента в out_dir (отдельный .txt).
    Работает до Ctrl+C.
    out_dir: папка для сохранения (по умолчанию telegram_saved/). server_url: URL сервера.
    """
    import os
    import time
    base_url = (server_url or "").strip() or _get_url()
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)
    last_id = 0
    print(f"Сервер: {base_url}. Сообщения сохраняются в: {out_dir}")
    print("Выход: Ctrl+C.\n")
    while True:
        try:
            data = _request(base_url, f"/telegram_new?after_id={last_id}")
            for m in data.get("messages", []):
                mid = m.get("id", 0)
                text = m.get("text", "") or "(медиа/пусто)"
                date = m.get("date", "").replace(":", "-").replace("T", "_")[:19]
                path = os.path.join(out_dir, f"{date}_{mid}.txt")
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text)
                last_id = max(last_id, mid)
                print(f"  сохранено: {os.path.basename(path)}")
        except Exception as e:
            print(f"  ошибка запроса: {e}")
        time.sleep(3)
