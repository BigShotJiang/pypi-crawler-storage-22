# abuz-solver-client

Клиент для удалённого решателя задач. Подключается к серверу (FastAPI), отправляет задачу и получает код решения.

## Установка

```bash
pip install abuz-solver-client
```

## Использование

```python
from abuz_solver import solve, send_to_saved, listen_and_save_telegram, get_saved_messages

# Решить задачу (результат сохраняется в папку solutions/ и возвращается строкой)
code = solve("Напиши hello world на Python", lang="python")

# Отправить текст в «Избранное» Telegram через сервер
send_to_saved("текст")

# Слушать новые сообщения из «Избранное» и сохранять в файлы
listen_and_save_telegram(server_url="http://your-server:8001")

# Получить последние сообщения из «Избранное»
messages = get_saved_messages(limit=50)
```

При первом запуске будет запрошен URL сервера (например `http://your-server:8001`). Он сохраняется в конфиг для следующих вызовов.

## Требования

- Python 3.8+
- Доступ к серверу abuz-solver (с туннелем или в одной сети)
