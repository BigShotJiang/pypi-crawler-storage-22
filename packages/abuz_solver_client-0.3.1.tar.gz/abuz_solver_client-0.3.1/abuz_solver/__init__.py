"""
Клиент к серверу solver + Telegram. Три независимых сценария (отдельные терминалы):

  Терминал 1 — слушать «Избранное», сохранять в папку:
    from abuz_solver import listen_and_save_telegram_sync
    listen_and_save_telegram_sync()   # до Ctrl+C

  Терминал 2 — отправлять сообщения в «Избранное»:
    from abuz_solver import send_to_saved_sync
    send_to_saved_sync("текст")

  Терминал 3 — отправлять задачи в Gemini, получать код:
    from abuz_solver import solve_sync
    solve_sync("задача", lang="py")

Сервер и туннель должны быть запущены. Все функции синхронные (*_sync) — без asyncio.
"""
from ._client import (
    solve,
    solve_sync,
    get_saved_messages,
    get_saved_messages_sync,
    listen_and_save_telegram,
    listen_and_save_telegram_sync,
    send_to_saved,
    send_to_saved_sync,
)

__all__ = [
    "solve",
    "solve_sync",
    "get_saved_messages",
    "get_saved_messages_sync",
    "listen_and_save_telegram",
    "listen_and_save_telegram_sync",
    "send_to_saved",
    "send_to_saved_sync",
]
