from __future__ import annotations

import sys
from typing import List, Optional

from . import _config

_no_proxy_done = False

def _no_proxy():
    global _no_proxy_done
    if _no_proxy_done:
        return
    import urllib.request
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    urllib.request.install_opener(opener)
    _no_proxy_done = True

def _client_log(msg: str, level: str = "INFO"):
    try:
        import os
        line = f"{msg}\n"
        log_path = os.path.join(_config._config_dir(), "solver_client.log")
        os.makedirs(_config._config_dir(), exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass

def _get_url():
    cfg = _config.load()
    if cfg and cfg.get("url"):
        return cfg["url"]
    print("First run: enter server URL.")
    url = input("Server URL (e.g. http://your-server:8001): ").strip()
    if not url:
        raise RuntimeError("Server URL is required")
    _config.save_url(url)
    return url

def _request(base_url: str, path: str, method: str = "GET", data: Optional[dict] = None, timeout: Optional[int] = 120) -> dict:
    _no_proxy()
    import urllib.request
    import urllib.error
    import json
    url = f"{base_url.rstrip('/')}{path}"
    req = urllib.request.Request(url, method=method)
    req.add_header("Bypass-Tunnel-Reminder", "true")
    if data is not None:
        req.data = json.dumps(data).encode("utf-8")
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace") if e.fp else ""
        raise RuntimeError(f"HTTP {e.code}: {body[:200]}" if body else str(e)) from e

def _run_sync_async(sync_func, *args, **kwargs):
    """Запустить блокирующую функцию в потоке. Использовать: await _run_sync_async(...)."""
    import asyncio
    if sys.version_info >= (3, 9):
        return asyncio.to_thread(sync_func, *args, **kwargs)
    loop = asyncio.get_event_loop()
    return loop.run_in_executor(None, lambda: sync_func(*args, **kwargs))


def _solve_sync(task: str, lang: str, out_file: Optional[str] = None, server_url: Optional[str] = None, out_dir: str = "solutions", poll_interval: float = 0.2, poll_timeout: float = 600) -> str:
    import os
    import time
    from datetime import datetime
    base_url = (server_url or "").strip() or _get_url()
    last_err = None
    for attempt in range(3):
        try:
            data = _request(base_url, "/solve", method="POST", data={"task": task, "lang": lang}, timeout=120)
            break
        except (TimeoutError, OSError, ConnectionError) as e:
            last_err = e
            if attempt < 2:
                time.sleep(5)
                continue
            raise RuntimeError(f"{e}. Проверьте туннель и повторите.") from e
    if not data.get("ok"):
        raise RuntimeError(data.get("detail", "Solve failed"))
    job_id = data.get("job_id")
    if not job_id:
        raise RuntimeError("Server did not return job_id")
    os.makedirs(out_dir, exist_ok=True)
    # Таймаут GET: большой ответ Gemini через туннель может идти долго
    result_http_timeout = 120
    deadline = time.monotonic() + poll_timeout
    while True:
        if time.monotonic() > deadline:
            raise RuntimeError(f"Solve не завершился за {int(poll_timeout)} с. Сервер мог уже вернуть результат — проверьте туннель и повторите.")
        try:
            result = _request(base_url, f"/solve/result/{job_id}", timeout=result_http_timeout)
        except (TimeoutError, OSError, ConnectionError) as e:
            time.sleep(poll_interval)
            continue
        status = result.get("status", "")
        if status == "ready":
            content = result.get("content", "")
            default_path = os.path.join(out_dir, datetime.now().strftime("solution_%Y%m%d_%H%M%S.txt"))
            with open(default_path, "w", encoding="utf-8") as f:
                f.write(content)
                f.flush()
            if out_file:
                with open(out_file, "w", encoding="utf-8") as f:
                    f.write(content)
                    f.flush()
            return content
        if status == "error":
            raise RuntimeError(result.get("detail", "Solve failed"))
        time.sleep(poll_interval)


async def solve(task: str, lang: str, out_file: Optional[str] = None, server_url: Optional[str] = None, out_dir: str = "solutions", poll_interval: float = 0.2, poll_timeout: float = 600) -> str:
    """
    Отправить задачу на сервер, вернуть решение (код). Async — не блокирует, можно вызывать параллельно с send_to_saved.
    poll_timeout — макс. время ожидания результата в секундах (по умолчанию 600). Вызов: await solve(...).
    """
    return await _run_sync_async(_solve_sync, task, lang, out_file=out_file, server_url=server_url, out_dir=out_dir, poll_interval=poll_interval, poll_timeout=poll_timeout)


def _send_to_saved_sync(text: str, server_url: Optional[str] = None, out_dir: str = "telegram_sent", timeout: int = 120, max_retries: int = 3) -> None:
    import os
    import time
    from datetime import datetime
    base_url = (server_url or "").strip() or _get_url()
    print("Отправка в Избранное через сервер...")
    last_err = None
    for attempt in range(max_retries):
        try:
            data = _request(base_url, "/telegram_send", method="POST", data={"text": text}, timeout=timeout)
            if not data.get("ok"):
                raise RuntimeError(data.get("detail", "Send failed"))
            break
        except (TimeoutError, OSError, ConnectionError, RuntimeError) as e:
            last_err = e
            if attempt < max_retries - 1:
                time.sleep(2)
                continue
            raise RuntimeError(f"{e}. После {max_retries} попыток.") from e
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, datetime.now().strftime("sent_%Y%m%d_%H%M%S.txt"))
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


async def send_to_saved(text: str, server_url: Optional[str] = None, out_dir: str = "telegram_sent", timeout: int = 120) -> None:
    """
    Отправить текст в «Избранное» Telegram через сервер. Async — можно вызывать параллельно с solve().
    Вызов: await send_to_saved(...). timeout — таймаут запроса в секундах (по умолчанию 120).
    """
    await _run_sync_async(_send_to_saved_sync, text, server_url=server_url, out_dir=out_dir, timeout=timeout)


def _get_saved_messages_sync(limit: int = 50, server_url: Optional[str] = None, out_dir: str = "telegram_saved") -> List[dict]:
    import os
    base_url = (server_url or "").strip() or _get_url()
    data = _request(base_url, f"/telegram_saved_messages?limit={limit}", timeout=60)
    raw = data.get("messages", [])
    msgs = [{"id": m.get("id", 0), "text": m.get("text", ""), "date": m.get("date", "")} for m in raw]
    os.makedirs(out_dir, exist_ok=True)
    for m in msgs:
        date_part = (m.get("date", "") or "").replace(":", "-").replace("T", "_")[:19] or "no_date"
        path = os.path.join(out_dir, f"{date_part}_{m.get('id', 0)}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(m.get("text", "") or "(медиа/пусто)")
    return msgs


async def get_saved_messages(limit: int = 50, server_url: Optional[str] = None, out_dir: str = "telegram_saved") -> List[dict]:
    """
    Последние сообщения из «Избранное». Async. Вызов: await get_saved_messages(...).
    """
    return await _run_sync_async(_get_saved_messages_sync, limit=limit, server_url=server_url, out_dir=out_dir)


def _save_telegram_message(m: dict, out_dir: str) -> None:
    import os
    mid = m.get("id", 0)
    text = m.get("text", "") or "(медиа/пусто)"
    date = (m.get("date", "") or "").replace(":", "-").replace("T", "_")[:19] or "no_date"
    path = os.path.join(out_dir, f"{date}_{mid}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"  сохранено: {os.path.basename(path)}")


def listen_telegram_stream(
    out_dir: str = "telegram_saved",
    server_url: Optional[str] = None,
    last_id_ref: Optional[list] = None,
    raise_on_404: bool = True,
) -> None:
    """
    Подписка на поток SSE: новые сообщения из «Избранное» приходят мгновенно (push).
    last_id_ref: если передан список [int], после сохранения обновляется last_id_ref[0].
    raise_on_404: при True при 404 пробрасывается исключение; при False — тихий выход.
    """
    import json
    import os
    import urllib.error
    import urllib.request
    base_url = (server_url or "").strip() or _get_url()
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)
    stream_url = f"{base_url.rstrip('/')}/telegram_new_stream"
    _no_proxy()
    if last_id_ref is None:
        print(f"Сервер: {base_url}. Поток SSE. Сохранение в: {out_dir}")
    while True:
        try:
            req = urllib.request.Request(stream_url)
            req.add_header("Bypass-Tunnel-Reminder", "true")
            with urllib.request.urlopen(req, timeout=120) as r:
                for line in r:
                    line = line.decode("utf-8", errors="replace").rstrip("\n\r")
                    if line.startswith("data: "):
                        try:
                            msg = json.loads(line[6:])
                            _save_telegram_message(msg, out_dir)
                            if last_id_ref is not None:
                                last_id_ref[0] = max(last_id_ref[0], msg.get("id", 0))
                        except Exception:
                            pass
        except KeyboardInterrupt:
            break
        except urllib.error.HTTPError as e:
            if e.code == 404:
                if raise_on_404:
                    raise
                return
            print(f"  ошибка потока: {e}. Переподключение через 5 сек...")
            import time
            time.sleep(5)
        except Exception as e:
            print(f"  ошибка потока: {e}. Переподключение через 5 сек...")
            import time
            time.sleep(5)


def _listen_and_save_telegram_sync(out_dir: str = "telegram_saved", server_url: Optional[str] = None, poll_interval: float = 0.5, request_timeout: int = 20) -> None:
    import json
    import os
    import threading
    import time
    import urllib.error
    import urllib.request
    base_url = (server_url or "").strip() or _get_url()
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)
    last_id = [0]
    def run_sse():
        try:
            listen_telegram_stream(
                out_dir=out_dir,
                server_url=base_url,
                last_id_ref=last_id,
                raise_on_404=False,
            )
        except Exception:
            pass
    t = threading.Thread(target=run_sse, daemon=True)
    t.start()
    print(f"Сервер: {base_url}. Опрос каждые {poll_interval} сек (таймаут запроса {request_timeout} сек). Сохранение в: {out_dir}")
    print("Выход: Ctrl+C.\n")
    backoff_sec = 1.0
    backoff_max = 10.0
    while True:
        try:
            url = f"{base_url.rstrip('/')}/telegram_new?after_id={last_id[0]}"
            _no_proxy()
            req = urllib.request.Request(url)
            req.add_header("Bypass-Tunnel-Reminder", "true")
            with urllib.request.urlopen(req, timeout=request_timeout) as r:
                raw = r.read().decode("utf-8", errors="replace")
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                raise RuntimeError("Неполный ответ от сервера (повтор)")
            for m in data.get("messages", []):
                _save_telegram_message(m, out_dir)
                last_id[0] = max(last_id[0], m.get("id", 0))
            sleep_sec = poll_interval
            backoff_sec = 1.0
        except KeyboardInterrupt:
            break
        except urllib.error.HTTPError as e:
            if e.code == 404:
                sleep_sec = poll_interval
                backoff_sec = 1.0
            else:
                print(f"  ошибка запроса: HTTP {e.code}. Повтор через {backoff_sec:.0f} сек...")
                sleep_sec = backoff_sec
                backoff_sec = min(backoff_sec * 2, backoff_max)
        except Exception as e:
            print(f"  ошибка запроса: {e}. Повтор через {backoff_sec:.0f} сек...")
            sleep_sec = backoff_sec
            backoff_sec = min(backoff_sec * 2, backoff_max)
        try:
            time.sleep(sleep_sec)
        except KeyboardInterrupt:
            break


async def listen_and_save_telegram(out_dir: str = "telegram_saved", server_url: Optional[str] = None, poll_interval: float = 0.5, request_timeout: int = 20) -> None:
    """
    Сохраняет каждое новое сообщение из «Избранное» в out_dir. Async — запускается в потоке.
    request_timeout — таймаут одного запроса (короткий = меньше обрывов через туннель). Вызов: await listen_and_save_telegram().
    """
    await _run_sync_async(_listen_and_save_telegram_sync, out_dir=out_dir, server_url=server_url, poll_interval=poll_interval, request_timeout=request_timeout)


# --- Синхронные обёртки: вызов без asyncio.run() и await ---

def solve_sync(task: str, lang: str, out_file: Optional[str] = None, server_url: Optional[str] = None, out_dir: str = "solutions", poll_interval: float = 0.2, poll_timeout: float = 600) -> str:
    """То же, что solve(), но без asyncio. poll_timeout — макс. ожидание результата в секундах."""
    import asyncio
    return asyncio.run(solve(task, lang, out_file=out_file, server_url=server_url, out_dir=out_dir, poll_interval=poll_interval, poll_timeout=poll_timeout))


def send_to_saved_sync(text: str, server_url: Optional[str] = None, out_dir: str = "telegram_sent", timeout: int = 120) -> None:
    """То же, что send_to_saved(), но без asyncio: send_to_saved_sync('текст'). timeout — таймаут в секундах."""
    import asyncio
    asyncio.run(send_to_saved(text, server_url=server_url, out_dir=out_dir, timeout=timeout))


def get_saved_messages_sync(limit: int = 50, server_url: Optional[str] = None, out_dir: str = "telegram_saved") -> List[dict]:
    """То же, что get_saved_messages(), но без asyncio."""
    import asyncio
    return asyncio.run(get_saved_messages(limit=limit, server_url=server_url, out_dir=out_dir))


def listen_and_save_telegram_sync(out_dir: str = "telegram_saved", server_url: Optional[str] = None, poll_interval: float = 0.5, request_timeout: int = 20) -> None:
    """То же, что listen_and_save_telegram(), но без asyncio. request_timeout — таймаут запроса (сек)."""
    import asyncio
    asyncio.run(listen_and_save_telegram(out_dir=out_dir, server_url=server_url, poll_interval=poll_interval, request_timeout=request_timeout))
