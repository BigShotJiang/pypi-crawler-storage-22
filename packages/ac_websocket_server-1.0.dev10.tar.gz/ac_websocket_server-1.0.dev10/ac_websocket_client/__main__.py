#!/usr/bin/env python3
"""Entry point for ACWS Web Client using PyWebView.

Replaces the tkinter-based client with a modern web-based UI
served via local HTTP server and displayed in PyWebView.
"""

import os
import sys
import runpy


def main():
    """Delegate to webview_launcher.py for HTTP server and window setup."""
    launcher_path = os.path.join(
        os.path.dirname(__file__), "webview_launcher.py"
    )
    sys.argv[0] = launcher_path
    runpy.run_path(launcher_path, run_name="__main__")


if __name__ == "__main__":
    main()
