#!/usr/bin/env python3
"""PyWebView launcher for ACWS Web Client.

Launches a local HTTP server and opens the ac_http_server/index.html
in a PyWebView window with optional single-server mode via query parameters.
"""

import argparse
import http.server
import os
import socketserver
import sys
import threading
import webview


class SilentHTTPHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP handler that suppresses logging."""

    def log_message(self, fmt, *args):  # noqa: F841
        """Suppress HTTP request logging."""
        pass


def find_free_port(start=8765, end=8800):
    """Find the first available port in the given range.

    Args:
        start: First port to try (default: 8765)
        end: Last port to try (default: 8800)

    Returns:
        An available port number

    Raises:
        RuntimeError: If no port is available in the range
    """
    import socket
    for port in range(start, end):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise RuntimeError("No free port found in range")


def start_http_server(web_directory, port=8765):
    """Start a local HTTP server in a background thread.

    Args:
        web_directory: Directory to serve files from
        port: Port to listen on (default: 8765)

    Returns:
        A tuple of (httpd, port) where httpd is the server instance
    """
    os.chdir(web_directory)
    handler = SilentHTTPHandler
    httpd = socketserver.TCPServer(("127.0.0.1", port), handler)
    server_thread = threading.Thread(
        target=httpd.serve_forever, daemon=True
    )
    server_thread.start()
    return httpd, port


def main():
    """Main entry point for the PyWebView client launcher."""
    parser = argparse.ArgumentParser(
        description="ACWS Web Client (PyWebView)",
        epilog="Example: python -m ac_websocket_client "
               "--host 192.168.1.1 --port 9701"
    )
    parser.add_argument(
        "--host",
        type=str,
        help="Server host for single server mode"
    )
    parser.add_argument(
        "--port",
        type=str,
        help="Server port for single server mode"
    )
    args = parser.parse_args()

    # Validate that both host and port are provided if either is given
    if (args.host and not args.port) or (args.port and not args.host):
        parser.error(
            "Both --host and --port must be provided together "
            "for single server mode"
        )

    # Find ac_http_server directory
    base_dir = os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )
    web_dir = os.path.join(base_dir, "ac_http_server")
    html_file = "index.html"

    if not os.path.exists(os.path.join(web_dir, html_file)):
        print(f"Error: {html_file} not found in {web_dir}")
        sys.exit(1)

    # Find a free port and start HTTP server
    port = find_free_port()
    httpd, port = start_http_server(web_dir, port)

    # Build URL with query parameters for single server mode
    url = f"http://127.0.0.1:{port}/{html_file}"
    if args.host and args.port:
        url += f"?host={args.host}&port={args.port}"

    # Create and start PyWebView window
    try:
        webview.create_window("ACWS Control Panel", url)
        webview.start()
    finally:
        httpd.shutdown()


if __name__ == "__main__":
    main()
