# academic-mcp

一个用于学术任务的 MCP 服务，支持：

- `paper_search`：跨多源检索论文（arXiv / Crossref / Semantic Scholar / CORE）
- `generate_literature_review`：基于检索结果自动生成综述草稿（可落盘到 `docs/`）
- `get_academic_config`：查看当前 key/配置状态

## 1) 环境变量

复制 `.env.example` 为 `.env`，需要的 key 默认留空：

```env
SEMANTIC_SCHOLAR_API_KEY=
CORE_API_KEY=
SCIENCEDIRECT_API_KEY=
SPRINGER_API_KEY=
IEEE_API_KEY=
SCOPUS_API_KEY=
```

说明：

- 本项目核心流程不强制依赖 key（arXiv/Crossref 可直接用）。
- 如需更高配额或付费源，再填对应 key。

## 2) uv 运行

在 `academic-mcp/` 目录执行：

```bash
uv sync
uv run academic-mcp --transport stdio
```

HTTP 模式：

```bash
uv run academic-mcp --transport http --host 127.0.0.1 --port 8005
```

模块方式：

```bash
uv run python -m academic_mcp --transport stdio
```

## 3) 测试

```bash
uv run python tests/smoke_test.py
```

## 4) 发布

```bash
uv build
uv publish
```

可选 TestPyPI：

```bash
uv publish --index testpypi
```

## 5) OpenCode MCP 配置示例

```json
{
  "mcp": {
    "academic-mcp": {
      "type": "local",
      "command": [
        "uv",
        "run",
        "--directory",
        "D:/OneDrive/WORK/Python/mcps/academic-mcp",
        "academic-mcp"
      ],
      "environment": {
        "SEMANTIC_SCHOLAR_API_KEY": "",
        "CORE_API_KEY": "",
        "ACADEMIC_MCP_TRANSPORT": "stdio"
      }
    }
  }
}
```
