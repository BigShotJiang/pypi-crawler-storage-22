# academic-mcp

一个用于学术任务的 MCP 服务，支持：

- `paper_search`：基于 OpenAlex 检索论文
- `generate_literature_review`：基于检索结果自动生成综述草稿（可落盘到 `docs/`）
- `get_academic_config`：查看当前 key/配置状态

## 1) 环境变量

复制 `.env.example` 为 `.env`：

```env
OPENALEX_API_KEY=
OPENALEX_MAILTO=
```

说明：

- `OPENALEX_API_KEY` 为必填。
- `OPENALEX_MAILTO` 可选，建议填写（用于 OpenAlex polite pool）。

## 2) uv 运行

在 `academic-mcp/` 目录执行：

```bash
uv sync
uv run academic-mcp --transport stdio
```

HTTP 模式：

```bash
uv run academic-mcp --transport http --host 127.0.0.1 --port 8005
```

模块方式：

```bash
uv run python -m academic_mcp --transport stdio
```

## 3) 测试

```bash
uv run python tests/smoke_test.py
```

## 4) 发布

```bash
uv build
uv publish
```

可选 TestPyPI：

```bash
uv publish --index testpypi
```

## 5) OpenCode MCP 配置示例

```json
{
  "mcp": {
    "academic-mcp": {
      "type": "local",
      "command": [
        "uv",
        "run",
        "--directory",
        "D:/OneDrive/WORK/Python/mcps/academic-mcp",
        "academic-mcp"
      ],
      "environment": {
        "OPENALEX_API_KEY": "",
        "OPENALEX_MAILTO": "",
        "ACADEMIC_MCP_TRANSPORT": "stdio"
      }
    }
  }
}
```
