from __future__ import annotations

import asyncio

from academic_mcp.server import generate_literature_review, paper_search


async def main() -> int:
    search_result = await paper_search(
        query="large language model",
        sources=["openalex"],
        max_results_per_source=2,
        timeout_seconds=30,
    )
    papers = search_result.get("papers", [])
    assert isinstance(papers, list), "papers should be a list"
    assert len(papers) > 0, "paper_search should return at least one paper"

    review_result = await generate_literature_review(
        topic="large language model safety",
        queries=["large language model safety"],
        sources=["openalex"],
        max_results_per_query=2,
        save_to_docs=False,
        timeout_seconds=30,
    )
    review_markdown = review_result.get("review_markdown", "")
    assert isinstance(review_markdown, str), "review_markdown should be string"
    assert "论文综述草稿" in review_markdown, "review output should contain expected section"

    print("smoke_test passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
