class PlaceHolderRecord:
    pass
