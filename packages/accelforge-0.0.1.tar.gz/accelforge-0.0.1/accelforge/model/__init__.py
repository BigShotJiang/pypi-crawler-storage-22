from accelforge.model.main import evaluate_mapping
