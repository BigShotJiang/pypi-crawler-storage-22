from .latency import get_latency
