import os
from pathlib import Path

EXAMPLES_DIR = Path(os.path.abspath("../../examples"))