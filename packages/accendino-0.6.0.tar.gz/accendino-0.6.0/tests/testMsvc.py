import json
from accendino.toolchain import computeEnvDiff

v = '''[
  {
    "instanceId": "8889553d",
    "installDate": "2024-01-23T08:00:18Z",
    "installationName": "VisualStudio/17.14.14+36429.23",
    "installationPath": "C:\\\\Program Files\\\\Microsoft Visual Studio\\\\2022\\\\Community",
    "installationVersion": "17.14.36429.23",
    "productId": "Microsoft.VisualStudio.Product.Community",
    "productPath": "C:\\\\Program Files\\\\Microsoft Visual Studio\\\\2022\\\\Community\\\\Common7\\\\IDE\\\\devenv.exe",
    "state": 4294967295,
    "isComplete": true,
    "isLaunchable": true,
    "isPrerelease": false,
    "isRebootRequired": false,
    "displayName": "Visual Studio Community 2022",
    "description": "IDE puissant, gratuit pour les étudiants, les contributeurs open source et les particuliers",
    "channelId": "VisualStudio.17.Release",
    "channelUri": "https://aka.ms/vs/17/release/channel",
    "enginePath": "C:\\\\Program Files (x86)\\\\Microsoft Visual Studio\\\\Installer\\\\resources\\\\app\\\\ServiceHub\\\\Services\\\\Microsoft.VisualStudio.Setup.Service",
    "installedChannelId": "VisualStudio.17.Release",
    "installedChannelUri": "https://aka.ms/vs/17/release/channel",
    "releaseNotes": "https://docs.microsoft.com/en-us/visualstudio/releases/2022/release-notes-v17.14#17.14.14",
    "resolvedInstallationPath": "C:\\\\Program Files\\\\Microsoft Visual Studio\\\\2022\\\\Community",
    "thirdPartyNotices": "https://go.microsoft.com/fwlink/?LinkId=661288",
    "updateDate": "2025-09-12T19:56:45.150353Z",
    "catalog": {
      "buildBranch": "d17.14",
      "buildVersion": "17.14.36429.23",
      "id": "VisualStudio/17.14.14+36429.23",
      "localBuild": "build-lab",
      "manifestName": "VisualStudio",
      "manifestType": "installer",
      "productDisplayVersion": "17.14.14",
      "productLine": "Dev17",
      "productLineVersion": "2022",
      "productMilestone": "RTW",
      "productMilestoneIsPreRelease": "False",
      "productName": "Visual Studio",
      "productPatchVersion": "14",
      "productPreReleaseMilestoneSuffix": "1.0",
      "productSemanticVersion": "17.14.14+36429.23",
      "requiredEngineVersion": "3.14.2086.54749"
    },
    "properties": {
      "campaignId": "2030:084e6fb6-0816-4291-b1cf-71d75f4176bc",
      "channelManifestId": "VisualStudio.17.Release/17.14.14+36429.23",
      "nickname": "",
      "setupEngineFilePath": "C:\\\\Program Files (x86)\\\\Microsoft Visual Studio\\\\Installer\\\\setup.exe"
    }
  }
]'''


#obj = json.loads(v)
#print(obj)

if __name__ == '__main__':
    v = open('cmdOutput.txt', 'r').readlines()

    diff = computeEnvDiff(v)
