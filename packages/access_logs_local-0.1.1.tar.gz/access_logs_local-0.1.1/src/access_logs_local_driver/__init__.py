from .process_download_logs import make_filters
from .logdata import LogProcessor
