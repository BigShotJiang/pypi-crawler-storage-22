from accusleepy.gui.main import run_primary_window

if __name__ == "__main__":
    run_primary_window()
