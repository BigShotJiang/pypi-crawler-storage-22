from typing import Any

from .tool import Tool

BUILTIN_TOOLS: list[Tool[Any, Any]] = []
