import re

_LATIN_TO_CUNEIFORM = {
    "a": "\U000103A0",
    "i": "\U000103A1",
    "u": "\U000103A2",
    "b": "\U000103B2",
    "p": "\U000103B1",
    "t": "\U000103AB",
    "d": "\U000103AD",
    "g": "\U000103A5",
    "k": "\U000103A3",
    "c": "\U000103A8",
    "ç": "\U000103C2",
    "j": "\U000103A9",
    "y": "\U000103B9",
    "v": "\U000103BA",
    "r": "\U000103BC",
    "l": "\U000103BE",
    "s": "\U000103BF",
    "z": "\U000103C0",
    "š": "\U000103C1",
    "h": "\U000103C3",
    "m": "\U000103B6",
    "n": "\U000103B4",
    "θ": "\U000103B0",
    "x": "\U000103A7",
    "f": "\U000103B3",
    "th": "\U000103B0",
    "ch": "\U000103A8",
    "sh": "\U000103C1",
    "tr": "\U000103AB\U000103BC",
    "je": "\U000103A9",
    "do": "\U000103AD",
    "de": "\U000103AD",
    "ro": "\U000103BC",
}

_PERSIAN_TO_ENGLISH = {
    'ا': 'a', 'آ': 'a', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ث': 's',
    'ج': 'j', 'چ': 'ch', 'ح': 'h', 'خ': 'kh', 'د': 'd', 'ذ': 'z',
    'ر': 'r', 'ز': 'z', 'ژ': 'zh', 'س': 's', 'ش': 'sh', 'ص': 's',
    'ض': 'z', 'ط': 't', 'ظ': 'z', 'ع': 'a', 'غ': 'gh', 'ف': 'f',
    'ق': 'gh', 'ک': 'k', 'گ': 'g', 'ل': 'l', 'م': 'm', 'ن': 'n',
    'و': 'v', 'ه': 'h', 'ی': 'y', 'ي': 'y', 'ء': '',
    ' ': ' ', '،': ',', '؟': '?', '.': '.', '!': '!',
}

def is_persian(text):
    for ch in text:
        if 0x0600 <= ord(ch) <= 0x06FF or 0xFB50 <= ord(ch) <= 0xFDFF:
            return True
    return False

def persian_to_english(text):
    return ''.join(_PERSIAN_TO_ENGLISH.get(ch, ch) for ch in text)

def convert(text):
    if is_persian(text):
        text = persian_to_english(text)
    result = []
    i = 0
    keys = sorted(_LATIN_TO_CUNEIFORM.keys(), key=len, reverse=True)
    while i < len(text):
        matched = False
        for key in keys:
            if text.lower().startswith(key, i):
                result.append(_LATIN_TO_CUNEIFORM[key])
                i += len(key)
                matched = True
                break
        if not matched:
            result.append(text[i])
            i += 1
    return ''.join(result)

def reverse_convert(cuneiform):
    rev_map = {v: k for k, v in _LATIN_TO_CUNEIFORM.items()}
    return ''.join(rev_map.get(ch, ch) for ch in cuneiform)