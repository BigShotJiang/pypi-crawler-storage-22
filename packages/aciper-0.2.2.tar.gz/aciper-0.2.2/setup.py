from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="aciper",
    version="0.2.2",
    author="Mohammad Latifipour",
    author_email="your.email@example.com",
    description="تبدیل متن فارسی/انگلیسی به خط میخی پارسی باستان",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/aciper",
    packages=find_packages(),  # یا packages=["aciper"]
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Text Processing :: Linguistic",
        "Natural Language :: Persian",
    ],
    python_requires='>=3.6',
    keywords="cuneiform old persian achaemenid persian farsi",
)