from acoustools.BEM.Gradients.E_Gradient import *
from acoustools.BEM.Gradients.H_Gradient import *