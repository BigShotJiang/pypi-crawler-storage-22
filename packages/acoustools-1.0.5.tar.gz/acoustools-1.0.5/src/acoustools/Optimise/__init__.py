'''
Methods for optimsation objectives and constrains\n
`src.acoustools.Optimise.Constraints`\n
`src.acoustools.Optimise.Objectives`\n
'''