# SPDX-FileCopyrightText: 2023-present JoshuaMukherjee <joshuaakmukherjee@gmail.com>
#
# SPDX-License-Identifier: MIT

"""
.. include:: ../../../README.md
"""

