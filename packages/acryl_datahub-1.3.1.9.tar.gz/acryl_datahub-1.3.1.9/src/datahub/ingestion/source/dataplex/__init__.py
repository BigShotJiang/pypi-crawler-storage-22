"""Google Dataplex source for DataHub."""

from datahub.ingestion.source.dataplex.dataplex import DataplexSource

__all__ = ["DataplexSource"]
