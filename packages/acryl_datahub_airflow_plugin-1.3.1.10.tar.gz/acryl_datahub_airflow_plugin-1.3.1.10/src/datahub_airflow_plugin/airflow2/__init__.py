"""
DataHub Airflow Plugin v2 for Airflow 2.x.

This module provides the DataHub listener implementation for Airflow 2.x,
using the legacy openlineage-airflow package and extractor-based lineage.
"""
