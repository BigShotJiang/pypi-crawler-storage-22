"""Tests for Action Aperture."""
