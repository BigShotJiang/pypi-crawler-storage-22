"""
ActivePaths: A library for rare dynamical event sampling in non-equilibrium systems.
Based on Transition Path Sampling (RTP-TPS) and Variational Path Sampling (VPS).
"""
