"""
AdamOps Models Module

Provides model training and management capabilities:
- modelops: Train various ML models (regression, classification, clustering)
- registry: Version and track models with metadata
- ensembles: Create ensemble models (voting, stacking, blending)
- automl: Automated model selection and hyperparameter tuning
"""

from adamops.models import modelops
from adamops.models import registry
from adamops.models import ensembles
from adamops.models import automl

__all__ = [
    "modelops",
    "registry",
    "ensembles",
    "automl",
]
