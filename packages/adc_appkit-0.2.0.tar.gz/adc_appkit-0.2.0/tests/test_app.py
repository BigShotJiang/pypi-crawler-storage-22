"""
Core tests for BaseApp: singleton lifecycle, DI, request scope, healthcheck.
"""

import pytest

from adc_appkit import BaseApp, ComponentStrategy, component
from adc_appkit.components.component import Component


# ========================= Mock components =========================


class MockResource:
    """Plain resource with close/is_alive support."""

    def __init__(self, **kwargs):
        self.config = kwargs
        self.closed = False

    async def close(self):
        self.closed = True

    async def is_alive(self):
        return not self.closed


class MockComponent(Component[MockResource]):
    async def _start(self, **kwargs) -> MockResource:
        return MockResource(**kwargs)

    async def _stop(self) -> None:
        await self.obj.close()

    async def is_alive(self) -> bool:
        return await self.obj.is_alive()


class FailingComponent(Component[MockResource]):
    """Component that always fails on start."""

    async def _start(self, **kwargs) -> MockResource:
        raise RuntimeError("startup failure")

    async def _stop(self) -> None:
        pass


# ========================= Test apps =========================


class SimpleApp(BaseApp):
    comp = component(MockComponent, config_key="comp")


class TwoSingletonApp(BaseApp):
    comp1 = component(MockComponent, config_key="comp1")
    comp2 = component(
        MockComponent, config_key="comp2", dependencies={"dep": "comp1"}
    )


class SingletonAndRequestApp(BaseApp):
    singleton = component(MockComponent, config_key="singleton")
    req_comp = component(
        MockComponent,
        config_key="req_comp",
        strategy=ComponentStrategy.REQUEST,
    )


class RequestWithDepApp(BaseApp):
    singleton = component(MockComponent, config_key="singleton")
    req_comp = component(
        MockComponent,
        config_key="req_comp",
        strategy=ComponentStrategy.REQUEST,
        dependencies={"dep": "singleton"},
    )


class TwoRequestApp(BaseApp):
    req_a = component(
        MockComponent,
        config_key="req_a",
        strategy=ComponentStrategy.REQUEST,
    )
    req_b = component(
        MockComponent,
        config_key="req_b",
        strategy=ComponentStrategy.REQUEST,
    )


class RequestWithFailApp(BaseApp):
    singleton = component(MockComponent, config_key="singleton")
    good_req = component(
        MockComponent,
        config_key="good_req",
        strategy=ComponentStrategy.REQUEST,
    )
    bad_req = component(
        FailingComponent,
        config_key="bad_req",
        strategy=ComponentStrategy.REQUEST,
    )


# ========================= Singleton tests =========================


async def test_singleton_lifecycle():
    app = SimpleApp(components_config={"comp": {"name": "test"}})
    await app.start()

    obj = app.comp
    assert obj.config["name"] == "test"
    assert not obj.closed

    await app.stop()
    # after stop, descriptor raises; but the object itself was closed
    assert obj.closed


async def test_singleton_identity():
    """Same descriptor access returns same object."""
    app = SimpleApp(components_config={"comp": {"x": 1}})
    await app.start()

    obj1 = app.comp
    obj2 = app.comp
    assert obj1 is obj2

    await app.stop()


async def test_singleton_dependency_injection():
    """comp2 receives comp1.obj as 'dep' parameter."""
    app = TwoSingletonApp(
        components_config={"comp1": {"role": "database"}, "comp2": {"role": "dao"}}
    )
    await app.start()

    # comp2 should have received comp1.obj as dep
    assert app.comp2.config["dep"] is app.comp1

    await app.stop()


async def test_singleton_start_order():
    """Dependencies start before dependents (topological order)."""
    start_log = []

    class TrackingComponent(Component[MockResource]):
        async def _start(self, **kwargs) -> MockResource:
            start_log.append(kwargs.get("name"))
            return MockResource(**kwargs)

        async def _stop(self) -> None:
            pass

    class OrderApp(BaseApp):
        first = component(TrackingComponent, config_key="first")
        second = component(
            TrackingComponent,
            config_key="second",
            dependencies={"dep": "first"},
        )

    app = OrderApp(
        components_config={"first": {"name": "first"}, "second": {"name": "second"}}
    )
    await app.start()

    assert start_log == ["first", "second"]
    await app.stop()


async def test_healthcheck():
    app = TwoSingletonApp(
        components_config={"comp1": {"x": 1}, "comp2": {"x": 2}}
    )
    await app.start()

    health = await app.healthcheck()
    assert health == {"comp1": True, "comp2": True}

    await app.stop()


async def test_stop_reverse_order():
    """Components stop in reverse topological order."""
    stop_log = []

    class TrackingComponent(Component[MockResource]):
        async def _start(self, **kwargs) -> MockResource:
            return MockResource(**kwargs)

        async def _stop(self) -> None:
            stop_log.append(self._config.get("name"))

    class OrderApp(BaseApp):
        first = component(TrackingComponent, config_key="first")
        second = component(
            TrackingComponent,
            config_key="second",
            dependencies={"dep": "first"},
        )

    app = OrderApp(
        components_config={"first": {"name": "first"}, "second": {"name": "second"}}
    )
    await app.start()
    await app.stop()

    assert stop_log == ["second", "first"]


async def test_descriptor_returns_obj():
    """Descriptor returns the managed object, not the Component wrapper."""
    app = SimpleApp(components_config={"comp": {"val": 42}})
    await app.start()

    result = app.comp
    assert isinstance(result, MockResource)
    assert result.config["val"] == 42

    await app.stop()


async def test_singleton_cannot_depend_on_request():
    """Validation rejects SINGLETON depending on REQUEST."""
    with pytest.raises(RuntimeError, match="cannot depend on REQUEST"):

        class BadApp(BaseApp):
            req = component(
                MockComponent,
                config_key="req",
                strategy=ComponentStrategy.REQUEST,
            )
            single = component(
                MockComponent,
                config_key="single",
                dependencies={"dep": "req"},
            )

        BadApp(components_config={"req": {}, "single": {}})


# ========================= Request scope tests =========================


async def test_request_scope_lifecycle():
    app = SingletonAndRequestApp(
        components_config={"singleton": {"x": 1}, "req_comp": {"y": 2}}
    )
    await app.start()

    async with app.request_scope({"req_comp": {"y": 99}}) as scope:
        comp = scope.get("req_comp")
        assert comp.started

    # after exit, component is stopped
    assert not comp.started

    await app.stop()


async def test_request_scope_ctx_overrides():
    """ctx values override base config for REQUEST components."""
    app = SingletonAndRequestApp(
        components_config={"singleton": {"x": 1}, "req_comp": {"base_val": "original"}}
    )
    await app.start()

    async with app.request_scope({"req_comp": {"base_val": "overridden", "extra": 42}}) as scope:
        obj = scope.use("req_comp")
        assert obj.config["base_val"] == "overridden"
        assert obj.config["extra"] == 42

    await app.stop()


async def test_request_scope_isolation():
    """Two request scopes get independent component instances."""
    app = SingletonAndRequestApp(
        components_config={"singleton": {}, "req_comp": {}}
    )
    await app.start()

    async with app.request_scope({"req_comp": {"id": 1}}) as scope1:
        obj1 = scope1.use("req_comp")

    async with app.request_scope({"req_comp": {"id": 2}}) as scope2:
        obj2 = scope2.use("req_comp")

    assert obj1 is not obj2
    assert obj1.config["id"] == 1
    assert obj2.config["id"] == 2

    await app.stop()


async def test_request_scope_with_singleton_dependency():
    """REQUEST component receives SINGLETON .obj via DI."""
    app = RequestWithDepApp(
        components_config={"singleton": {"name": "pg"}, "req_comp": {"extra": 1}}
    )
    await app.start()

    async with app.request_scope({"req_comp": {}}) as scope:
        obj = scope.use("req_comp")
        # dep should be the singleton's MockResource
        assert isinstance(obj.config["dep"], MockResource)
        assert obj.config["dep"] is app.singleton

    await app.stop()


async def test_request_scope_multiple_components():
    app = TwoRequestApp(
        components_config={"req_a": {"name": "a"}, "req_b": {"name": "b"}}
    )
    await app.start()

    async with app.request_scope({}) as scope:
        a = scope.use("req_a")
        b = scope.use("req_b")
        assert a is not b
        assert a.config["name"] == "a"
        assert b.config["name"] == "b"

    await app.stop()


async def test_request_scope_cleanup_on_error():
    """If a REQUEST component fails to start, already-started ones are stopped."""
    app = RequestWithFailApp(
        components_config={"singleton": {}, "good_req": {}, "bad_req": {}}
    )
    await app.start()

    with pytest.raises(RuntimeError, match="startup failure"):
        async with app.request_scope({}):
            pass

    await app.stop()
