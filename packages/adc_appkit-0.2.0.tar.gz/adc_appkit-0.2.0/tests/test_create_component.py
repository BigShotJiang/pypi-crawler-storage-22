"""
Tests for create_component(): wrapping plain classes into Component.
"""

import pytest

from adc_appkit import BaseApp, ComponentStrategy, component
from adc_appkit.components.component import Component, create_component


# ========================= Mock classes =========================


class ServiceWithAsyncClose:
    def __init__(self, name: str = "default", **kwargs):
        self.name = name
        self.extra = kwargs
        self.closed = False

    async def close(self):
        self.closed = True

    async def is_alive(self):
        return not self.closed


class ServiceWithSyncClose:
    def __init__(self, batch_size: int = 10, **kwargs):
        self.batch_size = batch_size
        self.extra = kwargs
        self.closed = False

    def close(self):
        self.closed = True


class PlainObject:
    """No close, no is_alive."""

    def __init__(self, **kwargs):
        self.config = kwargs


class DAOMock:
    """Simulates DAO that receives a pool dependency."""

    def __init__(self, pool, **kwargs):
        self.pool = pool
        self.extra = kwargs


# ========================= Tests =========================


async def test_basic():
    """create_component wraps class, _start creates instance."""
    Wrapped = create_component(ServiceWithAsyncClose)
    inst = Wrapped()
    inst.set_config({"name": "svc"})
    await inst.start()

    assert isinstance(inst.obj, ServiceWithAsyncClose)
    assert inst.obj.name == "svc"

    await inst.stop()


async def test_config_passthrough():
    """All config kwargs reach the constructor."""
    Wrapped = create_component(ServiceWithAsyncClose)
    inst = Wrapped()
    inst.set_config({"name": "test", "debug": True, "retries": 3})
    await inst.start()

    assert inst.obj.name == "test"
    assert inst.obj.extra["debug"] is True
    assert inst.obj.extra["retries"] == 3

    await inst.stop()


async def test_async_close():
    """Stop calls async close() on the wrapped object."""
    Wrapped = create_component(ServiceWithAsyncClose)
    inst = Wrapped()
    inst.set_config({"name": "a"})
    await inst.start()

    assert not inst.obj.closed
    await inst.stop()
    assert inst._obj.closed


async def test_sync_close():
    """Stop calls sync close() on the wrapped object."""
    Wrapped = create_component(ServiceWithSyncClose)
    inst = Wrapped()
    inst.set_config({"batch_size": 50})
    await inst.start()

    assert not inst.obj.closed
    await inst.stop()
    assert inst._obj.closed


async def test_no_close():
    """Stop works even without close method."""
    Wrapped = create_component(PlainObject)
    inst = Wrapped()
    inst.set_config({"key": "value"})
    await inst.start()
    await inst.stop()  # should not raise


async def test_is_alive_delegation():
    """is_alive delegates to obj.is_alive if present."""
    Wrapped = create_component(ServiceWithAsyncClose)
    inst = Wrapped()
    inst.set_config({"name": "x"})
    await inst.start()

    assert await inst.is_alive() is True

    inst.obj.closed = True
    assert await inst.is_alive() is False

    await inst.stop()


async def test_class_naming():
    """Wrapped class has readable name."""
    Wrapped = create_component(ServiceWithAsyncClose)
    assert Wrapped.__name__ == "Component[ServiceWithAsyncClose]"
    assert Wrapped.__qualname__ == "Component[ServiceWithAsyncClose]"
    assert issubclass(Wrapped, Component)


async def test_as_singleton_in_app():
    """create_component works as SINGLETON in BaseApp."""

    class App(BaseApp):
        svc = component(
            create_component(ServiceWithAsyncClose),
            config_key="svc",
        )

    app = App(components_config={"svc": {"name": "prod"}})
    await app.start()

    assert isinstance(app.svc, ServiceWithAsyncClose)
    assert app.svc.name == "prod"

    await app.stop()


async def test_as_request_in_app():
    """create_component works as REQUEST in BaseApp with ctx overrides."""

    class App(BaseApp):
        processor = component(
            create_component(ServiceWithSyncClose),
            config_key="processor",
            strategy=ComponentStrategy.REQUEST,
        )

    app = App(components_config={"processor": {"batch_size": 100}})
    await app.start()

    async with app.request_scope({"processor": {"batch_size": 25}}) as scope:
        obj = scope.use("processor")
        assert isinstance(obj, ServiceWithSyncClose)
        assert obj.batch_size == 25  # ctx override applied

    await app.stop()


async def test_with_dependency():
    """create_component receives DI-injected .obj (pattern: DAO gets pool from PG)."""

    class PoolMock:
        def __init__(self, dsn: str = "", **kw):
            self.dsn = dsn

    class PoolComponent(Component[PoolMock]):
        async def _start(self, **kw) -> PoolMock:
            return PoolMock(**kw)

        async def _stop(self) -> None:
            pass

    class App(BaseApp):
        pool = component(PoolComponent, config_key="pool")
        dao = component(
            create_component(DAOMock),
            config_key="dao",
            dependencies={"pool": "pool"},
        )

    app = App(components_config={"pool": {"dsn": "postgres://localhost"}, "dao": {}})
    await app.start()

    assert isinstance(app.dao, DAOMock)
    assert isinstance(app.dao.pool, PoolMock)
    assert app.dao.pool.dsn == "postgres://localhost"
    assert app.dao.pool is app.pool

    await app.stop()
