"""
Tests for REQUEST component patterns.

Inspired by auth project: CurrentIdentity receives ctx (sub from JWT)
and DI dependency (dao from SINGLETON), loads user from DB on start.
"""

import pytest

from adc_appkit import BaseApp, ComponentStrategy, component
from adc_appkit.components.component import Component, create_component


# ========================= Mock domain =========================


class User:
    """Domain object returned by CurrentUser component."""

    def __init__(self, user_id: str, name: str):
        self.user_id = user_id
        self.name = name


class FakeDAO:
    """Simulates a data access layer (SINGLETON)."""

    def __init__(self, **kwargs):
        self.users = {
            "user-1": User("user-1", "Alice"),
            "user-2": User("user-2", "Bob"),
        }

    async def get_user_by_id(self, user_id: str):
        return self.users.get(user_id)


class CurrentUser(Component[User]):
    """
    REQUEST-scoped component: loads current user by ID from request context.
    Pattern from auth: CurrentIdentity(Component[AuthIdentity]).
    """

    async def _start(self, sub: str, dao: FakeDAO, **kw) -> User:
        user = await dao.get_user_by_id(sub)
        if not user:
            raise ValueError(f"User {sub} not found")
        return user

    async def _stop(self) -> None:
        pass


class RequestLogger(Component):
    """Another REQUEST component that receives ctx values."""

    async def _start(self, request_id: str = "", **kw):
        return {"request_id": request_id, **kw}

    async def _stop(self) -> None:
        pass


# ========================= Test apps =========================


class AppWithCurrentUser(BaseApp):
    dao = component(create_component(FakeDAO), config_key="dao")
    current_user = component(
        CurrentUser,
        config_key="current_user",
        strategy=ComponentStrategy.REQUEST,
        dependencies={"dao": "dao"},
    )


class AppWithMultipleRequest(BaseApp):
    dao = component(create_component(FakeDAO), config_key="dao")
    current_user = component(
        CurrentUser,
        config_key="current_user",
        strategy=ComponentStrategy.REQUEST,
        dependencies={"dao": "dao"},
    )
    logger = component(
        RequestLogger,
        config_key="logger",
        strategy=ComponentStrategy.REQUEST,
    )


# ========================= Tests =========================


async def test_request_component_receives_ctx_and_deps():
    """REQUEST component gets ctx values (sub) AND singleton .obj (dao)."""
    app = AppWithCurrentUser(components_config={"dao": {}, "current_user": {}})
    await app.start()

    async with app.request_scope({"current_user": {"sub": "user-1"}}) as scope:
        user = scope.use("current_user")
        assert isinstance(user, User)
        assert user.user_id == "user-1"
        assert user.name == "Alice"

    await app.stop()


async def test_request_component_accessible_via_descriptor():
    """app.current_user returns .obj directly inside request scope."""
    app = AppWithCurrentUser(components_config={"dao": {}, "current_user": {}})
    await app.start()

    async with app.request_scope({"current_user": {"sub": "user-2"}}):
        user = app.current_user
        assert isinstance(user, User)
        assert user.name == "Bob"

    await app.stop()


async def test_request_component_different_ctx():
    """Different request scopes with different ctx produce different objects."""
    app = AppWithCurrentUser(components_config={"dao": {}, "current_user": {}})
    await app.start()

    async with app.request_scope({"current_user": {"sub": "user-1"}}) as s1:
        user1 = s1.use("current_user")

    async with app.request_scope({"current_user": {"sub": "user-2"}}) as s2:
        user2 = s2.use("current_user")

    assert user1.name == "Alice"
    assert user2.name == "Bob"
    assert user1 is not user2

    await app.stop()


async def test_request_component_invalid_ctx_raises():
    """If ctx value causes _start to fail, error propagates."""
    app = AppWithCurrentUser(components_config={"dao": {}, "current_user": {}})
    await app.start()

    with pytest.raises(ValueError, match="not found"):
        async with app.request_scope({"current_user": {"sub": "nonexistent"}}):
            pass

    await app.stop()


async def test_multiple_request_components():
    """Several REQUEST components in one scope, each gets its own ctx."""
    app = AppWithMultipleRequest(
        components_config={"dao": {}, "current_user": {}, "logger": {}}
    )
    await app.start()

    ctx = {
        "current_user": {"sub": "user-1"},
        "logger": {"request_id": "req-42"},
    }
    async with app.request_scope(ctx) as scope:
        user = scope.use("current_user")
        log_data = scope.use("logger")

        assert user.name == "Alice"
        assert log_data["request_id"] == "req-42"

    await app.stop()


async def test_ctx_override_base_config():
    """ctx values override base config keys."""
    app = AppWithMultipleRequest(
        components_config={
            "dao": {},
            "current_user": {},
            "logger": {"request_id": "default"},
        }
    )
    await app.start()

    # without ctx override — uses base config
    async with app.request_scope({"current_user": {"sub": "user-1"}}) as scope:
        log_data = scope.use("logger")
        assert log_data["request_id"] == "default"

    # with ctx override — overrides base
    ctx = {
        "current_user": {"sub": "user-1"},
        "logger": {"request_id": "req-override"},
    }
    async with app.request_scope(ctx) as scope:
        log_data = scope.use("logger")
        assert log_data["request_id"] == "req-override"

    await app.stop()


async def test_singleton_unchanged_across_scopes():
    """SINGLETON dao is the same instance across request scopes."""
    app = AppWithCurrentUser(components_config={"dao": {}, "current_user": {}})
    await app.start()

    dao_ref = app.dao

    async with app.request_scope({"current_user": {"sub": "user-1"}}):
        assert app.dao is dao_ref

    async with app.request_scope({"current_user": {"sub": "user-2"}}):
        assert app.dao is dao_ref

    await app.stop()
