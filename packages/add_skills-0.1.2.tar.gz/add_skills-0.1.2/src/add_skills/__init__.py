"""add-skills - A tool for managing AI agent Skills."""

__version__ = "0.0.1"
