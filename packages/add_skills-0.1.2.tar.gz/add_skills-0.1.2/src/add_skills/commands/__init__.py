"""CLI commands for add-skills."""

from add_skills.commands.add import add_skills
from add_skills.commands.find import find

__all__ = ["add_skills", "find"]
