# Additory v0.1.1a1

Data augmentation library with Polars backend.

## Installation

```bash
pip install additory
```

## Quick Start

```python
import additory
import polars as pl

# Add columns from reference DataFrame
result = additory.add.to(df, reference_df, on='id', bring='price')

# Transform columns
result = additory.add.transform(df, mode='onehotencoding', columns=['category'])

# Filter data
result = additory.add.snapshot(df, where='age > 18')

# Generate synthetic data
result = additory.add.synthetic(df, rows=1000)

# Analyze data
result = additory.add.analyze(df, preset='quick')

# Evaluate expressions
result = additory.add.expressions(df, 'inbuilt:bmi')
```

## Features

- **Blazing Fast**: Built on Polars for maximum performance
- **Simple API**: Clean, intuitive API with `additory.add.function()` pattern
- **Flexible**: Works with Polars, pandas, and cuDF
- **Comprehensive**: 6 main functions covering all data augmentation needs
- **Well Tested**: 1,023 tests with 90% coverage

## Documentation

Visit [https://additory.dev](https://additory.dev) for full documentation.

## License

MIT
