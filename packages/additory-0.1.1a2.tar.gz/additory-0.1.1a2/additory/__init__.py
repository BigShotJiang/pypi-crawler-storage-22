"""
Additory v0.1.1 - Data Augmentation Library

A Polars-first data augmentation library with 5 main functions:
- to: Add columns from other DataFrames
- transform: Transform columns (transpose, encode, extract, etc.)
- snapshot: Filter and select data
- synthetic: Generate synthetic data
- analyze: Analyze data quality and patterns
- expressions: Evaluate expressions and add computed columns

Usage:
    import additory
    
    # Add columns
    result = additory.add.to(df, reference_df, on='id', bring='price')
    
    # Transform columns
    result = additory.add.transform(df, mode='onehotencoding', columns=['category'])
    
    # Filter data
    result = additory.add.snapshot(df, where='age > 18')
    
    # Generate synthetic data
    result = additory.add.synthetic(df, rows=1000)
    
    # Analyze data
    result = additory.add.analyze(df, preset='quick')
    
    # Evaluate expressions
    result = additory.add.expressions(df, 'inbuilt:bmi', 'age * 12')
"""

from types import SimpleNamespace

# Import main functions
from additory.functions.to import to
from additory.functions.transform import transform
from additory.functions.snapshot import snapshot
from additory.functions.synthetic import synthetic
from additory.functions.analyze import analyze
from additory.functions.expressions import expressions

# Import configuration functions
from additory.core.config import set_expressions_folder, set_default_backend

# Create simple API namespace
add = SimpleNamespace(
    to=to,
    transform=transform,
    snapshot=snapshot,
    synthetic=synthetic,
    analyze=analyze,
    expressions=expressions,
    set_expressions_folder=set_expressions_folder,
    set_default_backend=set_default_backend
)

# Version
__version__ = "0.1.1a2"

# Public API
__all__ = ['add', '__version__']
