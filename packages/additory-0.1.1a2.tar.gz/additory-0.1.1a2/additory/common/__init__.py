"""
Common utilities for Additory.

This module provides shared utilities used across all functions:
- validation: Input validation
- strategy_parser: Strategy parsing
- column_selector: Column selection
- result: Result wrappers
- extractors: Feature extractors
- unit_conversions: Unit conversion utilities
- knn_imputation: KNN imputation
- distributions: Distribution generation
"""

from .validation import (
    validate_dataframe,
    validate_not_empty,
    validate_column_name,
    validate_positive_integer,
    validate_percentage,
    validate_mode,
    validate_dict,
    validate_list,
    validate_string,
    validate_boolean,
    validate_optional
)

__all__ = [
    'validate_dataframe',
    'validate_not_empty',
    'validate_column_name',
    'validate_positive_integer',
    'validate_percentage',
    'validate_mode',
    'validate_dict',
    'validate_list',
    'validate_string',
    'validate_boolean',
    'validate_optional'
]
