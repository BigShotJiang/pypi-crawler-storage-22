"""
Statistical distribution utilities for Additory.

Provides generation and analysis of statistical distributions for synthetic data.
"""

import math
from typing import Dict, Optional
import polars as pl
import numpy as np


def generate_normal(n: int, mean: float = 0, std: float = 1, seed: Optional[int] = None) -> pl.Series:
    """
    Generate values from normal distribution.
    
    Args:
        n: Number of values to generate
        mean: Mean of distribution
        std: Standard deviation
        seed: Random seed for reproducibility
        
    Returns:
        Polars Series with generated values
        
    Example:
        values = generate_normal(n=1000, mean=50, std=10)
    """
    if seed is not None:
        np.random.seed(seed)
    
    values = np.random.normal(mean, std, n)
    return pl.Series(values)


def generate_uniform(n: int, low: float, high: float, seed: Optional[int] = None) -> pl.Series:
    """
    Generate values from uniform distribution.
    
    Args:
        n: Number of values to generate
        low: Lower bound
        high: Upper bound
        seed: Random seed
        
    Returns:
        Polars Series with generated values
    """
    if seed is not None:
        np.random.seed(seed)
    
    values = np.random.uniform(low, high, n)
    return pl.Series(values)


def generate_exponential(n: int, rate: float = 1.0, seed: Optional[int] = None) -> pl.Series:
    """
    Generate values from exponential distribution.
    
    Args:
        n: Number of values to generate
        rate: Rate parameter (lambda)
        seed: Random seed
        
    Returns:
        Polars Series with generated values
    """
    if seed is not None:
        np.random.seed(seed)
    
    # numpy uses scale = 1/rate
    scale = 1.0 / rate
    values = np.random.exponential(scale, n)
    return pl.Series(values)


def generate_poisson(n: int, lambda_: float, seed: Optional[int] = None) -> pl.Series:
    """
    Generate values from Poisson distribution.
    
    Args:
        n: Number of values to generate
        lambda_: Lambda parameter (mean)
        seed: Random seed
        
    Returns:
        Polars Series with generated values
    """
    if seed is not None:
        np.random.seed(seed)
    
    values = np.random.poisson(lambda_, n)
    return pl.Series(values)


def generate_binomial(n: int, trials: int, prob: float, seed: Optional[int] = None) -> pl.Series:
    """
    Generate values from binomial distribution.
    
    Args:
        n: Number of values to generate
        trials: Number of trials
        prob: Probability of success
        seed: Random seed
        
    Returns:
        Polars Series with generated values
    """
    if seed is not None:
        np.random.seed(seed)
    
    values = np.random.binomial(trials, prob, n)
    return pl.Series(values)


def fit_distribution(series: pl.Series, dist_type: str) -> Dict:
    """
    Fit distribution to data and return parameters.
    
    Args:
        series: Data to fit
        dist_type: Distribution type ('normal', 'uniform', 'exponential', etc.)
        
    Returns:
        Dictionary with fitted parameters
        
    Example:
        params = fit_distribution(df['age'], 'normal')
        # Returns: {'mean': 35.5, 'std': 12.3, 'fit_quality': 0.95}
    """
    data = series.to_numpy()
    
    if dist_type == 'normal':
        mean = float(np.mean(data))
        std = float(np.std(data, ddof=1))
        
        # Simple fit quality based on how well data matches normal
        # Using coefficient of variation as a rough measure
        cv = std / abs(mean) if mean != 0 else float('inf')
        fit_quality = max(0.0, min(1.0, 1.0 - cv / 2.0))  # Rough approximation
        
        return {
            'mean': mean,
            'std': std,
            'fit_quality': fit_quality
        }
    
    elif dist_type == 'uniform':
        low = float(np.min(data))
        high = float(np.max(data))
        
        # Check if data is roughly uniform
        expected_mean = (low + high) / 2
        actual_mean = float(np.mean(data))
        fit_quality = max(0.0, 1.0 - abs(actual_mean - expected_mean) / (high - low))
        
        return {
            'low': low,
            'high': high,
            'fit_quality': fit_quality
        }
    
    elif dist_type == 'exponential':
        rate = 1.0 / float(np.mean(data))
        
        # Simple fit quality check
        theoretical_std = 1.0 / rate
        actual_std = float(np.std(data, ddof=1))
        fit_quality = max(0.0, 1.0 - abs(actual_std - theoretical_std) / theoretical_std)
        
        return {
            'rate': rate,
            'fit_quality': fit_quality
        }
    
    else:
        raise ValueError(f"Unsupported distribution type: {dist_type}")


def calculate_distribution_stats(series: pl.Series) -> Dict:
    """
    Calculate distribution statistics.
    
    Args:
        series: Data to analyze
        
    Returns:
        Dictionary with statistics
    """
    data = series.to_numpy()
    
    # Basic statistics
    mean = float(np.mean(data))
    median = float(np.median(data))
    std = float(np.std(data, ddof=1))
    variance = float(np.var(data, ddof=1))
    
    # Min/max/range
    min_val = float(np.min(data))
    max_val = float(np.max(data))
    range_val = max_val - min_val
    
    # Quantiles
    q25 = float(np.percentile(data, 25))
    q75 = float(np.percentile(data, 75))
    iqr = q75 - q25
    
    # Mode (most frequent value)
    unique, counts = np.unique(data, return_counts=True)
    mode_idx = np.argmax(counts)
    mode = float(unique[mode_idx])
    
    # Skewness and kurtosis (simplified calculations)
    n = len(data)
    if n > 2 and std > 0:
        # Skewness
        skewness = float(np.sum(((data - mean) / std) ** 3) / n)
        
        # Kurtosis (excess kurtosis)
        kurtosis = float(np.sum(((data - mean) / std) ** 4) / n - 3)
    else:
        skewness = 0.0
        kurtosis = 0.0
    
    return {
        'mean': mean,
        'median': median,
        'mode': mode,
        'std': std,
        'variance': variance,
        'skewness': skewness,
        'kurtosis': kurtosis,
        'min': min_val,
        'max': max_val,
        'range': range_val,
        'q25': q25,
        'q75': q75,
        'iqr': iqr
    }


def check_normality(series: pl.Series) -> Dict:
    """
    Test if data follows normal distribution.
    
    Args:
        series: Data to test
        
    Returns:
        Dictionary with test results
    """
    data = series.to_numpy()
    
    # Simple normality test based on skewness and kurtosis
    # This is a simplified version - in production, you'd use scipy.stats
    stats = calculate_distribution_stats(series)
    
    # Normal distribution has skewness ≈ 0 and kurtosis ≈ 0
    skew_test = abs(stats['skewness']) < 0.5
    kurt_test = abs(stats['kurtosis']) < 0.5
    
    is_normal = skew_test and kurt_test
    
    # Rough p-value approximation
    skew_p = max(0.001, 1.0 - abs(stats['skewness']))
    kurt_p = max(0.001, 1.0 - abs(stats['kurtosis']))
    p_value = min(skew_p, kurt_p)
    
    # Test statistic (combined skewness and kurtosis)
    test_statistic = abs(stats['skewness']) + abs(stats['kurtosis'])
    
    return {
        'is_normal': is_normal,
        'p_value': p_value,
        'test_statistic': test_statistic,
        'test_name': 'Simplified Normality Test'
    }


def generate_correlated(series: pl.Series, n: int, correlation: float, 
                       seed: Optional[int] = None) -> pl.Series:
    """
    Generate values correlated with existing series.
    
    Args:
        series: Series to correlate with
        n: Number of values to generate
        correlation: Desired correlation (-1 to 1)
        seed: Random seed
        
    Returns:
        Polars Series with correlated values
        
    Example:
        # Generate income correlated with age (correlation = 0.75)
        income = generate_correlated(df['age'], n=1000, correlation=0.75)
    """
    if seed is not None:
        np.random.seed(seed)
    
    # Get original data
    x = series.to_numpy()
    
    # If we need more values than available, repeat the series
    if n > len(x):
        repeats = (n // len(x)) + 1
        x = np.tile(x, repeats)[:n]
    else:
        x = x[:n]
    
    # Standardize x
    x_mean = np.mean(x)
    x_std = np.std(x)
    if x_std == 0:
        x_std = 1.0  # Avoid division by zero
    x_standardized = (x - x_mean) / x_std
    
    # Generate independent random variable
    z = np.random.normal(0, 1, n)
    
    # Create correlated variable using Cholesky-like approach
    # y = correlation * x + sqrt(1 - correlation^2) * z
    y = correlation * x_standardized + math.sqrt(1 - correlation**2) * z
    
    # Scale y to have similar range as x
    y = y * x_std + x_mean
    
    return pl.Series(y)


def add_noise(series: pl.Series, noise_level: float, seed: Optional[int] = None) -> pl.Series:
    """
    Add random noise to series.
    
    Args:
        series: Series to add noise to
        noise_level: Noise level (0 to 1, as fraction of std)
        seed: Random seed
        
    Returns:
        Series with added noise
    """
    if seed is not None:
        np.random.seed(seed)
    
    data = series.to_numpy()
    std = np.std(data)
    
    # If std is zero (constant data), use a small default noise level
    if std == 0:
        std = 1.0  # Use unit noise for constant data
    
    # Generate noise
    noise = np.random.normal(0, std * noise_level, len(data))
    
    # Add noise to original data
    noisy_data = data + noise
    
    return pl.Series(noisy_data)


def generate_seasonal(n: int, period: int, amplitude: float = 1.0, 
                     trend: str = 'none', noise: float = 0.0, 
                     seed: Optional[int] = None) -> pl.Series:
    """
    Generate seasonal time series data.
    
    Args:
        n: Number of values to generate
        period: Seasonal period (e.g., 7 for weekly, 365 for yearly)
        amplitude: Amplitude of seasonal component
        trend: Trend type ('none', 'increasing', 'decreasing')
        noise: Noise level
        seed: Random seed
        
    Returns:
        Series with seasonal pattern
        
    Example:
        # Generate weekly seasonal sales data
        sales = generate_seasonal(n=365, period=7, amplitude=100, 
                                trend='increasing', noise=0.1)
    """
    if seed is not None:
        np.random.seed(seed)
    
    # Time index
    t = np.arange(n)
    
    # Seasonal component (sine wave)
    seasonal = amplitude * np.sin(2 * np.pi * t / period)
    
    # Trend component
    if trend == 'increasing':
        trend_component = t * (amplitude / n)
    elif trend == 'decreasing':
        trend_component = -t * (amplitude / n)
    else:  # 'none'
        trend_component = np.zeros(n)
    
    # Noise component
    if noise > 0:
        noise_component = np.random.normal(0, amplitude * noise, n)
    else:
        noise_component = np.zeros(n)
    
    # Combine components
    values = seasonal + trend_component + noise_component
    
    return pl.Series(values)