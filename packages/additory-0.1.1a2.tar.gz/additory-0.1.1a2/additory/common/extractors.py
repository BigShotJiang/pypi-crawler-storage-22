"""
Feature extraction utilities for Additory.

Provides functions to extract features from various column types
(datetime, email, text, URL, phone, etc.).
"""

import re
from typing import Dict, List, Optional
import polars as pl


def extract_datetime_features(series: pl.Series, features: List[str]) -> Dict[str, pl.Series]:
    """
    Extract datetime features from a datetime column.
    
    Args:
        series: Polars Series with datetime values
        features: List of features to extract
        
    Returns:
        Dictionary mapping feature name to Series
        
    Supported Features:
        - 'year', 'month', 'day', 'hour', 'minute', 'second'
        - 'day_of_week', 'day_of_year', 'week', 'quarter'
        - 'time_of_day' ('morning', 'afternoon', 'evening', 'night')
        - 'is_weekend', 'is_business_day'
        
    Example:
        features = extract_datetime_features(df['timestamp'], ['hour', 'day_of_week'])
    """
    result = {}
    
    for feature in features:
        if feature == 'year':
            result[feature] = series.dt.year()
        elif feature == 'month':
            result[feature] = series.dt.month()
        elif feature == 'day':
            result[feature] = series.dt.day()
        elif feature == 'hour':
            result[feature] = series.dt.hour()
        elif feature == 'minute':
            result[feature] = series.dt.minute()
        elif feature == 'second':
            result[feature] = series.dt.second()
        elif feature == 'day_of_week':
            result[feature] = series.dt.weekday()
        elif feature == 'day_of_year':
            result[feature] = series.dt.ordinal_day()
        elif feature == 'week':
            result[feature] = series.dt.week()
        elif feature == 'quarter':
            result[feature] = series.dt.quarter()
        elif feature == 'time_of_day':
            hour = series.dt.hour()
            time_of_day = pl.when(hour < 6).then(pl.lit('night')) \
                           .when(hour < 12).then(pl.lit('morning')) \
                           .when(hour < 18).then(pl.lit('afternoon')) \
                           .otherwise(pl.lit('evening'))
            # Evaluate the expression to get a Series
            result[feature] = pl.select(time_of_day.alias('time_of_day')).to_series()
        elif feature == 'is_weekend':
            weekday = series.dt.weekday()
            result[feature] = (weekday >= 6)
        elif feature == 'is_business_day':
            weekday = series.dt.weekday()
            result[feature] = (weekday < 5)
        else:
            raise ValueError(f"Unsupported datetime feature: {feature}")
    
    return result


def extract_email_features(series: pl.Series, features: List[str]) -> Dict[str, pl.Series]:
    """
    Extract features from email addresses.
    
    Args:
        series: Polars Series with email strings
        features: List of features to extract
        
    Returns:
        Dictionary mapping feature name to Series
        
    Supported Features:
        - 'domain' - Email domain (e.g., 'gmail.com')
        - 'username' - Username part (before @)
        - 'tld' - Top-level domain (e.g., 'com')
        - 'is_free_email' - Boolean (gmail, yahoo, etc.)
        - 'is_corporate' - Boolean (not free email)
        
    Example:
        features = extract_email_features(df['email'], ['domain', 'is_free_email'])
    """
    result = {}
    
    # Common free email providers
    free_providers = {'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 
                     'aol.com', 'icloud.com', 'mail.com', 'protonmail.com'}
    
    for feature in features:
        if feature == 'domain':
            # Extract domain (part after @)
            result[feature] = series.str.extract(r'@(.+)$', 1)
        elif feature == 'username':
            # Extract username (part before @)
            result[feature] = series.str.extract(r'^([^@]+)@', 1)
        elif feature == 'tld':
            # Extract top-level domain (last part after .)
            result[feature] = series.str.extract(r'\.([^.]+)$', 1)
        elif feature == 'is_free_email':
            # Check if domain is in free providers list
            domain = series.str.extract(r'@(.+)$', 1)
            result[feature] = domain.is_in(list(free_providers))
        elif feature == 'is_corporate':
            # Opposite of is_free_email
            domain = series.str.extract(r'@(.+)$', 1)
            result[feature] = ~domain.is_in(list(free_providers))
        else:
            raise ValueError(f"Unsupported email feature: {feature}")
    
    return result


def extract_text_features(series: pl.Series, features: List[str]) -> Dict[str, pl.Series]:
    """
    Extract features from text columns.
    
    Args:
        series: Polars Series with text strings
        features: List of features to extract
        
    Returns:
        Dictionary mapping feature name to Series
        
    Supported Features:
        - 'length' - Character count
        - 'word_count' - Number of words
        - 'sentence_count' - Number of sentences
        - 'has_numbers' - Boolean
        - 'has_special_chars' - Boolean
        - 'is_uppercase' - Boolean
        - 'is_lowercase' - Boolean
        
    Example:
        features = extract_text_features(df['description'], ['length', 'word_count'])
    """
    result = {}
    
    for feature in features:
        if feature == 'length':
            result[feature] = series.str.len_chars()
        elif feature == 'word_count':
            # Count words (split by whitespace)
            result[feature] = series.str.split(' ').list.len()
        elif feature == 'sentence_count':
            # Count sentences (split by . ! ?)
            result[feature] = series.str.count_matches(r'[.!?]')
        elif feature == 'has_numbers':
            result[feature] = series.str.contains(r'\d')
        elif feature == 'has_special_chars':
            result[feature] = series.str.contains(r'[^a-zA-Z0-9\s]')
        elif feature == 'is_uppercase':
            result[feature] = series.str.to_uppercase() == series
        elif feature == 'is_lowercase':
            result[feature] = series.str.to_lowercase() == series
        else:
            raise ValueError(f"Unsupported text feature: {feature}")
    
    return result


def split_column(series: pl.Series, delimiter: str, max_splits: Optional[int] = None) -> List[pl.Series]:
    """
    Split column by delimiter into multiple columns.
    
    Args:
        series: Polars Series to split
        delimiter: Delimiter string
        max_splits: Maximum number of splits (None = unlimited)
        
    Returns:
        List of Series (one per split part)
        
    Example:
        # Split 'red,green,blue' into 3 columns
        parts = split_column(df['tags'], delimiter=',', max_splits=3)
    """
    # Split the series
    split_series = series.str.split(delimiter)
    
    # Determine number of parts
    if max_splits is None:
        # Find maximum number of parts
        max_len = split_series.list.len().max()
        if max_len is None:
            # Empty series
            return []
        max_parts = int(max_len)
    else:
        max_parts = max_splits
    
    # Extract each part as a separate series
    result = []
    for i in range(max_parts):
        try:
            part = split_series.list.get(i, null_on_oob=True)
            result.append(part)
        except Exception:
            # If index is out of bounds, append None series
            result.append(pl.Series([None] * len(series)))
    
    return result


def extract_url_features(series: pl.Series, features: List[str]) -> Dict[str, pl.Series]:
    """
    Extract features from URLs.
    
    Args:
        series: Polars Series with URL strings
        features: List of features to extract
        
    Returns:
        Dictionary mapping feature name to Series
        
    Supported Features:
        - 'protocol' - http, https, ftp, etc.
        - 'domain' - Domain name
        - 'path' - URL path
        - 'is_secure' - Boolean (https)
        
    Example:
        features = extract_url_features(df['url'], ['protocol', 'domain'])
    """
    result = {}
    
    for feature in features:
        if feature == 'protocol':
            # Extract protocol (e.g., http, https)
            result[feature] = series.str.extract(r'^([a-z]+)://', 1)
        elif feature == 'domain':
            # Extract domain (between :// and /)
            result[feature] = series.str.extract(r'://([^/]+)', 1)
        elif feature == 'path':
            # Extract path (after domain)
            result[feature] = series.str.extract(r'://[^/]+(/[^?#]*)', 1)
        elif feature == 'is_secure':
            # Check if protocol is https
            protocol = series.str.extract(r'^([a-z]+)://', 1)
            result[feature] = (protocol == 'https')
        else:
            raise ValueError(f"Unsupported URL feature: {feature}")
    
    return result


def extract_phone_features(series: pl.Series, features: List[str]) -> Dict[str, pl.Series]:
    """
    Extract features from phone numbers.
    
    Args:
        series: Polars Series with phone number strings
        features: List of features to extract
        
    Returns:
        Dictionary mapping feature name to Series
        
    Supported Features:
        - 'country_code' - Country code
        - 'area_code' - Area code
        - 'is_valid' - Boolean (basic validation)
        
    Example:
        features = extract_phone_features(df['phone'], ['country_code', 'area_code'])
    """
    result = {}
    
    for feature in features:
        if feature == 'country_code':
            # Extract country code (e.g., +1, +44)
            result[feature] = series.str.extract(r'^\+?(\d{1,3})', 1)
        elif feature == 'area_code':
            # Extract area code (3 digits after country code)
            result[feature] = series.str.extract(r'\(?(\d{3})\)?', 1)
        elif feature == 'is_valid':
            # Basic validation: has at least 10 digits
            digits_only = series.str.replace_all(r'\D', '')
            result[feature] = digits_only.str.len_chars() >= 10
        else:
            raise ValueError(f"Unsupported phone feature: {feature}")
    
    return result


def parse_pattern(series: pl.Series, pattern: str) -> pl.Series:
    """
    Extract pattern from strings using regex.
    
    Args:
        series: Polars Series with strings
        pattern: Regex pattern to extract
        
    Returns:
        Series with extracted values
        
    Example:
        # Extract numbers from strings
        numbers = parse_pattern(df['text'], r'\\d+')
    """
    return series.str.extract(pattern, 0)
