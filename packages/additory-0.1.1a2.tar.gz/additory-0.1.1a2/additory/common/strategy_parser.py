"""
Strategy parsing and validation utilities for Additory.

Provides functions to parse and validate strategy dictionaries
used across multiple functions (to, transform, synthetic).
"""

from typing import Any, Dict, List, Tuple
import polars as pl


def parse_strategy(strategy: Dict, context: str) -> Dict:
    """
    Parse and validate strategy dictionary for a given context.
    
    Args:
        strategy: Dictionary containing strategy configuration
        context: Context string ('to', 'transform', 'synthetic')
        
    Returns:
        Validated and normalized strategy dictionary
        
    Example:
        strategy = {'price': {'mode': 'first', 'position': 'after:id'}}
        parsed = parse_strategy(strategy, context='to')
    """
    # Define allowed keys for each context
    allowed_keys_by_context = {
        'to': ['mode', 'position', 'default', 'deduce'],
        'transform': ['mode', 'from_unit', 'to_unit', 'features', 'deduce'],
        'synthetic': ['mode', 'distribution', 'min', 'max', 'mean', 'std', 
                     'categories', 'deduce', 'correlation']
    }
    
    if context not in allowed_keys_by_context:
        raise ValueError(f"Invalid context: {context}. Must be one of: {list(allowed_keys_by_context.keys())}")
    
    allowed_keys = allowed_keys_by_context[context]
    
    # Validate and normalize each column strategy
    parsed = {}
    for column, column_strategy in strategy.items():
        if isinstance(column_strategy, dict):
            # Validate keys
            validate_strategy_keys(column_strategy, allowed_keys)
            
            # Normalize values
            normalized = {}
            for key, value in column_strategy.items():
                normalized[key] = normalize_strategy_value(value, key)
            
            parsed[column] = normalized
        else:
            # Simple value (e.g., 'deduce:expression')
            parsed[column] = normalize_strategy_value(column_strategy, 'simple')
    
    return parsed


def validate_strategy_keys(strategy: Dict, allowed_keys: List[str]) -> bool:
    """
    Validate that strategy contains only allowed keys.
    
    Args:
        strategy: Strategy dictionary to validate
        allowed_keys: List of allowed keys for this context
        
    Returns:
        True if valid
        
    Raises:
        ValueError: If strategy contains invalid keys
    """
    invalid_keys = set(strategy.keys()) - set(allowed_keys)
    
    if invalid_keys:
        raise ValueError(
            f"Invalid strategy keys: {invalid_keys}. "
            f"Allowed keys: {allowed_keys}"
        )
    
    return True


def normalize_strategy_value(value: Any, value_type: str) -> Any:
    """
    Normalize strategy value to expected type.
    
    Args:
        value: Value to normalize
        value_type: Expected type ('mode', 'position', 'expression', etc.)
        
    Returns:
        Normalized value
    """
    if value_type == 'mode':
        # Mode should be a string
        if not isinstance(value, str):
            raise ValueError(f"Mode must be a string, got {type(value)}")
        return value.lower()
    
    elif value_type == 'position':
        # Position should be a string (e.g., 'after:id', 'before:name')
        if not isinstance(value, str):
            raise ValueError(f"Position must be a string, got {type(value)}")
        return value.lower()
    
    elif value_type == 'deduce':
        # Deduce should be a string (expression or reference)
        if not isinstance(value, str):
            raise ValueError(f"Deduce must be a string, got {type(value)}")
        return value
    
    elif value_type == 'distribution':
        # Distribution should be a string
        if not isinstance(value, str):
            raise ValueError(f"Distribution must be a string, got {type(value)}")
        return value.lower()
    
    elif value_type in ['min', 'max', 'mean', 'std', 'correlation']:
        # Numeric values
        if not isinstance(value, (int, float)):
            raise ValueError(f"{value_type} must be numeric, got {type(value)}")
        return float(value)
    
    elif value_type == 'categories':
        # Categories should be a list
        if not isinstance(value, list):
            raise ValueError(f"Categories must be a list, got {type(value)}")
        return value
    
    elif value_type == 'features':
        # Features should be a list
        if not isinstance(value, list):
            raise ValueError(f"Features must be a list, got {type(value)}")
        return value
    
    elif value_type in ['from_unit', 'to_unit']:
        # Units should be strings
        if not isinstance(value, str):
            raise ValueError(f"{value_type} must be a string, got {type(value)}")
        return value.lower()
    
    elif value_type == 'default':
        # Default can be any type
        return value
    
    elif value_type == 'simple':
        # Simple value (not in a dict)
        return value
    
    else:
        # Unknown type, return as-is
        return value


def parse_deduce_strategy(strategy_value: str, df: pl.DataFrame) -> pl.Series:
    """
    Parse 'deduce:' strategy (inline expression or reference).
    
    Args:
        strategy_value: Strategy string starting with 'deduce:'
        df: DataFrame for expression evaluation
        
    Returns:
        Polars Series with computed values
        
    Example:
        # Inline expression
        result = parse_deduce_strategy('deduce:weight / (height ** 2)', df)
        
        # Reference expression
        result = parse_deduce_strategy('deduce:inbuilt:bmi', df)
    """
    if not strategy_value.startswith('deduce:'):
        raise ValueError(f"Strategy value must start with 'deduce:', got: {strategy_value}")
    
    # Remove 'deduce:' prefix
    expression_part = strategy_value[7:]  # len('deduce:') = 7
    
    # Check if it's a reference (contains ':')
    if ':' in expression_part:
        # It's a reference like 'inbuilt:bmi' or 'myfolder:roi'
        namespace, expr_name = extract_namespace_from_reference(expression_part)
        
        # For now, we'll return a placeholder since expressions.engine is not yet implemented
        # This will be replaced when expressions.engine is available
        raise NotImplementedError(
            f"Expression references not yet implemented. "
            f"Namespace: {namespace}, Expression: {expr_name}"
        )
    else:
        # It's an inline expression like 'weight / (height ** 2)'
        # For now, we'll try to evaluate it directly using Polars
        try:
            # Try to evaluate as a simple Polars expression
            # This is a simplified version - full implementation will use expressions.engine
            result = df.select(pl.lit(expression_part).alias('result'))['result']
            return result
        except Exception as e:
            raise ValueError(
                f"Failed to evaluate inline expression: {expression_part}. "
                f"Error: {str(e)}"
            )


def extract_namespace_from_reference(reference: str) -> Tuple[str, str]:
    """
    Extract namespace and expression name from reference.
    
    Args:
        reference: Reference string like 'inbuilt:bmi' or 'myfolder:roi'
        
    Returns:
        Tuple of (namespace, expression_name)
        
    Example:
        namespace, expr_name = extract_namespace_from_reference('inbuilt:bmi')
        # Returns: ('inbuilt', 'bmi')
    """
    if ':' not in reference:
        raise ValueError(
            f"Invalid reference format: {reference}. "
            f"Expected format: 'namespace:expression_name'"
        )
    
    parts = reference.split(':', 1)
    if len(parts) != 2:
        raise ValueError(
            f"Invalid reference format: {reference}. "
            f"Expected format: 'namespace:expression_name'"
        )
    
    namespace = parts[0].strip()
    expr_name = parts[1].strip()
    
    if not namespace or not expr_name:
        raise ValueError(
            f"Invalid reference format: {reference}. "
            f"Both namespace and expression name must be non-empty"
        )
    
    return namespace, expr_name
