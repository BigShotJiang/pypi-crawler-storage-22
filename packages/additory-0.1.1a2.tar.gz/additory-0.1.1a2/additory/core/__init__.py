"""
Core infrastructure for Additory.

This module provides essential infrastructure components:
- logging: Transparent logging system
- memory_manager: Memory cleanup utilities
- backend: Backend detection and conversion
- config: Global configuration settings
"""

from .logging import Logger, get_logger, set_log_level
from .memory_manager import (
    MemoryManager,
    get_memory_manager,
    cleanup_after_operation,
    estimate_memory_usage
)
from .config import (
    Config,
    get_config,
    set_expressions_folder,
    set_default_backend,
    derive_namespace_from_path
)

__all__ = [
    'Logger',
    'get_logger',
    'set_log_level',
    'MemoryManager',
    'get_memory_manager',
    'cleanup_after_operation',
    'estimate_memory_usage',
    'Config',
    'get_config',
    'set_expressions_folder',
    'set_default_backend',
    'derive_namespace_from_path'
]
