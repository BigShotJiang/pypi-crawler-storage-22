"""
Memory management for Additory operations.

Provides automatic cleanup of intermediate objects to free memory:
- Tracks temporary DataFrames
- Cleans up after operations
- Can be enabled/disabled for debugging
"""

import gc
import sys
from typing import Any, Callable, List, Optional, Tuple
from functools import wraps


class MemoryManager:
    """
    Manages memory cleanup after operations.
    
    Tracks intermediate objects created during processing and
    cleans them up automatically to free memory.
    """
    
    def __init__(self):
        """Initialize memory manager."""
        self.tracked_objects: List[Tuple[Any, Optional[str]]] = []
        self.cleanup_enabled: bool = True
    
    def track(self, obj: Any, name: Optional[str] = None) -> None:
        """
        Track object for cleanup.
        
        Args:
            obj: Object to track (typically DataFrame or Series)
            name: Optional name for debugging
            
        Example:
            memory_manager.track(temp_df, 'intermediate_result')
        """
        if self.cleanup_enabled:
            self.tracked_objects.append((obj, name))
    
    def cleanup(self) -> None:
        """
        Clean up all tracked objects.
        
        Deletes references to tracked objects and runs garbage collection.
        Called automatically at the end of every operation.
        
        Example:
            try:
                result = process_data(df)
                return result
            finally:
                memory_manager.cleanup()
        """
        if not self.cleanup_enabled:
            return
        
        # Count objects before cleanup
        count = len(self.tracked_objects)
        
        if count > 0:
            # Estimate memory before cleanup (optional, for logging)
            total_memory = 0
            for obj, name in self.tracked_objects:
                try:
                    memory = estimate_memory_usage(obj)
                    total_memory += memory
                except:
                    pass  # Ignore errors in memory estimation
            
            # Clear references
            self.tracked_objects.clear()
            
            # Force garbage collection
            gc.collect()
            
            # Log cleanup (if logger is available)
            try:
                from .logging import get_logger
                logger = get_logger()
                if total_memory > 0:
                    memory_mb = total_memory / (1024 * 1024)
                    logger.info(
                        f"Cleaned up {count} intermediate objects (~{memory_mb:.2f} MB)"
                    )
            except:
                pass  # Ignore if logger not available
    
    def enable(self) -> None:
        """
        Enable automatic cleanup.
        
        Called by user code via add.enable_memory_cleanup()
        """
        self.cleanup_enabled = True
    
    def disable(self) -> None:
        """
        Disable automatic cleanup.
        
        Useful for debugging to inspect intermediate objects.
        Called by user code via add.disable_memory_cleanup()
        """
        self.cleanup_enabled = False
    
    def get_tracked_count(self) -> int:
        """
        Get number of tracked objects.
        
        Returns:
            Number of tracked objects
            
        Used for testing and debugging.
        """
        return len(self.tracked_objects)
    
    def clear_tracking(self) -> None:
        """
        Clear tracking list without cleanup.
        
        Called after successful cleanup or when resetting state.
        """
        self.tracked_objects.clear()


# Global memory manager instance
_global_memory_manager: Optional[MemoryManager] = None


def get_memory_manager() -> MemoryManager:
    """
    Get the global memory manager instance.
    
    Returns:
        Global MemoryManager instance
        
    Example:
        memory_manager = get_memory_manager()
        memory_manager.track(temp_df)
    """
    global _global_memory_manager
    if _global_memory_manager is None:
        _global_memory_manager = MemoryManager()
    return _global_memory_manager


def cleanup_after_operation(func: Callable) -> Callable:
    """
    Decorator to ensure cleanup after operation.
    
    Wraps a function to automatically clean up tracked objects
    after execution, even if an exception occurs.
    
    Args:
        func: Function to wrap
        
    Returns:
        Wrapped function with automatic cleanup
        
    Example:
        @cleanup_after_operation
        def to(df, ...):
            # Function implementation
            pass
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        memory_manager = get_memory_manager()
        try:
            result = func(*args, **kwargs)
            return result
        finally:
            memory_manager.cleanup()
    
    return wrapper


def estimate_memory_usage(obj: Any) -> int:
    """
    Estimate memory usage of an object.
    
    Args:
        obj: Object to estimate (typically DataFrame or Series)
        
    Returns:
        Estimated memory usage in bytes
        
    Note:
        This is an approximation. Actual memory usage may vary.
    """
    try:
        # Try to get memory usage from object (Polars/pandas)
        if hasattr(obj, 'estimated_size'):
            # Polars DataFrame
            return obj.estimated_size()
        elif hasattr(obj, 'memory_usage'):
            # pandas DataFrame or Series
            memory_usage = obj.memory_usage(deep=True)
            if hasattr(memory_usage, 'sum'):
                return int(memory_usage.sum())
            return int(memory_usage)
        else:
            # Fallback to sys.getsizeof
            return sys.getsizeof(obj)
    except:
        # If all else fails, return 0
        return 0
