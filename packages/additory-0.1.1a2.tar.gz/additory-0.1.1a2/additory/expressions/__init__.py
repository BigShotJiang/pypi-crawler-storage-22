"""
Expression engine for Additory.

Provides expression parsing, compilation, and evaluation.
"""
