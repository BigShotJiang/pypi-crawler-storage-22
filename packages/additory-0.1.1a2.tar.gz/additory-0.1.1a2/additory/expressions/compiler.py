"""
Expression compiler for Additory.

Compiles Abstract Syntax Trees (AST) into Polars expressions.
"""

import polars as pl
from typing import List
from additory.expressions.parser import ASTNode


class ExpressionCompiler:
    """
    Compile AST nodes to Polars expressions.
    
    Supports:
    - Arithmetic operators: +, -, *, /, **, %
    - Comparison operators: ==, !=, >, <, >=, <=
    - Logical operators: AND, OR, NOT
    - Functions: sqrt, abs, log, if_else, etc.
    """
    
    def compile(self, ast: ASTNode, df: pl.DataFrame) -> pl.Expr:
        """
        Compile AST to Polars expression.
        
        Args:
            ast: Root AST node
            df: DataFrame (for column validation)
            
        Returns:
            Polars expression
            
        Example:
            compiler = ExpressionCompiler()
            expr = compiler.compile(ast, df)
            result = df.select(expr)
        """
        return self.compile_node(ast, df)
    
    def compile_node(self, node: ASTNode, df: pl.DataFrame) -> pl.Expr:
        """
        Compile a single AST node.
        
        Args:
            node: AST node to compile
            df: DataFrame
            
        Returns:
            Polars expression
        """
        if node.type == 'literal':
            return self.compile_literal(node)
        elif node.type == 'identifier':
            return self.compile_identifier(node, df)
        elif node.type == 'binary_op':
            return self.compile_binary_op(node, df)
        elif node.type == 'unary_op':
            return self.compile_unary_op(node, df)
        elif node.type == 'function':
            return self.compile_function(node, df)
        else:
            raise ValueError(f"Unknown node type: {node.type}")
    
    def compile_literal(self, node: ASTNode) -> pl.Expr:
        """
        Compile literal value node.
        
        Args:
            node: Literal node
            
        Returns:
            Polars expression
        """
        return pl.lit(node.value)
    
    def compile_identifier(self, node: ASTNode, df: pl.DataFrame) -> pl.Expr:
        """
        Compile column reference node.
        
        Args:
            node: Identifier node
            df: DataFrame
            
        Returns:
            Polars expression
        """
        column_name = node.value
        
        # Validate column exists
        if column_name not in df.columns:
            raise ValueError(f"Column '{column_name}' not found in DataFrame")
        
        return pl.col(column_name)
    
    def compile_binary_op(self, node: ASTNode, df: pl.DataFrame) -> pl.Expr:
        """
        Compile binary operator node.
        
        Args:
            node: Binary operator node
            df: DataFrame
            
        Returns:
            Polars expression
        """
        # Compile left and right operands
        left = self.compile_node(node.left, df)
        right = self.compile_node(node.right, df)
        
        # Apply operator
        operator = node.value
        
        if operator == '+':
            return left + right
        elif operator == '-':
            return left - right
        elif operator == '*':
            return left * right
        elif operator == '/':
            return left / right
        elif operator == '**':
            return left ** right
        elif operator == '%':
            return left % right
        elif operator == '==':
            return left == right
        elif operator == '!=':
            return left != right
        elif operator == '>':
            return left > right
        elif operator == '<':
            return left < right
        elif operator == '>=':
            return left >= right
        elif operator == '<=':
            return left <= right
        elif operator == 'AND':
            return left & right
        elif operator == 'OR':
            return left | right
        else:
            raise ValueError(f"Unknown binary operator: {operator}")
    
    def compile_unary_op(self, node: ASTNode, df: pl.DataFrame) -> pl.Expr:
        """
        Compile unary operator node.
        
        Args:
            node: Unary operator node
            df: DataFrame
            
        Returns:
            Polars expression
        """
        # Compile operand
        operand = self.compile_node(node.right, df)
        
        # Apply operator
        operator = node.value
        
        if operator == '-':
            return -operand
        elif operator == 'NOT':
            return ~operand
        else:
            raise ValueError(f"Unknown unary operator: {operator}")
    
    def compile_function(self, node: ASTNode, df: pl.DataFrame) -> pl.Expr:
        """
        Compile function call node.
        
        Args:
            node: Function node
            df: DataFrame
            
        Returns:
            Polars expression
        """
        func_name = node.value
        
        # Compile arguments
        args = [self.compile_node(arg, df) for arg in (node.children or [])]
        
        # Dispatch to specific function compiler
        if func_name in ['sqrt', 'abs', 'log', 'log10', 'exp', 'pow', 'round', 'floor', 'ceil']:
            return self.compile_math_function(func_name, args)
        elif func_name in ['lower', 'upper', 'trim', 'length', 'substring', 'replace', 'contains', 'matches']:
            return self.compile_string_function(func_name, args)
        elif func_name in ['year', 'month', 'day', 'hour', 'minute', 'second', 'day_of_week', 'time_of_day']:
            return self.compile_datetime_function(func_name, args)
        elif func_name in ['sum', 'mean', 'median', 'min', 'max', 'count', 'std']:
            return self.compile_aggregation_function(func_name, args)
        elif func_name in ['if_else', 'coalesce', 'is_null', 'is_not_null']:
            return self.compile_conditional_function(func_name, args)
        else:
            raise ValueError(f"Unknown function: {func_name}")
    
    def compile_math_function(self, name: str, args: List[pl.Expr]) -> pl.Expr:
        """
        Compile mathematical function.
        
        Args:
            name: Function name
            args: Compiled arguments
            
        Returns:
            Polars expression
        """
        if name == 'sqrt':
            if len(args) != 1:
                raise ValueError(f"Function 'sqrt' expects 1 argument, got {len(args)}")
            return args[0].sqrt()
        
        elif name == 'abs':
            if len(args) != 1:
                raise ValueError(f"Function 'abs' expects 1 argument, got {len(args)}")
            return args[0].abs()
        
        elif name == 'log':
            if len(args) != 1:
                raise ValueError(f"Function 'log' expects 1 argument, got {len(args)}")
            return args[0].log()
        
        elif name == 'log10':
            if len(args) != 1:
                raise ValueError(f"Function 'log10' expects 1 argument, got {len(args)}")
            return args[0].log10()
        
        elif name == 'exp':
            if len(args) != 1:
                raise ValueError(f"Function 'exp' expects 1 argument, got {len(args)}")
            return args[0].exp()
        
        elif name == 'pow':
            if len(args) != 2:
                raise ValueError(f"Function 'pow' expects 2 arguments, got {len(args)}")
            return args[0].pow(args[1])
        
        elif name == 'round':
            if len(args) not in (1, 2):
                raise ValueError(f"Function 'round' expects 1 or 2 arguments, got {len(args)}")
            decimals = args[1] if len(args) == 2 else pl.lit(0)
            return args[0].round(decimals)
        
        elif name == 'floor':
            if len(args) != 1:
                raise ValueError(f"Function 'floor' expects 1 argument, got {len(args)}")
            return args[0].floor()
        
        elif name == 'ceil':
            if len(args) != 1:
                raise ValueError(f"Function 'ceil' expects 1 argument, got {len(args)}")
            return args[0].ceil()
        
        else:
            raise ValueError(f"Unknown math function: {name}")
    
    def compile_string_function(self, name: str, args: List[pl.Expr]) -> pl.Expr:
        """
        Compile string function.
        
        Args:
            name: Function name
            args: Compiled arguments
            
        Returns:
            Polars expression
        """
        if name == 'lower':
            if len(args) != 1:
                raise ValueError(f"Function 'lower' expects 1 argument, got {len(args)}")
            return args[0].str.to_lowercase()
        
        elif name == 'upper':
            if len(args) != 1:
                raise ValueError(f"Function 'upper' expects 1 argument, got {len(args)}")
            return args[0].str.to_uppercase()
        
        elif name == 'trim':
            if len(args) != 1:
                raise ValueError(f"Function 'trim' expects 1 argument, got {len(args)}")
            return args[0].str.strip_chars()
        
        elif name == 'length':
            if len(args) != 1:
                raise ValueError(f"Function 'length' expects 1 argument, got {len(args)}")
            return args[0].str.len_chars()
        
        elif name == 'substring':
            if len(args) != 3:
                raise ValueError(f"Function 'substring' expects 3 arguments, got {len(args)}")
            return args[0].str.slice(args[1], args[2])
        
        elif name == 'replace':
            if len(args) != 3:
                raise ValueError(f"Function 'replace' expects 3 arguments, got {len(args)}")
            return args[0].str.replace(args[1], args[2])
        
        elif name == 'contains':
            if len(args) != 2:
                raise ValueError(f"Function 'contains' expects 2 arguments, got {len(args)}")
            return args[0].str.contains(args[1])
        
        elif name == 'matches':
            if len(args) != 2:
                raise ValueError(f"Function 'matches' expects 2 arguments, got {len(args)}")
            return args[0].str.contains(args[1])
        
        else:
            raise ValueError(f"Unknown string function: {name}")
    
    def compile_datetime_function(self, name: str, args: List[pl.Expr]) -> pl.Expr:
        """
        Compile datetime function.
        
        Args:
            name: Function name
            args: Compiled arguments
            
        Returns:
            Polars expression
        """
        if name == 'year':
            if len(args) != 1:
                raise ValueError(f"Function 'year' expects 1 argument, got {len(args)}")
            return args[0].dt.year()
        
        elif name == 'month':
            if len(args) != 1:
                raise ValueError(f"Function 'month' expects 1 argument, got {len(args)}")
            return args[0].dt.month()
        
        elif name == 'day':
            if len(args) != 1:
                raise ValueError(f"Function 'day' expects 1 argument, got {len(args)}")
            return args[0].dt.day()
        
        elif name == 'hour':
            if len(args) != 1:
                raise ValueError(f"Function 'hour' expects 1 argument, got {len(args)}")
            return args[0].dt.hour()
        
        elif name == 'minute':
            if len(args) != 1:
                raise ValueError(f"Function 'minute' expects 1 argument, got {len(args)}")
            return args[0].dt.minute()
        
        elif name == 'second':
            if len(args) != 1:
                raise ValueError(f"Function 'second' expects 1 argument, got {len(args)}")
            return args[0].dt.second()
        
        elif name == 'day_of_week':
            if len(args) != 1:
                raise ValueError(f"Function 'day_of_week' expects 1 argument, got {len(args)}")
            return args[0].dt.weekday()
        
        elif name == 'time_of_day':
            if len(args) != 1:
                raise ValueError(f"Function 'time_of_day' expects 1 argument, got {len(args)}")
            # Custom time_of_day: morning (6-12), afternoon (12-18), evening (18-22), night (22-6)
            hour = args[0].dt.hour()
            return (
                pl.when((hour >= 6) & (hour < 12)).then(pl.lit('morning'))
                .when((hour >= 12) & (hour < 18)).then(pl.lit('afternoon'))
                .when((hour >= 18) & (hour < 22)).then(pl.lit('evening'))
                .otherwise(pl.lit('night'))
            )
        
        else:
            raise ValueError(f"Unknown datetime function: {name}")
    
    def compile_aggregation_function(self, name: str, args: List[pl.Expr]) -> pl.Expr:
        """
        Compile aggregation function.
        
        Args:
            name: Function name
            args: Compiled arguments
            
        Returns:
            Polars expression
        """
        if name == 'sum':
            if len(args) != 1:
                raise ValueError(f"Function 'sum' expects 1 argument, got {len(args)}")
            return args[0].sum()
        
        elif name == 'mean':
            if len(args) != 1:
                raise ValueError(f"Function 'mean' expects 1 argument, got {len(args)}")
            return args[0].mean()
        
        elif name == 'median':
            if len(args) != 1:
                raise ValueError(f"Function 'median' expects 1 argument, got {len(args)}")
            return args[0].median()
        
        elif name == 'min':
            if len(args) != 1:
                raise ValueError(f"Function 'min' expects 1 argument, got {len(args)}")
            return args[0].min()
        
        elif name == 'max':
            if len(args) != 1:
                raise ValueError(f"Function 'max' expects 1 argument, got {len(args)}")
            return args[0].max()
        
        elif name == 'count':
            if len(args) not in (0, 1):
                raise ValueError(f"Function 'count' expects 0 or 1 arguments, got {len(args)}")
            if len(args) == 0:
                return pl.count()
            return args[0].count()
        
        elif name == 'std':
            if len(args) != 1:
                raise ValueError(f"Function 'std' expects 1 argument, got {len(args)}")
            return args[0].std()
        
        else:
            raise ValueError(f"Unknown aggregation function: {name}")
    
    def compile_conditional_function(self, name: str, args: List[pl.Expr]) -> pl.Expr:
        """
        Compile conditional function.
        
        Args:
            name: Function name
            args: Compiled arguments
            
        Returns:
            Polars expression
        """
        if name == 'if_else':
            if len(args) != 3:
                raise ValueError(f"Function 'if_else' expects 3 arguments, got {len(args)}")
            return pl.when(args[0]).then(args[1]).otherwise(args[2])
        
        elif name == 'coalesce':
            if len(args) < 1:
                raise ValueError(f"Function 'coalesce' expects at least 1 argument, got {len(args)}")
            return pl.coalesce(*args)
        
        elif name == 'is_null':
            if len(args) != 1:
                raise ValueError(f"Function 'is_null' expects 1 argument, got {len(args)}")
            return args[0].is_null()
        
        elif name == 'is_not_null':
            if len(args) != 1:
                raise ValueError(f"Function 'is_not_null' expects 1 argument, got {len(args)}")
            return args[0].is_not_null()
        
        else:
            raise ValueError(f"Unknown conditional function: {name}")
