"""
Core expression evaluation engine for Additory.

Main engine that ties together parser, compiler, loader, resolver, and integrity.
"""

import polars as pl
from typing import Dict, List, Optional, Tuple
from pathlib import Path

from additory.expressions.parser import ExpressionParser
from additory.expressions.compiler import ExpressionCompiler
from additory.expressions.loader import load_expressions_from_file
from additory.expressions.resolver import resolve_dependencies, check_circular_dependencies
from additory.expressions.integrity import verify_sha
from additory.core.logging import Logger


# Global engine instance
_engine_instance: Optional['ExpressionEngine'] = None


class ExpressionEngine:
    """
    Main expression evaluation engine.
    
    Singleton class that manages expression loading, parsing, compilation, and evaluation.
    """
    
    def __init__(self):
        """Initialize expression engine."""
        self.loaded_expressions: Dict[str, Dict] = {}
        self.parser = ExpressionParser()
        self.compiler = ExpressionCompiler()
        self.logger = Logger()
        
        # Load built-in expressions
        self._load_inbuilt_expressions()
    
    def _load_inbuilt_expressions(self):
        """Load built-in expressions from bundled .add files."""
        # Get the inbuilt expressions directory
        # This would be in the package: additory/inbuilt_expressions/
        inbuilt_dir = Path(__file__).parent.parent / 'inbuilt_expressions'
        
        if inbuilt_dir.exists():
            self.load_namespace('inbuilt', str(inbuilt_dir))
    
    def evaluate(self, df: pl.DataFrame, expression: str) -> pl.Series:
        """
        Evaluate expression and return result.
        
        Args:
            df: DataFrame to evaluate expression on
            expression: Expression string (inline or reference)
            
        Returns:
            Polars Series with result
            
        Example:
            # Inline expression
            result = engine.evaluate(df, 'weight / (height ** 2)')
            
            # Reference expression
            result = engine.evaluate(df, 'inbuilt:bmi')
        """
        # Check if this is a reference or inline expression
        if is_reference(expression):
            # Parse reference
            namespace, name = parse_expression_reference(expression)
            
            # Get expression definition
            expr_def = self.get_expression(f"{namespace}:{name}")
            
            # Get expression string
            expr_string = expr_def['expression']
            
            # Verify SHA integrity
            if 'sha' in expr_def and expr_def['sha']:
                is_valid = verify_sha(expr_string, expr_def['sha'])
                if not is_valid:
                    self.logger.warning(
                        f"Expression '{name}' in namespace '{namespace}' failed integrity check"
                    )
            
            # Log evaluation
            self.logger.info(f"Evaluating expression: {namespace}:{name}")
        else:
            # Inline expression
            expr_string = expression
            self.logger.info(f"Evaluating inline expression")
        
        # Parse expression to AST
        ast = self.parser.parse(expr_string)
        
        # Compile AST to Polars expression
        polars_expr = self.compiler.compile(ast, df)
        
        # Execute and return result
        result = df.select(polars_expr.alias('result'))['result']
        
        return result
    
    def load_namespace(self, namespace: str, folder_path: str):
        """
        Load expressions from a namespace folder.
        
        Args:
            namespace: Namespace name
            folder_path: Path to folder containing .add files
            
        Example:
            engine.load_namespace('inbuilt', '/path/to/inbuilt_expressions')
        """
        folder = Path(folder_path)
        
        if not folder.exists():
            self.logger.warning(f"Namespace folder not found: {folder_path}")
            return
        
        # Find all .add files
        add_files = list(folder.glob('*.add'))
        
        if not add_files:
            self.logger.info(f"No .add files found in {folder_path}")
            return
        
        # Load expressions from each file
        loaded_count = 0
        for add_file in add_files:
            try:
                expressions = load_expressions_from_file(str(add_file), namespace)
                
                # Store expressions
                for name, expr_def in expressions.items():
                    # Create full reference
                    full_ref = f"{namespace}:{name}"
                    
                    # Check for duplicates
                    if full_ref in self.loaded_expressions:
                        self.logger.warning(
                            f"Duplicate expression '{name}' in namespace '{namespace}' "
                            f"(from {add_file.name})"
                        )
                        continue
                    
                    # Add source file info
                    expr_def['source_file'] = add_file.name
                    
                    # Store expression
                    self.loaded_expressions[full_ref] = expr_def
                    loaded_count += 1
                
            except Exception as e:
                self.logger.error(f"Error loading {add_file.name}: {str(e)}")
        
        self.logger.info(
            f"Loaded {loaded_count} expressions from namespace '{namespace}'"
        )
    
    def get_expression(self, reference: str) -> Dict:
        """
        Get expression definition from reference.
        
        Args:
            reference: Expression reference ('inbuilt:bmi', 'myfolder:roi')
            
        Returns:
            Dictionary with expression definition
            
        Raises:
            ValueError: If expression not found
            
        Example:
            expr_def = engine.get_expression('inbuilt:bmi')
        """
        if reference not in self.loaded_expressions:
            raise ValueError(
                f"Expression '{reference}' not found. "
                f"Available expressions: {list(self.loaded_expressions.keys())}"
            )
        
        return self.loaded_expressions[reference]
    
    def list_expressions(self, namespace: Optional[str] = None) -> List[Dict]:
        """
        List all available expressions.
        
        Args:
            namespace: Filter by namespace (None = all)
            
        Returns:
            List of expression dictionaries
            
        Example:
            # List all expressions
            all_exprs = engine.list_expressions()
            
            # List only inbuilt
            inbuilt = engine.list_expressions('inbuilt')
        """
        if namespace is None:
            return list(self.loaded_expressions.values())
        
        # Filter by namespace
        return [
            expr_def for ref, expr_def in self.loaded_expressions.items()
            if ref.startswith(f"{namespace}:")
        ]
    
    def reload_custom_namespace(self):
        """
        Reload custom namespace expressions.
        
        Reloads all .add files from custom folder.
        """
        from additory.core.config import Config
        
        config = Config()
        custom_folder = config.get_expressions_folder()
        
        if custom_folder:
            # Clear existing custom expressions
            self.clear_custom_namespace()
            
            # Reload
            self.load_namespace('user', custom_folder)
    
    def clear_custom_namespace(self):
        """Clear custom namespace."""
        # Remove all expressions that don't start with 'inbuilt:'
        to_remove = [
            ref for ref in self.loaded_expressions.keys()
            if not ref.startswith('inbuilt:')
        ]
        
        for ref in to_remove:
            del self.loaded_expressions[ref]
        
        self.logger.info(f"Cleared {len(to_remove)} custom expressions")


def get_engine() -> ExpressionEngine:
    """
    Get the global expression engine instance.
    
    Returns:
        Global ExpressionEngine instance
        
    Example:
        engine = get_engine()
        result = engine.evaluate(df, 'inbuilt:bmi')
    """
    global _engine_instance
    
    if _engine_instance is None:
        _engine_instance = ExpressionEngine()
    
    return _engine_instance


def parse_expression_reference(expression: str) -> Tuple[str, str]:
    """
    Parse expression reference into namespace and name.
    
    Args:
        expression: Expression string
        
    Returns:
        Tuple of (namespace, name)
        
    Raises:
        ValueError: If not a valid reference
        
    Example:
        namespace, name = parse_expression_reference('inbuilt:bmi')
        # Returns: ('inbuilt', 'bmi')
    """
    if ':' not in expression:
        raise ValueError(f"Invalid expression reference: {expression}")
    
    parts = expression.split(':', 1)
    namespace = parts[0]
    name = parts[1]
    
    return namespace, name


def is_reference(expression: str) -> bool:
    """
    Check if expression is a reference (not inline).
    
    Args:
        expression: Expression string
        
    Returns:
        True if reference, False if inline
        
    Example:
        is_reference('inbuilt:bmi')  # True
        is_reference('weight / height')  # False
    """
    # A reference has the format: namespace:name
    # It should have exactly one colon and no spaces before the colon
    if ':' not in expression:
        return False
    
    # Check if it looks like a reference (namespace:name)
    parts = expression.split(':', 1)
    if len(parts) != 2:
        return False
    
    namespace = parts[0].strip()
    name = parts[1].strip()
    
    # Namespace and name should be valid identifiers (no spaces, operators, etc.)
    if not namespace or not name:
        return False
    
    # Check if namespace looks like an identifier
    if not namespace.replace('_', '').isalnum():
        return False
    
    # Check if name looks like an identifier
    if not name.replace('_', '').isalnum():
        return False
    
    return True
