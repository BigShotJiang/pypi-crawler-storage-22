"""
Expression integrity verification for Additory.

Verifies SHA-256 hashes of expressions to detect tampering or corruption.
"""

import hashlib
import re
from typing import Dict
from pathlib import Path


def verify_sha(expression: str, expected_sha: str) -> bool:
    """
    Verify SHA hash of expression.
    
    Args:
        expression: Expression string
        expected_sha: Expected SHA hash
        
    Returns:
        True if matches, False if mismatch
        
    Example:
        is_valid = verify_sha('weight / (height ** 2)', 'a1b2c3d4e5f6...')
    """
    # Compute actual SHA
    actual_sha = compute_sha(expression)
    
    # Compare
    if actual_sha != expected_sha:
        return False
    
    return True


def compute_sha(expression: str) -> str:
    """
    Compute SHA-256 hash of expression.
    
    Args:
        expression: Expression string
        
    Returns:
        SHA-256 hash as hex string
        
    Example:
        sha = compute_sha('weight / (height ** 2)')
        # Returns: 'a1b2c3d4e5f6...'
    """
    # Normalize expression
    normalized = normalize_expression(expression)
    
    # Compute SHA-256
    sha = hashlib.sha256(normalized.encode('utf-8')).hexdigest()
    
    return sha


def normalize_expression(expression: str) -> str:
    """
    Normalize expression for consistent hashing.
    
    Args:
        expression: Expression string
        
    Returns:
        Normalized expression string
        
    Example:
        normalized = normalize_expression('  weight  /  ( height ** 2 )  ')
        # Returns: 'weight / (height ** 2)'
    """
    # Remove leading/trailing whitespace
    normalized = expression.strip()
    
    # Collapse multiple spaces to single space
    normalized = re.sub(r'\s+', ' ', normalized)
    
    return normalized


def generate_sha_for_file(file_path: str) -> Dict[str, str]:
    """
    Generate SHA hashes for all expressions in a file.
    
    Args:
        file_path: Path to .add file
        
    Returns:
        Dictionary mapping expression name to SHA hash
        
    Example:
        hashes = generate_sha_for_file('core.add')
        # Returns: {'bmi': 'a1b2c3...', 'bsa': 'f6e5d4...'}
    """
    from additory.expressions.loader import load_expressions_from_file
    
    # Load expressions from file (use 'temp' as namespace for generation)
    expressions = load_expressions_from_file(file_path, 'temp')
    
    # Generate SHA for each expression
    hashes = {}
    for name, expr_def in expressions.items():
        # Extract expression string from definition
        if isinstance(expr_def, dict):
            expr_string = expr_def.get('expression', '')
        else:
            expr_string = expr_def
        
        hashes[name] = compute_sha(expr_string)
    
    return hashes


def verify_all_expressions(expressions: Dict[str, Dict]) -> Dict[str, bool]:
    """
    Verify SHA hashes for all expressions.
    
    Args:
        expressions: Dictionary of expression definitions
                    Each value should have 'expression' and 'sha' keys
        
    Returns:
        Dictionary mapping expression name to verification result
        
    Example:
        results = verify_all_expressions(loaded_expressions)
        # Returns: {'bmi': True, 'bsa': True, 'custom': False}
    """
    results = {}
    
    for name, expr_def in expressions.items():
        # Get expression string and expected SHA
        expr_string = expr_def.get('expression', '')
        expected_sha = expr_def.get('sha', '')
        
        # Skip if no SHA provided
        if not expected_sha:
            results[name] = True
            continue
        
        # Verify SHA
        is_valid = verify_sha(expr_string, expected_sha)
        results[name] = is_valid
        
        # Log warning if mismatch
        if not is_valid:
            actual_sha = compute_sha(expr_string)
            namespace = expr_def.get('namespace', 'unknown')
            log_integrity_warning(name, namespace, expected_sha, actual_sha)
    
    return results


def log_integrity_warning(
    expression_name: str,
    namespace: str,
    expected_sha: str,
    actual_sha: str
):
    """
    Log integrity warning.
    
    Args:
        expression_name: Name of expression
        namespace: Namespace name
        expected_sha: Expected SHA hash
        actual_sha: Actual SHA hash
    """
    from additory.core.logging import Logger
    
    logger = Logger()
    logger.warning(
        f"Expression '{expression_name}' in namespace '{namespace}' failed integrity check\n"
        f"  Expected SHA: {expected_sha}\n"
        f"  Actual SHA:   {actual_sha}\n"
        f"  This expression may have been modified. Use in development mode only."
    )
