"""
Expression loader for Additory.

Loads expressions from .add files (TOML format) in specified folders.
"""

import sys
from pathlib import Path
from typing import Dict, List

# Use tomllib for Python 3.11+ or tomli for earlier versions
if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        raise ImportError(
            "tomli is required for Python < 3.11. Install with: pip install tomli"
        )


def load_expressions_from_folder(folder_path: str, namespace: str) -> Dict[str, Dict]:
    """
    Load all expressions from .add files in a folder.
    
    Args:
        folder_path: Path to folder containing .add files
        namespace: Namespace name for these expressions
        
    Returns:
        Dictionary mapping expression name to definition
        
    Example:
        expressions = load_expressions_from_folder('/path/to/inbuilt', 'inbuilt')
        # Returns: {'bmi': {...}, 'bsa': {...}, ...}
    """
    # Check if folder exists
    folder = Path(folder_path)
    if not folder.exists():
        raise FileNotFoundError(f"Folder '{folder_path}' not found")
    
    if not folder.is_dir():
        raise ValueError(f"'{folder_path}' is not a directory")
    
    # Find all .add files
    add_files = find_add_files(folder_path)
    
    if not add_files:
        return {}
    
    # Load expressions from each file
    all_expressions = {}
    
    for file_path in add_files:
        file_expressions = load_expressions_from_file(file_path, namespace)
        
        # Check for duplicates
        check_duplicate_names(all_expressions, file_expressions, file_path)
        
        # Add to combined dictionary
        all_expressions.update(file_expressions)
    
    return all_expressions


def load_expressions_from_file(file_path: str, namespace: str) -> Dict[str, Dict]:
    """
    Load expressions from a single .add file.
    
    Args:
        file_path: Path to .add file
        namespace: Namespace name
        
    Returns:
        Dictionary mapping expression name to definition
        
    Example:
        expressions = load_expressions_from_file('/path/to/core.add', 'inbuilt')
        # Returns: {'bmi': {...}, 'bsa': {...}}
    """
    # Parse TOML file
    try:
        toml_data = parse_toml_file(file_path)
    except Exception as e:
        raise ValueError(f"File '{Path(file_path).name}' is not valid TOML: {str(e)}")
    
    # Process each expression
    expressions = {}
    file_name = Path(file_path).name
    
    for name, definition in toml_data.items():
        # Validate definition
        validate_expression_definition(name, definition, file_path)
        
        # Add metadata
        expression_def = {
            'name': name,
            'expression': definition['expression'],
            'description': definition['description'],
            'sha': definition['sha'],
            'namespace': namespace,
            'source_file': file_name
        }
        
        # Add optional fields
        if 'author' in definition:
            expression_def['author'] = definition['author']
        if 'version' in definition:
            expression_def['version'] = definition['version']
        if 'tags' in definition:
            expression_def['tags'] = definition['tags']
        
        expressions[name] = expression_def
    
    return expressions


def parse_toml_file(file_path: str) -> Dict:
    """
    Parse TOML file.
    
    Args:
        file_path: Path to TOML file
        
    Returns:
        Parsed TOML as dictionary
    """
    path = Path(file_path)
    
    if not path.exists():
        raise FileNotFoundError(f"File '{file_path}' not found")
    
    # Read and parse TOML
    with open(path, 'rb') as f:
        return tomllib.load(f)


def validate_expression_definition(name: str, definition: Dict, file_path: str) -> bool:
    """
    Validate expression definition has required fields.
    
    Args:
        name: Expression name
        definition: Expression definition dictionary
        file_path: Source file path (for error messages)
        
    Returns:
        True if valid
        
    Raises:
        ValueError: If validation fails
    """
    file_name = Path(file_path).name
    
    # Check if definition is a dictionary
    if not isinstance(definition, dict):
        raise ValueError(
            f"Expression '{name}' in '{file_name}' must be a table/dictionary"
        )
    
    # Required fields
    required_fields = ['expression', 'description', 'sha']
    
    for field in required_fields:
        if field not in definition:
            raise ValueError(
                f"Expression '{name}' in '{file_name}' missing required field '{field}'"
            )
        
        # Check field is a string
        if not isinstance(definition[field], str):
            raise ValueError(
                f"Expression '{name}' in '{file_name}' field '{field}' must be a string"
            )
        
        # Check field is not empty
        if not definition[field].strip():
            raise ValueError(
                f"Expression '{name}' in '{file_name}' field '{field}' cannot be empty"
            )
    
    # Validate optional fields if present
    if 'author' in definition and not isinstance(definition['author'], str):
        raise ValueError(
            f"Expression '{name}' in '{file_name}' field 'author' must be a string"
        )
    
    if 'version' in definition and not isinstance(definition['version'], str):
        raise ValueError(
            f"Expression '{name}' in '{file_name}' field 'version' must be a string"
        )
    
    if 'tags' in definition:
        if not isinstance(definition['tags'], list):
            raise ValueError(
                f"Expression '{name}' in '{file_name}' field 'tags' must be a list"
            )
        if not all(isinstance(tag, str) for tag in definition['tags']):
            raise ValueError(
                f"Expression '{name}' in '{file_name}' field 'tags' must contain only strings"
            )
    
    return True


def find_add_files(folder_path: str) -> List[str]:
    """
    Find all .add files in a folder.
    
    Args:
        folder_path: Path to folder
        
    Returns:
        List of .add file paths (sorted alphabetically)
    """
    folder = Path(folder_path)
    
    # Find all .add files (not recursive)
    add_files = list(folder.glob('*.add'))
    
    # Sort alphabetically
    add_files.sort()
    
    # Convert to strings
    return [str(f) for f in add_files]


def check_duplicate_names(
    expressions_dict: Dict[str, Dict],
    new_expressions: Dict[str, Dict],
    source_file: str
) -> bool:
    """
    Check for duplicate expression names.
    
    Args:
        expressions_dict: Existing expressions
        new_expressions: New expressions to add
        source_file: Source file of new expressions
        
    Returns:
        True if no duplicates
        
    Raises:
        ValueError: If duplicates found
    """
    duplicates = []
    
    for name in new_expressions:
        if name in expressions_dict:
            existing_file = expressions_dict[name]['source_file']
            new_file = Path(source_file).name
            duplicates.append((name, existing_file, new_file))
    
    if duplicates:
        error_lines = ["Duplicate expression names found:"]
        for name, existing_file, new_file in duplicates:
            error_lines.append(f"  - '{name}' in '{existing_file}' and '{new_file}'")
        error_lines.append("Please rename one of them.")
        raise ValueError('\n'.join(error_lines))
    
    return True
