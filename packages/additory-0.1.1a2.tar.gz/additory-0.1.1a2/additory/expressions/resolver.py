"""
Expression dependency resolver for Additory.

Resolves column references and dependencies in expressions.
"""

import re
from typing import List, Dict, Set


# Known function names
FUNCTION_NAMES = {
    # Math functions
    'sqrt', 'abs', 'log', 'log10', 'exp', 'pow', 'round', 'floor', 'ceil',
    # String functions
    'lower', 'upper', 'trim', 'length', 'substring', 'replace', 'contains', 'matches',
    # DateTime functions
    'year', 'month', 'day', 'hour', 'minute', 'second', 'day_of_week', 'time_of_day',
    # Aggregation functions
    'sum', 'mean', 'median', 'min', 'max', 'count', 'std',
    # Conditional functions
    'if_else', 'coalesce', 'is_null', 'is_not_null'
}


def resolve_dependencies(expression: str, available_columns: List[str]) -> List[str]:
    """
    Find all column dependencies in an expression.
    
    Args:
        expression: Expression string
        available_columns: List of available column names in DataFrame
        
    Returns:
        List of column names used in expression
        
    Example:
        deps = resolve_dependencies('weight / (height ** 2)', ['weight', 'height', 'age'])
        # Returns: ['weight', 'height']
    """
    # Extract all identifiers
    identifiers = extract_identifiers(expression)
    
    # Filter to only columns that exist in DataFrame
    dependencies = [id for id in identifiers if id in available_columns]
    
    # Return unique list
    return list(set(dependencies))


def validate_dependencies(expression: str, available_columns: List[str]) -> bool:
    """
    Validate that all column dependencies exist.
    
    Args:
        expression: Expression string
        available_columns: List of available column names
        
    Returns:
        True if all dependencies exist
        
    Raises:
        ValueError: If any dependencies are missing
        
    Example:
        validate_dependencies('weight / height', ['weight', 'height'])  # Returns True
        validate_dependencies('weight / height', ['age'])  # Raises ValueError
    """
    # Extract all identifiers
    identifiers = extract_identifiers(expression)
    
    # Find missing columns
    missing = [id for id in identifiers if id not in available_columns]
    
    if missing:
        raise ValueError(
            f"Expression requires columns {missing} but DataFrame only has {available_columns}"
        )
    
    return True


def extract_identifiers(expression: str) -> List[str]:
    """
    Extract all identifiers from expression string.
    
    Args:
        expression: Expression string
        
    Returns:
        List of identifier names (column names, not function names)
        
    Example:
        identifiers = extract_identifiers('sqrt((height * weight) / 3600)')
        # Returns: ['height', 'weight']
    """
    # Remove string literals first (both single and double quotes)
    # This prevents extracting identifiers from within strings
    expr_without_strings = re.sub(r'"[^"]*"', '', expression)
    expr_without_strings = re.sub(r"'[^']*'", '', expr_without_strings)
    
    # Pattern to match identifiers (letters, numbers, underscores)
    pattern = r'\b[a-zA-Z_][a-zA-Z0-9_]*\b'
    
    # Find all matches
    matches = re.findall(pattern, expr_without_strings)
    
    # Filter out keywords and function names
    keywords = {'AND', 'OR', 'NOT'}
    identifiers = [
        match for match in matches
        if match not in keywords and not is_function_name(match)
    ]
    
    # Return unique list
    return list(set(identifiers))


def is_function_name(identifier: str) -> bool:
    """
    Check if identifier is a function name.
    
    Args:
        identifier: Identifier string
        
    Returns:
        True if function name, False if column name
        
    Example:
        is_function_name('sqrt')  # Returns True
        is_function_name('weight')  # Returns False
    """
    return identifier.lower() in FUNCTION_NAMES


def check_circular_dependencies(expressions: Dict[str, str]) -> bool:
    """
    Check for circular dependencies between expressions.
    
    Args:
        expressions: Dictionary mapping expression name to expression string
        
    Returns:
        True if no circular dependencies
        
    Raises:
        ValueError: If circular dependency detected
        
    Example:
        expressions = {
            'a': 'b + 1',
            'b': 'c + 1',
            'c': 'a + 1'  # Circular!
        }
        check_circular_dependencies(expressions)
        # Raises: "Circular dependency detected: a -> b -> c -> a"
    """
    # Build dependency graph
    graph = build_dependency_graph(expressions)
    
    # Track visited nodes and recursion stack
    visited: Set[str] = set()
    rec_stack: Set[str] = set()
    path: List[str] = []
    
    def has_cycle(node: str) -> bool:
        """DFS to detect cycles."""
        visited.add(node)
        rec_stack.add(node)
        path.append(node)
        
        # Check all dependencies
        for dep in graph.get(node, []):
            if dep not in visited:
                if has_cycle(dep):
                    return True
            elif dep in rec_stack:
                # Found cycle
                cycle_start = path.index(dep)
                cycle = path[cycle_start:] + [dep]
                raise ValueError(
                    f"Circular dependency detected: {' -> '.join(cycle)}"
                )
        
        rec_stack.remove(node)
        path.pop()
        return False
    
    # Check each expression
    for expr_name in expressions:
        if expr_name not in visited:
            has_cycle(expr_name)
    
    return True


def topological_sort(expressions: Dict[str, str]) -> List[str]:
    """
    Sort expressions by dependency order.
    
    Args:
        expressions: Dictionary mapping expression name to expression string
        
    Returns:
        List of expression names in dependency order
        
    Example:
        expressions = {
            'bmi': 'weight / (height ** 2)',
            'bmi_category': 'if_else(bmi < 18.5, "underweight", "normal")',
            'weight': 'weight_lb * 0.453592'
        }
        order = topological_sort(expressions)
        # Returns: ['weight', 'bmi', 'bmi_category']
    """
    # Build dependency graph
    graph = build_dependency_graph(expressions)
    
    # Track visited nodes and result
    visited: Set[str] = set()
    result: List[str] = []
    
    def visit(node: str):
        """DFS to build topological order."""
        if node in visited:
            return
        
        visited.add(node)
        
        # Visit all dependencies first
        for dep in graph.get(node, []):
            if dep in expressions:  # Only visit if it's an expression
                visit(dep)
        
        # Add node after all dependencies
        result.append(node)
    
    # Visit each expression
    for expr_name in expressions:
        visit(expr_name)
    
    return result


def build_dependency_graph(expressions: Dict[str, str]) -> Dict[str, List[str]]:
    """
    Build dependency graph for expressions.
    
    Args:
        expressions: Dictionary mapping expression name to expression string
        
    Returns:
        Dictionary mapping expression name to list of dependencies
        
    Example:
        expressions = {
            'bmi': 'weight / (height ** 2)',
            'bmi_category': 'if_else(bmi < 18.5, "underweight", "normal")'
        }
        graph = build_dependency_graph(expressions)
        # Returns: {'bmi': [], 'bmi_category': ['bmi']}
    """
    graph: Dict[str, List[str]] = {}
    
    for expr_name, expr_string in expressions.items():
        # Extract identifiers from expression
        identifiers = extract_identifiers(expr_string)
        
        # Filter to only other expressions (not columns)
        dependencies = [id for id in identifiers if id in expressions]
        
        graph[expr_name] = dependencies
    
    return graph
