"""
Analyze function - Data analysis with multiple modes.

Provides comprehensive data analysis including quality, cardinality,
distributions, correlations, and more.
"""

import polars as pl
import time
from typing import Optional

from additory.core.backend import detect_backend, to_polars
from additory.core.logging import get_logger
from additory.common.validation import validate_dataframe
from additory.common.result import wrap_analysis

from . import quality
from . import cardinality
from . import distributions
from . import correlations
from . import types
from . import features
from . import patterns
from . import outliers
from . import duplicates
from . import timeseries
from . import imputation
from . import presets


logger = get_logger()


def analyze(
    df,
    preset: Optional[str] = None,
    quality_analysis: bool = False,
    cardinality_analysis: bool = False,
    distributions_analysis: bool = False,
    correlations_analysis: bool = False,
    features_analysis: bool = False,
    types_analysis: bool = False,
    patterns_analysis: bool = False,
    outliers_analysis: bool = False,
    duplicates_analysis: bool = False,
    timeseries_analysis: bool = False,
    imputation_analysis: bool = False,
    date_column: Optional[str] = None
):
    """
    Analyze DataFrame with multiple analysis types.
    
    Args:
        df: Input DataFrame
        preset: Preset name ('quick', 'full')
        quality_analysis: Run quality analysis
        cardinality_analysis: Run cardinality analysis
        distributions_analysis: Run distribution analysis
        correlations_analysis: Run correlation analysis
        features_analysis: Run feature analysis
        types_analysis: Run type analysis
        patterns_analysis: Run pattern analysis
        outliers_analysis: Run outlier analysis
        duplicates_analysis: Run duplicate analysis
        timeseries_analysis: Run timeseries analysis
        imputation_analysis: Run imputation analysis
        date_column: Column for timeseries analysis
        
    Returns:
        AnalysisResult with analysis results
    """
    start_time = time.time()
    
    # Validate and convert
    validate_dataframe(df, 'df')
    backend = detect_backend(df)
    polars_df = to_polars(df)
    
    # Determine analyses to run
    if preset:
        analyses_to_run = presets.get_preset_analyses(preset)
    else:
        analyses_to_run = {
            'quality': quality_analysis,
            'cardinality': cardinality_analysis,
            'distributions': distributions_analysis,
            'correlations': correlations_analysis,
            'features': features_analysis,
            'types': types_analysis,
            'patterns': patterns_analysis,
            'outliers': outliers_analysis,
            'duplicates': duplicates_analysis,
            'timeseries': timeseries_analysis,
            'imputation': imputation_analysis
        }
    
    # Run analyses
    results = {}
    
    if analyses_to_run.get('quality'):
        results['quality'] = quality.analyze_quality(polars_df)
    
    if analyses_to_run.get('cardinality'):
        results['cardinality'] = cardinality.analyze_cardinality(polars_df)
    
    if analyses_to_run.get('distributions'):
        results['distributions'] = distributions.analyze_distributions(polars_df)
    
    if analyses_to_run.get('correlations'):
        results['correlations'] = correlations.analyze_correlations(polars_df)
    
    if analyses_to_run.get('features'):
        results['features'] = features.analyze_features(polars_df)
    
    if analyses_to_run.get('types'):
        results['types'] = types.analyze_types(polars_df)
    
    if analyses_to_run.get('patterns'):
        results['patterns'] = patterns.analyze_patterns(polars_df)
    
    if analyses_to_run.get('outliers'):
        results['outliers'] = outliers.analyze_outliers(polars_df)
    
    if analyses_to_run.get('duplicates'):
        results['duplicates'] = duplicates.analyze_duplicates(polars_df)
    
    if analyses_to_run.get('timeseries') and date_column:
        results['timeseries'] = timeseries.analyze_timeseries(polars_df, date_column)
    
    if analyses_to_run.get('imputation'):
        results['imputation'] = imputation.analyze_imputation(polars_df)
    
    # Calculate execution time
    execution_time = time.time() - start_time
    
    # Wrap and return
    metadata = {
        'preset': preset,
        'analyses_run': list(results.keys()),
        'execution_time': execution_time,
        'input_shape': (polars_df.height, polars_df.width)
    }
    
    return wrap_analysis(results, metadata)
