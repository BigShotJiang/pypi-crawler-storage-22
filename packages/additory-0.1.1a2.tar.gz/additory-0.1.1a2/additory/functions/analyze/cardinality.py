"""
Cardinality analysis module.

Analyzes unique value counts and cardinality ratios to identify
potential keys and categorical columns.
"""

import polars as pl
from typing import Dict, Any, List


def analyze_cardinality(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Analyze cardinality metrics.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with cardinality metrics:
        - unique_counts: Dict of column -> unique count
        - cardinality_ratios: Dict of column -> ratio (unique/total)
        - high_cardinality: List of high cardinality columns (ratio > 0.95)
        - low_cardinality: List of low cardinality columns (ratio < 0.05)
        - potential_keys: List of columns that could be keys (ratio == 1.0)
        - potential_categories: List of columns that could be categories (ratio < 0.05)
        
    Example:
        >>> df = pl.DataFrame({'id': [1, 2, 3], 'category': ['A', 'A', 'B']})
        >>> result = analyze_cardinality(df)
        >>> result['potential_keys']
        ['id']
    """
    total_rows = df.height
    
    # Calculate unique counts and ratios
    unique_counts = {}
    cardinality_ratios = {}
    
    for col in df.columns:
        unique_count = df[col].n_unique()
        unique_counts[col] = unique_count
        cardinality_ratios[col] = (unique_count / total_rows) if total_rows > 0 else 0.0
    
    # Classify columns by cardinality
    high_cardinality = [col for col, ratio in cardinality_ratios.items() if ratio > 0.95]
    low_cardinality = [col for col, ratio in cardinality_ratios.items() if ratio < 0.05]
    potential_keys = [col for col, ratio in cardinality_ratios.items() if ratio == 1.0]
    potential_categories = [col for col, ratio in cardinality_ratios.items() if ratio < 0.05 and ratio > 0]
    
    return {
        'unique_counts': unique_counts,
        'cardinality_ratios': {k: round(v, 4) for k, v in cardinality_ratios.items()},
        'high_cardinality': high_cardinality,
        'low_cardinality': low_cardinality,
        'potential_keys': potential_keys,
        'potential_categories': potential_categories
    }
