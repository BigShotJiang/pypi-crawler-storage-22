"""
Correlation analysis module.

Analyzes correlations between numeric columns using Pearson correlation.
"""

import polars as pl
from typing import Dict, Any, List, Tuple


def analyze_correlations(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Analyze correlations between numeric columns.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with correlation metrics:
        - correlation_matrix: Dict of column pairs -> correlation value
        - highly_correlated: List of highly correlated pairs (|r| > 0.7)
        - numeric_columns: List of columns analyzed
        
    Example:
        >>> df = pl.DataFrame({'a': [1, 2, 3], 'b': [2, 4, 6], 'c': [1, 1, 1]})
        >>> result = analyze_correlations(df)
        >>> len(result['highly_correlated']) > 0
        True
    """
    # Get numeric columns
    numeric_cols = [col for col in df.columns if df[col].dtype in [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64, pl.Float32, pl.Float64]]
    
    if len(numeric_cols) < 2:
        return {
            'correlation_matrix': {},
            'highly_correlated': [],
            'numeric_columns': numeric_cols
        }
    
    # Calculate correlation matrix
    correlation_matrix = {}
    highly_correlated = []
    
    for i, col1 in enumerate(numeric_cols):
        for col2 in numeric_cols[i+1:]:
            # Calculate Pearson correlation
            corr = df.select([
                pl.corr(col1, col2).alias('correlation')
            ])['correlation'][0]
            
            if corr is not None:
                correlation_matrix[f"{col1}_{col2}"] = round(float(corr), 4)
                
                # Check if highly correlated
                if abs(corr) > 0.7:
                    highly_correlated.append({
                        'column1': col1,
                        'column2': col2,
                        'correlation': round(float(corr), 4)
                    })
    
    return {
        'correlation_matrix': correlation_matrix,
        'highly_correlated': highly_correlated,
        'numeric_columns': numeric_cols
    }
