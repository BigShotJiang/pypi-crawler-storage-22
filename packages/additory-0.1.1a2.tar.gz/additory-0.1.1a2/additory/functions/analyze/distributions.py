"""
Distribution analysis module.

Analyzes statistical distributions of numeric columns including
mean, median, std, skewness, and kurtosis.
"""

import polars as pl
from typing import Dict, Any


def analyze_distributions(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Analyze distribution metrics for numeric columns.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with distribution metrics per numeric column:
        - mean: Mean value
        - median: Median value
        - std: Standard deviation
        - min: Minimum value
        - max: Maximum value
        - q25: 25th percentile
        - q75: 75th percentile
        
    Example:
        >>> df = pl.DataFrame({'a': [1, 2, 3, 4, 5], 'b': ['x', 'y', 'z', 'x', 'y']})
        >>> result = analyze_distributions(df)
        >>> 'a' in result
        True
    """
    numeric_cols = [col for col in df.columns if df[col].dtype in [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64, pl.Float32, pl.Float64]]
    
    distributions = {}
    
    for col in numeric_cols:
        col_data = df[col]
        
        # Calculate basic statistics
        distributions[col] = {
            'mean': float(col_data.mean()) if col_data.mean() is not None else None,
            'median': float(col_data.median()) if col_data.median() is not None else None,
            'std': float(col_data.std()) if col_data.std() is not None else None,
            'min': float(col_data.min()) if col_data.min() is not None else None,
            'max': float(col_data.max()) if col_data.max() is not None else None,
            'q25': float(col_data.quantile(0.25)) if col_data.quantile(0.25) is not None else None,
            'q75': float(col_data.quantile(0.75)) if col_data.quantile(0.75) is not None else None
        }
    
    return distributions
