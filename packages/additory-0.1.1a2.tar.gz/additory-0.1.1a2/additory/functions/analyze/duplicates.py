"""
Duplicate detection module.

Detects duplicate rows and values in the DataFrame.
"""

import polars as pl
from typing import Dict, Any


def analyze_duplicates(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Detect duplicate rows and values.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with duplicate detection results:
        - duplicate_rows: Number of duplicate rows
        - duplicate_percentage: Percentage of duplicate rows
        - columns_with_duplicates: List of columns with duplicate values
        - unique_rows: Number of unique rows
        
    Example:
        >>> df = pl.DataFrame({'a': [1, 1, 2], 'b': [1, 1, 2]})
        >>> result = analyze_duplicates(df)
        >>> result['duplicate_rows']
        1
    """
    total_rows = df.height
    unique_rows = df.unique().height
    duplicate_rows = total_rows - unique_rows
    duplicate_percentage = (duplicate_rows / total_rows * 100) if total_rows > 0 else 0.0
    
    # Check for duplicates in each column
    columns_with_duplicates = []
    for col in df.columns:
        unique_count = df[col].n_unique()
        if unique_count < total_rows:
            columns_with_duplicates.append(col)
    
    return {
        'duplicate_rows': duplicate_rows,
        'duplicate_percentage': round(duplicate_percentage, 2),
        'unique_rows': unique_rows,
        'total_rows': total_rows,
        'columns_with_duplicates': columns_with_duplicates
    }
