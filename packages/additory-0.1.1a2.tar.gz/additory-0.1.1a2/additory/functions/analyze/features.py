"""
Feature analysis module.

Analyzes feature types and provides transformation recommendations.
"""

import polars as pl
from typing import Dict, Any


def analyze_features(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Analyze features and provide recommendations.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with feature analysis:
        - feature_types: Dict of column -> feature type
        - numeric_features: List of numeric features
        - categorical_features: List of categorical features
        - datetime_features: List of datetime features
        
    Example:
        >>> df = pl.DataFrame({'a': [1, 2, 3], 'b': ['x', 'y', 'z']})
        >>> result = analyze_features(df)
        >>> result['numeric_features']
        ['a']
    """
    feature_types = {}
    numeric_features = []
    categorical_features = []
    datetime_features = []
    
    for col in df.columns:
        dtype = df[col].dtype
        
        if dtype in [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64, pl.Float32, pl.Float64]:
            feature_types[col] = 'numeric'
            numeric_features.append(col)
        elif dtype == pl.Utf8:
            # Check if it's categorical (low cardinality)
            unique_ratio = df[col].n_unique() / df.height if df.height > 0 else 0
            if unique_ratio < 0.05:
                feature_types[col] = 'categorical'
                categorical_features.append(col)
            else:
                feature_types[col] = 'text'
        elif dtype in [pl.Date, pl.Datetime]:
            feature_types[col] = 'datetime'
            datetime_features.append(col)
        else:
            feature_types[col] = str(dtype)
    
    return {
        'feature_types': feature_types,
        'numeric_features': numeric_features,
        'categorical_features': categorical_features,
        'datetime_features': datetime_features
    }
