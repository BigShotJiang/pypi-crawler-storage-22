"""
Outlier detection module.

Detects outliers in numeric columns using IQR method.
"""

import polars as pl
from typing import Dict, Any


def analyze_outliers(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Detect outliers in numeric columns using IQR method.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with outlier detection results:
        - outlier_counts: Dict of column -> outlier count
        - outlier_percentages: Dict of column -> outlier percentage
        - columns_with_outliers: List of columns with outliers
        
    Example:
        >>> df = pl.DataFrame({'a': [1, 2, 3, 4, 100]})
        >>> result = analyze_outliers(df)
        >>> result['outlier_counts']['a'] > 0
        True
    """
    numeric_cols = [col for col in df.columns if df[col].dtype in [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64, pl.Float32, pl.Float64]]
    
    outlier_counts = {}
    outlier_percentages = {}
    
    for col in numeric_cols:
        col_data = df[col].drop_nulls()
        
        if len(col_data) == 0:
            outlier_counts[col] = 0
            outlier_percentages[col] = 0.0
            continue
        
        # Calculate IQR
        q25 = col_data.quantile(0.25)
        q75 = col_data.quantile(0.75)
        iqr = q75 - q25
        
        # Calculate bounds
        lower_bound = q25 - 1.5 * iqr
        upper_bound = q75 + 1.5 * iqr
        
        # Count outliers
        outliers = col_data.filter((col_data < lower_bound) | (col_data > upper_bound))
        outlier_count = len(outliers)
        
        outlier_counts[col] = outlier_count
        outlier_percentages[col] = (outlier_count / len(col_data) * 100) if len(col_data) > 0 else 0.0
    
    columns_with_outliers = [col for col, count in outlier_counts.items() if count > 0]
    
    return {
        'outlier_counts': outlier_counts,
        'outlier_percentages': {k: round(v, 2) for k, v in outlier_percentages.items()},
        'columns_with_outliers': columns_with_outliers
    }
