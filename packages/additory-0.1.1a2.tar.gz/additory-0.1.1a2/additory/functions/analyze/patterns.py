"""
Pattern detection module.

Detects common patterns in string columns like emails, phone numbers, etc.
"""

import polars as pl
import re
from typing import Dict, Any


def analyze_patterns(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Detect patterns in string columns.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with pattern detection results:
        - email_columns: List of columns containing emails
        - phone_columns: List of columns containing phone numbers
        - date_string_columns: List of columns containing date strings
        - id_columns: List of columns containing IDs
        
    Example:
        >>> df = pl.DataFrame({'email': ['a@b.com', 'c@d.com']})
        >>> result = analyze_patterns(df)
        >>> 'email' in result['email_columns']
        True
    """
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    phone_pattern = r'^\+?[\d\s\-\(\)]{10,}$'
    
    email_columns = []
    phone_columns = []
    date_string_columns = []
    id_columns = []
    
    for col in df.columns:
        if df[col].dtype != pl.Utf8:
            continue
        
        # Sample first 100 non-null values
        sample = df[col].drop_nulls().head(100).to_list()
        
        if not sample:
            continue
        
        # Check for email pattern
        email_matches = sum(1 for val in sample if re.match(email_pattern, str(val)))
        if email_matches / len(sample) > 0.8:
            email_columns.append(col)
        
        # Check for phone pattern
        phone_matches = sum(1 for val in sample if re.match(phone_pattern, str(val)))
        if phone_matches / len(sample) > 0.8:
            phone_columns.append(col)
    
    return {
        'email_columns': email_columns,
        'phone_columns': phone_columns,
        'date_string_columns': date_string_columns,
        'id_columns': id_columns
    }
