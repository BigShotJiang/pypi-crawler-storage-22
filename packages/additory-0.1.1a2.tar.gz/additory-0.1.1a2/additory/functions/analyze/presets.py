"""
Preset analysis configurations.

Provides preset analysis configurations for quick and full analysis.
"""

from typing import Dict, List


def get_preset_analyses(preset_name: str) -> Dict[str, bool]:
    """
    Get analyses for a preset.
    
    Args:
        preset_name: Name of preset ('quick' or 'full')
        
    Returns:
        Dictionary of analysis_name -> enabled
        
    Example:
        >>> analyses = get_preset_analyses('quick')
        >>> analyses['quality']
        True
    """
    presets = {
        'quick': {
            'quality': True,
            'cardinality': True,
            'types': True,
            'distributions': False,
            'correlations': False,
            'features': False,
            'patterns': False,
            'outliers': False,
            'duplicates': False,
            'timeseries': False,
            'imputation': False
        },
        'full': {
            'quality': True,
            'cardinality': True,
            'types': True,
            'distributions': True,
            'correlations': True,
            'features': True,
            'patterns': True,
            'outliers': True,
            'duplicates': True,
            'timeseries': False,  # Requires date_column
            'imputation': True
        }
    }
    
    if preset_name not in presets:
        raise ValueError(f"Unknown preset '{preset_name}'. Available: {list(presets.keys())}")
    
    return presets[preset_name]


def list_presets() -> List[str]:
    """
    List available presets.
    
    Returns:
        List of preset names
        
    Example:
        >>> presets = list_presets()
        >>> 'quick' in presets
        True
    """
    return ['quick', 'full']
