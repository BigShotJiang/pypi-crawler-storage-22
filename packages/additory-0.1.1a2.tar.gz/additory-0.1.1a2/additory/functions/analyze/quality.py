"""
Data quality analysis module.

Analyzes data quality metrics including missing values, type consistency,
and format violations.
"""

import polars as pl
from typing import Dict, Any


def analyze_quality(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Analyze data quality metrics.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with quality metrics:
        - missing_values: Dict of column -> count
        - missing_percentages: Dict of column -> percentage
        - total_rows: Total number of rows
        - columns_with_nulls: List of columns with missing values
        - quality_score: Overall quality score (0-100)
        
    Example:
        >>> df = pl.DataFrame({'a': [1, 2, None], 'b': [1, 2, 3]})
        >>> result = analyze_quality(df)
        >>> result['missing_values']
        {'a': 1, 'b': 0}
    """
    total_rows = df.height
    total_cells = total_rows * df.width
    
    # Calculate missing values per column
    missing_values = {}
    missing_percentages = {}
    
    for col in df.columns:
        null_count = df[col].null_count()
        missing_values[col] = null_count
        missing_percentages[col] = (null_count / total_rows * 100) if total_rows > 0 else 0.0
    
    # Identify columns with nulls
    columns_with_nulls = [col for col, count in missing_values.items() if count > 0]
    
    # Calculate overall quality score (percentage of non-null cells)
    total_nulls = sum(missing_values.values())
    quality_score = ((total_cells - total_nulls) / total_cells * 100) if total_cells > 0 else 100.0
    
    return {
        'missing_values': missing_values,
        'missing_percentages': missing_percentages,
        'total_rows': total_rows,
        'total_columns': df.width,
        'columns_with_nulls': columns_with_nulls,
        'quality_score': round(quality_score, 2)
    }
