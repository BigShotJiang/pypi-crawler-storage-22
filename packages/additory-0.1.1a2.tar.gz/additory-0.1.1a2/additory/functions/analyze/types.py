"""
Data type analysis module.

Analyzes data types and provides type recommendations.
"""

import polars as pl
from typing import Dict, Any


def analyze_types(df: pl.DataFrame) -> Dict[str, Any]:
    """
    Analyze data types of columns.
    
    Args:
        df: Polars DataFrame to analyze
        
    Returns:
        Dictionary with type information:
        - column_types: Dict of column -> type name
        - numeric_columns: List of numeric columns
        - string_columns: List of string columns
        - boolean_columns: List of boolean columns
        - date_columns: List of date/datetime columns
        
    Example:
        >>> df = pl.DataFrame({'a': [1, 2, 3], 'b': ['x', 'y', 'z']})
        >>> result = analyze_types(df)
        >>> result['numeric_columns']
        ['a']
    """
    column_types = {col: str(df[col].dtype) for col in df.columns}
    
    numeric_columns = [col for col in df.columns if df[col].dtype in [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64, pl.Float32, pl.Float64]]
    string_columns = [col for col in df.columns if df[col].dtype == pl.Utf8]
    boolean_columns = [col for col in df.columns if df[col].dtype == pl.Boolean]
    date_columns = [col for col in df.columns if df[col].dtype in [pl.Date, pl.Datetime]]
    
    return {
        'column_types': column_types,
        'numeric_columns': numeric_columns,
        'string_columns': string_columns,
        'boolean_columns': boolean_columns,
        'date_columns': date_columns
    }
