"""
Expressions function - Evaluate expressions and add result columns.

Supports both inline expressions and references to named expressions.
"""

import polars as pl
import time
import re
from typing import List

from additory.core.backend import detect_backend, to_polars, from_polars
from additory.core.logging import get_logger
from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.result import wrap_result
from additory.expressions.engine import get_engine


logger = get_logger()


def expressions(df, *expressions_list):
    """
    Evaluate one or more expressions and add result columns.
    
    Args:
        df: Input DataFrame
        *expressions_list: Variable number of expression strings
        
    Returns:
        DataFrameResult with computed columns
        
    Examples:
        >>> # Single expression
        >>> result = expressions(df, 'inbuilt:bmi')
        
        >>> # Multiple expressions
        >>> result = expressions(df, 'inbuilt:bmi', 'inbuilt:bsa')
        
        >>> # Inline expression
        >>> result = expressions(df, 'weight / (height ** 2)')
        
        >>> # Mix of inline and references
        >>> result = expressions(df, 'inbuilt:bmi', 'age * 12')
    """
    start_time = time.time()
    
    # Validate inputs
    validate_dataframe(df, 'df')
    validate_not_empty(df, 'df')
    
    if not expressions_list:
        raise ValueError("At least one expression required")
    
    # Detect backend and convert to Polars
    backend = detect_backend(df)
    polars_df = to_polars(df)
    
    # Get expression engine
    engine = get_engine()
    
    # Track columns added
    columns_added = []
    
    # Evaluate each expression
    result_df = polars_df
    for expr_str in expressions_list:
        # Evaluate expression
        result_series = engine.evaluate(result_df, expr_str)
        
        # Determine column name
        col_name = determine_column_name(expr_str)
        
        # Add to DataFrame
        result_df = result_df.with_columns(result_series.alias(col_name))
        columns_added.append(col_name)
        
        logger.info(f"Added column '{col_name}' from expression '{expr_str}'")
    
    # Convert back to original backend
    result_df = from_polars(result_df, backend)
    
    # Calculate execution time
    execution_time = time.time() - start_time
    
    # Wrap result
    metadata = {
        'expressions_evaluated': len(expressions_list),
        'columns_added': columns_added,
        'input_shape': (polars_df.height, polars_df.width),
        'execution_time': execution_time
    }
    
    return wrap_result(result_df, 'expressions', metadata)


def determine_column_name(expression: str) -> str:
    """
    Determine column name for expression result.
    
    Args:
        expression: Expression string
        
    Returns:
        Column name
        
    Examples:
        >>> determine_column_name('inbuilt:bmi')
        'bmi'
        >>> determine_column_name('weight / height')
        'weight_div_height'
    """
    # If reference (e.g., 'inbuilt:bmi'), use expression name
    if ':' in expression:
        parts = expression.split(':', 1)
        if len(parts) == 2 and parts[0] in ['inbuilt', 'user', 'company']:
            return parts[1]
    
    # If inline, infer from expression
    return infer_column_name(expression)


def infer_column_name(expression: str) -> str:
    """
    Infer column name from inline expression.
    
    Args:
        expression: Inline expression string
        
    Returns:
        Inferred column name
        
    Examples:
        >>> infer_column_name('weight / height')
        'weight_div_height'
        >>> infer_column_name('sqrt(age)')
        'sqrt_age'
        >>> infer_column_name('age * 12')
        'age_mul_12'
    """
    # Replace operators with words
    name = expression
    name = name.replace(' / ', '_div_')
    name = name.replace(' * ', '_mul_')
    name = name.replace(' + ', '_add_')
    name = name.replace(' - ', '_sub_')
    name = name.replace('**', '_pow_')
    
    # Remove parentheses and spaces
    name = name.replace('(', '_')
    name = name.replace(')', '')
    name = name.replace(' ', '')
    
    # Remove trailing underscores
    name = name.strip('_')
    
    # If name is too long or complex, use generic name
    if len(name) > 50 or not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name):
        return 'expr_result'
    
    return name
