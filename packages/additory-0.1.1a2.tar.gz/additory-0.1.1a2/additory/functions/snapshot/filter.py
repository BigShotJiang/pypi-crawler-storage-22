"""
Filter and select data.

This module provides filtering functionality for the snapshot function.
"""

import polars as pl
from typing import List, Optional

from additory.common.validation import validate_dataframe
from additory.common.column_selector import select_columns as select_cols
from additory.core.logging import Logger


def apply_filter(df: pl.DataFrame, where: str) -> pl.DataFrame:
    """
    Apply WHERE clause filter to DataFrame.
    
    Args:
        df: Input DataFrame
        where: Filter expression (SQL-like WHERE clause)
        
    Returns:
        Filtered DataFrame
        
    Example:
        >>> result = apply_filter(df, 'age > 18 AND status == "active"')
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    
    if not where:
        return df
    
    logger.info(f"Applying filter: {where}")
    
    # Parse and evaluate WHERE clause
    where_expr = parse_where_clause(df, where)
    result = df.filter(where_expr)
    
    logger.info(f"Filter applied: {len(result)} rows remaining")
    
    return result


def parse_where_clause(df: pl.DataFrame, where: str) -> pl.Expr:
    """
    Parse WHERE clause into Polars expression.
    
    Args:
        df: Input DataFrame (for column validation)
        where: Filter expression
        
    Returns:
        Polars expression
        
    Supports:
        - Comparison: >, <, >=, <=, ==, !=
        - Logical: AND, OR, NOT
        - Parentheses for grouping
        
    Example:
        >>> expr = parse_where_clause(df, 'age > 18 AND status == "active"')
    """
    # Simple implementation - convert to Polars expression
    # This is a simplified parser - full implementation would use expressions.parser
    
    # Replace SQL-style logical operators with Python/Polars operators
    expr_str = where
    expr_str = expr_str.replace(' AND ', ' & ')
    expr_str = expr_str.replace(' OR ', ' | ')
    expr_str = expr_str.replace(' NOT ', ' ~ ')
    
    # For now, use Polars' SQL context for parsing
    # Create a temporary SQL query and extract the filter
    try:
        # Build namespace with column references
        namespace = {col: pl.col(col) for col in df.columns}
        namespace['pl'] = pl
        
        # Evaluate the expression
        result = eval(expr_str, namespace)
        return result
    except Exception as e:
        raise ValueError(f"Invalid WHERE clause: {where}. Error: {e}")


def select_columns(df: pl.DataFrame, columns: List[str]) -> pl.DataFrame:
    """
    Select specified columns from DataFrame.
    
    Args:
        df: Input DataFrame
        columns: List of column names to select
        
    Returns:
        DataFrame with selected columns
        
    Example:
        >>> result = select_columns(df, ['name', 'age', 'email'])
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    
    if not columns:
        return df
    
    logger.info(f"Selecting {len(columns)} columns")
    
    # Use Polars select directly
    result = df.select(columns)
    
    logger.info(f"Column selection complete")
    
    return result
