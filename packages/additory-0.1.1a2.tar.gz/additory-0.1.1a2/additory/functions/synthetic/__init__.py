"""
Synthetic function - Generate synthetic data.

This module provides the main synthetic function for generating synthetic data
in three modes: augment, create, and preset.
"""

import polars as pl
from typing import Dict, Optional, Union

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.result import wrap_result
from additory.core.backend import detect_backend, to_polars, from_polars
from additory.core.logging import Logger
from additory.functions.synthetic.mode_detector import detect_mode
from additory.functions.synthetic.strategies.generative import generate_data
from additory.functions.synthetic.strategies.augmentative import augment_data
from additory.functions.synthetic.strategies.presets import apply_preset


def synthetic(
    df_or_mode,
    n_rows: Optional[Union[int, str]] = None,
    strategy: Optional[Dict] = None,
    preset: Optional[str] = None,
    **kwargs
):
    """
    Generate synthetic data.
    
    Args:
        df_or_mode: DataFrame (augment mode) or '@new' (create mode)
        n_rows: Number of rows to generate
        strategy: Strategy dictionary
        preset: Preset name
        **kwargs: Mode-specific parameters
        
    Returns:
        DataFrameResult with synthetic data
        
    Modes:
        - augment: Add synthetic rows to existing data
        - create: Create synthetic data from scratch
        - preset: Use preset configuration
        
    Examples:
        >>> # Augment mode
        >>> result = synthetic(df, n_rows=100)
        >>> result = synthetic(df, n_rows="50%")
        
        >>> # Create mode
        >>> result = synthetic('@new', n_rows=100, strategy={
        ...     'id': 'increment:start=1',
        ...     'age': 'range:18-65',
        ...     'status': 'choice:[Active,Inactive,Pending]'
        ... })
        
        >>> # Preset mode
        >>> result = synthetic('@new', n_rows=100, preset='users')
    """
    logger = Logger()
    logger.info("[synthetic] Starting synthetic() function")
    
    try:
        # Detect mode
        mode = detect_mode(df_or_mode, strategy, preset)
        logger.info(f"Mode detected: {mode}")
        
        if mode == 'augment':
            # Validate and convert
            validate_dataframe(df_or_mode)
            validate_not_empty(df_or_mode)
            backend = detect_backend(df_or_mode)
            polars_df = to_polars(df_or_mode)
            
            # Augment
            result = augment_data(polars_df, n_rows, strategy)
            
        elif mode == 'create':
            # Create from scratch
            if not n_rows:
                raise ValueError("n_rows is required for create mode")
            
            result = generate_data(n_rows, strategy)
            backend = 'polars'
            
        elif mode == 'preset':
            # Use preset
            if not n_rows:
                raise ValueError("n_rows is required for preset mode")
            
            result = apply_preset(preset, n_rows)
            backend = 'polars'
        
        else:
            raise ValueError(f"Unknown mode: {mode}")
        
        # Convert back
        result = from_polars(result, backend)
        
        logger.info(f"Output: {len(result)} rows × {len(result.columns) if hasattr(result, 'columns') else 'N/A'} columns")
        logger.info("[synthetic] synthetic() function complete")
        
        # Wrap result
        return wrap_result(result, 'synthetic', metadata={
            'mode': mode,
            'rows_generated': n_rows
        })
        
    except Exception as e:
        logger.error(f"Error in synthetic() function: {e}", error_location="synthetic")
        raise

