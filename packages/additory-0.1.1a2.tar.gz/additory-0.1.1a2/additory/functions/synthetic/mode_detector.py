"""
Mode detection for synthetic data generation.

This module detects which mode to use: augment, create, or preset.
"""

from typing import Optional, Dict
from additory.common.validation import is_dataframe


def detect_mode(df_or_mode, strategy: Optional[Dict], preset: Optional[str]) -> str:
    """
    Detect synthetic data generation mode.
    
    Args:
        df_or_mode: DataFrame (augment mode) or '@new' (create mode)
        strategy: Strategy dictionary
        preset: Preset name
        
    Returns:
        Mode string ('augment', 'create', 'preset')
        
    Raises:
        ValueError: If parameters are invalid
        
    Example:
        >>> mode = detect_mode(df, None, None)  # Returns: 'augment'
        >>> mode = detect_mode('@new', strategy, None)  # Returns: 'create'
        >>> mode = detect_mode('@new', None, 'users')  # Returns: 'preset'
    """
    # Preset mode takes precedence
    if preset is not None:
        return 'preset'
    
    # Check if it's a DataFrame first (augment mode)
    elif is_dataframe(df_or_mode):
        return 'augment'
    
    # Create mode
    elif df_or_mode == '@new':
        return 'create'
    
    else:
        raise ValueError(
            "Invalid parameters for synthetic(). "
            "First parameter must be a DataFrame or '@new'"
        )
