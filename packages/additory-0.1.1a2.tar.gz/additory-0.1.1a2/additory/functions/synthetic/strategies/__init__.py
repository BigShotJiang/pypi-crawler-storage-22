# Synthetic strategies module
