"""
Augment existing data with synthetic rows.

This module provides functionality to add synthetic rows to existing data.
"""

import polars as pl
from typing import Dict, Optional, Union
import numpy as np

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.distributions import generate_normal, generate_uniform
from additory.core.logging import Logger


def augment_data(
    df: pl.DataFrame,
    n_rows: Union[int, str],
    strategy: Optional[Dict] = None
) -> pl.DataFrame:
    """
    Add synthetic rows to existing data.
    
    Args:
        df: Input DataFrame
        n_rows: Number of rows (int or percentage string like '50%')
        strategy: Optional augmentation strategy
        
    Returns:
        DataFrame with original + synthetic rows
        
    Example:
        >>> result = augment_data(df, n_rows=100)  # Add 100 rows
        >>> result = augment_data(df, n_rows="50%")  # Add 50% more rows
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    validate_not_empty(df)
    
    # Parse n_rows
    n_synthetic = parse_n_rows(n_rows, len(df))
    
    logger.info(f"Augmenting {len(df)} rows with {n_synthetic} synthetic rows")
    
    # Generate synthetic rows
    synthetic_df = generate_synthetic_rows(df, n_synthetic, strategy)
    
    # Concatenate
    result = pl.concat([df, synthetic_df])
    
    logger.info(f"Augmentation complete: {len(result)} total rows")
    
    return result


def parse_n_rows(n_rows: Union[int, str], df_len: int) -> int:
    """
    Parse n_rows parameter.
    
    Args:
        n_rows: Number of rows (int or percentage string)
        df_len: Length of DataFrame
        
    Returns:
        Number of rows to generate
        
    Example:
        >>> parse_n_rows(100, 1000)
        100
        >>> parse_n_rows("50%", 1000)
        500
    """
    if isinstance(n_rows, int):
        return n_rows
    
    elif isinstance(n_rows, str) and n_rows.endswith('%'):
        percentage = float(n_rows.rstrip('%'))
        return int(df_len * percentage / 100)
    
    else:
        raise ValueError(f"Invalid n_rows: {n_rows}. Must be int or percentage string")


def generate_synthetic_rows(
    df: pl.DataFrame,
    n_rows: int,
    strategy: Optional[Dict]
) -> pl.DataFrame:
    """
    Generate synthetic rows matching existing data.
    
    Args:
        df: Input DataFrame
        n_rows: Number of rows to generate
        strategy: Optional strategy
        
    Returns:
        DataFrame with synthetic rows
    """
    logger = Logger()
    
    # Generate each column
    columns = {}
    
    for col in df.columns:
        logger.info(f"Generating synthetic column: {col}")
        
        # Get column dtype
        dtype = df[col].dtype
        
        # Generate based on dtype
        if dtype in [pl.Int8, pl.Int16, pl.Int32, pl.Int64,
                     pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64]:
            # Integer column - match distribution
            col_data = df[col].drop_nulls()
            if len(col_data) > 0:
                mean = float(col_data.mean())
                std = float(col_data.std())
                synthetic = generate_normal(n_rows, mean, std).cast(dtype)
                columns[col] = synthetic
            else:
                columns[col] = pl.Series([None] * n_rows, dtype=dtype)
        
        elif dtype in [pl.Float32, pl.Float64]:
            # Float column - match distribution
            col_data = df[col].drop_nulls()
            if len(col_data) > 0:
                mean = float(col_data.mean())
                std = float(col_data.std())
                columns[col] = generate_normal(n_rows, mean, std)
            else:
                columns[col] = pl.Series([None] * n_rows, dtype=dtype)
        
        elif dtype == pl.Utf8:
            # String column - sample from existing values
            col_data = df[col].drop_nulls()
            if len(col_data) > 0:
                values = col_data.to_list()
                synthetic = np.random.choice(values, n_rows)
                columns[col] = pl.Series(synthetic)
            else:
                columns[col] = pl.Series([None] * n_rows, dtype=dtype)
        
        elif dtype == pl.Boolean:
            # Boolean column - match distribution
            col_data = df[col].drop_nulls()
            if len(col_data) > 0:
                true_ratio = float(col_data.sum()) / len(col_data)
                synthetic = np.random.random(n_rows) < true_ratio
                columns[col] = pl.Series(synthetic)
            else:
                columns[col] = pl.Series([None] * n_rows, dtype=dtype)
        
        else:
            # Other types - just use nulls
            columns[col] = pl.Series([None] * n_rows, dtype=dtype)
    
    return pl.DataFrame(columns)
