"""
Generate synthetic data from scratch.

This module provides functionality to create synthetic data using various strategies.
"""

import polars as pl
from typing import Dict, Any
import numpy as np

from additory.common.distributions import (
    generate_normal, generate_uniform, generate_correlated
)
from additory.core.logging import Logger


def generate_data(n_rows: int, strategy: Dict[str, str]) -> pl.DataFrame:
    """
    Generate synthetic data from scratch.
    
    Args:
        n_rows: Number of rows to generate
        strategy: Dictionary mapping column to generation strategy
        
    Returns:
        DataFrame with synthetic data
        
    Example:
        >>> result = generate_data(n_rows=1000, strategy={
        ...     'id': 'increment:start=1',
        ...     'age': 'range:18-65',
        ...     'status': 'choice:[Active,Inactive,Pending]'
        ... })
    """
    logger = Logger()
    logger.info(f"Generating {n_rows} rows with {len(strategy)} columns")
    
    if not strategy:
        raise ValueError("strategy dictionary cannot be empty")
    
    if n_rows <= 0:
        raise ValueError(f"n_rows must be positive, got {n_rows}")
    
    # Generate each column
    columns = {}
    for col_name, strategy_value in strategy.items():
        logger.info(f"Generating column: {col_name}")
        columns[col_name] = generate_column(n_rows, strategy_value)
    
    # Create DataFrame
    result = pl.DataFrame(columns)
    
    logger.info(f"Generated {len(result)} rows × {len(result.columns)} columns")
    
    return result


def generate_column(n_rows: int, strategy_value: str) -> pl.Series:
    """
    Generate a single column based on strategy.
    
    Args:
        n_rows: Number of rows
        strategy_value: Strategy string
        
    Returns:
        Series with generated data
        
    Supported strategies:
        - increment:start=1:step=1
        - range:18-65
        - choice:[A,B,C]
        - normal:mean=50:std=10
        - uniform:low=0:high=100
    """
    # Parse strategy
    strategy_type, params = parse_strategy_value(strategy_value)
    
    # Generate based on type
    if strategy_type == 'increment':
        start = params.get('start', 1)
        step = params.get('step', 1)
        return pl.Series(range(start, start + n_rows * step, step))
    
    elif strategy_type == 'range':
        low, high = params['range']
        return pl.Series(np.random.randint(low, high + 1, n_rows))
    
    elif strategy_type == 'choice':
        choices = params['choices']
        weights = params.get('weights')
        if weights:
            return pl.Series(np.random.choice(choices, n_rows, p=weights))
        else:
            return pl.Series(np.random.choice(choices, n_rows))
    
    elif strategy_type == 'normal':
        mean = params['mean']
        std = params['std']
        return generate_normal(n_rows, mean, std)
    
    elif strategy_type == 'uniform':
        low = params['low']
        high = params['high']
        return generate_uniform(n_rows, low, high)
    
    else:
        raise ValueError(f"Unsupported strategy type: {strategy_type}")


def parse_strategy_value(strategy_value: str) -> tuple[str, Dict[str, Any]]:
    """
    Parse strategy string into type and parameters.
    
    Args:
        strategy_value: Strategy string
        
    Returns:
        Tuple of (strategy_type, parameters)
        
    Examples:
        >>> parse_strategy_value('increment:start=1:step=2')
        ('increment', {'start': 1, 'step': 2})
        
        >>> parse_strategy_value('range:18-65')
        ('range', {'range': (18, 65)})
        
        >>> parse_strategy_value('choice:[A,B,C]')
        ('choice', {'choices': ['A', 'B', 'C']})
    """
    parts = strategy_value.split(':')
    strategy_type = parts[0]
    params = {}
    
    if strategy_type == 'increment':
        for part in parts[1:]:
            if '=' in part:
                key, value = part.split('=')
                params[key] = int(value)
    
    elif strategy_type == 'range':
        if len(parts) > 1:
            range_str = parts[1]
            low, high = map(int, range_str.split('-'))
            params['range'] = (low, high)
    
    elif strategy_type == 'choice':
        if len(parts) > 1:
            choices_str = parts[1]
            # Remove brackets
            choices_str = choices_str.strip('[]')
            # Split by comma
            choices = [c.strip() for c in choices_str.split(',')]
            params['choices'] = choices
    
    elif strategy_type == 'normal':
        for part in parts[1:]:
            if '=' in part:
                key, value = part.split('=')
                params[key] = float(value)
    
    elif strategy_type == 'uniform':
        for part in parts[1:]:
            if '=' in part:
                key, value = part.split('=')
                params[key] = float(value)
    
    return strategy_type, params
