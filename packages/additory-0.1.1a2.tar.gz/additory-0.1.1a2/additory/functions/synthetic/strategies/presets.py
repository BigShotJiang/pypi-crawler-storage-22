"""
Preset configurations for common synthetic data types.

This module provides preset configurations for generating common data types.
"""

import polars as pl
from typing import Dict, List

from additory.functions.synthetic.strategies.generative import generate_data
from additory.core.logging import Logger


# Define presets
PRESETS = {
    'users': {
        'id': 'increment:start=1',
        'age': 'range:18-75',
        'status': 'choice:[Active,Inactive,Pending]',
        'country': 'choice:[USA,UK,Canada,Australia,Germany]'
    },
    'transactions': {
        'transaction_id': 'increment:start=1000',
        'amount': 'uniform:low=10:high=1000',
        'currency': 'choice:[USD,EUR,GBP]',
        'status': 'choice:[completed,pending,failed]'
    },
    'products': {
        'product_id': 'increment:start=1',
        'price': 'uniform:low=5:high=500',
        'stock': 'range:0-1000',
        'category': 'choice:[Electronics,Clothing,Food,Books]'
    },
    'timeseries': {
        'value': 'normal:mean=100:std=20'
    },
    'medical': {
        'patient_id': 'increment:start=1',
        'age': 'range:18-90',
        'weight': 'normal:mean=70:std=15',
        'height': 'normal:mean=170:std=10'
    }
}


def apply_preset(preset_name: str, n_rows: int) -> pl.DataFrame:
    """
    Apply preset configuration.
    
    Args:
        preset_name: Name of preset
        n_rows: Number of rows to generate
        
    Returns:
        DataFrame with synthetic data
        
    Raises:
        ValueError: If preset not found
        
    Example:
        >>> result = apply_preset('users', n_rows=1000)
    """
    logger = Logger()
    
    if preset_name not in PRESETS:
        available = list_presets()
        raise ValueError(
            f"Preset '{preset_name}' not found. "
            f"Available presets: {', '.join(available)}"
        )
    
    logger.info(f"Applying preset: {preset_name}")
    
    # Get preset strategy
    strategy = get_preset_strategy(preset_name)
    
    # Generate data
    result = generate_data(n_rows, strategy)
    
    logger.info(f"Preset '{preset_name}' applied: {len(result)} rows")
    
    return result


def get_preset_strategy(preset_name: str) -> Dict[str, str]:
    """
    Get strategy dictionary for preset.
    
    Args:
        preset_name: Name of preset
        
    Returns:
        Strategy dictionary
        
    Raises:
        ValueError: If preset not found
    """
    if preset_name not in PRESETS:
        raise ValueError(f"Preset '{preset_name}' not found")
    
    return PRESETS[preset_name].copy()


def list_presets() -> List[str]:
    """
    List available presets.
    
    Returns:
        List of preset names
        
    Example:
        >>> presets = list_presets()
        >>> print(presets)
        ['users', 'transactions', 'products', 'timeseries', 'medical']
    """
    return list(PRESETS.keys())
