"""
Main to function - add columns to DataFrame.

This module provides the main user-facing to() function with multiple modes:
- lookup: Add columns from reference DataFrame
- summarize: Group and aggregate data
- merge: Merge multiple DataFrames
- sort: Sort DataFrame
"""

import polars as pl
from typing import Union, List, Optional, Dict, Any

from additory.core.backend import detect_backend, to_polars, from_polars
from additory.core.logging import Logger
from additory.core.memory_manager import MemoryManager
from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.result import wrap_result

from additory.functions.to.lookup import perform_lookup
from additory.functions.to.summarize import perform_summarize
from additory.functions.to.merge import perform_merge
from additory.functions.to.sort import perform_sort


def to(
    df: Any,
    from_df: Optional[Any] = None,
    bring: Optional[Union[str, List[str]]] = None,
    against: Optional[Union[str, List[str]]] = None,
    on: Optional[Union[str, List[str]]] = None,  # Alias for 'against'
    to: Optional[str] = None,
    bring_at: Optional[str] = None,
    strategy: Optional[Dict] = None,
    **kwargs
) -> Any:
    """
    Add columns to DataFrame using various modes.
    
    Args:
        df: Input DataFrame (or list of DataFrames for merge mode)
        from_df: Reference DataFrame (for lookup mode)
        bring: Column(s) to bring (for lookup mode)
        against: Key column(s) for matching (for lookup mode)
        to: Special mode indicator ('@summarize', '@merge', '@sort')
        bring_at: Position to insert columns
        strategy: Strategy dictionary for advanced control
        **kwargs: Mode-specific parameters
        
    Returns:
        DataFrame with added columns (wrapped in Result)
        
    Modes:
        1. Lookup (default): Add columns from reference DataFrame
           - Triggered by: from_df is provided
           - Example: to(df, from_df=products, bring='price', against='product_id')
           
        2. Summarize: Group and aggregate data
           - Triggered by: to='@summarize'
           - Example: to(df, to='@summarize', group_by='category', aggregations={'sales': 'sum'})
           
        3. Merge: Merge multiple DataFrames
           - Triggered by: to='@merge'
           - Example: to([df1, df2, df3], to='@merge')
           
        4. Sort: Sort DataFrame
           - Triggered by: to='@sort'
           - Example: to(df, to='@sort', by='date', descending=True)
    """
    logger = Logger()
    memory_manager = MemoryManager()
    
    # Handle 'on' as alias for 'against'
    if on is not None and against is None:
        against = on
    elif on is not None and against is not None:
        raise ValueError("Cannot specify both 'on' and 'against' parameters")
    
    try:
        # Detect mode
        mode = detect_mode(df, from_df, to, **kwargs)
        logger.set_context('to', {'mode': mode})
        logger.info(f"Starting to() function in '{mode}' mode")
        
        # Handle merge mode specially (df is a list)
        if mode == 'merge':
            # Validate list of DataFrames
            if not isinstance(df, list):
                raise TypeError("For merge mode, df must be a list of DataFrames")
            
            # Detect backend from first DataFrame
            backend = detect_backend(df[0])
            
            # Convert all to Polars
            polars_dfs = [to_polars(d) for d in df]
            
            # Perform merge
            result = perform_merge(polars_dfs, **kwargs)
        
        else:
            # Single DataFrame modes
            # Validate input
            validate_dataframe(df)
            validate_not_empty(df)
            
            # Detect backend and convert to Polars
            backend = detect_backend(df)
            polars_df = to_polars(df)
            
            # Dispatch to appropriate mode
            if mode == 'summarize':
                result = perform_summarize(polars_df, **kwargs)
            elif mode == 'sort':
                result = perform_sort(polars_df, **kwargs)
            elif mode == 'lookup':
                # Convert from_df to Polars
                polars_from_df = to_polars(from_df)
                result = perform_lookup(
                    polars_df,
                    polars_from_df,
                    bring,
                    against,
                    bring_at,
                    strategy
                )
            else:
                raise ValueError(f"Unknown mode: {mode}")
        
        # Convert back to original backend
        result = from_polars(result, backend)
        
        # Cleanup
        memory_manager.cleanup()
        
        # Wrap result
        logger.info(f"to() function complete: {len(result)} rows, {len(result.columns)} columns")
        return wrap_result(result, 'to', metadata={'mode': mode})
    
    except Exception as e:
        logger.error(f"Error in to() function: {str(e)}", error_location="to")
        raise


def detect_mode(
    df: Any,
    from_df: Optional[Any],
    to: Optional[str],
    **kwargs
) -> str:
    """
    Detect which mode to use based on parameters.
    
    Args:
        df: Input DataFrame
        from_df: Reference DataFrame
        to: Mode indicator
        **kwargs: Additional parameters
        
    Returns:
        Mode string ('lookup', 'summarize', 'merge', 'sort')
        
    Raises:
        ValueError: If mode cannot be determined
    """
    # Check for explicit mode indicators
    if to == '@summarize':
        return 'summarize'
    elif to == '@merge':
        return 'merge'
    elif to == '@sort':
        return 'sort'
    
    # Check for lookup mode (from_df provided)
    elif from_df is not None:
        return 'lookup'
    
    # Cannot determine mode
    else:
        raise ValueError(
            "Cannot determine mode. Please provide either:\n"
            "  - from_df (for lookup mode)\n"
            "  - to='@summarize' (for summarize mode)\n"
            "  - to='@merge' (for merge mode)\n"
            "  - to='@sort' (for sort mode)"
        )


__all__ = ['to']
