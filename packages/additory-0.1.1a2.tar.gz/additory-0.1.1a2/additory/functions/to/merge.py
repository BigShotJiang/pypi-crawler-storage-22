"""
Merge multiple DataFrames.

This module provides merging functionality for the to function.
"""

import polars as pl
from typing import List, Union, Optional

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.core.logging import Logger


def perform_merge(
    dfs: List[pl.DataFrame],
    how: str = 'vertical',
    on: Optional[Union[str, List[str]]] = None,
    **kwargs
) -> pl.DataFrame:
    """
    Merge multiple DataFrames.
    
    Args:
        dfs: List of DataFrames to merge
        how: Merge type ('vertical', 'horizontal', 'diagonal')
        on: Key column(s) for horizontal merge (required for horizontal)
        **kwargs: Additional parameters (reserved for future use)
        
    Returns:
        Merged DataFrame
        
    Merge Types:
        - 'vertical' - Stack vertically (union, concat)
        - 'horizontal' - Join horizontally (requires key)
        - 'diagonal' - Diagonal concat (fill missing columns)
        
    Example:
        >>> result = perform_merge([df1, df2, df3], how='vertical')
        >>> result = perform_merge([df1, df2], how='horizontal', on='id')
    """
    logger = Logger()
    
    # Validate parameters
    validate_merge_parameters(dfs, how, on)
    
    # Log operation
    logger.info(f"Merging {len(dfs)} DataFrames using '{how}' method")
    
    # Dispatch to appropriate merge function
    if how == 'vertical':
        result = merge_vertical(dfs)
    elif how == 'horizontal':
        result = merge_horizontal(dfs, on)
    elif how == 'diagonal':
        result = merge_diagonal(dfs)
    else:
        raise ValueError(f"Invalid merge type: {how}")
    
    logger.info(f"Merge complete: {len(result)} rows, {len(result.columns)} columns")
    
    return result


def validate_merge_parameters(
    dfs: List[pl.DataFrame],
    how: str,
    on: Optional[Union[str, List[str]]] = None
) -> None:
    """
    Validate merge parameters.
    
    Args:
        dfs: List of DataFrames to merge
        how: Merge type
        on: Key column(s) for horizontal merge
        
    Raises:
        ValueError: If validation fails
    """
    # Check that dfs is a list
    if not isinstance(dfs, list):
        raise TypeError("dfs must be a list of DataFrames")
    
    # Check that we have at least 2 DataFrames
    if len(dfs) < 2:
        raise ValueError("Must provide at least 2 DataFrames to merge")
    
    # Validate each DataFrame
    for i, df in enumerate(dfs):
        validate_dataframe(df)
        validate_not_empty(df)
    
    # Check that how is valid
    valid_how = ['vertical', 'horizontal', 'diagonal']
    if how not in valid_how:
        raise ValueError(
            f"Invalid merge type: {how}. "
            f"Valid types: {valid_how}"
        )
    
    # For horizontal merge, on is required
    if how == 'horizontal' and on is None:
        raise ValueError("Parameter 'on' is required for horizontal merge")
    
    # For horizontal merge, check that on columns exist in all DataFrames
    if how == 'horizontal' and on is not None:
        on_list = [on] if isinstance(on, str) else on
        for i, df in enumerate(dfs):
            missing_cols = [col for col in on_list if col not in df.columns]
            if missing_cols:
                raise ValueError(
                    f"Key columns not found in DataFrame {i}: {missing_cols}. "
                    f"Available columns: {df.columns}"
                )


def merge_vertical(dfs: List[pl.DataFrame]) -> pl.DataFrame:
    """
    Stack DataFrames vertically.
    
    Args:
        dfs: List of DataFrames to stack
        
    Returns:
        Vertically stacked DataFrame
        
    Note:
        All DataFrames must have the same columns.
    """
    # Check that all DataFrames have the same columns
    first_cols = set(dfs[0].columns)
    for i, df in enumerate(dfs[1:], 1):
        if set(df.columns) != first_cols:
            raise ValueError(
                f"DataFrame {i} has different columns than DataFrame 0. "
                f"For vertical merge, all DataFrames must have the same columns. "
                f"Use 'diagonal' merge to handle different columns."
            )
    
    # Concatenate vertically
    result = pl.concat(dfs, how='vertical')
    
    return result


def merge_horizontal(
    dfs: List[pl.DataFrame],
    on: Union[str, List[str]]
) -> pl.DataFrame:
    """
    Join DataFrames horizontally.
    
    Args:
        dfs: List of DataFrames to join
        on: Key column(s) for joining
        
    Returns:
        Horizontally joined DataFrame
        
    Note:
        Performs left joins sequentially.
    """
    # Start with first DataFrame
    result = dfs[0]
    
    # Join each subsequent DataFrame
    for i, df in enumerate(dfs[1:], 1):
        result = result.join(df, on=on, how='left')
    
    return result


def merge_diagonal(dfs: List[pl.DataFrame]) -> pl.DataFrame:
    """
    Diagonal concat (fill missing columns).
    
    Args:
        dfs: List of DataFrames to concat
        
    Returns:
        Diagonally concatenated DataFrame
        
    Note:
        Missing columns are filled with nulls.
    """
    # Concatenate diagonally (Polars handles missing columns)
    result = pl.concat(dfs, how='diagonal')
    
    return result
