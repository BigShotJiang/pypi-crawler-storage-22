"""
Sort DataFrame.

This module provides sorting functionality for the to function.
"""

import polars as pl
from typing import Union, List

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.core.logging import Logger


def perform_sort(
    df: pl.DataFrame,
    by: Union[str, List[str]],
    descending: Union[bool, List[bool]] = False,
    nulls_last: bool = True
) -> pl.DataFrame:
    """
    Sort DataFrame by specified columns.
    
    Args:
        df: Input DataFrame
        by: Column(s) to sort by
        descending: Sort in descending order (single bool or list per column)
        nulls_last: Place nulls at end
        
    Returns:
        Sorted DataFrame
        
    Example:
        >>> result = perform_sort(df, by='date', descending=True)
        >>> result = perform_sort(df, by=['category', 'price'], 
        ...                       descending=[False, True])
    """
    logger = Logger()
    
    # Validate parameters
    validate_sort_parameters(df, by)
    
    # Normalize by to list
    by_list = [by] if isinstance(by, str) else by
    
    # Normalize descending to list
    if isinstance(descending, bool):
        descending_list = [descending] * len(by_list)
    else:
        descending_list = descending
        if len(descending_list) != len(by_list):
            raise ValueError(
                f"Length of descending ({len(descending_list)}) must match "
                f"length of by ({len(by_list)})"
            )
    
    # Log operation
    logger.info(f"Sorting by {by_list}, descending={descending_list}")
    
    # Perform sort
    result = df.sort(by=by_list, descending=descending_list, nulls_last=nulls_last)
    
    logger.info(f"Sort complete: {len(result)} rows")
    
    return result


def validate_sort_parameters(df: pl.DataFrame, by: Union[str, List[str]]) -> None:
    """
    Validate sort parameters.
    
    Args:
        df: Input DataFrame
        by: Column(s) to sort by
        
    Raises:
        ValueError: If validation fails
    """
    # Validate DataFrame
    validate_dataframe(df)
    validate_not_empty(df)
    
    # Normalize by to list
    by_list = [by] if isinstance(by, str) else by
    
    # Check that all columns exist
    missing_cols = [col for col in by_list if col not in df.columns]
    if missing_cols:
        raise ValueError(
            f"Sort columns not found in DataFrame: {missing_cols}. "
            f"Available columns: {df.columns}"
        )
