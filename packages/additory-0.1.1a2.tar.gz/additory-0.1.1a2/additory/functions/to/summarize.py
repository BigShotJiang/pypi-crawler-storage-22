"""
Group and aggregate data.

This module provides summarization functionality for the to function.
"""

import polars as pl
from typing import Union, List, Dict

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.core.logging import Logger


# Mapping of aggregation names to Polars methods
AGGREGATION_MAP = {
    'sum': 'sum',
    'mean': 'mean',
    'median': 'median',
    'min': 'min',
    'max': 'max',
    'count': 'count',
    'count_unique': 'n_unique',
    'std': 'std',
    'var': 'var',
    'first': 'first',
    'last': 'last',
}


def perform_summarize(
    df: pl.DataFrame,
    group_by: Union[str, List[str]],
    aggregations: Dict[str, str],
    **kwargs
) -> pl.DataFrame:
    """
    Group and aggregate DataFrame.
    
    Args:
        df: Input DataFrame
        group_by: Column(s) to group by
        aggregations: Dictionary mapping column to aggregation function
        **kwargs: Additional parameters (reserved for future use)
        
    Returns:
        Summarized DataFrame
        
    Example:
        >>> result = perform_summarize(
        ...     df,
        ...     group_by='category',
        ...     aggregations={'sales': 'sum', 'orders': 'count', 'price': 'mean'}
        ... )
        
    Supported Aggregations:
        - 'sum', 'mean', 'median', 'min', 'max'
        - 'count', 'count_unique', 'std', 'var'
        - 'first', 'last'
    """
    logger = Logger()
    
    # Validate parameters
    validate_summarize_parameters(df, group_by, aggregations)
    
    # Normalize group_by to list
    group_by_list = [group_by] if isinstance(group_by, str) else group_by
    
    # Log operation
    logger.info(f"Summarizing by {group_by_list}, {len(aggregations)} aggregations")
    
    # Parse aggregation specifications
    agg_exprs = parse_aggregation_spec(aggregations)
    
    # Perform groupby and aggregation
    result = df.group_by(group_by_list).agg(agg_exprs)
    
    logger.info(f"Summarize complete: {len(result)} groups")
    
    return result


def validate_summarize_parameters(
    df: pl.DataFrame,
    group_by: Union[str, List[str]],
    aggregations: Dict[str, str]
) -> None:
    """
    Validate summarize parameters.
    
    Args:
        df: Input DataFrame
        group_by: Column(s) to group by
        aggregations: Dictionary mapping column to aggregation function
        
    Raises:
        ValueError: If validation fails
    """
    # Validate DataFrame
    validate_dataframe(df)
    validate_not_empty(df)
    
    # Normalize group_by to list
    group_by_list = [group_by] if isinstance(group_by, str) else group_by
    
    # Check that group_by columns exist
    missing_cols = [col for col in group_by_list if col not in df.columns]
    if missing_cols:
        raise ValueError(
            f"Group by columns not found in DataFrame: {missing_cols}. "
            f"Available columns: {df.columns}"
        )
    
    # Check that aggregations is not empty
    if not aggregations:
        raise ValueError("Aggregations dictionary cannot be empty")
    
    # Check that aggregation columns exist
    missing_agg_cols = [col for col in aggregations.keys() if col not in df.columns]
    if missing_agg_cols:
        raise ValueError(
            f"Aggregation columns not found in DataFrame: {missing_agg_cols}. "
            f"Available columns: {df.columns}"
        )
    
    # Check that aggregation functions are valid
    invalid_funcs = [
        func for func in aggregations.values() 
        if func not in AGGREGATION_MAP
    ]
    if invalid_funcs:
        raise ValueError(
            f"Invalid aggregation functions: {invalid_funcs}. "
            f"Valid functions: {list(AGGREGATION_MAP.keys())}"
        )


def parse_aggregation_spec(aggregations: Dict[str, str]) -> List[pl.Expr]:
    """
    Parse aggregation specifications into Polars expressions.
    
    Args:
        aggregations: Dictionary mapping column to aggregation function
        
    Returns:
        List of Polars expressions
        
    Example:
        >>> # Input: {'sales': 'sum', 'orders': 'count'}
        >>> # Output: [pl.col('sales').sum(), pl.col('orders').count()]
    """
    exprs = []
    
    for col, func in aggregations.items():
        # Get the Polars method name
        polars_method = AGGREGATION_MAP[func]
        
        # Create expression
        if polars_method == 'n_unique':
            # Special case for count_unique
            expr = pl.col(col).n_unique()
        elif polars_method == 'count':
            # For count, we count non-null values
            expr = pl.col(col).count()
        else:
            # Standard aggregation
            expr = getattr(pl.col(col), polars_method)()
        
        exprs.append(expr)
    
    return exprs
