"""
Main transform function - transform DataFrame structure.

This module provides the main user-facing transform() function with 6 modes:
- transpose: Transpose DataFrame (rows ↔ columns)
- onehotencoding: One-hot encode categorical columns
- extract: Extract features from columns
- datetime: Normalize datetime columns
- harmonize: Harmonize units across columns
- knn: Impute missing values using KNN
"""

import polars as pl
from typing import Any, Optional, Dict, List, Union

from additory.core.backend import detect_backend, to_polars, from_polars
from additory.core.logging import Logger
from additory.core.memory_manager import MemoryManager
from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.result import wrap_result

from additory.functions.transform.transpose import perform_transpose
from additory.functions.transform.onehotencoding import perform_onehotencoding
from additory.functions.transform.extract import perform_extract
from additory.functions.transform.datetime import perform_datetime_normalization
from additory.functions.transform.harmonize import perform_harmonize
from additory.functions.transform.knn import perform_knn_imputation


def transform(
    df: Any,
    mode: str,
    columns: Optional[Union[str, List[str], Dict]] = None,
    strategy: Optional[Dict] = None,
    **kwargs
) -> Any:
    """
    Transform DataFrame structure using various modes.
    
    Args:
        df: Input DataFrame
        mode: Transformation mode
        columns: Columns to transform (mode-specific)
        strategy: Strategy dictionary for advanced control
        **kwargs: Mode-specific parameters
        
    Returns:
        Transformed DataFrame (wrapped in Result)
        
    Modes:
        1. transpose: Transpose DataFrame (rows ↔ columns)
           - Example: transform(df, mode='transpose')
           
        2. onehotencoding: One-hot encode categorical columns
           - Example: transform(df, mode='onehotencoding', columns=['category'])
           
        3. extract: Extract features from columns
           - Example: transform(df, mode='extract', columns={'date': ['hour', 'day']})
           
        4. datetime: Normalize datetime columns
           - Example: transform(df, mode='datetime', columns=['birth_date'], strategy={...})
           
        5. harmonize: Harmonize units across columns
           - Example: transform(df, mode='harmonize', columns=['height'], strategy={...})
           
        6. knn: Impute missing values using KNN
           - Example: transform(df, mode='knn', columns=['age'], strategy={'k': 5})
    """
    logger = Logger()
    memory_manager = MemoryManager()
    
    try:
        # Validate input
        validate_dataframe(df)
        validate_not_empty(df)
        
        # Detect backend and convert to Polars
        backend = detect_backend(df)
        polars_df = to_polars(df)
        
        # Set logging context
        logger.set_context('transform', {'mode': mode})
        logger.info(f"Starting transform() function in '{mode}' mode")
        
        # Dispatch to appropriate mode
        if mode == 'transpose':
            result = perform_transpose(polars_df)
        
        elif mode == 'onehotencoding':
            if columns is None:
                raise ValueError("columns parameter required for onehotencoding mode")
            result = perform_onehotencoding(polars_df, columns)
        
        elif mode == 'extract':
            if columns is None:
                raise ValueError("columns parameter required for extract mode")
            if not isinstance(columns, dict):
                raise TypeError("columns must be a dictionary for extract mode")
            result = perform_extract(polars_df, columns, strategy)
        
        elif mode == 'datetime':
            if columns is None:
                raise ValueError("columns parameter required for datetime mode")
            columns_list = [columns] if isinstance(columns, str) else columns
            result = perform_datetime_normalization(polars_df, columns_list, strategy)
        
        elif mode == 'harmonize':
            if columns is None:
                raise ValueError("columns parameter required for harmonize mode")
            columns_list = [columns] if isinstance(columns, str) else columns
            result = perform_harmonize(polars_df, columns_list, strategy)
        
        elif mode == 'knn':
            if columns is None:
                raise ValueError("columns parameter required for knn mode")
            columns_list = [columns] if isinstance(columns, str) else columns
            result = perform_knn_imputation(polars_df, columns_list, strategy)
        
        else:
            raise ValueError(
                f"Unknown mode: {mode}. "
                f"Valid modes: transpose, onehotencoding, extract, datetime, harmonize, knn"
            )
        
        # Convert back to original backend
        result = from_polars(result, backend)
        
        # Cleanup
        memory_manager.cleanup()
        
        # Wrap result
        logger.info(f"transform() function complete: {len(result)} rows, {len(result.columns)} columns")
        return wrap_result(result, 'transform', metadata={'mode': mode})
    
    except Exception as e:
        logger.error(f"Error in transform() function: {str(e)}", error_location="transform")
        raise


__all__ = ['transform']
