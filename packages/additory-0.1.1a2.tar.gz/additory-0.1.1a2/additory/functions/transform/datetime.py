"""
Normalize datetime columns.

This module provides datetime normalization functionality for the transform function.
"""

import polars as pl
from typing import List, Dict, Optional

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.core.logging import Logger


def perform_datetime_normalization(
    df: pl.DataFrame,
    columns: List[str],
    strategy: Optional[Dict] = None
) -> pl.DataFrame:
    """
    Normalize datetime columns.
    
    Args:
        df: Input DataFrame
        columns: Columns to normalize
        strategy: Normalization strategy per column
        
    Returns:
        DataFrame with normalized datetime columns
        
    Example:
        >>> result = perform_datetime_normalization(df, 
        ...     columns=['birth_date'],
        ...     strategy={
        ...         'birth_date': {
        ...             'format': '%Y-%m-%d',
        ...             'output_format': '%d-%b-%Y'
        ...         }
        ...     })
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    validate_not_empty(df)
    
    if not columns:
        raise ValueError("columns list cannot be empty")
    
    # Validate columns exist
    missing = [col for col in columns if col not in df.columns]
    if missing:
        raise ValueError(f"Columns not found: {missing}")
    
    logger.info(f"Normalizing {len(columns)} datetime columns")
    
    result = df
    strategy = strategy or {}
    
    # Normalize each column
    for col in columns:
        col_strategy = strategy.get(col, {})
        
        # Parse datetime if string
        if result[col].dtype == pl.Utf8:
            fmt = col_strategy.get('format', '%Y-%m-%d')
            result = result.with_columns(
                pl.col(col).str.strptime(pl.Datetime, fmt, strict=False).alias(col)
            )
        
        # Convert to desired output format if specified
        output_fmt = col_strategy.get('output_format')
        if output_fmt:
            result = result.with_columns(
                pl.col(col).dt.strftime(output_fmt).alias(col)
            )
    
    logger.info(f"Datetime normalization complete")
    
    return result
