"""
Extract features from columns.

This module provides feature extraction functionality for the transform function.
"""

import polars as pl
from typing import Dict, Optional

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.extractors import (
    extract_datetime_features,
    extract_email_features,
    extract_text_features
)
from additory.core.logging import Logger


def perform_extract(
    df: pl.DataFrame,
    columns: Dict[str, list],
    strategy: Optional[Dict] = None
) -> pl.DataFrame:
    """
    Extract features from columns.
    
    Args:
        df: Input DataFrame
        columns: Dictionary mapping column to features to extract
        strategy: Optional strategy for extraction
        
    Returns:
        DataFrame with extracted features
        
    Example:
        >>> result = perform_extract(df, columns={
        ...     'timestamp': ['hour', 'day_of_week', 'quarter'],
        ...     'email': ['domain'],
        ...     'tags': ['split']
        ... })
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    validate_not_empty(df)
    
    if not columns:
        raise ValueError("columns dictionary cannot be empty")
    
    logger.info(f"Extracting features from {len(columns)} columns")
    
    result = df
    
    # Extract features from each column
    for col, features in columns.items():
        if col not in df.columns:
            raise ValueError(f"Column not found: {col}")
        
        # Determine column type and extract accordingly
        col_dtype = df[col].dtype
        
        extracted_features = {}
        
        if col_dtype in [pl.Datetime, pl.Date]:
            # Datetime extraction
            extracted_features = extract_datetime_features(df[col], features)
        elif col_dtype == pl.Utf8:
            # Check if it's email or text
            if 'domain' in features or 'username' in features:
                extracted_features = extract_email_features(df[col], features)
            else:
                extracted_features = extract_text_features(df[col], features)
        else:
            logger.warning(f"Unsupported column type for extraction: {col_dtype}")
            continue
        
        # Add extracted features as new columns
        for feature_name, feature_series in extracted_features.items():
            new_col_name = f"{col}_{feature_name}"
            result = result.with_columns(feature_series.alias(new_col_name))
    
    logger.info(f"Feature extraction complete: {len(result.columns)} columns")
    
    return result
