"""
Harmonize units across columns.

This module provides unit harmonization functionality for the transform function.
"""

import polars as pl
from typing import List, Dict, Optional

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.unit_conversions import (
    convert_weight, convert_temperature, convert_distance,
    convert_currency, convert_volume, convert_time, detect_unit_type
)
from additory.core.logging import Logger


def perform_harmonize(
    df: pl.DataFrame,
    columns: List[str],
    strategy: Optional[Dict] = None
) -> pl.DataFrame:
    """
    Harmonize units across columns.
    
    Args:
        df: Input DataFrame
        columns: Columns to harmonize
        strategy: Harmonization strategy per column
        
    Returns:
        DataFrame with harmonized units
        
    Example:
        >>> result = perform_harmonize(df,
        ...     columns=['height', 'weight'],
        ...     strategy={
        ...         'height': {'from': 'cm', 'to': 'm'},
        ...         'weight': {'from': 'lb', 'to': 'kg'}
        ...     })
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    validate_not_empty(df)
    
    if not columns:
        raise ValueError("columns list cannot be empty")
    
    # Validate columns exist
    missing = [col for col in columns if col not in df.columns]
    if missing:
        raise ValueError(f"Columns not found: {missing}")
    
    if not strategy:
        raise ValueError("strategy is required for harmonization")
    
    logger.info(f"Harmonizing {len(columns)} columns")
    
    result = df
    
    # Harmonize each column
    for col in columns:
        if col not in strategy:
            logger.warning(f"No strategy provided for column: {col}")
            continue
        
        col_strategy = strategy[col]
        from_unit = col_strategy.get('from')
        to_unit = col_strategy.get('to')
        
        if not from_unit or not to_unit:
            raise ValueError(f"Both 'from' and 'to' units required for column: {col}")
        
        # Detect unit type
        unit_type = detect_unit_type(from_unit)
        
        # Select appropriate conversion function
        if unit_type == 'weight':
            converter = convert_weight
        elif unit_type == 'temperature':
            converter = convert_temperature
        elif unit_type == 'distance':
            converter = convert_distance
        elif unit_type == 'currency':
            converter = convert_currency
        elif unit_type == 'volume':
            converter = convert_volume
        elif unit_type == 'time':
            converter = convert_time
        else:
            raise ValueError(f"Unsupported unit type: {unit_type}")
        
        # Convert units using map_elements
        result = result.with_columns(
            pl.col(col).map_elements(
                lambda x: converter(x, from_unit, to_unit) if x is not None else None,
                return_dtype=pl.Float64
            ).alias(col)
        )
    
    logger.info(f"Unit harmonization complete")
    
    return result
