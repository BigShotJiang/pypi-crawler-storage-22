"""
KNN imputation for missing values.

This module provides KNN imputation functionality for the transform function.
"""

import polars as pl
from typing import List, Optional, Dict

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.knn_imputation import knn_impute
from additory.core.logging import Logger


def perform_knn_imputation(
    df: pl.DataFrame,
    columns: List[str],
    strategy: Optional[Dict] = None
) -> pl.DataFrame:
    """
    Impute missing values using KNN.
    
    Args:
        df: Input DataFrame
        columns: Columns to impute
        strategy: Imputation strategy (k, weights, etc.)
        
    Returns:
        DataFrame with imputed values
        
    Example:
        >>> result = perform_knn_imputation(df,
        ...     columns=['age', 'income'],
        ...     strategy={'k': 5, 'weights': 'distance'})
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    validate_not_empty(df)
    
    if not columns:
        raise ValueError("columns list cannot be empty")
    
    # Validate columns exist
    missing = [col for col in columns if col not in df.columns]
    if missing:
        raise ValueError(f"Columns not found: {missing}")
    
    logger.info(f"Performing KNN imputation on {len(columns)} columns")
    
    strategy = strategy or {}
    k = strategy.get('k', 5)
    weights = strategy.get('weights', 'uniform')
    metric = strategy.get('metric', 'euclidean')
    
    # Perform KNN imputation
    result = knn_impute(df, columns, k=k, weights=weights, metric=metric)
    
    logger.info(f"KNN imputation complete")
    
    return result
