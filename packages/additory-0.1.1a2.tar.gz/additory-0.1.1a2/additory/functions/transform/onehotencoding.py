"""
One-hot encode categorical columns.

This module provides one-hot encoding functionality for the transform function.
"""

import polars as pl
from typing import List, Union

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.core.logging import Logger


def perform_onehotencoding(
    df: pl.DataFrame,
    columns: Union[str, List[str]]
) -> pl.DataFrame:
    """
    One-hot encode categorical columns.
    
    Args:
        df: Input DataFrame
        columns: Column(s) to encode
        
    Returns:
        DataFrame with one-hot encoded columns
        
    Example:
        >>> # Before: ['category'] = ['A', 'B', 'C']
        >>> # After: ['category_A', 'category_B', 'category_C'] = [1, 0, 0]
        >>> result = perform_onehotencoding(df, columns=['category'])
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    validate_not_empty(df)
    
    # Normalize to list
    columns_list = [columns] if isinstance(columns, str) else columns
    
    # Validate columns exist
    missing = [col for col in columns_list if col not in df.columns]
    if missing:
        raise ValueError(f"Columns not found: {missing}")
    
    logger.info(f"One-hot encoding {len(columns_list)} columns")
    
    result = df
    
    # Encode each column
    for col in columns_list:
        # Get unique values
        unique_vals = df[col].unique().drop_nulls().sort().to_list()
        
        # Create binary columns for each unique value
        for val in unique_vals:
            new_col_name = f"{col}_{val}"
            result = result.with_columns(
                (pl.col(col) == val).cast(pl.Int8).alias(new_col_name)
            )
        
        # Drop original column
        result = result.drop(col)
    
    logger.info(f"One-hot encoding complete: {len(result.columns)} columns")
    
    return result
