"""
Transpose DataFrame (rows ↔ columns).

This module provides transpose functionality for the transform function.
"""

import polars as pl
from additory.common.validation import validate_dataframe, validate_not_empty
from additory.core.logging import Logger


def perform_transpose(df: pl.DataFrame) -> pl.DataFrame:
    """
    Transpose DataFrame (swap rows and columns).
    
    Args:
        df: Input DataFrame
        
    Returns:
        Transposed DataFrame
        
    Example:
        >>> # Before: 3 rows × 4 columns
        >>> # After: 4 rows × 3 columns
        >>> result = perform_transpose(df)
    """
    logger = Logger()
    
    # Validate
    validate_dataframe(df)
    validate_not_empty(df)
    
    logger.info(f"Transposing DataFrame: {df.shape[0]} rows × {df.shape[1]} columns")
    
    # Transpose using Polars
    # The transpose method in Polars swaps rows and columns
    # include_header=True keeps the original column names as the first column
    result = df.transpose(include_header=True, header_name='column')
    
    logger.info(f"Transpose complete: {result.shape[0]} rows × {result.shape[1]} columns")
    
    return result
