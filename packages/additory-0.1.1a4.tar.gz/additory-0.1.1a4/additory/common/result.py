"""
Result wrapper classes for Additory operations.

Provides DataFrameResult and AnalysisResult classes that wrap
operation results with metadata and helper methods.
"""

from typing import Any, Dict, List, Optional
import polars as pl
import json
import time


class DataFrameResult:
    """
    Enhanced DataFrame wrapper with metadata and helper methods.
    
    Used by: to, transform, snapshot, synthetic, expressions functions
    
    Attributes:
        df: Polars DataFrame (the actual result)
        metadata: Dictionary of operation metadata
        operation: Operation name ('to', 'transform', 'snapshot', 'synthetic')
        input_shape: Original DataFrame shape
        output_shape: Result DataFrame shape
        columns_added: List of columns added
        columns_removed: List of columns removed
        execution_time: Time taken for operation
    """
    
    def __init__(self, df: pl.DataFrame, operation: str, metadata: Dict[str, Any]):
        """
        Initialize result wrapper.
        
        Args:
            df: Result DataFrame
            operation: Operation name
            metadata: Operation metadata
        """
        self.df = df
        self.operation = operation
        self.metadata = metadata
        
        # Extract common metadata
        self.input_shape = metadata.get('input_shape', (0, 0))
        
        # Get shape in a backend-agnostic way
        # Note: hasattr() doesn't work reliably with pandas due to __getattr__ magic
        # so we use try-except instead
        try:
            # Try Polars attributes first
            self.output_shape = (df.height, df.width)
        except (AttributeError, TypeError):
            # Fall back to pandas shape attribute
            try:
                self.output_shape = df.shape
            except (AttributeError, TypeError):
                self.output_shape = (0, 0)
            
        self.columns_added = metadata.get('columns_added', [])
        self.columns_removed = metadata.get('columns_removed', [])
        self.execution_time = metadata.get('execution_time', 0.0)
    
    def info(self) -> Dict[str, Any]:
        """
        Get summary information about the result.
        
        Returns:
            Dictionary with shape, columns, operation info
            
        Example:
            result = add.to(df, ...)
            print(result.info())
            # {'operation': 'to', 'rows': 1000, 'columns': 15, ...}
        """
        return {
            'operation': self.operation,
            'rows': self.output_shape[0],
            'columns': self.output_shape[1],
            'columns_added': self.columns_added,
            'columns_removed': self.columns_removed,
            'execution_time': self.execution_time,
            'input_shape': self.input_shape,
            'output_shape': self.output_shape,
            'metadata': self.metadata
        }
    
    def summary(self) -> str:
        """
        Get human-readable summary of the operation.
        
        Returns:
            Formatted string summary
            
        Example:
            result = add.to(df, ...)
            print(result.summary())
            # "Added 1 column (price) to 1000 rows in 0.05s"
        """
        parts = []
        
        # Operation name
        parts.append(f"Operation: add.{self.operation}()")
        
        # Columns added
        if self.columns_added:
            cols_str = ', '.join(self.columns_added)
            parts.append(f"Added {len(self.columns_added)} column(s): {cols_str}")
        
        # Columns removed
        if self.columns_removed:
            cols_str = ', '.join(self.columns_removed)
            parts.append(f"Removed {len(self.columns_removed)} column(s): {cols_str}")
        
        # Shape change
        if self.input_shape != self.output_shape:
            parts.append(
                f"Shape: {self.input_shape[0]}x{self.input_shape[1]} → "
                f"{self.output_shape[0]}x{self.output_shape[1]}"
            )
        
        # Execution time
        parts.append(f"Time: {self.execution_time:.3f}s")
        
        return '\n'.join(parts)
    
    def explain(self) -> str:
        """
        Get detailed explanation of what happened.
        
        Returns:
            Detailed explanation string
            
        Example:
            result = add.to(df, ...)
            print(result.explain())
            # "Operation: add.to()
            #  - Looked up 'price' from reference DataFrame
            #  - Matched on 'product_id' (1000 matches)
            #  - Used 'fetch if unique' mode
            #  - Added column at position 'after:product_id'"
        """
        lines = [f"Operation: add.{self.operation}()"]
        
        # Add metadata details
        for key, value in self.metadata.items():
            if key not in ['input_shape', 'execution_time', 'columns_added', 'columns_removed']:
                lines.append(f" - {key}: {value}")
        
        # Add summary info
        if self.columns_added:
            lines.append(f" - Added columns: {', '.join(self.columns_added)}")
        if self.columns_removed:
            lines.append(f" - Removed columns: {', '.join(self.columns_removed)}")
        
        lines.append(f" - Execution time: {self.execution_time:.3f}s")
        
        return '\n'.join(lines)
    
    def to_polars(self) -> pl.DataFrame:
        """
        Get the underlying Polars DataFrame.
        
        Returns:
            Polars DataFrame
        """
        return self.df
    
    def to_pandas(self):
        """
        Convert result to pandas DataFrame.
        
        Returns:
            pandas DataFrame
        """
        return self.df.to_pandas()
    
    def to_arrow(self):
        """
        Convert result to Arrow Table.
        
        Returns:
            Arrow Table
        """
        return self.df.to_arrow()
    
    def __repr__(self) -> str:
        """String representation of result."""
        return (
            f"DataFrameResult(operation='{self.operation}', "
            f"shape={self.output_shape}, "
            f"columns_added={len(self.columns_added)}, "
            f"columns_removed={len(self.columns_removed)})"
        )
    
    def __getattr__(self, name: str) -> Any:
        """
        Delegate attribute access to underlying DataFrame.
        
        Args:
            name: Attribute name
            
        Returns:
            Attribute from DataFrame
            
        Example:
            result = add.to(df, ...)
            result.select(['name', 'age'])  # Delegates to df.select()
        """
        # Avoid infinite recursion for special attributes
        if name in ['df', 'operation', 'metadata', 'input_shape', 'output_shape',
                    'columns_added', 'columns_removed', 'execution_time']:
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
        
        # Delegate to underlying DataFrame
        return getattr(self.df, name)


class AnalysisResult:
    """
    Special result wrapper for analyze() function.
    
    Used by: analyze function
    
    Attributes:
        quality: Quality analysis results
        cardinality: Cardinality analysis results
        distributions: Distribution analysis results
        correlations: Correlation analysis results
        features: Feature analysis results
        types: Type analysis results
        patterns: Pattern analysis results
        outliers: Outlier analysis results
        duplicates: Duplicate analysis results
        timeseries: Time series analysis results (if applicable)
        imputation: Imputation recommendations
        metadata: Analysis metadata
    """
    
    def __init__(self, analyses: Dict[str, Any], metadata: Dict[str, Any]):
        """
        Initialize analysis result.
        
        Args:
            analyses: Dictionary of analysis results
            metadata: Analysis metadata
        """
        self.metadata = metadata
        
        # Store individual analysis results
        self.quality = analyses.get('quality')
        self.cardinality = analyses.get('cardinality')
        self.distributions = analyses.get('distributions')
        self.correlations = analyses.get('correlations')
        self.features = analyses.get('features')
        self.types = analyses.get('types')
        self.patterns = analyses.get('patterns')
        self.outliers = analyses.get('outliers')
        self.duplicates = analyses.get('duplicates')
        self.timeseries = analyses.get('timeseries')
        self.imputation = analyses.get('imputation')
        
        # Store all analyses
        self._analyses = analyses
    
    def summary(self) -> str:
        """
        Get summary of all analyses.
        
        Returns:
            Formatted summary string
        """
        lines = ["Analysis Summary"]
        lines.append("=" * 50)
        
        # Count available analyses
        available = [k for k, v in self._analyses.items() if v is not None]
        lines.append(f"Analyses performed: {len(available)}")
        lines.append("")
        
        # Summarize each analysis
        for analysis_name in available:
            result = self._analyses[analysis_name]
            lines.append(f"{analysis_name.upper()}:")
            
            if isinstance(result, dict):
                for key, value in result.items():
                    if isinstance(value, (int, float, str, bool)):
                        lines.append(f"  {key}: {value}")
                    elif isinstance(value, list):
                        lines.append(f"  {key}: {len(value)} items")
                    elif isinstance(value, pl.DataFrame):
                        lines.append(f"  {key}: DataFrame ({value.height}x{value.width})")
            else:
                lines.append(f"  {result}")
            
            lines.append("")
        
        # Add metadata
        if self.metadata:
            lines.append("METADATA:")
            for key, value in self.metadata.items():
                lines.append(f"  {key}: {value}")
        
        return '\n'.join(lines)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert all results to dictionary.
        
        Returns:
            Dictionary of all analysis results
        """
        result = {}
        
        for key, value in self._analyses.items():
            if value is None:
                continue
            
            # Convert DataFrames to dictionaries
            if isinstance(value, pl.DataFrame):
                result[key] = value.to_dict()
            elif isinstance(value, dict):
                # Recursively convert nested DataFrames
                result[key] = {}
                for k, v in value.items():
                    if isinstance(v, pl.DataFrame):
                        result[key][k] = v.to_dict()
                    else:
                        result[key][k] = v
            else:
                result[key] = value
        
        # Add metadata
        result['metadata'] = self.metadata
        
        return result
    
    def to_json(self) -> str:
        """
        Convert all results to JSON.
        
        Returns:
            JSON string
        """
        return json.dumps(self.to_dict(), indent=2, default=str)
    
    def __repr__(self) -> str:
        """String representation."""
        available = [k for k, v in self._analyses.items() if v is not None]
        return f"AnalysisResult(analyses={len(available)})"


def wrap_result(df: pl.DataFrame, operation: str, metadata: Dict[str, Any]) -> DataFrameResult:
    """
    Convenience function to wrap DataFrame as result.
    
    Called by: to, transform, snapshot, synthetic, expressions functions
    
    Args:
        df: DataFrame to wrap
        operation: Operation name
        metadata: Operation metadata
        
    Returns:
        DataFrameResult instance
        
    Example:
        result = wrap_result(df, 'to', {'columns_added': ['price']})
    """
    return DataFrameResult(df, operation, metadata)


def wrap_analysis(analyses: Dict[str, Any], metadata: Dict[str, Any]) -> AnalysisResult:
    """
    Convenience function to wrap analysis results.
    
    Called by: analyze function
    
    Args:
        analyses: Dictionary of analysis results
        metadata: Analysis metadata
        
    Returns:
        AnalysisResult instance
        
    Example:
        result = wrap_analysis(
            {'quality': {...}, 'cardinality': {...}},
            {'execution_time': 0.5}
        )
    """
    return AnalysisResult(analyses, metadata)
