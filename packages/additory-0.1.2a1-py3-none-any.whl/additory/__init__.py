"""
Additory v0.1.2 - Data Augmentation Library

A Polars-first data augmentation library with 6 main functions:
- to: Add columns from other DataFrames
- transform: Transform columns (transpose, encode, extract, etc.)
- snapshot: Filter and select data
- synthetic: Generate synthetic data
- analyze: Analyze data quality and patterns
- expressions: Evaluate expressions and add computed columns

Usage:
    # Recommended: Import as 'add' for clean syntax
    import additory as add
    
    # Add columns
    result = add.to(df, bring_from=reference_df, against='id', bring='price')
    
    # Transform columns
    result = add.transform(df, mode='onehotencoding', columns=['category'])
    
    # Filter data
    result = add.snapshot(df, where='age > 18')
    
    # Generate synthetic data
    result = add.synthetic(df, n_rows=1000)
    
    # Analyze data
    result = add.analyze(df, preset='quick')
    
    # Evaluate expressions
    result = add.expressions(df, 'inbuilt:bmi', 'age * 12')
    
    # Alternative: Use full module name
    import additory
    result = additory.to(df, bring_from=reference_df, against='id', bring='price')
"""

# Import main functions
from additory.functions.to import to
from additory.functions.transform import transform
from additory.functions.snapshot import snapshot
from additory.functions.synthetic import synthetic
from additory.functions.analyze import analyze
from additory.functions.expressions import expressions

# Import configuration functions
from additory.core.config import set_expressions_folder, set_default_backend

# Version
__version__ = "0.1.2"

# Public API
__all__ = [
    'to', 'transform', 'snapshot', 'synthetic', 'analyze', 'expressions',
    'set_expressions_folder', 'set_default_backend',
    '__version__'
]
