"""
Input validation utilities for Additory.

Provides consistent validation across all functions with clear error messages.
"""

import re
from typing import Any, Callable, List


def is_dataframe(df: Any) -> bool:
    """
    Check if input is a DataFrame (pandas/polars).
    
    Args:
        df: Input to check
        
    Returns:
        True if input is a DataFrame, False otherwise
        
    Example:
        >>> is_dataframe(pl.DataFrame({'a': [1, 2, 3]}))
        True
        >>> is_dataframe([1, 2, 3])
        False
    """
    # Check for polars DataFrame
    try:
        import polars as pl
        if isinstance(df, pl.DataFrame):
            return True
    except ImportError:
        pass
    
    # Check for pandas DataFrame
    try:
        import pandas as pd
        if isinstance(df, pd.DataFrame):
            return True
    except ImportError:
        pass
    
    return False


def validate_dataframe(df: Any, param_name: str = 'df') -> Any:
    """
    Validate that input is a DataFrame (pandas/polars).
    
    Args:
        df: Input to validate
        param_name: Parameter name for error messages
        
    Returns:
        Input df if valid
        
    Raises:
        TypeError: If input is not a DataFrame
        
    Example:
        df = validate_dataframe(df, 'df')
    """
    # Check for polars DataFrame
    try:
        import polars as pl
        if isinstance(df, pl.DataFrame):
            return df
    except ImportError:
        pass
    
    # Check for pandas DataFrame
    try:
        import pandas as pd
        if isinstance(df, pd.DataFrame):
            return df
    except ImportError:
        pass
    
    # If we get here, it's not a valid DataFrame
    raise TypeError(
        f"Parameter '{param_name}' must be a DataFrame "
        f"(pandas or polars), got {type(df).__name__}"
    )


def validate_not_empty(df: Any, param_name: str = 'df') -> bool:
    """
    Validate that DataFrame is not empty.
    
    Args:
        df: DataFrame to check
        param_name: Parameter name for error messages
        
    Returns:
        True if not empty
        
    Raises:
        ValueError: If DataFrame is empty
    """
    # Check row count (works for pandas, polars)
    if hasattr(df, 'shape'):
        if df.shape[0] == 0:
            raise ValueError(f"Parameter '{param_name}' cannot be empty (0 rows)")
    elif hasattr(df, '__len__'):
        if len(df) == 0:
            raise ValueError(f"Parameter '{param_name}' cannot be empty (0 rows)")
    
    return True


def validate_column_name(name: str) -> bool:
    """
    Validate that column name is valid.
    
    Args:
        name: Column name to validate
        
    Returns:
        True if valid
        
    Raises:
        ValueError: If column name is invalid
        
    Rules:
        - Not empty
        - No leading/trailing whitespace
        - No special characters except underscore
        - Not a reserved keyword
    """
    if not name:
        raise ValueError("Column name cannot be empty")
    
    if name != name.strip():
        raise ValueError(f"Column name '{name}' has leading/trailing whitespace")
    
    # Check for valid characters (alphanumeric and underscore only)
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name):
        raise ValueError(
            f"Column name '{name}' contains invalid characters. "
            "Only alphanumeric and underscore allowed, must start with letter or underscore"
        )
    
    # Check for reserved keywords (Python keywords)
    reserved = [
        'and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del',
        'elif', 'else', 'except', 'False', 'finally', 'for', 'from', 'global',
        'if', 'import', 'in', 'is', 'lambda', 'None', 'nonlocal', 'not', 'or',
        'pass', 'raise', 'return', 'True', 'try', 'while', 'with', 'yield'
    ]
    if name in reserved:
        raise ValueError(f"Column name '{name}' is a reserved keyword")
    
    return True


def validate_positive_integer(value: int, param_name: str) -> bool:
    """
    Validate that value is a positive integer.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        
    Returns:
        True if valid
        
    Raises:
        TypeError: If value is not an integer
        ValueError: If value is not positive
    """
    if not isinstance(value, int):
        raise TypeError(f"Parameter '{param_name}' must be an integer, got {type(value).__name__}")
    
    if value <= 0:
        raise ValueError(f"Parameter '{param_name}' must be positive, got {value}")
    
    return True


def validate_percentage(value: str) -> bool:
    """
    Validate that value is a valid percentage string.
    
    Args:
        value: Percentage string to validate (e.g., '50%')
        
    Returns:
        True if valid
        
    Raises:
        ValueError: If percentage is invalid
        
    Example:
        validate_percentage('50%')   # True
        validate_percentage('150%')  # True
        validate_percentage('abc')   # Raises ValueError
    """
    if not isinstance(value, str):
        raise ValueError(f"Percentage must be a string, got {type(value).__name__}")
    
    if not value.endswith('%'):
        raise ValueError(f"Percentage must end with '%', got '{value}'")
    
    # Extract numeric part
    numeric_part = value[:-1].strip()
    
    try:
        percent = float(numeric_part)
    except ValueError:
        raise ValueError(f"Invalid percentage value: '{value}'")
    
    if percent < 0:
        raise ValueError(f"Percentage cannot be negative, got '{value}'")
    
    return True


def validate_mode(mode: str, allowed_modes: List[str], param_name: str = 'mode') -> bool:
    """
    Validate that mode is in allowed list.
    
    Args:
        mode: Mode to validate
        allowed_modes: List of allowed modes
        param_name: Parameter name for error messages
        
    Returns:
        True if valid
        
    Raises:
        ValueError: If mode is not in allowed list
        
    Example:
        validate_mode('transpose', ['transpose', 'onehotencoding', 'extract'])
    """
    if mode not in allowed_modes:
        raise ValueError(
            f"Invalid {param_name} '{mode}'. "
            f"Must be one of: {', '.join(allowed_modes)}"
        )
    
    return True


def validate_dict(value: Any, param_name: str) -> bool:
    """
    Validate that value is a dictionary.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        
    Returns:
        True if valid
        
    Raises:
        TypeError: If value is not a dictionary
    """
    if not isinstance(value, dict):
        raise TypeError(
            f"Parameter '{param_name}' must be a dictionary, got {type(value).__name__}"
        )
    
    return True


def validate_list(value: Any, param_name: str, allow_empty: bool = False) -> bool:
    """
    Validate that value is a list.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        allow_empty: Whether to allow empty lists
        
    Returns:
        True if valid
        
    Raises:
        TypeError: If value is not a list
        ValueError: If list is empty and allow_empty is False
    """
    if not isinstance(value, list):
        raise TypeError(
            f"Parameter '{param_name}' must be a list, got {type(value).__name__}"
        )
    
    if not allow_empty and len(value) == 0:
        raise ValueError(f"Parameter '{param_name}' cannot be an empty list")
    
    return True


def validate_string(value: Any, param_name: str, allow_empty: bool = False) -> bool:
    """
    Validate that value is a string.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        allow_empty: Whether to allow empty strings
        
    Returns:
        True if valid
        
    Raises:
        TypeError: If value is not a string
        ValueError: If string is empty and allow_empty is False
    """
    if not isinstance(value, str):
        raise TypeError(
            f"Parameter '{param_name}' must be a string, got {type(value).__name__}"
        )
    
    if not allow_empty and len(value) == 0:
        raise ValueError(f"Parameter '{param_name}' cannot be an empty string")
    
    return True


def validate_boolean(value: Any, param_name: str) -> bool:
    """
    Validate that value is a boolean.
    
    Args:
        value: Value to validate
        param_name: Parameter name for error messages
        
    Returns:
        True if valid
        
    Raises:
        TypeError: If value is not a boolean
    """
    if not isinstance(value, bool):
        raise TypeError(
            f"Parameter '{param_name}' must be a boolean, got {type(value).__name__}"
        )
    
    return True


def validate_optional(value: Any, validator: Callable, param_name: str) -> bool:
    """
    Validate optional parameter (None or valid value).
    
    Args:
        value: Value to validate
        validator: Validation function to use if not None
        param_name: Parameter name for error messages
        
    Returns:
        True if valid (None or passes validator)
        
    Example:
        validate_optional(strategy, validate_dict, 'strategy')
    """
    if value is None:
        return True
    
    return validator(value, param_name)
