"""
Backend detection and conversion utilities for Additory.

Handles automatic conversion between pandas and Polars DataFrames.
All processing happens in Polars, with transparent conversions at boundaries.
"""

from typing import Any
import polars as pl


# Global default backend setting
_DEFAULT_BACKEND = 'polars'


def detect_backend(df: Any) -> str:
    """
    Detect the backend type of a DataFrame.
    
    Args:
        df: DataFrame to detect
        
    Returns:
        Backend string ('polars', 'pandas')
        
    Raises:
        TypeError: If df is not a supported DataFrame type
        
    Example:
        backend = detect_backend(df)
        # Returns: 'pandas' or 'polars'
    """
    # Check Polars
    if isinstance(df, pl.DataFrame):
        return 'polars'
    
    # Check pandas
    try:
        import pandas as pd
        if isinstance(df, pd.DataFrame):
            return 'pandas'
    except ImportError:
        pass
    
    # Unsupported type
    raise TypeError(
        f"Unsupported DataFrame type: {type(df).__name__}. "
        f"Supported types: pandas.DataFrame, polars.DataFrame"
    )


def to_polars(df: Any) -> pl.DataFrame:
    """
    Convert any DataFrame to Polars.
    
    Args:
        df: DataFrame to convert
        
    Returns:
        Polars DataFrame
        
    Raises:
        TypeError: If df is not a supported DataFrame type
        
    Example:
        polars_df = to_polars(df)  # Works with pandas, polars
    """
    # Already Polars
    if isinstance(df, pl.DataFrame):
        return df
    
    # From pandas
    try:
        import pandas as pd
        if isinstance(df, pd.DataFrame):
            return pl.from_pandas(df)
    except ImportError:
        pass
    
    # Unsupported type
    raise TypeError(
        f"Unsupported DataFrame type: {type(df).__name__}. "
        f"Supported types: pandas.DataFrame, polars.DataFrame"
    )


def from_polars(df: pl.DataFrame, target_backend: str) -> Any:
    """
    Convert Polars DataFrame back to target backend.
    
    Args:
        df: Polars DataFrame to convert
        target_backend: Target backend ('polars', 'pandas')
        
    Returns:
        DataFrame in target backend
        
    Raises:
        TypeError: If target_backend is not supported
        
    Example:
        result = from_polars(polars_df, 'pandas')  # Returns pandas DataFrame
    """
    if not isinstance(df, pl.DataFrame):
        raise TypeError(f"Input must be a Polars DataFrame, got {type(df).__name__}")
    
    # To Polars (no conversion needed)
    if target_backend == 'polars':
        return df
    
    # To pandas
    if target_backend == 'pandas':
        return df.to_pandas()
    
    # Unsupported backend
    raise TypeError(
        f"Unsupported backend: {target_backend}. "
        f"Supported backends: polars, pandas"
    )


def get_default_backend() -> str:
    """
    Get the default backend setting.
    
    Returns:
        Default backend string ('polars', 'pandas')
        
    Example:
        backend = get_default_backend()  # Returns 'polars' by default
    """
    return _DEFAULT_BACKEND


def set_default_backend(backend: str) -> None:
    """
    Set the default backend for operations.
    
    Args:
        backend: Backend to set ('polars', 'pandas')
        
    Raises:
        ValueError: If backend is not supported
        
    Example:
        import additory
        additory.add.set_default_backend('pandas')
    """
    global _DEFAULT_BACKEND
    
    supported_backends = ['polars', 'pandas']
    if backend not in supported_backends:
        raise ValueError(
            f"Unsupported backend: {backend}. "
            f"Supported backends: {', '.join(supported_backends)}"
        )
    
    _DEFAULT_BACKEND = backend
