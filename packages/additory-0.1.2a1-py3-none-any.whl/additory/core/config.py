"""
Global configuration management for Additory.

Manages only 2 global settings:
1. Expressions folder - Path to custom expressions
2. Default backend - Default DataFrame backend

Principle: Minimal configuration, maximum simplicity.
"""

import os
from pathlib import Path
from typing import Optional


class Config:
    """
    Global configuration manager.
    
    Manages two settings:
    - expressions_folder: Path to custom .add files
    - default_backend: Default backend for operations
    """
    
    def __init__(self):
        """Initialize config with defaults."""
        self.expressions_folder: Optional[str] = None
        self.default_backend: str = 'polars'
        self._custom_namespace: Optional[str] = None
    
    def set_expressions_folder(self, path: str) -> None:
        """
        Set custom expressions folder.
        
        Args:
            path: Path to folder containing .add files
            
        Raises:
            ValueError: If path doesn't exist or is not a directory
            
        Example:
            config.set_expressions_folder('/path/to/my_expressions')
            # Now expressions can be referenced as: my_expressions:bmi
        """
        # Validate path
        if not os.path.exists(path):
            raise ValueError(f"Expressions folder does not exist: {path}")
        
        if not os.path.isdir(path):
            raise ValueError(f"Expressions folder is not a directory: {path}")
        
        # Set folder
        self.expressions_folder = str(Path(path).resolve())
        
        # Derive namespace from folder name
        self._custom_namespace = derive_namespace_from_path(self.expressions_folder)
        
        # Log change
        try:
            from .logging import get_logger
            logger = get_logger()
            logger.info(
                f"Expressions folder set to: {self.expressions_folder}",
                details={'namespace': self._custom_namespace}
            )
        except:
            pass  # Ignore if logger not available
    
    def get_expressions_folder(self) -> Optional[str]:
        """
        Get current expressions folder.
        
        Returns:
            Path to expressions folder or None
        """
        return self.expressions_folder
    
    def get_custom_namespace(self) -> Optional[str]:
        """
        Get custom namespace name.
        
        Returns:
            Namespace name (folder name) or None
            
        Example:
            # If folder is '/path/to/my_expressions'
            namespace = config.get_custom_namespace()
            # Returns: 'my_expressions'
        """
        return self._custom_namespace
    
    def set_default_backend(self, backend: str) -> None:
        """
        Set default backend.
        
        Args:
            backend: Backend name ('polars', 'pandas')
            
        Raises:
            ValueError: If backend is not supported
            
        Example:
            config.set_default_backend('pandas')
        """
        valid_backends = ['polars', 'pandas']
        if backend not in valid_backends:
            raise ValueError(
                f"Invalid backend '{backend}'. Must be one of: {valid_backends}"
            )
        
        self.default_backend = backend
        
        # Log change
        try:
            from .logging import get_logger
            logger = get_logger()
            logger.info(f"Default backend set to: {backend}")
        except:
            pass  # Ignore if logger not available
    
    def get_default_backend(self) -> str:
        """
        Get default backend.
        
        Returns:
            Backend name ('polars' or 'pandas')
        """
        return self.default_backend
    
    def reset(self) -> None:
        """
        Reset all settings to defaults.
        
        Used for testing or to clear configuration.
        """
        self.expressions_folder = None
        self.default_backend = 'polars'
        self._custom_namespace = None
        
        # Log reset
        try:
            from .logging import get_logger
            logger = get_logger()
            logger.info("Configuration reset to defaults")
        except:
            pass  # Ignore if logger not available


# Global config instance
_global_config: Optional[Config] = None


def get_config() -> Config:
    """
    Get the global config instance.
    
    Returns:
        Global Config instance
        
    Example:
        config = get_config()
        folder = config.get_expressions_folder()
    """
    global _global_config
    if _global_config is None:
        _global_config = Config()
    return _global_config


def set_expressions_folder(path: str) -> None:
    """
    Convenience function to set expressions folder.
    
    Args:
        path: Path to expressions folder
        
    Example:
        import additory
        additory.add.set_expressions_folder('/path/to/my_expressions')
    """
    config = get_config()
    config.set_expressions_folder(path)


def set_default_backend(backend: str) -> None:
    """
    Convenience function to set default backend.
    
    Args:
        backend: Backend name ('polars', 'pandas')
        
    Example:
        import additory
        additory.add.set_default_backend('pandas')
    """
    config = get_config()
    config.set_default_backend(backend)


def derive_namespace_from_path(path: str) -> str:
    """
    Derive namespace name from folder path.
    
    Args:
        path: Folder path
        
    Returns:
        Namespace name (folder name)
        
    Example:
        namespace = derive_namespace_from_path('/path/to/my_expressions')
        # Returns: 'my_expressions'
    """
    return Path(path).name
