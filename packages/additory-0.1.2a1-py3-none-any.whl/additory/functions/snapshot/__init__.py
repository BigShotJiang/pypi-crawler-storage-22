"""
Snapshot function - Filter and select data.

This module provides the main snapshot function for filtering and selecting data.
"""

import polars as pl
from typing import List, Optional

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.result import wrap_result
from additory.core.backend import detect_backend, to_polars, from_polars
from additory.core.logging import Logger
from additory.functions.snapshot.filter import apply_filter, select_columns


def snapshot(
    df,
    where: Optional[str] = None,
    columns: Optional[List[str]] = None
):
    """
    Filter and select data from DataFrame.
    
    Args:
        df: Input DataFrame (Polars or pandas)
        where: Optional filter expression (SQL-like WHERE clause)
        columns: Optional list of columns to select
        
    Returns:
        DataFrameResult with filtered/selected data
        
    Examples:
        >>> # Simple filter
        >>> result = snapshot(df, where='age > 18')
        
        >>> # Filter + select
        >>> result = snapshot(df, 
        ...     where='age > 18 AND status == "active"',
        ...     columns=['name', 'email', 'age'])
        
        >>> # Complex conditions
        >>> result = snapshot(df,
        ...     where='(age >= 18 AND status == "active") OR country == "USA"')
    """
    logger = Logger()
    logger.info("[snapshot] Starting snapshot() function")
    
    try:
        # Validate and convert
        validate_dataframe(df)
        validate_not_empty(df)
        backend = detect_backend(df)
        polars_df = to_polars(df)
        
        logger.info(f"Input: {polars_df.shape[0]} rows × {polars_df.shape[1]} columns")
        
        # Apply filter
        if where:
            polars_df = apply_filter(polars_df, where)
        
        # Select columns
        if columns:
            polars_df = select_columns(polars_df, columns)
        
        # Convert back
        result = from_polars(polars_df, backend)
        
        logger.info(f"Output: {polars_df.shape[0]} rows × {polars_df.shape[1]} columns")
        logger.info("[snapshot] snapshot() function complete")
        
        # Wrap result
        return wrap_result(result, 'snapshot', metadata={
            'where': where,
            'columns': columns,
            'rows_filtered': len(polars_df)
        })
        
    except Exception as e:
        logger.error(f"Error in snapshot() function: {e}", error_location="snapshot")
        raise

