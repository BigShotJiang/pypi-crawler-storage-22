"""
Main to function - add columns to DataFrame.

This module provides the main user-facing to() function with multiple modes:
- lookup: Add columns from reference DataFrame
- summarize: Group and aggregate data
- merge: Merge multiple DataFrames
- sort: Sort DataFrame

The function automatically uses Rust implementation when available for 2-5x
performance improvement, with transparent fallback to pure Python.
"""

import polars as pl
import io
from typing import Union, List, Optional, Dict, Any

from additory.core.backend import detect_backend, to_polars, from_polars
from additory.core.logging import Logger
from additory.core.memory_manager import MemoryManager
from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.result import wrap_result

from additory.functions.to.lookup import perform_lookup
from additory.functions.to.summarize import perform_summarize
from additory.functions.to.merge import perform_merge
from additory.functions.to.sort import perform_sort

# Try to import Rust bindings
try:
    from additory import _rust
    RUST_AVAILABLE = True
except ImportError:
    RUST_AVAILABLE = False


def _df_to_arrow_bytes(df: pl.DataFrame) -> bytes:
    """
    Convert polars DataFrame to Arrow IPC bytes.
    
    This function serializes a polars DataFrame to Arrow IPC format for
    zero-copy transfer to Rust.
    
    Args:
        df: Polars DataFrame to convert
        
    Returns:
        Arrow IPC bytes that can be passed to Rust functions
        
    Example:
        df_bytes = _df_to_arrow_bytes(polars_df)
        result_bytes = _rust.to_lookup(df_bytes, ...)
    """
    buffer = io.BytesIO()
    df.write_ipc(buffer)
    return buffer.getvalue()


def _arrow_bytes_to_df(data: bytes) -> pl.DataFrame:
    """
    Convert Arrow IPC bytes to polars DataFrame.
    
    This function deserializes Arrow IPC bytes (returned from Rust) back
    into a polars DataFrame.
    
    Args:
        data: Arrow IPC bytes from Rust function
        
    Returns:
        Polars DataFrame
        
    Example:
        result_bytes = _rust.to_lookup(...)
        result_df = _arrow_bytes_to_df(result_bytes)
    """
    buffer = io.BytesIO(data)
    return pl.read_ipc(buffer)


def _call_rust_implementation(
    df_pl: pl.DataFrame,
    from_df_pl: Optional[pl.DataFrame],
    bring: Optional[Union[str, List[str]]],
    against: Optional[Union[str, List[str]]],
    mode: str,
    **kwargs
) -> pl.DataFrame:
    """
    Call Rust implementation via Arrow IPC.
    
    This function routes to the appropriate Rust function based on mode,
    handling DataFrame conversion and parameter preparation.
    
    Args:
        df_pl: Main DataFrame (polars)
        from_df_pl: Reference DataFrame (polars, optional)
        bring: Columns to bring (for lookup mode)
        against: Key columns (for lookup/summarize modes)
        mode: Operation mode ('lookup', 'merge', 'sort', 'summarize')
        **kwargs: Mode-specific parameters
        
    Returns:
        Result DataFrame (polars)
        
    Raises:
        ValueError: If mode is unknown or parameters are invalid
        RuntimeError: If Rust operation fails
        
    Example:
        result = _call_rust_implementation(
            df_pl, from_df_pl, 'price', 'product_id', 'lookup'
        )
    """
    # Convert DataFrames to Arrow IPC bytes
    df_bytes = _df_to_arrow_bytes(df_pl)
    from_df_bytes = _df_to_arrow_bytes(from_df_pl) if from_df_pl is not None else None
    
    # Call appropriate Rust function based on mode
    if mode == 'lookup':
        # Normalize bring and against to lists
        bring_list = [bring] if isinstance(bring, str) else bring
        against_list = [against] if isinstance(against, str) else against
        
        if not bring_list or not against_list:
            raise ValueError("lookup mode requires 'bring' and 'against' parameters")
        
        result_bytes = _rust.to_lookup(
            df_bytes,
            from_df_bytes,
            bring_list,
            against_list
        )
    
    elif mode == 'merge':
        if from_df_bytes is None:
            raise ValueError("merge mode requires 'from_df' parameter")
        
        how = kwargs.get('how', 'vertical')
        result_bytes = _rust.to_merge(
            df_bytes,
            from_df_bytes,
            how
        )
    
    elif mode == 'sort':
        by = kwargs.get('by', against)
        if not by:
            raise ValueError("sort mode requires 'by' parameter")
        
        by_list = [by] if isinstance(by, str) else by
        descending = kwargs.get('descending', [False] * len(by_list))
        
        # Normalize descending to list
        if isinstance(descending, bool):
            descending = [descending] * len(by_list)
        
        nulls_last = kwargs.get('nulls_last', True)
        
        result_bytes = _rust.to_sort(
            df_bytes,
            by_list,
            descending,
            nulls_last
        )
    
    elif mode == 'summarize':
        group_by = against if isinstance(against, list) else [against] if against else []
        aggregations = kwargs.get('aggregations', {})
        
        if not group_by:
            raise ValueError("summarize mode requires 'against' parameter for grouping")
        
        result_bytes = _rust.to_summarize(
            df_bytes,
            group_by,
            aggregations
        )
    
    else:
        raise ValueError(f"Unknown mode: {mode}")
    
    # Convert result bytes back to DataFrame
    return _arrow_bytes_to_df(result_bytes)


def to(
    df: Any,
    bring_from: Optional[Any] = None,
    bring: Optional[Union[str, List[str]]] = None,
    against: Optional[Union[str, List[str]]] = None,
    to: Optional[str] = None,
    bring_at: Optional[Union[str, int]] = None,
    strategy: Optional[Dict] = None,
    logging: bool = False,
    max_rows: Optional[int] = None,
    **kwargs
) -> Any:
    """
    Add columns to DataFrame using various modes.
    
    This function automatically uses Rust implementation when available for
    2-5x performance improvement, with transparent fallback to pure Python.
    
    Philosophy: "There is only one way to do a thing"
    - No aliases (use 'against', not 'on')
    - Clear parameter names (bring_from, not from_df)
    - Helpful error messages with examples
    
    Args:
        df: Input DataFrame (or list of DataFrames for merge mode)
        bring_from: Reference DataFrame (for lookup mode)
        bring: Column(s) to bring (for lookup mode)
        against: Key column(s) for matching (for lookup mode)
        to: Special mode indicator ('@summarize', '@merge', '@sort')
        bring_at: Position to insert columns (int, 'start', 'end', 'after:col', 'before:col')
        strategy: Strategy dictionary for advanced control
        logging: Enable detailed logging (default: False, warnings/errors always shown)
        max_rows: Override row limit for safety checks
        **kwargs: Mode-specific parameters
        
    Returns:
        DataFrame with added columns (wrapped in Result)
        
    Modes:
        1. Lookup (default): Add columns from reference DataFrame
           - Triggered by: bring_from is provided
           - Example: to(df, bring_from=products, bring='price', against='product_id')
           
        2. Summarize: Group and aggregate data
           - Triggered by: to='@summarize'
           - Example: to(df, to='@summarize', group_by='category', aggregations={'sales': 'sum'})
           
        3. Merge: Merge multiple DataFrames
           - Triggered by: to='@merge'
           - Example: to([df1, df2, df3], to='@merge')
           
        4. Sort: Sort DataFrame
           - Triggered by: to='@sort'
           - Example: to(df, to='@sort', by='date', descending=True)
    
    Performance:
        When Rust bindings are available, operations are 2-5x faster than pure Python.
        The function automatically detects Rust availability and falls back to Python
        if needed. No code changes required to benefit from Rust acceleration.
    """
    from additory.functions.to.validation import (
        validate_to_lookup,
        validate_to_summarize,
        validate_to_sort,
        validate_to_merge,
        ValidationError
    )
    
    logger = Logger()
    if not logging:
        logger.set_level('silent')  # Disable logging if logging=False
    memory_manager = MemoryManager()
    
    try:
        # Detect mode
        mode = detect_mode(df, bring_from, to, **kwargs)
        logger.set_context('to', {'mode': mode, 'rust_available': RUST_AVAILABLE})
        
        # Validate based on mode
        warnings = []
        try:
            if mode == 'lookup':
                warnings = validate_to_lookup(df, bring_from, bring, against, bring_at, max_rows, logging)
            elif mode == 'summarize':
                group_by = kwargs.get('group_by', against)
                aggregations = kwargs.get('aggregations', {})
                warnings = validate_to_summarize(df, group_by, aggregations, max_rows)
            elif mode == 'sort':
                by = kwargs.get('by', against)
                descending = kwargs.get('descending', False)
                warnings = validate_to_sort(df, by, descending, max_rows)
            elif mode == 'merge':
                how = kwargs.get('how', 'vertical')
                on = kwargs.get('on', against)
                warnings = validate_to_merge(df, how, on, max_rows)
        except ValidationError as e:
            # Show validation error with helpful message (no stack trace)
            raise ValueError(str(e)) from None
        
        # Show warnings (always shown, regardless of logging setting)
        for warning in warnings:
            print(f"\n{warning}\n")
        
        logger.info(f"Starting to() function in '{mode}' mode (Rust: {RUST_AVAILABLE})")
        
        # Handle merge mode specially (df is a list)
        if mode == 'merge':
            # Validate list of DataFrames
            if not isinstance(df, list):
                raise TypeError("For merge mode, df must be a list of DataFrames")
            
            # Detect backend from first DataFrame
            backend = detect_backend(df[0])
            
            # Convert all to Polars
            polars_dfs = [to_polars(d) for d in df]
            
            # Try Rust implementation first if available
            if RUST_AVAILABLE and len(polars_dfs) == 2:
                try:
                    result = _call_rust_implementation(
                        polars_dfs[0],
                        polars_dfs[1],
                        None,
                        None,
                        mode,
                        **kwargs
                    )
                except Exception as e:
                    logger.warning(f"Rust implementation failed, falling back to Python: {str(e)}")
                    result = perform_merge(polars_dfs, **kwargs)
            else:
                # Fallback to Python (Rust doesn't support >2 DataFrames yet)
                result = perform_merge(polars_dfs, **kwargs)
        
        else:
            # Single DataFrame modes
            # Detect backend and convert to Polars
            backend = detect_backend(df)
            polars_df = to_polars(df)
            
            # Try Rust implementation first if available
            if RUST_AVAILABLE:
                try:
                    # Convert bring_from to Polars if needed
                    polars_bring_from = to_polars(bring_from) if bring_from is not None else None
                    
                    result = _call_rust_implementation(
                        polars_df,
                        polars_bring_from,
                        bring,
                        against,
                        mode,
                        **kwargs
                    )
                except Exception as e:
                    # Log the error and fallback to Python
                    logger.warning(f"Rust implementation failed, falling back to Python: {str(e)}")
                    
                    # Dispatch to appropriate Python mode
                    if mode == 'summarize':
                        result = perform_summarize(polars_df, **kwargs)
                    elif mode == 'sort':
                        result = perform_sort(polars_df, **kwargs)
                    elif mode == 'lookup':
                        polars_bring_from = to_polars(bring_from)
                        result = perform_lookup(
                            polars_df,
                            polars_bring_from,
                            bring,
                            against,
                            bring_at,
                            strategy
                        )
                    else:
                        raise ValueError(f"Unknown mode: {mode}")
            else:
                # Rust not available, use Python implementation
                if mode == 'summarize':
                    result = perform_summarize(polars_df, **kwargs)
                elif mode == 'sort':
                    result = perform_sort(polars_df, **kwargs)
                elif mode == 'lookup':
                    polars_bring_from = to_polars(bring_from)
                    result = perform_lookup(
                        polars_df,
                        polars_bring_from,
                        bring,
                        against,
                        bring_at,
                        strategy
                    )
                else:
                    raise ValueError(f"Unknown mode: {mode}")
        
        # Convert back to original backend
        result = from_polars(result, backend)
        
        # Cleanup
        memory_manager.cleanup()
        
        # Wrap result
        logger.info(f"to() function complete: {len(result)} rows, {len(result.columns)} columns")
        return wrap_result(result, 'to', metadata={'mode': mode, 'rust_used': RUST_AVAILABLE})
    
    except Exception as e:
        logger.error(f"Error in to() function: {str(e)}", error_location="to")
        # Re-raise the original error without wrapping
        raise


def detect_mode(
    df: Any,
    bring_from: Optional[Any],
    to: Optional[str],
    **kwargs
) -> str:
    """
    Detect which mode to use based on parameters.
    
    Args:
        df: Input DataFrame
        bring_from: Reference DataFrame
        to: Mode indicator
        **kwargs: Additional parameters
        
    Returns:
        Mode string ('lookup', 'summarize', 'merge', 'sort')
        
    Raises:
        ValueError: If mode cannot be determined
    """
    # Check for explicit mode indicators
    if to == '@summarize':
        return 'summarize'
    elif to == '@merge':
        return 'merge'
    elif to == '@sort':
        return 'sort'
    
    # Check for lookup mode (bring_from provided)
    elif bring_from is not None:
        return 'lookup'
    
    # Cannot determine mode
    else:
        raise ValueError(
            "Cannot determine operation mode. Please provide one of:\n"
            "  - bring_from parameter (for lookup mode)\n"
            "  - to='@summarize' (for summarize mode)\n"
            "  - to='@merge' (for merge mode)\n"
            "  - to='@sort' (for sort mode)\n\n"
            "Example:\n"
            "  add.to(df, bring_from=products, bring='price', against='product_id')"
        )


__all__ = ['to']
