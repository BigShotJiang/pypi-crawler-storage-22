"""
Lookup and add columns from reference DataFrame.

This module provides lookup functionality for the to function.
"""

import polars as pl
from typing import Union, List, Optional, Dict

from additory.common.validation import validate_dataframe, validate_not_empty
from additory.common.column_selector import select_columns
from additory.core.logging import Logger


def perform_lookup(
    df: pl.DataFrame,
    from_df: pl.DataFrame,
    bring: Union[str, List[str]],
    against: Union[str, List[str]],
    bring_at: Optional[str] = None,
    strategy: Optional[Dict] = None
) -> pl.DataFrame:
    """
    Perform lookup and add columns from reference DataFrame.
    
    Args:
        df: Input DataFrame
        from_df: Reference DataFrame
        bring: Column(s) to bring from reference
        against: Key column(s) for matching
        bring_at: Position to insert columns ('start', 'end', 'after:col', 'before:col')
        strategy: Strategy dictionary for advanced control
        
    Returns:
        DataFrame with added columns
        
    Example:
        >>> result = perform_lookup(
        ...     df=orders,
        ...     from_df=products,
        ...     bring='price',
        ...     against='product_id'
        ... )
    """
    logger = Logger()
    
    # Validate parameters
    validate_lookup_parameters(df, from_df, bring, against)
    
    # Normalize parameters
    bring_list = [bring] if isinstance(bring, str) else bring
    against_list = [against] if isinstance(against, str) else against
    
    # Log operation
    logger.info(f"Lookup: bringing {bring_list} against {against_list}")
    
    # Detect lookup mode based on cardinality
    mode = detect_lookup_mode(df, from_df, against_list)
    logger.info(f"Detected lookup mode: {mode}")
    
    # Perform the join
    result = perform_join(df, from_df, bring_list, against_list, mode)
    
    # Apply strategy if provided
    if strategy:
        result = apply_strategy(result, bring_list, strategy)
    
    # Position columns if specified
    if bring_at:
        result = position_columns(result, bring_list, bring_at)
    
    logger.info(f"Lookup complete: {len(result)} rows, {len(result.columns)} columns")
    
    return result


def validate_lookup_parameters(
    df: pl.DataFrame,
    from_df: pl.DataFrame,
    bring: Union[str, List[str]],
    against: Union[str, List[str]]
) -> None:
    """
    Validate lookup parameters.
    
    Args:
        df: Input DataFrame
        from_df: Reference DataFrame
        bring: Column(s) to bring
        against: Key column(s)
        
    Raises:
        ValueError: If validation fails
    """
    # Validate DataFrames
    validate_dataframe(df)
    validate_not_empty(df)
    validate_dataframe(from_df)
    validate_not_empty(from_df)
    
    # Normalize to lists
    bring_list = [bring] if isinstance(bring, str) else bring
    against_list = [against] if isinstance(against, str) else against
    
    # Check that bring columns exist in from_df
    missing_bring = [col for col in bring_list if col not in from_df.columns]
    if missing_bring:
        raise ValueError(
            f"Bring columns not found in reference DataFrame: {missing_bring}. "
            f"Available columns: {from_df.columns}"
        )
    
    # Check that against columns exist in both DataFrames
    missing_in_df = [col for col in against_list if col not in df.columns]
    if missing_in_df:
        raise ValueError(
            f"Key columns not found in input DataFrame: {missing_in_df}. "
            f"Available columns: {df.columns}"
        )
    
    missing_in_from = [col for col in against_list if col not in from_df.columns]
    if missing_in_from:
        raise ValueError(
            f"Key columns not found in reference DataFrame: {missing_in_from}. "
            f"Available columns: {from_df.columns}"
        )


def detect_lookup_mode(
    df: pl.DataFrame,
    from_df: pl.DataFrame,
    against: List[str]
) -> str:
    """
    Detect lookup mode based on cardinality.
    
    Args:
        df: Input DataFrame
        from_df: Reference DataFrame
        against: Key columns
        
    Returns:
        Lookup mode string ('fetch_if_unique', 'first', etc.)
    """
    logger = Logger()
    
    # Check cardinality
    cardinality = check_cardinality(df, from_df, against)
    
    if cardinality['type'] == 'one_to_one':
        return 'fetch_if_unique'
    elif cardinality['type'] == 'many_to_one':
        return 'fetch_if_unique'
    elif cardinality['type'] == 'one_to_many':
        logger.warning(
            f"One-to-many relationship detected. "
            f"Using 'first' mode (taking first match). "
            f"Max matches per key: {cardinality['max_matches']}"
        )
        return 'first'
    else:  # many_to_many
        raise ValueError(
            "Many-to-many relationship detected. "
            "Cannot perform lookup with many-to-many relationships. "
            "Consider using a different key or aggregating the reference data first."
        )


def check_cardinality(
    df: pl.DataFrame,
    from_df: pl.DataFrame,
    against: List[str]
) -> Dict:
    """
    Check cardinality of relationship between DataFrames.
    
    Args:
        df: Input DataFrame
        from_df: Reference DataFrame
        against: Key columns
        
    Returns:
        Dictionary with cardinality information
    """
    # Check if keys are unique in each DataFrame
    left_unique = df.select(against).n_unique() == len(df)
    right_unique = from_df.select(against).n_unique() == len(from_df)
    
    # Calculate max matches
    if right_unique:
        max_matches = 1
    else:
        # Group by keys and count
        counts = from_df.group_by(against).agg(pl.len().alias('count'))
        max_matches = counts['count'].max()
    
    # Determine relationship type
    if left_unique and right_unique:
        rel_type = 'one_to_one'
    elif not left_unique and right_unique:
        rel_type = 'many_to_one'
    elif left_unique and not right_unique:
        rel_type = 'one_to_many'
    else:
        rel_type = 'many_to_many'
    
    return {
        'type': rel_type,
        'left_unique': left_unique,
        'right_unique': right_unique,
        'max_matches': max_matches
    }


def perform_join(
    df: pl.DataFrame,
    from_df: pl.DataFrame,
    bring: List[str],
    against: List[str],
    mode: str
) -> pl.DataFrame:
    """
    Perform the actual join operation.
    
    Args:
        df: Input DataFrame
        from_df: Reference DataFrame
        bring: Columns to bring
        against: Key columns
        mode: Lookup mode
        
    Returns:
        DataFrame with joined columns
    """
    # Select only needed columns from reference
    ref_cols = list(set(against + bring))
    ref_df = from_df.select(ref_cols)
    
    # For 'first' mode, take first occurrence of each key
    if mode == 'first':
        ref_df = ref_df.unique(subset=against, keep='first')
    
    # Perform left join
    result = df.join(ref_df, on=against, how='left')
    
    return result


def apply_strategy(
    df: pl.DataFrame,
    bring: List[str],
    strategy: Dict
) -> pl.DataFrame:
    """
    Apply strategy to lookup results.
    
    Args:
        df: DataFrame with joined columns
        bring: Columns that were brought
        strategy: Strategy dictionary
        
    Returns:
        DataFrame with strategy applied
        
    Note:
        Strategy can include fill_null, position, etc.
    """
    result = df
    
    for col in bring:
        if col in strategy:
            col_strategy = strategy[col]
            
            # Handle fill_null
            if isinstance(col_strategy, dict) and 'fill_null' in col_strategy:
                fill_value = col_strategy['fill_null']
                result = result.with_columns(
                    pl.col(col).fill_null(fill_value)
                )
    
    return result


def position_columns(
    df: pl.DataFrame,
    bring: List[str],
    bring_at: Union[str, int]
) -> pl.DataFrame:
    """
    Position brought columns at specified location.
    
    Args:
        df: DataFrame with new columns
        bring: Columns to position
        bring_at: Position specification (string or integer)
        
    Returns:
        DataFrame with repositioned columns
        
    Position Specifications:
        - 'start' - At beginning
        - 'end' - At end (default)
        - 'after:column_name' - After specified column
        - 'before:column_name' - Before specified column
        - Integer: Index position (0-based, supports negative indexing)
    """
    # Handle integer positioning
    if isinstance(bring_at, int):
        # Get all columns except the ones being brought
        other_cols = [col for col in df.columns if col not in bring]
        
        # Handle negative indices
        total_cols = len(other_cols) + len(bring)
        if bring_at < 0:
            bring_at = total_cols + bring_at
        
        # Clamp to valid range
        bring_at = max(0, min(bring_at, len(other_cols)))
        
        # Insert at specified position
        new_order = other_cols[:bring_at] + bring + other_cols[bring_at:]
        return df.select(new_order)
    
    # Handle string positioning
    if bring_at == 'start':
        # Move to start
        other_cols = [col for col in df.columns if col not in bring]
        return df.select(bring + other_cols)
    
    elif bring_at == 'end':
        # Already at end (default join behavior)
        return df
    
    elif bring_at.startswith('after:'):
        # Insert after specified column
        target_col = bring_at.split(':', 1)[1]
        if target_col not in df.columns:
            raise ValueError(f"Target column '{target_col}' not found in DataFrame")
        
        # Build new column order
        new_order = []
        for col in df.columns:
            if col not in bring:
                new_order.append(col)
                if col == target_col:
                    new_order.extend(bring)
        
        return df.select(new_order)
    
    elif bring_at.startswith('before:'):
        # Insert before specified column
        target_col = bring_at.split(':', 1)[1]
        if target_col not in df.columns:
            raise ValueError(f"Target column '{target_col}' not found in DataFrame")
        
        # Build new column order
        new_order = []
        for col in df.columns:
            if col not in bring:
                if col == target_col:
                    new_order.extend(bring)
                new_order.append(col)
        
        return df.select(new_order)
    
    else:
        raise ValueError(
            f"Invalid bring_at specification: {bring_at}. "
            f"Valid options: 'start', 'end', 'after:column', 'before:column', or integer index"
        )

