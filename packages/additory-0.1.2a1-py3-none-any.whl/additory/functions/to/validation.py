"""
Validation module for add.to() function.

This module provides comprehensive validation with clear, helpful error messages
that guide users to correct syntax rather than showing Python stack traces.

Philosophy: "There is only one way to do a thing"
- No aliases (removed 'on', use only 'against')
- Clear parameter names (bring_from, not from_df)
- Helpful error messages with examples
"""

from typing import Any, List, Optional, Union, Dict, Tuple
import polars as pl
import pandas as pd


class ValidationError(Exception):
    """Custom exception for validation errors with helpful messages."""
    pass


class ValidationWarning:
    """Container for validation warnings."""
    def __init__(self, message: str):
        self.message = message
    
    def __str__(self):
        return f"Warning: {self.message}"


def validate_to_lookup(
    df: Any,
    bring_from: Optional[Any],
    bring: Optional[Union[str, List[str]]],
    against: Optional[Union[str, List[str]]],
    bring_at: Optional[Union[str, int]] = None,
    max_rows: Optional[int] = None,
    logging: bool = False
) -> List[ValidationWarning]:
    """
    Validate parameters for add.to() lookup mode.
    
    Args:
        df: Input DataFrame
        bring_from: Reference DataFrame
        bring: Columns to bring
        against: Key columns for matching
        bring_at: Position to insert columns
        max_rows: Maximum row limit override
        logging: Whether logging is enabled
    
    Returns:
        List of warnings (empty if no warnings)
    
    Raises:
        ValidationError: If validation fails with helpful error message
    """
    warnings = []
    
    # 1. DataFrame Validation
    _validate_dataframe(df, "df")
    _validate_dataframe(bring_from, "bring_from")
    
    # 2. Required Parameters
    if bring is None:
        raise ValidationError(
            "Parameter 'bring' is required for lookup mode.\n"
            "Specify which column(s) to bring from the reference DataFrame.\n\n"
            "Example:\n"
            "  add.to(df, bring_from=products, bring='price', against='product_id')"
        )
    
    if against is None:
        raise ValidationError(
            "Parameter 'against' is required for lookup mode.\n"
            "Specify which column(s) to use as keys for matching.\n\n"
            "Example:\n"
            "  add.to(df, bring_from=products, bring='price', against='product_id')"
        )
    
    # 3. Type Validation
    bring_list = _validate_column_parameter(bring, "bring")
    against_list = _validate_column_parameter(against, "against")
    
    # 4. Column Existence
    _validate_columns_exist(bring_list, bring_from, "bring", "bring_from")
    _validate_columns_exist(against_list, df, "against", "df (input)")
    _validate_columns_exist(against_list, bring_from, "against", "bring_from")
    
    # 5. Position Validation
    if bring_at is not None:
        _validate_position(bring_at, df, len(bring_list))
    
    # 6. Row Limit Validation
    if max_rows is None:
        max_rows = 10_000_000  # Default: 10M rows for lookup
    
    row_warning = _validate_row_limit(df, "lookup", max_rows)
    if row_warning:
        warnings.append(row_warning)
    
    row_warning = _validate_row_limit(bring_from, "lookup", max_rows, is_reference=True)
    if row_warning:
        warnings.append(row_warning)
    
    return warnings


def validate_to_summarize(
    df: Any,
    group_by: Optional[Union[str, List[str]]],
    aggregations: Optional[Dict[str, str]],
    max_rows: Optional[int] = None
) -> List[ValidationWarning]:
    """
    Validate parameters for add.to() summarize mode.
    
    Args:
        df: Input DataFrame
        group_by: Columns to group by
        aggregations: Aggregation functions
        max_rows: Maximum row limit override
    
    Returns:
        List of warnings (empty if no warnings)
    
    Raises:
        ValidationError: If validation fails with helpful error message
    """
    warnings = []
    
    # 1. DataFrame Validation
    _validate_dataframe(df, "df")
    
    # 2. Required Parameters
    if group_by is None:
        raise ValidationError(
            "Parameter 'group_by' is required for summarize mode (to='@summarize').\n"
            "Specify which column(s) to group by.\n\n"
            "Example:\n"
            "  add.to(df, to='@summarize', group_by='category', aggregations={'sales': 'sum'})"
        )
    
    if aggregations is None or len(aggregations) == 0:
        raise ValidationError(
            "Parameter 'aggregations' is required for summarize mode (to='@summarize').\n"
            "Specify which columns to aggregate and how.\n\n"
            "Example:\n"
            "  add.to(df, to='@summarize', group_by='category', aggregations={'sales': 'sum', 'orders': 'count'})"
        )
    
    # 3. Type Validation
    group_by_list = _validate_column_parameter(group_by, "group_by")
    
    if not isinstance(aggregations, dict):
        raise ValidationError(
            f"Parameter 'aggregations' must be a dictionary.\n"
            f"Received: {type(aggregations).__name__}\n\n"
            "Example:\n"
            "  aggregations={'sales': 'sum', 'orders': 'count'}"
        )
    
    # 4. Column Existence
    _validate_columns_exist(group_by_list, df, "group_by", "df")
    
    agg_columns = list(aggregations.keys())
    _validate_columns_exist(agg_columns, df, "aggregations", "df")
    
    # 5. Aggregation Functions
    valid_functions = ['sum', 'count', 'mean', 'median', 'min', 'max', 'first', 'last', 'std', 'var']
    invalid_funcs = [f for f in aggregations.values() if f not in valid_functions]
    
    if invalid_funcs:
        raise ValidationError(
            f"Invalid aggregation function(s): {invalid_funcs}\n"
            f"Valid functions: {valid_functions}\n\n"
            "Example:\n"
            "  aggregations={'sales': 'sum', 'orders': 'count', 'price': 'mean'}"
        )
    
    # 6. Row Limit Validation
    if max_rows is None:
        max_rows = 100_000_000  # Default: 100M rows for summarize
    
    row_warning = _validate_row_limit(df, "summarize", max_rows)
    if row_warning:
        warnings.append(row_warning)
    
    return warnings


def validate_to_sort(
    df: Any,
    by: Optional[Union[str, List[str]]],
    descending: Union[bool, List[bool]] = False,
    max_rows: Optional[int] = None
) -> List[ValidationWarning]:
    """
    Validate parameters for add.to() sort mode.
    
    Args:
        df: Input DataFrame
        by: Columns to sort by
        descending: Sort order (single bool or list)
        max_rows: Maximum row limit override
    
    Returns:
        List of warnings (empty if no warnings)
    
    Raises:
        ValidationError: If validation fails with helpful error message
    """
    warnings = []
    
    # 1. DataFrame Validation
    _validate_dataframe(df, "df")
    
    # 2. Required Parameters
    if by is None:
        raise ValidationError(
            "Parameter 'by' is required for sort mode (to='@sort').\n"
            "Specify which column(s) to sort by.\n\n"
            "Example:\n"
            "  add.to(df, to='@sort', by='date', descending=True)"
        )
    
    # 3. Type Validation
    by_list = _validate_column_parameter(by, "by")
    
    # 4. Column Existence
    _validate_columns_exist(by_list, df, "by", "df")
    
    # 5. Descending Parameter
    if isinstance(descending, list):
        if len(descending) != len(by_list):
            raise ValidationError(
                f"Parameter 'descending' length ({len(descending)}) must match 'by' length ({len(by_list)}).\n"
                f"You specified {len(by_list)} column(s) to sort by: {by_list}\n"
                f"But provided {len(descending)} descending value(s): {descending}\n\n"
                "Either provide:\n"
                "  - A single boolean (applies to all columns)\n"
                "  - A list with {len(by_list)} boolean values (one per column)\n\n"
                "Example:\n"
                f"  add.to(df, to='@sort', by={by_list}, descending=[True, False])"
            )
    
    # 6. Row Limit Validation
    if max_rows is None:
        max_rows = 20_000_000  # Default: 20M rows for sort
    
    row_warning = _validate_row_limit(df, "sort", max_rows)
    if row_warning:
        warnings.append(row_warning)
    
    return warnings


def validate_to_merge(
    df: Any,
    how: str = 'vertical',
    on: Optional[Union[str, List[str]]] = None,
    max_rows: Optional[int] = None
) -> List[ValidationWarning]:
    """
    Validate parameters for add.to() merge mode.
    
    Args:
        df: List of DataFrames
        how: Merge strategy ('vertical', 'horizontal', 'diagonal')
        on: Key columns for horizontal merge
        max_rows: Maximum row limit override
    
    Returns:
        List of warnings (empty if no warnings)
    
    Raises:
        ValidationError: If validation fails with helpful error message
    """
    warnings = []
    
    # 1. DataFrame List Validation
    if not isinstance(df, list):
        raise ValidationError(
            "For merge mode (to='@merge'), parameter 'df' must be a list of DataFrames.\n"
            f"Received: {type(df).__name__}\n\n"
            "Example:\n"
            "  add.to([df1, df2, df3], to='@merge', how='vertical')"
        )
    
    if len(df) < 2:
        raise ValidationError(
            f"For merge mode, at least 2 DataFrames are required.\n"
            f"Received list with {len(df)} DataFrame(s).\n\n"
            "Example:\n"
            "  add.to([df1, df2], to='@merge', how='vertical')"
        )
    
    # Validate each DataFrame
    for i, d in enumerate(df):
        try:
            _validate_dataframe(d, f"df[{i}]")
        except ValidationError as e:
            raise ValidationError(
                f"DataFrame at index {i} is invalid:\n{str(e)}"
            )
    
    # 2. How Parameter
    valid_how = ['vertical', 'horizontal', 'diagonal']
    if how not in valid_how:
        raise ValidationError(
            f"Parameter 'how' has invalid value: '{how}'.\n"
            f"Valid values for merge mode: {valid_how}\n\n"
            "Examples:\n"
            "  - 'vertical' (stack rows, requires same columns)\n"
            "  - 'horizontal' (join on keys, requires 'on' parameter)\n"
            "  - 'diagonal' (stack with different columns, fills nulls)"
        )
    
    # 3. Horizontal Merge Validation
    if how == 'horizontal' and on is None:
        raise ValidationError(
            "Parameter 'on' is required for horizontal merge (how='horizontal').\n"
            "Specify which column(s) to use as keys for joining.\n\n"
            "Example:\n"
            "  add.to([df1, df2], to='@merge', how='horizontal', on='id')"
        )
    
    # 4. Row Limit Validation
    if max_rows is None:
        max_rows = 50_000_000  # Default: 50M rows for merge
    
    for i, d in enumerate(df):
        row_warning = _validate_row_limit(d, "merge", max_rows, df_name=f"df[{i}]")
        if row_warning:
            warnings.append(row_warning)
    
    return warnings


# Helper Functions

def _validate_dataframe(df: Any, param_name: str) -> None:
    """Validate that parameter is a valid DataFrame."""
    if df is None:
        raise ValidationError(
            f"Parameter '{param_name}' is required but was not provided."
        )
    
    # Check if it's a DataFrame
    is_pandas = isinstance(df, pd.DataFrame)
    is_polars = isinstance(df, pl.DataFrame)
    
    if not (is_pandas or is_polars):
        # Check for cuDF
        df_type = type(df).__name__
        if 'cudf' in df_type.lower() or 'gpu' in df_type.lower():
            raise ValidationError(
                f"cuDF DataFrames are not supported for '{param_name}'.\n"
                "Please convert to Pandas or Polars DataFrame first.\n\n"
                "Example:\n"
                f"  {param_name} = {param_name}.to_pandas()"
            )
        
        raise ValidationError(
            f"Parameter '{param_name}' must be a Pandas or Polars DataFrame.\n"
            f"Received: {df_type}\n\n"
            "Supported types: pandas.DataFrame, polars.DataFrame"
        )
    
    # Check if empty
    if len(df) == 0:
        raise ValidationError(
            f"Parameter '{param_name}' cannot be an empty DataFrame.\n"
            "DataFrame has 0 rows."
        )


def _validate_column_parameter(
    param: Union[str, List[str]],
    param_name: str
) -> List[str]:
    """Validate and normalize column parameter to list."""
    if isinstance(param, str):
        return [param]
    elif isinstance(param, list):
        if len(param) == 0:
            raise ValidationError(
                f"Parameter '{param_name}' cannot be an empty list.\n"
                "Specify at least one column."
            )
        
        # Check all items are strings
        non_strings = [type(item).__name__ for item in param if not isinstance(item, str)]
        if non_strings:
            raise ValidationError(
                f"Parameter '{param_name}' must be a string or list of strings.\n"
                f"Found non-string types: {set(non_strings)}"
            )
        
        return param
    else:
        raise ValidationError(
            f"Parameter '{param_name}' must be a string or list of strings.\n"
            f"Received: {type(param).__name__}"
        )


def _validate_columns_exist(
    columns: List[str],
    df: Any,
    param_name: str,
    df_name: str
) -> None:
    """Validate that columns exist in DataFrame."""
    df_columns = list(df.columns)
    missing = [col for col in columns if col not in df_columns]
    
    if missing:
        raise ValidationError(
            f"Column(s) specified in '{param_name}' not found in {df_name} DataFrame: {missing}\n"
            f"Available columns in {df_name}: {df_columns}\n\n"
            "Check for typos or case sensitivity."
        )


def _validate_position(
    bring_at: Union[str, int],
    df: Any,
    num_new_cols: int
) -> None:
    """Validate bring_at position parameter."""
    total_cols = len(df.columns) + num_new_cols
    
    if isinstance(bring_at, int):
        # Validate integer range
        if bring_at >= total_cols or bring_at < -total_cols:
            # Way out of range
            if abs(bring_at) > total_cols * 2:
                raise ValidationError(
                    f"Parameter 'bring_at' index {bring_at} is far out of range.\n"
                    f"DataFrame will have {total_cols} columns after adding new columns.\n"
                    f"Valid range: 0 to {total_cols-1} (or -1 to -{total_cols})\n\n"
                    "Did you mean:\n"
                    "  - 0 (first position)?\n"
                    "  - -1 (last position)?\n"
                    f"  - {total_cols-1} (last position)?"
                )
            
            # Just out of range
            if bring_at >= 0:
                raise ValidationError(
                    f"Parameter 'bring_at' index {bring_at} is out of range.\n"
                    f"DataFrame will have {total_cols} columns after adding new columns.\n"
                    f"Valid positive indices: 0 to {total_cols-1}\n"
                    f"(0 = first position, {total_cols-1} = last position)"
                )
            else:
                raise ValidationError(
                    f"Parameter 'bring_at' index {bring_at} is out of range.\n"
                    f"DataFrame will have {total_cols} columns after adding new columns.\n"
                    f"Valid negative indices: -1 to -{total_cols}\n"
                    f"(-1 = last position, -{total_cols} = first position)"
                )
    
    elif isinstance(bring_at, str):
        # Validate string format
        if bring_at in ['start', 'end']:
            return  # Valid
        
        if bring_at.startswith('after:') or bring_at.startswith('before:'):
            target_col = bring_at.split(':', 1)[1]
            
            if target_col not in df.columns:
                raise ValidationError(
                    f"Parameter 'bring_at' specifies '{bring_at}' but column '{target_col}' not found in DataFrame.\n"
                    f"Available columns: {list(df.columns)}"
                )
        else:
            raise ValidationError(
                f"Parameter 'bring_at' has invalid format: '{bring_at}'\n"
                "Valid formats:\n"
                "  - 'start' (beginning of DataFrame)\n"
                "  - 'end' (end of DataFrame)\n"
                "  - 'after:column_name' (after specified column)\n"
                "  - 'before:column_name' (before specified column)\n"
                f"  - Integer index (0 to {total_cols-1} or -1 to -{total_cols})"
            )
    else:
        raise ValidationError(
            f"Parameter 'bring_at' must be a string or integer.\n"
            f"Received: {type(bring_at).__name__}"
        )


def _validate_row_limit(
    df: Any,
    operation: str,
    max_rows: int,
    is_reference: bool = False,
    df_name: str = "DataFrame"
) -> Optional[ValidationWarning]:
    """Validate row count against safe limits."""
    row_count = len(df)
    
    # Check if exceeds limit
    if row_count > max_rows:
        df_type = "Reference DataFrame" if is_reference else df_name
        raise ValidationError(
            f"{df_type} has {row_count:,} rows, exceeding safe limit of {max_rows:,} for {operation} operation.\n\n"
            "Recommendations:\n"
            "  1. Process in smaller chunks\n"
            "  2. Filter data before operation\n"
            f"  3. Override limit with max_rows={row_count} (use at your own risk)\n\n"
            "Example:\n"
            f"  add.to(df, ..., max_rows={row_count})"
        )
    
    # Warn if approaching limit (>80%)
    if row_count > max_rows * 0.8:
        df_type = "Reference DataFrame" if is_reference else df_name
        return ValidationWarning(
            f"{df_type} has {row_count:,} rows, approaching limit of {max_rows:,} ({row_count/max_rows*100:.1f}%).\n"
            "Operation may be slow."
        )
    
    return None


__all__ = [
    'validate_to_lookup',
    'validate_to_summarize',
    'validate_to_sort',
    'validate_to_merge',
    'ValidationError',
    'ValidationWarning'
]
