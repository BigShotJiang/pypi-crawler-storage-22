# adi-agentic-agi

A cognitive, policy-driven, multi-agent framework built on a **Cognitive Bus (Blackboard)**.

## v0.5.0 Additions
- **SQL adapters**: SQLite/Postgres event store (`SqlEventStore`) *(extras: [db])*
- **Redis adapter**: Redis event store (`RedisEventStore`) *(extras: [redis])*
- **Web UI Dashboard** (FastAPI) *(extras: [ui])*:
  - HITL approvals (Approve/Reject gates)
  - Visual trace explorer (live timeline)
  - Council status view (threads + realtime events)

## Run the Dashboard
```bash
pip install "adi-agentic-agi[ui]"
```

```python
import uvicorn
from adi_agentic_agi.core.bus import CognitiveBus
from adi_agentic_agi import create_app

bus = CognitiveBus()
app = create_app(bus=bus)

uvicorn.run(app, host="0.0.0.0", port=8080)
```

Open: http://localhost:8080

## Use Postgres for durable threads
```bash
pip install "adi-agentic-agi[db]"
```

```python
from adi_agentic_agi.core.bus import CognitiveBus
from adi_agentic_agi.memory.sql_store import SqlEventStore

store = SqlEventStore("postgresql+asyncpg://user:pass@host:5432/db")
bus = CognitiveBus(store=store)
```

## Use Redis for durable threads
```bash
pip install "adi-agentic-agi[redis]"
```

```python
from adi_agentic_agi.core.bus import CognitiveBus
from adi_agentic_agi.memory.redis_store import RedisEventStore

store = RedisEventStore("redis://localhost:6379/0")
bus = CognitiveBus(store=store)
```

## Local integration testing (Postgres + Redis)

Start services:
```bash
docker-compose up -d
```

Run tests with extras:
```bash
pip install -e ".[dev,db,redis,ui,http]"
export DATABASE_URL="postgresql+asyncpg://adi:adi@localhost:5432/adi_agentic_agi"
export REDIS_URL="redis://localhost:6379/0"
pytest -q
```

