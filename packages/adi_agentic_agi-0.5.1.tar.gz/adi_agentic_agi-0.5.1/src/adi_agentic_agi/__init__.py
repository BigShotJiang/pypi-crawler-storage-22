from ._version import __version__

from .core.bus import CognitiveBus
from .core.agent import BaseAgent, AgentConfig
from .core.context import ContextObject, MediaBlob
from .core.routing import ConfidenceRouter
from .providers.base import ProviderConfig
from .tools.http_executor import OpenAPIHttpExecutor, HttpAuth
from .tools.openapi_binder import bind_openapi_directory
from .highlevel.council import Council, CouncilResult

__all__ = [
    "__version__",
    "CognitiveBus",
    "BaseAgent",
    "AgentConfig",
    "ContextObject",
    "MediaBlob",
    "ConfidenceRouter",
    "ProviderConfig",
    "OpenAPIHttpExecutor",
    "HttpAuth",
    "bind_openapi_directory",
    "Council",
    "CouncilResult",
]

def create_app(*args, **kwargs):
    """Create the optional FastAPI dashboard app (requires adi-agentic-agi[ui])."""
    try:
        from .ui.server import create_app as _create_app
    except Exception as e:  # pragma: no cover
        raise ImportError('Install extras: adi-agentic-agi[ui]') from e
    return _create_app(*args, **kwargs)
