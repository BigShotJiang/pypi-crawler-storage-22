from __future__ import annotations
from typing import Callable, Dict, Type

_AGENT_REGISTRY: Dict[str, Type] = {}

def agent_role(name: str) -> Callable[[Type], Type]:
    def _wrap(cls: Type) -> Type:
        _AGENT_REGISTRY[name] = cls
        setattr(cls, "__adi_role__", name)
        return cls
    return _wrap

def list_roles() -> Dict[str, Type]:
    return dict(_AGENT_REGISTRY)
