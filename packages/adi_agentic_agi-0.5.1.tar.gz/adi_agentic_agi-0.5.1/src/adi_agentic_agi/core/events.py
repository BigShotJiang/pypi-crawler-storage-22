from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .context import ContextObject

Json = Dict[str, Any]

class BusEvent(BaseModel):
    event_id: str
    thread_id: Optional[str] = None
    ts: float = Field(default_factory=lambda: time.time())

    topic: str
    type: str  # TASK | THOUGHT | RESULT | ALERT
    context: ContextObject = Field(default_factory=ContextObject)

    parent_id: Optional[str] = None
    sender: Optional[str] = None
    intended_for: List[str] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)

    confidence: Optional[float] = None
    priority: int = 5
    meta: Json = Field(default_factory=dict)
