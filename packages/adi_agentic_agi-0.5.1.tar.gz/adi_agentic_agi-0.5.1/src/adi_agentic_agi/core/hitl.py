from __future__ import annotations
import asyncio
from typing import Any, Dict
from pydantic import BaseModel, Field

class HITLDecision(BaseModel):
    approved: bool
    notes: str = ""
    meta: Dict[str, Any] = Field(default_factory=dict)

class HITLGate:
    def __init__(self):
        loop = asyncio.get_event_loop()
        self._future: asyncio.Future[HITLDecision] = loop.create_future()

    def approve(self, notes: str = "") -> None:
        if not self._future.done():
            self._future.set_result(HITLDecision(approved=True, notes=notes))

    def reject(self, notes: str = "") -> None:
        if not self._future.done():
            self._future.set_result(HITLDecision(approved=False, notes=notes))

    async def wait(self, timeout_s: float = 3600) -> HITLDecision:
        return await asyncio.wait_for(self._future, timeout=timeout_s)
