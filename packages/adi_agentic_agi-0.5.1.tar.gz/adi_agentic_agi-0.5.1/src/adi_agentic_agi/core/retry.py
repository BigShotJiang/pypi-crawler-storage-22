from __future__ import annotations
from typing import Callable, TypeVar, Awaitable
from tenacity import retry, stop_after_attempt, wait_exponential

T = TypeVar("T")

def async_retry(attempts: int = 3, min_s: float = 0.2, max_s: float = 3.0):
    """Decorator for retrying async functions."""
    return retry(
        reraise=True,
        stop=stop_after_attempt(attempts),
        wait=wait_exponential(min=min_s, max=max_s),
    )
