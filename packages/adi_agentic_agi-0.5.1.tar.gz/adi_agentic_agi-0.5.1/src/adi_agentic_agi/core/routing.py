from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from .events import BusEvent

@dataclass(frozen=True)
class RoutingDecision:
    intended_for: Optional[list[str]] = None
    priority: Optional[int] = None
    tags_add: Optional[list[str]] = None

class ConfidenceRouter:
    """Simple policy engine: route/escalate based on confidence + tags.

    Extend/replace this class in enterprise deployments.
    """

    def __init__(self, low_conf_threshold: float = 0.6, high_stakes_tag: str = "high_stakes"):
        self.low_conf_threshold = low_conf_threshold
        self.high_stakes_tag = high_stakes_tag

    def decide(self, event: BusEvent) -> RoutingDecision:
        # If low confidence RESULT -> escalate to critic by tagging
        if event.type == "RESULT" and event.confidence is not None and event.confidence < self.low_conf_threshold:
            return RoutingDecision(tags_add=["needs_review"], priority=max(1, event.priority - 1))
        # If high stakes -> require HITL tag for guardrail agent
        if self.high_stakes_tag in (event.tags or []):
            return RoutingDecision(tags_add=["needs_hitl"], priority=1)
        return RoutingDecision()
