from __future__ import annotations
from typing import Optional, Set
from ..core.agent import BaseAgent
from ..core.decorators import agent_role
from ..core.events import BusEvent

@agent_role("retrospective")
class RetrospectiveAgent(BaseAgent):
    def topics(self) -> Optional[Set[str]]:
        return {"signal.failure"}

    def filter_event(self, event: BusEvent) -> bool:
        return event.topic == "signal.failure" and event.type == "ALERT"

    async def handle(self, event: BusEvent) -> None:
        await self.report(parent=event, topic="signal.prompt_patch",
                          text="Patch suggestion: Add explicit validation + structured output for next attempt.", confidence=0.8)
