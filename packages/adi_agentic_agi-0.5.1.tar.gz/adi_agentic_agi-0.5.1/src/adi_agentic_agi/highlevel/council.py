from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass
from typing import Optional, Sequence

from ..core.bus import CognitiveBus
from ..core.agent import BaseAgent
from ..core.context import ContextObject
from ..core.events import BusEvent

@dataclass
class CouncilResult:
    thread_id: str
    final_text: str
    final_event: BusEvent

class Council:
    """CrewAI-like convenience wrapper around the CognitiveBus."""

    def __init__(self, agents: Sequence[BaseAgent], *, bus: Optional[CognitiveBus] = None):
        self.bus = bus or CognitiveBus()
        self.agents = agents
        for a in self.agents:
            a.bus = self.bus  # type: ignore
            a.subscribe()

    async def run(
        self,
        goal: str,
        *,
        wait_for_topic: str = "result.final",
        timeout_s: float = 60.0,
        thread_id: Optional[str] = None,
        tags: Optional[list[str]] = None,
    ) -> CouncilResult:
        tid = thread_id or str(uuid.uuid4())
        loop = asyncio.get_event_loop()
        done: asyncio.Future[BusEvent] = loop.create_future()

        async def _watch(ev: BusEvent) -> None:
            if ev.thread_id == tid and ev.topic == wait_for_topic and ev.type == "RESULT":
                if not done.done():
                    done.set_result(ev)

        self.bus.subscribe(agent_id="__council__", callback=_watch, topics={wait_for_topic})
        await self.bus.start()

        await self.bus.emit(
            topic="goal",
            type="TASK",
            sender="user",
            thread_id=tid,
            tags=tags or [],
            priority=1,
            context=ContextObject(text=goal),
        )

        ev = await asyncio.wait_for(done, timeout=timeout_s)
        await self.bus.stop()
        return CouncilResult(thread_id=tid, final_text=ev.context.text or "", final_event=ev)
