from __future__ import annotations
import time
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field

class ApprovalRequest(BaseModel):
    approval_id: str
    thread_id: str
    created_ts: float = Field(default_factory=lambda: time.time())
    title: str
    description: str = ""
    payload: Dict[str, Any] = Field(default_factory=dict)
    status: str = "PENDING"  # PENDING|APPROVED|REJECTED
    decided_ts: Optional[float] = None
    decided_by: Optional[str] = None
    decision_notes: Optional[str] = None

class ApprovalDecision(BaseModel):
    status: str  # APPROVED|REJECTED
    decided_by: str
    decision_notes: str = ""
