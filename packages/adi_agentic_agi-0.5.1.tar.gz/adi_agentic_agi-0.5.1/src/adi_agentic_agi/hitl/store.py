from __future__ import annotations
import asyncio
from typing import Dict, List, Optional
from .models import ApprovalRequest, ApprovalDecision

class InMemoryApprovalStore:
    def __init__(self):
        self._by_id: Dict[str, ApprovalRequest] = {}
        self._lock = asyncio.Lock()

    async def create(self, req: ApprovalRequest) -> None:
        async with self._lock:
            self._by_id[req.approval_id] = req

    async def list(self, *, thread_id: Optional[str] = None, status: Optional[str] = None) -> List[ApprovalRequest]:
        async with self._lock:
            items = list(self._by_id.values())
        if thread_id:
            items = [x for x in items if x.thread_id == thread_id]
        if status:
            items = [x for x in items if x.status == status]
        items.sort(key=lambda x: x.created_ts, reverse=True)
        return items

    async def get(self, approval_id: str) -> Optional[ApprovalRequest]:
        async with self._lock:
            return self._by_id.get(approval_id)

    async def decide(self, approval_id: str, decision: ApprovalDecision) -> Optional[ApprovalRequest]:
        async with self._lock:
            req = self._by_id.get(approval_id)
            if not req:
                return None
            req.status = decision.status
            req.decided_by = decision.decided_by
            req.decision_notes = decision.decision_notes
            import time
            req.decided_ts = time.time()
            self._by_id[approval_id] = req
            return req
