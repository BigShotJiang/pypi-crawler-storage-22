from __future__ import annotations
from typing import Optional
from .store import EventStore, Checkpoint

class CheckpointManager:
    def __init__(self, store: EventStore):
        self.store = store

    async def snapshot(self, notes: str = "") -> Checkpoint:
        return await self.store.checkpoint(notes=notes)
