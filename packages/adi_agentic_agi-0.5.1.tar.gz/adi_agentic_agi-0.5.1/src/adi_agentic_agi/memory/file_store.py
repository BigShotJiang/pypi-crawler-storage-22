from __future__ import annotations

import asyncio
import json
import os
from typing import List, Optional

from ..core.events import BusEvent
from .store import Checkpoint

class FileEventStore:
    """Durable store: JSON per event + JSONL per thread."""

    def __init__(self, root_dir: str):
        self.root_dir = root_dir
        self.threads_dir = os.path.join(root_dir, "threads")
        self.index_dir = os.path.join(root_dir, "index", "events")
        os.makedirs(self.threads_dir, exist_ok=True)
        os.makedirs(self.index_dir, exist_ok=True)

    async def put_event(self, event: BusEvent) -> None:
        payload = event.model_dump()
        await asyncio.to_thread(_write_json, os.path.join(self.index_dir, f"{event.event_id}.json"), payload)
        tid = event.thread_id or "default"
        await asyncio.to_thread(_append_jsonl, os.path.join(self.threads_dir, f"{tid}.jsonl"), payload)

    async def get_event(self, event_id: str) -> Optional[BusEvent]:
        path = os.path.join(self.index_dir, f"{event_id}.json")
        if not os.path.exists(path):
            return None
        data = await asyncio.to_thread(_read_json, path)
        return BusEvent.model_validate(data)

    async def list_recent(self, limit: int = 100, thread_id: Optional[str] = None) -> List[BusEvent]:
        tid = thread_id or "default"
        tpath = os.path.join(self.threads_dir, f"{tid}.jsonl")
        if not os.path.exists(tpath):
            return []
        lines = await asyncio.to_thread(_tail_lines, tpath, limit)
        out: List[BusEvent] = []
        for ln in lines:
            try:
                out.append(BusEvent.model_validate(json.loads(ln)))
            except Exception:
                continue
        return out

    async def checkpoint(self, notes: str = "") -> Checkpoint:
        import time, uuid
        return Checkpoint(checkpoint_id=str(uuid.uuid4()), ts=time.time(), notes=notes)


def _write_json(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f)


def _read_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _append_jsonl(path: str, data: dict) -> None:
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(data) + "\n")


def _tail_lines(path: str, limit: int) -> list[str]:
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    return [ln.strip() for ln in lines[-limit:]]
