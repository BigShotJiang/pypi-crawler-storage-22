from __future__ import annotations
from typing import List, Dict, Any

class RAGClient:
    def __init__(self, backend: str = "stub", **kwargs: Any):
        self.backend = backend
        self.kwargs = kwargs

    async def retrieve(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        return [{"text": "(stub) relevant context", "score": 0.0, "meta": {}}]
