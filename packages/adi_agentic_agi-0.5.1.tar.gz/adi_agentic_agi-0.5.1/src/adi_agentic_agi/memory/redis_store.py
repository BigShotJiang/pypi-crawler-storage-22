from __future__ import annotations
import json
import time
from dataclasses import dataclass
from typing import Optional, List

from ..core.events import BusEvent
from .store import Checkpoint

try:
    import redis.asyncio as redis
except Exception as e:  # pragma: no cover
    raise ImportError("Install extras: adi-agentic-agi[redis] for Redis store") from e

@dataclass
class RedisEventStore:
    """Redis-backed event store.

    Keys:
      - adi:ev:<event_id> -> JSON
      - adi:th:<thread_id> -> list of event_ids (LPUSH)
    """

    url: str

    def __post_init__(self):
        self._r = redis.from_url(self.url, decode_responses=True)

    async def put_event(self, event: BusEvent) -> None:
        p = event.model_dump()
        eid = p["event_id"]
        tid = p.get("thread_id") or "default"
        await self._r.set(f"adi:ev:{eid}", json.dumps(p))
        await self._r.lpush(f"adi:th:{tid}", eid)

    async def get_event(self, event_id: str) -> Optional[BusEvent]:
        raw = await self._r.get(f"adi:ev:{event_id}")
        if not raw:
            return None
        return BusEvent.model_validate(json.loads(raw))

    async def list_recent(self, limit: int = 100, thread_id: Optional[str] = None) -> List[BusEvent]:
        tid = thread_id or "default"
        ids = await self._r.lrange(f"adi:th:{tid}", 0, limit - 1)
        events: List[BusEvent] = []
        for eid in reversed(ids):
            ev = await self.get_event(eid)
            if ev:
                events.append(ev)
        return events

    async def checkpoint(self, notes: str = "") -> Checkpoint:
        import uuid
        return Checkpoint(checkpoint_id=str(uuid.uuid4()), ts=time.time(), notes=notes)
