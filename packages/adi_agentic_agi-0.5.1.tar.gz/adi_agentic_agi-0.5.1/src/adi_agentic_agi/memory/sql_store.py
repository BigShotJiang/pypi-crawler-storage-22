from __future__ import annotations
import json
import time
from typing import Optional, List
from dataclasses import dataclass

from ..core.events import BusEvent
from .store import Checkpoint

try:
    from sqlalchemy import (
        Table, Column, String, Float, Integer, Text, MetaData, select, insert
    )
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncEngine
except Exception as e:  # pragma: no cover
    raise ImportError("Install extras: adi-agentic-agi[db] for SQL stores") from e

metadata = MetaData()

events_table = Table(
    "adi_events",
    metadata,
    Column("event_id", String, primary_key=True),
    Column("thread_id", String, index=True, nullable=True),
    Column("ts", Float, nullable=False),
    Column("topic", String, index=True, nullable=False),
    Column("type", String, nullable=False),
    Column("sender", String, nullable=False),
    Column("parent_id", String, nullable=True),
    Column("tags_json", Text, nullable=False),
    Column("priority", Integer, nullable=False),
    Column("confidence", Float, nullable=True),
    Column("context_json", Text, nullable=False),
)

@dataclass
class SqlEventStore:
    """Async SQL event store (SQLite/Postgres).

    URL examples:
      - sqlite+aiosqlite:///./adi_events.db
      - postgresql+asyncpg://user:pass@host:5432/dbname
    """

    url: str
    engine: Optional[AsyncEngine] = None

    async def start(self) -> None:
        if self.engine is None:
            self.engine = create_async_engine(self.url, future=True)
        async with self.engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

    async def stop(self) -> None:
        if self.engine is not None:
            await self.engine.dispose()
            self.engine = None

    async def put_event(self, event: BusEvent) -> None:
        if self.engine is None:
            await self.start()
        assert self.engine is not None
        p = event.model_dump()
        stmt = insert(events_table).values(
            event_id=p["event_id"],
            thread_id=p.get("thread_id"),
            ts=float(p["ts"]),
            topic=p["topic"],
            type=p["type"],
            sender=p["sender"],
            parent_id=p.get("parent_id"),
            tags_json=json.dumps(p.get("tags") or []),
            priority=int(p.get("priority") or 5),
            confidence=p.get("confidence"),
            context_json=json.dumps(p.get("context") or {}),
        )
        async with self.engine.begin() as conn:
            await conn.execute(stmt)

    async def get_event(self, event_id: str) -> Optional[BusEvent]:
        if self.engine is None:
            await self.start()
        assert self.engine is not None
        stmt = select(events_table).where(events_table.c.event_id == event_id)
        async with self.engine.connect() as conn:
            row = (await conn.execute(stmt)).mappings().first()
        if not row:
            return None
        return _row_to_event(dict(row))

    async def list_recent(self, limit: int = 100, thread_id: Optional[str] = None) -> List[BusEvent]:
        if self.engine is None:
            await self.start()
        assert self.engine is not None
        stmt = select(events_table).order_by(events_table.c.ts.desc()).limit(limit)
        if thread_id:
            stmt = stmt.where(events_table.c.thread_id == thread_id)
        async with self.engine.connect() as conn:
            rows = (await conn.execute(stmt)).mappings().all()
        return list(reversed([_row_to_event(dict(r)) for r in rows]))

    async def checkpoint(self, notes: str = "") -> Checkpoint:
        import uuid
        return Checkpoint(checkpoint_id=str(uuid.uuid4()), ts=time.time(), notes=notes)

def _row_to_event(row: dict) -> BusEvent:
    ctx = json.loads(row["context_json"]) if row.get("context_json") else {}
    tags = json.loads(row["tags_json"]) if row.get("tags_json") else []
    return BusEvent(
        event_id=row["event_id"],
        thread_id=row.get("thread_id"),
        ts=float(row["ts"]),
        topic=row["topic"],
        type=row["type"],
        sender=row["sender"],
        parent_id=row.get("parent_id"),
        tags=tags,
        priority=int(row.get("priority") or 5),
        confidence=row.get("confidence"),
        context=ctx,
    )
