from __future__ import annotations

from typing import Optional, Protocol, List

from pydantic import BaseModel

from ..core.events import BusEvent

class Checkpoint(BaseModel):
    checkpoint_id: str
    ts: float
    notes: str = ""

class EventStore(Protocol):
    async def put_event(self, event: BusEvent) -> None: ...
    async def get_event(self, event_id: str) -> Optional[BusEvent]: ...
    async def list_recent(self, limit: int = 100, thread_id: Optional[str] = None) -> List[BusEvent]: ...
    async def checkpoint(self, notes: str = "") -> Checkpoint: ...

class InMemoryEventStore:
    def __init__(self):
        self._events: dict[str, BusEvent] = {}
        self._order: list[str] = []

    async def put_event(self, event: BusEvent) -> None:
        if event.event_id not in self._events:
            self._order.append(event.event_id)
        self._events[event.event_id] = event

    async def get_event(self, event_id: str) -> Optional[BusEvent]:
        return self._events.get(event_id)

    async def list_recent(self, limit: int = 100, thread_id: Optional[str] = None) -> List[BusEvent]:
        ids = self._order[-limit:]
        events = [self._events[i] for i in ids]
        if thread_id:
            events = [e for e in events if e.thread_id == thread_id]
        return events

    async def checkpoint(self, notes: str = "") -> Checkpoint:
        import time, uuid
        return Checkpoint(checkpoint_id=str(uuid.uuid4()), ts=time.time(), notes=notes)
