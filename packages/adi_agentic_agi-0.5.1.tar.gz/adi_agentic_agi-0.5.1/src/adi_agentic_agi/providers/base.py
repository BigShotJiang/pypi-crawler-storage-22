from __future__ import annotations
from typing import Any, Dict, List, Optional, Protocol
from pydantic import BaseModel, Field

Json = Dict[str, Any]

class LLMMessage(BaseModel):
    role: str
    content: str
    meta: Json = Field(default_factory=dict)

class LLMResponse(BaseModel):
    text: str
    raw: Json = Field(default_factory=dict)

class ProviderConfig(BaseModel):
    provider: str
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    timeout_s: float = 60.0
    extra: Json = Field(default_factory=dict)

class Provider(Protocol):
    config: ProviderConfig
    async def generate(self, messages: List[LLMMessage], **kwargs: Any) -> LLMResponse: ...
