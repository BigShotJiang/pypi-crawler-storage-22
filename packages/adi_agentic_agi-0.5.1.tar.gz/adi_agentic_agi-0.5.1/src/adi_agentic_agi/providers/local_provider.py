from __future__ import annotations
from typing import Any, List
from .base import ProviderConfig, LLMMessage, LLMResponse

class LocalProvider:
    def __init__(self, config: ProviderConfig):
        self.config = config

    async def generate(self, messages: List[LLMMessage], **kwargs: Any) -> LLMResponse:
        last = next((m.content for m in reversed(messages) if m.role == "user"), "")
        return LLMResponse(text=f"[LOCAL:{self.config.model}] {last}", raw={"stub": True})
