from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional

from .registry import ToolRegistry
from ..providers.base import Provider, LLMMessage

@dataclass
class ToolLoopResult:
    ok: bool
    text: str
    tool_calls: int = 0
    last_tool: Optional[str] = None

class ToolCallingLoop:
    """Provider-agnostic tool loop using strict JSON protocol."""

    def __init__(self, provider: Provider, registry: ToolRegistry, *, max_iters: int = 6):
        self.provider = provider
        self.registry = registry
        self.max_iters = max_iters

    async def run(self, system: str, user: str) -> ToolLoopResult:
        tool_calls = 0
        last_tool: Optional[str] = None
        transcript: list[str] = []

        for _ in range(self.max_iters):
            resp = await self.provider.generate([
                LLMMessage(role="system", content=system),
                LLMMessage(role="user", content=user + "\n\n" + "\n".join(transcript)),
            ])
            raw = (resp.text or "").strip()
            try:
                obj = json.loads(raw)
            except Exception:
                return ToolLoopResult(ok=False, text=f"Non-JSON response: {raw}", tool_calls=tool_calls, last_tool=last_tool)

            if "final" in obj:
                return ToolLoopResult(ok=True, text=str(obj["final"]), tool_calls=tool_calls, last_tool=last_tool)

            if "tool" in obj:
                name = str(obj["tool"])
                args = obj.get("args") or {}
                tool = self.registry.get(name)
                if not tool:
                    return ToolLoopResult(ok=False, text=f"Unknown tool: {name}", tool_calls=tool_calls, last_tool=name)
                out = await tool.fn(**args)
                tool_calls += 1
                last_tool = name
                transcript.append(f"TOOL[{name}] args={args} -> {out}")
                continue

            return ToolLoopResult(ok=False, text=f"Invalid protocol: {obj}", tool_calls=tool_calls, last_tool=last_tool)

        return ToolLoopResult(ok=False, text="Max iterations reached", tool_calls=tool_calls, last_tool=last_tool)
