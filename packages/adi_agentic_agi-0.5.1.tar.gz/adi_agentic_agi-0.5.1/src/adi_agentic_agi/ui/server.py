from __future__ import annotations
import asyncio
import json
from typing import Optional, Dict, Any, List

try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect
    from fastapi.responses import HTMLResponse, JSONResponse
except Exception as e:  # pragma: no cover
    raise ImportError("Install extras: adi-agentic-agi[ui] to use the web dashboard") from e

from ..core.bus import CognitiveBus
from ..hitl.store import InMemoryApprovalStore
from ..hitl.models import ApprovalRequest, ApprovalDecision

class WSManager:
    def __init__(self):
        self._clients: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self._clients.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self._clients:
            self._clients.remove(ws)

    async def broadcast(self, msg: Dict[str, Any]):
        dead: List[WebSocket] = []
        for ws in list(self._clients):
            try:
                await ws.send_text(json.dumps(msg))
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

def create_app(
    *,
    bus: CognitiveBus,
    approvals: Optional[InMemoryApprovalStore] = None,
    title: str = "ADI Agentic AGI Dashboard",
) -> FastAPI:
    app = FastAPI(title=title)
    approvals = approvals or InMemoryApprovalStore()
    wsman = WSManager()

    @app.get("/", response_class=HTMLResponse)
    async def home():
        return HTMLResponse(_INDEX_HTML)

    @app.get("/api/threads")
    async def threads():
        snap = bus.snapshot(10000)
        tids: List[str] = []
        seen = set()
        for ev in reversed(snap):
            tid = ev.thread_id or "default"
            if tid not in seen:
                seen.add(tid)
                tids.append(tid)
        return {"threads": tids}

    @app.get("/api/events")
    async def events(thread_id: Optional[str] = None, limit: int = 500):
        snap = bus.snapshot(10000)
        out = []
        for ev in snap[-limit:]:
            if thread_id and (ev.thread_id or "default") != thread_id:
                continue
            out.append(ev.model_dump())
        return {"events": out}

    @app.get("/api/approvals")
    async def list_approvals(thread_id: Optional[str] = None, status: Optional[str] = None):
        items = await approvals.list(thread_id=thread_id, status=status)
        return {"approvals": [x.model_dump() for x in items]}

    @app.post("/api/approvals/create")
    async def create_approval(req: Dict[str, Any]):
        ar = ApprovalRequest.model_validate(req)
        await approvals.create(ar)
        await wsman.broadcast({"type": "approval.created", "approval": ar.model_dump()})
        return {"ok": True, "approval": ar.model_dump()}

    @app.post("/api/approvals/{approval_id}/decide")
    async def decide(approval_id: str, decision: Dict[str, Any]):
        dec = ApprovalDecision.model_validate(decision)
        updated = await approvals.decide(approval_id, dec)
        if not updated:
            return JSONResponse({"ok": False, "error": "not_found"}, status_code=404)
        await wsman.broadcast({"type": "approval.decided", "approval": updated.model_dump()})
        return {"ok": True, "approval": updated.model_dump()}

    @app.websocket("/ws")
    async def ws(ws: WebSocket):
        await wsman.connect(ws)
        try:
            while True:
                _ = await ws.receive_text()  # keep alive
        except WebSocketDisconnect:
            wsman.disconnect(ws)

    @app.on_event("startup")
    async def _startup():
        app.state._poll_task = asyncio.create_task(_poll_events(bus, wsman))

    @app.on_event("shutdown")
    async def _shutdown():
        t = getattr(app.state, "_poll_task", None)
        if t:
            t.cancel()

    return app

async def _poll_events(bus: CognitiveBus, wsman: WSManager, interval_s: float = 0.5):
    last = 0
    while True:
        snap = bus.snapshot(10000)
        if len(snap) != last:
            new = snap[last:]
            last = len(snap)
            for ev in new:
                await wsman.broadcast({"type": "bus.event", "event": ev.model_dump()})
        await asyncio.sleep(interval_s)

_INDEX_HTML = """<!doctype html>
<html>
<head>
  <meta charset=\"utf-8\"/>
  <title>ADI Agentic AGI Dashboard</title>
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 0; }
    header { padding: 12px 16px; border-bottom: 1px solid #ddd; display:flex; gap:12px; align-items:center;}
    #wrap { display:flex; height: calc(100vh - 50px); }
    #left { width: 320px; border-right: 1px solid #ddd; padding: 12px; overflow:auto; }
    #main { flex:1; padding: 12px; overflow:auto; }
    .card { border: 1px solid #ddd; border-radius: 10px; padding: 10px; margin-bottom: 10px; }
    .row { display:flex; gap:8px; align-items:center; }
    select, button, input { padding: 6px 8px; }
    pre { white-space: pre-wrap; word-wrap: break-word; }
    .pill { font-size: 12px; padding: 2px 8px; border: 1px solid #ccc; border-radius: 999px; }
    .ok { background:#e7f7ec; }
    .warn { background:#fff4e5; }
    .bad { background:#fde8e8; }
    table { width:100%; border-collapse: collapse; }
    td, th { border-bottom:1px solid #eee; padding: 6px; font-size: 13px; text-align:left; }
    .muted { color:#666; font-size: 12px; }
  </style>
</head>
<body>
<header>
  <strong>ADI Agentic AGI</strong>
  <span class=\"pill\">Trace Explorer</span>
  <span class=\"pill\">HITL Approvals</span>
  <span class=\"pill\">Council Status</span>
  <div style=\"flex:1\"></div>
  <span class=\"muted\" id=\"status\">disconnected</span>
</header>
<div id=\"wrap\">
  <div id=\"left\">
    <div class=\"card\">
      <div class=\"row\">
        <label>Thread</label>
        <select id=\"thread\"></select>
        <button onclick=\"refreshAll()\">Refresh</button>
      </div>
      <div class=\"muted\">Select a thread to view timeline and approvals.</div>
    </div>
    <div class=\"card\">
      <h3 style=\"margin:0 0 8px 0;\">Approvals (HITL)</h3>
      <button onclick=\"createDemoApproval()\">Create demo approval</button>
      <div id=\"approvals\"></div>
    </div>
  </div>
  <div id=\"main\">
    <div class=\"card\">
      <h3 style=\"margin:0 0 8px 0;\">Timeline</h3>
      <div class=\"muted\">Live bus events filtered by thread.</div>
      <table id=\"eventsTbl\">
        <thead><tr><th>ts</th><th>topic</th><th>type</th><th>sender</th><th>confidence</th></tr></thead>
        <tbody></tbody>
      </table>
    </div>
    <div class=\"card\">
      <h3 style=\"margin:0 0 8px 0;\">Event Detail</h3>
      <pre id=\"detail\">(click an event row)</pre>
    </div>
  </div>
</div>

<script>
let ws = null;
let events = [];
let approvals = [];
let currentThread = null;

function fmtTs(ts){
  const d = new Date(ts*1000);
  return d.toLocaleTimeString();
}

async function loadThreads(){
  const res = await fetch('/api/threads');
  const j = await res.json();
  const sel = document.getElementById('thread');
  sel.innerHTML = '';
  j.threads.forEach(t=>{
    const o=document.createElement('option');
    o.value=t; o.textContent=t;
    sel.appendChild(o);
  });
  currentThread = sel.value || 'default';
  sel.onchange = ()=>{ currentThread = sel.value; renderEvents(); refreshApprovals(); };
}

async function loadEvents(){
  const res = await fetch('/api/events?thread_id='+encodeURIComponent(currentThread)+'&limit=800');
  const j = await res.json();
  events = j.events || [];
  renderEvents();
}

async function refreshApprovals(){
  const res = await fetch('/api/approvals?thread_id='+encodeURIComponent(currentThread));
  const j = await res.json();
  approvals = j.approvals || [];
  renderApprovals();
}

function renderEvents(){
  const tbody = document.querySelector('#eventsTbl tbody');
  tbody.innerHTML='';
  events.forEach(ev=>{
    const tid = ev.thread_id || 'default';
    if (tid !== currentThread) return;
    const tr=document.createElement('tr');
    tr.innerHTML = `<td>${fmtTs(ev.ts)}</td><td>${ev.topic}</td><td>${ev.type}</td><td>${ev.sender}</td><td>${ev.confidence ?? ''}</td>`;
    tr.onclick = ()=>{ document.getElementById('detail').textContent = JSON.stringify(ev,null,2); };
    tbody.appendChild(tr);
  });
}

function renderApprovals(){
  const div = document.getElementById('approvals');
  div.innerHTML='';
  approvals.forEach(a=>{
    const cls = a.status==='APPROVED'?'ok':(a.status==='REJECTED'?'bad':'warn');
    const el=document.createElement('div');
    el.className='card '+cls;
    el.innerHTML = `<div class="row"><strong>${a.title}</strong><span class="pill">${a.status}</span></div>
      <div class="muted">${a.description||''}</div>
      <div class="row" style="margin-top:8px;">
        <button onclick="decide('${a.approval_id}','APPROVED')">Approve</button>
        <button onclick="decide('${a.approval_id}','REJECTED')">Reject</button>
      </div>`;
    div.appendChild(el);
  });
}

async function decide(id, status){
  await fetch('/api/approvals/'+id+'/decide', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({status: status, decided_by: 'human', decision_notes:''})
  });
}

async function createDemoApproval(){
  const id = crypto.randomUUID();
  await fetch('/api/approvals/create', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      approval_id: id,
      thread_id: currentThread || 'default',
      title: 'High-stakes action',
      description: 'Approve this action before execution.',
      payload: {example:true},
      status: 'PENDING'
    })
  });
}

async function refreshAll(){
  await loadThreads();
  await loadEvents();
  await refreshApprovals();
}

function connectWS(){
  ws = new WebSocket((location.protocol==='https:'?'wss://':'ws://') + location.host + '/ws');
  ws.onopen = ()=>{ document.getElementById('status').textContent='connected'; };
  ws.onclose = ()=>{ document.getElementById('status').textContent='disconnected'; setTimeout(connectWS, 1000); };
  ws.onmessage = (m)=>{
    const msg = JSON.parse(m.data);
    if (msg.type==='bus.event'){
      events.push(msg.event);
      if (events.length>2000) events = events.slice(events.length-2000);
      renderEvents();
    }
    if (msg.type==='approval.created' || msg.type==='approval.decided'){
      refreshApprovals();
    }
  };
}

(async ()=>{
  await loadThreads();
  await loadEvents();
  await refreshApprovals();
  connectWS();
})();
</script>
</body>
</html>"""
