from __future__ import annotations
import asyncio
from ..core.bus import CognitiveBus
from ..core.agent import AgentConfig
from ..providers.base import ProviderConfig
from ..providers.local_provider import LocalProvider
from ..council.orchestrator import OrchestratorAgent
from ..council.context_librarian import ContextLibrarianAgent
from ..council.tool_smith import ToolSmithAgent
from ..council.critic import CriticRefinerAgent
from ..council.ethics_guard import EthicsGuardrailAgent
from ..council.retrospective import RetrospectiveAgent
from ..core.context import ContextObject

async def run():
    bus = CognitiveBus()
    await bus.start()
    provider = LocalProvider(ProviderConfig(provider="local", model="stub-llm"))

    agents = [
        OrchestratorAgent(config=AgentConfig(agent_id="orchestrator", retry_attempts=2), bus=bus, provider=provider),
        ContextLibrarianAgent(config=AgentConfig(agent_id="librarian", retry_attempts=2), bus=bus, provider=provider),
        ToolSmithAgent(config=AgentConfig(agent_id="tool_smith", retry_attempts=1, extra={"tool_smith_container": False}),
                      bus=bus, provider=provider),
        CriticRefinerAgent(config=AgentConfig(agent_id="critic", retry_attempts=1), bus=bus, provider=provider),
        EthicsGuardrailAgent(config=AgentConfig(agent_id="ethics", retry_attempts=1), bus=bus, provider=provider),
        RetrospectiveAgent(config=AgentConfig(agent_id="retro", retry_attempts=1), bus=bus, provider=provider),
    ]
    for a in agents:
        a.subscribe()

    await bus.emit(
        topic="goal",
        type="TASK",
        sender="user",
        context=ContextObject(text="Design a caching layer for API responses with TTL + tests."),
        priority=1,
    )

    await asyncio.sleep(1.0)
    for e in bus.snapshot()[-25:]:
        t = (e.context.text or "").replace("\n", " ")
        if len(t) > 90:
            t = t[:90] + "..."
        print(f"{e.type:<6} {e.topic:<18} sender={e.sender} conf={e.confidence} prio={e.priority} text={t!r}")
    await bus.stop()

if __name__ == "__main__":
    asyncio.run(run())
