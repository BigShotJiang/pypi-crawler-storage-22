import pytest
from adi_agentic_agi.highlevel.council import Council
from adi_agentic_agi.core.agent import AgentConfig
from adi_agentic_agi.providers.local_provider import LocalProvider
from adi_agentic_agi.providers.base import ProviderConfig
from adi_agentic_agi.council.orchestrator import OrchestratorAgent
from adi_agentic_agi.council.tool_smith import ToolSmithAgent
from adi_agentic_agi.council.critic import CriticRefinerAgent

@pytest.mark.asyncio
async def test_council_run_returns_final():
    provider = LocalProvider(ProviderConfig(provider="local", model="stub"))
    agents = [
        OrchestratorAgent(config=AgentConfig(agent_id="orch"), bus=None, provider=provider),  # type: ignore
        ToolSmithAgent(config=AgentConfig(agent_id="smith"), bus=None, provider=provider),  # type: ignore
        CriticRefinerAgent(config=AgentConfig(agent_id="critic"), bus=None, provider=provider),  # type: ignore
    ]
    council = Council(agents)
    res = await council.run("Do something small", timeout_s=5)
    assert res.thread_id
    assert isinstance(res.final_text, str)
