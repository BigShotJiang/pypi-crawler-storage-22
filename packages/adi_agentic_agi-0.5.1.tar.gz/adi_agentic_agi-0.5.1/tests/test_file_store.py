import pytest
from adi_agentic_agi.memory.file_store import FileEventStore
from adi_agentic_agi.core.events import BusEvent
from adi_agentic_agi.core.context import ContextObject

@pytest.mark.asyncio
async def test_file_store_roundtrip(tmp_path):
    store = FileEventStore(str(tmp_path))
    ev = BusEvent(event_id="e1", thread_id="t1", topic="x", type="TASK", sender="u", context=ContextObject(text="hi"))
    await store.put_event(ev)
    got = await store.get_event("e1")
    assert got is not None
    assert got.thread_id == "t1"
    rec = await store.list_recent(limit=10, thread_id="t1")
    assert len(rec) == 1
    assert rec[0].event_id == "e1"
