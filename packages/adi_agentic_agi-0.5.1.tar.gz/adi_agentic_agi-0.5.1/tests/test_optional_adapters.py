import pytest


@pytest.mark.asyncio
async def test_sql_store_optional():
    try:
        from adi_agentic_agi.memory.sql_store import SqlEventStore
    except Exception:
        pytest.skip("db extras not installed")
    store = SqlEventStore("sqlite+aiosqlite:///:memory:")
    await store.start()
    await store.stop()

@pytest.mark.asyncio
async def test_redis_store_optional():
    try:
        from adi_agentic_agi.memory.redis_store import RedisEventStore
    except Exception:
        pytest.skip("redis extras not installed")
    _ = RedisEventStore("redis://localhost:6379/0")

def test_ui_optional_import():
    try:
        from adi_agentic_agi.ui.server import create_app  # noqa
    except Exception:
        pytest.skip("ui extras not installed")
