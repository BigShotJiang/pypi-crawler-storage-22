from adi_agentic_agi.core.decorators import list_roles
from adi_agentic_agi.council import orchestrator, critic, tool_smith, context_librarian, ethics_guard, retrospective  # noqa: F401

def test_roles_registered():
    roles = list_roles()
    assert "orchestrator" in roles
    assert "critic" in roles
    assert "tool_smith" in roles
    assert "context_librarian" in roles
