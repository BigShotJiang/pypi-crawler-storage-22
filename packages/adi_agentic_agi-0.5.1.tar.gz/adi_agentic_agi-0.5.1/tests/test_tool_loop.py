import pytest
from adi_agentic_agi.tools.registry import ToolRegistry, ToolSpec
from adi_agentic_agi.tools.runner import ToolCallingLoop
from adi_agentic_agi.providers.base import ProviderConfig, LLMResponse

class FakeProvider:
    def __init__(self):
        self.config = ProviderConfig(provider="fake", model="fake")
        self.calls = 0

    async def generate(self, messages, **kwargs):
        self.calls += 1
        if self.calls == 1:
            return LLMResponse(text='{"tool":"add","args":{"a":2,"b":3}}')
        return LLMResponse(text='{"final":"Answer is 5"}')

@pytest.mark.asyncio
async def test_tool_calling_loop_executes_tool():
    reg = ToolRegistry()
    async def add(a:int, b:int): return a + b
    reg.register(ToolSpec(name="add"), add)
    loop = ToolCallingLoop(FakeProvider(), reg, max_iters=4)
    res = await loop.run(system="Return JSON", user="Compute 2+3")
    assert res.ok is True
    assert "5" in res.text
    assert res.tool_calls == 1
