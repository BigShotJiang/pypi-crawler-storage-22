# Copyright (c) IBM Corporation
# SPDX-License-Identifier: MIT

SECONDS_IN_A_MINUTE = 60
SECONDS_IN_AN_HOUR = 3600
SECONDS_IN_A_DAY = 86400
