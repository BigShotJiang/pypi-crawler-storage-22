"""ado-git-repo-insights: Azure DevOps PR metrics extraction and CSV generation."""

__version__ = "0.0.0"  # Managed by setuptools_scm
