"""Extractor module for Azure DevOps API interactions."""
