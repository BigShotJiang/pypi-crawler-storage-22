# Adorablize Your AI!

Adorablize is a framework for making AIs perform better and become more adorable!
I.e., it adorablizes AIs!
