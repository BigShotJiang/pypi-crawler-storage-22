class DataStore:
