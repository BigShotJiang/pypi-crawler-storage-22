"""
Core abstractions.

Rollout abstraction:

- Each rollout contains multiple actors;
- During the rollout, each actor can submit trajectory updates
(e.g., new tool call, new tool call result, etc.)
as it interacts with the environment.
"""

from .actor import Actor
from .rollout import Rollout


__all__ = ['Actor', 'Rollout']
