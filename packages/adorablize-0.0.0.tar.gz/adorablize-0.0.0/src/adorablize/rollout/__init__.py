"""
Various utilities for building rollouts.
"""