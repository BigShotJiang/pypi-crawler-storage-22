import random


def split_rngs(rng: random.Random, n_splits: int) -> list[random.Random]:
    child_seeds = [rng.getrandbits(64) for _ in range(n_splits)]

    return [random.Random(s) for s in child_seeds]
