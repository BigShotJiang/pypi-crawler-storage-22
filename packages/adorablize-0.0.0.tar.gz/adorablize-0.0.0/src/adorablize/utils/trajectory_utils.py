from typing import TypeVar


U = TypeVar('U')


def split_trajectories(trajectories: list[tuple[str, U]]) -> dict[str, list[U]]:
    """
    Splits a trajectory update list containing trajectories of multiple actors
    into separate trajectories for each actor, based on ID.
    :param trajectories: The aggregated trajectories to split.
    The string part in each tuple in the list is expected to be the ID of the actor.
    :return:
    """

    # TODO
    raise NotImplementedError()
