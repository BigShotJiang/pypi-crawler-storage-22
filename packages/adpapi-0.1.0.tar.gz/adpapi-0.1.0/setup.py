from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="adpapi",
    version="1.0.0",
    author="Joey Russoniello",
    description="A robust client library for ADP Workforce Now API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/JoeyRussoniello/Adp-Api-Client",
    py_modules=["client", "sessions", "logger", "main"],
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.10",
    include_package_data=True,
    zip_safe=False,
)
