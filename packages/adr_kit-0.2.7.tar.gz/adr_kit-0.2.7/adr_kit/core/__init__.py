"""Core ADR Kit functionality."""
