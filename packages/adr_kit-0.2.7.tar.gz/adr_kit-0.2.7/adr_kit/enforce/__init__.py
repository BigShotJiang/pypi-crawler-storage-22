"""ADR enforcement functionality."""
