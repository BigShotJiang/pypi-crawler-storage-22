"""ADR indexing functionality."""
