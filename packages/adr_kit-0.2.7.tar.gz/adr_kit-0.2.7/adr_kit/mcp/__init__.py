"""MCP server functionality."""
