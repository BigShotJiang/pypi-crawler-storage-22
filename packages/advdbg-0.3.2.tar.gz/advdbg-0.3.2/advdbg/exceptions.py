"""

Advanced Debugger
Exception list

"""



class OutputListError(Exception):
    """
    
    Raised when detected error
    in list
    
    """
    
    pass
    
class TelegramAuthException(Exception):
    """
    
    Raised when API Telegram returns "Unauthorized" error
    
    """ 
    
    pass