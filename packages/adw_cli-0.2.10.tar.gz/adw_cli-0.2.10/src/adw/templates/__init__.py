"""Template files for ADW project initialization."""
