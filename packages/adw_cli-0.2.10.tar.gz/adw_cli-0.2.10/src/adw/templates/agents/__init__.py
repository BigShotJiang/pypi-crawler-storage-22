"""Agent templates for ADW."""
