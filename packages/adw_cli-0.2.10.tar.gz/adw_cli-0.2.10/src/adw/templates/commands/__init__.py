"""Command templates for ADW."""
