# Tasks

This file tracks tasks created by ADW orchestration.

## Active Tasks

<!-- Tasks are added here by /discuss and /approve_spec commands -->

## Completed Tasks

<!-- Completed tasks are moved here for reference -->
