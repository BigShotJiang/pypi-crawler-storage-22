""" project_tpls unit tests. """
from aedev.project_tpls import __version__


class TestDummyClass:
    def test_dummy(self):
        assert __version__
