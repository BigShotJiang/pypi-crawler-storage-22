import os
import cv2
import hashlib
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import blind_watermark
from blind_watermark import WaterMark

# 关闭 blind-watermark 的欢迎提示信息
blind_watermark.bw_notes.close()

class FrequencyWatermarker:
    """
    基于频域盲水印 (DCT/DWT) 的核心实现。
    安全增强版：支持字符串密钥 + SHA-256 哈希映射，彻底杜绝撞库。
    """
    def __init__(self, key: str = "1"):
        # 将字符串密钥转为哈希，提取前 8 字节转为大整数作为种子
        # 即使只取一部分，其空间也达到了 2^64，远超 2^32
        hash_digest = hashlib.sha256(str(key).encode()).digest()
        seed = int.from_bytes(hash_digest[:8], byteorder='big') % (2**32)
        
        self.pwd_wm = seed
        self.pwd_img = seed
        self.wm_size = (64, 64)  # 固定水印图尺寸

    def _text_to_wm_image(self, text):
        """将文字转为 64x64 的黑白位图"""
        img = Image.new('1', self.wm_size, 0)
        draw = ImageDraw.Draw(img)
        
        try:
            font = ImageFont.load_default()
        except:
            font = None

        # 简单的自动换行逻辑：如果长度超过 7 个字符且包含下划线或较长，尝试分两行
        if len(text) > 7:
            mid = len(text) // 2
            # 尝试在中间寻找分割点
            text_lines = [text[:mid], text[mid:]]
            y_offset = 15
            for line in text_lines:
                # 获取行尺寸以居中
                bbox = draw.textbbox((0, 0), line, font=font)
                w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
                draw.text(((self.wm_size[0] - w) // 2, y_offset), line, font=font, fill=1)
                y_offset += 20
        else:
            # 短文字直接居中
            bbox = draw.textbbox((0, 0), text, font=font)
            w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
            draw.text(((self.wm_size[0] - w) // 2, (self.wm_size[1] - h) // 2), text, font=font, fill=1)
        
        temp_wm_path = "temp_wm.png"
        img.save(temp_wm_path)
        return temp_wm_path

    def embed(self, input_path: str, output_path: str, text: str):
        """嵌入水印"""
        temp_wm = self._text_to_wm_image(text)
        try:
            bwm = WaterMark(password_wm=self.pwd_wm, password_img=self.pwd_img)
            bwm.read_img(input_path)
            bwm.read_wm(temp_wm) # 以图片模式读取
            bwm.embed(output_path)
            return True
        except Exception as e:
            print(f"[Error] Failed to embed image watermark: {e}")
            return False
        finally:
            if os.path.exists(temp_wm):
                os.remove(temp_wm)

    def extract(self, input_path: str, output_wm_path: str = None) -> str:
        """提取水印"""
        if output_wm_path is None:
            # 在同一目录下生成提取结果
            output_wm_path = input_path + "_wm.png"
            
        try:
            bwm = WaterMark(password_wm=self.pwd_wm, password_img=self.pwd_img)
            # 图片模式提取，固定 shape
            bwm.extract(input_path, wm_shape=self.wm_size, out_wm_name=output_wm_path, mode='img')
            return output_wm_path
        except Exception as e:
            # print(f"[Error] Failed to extract image watermark: {e}")
            return ""