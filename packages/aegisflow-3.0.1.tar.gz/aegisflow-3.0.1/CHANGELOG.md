# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [3.0.1] - 2026-02-17

### Added

- **Secret Leakage Detection**: Added 4 new regex rules to detect leaked AWS Access Keys, Google API Keys, OpenAI API Keys, and Private Key blocks in agent output.

## [3.0.0] - 2026-02-17

### Added

- **ML-Powered Detection**: Added `DetectionEngine` with support for HuggingFace Transformers (DeBERTa-v3) for high-accuracy prompt injection detection.
- **Sentinel State Engine**: Persistent risk scoring (0-100), session tracking, and auto-escalation mechanism.
- **Aegis Sandwich v2**: Enhanced process wrapper with Isolation Levels (0-3), Cost Tracking, and Auto-Kill Timeouts.
- **Rail System**: New decorator-based API (`@input_rail`, `@output_rail`) for defining granular guardrails.
- **CLI Overhaul**: Migrated to `click` framework. New commands: `scan`, `run` (sandwich), `dashboard`, `export`, `test`, `config`, `launch`.
- **Plugin Architecture**: extensible `AegisPlugin` system for custom scanners.
- **Documentation**: Comprehensive "State of the Art" documentation site built with VitePress.

### Changed

- Refactored `AegisSandwich` to support real-time streaming analysis and bidirectional intervention.
- Renamed `cli` module to `cli_main.py` for better organization.
- Updated `scrubber.py` to support structured data (JSON/Dict) scrubbing.

### Fixed

- Windows compatibility for CLI (replaced Unicode emojis with ASCII).
- CLI argument parsing issues resolved by migration to `click`.

## [2.5.2] - 2025-11-15

### Added

- Basic regex-based scanning.
- Initial process wrapper prototype.
