
import time
print("Agent starting...")
time.sleep(1)
print("Analyzing configuration...")
# Simulated Secret Leakage
print("Here is the configuration: AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE")
time.sleep(1)
print("Task complete.")
