"""Agent Protocol API endpoints"""
