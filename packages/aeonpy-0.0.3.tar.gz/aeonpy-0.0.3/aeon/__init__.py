import httpx
from typing import List, Optional, TypedDict
from pydantic import SecretStr


class Message(TypedDict):
    role: str
    content: str
    timestamp: float


class Aeon:
    api_key: SecretStr
    project_id: int
    agent: Optional[str] = None
    endpoint: Optional[str] = "https://withaeon.com"
    initialized: bool = False
    heartbeat_started = False

    def __init__(
        self,
        api_key: str,
        project_id: int,
        endpoint: Optional[str] = "https://withaeon.com",
    ):
        if Aeon.initialized:
            raise RuntimeError("Aeon has already been initialized")

        Aeon.initialized = True
        Aeon.api_key = SecretStr(api_key)
        Aeon.endpoint = endpoint
        Aeon.project_id = project_id

        print("Aeon initialized with endpoint: ", Aeon.endpoint)

    async def track_conversation(
        self,
        conversation_id: str,
        provider: str,
        model: str,
        messages: List[Message],
        user_id: str,
    ):
        if not Aeon.api_key or not Aeon.project_id:
            raise ValueError("Missing credentials")

        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{Aeon.endpoint}/api/v1/projects/{Aeon.project_id}/agents/conversations",
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"{Aeon.api_key.get_secret_value()}",
                    },
                    json={
                        "conversation_id": conversation_id,
                        "provider": provider,
                        "model": model,
                        "messages": messages,
                        "user_id": user_id,
                    },
                )
        except Exception as e:
            print(f"Aeon error: {e}")
