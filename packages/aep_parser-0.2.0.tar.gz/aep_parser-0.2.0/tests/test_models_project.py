"""Tests for Project model parsing."""

from __future__ import annotations

from pathlib import Path

import pytest
from conftest import get_sample_files, load_expected, parse_project

from aep_parser import Project

SAMPLES_DIR = Path(__file__).parent.parent / "samples" / "models" / "project"


@pytest.mark.parametrize("sample_name", get_sample_files(SAMPLES_DIR))
def test_parse_project_sample(sample_name: str) -> None:
    """Each project sample can be parsed without error."""
    aep_path = SAMPLES_DIR / f"{sample_name}.aep"
    project = parse_project(aep_path)
    assert isinstance(project, Project)


class TestBitsPerChannel:
    """Tests for bitsPerChannel attribute."""

    def test_8bpc(self) -> None:
        expected = load_expected(SAMPLES_DIR, "bitsPerChannel_8")
        project = parse_project(SAMPLES_DIR / "bitsPerChannel_8.aep")
        assert expected["bitsPerChannel"] == 8
        assert project.bits_per_channel.value == expected["bitsPerChannel"]

    def test_16bpc(self) -> None:
        expected = load_expected(SAMPLES_DIR, "bitsPerChannel_16")
        project = parse_project(SAMPLES_DIR / "bitsPerChannel_16.aep")
        assert expected["bitsPerChannel"] == 16
        assert project.bits_per_channel.value == expected["bitsPerChannel"]

    def test_32bpc(self) -> None:
        expected = load_expected(SAMPLES_DIR, "bitsPerChannel_32")
        project = parse_project(SAMPLES_DIR / "bitsPerChannel_32.aep")
        assert expected["bitsPerChannel"] == 32
        assert project.bits_per_channel.value == expected["bitsPerChannel"]


class TestExpressionEngine:
    """Tests for expressionEngine attribute."""

    def test_javascript(self) -> None:
        expected = load_expected(SAMPLES_DIR, "expressionEngine_javascript")
        project = parse_project(SAMPLES_DIR / "expressionEngine_javascript.aep")
        assert expected["expressionEngine"] == "javascript-1.0"
        assert project.expression_engine == expected["expressionEngine"]


class TestDisplayStartFrame:
    """Tests for displayStartFrame attribute."""

    def test_displayStartFrame_1(self) -> None:
        expected = load_expected(SAMPLES_DIR, "displayStartFrame_1")
        project = parse_project(SAMPLES_DIR / "displayStartFrame_1.aep")
        assert expected["displayStartFrame"] == 1
        assert project.display_start_frame == expected["displayStartFrame"]


class TestFramesCountType:
    """Tests for framesCountType attribute."""

    def test_start0(self) -> None:
        load_expected(SAMPLES_DIR, "framesCountType_start0")
        project = parse_project(SAMPLES_DIR / "framesCountType_start0.aep")
        assert project.display_start_frame == 0


class TestWorkingGamma:
    """Tests for workingGamma attribute."""

    def test_workingGamma_2_4(self) -> None:
        project = parse_project(SAMPLES_DIR / "workingGamma_2.4.aep")
        assert project.working_gamma == 2.4

    def test_workingGamma_2_2(self) -> None:
        project = parse_project(SAMPLES_DIR / "workingGamma_2.2.aep")
        assert project.working_gamma == 2.2


class TestWorkingSpace:
    """Tests for workingSpace attribute."""

    def test_workingSpace_sRGB(self) -> None:
        expected = load_expected(SAMPLES_DIR, "workingSpace_sRGB")
        project = parse_project(SAMPLES_DIR / "workingSpace_sRGB.aep")
        assert expected["workingSpace"] == "sRGB IEC61966-2.1"
        assert project.working_space == expected["workingSpace"]


class TestLinearBlending:
    """Tests for linearBlending attribute."""

    def test_linearBlending_false(self) -> None:
        project = parse_project(SAMPLES_DIR / "linearBlending_false.aep")
        assert not project.linear_blending

    def test_linearBlending_true(self) -> None:
        project = parse_project(SAMPLES_DIR / "linearBlending_true.aep")
        assert project.linear_blending


class TestTransparencyGridThumbnails:
    """Tests for transparencyGridThumbnails attribute."""

    def test_true(self) -> None:
        project = parse_project(SAMPLES_DIR / "transparencyGridThumbnails_true.aep")
        assert project.transparency_grid_thumbnails is True

    def test_false(self) -> None:
        project = parse_project(SAMPLES_DIR / "transparencyGridThumbnails_false.aep")
        assert project.transparency_grid_thumbnails is False


class TestColorManagement:
    """Tests for CC 2024+ color management attributes."""

    def test_colorManagementSystem_adobe(self) -> None:
        project = parse_project(SAMPLES_DIR / "colorManagementSystem_adobe.aep")
        assert project.color_management_system.name == "ADOBE"

    def test_colorManagementSystem_ocio(self) -> None:
        project = parse_project(SAMPLES_DIR / "colorManagementSystem_ocio.aep")
        assert project.color_management_system.name == "OCIO"

    def test_lutInterpolationMethod_trilinear(self) -> None:
        project = parse_project(SAMPLES_DIR / "lutInterpolationMethod_trilinear.aep")
        assert project.lut_interpolation_method == project.lut_interpolation_method.TRILINEAR

    def test_lutInterpolationMethod_tetrahedral(self) -> None:
        project = parse_project(SAMPLES_DIR / "lutInterpolationMethod_tetrahedral.aep")
        assert project.lut_interpolation_method == project.lut_interpolation_method.TETRAHEDRAL


VIEW_SAMPLES_DIR = Path(__file__).parent.parent / "samples" / "models" / "view"


class TestActiveItem:
    """Tests for active_item attribute."""

    def test_comp1_active(self) -> None:
        project = parse_project(VIEW_SAMPLES_DIR / "comp1_active.aep")
        assert project.active_item is not None
        assert project.active_item.name == "Comp 1"

    def test_comp2_active(self) -> None:
        project = parse_project(VIEW_SAMPLES_DIR / "comp2_active.aep")
        assert project.active_item is not None
        assert project.active_item.name == "Comp 2"

