# aero-cli

Customizable workflow automation tool for Aerostacks projects and beyond.

## Overview

Aero CLI is a lightweight, YAML-based workflow automation tool that simplifies project management, deployment, and task execution. It provides a unified interface for running complex multi-step workflows, both locally and on remote servers via SSH. Originally developed for Aerostacks infrastructure management, it's designed to be flexible enough for any project.

## Features

- **YAML-based configuration** - Define workflows in simple `aero.yaml` files
- **Command composition** - Reference and chain commands together
- **Remote execution** - Run commands on remote servers via SSH
- **Error handling** - Continue on errors or fail fast
- **Template variables** - Dynamic values like current git branch
- **Command aliases** - Multiple names for the same command
- **Nested execution** - Visual indentation for composed commands
- **Cross-platform** - Works on Linux and macOS (WSL for Windows)

## Installation

### Prerequisites

- Python 3.x
- pip
- Git (for cloning)

### Install from Source

```bash
git clone git@github.com:Aerostacks/aero-cli.git
cd aero-cli
pip install -e .
```

### Verify Installation

```bash
aero --help
```

## Usage

Define custom commands in `aero.yaml` and run them with `aero <command>`.

### Basic Example

```bash
# Run a command
aero deploy

# Use an alias
aero up  # If 'up' is an alias for 'start'

# Get help
aero --help
aero deploy --help
```

## Configuration

Create an `aero.yaml` file in your project root:

```yaml
remote: user@host  # Optional: SSH host for remote deployments

commands:
  start:
    help: Start local project
    aliases: [up]
    steps:
      - run: docker-compose up -d
  
  stop:
    help: Stop local project
    aliases: [down]
    steps:
      - run: docker-compose down
  
  deploy:
    help: Deploy to production
    steps:
      - run: git push
      - run: systemctl restart myapp
        remote: true
        ignore_errors: true
```

### Command Structure

Each command supports:
- `help`: Description shown in CLI help
- `aliases`: Alternative command names (list)
- `steps`: List of steps to execute sequentially

### Step Options

Each step can be:

**Simple string format:**
```yaml
- git push
- docker build -t myapp .
```

**Object format with options:**
```yaml
- run: docker-compose up -d
  remote: false
  ignore_errors: false
```

**Available options:**
- `run`: Command to execute (required)
- `remote`: Run on remote host via SSH (default: false)
- `ignore_errors`: Continue on failure (default: false)

### Composability

Reference other commands using `@command` syntax:

```yaml
commands:
  build:
    steps:
      - run: npm run build
  
  test:
    steps:
      - run: npm test
  
  deploy:
    steps:
      - run: "@build"      # Runs the build command
      - run: "@test"       # Runs the test command
      - run: rsync -av dist/ server:/var/www/
        remote: true
```

Steps are indented in the output to show nesting levels.

### Template Variables

Use template variables for dynamic values:

**Current git branch:**
```yaml
steps:
  - run: git checkout {branch} && git pull
  - run: docker build -t myapp:{branch} .
```

Available variables:
- `{branch}` - Current git branch name

### Remote Execution

Execute commands on remote servers via SSH:

```yaml
remote: user@production-server

commands:
  deploy:
    steps:
      - run: git pull
        remote: true
      - run: docker-compose up -d
        remote: true
```

Requirements:
- SSH access configured (key-based authentication recommended)
- Remote host specified in `remote` field

### Error Handling

Control how errors are handled:

```yaml
commands:
  deploy:
    steps:
      - run: npm run build
        # Fails if build fails (default)
      
      - run: npm run lint
        ignore_errors: true
        # Continues even if linting fails
      
      - run: rsync -av dist/ server:/var/www/
        remote: true
```

## Real-World Examples

### Aerostacks Deployment

```yaml
remote: betar@betar-field-system

commands:
  deploy:
    help: Deploy services to field system
    steps:
      - run: docker-compose pull
        remote: true
      - run: docker-compose up -d
        remote: true
  
  logs:
    help: View service logs
    steps:
      - run: docker-compose logs -f
        remote: true
  
  restart:
    help: Restart all services
    steps:
      - run: docker-compose restart
        remote: true
```

### Multi-Stage Build and Deploy

```yaml
commands:
  build:
    help: Build Docker images
    steps:
      - run: docker build -t myapp:{branch} .
  
  push:
    help: Push to registry
    steps:
      - run: "@build"
      - run: docker push myapp:{branch}
  
  deploy:
    help: Full deployment pipeline
    steps:
      - run: "@push"
      - run: kubectl set image deployment/myapp myapp=myapp:{branch}
```

## Project Structure

```
aero-cli/
├── src/
│   └── aero_cli/
│       ├── __init__.py
│       ├── cli.py          # CLI interface
│       ├── config.py       # YAML parsing
│       └── executor.py     # Command execution
├── pyproject.toml          # Package configuration
├── README.md
└── aero.yaml              # Self-hosting configuration
```

## Development

### Running from Source

```bash
cd aero-cli
pip install -e .
aero --help
```

### Testing

```bash
# Test with a sample project
cd /path/to/project
echo "commands:
  hello:
    steps:
      - run: echo 'Hello from Aero CLI'" > aero.yaml

aero hello
```

## Windows Support (WSL)

Aero CLI does not support native Windows. Use WSL (Windows Subsystem for Linux):

### Setting up WSL

1. Install WSL: `wsl --install`
2. Install Ubuntu from Microsoft Store
3. Follow Linux installation instructions

### Setting up Git on WSL

```bash
sudo apt install git

# Generate SSH key
ssh-keygen
# Accept all defaults

# Copy public key
cat ~/.ssh/id_ed25519.pub
```

Add the public key to GitHub:
1. Go to https://github.com/settings/keys
2. Click "New SSH key"
3. Paste the key and save

## Troubleshooting

### Command not found

Ensure `aero` is in your PATH:
```bash
which aero
pip show aero-cli
```

### SSH connection fails

Test SSH connection manually:
```bash
ssh user@host
```

Ensure key-based authentication is configured.

### YAML parsing errors

Validate your `aero.yaml`:
```bash
python -c "import yaml; yaml.safe_load(open('aero.yaml'))"
```

## Related Projects

All Aerostacks services use Aero CLI for deployment:
- [Synapse](https://github.com/Aerostacks/synapse)
- [Betar-Frontend](https://github.com/Aerostacks/Betar-Frontend)
- [Button-Frontend](https://github.com/Aerostacks/Button-Frontend)
- [infra-config](https://github.com/Aerostacks/infra-config)

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

See LICENSE file for details.
