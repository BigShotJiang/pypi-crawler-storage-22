import argparse
import logging
import subprocess
from codecs import ignore_errors

import yaml

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _build_parser(config):
    parser = argparse.ArgumentParser(
        prog="aero",
        description="Aero CLI - Customizable workflow automation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command")

    for cmd_name, cmd_config in config.get("commands", {}).items():
        help_text = cmd_config.get("help", f"Run {cmd_name} workflow")
        aliases = cmd_config.get("aliases", [])
        subparsers.add_parser(cmd_name, help=help_text, aliases=aliases).set_defaults(
            command=cmd_name
        )

    return parser


def main():
    try:
        config = loadConfig()
    except FileNotFoundError:
        logger.error("aero.yaml not found in current directory")
        return

    parser = _build_parser(config)
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    runWorkflow(config, args.command)


def loadConfig():
    with open("aero.yaml") as f:
        return yaml.safe_load(f)


def runWorkflow(config, command, step_info=None, indent=0):
    if step_info is None:
        step_info = dict()
    commands_config = config.get("commands", {})
    if command not in commands_config:
        logger.error(f"Command '{command}' not found in aero.yaml")
        return

    workflow = commands_config[command].get("steps", [])
    if not workflow:
        logger.warning(f"No steps defined for '{command}'")
        return

    for step in workflow:
        step = {**step_info, **step}
        runStep(config, step, indent)


def runStep(config, step, indent=0):
    prefix = "  " * indent

    if isinstance(step, str):
        step = {"run": step}

    command_str = step.get("run", "")
    if not command_str:
        return

    # Check if referencing another command
    if command_str.startswith("@"):
        ref_command = command_str[1:]
        logger.info(f"{prefix}→ {ref_command}")
        runWorkflow(config, ref_command, step, indent + 1)
        return

    command_str = replaceVars(command_str)

    remote = step.get("remote", False)
    if remote and config.get("remote"):
        command_str = f"ssh {config['remote']} '{command_str}'"

    ignore_errors = step.get("ignore_errors", False)

    logger.info(f"{prefix}$ {command_str}")
    try:
        subprocess.run(["bash", "-c", command_str], check=True)
    except subprocess.CalledProcessError as e:
        if ignore_errors:
            logger.warning(f"{prefix}✗ Step failed (ignored): {e}")
        else:
            logger.error(f"{prefix}✗ Step failed: {e}")
            raise


def replaceVars(command_str):
    if "{branch}" in command_str:
        branch = subprocess.check_output(
            ["git", "branch", "--show-current"], text=True
        ).strip()
        command_str = command_str.replace("{branch}", branch)
    return command_str
