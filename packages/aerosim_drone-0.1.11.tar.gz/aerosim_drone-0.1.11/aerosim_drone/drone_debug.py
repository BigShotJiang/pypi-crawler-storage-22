from enum import Enum, auto

from aerosim_drone.messages.telemetry import Telemetry
from aerosim_drone.messages.detections import Detections
from aerosim_drone.messages.text import Text
from aerosim_drone.commands.base import Command


class DroneDebug:
    class DebugLevel(Enum):
        Disabled = 0
        Trace = 1
        State = 2


    def __init__(self, debug_level: DebugLevel = DebugLevel.Disabled):
        self._debug_level = debug_level

    # def is_trace_debug_level(self) -> bool:
    #     return self._debug_level == self.DebugLevel.Trace
    #
    # def is_state_debug_level(self) -> bool:
    #     return self._debug_level == self.DebugLevel.State

    def _debug_process_detections(self, detections: Detections):
        if self._debug_level == self.DebugLevel.Trace:
            self._print_green('Receive: ' + str(detections))

    def _debug_process_telemetry(self, telemetry: Telemetry):
        if self._debug_level == self.DebugLevel.Trace:
            self._print_green('Receive: telemetry ' +  str(telemetry))


    def _debug_process_text(self, text: Text):
        if self._debug_level == self.DebugLevel.Trace:
            self._print_green('Receive: ' + str(text))

    def _debug_process_command(self, command: Command):
        if self._debug_level == self.DebugLevel.Trace:
            self._print_blue('Send: ' + str(command))

    def _print_green(self, string: str):
        print('\033[92m' + string + '\033[0m')

    def _print_red(self, string: str):
        print('\033[91m' + string + '\033[0m')

    def _print_blue(self, string: str):
        print('\033[94m' + string + '\033[0m')