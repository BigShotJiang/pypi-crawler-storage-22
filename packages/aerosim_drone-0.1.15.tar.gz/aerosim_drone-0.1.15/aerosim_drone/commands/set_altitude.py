from .base import Command


class SetAltitude(Command):
    """
    Set altitude command
    Change the desired flight altitude. The service is used to set the altitude and its coordinate system independently, after calling navigate or set_position.

    :param z: Altitude
    """
    name = "set_altitude"

    def __init__(
            self,
            z: float
    ):
        self.z = z

    def getData(self) -> dict:
        return {
            "z": self.z
        }
