from .base import Command


class SetAttitude(Command):
    """
    SetAttitude command
    Set roll, pitch, yaw and throttle level (similar to the STABILIZED mode). This service may be used for lower level control of the drone behavior, or controlling the drone when no reliable data on its position is available.

    :param roll: Requested roll (radians)
    :param pitch: Requested pitch (radians)
    :param yaw: Requested yaw (radians)
    :param thrust: Throttle level, ranges from 0 (no throttle, propellers are stopped) to 1 (full throttle).
    :param auto_arm: switch the drone to OFFBOARD and arm automatically (the drone will take off)
    """

    name = "set_attitude"

    def __init__(
            self,
            roll: float,
            pitch: float,
            yaw: float,
            thrust: float,
            auto_arm: bool = False,
    ):
        self.roll = roll
        self.pitch = pitch
        self.yaw = yaw
        self.thrust = thrust
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "roll": self.roll,
            "pitch": self.pitch,
            "yaw": self.yaw,
            "thrust": self.thrust,
            "auto_arm": self.auto_arm,
        }
