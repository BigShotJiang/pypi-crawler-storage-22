from .base import Command


class SetPosition(Command):
    """
    SetPosition command
    Set the setpoint for position and yaw. This service may be used to specify the continuous flow of target points, for example, for flying along complex trajectories (circular, arcuate, etc.).

    :param x: Point coordinate x
    :param y: Point coordinate y
    :param z: Point coordinate z
    :param yaw: Yaw angle (radians)
    :param auto_arm: switch the drone to OFFBOARD and arm automatically (the drone will take off)
    """
    name = "set_position"

    def __init__(
            self,
            x: float,
            y: float,
            z: float,
            yaw: float,
            auto_arm: bool = False,
    ):
        self.x = x
        self.y = y
        self.z = z
        self.yaw = yaw
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "yaw": self.yaw,
            "auto_arm": self.auto_arm,
        }
