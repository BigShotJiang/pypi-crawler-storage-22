from .base import Command


class SetVelocity(Command):
    """
    SetVelocity command
    Set the setpoint for position and yaw. This service may be used to specify the continuous flow of target points, for example, for flying along complex trajectories (circular, arcuate, etc.).

    :param vx: Flight speed (m/s) x
    :param vy: Flight speed (m/s) y
    :param vz: Flight speed (m/s) z
    :param yaw: Yaw angle (radians)
    :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
    """
    name = "set_velocity"

    def __init__(
            self,
            vx: float,
            vy: float,
            vz: float,
            yaw: float,
            auto_arm: bool = False,
    ):
        self.vx = vx
        self.vy = vy
        self.vz = vz
        self.yaw = yaw
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "vx": self.vx,
            "vy": self.vy,
            "vz": self.vz,
            "yaw": self.yaw,
            "auto_arm": self.auto_arm,
        }
