from .base import Command


class SetYaw(Command):
    """
    SetYaw command
    Change the desired yaw angle (and its coordinate system), keeping the previous command in effect.

    :param yaw: Yaw angle (radians)
    """
    name = "set_yaw"

    def __init__(
            self,
            yaw: float
    ):

        self.yaw = yaw

    def getData(self) -> dict:
        return {
            "yaw": self.yaw,
        }
