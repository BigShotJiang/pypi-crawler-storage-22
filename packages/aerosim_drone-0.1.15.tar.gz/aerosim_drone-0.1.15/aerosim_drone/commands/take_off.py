from .base import Command


class TakeOff(Command):
    """
    Take off command
    Take off drone
    :param z: Coordinate z
    """
    name = "take_off"

    def __init__(
            self,
            z: float,
    ):
        self.z = z

    def getData(self) -> dict:
        return {
            "z": self.z
        }
