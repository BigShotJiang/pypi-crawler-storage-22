import asyncio
import sys
import threading
import json
import time
import os

import websockets

from aerosim_drone.drone_last_command import DroneLastCommand
from aerosim_drone.drone_receiver import DroneReceiver
from aerosim_drone.drone_sender import DroneSender
from aerosim_drone.drone_telemetry import DroneTelemetry
from aerosim_drone.drone_detections import DroneDetections
from aerosim_drone.drone_text import DroneText
from aerosim_drone.drone_debug import DroneDebug


class Drone(DroneSender, DroneReceiver, DroneTelemetry, DroneText, DroneDetections, DroneLastCommand, DroneDebug):
    def __init__(self, host="localhost", port=8080, debug_level: DroneDebug.DebugLevel = DroneDebug.DebugLevel.Disabled):
        DroneTelemetry.__init__(self)
        DroneText.__init__(self)
        DroneDetections.__init__(self)
        DroneLastCommand.__init__(self)
        DroneDebug.__init__(self, debug_level)
        self.uri = f"ws://{host}:{port}"
        self._loop = asyncio.new_event_loop()
        self._ws = None
        self._connected = threading.Event()
        self._thread = None
        self._connect_exception = None
        self._is_connected = False
        self._is_connected_lock = threading.Lock()

    async def _connect_async(self):
        try:
            self._ws = await websockets.connect(self.uri)
            with self._is_connected_lock:
                self._is_connected = True
        except Exception as e:
            self._connect_exception = e
            with self._is_connected_lock:
                self._is_connected = False
        finally:
            self._connected.set()

        # try:
        #     self._ws = await websockets.connect(self.uri)
        # except Exception as e:
        #     print("Cannot connect to drone")
        # self._connected.set()


    def connect(self):
        def run_loop():
            asyncio.set_event_loop(self._loop)
            self._loop.run_until_complete(self._connect_async())

            if self._connect_exception:
                return

            self._loop.create_task(self._recv_loop())
            self._loop.run_forever()

        self._thread = threading.Thread(target=run_loop, daemon=True)
        self._thread.start()
        self._connected.wait()

        time.sleep(2)
        if self._connect_exception:
            print("Cannot connect to drone")
            sys.exit(1)


    def _send_websocket_data(self, payload, channel):

        message = json.dumps({
            "channel": channel,
            "payload": payload,
        })

        async def _send():
            await self._ws.send(message)

        self._loop.call_soon_threadsafe(
            asyncio.create_task, _send()
        )

    async def _recv_loop(self):
        try:
            async for msg in self._ws:
                try:
                    self._receive_message(json.loads(msg))
                except Exception as e:
                    print("Receive error:", e)
        except Exception as e:
            print("[WS] Receive error:", e)


    def disconnect(self):
        async def _close():
            await self._ws.close()
            self._loop.stop()

        self._loop.call_soon_threadsafe(
            asyncio.create_task, _close()
        )

    @property
    def is_connected(self) -> bool:
        with self._is_connected_lock:
            return self._is_connected

    def _kill(self, exit_code: int = 1):
        os._exit(exit_code)