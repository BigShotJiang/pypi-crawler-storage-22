import sys

from aerosim_drone.messages.detections import Detections
from aerosim_drone.messages.telemetry import Telemetry
from aerosim_drone.messages.text import Text


class DroneReceiver:
    def __init__(self):
        self.telemetry = None

    def _receive_message(self, message):
        if message and 'channel' in message and 'payload' in message and 'data' in message['payload']:
            data = message['payload']['data']
            if message['channel'] == 'telemetries':
                self._receive_telemetry(data)
            elif message['channel'] == 'texts':
                self._receive_text(data)
            elif message['channel'] == 'detections':
                self._receive_detections(data)
            # else:
            #     print('cannot receive message', message)

    def _receive_telemetry(self, data):
        telemetry = Telemetry.from_dict(data)
        self._update_telemetry(telemetry)
        self._debug_process_telemetry(telemetry)

    def _receive_text(self, data):
        text = Text(
            level=Text.NotificationLevel(data["level"]),
            content=data["content"],
        )
        self._debug_process_text(text)
        if text.isError():
            print('\033[91m' + str(text) + '\033[0m', file=sys.stderr)
            self._kill()
        else:
            print(text)



    def _receive_detections(self, data):
        if 'detections' in data:
            detections = Detections.from_dict(data['detections'])
            self._update_detections(detections)
            self._debug_process_detections(detections)
        else:
            print('cannot receive detections', data)
