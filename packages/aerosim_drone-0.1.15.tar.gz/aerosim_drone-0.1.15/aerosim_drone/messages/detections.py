from enum import Enum, auto
from typing import List

from aerosim_drone.messages.base import Message


class GateType(Enum):
    """
     Type of racing gate detected in the simulation.

     Attributes:
         Square (int):
             Standard square racing gate.

         Cone (int):
             Cone-shaped obstacle or marker.

         EmptySquare (int):
             Hollow square gate without center panel.

         Arc (int):
             Arc-shaped gate.
     """
    Square = 0
    Cone = 1
    EmptySquare = 2
    Arc = 3

    def __str__(self):
        return f"GateType.{self.name}({self.value})"
    def print(self):
        print(self.__str__())


class GateColor(Enum):
    """
    Color of detected gate.

    Attributes:
        Red (int):
            Red colored gate.

        Green (int):
            Green colored gate.
    """
    Red = 0
    Green = 1

    def __str__(self):
        return f"GateColor.{self.name}({self.value})"
    def print(self):
        print(self.__str__())

class Position:
    """
    3D position of detected object in world coordinates.

    Attributes:
        x (float):
            X coordinate in meters.

        y (float):
            Y coordinate in meters.

        z (float):
            Z coordinate in meters.
    """

    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            x=data["x"],
            y=data["y"],
            z=data["z"]
        )

    def __str__(self):
        return (
            f"Position("
            f"x={self.x:.2f}, "
            f"y={self.y:.2f}, "
            f"z={self.z:.2f}"
            f")"
        )
    def print(self):
        print(self.__str__())



class Gate:
    """
    Describes gate physical characteristics.

    Attributes:
        type (GateType):
            Type of the detected gate.

        color (GateColor):
            Color of the detected gate.
    """

    def __init__(self, gate_type: GateType, color: GateColor):
        self.type = gate_type
        self.color = color

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            gate_type=GateType(data["type"]),
            color=GateColor(data["color"])
        )

    def __str__(self):
        return (
            f"Gate("
            f"type={self.type.name}, "
            f"color={self.color.name}"
            f")"
        )
    def print(self):
        print(self.__str__())



class GateDetection:
    """
    Represents a single detected gate in current frame.

    Attributes:
        gate (Gate):
            Gate description including type and color.

        distance (float):
            Distance from drone to gate in meters.

        position (Position):
            3D world coordinates of the gate center.

        index (int):
            Gate index in track order.
    """

    def __init__(
            self,
            gate: Gate,
            distance: float,
            position: Position,
            index: int
    ):
        self.gate = gate
        self.distance = distance
        self.position = position
        self.index = index

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            gate=Gate.from_dict(data["gate"]),
            distance=data["distance"],
            position=Position.from_dict(data["position"]),
            index=data["index"]
        )

    def __str__(self):
        return (
            f"GateDetection("
            f"index={self.index}, "
            f"distance={self.distance:.2f}m, "
            f"gate={self.gate}, "
            f"position={self.position}"
            f")"
        )
    def print(self):
        print(self.__str__())


class Detections(Message):
    """
    Contains detected gates in current frame.

    Attributes:
        detections (List[GateDetection]):
            List of detected gates.
            Each element contains gate type, color,
            3D position and distance to drone.
    """

    channel = "detections"
    type = "detections"

    def __init__(self, detections: List[GateDetection]):
        self.detections = detections

    @classmethod
    def from_dict(cls, detections_raw: list):

        detections = [
            GateDetection.from_dict(item)
            for item in detections_raw
        ]
        return cls(detections)

    @classmethod
    def empty(cls):
        return cls(detections=[])

    def __len__(self):
        return len(self.detections)

    def __iter__(self):
        return iter(self.detections)

    def __str__(self):
        if not self.detections:
            return "Detections(empty)"

        lines = [
            f"Detections(count={len(self.detections)})"
        ]

        for detection in self.detections:
            lines.append(f"  └─ {detection}")

        return "\n".join(lines)

    def print(self):
        print(self.__str__())
