from .base import Command


class Arm(Command):
    """Arming
    """
    name = "arm"
    def getData(self) -> dict:
        return {
            "armed": True,
        }
