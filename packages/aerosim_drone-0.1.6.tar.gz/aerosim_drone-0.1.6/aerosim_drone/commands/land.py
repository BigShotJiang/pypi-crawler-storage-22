from .base import Command


class Land(Command):
    name = "land"
    def getData(self) -> dict:
        return {
            "landed": True,
        }
