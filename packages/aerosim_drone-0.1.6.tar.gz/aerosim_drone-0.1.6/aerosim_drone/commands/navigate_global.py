from .base import Command


class NavigateGlobal(Command):
    name = "navigate_global"

    def __init__(
            self,
            lat: float,
            lon: float,
            z: float,
            yaw: float,
            speed: float,
            frame_id: str = "map",
            auto_arm: bool = False
    ):
        self.lat = lat
        self.lon = lon
        self.z = z
        self.yaw = yaw
        self.speed = speed
        self.frame_id = frame_id
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "lat": self.lat,
            "lon": self.lon,
            "z": self.z,
            "yaw": self.yaw,
            "speed": self.speed,
            "frame_id": self.frame_id,
            "auto_arm": self.auto_arm
        }
