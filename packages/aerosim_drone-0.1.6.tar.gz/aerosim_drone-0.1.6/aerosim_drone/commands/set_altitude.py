from .base import Command


class SetAltitude(Command):
    name = "set_altitude"

    def __init__(
            self,
            z: float,
            frame_id: str = "map"
    ):
        self.z = z
        self.frame_id = frame_id

    def getData(self) -> dict:
        return {
            "z": self.z,
            "frame_id": self.frame_id,
        }
