from .base import Command


class SetAttitude(Command):
    name = "set_attitude"

    def __init__(
            self,
            roll: float,
            pitch: float,
            yaw: float,
            thrust: float,
            frame_id: str = "map",
            auto_arm: bool = False,
    ):
        self.roll = roll
        self.pitch = pitch
        self.yaw = yaw
        self.thrust = thrust
        self.frame_id = frame_id
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "roll": self.roll,
            "pitch": self.pitch,
            "yaw": self.yaw,
            "thrust": self.thrust,
            "frame_id": self.frame_id,
            "auto_arm": self.auto_arm,
        }
