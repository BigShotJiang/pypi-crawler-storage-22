from .base import Command


class SetPosition(Command):
    name = "set_position"

    def __init__(
            self,
            x: float,
            y: float,
            z: float,
            frame_id: str = "map",
            auto_arm: bool = False,
    ):
        self.x = x
        self.y = y
        self.z = z
        self.frame_id = frame_id
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "frame_id": self.frame_id,
            "auto_arm": self.auto_arm,
        }
