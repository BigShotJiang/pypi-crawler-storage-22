from .base import Command


class SetRates(Command):
    name = "set_rates"

    def __init__(
            self,
            roll_rate: float,
            pitch_rate: float,
            yaw_rate: float,
            thrust: float,
            auto_arm: bool = False,
    ):
        self.roll_rate = roll_rate
        self.pitch_rate = pitch_rate
        self.yaw_rate = yaw_rate
        self.thrust = thrust
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "roll_rate": self.roll_rate,
            "pitch_rate": self.pitch_rate,
            "yaw_rate": self.yaw_rate,
            "thrust": self.thrust,
            "auto_arm": self.auto_arm,
        }
