from .base import Command


class SetVelocity(Command):
    name = "set_velocity"

    def __init__(
            self,
            vx: float,
            vy: float,
            vz: float,
            yaw: float,
            frame_id: str = "map",
            auto_arm: bool = False,
    ):
        self.vx = vx
        self.vy = vy
        self.vz = vz
        self.yaw = yaw
        self.frame_id = frame_id
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "vx": self.vx,
            "vy": self.vy,
            "vz": self.vz,
            "yaw": self.yaw,
            "frame_id": self.frame_id,
            "auto_arm": self.auto_arm,
        }
