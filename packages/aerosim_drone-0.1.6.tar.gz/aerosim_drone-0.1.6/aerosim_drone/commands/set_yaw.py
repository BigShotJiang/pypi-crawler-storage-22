from .base import Command


class SetYaw(Command):
    name = "set_yaw"

    def __init__(
            self,
            yaw: float,
            frame_id: str = "map"
    ):

        self.yaw = yaw
        self.frame_id = frame_id

    def getData(self) -> dict:
        return {
            "yaw": self.yaw,
            "frame_id": self.frame_id,
        }
