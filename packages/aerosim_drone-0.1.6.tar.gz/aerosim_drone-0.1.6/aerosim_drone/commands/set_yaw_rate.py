from .base import Command


class SetYawRate(Command):
    name = "set_yaw_rate"

    def __init__(
            self,
            yaw_rate: float,
            frame_id: str = "map"
    ):

        self.yaw_rate = yaw_rate
        self.frame_id = frame_id

    def getData(self) -> dict:
        return {
            "yaw_rate": self.yaw_rate,
            "frame_id": self.frame_id,
        }
