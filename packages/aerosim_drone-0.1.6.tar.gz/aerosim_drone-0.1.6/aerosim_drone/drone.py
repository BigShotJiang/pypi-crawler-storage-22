import asyncio
import sys
import threading
import json
import time

import websockets

from aerosim_drone.drone_receiver import DroneReceiver
from aerosim_drone.drone_sender import DroneSender


class Drone(DroneSender, DroneReceiver):
    def __init__(self, host="localhost", port=8080):
        self.uri = f"ws://{host}:{port}"
        self._loop = asyncio.new_event_loop()
        self._ws = None
        self._connected = threading.Event()

    async def _connect_async(self):
        try:
            self._ws = await websockets.connect(self.uri)

        except Exception as e:
            print("Cannot connect to drone:", e)
            sys.exit()

        self._connected.set()


    def connect(self):
        def run_loop():
            asyncio.set_event_loop(self._loop)
            self._loop.run_until_complete(self._connect_async())
            self._loop.create_task(self._recv_loop())
            self._loop.run_forever()

        t = threading.Thread(target=run_loop, daemon=True)
        t.start()

        # 🔥 ждём подключения
        self._connected.wait()


    def _send_websocket_data(self, payload, channel):

        message = json.dumps({
            "channel": channel,
            "payload": payload,
        })

        async def _send():
            await self._ws.send(message)

        self._loop.call_soon_threadsafe(
            asyncio.create_task, _send()
        )

    async def _recv_loop(self):
        try:
            async for msg in self._ws:
                try:
                    self.receive_message(json.loads(msg))
                except Exception as e:
                    print("Receive error:", e)
                # self.receive_message(json.loads(msg))
        except Exception as e:
            print("[WS] Receive error:", e)

    def disconnect(self):
        async def _close():
            await self._ws.close()
            self._loop.stop()

        self._loop.call_soon_threadsafe(
            asyncio.create_task, _close()
        )
