from aerosim_drone.messages.telemetry import Telemetry
from aerosim_drone.messages.text import Text


class DroneReceiver:
    def __init__(self):
        self.telemetry = None

    def receive_message(self, message):
        if message and 'channel' in message and 'payload' in message and 'data' in message['payload']:
            if message['channel'] == 'telemetries':
                self._receive_telemetry(message['payload']['data'])
            elif message['channel'] == 'texts':
                self._receive_text(message['payload']['data'])
            elif message['channel'] == 'detections':
                self._receive_detection(message['payload']['data'])

    @staticmethod
    def _receive_telemetry(data):
        telemetry = Telemetry(
            frame_id=data["frame_id"],
            connected=data["connected"],
            armed=data["armed"],
            mode=Telemetry.FlightMode(data["mode"]),
            x=data["x"],
            y=data["y"],
            z=data["z"],
            lat=data["lat"],
            lon=data["lon"],
            alt=data["alt"],
            vx=data["vx"],
            vy=data["vy"],
            vz=data["vz"],
            roll=data["roll"],
            pitch=data["pitch"],
            yaw=data["yaw"],
            roll_rate=data["roll_rate"],
            pitch_rate=data["pitch_rate"],
            yaw_rate=data["yaw_rate"],
            voltage=data["voltage"],
            cell_voltage=data["cell_voltage"],
        )
        # todo: save latest telemetry
        telemetry.print()

    @staticmethod
    def _receive_text(data):
        text = Text(
            level=Text.NotificationLevel(data["level"]),
            content=data["content"],
        )
        text.print()
        # todo: save latest text

    @staticmethod
    def _receive_detection(data):
        print('todo: make _receive_detection')
