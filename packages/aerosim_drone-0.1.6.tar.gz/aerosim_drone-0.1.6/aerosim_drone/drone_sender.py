import time

from aerosim_drone.commands.arm import Arm
from aerosim_drone.commands.land import Land
from aerosim_drone.commands.navigate import Navigate
from aerosim_drone.commands.navigate_global import NavigateGlobal
from aerosim_drone.commands.set_altitude import SetAltitude
from aerosim_drone.commands.set_attitude import SetAttitude
from aerosim_drone.commands.set_position import SetPosition
from aerosim_drone.commands.set_rates import SetRates
from aerosim_drone.commands.set_velocity import SetVelocity
from aerosim_drone.commands.set_yaw import SetYaw
from aerosim_drone.commands.set_yaw_rate import SetYawRate


class DroneSender:

    def _send_command(self, command):
        command.print()
        self._send_websocket_data({
            "model": "command",
            "type": command.name,
            "timestamp": int(time.time()),
            "data": command.getData()
        }, "commands")


    # ---------- Commands ----------

    def arm(self):
        self._send_command(Arm())

    def land(self):
        self._send_command(Land())

    def navigate(
            self,
            x: float,
            y: float,
            z: float,
            speed: float,
            frame_id: str = "map",
            auto_arm: bool = False
    ):
        """
        Fly to the designated point in a straight line.

        :param x: Coordinate x
        :param y: Coordinate y
        :param z:Coordinate z
        :param speed: Flight speed (setpoint speed) (m/s)
        :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
        :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
        :return: None
        """
        self._send_command(
            Navigate(
                x=x,
                y=y,
                z=z,
                speed=speed,
                frame_id=frame_id,
                auto_arm=auto_arm
            )
        )

    def navigate_global(
            self,
            lat: float,
            lon: float,
            z: float,
            yaw: float,
            speed: float,
            frame_id: str = "map",
            auto_arm: bool = False
    ):
        self._send_command(
            NavigateGlobal(
                lat=lat,
                lon=lon,
                z=z,
                yaw=yaw,
                speed=speed,
                frame_id=frame_id,
                auto_arm=auto_arm
            )
        )

        def set_altitude(
                self,
                z: float,
                frame_id: str = "map",
        ):
            self._send_command(
                SetAltitude(
                    z=z,
                    frame_id=frame_id
                )
            )

        def set_attitude(
                self,
                roll: float,
                pitch: float,
                yaw: float,
                thrust: float,
                frame_id: str = "map",
                auto_arm: bool = False,
        ):
            self._send_command(
                SetAttitude(
                    roll=roll,
                    pitch=pitch,
                    yaw=yaw,
                    thrust=thrust,
                    frame_id=frame_id,
                    auto_arm=auto_arm,
                )
            )

        def set_position(
                self,
                x: float,
                y: float,
                z: float,
                frame_id: str = "map",
                auto_arm: bool = False,
        ):
            self._send_command(
                SetPosition(
                    x=x,
                    y=y,
                    z=z,
                    frame_id=frame_id,
                    auto_arm=auto_arm,
                )
            )

        def set_rates(
                self,
                roll_rate: float,
                pitch_rate: float,
                yaw_rate: float,
                thrust: float,
                auto_arm: bool = False,
        ):
            self._send_command(
                SetRates(
                    roll_rate=roll_rate,
                    pitch_rate=pitch_rate,
                    yaw_rate=yaw_rate,
                    thrust=thrust,
                    auto_arm=auto_arm,
                )
            )

        def set_velocity(
                self,
                vx: float,
                vy: float,
                vz: float,
                yaw: float,
                frame_id: str = "map",
                auto_arm: bool = False,
        ):
            self._send_command(
                SetVelocity(
                    vx=vx,
                    vy=vy,
                    vz=vz,
                    yaw=yaw,
                    frame_id=frame_id,
                    auto_arm=auto_arm,
                )
            )

        def set_yaw(
                self,
                yaw: float,
                frame_id: str = "map"
        ):
            self._send_command(
                SetYaw(
                    yaw=yaw,
                    frame_id=frame_id,
                )
            )

        def set_yaw_rate(
                self,
                yaw_rate: float,
                frame_id: str = "map"
        ):
            self._send_command(
                SetYawRate(
                    yaw_rate=yaw_rate,
                    frame_id=frame_id,
                )
            )
