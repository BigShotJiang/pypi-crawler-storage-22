import json
import time
from abc import ABC, abstractmethod


class Message(ABC):
    name: str  # имя команды (type)

    @abstractmethod
    def getData(self) -> dict:
        """return data of the command"""
        pass

    def serialize(self) -> str:
        return json.dumps(self.getData())

    @classmethod
    def deserialize(cls, raw: str):
        obj = json.loads(raw)
        return obj

    def print(self):
        print("Receive message " + self.__class__.__name__ + ": " + str(self.getData()))