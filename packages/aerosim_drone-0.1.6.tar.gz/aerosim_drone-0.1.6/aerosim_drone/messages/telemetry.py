from enum import Enum, auto

from aerosim_drone.messages.base import Message


class Telemetry(Message):
    channel = "telemetries"
    type = "telemetry"
    # TODO: make with a numbers 1,2,3 etc
    class FlightMode(Enum):
        StabilizedManual = 0
        Acro = 1
        Rattitude = 2
        Altctl = 3
        Posctl = 4
        Offboard = 5
        AutoMission = 6
        AutoRtl = 7
        AutoLand = 8

    def __init__(
        self,
        frame_id: str,
        connected: bool,
        armed: bool,
        mode: FlightMode,
        x: float,
        y: float,
        z: float,
        lat: float,
        lon: float,
        alt: float,
        vx: float,
        vy: float,
        vz: float,
        roll: float,
        pitch: float,
        yaw: float,
        roll_rate: float,
        pitch_rate: float,
        yaw_rate: float,
        voltage: float,
        cell_voltage: float
    ):
        self.frame_id = frame_id
        self.connected = connected
        self.armed = armed
        self.mode = mode
        self.x = x
        self.y = y
        self.z = z
        self.lat = lat
        self.lon = lon
        self.alt = alt
        self.vx = vx
        self.vy = vy
        self.vz = vz
        self.roll = roll
        self.pitch = pitch
        self.yaw = yaw
        self.roll_rate = roll_rate
        self.pitch_rate = pitch_rate
        self.yaw_rate = yaw_rate
        self.voltage = voltage
        self.cell_voltage = cell_voltage

    def getData(self) -> dict:
        return {
            "frame_id": self.frame_id,
            "connected": self.connected,
            "armed": self.armed,
            "mode": self.mode.name,
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "lat": self.lat,
            "lon": self.lon,
            "alt": self.alt,
            "vx": self.vx,
            "vy": self.vy,
            "vz": self.vz,
            "roll": self.roll,
            "pitch": self.pitch,
            "yaw": self.yaw,
            "roll_rate": self.roll_rate,
            "pitch_rate": self.pitch_rate,
            "yaw_rate": self.yaw_rate,
            "voltage": self.voltage,
            "cell_voltage": self.cell_voltage
        }
