from enum import Enum, auto

from aerosim_drone.messages.base import Message

class Text(Message):
    channel = "texts"
    type = "text"

    class NotificationLevel(Enum):
        Info = 0
        Warn = 1
        Error = 2

    def __init__(
        self,
        level: NotificationLevel,
        content: str
    ):
        self.level = level
        self.content = content


    def getData(self) -> dict:
        return {
            "level": self.level,
            "content": self.content
        }
