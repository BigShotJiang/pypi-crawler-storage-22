from .base import Command


class Arm(Command):
    """
    Arming command
    """
    name = "arm"
    def getData(self) -> dict:
        return {
            "armed": True,
        }
