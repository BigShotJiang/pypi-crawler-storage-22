import json
import time
from abc import ABC, abstractmethod


class Command(ABC):
    """
    Base command class
    """
    name: str  # имя команды (type)
    @abstractmethod
    def getData(self) -> dict:
        """return data of the command"""
        pass

    def serialize(self) -> str:
        return json.dumps(self.getData())

    @classmethod
    def deserialize(cls, raw: str):
        obj = json.loads(raw)
        return obj

    def __str__(self):
        data = self.getData()

        if not data:
            return f"{self.__class__.__name__}(empty)"

        formatted = ", ".join(
            f"{key}={value}"
            for key, value in data.items()
        )

        return f"Command {self.__class__.__name__}({formatted})"

    def __repr__(self):
        return self.__str__()

    def print(self):
        print(self.__str__())
