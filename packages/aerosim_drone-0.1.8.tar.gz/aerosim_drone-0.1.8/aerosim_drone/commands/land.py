from .base import Command


class Land(Command):
    """
    Landing command
    """
    name = "land"
    def getData(self) -> dict:
        return {
            "landed": True,
        }
