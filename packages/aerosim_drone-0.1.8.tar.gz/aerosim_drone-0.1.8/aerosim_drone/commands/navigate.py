from .base import Command


class Navigate(Command):
    """
    Navigate command
    Fly to the designated point in a straight line.

    :param x: Coordinate x
    :param y: Coordinate y
    :param z:Coordinate z
    :param speed: Flight speed (setpoint speed) (m/s)
    :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
    :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
    """
    name = "navigate"

    def __init__(
            self,
            x: float,
            y: float,
            z: float,
            speed: float,
            frame_id: str = "map",
            auto_arm: bool = False
    ):
        self.x = x
        self.y = y
        self.z = z
        self.speed = speed
        self.frame_id = frame_id
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "speed": self.speed,
            "frame_id": self.frame_id,
            "auto_arm": self.auto_arm
        }
