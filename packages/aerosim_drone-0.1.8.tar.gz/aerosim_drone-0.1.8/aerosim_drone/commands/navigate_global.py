from .base import Command


class NavigateGlobal(Command):
    """
    NavigateGlobal command
    Flying in a straight line to a point in the global coordinate system (latitude/longitude).

    :param lat: Latitude
    :param lon: Longitude
    :param z: Altitude (m)
    :param yaw: Yaw angle (radians)
    :param speed: Flight speed (setpoint speed) (m/s)
    :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
    :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)

    """
    name = "navigate_global"

    def __init__(
            self,
            lat: float,
            lon: float,
            z: float,
            yaw: float,
            speed: float,
            frame_id: str = "map",
            auto_arm: bool = False
    ):
        self.lat = lat
        self.lon = lon
        self.z = z
        self.yaw = yaw
        self.speed = speed
        self.frame_id = frame_id
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "lat": self.lat,
            "lon": self.lon,
            "z": self.z,
            "yaw": self.yaw,
            "speed": self.speed,
            "frame_id": self.frame_id,
            "auto_arm": self.auto_arm
        }
