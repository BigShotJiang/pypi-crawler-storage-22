from .base import Command


class SetAltitude(Command):
    """
    Set altitude command
    Change the desired flight altitude. The service is used to set the altitude and its coordinate system independently, after calling navigate or set_position.

    :param z: Altitude
    :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
    """
    name = "set_altitude"

    def __init__(
            self,
            z: float,
            frame_id: str = "map"
    ):
        self.z = z
        self.frame_id = frame_id

    def getData(self) -> dict:
        return {
            "z": self.z,
            "frame_id": self.frame_id,
        }
