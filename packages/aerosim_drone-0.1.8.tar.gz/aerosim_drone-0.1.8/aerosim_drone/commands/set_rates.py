from .base import Command


class SetRates(Command):
    """
    SetRates command
    Set roll, pitch, yaw and throttle level (similar to the STABILIZED mode). This service may be used for lower level control of the drone behavior, or controlling the drone when no reliable data on its position is available.

    :param roll_rate: Roll rate (rad/s)
    :param pitch_rate: Pitch rate (rad/s)
    :param yaw_rate: Yaw rate (rad/s)
    :param thrust: Throttle level, ranges from 0 (no throttle, propellers are stopped) to 1 (full throttle).
    :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
    """
    name = "set_rates"

    def __init__(
            self,
            roll_rate: float,
            pitch_rate: float,
            yaw_rate: float,
            thrust: float,
            auto_arm: bool = False,
    ):
        self.roll_rate = roll_rate
        self.pitch_rate = pitch_rate
        self.yaw_rate = yaw_rate
        self.thrust = thrust
        self.auto_arm = auto_arm

    def getData(self) -> dict:
        return {
            "roll_rate": self.roll_rate,
            "pitch_rate": self.pitch_rate,
            "yaw_rate": self.yaw_rate,
            "thrust": self.thrust,
            "auto_arm": self.auto_arm,
        }
