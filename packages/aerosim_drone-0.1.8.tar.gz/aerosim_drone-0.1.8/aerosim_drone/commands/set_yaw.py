from .base import Command


class SetYaw(Command):
    """
    SetYaw command
    Change the desired yaw angle (and its coordinate system), keeping the previous command in effect.

    :param yaw: Yaw angle (radians)
    :param frame_id: Coordinate system for computing the yaw. Default value: map.
    """
    name = "set_yaw"

    def __init__(
            self,
            yaw: float,
            frame_id: str = "map"
    ):

        self.yaw = yaw
        self.frame_id = frame_id

    def getData(self) -> dict:
        return {
            "yaw": self.yaw,
            "frame_id": self.frame_id,
        }
