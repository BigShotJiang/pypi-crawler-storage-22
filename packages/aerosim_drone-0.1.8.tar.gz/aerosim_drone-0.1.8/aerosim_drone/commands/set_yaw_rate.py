from .base import Command


class SetYawRate(Command):
    """
    SetYawRate command
    The the desired angular yaw velocity, keeping the previous command in effect.

    :param yaw_rate: Angular yaw velocity (rad/s);
    """
    name = "set_yaw_rate"

    def __init__(
            self,
            yaw_rate: float
    ):

        self.yaw_rate = yaw_rate

    def getData(self) -> dict:
        return {
            "yaw_rate": self.yaw_rate,
        }
