from .base import Command


class TakeOff(Command):
    """
    Take off command
    Take off drone
    :param y: Coordinate y
    """
    name = "take_off"

    def __init__(
            self,
            y: float,
    ):
        self.y = y

    def getData(self) -> dict:
        return {
            "y": self.y
        }
