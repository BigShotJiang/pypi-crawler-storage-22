import threading
import asyncio
from aerosim_drone.messages.detections import Detections

class DroneDetections:
    def __init__(self):
        self._detections_message = Detections.empty()
        self._detections_lock = threading.Lock()

    def _update_detections(self, telemetry: Detections):
        with self._detections_lock:
            self._detections_message = telemetry

    async def _get_detections_async(self) -> Detections:
        with self._detections_lock:
            return self._detections_message

    def get_detections(self) -> Detections:
        """
        Get last received detections

        Detections
        └── detections: List[GateDetection]
            ├── index: int
            ├── distance: float
            ├── gate: Gate
            │   ├── type: GateType
            │   │   ├── Square (0)
            │   │   ├── Cone (1)
            │   │   ├── EmptySquare (2)
            │   │   └── Arc (3)
            │   └── color: GateColor
            │       ├── Red (0)
            │       └── Green (1)
            └── position: Position
                ├── x: float
                ├── y: float
                └── z: float
        """
        with self._detections_lock:
            return self._detections_message

