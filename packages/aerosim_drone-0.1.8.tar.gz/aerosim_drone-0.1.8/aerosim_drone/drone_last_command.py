import threading
import asyncio

from aerosim_drone.commands import Command
from aerosim_drone.messages import Message
from aerosim_drone.messages.telemetry import Telemetry
from aerosim_drone.messages.text import Text
from typing import Optional


class DroneLastCommand:
    def __init__(self):
        self._last_command = None
        self._last_command_lock = threading.Lock()

    def _update_last_command(self, command: Command) -> Optional[Command]:
        with self._last_command_lock:
            self._last_command = command

    async def _get_last_command_async(self) -> Optional[Command]:
        with self._last_command_lock:
            return self._last_command

    def _get_last_command(self) -> Optional[Command]:
        with self._last_command_lock:
            return self._last_command
