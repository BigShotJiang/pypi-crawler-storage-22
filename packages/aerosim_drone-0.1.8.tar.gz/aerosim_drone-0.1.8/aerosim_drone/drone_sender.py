import time

from aerosim_drone.commands.arm import Arm
from aerosim_drone.commands.land import Land
from aerosim_drone.commands.navigate import Navigate
from aerosim_drone.commands.navigate_global import NavigateGlobal
from aerosim_drone.commands.set_altitude import SetAltitude
from aerosim_drone.commands.set_attitude import SetAttitude
from aerosim_drone.commands.set_position import SetPosition
from aerosim_drone.commands.set_rates import SetRates
from aerosim_drone.commands.set_velocity import SetVelocity
from aerosim_drone.commands.set_yaw import SetYaw
from aerosim_drone.commands.set_yaw_rate import SetYawRate
from aerosim_drone.commands.take_off import TakeOff
from aerosim_drone.drone_last_command import DroneLastCommand


class DroneSender:

    def _send_command(self, command):
        self._send_websocket_data({
            "model": "command",
            "type": command.name,
            "timestamp": int(time.time()),
            "data": command.getData()
        }, "commands")

        self._update_last_command(command)
        self._debug_process_command(command)

    # ---------- Commands ----------

    def arm(self):
        """
        Arms the drone
        :return: None
        """
        self._send_command(Arm())

    def land(self):
        """
        Lands the drone
        :return: None
        """
        self._send_command(Land())

    def navigate(
            self,
            x: float,
            y: float,
            z: float,
            speed: float,
            frame_id: str = "map",
            auto_arm: bool = False
    ):
        """
        Fly to the designated point in a straight line.

        :param x: Coordinate x
        :param y: Coordinate y
        :param z:Coordinate z
        :param speed: Flight speed (setpoint speed) (m/s)
        :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
        :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
        :return: None
        """
        self._send_command(
            Navigate(
                x=x,
                y=y,
                z=z,
                speed=speed,
                frame_id=frame_id,
                auto_arm=auto_arm
            )
        )

    def navigate_global(
            self,
            lat: float,
            lon: float,
            z: float,
            yaw: float,
            speed: float,
            frame_id: str = "map",
            auto_arm: bool = False
    ):
        """
        Flying in a straight line to a point in the global coordinate system (latitude/longitude).

        :param lat: Latitude
        :param lon: Longitude
        :param z: Altitude (m)
        :param yaw: Yaw angle (radians)
        :param speed: Flight speed (setpoint speed) (m/s)
        :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
        :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
        :return: None
        """
        self._send_command(
            NavigateGlobal(
                lat=lat,
                lon=lon,
                z=z,
                yaw=yaw,
                speed=speed,
                frame_id=frame_id,
                auto_arm=auto_arm
            )
        )

    def set_altitude(
            self,
            z: float,
            frame_id: str = "map",
    ):
        """
        Change the desired flight altitude. The service is used to set the altitude and its coordinate system independently, after calling navigate or set_position.

        :param z: Altitude
        :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
        :return: None
        """
        self._send_command(
            SetAltitude(
                z=z,
                frame_id=frame_id
            )
        )

    def set_attitude(
            self,
            roll: float,
            pitch: float,
            yaw: float,
            thrust: float,
            frame_id: str = "map",
            auto_arm: bool = False,
    ):
        """
        Set roll, pitch, yaw and throttle level (similar to the STABILIZED mode). This service may be used for lower level control of the drone behavior, or controlling the drone when no reliable data on its position is available.

        :param roll: Requested roll (radians)
        :param pitch: Requested pitch (radians)
        :param yaw: Requested yaw (radians)
        :param thrust: Throttle level, ranges from 0 (no throttle, propellers are stopped) to 1 (full throttle).
        :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
        :param auto_arm: switch the drone to OFFBOARD and arm automatically (the drone will take off)
        :return: None
        """
        self._send_command(
            SetAttitude(
                roll=roll,
                pitch=pitch,
                yaw=yaw,
                thrust=thrust,
                frame_id=frame_id,
                auto_arm=auto_arm,
            )
        )

    def set_position(
            self,
            x: float,
            y: float,
            z: float,
            yaw: float,
            frame_id: str = "map",
            auto_arm: bool = False,
    ):
        """
        Set the setpoint for position and yaw. This service may be used to specify the continuous flow of target points, for example, for flying along complex trajectories (circular, arcuate, etc.).

        :param x: Point coordinate x
        :param y: Point coordinate y
        :param z: Point coordinate z
        :param yaw: Yaw angle (radians)
        :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
        :param auto_arm: switch the drone to OFFBOARD and arm automatically (the drone will take off)
        :return: None
        """
        self._send_command(
            SetPosition(
                x=x,
                y=y,
                z=z,
                yaw=yaw,
                frame_id=frame_id,
                auto_arm=auto_arm,
            )
        )

    def set_rates(
            self,
            roll_rate: float,
            pitch_rate: float,
            yaw_rate: float,
            thrust: float,
            auto_arm: bool = False,
    ):
        """
        Set roll, pitch, yaw and throttle level (similar to the STABILIZED mode). This service may be used for lower level control of the drone behavior, or controlling the drone when no reliable data on its position is available.

        :param roll_rate: Roll rate (rad/s)
        :param pitch_rate: Pitch rate (rad/s)
        :param yaw_rate: Yaw rate (rad/s)
        :param thrust: Throttle level, ranges from 0 (no throttle, propellers are stopped) to 1 (full throttle).
        :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
        :return: None
        """
        self._send_command(
            SetRates(
                roll_rate=roll_rate,
                pitch_rate=pitch_rate,
                yaw_rate=yaw_rate,
                thrust=thrust,
                auto_arm=auto_arm,
            )
        )

    def set_velocity(
            self,
            vx: float,
            vy: float,
            vz: float,
            yaw: float,
            frame_id: str = "map",
            auto_arm: bool = False,
    ):
        """
        Set the setpoint for position and yaw. This service may be used to specify the continuous flow of target points, for example, for flying along complex trajectories (circular, arcuate, etc.).

        :param vx: Flight speed (m/s) x
        :param vy: Flight speed (m/s) y
        :param vz: Flight speed (m/s) z
        :param yaw: Yaw angle (radians)
        :param frame_id: Coordinate system for values x, y, z and yaw. Example: map, body, aruco_map. Default value: map.
        :param auto_arm: Switch the drone to OFFBOARD and arm automatically (the drone will take off)
        :return: None
        """
        self._send_command(
            SetVelocity(
                vx=vx,
                vy=vy,
                vz=vz,
                yaw=yaw,
                frame_id=frame_id,
                auto_arm=auto_arm,
            )
        )

    def set_yaw(
            self,
            yaw: float,
            frame_id: str = "map"
    ):
        """
        Change the desired yaw angle (and its coordinate system), keeping the previous command in effect.

        :param yaw: Yaw angle (radians)
        :param frame_id: Coordinate system for computing the yaw. Default value: map.
        :return: None
        """
        self._send_command(
            SetYaw(
                yaw=yaw,
                frame_id=frame_id,
            )
        )

    def set_yaw_rate(
            self,
            yaw_rate: float,
            frame_id: str = "map"
    ):
        """
        The the desired angular yaw velocity, keeping the previous command in effect.

        :param yaw_rate: Angular yaw velocity (rad/s);
        :return: None
        """
        self._send_command(
            SetYawRate(
                yaw_rate=yaw_rate,
            )
        )

    def take_off(self, y: float):
        """
        Take off drone
        :param y: Coordinate y
        :return: None
        """
        self._send_command(TakeOff(y))
