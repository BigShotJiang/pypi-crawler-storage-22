import threading
import asyncio
from aerosim_drone.messages.telemetry import Telemetry

class DroneTelemetry:
    def __init__(self):
        self._telemetry_message = Telemetry.empty()
        self._telemetry_lock = threading.Lock()

    def _update_telemetry(self, telemetry: Telemetry):
        with self._telemetry_lock:
            self._telemetry_message = telemetry

    async def _get_telemetry_async(self) -> Telemetry:
        with self._telemetry_lock:
            return self._telemetry_message

    def get_telemetry(self) -> Telemetry:
        """
        Get last received telemetry

        Telemetry
        ├── frame_id: str
        ├── connected: bool
        ├── armed: bool
        ├── mode: FlightMode
        │   ├── StabilizedManual (0)
        │   ├── Acro (1)
        │   ├── Rattitude (2)
        │   ├── Altctl (3)
        │   ├── Posctl (4)
        │   ├── Offboard (5)
        │   ├── AutoMission (6)
        │   ├── AutoRtl (7)
        │   └── AutoLand (8)
        ├── x: float
        ├── y: float
        ├── z: float
        ├── lat: float
        ├── lon: float
        ├── alt: float
        ├── vx: float
        ├── vy: float
        ├── vz: float
        ├── roll: float
        ├── pitch: float
        ├── yaw: float
        ├── roll_rate: float
        ├── pitch_rate: float
        ├── yaw_rate: float
        ├── voltage: float
        └── cell_voltage: float
        """
        with self._telemetry_lock:
            return self._telemetry_message

