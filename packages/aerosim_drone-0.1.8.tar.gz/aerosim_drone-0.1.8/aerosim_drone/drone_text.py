import threading
import asyncio

from aerosim_drone.messages import Message
from aerosim_drone.messages.telemetry import Telemetry
from aerosim_drone.messages.text import Text


class DroneText:
    def __init__(self):
        self._text_message = Text.empty()
        self._text_lock = threading.Lock()

    def _update_text(self, text: Text):
        with self._text_lock:
            self._text_message = text

    async def _get_text_async(self) -> Text:
        with self._text_lock:
            return self._text_message

    def _get_text(self) -> Text:
        with self._text_lock:
            return self._text_message

