from enum import Enum, auto

from aerosim_drone.messages.base import Message


class Telemetry(Message):
    channel = "telemetries"
    type = "telemetry"


    class FlightMode(Enum):
        StabilizedManual = 0
        Acro = 1
        Rattitude = 2
        Altctl = 3
        Posctl = 4
        Offboard = 5
        AutoMission = 6
        AutoRtl = 7
        AutoLand = 8

    def __init__(
            self,
            frame_id: str,
            connected: bool,
            armed: bool,
            mode: FlightMode,
            x: float,
            y: float,
            z: float,
            lat: float,
            lon: float,
            alt: float,
            vx: float,
            vy: float,
            vz: float,
            roll: float,
            pitch: float,
            yaw: float,
            roll_rate: float,
            pitch_rate: float,
            yaw_rate: float,
            voltage: float,
            cell_voltage: float,
            is_empty: bool = False,
    ):
        self.frame_id = frame_id
        self.connected = connected
        self.armed = armed
        self.mode = mode
        self.x = x
        self.y = y
        self.z = z
        self.lat = lat
        self.lon = lon
        self.alt = alt
        self.vx = vx
        self.vy = vy
        self.vz = vz
        self.roll = roll
        self.pitch = pitch
        self.yaw = yaw
        self.roll_rate = roll_rate
        self.pitch_rate = pitch_rate
        self.yaw_rate = yaw_rate
        self.voltage = voltage
        self.cell_voltage = cell_voltage
        self._is_empty = is_empty


    @classmethod
    def from_dict(cls, data: dict):

        return cls(
            is_empty=False,
            frame_id=data["frame_id"],
            connected=data["connected"],
            armed=data["armed"],
            mode=Telemetry.FlightMode(data["mode"]),

            x=data["x"],
            y=data["y"],
            z=data["z"],

            lat=data["lat"],
            lon=data["lon"],
            alt=data["alt"],

            vx=data["vx"],
            vy=data["vy"],
            vz=data["vz"],

            roll=data["roll"],
            pitch=data["pitch"],
            yaw=data["yaw"],

            roll_rate=data["roll_rate"],
            pitch_rate=data["pitch_rate"],
            yaw_rate=data["yaw_rate"],

            voltage=data["voltage"],
            cell_voltage=data["cell_voltage"],
        )

    @classmethod
    def empty(cls):
        return cls(
            is_empty=True,
            frame_id="",
            connected=False,
            armed=False,
            mode=cls.FlightMode.StabilizedManual,
            x=0.0, y=0.0, z=0.0,
            lat=0.0, lon=0.0, alt=0.0,
            vx=0.0, vy=0.0, vz=0.0,
            roll=0.0, pitch=0.0, yaw=0.0,
            roll_rate=0.0, pitch_rate=0.0, yaw_rate=0.0,
            voltage=0.0, cell_voltage=0.0
        )

    def __str__(self):
        if self._is_empty:
            return "Telemetry is empty"
        return (
            f"Telemetry("
            f"connected={self.connected}, "
            f"armed={self.armed}, "
            f"mode={self.mode}, "
            f"pos=({self.x:.2f}, {self.y:.2f}, {self.z:.2f}), "
            f"vel=({self.vx:.2f}, {self.vy:.2f}, {self.vz:.2f}), "
            f"rpy=({self.roll:.2f}, {self.pitch:.2f}, {self.yaw:.2f}), "
            f"voltage={self.voltage:.2f}V"
            f")"
        )

    def __repr__(self):
        return self.__str__()