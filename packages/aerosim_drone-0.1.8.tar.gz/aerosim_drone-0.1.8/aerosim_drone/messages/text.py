from enum import Enum, auto

from aerosim_drone.messages.base import Message


class Text(Message):
    channel = "texts"
    type = "text"

    class NotificationLevel(Enum):
        Info = 0
        Warn = 1
        Error = 2

    def __init__(
            self,
            level: NotificationLevel,
            content: str
    ):
        self._level = level
        self._content = content

    def isError(self) -> bool:
        return self._level == self.NotificationLevel.Error

    def getData(self) -> dict:
        return {
            "level": self._level,
            "content": self._content
        }

    def _isExists(self) -> bool:
        return self._content

    def _getString(self) -> str:
        return self._isExists() if self._getContent() + ' ' + self._getLevelString() else ''

    def _getLevelString(self) -> str:
        if self._level == self.NotificationLevel.Info:
            return "[INFO]"
        elif self._level == self.NotificationLevel.Warn:
            return "[WARN]"
        elif self._level == self.NotificationLevel.Error:
            return "[ERROR]"
        return ''

    def _getContent(self) -> str:
        return self._content

    @classmethod
    def empty(cls):
        """Returns a Text instance with default values"""
        return cls(
            level=cls.NotificationLevel.Info,
            content=""
        )

    def __str__(self):
       if not self._isExists() :
            return "Text empty"
       else:
            return f"Command {self._getString()}"

    def __repr__(self):
        return self.__str__()

    def print(self):
        print(self.__str__())