# Aethelgard Python SDK

**Enterprise AI Compliance & Fairness Verification — Formal Proofs, Not Statistical Guesses.**

[![PyPI version](https://badge.fury.io/py/aethelgard.svg)](https://pypi.org/project/aethelgard/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

Aethelgard is the only AI governance engine that uses **Z3 SMT formal verification** to *mathematically prove* fairness compliance — not merely estimate it statistically. This SDK provides a Python client for the Aethelgard Engine API.

## Why Aethelgard?

| Capability | Fairlearn / AIF360 | Aethelgard |
|---|---|---|
| **Evidence Type** | Statistical p-values | Z3 formal proofs (deterministic) |
| **Intersectional Analysis** | Manual specification | Exhaustive automatic discovery |
| **Regulations** | None built-in | 6 frameworks (LL144, EU AI Act, SR 11-7, Colorado, FDA, Texas TRAIGA) |
| **Confidence Intervals** | Wilson CI only | Wilson CI + Z3 uncertainty-aware verification |
| **Remediation** | None | Automated minimum-cost remediation plans |
| **Monitoring** | None | Real-time drift detection with breach forecasting |
| **Legal Protection** | None | Attorney-client privilege safe harbor |
| **Throughput** | ~100 rec/s (Python) | 1.23 billion rec/s (Rust engine) |

## Installation

```bash
pip install aethelgard
```

For benchmarking utilities:

```bash
pip install aethelgard[benchmarks]
```

## Quick Start

```python
from aethelgard import AethelgardClient

client = AethelgardClient(
    base_url="http://localhost:8080",
    api_key="your-api-key",
)

# Run a bias audit (NYC LL144 / EEOC Four-Fifths Rule)
result = client.audit_ll144(
    model_name="hiring-model-v2",
    groups=[
        {"category": {"category_type": "Race", "value": "White"}, "total_candidates": 1000, "selected_candidates": 600},
        {"category": {"category_type": "Race", "value": "Black"}, "total_candidates": 800, "selected_candidates": 440},
        {"category": {"category_type": "Race", "value": "Hispanic"}, "total_candidates": 600, "selected_candidates": 300},
    ],
)

for group in result["group_results"]:
    print(f"{group['group']:20s}  IR={group['impact_ratio']:.4f}  Z3={group['z3_verified']}")
```

## Supported Regulations

| Regulation | Method | Jurisdiction |
|---|---|---|
| NYC Local Law 144 | `client.audit_ll144()` | New York City |
| EU AI Act (Art 9-15) | `client.audit_eu_ai_act()` | European Union |
| Federal Reserve SR 11-7 | `client.audit_sr117()` | US Banking |
| Colorado AI Act (SB 205) | `client.audit_colorado()` | Colorado |
| FDA 21 CFR 820 | `client.audit_fda()` | US Medical Devices |
| Texas TRAIGA (HB 149) | `client.audit_texas_traiga()` | Texas |

## Key Features

### Formal Verification (Z3 SMT Proofs)
Every audit produces machine-checkable mathematical proofs — not statistical estimates.

### Intersectional Analysis
Automatically discovers and tests all combinatorial demographic intersections.

### Multi-Regulation Crosswalk
Map compliance findings across frameworks (e.g., LL144 → EU AI Act → NIST AI RMF).

### Zero-Knowledge Proofs
Prove fairness compliance without revealing model weights or training data.

### Continuous Monitoring
Real-time drift detection with confidence-weighted alerts and breach forecasting.

## API Reference

See the [full documentation](https://github.com/ProgrmerJack/Aethelgard#readme).

## Benchmarks

Reproducible benchmarks comparing Aethelgard to Fairlearn, AIF360, and manual auditing across 10 real-world datasets (40K+ to 2.5M+ records):

```bash
pip install aethelgard[benchmarks]
python -m aethelgard.benchmarks
```

## Citation

```bibtex
@software{aethelgard2026,
  author = {Ashuraliyev, Abduxoliq},
  title = {Aethelgard: Formal Verification for AI Fairness Compliance},
  year = {2026},
  url = {https://github.com/ProgrmerJack/Aethelgard},
}
```

## License

Apache License 2.0. See [LICENSE](LICENSE).
