"""
Aethelgard Python SDK
=====================

Enterprise AI Compliance & Fairness Verification Engine.

The only governance platform that uses Z3 SMT formal verification
to *mathematically prove* fairness compliance.

Basic usage::

    from aethelgard import AethelgardClient

    client = AethelgardClient("http://localhost:8080", api_key="your-key")
    result = client.audit_ll144(model_name="my-model", groups=[...])
"""

from aethelgard.client import AethelgardClient
from aethelgard._version import __version__

__all__ = ["AethelgardClient", "__version__"]
