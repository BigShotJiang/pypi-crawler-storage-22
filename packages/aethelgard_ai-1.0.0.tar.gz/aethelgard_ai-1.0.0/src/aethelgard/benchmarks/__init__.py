"""
Aethelgard Benchmarks
=====================

Multi-sector fairness benchmarking suite comparing the Aethelgard
formal verification engine against statistical-only tools (Fairlearn,
AIF360, manual auditing).

Datasets span 10 real-world sources across 6 industry sectors:
  - Criminal Justice (COMPAS)
  - Employment / Income (Adult Income, Law School)
  - Financial Services (German Credit, HMDA, Bank Marketing)
  - Healthcare (MIMIC / Diabetes, Communities & Crime)
  - Education (Student Performance)
  - Public Sector (Taiwan Credit Default)

Run all benchmarks::

    python -m aethelgard.benchmarks
"""

from aethelgard.benchmarks.runner import main as run_all

__all__ = ["run_all"]
