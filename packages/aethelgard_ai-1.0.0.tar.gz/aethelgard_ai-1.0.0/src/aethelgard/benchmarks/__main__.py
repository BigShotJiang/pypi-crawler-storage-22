"""
aethelgard.benchmarks.__main__
==============================

Entry point for ``python -m aethelgard.benchmarks``.
"""

from aethelgard.benchmarks.runner import main

if __name__ == "__main__":
    main()
