"""
Aethelgard HTTP Client
======================

Thread-safe, synchronous HTTP client for the Aethelgard Engine API.
Uses httpx for connection pooling and automatic retries.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Union

import httpx


class AethelgardError(Exception):
    """Base exception for Aethelgard SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, body: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class AethelgardClient:
    """Synchronous client for the Aethelgard AI Compliance Engine.

    Parameters
    ----------
    base_url : str
        The base URL of the Aethelgard server (e.g. ``http://localhost:8080``).
    api_key : str, optional
        Bearer token for authentication. Required for most endpoints.
    timeout : float
        Request timeout in seconds (default: 120).
    max_retries : int
        Number of retries on transient failures (default: 3).

    Examples
    --------
    >>> client = AethelgardClient("http://localhost:8080", api_key="my-key")
    >>> health = client.health()
    >>> print(health["status"])
    healthy
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float = 120.0,
        max_retries: int = 3,
    ):
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._max_retries = max_retries
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        transport = httpx.HTTPTransport(retries=max_retries)
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=headers,
            timeout=timeout,
            transport=transport,
        )

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> "AethelgardClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get(self, path: str, params: Dict[str, Any] | None = None) -> Any:
        resp = self._client.get(path, params=params)
        if resp.status_code >= 400:
            raise AethelgardError(
                f"GET {path} returned {resp.status_code}",
                status_code=resp.status_code,
                body=resp.text,
            )
        return resp.json()

    def _post(self, path: str, json_body: Any = None) -> Any:
        resp = self._client.post(path, json=json_body)
        if resp.status_code >= 400:
            raise AethelgardError(
                f"POST {path} returned {resp.status_code}",
                status_code=resp.status_code,
                body=resp.text,
            )
        return resp.json()

    def _post_unwrap(self, path: str, json_body: Any = None) -> Any:
        """POST, unwrap ApiResponse envelope, return the ``data`` field."""
        raw = self._post(path, json_body)
        if isinstance(raw, dict):
            if not raw.get("success", True):
                raise AethelgardError(
                    raw.get("error", "Unknown server error"),
                    body=raw,
                )
            if "data" in raw:
                return raw["data"]
        return raw

    def _timed_post(self, path: str, json_body: Any = None) -> tuple[Any, float]:
        """POST and return (response_json, elapsed_seconds)."""
        t0 = time.perf_counter()
        result = self._post_unwrap(path, json_body)
        elapsed = time.perf_counter() - t0
        return result, elapsed

    # ------------------------------------------------------------------
    # Health & metadata
    # ------------------------------------------------------------------

    def health(self) -> Dict[str, Any]:
        """Check server health and Z3 availability."""
        return self._get("/health")

    def list_regulations(self) -> List[Dict[str, Any]]:
        """List all supported regulatory frameworks."""
        return self._get("/api/v1/regulations")

    def list_constraint_packs(self) -> Dict[str, Any]:
        """List all built-in constraint packs."""
        return self._get("/api/v1/constraint-packs")

    # ------------------------------------------------------------------
    # Bias audits
    # ------------------------------------------------------------------

    def audit_ll144(
        self,
        model_name: str,
        groups: List[Dict[str, Any]],
        model_version: str = "1.0",
        model_type: str = "Selection",
    ) -> Dict[str, Any]:
        """Run an NYC LL144 / EEOC four-fifths bias audit.

        Parameters
        ----------
        model_name : str
            Identifier for the AI model being audited.
        groups : list
            List of group dictionaries, each with:
            - category: Rust-enum tag dict, e.g. ``{"Race": "White"}``,
              ``{"Sex": "Male"}``, ``{"Age": "18-25"}``, or ``{"Custom": "..."}``
            - total_candidates: int
            - selected_candidates: int
        model_version : str
            Version string for the model.
        model_type : str
            "Selection", "Scoring", or "Classification".

        Returns
        -------
        dict
            Audit result with group_results, formal_proof_status, audit_id, etc.
        """
        return self._post_unwrap("/api/v1/audit/ll144", {
            "audit_data": {
                "model_name": model_name,
                "model_version": model_version,
                "model_type": model_type,
                "groups": groups,
                "metadata": {},
            }
        })

    def audit_ll144_timed(
        self,
        model_name: str,
        groups: List[Dict[str, Any]],
        model_version: str = "1.0",
        model_type: str = "Selection",
    ) -> tuple[Dict[str, Any], float]:
        """Run LL144 audit and return (result, elapsed_seconds)."""
        return self._timed_post("/api/v1/audit/ll144", {
            "audit_data": {
                "model_name": model_name,
                "model_version": model_version,
                "model_type": model_type,
                "groups": groups,
                "metadata": {},
            }
        })

    def audit_eu_ai_act(
        self,
        model_name: str,
        risk_level: str = "high",
        groups: List[Dict[str, Any]] | None = None,
        model_version: str = "1.0",
        model_type: str = "Selection",
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Run an EU AI Act conformity assessment (Articles 9-15).

        Parameters
        ----------
        model_name : str
            Identifier for the AI system.
        risk_level : str
            "high", "limited", or "minimal".
        groups : list, optional
            Demographic group data for bias analysis.
        model_version : str
            Version string.
        model_type : str
            "Selection", "Scoring", or "Classification".

        Returns
        -------
        dict
            Conformity assessment with article-level checks.
        """
        audit_data: Dict[str, Any] = {
            "model_name": model_name,
            "model_version": model_version,
            "model_type": model_type,
            "groups": groups or [],
            "metadata": {},
        }
        return self._post_unwrap("/api/v1/audit/eu-ai-act", {
            "audit_data": audit_data,
            "risk_tier": risk_level,
        })

    def audit_sr117(
        self,
        model_name: str,
        groups: List[Dict[str, Any]],
        model_version: str = "1.0",
        model_type: str = "Selection",
    ) -> Dict[str, Any]:
        """Run a Federal Reserve SR 11-7 model risk audit."""
        return self._post_unwrap("/api/v1/audit/sr117", {
            "audit_data": {
                "model_name": model_name,
                "model_version": model_version,
                "model_type": model_type,
                "groups": groups,
                "metadata": {},
            }
        })

    # ------------------------------------------------------------------
    # Z3 formal verification
    # ------------------------------------------------------------------

    def verify_constraint(
        self,
        groups: List[Dict[str, Any]],
        constraint_type: str = "ImpactRatio",
        threshold: float = 0.80,
        timeout_ms: int = 30000,
    ) -> Dict[str, Any]:
        """Run Z3 formal verification of a fairness constraint.

        Parameters
        ----------
        groups : list
            Group data for verification.
        constraint_type : str
            "ImpactRatio", "MaxDisparity", "StatisticalParity",
            "Intersectional", or "FormalSpec".
        threshold : float
            Compliance threshold.
        timeout_ms : int
            Z3 solver timeout in milliseconds.

        Returns
        -------
        dict
            Verification result with z3_result, counterexample, etc.
        """
        return self._post_unwrap("/api/v1/verify/constraint", {
            "constraint": {
                "name": constraint_type,
                "threshold": threshold,
                "groups": groups,
                "timeout_ms": timeout_ms,
            }
        })

    def verify_constraint_timed(
        self,
        groups: List[Dict[str, Any]],
        constraint_type: str = "ImpactRatio",
        threshold: float = 0.80,
        timeout_ms: int = 30000,
    ) -> tuple[Dict[str, Any], float]:
        """Verify constraint and return (result, elapsed_seconds)."""
        return self._timed_post("/api/v1/verify/constraint", {
            "constraint": {
                "name": constraint_type,
                "threshold": threshold,
                "groups": groups,
                "timeout_ms": timeout_ms,
            }
        })

    # ------------------------------------------------------------------
    # Reports
    # ------------------------------------------------------------------

    def generate_report(self, audit_id: str, **kwargs: Any) -> Dict[str, Any]:
        """Generate a full compliance report from an existing audit."""
        body: Dict[str, Any] = {"audit_id": audit_id}
        body.update(kwargs)
        return self._post("/api/v1/report", body)

    # ------------------------------------------------------------------
    # Crosswalk
    # ------------------------------------------------------------------

    def nist_profile(self, audit_id: str) -> Dict[str, Any]:
        """Get NIST AI RMF profile for an audit."""
        return self._get(f"/api/v1/crosswalk/nist-profile/{audit_id}")

    def iso_soa(self, audit_id: str) -> Dict[str, Any]:
        """Get ISO 42001 Statement of Applicability for an audit."""
        return self._get(f"/api/v1/crosswalk/iso-soa/{audit_id}")

    # ------------------------------------------------------------------
    # ZKML
    # ------------------------------------------------------------------

    def zkml_commit(self, model_name: str, weights: List[float]) -> Dict[str, Any]:
        """Create a Pedersen commitment to model weights."""
        return self._post("/api/v1/zkml/commit", {
            "model_name": model_name,
            "weights": weights,
        })

    def zkml_prove(
        self,
        model_name: str,
        commitment: str,
        groups: List[Dict[str, Any]],
        metric: str = "DemographicParity",
        threshold: float = 0.80,
    ) -> Dict[str, Any]:
        """Generate a ZK-SNARK fairness proof."""
        return self._post("/api/v1/zkml/prove", {
            "model_name": model_name,
            "commitment": commitment,
            "metric": metric,
            "threshold": threshold,
            "groups": groups,
        })

    def zkml_verify(self, proof: str, public_inputs: str, vk: str) -> Dict[str, Any]:
        """Verify a ZK-SNARK proof."""
        return self._post("/api/v1/zkml/verify", {
            "proof": proof,
            "public_inputs": public_inputs,
            "verification_key": vk,
        })

    # ------------------------------------------------------------------
    # Monitoring (MRV)
    # ------------------------------------------------------------------

    def mrv_register(self, model_name: str, **kwargs: Any) -> Dict[str, Any]:
        """Register a model for continuous monitoring."""
        body: Dict[str, Any] = {"model_name": model_name}
        body.update(kwargs)
        return self._post("/api/v1/mrv/register", body)

    def mrv_drift_check(self, model_name: str, groups: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Check for compliance drift."""
        return self._post("/api/v1/mrv/drift-check", {
            "model_name": model_name,
            "groups": groups,
        })

    # ------------------------------------------------------------------
    # Scale testing utility
    # ------------------------------------------------------------------

    def audit_scale(
        self,
        total_records: int,
        num_groups: int = 10,
        model_name: str = "scale-benchmark",
    ) -> tuple[Dict[str, Any], float]:
        """Run a scaled audit and return (result, elapsed_seconds).

        Generates synthetic group data for throughput benchmarking.
        """
        import random
        random.seed(42)
        base = total_records // num_groups
        groups = []
        for i in range(num_groups):
            total = base + random.randint(-base // 10, base // 10)
            selected = int(total * random.uniform(0.3, 0.8))
            groups.append({
                "category": {"Custom": f"G{i}"},
                "total_candidates": total,
                "selected_candidates": selected,
            })
        return self.audit_ll144_timed(
            model_name=model_name,
            groups=groups,
        )

    # ------------------------------------------------------------------
    # Remediation
    # ------------------------------------------------------------------

    def remediation_plan(self, audit_id: str) -> Dict[str, Any]:
        """Generate an automated remediation plan."""
        return self._post("/api/v1/remediation", {"audit_id": audit_id})

    # ------------------------------------------------------------------
    # Statistical rigor
    # ------------------------------------------------------------------

    def statistical_rigor(self, groups: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Run full statistical evidence analysis (Fisher's exact, chi-squared, etc.)."""
        return self._post("/api/v1/statistical-rigor", {"groups": groups})

    # ------------------------------------------------------------------
    # Executive summary
    # ------------------------------------------------------------------

    def executive_summary(self, audit_id: str) -> Dict[str, Any]:
        """Generate a C-suite executive summary."""
        return self._post("/api/v1/executive-summary", {"audit_id": audit_id})
