from collections.abc import AsyncIterator, Iterable
from contextlib import asynccontextmanager
import inspect
import logging
from pathlib import Path, PurePath
from typing import Any, Literal
import uuid

from aethergraph.contracts.services.artifacts import Artifact
from aethergraph.contracts.services.channel import Button, FileRef, OutEvent
from aethergraph.services.continuations.continuation import Correlator


def _artifact_filename(artifact: Artifact, fallback: str | None = None) -> str:
    labels = artifact.labels or {}
    if "filename" in labels and labels["filename"]:
        return str(labels["filename"])

    # If no explicit filename label, try URI
    if artifact.uri:
        try:
            return PurePath(artifact.uri).name or fallback or artifact.artifact_id
        except Exception:
            pass

    return fallback or artifact.artifact_id


def _artifact_to_chat_file(
    artifact: Artifact,
    fallback_filename: str | None = None,
) -> dict[str, Any]:
    labels = artifact.labels or {}

    filename = (
        labels.get("filename")
        or (PurePath(artifact.uri).name if artifact.uri else None)
        or fallback_filename
        or artifact.artifact_id
    )

    # 👇 Renderer hint from labels (e.g. {"renderer": "image"})
    renderer = labels.get("renderer")

    # Make sure we actually set a mimetype if possible
    mime = artifact.mime
    if not mime and filename:
        # crude but fine: infer from extension
        lower = filename.lower()
        if lower.endswith(".png"):
            mime = "image/png"
        elif lower.endswith((".jpg", ".jpeg")):
            mime = "image/jpeg"
        elif lower.endswith(".gif"):
            mime = "image/gif"

    size = (
        getattr(artifact, "bytes", None)
        or getattr(artifact, "size", None)
        or getattr(artifact, "size_bytes", None)
    )

    return {
        "name": filename,
        "filename": filename,
        "mimetype": mime,
        "size": size,
        "uri": artifact.artifact_id,
        # "url" key is adapter-specific; we don't set it here; webUI will build from artifact_id and its api
        "renderer": renderer,  # key for the UI
    }


def _image_filename(title: str | None, alt: str | None) -> str:
    base = title or alt or "image"
    p = Path(base)
    if p.suffix:
        return base
    return base + ".png"


class ChannelSession:
    """Helper to manage a channel-based session within a NodeContext.
    Provides methods to send messages, ask for user input or approval, and stream messages.
    The channel key is read from `session.channel` in the context.
    """

    def __init__(self, context, channel_key: str | None = None):
        self.ctx = context
        self._override_key = channel_key  # optional strong binding

    @property
    def _memory_facade(self):
        """
        Best-effort resolver for MemoryFacade.

        We intentionally go via ctx.services.memory_facade instead of ctx.memory()
        so that:
        - we reuse the same scoped facade NodeContext exposes, and
        - we do NOT raise if memory is not bound (auto logging should be optional).
        """
        return getattr(self.ctx.services, "memory_facade", None)

    # Channel bus
    @property
    def _bus(self):
        return self.ctx.services.channels

    # Continuation store
    @property
    def _cont_store(self):
        return self.ctx.services.continuation_store

    @property
    def _run_id(self):
        return self.ctx.run_id

    @property
    def _node_id(self):
        return self.ctx.node_id

    @property
    def _session_id(self):
        return self.ctx.session_id

    def _inject_context_meta(self, meta: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Merge caller-provided meta with context-derived metadata
        (run_id, session_id, agent_id, app_id, graph_id, node_id).

        Caller-supplied keys win; we only fill in defaults.
        """
        base: dict[str, Any] = dict(meta or {})
        ctx = self.ctx

        # Use setdefault so explicit meta wins.
        if getattr(ctx, "run_id", None) is not None:
            base.setdefault("run_id", ctx.run_id)

        if getattr(ctx, "graph_id", None) is not None:
            base.setdefault("graph_id", ctx.graph_id)

        if getattr(ctx, "node_id", None) is not None:
            base.setdefault("node_id", ctx.node_id)

        if getattr(ctx, "session_id", None) is not None:
            base.setdefault("session_id", ctx.session_id)

        if getattr(ctx, "agent_id", None) is not None:
            base.setdefault("agent_id", ctx.agent_id)

        if getattr(ctx, "app_id", None) is not None:
            base.setdefault("app_id", ctx.app_id)

        return base

    def _default_chat_tags(
        self,
        extra: list[str] | None = None,
        *,
        channel: str | None = None,
    ) -> list[str]:
        """
        Derive some lightweight, structured tags from context
        and merge with caller-provided tags.
        """
        tags: list[str] = []

        # Channel name is very useful when debugging
        try:
            ch = self._resolve_key(channel)
            tags.append(f"channel:{ch}")
        except Exception:
            pass

        if self._run_id:
            tags.append(f"run:{self._run_id}")
        if self._session_id:
            tags.append(f"session:{self._session_id}")
        if self._node_id:
            tags.append(f"node:{self._node_id}")

        if extra:
            tags.extend(extra)

        return tags

    async def _log_chat(
        self,
        role: Literal["user", "assistant", "system", "tool"],
        text: str,
        *,
        tags: list[str] | None = None,
        data: dict[str, Any] | None = None,
        severity: int = 2,
        signal: float | None = None,
        enabled: bool = True,
        channel: str | None = None,
    ) -> None:
        """
        Internal helper: best-effort chat logging.
        Respects `enabled` and silently no-ops if memory is missing.
        """
        if not enabled or not text:
            return

        mem = self._memory_facade
        if not mem:
            return

        await mem.record_chat(
            role,
            text,
            tags=self._default_chat_tags(tags, channel=channel),
            data=data,
            severity=severity,
            signal=signal,
        )

    def _resolve_default_key(self) -> str:
        """Unified default resolver (bus default → console)."""
        return self._bus.get_default_channel_key() or "console:stdin"

    def _resolve_key(self, channel: str | None = None) -> str:
        """
        Priority: explicit arg → bound override → resolved default,
        then run through ChannelBus alias resolver for canonical form.
        """
        raw = channel or self._override_key or self._resolve_default_key()
        if not raw:
            # Should never happen given the fallback, but fail fast if misconfigured
            raise RuntimeError("ChannelSession: unable to resolve a channel key")
        # NEW: alias → canonical resolution
        return self._bus.resolve_channel_key(raw)

    def _ensure_channel(self, event: "OutEvent", channel: str | None = None) -> "OutEvent":
        """
        Ensure event.channel is set to a concrete channel key before publishing.
        If caller set event.channel already, keep it; otherwise fill in via resolver.
        """
        if not getattr(event, "channel", None):
            event.channel = self._resolve_key(channel)
        return event

    @property
    def _inbox_kv_key(self) -> str:
        """Key for this channel's inbox in ephemeral KV store (legacy helper)."""
        return f"inbox://{self._resolve_key()}"

    @property
    def _inbox_key(self) -> str:
        return f"inbox:{self._resolve_key()}"

    # -------- send --------
    async def send(self, event: OutEvent, *, channel: str | None = None):
        """
        Send a single outbound event to the configured channel.

        This method ensures the event is associated with the correct channel,
        merges context-derived metadata, and publishes the event via the channel bus.
        This is the core low-level send method; higher-level convenience methods
        (e.g., `send_text`, `send_rich`, etc.) build on top of this and are recommended
        for common use cases.

        Examples:
            Basic usage to send a pre-constructed event:
            ```python

            event = OutEvent(type="agent.message", text="Hello!", channel=None)
            await context.channel().send(event)
            ```

            Sending to a specific channel:
            ```python
            await context.channel().send(event, channel="web:chat")
            ```

        Args:
            event: The `OutEvent` instance to send. If `event.channel` is not set,
                it will be resolved automatically.
            channel: Optional explicit channel key to override the default or event's channel.

        Returns:
            None

        Notes:
        for AG WebUI, you can set meta with
        ```python
            {
                "agent_id": "agent-123",
                "name": "Analyst",
            }
        ```
        to override the sender's display name and avatar in the chat.
        """
        event = self._ensure_channel(event, channel=channel)

        # merge context meta
        event.meta = self._inject_context_meta(event.meta)
        await self._bus.publish(event)

    async def send_phase(
        self,
        phase: str,
        status: Literal["pending", "active", "done", "failed", "skipped"],
        *,
        label: str | None = None,
        detail: str | None = None,
        code: str | None = None,
        channel: str | None = None,
        key_suffix: str | None = None,
    ) -> None:
        """
        This method constructs a normalized outbound event representing the current
        phase and its status, merges context-derived metadata, and dispatches the
        event via the channel bus.

        Examples:
            Sending a phase update with a "pending" status:
            ```python
            await context.channel().send_phase("routing", "pending")
            ```

            Sending a phase update with additional details and a specific channel:
            ```python
            await context.channel().send_phase(
                "planning",
                "active",
                label="Planning Phase",
                detail="Calculating optimal routes",
            )
            ```

        Args:
            phase: The logical stage name (e.g., "routing", "planning", "reasoning").
            status: The current state of the phase ("pending", "active", "done", "failed", "skipped").
            label: Optional custom label for the phase (default: capitalized phase name).
            detail: Optional detailed description of the phase (default: empty string).
            code: Optional code identifier for the phase.
            channel: Optional explicit channel key to override the default or session-bound channel.
            key_suffix: Optional suffix to customize the upsert key (default: "phase:{phase}").

        Returns:
            None

        Notes:
            - This method will show a phase block in AG WebUI's timeline view if the adapter supports it.
            - Other adapters may choose to render this differently or ignore the rich payload.
            - All stage, status, label, detail, code fields can be customized without a fixed schema; the UI will treat them as opaque strings for display and filtering.
            - The `upsert_key` ensures stable updates for the same phase within a node/run.
        """
        ch_key = self._resolve_key(channel)
        # Stable upsert per phase per node/run
        suffix = key_suffix or f"phase:{phase}"
        upsert_key = f"{self._run_id}:{self._node_id}:{suffix}"

        rich = {
            "kind": "phase",
            "phase": phase,
            "status": status,
            "label": label or phase.title(),
            "detail": detail or "",
        }
        if code:
            rich["code"] = code

        await self._bus.publish(
            OutEvent(
                type="agent.progress.update",
                channel=ch_key,
                upsert_key=upsert_key,
                rich=rich,
                meta=self._inject_context_meta(None),
            )
        )

    async def send_text(
        self,
        text: str,
        *,
        meta: dict[str, Any] | None = None,
        channel: str | None = None,
        # memory logging handled separately
        memory_log: bool = True,
        memory_role: Literal["user", "assistant", "system", "tool"] = "assistant",
        memory_tags: list[str] | None = None,
        memory_data: dict[str, Any] | None = None,  # extra structured data
        memory_severity: int = 2,
        memory_signal: float | None = None,
    ):
        """
        Send a plain text message to the configured channel.

        This method constructs a normalized outbound event, merges context-derived metadata,
        and dispatches the message via the channel bus.

        Examples:
            Basic usage to send a text message:
            ```python
            await context.channel().send_text("Hello, world!")
            ```

            Sending with additional metadata and to a specific channel:
            ```python
            await context.channel().send_text(
                "Status update.",
                meta={"priority": "high"},
                channel="web:chat"
            )
            ```

        Args:
            text: The primary text content to send.
            meta: Optional dictionary of metadata to include with the event.
            channel: Optional explicit channel key to override the default or session-bound channel.
            memory_log: Whether to log this message to memory (default: True).
            memory_role: The role to use when logging to memory (default: "assistant").
            memory_tags: Optional list of tags to associate with the memory log entry.
            memory_data: Optional structured data to include with the memory log entry.
            memory_severity: Severity level for the memory log entry (default: 2).
            memory_signal: Optional signal value for the memory log entry.

        Returns:
            None

        Notes:
        for AG WebUI, you can set meta with
        ```python
            {
                "agent_id": "agent-123",
                "name": "Analyst",
            }
        ```
        """

        await self._log_chat(
            memory_role,
            text,
            tags=memory_tags,
            data=memory_data,
            severity=memory_severity,
            signal=memory_signal,
            enabled=memory_log,
            channel=channel,
        )

        event = OutEvent(
            type="agent.message",
            channel=self._resolve_key(channel),
            text=text,
            meta=self._inject_context_meta(meta),
        )
        await self._bus.publish(event)

    async def send_rich(
        self,
        text: str | None = None,
        *,
        rich: dict[str, Any] | None = None,
        meta: dict[str, Any] | None = None,
        channel: str | None = None,
        # memory logging handled separately
        memory_log: bool = True,
        memory_role: Literal["user", "assistant", "system", "tool"] = "assistant",
        memory_tags: list[str] | None = None,
        memory_data: dict[str, Any] | None = None,  # extra structured data
        memory_severity: int = 2,
        memory_signal: float | None = None,
    ):
        """
        Send a rich UI message to the configured channel.

        This method constructs a normalized outbound event, merges context-derived metadata,
        and dispatches the message with an optional `rich` payload for UI-aware adapters.

        Examples:
            Sending a single rich block:
            ```python
            await context.channel().send_rich(
            text="Here is the loss curve:",
            rich={
                "kind": "plot",
                "title": "Training loss",
                "payload": {
                "engine": "vega-lite",
                "spec": loss_vega_spec,
                },
            },
            )
            ```

            Sending multiple rich blocks:
            ```python
            await context.channel().send_rich(
            text="Training summary:",
            rich={
                "blocks": [
                {
                    "kind": "plot",
                    "title": "Loss",
                    "payload": {
                    "engine": "vega-lite",
                    "spec": loss_vega_spec,
                    },
                },
                {
                    "kind": "metrics",
                    "title": "Key metrics",
                    "payload": {
                    "items": [
                        {"label": "Best val loss", "value": "0.023"},
                        {"label": "Epochs", "value": "20"},
                    ],
                    },
                },
                ]
            },
            )
            ```

        Args:
            text: Optional plain text content to send alongside the rich payload.
            rich: A dictionary representing the structured rich payload. This can be a single block
            or multiple blocks depending on the use case.
            meta: Optional dictionary of metadata to include with the event.
            channel: Optional explicit channel key to override the default or session-bound channel.
            memory_log: Whether to log this message to memory (default: True).
            memory_role: The role to use when logging to memory (default: "assistant").
            memory_tags: Optional list of tags to associate with the memory log entry.
            memory_data: Optional structured data to include with the memory log entry.
            memory_severity: Severity level for the memory log entry (default: 2).
            memory_signal: Optional signal value for the memory log entry.

        Returns:
            None

        Notes:
            - For AG WebUI, the `rich` payload is passed through as-is and rendered as UI blocks.
            - Other adapters may down-level these blocks to plain text or ignore them.
        """

        # --- 1) Memory logging (log *something* even if text=None) ---
        log_text = text or "[rich message]"
        await self._log_chat(
            memory_role,
            log_text,
            tags=memory_tags,
            data=memory_data,
            severity=memory_severity,
            signal=memory_signal,
            enabled=memory_log,
            channel=channel,
        )

        # --- 2) Publish outbound event ---
        await self._bus.publish(
            OutEvent(
                type="agent.message",
                channel=self._resolve_key(channel),
                text=text,
                rich=rich,
                meta=self._inject_context_meta(meta),
            )
        )

    async def send_image(
        self,
        url: str | None = None,
        *,
        file_bytes: bytes | None = None,
        alt: str = "image",
        title: str | None = None,
        channel: str | None = None,
        artifact_labels: dict[str, Any] | None = None,
        # memory logging...
        memory_log: bool = True,
        memory_role: Literal["user", "assistant", "system", "tool"] = "assistant",
        memory_tags: list[str] | None = None,
        memory_data: dict[str, Any] | None = None,
        memory_severity: int = 2,
        memory_signal: float | None = None,
    ):
        """
        Send an image message to the configured channel.

        This method constructs a normalized outbound event, merges context-derived metadata,
        and dispatches the image message via the channel bus. The image can be specified
        using a URL or raw bytes, and additional metadata such as alternative text and title
        can be provided.

        Examples:
            Basic usage to send an image by URL:
            ```python
            await context.channel().send_image(
                url="https://example.com/image.png",
                alt="Sample image"
            )
            ```

            Sending an image with a custom title and to a specific channel:
            ```python
            await context.channel().send_image(
                url="https://example.com/photo.jpg",
                alt="User profile photo",
                title="Profile",
                channel="web:chat"
            )
            ```

            Sending an image from raw bytes:
            ```python
            await context.channel().send_image(
                file_bytes=b"binaryimagedata...",
                alt="Generated image",
                title="Generated Output"
            )
            ```

        Args:
            url: The URL of the image to send. If None, raw bytes must be provided.
            file_bytes: Optional raw bytes of the image to send.
            alt: Alternative text describing the image (for accessibility).
            title: Optional title to display with the image.
            channel: Optional explicit channel key to override the default or session-bound channel.
            artifact_labels: Optional dictionary of labels to associate with the image artifact.
            memory_log: Whether to log this message to memory (default: True).
            memory_role: The role to use when logging to memory (default: "assistant").
            memory_tags: Optional list of tags to associate with the memory log entry.
            memory_data: Optional structured data to include with the memory log entry.
            memory_severity: Severity level for the memory log entry (default: 2).
            memory_signal: Optional signal value for the memory log entry.

        Returns:
            None

        Notes:
            The capability to render images depends on the client adapter. If both `url` and
            `file_bytes` are provided, both will be included in the event.
        """

        labels = {"renderer": "image"}
        if artifact_labels:
            labels.update(artifact_labels)

        # Reuse memory logging text
        memory_tags = [*(memory_tags or []), "image"]

        await self.send_file(
            url=url,
            file_bytes=file_bytes,
            filename=_image_filename(title, alt),
            title=title or alt,
            channel=channel,
            artifact_kind="image",
            artifact_labels=labels,
            memory_log=memory_log,
            memory_role=memory_role,
            memory_tags=memory_tags,
            memory_data=memory_data,
            memory_severity=memory_severity,
            memory_signal=memory_signal,
        )

    async def send_file(
        self,
        url: str | None = None,
        *,
        file_bytes: bytes | None = None,
        filename: str = "file.bin",
        title: str | None = None,
        channel: str | None = None,
        # NEW: optional hints for artifact
        artifact_kind: str = "file",
        artifact_labels: dict[str, Any] | None = None,
        # memory logging handled separately
        memory_log: bool = True,
        memory_role: Literal["user", "assistant", "system", "tool"] = "assistant",
        memory_tags: list[str] | None = None,
        memory_data: dict[str, Any] | None = None,
        memory_severity: int = 2,
        memory_signal: float | None = None,
    ):
        """
        Send a file to the configured channel in a normalized format.

        This method constructs and dispatches an outbound event containing file metadata,
        including the file URL, raw bytes, filename, and an optional title. Context-derived
        metadata is automatically merged, and the event is published via the channel bus.

        Examples:
            Basic usage to send a file by URL:
            ```python
            await context.channel().send_file(
                url="https://example.com/report.pdf",
                filename="report.pdf",
                title="Monthly Report"
            )
            ```

            Sending a file from bytes:
            ```python
            await context.channel().send_file(
                file_bytes=b"binarydata...",
                filename="data.bin",
                title="Raw Data"
            )
            ```

        Args:
            url: The URL of the file to send. If None, only file_bytes will be used.
            file_bytes: Optional raw bytes of the file to send.
            filename: The display name of the file (defaults to "file.bin").
            title: Optional title to display with the file.
            channel: Optional explicit channel key to override the default or session-bound channel.
            memory_*: Parameters controlling logging to memory (see `send_text` for details).

        Returns:
            None

        Notes:
            The capability to handle file uploads depends on the client adapter.
            If both `url` and `file_bytes` are provided, both will be included in the event.
        """
        # ------------------------------
        # 1) Maybe create an Artifact
        # ------------------------------
        chat_file: dict[str, Any] = {
            "name": filename,
        }

        artifact = None

        # Ensure labels always carry filename
        effective_labels: dict[str, Any] = dict(artifact_labels or {})
        effective_labels.setdefault("filename", filename)

        # Case A: raw bytes → stream to ArtifactStore
        if file_bytes is not None:
            try:
                artifacts = self.ctx.artifacts()
                async with artifacts.writer(
                    kind=artifact_kind,
                    planned_ext=Path(filename).suffix or None,
                    pin=False,
                ) as w:
                    write_result = w.write(file_bytes)
                    if inspect.isawaitable(write_result):
                        await write_result

                    add_labels = getattr(w, "add_labels", None)
                    if callable(add_labels):
                        add_labels(effective_labels)

                artifact = artifacts.last_artifact

            except Exception:
                import logging

                logging.getLogger("aethergraph.channel").exception("send_file_artifact_failed")

        # Case B: local path (non-HTTP) → save_file
        elif url and not url.startswith(("http://", "https://")):
            try:
                artifacts = self.ctx.artifacts()
                artifact = await artifacts.save_file(
                    path=url,
                    kind=artifact_kind,
                    labels=effective_labels,
                    name=filename,
                    pin=False,
                )
            except Exception:
                import logging

                logging.getLogger("aethergraph.channel").exception("send_file_save_failed")

        # ------------------------------
        # 1b) Normalize chat_file from artifact or fallback URL
        # ------------------------------
        if artifact is not None:
            # Use artifact meta → url, mimetype, renderer (from labels), etc.
            chat_file.update(_artifact_to_chat_file(artifact, fallback_filename=filename))
        else:
            # Fallback: just pass whatever URL we got (may be remote HTTP or None)
            if url:
                chat_file["url"] = url

            # If caller passed renderer in labels, keep honoring it
            if artifact_labels and "renderer" in artifact_labels:
                chat_file["renderer"] = artifact_labels["renderer"]

        # For compatibility with existing payloads that used "filename"
        chat_file.setdefault("filename", chat_file.get("name"))

        # ------------------------------
        # 2) Log to memory
        # ------------------------------
        memory_tags = [*(memory_tags or []), "file"]
        await self._log_chat(
            memory_role,
            f"File: {filename} (url: {chat_file.get('url') or 'N/A'})",
            tags=memory_tags,
            data=memory_data,
            severity=memory_severity,
            signal=memory_signal,
            enabled=memory_log,
            channel=channel,
        )

        # ------------------------------
        # 3) Publish OutEvent
        # ------------------------------
        await self._bus.publish(
            OutEvent(
                type="agent.message",  # UI treats as normal message with attachment
                channel=self._resolve_key(channel),
                text=title or filename,
                file=chat_file,
                meta=self._inject_context_meta(None),
            )
        )

    async def send_buttons(
        self,
        text: str,
        buttons: list[Button],
        *,
        meta: dict[str, Any] | None = None,
        channel: str | None = None,
        # memory logging handled separately
        memory_log: bool = True,
        memory_role: Literal["user", "assistant", "system", "tool"] = "assistant",
        memory_tags: list[str] | None = None,
        memory_data: dict[str, Any] | None = None,  # extra structured data
        memory_severity: int = 2,
        memory_signal: float | None = None,
    ):
        """
        Send a message with interactive buttons to the configured channel.

        This method constructs and dispatches an outbound event containing a text prompt and a list of interactive buttons. Context-derived metadata is automatically merged, and the event is published via the channel bus.

        Examples:
            Basic usage to send a button prompt:
            ```python
            from aethergraph import Button
            await context.channel().send_buttons(
                "Choose an option:",
                [Button(label="Yes", value="yes"), Button(label="No", value="no")]
            )
            ```

            Sending with additional metadata and to a specific channel:
            ```python
            await context.channel().send_buttons(
                "Select your role:",
                [Button(label="Admin", value="admin"), Button(label="User", value="user")],
                meta={"priority": "high"},
                channel="web:chat"
            )
            ```

        Args:
            text: The primary text content to display above the buttons.
            buttons: A list of `Button` objects representing the interactive options.
            meta: Optional dictionary of metadata to include with the event.
            channel: Optional explicit channel key to override the default or session-bound channel.
            memory_*: Parameters controlling logging to memory (see `send_text` for details).

        Returns:
            None
        """
        memory_tags = [*(memory_tags or []), "buttons"]
        await self._log_chat(
            memory_role,
            text,
            tags=memory_tags,
            data=memory_data,
            severity=memory_severity,
            signal=memory_signal,
            enabled=memory_log,
            channel=channel,
        )

        await self._bus.publish(
            OutEvent(
                type="link.buttons",
                channel=self._resolve_key(channel),
                text=text,
                buttons=buttons,
                meta=self._inject_context_meta(meta),
            )
        )

    # Small core helper to avoid the wait-before-resume race and DRY the flow.
    async def _ask_core(
        self,
        *,
        kind: str,
        payload: dict,  # what stored in continuation.payload
        channel: str | None,
        timeout_s: int,
    ) -> dict:
        ch_key = self._resolve_key(channel)
        # 1) Create continuation (with audit/security)
        cont = await self.ctx.create_continuation(
            channel=ch_key, kind=kind, payload=payload, deadline_s=timeout_s
        )
        # 2) PREPARE the wait future BEFORE notifying (prevents race)
        fut = self.ctx.prepare_wait_for_resume(cont.token)

        # 3) Notify (console/local-web may return {"payload": ...} inline)
        res = await self._bus.notify(cont)

        # 4) Inline short-circuit: skip waiting and cleanup
        inline = (res or {}).get("payload")
        if inline is not None:
            # Defensive resolve (ok if already resolved by design)
            try:
                self.ctx.services.waits.resolve(cont.token, inline)
            except Exception:
                logger = logging.getLogger("aethergraph.services.channel.session")
                logger.debug("Continuation token %s already resolved inline", cont.token)
            try:
                await self._cont_store.delete(self._run_id, self._node_id)
            except Exception:
                logger.debug("Failed to delete continuation for token %s", cont.token)
                logger.exception("Error occurred while deleting continuation")
            return inline

        # 5) Push-only: bind correlator(s) so webhooks can locate the continuation
        corr = (res or {}).get("correlator")
        if corr:
            await self._cont_store.bind_correlator(token=cont.token, corr=corr)
            await self._cont_store.bind_correlator(  # message-less key for thread roots
                token=cont.token,
                corr=Correlator(
                    scheme=corr.scheme, channel=corr.channel, thread=corr.thread, message=""
                ),
            )
        else:
            # Best-effort binding (peek thread/channel)
            peek = await self._bus.peek_correlator(ch_key)
            if peek:
                await self._cont_store.bind_correlator(
                    token=cont.token, corr=Correlator(peek.scheme, peek.channel, peek.thread, "")
                )
            else:
                await self._cont_store.bind_correlator(
                    token=cont.token, corr=Correlator(self._bus._prefix(ch_key), ch_key, "", "")
                )

        # 6) Await the already-prepared future (router will resolve it later)
        return await fut

    # ------------------ Public ask_* APIs (race-free, normalized) ------------------
    async def ask_text(
        self,
        prompt: str | None,
        *,
        timeout_s: int = 3600,
        silent: bool = False,  # kept for back-compat; same behavior as before
        channel: str | None = None,
        # memory config
        memory_log_prompt: bool = True,
        memory_log_reply: bool = True,
        memory_tags: list[str] | None = None,
    ) -> str:
        """
        Prompt the user for a text response in a normalized format.

        This method sends a prompt to the configured channel, waits for a user reply, and returns the text input.
        It automatically handles context metadata, timeout, and channel resolution.

        Examples:
            Basic usage to prompt for user input:
            ```python
            reply = await context.channel().ask_text("What is your name?")
            ```

            Prompting with a custom timeout and silent mode:
            ```python
            reply = await context.channel().ask_text(
                "Enter your feedback.",
                timeout_s=120,
                silent=True
            )
            ```

        Args:
            prompt: The text prompt to display to the user. If None, a generic prompt may be shown.
            timeout_s: Maximum time in seconds to wait for a response (default: 3600).
            silent: If True, suppresses prompt display in some adapters (back-compat; default: False).
            channel: Optional explicit channel key to override the default or session-bound channel.
            memory_log_prompt: Whether to log the prompt to memory (default: True).
            memory_log_reply: Whether to log the user's reply to memory (default: True).
            memory_tags: Optional list of tags to associate with the memory log entries.

        Returns:
            str: The user's text response, or an empty string if no input was received.
        """
        if prompt:
            await self._log_chat(
                "assistant",
                prompt,
                tags=[*(memory_tags or []), "ask_text", "prompt"],
                enabled=memory_log_prompt,
                channel=channel,
            )

        payload = await self._ask_core(
            kind="user_input",
            payload={"prompt": prompt, "_silent": silent},
            channel=channel,
            timeout_s=timeout_s,
        )

        text = str(payload.get("text", ""))

        if text:
            await self._log_chat(
                "user",
                text,
                tags=[*(memory_tags or []), "ask_text", "reply"],
                enabled=memory_log_reply,
                channel=channel,
            )
        return text

    async def wait_text(
        self,
        *,
        timeout_s: int = 3600,
        channel: str | None = None,
        memory_log_reply: bool = True,
        memory_tags: list[str] | None = None,
    ) -> str:
        """
        Wait for a single text response from the user in a normalized format.

        This method prompts the user for input (with no explicit prompt), waits for a reply,
        and returns the text. It automatically handles context metadata, timeout, and channel resolution.

        Examples:
            Basic usage to wait for user input:
            ```python
            reply = await context.channel().wait_text()
            ```

            Waiting with a custom timeout and specific channel:
            ```python
            reply = await context.channel().wait_text(
                timeout_s=120,
                channel="web:chat"
            )
            ```

        Args:
            timeout_s: Maximum time in seconds to wait for a response (default: 3600).
            channel: Optional explicit channel key to override the default or session-bound channel.
            memory_log_reply: Whether to log the user's reply to memory (default: True).
            memory_tags: Optional list of tags to associate with the memory log entry.

        Returns:
            str: The user's text response, or an empty string if no input was received.
        """
        # Alias for ask_text(prompt=None) but keeps existing signature
        return await self.ask_text(
            prompt=None,
            timeout_s=timeout_s,
            silent=True,
            channel=channel,
            memory_log_prompt=False,  # no prompt to log
            memory_log_reply=memory_log_reply,
            memory_tags=memory_tags,
        )

    async def ask_approval(
        self,
        prompt: str,
        options: Iterable[str] = ("Approve", "Reject"),
        *,
        timeout_s: int = 3600,
        channel: str | None = None,
        memory_log_prompt: bool = True,
        memory_log_reply: bool = True,
        memory_tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Prompt the user for approval or rejection in a normalized format.

        This method sends an approval prompt with customizable options (buttons) to the configured channel,
        waits for the user's selection, and returns a normalized result indicating approval status and choice.
        Context metadata, timeout, and channel resolution are handled automatically.

        Examples:
            Basic usage to prompt for approval:
            ```python
            result = await context.channel().ask_approval("Do you approve this action?")
            # result: { "approved": True/False, "choice": "Approve"/"Reject" }
            ```

            Prompting with custom options and timeout:
            ```python
            result = await context.channel().ask_approval(
                "Proceed with deployment?",
                options=["Yes", "No", "Defer"],
                timeout_s=120
            )
            ```

        Args:
            prompt: The text prompt to display to the user.
            options: Iterable of button labels for user choices (defaults to "Approve" and "Reject").
            timeout_s: Maximum time in seconds to wait for a response (default: 3600).
            channel: Optional explicit channel key to override the default or session-bound channel.
            memory_log_prompt: Whether to log the prompt to memory (default: True).
            memory_log_reply: Whether to log the user's reply to memory (default: True).
            memory_tags: Optional list of tags to associate with the memory log entries.

        Returns:
            dict: A dictionary containing:
                - "approved": bool indicating if the __first__ option was selected (True if approved, False otherwise).
                - "choice": The label of the button selected by the user (str or None).

        Warning:
            The returned "choices" are determined by the external adapter and may vary. To be robust, make sure
            to use `choices.lower()` and strip whitespace when comparing.
        """
        if prompt:
            await self._log_chat(
                "assistant",
                prompt,
                tags=[*(memory_tags or []), "ask_approval", "prompt"],
                enabled=memory_log_prompt,
                channel=channel,
            )

        payload = await self._ask_core(
            kind="approval",
            payload={"prompt": {"title": prompt, "buttons": list(options)}},
            channel=channel,
            timeout_s=timeout_s,
        )
        choice = payload.get("choice")
        if choice is not None:
            await self._log_chat(
                "user",
                f"Selected: {str(choice)}",
                tags=[*(memory_tags or []), "ask_approval", "reply"],
                enabled=memory_log_reply,
                channel=channel,
            )

        # Normalize return
        # 1) If adapter explicitly sets approved, trust it
        buttons = list(options)  # just plain list, not Button objects
        # 2) Fallback: derive from choice + options
        if choice is None or not buttons:
            approved = False
        else:
            choice_norm = str(choice).strip().lower()
            first_norm = str(buttons[0]).strip().lower()
            approved = choice_norm == first_norm

        return {
            "approved": approved,
            "choice": choice,
        }

    async def ask_files(
        self,
        prompt: str,
        *,
        accept: list[str] | None = None,
        multiple: bool = True,
        timeout_s: int = 3600,
        channel: str | None = None,
        memory_log_prompt: bool = True,
        memory_log_reply: bool = True,
        memory_tags: list[str] | None = None,
    ) -> dict:
        """
        Prompt the user to upload one or more files, optionally with a text comment.

        This method sends a file upload request to the configured channel, allowing the user to select files
        and optionally enter accompanying text. The `accept` parameter provides hints to the client UI about
        which file types are preferred, but is not enforced server-side. The method waits for the user's response
        and returns a normalized result containing both text and file references.

        Examples:
            Basic usage to prompt for file upload:
            ```python
            result = await context.channel().ask_files(
                prompt="Please upload your report."
            )
            # result: { "text": "...", "files": [FileRef(...), ...] }
            ```

            Restricting to images and allowing multiple files:
            ```python
            result = await context.channel().ask_files(
                prompt="Upload images for review.",
                accept=["image/png", ".jpg"],
                multiple=True
            )
            ```

        Args:
            prompt: The text prompt to display to the user above the file picker.
            accept: Optional list of MIME types or file extensions to suggest allowed file types (e.g., "image/png", ".pdf", ".jpg").
            multiple: If True, allows the user to select multiple files (default: True).
            timeout_s: Maximum time in seconds to wait for a response (default: 3600).
            channel: Optional explicit channel key to override the default or session-bound channel.

        Returns:
            dict: A dictionary containing:
                - "text": str, the user's comment or description (may be empty).
                - "files": List[FileRef], references to the uploaded files (empty if none).

        Notes:
            On console adapters, file upload is not supported; only text will be returned.
            The `accept` parameter is a UI hint and does not guarantee file type enforcement.
        """
        if prompt:
            await self._log_chat(
                "assistant",
                prompt,
                tags=[*(memory_tags or []), "ask_files", "prompt"],
                enabled=memory_log_prompt,
                channel=channel,
            )

        payload = await self._ask_core(
            kind="user_files",
            payload={"prompt": prompt, "accept": accept or [], "multiple": bool(multiple)},
            channel=channel,
            timeout_s=timeout_s,
        )

        text = str(payload.get("text", ""))
        if text:
            await self._log_chat(
                "user",
                text,
                tags=[*(memory_tags or []), "ask_files", "reply"],
                enabled=memory_log_reply,
                channel=channel,
            )

        return {
            "text": text,
            "files": payload.get("files", []) if isinstance(payload.get("files", []), list) else [],
        }

    async def ask_text_or_files(
        self,
        *,
        prompt: str,
        timeout_s: int = 3600,
        channel: str | None = None,
        memory_log_prompt: bool = True,
        memory_log_reply: bool = True,
        memory_tags: list[str] | None = None,
    ) -> dict:
        """
        Prompt the user for either text input or file uploads in a normalized format.
        This method sends a prompt to the configured channel, allowing the user to respond with
        text, files, or both. It waits for the user's response and returns a normalized result
        containing the text and file references.

        Not used very often; prefer ask_text + get_latest_uploads or ask_files.
        """
        if prompt:
            await self._log_chat(
                "assistant",
                prompt,
                tags=[*(memory_tags or []), "ask_text_or_files", "prompt"],
                enabled=memory_log_prompt,
                channel=channel,
            )

        payload = await self._ask_core(
            kind="user_input_or_files",
            payload={"prompt": prompt},
            channel=channel,
            timeout_s=timeout_s,
        )

        text = str(payload.get("text", ""))
        if text:
            await self._log_chat(
                "user",
                text,
                tags=[*(memory_tags or []), "ask_text_or_files", "reply"],
                enabled=memory_log_reply,
                channel=channel,
            )

        return {
            "text": text,
            "files": payload.get("files", []) if isinstance(payload.get("files", []), list) else [],
        }

    # ---------- inbox helpers (platform-agnostic) ----------
    async def get_latest_uploads(self, *, clear: bool = True) -> list[FileRef]:
        """
        Retrieve the latest uploaded files from this channel's inbox in a normalized format.

        This method accesses the ephemeral KV store to fetch file uploads associated with the current channel.
        By default, it clears the inbox after retrieval to prevent duplicate processing. If the KV service
        is unavailable in the context, a RuntimeError is raised. This method allows the fetch the files user
        uploaded __not__ from an ask_files prompt, but from any prior upload event.

        Examples:
            Basic usage to fetch and clear uploaded files:
            ```python
            files = await context.channel().get_latest_uploads()
            ```

            Fetching files without clearing the inbox:
            ```python
            files = await context.channel().get_latest_uploads(clear=False)
            ```

        Args:
            clear: If True (default), removes files from the inbox after retrieval.
                If False, files are returned but remain in the inbox.

        Returns:
            List[FileRef]: A list of `FileRef` objects representing the uploaded files.
                Returns an empty list if no files are present.

        Raises:
            RuntimeError: If the ephemeral KV service is not available in the current context.
        """
        kv = getattr(self.ctx.services, "kv", None)
        if kv:
            if clear:
                files = await kv.list_pop_all(self._inbox_kv_key) or []
            else:
                files = await kv.get(self._inbox_kv_key, []) or []
            return files
        else:
            raise RuntimeError(
                "EphemeralKV service not available in this context. Inbox not supported."
            )

    # ---------- streaming ----------

    class _StreamSender:
        def __init__(self, outer: "ChannelSession", *, channel_key: str | None = None):
            self._outer = outer
            self._started = False
            # Resolve once (explicit -> bound -> default)
            self._channel_key = outer._resolve_key(channel_key)
            # Unique per stream so multiple streams from same node don’t collide
            self._upsert_key = f"{outer._run_id}:{outer._node_id}:stream:{uuid.uuid4().hex}"

        def _inject_context_meta(self, meta: dict[str, Any] | None = None) -> dict[str, Any]:
            return self._outer._inject_context_meta(meta)

        def _buf(self):
            return getattr(self, "__buf", None)

        def _ensure_buf(self):
            if not hasattr(self, "__buf"):
                self.__buf = []
            return self.__buf

        async def start(self) -> None:
            if not self._started:
                self._started = True
                await self._outer._bus.publish(
                    OutEvent(
                        type="agent.stream.start",
                        channel=self._channel_key,
                        upsert_key=self._upsert_key,
                        meta=self._inject_context_meta(None),
                    )
                )

        async def delta(self, text_piece: str) -> None:
            """
            Send a text delta for this stream.

            The UI is expected to append `text_piece` to the message associated
            with `upsert_key`. We also keep an internal buffer so `end()` can log
            the full text to memory if needed.
            """
            if not text_piece:
                return

            await self.start()
            buf = self._ensure_buf()
            buf.append(text_piece)

            await self._outer._bus.publish(
                OutEvent(
                    type="agent.stream.delta",
                    channel=self._channel_key,
                    text=text_piece,
                    upsert_key=self._upsert_key,
                    meta=self._inject_context_meta(None),
                )
            )

        async def end(
            self,
            full_text: str | None = None,
            *,
            memory_log: bool = True,
            memory_role: Literal["assistant", "system", "tool", "user"] = "assistant",
            memory_tags: list[str] | None = None,
            memory_data: dict[str, Any] | None = None,
            memory_severity: int = 2,
            memory_signal: float | None = None,
        ) -> None:
            """
            Finalize the stream.

            - If `full_text` is None, uses the concatenated buffer.
            - Logs the completed text to memory (once).
            - Emits `agent.stream.end` with the final text.
            """
            # Make sure we at least emitted start if no delta was ever sent
            await self.start()

            if full_text is None:
                buf = self._buf()
                full_text = "".join(buf) if buf else ""

            # 1) Memory logging of the completed message
            await self._outer._log_chat(
                memory_role,
                full_text,
                tags=memory_tags,
                data=memory_data,
                severity=memory_severity,
                signal=memory_signal,
                enabled=memory_log,
                channel=self._channel_key,
            )

            # 2) End-of-stream event with final text
            await self._outer._bus.publish(
                OutEvent(
                    type="agent.stream.end",
                    channel=self._channel_key,
                    text=full_text,
                    upsert_key=self._upsert_key,
                    meta=self._inject_context_meta(None),
                )
            )

    @asynccontextmanager
    async def stream(self, channel: str | None = None) -> AsyncIterator["_StreamSender"]:
        """
        Stream a sequence of text deltas to the configured channel in a normalized format.

        This method provides a context manager for streaming incremental message updates (such as LLM generation)
        to the target channel. It automatically handles context metadata, upsert keys, and dispatches start, update,
        and end events to the channel bus. The caller is responsible for sending deltas and ending the stream.

        Examples:
            Basic usage to stream texts:
            ```python
            async with context.channel().stream() as s:
                await s.delta("Hello, ")
                await s.delta("world!")
                await s.end()
            ```

            Streaming to a specific channel:
            ```python
            async with context.channel().stream(channel="web:chat") as s:
                await s.delta("Generating results...")
                await s.end(full_text="Results complete.", memory_tags=["llm"])
            ```

            Streaming with context.llm().stream_chat()
            ```python
            async with context.channel().stream() as s:
                    # The `on_delta` callback sends each piece to the stream.
                    async def on_delta(piece: str) -> None:
                        await s.delta(piece)
                    resp, usage = await llm.chat_stream(
                        messages=messages,
                        on_delta=on_delta, # send each delta to the stream as it arrives
                    )
                await s.end(full_text=resp)
            ```

        Args:
            channel: Optional explicit channel key to target a specific channel for this stream.
                If None, uses the session-bound or default channel.

        Returns:
            AsyncIterator[_StreamSender]: An async context manager yielding a `_StreamSender` object
                for sending deltas and ending the stream.

        Notes:
            - The caller must explicitly call `end()` to finalize the stream. No auto-end is performed.
            - The adapter may have specific behaviors for rendering streamed content (update vs. append).
        """
        s = ChannelSession._StreamSender(self, channel_key=channel)
        try:
            yield s
        finally:
            # No auto-end; caller decides when to end()
            pass

    # ---------- progress ----------
    class _ProgressSender:
        def __init__(
            self,
            outer: "ChannelSession",
            *,
            title: str = "Working...",
            total: int | None = None,
            key_suffix: str = "progress",
            channel_key: str | None = None,
        ):
            self._outer = outer
            self._title = title
            self._total = total
            self._current = 0
            self._started = False
            # Resolve once (explicit -> bound -> default)
            self._channel_key = outer._resolve_key(channel_key)
            self._upsert_key = f"{outer._run_id}:{outer._node_id}:{key_suffix}"

        def _inject_context_meta(self, meta: dict[str, Any] | None = None) -> dict[str, Any]:
            return self._outer._inject_context_meta(meta)

        async def start(self, *, subtitle: str | None = None):
            if not self._started:
                self._started = True
                await self._outer._bus.publish(
                    OutEvent(
                        type="agent.progress.start",
                        channel=self._channel_key,
                        upsert_key=self._upsert_key,
                        rich={
                            "kind": "progress",
                            "title": self._title,
                            "subtitle": subtitle or "",
                            "total": self._total,
                            "current": self._current,
                        },
                        meta=self._inject_context_meta(None),
                    )
                )

        async def update(
            self,
            *,
            current: int | None = None,
            inc: int | None = None,
            subtitle: str | None = None,
            percent: float | None = None,
            eta_seconds: float | None = None,
        ):
            await self.start()
            if percent is not None and self._total:
                self._current = int(round(self._total * max(0.0, min(1.0, percent))))
            if inc is not None:
                self._current += int(inc)
            if current is not None:
                self._current = int(current)
            payload = {
                "kind": "progress",
                "title": self._title,
                "subtitle": subtitle or "",
                "total": self._total,
                "current": self._current,
            }
            if eta_seconds is not None:
                payload["eta_seconds"] = float(eta_seconds)
            await self._outer._bus.publish(
                OutEvent(
                    type="agent.progress.update",
                    channel=self._channel_key,
                    upsert_key=self._upsert_key,
                    rich=payload,
                    meta=self._inject_context_meta(None),
                )
            )

        async def end(self, *, subtitle: str | None = "Done.", success: bool = True):
            await self._outer._bus.publish(
                OutEvent(
                    type="agent.progress.end",
                    channel=self._channel_key,
                    upsert_key=self._upsert_key,
                    rich={
                        "kind": "progress",
                        "title": self._title,
                        "subtitle": subtitle or "",
                        "success": bool(success),
                        "total": self._total,
                        "current": self._total if self._total is not None else None,
                    },
                    meta=self._inject_context_meta(None),
                )
            )

    @asynccontextmanager
    async def progress(
        self,
        *,
        title: str = "Working...",
        total: int | None = None,
        key_suffix: str = "progress",
        channel: str | None = None,
    ) -> AsyncIterator["_ProgressSender"]:
        """
        Back-compat: no channel uses session/default/console.
        New: pass channel to target a specific channel for this progress bar.
        """
        p = ChannelSession._ProgressSender(
            self, title=title, total=total, key_suffix=key_suffix, channel_key=channel
        )
        try:
            await p.start()
            yield p
        finally:
            # no auto-end
            pass
