## Summary

-

## Test plan

- [ ] Added/updated tests
- [ ] `pytest`
- [ ] `ruff check .`
- [ ] `mypy affinity`

## Notes

-
