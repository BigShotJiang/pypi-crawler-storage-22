# Exceptions

::: affinity.exceptions
