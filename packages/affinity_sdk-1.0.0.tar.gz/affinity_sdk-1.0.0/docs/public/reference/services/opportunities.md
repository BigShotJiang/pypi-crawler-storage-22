# Opportunities

::: affinity.services.opportunities.OpportunityService

::: affinity.services.opportunities.AsyncOpportunityService
