# Relationship strength (V1)

::: affinity.services.v1_only.RelationshipStrengthService
