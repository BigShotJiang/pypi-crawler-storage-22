# afflib

`afflib` is a Python library for processing charts for game *Arcaea*.

This project is dedicated to Public Domain by *CC0 1.0 Universal (CC0 1.0) Public Domain Dedication*. See [https://creativecommons.org/publicdomain/zero/1.0/](https://creativecommons.org/publicdomain/zero/1.0/).

This project is not affiliated with *lowiro limited*.

