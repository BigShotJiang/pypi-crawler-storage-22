"""
AfriLink Finetune Module

Provides the user-facing API for submitting finetuning jobs to HPC backends.
Supports flexible job specification with sensible defaults.

Usage:
    from afrilink import finetune

    ft = finetune(
        model="gpt-oss",
        training_mode="low",
        data=dataset,
        gpus=4
    )

    result = ft.run()
"""

import os
import uuid
import time
from pathlib import Path
from typing import Optional, Dict, Any, Union, List
from dataclasses import dataclass, field
from enum import Enum


class TrainingMode(Enum):
    """
    Training intensity modes that control resource allocation and training strategy.

    - LOW: QLoRA with minimal resources, single GPU fine
    - MEDIUM: LoRA with moderate resources, 1-2 GPUs
    - HIGH: Full finetuning with DDP, 4+ GPUs recommended
    - CUSTOM: User-defined configuration
    """
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CUSTOM = "custom"


@dataclass
class TrainingConfig:
    """
    Complete training configuration derived from training mode.
    """
    # LoRA/PEFT configuration
    use_lora: bool = True
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    lora_target_modules: List[str] = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj"
    ])

    # Quantization
    use_quantization: bool = True
    quantization_bits: int = 4  # 4 or 8

    # Training hyperparameters
    learning_rate: float = 2e-4
    batch_size: int = 4
    gradient_accumulation_steps: int = 4
    num_epochs: int = 3
    max_steps: int = -1  # -1 means use num_epochs
    warmup_ratio: float = 0.03
    weight_decay: float = 0.001
    max_grad_norm: float = 0.3

    # Sequence length
    max_seq_length: int = 2048

    # Distributed training
    use_ddp: bool = False
    use_fsdp: bool = False
    use_deepspeed: bool = False
    deepspeed_stage: int = 2

    # Memory optimization
    gradient_checkpointing: bool = True
    use_flash_attention: bool = True

    # Logging
    logging_steps: int = 10
    save_steps: int = 100
    eval_steps: int = 100

    @classmethod
    def from_mode(cls, mode: TrainingMode, gpus: int = 1) -> "TrainingConfig":
        """Create config from training mode"""
        if mode == TrainingMode.LOW:
            # QLoRA: 4-bit quantization, minimal resources
            return cls(
                use_lora=True,
                lora_r=8,
                lora_alpha=16,
                use_quantization=True,
                quantization_bits=4,
                batch_size=2,
                gradient_accumulation_steps=8,
                use_ddp=False,
                gradient_checkpointing=True,
                max_seq_length=1024,
            )
        elif mode == TrainingMode.MEDIUM:
            # LoRA: 8-bit or no quantization, moderate resources
            return cls(
                use_lora=True,
                lora_r=16,
                lora_alpha=32,
                use_quantization=gpus < 2,  # Quantize only if single GPU
                quantization_bits=8,
                batch_size=4,
                gradient_accumulation_steps=4,
                use_ddp=gpus > 1,
                gradient_checkpointing=True,
                max_seq_length=2048,
            )
        elif mode == TrainingMode.HIGH:
            # Full finetuning or high-rank LoRA with DDP
            return cls(
                use_lora=True,  # Still use LoRA but high rank
                lora_r=64,
                lora_alpha=128,
                use_quantization=False,
                batch_size=8,
                gradient_accumulation_steps=2,
                use_ddp=gpus > 1,
                use_fsdp=gpus >= 4,
                gradient_checkpointing=True,
                max_seq_length=4096,
                num_epochs=5,
            )
        else:
            # Custom: return defaults
            return cls()


@dataclass
class FinetuneJobSpec:
    """
    Complete specification for a finetuning job.
    """
    # Job identification
    job_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    job_name: Optional[str] = None

    # Model specification
    model: str = "gpt-oss"  # Model identifier from registry
    model_path: Optional[str] = None  # Override with local/remote path

    # Dataset specification
    dataset: Optional[Any] = None  # Dataset object or path
    dataset_path: Optional[str] = None
    dataset_format: str = "jsonl"  # jsonl, parquet, csv, huggingface

    # Training configuration
    training_mode: TrainingMode = TrainingMode.LOW
    training_config: Optional[TrainingConfig] = None

    # Resource allocation
    gpus: int = 1
    cpus_per_gpu: int = 4
    memory_gb: int = 32
    time_limit: str = "04:00:00"  # HH:MM:SS

    # Output configuration
    output_dir: str = "$WORK/finetune_outputs"
    checkpoint_dir: Optional[str] = None
    push_to_hub: bool = False
    hub_model_id: Optional[str] = None

    # Callbacks and hooks
    wandb_project: Optional[str] = None
    wandb_run_name: Optional[str] = None

    def __post_init__(self):
        if self.job_name is None:
            self.job_name = f"ft-{self.model}-{self.job_id}"

        if self.training_config is None:
            self.training_config = TrainingConfig.from_mode(
                self.training_mode, self.gpus
            )


class FinetuneJob:
    """
    Represents a finetuning job that can be submitted to HPC backends.

    This is the main user-facing class for job submission.
    """

    def __init__(
        self,
        spec: FinetuneJobSpec,
        cineca_auth=None,
        slurm_manager=None,
        transfer_manager=None,
        job_tracker=None,
    ):
        """
        Initialize finetune job.

        Args:
            spec: Job specification
            cineca_auth: CinecaDirectAuth instance for SSH access
            slurm_manager: SlurmJobManager instance
            transfer_manager: DataTransferManager for file uploads
            job_tracker: JobUsageTracker for billing (attached by AfriLinkClient)
        """
        self.spec = spec
        self.cineca_auth = cineca_auth
        self.slurm_manager = slurm_manager
        self.transfer_manager = transfer_manager
        self.job_tracker = job_tracker

        # Job state
        self._slurm_job_id: Optional[str] = None
        self._status: str = "created"
        self._result: Optional[Dict[str, Any]] = None

    @property
    def job_id(self) -> str:
        return self.spec.job_id

    @property
    def slurm_job_id(self) -> Optional[str]:
        return self._slurm_job_id

    @property
    def status(self) -> str:
        return self._status

    def validate(self) -> List[str]:
        """
        Validate job specification.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        if not self.spec.model and not self.spec.model_path:
            errors.append("Either model or model_path must be specified")

        # Check dataset - handle pandas DataFrames and other objects that don't
        # support direct truthiness checks
        has_dataset = self.spec.dataset is not None
        if hasattr(self.spec.dataset, 'empty'):
            # Pandas DataFrame - check if not empty
            has_dataset = not self.spec.dataset.empty
        elif hasattr(self.spec.dataset, '__len__'):
            # Lists, HuggingFace datasets, etc.
            has_dataset = len(self.spec.dataset) > 0

        if not has_dataset and not self.spec.dataset_path:
            errors.append("Either dataset or dataset_path must be specified")

        if self.spec.gpus < 1:
            errors.append("At least 1 GPU required")

        if self.spec.gpus > 4 and not self.spec.training_config.use_ddp:
            errors.append("DDP recommended for >4 GPUs")

        return errors

    def prepare(self) -> Dict[str, Any]:
        """
        Prepare job for submission.
        - Validates configuration
        - Generates training script
        - Prepares SLURM batch script

        Returns:
            Dict with preparation status and paths
        """
        errors = self.validate()
        if errors:
            raise ValueError(f"Job validation failed: {errors}")

        self._status = "preparing"

        # This will be filled in by the SLURM manager
        return {
            "job_id": self.spec.job_id,
            "job_name": self.spec.job_name,
            "model": self.spec.model,
            "gpus": self.spec.gpus,
            "training_mode": self.spec.training_mode.value,
            "status": "prepared",
        }

    def _upload_dataset(self) -> str:
        """
        Upload dataset to CINECA if it's a DataFrame or local file.

        Returns:
            Remote path to the dataset
        """
        import tempfile

        dataset = self.spec.dataset

        # Already have a remote path specified
        if self.spec.dataset_path and self.spec.dataset_path.startswith("$"):
            return self.spec.dataset_path

        # Need transfer manager for upload
        if not self.transfer_manager:
            if not self.cineca_auth:
                raise RuntimeError("No transfer manager or cineca_auth available for dataset upload")
            # Create transfer manager on the fly
            from .transfer import create_transfer_manager
            self.transfer_manager = create_transfer_manager(self.cineca_auth)

        # Handle pandas DataFrame
        if hasattr(dataset, 'to_json'):
            print(f"Uploading dataset ({len(dataset)} rows) to CINECA...")
            with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False) as f:
                dataset.to_json(f.name, orient='records', lines=True)
                local_path = f.name

            remote_path = f"$WORK/datasets/{self.spec.job_id}/train.jsonl"
            result = self.transfer_manager.upload_file(local_path, remote_path)

            # Clean up temp file
            try:
                os.unlink(local_path)
            except Exception:
                pass

            if not result.success:
                raise RuntimeError(f"Failed to upload dataset: {result.error}")

            return remote_path

        # Handle HuggingFace Dataset
        elif hasattr(dataset, 'save_to_disk'):
            print(f"Uploading HuggingFace dataset to CINECA...")
            with tempfile.TemporaryDirectory() as tmpdir:
                local_path = os.path.join(tmpdir, 'dataset')
                dataset.save_to_disk(local_path)

                remote_path = f"$WORK/datasets/{self.spec.job_id}"
                result = self.transfer_manager.upload_directory(local_path, remote_path)

                if not result.success:
                    raise RuntimeError(f"Failed to upload dataset: {result.error}")

                return remote_path

        # Handle local file path
        elif self.spec.dataset_path:
            local_path = self.spec.dataset_path
            if os.path.exists(local_path):
                print(f"Uploading dataset file to CINECA...")
                remote_path = f"$WORK/datasets/{self.spec.job_id}/{os.path.basename(local_path)}"
                result = self.transfer_manager.upload_file(local_path, remote_path)

                if not result.success:
                    raise RuntimeError(f"Failed to upload dataset: {result.error}")

                return remote_path

        return self.spec.dataset_path

    def run(
        self,
        wait: bool = False,
        poll_interval: int = 30,
        timeout: int = 14400,  # 4 hours default
        sif_path: str = None,
    ) -> Dict[str, Any]:
        """
        Submit and optionally wait for job completion.

        Args:
            wait: Whether to wait for job completion
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds
            sif_path: Path to Singularity container on CINECA (default: auto-detect)

        Returns:
            Dict with job result including output paths
        """
        if not self.slurm_manager:
            raise RuntimeError("No SLURM manager configured. Use with AfriLinkClient.")

        # Step 1: Upload dataset if needed
        print(f"\n{'='*60}")
        print(f"Preparing finetune job: {self.spec.job_name}")
        print(f"{'='*60}")

        if self.spec.dataset is not None or self.spec.dataset_path:
            remote_dataset_path = self._upload_dataset()
            self.spec.dataset_path = remote_dataset_path
            print(f"  Dataset: {remote_dataset_path}")

        # Step 2: Determine container path
        if sif_path is None:
            # Use model-specific container
            sif_path = f"$WORK/containers/afrilink-{self.spec.model}.sif"
        print(f"  Container: {sif_path}")

        # Step 3: Verify container exists on CINECA before submitting
        if self.cineca_auth:
            # sif_path may contain $WORK which the remote shell will expand
            code, stdout, _ = self.cineca_auth.run_ssh_command(
                f'test -f {sif_path} && echo ok || echo missing', timeout=15
            )
            if "missing" in (stdout or ""):
                raise FileNotFoundError(
                    f"Container not found on CINECA: {sif_path}\n"
                    f"Upload the container first, or pass sif_path= to run()."
                )

        # Step 4: Prepare and validate the job
        prep_result = self.prepare()

        # Step 5: Submit via SLURM manager
        print(f"\nSubmitting to SLURM...")
        self._slurm_job_id = self.slurm_manager.submit_job(self.spec, sif_path=sif_path)
        self._status = "submitted"

        print(f"Job submitted: {self._slurm_job_id}")
        print(f"  Name: {self.spec.job_name}")
        print(f"  Model: {self.spec.model}")
        print(f"  GPUs: {self.spec.gpus}")
        print(f"  Training mode: {self.spec.training_mode.value}")

        if not wait:
            return {
                "job_id": self.spec.job_id,
                "slurm_job_id": self._slurm_job_id,
                "status": "submitted",
            }

        # Wait for completion
        print(f"\nWaiting for job completion (timeout: {timeout}s)...")
        start_time = time.time()

        while time.time() - start_time < timeout:
            status = self.slurm_manager.get_job_status(self._slurm_job_id)
            self._status = status.get("state", "unknown")

            if self._status in ["COMPLETED", "FAILED", "CANCELLED", "TIMEOUT"]:
                break

            if self._status == "RUNNING":
                elapsed = status.get("elapsed_time", "unknown")
                print(f"  Status: RUNNING (elapsed: {elapsed})")

            time.sleep(poll_interval)

        # Bill based on actual SLURM job runtime (not wall-clock)
        billing_report = self._finalize_billing()

        if self._status == "COMPLETED":
            print(f"\nJob completed successfully!")
            self._result = self.slurm_manager.get_job_output(self._slurm_job_id)
            result = {
                "job_id": self.spec.job_id,
                "slurm_job_id": self._slurm_job_id,
                "status": "completed",
                "output_dir": self._result.get("output_dir"),
                "model_path": self._result.get("model_path"),
            }
            if billing_report:
                result["billing"] = billing_report
            return result
        else:
            print(f"\nJob ended with status: {self._status}")
            error_logs = self.slurm_manager.get_job_error(self._slurm_job_id)
            if error_logs and error_logs.strip() and "not found" not in error_logs.lower():
                print(f"\n--- SLURM Error Logs ---")
                # Show last 30 lines of error output
                lines = error_logs.strip().split('\n')
                for line in lines[-30:]:
                    print(f"  {line}")
                print(f"--- End Error Logs ---")
            result = {
                "job_id": self.spec.job_id,
                "slurm_job_id": self._slurm_job_id,
                "status": self._status,
                "error": error_logs,
            }
            if billing_report:
                result["billing"] = billing_report
            return result

    def _finalize_billing(self) -> Optional[Dict[str, Any]]:
        """
        Calculate and deduct billing based on actual SLURM job runtime.

        Uses the JobUsageTracker (if attached) to query sacct for the real
        elapsed time and number of GPUs, then computes cost at $2.00/GPU-hour
        and deducts from the user's DataSpires balance.

        Returns:
            Billing report dict, or None if no tracker attached.
        """
        if not self.job_tracker or not self._slurm_job_id:
            return None

        try:
            # Register this job with the tracker so it can query sacct
            self.job_tracker._jobs[self._slurm_job_id] = {
                'submitted_at': None,
                'status': self._status,
                'runtime_minutes': 0.0,
                'gpus': self.spec.gpus,
            }

            # Calculate cost from actual SLURM runtime
            total_gpu_minutes, total_cost = self.job_tracker.calculate_total_cost()

            report = {
                'total_gpu_minutes': round(total_gpu_minutes, 2),
                'total_gpu_hours': round(total_gpu_minutes / 60, 4),
                'rate_per_gpu_hour': self.job_tracker.rate_per_gpu_hour,
                'total_cost_usd': round(total_cost, 4),
            }

            # Deduct credits
            if self.job_tracker.auto_deduct_credits and total_cost > 0:
                cost_cents = int(total_cost * 100)
                if self.job_tracker._writer.deduct_credits(
                    self.job_tracker.user_id, cost_cents
                ):
                    print(f"\n  Billing: {total_gpu_minutes:.1f} GPU-min "
                          f"x ${self.job_tracker.rate_per_gpu_hour:.2f}/GPU-hr "
                          f"= ${total_cost:.4f} deducted")
                else:
                    print(f"\n  Billing: ${total_cost:.4f} (credit deduction failed)")
            elif total_cost > 0:
                print(f"\n  Billing: ${total_cost:.4f} (auto-deduct disabled)")

            # Log to Supabase telemetry
            if self.job_tracker._supabase_key:
                self.job_tracker._writer.write_telemetry_event(
                    event_type='job_billed',
                    session_id=self.job_tracker.session_id,
                    user_id=self.job_tracker.user_id,
                    metadata={
                        'slurm_job_id': self._slurm_job_id,
                        'afrilink_job_id': self.spec.job_id,
                        'gpus': self.spec.gpus,
                        **report,
                    },
                )

            return report
        except Exception as e:
            print(f"\n  Billing calculation failed: {e}")
            return None

    def cancel(self) -> bool:
        """
        Cancel the job if running.

        Returns:
            True if cancelled successfully
        """
        if not self._slurm_job_id:
            print("No job to cancel")
            return False

        if not self.slurm_manager:
            raise RuntimeError("No SLURM manager configured")

        result = self.slurm_manager.cancel_job(self._slurm_job_id)
        if result:
            self._status = "cancelled"
            print(f"Job {self._slurm_job_id} cancelled")
        return result

    def get_logs(self, tail: int = 100) -> str:
        """
        Get job logs.

        Args:
            tail: Number of lines to return

        Returns:
            Log content
        """
        if not self._slurm_job_id:
            return "No job submitted yet"

        if not self.slurm_manager:
            raise RuntimeError("No SLURM manager configured")

        return self.slurm_manager.get_job_logs(self._slurm_job_id, tail=tail)


def finetune(
    model: str = "gpt-oss",
    training_mode: Union[str, TrainingMode] = "low",
    data: Any = None,
    dataset_path: str = None,
    gpus: int = 1,
    time_limit: str = "04:00:00",
    output_dir: str = None,
    **kwargs,
) -> FinetuneJob:
    """
    Create a finetuning job with the specified configuration.

    This is the primary user-facing API for the SDK.

    Args:
        model: Model identifier (e.g., "gpt-oss", "llama-7b", "mistral-7b")
        training_mode: Training intensity ("low", "medium", "high", or TrainingMode)
        data: Dataset object (pandas DataFrame, HuggingFace Dataset, or path)
        dataset_path: Explicit path to dataset file
        gpus: Number of GPUs to request
        time_limit: Maximum job time in HH:MM:SS format
        output_dir: Output directory for results
        **kwargs: Additional job configuration

    Returns:
        FinetuneJob instance ready for submission

    Example:
        ft = finetune(
            model="gpt-oss",
            training_mode="low",
            data=my_dataset,
            gpus=4
        )

        result = ft.run()
    """
    # Convert string mode to enum
    if isinstance(training_mode, str):
        training_mode = TrainingMode(training_mode.lower())

    # Handle dataset
    ds_path = dataset_path
    if data is not None and dataset_path is None:
        # Try to detect dataset type
        if hasattr(data, "to_json"):
            # Pandas DataFrame - will be serialized later
            ds_path = None
        elif hasattr(data, "save_to_disk"):
            # HuggingFace Dataset
            ds_path = None
        elif isinstance(data, (str, Path)):
            ds_path = str(data)

    # Create job spec
    spec = FinetuneJobSpec(
        model=model,
        dataset=data,
        dataset_path=ds_path,
        training_mode=training_mode,
        gpus=gpus,
        time_limit=time_limit,
        output_dir=output_dir or "$WORK/finetune_outputs",
        **kwargs,
    )

    return FinetuneJob(spec)
