"""Afterburn CLI module."""
