# Blender MCP Example Workflows

Each new capability, and each capability change that adds new behavior, MUST include at least one runnable example under `examples/`.

For MCP client configuration guides (Cursor, Claude Code, VS Code, Windsurf, etc.), see [docs/clients/](../docs/clients/).

## Example 1: Minimal Stdio Loop
Run:

```python
python -m examples.stdio_loop
```

Send:

```json
{ "jsonrpc": "2.0", "id": 1, "method": "scene.read", "params": {"payload": {}, "scopes": ["scene:read"]} }
```

Additional examples will be added as capabilities are implemented.
