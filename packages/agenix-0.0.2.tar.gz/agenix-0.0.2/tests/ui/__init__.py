"""UI module tests."""
