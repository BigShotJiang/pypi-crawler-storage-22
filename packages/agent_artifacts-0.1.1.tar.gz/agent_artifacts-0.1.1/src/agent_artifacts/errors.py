class ExecutionError(RuntimeError):
    pass
