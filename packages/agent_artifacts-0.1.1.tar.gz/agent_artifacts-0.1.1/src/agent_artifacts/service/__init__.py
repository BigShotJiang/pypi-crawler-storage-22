"""Storage service for Agent Artifacts."""
