"""Doc-Serve CLI - Command-line interface for managing Doc-Serve server."""

__version__ = "1.2.0"
