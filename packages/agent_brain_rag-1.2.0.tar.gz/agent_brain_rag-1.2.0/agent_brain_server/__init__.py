"""Doc-Serve Server - RAG-based document indexing and query service."""

__version__ = "1.2.0"
