"""Tests for the agent-cli package."""
