"""A suite of AI-powered command-line tools for text correction, audio transcription, and voice assistance."""

from importlib.metadata import version

__version__ = version("agent-cli")
