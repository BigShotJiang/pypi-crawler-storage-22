"""Installation commands for agent-cli."""

from __future__ import annotations

__all__ = ["extras", "hotkeys", "services"]
