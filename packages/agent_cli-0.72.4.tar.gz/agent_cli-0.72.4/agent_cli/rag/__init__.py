"""RAG module."""

from __future__ import annotations
