"""Scripts package containing installation and service management scripts."""
