"""Core helper tests."""
