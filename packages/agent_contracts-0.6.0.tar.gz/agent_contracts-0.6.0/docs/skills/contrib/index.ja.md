# Contributor Skills（テンプレート）

このテンプレート群は、コーディングエージェントを使ってこのリポジトリへ貢献するためのものです。

- `docs/skills/contrib/agent_contracts_contributor_skill_template.md`
- `docs/skills/contrib/agent_contracts_contributor_skill_template.ja.md`

