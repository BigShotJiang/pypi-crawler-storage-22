# Contributor Skills (Templates)

These templates are for contributing to this repository with coding agents.

- `docs/skills/contrib/agent_contracts_contributor_skill_template.md`
- `docs/skills/contrib/agent_contracts_contributor_skill_template.ja.md`
