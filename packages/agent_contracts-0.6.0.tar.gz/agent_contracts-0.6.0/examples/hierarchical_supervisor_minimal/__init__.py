"""Minimal hierarchical supervisor example."""
