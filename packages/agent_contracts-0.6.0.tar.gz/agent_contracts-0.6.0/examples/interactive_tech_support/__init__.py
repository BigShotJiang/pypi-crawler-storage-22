"""Interactive Tech Support Demo.

A comprehensive example demonstrating agent-contracts for building
a multi-node tech support assistant with interactive CUI and
optional LLM integration.
"""

__version__ = "0.1.0"
