"""Entry point for running the interactive tech support demo.

Run with:
    python -m examples.interactive_tech_support
"""

from examples.interactive_tech_support.main import main

if __name__ == "__main__":
    main()
