"""Configuration management for the tech support demo."""

from examples.interactive_tech_support.config.loader import ConfigLoader, AppConfig

__all__ = ["ConfigLoader", "AppConfig"]
