"""Agent Factory - Core library for building AI agents.

This library provides a model-agnostic and channel-agnostic framework
for building AI agents with:
- Pluggable AI models (Bedrock, Anthropic, OpenAI, etc.)
- Pluggable communication channels (Slack, Teams, API, etc.)
- Tool registration and execution
- Conversation memory management
- Observability (logging, metrics, tracing)
- Circuit breaker for resilience

Example:
    from agent_factory import AgentOrchestrator
    from agent_factory.models import BedrockModel
    from agent_factory.channels import SlackChannel
    from agent_factory.handlers import SlackAgentHandler

    # Create agent
    agent = AgentOrchestrator(
        model=BedrockModel(),
        system_prompt="You are a helpful assistant.",
    )

    # Create Slack handler
    handler = SlackAgentHandler(
        orchestrator=agent,
        channel=SlackChannel(),
    )

    # Lambda entry point
    def lambda_handler(event, context):
        return handler.handle(event, context)
"""

from agent_factory.channels.base import BaseChannel, ChannelMessage
from agent_factory.core.circuit_breaker import CircuitBreaker, get_circuit_breaker
from agent_factory.core.config import BaseAgentConfig, get_env_or_ssm, get_ssm_parameter
from agent_factory.core.errors import AgentError, AIServiceError, ToolExecutionError
from agent_factory.core.gateway import ToolGateway
from agent_factory.core.memory import InMemoryStore, Memory
from agent_factory.core.orchestrator import AgentOrchestrator
from agent_factory.models.base import BaseModel, ModelResponse
from agent_factory.tools.base import BaseTool, ToolResult, tool

__version__ = "0.3.0"

__all__ = [
    # Core
    "AgentOrchestrator",
    "Memory",
    "InMemoryStore",
    "ToolGateway",
    # Config
    "BaseAgentConfig",
    "get_ssm_parameter",
    "get_env_or_ssm",
    # Circuit Breaker
    "CircuitBreaker",
    "get_circuit_breaker",
    # Errors
    "AgentError",
    "AIServiceError",
    "ToolExecutionError",
    # Models
    "BaseModel",
    "ModelResponse",
    # Channels
    "BaseChannel",
    "ChannelMessage",
    # Tools
    "BaseTool",
    "ToolResult",
    "tool",
]
