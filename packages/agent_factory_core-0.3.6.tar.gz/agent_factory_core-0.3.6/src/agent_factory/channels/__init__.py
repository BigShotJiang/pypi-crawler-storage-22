"""Communication channel implementations.

This module provides the base interface and implementations for
communication channels (Slack, Teams, API, etc.).
"""

from agent_factory.channels.base import (
    BaseChannel,
    ChannelAccessDeniedError,
    ChannelAuthError,
    ChannelError,
    ChannelMessage,
    ChannelResponse,
    ChannelSendError,
    ChannelType,
)

__all__ = [
    "BaseChannel",
    "ChannelAccessDeniedError",
    "ChannelAuthError",
    "ChannelError",
    "ChannelMessage",
    "ChannelResponse",
    "ChannelSendError",
    "ChannelType",
]


# Lazy imports for optional dependencies
def __getattr__(name: str):
    if name == "SlackChannel":
        from agent_factory.channels.slack import SlackChannel

        return SlackChannel
    elif name == "TeamsChannel":
        from agent_factory.channels.teams import TeamsChannel

        return TeamsChannel
    elif name == "ApiChannel":
        from agent_factory.channels.api import ApiChannel

        return ApiChannel
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
