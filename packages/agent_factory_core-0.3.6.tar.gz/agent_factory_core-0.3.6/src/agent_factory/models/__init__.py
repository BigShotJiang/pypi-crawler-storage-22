"""AI Model implementations.

This module provides the base interface and implementations for AI models.
"""

from agent_factory.models.base import BaseModel, Message, ModelResponse, ToolUse

__all__ = [
    "BaseModel",
    "ModelResponse",
    "Message",
    "ToolUse",
]


# Lazy imports for optional dependencies
def __getattr__(name: str):
    if name == "BedrockModel":
        from agent_factory.models.bedrock import BedrockModel

        return BedrockModel
    elif name == "AnthropicModel":
        from agent_factory.models.anthropic import AnthropicModel

        return AnthropicModel
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
