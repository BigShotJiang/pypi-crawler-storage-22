"""Observability module for AI agents.

This module provides logging, metrics, and tracing functionality
using AWS Lambda Powertools and OpenTelemetry.

Usage:
    from agent_factory.observability import get_logger, get_metrics, get_tracer

    logger = get_logger("my_module")
    logger.info("Processing request", extra={"user_id": "123"})

    metrics = get_metrics()
    metrics.add_metric("Requests", 1)

    tracer = get_tracer()

    @tracer.capture_method
    def my_function():
        ...
"""

from agent_factory.observability.logging import (
    get_logger,
    log_error,
    log_handler_complete,
    log_handler_start,
)
from agent_factory.observability.metrics import (
    get_metrics,
    record_ai_tokens,
    record_invocation,
    record_latency,
)
from agent_factory.observability.tracing import get_tracer

__all__ = [
    # Logging
    "get_logger",
    "log_handler_start",
    "log_handler_complete",
    "log_error",
    # Metrics
    "get_metrics",
    "record_invocation",
    "record_latency",
    "record_ai_tokens",
    # Tracing
    "get_tracer",
]
