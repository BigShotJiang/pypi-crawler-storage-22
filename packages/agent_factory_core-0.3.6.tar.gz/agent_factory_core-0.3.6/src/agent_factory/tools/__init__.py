"""Tool definitions and interfaces.

This module provides the base interface for tools that can be
used by AI agents, including MCP client support for external tool servers.
"""

from agent_factory.tools.base import BaseTool, ToolResult, tool
from agent_factory.tools.mcp import MCPClient, MCPToolWrapper, get_mcp_client

__all__ = [
    "BaseTool",
    "ToolResult",
    "tool",
    # MCP
    "MCPClient",
    "MCPToolWrapper",
    "get_mcp_client",
]
