from typing import Any, Dict, Callable, List, Optional, Tuple
import inspect

# Mapping from ToolSpec field name to MCP hint name
TOOL_ANNOTATION_FIELDS: List[Tuple[str, str]] = [
    ("read_only", "readOnlyHint"),
    ("destructive", "destructiveHint"),
    ("idempotent", "idempotentHint"),
    ("open_world", "openWorldHint"),
]


class ToolSpec:
    def __init__(
        self,
        name: str,
        description: str,
        fn: Callable,
        param_schema: Dict[str, Any],
        tags: List[str],
        read_only: Optional[bool] = None,
        destructive: Optional[bool] = None,
        idempotent: Optional[bool] = None,
        open_world: Optional[bool] = None,
    ):
        self.name = name
        self.description = description
        self.fn = fn
        self.param_schema = param_schema
        self.tags = tags
        self.is_async = inspect.iscoroutinefunction(fn)
        self.read_only = read_only
        self.destructive = destructive
        self.idempotent = idempotent
        self.open_world = open_world


class ConnectorRegistry:
    _tools: Dict[str, ToolSpec] = {}

    @classmethod
    def register_tool(
        cls,
        name: str,
        description: str,
        fn: Callable,
        param_schema: Dict[str, Any],
        tags: List[str],
        read_only: Optional[bool] = None,
        destructive: Optional[bool] = None,
        idempotent: Optional[bool] = None,
        open_world: Optional[bool] = None,
    ) -> None:
        cls._tools[name] = ToolSpec(
            name, description, fn, param_schema, tags, read_only, destructive, idempotent, open_world
        )

    @classmethod
    def _format_tool_spec(cls, spec: ToolSpec) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "name": spec.name,
            "description": spec.description,
            "input_schema": spec.param_schema,
        }
        # Add annotations if any are set
        annotations: Dict[str, bool] = {}
        for field_name, hint_name in TOOL_ANNOTATION_FIELDS:
            value = getattr(spec, field_name, None)
            if value is not None:
                annotations[hint_name] = value
        if annotations:
            result["annotations"] = annotations
        return result

    @classmethod
    def list_tools(cls) -> List[Dict[str, Any]]:
        return [cls._format_tool_spec(t) for t in cls._tools.values()]

    @classmethod
    def get_tool(cls, name: str) -> Dict[str, Any]:
        if name not in cls._tools:
            raise ValueError(f"Tool {name!r} not found in registry")
        return cls._format_tool_spec(cls._tools[name])

    @classmethod
    def get_tool_spec(cls, name: str) -> ToolSpec:
        if name not in cls._tools:
            raise ValueError(f"Tool {name!r} not found in registry")
        return cls._tools[name]
