"""Strongly-typed webhook input/output types for connector webhooks."""

from datetime import datetime
from enum import Enum
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from .auth import AuthContext


class RegistrationStatus(str, Enum):
    """Status of webhook subscription registration with external system."""

    # Webhook is registered but awaiting automatic confirmation from the external service.
    # Use when the external service will send a verification/handshake request to confirm
    # (e.g., Google Calendar which sends a "sync" notification after watch creation).
    AWAITING_CONFIRMATION_AUTO = "AWAITING_CONFIRMATION_AUTO"

    # Webhook is immediately active and ready to receive events.
    # Use when the external service confirms the webhook during registration
    # (e.g., GitHub, GitLab where webhooks are active immediately after API call).
    ACTIVE = "ACTIVE"

    # Webhook subscription has been disabled by the user.
    # This is typically set by the backend when a user disables webhooks, not by connectors.
    DISABLED = "DISABLED"

    # Webhook requires manual configuration by the user in the external service's UI.
    # Use when the external service doesn't support programmatic webhook creation
    # (e.g., Slack where the user must configure Event Subscriptions manually).
    AWAITING_CONFIRMATION_MANUAL = "AWAITING_CONFIRMATION_MANUAL"


class RegisterWebhooksInput(BaseModel):
    """Input for register_webhooks function.

    Connector-specific fields (e.g., signing_secret, channel_id, ttl, selected_event_types)
    are passed as extra fields and accessible via model_extra:
        context.model_extra.get("signing_secret")
        context.model_extra.get("channel_id")
    """

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    callback_url: str = Field(..., description="Webhook endpoint URL to register")
    verification_key: str = Field(..., description="Secret for signature verification")
    auth_context: AuthContext = Field(..., description="Auth context for API calls")


class RegisterWebhooksOutput(BaseModel):
    """Output from register_webhooks function.

    For errors, connectors should raise an exception rather than returning an error status.
    """

    model_config = ConfigDict(extra="allow")

    status: RegistrationStatus = Field(..., description="Registration result status")
    verification_key: Optional[str] = Field(None, description="Override verification key")
    source_metadata: Optional[dict[str, Any]] = Field(None, description="Connector-specific metadata for teardown")
    subscription_expires_at: Optional[datetime] = Field(None, description="When subscription expires")


class VerifyWebhooksInput(BaseModel):
    """Input for verify_webhooks function."""

    model_config = ConfigDict(extra="allow")

    payload: dict[str, Any] = Field(..., description="Parsed JSON request body")
    headers: dict[str, str] = Field(..., description="HTTP request headers")
    verification_key: str = Field(..., description="Secret for signature verification")
    raw_body: str = Field(..., description="Raw request body for signature verification")


class VerifyWebhooksOutput(BaseModel):
    """Output from verify_webhooks function.

    Connector-specific response fields (e.g., Slack's "challenge") are allowed
    via extra="allow" configuration.
    """

    model_config = ConfigDict(extra="allow")

    valid: bool = Field(..., description="Whether signature verification passed")
    error: Optional[str] = Field(None, description="Error message if validation failed")
    confirmed: Optional[bool] = Field(None, description="True if webhook handshake confirmed")


class TransformWebhooksInput(BaseModel):
    """Input for transform_webhooks function."""

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    auth_context: AuthContext = Field(..., description="Auth context for API calls")
    method: str = Field(..., description="HTTP method")
    url: str = Field(..., description="Request URL")
    headers: dict[str, str] = Field(..., description="HTTP headers")
    body: dict[str, Any] = Field(..., description="Request body")


class TransformWebhooksOutput(BaseModel):
    """Output from transform_webhooks function."""

    model_config = ConfigDict(extra="allow")

    valid: bool = Field(..., description="Whether transformation succeeded")
    data: Optional[Any] = Field(None, description="Transformed payload")
    error: Optional[str] = Field(None, description="Error message if transformation failed")


class TeardownWebhooksInput(BaseModel):
    """Input for teardown_webhooks function."""

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    listener_token: str = Field(..., description="Webhook listener token")
    verification_key: str = Field(..., description="Verification key")
    source_metadata: dict[str, Any] = Field(..., description="Metadata from registration for cleanup")
    auth_context: AuthContext = Field(..., description="Auth context for API calls")


class TeardownWebhooksOutput(BaseModel):
    """Output from teardown_webhooks function."""

    model_config = ConfigDict(extra="allow")

    status: Literal["success", "error"] = Field(..., description="Teardown result")
    error: Optional[str] = Field(None, description="Error message if teardown failed")
