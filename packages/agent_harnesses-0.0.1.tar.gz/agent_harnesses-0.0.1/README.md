# agent-harnesses

Harness infrastructure for running and evaluating AI agents.

> This package is under active development by [Synth Laboratories](https://usesynth.ai).

## Installation

```bash
pip install agent-harnesses
```

## Status

This package is in early planning. Watch this space.
