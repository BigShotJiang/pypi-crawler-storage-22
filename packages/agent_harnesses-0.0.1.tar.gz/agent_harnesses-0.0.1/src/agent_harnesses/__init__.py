"""Harness infrastructure for running and evaluating AI agents."""

__version__ = "0.0.1"
