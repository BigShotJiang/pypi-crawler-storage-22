rootProject.name = "agent-memory-client-java"
