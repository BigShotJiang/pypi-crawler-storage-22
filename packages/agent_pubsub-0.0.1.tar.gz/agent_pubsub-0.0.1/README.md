# agent-pubsub

Pub/sub messaging infrastructure for AI agent systems.

> This package is under active development by [Synth Laboratories](https://usesynth.ai).

## Installation

```bash
pip install agent-pubsub
```

## Status

This package is in early planning. Watch this space.
