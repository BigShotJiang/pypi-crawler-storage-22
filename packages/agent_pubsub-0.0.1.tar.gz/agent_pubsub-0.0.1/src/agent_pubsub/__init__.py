"""Pub/sub messaging infrastructure for AI agent systems."""

__version__ = "0.0.1"
