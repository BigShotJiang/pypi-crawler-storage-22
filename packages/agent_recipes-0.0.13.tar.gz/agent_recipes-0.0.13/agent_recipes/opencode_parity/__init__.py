"""
OpenCode Parity Examples for PraisonAI Agents.

These examples demonstrate features implemented for OpenCode parity.
"""
