# AI Doc Translator

Translate documents to different languages.

## Usage
```bash
praison run ai-doc-translator document.md --language es
praison run ai-doc-translator document.txt --language fr
```

## Output
- `translated.md` - Translated document
