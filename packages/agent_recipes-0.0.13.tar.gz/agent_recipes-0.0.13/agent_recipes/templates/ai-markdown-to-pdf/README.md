# AI Markdown to PDF

Convert Markdown to styled PDF using pandoc.

## Usage
```bash
praison run ai-markdown-to-pdf document.md
praison run ai-markdown-to-pdf document.md --output report.pdf
```

## Output
- `document.pdf` - Styled PDF
