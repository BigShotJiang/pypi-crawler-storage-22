"""
Entry point for running as python -m ai_video_editor
"""

from .cli import main

if __name__ == "__main__":
    main()
