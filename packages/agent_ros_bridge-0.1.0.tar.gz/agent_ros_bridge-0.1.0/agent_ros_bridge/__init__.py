"""
Agent ROS Bridge - Universal ROS1/ROS2 bridge for AI agents.

This package provides a multi-protocol, multi-robot gateway enabling
AI agents to control ROS-based robots and embodied intelligence systems.

Example:
    >>> from agent_ros_bridge import Bridge
    >>> from agent_ros_bridge.transports.websocket import WebSocketTransport
    >>> 
    >>> bridge = Bridge()
    >>> bridge.transport_manager.register(WebSocketTransport({"port": 8765}))
    >>> await bridge.start()
"""

__version__ = "2.0.0"
__author__ = "Agent ROS Bridge Team"
__email__ = "dev@agent-ros-bridge.org"

# Import main components for convenience
from agent_ros_bridge.gateway_v2.core import (
    Bridge,
    Transport,
    TransportManager,
    Connector,
    ConnectorRegistry,
    Robot,
    RobotFleet,
    Plugin,
    PluginManager,
    Message,
    Header,
    Command,
    Telemetry,
    Event,
    Identity,
    QoS,
)

from agent_ros_bridge.gateway_v2.config import (
    BridgeConfig,
    TransportConfig,
    ConnectorConfig,
    SecurityConfig,
    PluginConfig,
    ConfigLoader,
)

__all__ = [
    "Bridge",
    "Transport",
    "TransportManager",
    "Connector",
    "ConnectorRegistry",
    "Robot",
    "RobotFleet",
    "Plugin",
    "PluginManager",
    "Message",
    "Header",
    "Command",
    "Telemetry",
    "Event",
    "Identity",
    "QoS",
    "BridgeConfig",
    "TransportConfig",
    "ConnectorConfig",
    "SecurityConfig",
    "PluginConfig",
    "ConfigLoader",
]
