# Publishing to Homebrew

This guide explains how to publish `agent-skill-kit` to Homebrew using a custom Tap.

## Prerequisites

1.  A GitHub account.
2.  `agent-skill-kit` **v0.1.3** must be published to PyPI (so the download URL works).

## 1. Create the Tap Repository

1.  Go to GitHub and create a new **public** repository named:
    `homebrew-Agent-Skill-Kit`
    (The `homebrew-` prefix is standard convention).

## 2. Add the Formula

1.  In the new repository, create a folder named `Formula` (optional, but recommended).
2.  Copy the file `Formula/agent-skill-kit.rb` from this project into that repository.
    *   Path in new repo: `Formula/agent-skill-kit.rb` (or just `agent-skill-kit.rb` at root).

## 3. Usage

Users can now install your tool with:

```bash
brew tap <your-github-username>/Agent-Skill-Kit
brew install agent-skill-kit
```

### Updates

When you release a new version (e.g., v0.1.4):
1.  Publish the new version to PyPI.
2.  Get the SHA256 of the new tarball:
    ```bash
    shasum -a 256 dist/agent_skill_kit-0.1.4.tar.gz
    ```
3.  Update the `url` and `sha256` in `agent-skill-kit.rb` in your `homebrew-Agent-Skill-Kit` repo.
