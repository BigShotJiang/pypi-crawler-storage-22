# agent-tasks

Task environments and evaluation harnesses for AI agents.

> This package is under active development by [Synth Laboratories](https://usesynth.ai).

## Installation

```bash
pip install agent-tasks
```

## Status

This package is in early planning. Watch this space.
