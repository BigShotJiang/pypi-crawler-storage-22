# 🚀 Publishing Guide

1.  **Update Version**: Bump the version in `pyproject.toml`.
2.  **Tag**: Create a new git tag.
    ```bash
    git tag v0.1.0
    git push origin v0.1.0
    ```
3.  **Verify**: Check the "Publish to PyPI" action in GitHub Actions tab.

## Local Test Build

```bash
pip install hatch
hatch build
```
