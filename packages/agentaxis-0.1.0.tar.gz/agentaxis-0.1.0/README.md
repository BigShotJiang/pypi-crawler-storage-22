# 🤖 AI Agent Framework

A production-ready, extensible AI Agent Framework for Python. Built with Clean Architecture, it supports multi-provider LLM orchestration (via LiteLLM), memory management, and tool usage.

## 🚀 Features

-   **Multi-Provider Support**: Switch between OpenAI, Anthropic, Gemini, and local models seamlessly using LiteLLM.
-   **Intelligent Routing**: Architecture designed for dynamic model selection.
-   **Tooling System**: Register Python functions as tools with automatic JSON schema generation + MCP Support.
-   **Memory Management**: Pluggable memory backends (In-Memory provided, Extensible to Redis/Postgres).
-   **Vector Store / RAG**: Built-in adapter for ChromaDB.
-   **Clean Architecture**: strictly decoupled core logic from infrastructure.

## 📦 Installation

```bash
pip install agentaxis
```

## ⚡ Quick Start

### 1. Basic Agent

```python
from agentaxis import AgentService, AgentEntity, InMemoryMemory, LiteLLMAdapter
from agentaxis.adapters.tools import ToolRegistry
import asyncio

async def main():
    # 1. Setup Wrapper
    llm = LiteLLMAdapter(model="gpt-4o", api_key="sk-...")
    memory = InMemoryMemory()
    registry = ToolRegistry()
    
    # 2. Register Tools
    @registry.register
    def get_time(timezone: str) -> str:
        """Returns current time in timezone."""
        return "12:00 PM"

    # 3. Create Agent
    entity = AgentEntity(id="bot-1", name="Helper", role_description="Assistant")
    agent = AgentService(agent_entity=entity, llm=llm, memory=memory, tool_registry=registry)

    # 4. Chat
    response = await agent.chat("What time is it in NY?")
    print(response)

if __name__ == "__main__":
    asyncio.run(main())
```

## 🏗️ Architecture

The framework follows **Hexagonal Architecture**:

-   **Core/Domain**: Pure business entities (`Agent`, `Message`).
-   **Core/Ports**: Interfaces for external dependencies (`BaseLLM`, `MemoryPort`).
-   **Adapters**: Concrete implementations (`LiteLLMAdapter`, `ChromaAdapter`).

## 🛠️ Development

1.  Clone the repository.
2.  Install dependencies: `pip install -e .[dev]`
3.  Run tests: `pytest`

## 🤝 Contribution

Contributions are welcome! Please follow the Clean Architecture patterns.
