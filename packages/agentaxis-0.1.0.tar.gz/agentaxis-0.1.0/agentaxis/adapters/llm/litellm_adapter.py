from typing import List, Dict, Any, AsyncGenerator, Union
import litellm
from ...core.ports.driven.llm_port import BaseLLM
from ...core.domain.message import Message, Role, ToolCall

class LiteLLMAdapter(BaseLLM):
    def __init__(self, model: str, api_key: str = None, api_base: str = None, **kwargs):
        self.model = model
        self.api_key = api_key
        self.api_base = api_base
        self.default_args = kwargs

    async def generate(
        self, 
        messages: List[Message], 
        tools: List[Dict[str, Any]] | None = None,
        stream: bool = False,
        **kwargs
    ) -> Union[Message, AsyncGenerator[Message, None]]:
        
        # Convert domain messages to dictionary format for LiteLLM
        formatted_messages = [msg.to_dict() for msg in messages]
        
        # Merge default args with call-time args
        call_params = {**self.default_args, **kwargs}
        if self.api_key:
            call_params["api_key"] = self.api_key
        if self.api_base:
            call_params["api_base"] = self.api_base # litellm uses api_base too
            
        response = await litellm.acompletion(
            model=self.model,
            messages=formatted_messages,
            tools=tools,
            stream=stream,
            **call_params
        )

        if stream:
            return self._handle_stream(response)
        else:
            return self._handle_response(response)

    def _handle_response(self, response: Any) -> Message:
        choice = response.choices[0]
        message_data = choice.message
        
        content = message_data.get("content")
        tool_calls_data = message_data.get("tool_calls")
        
        tool_calls = None
        if tool_calls_data:
            tool_calls = []
            for tc in tool_calls_data:
                tool_calls.append(ToolCall(
                    id=tc.id,
                    type=tc.type,
                    function=tc.function.model_dump() if hasattr(tc.function, 'model_dump') else tc.function
                ))

        return Message(
            role=Role(message_data.role),
            content=content,
            tool_calls=tool_calls
        )

    async def _handle_stream(self, response_generator) -> AsyncGenerator[Message, None]:
        # Simple stream handler - for now just yields content chunks
        # A more robust one connects full chunks for tool calls, but we start basic.
        async for chunk in response_generator:
            delta = chunk.choices[0].delta
            content = delta.get("content")
            if content:
                yield Message(
                    role=Role.ASSISTANT,
                    content=content
                )
