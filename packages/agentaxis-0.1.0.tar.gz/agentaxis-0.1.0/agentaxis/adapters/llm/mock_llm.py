from typing import List, Dict, Any, Union, AsyncGenerator
from ...core.ports.driven.llm_port import BaseLLM
from ...core.domain.message import Message, Role, ToolCall

class MockLLM(BaseLLM):
    """
    A controllable LLM for testing purposes.
    """
    def __init__(self, responses: List[Message] = None):
        self.responses = responses or []
        self.call_count = 0

    async def generate(
        self, 
        messages: List[Message], 
        tools: List[Dict[str, Any]] | None = None,
        stream: bool = False,
        **kwargs
    ) -> Union[Message, AsyncGenerator[Message, None]]:
        
        if self.call_count < len(self.responses):
            response = self.responses[self.call_count]
            self.call_count += 1
            return response
        
        return Message(role=Role.ASSISTANT, content="Mock LLM default response")
