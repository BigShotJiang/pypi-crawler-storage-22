from typing import Dict, List, Any
from ...core.ports.driven.memory_port import MemoryPort
from ...core.domain.message import Message

class InMemoryMemory(MemoryPort):
    def __init__(self):
        self._storage: Dict[str, List[Message]] = {}

    async def add_message(self, session_id: str, message: Message):
        if session_id not in self._storage:
            self._storage[session_id] = []
        self._storage[session_id].append(message)

    async def get_history(self, session_id: str) -> List[Message]:
        return self._storage.get(session_id, []).copy()

    async def clear(self, session_id: str):
        if session_id in self._storage:
            del self._storage[session_id]
