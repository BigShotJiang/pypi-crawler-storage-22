import inspect
from typing import Callable, Dict, Any, List, Optional
from pydantic import BaseModel, create_model
from docstring_parser import parse
from ...core.domain.tool import Tool

class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, func: Callable) -> Callable:
        """
        Decorator to register a python function as a tool.
        """
        tool = self._create_tool_from_func(func)
        self._tools[tool.name] = tool
        return func

    def register_tool(self, tool: Tool):
        """Register an existing Tool object (e.g. from MCP)."""
        self._tools[tool.name] = tool

    def get_tools(self) -> List[Tool]:
        return list(self._tools.values())

    def get_tool(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def get_openai_tools(self) -> List[Dict[str, Any]]:
        return [t.to_openai_schema() for t in self._tools.values()]

    def execute(self, name: str, arguments: Dict[str, Any]) -> Any:
        tool = self._tools.get(name)
        if not tool:
            raise ValueError(f"Tool '{name}' not found")
        return tool.func(**arguments)

    def _create_tool_from_func(self, func: Callable) -> Tool:
        name = func.__name__
        doc = parse(func.__doc__ or "")
        description = doc.short_description or f"Function {name}"
        if doc.long_description:
            description += f"\n{doc.long_description}"

        # Generate JSON Schema from Type Hints using Pydantic
        # This is a simplified version. For prod, we'd use TypeAdapter or custom logic.
        sig = inspect.signature(func)
        fields = {}
        for param_name, param in sig.parameters.items():
            if param_name == "self": continue
            
            annotation = param.annotation
            if annotation == inspect.Parameter.empty:
                annotation = Any
            
            default = param.default
            if default == inspect.Parameter.empty:
                fields[param_name] = (annotation, ...)
            else:
                fields[param_name] = (annotation, default)
        
        # Create a dynamic Pydantic model to get the schema
        DynamicModel = create_model(f"{name}Args", **fields)
        schema = DynamicModel.model_json_schema()
        
        # Cleanup schema for OpenAI (remove title, etc if needed)
        if "title" in schema: del schema["title"]

        return Tool(
            name=name,
            description=description,
            parameters=schema,
            func=func
        )
