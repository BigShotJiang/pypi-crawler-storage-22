from typing import List, Dict, Any
import chromadb
from ...core.ports.driven.vector_port import VectorDBPort

class ChromaAdapter(VectorDBPort):
    def __init__(self, collection_name: str = "agentaxis_docs", path: str = "./chroma_db"):
        self.client = chromadb.PersistentClient(path=path)
        self.collection = self.client.get_or_create_collection(collection_name)

    async def add_documents(self, documents: List[str], metadatas: List[Dict[str, Any]], ids: List[str]):
        # Chroma APIs are synchronous by default, usually fine for local dev
        # In prod, offload to thread/executor or usage asymc client if available
        self.collection.add(
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )

    async def query(self, query: str, top_k: int = 4) -> List[str]:
        results = self.collection.query(
            query_texts=[query],
            n_results=top_k
        )
        # Flatten results (returns list of lists)
        return results['documents'][0] if results['documents'] else []
