from typing import List, Optional
from pydantic import BaseModel, Field
from .message import Message

class AgentEntity(BaseModel):
    """
    Represents the core State of an Agent.
    This is NOT the orchestrator service, but the domain entity.
    """
    id: str
    name: str
    role_description: str
    memory: List[Message] = Field(default_factory=list)
    
    def add_message(self, message: Message):
        self.memory.append(message)
        
    def clear_memory(self):
        self.memory = []
