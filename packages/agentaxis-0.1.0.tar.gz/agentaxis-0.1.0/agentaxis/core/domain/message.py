from enum import Enum
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field

class Role(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    FUNCTION = "function"
    TOOL = "tool"

class ToolCall(BaseModel):
    id: str
    type: str = "function"
    function: Dict[str, Any]

class Message(BaseModel):
    role: Role
    content: Optional[str] = None
    name: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary excluding None values for cleaner API payloads."""
        return self.model_dump(exclude_none=True)
