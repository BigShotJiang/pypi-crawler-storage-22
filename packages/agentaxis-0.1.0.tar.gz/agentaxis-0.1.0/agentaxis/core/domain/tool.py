from typing import Callable, Dict, Any, Optional, List
from pydantic import BaseModel, Field

class Tool(BaseModel):
    """
    Domain entity representing a tool that the agent can usage.
    """
    name: str
    description: str
    parameters: Dict[str, Any]  # JSON Schema
    func: Callable[..., Any] = Field(exclude=True)  # The actual callable, excluded from serialization
    
    def to_openai_schema(self) -> Dict[str, Any]:
        """
        Convert to OpenAI function calling format.
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters
            }
        }
