from abc import ABC, abstractmethod
from typing import List, Dict, Any, AsyncGenerator, Union
from ...domain.message import Message

class BaseLLM(ABC):
    """
    Port interface that any LLM Provider Adapter must implement.
    """
    
    @abstractmethod
    async def generate(
        self, 
        messages: List[Message], 
        tools: List[Dict[str, Any]] | None = None,
        stream: bool = False,
        **kwargs
    ) -> Union[Message, AsyncGenerator[Message, None]]:
        """
        Generate a response from the LLM.
        
        Args:
            messages: List of domain Message objects
            tools: Optional list of tool definitions (JSON schema)
            stream: Whether to stream the response
            **kwargs: Extra provider-specific args
            
        Returns:
            Either a single Message object (if not streaming)
            or an AsyncGenerator yielding Message chunks.
        """
        pass
