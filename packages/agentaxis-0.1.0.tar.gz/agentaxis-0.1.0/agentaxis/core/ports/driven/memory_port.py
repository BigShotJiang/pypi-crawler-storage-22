from abc import ABC, abstractmethod
from typing import List
from ...domain.message import Message

class MemoryPort(ABC):
    @abstractmethod
    async def add_message(self, session_id: str, message: Message):
        pass

    @abstractmethod
    async def get_history(self, session_id: str) -> List[Message]:
        pass

    @abstractmethod
    async def clear(self, session_id: str):
        pass
