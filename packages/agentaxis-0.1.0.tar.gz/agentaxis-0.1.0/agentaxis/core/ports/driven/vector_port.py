from abc import ABC, abstractmethod
from typing import List, Dict, Any

class VectorDBPort(ABC):
    @abstractmethod
    async def add_documents(self, documents: List[str], metadatas: List[Dict[str, Any]], ids: List[str]):
        pass

    @abstractmethod
    async def query(self, query: str, top_k: int = 4) -> List[str]:
        pass
