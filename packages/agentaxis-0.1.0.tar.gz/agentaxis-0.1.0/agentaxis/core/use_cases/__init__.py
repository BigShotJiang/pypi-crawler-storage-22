from .router import ModelRouter
