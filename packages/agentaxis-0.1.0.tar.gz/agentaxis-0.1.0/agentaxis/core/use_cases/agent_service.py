from typing import List, Dict, Any, Optional
import json
import logging
from ..domain.message import Message, Role
from ..domain.agent import AgentEntity
from ..ports.driven.llm_port import BaseLLM
from ..ports.driven.memory_port import MemoryPort
from ...adapters.tools.registry import ToolRegistry

logger = logging.getLogger(__name__)

class AgentService:
    """
    Main entry point for the Agent. Orchestrates LLM, Memory, and Tools.
    """
    def __init__(
        self,
        agent_entity: AgentEntity,
        llm: BaseLLM,
        memory: MemoryPort,
        tool_registry: ToolRegistry = None,
        max_steps: int = 10
    ):
        self.entity = agent_entity
        self.llm = llm
        self.memory = memory
        self.tools = tool_registry or ToolRegistry()
        self.max_steps = max_steps

    async def chat(self, user_input: str, session_id: str = "default", max_steps: Optional[int] = None) -> str:
        limit = max_steps or self.max_steps
        
        # 1. Add User Message to Memory & Entity
        logger.info(f"Agent {self.entity.id} received message: {user_input[:50]}...")
        user_msg = Message(role=Role.USER, content=user_input)
        await self.memory.add_message(session_id, user_msg)
        
        # 2. Retrieve History
        history = await self.memory.get_history(session_id)
        
        # 3. Agent Loop (ReAct / Function Calling)
        current_steps = 0
        final_response = ""
        
        while current_steps < limit:
            logger.info(f"--- Step {current_steps + 1} / {limit} ---")
            # Prepare tools for LLM
            available_tools = self.tools.get_openai_tools()
            
            # Call LLM
            response_msg = await self.llm.generate(
                messages=history,
                tools=available_tools if available_tools else None
            )
            
            # Auto-handle generator if streaming (simplification for now: consume stream)
            if hasattr(response_msg, '__aiter__'):
                # Handle stream accumulation here if needed, for now assume block
                pass 
                
            # Add Assistant Message to Memory
            await self.memory.add_message(session_id, response_msg)
            history.append(response_msg)
            
            # Check for Tool Calls
            if response_msg.tool_calls:
                for tool_call in response_msg.tool_calls:
                    tool_fn = tool_call.function
                    tool_name = tool_fn['name']
                    
                    # Handle arguments: could be JSON string (real LLM) or Dict (mock/pre-parsed)
                    raw_args = tool_fn.get('arguments', {})
                    if isinstance(raw_args, str):
                        try:
                            tool_args = json.loads(raw_args)
                        except json.JSONDecodeError:
                            tool_args = {} # Or handle error
                    else:
                        tool_args = raw_args
                    
                    # Execute Tool
                    try:
                        logger.info(f"Executing tool: {tool_name} with args: {tool_args}")
                        print(f"   [Agent] Executing {tool_name} with {tool_args}")
                        result = self.tools.execute(tool_name, tool_args)
                        result_str = str(result)
                        logger.info(f"Tool {tool_name} executed successfully.")
                    except Exception as e:
                        logger.error(f"Error executing tool {tool_name}: {e}")
                        result_str = f"Error executing tool {tool_name}: {e}"
                    
                    # Create Tool Output Message
                    tool_msg = Message(
                        role=Role.TOOL,
                        content=result_str,
                        tool_call_id=tool_call.id,
                        name=tool_name
                    )
                    await self.memory.add_message(session_id, tool_msg)
                    history.append(tool_msg)
                
                # Loop continues to let LLM process tool output
                current_steps += 1
            else:
                # No tool calls, we are done
                final_response = response_msg.content
                break
        
        return final_response
