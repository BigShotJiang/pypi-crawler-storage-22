from typing import Dict, Any, Optional
from ..ports.driven.llm_port import BaseLLM

class ModelRouter:
    """
    Service to handle model selection and routing.
    In the future, this will handle cost-based and latency-based routing.
    For now, it manages the active model ID.
    """
    def __init__(self, default_model: str = "gpt-4o"):
        self.active_model_id = default_model
        # Future: self.model_registry = {}

    def get_model_id(self, task: str = None, complexity: str = "medium") -> str:
        """
        Decide which model to usage. 
        Currently returns the active model, but designed to be extensible.
        """
        # Placeholder for intelligent routing logic
        return self.active_model_id

    def set_model(self, model_id: str):
        """Runtime model switching."""
        self.active_model_id = model_id
