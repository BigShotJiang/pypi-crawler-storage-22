import sys
import os
import asyncio
import json

# Setup path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, ".."))
sys.path.insert(0, project_root)

from agentaxis.core.domain.agent import AgentEntity
from agentaxis.core.domain.message import Message, Role, ToolCall
from agentaxis.core.use_cases.agent_service import AgentService
from agentaxis.adapters.memory.in_memory import InMemoryMemory
from agentaxis.adapters.tools.registry import ToolRegistry
from agentaxis.adapters.llm.mock_llm import MockLLM

async def run_demo():
    print("🤖 Initializing AI Agent Demo...")

    # 1. Setup Tool
    registry = ToolRegistry()
    @registry.register
    def get_weather(city: str) -> str:
        """Get the weather for a city."""
        print(f"   [Tool Executed] get_weather called for {city}")
        return f"The weather in {city} is Sunny, 25°C"

    # 2. Setup Mock LLM sequence
    # Turn 1: LLM decides to call tool
    msg1 = Message(
        role=Role.ASSISTANT,
        content=None,
        tool_calls=[ToolCall(id="call_1", function={"name": "get_weather", "arguments": {"city": "Paris"}})]
    )
    # Turn 2: LLM summarizes result
    msg2 = Message(
        role=Role.ASSISTANT,
        content="The weather in Paris is Sunny and 25 degrees Celsius."
    )
    
    mock_llm = MockLLM(responses=[msg1, msg2])

    # 3. Setup Agent
    agent_entity = AgentEntity(id="agent-1", name="DemoBot", role_description="Helpful Assistant")
    memory = InMemoryMemory()
    
    service = AgentService(
        agent_entity=agent_entity,
        llm=mock_llm,
        memory=memory,
        tool_registry=registry
    )

    # 4. Run Chat
    user_query = "What is the weather in Paris?"
    print(f"👤 User: {user_query}")
    
    response = await service.chat(user_query)
    
    print(f"🤖 Agent: {response}")
    
    # Validation
    history = await memory.get_history("default")
    print(f"\n✅ Interaction History ({len(history)} messages):")
    for m in history:
        print(f" - {m.role}: {m.content or '[Tool Call]'}")

    assert "Sunny" in response
    print("\n🎉 Functional Test Passed!")

if __name__ == "__main__":
    asyncio.run(run_demo())
