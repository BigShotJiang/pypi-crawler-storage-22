import sys
import os
import asyncio
import pytest

# Setup path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, ".."))
sys.path.insert(0, project_root)

# 1. Test Tools
from agentaxis.adapters.tools.registry import ToolRegistry

registry = ToolRegistry()

@registry.register
def calculator(a: int, b: int) -> int:
    """Useful for adding two numbers."""
    return a + b

print("\n--- Testing Tools ---")
tools = registry.get_openai_tools()
print(f"✅ Generated Schema: {tools[0]['function']['name']}")
assert tools[0]['function']['parameters']['properties']['a']['type'] == 'integer'
print("✅ Schema type validation passed")

# 2. Test Memory
from agentaxis.adapters.memory.in_memory import InMemoryMemory
from agentaxis.core.domain.message import Message, Role

print("\n--- Testing Memory ---")
memory = InMemoryMemory()
@pytest.mark.asyncio
async def test_memory():
    session_id = "test_session"
    await memory.add_message(session_id, Message(role=Role.USER, content="Hi"))
    history = await memory.get_history(session_id)
    print(f"✅ History retrieved: {len(history)} messages")
    assert history[0].content == "Hi"

# 3. Test Vector Store (Mocking Chroma to avoid heavy DB init if possible, but we'll try real)
from agentaxis.adapters.vectorstore.chroma_adapter import ChromaAdapter

print("\n--- Testing Vector Store ---")
try:
    # Use a temp path for testing
    vector_db = ChromaAdapter(path="./test_chroma_db")
    print("✅ Chroma Adapter initialized")
except Exception as e:
    print(f"⚠️ Chroma Init skipped (expected if libs missing): {e}")

async def main():
    await test_memory()
    print("\n✅ Phase 3 Verification Complete!")

if __name__ == "__main__":
    asyncio.run(main())
