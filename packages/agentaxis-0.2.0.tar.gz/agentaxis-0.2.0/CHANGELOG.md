# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-02-06

### Added
- **HTTPEngine**: New adapter for connecting to generic HTTP LLM endpoints with Bearer token authentication
- **System Prompt Support**: Both `AIEngine` and `HTTPEngine` now accept `system_prompt` parameter to configure agent behavior
- **Google Cloud Support**: Added `litellm[google]` dependency for Vertex AI compatibility

### Changed
- **BREAKING**: Renamed `LiteLLMAdapter` to `AIEngine` for more intuitive naming
  - Update imports: `from agentaxis import AIEngine` (previously `LiteLLMAdapter`)
- Updated all examples and documentation to reflect new naming

### Fixed
- Removed duplicate line assignments in `HTTPEngine.__init__`

## [0.1.0] - 2026-01-XX

### Added
- Initial release
- Multi-provider LLM support via LiteLLM
- Tool registry with automatic schema generation
- In-memory storage adapter
- ChromaDB vector store adapter
- Clean Architecture implementation
