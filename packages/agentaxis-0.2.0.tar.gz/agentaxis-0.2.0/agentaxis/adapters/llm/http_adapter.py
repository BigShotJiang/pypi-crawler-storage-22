from typing import List, Dict, Any, AsyncGenerator, Union, Optional
import httpx
import json
from ...core.ports.driven.llm_port import BaseLLM
from ...core.domain.message import Message, Role

class HTTPEngine(BaseLLM):
    """
    A generic HTTP-based LLM engine.
    Allows connecting to any LLM provider via a standard HTTP endpoint 
    using a Bearer token and a JSON body.
    """

    def __init__(
        self, 
        url: str, 
        auth_token: Optional[str] = None, 
        headers: Optional[Dict[str, str]] = None,
        model: str = "default",
        system_prompt: str = None,
        **kwargs
    ):
        """
        Initialize the HTTP Engine.

        Args:
            url: The full endpoint URL.
            auth_token: Optional Bearer token.
            headers: Optional additional headers.
            model: Model identifier (sent in body usually).
            **kwargs: Default request parameters to include in body.
        """
        self.url = url
        self.auth_token = auth_token
        self.model = model
        self.system_prompt = system_prompt
        self.default_headers = headers or {}
        
        if self.auth_token:
            self.default_headers["Authorization"] = f"Bearer {self.auth_token}"
            
        self.default_headers.setdefault("Content-Type", "application/json")
        self.default_body_params = kwargs

    async def generate(
        self, 
        messages: List[Message], 
        tools: List[Dict[str, Any]] | None = None,
        stream: bool = False,
        **kwargs
    ) -> Union[Message, AsyncGenerator[Message, None]]:
        
        # Prepare request payload
        payload = self._build_payload(messages, tools, stream, **kwargs)
        
        async with httpx.AsyncClient() as client:
            if stream:
                return self._stream_response(client, payload)
            else:
                response = await client.post(self.url, json=payload, headers=self.default_headers)
                response.raise_for_status()
                return self._parse_response(response.json())

    def _build_payload(self, messages: List[Message], tools: List[Dict[str, Any]] | None, stream: bool, **kwargs) -> Dict[str, Any]:
        """
        Builds the standard OpenAI-compatible JSON payload.
        Override this method for providers with different schemas.
        """
        formatted_messages = [msg.to_dict() for msg in messages]

        # Inject system prompt if defined
        if self.system_prompt:
            formatted_messages.insert(0, {"role": "system", "content": self.system_prompt})
        
        payload = {
            "model": self.model,
            "messages": formatted_messages,
            "stream": stream,
            **self.default_body_params,
            **kwargs
        }
        
        if tools:
            payload["tools"] = tools
            
        return payload

    def _parse_response(self, response_data: Dict[str, Any]) -> Message:
        """
        Parses a standard OpenAI-compatible response.
        Override this method for providers with different schemas.
        """
        # Handle cases where response might be different, but defaulting to OpenAI style
        try:
            choice = response_data["choices"][0]
            message_data = choice.get("message", {})
            
            content = message_data.get("content")
            role = message_data.get("role", "assistant")
            
            # TODO: Handle tool calls parsing if needed for generic http
            
            return Message(
                role=Role(role),
                content=content
            )
        except (KeyError, IndexError) as e:
            # Fallback for simple response bodies
            if "response" in response_data:
                 return Message(role=Role.ASSISTANT, content=response_data["response"])
            raise ValueError(f"Failed to parse response: {response_data}") from e

    async def _stream_response(self, client: httpx.AsyncClient, payload: Dict[str, Any]) -> AsyncGenerator[Message, None]:
        async with client.stream("POST", self.url, json=payload, headers=self.default_headers) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        data = json.loads(data_str)
                        delta = data["choices"][0]["delta"]
                        content = delta.get("content")
                        if content:
                            yield Message(role=Role.ASSISTANT, content=content)
                    except json.JSONDecodeError:
                        continue
                    except (KeyError, IndexError):
                         continue
