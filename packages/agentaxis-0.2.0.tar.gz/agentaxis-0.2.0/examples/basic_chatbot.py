from agentaxis import AgentService, AgentEntity, InMemoryMemory, AIEngine
from agentaxis.adapters.tools import ToolRegistry
import asyncio
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

async def main():
    api_key = os.getenv("OPENAI_API_KEY", "mock-key")
    if api_key == "mock-key":
        print("⚠️ Warning: Using mock key. Setup OPENAI_API_KEY for real usage.")

    # In a real scenario, we would need a real key. 
    # For this example to run without crashing if no key, we might need to handle it.
    # But standard usage implies providing the key.
    llm = AIEngine(
        model="gpt-3.5-turbo", 
        api_key=api_key,
        system_prompt="You are a helpful assistant talking like a pirate."
    )
    
    memory = InMemoryMemory()
    registry = ToolRegistry()
    
    # 2. Register Tools
    @registry.register
    def get_time() -> str:
        """Returns current time."""
        return "10:00 AM"

    # 3. Create Agent
    entity = AgentEntity(id="bot-1", name="Helper", role_description="Assistant")
    agent = AgentService(agent_entity=entity, llm=llm, memory=memory, tool_registry=registry)

    print("🤖 Chatbot initialized. Type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            break
        
        # We need to handle potential API errors gracefully in a real loop
        try:
            response = await agent.chat(user_input)
            print(f"Bot: {response}")
        except Exception as e:
            print(f"Bot Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())
