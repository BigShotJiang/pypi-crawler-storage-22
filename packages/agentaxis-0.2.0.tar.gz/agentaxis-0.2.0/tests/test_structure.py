import sys
import os
import asyncio

# Debug path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, ".."))
sys.path.insert(0, project_root)
print(f"DEBUG: Project Root added to path: {project_root}")
print(f"DEBUG: sys.path: {sys.path}")

# Import verify
try:
    import agentaxis
    print(f"✅ agentaxis package found: {agentaxis.__file__}")
except ImportError as e:
    print(f"❌ agentaxis package import failed: {e}")

try:
    from agentaxis.core.domain.message import Message, Role
    print("✅ Message imported")
    from agentaxis.adapters.llm.litellm_adapter import AIEngine
    print("✅ AIEngine imported")
except ImportError as e:
    print(f"❌ Detailed Import Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

async def main():
    print("✅ Core imports successful")
    
    # Test Message creation
    msg = Message(role=Role.USER, content="Hello")
    print(f"✅ Message created: {msg}")
    
    # Test Adapter Instantiation (Structural only, no API call yet)
    try:
        adapter = AIEngine(model="gpt-3.5-turbo")
        print(f"✅ Adapter instantiated: {adapter.model}")
    except Exception as e:
        print(f"❌ Adapter instantiation failed: {e}")
        
    print("\nPhase 2 Structural Verification Complete!")

if __name__ == "__main__":
    asyncio.run(main())
