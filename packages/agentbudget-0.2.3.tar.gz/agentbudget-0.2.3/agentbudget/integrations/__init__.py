"""Framework integrations for AgentBudget."""
