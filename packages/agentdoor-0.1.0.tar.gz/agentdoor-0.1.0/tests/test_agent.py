"""Tests for agentdoor.agent module."""

from __future__ import annotations

import json
import time
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from agentdoor.agent import Agent, AgentConfig
from agentdoor.credentials import Credential, InMemoryCredentialStore


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

DISCOVERY_DOC = {
    "agentdoor_version": "0.1",
    "service_name": "Test Service",
    "registration_endpoint": "/agentdoor/register",
    "verification_endpoint": "/agentdoor/register/verify",
    "auth_endpoint": "/agentdoor/auth",
    "scopes": [{"name": "read", "description": "Read access"}],
    "token_ttl_seconds": 3600,
}


def _make_response(status: int = 200, json_data: dict | None = None) -> httpx.Response:
    """Build a minimal httpx.Response for mocking."""
    resp = httpx.Response(
        status_code=status,
        json=json_data or {},
        request=httpx.Request("GET", "https://example.com"),
    )
    return resp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAgentInit:
    """Agent construction tests."""

    def test_defaults(self) -> None:
        agent = Agent()
        assert agent.base_url is None
        assert agent.discovery is None
        assert agent.credential is None
        assert agent.is_connected is False
        assert agent.is_registered is False

    def test_custom_config(self) -> None:
        store = InMemoryCredentialStore()
        cfg = AgentConfig(agent_name="custom", credential_store=store)
        agent = Agent(config=cfg)
        assert agent._config.agent_name == "custom"


class TestAgentConnect:
    """Tests for Agent.connect()."""

    @pytest.mark.asyncio
    async def test_connect_fetches_discovery(self) -> None:
        agent = Agent()
        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            doc = await agent.connect("https://example.com")

        assert doc.service_name == "Test Service"
        assert agent.is_connected is True
        assert agent.base_url == "https://example.com"

        # Cleanup
        await agent.close()

    @pytest.mark.asyncio
    async def test_connect_loads_cached_credential(self) -> None:
        store = InMemoryCredentialStore()
        cred = Credential(
            service_url="https://example.com",
            agent_id="agent-1",
            public_key="pub",
            secret_key="sec",
            api_key="key-123",
        )
        store.save(cred)

        agent = Agent(config=AgentConfig(credential_store=store))
        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            await agent.connect("https://example.com")

        assert agent.credential is not None
        assert agent.credential.api_key == "key-123"
        await agent.close()


class TestAgentRegister:
    """Tests for Agent.register()."""

    @pytest.mark.asyncio
    async def test_register_without_connect_raises(self) -> None:
        agent = Agent()
        with pytest.raises(RuntimeError, match="connect"):
            await agent.register(scopes=["read"])

    @pytest.mark.asyncio
    async def test_register_performs_challenge_flow(self) -> None:
        agent = Agent(config=AgentConfig(agent_name="test-agent"))

        # Mock connect
        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            await agent.connect("https://example.com")

        # Mock the registration HTTP calls
        reg_response = _make_response(200, {
            "challenge": "sign-this-challenge",
            "registration_id": "reg-abc",
        })
        verify_response = _make_response(200, {
            "api_key": "apikey-xyz",
            "agent_id": "agent-42",
        })

        assert agent._client is not None
        original_post = agent._client.post
        call_count = 0

        async def mock_post(url: str, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return reg_response
            return verify_response

        agent._client.post = mock_post  # type: ignore[assignment]

        cred = await agent.register(scopes=["read"])

        assert cred.api_key == "apikey-xyz"
        assert cred.agent_id == "agent-42"
        assert cred.scopes == ["read"]
        assert agent.is_registered is True
        assert call_count == 2

        await agent.close()


class TestAgentAuthenticate:
    """Tests for Agent.authenticate()."""

    @pytest.mark.asyncio
    async def test_authenticate_without_register_raises(self) -> None:
        agent = Agent()
        with pytest.raises(RuntimeError, match="register"):
            await agent.authenticate()

    @pytest.mark.asyncio
    async def test_authenticate_returns_token(self) -> None:
        agent = Agent(config=AgentConfig(agent_name="test-agent"))

        # Set up connected + registered state
        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            await agent.connect("https://example.com")

        from agentdoor.crypto import generate_keypair

        pub, sec = generate_keypair()
        agent._credential = Credential(
            service_url="https://example.com",
            agent_id="agent-42",
            public_key=pub,
            secret_key=sec,
            api_key="apikey-xyz",
        )

        auth_response = _make_response(200, {
            "token": "bearer-token-abc",
            "expires_in": 3600,
        })

        async def mock_post(url: str, **kwargs):
            return auth_response

        assert agent._client is not None
        agent._client.post = mock_post  # type: ignore[assignment]

        token = await agent.authenticate()
        assert token == "bearer-token-abc"
        assert agent._credential.token == "bearer-token-abc"
        assert agent._credential.token_expires_at is not None

        await agent.close()

    @pytest.mark.asyncio
    async def test_authenticate_uses_cached_token(self) -> None:
        agent = Agent(config=AgentConfig(agent_name="test-agent"))

        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            await agent.connect("https://example.com")

        from agentdoor.crypto import generate_keypair

        pub, sec = generate_keypair()
        agent._credential = Credential(
            service_url="https://example.com",
            agent_id="agent-42",
            public_key=pub,
            secret_key=sec,
            api_key="apikey-xyz",
            token="cached-token",
            token_expires_at=time.time() + 3600,
        )

        # Should not call the server at all
        token = await agent.authenticate()
        assert token == "cached-token"

        await agent.close()


class TestAgentRequest:
    """Tests for Agent.request()."""

    @pytest.mark.asyncio
    async def test_request_without_connect_raises(self) -> None:
        agent = Agent()
        with pytest.raises(RuntimeError, match="connect"):
            await agent.request("GET", "/data")

    @pytest.mark.asyncio
    async def test_request_attaches_bearer_token(self) -> None:
        agent = Agent(config=AgentConfig(agent_name="test-agent"))

        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            await agent.connect("https://example.com")

        from agentdoor.crypto import generate_keypair

        pub, sec = generate_keypair()
        agent._credential = Credential(
            service_url="https://example.com",
            agent_id="agent-42",
            public_key=pub,
            secret_key=sec,
            api_key="apikey-xyz",
            token="existing-token",
            token_expires_at=time.time() + 3600,
        )

        data_response = _make_response(200, {"result": "ok"})
        captured_headers: dict = {}

        async def mock_request(method: str, path: str, **kwargs):
            captured_headers.update(kwargs.get("headers", {}))
            return data_response

        assert agent._client is not None
        agent._client.request = mock_request  # type: ignore[assignment]

        resp = await agent.request("GET", "/data")
        assert resp.status_code == 200
        assert captured_headers["Authorization"] == "Bearer existing-token"

        await agent.close()

    @pytest.mark.asyncio
    async def test_request_retries_on_401(self) -> None:
        agent = Agent(config=AgentConfig(agent_name="test-agent"))

        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            await agent.connect("https://example.com")

        from agentdoor.crypto import generate_keypair

        pub, sec = generate_keypair()
        agent._credential = Credential(
            service_url="https://example.com",
            agent_id="agent-42",
            public_key=pub,
            secret_key=sec,
            api_key="apikey-xyz",
            token="stale-token",
            token_expires_at=time.time() + 3600,
        )

        # First request returns 401, second returns 200 after token refresh
        call_count = 0

        async def mock_request(method: str, path: str, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return _make_response(401, {"error": "expired"})
            return _make_response(200, {"result": "ok"})

        # Mock authenticate to return a fresh token after invalidation
        auth_response = _make_response(200, {
            "token": "fresh-token",
            "expires_in": 3600,
        })

        async def mock_post(url: str, **kwargs):
            return auth_response

        assert agent._client is not None
        agent._client.request = mock_request  # type: ignore[assignment]
        agent._client.post = mock_post  # type: ignore[assignment]

        resp = await agent.request("GET", "/data")
        # Should have retried after 401 and gotten 200
        assert resp.status_code == 200
        assert call_count == 2

        await agent.close()


class TestAgentClose:
    """Tests for Agent.close()."""

    @pytest.mark.asyncio
    async def test_close_cleans_up_client(self) -> None:
        agent = Agent()

        with patch("agentdoor.agent.discover", new_callable=AsyncMock) as mock_discover:
            from agentdoor.discovery import parse_discovery_document

            mock_discover.return_value = parse_discovery_document(DISCOVERY_DOC)
            await agent.connect("https://example.com")

        assert agent._client is not None
        await agent.close()
        assert agent._client is None

    @pytest.mark.asyncio
    async def test_close_when_not_connected(self) -> None:
        agent = Agent()
        # Should not raise
        await agent.close()
