# AgentDSL - Formal Language Specification

**Version:** 0.0.1  
**Status:** Alpha / Experimental  
**Last Updated:** February 2026

---

## Table of Contents

1. [Introduction](#introduction)
2. [Lexical Elements](#lexical-elements)
3. [Syntax & Grammar](#syntax--grammar)
4. [Type System](#type-system)
5. [Message Structure](#message-structure)
6. [Protocol Blocks](#protocol-blocks)
7. [Relational Semantics](#relational-semantics)
8. [Parsing Rules](#parsing-rules)
9. [Error Handling](#error-handling)
10. [EBNF Grammar](#ebnf-grammar)

---

## Introduction

**AgentDSL** is a specialized Domain-Specific Language designed for efficient, token-optimized communication between agents and language models. Unlike JSON/XML, AgentDSL uses a delimiter-based syntax optimized for:

- **LLM Context Windows:** Reduced token overhead for data-dense payloads
- **Streaming Parsing:** Line-by-line processing capability
- **Relational Integrity:** First-class support for foreign key relationships
- **Type Safety:** Explicit type annotations on every field

### Design Philosophy

AgentDSL separates **schema definitions** from **data values**. This decoupling eliminates repetitive key names, similar to CSV files but with explicit typing and relational semantics.

**JSON (Verbose, Repetitive):**

```json
{
  "user": { "id": 1, "name": "Alice" },
  "post": { "id": 1, "user_id": 1, "title": "Hello" }
}
```

**AgentDSL (Compact, Streamable):**

```text
[SCHEMA:USER]
ID:int|NAME:str

[DATA]
1|Alice

[SCHEMA:POST]
ID:int|USER_ID:@USER.ID|TITLE:str

[DATA]
1|1|Hello
```

---

## Lexical Elements

### Character Set

AgentDSL uses **UTF-8** encoding exclusively.

```
ASCII printable: U+0020 to U+007E
Unicode support: Full UTF-8 range (U+0000 to U+10FFFF)
```

### Whitespace

- **Horizontal whitespace:** Space (U+0020), Tab (U+0009)
- **Vertical whitespace:** Line Feed (U+000A), Carriage Return (U+000D)
- **Significant whitespace:** Within `[...]` markers and values
- **Insignificant whitespace:** Trailing spaces on lines (conventionally stripped)

### Delimiters

| Symbol  | Name            | Usage                                     |
| ------- | --------------- | ----------------------------------------- |
| `[` `]` | Square brackets | Block markers, section identifiers        |
| `\|`    | Pipe            | Field delimiter                           |
| `:`     | Colon           | Field type separator, key-value delimiter |
| `_`     | Underscore      | Null/empty value placeholder              |
| `@`     | At symbol       | Relational reference prefix               |
| `,`     | Comma           | Multi-value separator                     |

### Keywords/Reserved Words

Block type keywords (case-sensitive):

```
SCHEMA    - Schema definition block
DATA      - Data row block
FUNCTIONS - Function definition block
CALL      - RPC invocation block
RESULT    - Result/response block
STATUS    - Status field
ERROR     - Error field
FunctionName - User-defined function identifiers
DESC      - Description field within functions
IN        - Input parameters
OUT       - Output fields
```

### Comments

**Not supported** in the core DSL. Comments must be handled by the application layer.

---

## Syntax & Grammar

### Whitespace Rules

1. **Around delimiters:** No whitespace allowed inside `|` separators
2. **Block headers:** Whitespace allowed inside brackets: `[ SCHEMA : LABEL ]`
3. **Line structure:** Values are trimmed of trailing whitespace
4. **Preservation:** Whitespace within quoted strings (future extension) is preserved

### Identifier Rules

Identifiers include: `[A-Za-z0-9_]`

**Constraints:**

- Must start with a letter or underscore
- No spaces or special characters except `_`
- Case-sensitive
- Length: 1-100 characters (practical limit 50 for readability)

**Examples:**

```
VALID:    USER_ID, user_123, _internal, TABLE1
INVALID:  user-id, 123user, user id, @user, user.id
```

### Type Annotations

Type annotations appear after field names, separated by `:`.

```
[SCHEMA:USER]
ID:int|NAME:str|AGE:int|ACTIVE:bool
```

**Format:** `FIELDNAME:TYPE` or `@FOREIGNSCHEMA.FIELD:TYPE` (for references)

---

## Type System

### Atomic Types

#### `int` - Signed 64-bit Integer

- **Range:** -2⁶³ to 2⁶³-1 (-9,223,372,036,854,775,808 to 9,223,372,036,854,775,807)
- **Encoding:** Decimal notation, no leading zeros except "0"
- **Examples:** `1`, `-42`, `1000000000`, `0`

#### `float` - IEEE 754 Double Precision

- **Range:** ±5.0 × 10⁻³²⁴ to ±1.7 × 10³⁰⁸
- **Precision:** ~15-17 decimal digits
- **Notation:** Decimal with optional `e`/`E` exponent, decimal point required
- **Examples:** `3.14`, `1.0`, `-2.5e10`, `0.0`, `Infinity`, `-Infinity`, `NaN`

#### `str` - UTF-8 String

- **Encoding:** UTF-8
- **Length:** 0 to 2,147,483,647 characters (practical: ~10MB)
- **Escaping:** Pipe characters (`|`) must be escaped or the value placed in `any` type
- **Examples:** `"Hello World"`, `""`, `User_123`, `abc|def` (invalid, use `any`)

#### `bool` - Boolean

- **Values:** `true` or `false` (lowercase)
- **Storage:** Represented as strings in DSL
- **Examples:** `true`, `false`

#### `any` - JSON-Serialized Value

- **Purpose:** Complex nested structures, arrays, objects
- **Encoding:** Valid JSON (RFC 7159)
- **Escaping:** Newlines, pipes, special characters encoded as JSON
- **Examples:**
  ```
  {"nested": {"key": "value"}}
  [1, 2, 3]
  "any string value"
  null
  ```

#### `Reference` - Relational Pointer

- **Prefix:** `@`
- **Format:** `@SCHEMA.FIELD:type`
- **Purpose:** Foreign key relationship to another schema
- **Semantics:** Value is an ID from the referenced schema
- **Example:** `@USER.ID:int` (references USER schema's ID field)

### Type Coercion & Validation

| From    | To      | Rule                                         |
| ------- | ------- | -------------------------------------------- |
| `str`   | `int`   | Parse as decimal; fail if non-numeric        |
| `str`   | `float` | Parse as IEEE754; fail if non-numeric        |
| `int`   | `float` | Lossless for ±2⁵³; automatic conversion      |
| `float` | `int`   | Truncate toward zero; precision loss warning |
| Any     | `str`   | Lossy for complex types; use `any`           |
| Any     | `any`   | Automatic JSON serialization allowed         |

---

## Message Structure

### Canonical Message Format

An AgentDSL message consists of zero or more **blocks** in sequence:

```
<Block 1>
<optional newlines>
<Block 2>
...
<Block N>
```

### Block Types

1. **Schema Definition Block** (`[SCHEMA:...]`)
2. **Data Block** (`[DATA]`)
3. **Functions Block** (`[FUNCTIONS]`)
4. **Call Block** (`[CALL]`)
5. **Result Block** (`[RESULT]`)

### Line-by-Line Parsing

Each block is structured for incremental parsing:

```
[SCHEMA:LABEL]              # Header (1 line)
FIELD:type|FIELD:type      # Field definitions (1 line)

[DATA]                      # Header (1 line)
value|value|value          # Data row (1+ lines)
value|value|value
...

[FUNCTIONS]                 # Header (1 line)
[FunctionName]             # Function header
DESC[What it does]         # Description
IN[param:type|...]         # Input spec
OUT[field:type|...]        # Output spec
```

---

## Protocol Blocks

### 1. Schema Definition Block

**Syntax:**

```
[SCHEMA:LABEL]
FIELD1:type|FIELD2:type|...|FIELDN:type
```

**Constraints:**

- **LABEL:** Unique schema identifier (case-sensitive, 1-100 chars)
- **First field:** Must be `ID:int` (primary key)
- **Field count:** 1-1,000 fields (practical: ≤500)
- **Duplicates:** Field names must be unique within schema
- **Single line:** All fields on one line, pipe-delimited

**Example:**

```
[SCHEMA:CUSTOMER]
ID:int|NAME:str|EMAIL:str|AGE:int|ACTIVE:bool
```

**Grammar:**

```
SchemaBlock = "[SCHEMA:" identifier "]" NEWLINE
              fieldList NEWLINE

fieldList = fieldDef ("|" fieldDef)*
fieldDef  = identifier ":" type

type = "int" | "float" | "str" | "bool" | "any" | reference
reference = "@" identifier "." identifier ":" type
```

### 2. Data Block

**Syntax:**

```
[DATA]
value|value|...|value
value|value|...|value
```

**Constraints:**

- **Row format:** Pipe-delimited values matching schema field order
- **ID field:** First value must be a unique integer (primary key)
- **Empty values:** Represented as `_` (underscore)
- **Multi-values:** Comma-separated values in a single field: `val1,val2,val3`
- **Newlines:** Values cannot contain literal newlines (use `any` type with JSON)
- **Type validation:** Values must parse to declared field types

**Example:**

```
[DATA]
1|Alice|alice@example.com|28|true
2|Bob|bob@example.com|_|false
3|Carol|_|35|true
```

**Grammar:**

```
DataBlock = "[DATA]" NEWLINE
            dataRow (NEWLINE dataRow)*

dataRow = value ("|" value)*
value   = "_" | multiValue | primitiveValue

multiValue = primitiveValue ("," primitiveValue)+
```

### 3. Functions Block

**Syntax:**

```
[FUNCTIONS]
[FunctionName1]
DESC[Description text]
IN[PARAM1:type*|PARAM2:type|...]
OUT[RESULT1:type|RESULT2:type|...]

[FunctionName2]
...
```

**Constraints:**

- **Function name:** Identifier format, case-sensitive
- **Uniqueness:** No duplicate function names in block
- **Required params:** Marked with `*` suffix
- **Description:** Mandatory, used for function discovery
- **Ordering:** Functions can appear in any order

**Example:**

```
[FUNCTIONS]
[SearchDocuments]
DESC[Search documentation repository]
IN[QUERY:str*|MAX_RESULTS:int|LANGUAGE:str]
OUT[ID:str|TITLE:str|URL:str|SCORE:float]

[GetWeather]
DESC[Get current weather for location]
IN[CITY:str*|UNITS:str]
OUT[TEMP:float|HUMIDITY:int|CONDITION:str]
```

**Grammar:**

```
FunctionsBlock = "[FUNCTIONS]" NEWLINE
                 functionDef (NEWLINE functionDef)*

functionDef = "[" identifier "]" NEWLINE
              "DESC[" text "]" NEWLINE
              "IN[" paramList "]" NEWLINE
              "OUT[" fieldList "]"

paramList = paramDef ("|" paramDef)*
paramDef  = identifier ":" type ("*")?
```

### 4. Call Block (RPC)

**Syntax:**

```
[CALL]
[FunctionName]
PARAM1:value
PARAM2:value
...
```

**Constraints:**

- **Function reference:** Must match a function declared in `[FUNCTIONS]`
- **Argument format:** `NAME:VALUE` pairs
- **Required args:** All params marked `*` must be present
- **Order:** Argument order is irrelevant
- **Type validation:** Values must match parameter types

**Example:**

```
[CALL]
[SearchDocuments]
QUERY:machine learning
MAX_RESULTS:10
LANGUAGE:en
```

**Grammar:**

```
CallBlock = "[CALL]" NEWLINE
            "[" identifier "]" NEWLINE
            argument (NEWLINE argument)*

argument = identifier ":" value
```

### 5. Result Block

**Syntax:**

```
[RESULT]
[FIELD1:type|FIELD2:type|...]
value|value|...
value|value|...
[STATUS:str]
SUCCESS|ERROR
[ERROR:str]
optional error message
```

**Constraints:**

- **Status values:** Exactly `SUCCESS` or `ERROR`
- **Error message:** Empty if status is `SUCCESS`; required descriptive text if `ERROR`
- **Data rows:** Follow same format as `[DATA]` block
- **Field order:** Values match declared field order
- **Multiple schemas:** For complex results, precede `[RESULT]` with relational `[SCHEMA]` blocks

**Example:**

```
[SCHEMA:METADATA]
ID:int|SOURCE:str|RELEVANCE:float

[DATA]
1|internal_kb|0.95
2|public_api|0.82

[RESULT]
[ID:str|TITLE:str|METADATA:@METADATA.ID]
doc_001|Getting Started|1
doc_002|API Reference|2
[STATUS:str]
SUCCESS
[ERROR:str]
```

**Error Result:**

```
[RESULT]
[ID:str|TITLE:str]

[STATUS:str]
ERROR
[ERROR:str]
Query timeout exceeded; try with fewer results
```

**Grammar:**

```
ResultBlock = relationalSchemas?
              "[RESULT]" NEWLINE
              fieldList NEWLINE
              dataRow (NEWLINE dataRow)*
              NEWLINE
              "[STATUS:str]" NEWLINE
              ("SUCCESS" | "ERROR") NEWLINE
              "[ERROR:str]" NEWLINE
              errorMessage?

relationalSchemas = (SchemaBlock NEWLINE DataBlock NEWLINE)+
```

---

## Relational Semantics

### Foreign Key References

References create relationships between schemas without nesting data.

**Definition:**

```
[SCHEMA:ORDER]
ID:int|CUSTOMER_ID:@CUSTOMER.ID|TOTAL:float

[SCHEMA:CUSTOMER]
ID:int|NAME:str
```

**Semantics:**

- `CUSTOMER_ID:@CUSTOMER.ID` declares a foreign key to CUSTOMER's ID field
- Value in `CUSTOMER_ID` column must exist in CUSTOMER's ID column
- Type of reference must match referenced field's type

### Resolution Algorithm

When reconstructing to JSON from DSL:

1. **Collect all schemas** and their data
2. **Build index** of each schema by ID
3. **Resolve references** by looking up IDs in referenced schema's index
4. **Nest objects** where `@` references exist
5. **Reconstruct hierarchy** maintaining referential integrity

**Example:**

**DSL:**

```
[SCHEMA:CUSTOMER]
ID:int|NAME:str

[DATA]
1|Alice
2|Bob

[SCHEMA:PURCHASE]
ID:int|CUSTOMER:@CUSTOMER.ID|AMOUNT:float

[DATA]
101|1|50.0
102|2|75.0
```

**Reconstructed JSON:**

```json
{
  "customers": [
    { "id": 1, "name": "Alice", "purchases": [{ "id": 101, "amount": 50.0 }] },
    { "id": 2, "name": "Bob", "purchases": [{ "id": 102, "amount": 75.0 }] }
  ]
}
```

### Limitations

- **No circular references:** A → B → C only; not A → B → A
- **No self-references:** A schema cannot reference itself (normalized form)
- **Implicit cardinality:** One-to-many detected by reference multiplicity

---

## Parsing Rules

### Tokenization

1. **Lines:** Split input by `\n` (LF) or `\r\n` (CRLF)
2. **Tokens:** Parse line content for markers (`[...]`), delimiters (`|`), values
3. **Whitespace:** Trim trailing whitespace; preserve internal spaces in values

### State Machine

```
START
  ├─ [SCHEMA:X] → SCHEMA_HEADER → SCHEMA_FIELDS → START
  ├─ [DATA]     → DATA_HEADER   → DATA_ROWS     → START
  ├─ [FUNCTIONS]→ FUNC_HEADER   → FUNCTION_DEFS → START
  ├─ [CALL]     → CALL_HEADER   → CALL_ARGS     → START
  ├─ [RESULT]   → RESULT_HEADER → RESULT_DATA   → STATUS → ERROR → START
  └─ EOF        → (valid end state)
```

### Error Recovery

**Parse errors halt processing.** Implementation must report:

1. **Line number** where error occurred
2. **Error type:** (syntax, type mismatch, constraint violation)
3. **Context:** The problematic line and column

### Type Parsing

Each type has specific parsing rules:

**`int`:** `-?[0-9]+` (decimal, no leading zeros except "0")
**`float`:** `-?[0-9]*\.[0-9]+([eE][+-]?[0-9]+)?` or `[Infinity|-Infinity|NaN]`
**`str`:** Any UTF-8 sequence except unescaped `|`
**`bool`:** Case-insensitive "true" or "false"
**`any`:** Valid JSON value (determined by JSON parser)

---

## Error Handling

### Syntax Errors

| Error                | Cause                               | Example                         |
| -------------------- | ----------------------------------- | ------------------------------- |
| Invalid block marker | Unrecognized `[...]` block          | `[INVALID:X]`                   |
| Missing ID field     | Schema doesn't start with `ID:int`  | `[SCHEMA:X`<br/>`NAME:str`      |
| Field count mismatch | Data row has wrong number of values | Schema: 3 fields, Row: 2 values |
| Duplicate field name | Field name repeated in schema       | `ID:int\|ID:str`                |
| Invalid type         | Unknown type annotation             | `NAME:integer`                  |

### Semantic Errors

| Error                      | Cause                                      | Example                                  |
| -------------------------- | ------------------------------------------ | ---------------------------------------- |
| Type mismatch              | Value incompatible with type               | `age:int` with value `"twenty"`          |
| Missing reference          | Foreign key references non-existent schema | `@UNKNOWN.ID:int`                        |
| Required parameter missing | RPC call missing required param            | Function requires `city*`, none provided |
| Duplicate schema           | Schema with same label defined twice       | Two `[SCHEMA:USER]` blocks               |

### Error Reporting Format

Implementation-specific, but should include:

```
[ERROR] <severity>: <message>
    at line <N>, column <M>
    in block: <BLOCK_TYPE>:<LABEL>
    context: <relevant_line>
                 ^
    suggestion: <fix_hint>
```

---

## EBNF Grammar

Complete formal grammar in Extended Backus-Naur Form (EBNF):

```ebnf
(* Main structure *)
Message = Block*
Block = SchemaBlock | DataBlock | FunctionsBlock | CallBlock | ResultBlock

(* Schema Block *)
SchemaBlock = "[SCHEMA:" Identifier "]" NEWLINE FieldList NEWLINE
FieldList = FieldDef ("|" FieldDef)*
FieldDef = Identifier ":" Type
Type = "int" | "float" | "str" | "bool" | "any" | Reference
Reference = "@" Identifier "." Identifier ":" Type

(* Data Block *)
DataBlock = "[DATA]" NEWLINE DataRow (NEWLINE DataRow)*
DataRow = Value ("|" Value)*
Value = "_" | MultiValue | PrimitiveValue
MultiValue = PrimitiveValue ("," PrimitiveValue)+
PrimitiveValue = IntLiteral | FloatLiteral | StringLiteral | BoolLiteral | JsonValue

(* Functions Block *)
FunctionsBlock = "[FUNCTIONS]" NEWLINE FunctionDef (NEWLINE FunctionDef)*
FunctionDef = "[" Identifier "]" NEWLINE
              "DESC[" Text "]" NEWLINE
              "IN[" ParamList "]" NEWLINE
              "OUT[" FieldList "]"
ParamList = ParamDef ("|" ParamDef)*
ParamDef = Identifier ":" Type ("*")?

(* Call Block *)
CallBlock = "[CALL]" NEWLINE "[" Identifier "]" NEWLINE Argument (NEWLINE Argument)*
Argument = Identifier ":" Value

(* Result Block *)
ResultBlock = RelationalSchemas? "[RESULT]" NEWLINE
              FieldList NEWLINE
              DataRow (NEWLINE DataRow)*
              NEWLINE
              "[STATUS:str]" NEWLINE StatusValue NEWLINE
              "[ERROR:str]" NEWLINE ErrorMessage?
RelationalSchemas = (SchemaBlock NEWLINE DataBlock NEWLINE)+
StatusValue = "SUCCESS" | "ERROR"
ErrorMessage = StringLiteral

(* Terminals *)
Identifier = [a-zA-Z_][a-zA-Z0-9_]*
IntLiteral = "-"? [0-9]+
FloatLiteral = "-"? [0-9]* "." [0-9]+ ([eE][+-]? [0-9]+)?
           | "Infinity" | "-Infinity" | "NaN"
StringLiteral = [a-zA-Z0-9_\-. ]+  (* simplified; full UTF-8 allowed *)
BoolLiteral = "true" | "false"
JsonValue = (* RFC 7159 JSON *)
Text = [^]]+ (* any text except closing bracket *)
NEWLINE = "\n" | "\r\n"
```

---

## Validation Rules

### Schema Validation

- [x] Label is unique within message
- [x] ID field is first field
- [x] ID type is `int`
- [x] All field names are unique
- [x] All type annotations are valid
- [x] References point to existing schemas

### Data Validation

- [x] Row has correct number of fields
- [x] ID value is unique within dataset
- [x] ID value is positive integer
- [x] Each value parses to declared type
- [x] Foreign key values exist in referenced schema

### Function Validation

- [x] Function name is unique
- [x] All required parameters documented
- [x] Output fields have distinct names

### Call Validation

- [x] Function reference exists
- [x] All required parameters provided
- [x] Argument values parse to parameter types

### Result Validation

- [x] Status is `SUCCESS` or `ERROR`
- [x] If `ERROR`, error message is non-empty
- [x] Data rows match declared field count and types
- [x] If relational, referenced schemas exist and are self-consistent

---

## Performance Characteristics

### Space Complexity

| Operation                | Complexity | Notes                      |
| ------------------------ | ---------- | -------------------------- |
| Parse DSL to AST         | O(n)       | Linear in input size       |
| Serialize AST to DSL     | O(n)       | Linear in record count     |
| Store schema definitions | O(s × f)   | s=schemas, f=fields/schema |
| Store data               | O(r × f)   | r=records, f=fields        |

### Time Complexity

| Operation           | Complexity | Notes                            |
| ------------------- | ---------- | -------------------------------- |
| Parse single line   | O(f)       | f=fields per line                |
| Tokenize input      | O(n)       | n=input characters               |
| Validate types      | O(r × f)   | r=records, f=fields              |
| Resolve references  | O(r × m)   | r=records, m=max reference depth |
| JSON reconstruction | O(r × d)   | d=nesting depth                  |

### Example Performance

```
Input:  1000 records × 20 fields = 20,000 values
Parse:  ~1-5ms (single-threaded)
JSON reconstruct (4-level nesting): ~50-200ms
```

---

## Versioning & Stability

### Version Format

`MAJOR.MINOR.PATCH-prerelease` (SemVer 2.0.0)

**Current:** `0.0.1a0` (Alpha)

### Stability Guarantees

- **α (Alpha):** No stability guarantees. All features experimental.
- **β (Beta):** Core features stable; metadata/extensions may change.
- **1.0.0:** Stable release; protocol changes require new major version.

### Migration Guide

For forward compatibility when schema changes:

1. **Version field:** Include schema version in data

   ```
   [SCHEMA:DATA_V1]
   VERSION:int|ID:int|PAYLOAD:any
   ```

2. **Wrapper pattern:** Wrap data with metadata

   ```
   [RESULT]
   [VERSION:int|DATA_BLOCK:any]
   1|{"original": "nested_data"}
   ```

3. **Explicit updates:** Document breaking changes prominently

---

## References & Extensions

### Related Standards

- **RFC 3629:** UTF-8 encoding specification
- **RFC 7159:** JSON specification
- **ISO/IEC 10646:** Unicode standard
- **IEEE 754:** Floating-point arithmetic

### Reserved Keywords (Future Use)

```
ENUM, STRUCT, UNION, IMPORT, EXPORT, DEFAULT, CONSTRAINT,
INDEX, PRIMARY, FOREIGN, UNIQUE, NULL, NOT, AND, OR
```

Do not use these in user schemas.

---

## Appendix: Examples

### Example 1: Simple User Directory

```
[SCHEMA:USERS]
ID:int|USERNAME:str|EMAIL:str|ROLE:str

[DATA]
1|alice|alice@example.com|admin
2|bob|bob@example.com|user
3|carol|carol@example.com|user
```

### Example 2: One-to-Many Relationship (Orders)

```
[SCHEMA:CUSTOMER]
ID:int|NAME:str|EMAIL:str

[DATA]
1|Acme Corp|contact@acme.com
2|GlobalTech|support@globaltech.com

[SCHEMA:ORDER]
ID:int|CUSTOMER:@CUSTOMER.ID|ORDER_NUM:str|TOTAL:float

[DATA]
1|1|ORD-001|5000.00
2|1|ORD-002|3200.00
3|2|ORD-003|1500.00
```

### Example 3: Multi-Level Hierarchy (Decomposed)

```
[SCHEMA:DEPARTMENT]
ID:int|NAME:str|BUDGET:float

[DATA]
1|Engineering|500000
2|Marketing|200000

[SCHEMA:TEAM]
ID:int|DEPARTMENT:@DEPARTMENT.ID|NAME:str|LEAD:str

[DATA]
1|1|Backend|alice
2|1|Frontend|bob
3|2|Growth|carol

[SCHEMA:MEMBER]
ID:int|TEAM:@TEAM.ID|NAME:str|ROLE:str

[DATA]
1|1|David|Engineer
2|1|Eve|Engineer
3|2|Frank|Designer
4|3|Grace|Analyst
```

### Example 4: Tool Discovery & RPC

```
[FUNCTIONS]
[SearchDocuments]
DESC[Search knowledge base]
IN[QUERY:str*|LIMIT:int|OFFSET:int]
OUT[ID:str|TITLE:str|URL:str|SCORE:float]

[GetWeather]
DESC[Get current weather]
IN[LOCATION:str*|UNITS:str]
OUT[TEMP:float|HUMIDITY:int|CONDITION:str]

[CALL]
[SearchDocuments]
QUERY:machine learning
LIMIT:5

[RESULT]
[ID:str|TITLE:str|URL:str|SCORE:float]
doc_001|ML Basics|/ml/basics|0.95
doc_002|Deep Learning|/ml/dl|0.87
[STATUS:str]
SUCCESS
[ERROR:str]
```

### Example 5: Error Response

```
[RESULT]
[TEMP:float|HUMIDITY:int|CONDITION:str]

[STATUS:str]
ERROR
[ERROR:str]
Location "Unknown City" not found. Did you mean "New York"?
```

---

**End of Specification**

For questions, issues, or feature requests, please refer to the AgentDSL repository or documentation at [github.com/user/agentdsl](https://github.com).
