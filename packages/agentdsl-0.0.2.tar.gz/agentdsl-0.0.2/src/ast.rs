// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum DslType {
    Int,
    Str,
    Float,
    Any,
    Reference(String, String), // Schema, Field
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SchemaField {
    pub name: String,
    pub field_type: DslType,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SchemaBlock {
    pub id: i32, // Assuming ID is always present as per spec
    pub label: String,
    pub fields: Vec<SchemaField>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DataBlock {
    pub schema_label: Option<String>, // Optional, inferred from context if streaming
    pub records: Vec<Vec<String>>,    // Raw values, to be typed by Schema
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct FunctionParam {
    pub name: String,
    pub param_type: DslType,
    pub required: bool,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct FunctionDef {
    pub name: String,
    pub description: String,
    pub inputs: Vec<FunctionParam>,
    pub outputs: Vec<FunctionParam>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct FunctionsBlock {
    pub functions: Vec<FunctionDef>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CallBlock {
    pub function_name: String,
    pub arguments: Vec<(String, String)>, // Key-Value pairs
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum ResultStatus {
    Success,
    Error,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResultBlock {
    pub output_schema: Vec<FunctionParam>, // Re-using FunctionParam for typed headers
    pub records: Vec<Vec<String>>,
    pub status: ResultStatus,
    pub error_message: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum AgentMessage {
    Schema(SchemaBlock),
    Data(DataBlock),
    Functions(FunctionsBlock),
    Call(CallBlock),
    Result(ResultBlock),
}
