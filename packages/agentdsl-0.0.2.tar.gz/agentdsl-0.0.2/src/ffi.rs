// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas

use crate::parser;
use std::ffi::{CStr, CString};
use std::os::raw::c_char;

#[no_mangle]
pub unsafe extern "C" fn agentdsl_parse(input: *const c_char) -> *mut c_char {
    if input.is_null() {
        return std::ptr::null_mut();
    }

    let c_str = CStr::from_ptr(input);
    let input_str = match c_str.to_str() {
        Ok(s) => s,
        Err(_) => return std::ptr::null_mut(),
    };

    match parser::parse(input_str) {
        Ok(msg) => {
            let json = match serde_json::to_string(&msg) {
                Ok(j) => j,
                Err(_) => return std::ptr::null_mut(),
            };
            CString::new(json).unwrap().into_raw()
        }
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub unsafe extern "C" fn agentdsl_serialize(json_input: *const c_char) -> *mut c_char {
    if json_input.is_null() {
        return std::ptr::null_mut();
    }

    let c_str = CStr::from_ptr(json_input);
    let json_str = match c_str.to_str() {
        Ok(s) => s,
        Err(_) => return std::ptr::null_mut(),
    };

    let msg: crate::ast::AgentMessage = match serde_json::from_str(json_str) {
        Ok(m) => m,
        Err(_) => return std::ptr::null_mut(),
    };

    let dsl = crate::serializer::serialize(&msg);
    CString::new(dsl).unwrap().into_raw()
}

#[no_mangle]
pub unsafe extern "C" fn agentdsl_to_json(input: *const c_char) -> *mut c_char {
    if input.is_null() {
        return std::ptr::null_mut();
    }

    let c_str = CStr::from_ptr(input);
    let input_str = match c_str.to_str() {
        Ok(s) => s,
        Err(_) => return std::ptr::null_mut(),
    };

    match parser::parse(input_str) {
        Ok(messages) => {
            let json = crate::json::to_json(&messages);
            CString::new(json.to_string()).unwrap().into_raw()
        }
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub unsafe extern "C" fn agentdsl_from_json(json_input: *const c_char) -> *mut c_char {
    if json_input.is_null() {
        return std::ptr::null_mut();
    }

    let c_str = CStr::from_ptr(json_input);
    let json_str = match c_str.to_str() {
        Ok(s) => s,
        Err(_) => return std::ptr::null_mut(),
    };

    let json_val: serde_json::Value = match serde_json::from_str(json_str) {
        Ok(v) => v,
        Err(_) => return std::ptr::null_mut(),
    };

    match crate::json::from_json(&json_val) {
        Ok(messages) => {
            let mut output = String::new();
            for msg in messages {
                output.push_str(&crate::serializer::serialize(&msg));
                output.push('\n');
            }
            CString::new(output).unwrap().into_raw()
        }
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub unsafe extern "C" fn agentdsl_free_string(ptr: *mut c_char) {
    if !ptr.is_null() {
        let _ = CString::from_raw(ptr);
    }
}