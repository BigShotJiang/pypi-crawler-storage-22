// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas

use crate::ast::*;
use serde_json::{json, Map, Value};
use std::collections::HashMap;

pub fn to_json(messages: &[AgentMessage]) -> Value {
    let mut schemas: HashMap<String, SchemaBlock> = HashMap::new();
    let mut data_map: HashMap<String, Vec<Vec<String>>> = HashMap::new();
    let mut functions = Vec::new();
    let mut calls = Vec::new();
    let mut results = Vec::new();

    for msg in messages {
        match msg {
            AgentMessage::Schema(s) => {
                schemas.insert(s.label.clone(), s.clone());
            }
            AgentMessage::Data(d) => {
                if let Some(label) = &d.schema_label {
                    data_map.entry(label.clone()).or_default().extend(d.records.clone());
                }
            }
            AgentMessage::Functions(f) => {
                for func in &f.functions {
                    functions.push(func.clone());
                }
            }
            AgentMessage::Call(c) => {
                calls.push(c.clone());
            }
            AgentMessage::Result(r) => {
                results.push(r.clone());
            }
        }
    }

    let mut output = Map::new();

    let mut back_refs: HashMap<String, Vec<String>> = HashMap::new();
    for schema in schemas.values() {
        for field in &schema.fields {
            if field.name.starts_with('@') {
                let parts: Vec<&str> = field.name[1..].split('.').collect();
                if !parts.is_empty() {
                    back_refs.entry(parts[0].to_string()).or_default().push(schema.label.clone());
                }
            }
        }
    }

    fn parse_value_string(s: &str) -> Value {
        if let Ok(v) = serde_json::from_str::<Value>(s) {
            v
        } else {
            json!(s)
        }
    }

    fn resolve_record(
        schema_label: &str,
        record: &[String],
        schemas: &HashMap<String, SchemaBlock>,
        data_map: &HashMap<String, Vec<Vec<String>>>,
        back_refs: &HashMap<String, Vec<String>>,
    ) -> Value {
        let schema = match schemas.get(schema_label) {
            Some(s) => s,
            None => return Value::Null,
        };

        let mut obj = Map::new();
        let record_id = if !record.is_empty() { &record[0] } else { "" };

        

        for (i, field) in schema.fields.iter().enumerate() {
            if i >= record.len() {
                break;
            }
            let val_str = &record[i];

            if field.name.starts_with('@') {
                obj.insert(field.name.clone(), parse_value_string(val_str));
                continue;
            }

            match &field.field_type {
                DslType::Reference(ref_schema, _) => {
                    if let Some(ref_data) = data_map.get(ref_schema) {
                        if let Some(ref_record) = ref_data.iter().find(|r| !r.is_empty() && &r[0] == val_str) {
                            obj.insert(
                                field.name.clone(),
                                resolve_record(ref_schema, ref_record, schemas, data_map, back_refs),
                            );
                            continue;
                        }
                    }
                    obj.insert(field.name.clone(), parse_value_string(val_str));
                }
                DslType::Int => {
                    if let Ok(i_val) = val_str.parse::<i64>() { obj.insert(field.name.clone(), json!(i_val)); }
                    else { obj.insert(field.name.clone(), parse_value_string(val_str)); }
                }
                DslType::Float => {
                    if let Ok(f_val) = val_str.parse::<f64>() { obj.insert(field.name.clone(), json!(f_val)); }
                    else { obj.insert(field.name.clone(), parse_value_string(val_str)); }
                }
                _ => {
                    obj.insert(field.name.clone(), parse_value_string(val_str));
                }
            }
        }

        // Handle back-references (Parent pulls Children)
        if let Some(children_labels) = back_refs.get(schema_label) {
            for child_label in children_labels {
                if let Some(child_data) = data_map.get(child_label) {
                    let child_schema = schemas.get(child_label).unwrap();
                    // Find the field index that points back to us
                    let back_ref_field_idx = child_schema.fields.iter().position(|f| {
                        f.name.starts_with('@') && f.name.contains(&format!("{}.", schema_label))
                    });

                    if let Some(idx) = back_ref_field_idx {
                        let matches: Vec<Value> = child_data.iter()
                            .filter(|r| r.len() > idx && r[idx] == record_id)
                            .map(|r| resolve_record(child_label, r, schemas, data_map, back_refs))
                            .collect();
                        
                        if !matches.is_empty() {
                            obj.insert(child_label.clone(), Value::Array(matches));
                        }
                    }
                }
            }
        }

        Value::Object(obj)
    }

    if !data_map.is_empty() {
        let mut data_out = Map::new();
        for (label, records) in &data_map {
            let has_back_ref = schemas.get(label).map(|s| s.fields.iter().any(|f| f.name.starts_with('@'))).unwrap_or(false);
            let is_referenced = schemas.values().any(|s| s.fields.iter().any(|f| match &f.field_type {
                DslType::Reference(ref_s, _) => ref_s == label,
                _ => false,
            }));

            if has_back_ref || is_referenced { continue; }

            let list: Vec<Value> = records
                .iter()
                .map(|r| resolve_record(label, r, &schemas, &data_map, &back_refs))
                .collect();
            data_out.insert(label.clone(), Value::Array(list));
        }
        for (k, v) in data_out {
             output.insert(k, v);
        }
    }

    if !functions.is_empty() {
        let mut funcs_json = Vec::new();
        for f in functions {
            let mut f_obj = Map::new();
            f_obj.insert("name".to_string(), json!(f.name));
            f_obj.insert("description".to_string(), json!(f.description));

            let mut inputs = Map::new();
            for p in f.inputs {
                let mut p_obj = Map::new();
                p_obj.insert("type".to_string(), json!(p.param_type.to_string()));
                p_obj.insert("required".to_string(), json!(p.required));
                inputs.insert(p.name, Value::Object(p_obj));
            }
            f_obj.insert("inputs".to_string(), Value::Object(inputs));

            let mut outputs = Map::new();
            for p in f.outputs {
                outputs.insert(p.name, json!(p.param_type.to_string()));
            }
            f_obj.insert("outputs".to_string(), Value::Object(outputs));

            funcs_json.push(Value::Object(f_obj));
        }
        output.insert("functions".to_string(), Value::Array(funcs_json));
    }

    if let Some(c) = calls.last() {
        let mut c_obj = Map::new();
        c_obj.insert("function".to_string(), json!(c.function_name));
        let mut args = Map::new();
        for (k, v) in &c.arguments {
            args.insert(k.clone(), json!(v));
        }
        c_obj.insert("arguments".to_string(), Value::Object(args));
        output.insert("call".to_string(), Value::Object(c_obj));
    }

    if let Some(r) = results.last() {
        let mut r_obj = Map::new();
        let mut records = Vec::new();
        for rec in &r.records {
            let mut row_obj = Map::new();
            for (i, p) in r.output_schema.iter().enumerate() {
                if i < rec.len() {
                    let val_str = &rec[i];
                    
                    let ref_info = match &p.param_type {
                        DslType::Reference(s, _) => Some(s.clone()),
                        _ if p.name.starts_with('@') => {
                            let parts: Vec<&str> = p.name[1..].split('.').collect();
                            if !parts.is_empty() { Some(parts[0].to_string()) } else { None }
                        }
                        _ => None,
                    };

                    if let Some(ref_schema) = ref_info {
                        let key = if p.name.starts_with('@') { ref_schema.clone() } else { p.name.clone() };
                        if let Some(ref_data) = data_map.get(&ref_schema) {
                            if let Some(ref_record) = ref_data.iter().find(|r| !r.is_empty() && &r[0] == val_str) {
                                row_obj.insert(
                                    key,
                                    resolve_record(&ref_schema, ref_record, &schemas, &data_map, &back_refs),
                                );
                                continue;
                            }
                        }
                        row_obj.insert(key, parse_value_string(val_str));
                    } else {
                        match &p.param_type {
                            DslType::Int => {
                                if let Ok(iv) = val_str.parse::<i64>() { row_obj.insert(p.name.clone(), json!(iv)); }
                                else { row_obj.insert(p.name.clone(), parse_value_string(val_str)); }
                            }
                            DslType::Float => {
                                if let Ok(fv) = val_str.parse::<f64>() { row_obj.insert(p.name.clone(), json!(fv)); }
                                else { row_obj.insert(p.name.clone(), parse_value_string(val_str)); }
                            }
                            _ => { row_obj.insert(p.name.clone(), parse_value_string(val_str)); }
                        }
                    }
                }
            }
            records.push(Value::Object(row_obj));
        }
        r_obj.insert("data".to_string(), Value::Array(records));
        r_obj.insert("status".to_string(), json!(match r.status {
            ResultStatus::Success => "SUCCESS",
            ResultStatus::Error => "ERROR",
        }));
        r_obj.insert("error".to_string(), json!(r.error_message));
        output.insert("result".to_string(), Value::Object(r_obj));
    }

    Value::Object(output)
}

pub fn from_json(value: &Value) -> Result<Vec<AgentMessage>, String> {
    let mut messages = Vec::new();
    let mut discovered_schemas: HashMap<String, SchemaBlock> = HashMap::new();
    let mut next_ids: HashMap<String, i32> = HashMap::new();
    let mut data_map: HashMap<String, Vec<Vec<String>>> = HashMap::new();
    let mut label_order: Vec<String> = Vec::new();

    fn infer_type(v: &Value) -> DslType {
        match v {
            Value::Number(n) => if n.is_f64() { DslType::Float } else { DslType::Int },
            Value::Object(_) => DslType::Any,
            _ => DslType::Str,
        }
    }

    fn extract_nested_data(
        label: &str,
        obj: &Map<String, Value>,
        discovered_schemas: &mut HashMap<String, SchemaBlock>,
        data_map: &mut HashMap<String, Vec<Vec<String>>>,
        next_ids: &mut HashMap<String, i32>,
        label_order: &mut Vec<String>,
        preassigned_id: Option<String>,
        parent_ref: Option<(&str, &str)>,
    ) -> String {
        let id = if let Some(pid) = &preassigned_id {
            pid.parse::<i32>().unwrap_or(*next_ids.entry(label.to_string()).or_insert(1))
        } else {
            *next_ids.entry(label.to_string()).or_insert(1)
        };
        next_ids.insert(label.to_string(), id + 1);

        let mut fields = vec![SchemaField { name: "ID".to_string(), field_type: DslType::Int }];
        let mut row = vec![id.to_string()];

        if let Some((p_label, _)) = parent_ref {
            fields.push(SchemaField { 
                name: format!("@{}.ID", p_label), 
                field_type: DslType::Int 
            });
            row.push(parent_ref.unwrap().1.to_string());
        }

        for (k, v) in obj {
            if k == "ID" { continue; }
            let f_type = match v {
                Value::Object(inner_obj) => {
                    let child_id = extract_nested_data(k, inner_obj, discovered_schemas, data_map, next_ids, label_order, None, None);
                    let _ = child_id;
                    DslType::Reference(k.clone(), "ID".to_string())
                }
                Value::Array(arr) if !arr.is_empty() && arr[0].is_object() => {
                    DslType::Reference(k.clone(), "ID".to_string())
                }
                _ => infer_type(v),
            };

            fields.push(SchemaField { name: k.clone(), field_type: f_type });
            row.push(match v {
                Value::Object(_) => next_ids.get(k).map(|i| (i-1).to_string()).unwrap_or("1".to_string()),
                Value::Array(arr) if !arr.is_empty() && arr[0].is_object() => {
                    // For arrays, use the ID that will be assigned to the first item
                    let arr_label = k;
                    let arr_id = *next_ids.entry(arr_label.to_string()).or_insert(1);
                    arr_id.to_string()
                }
                _ => v.as_str().unwrap_or(&v.to_string()).to_string(),
            });
        }

        if !discovered_schemas.contains_key(label) {
            let schema = SchemaBlock { id: 0, label: label.to_string(), fields };
            discovered_schemas.insert(label.to_string(), schema);
            label_order.push(label.to_string());
        }

        data_map.entry(label.to_string()).or_default().push(row);

        for (k, v) in obj {
            if let Value::Array(arr) = v {
                if !arr.is_empty() && arr[0].is_object() {
                    for item in arr {
                        if let Some(child_obj) = item.as_object() {
                            let _ = extract_nested_data(k, child_obj, discovered_schemas, data_map, next_ids, label_order, None, Some((label, &id.to_string())));
                        }
                    }
                }
            }
        }

        id.to_string()
    }

    fn flush_new_labels(
        messages: &mut Vec<AgentMessage>,
        discovered_schemas: &HashMap<String, SchemaBlock>,
        data_map: &HashMap<String, Vec<Vec<String>>>,
        label_order: &Vec<String>,
    ) {
        for label in label_order.iter() {
            if let Some(schema) = discovered_schemas.get(label) {
                messages.push(AgentMessage::Schema(schema.clone()));
            }
            if let Some(records) = data_map.get(label) {
                messages.push(AgentMessage::Data(DataBlock {
                    schema_label: Some(label.clone()),
                    records: records.clone(),
                }));
            }
        }
    }

    if let Some(obj) = value.as_object() {
        if let Some(c_val) = obj.get("call") {
             let func_name = c_val.get("function").and_then(|v| v.as_str()).unwrap_or("Unknown").to_string();
             let mut arguments = Vec::new();
             if let Some(args_obj) = c_val.get("arguments").and_then(|v| v.as_object()) {
                 for (k, v) in args_obj {
                     arguments.push((k.clone(), v.as_str().unwrap_or(&v.to_string()).to_string()));
                 }
             }
             messages.push(AgentMessage::Call(CallBlock { function_name: func_name, arguments }));
        } else if let Some(r_val) = obj.get("result") {
            let status = match r_val.get("status").and_then(|v| v.as_str()) {
                Some("ERROR") => ResultStatus::Error,
                _ => ResultStatus::Success,
            };
            let error_message = r_val.get("error").and_then(|v| v.as_str()).map(|s| s.to_string());
            
            let mut records = Vec::new();
            let mut output_schema = Vec::new();

            if let Some(arr) = r_val.get("data").and_then(|v| v.as_array()) {
                if !arr.is_empty() {
                    let first_obj = arr[0].as_object().unwrap();
                    for (k, v) in first_obj {
                        let f_type = match v {
                            Value::Object(inner) => {
                                let _ = extract_nested_data(k, inner, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                DslType::Reference(k.clone(), "ID".to_string())
                            }
                            Value::Array(arr) if !arr.is_empty() && arr[0].is_object() => {
                                DslType::Reference(k.clone(), "ID".to_string())
                            }
                            _ => infer_type(v),
                        };
                        output_schema.push(FunctionParam { name: k.clone(), param_type: f_type, required: false });
                    }

                    for item in arr {
                        let mut row = Vec::new();
                        if let Some(item_obj) = item.as_object() {
                            for param in &output_schema {
                                if let Some(val) = item_obj.get(&param.name) {
                                    if let Value::Object(inner) = val {
                                        let id_str = extract_nested_data(&param.name, inner, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                        row.push(id_str);
                                    } else if let Value::Array(arr) = val {
                                        if !arr.is_empty() && arr[0].is_object() {
                                            if let Some(first_obj) = arr[0].as_object() {
                                                let id_str = extract_nested_data(&param.name, first_obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                                row.push(id_str);
                                                for item in arr.iter().skip(1) {
                                                    if let Some(obj) = item.as_object() {
                                                        let _ = extract_nested_data(&param.name, obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                                    }
                                                }
                                            } else {
                                                row.push("".to_string());
                                            }
                                        } else {
                                            row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                                        }
                                    } else {
                                        row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                                    }
                                } else {
                                    row.push("".to_string());
                                }
                            }
                        }
                        records.push(row);
                    }
                }
            }

            messages.push(AgentMessage::Result(ResultBlock {
                output_schema,
                records,
                status,
                error_message,
            }));
        } else {
            for (k, v) in obj {
                // Handle the case where the value is an object mapping keys to arrays
                // e.g. { "timeseries": { "SYM-Z70": [ {...}, {...} ] } }
                let map_opt: Option<serde_json::Map<String, Value>> = if let Some(s) = v.as_str() {
                    serde_json::from_str::<Value>(s).ok().and_then(|pv| pv.as_object().cloned())
                } else {
                    v.as_object().cloned()
                };

                if let Some(map) = map_opt {
                    // For each inner key that is an array-of-objects, create a schema for that key
                    let mut handled_inner = false;
                    for (inner_k, inner_v) in map {
                        if let Some(inner_arr) = inner_v.as_array() {
                            if !inner_arr.is_empty() && inner_arr[0].is_object() {
                                handled_inner = true;

                                // Collect top-level scalar metadata (non-array, non-object) except the parent key `k`
                                let top_metadata: Vec<(String, Value)> = obj.iter()
                                    .filter(|(mk, mv)| mk != &k && !mv.is_array() && !mv.is_object())
                                    .map(|(mk, mv)| (mk.clone(), mv.clone()))
                                    .collect();

                                // If there is top-level metadata, create a parent schema and a single parent row
                                let parent_label_opt: Option<String> = if !top_metadata.is_empty() {
                                    let parent_label = format!("{}_parent", k);
                                    let mut parent_fields = vec![SchemaField { name: "ID".to_string(), field_type: DslType::Int }];
                                    for (name, val) in &top_metadata {
                                        let f_type = infer_type(val);
                                        parent_fields.push(SchemaField { name: name.clone(), field_type: f_type });
                                    }
                                    if !discovered_schemas.contains_key(&parent_label) {
                                        let schema = SchemaBlock { id: 0, label: parent_label.clone(), fields: parent_fields.clone() };
                                        discovered_schemas.insert(parent_label.clone(), schema);
                                        label_order.push(parent_label.clone());
                                    }
                                    let id = *next_ids.entry(parent_label.clone()).or_insert(1);
                                    next_ids.insert(parent_label.clone(), id + 1);
                                    let mut parent_row = vec![id.to_string()];
                                    for (_, val) in &top_metadata {
                                        parent_row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                                    }
                                    data_map.entry(parent_label.clone()).or_default().push(parent_row);
                                    Some(parent_label)
                                } else { None };

                                let mut schema_fields = Vec::new();
                                let first_obj = inner_arr[0].as_object().unwrap();

                                schema_fields.push(SchemaField { name: "ID".to_string(), field_type: DslType::Int });
                                if let Some(pl) = &parent_label_opt {
                                    schema_fields.push(SchemaField { name: format!("@{}.ID", pl), field_type: DslType::Int });
                                }

                                for (fk, fv) in first_obj {
                                    if fk == "ID" { continue; }
                                    let f_type = match fv {
                                        Value::Object(inner) => {
                                            let _ = extract_nested_data(fk, inner, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                            DslType::Reference(fk.clone(), "ID".to_string())
                                        }
                                        Value::Array(child_arr) if !child_arr.is_empty() && child_arr[0].is_object() => {
                                            DslType::Reference(fk.clone(), "ID".to_string())
                                        }
                                        _ => infer_type(fv),
                                    };
                                    schema_fields.push(SchemaField { name: fk.clone(), field_type: f_type });
                                }

                                if !discovered_schemas.contains_key(&inner_k) {
                                    let schema = SchemaBlock { id: 0, label: inner_k.clone(), fields: schema_fields.clone() };
                                    discovered_schemas.insert(inner_k.clone(), schema);
                                    label_order.push(inner_k.clone());
                                }

                                for item in inner_arr {
                                    if let Some(item_obj) = item.as_object() {
                                        let mut row = Vec::new();
                                        let child_id = if let Some(id_val) = item_obj.get("ID") {
                                            id_val.as_str().unwrap_or(&id_val.to_string()).to_string()
                                        } else {
                                            let id = *next_ids.entry(inner_k.clone()).or_insert(1);
                                            next_ids.insert(inner_k.clone(), id + 1);
                                            id.to_string()
                                        };

                                        for field in &schema_fields {
                                            if let Some(val) = item_obj.get(&field.name) {
                                                if let Value::Object(inner) = val {
                                                    let id_str = extract_nested_data(&field.name, inner, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                                    row.push(id_str);
                                                } else if let Value::Array(arr) = val {
                                                    if !arr.is_empty() && arr[0].is_object() {
                                                        // Extract first object's ID for the reference
                                                        if let Some(first_obj) = arr[0].as_object() {
                                                            let id_str = extract_nested_data(&field.name, first_obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                                            row.push(id_str);
                                                            // Process remaining items in array
                                                            for item in arr.iter().skip(1) {
                                                                if let Some(obj) = item.as_object() {
                                                                    let _ = extract_nested_data(&field.name, obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                                                }
                                                            }
                                                        } else {
                                                            row.push("".to_string());
                                                        }
                                                    } else {
                                                        row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                                                    }
                                                } else {
                                                    row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                                                }
                                            } else if field.name == "ID" {
                                                row.push(child_id.clone());
                                            } else if let Some(pl) = &parent_label_opt {
                                                if field.name == format!("@{}.ID", pl) {
                                                    let pid = next_ids.get(pl).map(|i| (i-1).to_string()).unwrap_or("1".to_string());
                                                    row.push(pid);
                                                } else {
                                                    row.push("".to_string());
                                                }
                                            } else {
                                                row.push("".to_string());
                                            }
                                        }
                                        data_map.entry(inner_k.clone()).or_default().push(row.clone());

                                        for (fk, fv) in item_obj {
                                            if let Value::Array(child_arr) = fv {
                                                if !child_arr.is_empty() && child_arr[0].is_object() {
                                                    for child_item in child_arr {
                                                        if let Some(child_obj) = child_item.as_object() {
                                                            let _ = extract_nested_data(fk, child_obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, Some((inner_k.as_str(), &child_id)));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if handled_inner { continue; }
                }

                if let Some(arr) = v.as_array() {
                    if !arr.is_empty() && arr[0].is_object() {
                        // Collect top-level scalar metadata (non-array, non-object) except the array itself
                        let top_metadata: Vec<(String, Value)> = obj.iter()
                            .filter(|(mk, mv)| mk != &k && !mv.is_array() && !mv.is_object())
                            .map(|(mk, mv)| (mk.clone(), mv.clone()))
                            .collect();

                        // If there is top-level metadata, create a parent schema and a single parent row
                        let parent_label_opt: Option<String> = if !top_metadata.is_empty() {
                            let parent_label = format!("{}_parent", k);
                            let mut parent_fields = vec![SchemaField { name: "ID".to_string(), field_type: DslType::Int }];
                            for (name, val) in &top_metadata {
                                let f_type = infer_type(val);
                                parent_fields.push(SchemaField { name: name.clone(), field_type: f_type });
                            }
                            if !discovered_schemas.contains_key(&parent_label) {
                                let schema = SchemaBlock { id: 0, label: parent_label.clone(), fields: parent_fields.clone() };
                                discovered_schemas.insert(parent_label.clone(), schema);
                                label_order.push(parent_label.clone());
                            }
                            let id = *next_ids.entry(parent_label.clone()).or_insert(1);
                            next_ids.insert(parent_label.clone(), id + 1);
                            let mut parent_row = vec![id.to_string()];
                            for (_, val) in &top_metadata {
                                parent_row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                            }
                            data_map.entry(parent_label.clone()).or_default().push(parent_row);
                            Some(parent_label)
                        } else { None };

                        let mut schema_fields = Vec::new();
                        let first_obj = arr[0].as_object().unwrap();

                        schema_fields.push(SchemaField { name: "ID".to_string(), field_type: DslType::Int });
                        // If we created a parent, add a back-reference field to children
                        if let Some(pl) = &parent_label_opt {
                            schema_fields.push(SchemaField { name: format!("@{}.ID", pl), field_type: DslType::Int });
                        }

                        for (fk, fv) in first_obj {
                            if fk == "ID" { continue; }
                                let f_type = match fv {
                                Value::Object(inner) => {
                                    let _ = extract_nested_data(fk, inner, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                    DslType::Reference(fk.clone(), "ID".to_string())
                                }
                                Value::Array(child_arr) if !child_arr.is_empty() && child_arr[0].is_object() => {
                                    DslType::Reference(fk.clone(), "ID".to_string())
                                }
                                _ => infer_type(fv),
                            };
                            schema_fields.push(SchemaField { name: fk.clone(), field_type: f_type });
                        }

                        if !discovered_schemas.contains_key(k) {
                            let schema = SchemaBlock { id: 0, label: k.clone(), fields: schema_fields.clone() };
                            discovered_schemas.insert(k.clone(), schema);
                            label_order.push(k.clone());
                        }

                        for item in arr {
                            if let Some(item_obj) = item.as_object() {
                                let mut row = Vec::new();
                                let child_id = if let Some(id_val) = item_obj.get("ID") {
                                    id_val.as_str().unwrap_or(&id_val.to_string()).to_string()
                                } else {
                                    let id = *next_ids.entry(k.clone()).or_insert(1);
                                    next_ids.insert(k.clone(), id + 1);
                                    id.to_string()
                                };

                                for field in &schema_fields {
                                    if let Some(val) = item_obj.get(&field.name) {
                                        if let Value::Object(inner) = val {
                                            let id_str = extract_nested_data(&field.name, inner, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                            row.push(id_str);
                                        } else if let Value::Array(arr) = val {
                                            if !arr.is_empty() && arr[0].is_object() {
                                                // Extract first object's ID for the reference
                                                if let Some(first_obj) = arr[0].as_object() {
                                                    let id_str = extract_nested_data(&field.name, first_obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                                    row.push(id_str);
                                                    // Process remaining items in array
                                                    for item in arr.iter().skip(1) {
                                                        if let Some(obj) = item.as_object() {
                                                            let _ = extract_nested_data(&field.name, obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                                                        }
                                                    }
                                                } else {
                                                    row.push("".to_string());
                                                }
                                            } else {
                                                row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                                            }
                                        } else {
                                            row.push(val.as_str().unwrap_or(&val.to_string()).to_string());
                                        }
                                    } else if field.name == "ID" {
                                        row.push(child_id.clone());
                                    } else if let Some(pl) = &parent_label_opt {
                                        // parent back-ref field -> insert parent id
                                        if field.name == format!("@{}.ID", pl) {
                                            // Parent row was just created above; its id is next_ids[parent_label]-1
                                            let pid = next_ids.get(pl).map(|i| (i-1).to_string()).unwrap_or("1".to_string());
                                            row.push(pid);
                                        } else {
                                            row.push("".to_string());
                                        }
                                    } else {
                                        row.push("".to_string());
                                    }
                                }
                                // push parent row immediately so parent data is available before extracting children
                                data_map.entry(k.clone()).or_default().push(row.clone());

                                for (fk, fv) in item_obj {
                                    if let Value::Array(child_arr) = fv {
                                        if !child_arr.is_empty() && child_arr[0].is_object() {
                                            for child_item in child_arr {
                                                    if let Some(child_obj) = child_item.as_object() {
                                                        let _ = extract_nested_data(fk, child_obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, Some((k, &child_id)));
                                                    }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // If nothing was produced (no call/result/array-of-records branches matched),
    // try treating the top-level object as a single resource (use `kind` if present)
    // and extract nested data into discovered schemas so it gets flushed below.
    if messages.is_empty() {
        if let Some(obj) = value.as_object() {
            // Only treat as a top-level resource when it looks like a Kubernetes
            // resource (has both `apiVersion` and `kind`). This avoids treating
            // arbitrary JSON objects with incidental metadata as resources.
            let is_k8s = obj.get("apiVersion").is_some() && obj.get("kind").is_some();
            if is_k8s {
                let label = obj.get("kind").and_then(|v| v.as_str()).unwrap_or("root");
                // Prefer extracting from `spec` if available, since k8s resources
                // commonly carry user data there.
                if let Some(spec_obj) = obj.get("spec").and_then(|v| v.as_object()) {
                    let _ = extract_nested_data(label, spec_obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                } else {
                    let _ = extract_nested_data(label, obj, &mut discovered_schemas, &mut data_map, &mut next_ids, &mut label_order, None, None);
                }
            }
        }
    }

    // Flush any remaining discovered schemas/data in order
    flush_new_labels(&mut messages, &discovered_schemas, &data_map, &label_order);

    Ok(messages)
}
