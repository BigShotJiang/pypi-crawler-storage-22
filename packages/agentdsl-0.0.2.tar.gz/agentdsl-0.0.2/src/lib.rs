// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas

use pyo3::prelude::*;
use pythonize::{depythonize, pythonize};

pub mod ast;
pub mod parser;
pub mod serializer;
pub mod json;
pub mod ffi;

pub use ast::*;
pub use parser::*;
pub use serializer::*;
pub use json::*;

use pyo3::types::PyTuple;

#[pyfunction(name = "parse")]
fn py_parse<'py>(py: Python<'py>, input: String) -> PyResult<Bound<'py, PyAny>> {
    let result = parser::parse(&input).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    pythonize(py, &result).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
}

#[pyfunction(name = "serialize")]
fn py_serialize(input: Bound<'_, PyAny>) -> PyResult<String> {
    let agent_message: AgentMessage = depythonize(&input).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    Ok(serializer::serialize(&agent_message))
}

#[pyfunction(name = "to_json")]
fn py_to_json<'py>(py: Python<'py>, input: String) -> PyResult<Bound<'py, PyAny>> {
    let messages = parser::parse(&input).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    let json_val = json::to_json(&messages);
    pythonize(py, &json_val).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))
}

#[pyfunction(name = "from_json")]
fn py_from_json(input: Bound<'_, PyAny>) -> PyResult<String> {
    let json_val: serde_json::Value = depythonize(&input).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    let messages = json::from_json(&json_val).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    let mut output = String::new();
    for msg in messages {
        output.push_str(&serializer::serialize(&msg));
        output.push('\n');
    }
    Ok(output)
}


#[pyfunction]
fn tool<'py>(py: Python<'py>, func: Bound<'py, PyAny>) -> PyResult<Bound<'py, PyAny>> {
    let inspect = py.import("inspect")?;
    
    let name: String = func.getattr("__name__")?.extract()?;
    let doc: String = match func.getattr("__doc__") {
        Ok(d) if !d.is_none() => d.extract()?,
        _ => "No description provided".to_string(),
    };

    let sig = inspect.call_method1("signature", (&func,))?;
    let params = sig.getattr("parameters")?;
    let items = params.call_method0("items")?;

    let mut inputs = Vec::new();
    for item in items.try_iter()? {
        let item_tuple = item?.downcast_into::<PyTuple>()?;
        let p_name = item_tuple.get_item(0)?;
        let p_obj = item_tuple.get_item(1)?;
        
        let p_name_str: String = p_name.extract()?;
        let annotation = p_obj.getattr("annotation")?;
        
        let mut type_str = "any".to_string();
        if !annotation.is_none() {
            if let Ok(attr) = annotation.getattr("__name__") {
                type_str = attr.extract()?;
            }
        }

        let default = p_obj.getattr("default")?;
        let empty = inspect.getattr("_empty")?;
        let is_required = default.is(&empty);

        inputs.push(FunctionParam {
            name: p_name_str,
            param_type: match type_str.as_str() {
                "int" => DslType::Int,
                "str" => DslType::Str,
                "float" => DslType::Float,
                _ => DslType::Any,
            },
            required: is_required,
        });
    }

    // Return type
    let typing = py.import("typing")?;
    let type_hints = typing.call_method1("get_type_hints", (&func,))?;
    
    let mut outputs = Vec::new();
    let mut associated_schemas = Vec::new();

    fn process_type<'py>(py: Python<'py>, _name: &str, hint: &Bound<'py, PyAny>, typing: &Bound<'py, PyModule>, schemas: &mut Vec<SchemaBlock>) -> PyResult<DslType> {
        let mut target_type = hint.clone();
        
        // Handle List[T]
        let origin = typing.call_method1("get_origin", (hint,))?;
        if !origin.is_none() {
            let list_type = py.import("builtins")?.getattr("list")?;
            if origin.is(&list_type) {
                let args = typing.call_method1("get_args", (hint,))?;
                let args_tuple = args.downcast_into::<PyTuple>()?;
                if !args_tuple.is_empty() {
                    target_type = args_tuple.get_item(0)?;
                }
            }
        }

        if let Ok(ann) = target_type.getattr("__annotations__") {
            let type_name: String = target_type.getattr("__name__")?.extract()?;
            let mut fields = vec![SchemaField { name: "ID".to_string(), field_type: DslType::Int }];
            
            let ann_dict = ann.downcast_into::<pyo3::types::PyDict>()?;
            for (key, val) in ann_dict.iter() {
                let field_name: String = key.extract()?;
                let field_type = process_type(py, &field_name, &val, typing, schemas)?;
                fields.push(SchemaField { name: field_name, field_type });
            }
            
            schemas.push(SchemaBlock { id: 0, label: type_name.clone(), fields });
            Ok(DslType::Reference(type_name, "ID".to_string()))
        } else {
            let mut t_str = "any".to_string();
            if let Ok(attr) = target_type.getattr("__name__") {
                t_str = attr.extract()?;
            } else if let Ok(s_repr) = target_type.str() {
                t_str = s_repr.extract()?;
            }
            
            Ok(match t_str.as_str() {
                "int" => DslType::Int,
                "str" => DslType::Str,
                "float" => DslType::Float,
                _ => DslType::Any,
            })
        }
    }

    if let Ok(return_hint) = type_hints.get_item("return") {
        if !return_hint.is_none() {
            let mut target_type = return_hint.clone();
            let origin = typing.call_method1("get_origin", (&return_hint,))?;
            if !origin.is_none() {
                let list_type = py.import("builtins")?.getattr("list")?;
                if origin.is(&list_type) {
                    let args = typing.call_method1("get_args", (&return_hint,))?;
                    let args_tuple = args.downcast_into::<PyTuple>()?;
                    if !args_tuple.is_empty() {
                        target_type = args_tuple.get_item(0)?;
                    }
                }
            }

            if let Ok(ann) = target_type.getattr("__annotations__") {
                let ann_dict = ann.downcast_into::<pyo3::types::PyDict>()?;
                for (key, val) in ann_dict.iter() {
                    let field_name: String = key.extract()?;
                    let p_type = process_type(py, &field_name, &val, &typing, &mut associated_schemas)?;
                    outputs.push(FunctionParam { name: field_name, param_type: p_type, required: true });
                }
            } else {
                let d_type = process_type(py, "result", &target_type, &typing, &mut associated_schemas)?;
                outputs.push(FunctionParam { name: "result".to_string(), param_type: d_type, required: true });
            }
        }
    }

    let mut dsl_output = String::new();
    for schema in associated_schemas {
        dsl_output.push_str(&serializer::serialize(&AgentMessage::Schema(schema)));
        dsl_output.push('\n');
    }

    let func_def = FunctionDef {
        name: name.clone(),
        description: doc,
        inputs,
        outputs,
    };

    dsl_output.push_str(&serializer::serialize(&AgentMessage::Functions(FunctionsBlock { functions: vec![func_def] })));
    func.setattr("__agentdsl__", dsl_output)?;

    Ok(func)
}

fn extract_relational_internal(
    py: Python<'_>, 
    item: &Bound<'_, PyAny>, 
    schema_params: &[FunctionParam], 
    schemas: &[SchemaBlock],
    related_data: &mut std::collections::HashMap<String, Vec<Vec<String>>>,
    next_ids: &mut std::collections::HashMap<String, i32>
) -> PyResult<Vec<String>> {
    let mut row = Vec::new();
    
    if let Ok(dict) = item.downcast::<pyo3::types::PyDict>() {
        for param in schema_params {
            if let Some(val) = dict.get_item(&param.name)? {
                row.push(process_item_internal(py, &val, &param.param_type, schemas, related_data, next_ids)?);
            } else {
                row.push("".to_string());
            }
        }
    } else if item.is_none() {
         for _ in schema_params {
             row.push("".to_string());
         }
    } else {
        // Single value, map to first column
        row.push(process_item_internal(py, item, &schema_params[0].param_type, schemas, related_data, next_ids)?);
        while row.len() < schema_params.len() {
            row.push("".to_string());
        }
    }
    Ok(row)
}

fn process_item_internal(
    py: Python<'_>,
    val: &Bound<'_, PyAny>,
    p_type: &DslType,
    schemas: &[SchemaBlock],
    related_data: &mut std::collections::HashMap<String, Vec<Vec<String>>>,
    next_ids: &mut std::collections::HashMap<String, i32>
) -> PyResult<String> {
    let json = py.import("json")?;
    match p_type {
        DslType::Reference(s_label, _) => {
            let id = *next_ids.entry(s_label.clone()).or_insert(1);
            next_ids.insert(s_label.clone(), id + 1);
            
            let s_def = schemas.iter().find(|s| &s.label == s_label).ok_or_else(|| {
                PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Schema {} not found", s_label))
            })?;
            
            let mut child_row = vec![id.to_string()];
            let child_fields: Vec<FunctionParam> = s_def.fields.iter().skip(1).map(|f| FunctionParam {
                name: f.name.clone(),
                param_type: f.field_type.clone(),
                required: true,
            }).collect();
            
            let child_values = extract_relational_internal(py, val, &child_fields, schemas, related_data, next_ids)?;
            child_row.extend(child_values);
            
            related_data.entry(s_label.clone()).or_insert_with(Vec::new).push(child_row);
            Ok(id.to_string())
        }
        _ => {
            if val.downcast::<pyo3::types::PyDict>().is_ok() || val.downcast::<pyo3::types::PyList>().is_ok() {
                let json_str: String = json.call_method1("dumps", (val,))?.extract()?;
                Ok(json_str)
            } else {
                Ok(val.str()?.extract()?)
            }
        }
    }
}

#[pyfunction]
#[pyo3(signature = (func, value, status=None, error=None))]
fn serialize_result(py: Python<'_>, func: Bound<'_, PyAny>, value: Bound<'_, PyAny>, status: Option<String>, error: Option<String>) -> PyResult<String> {
    let dsl_def: String = func.getattr("__agentdsl__")?.extract()?;
    let messages = parser::parse(&dsl_def).map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
    
    let mut output_schema = Vec::new();
    let mut schemas = Vec::new();
    for msg in messages {
        match msg {
            AgentMessage::Functions(f) => {
                if let Some(first) = f.functions.first() {
                    output_schema = first.outputs.clone();
                }
            }
            AgentMessage::Schema(s) => {
                schemas.push(s);
            }
            _ => {}
        }
    }

    let mut related_data: std::collections::HashMap<String, Vec<Vec<String>>> = std::collections::HashMap::new();
    let mut next_ids: std::collections::HashMap<String, i32> = std::collections::HashMap::new();

    let mut records = Vec::new();
    if let Ok(list) = value.downcast::<pyo3::types::PyList>() {
        for item in list.iter() {
            records.push(extract_relational_internal(py, &item, &output_schema, &schemas, &mut related_data, &mut next_ids)?);
        }
    } else {
        records.push(extract_relational_internal(py, &value, &output_schema, &schemas, &mut related_data, &mut next_ids)?);
    }

    let mut final_dsl = String::new();
    for (label, rows) in related_data {
        if let Some(s_def) = schemas.iter().find(|s| s.label == label) {
            final_dsl.push_str(&serializer::serialize(&AgentMessage::Schema(s_def.clone())));
            final_dsl.push_str(&serializer::serialize(&AgentMessage::Data(DataBlock {
                schema_label: Some(label),
                records: rows,
            })));
            final_dsl.push('\n');
        }
    }

    let result_status = match status.as_deref() {
        Some("ERROR") => ResultStatus::Error,
        _ => ResultStatus::Success,
    };

    let result_block = ResultBlock {
        output_schema,
        records,
        status: result_status,
        error_message: error,
    };

    final_dsl.push_str(&serializer::serialize(&AgentMessage::Result(result_block)));
    Ok(final_dsl)
}

#[pymodule]
fn agentdsl(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(py_parse, m)?)?;
    m.add_function(wrap_pyfunction!(py_serialize, m)?)?;
    m.add_function(wrap_pyfunction!(py_to_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_from_json, m)?)?;
    m.add_function(wrap_pyfunction!(tool, m)?)?;
    m.add_function(wrap_pyfunction!(serialize_result, m)?)?;
    Ok(())
}
