// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas

use crate::ast::*;
use thiserror::Error;
use std::iter::Peekable;
use std::str::Lines;

#[derive(Error, Debug)]
pub enum ParseError {
    #[error("Invalid block header: {0}")]
    InvalidHeader(String),
    #[error("Unknown type: {0}")]
    UnknownType(String),
    #[error("Malformed line: {0}")]
    MalformedLine(String),
    #[error("Missing schema for data block")]
    MissingSchema,
    #[error("Schema mismatch: expected {expected} fields, found {found}")]
    SchemaMismatch { expected: usize, found: usize },
    #[error("Unexpected End of File")]
    UnexpectedEof,
}

pub struct Parser {
    current_schema: Option<SchemaBlock>,
}

impl Parser {
    pub fn new() -> Self {
        Self {
            current_schema: None,
        }
    }


    pub fn parse_internal(&mut self, input: &str) -> Result<Vec<AgentMessage>, ParseError> {

        let mut messages = Vec::new();
        let mut lines = input.lines().peekable();

        while let Some(line) = lines.peek() {
            let line = line.trim();
            if line.is_empty() {
                lines.next();
                continue;
            }

            if line.starts_with("[SCHEMA:") {
                let schema = self.parse_schema(&mut lines)?;
                self.current_schema = Some(schema.clone());
                messages.push(AgentMessage::Schema(schema));
            } else if line == "[DATA]" {
                let data = self.parse_data(&mut lines)?;
                messages.push(AgentMessage::Data(data));
            } else if line == "[FUNCTIONS]" {
                let functions = self.parse_functions(&mut lines)?;
                messages.push(AgentMessage::Functions(functions));
            } else if line == "[CALL]" {
                let call = self.parse_call(&mut lines)?;
                messages.push(AgentMessage::Call(call));
            } else if line == "[RESULT]" {
                let result = self.parse_result(&mut lines)?;
                messages.push(AgentMessage::Result(result));
            } else {
                 lines.next();
            }
        }

        Ok(messages)
    }

    fn parse_type(&self, type_str: &str) -> Result<DslType, ParseError> {
        match type_str.trim() {
            "int" => Ok(DslType::Int),
            "str" => Ok(DslType::Str),
            "float" => Ok(DslType::Float),
            "any" => Ok(DslType::Any),
            s if s.starts_with('*') => {
                 self.parse_type(&s[0..s.len()-1])
            }
            s if s.ends_with('*') => {
                self.parse_type(&s[0..s.len()-1])
            }
            s if s.starts_with('@') => {
                let parts: Vec<&str> = s[1..].split('.').collect();
                if parts.len() == 2 {
                    Ok(DslType::Reference(parts[0].to_string(), parts[1].to_string()))
                } else {
                    Err(ParseError::UnknownType(s.to_string()))
                }
            }
            _ => Err(ParseError::UnknownType(type_str.to_string())),
        }
    }

    fn parse_schema(&self, lines: &mut Peekable<Lines>) -> Result<SchemaBlock, ParseError> {
        let header = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
        let label = header
            .trim_start_matches("[SCHEMA:")
            .trim_end_matches(']')
            .to_string();

        let def_line = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
        if def_line.is_empty() {
             return Err(ParseError::MalformedLine("Empty definition line for SCHEMA".into()));
        }

        let parts: Vec<&str> = def_line.split('|').collect();
        let mut fields = Vec::new();

        for part in parts {
            let kv: Vec<&str> = part.split(':').collect();
            if kv.len() != 2 {
                return Err(ParseError::MalformedLine(format!("Invalid field definition: {}", part)));
            }
            let name = kv[0].to_string();
            let field_type = self.parse_type(kv[1])?;
            fields.push(SchemaField { name, field_type });
        }

        Ok(SchemaBlock {
            id: 0,
            label,
            fields,
        })
    }

    fn parse_data(&self, lines: &mut Peekable<Lines>) -> Result<DataBlock, ParseError> {
        lines.next(); // Consume [DATA] header

        let mut records = Vec::new();

        while let Some(line) = lines.peek() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('[') {
                break;
            }

            let values: Vec<String> = line.split('|').map(|s| {
                let s = s.trim();
                if s == "_" {
                    "".to_string()
                } else {
                    s.to_string()
                }
            }).collect();
            if let Some(schema) = &self.current_schema {
                if values.len() != schema.fields.len() {
                    return Err(ParseError::SchemaMismatch {
                        expected: schema.fields.len(),
                        found: values.len(),
                    });
                }
            }
            records.push(values);
            lines.next();
        }

        Ok(DataBlock {
            schema_label: self.current_schema.as_ref().map(|s| s.label.clone()),
            records,
        })
    }

    fn parse_parameter_list(&self, content: &str) -> Result<Vec<FunctionParam>, ParseError> {
         let content = content.trim_start_matches("IN[").trim_start_matches("OUT[").trim_end_matches(']');
         if content.is_empty() {
             return Ok(vec![]);
         }
         
         let parts: Vec<&str> = content.split('|').collect();
         let mut params = Vec::new();

         for part in parts {
            let kv: Vec<&str> = part.split(':').collect();
             if kv.len() != 2 {
                return Err(ParseError::MalformedLine(format!("Invalid parameter definition: {}", part)));
            }
            let name = kv[0].to_string();
            let type_str = kv[1];
            let required = type_str.ends_with('*');
            let type_clean = type_str.trim_end_matches('*');
            let param_type = self.parse_type(type_clean)?;
            
            params.push(FunctionParam { name, param_type, required });
         }
         Ok(params)
    }

    fn parse_functions(&self, lines: &mut Peekable<Lines>) -> Result<FunctionsBlock, ParseError> {
        lines.next();

        let mut functions = Vec::new();

        while let Some(line) = lines.peek() {
            let line = line.trim();
            if line.is_empty() {
                lines.next();
                continue;
            }
            if line.starts_with("[FUNCTIONS]") || line.starts_with("[DATA]") || line.starts_with("[SCHEMA") || line.starts_with("[CALL]") || line.starts_with("[RESULT]") {
                break;
            }

            if !line.starts_with('[') || !line.ends_with(']') {
                 break;
            }
            
            let name = line.trim_start_matches('[').trim_end_matches(']').to_string();
            lines.next();

            let desc_line = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
            let description = if desc_line.starts_with("DESC[") && desc_line.ends_with(']') {
                desc_line["DESC[".len()..desc_line.len()-1].to_string()
            } else {
                return Err(ParseError::MalformedLine(format!("Expected DESC, found: {}", desc_line)));
            };

            // IN
            let in_line = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
            let inputs = if in_line.starts_with("IN[") {
                self.parse_parameter_list(in_line)?
            } else {
                 return Err(ParseError::MalformedLine(format!("Expected IN, found: {}", in_line)));
            };

            // OUT
            let out_line = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
            let outputs = if out_line.starts_with("OUT[") {
                self.parse_parameter_list(out_line)?
            } else {
                 return Err(ParseError::MalformedLine(format!("Expected OUT, found: {}", out_line)));
            };

            functions.push(FunctionDef {
                name,
                description,
                inputs,
                outputs,
            });
        }

        Ok(FunctionsBlock { functions })
    }

    fn parse_call(&self, lines: &mut Peekable<Lines>) -> Result<CallBlock, ParseError> {
        lines.next();
        
        let name_line = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
        let function_name = if name_line.starts_with('[') && name_line.ends_with(']') {
            name_line.trim_start_matches('[').trim_end_matches(']').to_string()
        } else {
            return Err(ParseError::MalformedLine(format!("Expected [FunctionName], found: {}", name_line)));
        };

        let mut arguments = Vec::new();
        while let Some(line) = lines.peek() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('[') {
                break;
            }
            
            let parts: Vec<&str> = line.splitn(2, ':').collect();
            if parts.len() != 2 {
                 return Err(ParseError::MalformedLine(format!("Expected KEY:VALUE, found: {}", line)));
            }
            arguments.push((parts[0].to_string(), parts[1].to_string()));
            lines.next();
        }

        Ok(CallBlock { function_name, arguments })
    }

    fn parse_result(&self, lines: &mut Peekable<Lines>) -> Result<ResultBlock, ParseError> {
        lines.next();
        
        let header_line = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
        let header_content = header_line.trim_start_matches('[').trim_end_matches(']');
        let output_schema = if header_content.contains(':') {
             let parts: Vec<&str> = header_content.split('|').collect();
             let mut params = Vec::new();
             for part in parts {
                let kv: Vec<&str> = part.split(':').collect();
                 if kv.len() != 2 {
                    return Err(ParseError::MalformedLine(format!("Invalid result header: {}", part)));
                }
                let name = kv[0].to_string();
                let param_type = self.parse_type(kv[1])?;
                params.push(FunctionParam { name, param_type, required: false });
             }
             params
        } else {
            vec![]
        };

        let mut records = Vec::new();
        while let Some(line) = lines.peek() {
            let line = line.trim();
            if line.is_empty() {
                lines.next();
                continue;
            }
            if line.starts_with('[') {
                break;
            }

            let values: Vec<String> = line.split('|').map(|s| {
                let s = s.trim();
                if s == "_" {
                    "".to_string()
                } else {
                    s.to_string()
                }
            }).collect();
            records.push(values);
            lines.next();
        }

        let status_header = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
        if status_header != "[STATUS:str]" {
             return Err(ParseError::MalformedLine(format!("Expected [STATUS:str], found: {}", status_header)));
        }

        let status_val = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
        let status = match status_val {
            "SUCCESS" => ResultStatus::Success,
            "ERROR" => ResultStatus::Error,
            _ => return Err(ParseError::MalformedLine(format!("Unknown status: {}", status_val))),
        };
        
        let error_header = lines.next().ok_or(ParseError::UnexpectedEof)?.trim();
        if error_header != "[ERROR:str]" {
             return Err(ParseError::MalformedLine(format!("Expected [ERROR:str], found: {}", error_header)));
        }
        
        let mut error_message = None;
        if let Some(line) = lines.peek() {
            let line = line.trim();
            if !line.starts_with('[') && !line.is_empty() {
                 error_message = Some(line.to_string());
                 lines.next();
            } else if line.is_empty() {
                lines.next();
            }
        }

        Ok(ResultBlock {
            output_schema,
            records,
            status,
            error_message,
        })
    }
}

pub fn parse(input: &str) -> Result<Vec<AgentMessage>, ParseError> {
    let mut parser = Parser::new();
    parser.parse_internal(input)
}
