// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas

use crate::ast::*;
use std::fmt;

impl fmt::Display for DslType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DslType::Int => write!(f, "int"),
            DslType::Str => write!(f, "str"),
            DslType::Float => write!(f, "float"),
            DslType::Any => write!(f, "any"),
            DslType::Reference(schema, field) => write!(f, "@{}.{}", schema, field),
        }
    }
}

pub trait AgentDslSerialize {
    fn to_dsl(&self) -> String;
}

impl AgentDslSerialize for SchemaBlock {
    fn to_dsl(&self) -> String {
        let fields_str = self
            .fields
            .iter()
            .map(|field| format!("{}:{}", field.name, field.field_type))
            .collect::<Vec<String>>()
            .join("|");
        format!("[SCHEMA:{}]\n{}\n", self.label, fields_str)
    }
}

impl AgentDslSerialize for DataBlock {
    fn to_dsl(&self) -> String {
        let mut output = String::from("[DATA]\n");
        for record in &self.records {
            let row = record.iter().map(|s| {
                if s.is_empty() {
                    "_"
                } else {
                    s.as_str()
                }
            }).collect::<Vec<&str>>().join("|");
            output.push_str(&row);
            output.push('\n');
        }
        output
    }
}

impl AgentDslSerialize for FunctionsBlock {
    fn to_dsl(&self) -> String {
        let mut output = String::from("[FUNCTIONS]\n");
        for func in &self.functions {
            output.push_str(&format!("[{}]\n", func.name));
            output.push_str(&format!("DESC[{}]\n", func.description));
            
            let inputs_str = func
                .inputs
                .iter()
                .map(|p| format!("{}:{}{}", p.name, p.param_type, if p.required { "*" } else { "" }))
                .collect::<Vec<String>>()
                .join("|");
            output.push_str(&format!("IN[{}]\n", inputs_str));

            let outputs_str = func
                .outputs
                .iter()
                .map(|p| format!("{}:{}{}", p.name, p.param_type, if p.required { "*" } else { "" }))
                .collect::<Vec<String>>()
                .join("|");
            output.push_str(&format!("OUT[{}]\n", outputs_str));
            output.push('\n');
        }
        output
    }
}

impl AgentDslSerialize for CallBlock {
    fn to_dsl(&self) -> String {
        let mut output = String::from("[CALL]\n");
        output.push_str(&format!("[{}]\n", self.function_name));
        for (key, value) in &self.arguments {
            output.push_str(&format!("{}:{}\n", key, value));
        }
        output
    }
}

impl AgentDslSerialize for ResultBlock {
    fn to_dsl(&self) -> String {
        let mut output = String::from("[RESULT]\n");
        
        let header_str = self
            .output_schema
            .iter()
            .map(|p| format!("{}:{}", p.name, p.param_type))
            .collect::<Vec<String>>()
            .join("|");
        output.push_str(&format!("[{}]\n", header_str));

        for record in &self.records {
            let values_str = record.iter().map(|s| {
                if s.is_empty() {
                    "_"
                } else {
                    s.as_str()
                }
            }).collect::<Vec<&str>>().join("|");
            output.push_str(&values_str);
            output.push('\n');
        }

        output.push_str("[STATUS:str]\n");
        match self.status {
            ResultStatus::Success => output.push_str("SUCCESS\n"),
            ResultStatus::Error => output.push_str("ERROR\n"),
        }

        output.push_str("[ERROR:str]\n");
        if let Some(err) = &self.error_message {
            output.push_str(err);
            output.push('\n');
        }

        output
    }
}

impl AgentDslSerialize for AgentMessage {
    fn to_dsl(&self) -> String {
        match self {
            AgentMessage::Schema(x) => x.to_dsl(),
            AgentMessage::Data(x) => x.to_dsl(),
            AgentMessage::Functions(x) => x.to_dsl(),
            AgentMessage::Call(x) => x.to_dsl(),
            AgentMessage::Result(x) => x.to_dsl(),
        }
    }
}

pub fn serialize(message: &AgentMessage) -> String {
    message.to_dsl()
}
