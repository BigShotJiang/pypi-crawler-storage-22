# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Khaled Abbas
import json
import time
import os
import random
import sys

# Require a real `agentdsl` package for accurate benchmarks
try:
    import agentdsl
    print("✓ AgentDSL library found.")
except ImportError:
    raise ImportError(
        "The `agentdsl` package is required to run these benchmarks.\n"
        "Install it in the active environment (e.g. pip install -e . or pip install agentdsl).")

# Optional token counting using OpenAI tiktoken
try:
    import tiktoken
    # Use the common CL100K encoding that matches OpenAI's recent models
    encoding = tiktoken.get_encoding("cl100k_base")
    print("✓ tiktoken library found.")
except Exception:
    raise ImportError(
        "The `tiktoken` package is required to run token-aware benchmarks.\n"
        "Install it in the active environment (e.g. pip install tiktoken).")

# ------------------------------------------------------------------
# SCENARIO DEFINITIONS AND GENERATORS
# ------------------------------------------------------------------

def make_deep_org_hierarchy(n_depts=5):
    """Multi-level org structure: Department -> Team -> Member -> Tasks (4-level nesting)"""
    company = {
        "company_id": "ORG-001",
        "company_name": "TechCorp",
        "departments": []
    }
    base_ts = 1610000000
    task_id = 1
    
    for d in range(n_depts):
        dept = {
            "dept_id": f"D-{100+d}",
            "dept_name": f"Department {chr(65+d)}",
            "budget": round(random.uniform(100000, 500000), 2),
            "teams": []
        }
        
        for t in range(random.randint(2, 4)):
            team = {
                "team_id": f"T-{100+d}-{t}",
                "team_name": f"Team {chr(65+t)}",
                "lead": f"lead_user_{random.randint(1,50)}",
                "members": []
            }
            
            for m in range(random.randint(3, 6)):
                member = {
                    "member_id": f"M-{100+d}-{t}-{m}",
                    "name": f"Employee {task_id}",
                    "email": f"emp{task_id}@techcorp.com",
                    "role": random.choice(["Engineer", "Designer", "PM", "QA"]),
                    "tasks": []
                }
                
                # 4th level: Tasks
                for tk in range(random.randint(2, 4)):
                    member["tasks"].append({
                        "task_id": f"TSK-{task_id}",
                        "title": f"Task {task_id}: Implement feature {random.randint(1,100)}",
                        "status": random.choice(["TODO", "IN_PROGRESS", "DONE"]),
                        "due_date": base_ts + random.randint(86400*1, 86400*30),
                        "priority": random.choice([1,2,3,4,5])
                    })
                    task_id += 1
                
                team["members"].append(member)
            
            dept["teams"].append(team)
        
        company["departments"].append(dept)
    
    return company


def make_ecommerce_catalog(n_cats=8):
    """E-commerce with Category -> Subcategory -> Products -> Reviews (4-level nesting)"""
    catalog = {"store_id": "SHOP-001", "store_name": "MegaStore", "categories": []}
    
    for c in range(n_cats):
        category = {
            "cat_id": f"CAT-{100+c}",
            "cat_name": f"Category {chr(65+c)}",
            "subcategories": []
        }
        
        for sc in range(random.randint(2, 4)):
            subcat = {
                "subcat_id": f"SC-{100+c}-{sc}",
                "subcat_name": f"Subcategory {chr(65+sc)}",
                "products": []
            }
            
            for p in range(random.randint(3, 6)):
                product = {
                    "sku": f"SKU-{100+c}-{sc}-{p}",
                    "name": f"Product {chr(65+c)}{sc}{p}",
                    "price": round(random.uniform(10, 500), 2),
                    "stock": random.randint(0, 1000),
                    "reviews": []
                }
                
                # 4th level: Reviews
                for rv in range(random.randint(1, 5)):
                    product["reviews"].append({
                        "review_id": f"REV-{100+c}-{sc}-{p}-{rv}",
                        "rating": random.randint(1, 5),
                        "reviewer": f"user_{random.randint(1,1000)}",
                        "comment": f"Great product! " * random.randint(1, 5),
                        "helpful": random.randint(0, 100)
                    })
                
                subcat["products"].append(product)
            
            category["subcategories"].append(subcat)
        
        catalog["categories"].append(category)
    
    return catalog


def make_deep_api_response(n=100):
    """Nested API response: Results array with nested metadata (relational)"""
    results = []
    for i in range(n):
        result = {
            "result_id": f"R-{i}",
            "project_id": f"PROJ-{i%6}",
            "task_id": f"TASK-{i%20}",
            "name": f"Result {i}",
            "status": random.choice(["ACTIVE", "PLANNING", "COMPLETED"]),
            "details": {
                "priority": random.randint(1, 5),
                "due_date": 1610000000 + i*86400,
                "assigned_to": f"user_{random.randint(1,50)}"
            }
        }
        results.append(result)
    return {"results": results}


def make_database_query_results(n=150):
    """Database results: Customers -> Orders -> LineItems -> Fulfillment (4-level)"""
    results = {"query": "SELECT * FROM orders", "customers": []}
    
    for c in range(random.randint(5, 15)):
        customer = {
            "customer_id": f"CUST-{1000+c}",
            "name": f"Customer {c}",
            "email": f"cust{c}@example.com",
            "orders": []
        }
        
        for o in range(random.randint(1, 4)):
            order = {
                "order_id": f"ORD-{10000+c*10+o}",
                "order_date": 1610000000 + o * 86400,
                "status": random.choice(["PENDING", "PROCESSING", "SHIPPED", "DELIVERED"]),
                "items": []
            }
            
            for i in range(random.randint(1, 5)):
                item = {
                    "line_item_id": f"LI-{10000+c*10+o}-{i}",
                    "sku": f"SKU-{random.randint(1000, 9999)}",
                    "quantity": random.randint(1, 10),
                    "unit_price": round(random.uniform(5, 200), 2),
                    "fulfillment": {
                        "warehouse": f"WH-{chr(65+random.randint(0, 2))}",
                        "shipped_date": 1610000000 + (o+1) * 86400,
                        "tracking": f"TRACK{random.randint(100000, 999999)}"
                    }
                }
                order["items"].append(item)
            
            customer["orders"].append(order)
        
        results["customers"].append(customer)
    
    return results


def make_content_hierarchy(n=50):
    """Content tree: Sections -> Pages -> Paragraphs -> Links (4-level)"""
    content = {"site_id": "SITE-001", "site_name": "Documentation", "sections": []}
    
    for s in range(random.randint(3, 6)):
        section = {
            "section_id": f"SEC-{100+s}",
            "section_title": f"Section {chr(65+s)}",
            "pages": []
        }
        
        for p in range(random.randint(2, 5)):
            page = {
                "page_id": f"PAGE-{100+s}-{p}",
                "title": f"Page: {chr(65+s)}.{chr(65+p)}",
                "paragraphs": []
            }
            
            for para in range(random.randint(2, 4)):
                paragraph = {
                    "para_id": f"PARA-{100+s}-{p}-{para}",
                    "text": f"This is paragraph {para} with content. " * 5,
                    "links": []
                }
                
                for link in range(random.randint(0, 3)):
                    paragraph["links"].append({
                        "link_id": f"LINK-{100+s}-{p}-{para}-{link}",
                        "url": f"https://example.com/page/{s}/{p}/{para}/{link}",
                        "text": f"Link {link}"
                    })
                
                page["paragraphs"].append(paragraph)
            
            section["pages"].append(page)
        
        content["sections"].append(section)
    
    return content


def make_table_data(n=500):
    """High-density table: Users with many fields (optimal for DSL)"""
    users = []
    for i in range(n):
        users.append({
            "user_id": f"U-{1000+i}",
            "username": f"user_{i}",
            "email": f"user{i}@example.com",
            "age": random.randint(18, 80),
            "country": random.choice(["USA", "UK", "CA", "AU", "DE", "FR", "JP"]),
            "status": random.choice(["active", "inactive", "suspended"]),
            "signup_date": 1610000000 + i*60,
            "last_login": 1610000000 + random.randint(0, 86400*30),
            "subscription": random.choice(["free", "pro", "enterprise"]),
            "total_spent": round(random.uniform(0, 10000), 2)
        })
    return {"users": users}


def make_function_schema(n=30):
    """Tool discovery: Array of function definitions with parameters"""
    functions = []
    for i in range(n):
        func_name = f"Function_{chr(65 + i%26)}{i//26}"
        functions.append({
            "function_id": i,
            "name": func_name,
            "description": f"This function performs operation {i}",
            "input_params": random.randint(2, 5),
            "output_params": random.randint(1, 3),
            "is_required": random.choice([True, False]),
            "category": random.choice(["search", "compute", "transform", "aggregate"])
        })
    return {"functions": functions}


def make_api_result(n=200):
    """API result: Results with relational metadata (reference pattern)"""
    results = []
    for i in range(n):
        results.append({
            "id": f"RESULT-{i}",
            "title": f"Result Item {i}",
            "score": round(random.random(), 3),
            "metadata": {
                "source": random.choice(["api", "db", "cache"]),
                "timestamp": 1610000000 + i*60,
                "version": random.choice(["v1", "v2", "v3"])
            }
        })
    return {"results": results}


# Initialize and extend scenarios with curated nesting and relational examples
COMPLEX_SCENARIOS = {
    # High-density table (optimal for DSL)
    "Users_Table_500": make_table_data(500),
    
    # Unlimited nesting demonstrations (4-level deep)
    "Deep_Org_Hierarchy": make_deep_org_hierarchy(5),
    "E-Commerce_Catalog": make_ecommerce_catalog(6),
    "API_Response_Nested": make_deep_api_response(100),
    "Database_Orders_4Levels": make_database_query_results(12),
    "Documentation_Content": make_content_hierarchy(6),
    
    # Additional relevant scenarios
    "Function_Schema_Discovery": make_function_schema(30),
    "API_Results_200": make_api_result(200),
}


# ------------------------------------------------------------------
# LOGIC
# ------------------------------------------------------------------

def safe_dsl_convert(data):
    """Attempt conversion and return result or error string."""
    try:
        start_time = time.time()
        res = agentdsl.from_json(data)
        duration = (time.time() - start_time) * 1000 # ms
        return res, duration, None
    except Exception as e:
        return None, 0, str(e)

def generate_robust_report():
    print("\n" + "─" * 70)
    print("  AgentDSL Benchmark Suite - Comprehensive Performance Analysis")
    print("─" * 70 + "\n")
    
    results = []
    start_time = time.time()
    
    print(f"📊 Processing {len(COMPLEX_SCENARIOS)} scenarios...\n")
    
    for idx, (name, data) in enumerate(COMPLEX_SCENARIOS.items(), 1):
        sys.stdout.write(f"\r  [{idx:2d}/{len(COMPLEX_SCENARIOS)}] Processing {name:<30} ", )
        sys.stdout.flush()
        
        # Compact JSON for fair comparison
        json_str = json.dumps(data, separators=(',', ':'))
        # Token counts (requires `tiktoken` imported above)
        try:
            json_tokens = len(encoding.encode(json_str))
        except Exception:
            json_tokens = 0
        
        dsl_str, duration, error = safe_dsl_convert(data)
        
        if error:
            dsl_display = f"CONVERSION ERROR: {error}"
            dsl_len = 0
            gain = 0
            dsl_tokens = 0
            status_marker = "✗"
        else:
            dsl_display = dsl_str
            dsl_len = len(dsl_str)
            try:
                dsl_tokens = len(encoding.encode(str(dsl_str)))
            except Exception:
                dsl_tokens = 0
            # Calculate % reduction
            if len(json_str) > 0:
                gain = round(((len(json_str) - dsl_len) / len(json_str)) * 100, 1)
            else:
                gain = 0
            # Token-based efficiency (percent reduction)
            if json_tokens > 0:
                token_gain = round(((json_tokens - dsl_tokens) / json_tokens) * 100, 1)
            else:
                token_gain = 0
            status_marker = "✓"

        sys.stdout.write(f"{status_marker}\n")
        sys.stdout.flush()

        results.append({
            "name": name,
            "json_len": len(json_str),
            "json_tokens": json_tokens,
            "dsl_len": dsl_len,
            "dsl_tokens": dsl_tokens,
            "json_raw": json_str,
            "dsl_raw": dsl_display,
            "gain": gain,
            "token_gain": token_gain,
            "time_ms": round(duration, 2),
            "status": "Success" if not error else "Failed"
        })

    total_duration = time.time() - start_time

    # Prepare data for JS and summary stats
    labels = [r['name'] for r in results]
    json_data = [r['json_len'] for r in results]
    dsl_data = [r['dsl_len'] for r in results]
    gain_data = [r['gain'] for r in results]
    json_token_data = [r.get('json_tokens', 0) for r in results]
    dsl_token_data = [r.get('dsl_tokens', 0) for r in results]
    token_gain_data = [r.get('token_gain', 0) for r in results]
    total_json = sum(json_data)
    total_dsl = sum(dsl_data)
    total_json_tokens = sum(json_token_data)
    total_dsl_tokens = sum(dsl_token_data)
    avg_gain = round(sum(gain_data)/len(gain_data), 1) if gain_data else 0
    avg_token_gain = round(sum(token_gain_data)/len(token_gain_data), 1) if token_gain_data else 0
    total_time = round(sum(r['time_ms'] for r in results), 2)

    # Print summary statistics
    print("\n" + "─" * 70)
    print("  📈 Benchmark Summary")
    print("─" * 70 + "\n")
    
    print(f"  Total Scenarios Processed:    {len(results)}")
    print(f"  Total Execution Time:         {total_duration:.2f}s")
    print()
    
    print("  Character Size Analysis:")
    print(f"    JSON Total:                 {total_json:>12,} chars")
    print(f"    AgentDSL Total:             {total_dsl:>12,} chars")
    print(f"    Total Reduction:            {total_json - total_dsl:>12,} chars ({round((total_json - total_dsl) / total_json * 100, 1)}%)")
    print(f"    Average Per-Scenario:       {avg_gain:>12.1f}%")
    print()
    
    print("  Token Count Analysis:")
    print(f"    JSON Total:                 {total_json_tokens:>12,} tokens")
    print(f"    AgentDSL Total:             {total_dsl_tokens:>12,} tokens")
    print(f"    Total Reduction:            {total_json_tokens - total_dsl_tokens:>12,} tokens ({round((total_json_tokens - total_dsl_tokens) / total_json_tokens * 100, 1) if total_json_tokens > 0 else 0}%)")
    print(f"    Average Per-Scenario:       {avg_token_gain:>12.1f}%")
    print()
    
    print("  Conversion Performance:")
    print(f"    Total Conversion Time:      {total_time:>12.2f} ms")
    print(f"    Average Per-Scenario:       {total_time / len(results):>12.2f} ms")
    print()

    # Generate HTML with professional design
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AgentDSL Benchmark Report</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
        <style>
            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }}

            :root {{
                --bg-dark: #0f172a;
                --bg-card: #1e293b;
                --bg-light: #334155;
                --text-primary: #f1f5f9;
                --text-secondary: #cbd5e1;
                --border-light: #475569;
                --accent-blue: #0ea5e9;
                --accent-cyan: #06b6d4;
                --success: #10b981;
                --danger: #ef4444;
                --warning: #f59e0b;
            }}

            html {{
                scroll-behavior: smooth;
            }}

            body {{
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
                background: linear-gradient(135deg, var(--bg-dark) 0%, var(--bg-card) 100%);
                color: var(--text-primary);
                line-height: 1.6;
                min-height: 100vh;
            }}

            .container {{
                max-width: 1400px;
                margin: 0 auto;
                padding: 40px 20px;
            }}

            /* Header */
            .header {{
                margin-bottom: 50px;
                text-align: center;
            }}

            .header h1 {{
                font-size: 2.5rem;
                font-weight: 800;
                margin-bottom: 12px;
                background: linear-gradient(135deg, var(--accent-blue), var(--accent-cyan));
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                letter-spacing: -1px;
            }}

            .header .subtitle {{
                font-size: 1.1rem;
                color: var(--text-secondary);
                margin-bottom: 8px;
            }}

            .header .timestamp {{
                font-size: 0.9rem;
                color: var(--border-light);
            }}

            /* Overview Section */
            .overview {{
                background: var(--bg-card);
                border: 1px solid var(--border-light);
                border-radius: 16px;
                padding: 30px;
                margin-bottom: 50px;
                box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3);
            }}

            .overview p {{
                color: var(--text-secondary);
                font-size: 1rem;
                margin-bottom: 12px;
            }}

            .overview strong {{
                color: var(--accent-blue);
            }}

            /* Statistics Grid */
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 50px;
            }}

            .stat-box {{
                background: var(--bg-card);
                border: 1px solid var(--border-light);
                border-radius: 12px;
                padding: 24px;
                text-align: center;
                transition: all 0.3s ease;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2);
            }}

            .stat-box:hover {{
                transform: translateY(-4px);
                border-color: var(--accent-blue);
                box-shadow: 0 20px 25px -5px rgba(14, 165, 233, 0.2);
            }}

            .stat-box .value {{
                font-size: 2.2rem;
                font-weight: 700;
                color: var(--accent-blue);
                margin-bottom: 8px;
            }}

            .stat-box .label {{
                font-size: 0.85rem;
                color: var(--text-secondary);
                text-transform: uppercase;
                letter-spacing: 1px;
                font-weight: 600;
            }}

            /* Section Headers */
            .section-header {{
                margin-bottom: 30px;
                margin-top: 50px;
            }}

            .section-header h2 {{
                font-size: 1.8rem;
                font-weight: 700;
                margin-bottom: 8px;
                color: var(--text-primary);
            }}

            .section-header .description {{
                color: var(--text-secondary);
                font-size: 1rem;
            }}

            /* Charts Container */
            .charts-container {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
                gap: 30px;
                margin-bottom: 50px;
            }}

            .chart-wrapper {{
                background: var(--bg-card);
                border: 1px solid var(--border-light);
                border-radius: 12px;
                padding: 25px;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2);
            }}

            .chart-wrapper canvas {{
                max-height: 400px;
            }}

            /* Scenario Cards */
            .scenarios-container {{
                display: grid;
                gap: 25px;
            }}

            .scenario-card {{
                background: var(--bg-card);
                border: 1px solid var(--border-light);
                border-left: 4px solid var(--success);
                border-radius: 12px;
                padding: 28px;
                transition: all 0.3s ease;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2);
            }}

            .scenario-card:hover {{
                border-left-color: var(--accent-blue);
                transform: translateX(4px);
                box-shadow: 0 20px 25px -5px rgba(14, 165, 233, 0.15);
            }}

            .scenario-card.failed {{
                border-left-color: var(--danger);
            }}

            .scenario-header {{
                display: flex;
                justify-content: space-between;
                align-items: start;
                margin-bottom: 20px;
                gap: 16px;
                flex-wrap: wrap;
            }}

            .scenario-name {{
                font-size: 1.3rem;
                font-weight: 700;
                color: var(--text-primary);
            }}

            .scenario-badges {{
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
                align-items: center;
            }}

            .badge {{
                display: inline-flex;
                align-items: center;
                padding: 6px 12px;
                border-radius: 8px;
                font-size: 0.85rem;
                font-weight: 600;
                border: 1px solid;
            }}

            .badge.performance {{
                background: rgba(14, 165, 233, 0.1);
                color: var(--accent-blue);
                border-color: var(--accent-blue);
            }}

            .badge.reduction {{
                background: rgba(16, 185, 129, 0.1);
                color: var(--success);
                border-color: var(--success);
            }}

            .badge.token {{
                background: rgba(6, 182, 212, 0.1);
                color: var(--accent-cyan);
                border-color: var(--accent-cyan);
            }}

            /* Comparison Grid */
            .comparison {{
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-top: 20px;
                width: 100%;
                overflow: hidden;
            }}

            .code-section {{
                display: flex;
                flex-direction: column;
                min-width: 0;
                overflow: hidden;
            }}

            .code-header {{
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
                padding-bottom: 8px;
                border-bottom: 1px solid var(--border-light);
                flex-wrap: wrap;
                gap: 8px;
            }}

            .code-header .format {{
                font-weight: 700;
                color: var(--accent-blue);
                font-size: 0.95rem;
                flex-shrink: 0;
            }}

            .code-header .metrics {{
                color: var(--text-secondary);
                font-size: 0.85rem;
                flex-shrink: 1;
                min-width: 0;
                text-align: right;
            }}

            pre {{
                background: var(--bg-dark);
                color: var(--text-primary);
                border: 1px solid var(--border-light);
                border-radius: 8px;
                padding: 16px;
                font-size: 0.85rem;
                overflow: auto;
                max-height: 300px;
                font-family: 'Courier New', 'Monaco', 'Menlo', monospace;
                line-height: 1.5;
                word-break: break-word;
                overflow-wrap: break-word;
                white-space: pre-wrap;
                min-width: 0;
                width: 100%;
            }}

            pre::-webkit-scrollbar {{
                width: 6px;
                height: 6px;
            }}

            pre::-webkit-scrollbar-track {{
                background: rgba(255, 255, 255, 0.05);
            }}

            pre::-webkit-scrollbar-thumb {{
                background: rgba(14, 165, 233, 0.3);
                border-radius: 3px;
            }}

            pre::-webkit-scrollbar-thumb:hover {{
                background: rgba(14, 165, 233, 0.5);
            }}

            /* Footer */
            .footer {{
                margin-top: 60px;
                padding-top: 30px;
                border-top: 1px solid var(--border-light);
                text-align: center;
                color: var(--text-secondary);
                font-size: 0.9rem;
            }}

            .footer strong {{
                color: var(--accent-blue);
            }}

            /* Responsive */
            @media (max-width: 1024px) {{
                .comparison {{
                    grid-template-columns: 1fr;
                }}

                .charts-container {{
                    grid-template-columns: 1fr;
                }}

                .header h1 {{
                    font-size: 2rem;
                }}
            }}

            @media (max-width: 768px) {{
                .container {{
                    padding: 24px 16px;
                }}

                .header h1 {{
                    font-size: 1.75rem;
                }}

                .stats-grid {{
                    grid-template-columns: repeat(2, 1fr);
                }}

                .scenario-header {{
                    flex-direction: column;
                }}

                .scenario-badges {{
                    justify-content: flex-start;
                }}

                pre {{
                    font-size: 0.75rem;
                }}
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <!-- Header -->
            <div class="header">
                <h1>AgentDSL Benchmark Report</h1>
                <p class="subtitle">Comprehensive Performance Analysis: AgentDSL vs JSON</p>
                <p class="timestamp">Generated on {time.strftime('%Y-%m-%d at %H:%M:%S UTC', time.gmtime())}</p>
            </div>

            <!-- Overview -->
            <div class="overview">
                <p><strong>AgentDSL</strong> is a specialized serialization format designed for efficient data representation. This report compares its performance against standard JSON across {len(results)} diverse, real-world scenarios.</p>
                <p>Key metrics include character count reduction, token efficiency, and conversion time. Lower values indicate better performance and efficiency.</p>
            </div>

            <!-- Summary Statistics -->
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="value">{len(results)}</div>
                    <div class="label">Scenarios Tested</div>
                </div>
                <div class="stat-box">
                    <div class="value">{avg_gain}%</div>
                    <div class="label">Avg Size Reduction</div>
                </div>
                <div class="stat-box">
                    <div class="value">{avg_token_gain}%</div>
                    <div class="label">Avg Token Reduction</div>
                </div>
                <div class="stat-box">
                    <div class="value">{round((total_json - total_dsl) / total_json * 100, 1)}%</div>
                    <div class="label">Total Reduction</div>
                </div>
                <div class="stat-box">
                    <div class="value">{total_time / len(results):.2f}ms</div>
                    <div class="label">Avg Conversion Time</div>
                </div>
                <div class="stat-box">
                    <div class="value">{len([r for r in results if r['status'] == 'Success'])} / {len(results)}</div>
                    <div class="label">Success Rate</div>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="section-header">
                <h2>Performance Analysis</h2>
                <p class="description">Visual comparison of character count and token efficiency across all scenarios</p>
            </div>

            <div class="charts-container">
                <div class="chart-wrapper">
                    <canvas id="charChart"></canvas>
                </div>
                <div class="chart-wrapper">
                    <canvas id="tokenChart"></canvas>
                </div>
            </div>

            <!-- Detailed Scenarios -->
            <div class="section-header">
                <h2>Scenario Details</h2>
                <p class="description">Individual analysis of each benchmark scenario with side-by-side comparisons</p>
            </div>

            <div class="scenarios-container">
                {"".join([f'''
                <div class="scenario-card {("failed" if r["status"] == "Failed" else "")}">
                    <div class="scenario-header">
                        <div class="scenario-name">{r["name"]}</div>
                        <div class="scenario-badges">
                            <span class="badge performance">⏱ {r["time_ms"]}ms</span>
                            <span class="badge reduction">📉 {r["gain"]}% size</span>
                            <span class="badge token">🔤 {r.get("token_gain", 0)}% tokens</span>
                        </div>
                    </div>
                    
                    <div class="comparison">
                        <div class="code-section">
                            <div class="code-header">
                                <span class="format">JSON</span>
                                <span class="metrics">{r["json_len"]} chars • {r.get("json_tokens", 0)} tokens</span>
                            </div>
                            <pre>{r["json_raw"]}</pre>
                        </div>
                        <div class="code-section">
                            <div class="code-header">
                                <span class="format">AgentDSL</span>
                                <span class="metrics">{r["dsl_len"]} chars • {r.get("dsl_tokens", 0)} tokens</span>
                            </div>
                            <pre>{r["dsl_raw"]}</pre>
                        </div>
                    </div>
                </div>
                ''' for r in results])}
            </div>

            <!-- Footer -->
            <div class="footer">
                <p><strong>Report Summary:</strong> {total_json:,} JSON chars vs {total_dsl:,} AgentDSL chars | {total_json_tokens:,} JSON tokens vs {total_dsl_tokens:,} AgentDSL tokens</p>
                <p>Total execution time: {total_duration:.2f}s</p>
            </div>
        </div>

        <script>
            // Shared chart options
            const commonOptions = {{
                responsive: true,
                maintainAspectRatio: true,
                plugins: {{
                    legend: {{
                        labels: {{
                            color: '#cbd5e1',
                            font: {{ size: 12, weight: '600' }},
                            padding: 16,
                            usePointStyle: true
                        }}
                    }},
                    tooltip: {{
                        backgroundColor: 'rgba(15, 23, 42, 0.95)',
                        borderColor: 'rgba(14, 165, 233, 0.5)',
                        borderWidth: 1,
                        titleColor: '#f1f5f9',
                        bodyColor: '#cbd5e1',
                        padding: 12,
                        displayColors: true,
                        titleFont: {{ weight: 'bold' }}
                    }}
                }},
                scales: {{
                    x: {{
                        grid: {{ display: false, drawBorder: false }},
                        ticks: {{
                            color: '#cbd5e1',
                            font: {{ size: 11 }},
                            autoSkip: false,
                            maxRotation: 45,
                            minRotation: 0
                        }}
                    }},
                    y: {{
                        beginAtZero: true,
                        grid: {{ color: 'rgba(255, 255, 255, 0.05)', drawBorder: false }},
                        ticks: {{ color: '#cbd5e1', font: {{ size: 11 }} }}
                    }}
                }}
            }};

            // Character Count Chart
            const charCtx = document.getElementById('charChart').getContext('2d');
            new Chart(charCtx, {{
                type: 'bar',
                data: {{
                    labels: {labels},
                    datasets: [
                        {{
                            label: 'JSON',
                            data: {json_data},
                            backgroundColor: 'rgba(100, 116, 139, 0.7)',
                            borderColor: 'rgba(100, 116, 139, 1)',
                            borderWidth: 1,
                            borderRadius: 6
                        }},
                        {{
                            label: 'AgentDSL',
                            data: {dsl_data},
                            backgroundColor: 'rgba(14, 165, 233, 0.7)',
                            borderColor: 'rgba(14, 165, 233, 1)',
                            borderWidth: 1,
                            borderRadius: 6
                        }}
                    ]
                }},
                options: {{
                    ...commonOptions,
                    plugins: {{
                        ...commonOptions.plugins,
                        title: {{
                            display: true,
                            text: 'Character Count Comparison',
                            color: '#f1f5f9',
                            font: {{ size: 16, weight: 'bold' }},
                            padding: 20
                        }}
                    }},
                    scales: {{
                        ...commonOptions.scales,
                        y: {{
                            ...commonOptions.scales.y,
                            title: {{ display: true, text: 'Characters', color: '#cbd5e1' }}
                        }}
                    }}
                }}
            }});

            // Token Count Chart
            const tokenCtx = document.getElementById('tokenChart').getContext('2d');
            new Chart(tokenCtx, {{
                type: 'bar',
                data: {{
                    labels: {labels},
                    datasets: [
                        {{
                            label: 'JSON Tokens',
                            data: {json_token_data},
                            backgroundColor: 'rgba(100, 116, 139, 0.7)',
                            borderColor: 'rgba(100, 116, 139, 1)',
                            borderWidth: 1,
                            borderRadius: 6
                        }},
                        {{
                            label: 'AgentDSL Tokens',
                            data: {dsl_token_data},
                            backgroundColor: 'rgba(6, 182, 212, 0.7)',
                            borderColor: 'rgba(6, 182, 212, 1)',
                            borderWidth: 1,
                            borderRadius: 6
                        }}
                    ]
                }},
                options: {{
                    ...commonOptions,
                    plugins: {{
                        ...commonOptions.plugins,
                        title: {{
                            display: true,
                            text: 'Token Efficiency Comparison',
                            color: '#f1f5f9',
                            font: {{ size: 16, weight: 'bold' }},
                            padding: 20
                        }}
                    }},
                    scales: {{
                        ...commonOptions.scales,
                        y: {{
                            ...commonOptions.scales.y,
                            title: {{ display: true, text: 'Tokens', color: '#cbd5e1' }}
                        }}
                    }}
                }}
            }});
        </script>
    </body>
    </html>
    """

    with open("benchmark_report.html", "w", encoding="utf-8") as f:
        f.write(html_content)
    
    report_path = os.path.abspath("benchmark_report.html")
    print("─" * 70)
    print(f"  ✓ Report generated successfully")
    print(f"    Location: {report_path}")
    print("─" * 70 + "\n")

if __name__ == "__main__":
    try:
        generate_robust_report()
    except KeyboardInterrupt:
        print("\n\n⚠ Benchmark interrupted by user.\n")
        sys.exit(0)
    except Exception as e:
        print(f"\n\n❌ An error occurred during benchmarking:\n   {e}\n")
        sys.exit(1)