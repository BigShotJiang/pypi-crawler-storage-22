// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas

use agentdsl::{parse, serialize, AgentMessage};

#[test]
fn test_schema_and_data_parsing() {
    let input = r#"
[SCHEMA:INDIVIDUAL]
ID:int|NAME:str|AGE:int|GENDER:str|HOBBY:str

[DATA]
1|Sion|25|MALE|Coding,Reading
2|Alice|30|FEMALE|Painting
"#;

    let messages = parse(input).expect("Failed to parse");

    assert_eq!(messages.len(), 2);

    if let AgentMessage::Schema(schema) = &messages[0] {
        assert_eq!(schema.label, "INDIVIDUAL");
        assert_eq!(schema.fields.len(), 5);
        assert_eq!(schema.fields[0].name, "ID");
    } else {
        panic!("First message should be Schema");
    }

    if let AgentMessage::Data(data) = &messages[1] {
        assert_eq!(data.records.len(), 2);
        assert_eq!(data.records[0][1], "Sion");
        assert_eq!(data.schema_label, Some("INDIVIDUAL".to_string()));
    } else {
        panic!("Second message should be Data");
    }
}

#[test]
fn test_functions_parsing() {
    let input = r#"
[FUNCTIONS]
[GetWeather]
DESC[Get weather for a city]
IN[CITY:str*|FORCAST_DAYS:int] 
OUT[TEMPERATURE:str|HUMIDITY:str|WIND_SPEED:str]
"#;

    let messages = parse(input).expect("Failed to parse");
    
    if let AgentMessage::Functions(funcs) = &messages[0] {
        assert_eq!(funcs.functions.len(), 1);
        let func = &funcs.functions[0];
        assert_eq!(func.name, "GetWeather");
        assert_eq!(func.inputs.len(), 2);
        assert_eq!(func.inputs[0].name, "CITY");
        assert!(func.inputs[0].required);
    } else {
        panic!("Should be Functions block");
    }
}

#[test]
fn test_serialization_cycle() {
    let input = r#"
[SCHEMA:TEST]
ID:int|VAL:str

[DATA]
1|A
2|B
"#;
    let messages = parse(input).expect("Failed to parse");
    
    let serialized_schema = serialize(&messages[0]);
    assert!(serialized_schema.contains("[SCHEMA:TEST]"));
    assert!(serialized_schema.contains("ID:int|VAL:str"));

    let serialized_data = serialize(&messages[1]);
    assert!(serialized_data.contains("[DATA]"));
    assert!(serialized_data.contains("1|A"));
}

#[test]
fn test_json_conversion() {
    let input = r#"
[DATA]
1|Sion|25
"#;
    let messages = parse(input).expect("Failed to parse");
    
    // Convert to JSON
    let json_output = serde_json::to_string(&messages[0]).expect("Failed to serialize to JSON");
    assert!(json_output.contains("records"));
    assert!(json_output.contains("Sion"));

    // Convert back from JSON
    let decoded: AgentMessage = serde_json::from_str(&json_output).expect("Failed to deserialize from JSON");
    if let AgentMessage::Data(data) = decoded {
        assert_eq!(data.records[0][1], "Sion");
    } else {
        panic!("Should be Data block");
    }
}

#[test]
fn test_rpc_call_parsing() {
    let input = r#"
[CALL]
[GetWeather]
CITY:New York
FORCAST_DAYS:3
"#;
    let messages = parse(input).expect("Failed to parse");

    if let AgentMessage::Call(call) = &messages[0] {
        assert_eq!(call.function_name, "GetWeather");
        assert_eq!(call.arguments.len(), 2);
        assert_eq!(call.arguments[0], ("CITY".to_string(), "New York".to_string()));
        assert_eq!(call.arguments[1], ("FORCAST_DAYS".to_string(), "3".to_string()));
    } else {
        panic!("Should be Call block");
    }
}

#[test]
fn test_rpc_result_parsing() {
    let input = r#"
[RESULT]
[TEMPERATURE:str|HUMIDITY:str|WIND_SPEED:str]
30C|70%|10mph
[STATUS:str]
SUCCESS
[ERROR:str]
"#;
    let messages = parse(input).expect("Failed to parse");

    if let AgentMessage::Result(result) = &messages[0] {
        assert_eq!(result.output_schema.len(), 3);
        assert_eq!(result.records[0], vec!["30C", "70%", "10mph"]);
        match result.status {
            agentdsl::ResultStatus::Success => {},
            _ => panic!("Status should be Success"),
        }
    } else {
        panic!("Should be Result block");
    }
}

#[test]
fn test_empty_columns_with_underscore() {
    let input = r#"
[SCHEMA:TEST]
ID:int|VAL1:str|VAL2:str

[DATA]
1|_|A
2|B|_
"#;
    let messages = parse(input).expect("Failed to parse");
    
    if let AgentMessage::Data(data) = &messages[1] {
        assert_eq!(data.records[0][1], "");
        assert_eq!(data.records[0][2], "A");
        assert_eq!(data.records[1][1], "B");
        assert_eq!(data.records[1][2], "");
    } else {
        panic!("Should be Data block");
    }

    // Verify serialization
    let serialized = serialize(&messages[1]);
    assert!(serialized.contains("1|_|A"));
    assert!(serialized.contains("2|B|_"));
}

#[test]
fn test_result_empty_columns() {
    let input = r#"
[RESULT]
[VAL1:str|VAL2:str]
_|Result
[STATUS:str]
SUCCESS
[ERROR:str]
"#;
    let messages = parse(input).expect("Failed to parse");
    if let AgentMessage::Result(result) = &messages[0] {
        assert_eq!(result.records[0][0], "");
        assert_eq!(result.records[0][1], "Result");
    } else {
        panic!("Should be Result block");
    }

    let serialized = serialize(&messages[0]);
    assert!(serialized.contains("_|Result"));
}


#[test]
fn test_relational_result_parsing() {
    let input = r#"
[SCHEMA:Details]
ID:int|HUMIDITY:str|UV_INDEX:int

[DATA]
1|60%|5

[RESULT]
[CITY:str|DETAILS:@Details.ID]
Paris|1
[STATUS:str]
SUCCESS
[ERROR:str]
"#;
    let messages = parse(input).expect("Failed to parse");

    assert_eq!(messages.len(), 3);
    
    if let AgentMessage::Result(result) = &messages[2] {
        assert_eq!(result.records[0][0], "Paris");
        assert_eq!(result.records[0][1], "1");
    } else {
        panic!("Third message should be Result");
    }
}

#[test]
fn test_to_json_standard() {
    let input = r#"
[SCHEMA:INDIVIDUAL]
ID:int|NAME:str|AGE:int

[DATA]
1|Sion|25
"#;
    let messages = parse(input).unwrap();
    let json = agentdsl::json::to_json(&messages);
    
    assert!(json["INDIVIDUAL"].is_array());
    assert_eq!(json["INDIVIDUAL"][0]["NAME"], "Sion");
    assert_eq!(json["INDIVIDUAL"][0]["AGE"], 25);
    assert_eq!(json["INDIVIDUAL"][0]["ID"], 1);
}

#[test]
fn test_to_json_relational() {
    let input = r#"
[SCHEMA:INDIVIDUAL]
ID:int|NAME:str

[DATA]
1|Sion

[SCHEMA:JOB]
ID:int|TITLE:str|@INDIVIDUAL.ID:int

[DATA]
1|Engineer|1
"#;
    let messages = parse(input).unwrap();
    let json = agentdsl::json::to_json(&messages);
    
    // Parent should contain Child
    assert_eq!(json["INDIVIDUAL"][0]["NAME"], "Sion");
    assert_eq!(json["INDIVIDUAL"][0]["JOB"][0]["TITLE"], "Engineer");
}

#[test]
fn test_from_json_standard() {
    let json = serde_json::json!({
        "USERS": [
            {"ID": 1, "NAME": "Alice", "SCORE": 100},
            {"ID": 2, "NAME": "Bob", "SCORE": 95}
        ]
    });
    
    let messages = agentdsl::json::from_json(&json).unwrap();
    assert!(messages.len() >= 2); // Schema + Data
    
    if let AgentMessage::Schema(s) = &messages[0] {
        assert_eq!(s.label, "USERS");
        assert_eq!(s.fields[1].name, "NAME");
        assert_eq!(s.fields[2].name, "SCORE");
    }
}

#[test]
fn test_to_json_mixed() {
    let input = r#"
[SCHEMA:INDIVIDUAL]
ID:int|NAME:str

[DATA]
1|Sion

[SCHEMA:DETAILS]
ID:int|BIO:str

[DATA]
1|Adventurer

[SCHEMA:JOB]
ID:int|TITLE:str|@INDIVIDUAL.ID:int|DETAILS:@DETAILS.ID

[DATA]
1|Engineer|1|1
"#;
    let messages = parse(input).unwrap();
    let json = agentdsl::json::to_json(&messages);
    
    // Individual should contain JOB, and JOB should contain DETAILS
    assert_eq!(json["INDIVIDUAL"][0]["NAME"], "Sion");
    assert_eq!(json["INDIVIDUAL"][0]["JOB"][0]["TITLE"], "Engineer");
    assert_eq!(json["INDIVIDUAL"][0]["JOB"][0]["DETAILS"]["BIO"], "Adventurer");
    
    // JOB and DETAILS should NOT be at top level
    assert!(json["JOB"].is_null());
    assert!(json["DETAILS"].is_null());
}

#[test]
fn test_from_json_nested() {
    let json = serde_json::json!({
        "INDIVIDUAL": [
            {
                "ID": 1,
                "NAME": "Sion",
                "JOB": [{"ID": 1, "TITLE": "Coder"}]
            }
        ]
    });
    
    let messages = agentdsl::json::from_json(&json).unwrap();
    let serialized: String = messages.iter().map(|m| agentdsl::serializer::serialize(m)).collect::<Vec<_>>().join("\n");
    
    // Test unlimited nesting: JOB array inside INDIVIDUAL array items is decomposed
    assert!(serialized.contains("[SCHEMA:INDIVIDUAL]"));
    assert!(serialized.contains("[SCHEMA:JOB]"));
    assert!(serialized.contains("Sion"));
    assert!(serialized.contains("Coder"));
}

#[test]
fn test_from_json_simple_nested_array() {
    let json = serde_json::json!({
        "document_id": "doc-1",
        "title": "Test Doc",
        "sections": [
            {"heading": "Section 1", "text": "Content 1", "word_count": 100},
            {"heading": "Section 2", "text": "Content 2", "word_count": 200}
        ]
    });
    
    let messages = agentdsl::json::from_json(&json).unwrap();
    let serialized: String = messages.iter().map(|m| agentdsl::serializer::serialize(m)).collect::<Vec<_>>().join("\n");
    
    // Should create: Schema(sections), Data(sections)
    // Note: Root scalars (document_id, title) are preserved as metadata in a parent schema
    assert!(serialized.contains("[SCHEMA:sections_parent]"));
    assert!(serialized.contains("[SCHEMA:sections]"));
    assert!(serialized.contains("@sections_parent.ID"));
    assert!(serialized.contains("Section 1|Content 1|100"));
    assert!(serialized.contains("Section 2|Content 2|200"));
}

#[test]
fn test_from_json_arrays_within_arrays() {
    let json = serde_json::json!({
        "id": 1,
        "title": "Customer Support",
        "interactions": [
            {
                "type": "customer",
                "message": "Problem with API",
                "timestamp": 1610000000,
                "details": [
                    {"field": "error_code", "value": "401"},
                    {"field": "endpoint", "value": "/api/v1/items"}
                ]
            },
            {
                "type": "support",
                "message": "Investigating",
                "timestamp": 1610000100,
                "details": [
                    {"field": "status", "value": "in_review"}
                ]
            }
        ]
    });
    
    let messages = agentdsl::json::from_json(&json).unwrap();
    let serialized: String = messages.iter().map(|m| agentdsl::serializer::serialize(m)).collect::<Vec<_>>().join("\n");
    
    // Verify schemas are created for nested arrays - main feature is decomposition of unlimited nesting
    assert!(serialized.contains("[SCHEMA:interactions"));
    assert!(serialized.contains("[SCHEMA:details"));
    assert!(serialized.contains("error_code"));
    assert!(serialized.contains("endpoint"));
    assert!(serialized.contains("status"));
}

#[test]
fn test_from_json_four_level_deep_nesting() {
    let json = serde_json::json!({
        "org_id": "org-1",
        "org_name": "TechCorp",
        "departments": [
            {
                "dept_id": "d1",
                "name": "Engineering",
                "teams": [
                    {
                        "team_id": "t1",
                        "name": "Backend",
                        "members": [
                            {"member_id": "m1", "name": "Alice", "role": "Lead"},
                            {"member_id": "m2", "name": "Bob", "role": "Engineer"}
                        ]
                    },
                    {
                        "team_id": "t2",
                        "name": "Frontend",
                        "members": [
                            {"member_id": "m3", "name": "Carol", "role": "Lead"}
                        ]
                    }
                ]
            }
        ]
    });
    
    let messages = agentdsl::json::from_json(&json).unwrap();
    let serialized: String = messages.iter().map(|m| agentdsl::serializer::serialize(m)).collect::<Vec<_>>().join("\n");
    
    // Verify multiple schemas are created for unlimited nesting depth
    assert!(serialized.contains("[SCHEMA:departments"));
    assert!(serialized.contains("[SCHEMA:teams"));
    assert!(serialized.contains("[SCHEMA:members"));
    
    // Verify data integrity across all nesting levels
    assert!(serialized.contains("Alice"));
    assert!(serialized.contains("Bob"));
    assert!(serialized.contains("Carol"));
    assert!(serialized.contains("Backend"));
    assert!(serialized.contains("Frontend"));
}

#[test]
fn test_from_json_to_json_roundtrip_nested_arrays() {
    let json = serde_json::json!({
        "ticket_id": "TKT-001",
        "priority": "high",
        "interactions": [
            {"type": "customer", "message": "Help needed", "timestamp": 1000},
            {"type": "support", "message": "We will help", "timestamp": 2000}
        ]
    });
    
    // Convert to DSL
    let messages = agentdsl::json::from_json(&json).unwrap();
    
    // Convert back to JSON
    let result_json = agentdsl::json::to_json(&messages);
    
    // Verify interactions array is preserved (note: may be nested differently due to parent schema)
    assert!(result_json.get("interactions").is_some() || result_json.get("interactions_parent").is_some());
}

#[test]
fn test_from_json_nested_with_multiple_arrays() {
    let json = serde_json::json!({
        "project_id": "proj-1",
        "name": "MyProject",
        "team": [
            {
                "member_id": "m1",
                "name": "Alice",
                "tasks": [
                    {"task_id": "t1", "title": "Task 1", "status": "done"},
                    {"task_id": "t2", "title": "Task 2", "status": "in_progress"}
                ]
            },
            {
                "member_id": "m2",
                "name": "Bob",
                "tasks": [
                    {"task_id": "t3", "title": "Task 3", "status": "pending"}
                ]
            }
        ]
    });
    
    let messages = agentdsl::json::from_json(&json).unwrap();
    let serialized: String = messages.iter().map(|m| agentdsl::serializer::serialize(m)).collect::<Vec<_>>().join("\n");
    
    // Verify unlimited nesting with multiple arrays at different levels
    assert!(serialized.contains("[SCHEMA:team"));
    assert!(serialized.contains("[SCHEMA:tasks"));
    
    // Verify data preservation across all nesting levels
    assert!(serialized.contains("Alice"));
    assert!(serialized.contains("Bob"));
    assert!(serialized.contains("Task 1"));
    assert!(serialized.contains("done"));
}
