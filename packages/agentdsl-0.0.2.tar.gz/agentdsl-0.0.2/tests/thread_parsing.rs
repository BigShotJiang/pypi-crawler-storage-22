// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas
// Integration test to ensure string fields containing JSON are parsed
// into proper JSON arrays/objects when producing JSON output.

use serde_json::Value;

#[test]
fn thread_comments_parsed_to_json_array() {
    use agentdsl::ast::*;
    use agentdsl::json::to_json;

    // Define a `thread` schema matching the user's sample
    let schema = SchemaBlock {
        id: 0,
        label: "thread".to_string(),
        fields: vec![
            SchemaField { name: "ID".to_string(), field_type: DslType::Int },
            SchemaField { name: "author".to_string(), field_type: DslType::Str },
            SchemaField { name: "comments".to_string(), field_type: DslType::Str },
            SchemaField { name: "likes".to_string(), field_type: DslType::Int },
            SchemaField { name: "post_id".to_string(), field_type: DslType::Str },
            SchemaField { name: "text".to_string(), field_type: DslType::Str },
            SchemaField { name: "ts".to_string(), field_type: DslType::Int },
        ],
    };

    // Sample comments JSON encoded as a string (two comments)
    let comments_json = r#"[{"id":"c-2-0","text":"Comment 0 on post 2","ts":1610000120,"user":"user72"},{"id":"c-2-1","text":"Comment 1 on post 2","ts":1610000121,"user":"user1"}]"#;

    let record = vec![
        "3".to_string(),
        "user22".to_string(),
        comments_json.to_string(),
        "278".to_string(),
        "post-2".to_string(),
        "This is a simulated post number 2".to_string(),
        "1610000120".to_string(),
    ];

    let data = DataBlock { schema_label: Some("thread".to_string()), records: vec![record] };

    let messages = vec![AgentMessage::Schema(schema), AgentMessage::Data(data)];

    let out = to_json(&messages);

    // Ensure top-level `thread` key exists and is an array with one object
    let threads = out.get("thread").and_then(|v| v.as_array()).expect("thread array");
    assert_eq!(threads.len(), 1);

    let first = threads[0].as_object().expect("thread object");

    // `comments` should be parsed into a JSON array (not a string)
    let comments = first.get("comments").expect("comments present");
    match comments {
        Value::Array(a) => {
            assert_eq!(a.len(), 2);
            assert_eq!(a[0].get("id").and_then(|v| v.as_str()).unwrap(), "c-2-0");
            assert_eq!(a[1].get("id").and_then(|v| v.as_str()).unwrap(), "c-2-1");
        }
        other => panic!("comments is not an array: {:?}", other),
    }
}
