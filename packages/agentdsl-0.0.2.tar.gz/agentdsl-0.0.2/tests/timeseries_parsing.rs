// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Khaled Abbas
// Test that a top-level object-of-arrays like { "timeseries": { "SYM-Z70": [ ... ] } }
// is parsed into discovered schemas/data for the inner key (`SYM-Z70`).

use serde_json::Value;

#[test]
fn parse_timeseries_object_of_arrays() {
    use agentdsl::json::from_json;
    use agentdsl::ast::*;

    let json_str = r#"
    {
      "timeseries": {
        "SYM-Z70": [
          {"ts":1609459200,"price":74.45,"vol":9529},
          {"ts":1609459260,"price":74.11,"vol":8746}
        ]
      }
    }
    "#;

    let v: Value = serde_json::from_str(json_str).expect("valid json");
    let msgs = from_json(&v).expect("from_json ok");

    // Expect at least a Schema and a Data message for the inner key `SYM-Z70`
    let mut found_schema = None;
    let mut found_data = None;

    for m in msgs {
        match m {
            AgentMessage::Schema(s) if s.label == "SYM-Z70" => found_schema = Some(s),
            AgentMessage::Data(d) if d.schema_label.as_deref() == Some("SYM-Z70") => found_data = Some(d),
            _ => {}
        }
    }

    assert!(found_schema.is_some(), "schema for SYM-Z70 should be discovered");
    let schema = found_schema.expect("schema available");
    let data = found_data.expect("data for SYM-Z70 should be discovered");

    // Two records expected
    assert_eq!(data.records.len(), 2);

    // Determine column indices from the discovered schema rather than assuming order.
    let price_idx = schema.fields.iter().position(|f| f.name == "price").expect("price field");
    let vol_idx = schema.fields.iter().position(|f| f.name == "vol").expect("vol field");

    // Rows correspond to schema.fields order directly (ID included), so use same indices
    let first_row = &data.records[0];
    assert!(first_row.len() > price_idx, "row has enough columns");
    assert_eq!(first_row[price_idx], "74.45");
    assert_eq!(first_row[vol_idx], "9529");
}
