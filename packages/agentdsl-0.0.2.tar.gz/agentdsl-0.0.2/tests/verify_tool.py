# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Khaled Abbas

import agentdsl
from typing import Optional, List, Tuple, TypedDict

class WeatherResult(TypedDict):
    TEMPERATURE: str
    CONDITION: str

@agentdsl.tool
def get_weather(city: str, forecast_days: int = 1) -> WeatherResult:
    """Get weather for a city"""
    return {"TEMPERATURE": "25C", "CONDITION": "Sunny"}

class StockResult(TypedDict):
    PRICE: float
    CHANGE: float
    CHANGE_PERCENT: float

@agentdsl.tool
def get_stock(symbol: str) -> StockResult:
    """Get stock price for a symbol"""
    return {"PRICE": 150.25, "CHANGE": 2.5, "CHANGE_PERCENT": 1.7}

class NewsResult(TypedDict):
    TITLE: str
    URL: str
    SOURCE: str

@agentdsl.tool
def get_news(category: str, country: str = "US") -> List[NewsResult]:
    """Get news for a category"""
    return [
        {"TITLE": "AI Revolution", "URL": "https://news.com/ai", "SOURCE": "TechNews"},
        {"TITLE": "Market Update", "URL": "https://news.com/market", "SOURCE": "FinanceWire"}
    ]

class Details(TypedDict):
    HUMIDITY: str
    UV_INDEX: int

class ComplexResult(TypedDict):
    CITY: str
    DETAILS: Details

@agentdsl.tool
def get_complex_data() -> List[ComplexResult]:
    """Get complex nested data"""
    return [
        {"CITY": "Paris", "DETAILS": {"HUMIDITY": "60%", "UV_INDEX": 5}},
        {"CITY": "London", "DETAILS": {"HUMIDITY": "80%", "UV_INDEX": 2}}
    ]

@agentdsl.tool
def get_raw_json() -> str:
    """Get a raw JSON string"""
    return '{"key": "value", "status": "ok"}'

def run_scenario(func, *args, **kwargs):
    print("\n" + "="*50)
    print(f" SCENARIO: {func.__name__.upper()} ")
    print("="*50)
    
    print("\n[DEFINITION]")
    print(func.__agentdsl__.strip())
    
    print("\n[EXECUTION]")
    try:
        result = func(*args, **kwargs)
        print(f"Function called with: args={args}, kwargs={kwargs}")
        print(f"Python Result: {result}")
        
        print("\n[SERIALIZED RESULT DSL]")
        dsl_result = agentdsl.serialize_result(func, result)
        print(dsl_result.strip())
    except Exception as e:
        print(f"Python Error: {e}")
        print("\n[SERIALIZED ERROR DSL]")
        dsl_error = agentdsl.serialize_result(func, None, status="ERROR", error=str(e))
        print(dsl_error.strip())

if __name__ == "__main__":
    print("AgentDSL Real-World Scenario Simulation")
    
    # Scenario 1: Successful Weather Call
    run_scenario(get_weather, "New York", forecast_days=3)
    
    # Scenario 2: Stock Price Call
    run_scenario(get_stock, "AAPL")
    
    # Scenario 3: News Call
    run_scenario(get_news, "technology")

    # Scenario 4: Complex Nested Data (Relational)
    run_scenario(get_complex_data)

    # Scenario 5: Raw JSON String
    run_scenario(get_raw_json)
    
    # Scenario 6: Error Handling
    print("\n=== Scenario: Error Case ===")
    dsl_error = agentdsl.serialize_result(get_weather, None, status="ERROR", error="City not found")
    print(dsl_error)

    # Scenario 7: Native JSON Conversion (DSL -> JSON)
    print("\n" + "="*50)
    print(" SCENARIO: NATIVE JSON (DSL -> JSON) ")
    print("="*50)
    complex_dsl = get_complex_data.__agentdsl__ + "\n" + agentdsl.serialize_result(get_complex_data, get_complex_data())
    native_json = agentdsl.to_json(complex_dsl)
    import json
    print(json.dumps(native_json, indent=2))

    # Scenario 8: Native JSON Conversion (JSON -> DSL)
    print("\n" + "="*50)
    print(" SCENARIO: NATIVE JSON (JSON -> DSL) ")
    print("="*50)
    test_json = {
        "USERS": [
            {
                "ID": 1,
                "NAME": "Alice",
                "SCORE": 100,
                "ORDERS": [
                    {"ORDER_ID": "A101", "TOTAL": 50.0},
                    {"ORDER_ID": "A102", "TOTAL": 25.5}
                ]
            },
            {
                "ID": 2,
                "NAME": "Bob",
                "SCORE": 95,
                "ORDERS": [
                    {"ORDER_ID": "B201", "TOTAL": 10.99}
                ]
            },
            {
                "ID": 3,
                "NAME": "Charlie",
                "SCORE": 80,
                "ORDERS": [] # Testing empty nested list
            }
        ]
    }       
    inferred_dsl = agentdsl.from_json(test_json)
    print(inferred_dsl)
