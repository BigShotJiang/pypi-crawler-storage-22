"""
Resource namespace for AgentFoundry.
Contains configuration templates and static resource files.
"""

# Empty init to ensure resources is treated as a package by setuptools
__all__ = []