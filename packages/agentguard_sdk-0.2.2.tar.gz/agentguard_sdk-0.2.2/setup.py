"""Setup script for AgentGuard Python SDK."""

from setuptools import setup

# This file is kept for backward compatibility
# All configuration is in pyproject.toml
setup()
