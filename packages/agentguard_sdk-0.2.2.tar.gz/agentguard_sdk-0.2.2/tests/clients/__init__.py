"""Tests for guarded clients."""
