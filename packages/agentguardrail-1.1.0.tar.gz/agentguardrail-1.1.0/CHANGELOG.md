# Changelog

All notable changes to AgentGate will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- MCP security gateway (proxy for downstream MCP servers)
- Approval workflows (Slack, email, webhook)
- Multi-agent session orchestration
- SIEM/SOAR export (Splunk, Datadog, Sentinel)
- TypeScript/JavaScript native SDK
- Fine-tuned domain-specific NLP models
- Multi-language intent detection

## [1.1.0] - 2026-02-17

### Added
- **🧠 NLP Semantic Matching Engine** — sentence embeddings via fastembed (BAAI/bge-small-en-v1.5 ONNX model)
  - 20 semantic intent categories (payment, delete, admin, posting, messaging, sharing, etc.)
  - Cosine similarity classification with configurable confidence threshold (≥0.65)
  - Runs entirely on CPU (~67 MB model), zero API keys, ~2ms per classification
  - Custom intent support — add/remove intents at runtime
  - Optional install: `pip install agentguardrail[nlp]`
- **3-Layer Intent Detection Pipeline** — keywords → phonetic → semantic NLP
  - Layer 1: Exact keyword/substring matching (12 categories, 200+ synonyms)
  - Layer 2: Phonetic matching (catches typos & morphological variants)
  - Layer 3: NLP semantic matching (understands meaning of novel phrases)
- **Smart Intent Matching** — 12 intent categories with 200+ keyword synonyms
- **Phonetic Matching Engine** — custom phonetic encoder for typo-resilient detection
- **Semantic risk classification** — CRITICAL/HIGH/MEDIUM/LOW mapping for all 20 intent categories
- **MCP module scaffold** — `agentgate.mcp` package ready for v2.0 gateway features

### Fixed
- Phonetic prefix matching false positives (min 4-char code requirement)
- Neutral text misclassification ("click" no longer matches "cancel")

### Changed
- Risk auto-detection now uses 3-layer pipeline instead of simple keyword lists
- Updated README with NLP documentation, architecture diagram, and code examples
- fastembed + numpy added as optional `[nlp]` dependencies

## [1.0.0] - 2026-02-17

### Added
- **First public PyPI release** 🎉
- **Hardened licensing system** with enterprise-grade anti-tamper protection
  - Clock rollback detection (NTP + monotonic elapsed tracking)
  - File integrity seal (HMAC-SHA256 on all fields)
  - Deletion-resistant breadcrumb (secondary OS-specific storage)
  - Machine fingerprint binding (hardware-bound licenses)
  - PBKDF2-derived signing keys (not stored as plaintext)
- **License CLI commands** — `agentgate license status|activate|deactivate`
- **Sidecar license endpoints** — `/api/v1/license/status`, `/api/v1/license/activate`
- **Feature gating decorators** — `@require_feature()`, `@require_tier()`
- **Docker support** — Dockerfile + docker-compose.yml
- **Agent framework test scripts** — OpenAI, Anthropic, Google ADK, LangChain, CrewAI
- **Demo script** — `demo.py` for quick testing
- **Separate PyPI description** — `PYPI_README.md` for public-facing docs
- 137 tests (91 core + 46 licensing)

## [0.1.0] - 2025-01-01

### Added

#### Core Engine
- **Policy Engine** with YAML-based rules, URL/element/action matching, and regex support
- **15 Action Types**: navigate, click, type, submit, download, upload, copy, paste, evaluate_js, screenshot, cookie_access, set_header, request_intercept, dialog_handle, frame_navigate
- **5 Risk Levels**: critical, high, medium, low, info — with automatic risk classification
- **4 Decision Types**: allow, block, require_approval, audit_only
- Policy presets: `finance-safe`, `readonly`, `permissive`, `procurement-safe`, `support-agent`
- Most-restrictive-wins evaluation across multiple loaded policies

#### Browser Interceptor
- `InterceptedPage` wrapping Playwright's Page with policy enforcement
- Every `goto()`, `click()`, `fill()`, `type()`, `evaluate()` intercepted
- `ActionBlockedError` and `ApprovalRequiredError` exceptions
- Auto-classification of element text to risk levels

#### Evidence Vault
- Tamper-evident hash-chained evidence records (SHA-256)
- `EvidenceSession` with start/end, per-agent-id tracking
- JSONL storage with integrity verification
- Session listing, replay, and export (JSON)

#### Capability Tokens
- Scoped, time-bound permission tokens
- Domain, URL, action type, and element text restrictions
- Rate limiting (per-minute and total actions)
- HMAC-SHA256 signing and verification
- Token revocation support

#### Sidecar Service (OpenClaw Integration)
- FastAPI REST API with 16 endpoints
- `/api/v1/evaluate` — single action evaluation
- `/api/v1/evaluate/batch` — batch preflight checks
- `/api/v1/sessions` — evidence session management
- `/api/v1/tokens` — capability token CRUD
- `/api/v1/policies` — policy listing and loading
- `/api/v1/health` — health check
- Python SDK: `AgentGateClient` (sync) and `AsyncAgentGateClient`

#### CLI
- `agentgate init` — project scaffolding
- `agentgate policies list|show|verify` — policy management
- `agentgate sessions list|replay|verify|export` — evidence management
- `agentgate sidecar` — start the sidecar service
- `agentgate dashboard` — launch web dashboard
- `agentgate version` — version info

#### Dashboard
- FastAPI web dashboard on port 7860
- Session list, session detail, replay, statistics
- Policy browser and chain integrity verification

#### OpenClaw Skill
- Ready-to-use skill package (`skills/agentgate/`)
- `SKILL.md` with full instructions for OpenClaw
- Default and strict policy presets for OpenClaw

#### Documentation
- Comprehensive README with quickstart guide
- Non-technical user guide (`docs/GUIDE.md`)
- Architecture deep-dive (`docs/ARCHITECTURE.md`)
- Operations guide (`docs/OPERATIONS.md`)
- Agent compatibility matrix (`docs/AGENTS.md`)
- Contributing guidelines (`CONTRIBUTING.md`)
- Security policy (`SECURITY.md`)

#### Examples
- `basic_usage.py` — minimal working example
- `capability_tokens.py` — token creation and validation
- `custom_policies.py` — writing custom YAML policies
- `evidence_vault.py` — recording and verifying evidence
- `openclaw_integration.py` — sidecar + SDK usage
- `policy_testing.py` — testing policies programmatically

[Unreleased]: https://github.com/Nitin-100/agentgate/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/Nitin-100/agentgate/releases/tag/v0.1.0
