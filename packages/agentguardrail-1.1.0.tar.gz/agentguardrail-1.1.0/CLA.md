# AgentGate Individual Contributor License Agreement (CLA)

Thank you for your interest in contributing to AgentGate. This Contributor License Agreement ("Agreement") documents the rights granted by contributors to the AgentGate project.

## 1. Definitions

**"You"** means the individual who Submits a Contribution to the Project.

**"Contribution"** means any work of authorship, including code, documentation, or other material Submitted by You to the Project.

**"Submit"** means any form of communication sent to the Project, including but not limited to pull requests, issues, commits, and messages on project communication channels.

**"Project"** means the AgentGate software project maintained at https://github.com/Nitin-100/agentgate.

## 2. Grant of Rights

### 2.1 Copyright License

You hereby grant to the Project maintainers and to recipients of software distributed by the Project a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare derivative works of, publicly display, publicly perform, sublicense, and distribute Your Contributions and such derivative works.

### 2.2 Patent License

You hereby grant to the Project maintainers and to recipients of software distributed by the Project a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Contribution, where such license applies only to those patent claims licensable by You that are necessarily infringed by Your Contribution(s) alone or by combination of Your Contribution(s) with the Project to which such Contribution(s) was submitted.

## 3. Representations

You represent that:

- (a) You are legally entitled to grant the above license. If your employer(s) has rights to intellectual property that you create that includes your Contributions, you have received permission to make Contributions on behalf of that employer, or your employer has waived such rights.

- (b) Each of Your Contributions is Your original creation. You represent that Your Contribution submissions include complete details of any third-party license or other restriction of which you are aware and which are associated with any part of Your Contributions.

- (c) Your Contribution does not violate any existing agreement or obligation you have with any third party.

## 4. Support

You are not expected to provide support for Your Contributions, except to the extent You desire to provide support. You may provide support for free, for a fee, or not at all.

## 5. No Obligation

You understand that the decision to include Your Contribution in any project or distribution is entirely at the discretion of the Project maintainers, and this agreement does not obligate the Project to use Your Contribution.

## 6. Agreement

By submitting a Contribution to the Project, You agree to the terms of this Contributor License Agreement.

---

## How to Sign

### For Individual Contributors

When you submit your first Pull Request, the CLA bot will automatically check if you've signed. If not, follow these steps:

1. Read this agreement carefully
2. Reply to the CLA bot comment with: **"I have read the CLA Document and I hereby sign the CLA"**
3. Your signature will be recorded and all future PRs will be auto-approved

### For Corporate Contributors

If you're contributing on behalf of your company, please contact us at **cla@agentgate.dev** to set up a Corporate CLA.

---

## Developer Certificate of Origin (DCO)

In addition to the CLA, all commits should be signed off using the DCO:

```
Signed-off-by: Your Name <your.email@example.com>
```

Use `git commit -s` to automatically add this. The DCO certifies that you wrote the code or have the right to submit it. See [developercertificate.org](https://developercertificate.org/) for the full text.
