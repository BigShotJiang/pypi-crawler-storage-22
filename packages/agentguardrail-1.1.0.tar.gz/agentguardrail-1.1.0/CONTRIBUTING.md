# Contributing to AgentGate

Thank you for your interest in contributing to AgentGate! 🛡️

## Quick Start

```bash
# Clone the repo
git clone https://github.com/Nitin-100/agentgate.git
cd agentgate

# Install in development mode
pip install -e ".[dev]"

# Install Playwright browsers
playwright install chromium

# Run tests
pytest -v

# Run linting
ruff check .
ruff format --check .
mypy agentgate/
```

## Development Setup

### Prerequisites
- Python 3.11+
- Git

### Environment Setup
```bash
python -m venv .venv
.venv\Scripts\activate    # Windows
source .venv/bin/activate  # macOS/Linux

pip install -e ".[dev]"
playwright install chromium
```

## How to Contribute

### Reporting Bugs

1. Check existing issues first
2. Use the bug report template
3. Include: OS, Python version, AgentGate version, steps to reproduce

### Suggesting Features

1. Open a GitHub Discussion first
2. Describe the use case, not just the solution
3. Consider backward compatibility

### Submitting Code

1. **Fork** the repository
2. **Create a branch**: `git checkout -b feature/my-feature`
3. **Make changes** with tests
4. **Run tests**: `pytest -v`
5. **Lint**: `ruff check . && ruff format .`
6. **Commit**: Use conventional commits (`feat:`, `fix:`, `docs:`, `test:`)
7. **Push** and open a **Pull Request**

## Code Style

- **Formatter**: Ruff (line length 100)
- **Type hints**: Required on all public APIs
- **Docstrings**: Google style
- **Naming**: snake_case for functions/variables, PascalCase for classes

## Architecture Overview

```
agentgate/
├── policy/        # Policy engine — evaluate actions against rules
├── evidence/      # Evidence vault — tamper-evident audit trails
├── tokens/        # Capability tokens — scoped permissions
├── interceptor/   # Browser interceptor — Playwright wrapper
├── dashboard/     # Web dashboard — FastAPI + embedded UI
├── cli.py         # CLI — Click commands
└── runner.py      # Runner — main developer API
```

### Key Design Principles

1. **Intercept, don't block by default** — Everything is audited, policies decide what's blocked
2. **Hash chains for integrity** — Every evidence record links to the previous one
3. **YAML-first policies** — Easy to read, write, and version control
4. **Zero-config defaults** — Should work out of the box with sensible defaults
5. **Composable** — Each module works independently or together

## Writing Policies

New policy contributions go in `policies/`. Follow this template:

```yaml
name: my-policy
description: What this policy does
version: "1.0"
max_risk: medium

url_rules:
  - pattern: "https://example\\.com/.*"
    decision: allow
    reason: "Main domain allowed"

element_rules:
  - text_pattern: "(?i)dangerous"
    decision: block
    reason: "Dangerous actions blocked"

action_rules:
  - action_type: evaluate_js
    decision: block
    reason: "No JS execution"
```

### Policy Testing

Always include test scenarios:

```python
from agentgate.policy.engine import PolicyEngine, ActionEvent, ActionType, Decision

engine = PolicyEngine()
engine.load_policy_file("policies/my-policy.yaml")

event = ActionEvent(
    action_type=ActionType.CLICK,
    url="https://example.com/page",
    element_text="Submit",
)
result = engine.evaluate(event)
assert result.decision == Decision.ALLOW
```

## Writing Tests

- Use `pytest` with `pytest-asyncio` for async tests
- Place tests in `tests/` mirroring the source structure
- Aim for >80% coverage on new code
- Test both happy paths and edge cases

```python
# Sync test
def test_my_feature():
    ...

# Async test
@pytest.mark.asyncio
async def test_my_async_feature():
    ...
```

## Release Process

1. Update version in `pyproject.toml`
2. Update CHANGELOG.md
3. Create a git tag: `git tag v0.x.x`
4. Push tag: `git push origin v0.x.x`
5. GitHub Actions will publish to PyPI

## Community

- **GitHub Issues**: Bug reports and feature requests
- **GitHub Discussions**: Questions and ideas
- **Discord**: Coming soon

## Contributor License Agreement (CLA)

All contributors must sign our [Contributor License Agreement](CLA.md) before their first PR can be merged. This is a one-time process:

1. Submit your Pull Request
2. The CLA bot will check if you've signed
3. If not, reply to the bot with: **"I have read the CLA Document and I hereby sign the CLA"**
4. All future PRs are auto-approved

Additionally, all commits should include a DCO sign-off:

```bash
git commit -s -m "feat: my awesome feature"
# Adds: Signed-off-by: Your Name <your.email@example.com>
```

## License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0. See [LICENSE](LICENSE) for the full text.

## Security

If you discover a security vulnerability, **do NOT open a public issue**. See [SECURITY.md](SECURITY.md) for responsible disclosure instructions.

---

Thank you for helping make AI agents safer! 🚀
