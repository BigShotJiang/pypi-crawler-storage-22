# 🛡️ AgentGuardRail — The Execution Firewall for AI Agents

**Control what AI agents can do. Prove what they did.**

[![Python 3.11+](https://img.shields.io/pypi/pyversions/agentguardrail)](https://pypi.org/project/agentguardrail/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-green)](https://github.com/Nitin-100/agentgate/blob/master/LICENSE)

---

AI agents can now click buttons, fill forms, make payments, and take real actions on websites. **AgentGate is the missing security layer** — it sits between your agent and the browser, enforcing policies on every single action before it happens.

**New in v1.1:** 🧠 NLP-powered intent detection — understands the *meaning* of agent actions, not just keywords.

## Why AgentGate?

| What happens today | With AgentGate |
|---|---|
| Agent clicks "Pay $5,000" | 🛡️ **Blocked** — payment actions are policy-controlled |
| Agent exports customer PII | 🛡️ **Requires approval** — sensitive actions need human sign-off |
| "What did the agent do?" — nobody knows | 🛡️ **Tamper-proof evidence vault** — every action recorded with hash chain |
| Agent has unlimited access | 🛡️ **Capability tokens** — scoped, time-bound, revocable permissions |

## Works With Every AI Agent Framework

AgentGate is **framework-agnostic**. Drop it into any agent stack in under 5 minutes:

| Framework | Integration | Status |
|---|---|---|
| **OpenClaw** | Built-in skill + sidecar | ✅ First-class support |
| **OpenAI** (GPT-4, CUA) | Python SDK / REST API | ✅ Tested |
| **Anthropic** (Claude, Computer Use) | Python SDK / REST API | ✅ Tested |
| **Google ADK** | Python SDK / REST API | ✅ Tested |
| **LangChain** | Python SDK / REST API | ✅ Tested |
| **CrewAI** | Python SDK / REST API | ✅ Tested |
| **browser-use** | Python SDK | ✅ Tested |
| **Any HTTP client** | REST API on port 18790 | ✅ Universal |

### 🦞 First-Class OpenClaw Support

AgentGate ships with a ready-to-use **OpenClaw skill** — just drop the `skills/agentgate/` folder into your OpenClaw workspace and every browser action is automatically policy-checked. No code changes needed.

```bash
# Start AgentGate sidecar
agentgate sidecar --policy finance-safe

# OpenClaw automatically checks every action through AgentGate
```

## Install

```bash
pip install agentguardrail
```

**Want NLP-powered intent detection?** (~67 MB model, CPU-only, zero API keys):

```bash
pip install agentguardrail[nlp]
```

## Quick Start — 3 Lines to Secure Your Agent

```python
from agentgate.sidecar.client import AgentGateClient

gate = AgentGateClient()  # Connects to sidecar on localhost:18790

# Before your agent clicks anything:
result = gate.check_click("https://bank.com", "Pay Now", "button.pay")
# result.decision → "block" (payment actions blocked by policy)
```

Or use the **full browser wrapper** for automatic enforcement:

```python
from agentgate import SecureBrowser

async with SecureBrowser(policy="finance-safe") as browser:
    page = await browser.new_page()
    await page.goto("https://example.com")    # ✅ Allowed
    await page.click("button#pay")            # 🚫 Blocked automatically
```

## How It Works

```
Your AI Agent (OpenClaw / GPT-4 / Claude / LangChain / any)
    ↓  every action passes through AgentGate
┌──────────────────────────────────────┐
│  🛡️ AgentGate Firewall              │
│                                      │
│  1. Action Interceptor               │  ← Catches every click, type, navigate
│  2. Policy Engine (3-layer matching) │  ← Keywords → Phonetic → NLP Semantic
│  3. Evidence Vault (hash-chained)    │  ← Tamper-proof audit trail
│  4. Capability Tokens (scoped)       │  ← Time-bound, revocable permissions
└──────────────────────────────────────┘
    ↓  only allowed actions reach the browser
Target Website / Application
```

## Policies — Simple YAML, Powerful Control

```yaml
name: finance-safe
description: Allow reading, block all payments

rules:
  - action: click
    block_elements:
      - text_contains: ["Pay", "Transfer", "Delete"]
        risk: high
    require_approval:
      - text_contains: ["Submit", "Confirm"]
        risk: medium

  - action: navigate
    block:
      - pattern: "*/admin/*"
      - pattern: "*/payments/*"
```

**Built-in presets:** `finance-safe`, `readonly`, `permissive`, `procurement-safe`, `support-agent`

## Key Features

### 🧠 NLP Intent Detection *(new in v1.1)*
- **3-layer matching pipeline:** exact keywords → phonetic codes → semantic NLP
- **20 intent categories** — payment, delete, admin, posting, messaging, sharing, and more
- Understands novel phrases: "Process Transaction" → payment intent → HIGH risk
- Catches typos: "Chekout" → matches "checkout" via phonetic codes
- Runs on **CPU** (~67 MB ONNX model), **zero API keys**, ~2ms per classification
- Add custom intents at runtime

### 🔒 Policy Engine
- **15 action types** intercepted (click, type, navigate, download, JS eval, etc.)
- **5 risk levels** with automatic classification
- YAML-based rules — version-controlled, human-readable
- Most-restrictive-wins across multiple policies

### 📋 Evidence Vault
- **SHA-256 hash-chained** evidence records — tamper-evident by design
- Every action recorded: what, where, when, who, decision, fingerprint
- Session-based tracking with export and replay
- Holds up to compliance and audit requirements

### 🎟️ Capability Tokens
- Scoped permissions: limit by domain, URL pattern, action type, element text
- Time-bound: tokens auto-expire (minutes, hours, or days)
- Rate-limited: max actions per minute, max total actions
- HMAC-signed and revocable

### 🔌 Sidecar REST API
- FastAPI service on port 18790 — works with any language or framework
- 16 endpoints: evaluate, batch check, sessions, tokens, policies, health
- Python SDK included: `AgentGateClient` (sync) and `AsyncAgentGateClient`

## CLI

```bash
agentgate init                         # Scaffold a new project
agentgate sidecar --policy finance-safe  # Start the sidecar API
agentgate policies list                # View loaded policies
agentgate sessions list                # View evidence sessions
agentgate license status               # Check your license tier
```

## Licensing

| Tier | Price | What You Get |
|---|---|---|
| **Community** | Free forever | Core engine, 2 policies, basic sidecar |
| **Trial** | Free 24 hours | All features unlocked — starts automatically |
| **Pro** | $49/month | Unlimited policies, evidence vault, tokens, webhooks |
| **Enterprise** | $199/month | Everything + SSO, priority support, 365-day audit logs |

```bash
# First install → 24-hour trial starts automatically (all features)
pip install agentguardrail

# After trial → free Community tier continues working
# Upgrade anytime:
agentgate license activate YOUR-LICENSE-KEY
```

## Security

AgentGate's licensing includes **enterprise-grade anti-tamper protection**:
- 🔐 Clock rollback detection (NTP + monotonic tracking)
- 🔐 File integrity seal (HMAC-SHA256)
- 🔐 Machine-bound fingerprint
- 🔐 Deletion-resistant breadcrumb storage
- 🔐 PBKDF2-derived signing keys

## Links

- **GitHub:** [github.com/Nitin-100/agentgate](https://github.com/Nitin-100/agentgate)
- **Docs:** [User Guide](https://github.com/Nitin-100/agentgate/tree/master/docs)
- **Issues:** [Report a bug](https://github.com/Nitin-100/agentgate/issues)
- **Changelog:** [CHANGELOG.md](https://github.com/Nitin-100/agentgate/blob/master/CHANGELOG.md)

## License

Apache 2.0 — free to use, modify, and distribute. See [LICENSE](https://github.com/Nitin-100/agentgate/blob/master/LICENSE).

---

**🛡️ AgentGate — Because AI agents shouldn't have unlimited power.**
