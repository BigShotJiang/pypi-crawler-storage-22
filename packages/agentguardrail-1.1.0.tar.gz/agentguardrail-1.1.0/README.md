<p align="center">
  <h1 align="center">🛡️ AgentGate</h1>
  <p align="center">
    <strong>The open-source execution firewall for AI agents.</strong>
  </p>
  <p align="center">
    Control what agents can do. Prove what they did.
  </p>
  <p align="center">
    <a href="https://pypi.org/project/agentguardrail/"><img src="https://img.shields.io/pypi/v/agentguardrail?color=blue&label=PyPI" alt="PyPI"></a>
    <a href="https://pypi.org/project/agentguardrail/"><img src="https://img.shields.io/pypi/pyversions/agentguardrail" alt="Python"></a>
    <a href="https://github.com/Nitin-100/agentgate/blob/master/LICENSE"><img src="https://img.shields.io/badge/License-Apache%202.0-green" alt="License"></a>
  </p>
  <p align="center">
    <a href="#quickstart">Quickstart</a> •
    <a href="#how-it-works">How It Works</a> •
    <a href="#-test-with-any-ai-agent">Try It</a> •
    <a href="#openclaw-integration">OpenClaw</a> •
    <a href="#policies">Policies</a> •
    <a href="#evidence-vault">Evidence</a> •
    <a href="#dashboard">Dashboard</a> •
    <a href="#-licensing--pricing">Pricing</a> •
    <a href="#-documentation">Docs</a> •
    <a href="#contributing">Contributing</a>
  </p>
</p>

---

> **AI agents can now click buttons, fill forms, make payments, and take real actions.**  
> **AgentGate makes sure they only do what they're allowed to — and proves it.**

## ⚡ TL;DR — What Is AgentGate?

**AgentGate** is a security firewall that sits between your AI agent and the browser/application. It intercepts every action (click, type, navigate) and enforces your policies in real-time.

**Who needs this?** Anyone building or deploying AI agents that interact with real websites, internal tools, or customer-facing applications.

| Use Case | Without AgentGate | With AgentGate |
|---|---|---|
| AI agent clicks "Pay Now" | 💸 Uncontrolled | 🛡️ Blocked by policy |
| Agent exports customer data | 📤 No protection | 🛡️ Requires approval |
| Agent tries "Process Transaction" | 🤷 Unknown intent | 🧠 NLP detects financial action |
| Proving what agent did | 📋 Basic logs | 🛡️ Tamper-proof evidence vault |
| Limiting agent permissions | ❌ None | 🛡️ Scoped, time-bound tokens |

**Works with:** OpenAI, Anthropic, Google ADK, LangChain, CrewAI, browser-use, and any Python agent framework.  
**Powered by:** 🧠 NLP sentence embeddings — understands intent, not just keywords.

---

## The Problem

AI agents (browser-use, OpenAI CUA, Anthropic computer-use, etc.) can now operate websites like humans. They click, type, navigate, and submit. But there's **no control layer**:

- ❌ No way to block an agent from clicking "Pay Now"
- ❌ No way to prevent data exports or downloads
- ❌ No tamper-proof audit trail of what happened
- ❌ No scoped, time-bound permissions

**AgentGate fixes this.** It sits between your AI agent and the browser, enforcing policies on every single action.

## How AgentGate Is Different

| Existing Tools | AgentGate |
|---|---|
| Prompt/text filtering | **Action-level enforcement** |
| API call monitoring | **UI click/type/navigate control** |
| Keyword-only matching | **NLP semantic understanding** |
| Logs only | **Tamper-evident evidence chain** |
| Coarse permissions | **Scoped capability tokens** |
| Detection | **Prevention** |

## Architecture

```
AI Agent
    ↓
┌──────────────────────────────────┐
│        AgentGate Runtime         │
│                                  │
│  ┌────────────────────────────┐  │
│  │   Action Interceptor      │  │  ← Hooks every click, type, navigate
│  └────────────┬───────────────┘  │
│               ↓                  │
│  ┌────────────────────────────┐  │
│  │      Policy Engine        │  │  ← ALLOW / BLOCK / REQUIRE_APPROVAL
│  │                            │  │
│  │  Layer 1: Keyword Match    │  │  ← Exact synonyms (200+ terms)
│  │  Layer 2: Phonetic Match   │  │  ← Catches typos & inflections
│  │  Layer 3: NLP Semantic     │  │  ← Sentence embeddings (AI)
│  └────────────┬───────────────┘  │
│               ↓                  │
│  ┌────────────────────────────┐  │
│  │    Evidence Vault          │  │  ← Tamper-evident audit trail
│  └────────────┬───────────────┘  │
│               ↓                  │
│  ┌────────────────────────────┐  │
│  │   Capability Tokens        │  │  ← Scoped, time-bound permissions
│  └────────────────────────────┘  │
└──────────────────────────────────┘
    ↓
Target Website / Application
```

## Quickstart

### Install

```bash
pip install agentguardrail
playwright install chromium
```

**Want NLP-powered intent detection?** Install with the `nlp` extra:

```bash
pip install agentguardrail[nlp]
```

This adds sentence-embedding AI (~67 MB model, runs 100% on CPU, no GPU needed) that can understand the **meaning** of any agent action — not just keyword matches.

### Initialize a Project

```bash
agentgate init
```

This creates:
- `policies/` — YAML policy files
- `sample_agent.py` — working example
- `agentgate_evidence/` — evidence storage

### Run Your First Secure Agent

```python
import asyncio
from agentgate import SecureBrowser
from agentgate.interceptor.browser import ActionBlockedError

async def main():
    async with SecureBrowser(policy="finance-safe") as browser:
        page = await browser.new_page()

        # ✅ Reading is allowed
        await page.goto("https://example.com")
        print(await page.title())

        # 🚫 Payment actions are BLOCKED
        try:
            await page.click("button#pay")
        except ActionBlockedError as e:
            print(f"Blocked: {e}")

asyncio.run(main())
```

**That's it.** Your agent can read but can never pay, delete, or export.

## Policies

Policies are simple YAML files that define what an agent can and cannot do:

```yaml
name: finance-safe
description: Allow reading invoices, block all payment actions

block_js_evaluation: true
block_clipboard: true
max_actions_per_minute: 60

rules:
  - action: navigate
    block:
      - pattern: "*/admin/*"
      - pattern: "*/payments/*"

  - action: click
    block_elements:
      - text_contains: ["Pay", "Transfer", "Delete"]
        risk: high
    require_approval:
      - text_contains: ["Submit", "Confirm"]
        risk: medium

  - action: type
    block_elements:
      - selector: "input[type='password']"
      - selector: "input[name='credit_card']"
```

### Built-in Presets

| Policy | Description |
|---|---|
| `finance-safe` | Read financial data, block payments |
| `readonly` | No clicks, typing, or downloads |
| `permissive` | Block only critical-risk actions |

### Risk Auto-Detection — 3-Layer Intelligent Matching

AgentGate uses a **3-layer intent detection engine** to understand what an agent is actually trying to do — even if the UI text doesn't contain obvious keywords.

#### Layer 1 — Keyword Matching
Exact synonyms and substring matching across **12 intent categories** with **200+ terms**:
- **payment**: pay, checkout, purchase, transfer, billing, invoice …
- **delete**: remove, erase, destroy, drop, purge, wipe …
- **admin**: administrator, root access, superuser, sudo …
- And 9 more categories.

#### Layer 2 — Phonetic Matching
Catches **typos and morphological variants** that keywords miss:
- "Chekout" → matches "checkout" (same phonetic code)
- "Purchasing" → matches "purchase" (prefix match)
- "Transfering" → matches "transfer"

#### Layer 3 — NLP Semantic Matching *(optional, install with `[nlp]`)*
Uses **sentence embeddings** (BAAI/bge-small-en-v1.5 ONNX model) to understand the **meaning** of any action text — even completely novel phrases:

| Agent Action Text | Detected Intent | Risk |
|---|---|---|
| "Process Transaction" | payment | 🔴 HIGH |
| "Purge All Records" | destructive_system | 🔴 CRITICAL |
| "Grant Admin Privileges" | permission | 🔴 HIGH |
| "Post a Comment" | posting | 🟡 MEDIUM |
| "Share on Twitter" | sharing | 🟡 MEDIUM |
| "Download Backup" | downloading | 🟡 MEDIUM |
| "View Dashboard" | navigation | 🟢 LOW |

**20 semantic intent categories**: payment, delete, authentication, admin, posting, messaging, sharing, modifying, downloading, uploading, financial, permission, social, system, data_entry, sensitive_field, navigation, api_call, destructive_system, and confirm.

The NLP layer runs **entirely on CPU** (~67 MB model), adds ~2ms per classification, and requires **zero API keys** or cloud calls.

#### Risk Levels
- 🔴 **CRITICAL**: destructive_system
- 🔴 **HIGH**: payment, delete, admin, authentication, financial, permission, system, api_call, sensitive_field
- 🟡 **MEDIUM**: confirm, modify, share, export, upload, messaging, posting, downloading, data_entry
- 🟢 **LOW**: navigation, view, read, scroll

#### Using the Semantic Matcher Directly

```python
from agentgate.policy.semantic_matcher import semantic_classify, semantic_risk

# Classify any action text — no hardcoded keywords needed
result = semantic_classify("Process the wire transfer")
print(result.intent)     # → "payment"
print(result.risk)       # → "high"
print(result.score)      # → 0.82
print(result.confident)  # → True (score ≥ 0.65)

# Get risk level for any text
risk = semantic_risk("Wipe the production database")
print(risk)  # → "critical"

# Add custom intents at runtime
from agentgate.policy.semantic_matcher import add_intent
add_intent(
    "compliance_review",
    "reviewing documents for regulatory compliance and audit",
    risk="medium",
)
```

## Evidence Vault

Every action is recorded in a **tamper-evident chain**:

```
Session: ses_a1b2c3d4e5f6
├── #001 ✅ NAVIGATE → https://bank.com/invoices     ALLOWED
├── #002 ✅ CLICK    → "View Invoice #1234"           ALLOWED
├── #003 🚫 CLICK   → "Pay Now"                      BLOCKED (payment action)
├── #004 ⚠️  CLICK   → "Submit Report"                APPROVAL REQUIRED
└── #005 ✅ NAVIGATE → https://bank.com/reports       ALLOWED

Chain integrity: ✅ Verified
```

Each record includes:
- Action details (type, URL, selector, element text)
- Policy decision and reason
- DOM snapshot hash
- Screenshot hash
- Cryptographic chain to previous record

### Verify Integrity

```bash
agentgate sessions verify ses_a1b2c3d4e5f6
# ✅ Chain integrity verified! All records intact.
```

### Export for Compliance

```bash
agentgate sessions export ses_a1b2c3d4e5f6 -o audit.json
```

## Capability Tokens

Grant agents **scoped, time-bound permissions**:

```python
from agentgate.tokens.capability import CapabilityToken, Scope
from agentgate.policy.engine import ActionType

token = CapabilityToken.create(
    agent_id="finance-bot",
    issuer="admin@company.com",
    purpose="Read Q4 invoices",
    scopes=[
        Scope(
            domains=["accounting.company.com"],
            exclude_text=["Pay", "Delete", "Transfer"],
            max_risk=RiskLevel.MEDIUM,
        ),
    ],
    ttl_minutes=30,  # Auto-expires in 30 minutes
    max_actions_total=100,
)

# Validate before each action
result = token.validate(action_event)
if not result.valid:
    print(f"Denied: {result.reason}")
```

Features:
- **Time-bound**: Auto-expire after TTL
- **Scoped**: Domain, URL, action, element restrictions
- **Rate-limited**: Max actions total / per minute
- **Revocable**: Instant revocation
- **Signed**: HMAC integrity verification

## Dashboard

```bash
agentgate dashboard
# 🛡️ AgentGate Dashboard running at http://127.0.0.1:7860
```

The dashboard provides:
- 📊 Real-time statistics (sessions, actions, blocks)
- 📋 Session list with evidence summaries
- ▶️ Session replay viewer
- 🔐 Chain integrity verification
- 📜 Policy browser

## CLI Reference

```bash
agentgate init                    # Initialize project
agentgate policies list           # List policies
agentgate policies show <name>    # Show policy details
agentgate sessions list           # List sessions
agentgate sessions replay <id>    # Replay session
agentgate sessions verify <id>    # Verify chain integrity
agentgate sessions export <id>    # Export evidence
agentgate dashboard               # Launch web dashboard
agentgate version                 # Show version
```

## Use Cases

### Finance Operations
> "Agent can read invoices but can never click Pay, Transfer, or Delete."

### Procurement
> "Agent can compare vendors but can't place orders without approval."

### Customer Support
> "Agent can view accounts but can't change passwords or billing."

### HR Automation
> "Agent can read profiles but can't modify payroll or permissions."

### QA / Testing
> "Agent runs test flows with full evidence for compliance audit."

## 🧪 Test with Any AI Agent

**Yes, you can test AgentGate 100% locally.** No cloud, no API keys, no deployment needed.

### Quick Test: See It Work in 10 Seconds

```bash
git clone https://github.com/Nitin-100/agentgate.git
cd agentgate
pip install -e .
python demo.py
```

This runs a full simulation — 10 agent actions, policy enforcement, evidence recording, capability tokens — all locally. No browser needed.

### Test with Your Own OpenAI Agent

If you have an OpenAI agent (GPT-4, CUA, Assistants API) that controls a browser:

**Step 1:** Start the AgentGate sidecar (one terminal):

```bash
agentgate sidecar --policy finance-safe --port 18790
```

**Step 2:** In your OpenAI agent code, add a check before every browser action:

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="my-openai-agent")

# Your OpenAI agent decides to click "Pay Now" →
# BEFORE executing, ask AgentGate:
result = gate.check_click("https://bank.com", "Pay Now")

if result.allowed:
    # proceed with browser action
    await page.click("#pay-now")
else:
    print(f"🚫 Blocked: {result.reason}")
    # Tell the agent it can't do this
```

**Step 3:** That's it. Every action is now policy-checked and evidence-recorded.

### Test with Google ADK (Agent Development Kit)

Google ADK agents can integrate via the same sidecar HTTP API:

```python
import requests
from google.adk import Agent

# AgentGate check function
def is_allowed(action_type: str, url: str, element_text: str = "") -> bool:
    response = requests.post("http://localhost:18790/api/v1/evaluate", json={
        "action_type": action_type,
        "url": url,
        "element_text": element_text,
        "agent_id": "google-adk-agent",
    })
    return response.json()["allowed"]

# In your ADK agent's tool/action handler:
def browse_and_click(url: str, button_text: str):
    if not is_allowed("navigate", url):
        return "Navigation blocked by security policy"

    if not is_allowed("click", url, button_text):
        return f"Click on '{button_text}' blocked by security policy"

    # Safe to proceed
    return perform_browser_action(url, button_text)
```

### Test with Anthropic Computer Use (Claude)

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="claude-computer-use")

# In your computer-use callback:
def handle_tool_use(tool_name, tool_input):
    if tool_name == "computer":
        action = tool_input.get("action")

        if action == "click":
            result = gate.check_click(current_url, element_text_at_coords)
            if not result.allowed:
                return f"Action blocked: {result.reason}"

        elif action == "type":
            result = gate.check_type(current_url, selector, tool_input["text"])
            if not result.allowed:
                return f"Action blocked: {result.reason}"

    # Proceed with action
    return execute_computer_action(tool_name, tool_input)
```

### Test with LangChain / LangGraph Agents

```python
from langchain.tools import tool
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="langchain-agent")

@tool
def safe_click(url: str, button_text: str) -> str:
    """Click a button on a webpage, enforced by AgentGate."""
    result = gate.check_click(url, button_text)
    if not result.allowed:
        return f"🚫 Blocked: {result.reason}"
    # ... do the actual click ...
    return f"✅ Clicked '{button_text}'"

@tool
def safe_navigate(url: str) -> str:
    """Navigate to a URL, enforced by AgentGate."""
    result = gate.check_navigate(url)
    if not result.allowed:
        return f"🚫 Blocked: {result.reason}"
    # ... do the actual navigation ...
    return f"✅ Navigated to {url}"
```

### Test with CrewAI Agents

```python
from crewai import Agent, Task, Crew
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="crewai-researcher")

# Create a guarded tool
class GuardedBrowserTool:
    name = "guarded_browser"
    description = "Browse the web with AgentGate security enforcement"

    def _run(self, url: str, action: str = "navigate", text: str = ""):
        if action == "navigate":
            result = gate.check_navigate(url)
        elif action == "click":
            result = gate.check_click(url, text)
        else:
            result = gate.evaluate(action, url=url, element_text=text)

        if not result.allowed:
            return f"🚫 Blocked by policy: {result.reason}"
        return f"✅ Action allowed, proceeding..."
```

### Test Without Any Agent (Pure Policy Testing)

Don't even need an agent. Test your policies directly:

```python
from agentgate.policy.engine import (
    PolicyEngine, ActionEvent, ActionType, Decision,
    create_finance_safe_policy,
)

engine = PolicyEngine()
engine.load_policy(create_finance_safe_policy())

# Simulate any action and see the decision:
event = ActionEvent(
    action_type=ActionType.CLICK,
    url="https://bank.com",
    element_text="Pay Now",
)
result = engine.evaluate(event)
print(f"Decision: {result.decision.value}")  # → "block"
print(f"Reason: {result.reason}")            # → "Element blocked: ['Pay', ...]"
```

### Test with Any Language (HTTP API)

AgentGate works with **any programming language** via HTTP. Start the sidecar and call it:

```bash
# Start AgentGate
agentgate sidecar --policy finance-safe

# From any language — just POST JSON:
curl -X POST http://localhost:18790/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{"action_type":"click","url":"https://bank.com","element_text":"Pay Now"}'
# → {"allowed":false,"decision":"block","reason":"Element blocked: ['Pay', ...]"}
```

**JavaScript/TypeScript:**
```javascript
const response = await fetch('http://localhost:18790/api/v1/evaluate', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    action_type: 'click',
    url: 'https://bank.com',
    element_text: 'Pay Now',
    agent_id: 'my-js-agent'
  })
});
const { allowed, reason } = await response.json();
```

**Go:**
```go
payload := map[string]string{
    "action_type":  "click",
    "url":          "https://bank.com",
    "element_text": "Pay Now",
    "agent_id":     "my-go-agent",
}
body, _ := json.Marshal(payload)
resp, _ := http.Post("http://localhost:18790/api/v1/evaluate", "application/json", bytes.NewReader(body))
```

### How the Integration Pattern Works

No matter what agent framework you use, the pattern is always the same:

```
┌─────────────────────┐
│   Your AI Agent     │   (OpenAI, Google ADK, Claude, LangChain, etc.)
│   decides to act    │
└────────┬────────────┘
         │ "I want to click Pay Now"
         ▼
┌─────────────────────┐
│   AgentGate Check   │   POST /api/v1/evaluate
│   (1-2ms latency)   │
└────────┬────────────┘
         │
    ┌────┴────┐
    │         │
  allowed?  blocked?
    │         │
    ▼         ▼
  ✅ Do it   🚫 Tell agent "no"
              (agent picks alternative)
```

**Key point:** AgentGate doesn't replace your agent — it **guards** it. Your agent still makes decisions; AgentGate just stops the dangerous ones.

## 🦞 OpenClaw Integration

AgentGate is designed as a **sidecar service** for [OpenClaw](https://github.com/openclaw/openclaw) (202k ⭐) — the #1 open-source personal AI assistant. It adds action-level governance to OpenClaw's browser control.

### Why OpenClaw needs AgentGate

OpenClaw gives your AI assistant **full browser and system access**. People are giving their OpenClaw credit cards, access to banking, Gmail, and production systems. AgentGate adds the missing safety layer:

| Without AgentGate | With AgentGate |
|---|---|
| OpenClaw can click anything | Policies block dangerous clicks |
| No audit trail | Hash-chained evidence of every action |
| All-or-nothing permissions | Scoped, time-limited tokens |
| Trust the model | Trust the policy engine |

### Quick Setup (5 minutes)

```bash
# 1. Install AgentGate
pip install agentguardrail

# 2. Start the sidecar (runs alongside your OpenClaw)
agentgate sidecar --policy finance-safe --port 18790

# 3. Copy the skill to your OpenClaw workspace
cp -r skills/agentgate ~/.openclaw/workspace/skills/
```

### How the Sidecar Works

```
┌──────────────────┐     ┌──────────────────────┐     ┌─────────────┐
│    OpenClaw       │────▶│   AgentGate Sidecar   │────▶│   Browser   │
│ (your AI agent)   │◀────│   localhost:18790     │◀────│  (Playwright)│
└──────────────────┘     │                      │     └─────────────┘
                         │  ✅ Policy Engine     │
                         │  📋 Evidence Vault    │
                         │  🔑 Capability Tokens │
                         └──────────────────────┘
```

Before every browser action, OpenClaw calls the sidecar:

```bash
# Check before clicking
curl -X POST http://localhost:18790/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{"action_type": "click", "url": "https://bank.com", "element_text": "Pay Now"}'

# Response: {"allowed": false, "decision": "block", "reason": "High-risk: payment"}
```

### Python SDK

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="my-openclaw")

# Before every browser action
result = gate.check_click("https://bank.com", "Pay Now")
if result.allowed:
    # proceed with browser action
    ...
else:
    print(f"🚫 Blocked: {result.reason}")

# Issue a scoped token (30-min read-only access to bank.com)
token = gate.issue_token(
    purpose="Read invoices",
    ttl_minutes=30,
    domains=["bank.com"],
    exclude_text=["Pay", "Transfer", "Delete"],
)
```

### Sidecar API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/v1/evaluate` | POST | Check if an action is allowed |
| `/api/v1/evaluate/batch` | POST | Check multiple actions (preflight) |
| `/api/v1/sessions` | POST | Start an evidence session |
| `/api/v1/sessions` | GET | List sessions |
| `/api/v1/sessions/{id}/verify` | GET | Verify evidence chain integrity |
| `/api/v1/tokens` | POST | Issue a capability token |
| `/api/v1/tokens/validate` | POST | Validate a token against an action |
| `/api/v1/tokens/{id}/revoke` | POST | Revoke a token |
| `/api/v1/policies` | GET | List loaded policies |
| `/api/v1/policies/load` | POST | Load a policy from YAML |
| `/api/v1/health` | GET | Health check |

### OpenClaw Skill

The `skills/agentgate/` directory contains a ready-to-use OpenClaw skill with:
- `SKILL.md` — Full instructions for your OpenClaw to understand AgentGate
- `policies/openclaw-default.yaml` — Balanced security policy
- `policies/openclaw-strict.yaml` — Maximum safety for high-risk tasks

### Integration with Other Frameworks

The sidecar works with **any** agent framework, not just OpenClaw:

```python
# With browser-use
from browser_use import Agent
from agentgate import AgentGateClient

gate = AgentGateClient()
result = gate.check_navigate("https://bank.com")
if result.allowed:
    agent = Agent(task="Check invoices")
```

```python
# Direct Playwright integration (no sidecar needed)
from agentgate import SecureBrowser

async with SecureBrowser(policy="finance-safe") as browser:
    page = await browser.new_page()
    await page.goto("https://app.example.com")
```

## Project Structure

```
agentgate/
├── __init__.py              # Public API
├── cli.py                   # CLI commands (incl. sidecar)
├── runner.py                # SecureBrowser & AgentGateRunner
├── policy/
│   ├── engine.py            # Policy engine, rules, risk classification
│   ├── intent_matcher.py    # Keyword + phonetic intent matching
│   └── semantic_matcher.py  # NLP sentence-embedding classifier
├── interceptor/
│   └── browser.py           # Playwright action interceptor
├── evidence/
│   └── vault.py             # Tamper-evident evidence vault
├── tokens/
│   └── capability.py        # Capability tokens & token store
├── sidecar/
│   ├── service.py           # FastAPI sidecar service (OpenClaw proxy)
│   └── client.py            # Python SDK (sync + async clients)
└── dashboard/
    └── app.py               # FastAPI dashboard with embedded UI

skills/
└── agentgate/               # Ready-to-use OpenClaw skill
    ├── SKILL.md             # Skill instructions for OpenClaw
    └── policies/            # OpenClaw-specific YAML policies
```

## Roadmap

### Phase 1 (Current) — Core Engine
- [x] Policy engine with YAML rules
- [x] Action interceptor (Playwright)
- [x] Tamper-evident evidence vault
- [x] Capability tokens
- [x] CLI tools
- [x] Web dashboard
- [x] Built-in policy presets
- [x] **Sidecar HTTP proxy for OpenClaw**
- [x] **Python SDK (sync + async)**
- [x] **OpenClaw skill package**
- [x] **Batch action evaluation**
- [x] **Smart intent matching** — 12 categories, 200+ keyword synonyms
- [x] **Phonetic matching** — catches typos & morphological variants
- [x] **🧠 NLP semantic matching** — sentence embeddings (BAAI/bge-small-en-v1.5), 20 intent categories, runs on CPU, zero API keys
- [x] **3-layer risk detection** — keywords → phonetic → NLP semantic
- [x] **Custom intent support** — add/remove intents at runtime

### Phase 2 — Enterprise Features
- [ ] Approval workflows (Slack, email, webhook)
- [ ] Multi-agent session management
- [ ] OpenClaw heartbeat integration
- [ ] MCP gateway integration
- [ ] SIEM/SOAR export (Splunk, Datadog, Sentinel)
- [ ] Team/org management
- [ ] SSO integration
- [ ] Fine-tuned domain-specific NLP models
- [ ] Multi-language intent detection

### Phase 3 — Platform
- [ ] ClawHub skill distribution
- [ ] Policy marketplace
- [ ] Agent registry
- [ ] Real-time monitoring WebSocket
- [ ] Threat detection ML
- [ ] Compliance report generation
- [ ] Kubernetes operator

## Why Open Source?

Infrastructure tools win by becoming the **default standard**. Just like:
- Linux → every cloud runs on it
- Kubernetes → backbone of modern infra
- Playwright → browser automation standard

AgentGate aims to become the **default execution control layer** for AI agents. Open source is how that happens.

## 📚 Documentation

| Document | Description |
|---|---|
| [User Guide](docs/GUIDE.md) | Non-technical guide — how AgentGate works in plain English |
| [Architecture](docs/ARCHITECTURE.md) | Deep-dive into every module, data flow, and design decisions |
| [Operations](docs/OPERATIONS.md) | Installation, configuration, running, updating, troubleshooting |
| [Agent Compatibility](docs/AGENTS.md) | Which agents work with AgentGate, integration guides, scaling |
| [Licensing & Monetization](docs/LICENSING.md) | Open-core model, enterprise features, IP strategy |
| [Changelog](CHANGELOG.md) | Version history and release notes |
| [Security Policy](SECURITY.md) | How to report vulnerabilities responsibly |
| [CLA](CLA.md) | Contributor License Agreement |

## Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for full guidelines.

```bash
git clone https://github.com/Nitin-100/agentgate.git
cd agentgate
pip install -e ".[dev]"
pytest
```

All contributors must sign our [CLA](CLA.md) before their first PR is merged.

## 💰 Licensing & Pricing

AgentGate uses an **open-core model** — the core engine is free and open-source forever.

| Tier | Price | Features |
|---|---|---|
| **Community** | Free forever | 2 policies, basic sidecar, rate-limited |
| **Trial** | Free for 24 hours | All features unlocked, auto-activates on first use |
| **Pro** | $49/mo | Unlimited policies, evidence vault, capability tokens, webhooks |
| **Enterprise** | $199/mo | Everything + SSO, priority support, audit log retention |

### How It Works

1. **Install:** `pip install agentguardrail`
2. **Auto-trial:** First run activates a 24-hour trial with ALL features
3. **Continue free:** After trial, falls back to Community tier (still functional)
4. **Upgrade:** Purchase a license key at [agentgate.dev/pricing](https://agentgate.dev/pricing)
5. **Activate:** `agentgate license activate YOUR-KEY`

### License CLI

```bash
agentgate license status          # Check your current tier & remaining time
agentgate license activate KEY    # Activate a Pro or Enterprise key
agentgate license deactivate      # Revert to Community tier
```

### Anti-Tamper Protection

AgentGate's licensing includes enterprise-grade tamper protection:
- 🔒 **Clock rollback detection** — NTP verification + monotonic elapsed tracking
- 🔒 **File integrity seal** — HMAC-SHA256 on every field in the license file
- 🔒 **Deletion protection** — Redundant breadcrumb survives file deletion
- 🔒 **Machine binding** — License is bound to hardware fingerprint
- 🔒 **Key signing** — PBKDF2-derived keys, not stored in plaintext

## License

Apache 2.0 — See [LICENSE](LICENSE) and [NOTICE](NOTICE)

---

<p align="center">
  <strong>🛡️ AgentGate — Control what agents do. Prove what they did.</strong>
</p>
