# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 0.1.x   | ✅ Yes             |
| < 0.1   | ❌ No              |

## Reporting a Vulnerability

**⚠️ Do NOT report security vulnerabilities through public GitHub issues.**

If you discover a security vulnerability in AgentGate, please report it responsibly:

### How to Report

1. **Email**: Send a detailed report to **security@agentgate.dev**
2. **Subject**: `[SECURITY] Brief description of the vulnerability`
3. **Include**:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

### What to Expect

- **Acknowledgment**: Within 48 hours
- **Initial Assessment**: Within 5 business days
- **Fix Timeline**: Critical issues within 7 days, others within 30 days
- **Disclosure**: Coordinated disclosure after fix is released

### Scope

The following are in scope:

- AgentGate core library (`agentgate/`)
- Policy engine bypass or evasion
- Evidence vault integrity compromise (hash chain bypass)
- Capability token forgery or bypass
- Sidecar service vulnerabilities (authentication, injection, etc.)
- CLI command injection
- Dashboard authentication/authorization issues

### Out of Scope

- Vulnerabilities in dependencies (report upstream)
- Social engineering attacks
- Denial of service (resource exhaustion from expected usage)
- Issues requiring physical access

### Safe Harbor

We consider security research conducted in good faith to be authorized. We will not pursue legal action against researchers who:

- Make a good faith effort to avoid privacy violations, data destruction, and service disruption
- Only interact with accounts they own or with explicit permission
- Report vulnerabilities promptly
- Do not publicly disclose until a fix is available

### Recognition

We will acknowledge security researchers who report valid vulnerabilities in our release notes (unless they prefer to remain anonymous).

## Security Best Practices

When deploying AgentGate:

1. **Run the sidecar on localhost only** — Don't expose port 18790 to the network unless behind auth
2. **Use strict policies** — Start with `readonly` and open up only what's needed
3. **Enable evidence recording** — Always record sessions for audit
4. **Rotate token secrets** — Change `AGENTGATE_TOKEN_SECRET` regularly
5. **Monitor evidence integrity** — Run `agentgate sessions verify` periodically
6. **Keep AgentGate updated** — `pip install --upgrade agentgate`
