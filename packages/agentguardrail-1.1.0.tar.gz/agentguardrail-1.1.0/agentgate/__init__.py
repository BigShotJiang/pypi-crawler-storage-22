"""
AgentGate — The open-source execution firewall for AI agents.

Control what agents can do. Prove what they did.

Modules:
    - policy: Define and enforce action-level policies
    - interceptor: Intercept browser/UI actions in real-time
    - evidence: Tamper-evident audit trail and session replay
    - tokens: Capability-based permission tokens for agents
    - runner: Secure browser runner with policy enforcement
    - sidecar: HTTP proxy service for OpenClaw and other frameworks
    - cli: Command-line interface
    - dashboard: Web UI for policies, replay, and management
"""

__version__ = "1.1.0"
__all__ = [
    "SecureBrowser",
    "Policy",
    "PolicyEngine",
    "EvidenceVault",
    "CapabilityToken",
    "AgentGateRunner",
    "AgentGateClient",
    "AsyncAgentGateClient",
]

from agentgate.runner import SecureBrowser
from agentgate.policy.engine import Policy, PolicyEngine
from agentgate.evidence.vault import EvidenceVault
from agentgate.tokens.capability import CapabilityToken
from agentgate.runner import AgentGateRunner
from agentgate.sidecar.client import AgentGateClient, AsyncAgentGateClient
