"""
AgentGate CLI — Command-line interface for managing policies, sessions, and evidence.

Commands:
    agentgate init              Create a new AgentGate project with sample policies
    agentgate run               Run an agent with policy enforcement
    agentgate policies list     List available policies
    agentgate policies create   Create a new policy from template
    agentgate sessions list     List recorded sessions
    agentgate sessions replay   Replay a session's evidence
    agentgate sessions verify   Verify a session's integrity chain
    agentgate sessions export   Export session evidence
    agentgate dashboard         Launch the web dashboard
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich import box

console = Console()


# ---------------------------------------------------------------------------
# Main group
# ---------------------------------------------------------------------------

@click.group()
@click.version_option(version="0.1.0", prog_name="agentgate")
def main() -> None:
    """🛡️  AgentGate — The execution firewall for AI agents.

    Control what agents can do. Prove what they did.
    """
    pass


# ---------------------------------------------------------------------------
# init command
# ---------------------------------------------------------------------------

@main.command()
@click.option("--dir", "directory", default=".", help="Project directory")
def init(directory: str) -> None:
    """Initialize a new AgentGate project with sample policies."""
    project_dir = Path(directory)
    policies_dir = project_dir / "policies"
    policies_dir.mkdir(parents=True, exist_ok=True)

    # Create sample policies
    finance_policy = """# AgentGate Policy: Finance Safe
# This policy allows reading financial data but blocks payment actions.

name: finance-safe
description: Allow reading invoices and reports, block all payment actions
version: "1.0"

# Global settings
block_all_downloads: false
block_all_uploads: false
block_js_evaluation: true
block_clipboard: true
max_actions_per_minute: 60

# Allowed domains (empty = all domains allowed)
allowed_domains: []

# Blocked domains
blocked_domains:
  - malware.example.com

rules:
  # Navigation rules
  - action: navigate
    block:
      - pattern: "*/admin/*"
      - pattern: "*/settings/*"
      - pattern: "*/payments/new*"

  # Click rules
  - action: click
    block_elements:
      - text_contains: ["Pay", "Transfer", "Wire", "Send Money"]
        risk: high
      - text_contains: ["Delete", "Remove", "Purge", "Destroy"]
        risk: high
      - selector: "button[type='submit']"
        on_pages: "*/payments/*"
    require_approval:
      - text_contains: ["Submit", "Confirm", "Approve", "Send"]
        risk: medium

  # Type rules (block sensitive fields)
  - action: type
    block_elements:
      - selector: "input[name='credit_card']"
      - selector: "input[name='card_number']"
      - selector: "input[type='password']"
      - selector: "input[name='cvv']"
"""

    readonly_policy = """# AgentGate Policy: Read Only
# Blocks all mutation actions. Agent can only view content.

name: readonly
description: Read-only mode — no clicks, typing, downloads, or uploads
version: "1.0"

block_all_downloads: true
block_all_uploads: true
block_js_evaluation: true
block_clipboard: true

rules:
  - action: click
    block_risk_above: low
  - action: type
    block_risk_above: none
  - action: submit
    block_risk_above: none
"""

    (policies_dir / "finance-safe.yaml").write_text(finance_policy)
    (policies_dir / "readonly.yaml").write_text(readonly_policy)

    # Create sample agent script
    sample_agent = '''"""Sample AgentGate agent — demonstrates policy enforcement."""

import asyncio
from agentgate import SecureBrowser
from agentgate.interceptor.browser import ActionBlockedError


async def main():
    """Run a sample agent with finance-safe policy."""

    async with SecureBrowser(
        policy="finance-safe",
        agent_id="sample-agent",
        headless=False,  # Set to True for production
        capture_screenshots=True,
    ) as browser:
        page = await browser.new_page()

        # This will work — reading is allowed
        await page.goto("https://example.com")
        title = await page.title()
        print(f"✅ Page title: {title}")

        # This would be blocked — payment action
        try:
            await page.click("button#pay")
        except ActionBlockedError as e:
            print(f"🚫 Blocked: {e}")

    print("\\n📋 Session evidence saved to ./agentgate_evidence/")


if __name__ == "__main__":
    asyncio.run(main())
'''

    (project_dir / "sample_agent.py").write_text(sample_agent)

    # Create evidence directory
    (project_dir / "agentgate_evidence").mkdir(exist_ok=True)

    console.print(Panel.fit(
        "[bold green]✅ AgentGate project initialized![/]\n\n"
        f"📁 Policies:  {policies_dir}/\n"
        f"📋 Evidence:  {project_dir / 'agentgate_evidence'}/\n"
        f"🐍 Sample:    {project_dir / 'sample_agent.py'}\n\n"
        "[dim]Next steps:[/]\n"
        "  1. Edit policies in ./policies/\n"
        "  2. Run: [bold]python sample_agent.py[/]\n"
        "  3. View evidence: [bold]agentgate sessions list[/]",
        title="🛡️  AgentGate",
        border_style="green",
    ))


# ---------------------------------------------------------------------------
# policies group
# ---------------------------------------------------------------------------

@main.group()
def policies() -> None:
    """Manage agent policies."""
    pass


@policies.command("list")
@click.option("--dir", "directory", default="./policies", help="Policies directory")
def policies_list(directory: str) -> None:
    """List available policies."""
    from agentgate.policy.engine import Policy

    policies_dir = Path(directory)
    if not policies_dir.exists():
        console.print("[yellow]No policies directory found. Run 'agentgate init' first.[/]")
        return

    table = Table(
        title="🛡️  Loaded Policies",
        box=box.ROUNDED,
        show_lines=True,
    )
    table.add_column("Name", style="bold cyan")
    table.add_column("Description")
    table.add_column("Version")
    table.add_column("Rules", justify="center")
    table.add_column("Status", justify="center")

    for yaml_file in sorted(policies_dir.glob("*.yaml")):
        try:
            policy = Policy.from_yaml(yaml_file)
            status = "✅ Active" if policy.enabled else "⏸️  Disabled"
            table.add_row(
                policy.name,
                policy.description[:60],
                policy.version,
                str(len(policy.rules)),
                status,
            )
        except Exception as e:
            table.add_row(
                yaml_file.stem,
                f"[red]Error: {e}[/]",
                "-",
                "-",
                "❌ Error",
            )

    # Also show presets
    table.add_row("finance-safe", "Built-in: block payments", "1.0", "3", "📦 Preset")
    table.add_row("readonly", "Built-in: read-only mode", "1.0", "3", "📦 Preset")
    table.add_row("permissive", "Built-in: block only critical", "1.0", "3", "📦 Preset")

    console.print(table)


@policies.command("show")
@click.argument("name")
@click.option("--dir", "directory", default="./policies", help="Policies directory")
def policies_show(name: str, directory: str) -> None:
    """Show details of a specific policy."""
    from agentgate.policy.engine import Policy, PRESET_POLICIES

    # Check presets first
    if name in PRESET_POLICIES:
        policy = PRESET_POLICIES[name]()
        yaml_content = policy.to_yaml()
        console.print(Panel(
            Syntax(yaml_content, "yaml", theme="monokai"),
            title=f"🛡️  Policy: {name} (preset)",
            border_style="cyan",
        ))
        return

    # Check file
    policy_file = Path(directory) / f"{name}.yaml"
    if policy_file.exists():
        content = policy_file.read_text()
        console.print(Panel(
            Syntax(content, "yaml", theme="monokai"),
            title=f"🛡️  Policy: {name}",
            border_style="cyan",
        ))
    else:
        console.print(f"[red]Policy not found: {name}[/]")


# ---------------------------------------------------------------------------
# sessions group
# ---------------------------------------------------------------------------

@main.group()
def sessions() -> None:
    """Manage evidence sessions."""
    pass


@sessions.command("list")
@click.option("--dir", "evidence_dir", default="./agentgate_evidence", help="Evidence directory")
def sessions_list(evidence_dir: str) -> None:
    """List all recorded sessions."""
    from agentgate.evidence.vault import EvidenceVault

    async def _list() -> None:
        vault = EvidenceVault(evidence_dir)
        session_list = await vault.list_sessions()

        if not session_list:
            console.print("[yellow]No sessions found. Run an agent first.[/]")
            return

        table = Table(
            title="📋 Evidence Sessions",
            box=box.ROUNDED,
            show_lines=True,
        )
        table.add_column("Session ID", style="bold cyan")
        table.add_column("Agent", style="green")
        table.add_column("Actions", justify="center")
        table.add_column("Blocked", justify="center", style="red")
        table.add_column("Risk", justify="center")
        table.add_column("Duration", justify="right")
        table.add_column("Chain", justify="center")

        for s in session_list:
            if s.get("status") == "incomplete":
                table.add_row(
                    s["session_id"], "-", "-", "-", "-", "-", "⚠️"
                )
            else:
                duration = f"{s.get('duration_seconds', 0):.1f}s"
                chain = "✅" if s.get("chain_valid", False) else "❌"
                table.add_row(
                    s["session_id"],
                    s.get("agent_id", "-"),
                    str(s.get("total_actions", 0)),
                    str(s.get("actions_blocked", 0)),
                    s.get("highest_risk", "none"),
                    duration,
                    chain,
                )

        console.print(table)

    asyncio.run(_list())


@sessions.command("verify")
@click.argument("session_id")
@click.option("--dir", "evidence_dir", default="./agentgate_evidence", help="Evidence directory")
def sessions_verify(session_id: str, evidence_dir: str) -> None:
    """Verify the integrity chain of a session."""
    from agentgate.evidence.vault import EvidenceVault

    async def _verify() -> None:
        vault = EvidenceVault(evidence_dir)
        valid = await vault.verify_session(session_id)

        if valid:
            console.print(Panel(
                "[bold green]✅ Chain integrity verified![/]\n\n"
                "All evidence records are intact and unmodified.\n"
                "The session audit trail is trustworthy.",
                title=f"🔐 Session: {session_id}",
                border_style="green",
            ))
        else:
            console.print(Panel(
                "[bold red]❌ Chain integrity FAILED![/]\n\n"
                "Evidence records may have been tampered with.\n"
                "The session audit trail cannot be trusted.",
                title=f"🚨 Session: {session_id}",
                border_style="red",
            ))

    asyncio.run(_verify())


@sessions.command("replay")
@click.argument("session_id")
@click.option("--dir", "evidence_dir", default="./agentgate_evidence", help="Evidence directory")
def sessions_replay(session_id: str, evidence_dir: str) -> None:
    """Replay a session's evidence in the terminal."""
    from agentgate.evidence.vault import EvidenceVault

    async def _replay() -> None:
        vault = EvidenceVault(evidence_dir)
        records = await vault.get_session_records(session_id)

        if not records:
            console.print(f"[yellow]No records found for session: {session_id}[/]")
            return

        console.print(Panel(
            f"[bold]Session:[/] {session_id}\n"
            f"[bold]Records:[/] {len(records)}",
            title="▶️  Replay",
            border_style="blue",
        ))

        for record in records:
            decision_style = {
                "allow": "green",
                "block": "red bold",
                "require_approval": "yellow",
                "log_only": "dim",
            }.get(record.decision, "white")

            icon = {
                "allow": "✅",
                "block": "🚫",
                "require_approval": "⚠️",
                "log_only": "📝",
            }.get(record.decision, "•")

            console.print(
                f"  [{decision_style}]{icon} #{record.sequence:03d}[/] "
                f"[bold]{record.action_type}[/] "
                f"[dim]{record.url[:60]}[/] "
                f"→ [{decision_style}]{record.decision.upper()}[/] "
                f"[dim]({record.reason[:50]})[/]"
            )

        console.print()

    asyncio.run(_replay())


@sessions.command("export")
@click.argument("session_id")
@click.option("--dir", "evidence_dir", default="./agentgate_evidence", help="Evidence directory")
@click.option("--output", "-o", default=None, help="Output file path")
def sessions_export(session_id: str, evidence_dir: str, output: str | None) -> None:
    """Export session evidence as JSON."""
    from agentgate.evidence.vault import EvidenceVault

    async def _export() -> None:
        vault = EvidenceVault(evidence_dir)
        path = await vault.export_session(session_id, output)
        console.print(f"[green]✅ Exported to: {path}[/]")

    asyncio.run(_export())


# ---------------------------------------------------------------------------
# sidecar command — OpenClaw integration
# ---------------------------------------------------------------------------

@main.command()
@click.option("--port", default=18790, help="Sidecar port (default: 18790)")
@click.option("--host", default="127.0.0.1", help="Sidecar host (default: localhost only)")
@click.option("--policy", default=None, help="Policy preset or YAML file")
@click.option("--policy-dir", default=None, help="Directory with YAML policies")
@click.option("--evidence-dir", default="./agentgate_evidence", help="Evidence storage directory")
@click.option("--agent-id", default="openclaw", help="Default agent ID")
def sidecar(
    port: int,
    host: str,
    policy: str | None,
    policy_dir: str | None,
    evidence_dir: str,
    agent_id: str,
) -> None:
    """🦞 Start the AgentGate sidecar for OpenClaw integration.

    The sidecar runs as a local HTTP service that OpenClaw (or any agent
    framework) calls before executing browser actions. It enforces policies,
    records evidence, and validates capability tokens.

    \b
    Examples:
        agentgate sidecar --policy finance-safe
        agentgate sidecar --policy-dir ./policies --port 18790
        agentgate sidecar --policy openclaw-default --agent-id my-claw
    """
    console.print(Panel.fit(
        f"[bold cyan]🛡️  AgentGate Sidecar[/] [dim]for OpenClaw[/]\n\n"
        f"Endpoint:  [bold]http://{host}:{port}[/]\n"
        f"Agent ID:  {agent_id}\n"
        f"Policy:    {policy or 'none (pass-through)'}\n"
        f"Policy dir:{policy_dir or 'none'}\n"
        f"Evidence:  {evidence_dir}\n\n"
        f"[bold green]API endpoints:[/]\n"
        f"  POST /api/v1/evaluate      — Check if an action is allowed\n"
        f"  POST /api/v1/tokens        — Issue a capability token\n"
        f"  POST /api/v1/sessions      — Start an evidence session\n"
        f"  GET  /api/v1/health        — Health check\n"
        f"  GET  /api/v1/policies      — List loaded policies\n\n"
        f"[dim]Press Ctrl+C to stop[/]",
        border_style="cyan",
    ))

    from agentgate.sidecar.service import create_sidecar
    import uvicorn

    app = create_sidecar(
        policy=policy,
        policy_dir=policy_dir,
        evidence_dir=evidence_dir,
        default_agent_id=agent_id,
    )
    uvicorn.run(app, host=host, port=port, log_level="info")


# ---------------------------------------------------------------------------
# dashboard command
# ---------------------------------------------------------------------------

@main.command()
@click.option("--port", default=7860, help="Dashboard port")
@click.option("--host", default="127.0.0.1", help="Dashboard host")
@click.option("--evidence-dir", default="./agentgate_evidence", help="Evidence directory")
def dashboard(port: int, host: str, evidence_dir: str) -> None:
    """Launch the AgentGate web dashboard."""
    console.print(Panel.fit(
        f"[bold green]🛡️  AgentGate Dashboard[/]\n\n"
        f"URL: [bold]http://{host}:{port}[/]\n"
        f"Evidence: {evidence_dir}\n\n"
        "[dim]Press Ctrl+C to stop[/]",
        border_style="green",
    ))

    from agentgate.dashboard.app import create_app
    import uvicorn

    app = create_app(evidence_dir=evidence_dir)
    uvicorn.run(app, host=host, port=port, log_level="info")


# ---------------------------------------------------------------------------
# license commands
# ---------------------------------------------------------------------------

@main.group()
def license() -> None:
    """Manage your AgentGate license."""
    pass


@license.command("status")
def license_status() -> None:
    """Show current license status."""
    from agentgate.licensing.license_manager import LicenseManager, TIER_FEATURES, PRICING

    lm = LicenseManager()
    info = lm.license
    tier = info.tier.value.upper()
    pricing = PRICING.get(info.tier, {})

    # Status panel
    lines = [
        f"[bold]Tier:[/]           {tier}",
        f"[bold]Status:[/]         {'✅ Active' if info.is_valid and not info.is_expired else '❌ Expired'}",
        f"[bold]Remaining:[/]      {info.remaining_human}",
    ]
    if info.owner_email:
        lines.append(f"[bold]Owner:[/]          {info.owner_email}")
    if info.organization:
        lines.append(f"[bold]Organization:[/]   {info.organization}")
    lines.append(f"[bold]License ID:[/]     {info.license_id[:20]}...")
    lines.append(f"[bold]Machine:[/]        {info.machine_fingerprint[:16]}...")

    console.print(Panel(
        "\n".join(lines),
        title=f"🛡️  AgentGate License — {tier}",
        border_style="cyan" if lm.is_paid else "yellow" if lm.is_trial else "dim",
    ))

    # Feature table
    features = TIER_FEATURES.get(info.tier, {})
    table = Table(title="Features", box=box.SIMPLE)
    table.add_column("Feature", style="bold")
    table.add_column("Value", justify="right")
    for feat, val in sorted(features.items()):
        style = "green" if val is True else "red" if val is False else ""
        display = "✅" if val is True else "❌" if val is False else str(val)
        table.add_row(feat, display, style=style)
    console.print(table)

    if not lm.is_paid:
        console.print(
            "\n[yellow]💡 Upgrade to Pro ($49/mo) for full features:[/] "
            "[bold cyan]https://agentgate.dev/pricing[/]"
        )


@license.command("activate")
@click.argument("key")
def license_activate(key: str) -> None:
    """Activate a Pro or Enterprise license key."""
    from agentgate.licensing.license_manager import LicenseManager

    lm = LicenseManager()
    try:
        info = lm.activate_license(key)
        console.print(f"\n[bold green]✅ License activated![/]\n")
        console.print(f"  Tier:         {info.tier.value.upper()}")
        console.print(f"  Owner:        {info.owner_email}")
        console.print(f"  Organization: {info.organization}")
        console.print(f"  Expires:      {info.remaining_human}")
        console.print(f"\n  {info.validation_message}")
    except ValueError as e:
        console.print(f"\n[bold red]❌ {e}[/]")


@license.command("deactivate")
def license_deactivate() -> None:
    """Deactivate the current license (revert to Community)."""
    from agentgate.licensing.license_manager import LicenseManager

    lm = LicenseManager()
    lm.deactivate()
    console.print("[yellow]License deactivated. Using Community (free) tier.[/]")


@license.command("generate-key")
@click.option("--tier", type=click.Choice(["pro", "enterprise"]), required=True)
@click.option("--email", required=True, help="Owner email address")
@click.option("--org", default="", help="Organization name")
@click.option("--days", default=365, help="Validity in days")
def license_generate_key(tier: str, email: str, org: str, days: int) -> None:
    """Generate a license key (admin/server use only)."""
    from agentgate.licensing.license_manager import LicenseTier, generate_license_key

    t = LicenseTier.PRO if tier == "pro" else LicenseTier.ENTERPRISE
    key = generate_license_key(t, email, org, days)

    console.print(f"\n[bold green]✅ License key generated![/]")
    console.print(f"  Tier:  {tier.upper()}")
    console.print(f"  Email: {email}")
    console.print(f"  Org:   {org or '(none)'}")
    console.print(f"  Valid: {days} days\n")
    console.print(Panel(key, title="License Key", border_style="green"))
    console.print("\n[dim]Send this key to the customer. They activate with:[/]")
    console.print(f"  [bold]agentgate license activate {key[:40]}...[/]")


# ---------------------------------------------------------------------------
# version command
# ---------------------------------------------------------------------------

@main.command()
def version() -> None:
    """Show AgentGate version and info."""
    from agentgate.licensing.license_manager import LicenseManager
    lm = LicenseManager()

    console.print(Panel.fit(
        "[bold cyan]🛡️  AgentGate[/]\n\n"
        "Version: 0.1.0\n"
        f"License: {lm.tier.value.upper()} ({lm.remaining_trial_time()})\n"
        "Python:  3.11+\n\n"
        "The execution firewall for AI agents.\n"
        "Control what agents can do. Prove what they did.\n\n"
        "[dim]https://agentgate.dev[/]",
        border_style="cyan",
    ))


if __name__ == "__main__":
    main()
