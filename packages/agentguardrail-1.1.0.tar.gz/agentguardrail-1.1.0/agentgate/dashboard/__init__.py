"""Dashboard API and web UI for AgentGate."""
