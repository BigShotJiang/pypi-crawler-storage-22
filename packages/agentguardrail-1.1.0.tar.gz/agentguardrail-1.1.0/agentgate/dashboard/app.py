"""
AgentGate Dashboard — Web API and UI for managing policies, sessions, and replay.

Provides:
- REST API for policies, sessions, and evidence
- Real-time session monitoring via WebSocket
- Evidence replay viewer
- Policy editor
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, WebSocket
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from agentgate.evidence.vault import EvidenceVault


def create_app(
    evidence_dir: str = "./agentgate_evidence",
    policies_dir: str = "./policies",
) -> FastAPI:
    """Create the FastAPI dashboard application."""

    app = FastAPI(
        title="AgentGate Dashboard",
        description="The execution firewall for AI agents — Dashboard API",
        version="0.1.0",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    vault = EvidenceVault(evidence_dir)

    # ------------------------------------------------------------------
    # Dashboard Home
    # ------------------------------------------------------------------

    @app.get("/", response_class=HTMLResponse)
    async def home() -> str:
        return DASHBOARD_HTML

    # ------------------------------------------------------------------
    # Sessions API
    # ------------------------------------------------------------------

    @app.get("/api/sessions")
    async def list_sessions() -> list[dict[str, Any]]:
        return await vault.list_sessions()

    @app.get("/api/sessions/{session_id}")
    async def get_session(session_id: str) -> dict[str, Any]:
        summary = await vault.get_session_summary(session_id)
        if not summary:
            raise HTTPException(404, f"Session not found: {session_id}")
        return summary.model_dump()

    @app.get("/api/sessions/{session_id}/records")
    async def get_session_records(session_id: str) -> list[dict[str, Any]]:
        records = await vault.get_session_records(session_id)
        return [r.model_dump() for r in records]

    @app.get("/api/sessions/{session_id}/verify")
    async def verify_session(session_id: str) -> dict[str, Any]:
        valid = await vault.verify_session(session_id)
        return {"session_id": session_id, "chain_valid": valid}

    @app.post("/api/sessions/{session_id}/export")
    async def export_session(session_id: str) -> dict[str, str]:
        path = await vault.export_session(session_id)
        return {"path": path}

    # ------------------------------------------------------------------
    # Policies API
    # ------------------------------------------------------------------

    @app.get("/api/policies")
    async def list_policies() -> list[dict[str, Any]]:
        from agentgate.policy.engine import Policy

        policies = []
        pol_dir = Path(policies_dir)
        if pol_dir.exists():
            for f in sorted(pol_dir.glob("*.yaml")):
                try:
                    p = Policy.from_yaml(f)
                    policies.append({
                        "name": p.name,
                        "description": p.description,
                        "version": p.version,
                        "enabled": p.enabled,
                        "rules_count": len(p.rules),
                        "file": str(f),
                    })
                except Exception as e:
                    policies.append({
                        "name": f.stem,
                        "error": str(e),
                    })

        # Add presets
        from agentgate.policy.engine import PRESET_POLICIES  # noqa: F811
        # Just reference the dict keys from runner
        for name in ["finance-safe", "readonly", "permissive"]:
            policies.append({
                "name": name,
                "description": f"Built-in preset: {name}",
                "version": "1.0",
                "enabled": True,
                "preset": True,
            })

        return policies

    # ------------------------------------------------------------------
    # Stats API
    # ------------------------------------------------------------------

    @app.get("/api/stats")
    async def get_stats() -> dict[str, Any]:
        sessions = await vault.list_sessions()
        total_actions = sum(s.get("total_actions", 0) for s in sessions)
        total_blocked = sum(s.get("actions_blocked", 0) for s in sessions)
        return {
            "total_sessions": len(sessions),
            "total_actions": total_actions,
            "total_blocked": total_blocked,
            "block_rate": round(total_blocked / max(total_actions, 1) * 100, 1),
        }

    return app


# ---------------------------------------------------------------------------
# Embedded Dashboard HTML (single-file for easy distribution)
# ---------------------------------------------------------------------------

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgentGate Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --bg: #0a0a0f;
            --surface: #12121a;
            --surface2: #1a1a2e;
            --border: #2a2a3e;
            --text: #e0e0f0;
            --text-dim: #8888a8;
            --accent: #4fc3f7;
            --green: #66bb6a;
            --red: #ef5350;
            --yellow: #ffa726;
            --purple: #ab47bc;
        }
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }
        .header {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
            padding: 16px 32px;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .header h1 {
            font-size: 20px;
            font-weight: 600;
        }
        .header .shield { font-size: 24px; }
        .header .badge {
            background: var(--accent);
            color: #000;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 700;
        }
        .main {
            max-width: 1400px;
            margin: 0 auto;
            padding: 24px 32px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }
        .stat-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
        }
        .stat-card .label {
            font-size: 13px;
            color: var(--text-dim);
            margin-bottom: 8px;
        }
        .stat-card .value {
            font-size: 32px;
            font-weight: 700;
        }
        .stat-card .value.green { color: var(--green); }
        .stat-card .value.red { color: var(--red); }
        .stat-card .value.accent { color: var(--accent); }
        .stat-card .value.yellow { color: var(--yellow); }
        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .sessions-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--surface);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid var(--border);
        }
        .sessions-table th {
            background: var(--surface2);
            padding: 12px 16px;
            text-align: left;
            font-size: 13px;
            color: var(--text-dim);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .sessions-table td {
            padding: 12px 16px;
            border-top: 1px solid var(--border);
            font-size: 14px;
        }
        .sessions-table tr:hover td {
            background: var(--surface2);
        }
        .tag {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        .tag.allow { background: rgba(102, 187, 106, 0.15); color: var(--green); }
        .tag.block { background: rgba(239, 83, 80, 0.15); color: var(--red); }
        .tag.approval { background: rgba(255, 167, 38, 0.15); color: var(--yellow); }
        .tag.valid { background: rgba(79, 195, 247, 0.15); color: var(--accent); }
        .tag.invalid { background: rgba(239, 83, 80, 0.15); color: var(--red); }
        .mono { font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 13px; }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-dim);
        }
        .empty-state .icon { font-size: 48px; margin-bottom: 16px; }
        .empty-state p { margin-top: 8px; }
        .btn {
            background: var(--surface2);
            border: 1px solid var(--border);
            color: var(--text);
            padding: 6px 14px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.15s;
        }
        .btn:hover { background: var(--accent); color: #000; }
        .record-timeline {
            margin-top: 24px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            display: none;
        }
        .record-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 8px 0;
            border-bottom: 1px solid var(--border);
        }
        .record-item:last-child { border-bottom: none; }
        .record-item .seq {
            color: var(--text-dim);
            font-size: 12px;
            min-width: 40px;
            font-family: monospace;
        }
        .record-item .action-type {
            font-weight: 600;
            min-width: 90px;
            font-size: 13px;
        }
        .record-item .details {
            flex: 1;
            color: var(--text-dim);
            font-size: 13px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
</head>
<body>
    <div class="header">
        <span class="shield">🛡️</span>
        <h1>AgentGate</h1>
        <span class="badge">v0.1.0</span>
        <span style="flex:1"></span>
        <span style="color: var(--text-dim); font-size: 13px;">
            The execution firewall for AI agents
        </span>
    </div>
    <div class="main">
        <div class="stats-grid" id="stats">
            <div class="stat-card">
                <div class="label">Total Sessions</div>
                <div class="value accent" id="stat-sessions">-</div>
            </div>
            <div class="stat-card">
                <div class="label">Total Actions</div>
                <div class="value green" id="stat-actions">-</div>
            </div>
            <div class="stat-card">
                <div class="label">Actions Blocked</div>
                <div class="value red" id="stat-blocked">-</div>
            </div>
            <div class="stat-card">
                <div class="label">Block Rate</div>
                <div class="value yellow" id="stat-rate">-</div>
            </div>
        </div>

        <div class="section-title">📋 Evidence Sessions</div>
        <div id="sessions-container">
            <div class="empty-state">
                <div class="icon">🔍</div>
                <div>Loading sessions...</div>
            </div>
        </div>

        <div class="record-timeline" id="timeline">
            <div class="section-title">▶️ Session Replay <span id="replay-session" class="mono" style="color: var(--accent)"></span></div>
            <div id="timeline-records"></div>
        </div>
    </div>

    <script>
        async function loadStats() {
            try {
                const res = await fetch('/api/stats');
                const data = await res.json();
                document.getElementById('stat-sessions').textContent = data.total_sessions;
                document.getElementById('stat-actions').textContent = data.total_actions;
                document.getElementById('stat-blocked').textContent = data.total_blocked;
                document.getElementById('stat-rate').textContent = data.block_rate + '%';
            } catch(e) {
                console.error('Failed to load stats:', e);
            }
        }

        async function loadSessions() {
            try {
                const res = await fetch('/api/sessions');
                const sessions = await res.json();
                const container = document.getElementById('sessions-container');

                if (sessions.length === 0) {
                    container.innerHTML = `
                        <div class="empty-state">
                            <div class="icon">📭</div>
                            <div>No sessions recorded yet</div>
                            <p>Run an agent with AgentGate to see evidence here.</p>
                        </div>`;
                    return;
                }

                let html = `<table class="sessions-table">
                    <thead><tr>
                        <th>Session ID</th>
                        <th>Agent</th>
                        <th>Actions</th>
                        <th>Blocked</th>
                        <th>Risk</th>
                        <th>Duration</th>
                        <th>Chain</th>
                        <th></th>
                    </tr></thead><tbody>`;

                for (const s of sessions) {
                    const chain = s.chain_valid ? '<span class="tag valid">✅ Valid</span>' : '<span class="tag invalid">❌ Broken</span>';
                    const risk = s.highest_risk || 'none';
                    const riskClass = risk === 'high' || risk === 'critical' ? 'block' : risk === 'medium' ? 'approval' : 'allow';

                    html += `<tr>
                        <td class="mono">${s.session_id || '-'}</td>
                        <td>${s.agent_id || '-'}</td>
                        <td>${s.total_actions ?? '-'}</td>
                        <td>${s.actions_blocked ? '<span class="tag block">' + s.actions_blocked + '</span>' : '0'}</td>
                        <td><span class="tag ${riskClass}">${risk}</span></td>
                        <td>${s.duration_seconds ? s.duration_seconds.toFixed(1) + 's' : '-'}</td>
                        <td>${s.chain_valid !== undefined ? chain : '⚠️'}</td>
                        <td><button class="btn" onclick="loadReplay('${s.session_id}')">▶️ Replay</button></td>
                    </tr>`;
                }

                html += '</tbody></table>';
                container.innerHTML = html;
            } catch(e) {
                console.error('Failed to load sessions:', e);
            }
        }

        async function loadReplay(sessionId) {
            try {
                const res = await fetch(`/api/sessions/${sessionId}/records`);
                const records = await res.json();
                const timeline = document.getElementById('timeline');
                const container = document.getElementById('timeline-records');
                document.getElementById('replay-session').textContent = sessionId;

                if (records.length === 0) {
                    container.innerHTML = '<div class="empty-state">No records</div>';
                } else {
                    let html = '';
                    for (const r of records) {
                        const icon = r.decision === 'allow' ? '✅' : r.decision === 'block' ? '🚫' : '⚠️';
                        const color = r.decision === 'allow' ? 'var(--green)' : r.decision === 'block' ? 'var(--red)' : 'var(--yellow)';
                        html += `<div class="record-item">
                            <span class="seq">#${String(r.sequence).padStart(3, '0')}</span>
                            <span style="font-size:16px">${icon}</span>
                            <span class="action-type" style="color:${color}">${r.action_type}</span>
                            <span class="details">${r.url ? r.url.substring(0, 60) : ''} ${r.element_text ? '→ ' + r.element_text.substring(0, 30) : ''}</span>
                            <span class="tag ${r.decision === 'allow' ? 'allow' : r.decision === 'block' ? 'block' : 'approval'}">${r.decision.toUpperCase()}</span>
                        </div>`;
                    }
                    container.innerHTML = html;
                }

                timeline.style.display = 'block';
                timeline.scrollIntoView({ behavior: 'smooth' });
            } catch(e) {
                console.error('Failed to load replay:', e);
            }
        }

        loadStats();
        loadSessions();
        setInterval(loadStats, 5000);
        setInterval(loadSessions, 10000);
    </script>
</body>
</html>"""
