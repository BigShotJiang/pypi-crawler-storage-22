"""Evidence vault for AgentGate — tamper-evident audit trails."""
