"""Interceptor layer for AgentGate — hooks into browser actions."""
