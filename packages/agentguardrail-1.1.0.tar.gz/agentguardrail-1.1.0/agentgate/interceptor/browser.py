"""
AgentGate Browser Interceptor — Hooks into Playwright to intercept every action.

This is the enforcement layer. It wraps Playwright's Page object and intercepts
every click, type, navigate, download, etc. Before each action executes, the
interceptor:

1. Creates an ActionEvent describing the attempted action
2. Passes it to the PolicyEngine for evaluation
3. Records the action + decision in the EvidenceVault
4. Either allows, blocks, or requests approval

Usage:
    from agentgate.interceptor.browser import InterceptedPage

    page = InterceptedPage(
        playwright_page=page,
        policy_engine=engine,
        evidence_session=session,
    )

    # These are now policy-enforced:
    await page.goto("https://bank.com/payments")  # -> may be BLOCKED
    await page.click("button#pay")                # -> may be BLOCKED
    await page.fill("#amount", "10000")            # -> may be BLOCKED
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable

from playwright.async_api import Page, ElementHandle, Locator

from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    PolicyDecision,
    PolicyEngine,
    Decision,
)
from agentgate.evidence.vault import EvidenceSession


class ActionBlockedError(Exception):
    """Raised when a policy blocks an agent action."""
    def __init__(self, decision: PolicyDecision):
        self.decision = decision
        super().__init__(
            f"Action BLOCKED by policy '{decision.policy_name}': "
            f"{decision.reason} (rule: {decision.matched_rule})"
        )


class ApprovalRequiredError(Exception):
    """Raised when an action requires human approval."""
    def __init__(self, decision: PolicyDecision):
        self.decision = decision
        super().__init__(
            f"Action requires APPROVAL (policy '{decision.policy_name}'): "
            f"{decision.reason}"
        )


class InterceptedPage:
    """
    A policy-enforced wrapper around Playwright's Page object.

    Every browser action goes through the policy engine before execution.
    Every action is recorded in the evidence vault.
    """

    def __init__(
        self,
        playwright_page: Page,
        policy_engine: PolicyEngine,
        evidence_session: EvidenceSession | None = None,
        agent_id: str = "",
        session_id: str = "",
        on_block: Callable[[PolicyDecision], Any] | None = None,
        on_approval_needed: Callable[[PolicyDecision], Any] | None = None,
        capture_screenshots: bool = True,
        capture_dom: bool = False,
    ) -> None:
        self._page = playwright_page
        self._engine = policy_engine
        self._evidence = evidence_session
        self._agent_id = agent_id
        self._session_id = session_id
        self._on_block = on_block
        self._on_approval_needed = on_approval_needed
        self._capture_screenshots = capture_screenshots
        self._capture_dom = capture_dom
        self._action_count = 0

    @property
    def page(self) -> Page:
        """Access the underlying Playwright page (use with caution)."""
        return self._page

    @property
    def url(self) -> str:
        return self._page.url

    @property
    def action_count(self) -> int:
        return self._action_count

    # ------------------------------------------------------------------
    # Core enforcement method
    # ------------------------------------------------------------------

    async def _enforce(
        self,
        event: ActionEvent,
    ) -> PolicyDecision:
        """
        Core enforcement: evaluate policy, record evidence, act on decision.
        """
        # Evaluate policy
        decision = self._engine.evaluate(event)

        # Capture evidence
        screenshot = None
        dom_snapshot = None

        if self._evidence:
            if self._capture_screenshots:
                try:
                    screenshot = await self._page.screenshot(type="png")
                except Exception:
                    pass
            if self._capture_dom:
                try:
                    dom_snapshot = await self._page.content()
                except Exception:
                    pass

            await self._evidence.record(
                event=event,
                decision=decision,
                screenshot=screenshot,
                dom_snapshot=dom_snapshot,
            )

        self._action_count += 1

        # Act on decision
        if decision.is_blocked:
            if self._on_block:
                self._on_block(decision)
            raise ActionBlockedError(decision)

        if decision.needs_approval:
            if self._on_approval_needed:
                approved = self._on_approval_needed(decision)
                if not approved:
                    raise ApprovalRequiredError(decision)
            else:
                raise ApprovalRequiredError(decision)

        return decision

    def _make_event(
        self,
        action_type: ActionType,
        selector: str = "",
        element_text: str = "",
        value: str = "",
        **kwargs: Any,
    ) -> ActionEvent:
        """Create an ActionEvent for the current context."""
        return ActionEvent(
            action_type=action_type,
            url=self._page.url,
            selector=selector,
            element_text=element_text,
            value=value,
            agent_id=self._agent_id,
            session_id=self._session_id,
            metadata=kwargs,
        )

    # ------------------------------------------------------------------
    # Intercepted navigation
    # ------------------------------------------------------------------

    async def goto(self, url: str, **kwargs: Any) -> Any:
        """Navigate to a URL (policy-enforced)."""
        event = self._make_event(
            ActionType.NAVIGATE,
            element_text=url,
        )
        # Override URL with the target
        event.url = url
        await self._enforce(event)
        return await self._page.goto(url, **kwargs)

    # ------------------------------------------------------------------
    # Intercepted click
    # ------------------------------------------------------------------

    async def click(self, selector: str, **kwargs: Any) -> None:
        """Click an element (policy-enforced)."""
        # Try to get element text for better policy matching
        element_text = ""
        try:
            element = await self._page.query_selector(selector)
            if element:
                element_text = await element.text_content() or ""
        except Exception:
            pass

        event = self._make_event(
            ActionType.CLICK,
            selector=selector,
            element_text=element_text,
        )
        await self._enforce(event)
        await self._page.click(selector, **kwargs)

    # ------------------------------------------------------------------
    # Intercepted type/fill
    # ------------------------------------------------------------------

    async def fill(self, selector: str, value: str, **kwargs: Any) -> None:
        """Fill a form field (policy-enforced)."""
        event = self._make_event(
            ActionType.TYPE,
            selector=selector,
            value=value,
        )
        await self._enforce(event)
        await self._page.fill(selector, value, **kwargs)

    async def type(self, selector: str, text: str, **kwargs: Any) -> None:
        """Type into an element (policy-enforced)."""
        event = self._make_event(
            ActionType.TYPE,
            selector=selector,
            value=text,
        )
        await self._enforce(event)
        await self._page.type(selector, text, **kwargs)

    # ------------------------------------------------------------------
    # Intercepted keyboard
    # ------------------------------------------------------------------

    async def press(self, selector: str, key: str, **kwargs: Any) -> None:
        """Press a key (policy-enforced)."""
        event = self._make_event(
            ActionType.KEY_PRESS,
            selector=selector,
            value=key,
        )
        await self._enforce(event)
        await self._page.press(selector, key, **kwargs)

    # ------------------------------------------------------------------
    # Intercepted select
    # ------------------------------------------------------------------

    async def select_option(self, selector: str, value: str, **kwargs: Any) -> Any:
        """Select an option (policy-enforced)."""
        event = self._make_event(
            ActionType.SELECT,
            selector=selector,
            value=str(value),
        )
        await self._enforce(event)
        return await self._page.select_option(selector, value, **kwargs)

    # ------------------------------------------------------------------
    # Intercepted file operations
    # ------------------------------------------------------------------

    async def set_input_files(self, selector: str, files: Any, **kwargs: Any) -> None:
        """Upload files (policy-enforced)."""
        event = self._make_event(
            ActionType.UPLOAD,
            selector=selector,
            value=str(files),
        )
        await self._enforce(event)
        await self._page.set_input_files(selector, files, **kwargs)

    # ------------------------------------------------------------------
    # Intercepted JavaScript evaluation
    # ------------------------------------------------------------------

    async def evaluate(self, expression: str, *args: Any) -> Any:
        """Evaluate JavaScript (policy-enforced — blocked by default)."""
        event = self._make_event(
            ActionType.EVALUATE_JS,
            value=expression[:500],
        )
        await self._enforce(event)
        return await self._page.evaluate(expression, *args)

    # ------------------------------------------------------------------
    # Safe read-only operations (not intercepted)
    # ------------------------------------------------------------------

    async def title(self) -> str:
        """Get page title (safe, not intercepted)."""
        return await self._page.title()

    async def content(self) -> str:
        """Get page HTML content (safe, not intercepted)."""
        return await self._page.content()

    async def query_selector(self, selector: str) -> ElementHandle | None:
        """Query a selector (safe, not intercepted)."""
        return await self._page.query_selector(selector)

    async def query_selector_all(self, selector: str) -> list[ElementHandle]:
        """Query all matching elements (safe, not intercepted)."""
        return await self._page.query_selector_all(selector)

    async def text_content(self, selector: str) -> str | None:
        """Get text content (safe, not intercepted)."""
        return await self._page.text_content(selector)

    async def inner_text(self, selector: str) -> str:
        """Get inner text (safe, not intercepted)."""
        return await self._page.inner_text(selector)

    async def get_attribute(self, selector: str, name: str) -> str | None:
        """Get an attribute (safe, not intercepted)."""
        return await self._page.get_attribute(selector, name)

    async def screenshot(self, **kwargs: Any) -> bytes:
        """Take a screenshot (policy-enforced)."""
        event = self._make_event(ActionType.SCREENSHOT)
        await self._enforce(event)
        return await self._page.screenshot(**kwargs)

    async def wait_for_selector(self, selector: str, **kwargs: Any) -> ElementHandle | None:
        """Wait for selector (safe, not intercepted)."""
        return await self._page.wait_for_selector(selector, **kwargs)

    async def wait_for_load_state(self, state: str = "load", **kwargs: Any) -> None:
        """Wait for load state (safe, not intercepted)."""
        await self._page.wait_for_load_state(state, **kwargs)

    # ------------------------------------------------------------------
    # Scroll (policy-enforced but usually low-risk)
    # ------------------------------------------------------------------

    async def scroll(self, x: int = 0, y: int = 0) -> None:
        """Scroll the page (policy-enforced)."""
        event = self._make_event(
            ActionType.SCROLL,
            value=f"x={x},y={y}",
        )
        await self._enforce(event)
        await self._page.evaluate(f"window.scrollBy({x}, {y})")

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the page."""
        await self._page.close()

    async def __aenter__(self) -> InterceptedPage:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
