"""
AgentGate Licensing — Commercial license management, trial enforcement, and feature gating.
"""

from agentgate.licensing.license_manager import (
    LicenseManager,
    LicenseTier,
    LicenseInfo,
    TrialExpiredError,
    LicenseRequiredError,
    LicenseTamperError,
)

__all__ = [
    "LicenseManager",
    "LicenseTier",
    "LicenseInfo",
    "TrialExpiredError",
    "LicenseRequiredError",
    "LicenseTamperError",
]
