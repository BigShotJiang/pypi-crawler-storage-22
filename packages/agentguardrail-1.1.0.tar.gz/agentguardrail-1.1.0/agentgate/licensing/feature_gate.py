"""
AgentGate Feature Gate — Decorators and middleware for enforcing license tiers.

Usage in code:
    from agentgate.licensing.feature_gate import require_feature, require_tier

    @require_feature("evidence_vault")
    async def start_session(...):
        ...

    @require_tier(LicenseTier.PRO)
    def export_report(...):
        ...

Usage in sidecar:
    The LicenseMiddleware auto-injects into FastAPI and checks rate limits,
    feature access, and trial expiry on every request.
"""

from __future__ import annotations

import functools
import time
from typing import Any, Callable

from agentgate.licensing.license_manager import (
    LicenseManager,
    LicenseTier,
    LicenseRequiredError,
    LicenseLimitError,
    TIER_FEATURES,
)


# ---------------------------------------------------------------------------
# Decorators
# ---------------------------------------------------------------------------

def require_feature(feature: str):
    """Decorator: raises LicenseRequiredError if feature is not available."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            lm = LicenseManager()
            lm.check_feature(feature)
            return func(*args, **kwargs)

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            lm = LicenseManager()
            lm.check_feature(feature)
            return await func(*args, **kwargs)

        import asyncio
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper
    return decorator


def require_tier(min_tier: LicenseTier):
    """Decorator: ensures the current tier is at least min_tier."""
    tier_order = [LicenseTier.COMMUNITY, LicenseTier.TRIAL, LicenseTier.PRO, LicenseTier.ENTERPRISE]

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            lm = LicenseManager()
            current_idx = tier_order.index(lm.tier)
            required_idx = tier_order.index(min_tier)
            if current_idx < required_idx:
                raise LicenseRequiredError(func.__name__, min_tier.value.title())
            return func(*args, **kwargs)
        return wrapper
    return decorator


def check_rate_limit():
    """Call this before every evaluation to enforce rate limits."""
    lm = LicenseManager()
    lm.check_eval_rate()


# ---------------------------------------------------------------------------
# FastAPI Middleware for Sidecar
# ---------------------------------------------------------------------------

def create_license_middleware():
    """
    Creates FastAPI middleware that:
    1. Checks trial expiry
    2. Enforces rate limits
    3. Adds license info to response headers
    4. Blocks gated endpoints for COMMUNITY tier
    """
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
    from starlette.responses import JSONResponse

    # Endpoints that require specific features
    GATED_ENDPOINTS: dict[str, str] = {
        "/api/v1/tokens": "capability_tokens",
        "/api/v1/sessions": "evidence_vault",
        "/api/v1/sessions/": "evidence_vault",
        "/api/v1/export": "export_evidence",
        "/api/v1/dashboard": "dashboard",
        "/api/v1/webhooks": "webhook_alerts",
    }

    # Endpoints exempt from rate limiting
    EXEMPT_ENDPOINTS = {"/api/v1/health", "/api/v1/license", "/api/v1/license/status"}

    class LicenseMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            lm = LicenseManager()
            path = request.url.path

            # Always allow health and license endpoints
            if path in EXEMPT_ENDPOINTS:
                response = await call_next(request)
                response.headers["X-AgentGate-Tier"] = lm.tier.value
                return response

            # Check trial expiry
            if lm.is_trial and lm.license.is_expired:
                lm._license.tier = LicenseTier.COMMUNITY
                lm._license.features = TIER_FEATURES[LicenseTier.COMMUNITY]
                lm._save_license()

            # Check feature gating for specific endpoints
            for endpoint_prefix, feature in GATED_ENDPOINTS.items():
                if path.startswith(endpoint_prefix):
                    features = TIER_FEATURES.get(lm.tier, TIER_FEATURES[LicenseTier.COMMUNITY])
                    if not features.get(feature, False):
                        return JSONResponse(
                            status_code=403,
                            content={
                                "error": "feature_not_available",
                                "message": f"Feature '{feature}' requires AgentGate Pro. "
                                           f"Upgrade at https://agentgate.dev/pricing",
                                "current_tier": lm.tier.value,
                                "required_tier": "pro",
                                "upgrade_url": "https://agentgate.dev/pricing",
                            },
                        )

            # Check rate limits for evaluation endpoint
            if path == "/api/v1/evaluate":
                try:
                    lm.check_eval_rate()
                except LicenseLimitError as e:
                    return JSONResponse(
                        status_code=429,
                        content={
                            "error": "rate_limit_exceeded",
                            "message": str(e),
                            "current_tier": lm.tier.value,
                            "upgrade_url": "https://agentgate.dev/pricing",
                        },
                    )

            # Process request
            response = await call_next(request)

            # Add license headers
            response.headers["X-AgentGate-Tier"] = lm.tier.value
            if lm.is_trial:
                response.headers["X-AgentGate-Trial-Remaining"] = lm.remaining_trial_time()

            return response

    return LicenseMiddleware
