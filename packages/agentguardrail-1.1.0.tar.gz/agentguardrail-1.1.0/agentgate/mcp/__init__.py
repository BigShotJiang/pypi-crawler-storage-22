"""
AgentGate MCP — Model Context Protocol integration (coming in v2.0).

Planned:
    - AgentGateMCPServer: Exposes AgentGate tools via MCP
    - MCPProxy: Security gateway wrapping downstream MCP servers
    - Preset configs for web, e-commerce, finance, devops, social
"""
