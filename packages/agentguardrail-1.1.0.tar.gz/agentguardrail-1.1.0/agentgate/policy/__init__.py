"""Policy engine for AgentGate — the core of action-level control."""
