"""
AgentGate Semantic Matcher — NLP-powered intent classification.

Uses sentence embeddings (fastembed / ONNX) to understand the MEANING
of actions, not just keyword patterns.  This lets the policy engine
catch actions it has never seen before:

    "Venmo $50 to John"      → payment    (no keyword "venmo" needed)
    "Drop the entire table"  → delete     (understands database lingo)
    "Retweet this"           → social     (no social-media synonym list)
    "Comprar ahora"          → payment    (cross-language understanding)
    "Deploy to prod"         → system     (understands DevOps context)

Architecture
────────────
1. Each intent is described with a natural-language embedding that
   captures its semantic space (example phrases, not just labels).
2. At import time we pre-compute embeddings for all intent descriptions.
3. At runtime we embed the incoming action text and find the closest
   intent(s) via cosine similarity.
4. The keyword system in intent_matcher.py remains as a fast, precise
   first layer — this module is the deep-understanding second layer.

The model (~67 MB ONNX) runs entirely on CPU, needs no API keys, and
produces results in <50ms per query after warmup.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

import numpy as np

logger = logging.getLogger("agentgate.semantic")

# ═══════════════════════════════════════════════════════════════════════════
# Intent Definitions — natural language descriptions
# ═══════════════════════════════════════════════════════════════════════════
# Each intent is described by EXAMPLE PHRASES that capture its semantic
# space.  The embedding model turns these into vectors that can match
# *anything* in that space — even phrases we never wrote down.

SEMANTIC_INTENTS: dict[str, str] = {
    "payment": (
        "Pay now, buy, purchase, checkout, complete order, add to cart, "
        "subscribe, place order, finalize payment, process payment, "
        "pay with credit card, buy now, purchase item, "
        "make a payment, billing, charge card"
    ),
    "delete": (
        "Delete, remove, erase, destroy, purge, drop, wipe, trash, "
        "permanently delete, remove all records, clear data, "
        "uninstall, deactivate, close account, bulk delete"
    ),
    "authentication": (
        "Login, sign in, log out, sign out, enter password, "
        "reset password, change password, authenticate, verify identity, "
        "two-factor authentication, create account, register, "
        "forgot password, session expired"
    ),
    "admin": (
        "Admin panel, manage users, system settings, configuration, "
        "control panel, user management, assign roles, permissions, "
        "superuser, root access, elevated privileges, "
        "system configuration, account settings"
    ),
    "posting": (
        "Post comment, publish article, write review, create post, "
        "blog entry, reply to thread, tweet, submit feedback, "
        "leave a review, publish blog post, write a response, "
        "compose article, pin comment"
    ),
    "messaging": (
        "Send message, send email, compose email, reply to message, "
        "forward email, direct message, DM, chat message, "
        "new message, notify user, text message, SMS"
    ),
    "sharing": (
        "Share link, invite user, grant access, forward content, "
        "make public, share on social media, copy link, embed, "
        "share with team, send invitation, publish publicly"
    ),
    "modifying": (
        "Edit record, update profile, change settings, rename file, "
        "modify data, alter configuration, revise document, "
        "save changes, apply changes, overwrite, patch"
    ),
    "downloading": (
        "Download file, export data, save report, export CSV, "
        "export PDF, download all, bulk download, backup data, "
        "extract archive, save as, pull data"
    ),
    "uploading": (
        "Upload file, attach document, import data, import CSV, "
        "drag and drop file, browse files, choose file, "
        "restore backup, bulk import, load data"
    ),
    "financial": (
        "Wire transfer, refund, chargeback, billing, invoice, "
        "account balance, bank transaction, deposit, withdrawal, "
        "process refund, transaction history, statement, "
        "payout, remittance, settlement"
    ),
    "permission": (
        "Change permissions, grant role, revoke access, manage ACL, "
        "set privileges, change user role, promote user, "
        "demote user, add collaborator, restrict access, "
        "role-based access control"
    ),
    "social": (
        "Like post, follow user, unfollow, retweet, share tweet, "
        "upvote, downvote, bookmark, favorite, friend request, "
        "connect on LinkedIn, react to post"
    ),
    "system": (
        "Restart server, deploy to production, execute command, "
        "run script, shutdown service, kill process, "
        "rm -rf, sudo command, terminal command, "
        "reboot system, format disk, rollback deployment"
    ),
    "data_entry": (
        "Fill out form, enter personal information, type in field, "
        "input data, submit form, enter credit card number, "
        "fill address, type SSN, enter date of birth"
    ),
    "sensitive_field": (
        "Credit card number, SSN, social security number, password field, "
        "bank account number, routing number, tax ID, "
        "passport number, drivers license, date of birth, "
        "CVV, security code, secret key"
    ),
    "navigation": (
        "Browse page, view content, click link, scroll down, "
        "open new tab, go to homepage, read article, "
        "navigate to page, visit URL, open menu"
    ),
    "api_call": (
        "Make API request, call webhook, trigger integration, "
        "REST API call, GraphQL query, fetch endpoint, "
        "HTTP request, send POST request, invoke service"
    ),
    "destructive_system": (
        "Format hard drive, factory reset, wipe system, "
        "delete all data permanently, drop database, "
        "rm -rf /, destroy infrastructure, nuke environment"
    ),
}

# Risk levels for each semantic intent
SEMANTIC_RISK_MAP: dict[str, str] = {
    "payment": "high",
    "delete": "high",
    "authentication": "high",
    "admin": "high",
    "financial": "high",
    "permission": "high",
    "system": "high",
    "destructive_system": "critical",
    "sensitive_field": "high",
    "data_entry": "medium",
    "posting": "medium",
    "messaging": "medium",
    "sharing": "medium",
    "modifying": "medium",
    "uploading": "medium",
    "downloading": "medium",
    "social": "low",
    "navigation": "low",
    "api_call": "high",
}


# ═══════════════════════════════════════════════════════════════════════════
# Semantic Match Result
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class SemanticMatch:
    """Result of a semantic intent classification."""
    intent: str
    score: float
    risk: str  # "low", "medium", "high", "critical"
    description: str = ""

    @property
    def confident(self) -> bool:
        """Is this match confident enough to act on?"""
        return self.score >= 0.65


# ═══════════════════════════════════════════════════════════════════════════
# Semantic Matcher — the NLP engine
# ═══════════════════════════════════════════════════════════════════════════

class SemanticMatcher:
    """
    NLP-powered intent classifier using sentence embeddings.

    Usage::

        matcher = SemanticMatcher()           # loads model (~67MB, first time downloads)
        results = matcher.classify("Venmo $50 to John")
        # [SemanticMatch(intent='payment', score=0.72, risk='high'), ...]

        if matcher.matches_intent("payment", "Buy now"):
            print("This is a payment action")

    The matcher is designed as a **singleton** — one instance shared across
    the entire policy engine.  Model loading happens once at first use
    (lazy initialization).
    """

    # Class-level singleton
    _instance: SemanticMatcher | None = None
    _model: Any = None
    _intent_embeddings: np.ndarray | None = None
    _intent_names: list[str] = []
    _ready: bool = False

    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5"):
        self._model_name = model_name

    @classmethod
    def get_instance(cls) -> SemanticMatcher:
        """Get or create the singleton matcher instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _ensure_ready(self) -> bool:
        """Lazy-load the model on first use. Returns True if ready."""
        if self._ready:
            return True

        try:
            from fastembed import TextEmbedding

            t0 = time.time()
            logger.info("Loading semantic model: %s", self._model_name)
            self._model = TextEmbedding(self._model_name)

            # Pre-compute intent embeddings
            self._intent_names = list(SEMANTIC_INTENTS.keys())
            descriptions = list(SEMANTIC_INTENTS.values())
            embeddings = list(self._model.embed(descriptions))
            self._intent_embeddings = np.array(embeddings)

            # Normalize for cosine similarity via dot product
            norms = np.linalg.norm(self._intent_embeddings, axis=1, keepdims=True)
            self._intent_embeddings = self._intent_embeddings / norms

            elapsed = time.time() - t0
            logger.info(
                "Semantic model ready: %d intents, %.1fs load time",
                len(self._intent_names), elapsed,
            )
            self._ready = True
            return True

        except ImportError:
            logger.warning(
                "fastembed not installed — semantic matching disabled. "
                "Install with: pip install fastembed"
            )
            return False
        except Exception as e:
            logger.warning("Failed to load semantic model: %s", e)
            return False

    def classify(
        self,
        text: str,
        threshold: float = 0.55,
        top_k: int = 3,
    ) -> list[SemanticMatch]:
        """
        Classify text into intent categories.

        Args:
            text:      The action text to classify (button text, element text, etc.)
            threshold: Minimum cosine similarity to include (0.0-1.0).
            top_k:     Maximum number of results to return.

        Returns:
            List of SemanticMatch results, sorted by score (highest first).
        """
        if not self._ensure_ready():
            return []

        if not text or not text.strip():
            return []

        # Embed the query text
        query_emb = list(self._model.embed([text]))[0]
        query_norm = np.linalg.norm(query_emb)
        if query_norm > 0:
            query_emb = query_emb / query_norm

        # Cosine similarity via dot product (both normalized)
        similarities = query_emb @ self._intent_embeddings.T

        # Build results above threshold
        results: list[SemanticMatch] = []
        for i, score in enumerate(similarities):
            if score >= threshold:
                intent = self._intent_names[i]
                results.append(SemanticMatch(
                    intent=intent,
                    score=float(score),
                    risk=SEMANTIC_RISK_MAP.get(intent, "medium"),
                    description=SEMANTIC_INTENTS.get(intent, ""),
                ))

        # Sort by score descending, limit to top_k
        results.sort(key=lambda m: -m.score)
        return results[:top_k]

    def classify_top(self, text: str, threshold: float = 0.55) -> SemanticMatch | None:
        """Return the single best matching intent, or None."""
        results = self.classify(text, threshold=threshold, top_k=1)
        return results[0] if results else None

    def matches_intent(
        self,
        intent: str,
        text: str,
        threshold: float = 0.55,
    ) -> bool:
        """Check if text matches a specific intent semantically."""
        results = self.classify(text, threshold=threshold)
        return any(m.intent == intent for m in results)

    def detect_intents(
        self,
        text: str,
        threshold: float = 0.55,
    ) -> list[tuple[str, float]]:
        """
        Detect all intents in text above the threshold.

        Returns list of (intent_name, score) tuples.
        """
        results = self.classify(text, threshold=threshold, top_k=len(SEMANTIC_INTENTS))
        return [(m.intent, m.score) for m in results]

    def get_risk_level(self, text: str, threshold: float = 0.55) -> str:
        """
        Get the highest risk level for the given text.

        Returns: "low", "medium", "high", or "critical"
        """
        results = self.classify(text, threshold=threshold)
        if not results:
            return "low"

        risk_order = {"low": 0, "medium": 1, "high": 2, "critical": 3}
        max_risk = "low"
        for m in results:
            if risk_order.get(m.risk, 0) > risk_order.get(max_risk, 0):
                max_risk = m.risk
        return max_risk

    @property
    def is_available(self) -> bool:
        """Check if the semantic model can be loaded."""
        return self._ensure_ready()

    def add_intent(self, name: str, description: str, risk: str = "medium") -> None:
        """
        Add a custom intent at runtime.

        This lets policy authors define new categories without code changes::

            matcher.add_intent(
                "compliance",
                "regulatory compliance, audit trail, GDPR, HIPAA, SOX",
                risk="high"
            )
        """
        if not self._ensure_ready():
            return

        SEMANTIC_INTENTS[name] = description
        SEMANTIC_RISK_MAP[name] = risk

        # Recompute embedding for the new intent
        new_emb = list(self._model.embed([description]))[0]
        new_emb = new_emb / np.linalg.norm(new_emb)

        self._intent_names.append(name)
        self._intent_embeddings = np.vstack([
            self._intent_embeddings, new_emb.reshape(1, -1)
        ])

    def remove_intent(self, name: str) -> bool:
        """Remove a custom intent."""
        if name not in self._intent_names:
            return False

        idx = self._intent_names.index(name)
        self._intent_names.pop(idx)
        self._intent_embeddings = np.delete(self._intent_embeddings, idx, axis=0)
        SEMANTIC_INTENTS.pop(name, None)
        SEMANTIC_RISK_MAP.pop(name, None)
        return True


# ═══════════════════════════════════════════════════════════════════════════
# Module-level convenience functions
# ═══════════════════════════════════════════════════════════════════════════

def semantic_classify(text: str, threshold: float = 0.55) -> list[SemanticMatch]:
    """Classify text using the global semantic matcher."""
    return SemanticMatcher.get_instance().classify(text, threshold=threshold)


def semantic_detect_intents(text: str, threshold: float = 0.55) -> list[tuple[str, float]]:
    """Detect intents using the global semantic matcher."""
    return SemanticMatcher.get_instance().detect_intents(text, threshold=threshold)


def semantic_risk(text: str, threshold: float = 0.55) -> str:
    """Get the risk level for text using the global semantic matcher."""
    return SemanticMatcher.get_instance().get_risk_level(text, threshold=threshold)


def semantic_matches_intent(intent: str, text: str, threshold: float = 0.55) -> bool:
    """Check if text matches a specific intent semantically."""
    return SemanticMatcher.get_instance().matches_intent(intent, text, threshold=threshold)


def is_semantic_available() -> bool:
    """Check if semantic matching is available (fastembed installed)."""
    try:
        from fastembed import TextEmbedding  # noqa: F401
        return True
    except ImportError:
        return False
