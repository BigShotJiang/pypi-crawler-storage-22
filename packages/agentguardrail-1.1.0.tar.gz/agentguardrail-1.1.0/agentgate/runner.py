"""
AgentGate Runner — The main entry point for running agents securely.

The runner combines all components:
- Launches a controlled browser via Playwright
- Wraps pages with the Interceptor
- Enforces policies via the PolicyEngine
- Records everything in the EvidenceVault
- Manages CapabilityTokens

Usage (Python API):
    from agentgate import SecureBrowser

    async with SecureBrowser(policy="finance-safe") as browser:
        page = await browser.new_page()
        await page.goto("https://bank.com/invoices")  # allowed
        await page.click("button#pay")                # BLOCKED!

Usage (CLI):
    agentgate run --policy finance-safe --agent my-agent
    agentgate replay <session-id>
    agentgate policies list
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Callable

from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from agentgate.policy.engine import (
    Policy,
    PolicyEngine,
    PolicyDecision,
    create_finance_safe_policy,
    create_readonly_policy,
    create_permissive_policy,
)
from agentgate.evidence.vault import EvidenceVault, EvidenceSession
from agentgate.interceptor.browser import InterceptedPage
from agentgate.tokens.capability import CapabilityToken, TokenStore


# ---------------------------------------------------------------------------
# Preset policy registry
# ---------------------------------------------------------------------------

PRESET_POLICIES: dict[str, Callable[[], Policy]] = {
    "finance-safe": create_finance_safe_policy,
    "readonly": create_readonly_policy,
    "permissive": create_permissive_policy,
}


# ---------------------------------------------------------------------------
# SecureBrowser — the developer-facing API
# ---------------------------------------------------------------------------

class SecureBrowser:
    """
    A policy-enforced, evidence-recording browser for AI agents.

    This is the main developer-facing API. It wraps Playwright and adds:
    - Action-level policy enforcement
    - Tamper-evident audit trails
    - Capability token validation
    - Session replay

    Example:
        async with SecureBrowser(policy="finance-safe") as browser:
            page = await browser.new_page()
            await page.goto("https://app.example.com")
            await page.click("#view-invoices")  # ✅ allowed
            await page.click("#pay-now")        # 🚫 BLOCKED
    """

    def __init__(
        self,
        policy: str | Policy | None = None,
        policy_dir: str | Path | None = None,
        evidence_dir: str | Path = "./agentgate_evidence",
        agent_id: str = "default-agent",
        headless: bool = True,
        capture_screenshots: bool = True,
        capture_dom: bool = False,
        on_block: Callable[[PolicyDecision], Any] | None = None,
        on_approval_needed: Callable[[PolicyDecision], Any] | None = None,
        browser_type: str = "chromium",  # chromium, firefox, webkit
    ) -> None:
        self._agent_id = agent_id
        self._headless = headless
        self._capture_screenshots = capture_screenshots
        self._capture_dom = capture_dom
        self._on_block = on_block
        self._on_approval_needed = on_approval_needed
        self._browser_type = browser_type

        # Policy engine
        self._engine = PolicyEngine()
        if isinstance(policy, Policy):
            self._engine.load_policy(policy)
        elif isinstance(policy, str):
            if policy in PRESET_POLICIES:
                self._engine.load_policy(PRESET_POLICIES[policy]())
            else:
                # Try loading from file
                self._engine.load_policy(Policy.from_yaml(policy))
        if policy_dir:
            self._engine.load_policies_from_dir(policy_dir)

        # Evidence vault
        self._vault = EvidenceVault(evidence_dir)
        self._sessions: dict[str, EvidenceSession] = {}

        # Token store
        self._token_store = TokenStore()

        # Playwright state
        self._playwright: Any = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None

    @property
    def engine(self) -> PolicyEngine:
        return self._engine

    @property
    def vault(self) -> EvidenceVault:
        return self._vault

    @property
    def token_store(self) -> TokenStore:
        return self._token_store

    async def launch(self) -> None:
        """Launch the browser."""
        self._playwright = await async_playwright().start()

        launcher = getattr(self._playwright, self._browser_type)
        self._browser = await launcher.launch(headless=self._headless)
        self._context = await self._browser.new_context()

    async def new_page(self, session_id: str | None = None) -> InterceptedPage:
        """Create a new policy-enforced page with evidence recording."""
        if self._browser is None:
            await self.launch()

        assert self._context is not None

        # Create evidence session
        session = await self._vault.start_session(
            agent_id=self._agent_id,
            session_id=session_id,
        )
        self._sessions[session.session_id] = session

        # Create Playwright page
        page = await self._context.new_page()

        # Wrap with interceptor
        return InterceptedPage(
            playwright_page=page,
            policy_engine=self._engine,
            evidence_session=session,
            agent_id=self._agent_id,
            session_id=session.session_id,
            on_block=self._on_block,
            on_approval_needed=self._on_approval_needed,
            capture_screenshots=self._capture_screenshots,
            capture_dom=self._capture_dom,
        )

    async def close(self) -> dict[str, Any]:
        """Close the browser and end all sessions. Returns session summaries."""
        summaries = {}
        for sid, session in self._sessions.items():
            try:
                summary = await session.end()
                summaries[sid] = summary.model_dump()
            except Exception:
                pass

        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

        return summaries

    async def __aenter__(self) -> SecureBrowser:
        await self.launch()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


# ---------------------------------------------------------------------------
# AgentGateRunner — higher-level orchestrator
# ---------------------------------------------------------------------------

class AgentGateRunner:
    """
    High-level runner that orchestrates agent execution with full governance.

    Usage:
        runner = AgentGateRunner(
            policy="finance-safe",
            agent_fn=my_agent_function,
        )
        result = await runner.run()
    """

    def __init__(
        self,
        policy: str | Policy | None = None,
        policy_dir: str | Path | None = None,
        evidence_dir: str | Path = "./agentgate_evidence",
        agent_id: str = "default-agent",
        agent_fn: Callable | None = None,
        headless: bool = True,
        capture_screenshots: bool = True,
    ) -> None:
        self._browser = SecureBrowser(
            policy=policy,
            policy_dir=policy_dir,
            evidence_dir=evidence_dir,
            agent_id=agent_id,
            headless=headless,
            capture_screenshots=capture_screenshots,
        )
        self._agent_fn = agent_fn

    async def run(self, **kwargs: Any) -> dict[str, Any]:
        """Run the agent function with full policy enforcement."""
        async with self._browser as browser:
            page = await browser.new_page()

            result = None
            error = None

            try:
                if self._agent_fn:
                    result = await self._agent_fn(page, **kwargs)
            except Exception as e:
                error = str(e)

            summaries = await browser.close()

            return {
                "result": result,
                "error": error,
                "sessions": summaries,
            }
