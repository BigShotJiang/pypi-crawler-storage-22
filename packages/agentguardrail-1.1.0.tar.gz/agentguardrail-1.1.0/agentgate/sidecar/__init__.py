"""
AgentGate Sidecar — HTTP proxy service for external agent frameworks.

The sidecar runs as a local FastAPI service that any agent framework
(OpenClaw, LangChain, CrewAI, etc.) can call before executing browser
actions. It enforces policies, records evidence, and validates tokens
over a simple REST API.

Usage:
    agentgate sidecar --port 18790 --policy finance-safe
    agentgate sidecar --policy-dir ./policies --evidence-dir ./evidence
"""
