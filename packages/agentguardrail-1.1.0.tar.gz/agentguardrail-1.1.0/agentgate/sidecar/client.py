"""
AgentGate OpenClaw Client — Python SDK for calling the sidecar from any agent.

This module provides a simple, synchronous and async client that wraps
the sidecar REST API. Use it from OpenClaw skills, LangChain tools,
CrewAI agents, or any Python-based agent framework.

Usage:
    from agentgate.sidecar.client import AgentGateClient

    gate = AgentGateClient()  # connects to localhost:18790

    # Check before every browser action
    result = gate.evaluate("click", url="https://bank.com", element_text="Pay Now")
    if result.allowed:
        # proceed with browser action
        ...
    else:
        print(f"Blocked: {result.reason}")
"""

from __future__ import annotations

import time
from typing import Any

import httpx
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------

class GateDecision(BaseModel):
    """Result from evaluating an action against AgentGate policies."""
    allowed: bool
    decision: str
    risk_level: str = ""
    reason: str = ""
    policy_name: str = ""
    matched_rule: str = ""
    action_fingerprint: str = ""
    record_id: str = ""
    timestamp: float = Field(default_factory=time.time)


class GateToken(BaseModel):
    """A capability token issued by AgentGate."""
    token_id: str
    agent_id: str
    expires_at: float = 0
    remaining_ttl: float = 0
    max_actions_total: int | None = None


class GateHealth(BaseModel):
    """Health status of the AgentGate sidecar."""
    status: str = "unknown"
    version: str = ""
    uptime_seconds: float = 0
    active_sessions: int = 0
    policies_loaded: int = 0
    tokens_active: int = 0


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------

class AgentGateClient:
    """
    Synchronous client for the AgentGate sidecar API.

    Use this from OpenClaw skills or any synchronous Python code.

    Example:
        gate = AgentGateClient(port=18790)

        # Check before clicking
        result = gate.check_click("https://bank.com/invoices", "Pay Now")
        if not result.allowed:
            print(f"BLOCKED: {result.reason}")

        # Check before navigating
        result = gate.check_navigate("https://bank.com/admin")
        if not result.allowed:
            print(f"BLOCKED: {result.reason}")
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 18790,
        agent_id: str = "openclaw",
        timeout: float = 5.0,
        token_id: str | None = None,
    ) -> None:
        self.base_url = f"http://{host}:{port}"
        self.agent_id = agent_id
        self.token_id = token_id
        self._client = httpx.Client(base_url=self.base_url, timeout=timeout)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> AgentGateClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # --- Core methods ---

    def evaluate(
        self,
        action_type: str,
        url: str = "",
        selector: str = "",
        element_text: str = "",
        value: str = "",
        session_id: str = "",
        **kwargs: Any,
    ) -> GateDecision:
        """
        Evaluate whether an action should be allowed.

        Call this BEFORE executing any browser action. If the result
        says allowed=False, do NOT execute the action.
        """
        payload = {
            "action_type": action_type,
            "url": url,
            "selector": selector,
            "element_text": element_text,
            "value": value,
            "agent_id": self.agent_id,
            "session_id": session_id,
            "token_id": self.token_id,
            **kwargs,
        }

        try:
            resp = self._client.post("/api/v1/evaluate", json=payload)
            resp.raise_for_status()
            return GateDecision(**resp.json())
        except httpx.ConnectError:
            # Sidecar not running — fail open or closed based on preference
            return GateDecision(
                allowed=False,
                decision="block",
                reason="AgentGate sidecar is not running (connection refused)",
            )
        except Exception as e:
            return GateDecision(
                allowed=False,
                decision="block",
                reason=f"AgentGate error: {e}",
            )

    # --- Convenience methods ---

    def check_navigate(self, url: str) -> GateDecision:
        """Check if navigation to a URL is allowed."""
        return self.evaluate("navigate", url=url)

    def check_click(self, url: str, element_text: str, selector: str = "") -> GateDecision:
        """Check if clicking an element is allowed."""
        return self.evaluate("click", url=url, element_text=element_text, selector=selector)

    def check_type(self, url: str, selector: str, value: str) -> GateDecision:
        """Check if typing into a field is allowed."""
        return self.evaluate("type", url=url, selector=selector, value=value)

    def check_submit(self, url: str, element_text: str = "Submit") -> GateDecision:
        """Check if submitting a form is allowed."""
        return self.evaluate("submit", url=url, element_text=element_text)

    def check_download(self, url: str) -> GateDecision:
        """Check if downloading from a URL is allowed."""
        return self.evaluate("download", url=url)

    def check_upload(self, url: str) -> GateDecision:
        """Check if uploading to a URL is allowed."""
        return self.evaluate("upload", url=url)

    def check_js(self, url: str = "", script: str = "") -> GateDecision:
        """Check if executing JavaScript is allowed."""
        return self.evaluate("evaluate_js", url=url, value=script)

    # --- Token methods ---

    def issue_token(
        self,
        purpose: str = "",
        ttl_minutes: int = 60,
        domains: list[str] | None = None,
        exclude_text: list[str] | None = None,
        max_actions: int | None = None,
    ) -> GateToken:
        """Issue a new capability token."""
        payload = {
            "agent_id": self.agent_id,
            "purpose": purpose,
            "ttl_minutes": ttl_minutes,
            "domains": domains or [],
            "exclude_text": exclude_text or [],
            "max_actions_total": max_actions,
        }
        resp = self._client.post("/api/v1/tokens", json=payload)
        resp.raise_for_status()
        data = resp.json()
        token = GateToken(**data)
        self.token_id = token.token_id  # Use this token for future evaluations
        return token

    def revoke_token(self, token_id: str | None = None, reason: str = "") -> bool:
        """Revoke a capability token."""
        tid = token_id or self.token_id
        if not tid:
            return False
        resp = self._client.post(f"/api/v1/tokens/{tid}/revoke", params={"reason": reason})
        return resp.status_code == 200

    # --- Session methods ---

    def start_session(self, purpose: str = "") -> str:
        """Start a new evidence session. Returns session ID."""
        resp = self._client.post("/api/v1/sessions", json={
            "agent_id": self.agent_id,
            "purpose": purpose,
        })
        resp.raise_for_status()
        return resp.json()["session_id"]

    def end_session(self, session_id: str) -> dict[str, Any]:
        """End a session and save evidence."""
        resp = self._client.post(f"/api/v1/sessions/{session_id}/end")
        resp.raise_for_status()
        return resp.json()

    def list_sessions(self) -> list[dict[str, Any]]:
        """List all evidence sessions."""
        resp = self._client.get("/api/v1/sessions")
        resp.raise_for_status()
        return resp.json()

    def verify_session(self, session_id: str) -> bool:
        """Verify the integrity chain of a session."""
        resp = self._client.get(f"/api/v1/sessions/{session_id}/verify")
        resp.raise_for_status()
        return resp.json().get("chain_valid", False)

    # --- Health ---

    def health(self) -> GateHealth:
        """Check sidecar health."""
        try:
            resp = self._client.get("/api/v1/health")
            resp.raise_for_status()
            return GateHealth(**resp.json())
        except Exception:
            return GateHealth(status="unreachable")

    def is_running(self) -> bool:
        """Check if the sidecar is reachable."""
        return self.health().status == "ok"


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------

class AsyncAgentGateClient:
    """
    Async client for the AgentGate sidecar API.

    Use this from async agent frameworks or async OpenClaw integrations.

    Example:
        async with AsyncAgentGateClient() as gate:
            result = await gate.check_click("https://bank.com", "Pay Now")
            if not result.allowed:
                print(f"BLOCKED: {result.reason}")
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 18790,
        agent_id: str = "openclaw",
        timeout: float = 5.0,
        token_id: str | None = None,
    ) -> None:
        self.base_url = f"http://{host}:{port}"
        self.agent_id = agent_id
        self.token_id = token_id
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=timeout)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncAgentGateClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def evaluate(
        self,
        action_type: str,
        url: str = "",
        selector: str = "",
        element_text: str = "",
        value: str = "",
        session_id: str = "",
        **kwargs: Any,
    ) -> GateDecision:
        """Evaluate whether an action should be allowed (async)."""
        payload = {
            "action_type": action_type,
            "url": url,
            "selector": selector,
            "element_text": element_text,
            "value": value,
            "agent_id": self.agent_id,
            "session_id": session_id,
            "token_id": self.token_id,
            **kwargs,
        }
        try:
            resp = await self._client.post("/api/v1/evaluate", json=payload)
            resp.raise_for_status()
            return GateDecision(**resp.json())
        except httpx.ConnectError:
            return GateDecision(
                allowed=False,
                decision="block",
                reason="AgentGate sidecar is not running (connection refused)",
            )
        except Exception as e:
            return GateDecision(
                allowed=False,
                decision="block",
                reason=f"AgentGate error: {e}",
            )

    async def check_navigate(self, url: str) -> GateDecision:
        return await self.evaluate("navigate", url=url)

    async def check_click(self, url: str, element_text: str, selector: str = "") -> GateDecision:
        return await self.evaluate("click", url=url, element_text=element_text, selector=selector)

    async def check_type(self, url: str, selector: str, value: str) -> GateDecision:
        return await self.evaluate("type", url=url, selector=selector, value=value)

    async def check_js(self, url: str = "", script: str = "") -> GateDecision:
        return await self.evaluate("evaluate_js", url=url, value=script)

    async def health(self) -> GateHealth:
        try:
            resp = await self._client.get("/api/v1/health")
            resp.raise_for_status()
            return GateHealth(**resp.json())
        except Exception:
            return GateHealth(status="unreachable")

    async def is_running(self) -> bool:
        h = await self.health()
        return h.status == "ok"
