"""Capability tokens for AgentGate — scoped, time-bound agent permissions."""
