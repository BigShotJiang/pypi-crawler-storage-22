"""
🛡️  AgentGate — Live Demo
=========================
Run this to SEE AgentGate working in real-time.
No browser needed. No sidecar needed. Just run it.

    python demo.py

This simulates an AI agent trying to do things on a banking website,
and AgentGate blocks the dangerous stuff.
"""

from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    PolicyEngine,
    Policy,
    Decision,
    RiskLevel,
    classify_risk,
    create_finance_safe_policy,
)
from agentgate.evidence.vault import EvidenceVault
from agentgate.tokens.capability import CapabilityToken, Scope, TokenStore

import time


def header(text: str):
    print(f"\n{'='*60}")
    print(f"  {text}")
    print(f"{'='*60}")


def main():
    header("🛡️  AgentGate v0.1.0 — Live Demo")
    print("  Simulating an AI agent browsing a banking website.")
    print("  AgentGate evaluates every action BEFORE it happens.\n")

    # ─────────────────────────────────────────────────────────
    # STEP 1: Load a policy
    # ─────────────────────────────────────────────────────────
    header("STEP 1: Load the 'finance-safe' policy")

    engine = PolicyEngine()
    policy = create_finance_safe_policy()
    engine.load_policy(policy)

    print(f"  Policy: {policy.name}")
    print(f"  Rules:  {len(policy.rules)} action rules")
    print(f"  JS blocked:       {policy.block_js_evaluation}")
    print(f"  Clipboard blocked: {policy.block_clipboard}")
    print(f"  Downloads blocked: {policy.block_all_downloads}")

    # ─────────────────────────────────────────────────────────
    # STEP 2: Simulate agent actions
    # ─────────────────────────────────────────────────────────
    header("STEP 2: Simulate AI agent actions")
    print("  The agent tries 10 browser actions. Watch what happens.\n")

    actions = [
        ("Navigate to bank.com/dashboard", ActionType.NAVIGATE,
         {"url": "https://bank.com/dashboard"}),

        ("Click 'View Invoices'", ActionType.CLICK,
         {"url": "https://bank.com/dashboard", "element_text": "View Invoices"}),

        ("Navigate to invoice detail", ActionType.NAVIGATE,
         {"url": "https://bank.com/invoices/INV-2024-001"}),

        ("Click 'Pay Now' 💰", ActionType.CLICK,
         {"url": "https://bank.com/invoices/INV-2024-001", "element_text": "Pay Now"}),

        ("Click 'Delete Invoice' 🗑️", ActionType.CLICK,
         {"url": "https://bank.com/invoices/INV-2024-001", "element_text": "Delete Invoice"}),

        ("Click 'Submit Report'", ActionType.CLICK,
         {"url": "https://bank.com/reports/new", "element_text": "Submit Report"}),

        ("Type in search box", ActionType.TYPE,
         {"url": "https://bank.com/search", "selector": "input[name='q']", "value": "Q4 report"}),

        ("Type in password field 🔑", ActionType.TYPE,
         {"url": "https://bank.com/login", "selector": "input[type='password']", "value": "secret123"}),

        ("Execute JavaScript", ActionType.EVALUATE_JS,
         {"url": "https://bank.com", "value": "document.cookie"}),

        ("Navigate to admin panel", ActionType.NAVIGATE,
         {"url": "https://bank.com/admin/users"}),
    ]

    allowed = 0
    blocked = 0
    approval = 0

    for name, action_type, kwargs in actions:
        event = ActionEvent(action_type=action_type, **kwargs)
        risk = classify_risk(event)
        result = engine.evaluate(event)

        if result.decision == Decision.ALLOW:
            icon = "✅"
            status = "ALLOWED"
            allowed += 1
        elif result.decision == Decision.BLOCK:
            icon = "🚫"
            status = "BLOCKED"
            blocked += 1
        elif result.decision == Decision.REQUIRE_APPROVAL:
            icon = "⚠️ "
            status = "NEEDS APPROVAL"
            approval += 1
        else:
            icon = "📝"
            status = "LOGGED"
            allowed += 1

        print(f"  {icon} {name}")
        print(f"     → {status}  |  Risk: {risk.value}  |  {result.reason}")
        print()

    print(f"  ────────────────────────────────────")
    print(f"  ✅ Allowed:  {allowed}")
    print(f"  🚫 Blocked:  {blocked}")
    print(f"  ⚠️  Approval: {approval}")
    print(f"  Total:       {allowed + blocked + approval}")

    # ─────────────────────────────────────────────────────────
    # STEP 3: Evidence Vault
    # ─────────────────────────────────────────────────────────
    header("STEP 3: Evidence Vault — tamper-proof audit trail")

    import asyncio

    async def demo_evidence():
        vault = EvidenceVault(storage_dir="demo_evidence")
        session = await vault.start_session(agent_id="demo-agent")
        print(f"  Session started: {session.session_id[:16]}...")

        # Record a few actions
        for name, action_type, kwargs in actions[:5]:
            event = ActionEvent(action_type=action_type, **kwargs)
            result = engine.evaluate(event)
            record = await session.record(
                event=event,
                decision=result,
            )

        summary = await session.end()

        # Verify integrity
        is_valid = await vault.verify_session(session.session_id)
        print(f"  Records saved:   5")
        print(f"  Chain integrity: {'✅ VERIFIED' if is_valid else '❌ TAMPERED'}")
        print(f"  Storage:         demo_evidence/{session.session_id[:16]}...")
        print(f"\n  Each record is SHA-256 hash-chained to the previous one.")
        print(f"  If anyone modifies a record, the chain breaks. Like blockchain.")

        # Cleanup
        import shutil
        shutil.rmtree("demo_evidence", ignore_errors=True)

    asyncio.run(demo_evidence())

    # ─────────────────────────────────────────────────────────
    # STEP 4: Capability Tokens
    # ─────────────────────────────────────────────────────────
    header("STEP 4: Capability Tokens — scoped, time-limited permissions")

    token = CapabilityToken.create(
        agent_id="finance-bot",
        issuer="admin@company.com",
        purpose="Read Q4 invoices only",
        scopes=[
            Scope(
                domains=["bank.com"],
                exclude_text=["Pay", "Transfer", "Delete"],
                max_risk=RiskLevel.MEDIUM,
            ),
        ],
        ttl_minutes=30,
        max_actions_total=100,
    )

    print(f"  Token ID:    {token.token_id[:16]}...")
    print(f"  Agent:       {token.agent_id}")
    print(f"  Purpose:     {token.purpose}")
    print(f"  Expires in:  {token.remaining_ttl:.0f} seconds")
    print(f"  Max actions: {token.max_actions_total}")
    print(f"  Domains:     {token.scopes[0].domains}")
    print(f"  Blocked text: {token.scopes[0].exclude_text}")

    # Test the token
    print(f"\n  Testing token against actions:")

    token_tests = [
        ("View Invoice on bank.com", ActionEvent(
            action_type=ActionType.CLICK,
            url="https://bank.com/invoices",
            element_text="View Invoice",
            agent_id="finance-bot",
        )),
        ("Pay Now on bank.com", ActionEvent(
            action_type=ActionType.CLICK,
            url="https://bank.com/invoices",
            element_text="Pay Now",
            agent_id="finance-bot",
        )),
        ("Browse evil.com", ActionEvent(
            action_type=ActionType.NAVIGATE,
            url="https://evil.com",
            agent_id="finance-bot",
        )),
    ]

    for name, event in token_tests:
        validation = token.validate(event)
        icon = "✅" if validation.valid else "🚫"
        reason = "Allowed by token" if validation.valid else validation.reason
        print(f"    {icon} {name} → {reason}")

    # ─────────────────────────────────────────────────────────
    # STEP 5: Try different policies
    # ─────────────────────────────────────────────────────────
    header("STEP 5: Try different policies")

    from agentgate.policy.engine import create_readonly_policy, create_permissive_policy

    policies_to_test = [
        ("readonly", create_readonly_policy()),
        ("permissive", create_permissive_policy()),
    ]

    test_event = ActionEvent(
        action_type=ActionType.CLICK,
        url="https://example.com",
        element_text="Pay Now",
    )

    for name, pol in policies_to_test:
        eng = PolicyEngine()
        eng.load_policy(pol)
        result = eng.evaluate(test_event)
        icon = "✅" if result.decision == Decision.ALLOW else "🚫" if result.decision == Decision.BLOCK else "⚠️"
        print(f"  {icon} Policy '{name}' → Click 'Pay Now' → {result.decision.value}: {result.reason}")

    # Also test OpenClaw policy files
    import os
    if os.path.exists("skills/agentgate/policies"):
        print()
        for f in sorted(os.listdir("skills/agentgate/policies")):
            if f.endswith(".yaml"):
                pol = Policy.from_yaml(f"skills/agentgate/policies/{f}")
                eng = PolicyEngine()
                eng.load_policy(pol)
                result = eng.evaluate(test_event)
                icon = "✅" if result.decision == Decision.ALLOW else "🚫" if result.decision == Decision.BLOCK else "⚠️"
                print(f"  {icon} Policy '{pol.name}' → Click 'Pay Now' → {result.decision.value}: {result.reason}")

    # ─────────────────────────────────────────────────────────
    # DONE
    # ─────────────────────────────────────────────────────────
    header("🎉 Demo Complete!")
    print("""
  What you just saw:
  ──────────────────
  1. POLICY ENGINE    — YAML rules decide allow/block/require_approval
  2. RISK CLASSIFIER  — Auto-detects danger level of each action
  3. EVIDENCE VAULT   — Hash-chained audit trail (tamper-proof)
  4. CAPABILITY TOKENS— Scoped, time-limited agent permissions
  5. MULTIPLE POLICIES— Different rules for different use cases

  Next steps:
  ───────────
  • Run the sidecar for any agent:
      agentgate sidecar --policy finance-safe

  • Use with a real browser (needs Playwright):
      python examples/basic_usage.py

  • Launch the dashboard:
      agentgate dashboard

  • Write your own policy:
      See policies/finance-safe.yaml

  • Read the docs:
      docs/GUIDE.md         — Non-tech user guide
      docs/ARCHITECTURE.md  — How it all works
      docs/AGENTS.md        — Which agents are compatible
      docs/OPERATIONS.md    — Config & deployment
""")


if __name__ == "__main__":
    main()
