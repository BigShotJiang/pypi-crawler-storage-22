# 🤖 Agent Compatibility & Scaling Guide

> Which AI agents work with AgentGate, how to integrate each one, and how to scale to multi-agent deployments.

---

## Compatibility Matrix

| Agent Framework | Stars | Language | Integration Method | Effort | Status |
|---|---|---|---|---|---|
| **OpenClaw** | 202k ⭐ | TypeScript | Sidecar + Skill | 5 min | ✅ Ready |
| **browser-use** | 78k ⭐ | Python | Direct (SecureBrowser) | 3 lines | ✅ Ready |
| **Playwright agents** | — | Python | Direct (SecureBrowser) | 3 lines | ✅ Ready |
| **Anthropic Computer Use** | — | Python | Sidecar API | 10 lines | ✅ Ready |
| **OpenAI CUA** | — | Python/TS | Sidecar API | 10 lines | ✅ Ready |
| **LangChain** | 105k ⭐ | Python | Sidecar or Direct | 5 lines | ✅ Ready |
| **CrewAI** | 25k ⭐ | Python | Sidecar or Direct | 5 lines | ✅ Ready |
| **AutoGPT** | 170k ⭐ | Python | Sidecar API | 10 lines | ✅ Ready |
| **Microsoft AutoGen** | 40k ⭐ | Python | Sidecar API | 10 lines | ✅ Ready |
| **Semantic Kernel** | 22k ⭐ | C#/Python | Sidecar API | 10 lines | ✅ Ready |
| **Vercel AI SDK** | 12k ⭐ | TypeScript | Sidecar API (HTTP) | 15 lines | ✅ Ready |
| **Custom agents** | — | Any | Sidecar REST API | Varies | ✅ Ready |

**Bottom line:** If your agent can make HTTP calls, it works with AgentGate.

---

## Integration Patterns

### Pattern 1: Direct Python Integration (Best for Python agents)

Use `SecureBrowser` — wraps Playwright so every action is policy-enforced at the code level.

```python
from agentgate import SecureBrowser
from agentgate.interceptor.browser import ActionBlockedError

async with SecureBrowser(policy="finance-safe") as browser:
    page = await browser.new_page()

    await page.goto("https://bank.com")      # ← Intercepted, checked, recorded
    await page.click("#view-invoices")         # ← Intercepted, checked, recorded

    try:
        await page.click("#pay-now")           # ← Intercepted → BLOCKED
    except ActionBlockedError as e:
        print(f"Blocked: {e}")
```

**Works with:** browser-use, Playwright-based agents, custom Python agents.

**Pros:** Zero network overhead, lowest latency, most secure (no way to bypass).  
**Cons:** Python-only, requires code changes.

---

### Pattern 2: Sidecar HTTP API (Best for non-Python agents)

Run AgentGate as a sidecar service. The agent makes an HTTP call before every action.

```bash
# Start the sidecar
agentgate sidecar --policy finance-safe --port 18790
```

**From any language:**

```bash
# Before clicking a button:
curl -X POST http://localhost:18790/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{"action_type": "click", "url": "https://bank.com", "element_text": "Pay Now"}'

# Response:
# {"allowed": false, "decision": "block", "reason": "Element blocked: ['Pay']"}
```

**TypeScript example (for OpenClaw, Vercel AI SDK):**

```typescript
async function checkAction(actionType: string, url: string, elementText: string): Promise<boolean> {
  const response = await fetch('http://localhost:18790/api/v1/evaluate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action_type: actionType,
      url: url,
      element_text: elementText,
      agent_id: 'my-agent',
    }),
  });
  const data = await response.json();
  return data.allowed;
}

// Before clicking:
if (await checkAction('click', 'https://bank.com', 'Pay Now')) {
  await page.click('#pay-now');
} else {
  console.log('Action blocked by AgentGate');
}
```

**C# example (for Semantic Kernel):**

```csharp
var client = new HttpClient();
var payload = new {
    action_type = "click",
    url = "https://bank.com",
    element_text = "Pay Now"
};
var response = await client.PostAsJsonAsync("http://localhost:18790/api/v1/evaluate", payload);
var result = await response.Content.ReadFromJsonAsync<EvaluateResult>();

if (!result.Allowed) {
    Console.WriteLine($"Blocked: {result.Reason}");
}
```

**Pros:** Language-agnostic, works with any framework.  
**Cons:** Network overhead (~1ms per call), requires running a sidecar process.

---

### Pattern 3: Python SDK Client (Best for Python agents calling the sidecar)

When you want the sidecar's flexibility but with a nice Python API:

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="my-agent")

# Before each action, check:
if gate.check_navigate("https://bank.com").allowed:
    await page.goto("https://bank.com")

if gate.check_click("https://bank.com", "View Invoice").allowed:
    await page.click("#view-invoice")

result = gate.check_click("https://bank.com", "Pay Now")
if not result.allowed:
    print(f"Blocked: {result.reason}")
```

---

## Agent-Specific Integration Guides

### OpenClaw

OpenClaw is a TypeScript-based personal AI assistant. Integration uses the sidecar + skill pattern.

**Setup:**

```bash
# 1. Start AgentGate sidecar
agentgate sidecar --policy finance-safe --port 18790

# 2. Copy the skill to OpenClaw
cp -r skills/agentgate/ ~/.openclaw/workspace/skills/
```

**How it works:**
- OpenClaw loads the `SKILL.md` and learns the AgentGate API
- Before every browser action, OpenClaw calls `/api/v1/evaluate`
- If blocked, OpenClaw tells the user and suggests alternatives
- Every action is recorded in the evidence vault

**Policies included:**
- `openclaw-default.yaml` — Balanced (blocks payments, deletes; requires approval for submissions)
- `openclaw-strict.yaml` — Maximum safety (blocks everything except reading)

---

### browser-use

The most popular Python browser automation for AI agents (78k ⭐).

```python
from browser_use import Agent
from agentgate import SecureBrowser

async with SecureBrowser(policy="finance-safe") as browser:
    page = await browser.new_page()

    # Pass the policy-enforced page to browser-use
    agent = Agent(
        task="Check my latest invoices on bank.com",
        page=page.page,  # The underlying Playwright page (already wrapped)
    )
    await agent.run()
```

---

### Anthropic Computer Use

Claude's computer-use feature can control a browser. Wrap the browser with AgentGate:

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="claude-computer-use")

# In your Anthropic computer-use handler:
def handle_browser_action(action):
    if action.type == "click":
        result = gate.check_click(action.url, action.element_text)
    elif action.type == "navigate":
        result = gate.check_navigate(action.url)
    elif action.type == "type":
        result = gate.check_type(action.url, action.selector, action.value)

    if not result.allowed:
        return {"error": f"Blocked by AgentGate: {result.reason}"}

    # Proceed with the action
    return execute_action(action)
```

---

### LangChain

```python
from langchain.tools import Tool
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="langchain-agent")

def safe_browse(url: str) -> str:
    """Browse a URL, enforced by AgentGate policies."""
    result = gate.check_navigate(url)
    if not result.allowed:
        return f"Access denied: {result.reason}"
    # ... proceed with actual browsing ...
    return "Page content here"

browse_tool = Tool(
    name="safe_browse",
    func=safe_browse,
    description="Browse a URL with AgentGate policy enforcement",
)
```

---

### CrewAI

```python
from crewai import Agent, Task
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="crewai-researcher")

class SafeBrowseTool:
    """Browser tool with AgentGate enforcement."""

    def run(self, url: str, action: str = "navigate", element_text: str = ""):
        result = gate.evaluate(action, url=url, element_text=element_text)
        if not result.allowed:
            return f"🚫 Blocked: {result.reason}"
        # ... execute action ...
        return "Action completed"
```

---

### Custom Agent (Any Language)

If you're building your own agent in any language, integrate via HTTP:

**Before every browser action:**

```
POST http://localhost:18790/api/v1/evaluate
Content-Type: application/json

{
  "action_type": "click",         // navigate, click, type, submit, download, upload, evaluate_js
  "url": "https://example.com",   // Current page URL
  "element_text": "Pay Now",      // Text of the element being acted on
  "selector": "#pay-button",      // CSS selector (optional)
  "value": "",                    // For type actions: the value being typed
  "agent_id": "my-custom-agent"   // Your agent's identifier
}
```

**Check the response:**

```json
{
  "allowed": false,
  "decision": "block",
  "risk_level": "high",
  "reason": "Element blocked: ['Pay']",
  "policy_name": "finance-safe",
  "action_fingerprint": "a1b2c3d4e5f6",
  "record_id": "rec_789012"
}
```

**If `allowed` is `true`:** proceed with the action.  
**If `allowed` is `false`:** do NOT execute the action.

---

## Scaling

### Single Agent, Single Policy

The default setup. One agent, one policy, one sidecar.

```
┌────────┐     ┌───────────────┐     ┌─────────┐
│ Agent  │────▶│ AgentGate     │────▶│ Browser │
│        │◀────│ (sidecar)     │◀────│         │
└────────┘     └───────────────┘     └─────────┘
```

### Single Agent, Multiple Policies

Load multiple policies. The most restrictive wins.

```bash
agentgate sidecar --policy-dir ./policies
# Loads: finance-safe.yaml + procurement-safe.yaml + support-agent.yaml
# Result: All three policies are evaluated, strictest decision wins
```

### Multiple Agents, Shared Sidecar

Multiple agents can share one sidecar. Each agent identifies itself via `agent_id`.

```
┌──────────┐
│ Agent A  │──┐
└──────────┘  │     ┌───────────────┐     ┌─────────┐
              ├────▶│ AgentGate     │────▶│ Browser │
┌──────────┐  │     │ (sidecar)     │     │         │
│ Agent B  │──┘     └───────────────┘     └─────────┘
└──────────┘
```

Evidence sessions are tracked per agent_id, so you get separate audit trails.

### Multiple Agents, Separate Sidecars

For isolation, run one sidecar per agent on different ports:

```bash
# Agent A: Finance policy on port 18790
agentgate sidecar --policy finance-safe --port 18790 --agent-id agent-a

# Agent B: Readonly policy on port 18791
agentgate sidecar --policy readonly --port 18791 --agent-id agent-b
```

### High-Availability Deployment

For production systems that need uptime:

```
                    ┌─────────────────┐
                    │  Load Balancer  │
                    └────────┬────────┘
                    ┌────────┼────────┐
                    ▼        ▼        ▼
            ┌──────────┐ ┌──────────┐ ┌──────────┐
            │ Sidecar  │ │ Sidecar  │ │ Sidecar  │
            │ (port    │ │ (port    │ │ (port    │
            │  18790)  │ │  18791)  │ │  18792)  │
            └──────────┘ └──────────┘ └──────────┘
```

Each sidecar is stateless (policies are loaded from disk). Evidence can be written to shared storage (NFS, S3 — coming in v0.2.0).

### Kubernetes Deployment (Coming in Phase 3)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agentgate-sidecar
spec:
  replicas: 3
  template:
    spec:
      containers:
        - name: agentgate
          image: agentgate/sidecar:latest
          ports:
            - containerPort: 18790
          volumeMounts:
            - name: policies
              mountPath: /etc/agentgate/policies
      volumes:
        - name: policies
          configMap:
            name: agentgate-policies
```

---

## Performance

### Latency

| Operation | Latency |
|---|---|
| Policy evaluation (in-process) | < 0.1 ms |
| Sidecar API call (localhost) | ~1-2 ms |
| Evidence recording | ~0.5 ms |
| Token validation | < 0.1 ms |
| Hash chain verification (100 records) | ~5 ms |

### Throughput

The sidecar can handle **~5,000 evaluations/second** on a single core. For most use cases (browser automation is limited by browser speed), this is orders of magnitude more than needed.

### Memory

| Component | Memory |
|---|---|
| Policy engine (10 policies) | ~2 MB |
| Evidence session (1000 records) | ~5 MB |
| Token store (100 tokens) | ~1 MB |
| Sidecar server (idle) | ~30 MB |
| Total typical | ~40 MB |

---

## Roadmap for Agent Support

### Phase 2 (Next)
- [ ] MCP (Model Context Protocol) gateway — integrate with MCP-based agents
- [ ] WebSocket real-time monitoring — live dashboards
- [ ] Approval workflows — Slack/Teams/email notifications for REQUIRE_APPROVAL decisions
- [ ] Multi-agent orchestration — coordinated sessions across agents
- [ ] SIEM export — Splunk, Datadog, Azure Sentinel

### Phase 3 (Future)
- [ ] TypeScript/JavaScript native SDK — no sidecar needed for Node.js agents
- [ ] Go SDK — for Go-based agents
- [ ] Kubernetes operator — auto-inject AgentGate sidecars
- [ ] Policy marketplace — share and download community policies
- [ ] Agent registry — track all agents in an organization
- [ ] Compliance reporting — SOC 2, ISO 27001, GDPR audit reports
