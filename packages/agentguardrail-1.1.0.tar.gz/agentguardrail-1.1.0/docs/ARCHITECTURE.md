# 🏗️ AgentGate Architecture

> A deep-dive into how every module works, how they connect, and why they're designed this way.

---

## System Overview

```
                    ┌─────────────────────────────────────────────┐
                    │            AgentGate Runtime                │
                    │                                             │
  Agent Request     │  ┌───────────────────────────────────────┐  │
  (click, type,     │  │          Action Interceptor            │  │
   navigate, etc)──▶│  │  Wraps Playwright Page object.         │  │
                    │  │  Every method call is intercepted.      │  │
                    │  └──────────────┬────────────────────────┘  │
                    │                 │                            │
                    │                 ▼                            │
                    │  ┌───────────────────────────────────────┐  │
                    │  │          Policy Engine                 │  │
                    │  │  Loads YAML rules. Classifies risk.    │  │
                    │  │  Returns: ALLOW / BLOCK / APPROVAL     │  │
                    │  └──────────────┬────────────────────────┘  │
                    │                 │                            │
                    │       ┌─────────┼─────────┐                 │
                    │       ▼                   ▼                  │
                    │  ┌──────────────┐  ┌───────────────────┐    │
                    │  │ Evidence     │  │ Capability        │    │
                    │  │ Vault        │  │ Tokens            │    │
                    │  │              │  │                   │    │
                    │  │ Records      │  │ Validates scoped  │    │
                    │  │ every action │  │ permissions       │    │
                    │  │ in a hash    │  │ (domain, TTL,     │    │
                    │  │ chain        │  │  action limits)   │    │
                    │  └──────────────┘  └───────────────────┘    │
                    │                                             │
                    └──────────────────┬──────────────────────────┘
                                       │
                                       ▼
                               Target Website
```

---

## Module Reference

### 1. Policy Engine (`agentgate/policy/engine.py`)

**Purpose:** Evaluate every agent action against loaded YAML policies and return a decision.

**Key classes:**

| Class | Role |
|---|---|
| `ActionType` | Enum of 15 action types: `navigate`, `click`, `type`, `submit`, `download`, `upload`, `evaluate_js`, `scroll`, `select`, `hover`, `press`, `copy`, `screenshot`, `wait`, `drag` |
| `RiskLevel` | Enum: `none`, `low`, `medium`, `high`, `critical` |
| `Decision` | Enum: `allow`, `block`, `require_approval`, `log_only` |
| `ActionEvent` | Pydantic model — represents one action an agent wants to take (type, URL, selector, element text, value) |
| `PolicyDecision` | Pydantic model — the engine's verdict (decision, risk, reason, matched rule, fingerprint) |
| `URLRule` | Pattern-based URL matching rule |
| `ElementRule` | Selector/text-based element matching rule |
| `ActionRule` | Binds URL + element rules to an action type |
| `Policy` | Complete policy with global settings + rules. Loads from YAML. |
| `PolicyEngine` | Loads multiple policies, evaluates events, most-restrictive-wins. |

**How evaluation works:**

```
1. Engine receives an ActionEvent
2. Auto-classify risk based on keywords:
   - "Pay", "Delete", "Admin" → HIGH
   - "Submit", "Confirm" → MEDIUM
   - "View", "Read" → LOW
3. For each loaded policy:
   a. Check global blocks (JS, downloads, uploads, clipboard)
   b. Check domain restrictions (allowlist/blocklist)
   c. Check rate limits
   d. Check action-specific rules (URL patterns, element selectors, text matches)
   e. Check risk thresholds
4. Collect all decisions
5. Return the most restrictive: BLOCK > REQUIRE_APPROVAL > LOG_ONLY > ALLOW
```

**Risk auto-classification keywords:**

| Risk | Keywords |
|---|---|
| HIGH | pay, transfer, wire, delete, remove, purge, admin, password, credit_card |
| MEDIUM | submit, confirm, approve, send, upload, export |
| LOW | view, read, scroll, navigate, search |
| CRITICAL | System admin, production deployment, root access |

---

### 2. Action Interceptor (`agentgate/interceptor/browser.py`)

**Purpose:** Wrap a Playwright `Page` object so every browser method goes through the policy engine first.

**Key classes:**

| Class | Role |
|---|---|
| `InterceptedPage` | Wraps `playwright.Page`. Overrides every mutation method. |
| `ActionBlockedError` | Raised when a policy blocks an action. |
| `ApprovalRequiredError` | Raised when a policy requires human approval. |

**Intercepted methods:**

| Method | ActionType | What it does |
|---|---|---|
| `page.goto(url)` | `navigate` | Checks URL against rules before navigating |
| `page.click(selector)` | `click` | Resolves element text/tag, checks rules |
| `page.fill(selector, value)` | `type` | Checks if typing into this field is allowed |
| `page.type(selector, text)` | `type` | Same as fill |
| `page.press(selector, key)` | `press` | Checks key-press actions |
| `page.select_option(...)` | `select` | Checks dropdown selections |
| `page.set_input_files(...)` | `upload` | Checks upload permissions |
| `page.evaluate(js)` | `evaluate_js` | Checks JS execution permissions |
| `page.screenshot(...)` | `screenshot` | Records but generally allowed |

**How interception works:**

```python
# Without AgentGate — direct Playwright:
await page.click("#pay-button")  # Nothing stops it

# With AgentGate — InterceptedPage wraps page:
intercepted = InterceptedPage(page, policy_engine, evidence_session)
await intercepted.click("#pay-button")
#   ↓ InterceptedPage resolves "#pay-button" → element_text="Pay Now"
#   ↓ Creates ActionEvent(type=click, text="Pay Now", url=current_url)
#   ↓ Sends to PolicyEngine.evaluate()
#   ↓ Decision: BLOCK (text matches "Pay")
#   ↓ Records in EvidenceVault
#   ↓ Raises ActionBlockedError("Payment actions blocked")
```

---

### 3. Evidence Vault (`agentgate/evidence/vault.py`)

**Purpose:** Create tamper-evident audit trails for every agent session.

**Key classes:**

| Class | Role |
|---|---|
| `EvidenceRecord` | One record: action, decision, timestamps, hashes, chain link |
| `EvidenceSession` | A session of records with hash chaining |
| `SessionSummary` | Stats at session end: allowed/blocked counts, risk, chain validity |
| `EvidenceVault` | Manages sessions, storage (JSONL files), retrieval, export |

**Hash chaining:**

Each record's hash includes the previous record's hash, creating an append-only verifiable log:

```
Record #1: hash = SHA256(record_1_data + "genesis")
Record #2: hash = SHA256(record_2_data + hash_of_record_1)
Record #3: hash = SHA256(record_3_data + hash_of_record_2)
...
```

If anyone modifies Record #2, its hash changes, which breaks Record #3's chain. Verification walks the chain from genesis and recomputes every hash.

**Storage format:**

```
agentgate_evidence/
└── ses_a1b2c3d4e5f6/
    ├── evidence.jsonl      # Append-only records (one JSON per line)
    ├── screenshots/        # Screenshot PNGs (hashed)
    │   ├── 000001.png
    │   └── 000002.png
    ├── summary.json        # Session summary (after end)
    └── export.json         # Full export (on demand)
```

**Sensitive value redaction:**

Values matching patterns like `password`, `secret`, `token`, `card`, `cvv`, `ssn` are automatically redacted in evidence records: `"secret123"` → `"***t123"`.

---

### 4. Capability Tokens (`agentgate/tokens/capability.py`)

**Purpose:** Issue scoped, time-bound, revocable permissions to agents.

**Key classes:**

| Class | Role |
|---|---|
| `Scope` | What's allowed: domains, URL patterns, excluded text/selectors, risk level, read-only |
| `CapabilityToken` | Token with: scopes, time bounds, rate limits, HMAC signature |
| `TokenValidation` | Result of validating a token against an action |
| `TokenStore` | In-memory store with lookup, revocation, expiry cleanup |

**Token lifecycle:**

```
1. ISSUE — Create token with scopes, TTL, action limits
   ↓
2. VALIDATE — Before each action, check token against the ActionEvent
   ├── Check: not revoked
   ├── Check: within time bounds (valid_from → valid_until)
   ├── Check: agent ID matches
   ├── Check: action count under limit
   ├── Check: each scope allows the action (domain, URL, text, risk)
   └── Result: valid=true/false with reason
   ↓
3. USE — Increment action counter
   ↓
4. REVOKE — Instant revocation (by admin, on error, or programmatically)
   ↓
5. EXPIRE — Automatic when TTL runs out
```

**HMAC signing:**

Tokens are signed with HMAC-SHA256. The signature covers `token_id:agent_id:issued_at:valid_until`. This prevents forgery — if anyone modifies a token, the signature won't match.

---

### 5. Sidecar Service (`agentgate/sidecar/service.py`)

**Purpose:** REST API proxy for external agent frameworks (OpenClaw, browser-use, etc.)

**Why a sidecar?**

Most agent frameworks are written in different languages (TypeScript for OpenClaw, Python for browser-use). The sidecar pattern provides a **language-agnostic HTTP API** that any agent can call before taking actions.

```
Agent (any language)  ──HTTP──▶  AgentGate Sidecar (Python/FastAPI)  ──▶  Browser
```

**Endpoints (16 total):**

| Group | Endpoint | Method | Purpose |
|---|---|---|---|
| **Core** | `/api/v1/evaluate` | POST | Check if an action is allowed |
| | `/api/v1/evaluate/batch` | POST | Preflight check multiple actions |
| **Evidence** | `/api/v1/sessions` | POST | Start session |
| | `/api/v1/sessions` | GET | List sessions |
| | `/api/v1/sessions/{id}` | GET | Session details |
| | `/api/v1/sessions/{id}/end` | POST | End session |
| | `/api/v1/sessions/{id}/records` | GET | Get records |
| | `/api/v1/sessions/{id}/verify` | GET | Verify chain |
| **Tokens** | `/api/v1/tokens` | POST | Issue token |
| | `/api/v1/tokens` | GET | List tokens |
| | `/api/v1/tokens/validate` | POST | Validate token |
| | `/api/v1/tokens/{id}/revoke` | POST | Revoke token |
| **Policies** | `/api/v1/policies` | GET | List policies |
| | `/api/v1/policies/load` | POST | Load YAML policy |
| **Ops** | `/api/v1/health` | GET | Health check |
| | `/api/v1/record` | POST | Manual recording |

---

### 6. Python SDK Client (`agentgate/sidecar/client.py`)

**Purpose:** Convenience wrapper for calling the sidecar from Python code.

**Two clients:**

| Client | Use Case |
|---|---|
| `AgentGateClient` | Synchronous — for scripts, OpenClaw skills, simple agents |
| `AsyncAgentGateClient` | Async — for asyncio-based frameworks |

**Fail-closed behavior:**

If the sidecar is unreachable (crashed, not started), the client returns `allowed=False`. The AI is blocked until the sidecar is back online. This is a security design choice — we never fail open.

---

### 7. CLI (`agentgate/cli.py`)

**Purpose:** Command-line interface for managing policies, sessions, and the sidecar.

**Commands:**

| Command | Action |
|---|---|
| `agentgate init` | Scaffold a new project |
| `agentgate policies list` | Show loaded policies |
| `agentgate policies show <name>` | Display policy details |
| `agentgate sessions list` | List evidence sessions |
| `agentgate sessions replay <id>` | Replay a session timeline |
| `agentgate sessions verify <id>` | Verify hash chain integrity |
| `agentgate sessions export <id>` | Export to JSON |
| `agentgate sidecar` | Start the HTTP sidecar |
| `agentgate dashboard` | Launch web dashboard |
| `agentgate version` | Show version |

---

### 8. Dashboard (`agentgate/dashboard/app.py`)

**Purpose:** Web UI for monitoring agent sessions, reviewing evidence, and verifying integrity.

**Runs on:** `http://127.0.0.1:7860`

**Features:**
- Real-time session statistics
- Evidence timeline viewer
- Chain integrity verification
- Policy browser
- Session export

---

### 9. Runner (`agentgate/runner.py`)

**Purpose:** High-level developer API that ties everything together.

**Key classes:**

| Class | Role |
|---|---|
| `SecureBrowser` | Async context manager — creates a browser with policies enforced on every page |
| `AgentGateRunner` | Higher-level orchestrator with agent callback function |

```python
# SecureBrowser — the simple API
async with SecureBrowser(policy="finance-safe") as browser:
    page = await browser.new_page()
    await page.goto("https://bank.com")  # Intercepted!

# AgentGateRunner — the advanced API
runner = AgentGateRunner(
    policy="finance-safe",
    evidence_dir="./evidence",
    agent_fn=my_agent_function,
)
await runner.run()
```

---

## Data Flow: Complete Example

Here's what happens when an agent tries to click "Pay Now" on a banking site:

```
1. Agent calls: await page.click("#pay-button")

2. InterceptedPage:
   a. Resolves "#pay-button" → element_text="Pay Now", tag="button"
   b. Gets current URL: "https://bank.com/invoices"
   c. Creates ActionEvent:
      {
        action_type: "click",
        url: "https://bank.com/invoices",
        selector: "#pay-button",
        element_text: "Pay Now",
        element_tag: "button",
        agent_id: "finance-bot",
        timestamp: 1708012345.67
      }

3. PolicyEngine.evaluate(event):
   a. Risk classification: "Pay" → HIGH
   b. finance-safe policy:
      - Rule: click → block_elements → text_contains: ["Pay"] → BLOCK
   c. Returns PolicyDecision:
      {
        decision: BLOCK,
        risk_level: HIGH,
        reason: "Element blocked: ['Pay']",
        matched_rule: "block_element:['Pay']",
        policy_name: "finance-safe"
      }

4. EvidenceSession.record(event, decision):
   a. Creates EvidenceRecord with sequence #, hashes, chain
   b. Writes to evidence.jsonl (append-only)
   c. Returns record_id

5. InterceptedPage:
   a. Decision is BLOCK → raises ActionBlockedError
   b. Agent catches the error
   c. Agent reports: "I was blocked from clicking Pay Now"

6. The button was NEVER clicked. The bank page is untouched.
```

---

## Design Principles

1. **Intercept at the lowest level** — The agent never gets direct browser access. Every method call goes through AgentGate.

2. **Most restrictive wins** — When multiple policies apply, the strictest decision takes effect.

3. **Fail closed** — If anything goes wrong (sidecar down, policy error), the agent is blocked. Never fail open.

4. **Hash everything** — Evidence chain, screenshots, DOM snapshots — everything is hashed for integrity.

5. **YAML-first policies** — No code needed to define rules. Easy to read, version control, and audit.

6. **Language-agnostic sidecar** — Any agent in any language can call the REST API.

7. **Zero-config defaults** — Built-in presets work out of the box. Customize only when needed.

8. **Composable modules** — Each module (policy engine, evidence vault, tokens) works independently. Use just the policy engine without the interceptor? Fine. Use just the evidence vault? Also fine.

---

## File Map

```
agentgate/
├── __init__.py                 # Public exports
├── cli.py                      # CLI (Click framework)
├── runner.py                   # SecureBrowser + AgentGateRunner
├── policy/
│   ├── __init__.py
│   └── engine.py               # PolicyEngine, Policy, ActionEvent, etc. (~752 lines)
├── interceptor/
│   ├── __init__.py
│   └── browser.py              # InterceptedPage, ActionBlockedError
├── evidence/
│   ├── __init__.py
│   └── vault.py                # EvidenceVault, EvidenceSession, EvidenceRecord (~417 lines)
├── tokens/
│   ├── __init__.py
│   └── capability.py           # CapabilityToken, Scope, TokenStore (~361 lines)
├── sidecar/
│   ├── __init__.py
│   ├── service.py              # FastAPI sidecar REST API (~646 lines)
│   └── client.py               # AgentGateClient, AsyncAgentGateClient (~371 lines)
└── dashboard/
    ├── __init__.py
    └── app.py                  # FastAPI dashboard

docs/
├── GUIDE.md                    # Non-technical user guide
├── ARCHITECTURE.md             # This file
├── OPERATIONS.md               # Configuration, running, updating
└── AGENTS.md                   # Agent compatibility & scaling

policies/                       # Built-in policy YAML files
├── finance-safe.yaml
├── readonly.yaml
├── procurement-safe.yaml
└── support-agent.yaml

skills/
└── agentgate/                  # OpenClaw skill
    ├── SKILL.md
    └── policies/

tests/                          # 82 tests, 100% pass
├── test_policy_engine.py
├── test_evidence_vault.py
├── test_capability_tokens.py
├── test_sidecar.py
└── test_sidecar_client.py

examples/                       # Runnable examples
├── basic_usage.py
├── capability_tokens.py
├── custom_policies.py
├── evidence_vault.py
├── openclaw_integration.py
└── policy_testing.py
```
