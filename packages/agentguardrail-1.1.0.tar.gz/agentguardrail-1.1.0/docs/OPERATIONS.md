# ⚙️ AgentGate Operations Guide

> How to install, configure, run, update, and maintain AgentGate.

---

## Table of Contents

- [Installation](#installation)
- [Configuration](#configuration)
- [Running AgentGate](#running-agentgate)
- [Policy Management](#policy-management)
- [Evidence Management](#evidence-management)
- [Sidecar Service](#sidecar-service)
- [Dashboard](#dashboard)
- [Updating](#updating)
- [Troubleshooting](#troubleshooting)
- [Production Deployment](#production-deployment)

---

## Installation

### Requirements

- **Python 3.11+** (3.12 or 3.13 recommended)
- **Playwright** browser binaries
- **OS:** Windows, macOS, or Linux

### Quick Install

```bash
pip install agentguardrail
playwright install chromium
```

### Development Install

```bash
git clone https://github.com/Nitin-100/agentgate.git
cd agentgate
pip install -e ".[dev]"
playwright install chromium
```

### Verify Installation

```bash
agentgate version
# AgentGate v0.1.0

python -c "from agentgate import SecureBrowser; print('OK')"
# OK
```

---

## Configuration

### Project Initialization

```bash
agentgate init
```

This creates:
```
your-project/
├── policies/           # Your YAML policy files
│   └── default.yaml    # Starting policy
├── sample_agent.py     # Working example script
└── agentgate_evidence/ # Where evidence is stored
```

### Policy Configuration

Policies are YAML files in the `policies/` directory. Each policy has:

```yaml
# Required
name: my-policy                    # Unique identifier
description: What this policy does # Human-readable description
version: "1.0"                     # Semantic version

# Global settings (all optional)
enabled: true                      # Enable/disable this policy
default_decision: allow            # Default when no rule matches: allow, block
block_all_downloads: false         # Block all download actions
block_all_uploads: false           # Block all upload actions
block_js_evaluation: true          # Block JavaScript execution
block_clipboard: false             # Block clipboard access
max_actions_per_minute: 0          # Rate limit (0 = unlimited)
allowed_domains: []                # Domain allowlist (empty = all allowed)
blocked_domains: []                # Domain blocklist

# Rules (action-specific)
rules:
  - action: navigate               # Action type to match
    block:                         # URL patterns to block
      - pattern: "*/admin/*"
    allow:                         # URL patterns to explicitly allow
      - pattern: "*/public/*"

  - action: click
    block_elements:                # Elements to block
      - text_contains: ["Pay", "Delete"]
        risk: high
      - selector: "button.danger"
    require_approval:              # Elements requiring approval
      - text_contains: ["Submit"]
        risk: medium
    block_risk_above: critical     # Block any click above this risk

  - action: type
    block_elements:
      - selector: "input[type='password']"
      - selector: "input[name='credit_card']"
```

### Available Action Types

| Action | Applies To |
|---|---|
| `navigate` | `page.goto()` — visiting URLs |
| `click` | `page.click()` — clicking buttons/links |
| `type` | `page.fill()`, `page.type()` — typing into fields |
| `submit` | Form submissions |
| `download` | File downloads |
| `upload` | File uploads via `page.set_input_files()` |
| `evaluate_js` | `page.evaluate()` — running JavaScript |
| `select` | `page.select_option()` — dropdown selections |
| `press` | `page.press()` — keyboard shortcuts |
| `scroll` | Page scrolling |
| `hover` | Mouse hover |
| `copy` | Clipboard operations |
| `screenshot` | Taking screenshots |
| `wait` | Explicit waits |
| `drag` | Drag-and-drop |

### Built-in Policy Presets

| Preset | File | Use Case |
|---|---|---|
| `finance-safe` | `policies/finance-safe.yaml` | Read financial data, block payments |
| `readonly` | `policies/readonly.yaml` | View-only, no mutations |
| `procurement-safe` | `policies/procurement-safe.yaml` | Research vendors, block orders |
| `support-agent` | `policies/support-agent.yaml` | View accounts, block changes |
| `permissive` | (built-in) | Block only critical-risk actions |

### Environment Variables

| Variable | Default | Description |
|---|---|---|
| `AGENTGATE_EVIDENCE_DIR` | `./agentgate_evidence` | Where evidence is stored |
| `AGENTGATE_POLICY_DIR` | `./policies` | Policy YAML directory |
| `AGENTGATE_SIDECAR_PORT` | `18790` | Sidecar HTTP port |
| `AGENTGATE_DASHBOARD_PORT` | `7860` | Dashboard HTTP port |
| `AGENTGATE_LOG_LEVEL` | `INFO` | Logging level |
| `AGENTGATE_TOKEN_SECRET` | `agentgate-default-key` | HMAC signing key for tokens |

---

## Running AgentGate

### Mode 1: Direct Python Integration

Best for Python-based agents using Playwright directly.

```python
import asyncio
from agentgate import SecureBrowser

async def main():
    async with SecureBrowser(
        policy="finance-safe",         # Policy preset or YAML path
        evidence_dir="./evidence",     # Where to store evidence
    ) as browser:
        page = await browser.new_page()
        await page.goto("https://example.com")
        # ... your agent logic ...

asyncio.run(main())
```

### Mode 2: Sidecar Service (HTTP API)

Best for non-Python agents (OpenClaw, browser-use, custom frameworks).

```bash
# Start the sidecar
agentgate sidecar \
  --policy finance-safe \
  --port 18790 \
  --evidence-dir ./evidence \
  --agent-id my-agent

# Or with multiple policies from a directory
agentgate sidecar \
  --policy-dir ./policies \
  --port 18790
```

**Sidecar options:**

| Flag | Default | Description |
|---|---|---|
| `--policy` | (none) | Policy preset name or YAML file path |
| `--policy-dir` | (none) | Directory of YAML policies to load |
| `--port` | `18790` | HTTP port to listen on |
| `--evidence-dir` | `./agentgate_evidence` | Evidence storage directory |
| `--agent-id` | `openclaw` | Default agent ID for anonymous requests |

### Mode 3: AgentGateRunner (Advanced)

For agents that need the full lifecycle managed:

```python
from agentgate import AgentGateRunner

async def my_agent(page):
    """Your agent logic. The page is already policy-enforced."""
    await page.goto("https://bank.com")
    # ... do things ...

runner = AgentGateRunner(
    policy="finance-safe",
    evidence_dir="./evidence",
    agent_fn=my_agent,
)
await runner.run()
```

---

## Policy Management

### List Policies

```bash
agentgate policies list
```

### View a Policy

```bash
agentgate policies show finance-safe
```

### Create a Custom Policy

1. Create a YAML file in `policies/`:

```yaml
name: my-custom-policy
description: My specific rules
version: "1.0"

block_js_evaluation: true

rules:
  - action: click
    block_elements:
      - text_contains: ["Purchase", "Buy", "Order"]
        risk: high
  - action: navigate
    block:
      - pattern: "*/checkout/*"
```

2. Use it:

```python
async with SecureBrowser(policy="policies/my-custom-policy.yaml") as browser:
    ...
```

Or with the sidecar:

```bash
agentgate sidecar --policy policies/my-custom-policy.yaml
```

### Load Policies at Runtime (via Sidecar API)

```bash
curl -X POST http://localhost:18790/api/v1/policies/load \
  -H "Content-Type: application/json" \
  -d '{"yaml": "name: dynamic-policy\nrules:\n  - action: click\n    block_risk_above: high"}'
```

### Multiple Policies

When multiple policies are loaded, **the most restrictive decision wins**:

```
Policy A says: ALLOW clicking "Submit"
Policy B says: REQUIRE_APPROVAL for clicking "Submit"
→ Result: REQUIRE_APPROVAL (more restrictive)
```

---

## Evidence Management

### List Sessions

```bash
agentgate sessions list
```

### Replay a Session

```bash
agentgate sessions replay ses_a1b2c3d4e5f6
```

Outputs a timeline:
```
#001  ✅ NAVIGATE  https://bank.com/invoices       ALLOWED
#002  ✅ CLICK     "View Invoice #1234"             ALLOWED
#003  🚫 CLICK    "Pay Now"                        BLOCKED
#004  ✅ NAVIGATE  https://bank.com/reports         ALLOWED
```

### Verify Chain Integrity

```bash
agentgate sessions verify ses_a1b2c3d4e5f6
# ✅ Chain integrity verified — all 4 records intact
```

### Export for Compliance

```bash
agentgate sessions export ses_a1b2c3d4e5f6 -o audit_report.json
```

Produces a JSON file with:
- Session metadata
- Complete timeline with all records
- Risk summary
- Chain integrity status
- Policies that were active

### Evidence Storage Location

Evidence is stored in the `agentgate_evidence/` directory by default:

```
agentgate_evidence/
└── ses_a1b2c3d4e5f6/
    ├── evidence.jsonl      # One record per line (append-only)
    ├── screenshots/        # PNG screenshots (optional)
    └── summary.json        # Session summary (after end)
```

### Retention & Cleanup

Currently, evidence is stored indefinitely. To manage storage:

```python
from agentgate.evidence.vault import EvidenceVault

vault = EvidenceVault("./agentgate_evidence")

# Delete a session (irreversible)
await vault.delete_session("ses_a1b2c3d4e5f6")
```

---

## Sidecar Service

### Starting

```bash
agentgate sidecar --policy finance-safe --port 18790
```

### Health Check

```bash
curl http://localhost:18790/api/v1/health
# {"status": "ok", "version": "0.1.0", "uptime_seconds": 42.5, ...}
```

### Checking an Action

```bash
curl -X POST http://localhost:18790/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{
    "action_type": "click",
    "url": "https://bank.com",
    "element_text": "Pay Now",
    "agent_id": "my-agent"
  }'
# {"allowed": false, "decision": "block", "reason": "Element blocked: ['Pay']", ...}
```

### Using the Python SDK

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="my-agent")

# Quick checks
result = gate.check_navigate("https://bank.com")
result = gate.check_click("https://bank.com", "Pay Now")
result = gate.check_type("https://bank.com", "#email", "test@test.com")

if not result.allowed:
    print(f"Blocked: {result.reason}")
```

---

## Dashboard

### Starting

```bash
agentgate dashboard
# 🛡️ AgentGate Dashboard at http://127.0.0.1:7860
```

### What's Shown

- **Overview:** Active sessions, total actions, block rate
- **Sessions:** Browse and drill into any session
- **Evidence:** Full timeline with action details
- **Integrity:** Chain verification per session
- **Policies:** View loaded policies and their rules

---

## Updating

### Update from PyPI

```bash
pip install --upgrade agentgate
```

### Update from Source

```bash
cd agentgate
git pull origin master
pip install -e ".[dev]"
```

### Version Checking

```bash
agentgate version
python -c "import agentgate; print(agentgate.__version__)"
```

### Changelog

Check [CHANGELOG.md](../CHANGELOG.md) for release notes (coming in v0.2.0+).

### Breaking Changes

We follow semver. Before 1.0:
- Minor versions (0.x.0) may contain breaking changes
- Patch versions (0.0.x) are backward-compatible

---

## Troubleshooting

### "ModuleNotFoundError: No module named 'agentgate'"

```bash
pip install agentguardrail
# or for development:
pip install -e ".[dev]"
```

### "Playwright browser not found"

```bash
playwright install chromium
```

### "Sidecar not responding"

```bash
# Check if it's running:
curl http://localhost:18790/api/v1/health

# Check the port isn't already in use:
# Windows:
netstat -ano | findstr 18790
# macOS/Linux:
lsof -i :18790
```

### "Evidence directory permission error"

```bash
# Make sure the directory is writable:
mkdir -p agentgate_evidence
chmod 755 agentgate_evidence  # Linux/macOS
```

### "Policy not loading"

```bash
# Validate your YAML:
python -c "
from agentgate.policy.engine import Policy
p = Policy.from_yaml('your-policy.yaml')
print(f'Loaded: {p.name} with {len(p.rules)} rules')
"
```

### "All actions are being blocked"

Check:
1. Is your policy too restrictive? Try `permissive` preset first.
2. Are you in the blocked domains list?
3. Is `block_js_evaluation: true` catching evaluate calls?
4. Is there a rate limit (`max_actions_per_minute`) being hit?

---

## Production Deployment

### Docker (Coming in v0.2.0)

```dockerfile
FROM python:3.12-slim

RUN pip install agentguardrail && playwright install --with-deps chromium

COPY policies/ /app/policies/

EXPOSE 18790

CMD ["agentgate", "sidecar", "--policy-dir", "/app/policies", "--port", "18790"]
```

### Systemd Service (Linux)

```ini
[Unit]
Description=AgentGate Sidecar
After=network.target

[Service]
User=agentgate
ExecStart=/usr/local/bin/agentgate sidecar --policy-dir /etc/agentgate/policies --port 18790
Restart=always
RestartSec=5
Environment=AGENTGATE_EVIDENCE_DIR=/var/lib/agentgate/evidence

[Install]
WantedBy=multi-user.target
```

### Monitoring

- **Health endpoint:** `GET /api/v1/health` — returns uptime, session count, policy count, active tokens
- **Evidence metrics:** Count records, verify chains on a schedule
- **Alerts:** Monitor the health endpoint; if status ≠ "ok", the sidecar needs attention

### Scaling

See [AGENTS.md](AGENTS.md) for scaling strategies, multi-agent setups, and agent framework compatibility.
