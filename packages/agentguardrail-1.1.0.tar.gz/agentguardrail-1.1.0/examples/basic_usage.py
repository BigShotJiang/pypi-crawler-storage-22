"""
Example: Basic AgentGate usage — Finance-safe agent.

This demonstrates the core AgentGate flow:
1. Create a SecureBrowser with a policy
2. Every action is policy-enforced
3. Blocked actions raise ActionBlockedError
4. All actions are recorded in the Evidence Vault
"""

import asyncio
from agentgate import SecureBrowser
from agentgate.interceptor.browser import ActionBlockedError, ApprovalRequiredError


async def main():
    print("🛡️  AgentGate Example: Finance-Safe Agent")
    print("=" * 50)

    # Create a secure browser with the finance-safe policy
    async with SecureBrowser(
        policy="finance-safe",
        agent_id="finance-bot-v1",
        headless=False,  # Show browser for demo
        capture_screenshots=True,
    ) as browser:
        # Create a policy-enforced page
        page = await browser.new_page()

        # ✅ Safe navigation — this will work
        print("\n✅ Navigating to example.com...")
        await page.goto("https://example.com")
        title = await page.title()
        print(f"   Page title: {title}")

        # 🚫 Try a blocked action — this will be caught
        print("\n🚫 Attempting to click 'Pay Now'...")
        try:
            await page.click("button#pay")
        except ActionBlockedError as e:
            print(f"   BLOCKED: {e.decision.reason}")
            print(f"   Policy: {e.decision.policy_name}")
            print(f"   Rule: {e.decision.matched_rule}")

        # ⚠️ Try an action requiring approval
        print("\n⚠️  Attempting to click 'Submit Report'...")
        try:
            await page.click("button#submit")
        except (ActionBlockedError, ApprovalRequiredError) as e:
            print(f"   NEEDS APPROVAL: {e}")

        print("\n📋 Session evidence saved to ./agentgate_evidence/")
        print("   Run: agentgate sessions list")
        print("   Run: agentgate dashboard")


if __name__ == "__main__":
    asyncio.run(main())
