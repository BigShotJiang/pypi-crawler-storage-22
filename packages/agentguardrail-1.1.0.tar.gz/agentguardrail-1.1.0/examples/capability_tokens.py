"""
Example: Using Capability Tokens for scoped agent permissions.

Capability tokens give agents time-bound, scoped permissions.
This is the "least privilege" model for AI agents.
"""

import asyncio
from agentgate.tokens.capability import CapabilityToken, Scope, TokenStore
from agentgate.policy.engine import ActionEvent, ActionType, RiskLevel


def main():
    print("🛡️  AgentGate Example: Capability Tokens")
    print("=" * 50)

    # Create a token store
    store = TokenStore()

    # --- Token 1: Finance read-only ---
    print("\n📋 Creating finance read-only token...")
    finance_token = CapabilityToken.create(
        agent_id="finance-bot",
        issuer="admin@company.com",
        purpose="Read Q4 financial reports",
        scopes=[
            Scope(
                domains=["accounting.company.com"],
                exclude_text=["Pay", "Transfer", "Delete", "Wire"],
                max_risk=RiskLevel.MEDIUM,
            ),
        ],
        ttl_minutes=30,
        max_actions_total=100,
    )
    store.store(finance_token)
    print(f"   Token ID: {finance_token.token_id}")
    print(f"   Expires in: {finance_token.remaining_ttl:.0f}s")
    print(f"   Max actions: {finance_token.max_actions_total}")

    # --- Test: Allowed action ---
    print("\n✅ Testing allowed action (view invoice)...")
    event = ActionEvent(
        action_type=ActionType.CLICK,
        url="https://accounting.company.com/invoices/123",
        element_text="View Invoice",
        agent_id="finance-bot",
    )
    result = finance_token.validate(event)
    print(f"   Valid: {result.valid}")
    print(f"   Reason: {result.reason}")

    # --- Test: Blocked action (payment) ---
    print("\n🚫 Testing blocked action (pay invoice)...")
    event = ActionEvent(
        action_type=ActionType.CLICK,
        url="https://accounting.company.com/invoices/123",
        element_text="Pay Invoice",
        agent_id="finance-bot",
    )
    result = finance_token.validate(event)
    print(f"   Valid: {result.valid}")
    print(f"   Reason: {result.reason}")

    # --- Test: Wrong domain ---
    print("\n🚫 Testing wrong domain...")
    event = ActionEvent(
        action_type=ActionType.NAVIGATE,
        url="https://evil.com/steal-data",
        agent_id="finance-bot",
    )
    result = finance_token.validate(event)
    print(f"   Valid: {result.valid}")
    print(f"   Reason: {result.reason}")

    # --- Test: Action limit ---
    print("\n📊 Testing action limits...")
    limited_token = CapabilityToken.create(
        agent_id="limited-bot",
        max_actions_total=3,
        ttl_minutes=60,
    )
    for i in range(4):
        event = ActionEvent(
            action_type=ActionType.CLICK,
            url="https://example.com",
            element_text=f"Button {i+1}",
            agent_id="limited-bot",
        )
        result = limited_token.validate(event)
        status = "✅" if result.valid else "🚫"
        print(f"   Action {i+1}: {status} {result.reason}")
        if result.valid:
            limited_token.use()

    # --- Test: Revocation ---
    print("\n🔒 Testing token revocation...")
    token = CapabilityToken.create(agent_id="temp-bot", ttl_minutes=60)
    store.store(token)
    print(f"   Active tokens: {store.active_count}")

    token.revoke(by="security-team", reason="Suspicious activity detected")
    event = ActionEvent(
        action_type=ActionType.CLICK,
        url="https://example.com",
        element_text="Click",
        agent_id="temp-bot",
    )
    result = token.validate(event)
    print(f"   After revocation — Valid: {result.valid}")
    print(f"   Reason: {result.reason}")

    # --- Signature verification ---
    print("\n🔐 Testing signature verification...")
    token = CapabilityToken.create(agent_id="signed-bot", ttl_minutes=60)
    print(f"   Original signature valid: {token.verify_signature()}")
    token.agent_id = "tampered-bot"
    print(f"   After tampering: {token.verify_signature()}")

    print("\n✅ All capability token tests passed!")


if __name__ == "__main__":
    main()
