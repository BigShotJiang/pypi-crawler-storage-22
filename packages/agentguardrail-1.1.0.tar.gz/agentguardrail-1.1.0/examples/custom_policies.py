"""
Example: Custom policies — write your own YAML policy.

Shows how to create, validate, and test custom policies.
"""

from agentgate.policy.engine import (
    Policy,
    PolicyEngine,
    ActionEvent,
    ActionType,
    ActionRule,
    URLRule,
    ElementRule,
    Decision,
    RiskLevel,
)


def main():
    print("🛡️  AgentGate Example: Custom Policies")
    print("=" * 50)

    # --- Create policy from code ---
    print("\n📋 Creating policy from code...")
    policy = Policy(
        name="hr-agent-policy",
        description="Restrict HR agent to employee portal only",
        version="1.0",
        max_risk=RiskLevel.MEDIUM,
        url_rules=[
            URLRule(
                pattern=r"https://hr\.company\.com/.*",
                decision=Decision.ALLOW,
                reason="HR portal is allowed",
            ),
            URLRule(
                pattern=r"https://payroll\.company\.com/view.*",
                decision=Decision.ALLOW,
                reason="Read-only payroll access",
            ),
            URLRule(
                pattern=r"https://payroll\.company\.com/(edit|delete|create).*",
                decision=Decision.BLOCK,
                reason="Payroll modifications are blocked",
            ),
            URLRule(
                pattern=r".*",
                decision=Decision.BLOCK,
                reason="HR agent restricted to HR portal only",
            ),
        ],
        element_rules=[
            ElementRule(
                text_pattern=r"(?i)(terminate|fire|dismiss)",
                decision=Decision.REQUIRE_APPROVAL,
                reason="Employment termination requires human approval",
            ),
            ElementRule(
                text_pattern=r"(?i)(salary|compensation|bonus)",
                decision=Decision.REQUIRE_APPROVAL,
                reason="Compensation changes require approval",
            ),
        ],
        action_rules=[
            ActionRule(
                action_type=ActionType.EVALUATE_JS,
                decision=Decision.BLOCK,
                reason="No JS execution allowed",
            ),
            ActionRule(
                action_type=ActionType.FILE_UPLOAD,
                decision=Decision.REQUIRE_APPROVAL,
                reason="File uploads need approval",
            ),
        ],
    )

    # Serialize to YAML
    yaml_str = policy.to_yaml()
    print(f"   Name: {policy.name}")
    print(f"   URL rules: {len(policy.url_rules)}")
    print(f"   Element rules: {len(policy.element_rules)}")
    print(f"   Action rules: {len(policy.action_rules)}")
    print(f"\n   YAML representation:")
    for line in yaml_str.split("\n")[:15]:
        print(f"   {line}")
    print(f"   ... ({len(yaml_str.split(chr(10)))} total lines)")

    # Load it into the engine
    engine = PolicyEngine()
    engine.load_policy(policy)

    # --- Test scenarios ---
    print("\n🧪 Testing policy scenarios:")

    tests = [
        ("Navigate to HR portal", ActionEvent(
            action_type=ActionType.NAVIGATE,
            url="https://hr.company.com/employees",
        )),
        ("Navigate to external site", ActionEvent(
            action_type=ActionType.NAVIGATE,
            url="https://google.com",
        )),
        ("View payroll data", ActionEvent(
            action_type=ActionType.NAVIGATE,
            url="https://payroll.company.com/view/reports",
        )),
        ("Edit payroll", ActionEvent(
            action_type=ActionType.NAVIGATE,
            url="https://payroll.company.com/edit/salary/123",
        )),
        ("Click 'View Profile'", ActionEvent(
            action_type=ActionType.CLICK,
            url="https://hr.company.com/employees/456",
            element_text="View Profile",
        )),
        ("Click 'Terminate Employee'", ActionEvent(
            action_type=ActionType.CLICK,
            url="https://hr.company.com/employees/456",
            element_text="Terminate Employee",
        )),
        ("Click 'Update Salary'", ActionEvent(
            action_type=ActionType.CLICK,
            url="https://hr.company.com/compensation",
            element_text="Update Salary",
        )),
        ("Execute JavaScript", ActionEvent(
            action_type=ActionType.EVALUATE_JS,
            url="https://hr.company.com",
            value="document.cookie",
        )),
    ]

    for name, event in tests:
        decision = engine.evaluate(event)
        icon = {
            Decision.ALLOW: "✅",
            Decision.BLOCK: "🚫",
            Decision.REQUIRE_APPROVAL: "⚠️",
        }.get(decision.decision, "•")
        print(f"   {icon} {name}")
        print(f"      → {decision.decision.value.upper()}: {decision.reason}")

    # --- Load from YAML file ---
    print("\n📁 Loading policy from YAML file...")
    try:
        file_policy = Policy.from_yaml_file("policies/finance-safe.yaml")
        print(f"   Loaded: {file_policy.name} v{file_policy.version}")
        print(f"   Description: {file_policy.description}")
        print(f"   Max risk: {file_policy.max_risk.value}")
        print(f"   URL rules: {len(file_policy.url_rules)}")
        print(f"   Element rules: {len(file_policy.element_rules)}")
    except FileNotFoundError:
        print("   ⚠️  Policy file not found (run from project root)")

    print("\n✅ Policy engine ready!")


if __name__ == "__main__":
    main()
