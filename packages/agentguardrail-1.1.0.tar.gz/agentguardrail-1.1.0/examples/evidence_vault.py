"""
Example: Evidence Vault — recording and replaying agent sessions.

This shows how the Evidence Vault creates a tamper-evident audit
trail of everything an AI agent does.
"""

import asyncio
import json
from agentgate.evidence.vault import EvidenceVault
from agentgate.policy.engine import ActionEvent, ActionType, Decision, PolicyDecision


async def main():
    print("🛡️  AgentGate Example: Evidence Vault")
    print("=" * 50)

    # Create vault
    vault = EvidenceVault(storage_dir="./demo_evidence")

    # Start a session
    session = vault.start_session(agent_id="demo-agent", purpose="E-commerce order review")
    print(f"\n📋 Session started: {session.session_id[:12]}...")
    print(f"   Agent: {session.agent_id}")
    print(f"   Purpose: {session.purpose}")

    # Record some actions
    actions = [
        {
            "event": ActionEvent(
                action_type=ActionType.NAVIGATE,
                url="https://shop.example.com/orders",
                agent_id="demo-agent",
            ),
            "decision": PolicyDecision(
                decision=Decision.ALLOW,
                reason="Navigation to allowed domain",
                policy_name="procurement-safe",
                risk_score=0.1,
            ),
        },
        {
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://shop.example.com/orders",
                element_text="View Order #1234",
                agent_id="demo-agent",
            ),
            "decision": PolicyDecision(
                decision=Decision.ALLOW,
                reason="Read-only action",
                policy_name="procurement-safe",
                risk_score=0.2,
            ),
        },
        {
            "event": ActionEvent(
                action_type=ActionType.TYPE,
                url="https://shop.example.com/orders/1234",
                selector="input[name='search']",
                value="widget A",
                agent_id="demo-agent",
            ),
            "decision": PolicyDecision(
                decision=Decision.ALLOW,
                reason="Search input allowed",
                policy_name="procurement-safe",
                risk_score=0.2,
            ),
        },
        {
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://shop.example.com/orders/1234",
                element_text="Add to Cart",
                agent_id="demo-agent",
            ),
            "decision": PolicyDecision(
                decision=Decision.REQUIRE_APPROVAL,
                reason="Cart modification requires approval",
                policy_name="procurement-safe",
                risk_score=0.6,
            ),
        },
        {
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://shop.example.com/checkout",
                element_text="Place Order",
                agent_id="demo-agent",
            ),
            "decision": PolicyDecision(
                decision=Decision.BLOCK,
                reason="Order placement blocked by policy",
                policy_name="procurement-safe",
                risk_score=0.9,
            ),
        },
    ]

    print("\n📝 Recording actions...")
    for i, action in enumerate(actions):
        record = session.record(
            action=action["event"],
            decision=action["decision"],
        )
        icon = {"allow": "✅", "block": "🚫", "require_approval": "⚠️"}.get(
            action["decision"].decision.value, "•"
        )
        print(
            f"   {icon} [{record.sequence}] {action['event'].action_type.value}: "
            f"{action['event'].element_text or action['event'].url}"
        )

    # Verify chain integrity
    print("\n🔐 Verifying chain integrity...")
    is_valid = session.verify_chain()
    print(f"   Chain valid: {is_valid}")
    print(f"   Records: {len(session.records)}")
    print(f"   Hash chain: {session.records[0].content_hash[:16]}... → ... → {session.records[-1].content_hash[:16]}...")

    # Show summary
    print("\n📊 Session Summary:")
    summary = session.summary()
    print(f"   Total actions:    {summary['total_actions']}")
    print(f"   Allowed:          {summary['decisions']['allow']}")
    print(f"   Blocked:          {summary['decisions']['block']}")
    print(f"   Needs approval:   {summary['decisions']['require_approval']}")
    print(f"   Avg risk:         {summary['average_risk']:.2f}")
    print(f"   Domains visited:  {summary['domains_visited']}")

    # Save to disk
    print("\n💾 Saving session...")
    await vault.save_session(session)
    print(f"   Saved to: ./demo_evidence/{session.session_id}.jsonl")

    # Export as JSON
    export_path = await vault.export_session(session.session_id, format="json")
    print(f"   Exported to: {export_path}")

    print("\n✅ Done! You can replay this session with:")
    print(f"   agentgate sessions replay {session.session_id[:12]}")
    print(f"   agentgate sessions verify {session.session_id[:12]}")


if __name__ == "__main__":
    asyncio.run(main())
