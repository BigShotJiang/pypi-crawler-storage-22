"""
Example: Using AgentGate with OpenClaw (sidecar mode).

This shows the pattern for integrating AgentGate with OpenClaw
or any other agent framework that controls a browser.

Prerequisites:
    1. Install AgentGate: pip install agentguardrail
    2. Start the sidecar: agentgate sidecar --policy finance-safe --port 18790
    3. Run this script: python examples/openclaw_integration.py
"""

from agentgate.sidecar.client import AgentGateClient


def simulate_openclaw_browser_session():
    """
    Simulate what OpenClaw would do when browsing with AgentGate protection.

    In a real OpenClaw setup, these checks happen inside the browser skill
    before each Playwright/CDP action.
    """
    print("🦞🛡️  OpenClaw + AgentGate Integration Demo")
    print("=" * 55)

    # Connect to the AgentGate sidecar
    gate = AgentGateClient(port=18790, agent_id="my-openclaw")

    # Check if sidecar is running
    if not gate.is_running():
        print("\n❌ AgentGate sidecar is not running!")
        print("   Start it with: agentgate sidecar --policy finance-safe")
        print("\n   Running in demo mode (showing what WOULD happen)...")
        demo_mode = True
    else:
        health = gate.health()
        print(f"\n✅ AgentGate sidecar connected")
        print(f"   Policies loaded: {health.policies_loaded}")
        print(f"   Active sessions: {health.active_sessions}")
        demo_mode = False

    # --- Simulate browser actions ---
    print("\n📋 Simulating OpenClaw browser session...")
    print("-" * 55)

    actions = [
        {
            "step": "Navigate to bank",
            "check": lambda: gate.check_navigate("https://bank.com/dashboard"),
        },
        {
            "step": "Click 'View Invoices'",
            "check": lambda: gate.check_click(
                "https://bank.com/dashboard",
                "View Invoices",
                "a.nav-link",
            ),
        },
        {
            "step": "Navigate to invoice detail",
            "check": lambda: gate.check_navigate("https://bank.com/invoices/INV-2024-001"),
        },
        {
            "step": "Click 'Download PDF'",
            "check": lambda: gate.check_click(
                "https://bank.com/invoices/INV-2024-001",
                "Download PDF",
            ),
        },
        {
            "step": "Click 'Pay Now'",
            "check": lambda: gate.check_click(
                "https://bank.com/invoices/INV-2024-001",
                "Pay Now",
                "button.btn-primary",
            ),
        },
        {
            "step": "Click 'Transfer Money'",
            "check": lambda: gate.check_click(
                "https://bank.com/accounts",
                "Transfer Money",
            ),
        },
        {
            "step": "Type in search field",
            "check": lambda: gate.check_type(
                "https://bank.com/invoices",
                "input[name='search']",
                "2024 quarterly report",
            ),
        },
        {
            "step": "Type in password field",
            "check": lambda: gate.check_type(
                "https://bank.com/settings",
                "input[type='password']",
                "my-secret-password",
            ),
        },
        {
            "step": "Click 'Submit Report'",
            "check": lambda: gate.check_click(
                "https://bank.com/reports/new",
                "Submit Report",
            ),
        },
        {
            "step": "Execute JavaScript",
            "check": lambda: gate.check_js(
                "https://bank.com/dashboard",
                "document.cookie",
            ),
        },
        {
            "step": "Navigate to admin panel",
            "check": lambda: gate.check_navigate("https://bank.com/admin/users"),
        },
        {
            "step": "Click 'Delete Account'",
            "check": lambda: gate.check_click(
                "https://bank.com/settings",
                "Delete Account",
            ),
        },
    ]

    allowed_count = 0
    blocked_count = 0

    for action in actions:
        result = action["check"]()

        if result.allowed:
            icon = "✅"
            status = "ALLOWED"
            allowed_count += 1
        else:
            icon = "🚫"
            status = f"BLOCKED → {result.reason}"
            blocked_count += 1

        print(f"\n  {icon} {action['step']}")
        print(f"     {status}")
        if result.risk_level:
            print(f"     Risk: {result.risk_level}")

    # --- Summary ---
    print(f"\n{'=' * 55}")
    print(f"📊 Session Summary:")
    print(f"   ✅ Allowed:  {allowed_count}")
    print(f"   🚫 Blocked:  {blocked_count}")
    print(f"   Total:      {allowed_count + blocked_count}")

    if not demo_mode:
        sessions = gate.list_sessions()
        if sessions:
            print(f"\n📋 Evidence sessions: {len(sessions)}")
            print(f"   Latest: {sessions[-1]['session_id'][:12]}...")
            print(f"   Records: {sessions[-1]['record_count']}")

    print(f"\n💡 In a real OpenClaw setup:")
    print(f"   1. Copy skills/agentgate/ to ~/.openclaw/workspace/skills/")
    print(f"   2. Run: agentgate sidecar --policy finance-safe")
    print(f"   3. Your OpenClaw will check every browser action through AgentGate")
    print(f"   4. View audit trails: agentgate dashboard")

    gate.close()


# --- Capability token example ---

def demonstrate_capability_tokens():
    """Show how OpenClaw can use time-limited tokens."""
    print("\n\n🔑 Capability Token Demo")
    print("=" * 55)

    gate = AgentGateClient(port=18790, agent_id="my-openclaw")

    if not gate.is_running():
        print("   ⚠️  Sidecar not running — showing concept only\n")
        print("   # Issue a 30-minute read-only token for bank.com")
        print("   token = gate.issue_token(")
        print('       purpose="Read invoices",')
        print("       ttl_minutes=30,")
        print('       domains=["bank.com"],')
        print('       exclude_text=["Pay", "Transfer", "Delete"],')
        print("   )")
        print()
        print("   # All subsequent evaluations are checked against this token")
        print('   result = gate.check_click("https://bank.com", "View Invoice")')
        print("   # → allowed=True")
        print()
        print('   result = gate.check_click("https://bank.com", "Pay Now")')
        print("   # → allowed=False (token excludes 'Pay')")
        print()
        print('   result = gate.check_navigate("https://evil.com")')
        print("   # → allowed=False (token restricts to bank.com)")
        gate.close()
        return

    # Issue a scoped token
    token = gate.issue_token(
        purpose="Read Q4 invoices",
        ttl_minutes=30,
        domains=["bank.com"],
        exclude_text=["Pay", "Transfer", "Delete"],
        max_actions=50,
    )
    print(f"   Token ID:  {token.token_id[:12]}...")
    print(f"   Expires:   {token.remaining_ttl:.0f}s")
    print(f"   Max uses:  {token.max_actions_total}")

    # Test with token
    tests = [
        ("Navigate to bank.com", gate.check_navigate("https://bank.com/invoices")),
        ("Navigate to evil.com", gate.check_navigate("https://evil.com")),
        ("Click 'View Invoice'", gate.check_click("https://bank.com", "View Invoice")),
        ("Click 'Pay Now'", gate.check_click("https://bank.com", "Pay Now")),
    ]

    for name, result in tests:
        icon = "✅" if result.allowed else "🚫"
        print(f"\n   {icon} {name} → {result.decision}: {result.reason}")

    gate.close()


if __name__ == "__main__":
    simulate_openclaw_browser_session()
    demonstrate_capability_tokens()
