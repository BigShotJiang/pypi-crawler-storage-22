"""
Example: Policy Engine — test policies without a browser.

Useful for:
- Policy development and testing
- CI/CD policy validation
- Understanding how the engine evaluates actions
"""

from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    PolicyEngine,
    Policy,
    Decision,
    RiskLevel,
    classify_risk,
    create_finance_safe_policy,
    create_readonly_policy,
    create_permissive_policy,
)


def main():
    print("🛡️  AgentGate Example: Policy Engine Testing")
    print("=" * 50)

    # Load the finance-safe policy
    engine = PolicyEngine()
    engine.load_policy(create_finance_safe_policy())

    # Define test scenarios
    scenarios = [
        {
            "name": "View invoices page",
            "event": ActionEvent(
                action_type=ActionType.NAVIGATE,
                url="https://bank.com/invoices/list",
            ),
            "expected": "allow",
        },
        {
            "name": "Navigate to admin",
            "event": ActionEvent(
                action_type=ActionType.NAVIGATE,
                url="https://bank.com/admin/users",
            ),
            "expected": "block",
        },
        {
            "name": "Click 'View Invoice'",
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://bank.com/invoices/123",
                element_text="View Invoice",
            ),
            "expected": "allow",
        },
        {
            "name": "Click 'Pay Now'",
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://bank.com/invoices/123",
                element_text="Pay Now",
            ),
            "expected": "block",
        },
        {
            "name": "Click 'Transfer Money'",
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://bank.com/accounts",
                element_text="Transfer Money",
            ),
            "expected": "block",
        },
        {
            "name": "Click 'Delete Record'",
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://bank.com/records/456",
                element_text="Delete Record",
            ),
            "expected": "block",
        },
        {
            "name": "Click 'Submit Report'",
            "event": ActionEvent(
                action_type=ActionType.CLICK,
                url="https://bank.com/reports/new",
                element_text="Submit Report",
            ),
            "expected": "require_approval",
        },
        {
            "name": "Type in password field",
            "event": ActionEvent(
                action_type=ActionType.TYPE,
                url="https://bank.com/login",
                selector="input[type='password']",
                value="secret",
            ),
            "expected": "block",
        },
        {
            "name": "Evaluate JavaScript",
            "event": ActionEvent(
                action_type=ActionType.EVALUATE_JS,
                value="document.cookie",
            ),
            "expected": "block",
        },
        {
            "name": "Copy to clipboard",
            "event": ActionEvent(
                action_type=ActionType.COPY,
                url="https://bank.com/data",
            ),
            "expected": "block",
        },
    ]

    # Run scenarios
    passed = 0
    failed = 0
    for scenario in scenarios:
        decision = engine.evaluate(scenario["event"])
        risk = classify_risk(scenario["event"])

        icon_map = {
            Decision.ALLOW: "✅",
            Decision.BLOCK: "🚫",
            Decision.REQUIRE_APPROVAL: "⚠️",
        }
        icon = icon_map.get(decision.decision, "•")
        match = decision.decision.value == scenario["expected"]

        status = "PASS" if match else "FAIL"
        color = "" if match else " ← UNEXPECTED"

        print(f"\n  {icon} {scenario['name']}")
        print(f"     Decision: {decision.decision.value.upper()}")
        print(f"     Risk:     {risk.value}")
        print(f"     Rule:     {decision.matched_rule}")
        print(f"     Reason:   {decision.reason}")
        print(f"     Status:   {status}{color}")

        if match:
            passed += 1
        else:
            failed += 1

    print(f"\n{'=' * 50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(scenarios)}")

    if failed == 0:
        print("✅ All policy tests passed!")
    else:
        print("❌ Some tests failed — check your policy configuration")


if __name__ == "__main__":
    main()
