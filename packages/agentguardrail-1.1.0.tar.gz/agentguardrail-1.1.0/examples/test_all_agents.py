"""
🏆 AgentGate — Run ALL Agent Integration Tests
=================================================
Runs every agent framework test in sequence and reports results.

Run:
    python examples/test_all_agents.py
"""

import sys, os, subprocess, time

# ── Colors ──────────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

TESTS = [
    ("🤖 OpenAI Agent",             "test_openai_agent.py"),
    ("🧠 Google ADK Agent",         "test_google_adk_agent.py"),
    ("🖥️  Anthropic Computer Use",   "test_anthropic_agent.py"),
    ("🦜 LangChain/LangGraph",      "test_langchain_agent.py"),
    ("🚀 CrewAI Multi-Agent",       "test_crewai_agent.py"),
]


def main():
    print(f"""
{BOLD}{CYAN}╔══════════════════════════════════════════════════════════╗
║  🏆  AgentGate — Full Agent Integration Test Suite      ║
║     Testing with 5 different AI agent frameworks        ║
╚══════════════════════════════════════════════════════════╝{RESET}
    """)

    examples_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(examples_dir)
    
    results = []
    total_time = 0.0

    for name, script in TESTS:
        script_path = os.path.join(examples_dir, script)
        print(f"\n  {BOLD}{'─'*60}{RESET}")
        print(f"  Running: {name}")
        print(f"  {BOLD}{'─'*60}{RESET}\n")
        
        start = time.time()
        try:
            env = os.environ.copy()
            env["PYTHONUTF8"] = "1"
            result = subprocess.run(
                [sys.executable, script_path],
                capture_output=True, text=True, timeout=30,
                cwd=project_root, env=env,
            )
            elapsed = time.time() - start
            total_time += elapsed
            
            # Print output
            if result.stdout:
                for line in result.stdout.splitlines():
                    print(f"  {line}")
            
            if result.returncode == 0:
                results.append((name, True, elapsed, ""))
            else:
                stderr_short = result.stderr.strip().splitlines()[-3:] if result.stderr else ["Unknown error"]
                results.append((name, False, elapsed, "\n".join(stderr_short)))
                if result.stderr:
                    print(f"\n  {RED}STDERR:{RESET}")
                    for line in result.stderr.splitlines()[-5:]:
                        print(f"  {RED}  {line}{RESET}")
        
        except subprocess.TimeoutExpired:
            elapsed = time.time() - start
            total_time += elapsed
            results.append((name, False, elapsed, "TIMEOUT after 30s"))
            print(f"  {RED}❌ TIMEOUT after 30 seconds{RESET}")
        
        except Exception as e:
            elapsed = time.time() - start
            total_time += elapsed
            results.append((name, False, elapsed, str(e)))
            print(f"  {RED}❌ ERROR: {e}{RESET}")

    # ── Final Summary ──────────────────────────────────────────────────────
    print(f"\n\n{'═'*64}")
    print(f"{BOLD}  🏆 FINAL RESULTS — AgentGate Agent Integration Tests{RESET}")
    print(f"{'═'*64}\n")
    
    passed = sum(1 for _, ok, _, _ in results if ok)
    failed = len(results) - passed
    
    for name, ok, elapsed, error in results:
        icon = f"{GREEN}✅ PASS{RESET}" if ok else f"{RED}❌ FAIL{RESET}"
        print(f"  {icon}  {name:35s}  ({elapsed:.1f}s)")
        if error:
            print(f"        {RED}↳ {error[:80]}{RESET}")
    
    print(f"\n  {'─'*55}")
    print(f"  {GREEN}Passed: {passed}{RESET}  |  {RED}Failed: {failed}{RESET}  |  Time: {total_time:.1f}s")
    
    if failed == 0:
        print(f"\n  {GREEN}{BOLD}🎉 ALL {passed} AGENT TESTS PASSED!{RESET}")
    else:
        print(f"\n  {RED}{BOLD}⚠️  {failed} test(s) failed!{RESET}")
    
    print()
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
