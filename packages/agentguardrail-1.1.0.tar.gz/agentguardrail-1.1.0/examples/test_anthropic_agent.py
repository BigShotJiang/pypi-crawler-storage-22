"""
🖥️  AgentGate + Anthropic Computer Use Agent Test
===================================================
Simulates an Anthropic Claude agent using the Computer Use (beta) tool
to control a browser. AgentGate intercepts every action.

Run:
    python examples/test_anthropic_agent.py

No API key needed — simulates Claude's computer_use tool calls locally
while using the REAL AgentGate policy engine.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentgate.policy.engine import (
    ActionEvent, ActionType, PolicyEngine, Decision, RiskLevel,
    classify_risk, create_finance_safe_policy,
)
from agentgate.tokens.capability import CapabilityToken, Scope, TokenStore

# ── Colors ──────────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
MAGENTA = "\033[95m"
BOLD   = "\033[1m"
RESET  = "\033[0m"


def banner():
    print(f"""
{BOLD}{MAGENTA}╔════════════════════════════════════════════════════════════════════╗
║  🖥️  Anthropic Computer Use  +  🛡️  AgentGate  —  Integration Test ║
╚════════════════════════════════════════════════════════════════════╝{RESET}
    """)


# ── Simulated Anthropic Computer Use ────────────────────────────────────────

class ComputerUseTool:
    """
    Simulates Anthropic's computer_use tool block format.
    
    In production, Claude returns tool_use blocks like:
        {
            "type": "tool_use",
            "name": "computer",
            "input": {
                "action": "click",
                "coordinate": [500, 300]
            }
        }
    
    AgentGate intercepts these BEFORE they reach the browser.
    """
    
    def __init__(self, engine: PolicyEngine, token: CapabilityToken | None = None):
        self.engine = engine
        self.token = token
        self.current_url = "about:blank"
        self.results = []
    
    def _check(self, event: ActionEvent) -> dict:
        """Check action against policy + token."""
        # Policy check
        decision = self.engine.evaluate(event)
        
        # Token check (if we have one)
        token_ok = True
        token_msg = ""
        if self.token:
            validation = self.token.validate(event)
            token_ok = validation.valid
            if not token_ok:
                token_msg = f" [TOKEN: {validation.reason}]"
        
        final_allowed = decision.decision == Decision.ALLOW and token_ok
        result = {
            "allowed": final_allowed,
            "decision": "allow" if final_allowed else "block",
            "reason": decision.reason + token_msg,
            "risk": classify_risk(event).value,
        }
        self.results.append(result)
        return result
    
    def navigate(self, url: str) -> dict:
        """computer_use action: navigate / open URL."""
        self.current_url = url
        event = ActionEvent(
            action_type=ActionType.NAVIGATE, url=url,
            agent_id="claude-computer-use",
        )
        return self._check(event)
    
    def click(self, x: int, y: int, text: str = "", selector: str = "") -> dict:
        """computer_use action: click at coordinate."""
        event = ActionEvent(
            action_type=ActionType.CLICK,
            url=self.current_url,
            element_text=text, selector=selector,
            agent_id="claude-computer-use",
            metadata={"coordinate": [x, y]},
        )
        return self._check(event)
    
    def type_text(self, text: str, selector: str = "") -> dict:
        """computer_use action: type text."""
        event = ActionEvent(
            action_type=ActionType.TYPE,
            url=self.current_url,
            selector=selector, value=text,
            agent_id="claude-computer-use",
        )
        return self._check(event)
    
    def screenshot(self) -> dict:
        """computer_use action: take screenshot."""
        event = ActionEvent(
            action_type=ActionType.SCREENSHOT,
            url=self.current_url,
            agent_id="claude-computer-use",
        )
        return self._check(event)
    
    def scroll(self, direction: str = "down") -> dict:
        """computer_use action: scroll page."""
        event = ActionEvent(
            action_type=ActionType.SCROLL,
            url=self.current_url,
            agent_id="claude-computer-use",
            metadata={"direction": direction},
        )
        return self._check(event)
    
    def key_press(self, key: str) -> dict:
        """computer_use action: press key."""
        event = ActionEvent(
            action_type=ActionType.KEY_PRESS,
            url=self.current_url,
            value=key,
            agent_id="claude-computer-use",
        )
        return self._check(event)


def run_scenario_1(engine: PolicyEngine):
    """Scenario 1: Claude browses freely (no token — policy-only)."""
    print(f"  {BOLD}━━━ Scenario 1: Policy-Only Guard ━━━{RESET}\n")
    
    computer = ComputerUseTool(engine)
    
    steps = [
        ("Navigate to bank dashboard",     lambda: computer.navigate("https://bank.example.com/dashboard")),
        ("Screenshot the page",            lambda: computer.screenshot()),
        ("Click 'View Statements'",        lambda: computer.click(400, 250, text="View Statements")),
        ("Navigate to statements page",    lambda: computer.navigate("https://bank.example.com/statements/2024")),
        ("Scroll down to see more",        lambda: computer.scroll("down")),
        ("Click 'Download PDF'",           lambda: computer.click(600, 500, text="Download PDF")),
        ("Navigate to payments page",      lambda: computer.navigate("https://bank.example.com/payments/new")),
        ("Click 'Transfer Money'",         lambda: computer.click(500, 300, text="Transfer $10,000")),
        ("Type credit card number",        lambda: computer.type_text("4111-1111-1111-1111", "input[name='credit_card']")),
        ("Navigate to admin panel",        lambda: computer.navigate("https://bank.example.com/admin/settings")),
        ("Click 'Delete All Records'",     lambda: computer.click(300, 400, text="Delete All Records")),
        ("Press Enter to confirm",         lambda: computer.key_press("Enter")),
    ]
    
    allowed, blocked = 0, 0
    for i, (desc, fn) in enumerate(steps, 1):
        result = fn()
        icon = "✅" if result["allowed"] else "❌"
        color = GREEN if result["allowed"] else RED
        print(f"    [{i:02d}] {desc:35s} {color}{icon} {result['decision']:8s} risk={result['risk']}{RESET}")
        if not result["allowed"]:
            print(f"         {RED}↳ {result['reason']}{RESET}")
        
        allowed += result["allowed"]
        blocked += not result["allowed"]
    
    print(f"\n    Allowed: {allowed}  |  Blocked: {blocked}")
    return allowed, blocked


def run_scenario_2(engine: PolicyEngine):
    """Scenario 2: Claude with a scoped capability token."""
    print(f"\n  {BOLD}━━━ Scenario 2: Policy + Capability Token ━━━{RESET}\n")
    
    # Issue a token that only allows bank.example.com and blocks "Transfer"/"Delete"
    store = TokenStore()
    token = CapabilityToken.create(
        agent_id="claude-computer-use",
        scopes=[Scope(
            domains=["bank.example.com"],
            exclude_text=["Transfer", "Delete", "Remove"],
        )],
        purpose="Read-only bank browsing",
        ttl_minutes=5,
        max_actions_total=20,
    )
    store.store(token)
    print(f"    Token: {token.token_id[:16]}...")
    print(f"    Scope: domains=[bank.example.com], exclude_text=[Transfer, Delete, Remove]")
    print(f"    TTL:   5min, max_actions=20\n")
    
    computer = ComputerUseTool(engine, token)
    
    steps = [
        ("Navigate to bank dashboard",     lambda: computer.navigate("https://bank.example.com/dashboard")),
        ("Click 'View Statements'",        lambda: computer.click(400, 250, text="View Statements")),
        ("Click 'Transfer Money'",         lambda: computer.click(500, 300, text="Transfer Money")),
        ("Navigate to evil.com",           lambda: computer.navigate("https://evil.example.com/phishing")),
        ("Click 'Delete Account'",         lambda: computer.click(300, 400, text="Delete Account")),
        ("Click 'View Report'",            lambda: computer.click(200, 350, text="View Report")),
    ]
    
    allowed, blocked = 0, 0
    for i, (desc, fn) in enumerate(steps, 1):
        result = fn()
        icon = "✅" if result["allowed"] else "❌"
        color = GREEN if result["allowed"] else RED
        print(f"    [{i:02d}] {desc:35s} {color}{icon} {result['decision']:8s} risk={result['risk']}{RESET}")
        if not result["allowed"]:
            print(f"         {RED}↳ {result['reason']}{RESET}")
        
        allowed += result["allowed"]
        blocked += not result["allowed"]
    
    print(f"\n    Allowed: {allowed}  |  Blocked: {blocked}")
    return allowed, blocked


def main():
    banner()
    
    engine = PolicyEngine()
    engine.load_policy(create_finance_safe_policy())
    
    a1, b1 = run_scenario_1(engine)
    a2, b2 = run_scenario_2(engine)
    
    total_allowed = a1 + a2
    total_blocked = b1 + b2
    
    print(f"\n  {'═'*55}")
    print(f"  {BOLD}Overall Results:{RESET}")
    print(f"    {GREEN}✅ Total Allowed:  {total_allowed}{RESET}")
    print(f"    {RED}❌ Total Blocked:  {total_blocked}{RESET}")
    
    assert total_blocked > 0, "Expected some actions to be blocked!"
    assert total_allowed > 0, "Expected some actions to be allowed!"
    
    print(f"\n  {GREEN}{BOLD}✅ Anthropic Computer Use test PASSED{RESET}")


if __name__ == "__main__":
    main()
