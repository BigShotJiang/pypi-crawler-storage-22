"""
🚀 AgentGate + CrewAI Agent Test
==================================
Simulates a CrewAI multi-agent crew where each agent has browser tools
guarded by AgentGate. Different agents get different policies.

Run:
    python examples/test_crewai_agent.py

No API key needed — simulates the CrewAI crew pattern locally
while using the REAL AgentGate policy engine.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentgate.policy.engine import (
    ActionEvent, ActionType, PolicyEngine, Policy, Decision, RiskLevel,
    classify_risk, create_finance_safe_policy, create_readonly_policy, create_permissive_policy,
)

# ── Colors ──────────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
MAGENTA = "\033[95m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

AGENT_COLORS = {
    "researcher": CYAN,
    "analyst": MAGENTA,
    "executor": YELLOW,
}


def banner():
    print(f"""
{BOLD}{YELLOW}╔══════════════════════════════════════════════════════════════╗
║  🚀  CrewAI Multi-Agent  +  🛡️  AgentGate — Integration Test ║
╚══════════════════════════════════════════════════════════════╝{RESET}
    """)


# ── Simulated CrewAI Agent ──────────────────────────────────────────────────

class SimulatedCrewAgent:
    """
    Simulates a CrewAI Agent with browser tools.
    
    In real CrewAI:
    
        from crewai import Agent, Task, Crew
        from crewai.tools import BaseTool
        
        class GuardedBrowserTool(BaseTool):
            name = "browse"
            description = "Navigate and interact with web pages"
            
            def _run(self, action: str, url: str, **kwargs):
                event = ActionEvent(action_type=action, url=url, **kwargs)
                decision = gate.evaluate(event)
                if decision.decision != Decision.ALLOW:
                    return f"BLOCKED: {decision.reason}"
                return browser.execute(action, url, **kwargs)
        
        researcher = Agent(
            role="Research Analyst",
            tools=[GuardedBrowserTool()],
        )
    """
    
    def __init__(self, name: str, role: str, engine: PolicyEngine):
        self.name = name
        self.role = role
        self.engine = engine
        self.color = AGENT_COLORS.get(name, CYAN)
        self.results = {"allowed": 0, "blocked": 0}
    
    def execute_action(self, action_type: str, url: str, text: str = "", selector: str = "", value: str = "") -> dict:
        event = ActionEvent(
            action_type=ActionType(action_type),
            url=url,
            element_text=text,
            selector=selector,
            value=value,
            agent_id=f"crewai-{self.name}",
        )
        decision = self.engine.evaluate(event)
        risk = classify_risk(event)
        allowed = decision.decision == Decision.ALLOW
        
        if allowed:
            self.results["allowed"] += 1
        else:
            self.results["blocked"] += 1
        
        return {
            "allowed": allowed,
            "decision": decision.decision.value,
            "reason": decision.reason,
            "risk": risk.value,
        }


def run_researcher_agent():
    """Researcher agent with read-only policy — can browse but not submit forms."""
    print(f"  {CYAN}{BOLD}━━━ Agent: Researcher (read-only policy) ━━━{RESET}")
    print(f"  {CYAN}Role:   Research competitor websites and collect data{RESET}")
    print(f"  {CYAN}Policy: read-only (no clicks on submit/delete, no JS, no downloads){RESET}\n")
    
    engine = PolicyEngine()
    engine.load_policy(create_readonly_policy())
    agent = SimulatedCrewAgent("researcher", "Research Analyst", engine)
    
    tasks = [
        ("navigate", "https://competitor.example.com/products", "Navigate to competitor", {}),
        ("click", "https://competitor.example.com/products", "Click 'Pricing'", {"text": "Pricing", "selector": "a.pricing"}),
        ("navigate", "https://competitor.example.com/pricing", "Navigate pricing page", {}),
        ("navigate", "https://competitor.example.com/about", "Navigate about page", {}),
        ("click", "https://competitor.example.com/about", "Click 'Delete' button", {"text": "Delete", "selector": "button.delete"}),
        ("download", "https://competitor.example.com/report.pdf", "Download report", {}),
        ("evaluate_js", "https://competitor.example.com", "Execute JavaScript", {"value": "document.title"}),
    ]
    
    for i, (action, url, desc, kwargs) in enumerate(tasks, 1):
        r = agent.execute_action(action, url, **kwargs)
        icon = "✅" if r["allowed"] else "❌"
        color = GREEN if r["allowed"] else RED
        print(f"    [{i}] {desc:35s} {color}{icon} {r['decision']}{RESET}")
        if not r["allowed"]:
            print(f"        {RED}↳ {r['reason']}{RESET}")
    
    print(f"    → {GREEN}Allowed: {agent.results['allowed']}{RESET} | {RED}Blocked: {agent.results['blocked']}{RESET}\n")
    return agent.results


def run_analyst_agent():
    """Analyst agent with finance-safe policy — can read financial data but not transact."""
    print(f"  {MAGENTA}{BOLD}━━━ Agent: Analyst (finance-safe policy) ━━━{RESET}")
    print(f"  {MAGENTA}Role:   Analyze financial reports on the banking portal{RESET}")
    print(f"  {MAGENTA}Policy: finance-safe (read invoices/reports, block payments/admin){RESET}\n")
    
    engine = PolicyEngine()
    engine.load_policy(create_finance_safe_policy())
    agent = SimulatedCrewAgent("analyst", "Financial Analyst", engine)
    
    tasks = [
        ("navigate", "https://bank.example.com/dashboard", "Navigate to dashboard", {}),
        ("navigate", "https://bank.example.com/invoices/q4", "Navigate to invoices", {}),
        ("click", "https://bank.example.com/invoices/q4", "Click 'View Details'", {"text": "View Details", "selector": "a.detail"}),
        ("navigate", "https://bank.example.com/reports/annual", "Navigate to reports", {}),
        ("navigate", "https://bank.example.com/payments/new", "Navigate to payments", {}),
        ("click", "https://bank.example.com/payments/new", "Click 'Transfer'", {"text": "Transfer", "selector": "button.transfer"}),
        ("type", "https://bank.example.com/payments/new", "Type CC number", {"selector": "input[name='credit_card']", "value": "4111-1111-1111-1111"}),
        ("navigate", "https://bank.example.com/admin/settings", "Navigate to admin", {}),
    ]
    
    for i, (action, url, desc, kwargs) in enumerate(tasks, 1):
        r = agent.execute_action(action, url, **kwargs)
        icon = "✅" if r["allowed"] else "❌"
        color = GREEN if r["allowed"] else RED
        print(f"    [{i}] {desc:35s} {color}{icon} {r['decision']}{RESET}")
        if not r["allowed"]:
            print(f"        {RED}↳ {r['reason']}{RESET}")
    
    print(f"    → {GREEN}Allowed: {agent.results['allowed']}{RESET} | {RED}Blocked: {agent.results['blocked']}{RESET}\n")
    return agent.results


def run_executor_agent():
    """Executor agent with permissive policy — can do most things (tests edge cases)."""
    print(f"  {YELLOW}{BOLD}━━━ Agent: Executor (permissive policy) ━━━{RESET}")
    print(f"  {YELLOW}Role:   Execute approved browser tasks{RESET}")
    print(f"  {YELLOW}Policy: permissive (most actions allowed, still blocks critical){RESET}\n")
    
    engine = PolicyEngine()
    engine.load_policy(create_permissive_policy())
    agent = SimulatedCrewAgent("executor", "Task Executor", engine)
    
    tasks = [
        ("navigate", "https://app.example.com/dashboard", "Navigate to app", {}),
        ("click", "https://app.example.com/dashboard", "Click 'Settings'", {"text": "Settings", "selector": "a.settings"}),
        ("type", "https://app.example.com/settings", "Update display name", {"selector": "input[name='name']", "value": "New Name"}),
        ("click", "https://app.example.com/settings", "Click 'Save'", {"text": "Save Changes", "selector": "button.save"}),
        ("submit", "https://app.example.com/settings", "Submit form", {"text": "Submit"}),
        ("navigate", "https://evil.example.com/malware", "Navigate to malware site", {}),
        ("evaluate_js", "https://app.example.com", "Run JS", {"value": "alert('hacked')"}),
        ("click", "https://app.example.com/settings", "Click 'Delete Account'", {"text": "Delete Account", "selector": "button.delete"}),
    ]
    
    for i, (action, url, desc, kwargs) in enumerate(tasks, 1):
        r = agent.execute_action(action, url, **kwargs)
        icon = "✅" if r["allowed"] else "❌"
        color = GREEN if r["allowed"] else RED
        print(f"    [{i}] {desc:35s} {color}{icon} {r['decision']}{RESET}")
        if not r["allowed"]:
            print(f"        {RED}↳ {r['reason']}{RESET}")
    
    print(f"    → {GREEN}Allowed: {agent.results['allowed']}{RESET} | {RED}Blocked: {agent.results['blocked']}{RESET}\n")
    return agent.results


def main():
    banner()
    
    print(f"  {BOLD}CrewAI Pattern: 3 agents, each with different AgentGate policies{RESET}")
    print(f"  Each agent has the same browser tools but different safety levels.\n")
    
    r1 = run_researcher_agent()
    r2 = run_analyst_agent()
    r3 = run_executor_agent()
    
    total_a = r1["allowed"] + r2["allowed"] + r3["allowed"]
    total_b = r1["blocked"] + r2["blocked"] + r3["blocked"]
    total = total_a + total_b
    
    print(f"  {'═'*55}")
    print(f"  {BOLD}Crew Summary ({total} actions across 3 agents):{RESET}")
    print(f"    {CYAN}Researcher: {r1['allowed']} allowed, {r1['blocked']} blocked{RESET}")
    print(f"    {MAGENTA}Analyst:    {r2['allowed']} allowed, {r2['blocked']} blocked{RESET}")
    print(f"    {YELLOW}Executor:   {r3['allowed']} allowed, {r3['blocked']} blocked{RESET}")
    print(f"    ─────────────────────────────────────")
    print(f"    {GREEN}✅ Total Allowed:  {total_a}{RESET}")
    print(f"    {RED}❌ Total Blocked:  {total_b}{RESET}")
    
    assert total_b > 0, "Expected some actions to be blocked!"
    assert total_a > 0, "Expected some actions to be allowed!"
    
    print(f"\n  {GREEN}{BOLD}✅ CrewAI Multi-Agent test PASSED{RESET}")


if __name__ == "__main__":
    main()
