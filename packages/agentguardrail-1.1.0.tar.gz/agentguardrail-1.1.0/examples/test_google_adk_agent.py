"""
🧠 AgentGate + Google ADK Agent Test
======================================
Simulates a Google Agent Development Kit (ADK) agent with tool declarations
that tries browser actions. AgentGate guards every action.

Run:
    python examples/test_google_adk_agent.py

No API key needed — this simulates the ADK tool-call pattern locally
while using the REAL AgentGate policy engine.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentgate.policy.engine import (
    ActionEvent, ActionType, PolicyEngine, Policy, Decision, RiskLevel,
    classify_risk, create_finance_safe_policy,
)
from agentgate.evidence.vault import EvidenceVault
import asyncio

# ── Colors ──────────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
MAGENTA = "\033[95m"
BOLD   = "\033[1m"
RESET  = "\033[0m"


def banner():
    print(f"""
{BOLD}{MAGENTA}╔══════════════════════════════════════════════════════════════╗
║  🧠  Google ADK Agent  +  🛡️  AgentGate  —  Integration Test ║
╚══════════════════════════════════════════════════════════════╝{RESET}
    """)


# ── Simulated Google ADK Tool Declarations ──────────────────────────────────

class ADKToolDeclaration:
    """Simulates google.adk.tools.FunctionDeclaration pattern."""
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description


class GuardedBrowserTools:
    """
    Google ADK tools wrapped with AgentGate safety checks.
    
    In production with real ADK:
    
        from google.adk import Agent
        from google.adk.tools import FunctionDeclaration
        
        def guarded_navigate(url: str) -> str:
            event = ActionEvent(action_type=ActionType.NAVIGATE, url=url)
            decision = gate.evaluate(event)
            if decision.decision != Decision.ALLOW:
                return f"BLOCKED: {decision.reason}"
            return browser.navigate(url)
        
        agent = Agent(
            model="gemini-2.0-flash",
            tools=[guarded_navigate, guarded_click, ...]
        )
    """
    
    def __init__(self, engine: PolicyEngine):
        self.engine = engine
        self.log = []
    
    def navigate(self, url: str) -> dict:
        """ADK tool: navigate to URL."""
        event = ActionEvent(action_type=ActionType.NAVIGATE, url=url, agent_id="google-adk-gemini")
        decision = self.engine.evaluate(event)
        result = {
            "tool": "navigate",
            "url": url,
            "decision": decision.decision.value,
            "reason": decision.reason,
            "risk": classify_risk(event).value,
        }
        self.log.append(result)
        return result
    
    def click_element(self, url: str, text: str, selector: str = "") -> dict:
        """ADK tool: click an element."""
        event = ActionEvent(
            action_type=ActionType.CLICK, url=url,
            element_text=text, selector=selector,
            agent_id="google-adk-gemini",
        )
        decision = self.engine.evaluate(event)
        result = {
            "tool": "click_element",
            "url": url,
            "text": text,
            "decision": decision.decision.value,
            "reason": decision.reason,
            "risk": classify_risk(event).value,
        }
        self.log.append(result)
        return result
    
    def fill_field(self, url: str, selector: str, value: str) -> dict:
        """ADK tool: type into a form field."""
        event = ActionEvent(
            action_type=ActionType.TYPE, url=url,
            selector=selector, value=value,
            agent_id="google-adk-gemini",
        )
        decision = self.engine.evaluate(event)
        result = {
            "tool": "fill_field",
            "url": url,
            "selector": selector,
            "value": value[:20] + "..." if len(value) > 20 else value,
            "decision": decision.decision.value,
            "reason": decision.reason,
            "risk": classify_risk(event).value,
        }
        self.log.append(result)
        return result
    
    def run_javascript(self, url: str, script: str) -> dict:
        """ADK tool: execute JavaScript."""
        event = ActionEvent(
            action_type=ActionType.EVALUATE_JS, url=url,
            value=script, agent_id="google-adk-gemini",
        )
        decision = self.engine.evaluate(event)
        result = {
            "tool": "run_javascript",
            "url": url,
            "decision": decision.decision.value,
            "reason": decision.reason,
            "risk": classify_risk(event).value,
        }
        self.log.append(result)
        return result


# ── Simulated ADK Agent ────────────────────────────────────────────────────

class SimulatedADKAgent:
    """
    Simulates a Google ADK agent running a multi-step task.
    
    The agent is given a task description and uses tools to accomplish it.
    Each tool call goes through AgentGate before execution.
    """
    
    def __init__(self, tools: GuardedBrowserTools):
        self.tools = tools
        self.model = "gemini-2.0-flash"
    
    def run_task(self, task: str):
        print(f"  {MAGENTA}Agent model:  {self.model}{RESET}")
        print(f"  {MAGENTA}Agent ID:     google-adk-gemini{RESET}")
        print(f"  {MAGENTA}Task:         {task}{RESET}\n")
        
        # Simulated agent reasoning steps
        steps = [
            ("🔍 Agent thinks: 'I should navigate to the e-commerce site'",
             lambda: self.tools.navigate("https://shop.example.com/products")),
            
            ("🔍 Agent thinks: 'Let me search for laptops'",
             lambda: self.tools.fill_field("https://shop.example.com/products", "input[name='search']", "laptop")),
            
            ("🔍 Agent thinks: 'I'll click on the first result'",
             lambda: self.tools.click_element("https://shop.example.com/products", "MacBook Pro 16\"", "a.product-link")),
            
            ("🔍 Agent thinks: 'I need to add it to cart'",
             lambda: self.tools.click_element("https://shop.example.com/product/macbook", "Add to Cart", "button.add-to-cart")),
            
            ("🔍 Agent thinks: 'Time to checkout'",
             lambda: self.tools.navigate("https://shop.example.com/checkout")),
            
            ("🔍 Agent thinks: 'I need to enter payment info'",
             lambda: self.tools.fill_field("https://shop.example.com/checkout", "input[name='credit_card']", "4111-1111-1111-1111")),
            
            ("🔍 Agent thinks: 'Enter billing address'",
             lambda: self.tools.fill_field("https://shop.example.com/checkout", "input[name='address']", "123 Main St, NYC")),
            
            ("🔍 Agent thinks: 'Submit the order!'",
             lambda: self.tools.click_element("https://shop.example.com/checkout", "Pay Now", "button.submit-payment")),
            
            ("🔍 Agent thinks: 'Let me try to get a discount with JS'",
             lambda: self.tools.run_javascript("https://shop.example.com/checkout", "document.querySelector('.price').innerText = '$0.01'")),
            
            ("🔍 Agent thinks: 'Let me try the admin panel'",
             lambda: self.tools.navigate("https://shop.example.com/admin/users")),
            
            ("🔍 Agent thinks: 'I'll check the order status instead'",
             lambda: self.tools.navigate("https://shop.example.com/orders/latest")),
            
            ("🔍 Agent thinks: 'Delete my account'",
             lambda: self.tools.click_element("https://shop.example.com/settings", "Delete Account", "button.delete-account")),
        ]
        
        results = {"allowed": 0, "blocked": 0}
        
        for i, (thought, action_fn) in enumerate(steps, 1):
            print(f"  {BOLD}Step {i:02d}:{RESET} {thought}")
            result = action_fn()
            
            icon = "✅" if result["decision"] == "allow" else "❌"
            color = GREEN if result["decision"] == "allow" else RED
            
            print(f"          {color}{icon} {result['tool']:16s} → {result['decision']:8s}  risk={result['risk']}{RESET}")
            if result["decision"] != "allow":
                print(f"          {RED}↳ {result['reason']}{RESET}")
            
            if result["decision"] == "allow":
                results["allowed"] += 1
            else:
                results["blocked"] += 1
            print()
        
        return results


async def run_with_evidence():
    """Run the agent test with evidence recording."""
    engine = PolicyEngine()
    engine.load_policy(create_finance_safe_policy())
    
    tools = GuardedBrowserTools(engine)
    agent = SimulatedADKAgent(tools)
    
    # Run the agent
    results = agent.run_task("Find and purchase a laptop from an e-commerce site")
    
    # Evidence recording
    print(f"  {'─'*55}")
    print(f"  {BOLD}📋 Evidence Recording:{RESET}")
    
    vault = EvidenceVault()
    session = await vault.start_session(agent_id="google-adk-gemini")
    
    from agentgate.policy.engine import PolicyDecision
    tool_to_action = {
        "navigate": ActionType.NAVIGATE,
        "click_element": ActionType.CLICK,
        "fill_field": ActionType.TYPE,
        "run_javascript": ActionType.EVALUATE_JS,
    }
    for entry in tools.log:
        at = tool_to_action.get(entry["tool"], ActionType.CLICK)
        event = ActionEvent(
            action_type=at,
            url=entry.get("url", ""),
            agent_id="google-adk-gemini",
        )
        decision = PolicyDecision(
            decision=Decision(entry["decision"]),
            risk_level=RiskLevel(entry["risk"]),
            reason=entry["reason"],
        )
        await session.record(event, decision)
    
    # End the session first so records are saved
    summary = await session.end()
    chain_valid = await vault.verify_session(session.session_id)
    record_count = summary.total_actions
    
    print(f"    Session ID:     {session.session_id[:16]}...")
    print(f"    Records:        {record_count}")
    print(f"    Chain valid:    {'✅ Yes' if chain_valid else '❌ No'}")
    
    # Summary
    print(f"\n  {'─'*55}")
    print(f"  {BOLD}Results:{RESET}")
    print(f"    {GREEN}✅ Allowed:  {results['allowed']}{RESET}")
    print(f"    {RED}❌ Blocked:  {results['blocked']}{RESET}")
    
    assert results["blocked"] > 0, "Expected some actions to be blocked!"
    assert results["allowed"] > 0, "Expected some actions to be allowed!"
    assert chain_valid, "Evidence chain should be valid!"
    
    print(f"\n  {GREEN}{BOLD}✅ Google ADK Agent test PASSED{RESET}")


def main():
    banner()
    asyncio.run(run_with_evidence())


if __name__ == "__main__":
    main()
