"""
🤖 AgentGate + OpenAI Agent Test
=================================
Simulates an OpenAI-powered agent (like GPT-4 with browsing or Assistants API)
that tries browser actions. AgentGate guards every action.

Run:
    python examples/test_openai_agent.py

No API key needed — this simulates the agent loop locally while using
the REAL AgentGate policy engine.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentgate.policy.engine import (
    ActionEvent, ActionType, PolicyEngine, Decision, RiskLevel,
    classify_risk, create_finance_safe_policy,
)

# ── Colors ──────────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"


def banner():
    print(f"""
{BOLD}{CYAN}╔══════════════════════════════════════════════════════════╗
║  🤖  OpenAI Agent  +  🛡️  AgentGate  —  Integration Test ║
╚══════════════════════════════════════════════════════════╝{RESET}
    """)


# ── Simulated OpenAI Agent ──────────────────────────────────────────────────

class SimulatedOpenAIAgent:
    """
    Simulates an OpenAI agent (GPT-4 with tools / Assistants API).
    
    In production, you'd replace the 'plan' with actual OpenAI API calls.
    The AgentGate integration pattern stays the same:
    
        # Real code:
        # response = openai.chat.completions.create(...)
        # tool_calls = response.choices[0].message.tool_calls
        # for call in tool_calls:
        #     action = parse_tool_call(call)
        #     decision = gate_engine.evaluate(action)  # <-- AgentGate check
        #     if decision.decision == Decision.ALLOW:
        #         execute_action(action)
    """

    def __init__(self, engine: PolicyEngine):
        self.engine = engine
        self.actions_taken = 0
        self.actions_blocked = 0
        self.model = "gpt-4o"
    
    def plan_actions(self) -> list[dict]:
        """Simulated tool calls from OpenAI — what the agent WANTS to do."""
        return [
            {"tool": "browser.navigate", "url": "https://bank.example.com/dashboard"},
            {"tool": "browser.click",    "url": "https://bank.example.com/dashboard", "text": "View Invoices", "selector": "a.invoices-link"},
            {"tool": "browser.navigate", "url": "https://bank.example.com/invoices/2024"},
            {"tool": "browser.click",    "url": "https://bank.example.com/invoices/2024", "text": "Download PDF", "selector": "button.download"},
            {"tool": "browser.navigate", "url": "https://bank.example.com/payments/new"},
            {"tool": "browser.click",    "url": "https://bank.example.com/payments/new", "text": "Pay Now", "selector": "button.pay-now"},
            {"tool": "browser.type",     "url": "https://bank.example.com/payments/new", "selector": "input[name='credit_card']", "value": "4111-1111-1111-1111"},
            {"tool": "browser.click",    "url": "https://bank.example.com/payments/new", "text": "Transfer $5000", "selector": "button.transfer"},
            {"tool": "browser.navigate", "url": "https://bank.example.com/admin/settings"},
            {"tool": "browser.click",    "url": "https://bank.example.com/admin/settings", "text": "Delete Account", "selector": "button.delete-account"},
            {"tool": "browser.navigate", "url": "https://bank.example.com/reports/q4"},
            {"tool": "browser.click",    "url": "https://bank.example.com/reports/q4", "text": "View Report", "selector": "a.report-link"},
        ]

    def tool_call_to_event(self, call: dict) -> ActionEvent:
        """Convert an OpenAI tool call to an AgentGate ActionEvent."""
        tool = call["tool"]
        
        if tool == "browser.navigate":
            return ActionEvent(action_type=ActionType.NAVIGATE, url=call["url"], agent_id="openai-gpt4o")
        elif tool == "browser.click":
            return ActionEvent(
                action_type=ActionType.CLICK,
                url=call.get("url", ""),
                element_text=call.get("text", ""),
                selector=call.get("selector", ""),
                agent_id="openai-gpt4o",
            )
        elif tool == "browser.type":
            return ActionEvent(
                action_type=ActionType.TYPE,
                url=call.get("url", ""),
                selector=call.get("selector", ""),
                value=call.get("value", ""),
                agent_id="openai-gpt4o",
            )
        else:
            return ActionEvent(action_type=ActionType.CLICK, url=call.get("url", ""), agent_id="openai-gpt4o")

    def run(self):
        """Main agent loop: plan → check → execute (or block)."""
        print(f"  {CYAN}Agent model: {self.model}{RESET}")
        print(f"  {CYAN}Agent ID:    openai-gpt4o{RESET}")
        print(f"  {CYAN}Task:        Browse bank website, view invoices, try payments{RESET}\n")

        plan = self.plan_actions()
        print(f"  Agent planned {len(plan)} actions. Evaluating each...\n")

        results = {"allowed": 0, "blocked": 0, "approval_needed": 0}

        for i, call in enumerate(plan, 1):
            event = self.tool_call_to_event(call)
            decision = self.engine.evaluate(event)
            risk = classify_risk(event)

            icon = "✅" if decision.decision == Decision.ALLOW else "❌" if decision.decision == Decision.BLOCK else "⚠️"
            color = GREEN if decision.decision == Decision.ALLOW else RED if decision.decision == Decision.BLOCK else YELLOW
            
            print(f"  {BOLD}[{i:02d}]{RESET} {call['tool']:20s} → {color}{icon} {decision.decision.value:18s}{RESET} risk={risk.value}")
            
            if decision.decision == Decision.ALLOW:
                results["allowed"] += 1
            elif decision.decision == Decision.BLOCK:
                results["blocked"] += 1
                print(f"       {RED}↳ {decision.reason}{RESET}")
            else:
                results["approval_needed"] += 1
                print(f"       {YELLOW}↳ {decision.reason}{RESET}")

        # Summary
        print(f"\n  {'─'*50}")
        print(f"  {BOLD}Results:{RESET}")
        print(f"    {GREEN}✅ Allowed:  {results['allowed']}{RESET}")
        print(f"    {RED}❌ Blocked:  {results['blocked']}{RESET}")
        print(f"    {YELLOW}⚠️  Approval: {results['approval_needed']}{RESET}")
        
        assert results["blocked"] > 0, "Expected some actions to be blocked!"
        assert results["allowed"] > 0, "Expected some actions to be allowed!"
        print(f"\n  {GREEN}{BOLD}✅ OpenAI Agent test PASSED{RESET}")


def main():
    banner()
    engine = PolicyEngine()
    engine.load_policy(create_finance_safe_policy())
    
    agent = SimulatedOpenAIAgent(engine)
    agent.run()


if __name__ == "__main__":
    main()
