"""Tests for the NLP semantic matching engine.

Validates that the sentence-embedding-based matcher correctly
understands the MEANING of actions — not just keywords or
character patterns.
"""

import pytest

from agentgate.policy.semantic_matcher import (
    SemanticMatcher,
    SemanticMatch,
    semantic_classify,
    semantic_detect_intents,
    semantic_risk,
    semantic_matches_intent,
    is_semantic_available,
    SEMANTIC_INTENTS,
    SEMANTIC_RISK_MAP,
)
from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    Decision,
    ElementRule,
    RiskLevel,
    classify_risk,
)


# Skip all tests if fastembed is not installed
pytestmark = pytest.mark.skipif(
    not is_semantic_available(),
    reason="fastembed not installed — skipping semantic tests",
)


# ═══════════════════════════════════════════════════════════════════════════
# Semantic Matcher Core
# ═══════════════════════════════════════════════════════════════════════════

class TestSemanticMatcherCore:
    """Test the SemanticMatcher singleton and basic classification."""

    def test_singleton(self):
        m1 = SemanticMatcher.get_instance()
        m2 = SemanticMatcher.get_instance()
        assert m1 is m2

    def test_is_available(self):
        assert is_semantic_available() is True

    def test_classify_returns_list(self):
        results = semantic_classify("Buy Now")
        assert isinstance(results, list)
        assert len(results) > 0

    def test_classify_returns_semantic_match(self):
        results = semantic_classify("Buy Now")
        assert isinstance(results[0], SemanticMatch)
        assert hasattr(results[0], "intent")
        assert hasattr(results[0], "score")
        assert hasattr(results[0], "risk")

    def test_classify_empty_string(self):
        results = semantic_classify("")
        assert results == []

    def test_classify_whitespace(self):
        results = semantic_classify("   ")
        assert results == []

    def test_scores_between_0_and_1(self):
        results = semantic_classify("Delete my account")
        for r in results:
            assert 0.0 <= r.score <= 1.0


# ═══════════════════════════════════════════════════════════════════════════
# Payment Intent — the model should understand ALL forms of payment
# ═══════════════════════════════════════════════════════════════════════════

class TestPaymentIntent:
    """Test that diverse payment phrasings are correctly classified."""

    @pytest.mark.parametrize("text", [
        "Buy Now",
        "Add to cart",
        "Checkout",
        "Complete Purchase",
        "Place Order",
        "Pay with Visa",
        "Finalize Payment",
    ])
    def test_payment_standard(self, text):
        results = semantic_classify(text, threshold=0.50)
        intents = [r.intent for r in results]
        assert "payment" in intents, f"'{text}' should match payment intent"

    def test_subscribe_is_payment_or_social(self):
        """Subscribe could be payment or social depending on context."""
        results = semantic_classify("Subscribe Now", threshold=0.50)
        intents = [r.intent for r in results]
        assert any(i in intents for i in ["payment", "social", "posting", "navigation"]), (
            f"'Subscribe Now' should match some intent, got {intents}"
        )

    @pytest.mark.parametrize("text", [
        "Comprar ahora",         # Spanish: Buy now
    ])
    def test_payment_multilingual(self, text):
        results = semantic_classify(text, threshold=0.50)
        intents = [r.intent for r in results]
        assert "payment" in intents or "financial" in intents, (
            f"'{text}' should match payment or financial intent"
        )


# ═══════════════════════════════════════════════════════════════════════════
# Deletion Intent
# ═══════════════════════════════════════════════════════════════════════════

class TestDeleteIntent:
    """Test deletion detection across diverse phrasings."""

    @pytest.mark.parametrize("text", [
        "Delete Account",
        "Remove all data",
        "Erase everything",
        "Drop the entire database",
        "Purge old records",
        "Wipe system",
    ])
    def test_delete_actions(self, text):
        results = semantic_classify(text, threshold=0.50)
        intents = [r.intent for r in results]
        assert "delete" in intents or "destructive_system" in intents, (
            f"'{text}' should match delete or destructive_system"
        )


# ═══════════════════════════════════════════════════════════════════════════
# Novel Actions — things NO synonym list would ever cover
# ═══════════════════════════════════════════════════════════════════════════

class TestNovelActions:
    """Test that the model understands actions it was never explicitly trained for."""

    def test_social_media_retweet(self):
        results = semantic_classify("Retweet this post", threshold=0.50)
        intents = [r.intent for r in results]
        assert any(i in intents for i in ["social", "posting", "sharing"]), (
            "Retweet should match social/posting/sharing"
        )

    def test_devops_deploy(self):
        results = semantic_classify("Deploy to production", threshold=0.50)
        intents = [r.intent for r in results]
        assert "system" in intents, "Deploy should match system intent"

    def test_permission_grant(self):
        results = semantic_classify("Grant editor access to user", threshold=0.50)
        intents = [r.intent for r in results]
        assert any(i in intents for i in ["permission", "admin", "sharing"])

    def test_leave_a_review(self):
        results = semantic_classify("Leave a review", threshold=0.50)
        intents = [r.intent for r in results]
        assert any(i in intents for i in ["posting", "social"])

    def test_financial_wire(self):
        results = semantic_classify("Wire $1000 to savings", threshold=0.50)
        intents = [r.intent for r in results]
        assert any(i in intents for i in ["financial", "payment"])

    def test_process_refund(self):
        results = semantic_classify("Process refund", threshold=0.50)
        intents = [r.intent for r in results]
        assert "financial" in intents

    def test_restart_server(self):
        results = semantic_classify("Restart nginx server", threshold=0.50)
        intents = [r.intent for r in results]
        assert "system" in intents

    def test_change_user_role(self):
        results = semantic_classify("Change user role to admin", threshold=0.50)
        intents = [r.intent for r in results]
        assert any(i in intents for i in ["permission", "admin"])

    def test_publish_blog(self):
        results = semantic_classify("Publish blog post", threshold=0.50)
        intents = [r.intent for r in results]
        assert any(i in intents for i in ["posting", "sharing"])

    def test_like_photo(self):
        results = semantic_classify("Like this photo", threshold=0.50)
        intents = [r.intent for r in results]
        assert "social" in intents


# ═══════════════════════════════════════════════════════════════════════════
# Risk Level Classification
# ═══════════════════════════════════════════════════════════════════════════

class TestSemanticRisk:
    """Test that risk levels are correctly assigned."""

    def test_payment_is_high_risk(self):
        risk = semantic_risk("Buy Now")
        assert risk in ("high", "critical")

    def test_delete_is_high_risk(self):
        risk = semantic_risk("Delete everything permanently")
        assert risk in ("high", "critical")

    def test_navigation_is_low_risk(self):
        risk = semantic_risk("Read an article about cooking")
        assert risk in ("low", "medium")

    def test_social_is_low_risk(self):
        risk = semantic_risk("Like a photo")
        assert risk in ("low", "medium")

    def test_system_is_high_risk(self):
        risk = semantic_risk("Restart the server")
        assert risk in ("high", "critical")

    def test_messaging_is_medium(self):
        risk = semantic_risk("Send an email")
        assert risk in ("medium", "high")


# ═══════════════════════════════════════════════════════════════════════════
# Intent Matching
# ═══════════════════════════════════════════════════════════════════════════

class TestSemanticMatchesIntent:
    """Test targeted intent matching."""

    def test_payment_matches(self):
        assert semantic_matches_intent("payment", "Buy Now") is True

    def test_delete_matches(self):
        assert semantic_matches_intent("delete", "Remove all records") is True

    def test_wrong_intent_no_match(self):
        assert semantic_matches_intent("payment", "View homepage") is False

    def test_auth_matches(self):
        assert semantic_matches_intent("authentication", "Sign in") is True

    def test_posting_matches(self):
        assert semantic_matches_intent("posting", "Publish blog post") is True


# ═══════════════════════════════════════════════════════════════════════════
# Custom Intents
# ═══════════════════════════════════════════════════════════════════════════

class TestCustomIntents:
    """Test adding/removing custom intents at runtime."""

    def test_add_custom_intent(self):
        matcher = SemanticMatcher.get_instance()
        matcher.add_intent(
            "compliance",
            "regulatory compliance, audit trail, GDPR, HIPAA, SOX, "
            "data protection, privacy regulation, legal requirement",
            risk="high",
        )
        results = matcher.classify("Run GDPR compliance check")
        intents = [r.intent for r in results]
        assert "compliance" in intents

        # Cleanup
        matcher.remove_intent("compliance")

    def test_remove_custom_intent(self):
        matcher = SemanticMatcher.get_instance()
        matcher.add_intent("test_intent", "test description for testing", risk="low")
        assert matcher.remove_intent("test_intent") is True
        assert matcher.remove_intent("nonexistent") is False


# ═══════════════════════════════════════════════════════════════════════════
# Engine Integration — classify_risk with semantic fallback
# ═══════════════════════════════════════════════════════════════════════════

class TestEngineSemanticIntegration:
    """Test that classify_risk uses semantic matching as a fallback."""

    def _make_event(self, text: str, action: ActionType = ActionType.CLICK):
        return ActionEvent(
            action_type=action,
            selector="#btn",
            url="https://example.com",
            element_text=text,
        )

    def test_standard_payment_still_high(self):
        """Standard keyword-based detection still works."""
        event = self._make_event("Pay Now")
        assert classify_risk(event) == RiskLevel.HIGH

    def test_novel_payment_detected(self):
        """Novel payment phrasing detected via semantic."""
        event = self._make_event("Finalize Transaction")
        risk = classify_risk(event)
        assert risk in (RiskLevel.HIGH, RiskLevel.MEDIUM)

    def test_deploy_detected_as_risky(self):
        """DevOps action detected via semantic."""
        event = self._make_event("Deploy to production now")
        risk = classify_risk(event)
        assert risk in (RiskLevel.HIGH, RiskLevel.MEDIUM)

    def test_js_eval_still_critical(self):
        """JS eval remains critical regardless of text."""
        event = self._make_event("harmless text", ActionType.EVALUATE_JS)
        assert classify_risk(event) == RiskLevel.CRITICAL


# ═══════════════════════════════════════════════════════════════════════════
# ElementRule Semantic Matching
# ═══════════════════════════════════════════════════════════════════════════

class TestElementRuleSemantic:
    """Test that ElementRule uses semantic matching for intent-based rules."""

    def _make_event(self, text: str, url: str = "https://example.com"):
        return ActionEvent(
            action_type=ActionType.CLICK,
            selector="#btn",
            url=url,
            element_text=text,
        )

    def test_exact_keyword_match(self):
        """Standard keyword still matches (fast path)."""
        rule = ElementRule(intent="payment")
        event = self._make_event("Buy Now")
        assert rule.matches(event) is True

    def test_semantic_catches_novel_phrasing(self):
        """Novel phrasing matched via semantic fallback."""
        rule = ElementRule(intent="delete")
        event = self._make_event("Wipe the entire database")
        assert rule.matches(event) is True

    def test_semantic_disabled(self):
        """When semantic=False, only keyword/phonetic matching is used."""
        rule = ElementRule(intent="payment", semantic=False, phonetic=False)
        event = self._make_event("Finalize monetary exchange")
        # This phrasing is NOT in the keyword list, and phonetic/semantic disabled
        assert rule.matches(event) is False

    def test_unrelated_text_no_match(self):
        """Unrelated text should not match even with semantic enabled."""
        # Test semantic directly — it should not match "payment" for this
        assert semantic_matches_intent("payment", "Open the blue widget", threshold=0.60) is False


# ═══════════════════════════════════════════════════════════════════════════
# Data Integrity
# ═══════════════════════════════════════════════════════════════════════════

class TestSemanticDataIntegrity:
    """Verify the intent definitions and risk mappings are complete."""

    def test_all_intents_have_descriptions(self):
        for intent, desc in SEMANTIC_INTENTS.items():
            assert len(desc) > 10, f"Intent '{intent}' needs a longer description"

    def test_all_intents_have_risk(self):
        for intent in SEMANTIC_INTENTS:
            assert intent in SEMANTIC_RISK_MAP, (
                f"Intent '{intent}' missing from SEMANTIC_RISK_MAP"
            )

    def test_risk_values_valid(self):
        valid = {"low", "medium", "high", "critical"}
        for intent, risk in SEMANTIC_RISK_MAP.items():
            assert risk in valid, f"Intent '{intent}' has invalid risk '{risk}'"

    def test_at_least_15_intents(self):
        """We should have broad coverage."""
        assert len(SEMANTIC_INTENTS) >= 15

    def test_confident_property(self):
        match = SemanticMatch(intent="test", score=0.70, risk="low")
        assert match.confident is True
        match2 = SemanticMatch(intent="test", score=0.50, risk="low")
        assert match2.confident is False
