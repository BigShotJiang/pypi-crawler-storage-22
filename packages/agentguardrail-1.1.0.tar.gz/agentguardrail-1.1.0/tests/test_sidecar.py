"""
Tests for the AgentGate sidecar service and client.

These tests spin up the sidecar in-process (using TestClient)
and validate the full REST API surface.
"""

import pytest
from fastapi.testclient import TestClient

from agentgate.sidecar.service import create_sidecar
from agentgate.policy.engine import create_finance_safe_policy


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def app():
    """Create a sidecar app with finance-safe policy."""
    return create_sidecar(policy="finance-safe", evidence_dir="./test_evidence_sidecar")


@pytest.fixture
def client(app):
    """Create a test client."""
    return TestClient(app)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

class TestHealth:
    def test_health_check(self, client):
        resp = client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["version"] == "0.1.0"
        assert data["policies_loaded"] >= 1

    def test_health_has_uptime(self, client):
        resp = client.get("/api/v1/health")
        assert resp.json()["uptime_seconds"] >= 0


# ---------------------------------------------------------------------------
# Evaluate
# ---------------------------------------------------------------------------

class TestEvaluate:
    def test_allow_safe_navigation(self, client):
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "navigate",
            "url": "https://bank.com/invoices/list",
            "agent_id": "test-agent",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["allowed"] is True
        assert data["decision"] == "allow"
        assert data["record_id"] != ""  # Auto-recorded

    def test_block_payment_click(self, client):
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "click",
            "url": "https://bank.com/invoices/123",
            "element_text": "Pay Now",
            "agent_id": "test-agent",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["allowed"] is False
        assert data["decision"] == "block"
        assert "pay" in data["reason"].lower()

    def test_block_delete_click(self, client):
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "click",
            "url": "https://example.com/records",
            "element_text": "Delete Record",
            "agent_id": "test-agent",
        })
        data = resp.json()
        assert data["allowed"] is False
        assert data["decision"] == "block"

    def test_block_js_execution(self, client):
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "evaluate_js",
            "url": "https://example.com",
            "value": "document.cookie",
            "agent_id": "test-agent",
        })
        data = resp.json()
        assert data["allowed"] is False
        assert data["decision"] == "block"

    def test_require_approval_submit(self, client):
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "click",
            "url": "https://example.com/form",
            "element_text": "Submit Report",
            "agent_id": "test-agent",
        })
        data = resp.json()
        assert data["allowed"] is False
        assert data["decision"] in ("block", "require_approval")

    def test_invalid_action_type(self, client):
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "hack_the_planet",
            "url": "https://example.com",
        })
        assert resp.status_code == 400

    def test_response_has_fingerprint(self, client):
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "navigate",
            "url": "https://example.com/page",
        })
        data = resp.json()
        assert data["action_fingerprint"] != ""

    def test_auto_records_in_vault(self, client):
        """Every evaluation should create an evidence record."""
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "click",
            "url": "https://example.com",
            "element_text": "View",
            "agent_id": "vault-test-agent",
        })
        data = resp.json()
        assert data["record_id"] != ""


# ---------------------------------------------------------------------------
# Batch evaluate
# ---------------------------------------------------------------------------

class TestBatchEvaluate:
    def test_batch_evaluate(self, client):
        resp = client.post("/api/v1/evaluate/batch", json=[
            {"action_type": "navigate", "url": "https://example.com"},
            {"action_type": "click", "url": "https://bank.com", "element_text": "Pay Now"},
            {"action_type": "click", "url": "https://example.com", "element_text": "View"},
        ])
        assert resp.status_code == 200
        results = resp.json()
        assert len(results) == 3
        assert results[0]["allowed"] is True  # Safe navigation
        assert results[1]["allowed"] is False  # Payment blocked
        assert results[2]["allowed"] is True   # Safe click


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------

class TestSessions:
    def test_start_session(self, client):
        resp = client.post("/api/v1/sessions", json={
            "agent_id": "test-agent",
            "purpose": "Test session",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["session_id"] != ""
        assert data["agent_id"] == "test-agent"
        assert data["is_active"] is True

    def test_list_sessions(self, client):
        # Create a session
        client.post("/api/v1/sessions", json={"agent_id": "test-agent"})

        resp = client.get("/api/v1/sessions")
        assert resp.status_code == 200
        sessions = resp.json()
        assert len(sessions) >= 1

    def test_session_lifecycle(self, client):
        # Start
        resp = client.post("/api/v1/sessions", json={"agent_id": "lifecycle-test"})
        sid = resp.json()["session_id"]

        # Evaluate some actions (they auto-record into the session)
        client.post("/api/v1/evaluate", json={
            "action_type": "navigate",
            "url": "https://example.com",
            "agent_id": "lifecycle-test",
            "session_id": sid,
        })

        # Get session details
        resp = client.get(f"/api/v1/sessions/{sid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["record_count"] >= 1
        assert data["chain_valid"] is True

    def test_session_not_found(self, client):
        resp = client.get("/api/v1/sessions/nonexistent-id")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------

class TestTokens:
    def test_issue_token(self, client):
        resp = client.post("/api/v1/tokens", json={
            "agent_id": "test-agent",
            "purpose": "Read-only bank access",
            "ttl_minutes": 30,
            "domains": ["bank.com"],
            "exclude_text": ["Pay", "Transfer"],
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["token_id"] != ""
        assert data["agent_id"] == "test-agent"
        assert data["remaining_ttl"] > 0

    def test_validate_token(self, client):
        # Issue a token
        resp = client.post("/api/v1/tokens", json={
            "agent_id": "token-agent",
            "ttl_minutes": 60,
            "domains": ["example.com"],
        })
        token_id = resp.json()["token_id"]

        # Validate: allowed domain
        resp = client.post("/api/v1/tokens/validate", json={
            "token_id": token_id,
            "action_type": "navigate",
            "url": "https://example.com/page",
            "agent_id": "token-agent",
        })
        data = resp.json()
        assert data["valid"] is True

        # Validate: blocked domain
        resp = client.post("/api/v1/tokens/validate", json={
            "token_id": token_id,
            "action_type": "navigate",
            "url": "https://evil.com",
            "agent_id": "token-agent",
        })
        data = resp.json()
        assert data["valid"] is False

    def test_revoke_token(self, client):
        # Issue
        resp = client.post("/api/v1/tokens", json={
            "agent_id": "revoke-agent",
            "ttl_minutes": 60,
        })
        token_id = resp.json()["token_id"]

        # Revoke
        resp = client.post(f"/api/v1/tokens/{token_id}/revoke", params={"reason": "test"})
        assert resp.status_code == 200

        # Validate should fail
        resp = client.post("/api/v1/tokens/validate", json={
            "token_id": token_id,
            "action_type": "navigate",
            "url": "https://example.com",
            "agent_id": "revoke-agent",
        })
        assert resp.json()["valid"] is False

    def test_list_tokens(self, client):
        client.post("/api/v1/tokens", json={"agent_id": "list-agent", "ttl_minutes": 60})

        resp = client.get("/api/v1/tokens")
        assert resp.status_code == 200
        tokens = resp.json()
        assert len(tokens) >= 1

    def test_evaluate_with_token(self, client):
        """Token should be validated during evaluate if token_id is provided."""
        # Issue a restrictive token
        resp = client.post("/api/v1/tokens", json={
            "agent_id": "gated-agent",
            "ttl_minutes": 60,
            "domains": ["allowed.com"],
        })
        token_id = resp.json()["token_id"]

        # Evaluate with token — wrong domain should be blocked by token
        resp = client.post("/api/v1/evaluate", json={
            "action_type": "navigate",
            "url": "https://blocked.com/page",
            "agent_id": "gated-agent",
            "token_id": token_id,
        })
        data = resp.json()
        assert data["allowed"] is False
        assert "token" in data["reason"].lower() or "token" in data["policy_name"].lower()


# ---------------------------------------------------------------------------
# Policies
# ---------------------------------------------------------------------------

class TestPolicies:
    def test_list_policies(self, client):
        resp = client.get("/api/v1/policies")
        assert resp.status_code == 200
        policies = resp.json()
        assert len(policies) >= 1
        assert policies[0]["name"] == "finance-safe"

    def test_load_policy_yaml(self, client):
        yaml_str = """
name: test-loaded-policy
description: Test policy loaded via API
version: "1.0"
block_js_evaluation: true

rules:
  - action: click
    block_elements:
      - text_contains: ["nuke"]
        risk: critical
"""
        resp = client.post("/api/v1/policies/load", json={"yaml": yaml_str})
        assert resp.status_code == 200
        assert resp.json()["policy_name"] == "test-loaded-policy"

        # Verify it's loaded
        resp = client.get("/api/v1/policies")
        names = [p["name"] for p in resp.json()]
        assert "test-loaded-policy" in names


# ---------------------------------------------------------------------------
# No-policy sidecar (pass-through mode)
# ---------------------------------------------------------------------------

class TestPassThrough:
    def test_no_policy_allows_all(self):
        """A sidecar with no policies should allow everything."""
        app = create_sidecar(policy=None, evidence_dir="./test_evidence_passthrough")
        client = TestClient(app)

        resp = client.post("/api/v1/evaluate", json={
            "action_type": "click",
            "url": "https://bank.com",
            "element_text": "Pay Now",
        })
        data = resp.json()
        assert data["allowed"] is True
