"""
Tests for the AgentGate sidecar client (SDK).

Uses a real sidecar TestClient under the hood to verify
the client correctly wraps the REST API.
"""

import pytest
from starlette.testclient import TestClient as StarletteTestClient

from agentgate.sidecar.client import AgentGateClient, GateDecision, GateHealth
from agentgate.sidecar.service import create_sidecar


# ---------------------------------------------------------------------------
# Client tests with starlette TestClient as transport
# ---------------------------------------------------------------------------

class TestAgentGateClient:
    """Test the sync client using a real sidecar app via starlette TestClient."""

    @pytest.fixture
    def gate(self):
        """Create a client that uses starlette's TestClient as transport."""
        app = create_sidecar(policy="finance-safe", evidence_dir="./test_evidence_client")
        # StarletteTestClient is a subclass of httpx.Client with ASGI support
        test_client = StarletteTestClient(app)
        client = AgentGateClient(agent_id="test-claw")
        client._client.close()
        client._client = test_client
        yield client
        test_client.close()

    def test_check_navigate_allowed(self, gate):
        result = gate.check_navigate("https://example.com/invoices")
        assert result.allowed is True
        assert result.decision == "allow"

    def test_check_click_blocked(self, gate):
        result = gate.check_click("https://bank.com", "Pay Now")
        assert result.allowed is False
        assert result.decision == "block"

    def test_check_click_allowed(self, gate):
        result = gate.check_click("https://bank.com", "View Invoice")
        assert result.allowed is True

    def test_check_js_blocked(self, gate):
        result = gate.check_js("https://example.com", "document.cookie")
        assert result.allowed is False

    def test_check_type_with_password(self, gate):
        result = gate.check_type("https://example.com", "input[type='password']", "secret123")
        assert result.allowed is False

    def test_health_returns_ok(self, gate):
        health = gate.health()
        assert health.status == "ok"

    def test_is_running(self, gate):
        assert gate.is_running() is True


class TestClientFallback:
    """Test client behavior when sidecar is not running."""

    def test_connection_refused_blocks(self):
        """When sidecar is down, client should block by default (fail closed)."""
        client = AgentGateClient(port=19999)  # Nothing on this port
        result = client.check_navigate("https://example.com")
        assert result.allowed is False
        assert "not running" in result.reason.lower() or "connection" in result.reason.lower()
        client.close()

    def test_health_unreachable(self):
        """Health should return 'unreachable' when sidecar is down."""
        client = AgentGateClient(port=19999)
        health = client.health()
        assert health.status == "unreachable"
        client.close()

    def test_is_running_false(self):
        client = AgentGateClient(port=19999)
        assert client.is_running() is False
        client.close()
