# Changelog

All notable changes to AgentGuardrail will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.1] - 2026-02-17

### Fixed
- **📦 Missing core dependencies** — `numpy` and `mcp[cli]` moved from optional to core dependencies so `pip install agentguardrail` works out of the box without import errors

## [1.2.0] - 2026-02-17

### Added
- **🔌 MCP Extensible Plugin System** (`agentgate/mcp/plugin.py`)
  - Extensible plugin architecture with 4 base classes: `PolicyPlugin`, `TransformPlugin`, `AuditPlugin`, `ValidatorPlugin`
  - `PluginRegistry` with priority-ordered pipeline execution (transform → validate → pre-evaluate → engine → post-evaluate → audit)
  - `PluginPriority` enum (CRITICAL=0, HIGH=10, NORMAL=50, LOW=90, AUDIT=100)
  - `PluginDecision` and `PluginContext` models for plugin communication
  - Built-in plugins:
    - `SQLInjectionValidator` — detects SQL injection patterns in tool arguments
    - `SensitiveDataValidator` — detects credit cards, SSNs, API keys in arguments
    - `RateLimitByServerPlugin` — per-server rate limiting for MCP tool calls
    - `LoggingAuditPlugin` — structured logging of all MCP decisions
    - `ArgumentNormalizerTransform` — trims and normalizes tool arguments
  - `create_secure_registry()` factory — one-line setup with all security plugins
  - `BUILTIN_PLUGINS` registry for plugin discovery
  - Full integration into `MCPPolicyEngine.evaluate()` pipeline
- **🤖 Multi-Agent Session Manager** (`agentgate/sessions.py`)
  - `MultiAgentSessionManager` — coordinated governance for agent swarms
  - 6 agent roles: `READER`, `WRITER`, `ADMIN`, `EXECUTOR`, `OBSERVER`, `CUSTOM`
  - Role-based policy defaults (allowed/blocked action types, rate limits per role)
  - `AgentRegistration` model with lifecycle tracking (actions, risk, timestamps)
  - `OrchestrationSession` — groups multiple agent sessions under one orchestration
  - Cross-agent rate limiting (per-agent + collective rate limits)
  - Max total actions limit across all agents in an orchestration
  - Sequential execution mode — only one agent acts at a time (coordination locks)
  - Pause/resume/transfer agent control
  - Per-agent evidence sessions with unified orchestration summary
  - `OrchestrationSummary` with chain validity, risk tracking, and per-agent stats
  - Agent stats and orchestration stats queries
- **💓 OpenClaw Heartbeat Integration** (`agentgate/heartbeat.py`)
  - `HeartbeatClient` — async background health monitoring for AgentGate sidecar
  - `HeartbeatConfig` — configurable interval, timeout, max missed pings, auto-reconnect
  - `HeartbeatStatus` enum: HEALTHY, DEGRADED, UNHEALTHY, DISCONNECTED, UNKNOWN
  - Policy change detection via hash comparison (alerts when policies change mid-session)
  - License validation check on every heartbeat ping
  - Session keepalive verification
  - Auto-reconnect with configurable retry limits and backoff delay
  - Latency tracking (avg, min, max) and uptime percentage
  - 6 event callbacks: `on_healthy`, `on_degraded`, `on_unhealthy`, `on_disconnect`, `on_policy_change`, `on_reconnect`
  - `HeartbeatSummary` — session-level monitoring statistics
  - `HeartbeatResponse` model for sidecar responses
  - `add_heartbeat_endpoint()` — adds `/api/v1/heartbeat` and `/api/v1/heartbeat/status` to sidecar
- **164 new tests** for plugins, multi-agent sessions, and heartbeat (641 total)
  - `test_mcp_plugins.py` — 61 tests for the MCP plugin system
  - `test_multi_agent_sessions.py` — 56 tests for multi-agent session management
  - `test_heartbeat.py` — 47 tests for heartbeat client and models
- New package exports: `MultiAgentSessionManager`, `AgentRole`, `HeartbeatClient`, `HeartbeatConfig`, `PluginRegistry`, `PolicyPlugin`
- Version bumped to 1.2.0

### Changed
- `MCPPolicyEngine.evaluate()` now runs the full plugin pipeline when a `PluginRegistry` is provided
- Sidecar service now includes heartbeat endpoints (`/api/v1/heartbeat`, `/api/v1/heartbeat/status`)
- Updated `agentgate/mcp/__init__.py` with all plugin system exports
- Updated `agentgate/__init__.py` with sessions, heartbeat, and plugin exports

## [1.1.1] - 2025-07-16

### Changed
- **SEO & Discoverability** — major metadata and documentation rewrite for PyPI search ranking
  - Expanded keywords from 15 → 35 targeted search terms
  - Added 6 new PyPI classifiers (AI, Quality Assurance, Monitoring, etc.)
  - Rewrote package description with SEO-friendly language
  - Added Source and Download project URLs
- **PYPI_README.md** — complete rewrite for discoverability
  - New title: "AgentGuardrail — Guardrails & Policy Enforcement for AI Agents"
  - Added "What is AgentGuardrail?" section differentiating from guardrails-ai
  - Added "Why do AI agents need guardrails?" section
  - Added "AgentGuardrail vs. Other Tools" comparison table
  - Added PyPI Downloads badge
  - Added keyword-rich footer
- **README.md** — rebranded from "AgentGate" to "AgentGuardrail" throughout
  - Added Downloads badge
  - Consistent "AgentGuardrail" branding across all sections
  - Updated tagline to "Guardrails & policy enforcement for AI agents"

## [Unreleased]

### Added
- **🔌 MCP Server** — expose AgentGuardrail firewall tools via Model Context Protocol
  - 5 MCP tools: evaluate_action, evaluate_mcp_tool, classify_text_risk, list_policies, health
  - 2 MCP resources: agentgate://presets, agentgate://help
  - Supports stdio, SSE, and streamable-http transports
  - Works with Claude Desktop, Cursor, GPT, and any MCP-compatible client
  - Install: `pip install agentguardrail[mcp]`
- **🔌 MCP Proxy Gateway** — security proxy for downstream MCP servers
  - Intercepts every tool call and evaluates against MCP policies
  - Re-exposes downstream tools with policy wrapping (e.g., `stripe__create_payment`)
  - Auto-discovers tools from downstream servers via stdio/SSE/HTTP
  - Management tools: `agentgate_proxy_status`, `agentgate_check_tool`
  - YAML config for server definitions
- **🔌 MCP Policy Engine** — dedicated policy engine for MCP tool-call governance
  - MCPToolCall, MCPToolCallDecision, MCPToolRule, MCPPolicy data models
  - Same 3-layer intent matching pipeline (keywords → phonetic → NLP semantic)
  - Glob pattern matching for server names and tool names
  - Argument pattern matching (regex) and blocked argument values
  - Server allowlist/blocklist, tool allowlist/blocklist
  - Rate limiting per agent (max calls per minute)
  - Maximum argument length enforcement
  - Most-restrictive-wins across multiple policies
- **4 MCP Policy Presets**
  - `mcp-default` — block dangerous tools (delete, payment, admin), allow the rest
  - `mcp-readonly` — only allow read operations (get_*, list_*, search_*)
  - `mcp-finance-safe` — block all payment, billing, and financial mutation tools
  - `mcp-devops-safe` — block destructive infra ops, require approval for deploys
- **MCP CLI Commands**
  - `agentgate mcp serve` — start AgentGate as MCP server
  - `agentgate mcp proxy` — start MCP proxy gateway
  - `agentgate mcp policies` — list MCP policy presets
  - `agentgate mcp check <server> <tool>` — check if tool call is allowed
- **MCP YAML Policy Support** — load MCP policies from YAML files alongside browser policies
- **142 new tests** for MCP types, policy engine, server, proxy, and integration (477 total)
- New install extras: `pip install agentguardrail[mcp]` and `pip install agentguardrail[all]`

### Planned
- Approval workflows (Slack, email, webhook)
- SIEM/SOAR export (Splunk, Datadog, Sentinel)
- TypeScript/JavaScript native SDK
- Fine-tuned domain-specific NLP models
- Multi-language intent detection

## [1.1.0] - 2026-02-17

### Added
- **🧠 NLP Semantic Matching Engine** — sentence embeddings via fastembed (BAAI/bge-small-en-v1.5 ONNX model)
  - 20 semantic intent categories (payment, delete, admin, posting, messaging, sharing, etc.)
  - Cosine similarity classification with configurable confidence threshold (≥0.65)
  - Runs entirely on CPU (~67 MB model), zero API keys, ~2ms per classification
  - Custom intent support — add/remove intents at runtime
  - Optional install: `pip install agentguardrail[nlp]`
- **3-Layer Intent Detection Pipeline** — keywords → phonetic → semantic NLP
  - Layer 1: Exact keyword/substring matching (12 categories, 200+ synonyms)
  - Layer 2: Phonetic matching (catches typos & morphological variants)
  - Layer 3: NLP semantic matching (understands meaning of novel phrases)
- **Smart Intent Matching** — 12 intent categories with 200+ keyword synonyms
- **Phonetic Matching Engine** — custom phonetic encoder for typo-resilient detection
- **Semantic risk classification** — CRITICAL/HIGH/MEDIUM/LOW mapping for all 20 intent categories
- **MCP module scaffold** — `agentgate.mcp` package ready for v2.0 gateway features

### Fixed
- Phonetic prefix matching false positives (min 4-char code requirement)
- Neutral text misclassification ("click" no longer matches "cancel")

### Changed
- Risk auto-detection now uses 3-layer pipeline instead of simple keyword lists
- Updated README with NLP documentation, architecture diagram, and code examples
- fastembed + numpy added as optional `[nlp]` dependencies

## [1.0.0] - 2026-02-17

### Added
- **First public PyPI release** 🎉
- **Hardened licensing system** with enterprise-grade anti-tamper protection
  - Clock rollback detection (NTP + monotonic elapsed tracking)
  - File integrity seal (HMAC-SHA256 on all fields)
  - Deletion-resistant breadcrumb (secondary OS-specific storage)
  - Machine fingerprint binding (hardware-bound licenses)
  - PBKDF2-derived signing keys (not stored as plaintext)
- **License CLI commands** — `agentgate license status|activate|deactivate`
- **Sidecar license endpoints** — `/api/v1/license/status`, `/api/v1/license/activate`
- **Feature gating decorators** — `@require_feature()`, `@require_tier()`
- **Docker support** — Dockerfile + docker-compose.yml
- **Agent framework test scripts** — OpenAI, Anthropic, Google ADK, LangChain, CrewAI
- **Demo script** — `demo.py` for quick testing
- **Separate PyPI description** — `PYPI_README.md` for public-facing docs
- 137 tests (91 core + 46 licensing)

## [0.1.0] - 2025-01-01

### Added

#### Core Engine
- **Policy Engine** with YAML-based rules, URL/element/action matching, and regex support
- **15 Action Types**: navigate, click, type, submit, download, upload, copy, paste, evaluate_js, screenshot, cookie_access, set_header, request_intercept, dialog_handle, frame_navigate
- **5 Risk Levels**: critical, high, medium, low, info — with automatic risk classification
- **4 Decision Types**: allow, block, require_approval, audit_only
- Policy presets: `finance-safe`, `readonly`, `permissive`, `procurement-safe`, `support-agent`
- Most-restrictive-wins evaluation across multiple loaded policies

#### Browser Interceptor
- `InterceptedPage` wrapping Playwright's Page with policy enforcement
- Every `goto()`, `click()`, `fill()`, `type()`, `evaluate()` intercepted
- `ActionBlockedError` and `ApprovalRequiredError` exceptions
- Auto-classification of element text to risk levels

#### Evidence Vault
- Tamper-evident hash-chained evidence records (SHA-256)
- `EvidenceSession` with start/end, per-agent-id tracking
- JSONL storage with integrity verification
- Session listing, replay, and export (JSON)

#### Capability Tokens
- Scoped, time-bound permission tokens
- Domain, URL, action type, and element text restrictions
- Rate limiting (per-minute and total actions)
- HMAC-SHA256 signing and verification
- Token revocation support

#### Sidecar Service (OpenClaw Integration)
- FastAPI REST API with 16 endpoints
- `/api/v1/evaluate` — single action evaluation
- `/api/v1/evaluate/batch` — batch preflight checks
- `/api/v1/sessions` — evidence session management
- `/api/v1/tokens` — capability token CRUD
- `/api/v1/policies` — policy listing and loading
- `/api/v1/health` — health check
- Python SDK: `AgentGateClient` (sync) and `AsyncAgentGateClient`

#### CLI
- `agentgate init` — project scaffolding
- `agentgate policies list|show|verify` — policy management
- `agentgate sessions list|replay|verify|export` — evidence management
- `agentgate sidecar` — start the sidecar service
- `agentgate dashboard` — launch web dashboard
- `agentgate version` — version info

#### Dashboard
- FastAPI web dashboard on port 7860
- Session list, session detail, replay, statistics
- Policy browser and chain integrity verification

#### OpenClaw Skill
- Ready-to-use skill package (`skills/agentgate/`)
- `SKILL.md` with full instructions for OpenClaw
- Default and strict policy presets for OpenClaw

#### Documentation
- Comprehensive README with quickstart guide
- Non-technical user guide (`docs/GUIDE.md`)
- Architecture deep-dive (`docs/ARCHITECTURE.md`)
- Operations guide (`docs/OPERATIONS.md`)
- Agent compatibility matrix (`docs/AGENTS.md`)
- Contributing guidelines (`CONTRIBUTING.md`)
- Security policy (`SECURITY.md`)

#### Examples
- `basic_usage.py` — minimal working example
- `capability_tokens.py` — token creation and validation
- `custom_policies.py` — writing custom YAML policies
- `evidence_vault.py` — recording and verifying evidence
- `openclaw_integration.py` — sidecar + SDK usage
- `policy_testing.py` — testing policies programmatically

[Unreleased]: https://github.com/Nitin-100/agentgate/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/Nitin-100/agentgate/releases/tag/v0.1.0
