"""
AgentGate OpenClaw Heartbeat — Continuous health monitoring and session keepalive.

The heartbeat system provides a bidirectional health channel between
OpenClaw (or any agent framework) and AgentGate. It ensures:

    1. AgentGate sidecar is alive and responsive
    2. Policies haven't changed mid-session
    3. License is still valid
    4. Evidence sessions are still recording
    5. Agent is still within rate/action limits
    6. Automatic recovery on connection loss

Architecture:
    Agent/OpenClaw  ──→  Heartbeat Client  ──→  AgentGate Sidecar
                          │                       │
                          │ Periodic pings         │ Health + policy status
                          │ Policy version check   │ Session stats
                          │ Session keepalive       │ License validation
                          └────── ← ──────────────┘

Usage:
    from agentgate.heartbeat import HeartbeatClient, HeartbeatConfig

    hb = HeartbeatClient(
        config=HeartbeatConfig(
            interval_seconds=10,
            timeout_seconds=3,
            max_missed=3,
            on_failure=lambda status: print(f"ALERT: {status}"),
        ),
    )

    # Start heartbeat monitoring (runs in background)
    await hb.start()

    # Check status
    if hb.is_healthy:
        print("AgentGate is responsive")

    # Stop monitoring
    await hb.stop()
"""

from __future__ import annotations

import asyncio
import logging
import time
from enum import Enum
from typing import Any, Callable

from pydantic import BaseModel, Field

logger = logging.getLogger("agentgate.heartbeat")


# ---------------------------------------------------------------------------
# Heartbeat status and config
# ---------------------------------------------------------------------------

class HeartbeatStatus(str, Enum):
    """Current health status of the AgentGate connection."""
    HEALTHY = "healthy"                # All checks pass
    DEGRADED = "degraded"              # Some checks failed but still functional
    UNHEALTHY = "unhealthy"            # Critical failures detected
    DISCONNECTED = "disconnected"      # Cannot reach AgentGate
    UNKNOWN = "unknown"                # Not yet checked


class HeartbeatConfig(BaseModel):
    """Configuration for the heartbeat client."""
    host: str = "127.0.0.1"
    port: int = 18790
    interval_seconds: float = 10.0     # How often to ping
    timeout_seconds: float = 3.0       # Max time to wait for response
    max_missed: int = 3                # Max missed pings before UNHEALTHY
    check_policy_version: bool = True  # Detect policy changes
    check_license: bool = True         # Validate license status
    check_sessions: bool = True        # Verify sessions are alive
    auto_reconnect: bool = True        # Auto-reconnect on failure
    reconnect_delay_seconds: float = 5.0  # Delay between reconnect attempts
    max_reconnect_attempts: int = 10   # Give up after this many attempts
    agent_id: str = "openclaw"


class HeartbeatEvent(BaseModel):
    """A single heartbeat event (ping/pong cycle)."""
    timestamp: float = Field(default_factory=time.time)
    sequence: int = 0
    status: HeartbeatStatus = HeartbeatStatus.UNKNOWN
    latency_ms: float = 0.0
    sidecar_version: str = ""
    policies_loaded: int = 0
    policy_hash: str = ""              # Hash of loaded policies for change detection
    active_sessions: int = 0
    tokens_active: int = 0
    license_status: str = ""
    errors: list[str] = Field(default_factory=list)
    checks: dict[str, bool] = Field(default_factory=dict)


class HeartbeatSummary(BaseModel):
    """Summary of heartbeat monitoring session."""
    total_pings: int = 0
    successful_pings: int = 0
    failed_pings: int = 0
    avg_latency_ms: float = 0.0
    max_latency_ms: float = 0.0
    min_latency_ms: float = 0.0
    uptime_percentage: float = 0.0
    policy_changes_detected: int = 0
    disconnections: int = 0
    reconnections: int = 0
    start_time: float = 0.0
    duration_seconds: float = 0.0
    last_status: str = ""


# ---------------------------------------------------------------------------
# Heartbeat Client
# ---------------------------------------------------------------------------

class HeartbeatClient:
    """Monitors AgentGate sidecar health with periodic heartbeats.

    Runs as a background async task, periodically pinging the sidecar
    and checking that everything is healthy.

    Features:
        - Latency tracking
        - Policy change detection
        - License validation
        - Session keepalive
        - Auto-reconnection
        - Callbacks on status changes

    Usage:
        hb = HeartbeatClient(config=HeartbeatConfig(interval_seconds=5))

        # Register callbacks
        hb.on_healthy = lambda e: print("OK")
        hb.on_unhealthy = lambda e: print(f"PROBLEM: {e.errors}")
        hb.on_policy_change = lambda e: print("Policies changed!")
        hb.on_disconnect = lambda e: print("Lost connection!")

        await hb.start()
        ...
        await hb.stop()
    """

    def __init__(
        self,
        config: HeartbeatConfig | None = None,
        on_healthy: Callable[[HeartbeatEvent], Any] | None = None,
        on_degraded: Callable[[HeartbeatEvent], Any] | None = None,
        on_unhealthy: Callable[[HeartbeatEvent], Any] | None = None,
        on_disconnect: Callable[[HeartbeatEvent], Any] | None = None,
        on_policy_change: Callable[[HeartbeatEvent], Any] | None = None,
        on_reconnect: Callable[[HeartbeatEvent], Any] | None = None,
    ) -> None:
        self.config = config or HeartbeatConfig()
        self.on_healthy = on_healthy
        self.on_degraded = on_degraded
        self.on_unhealthy = on_unhealthy
        self.on_disconnect = on_disconnect
        self.on_policy_change = on_policy_change
        self.on_reconnect = on_reconnect

        # State
        self._status = HeartbeatStatus.UNKNOWN
        self._running = False
        self._task: asyncio.Task | None = None
        self._sequence = 0
        self._missed_count = 0
        self._last_policy_hash = ""
        self._history: list[HeartbeatEvent] = []
        self._latencies: list[float] = []
        self._start_time = 0.0
        self._policy_changes = 0
        self._disconnections = 0
        self._reconnections = 0
        self._reconnect_attempts = 0
        self._client = None

    @property
    def is_healthy(self) -> bool:
        """Whether the last heartbeat was successful."""
        return self._status == HeartbeatStatus.HEALTHY

    @property
    def is_connected(self) -> bool:
        """Whether we can reach the sidecar."""
        return self._status != HeartbeatStatus.DISCONNECTED

    @property
    def status(self) -> HeartbeatStatus:
        """Current heartbeat status."""
        return self._status

    @property
    def last_event(self) -> HeartbeatEvent | None:
        """The most recent heartbeat event."""
        return self._history[-1] if self._history else None

    @property
    def history(self) -> list[HeartbeatEvent]:
        """All heartbeat events."""
        return list(self._history)

    async def start(self) -> None:
        """Start the heartbeat monitoring loop."""
        if self._running:
            return

        self._running = True
        self._start_time = time.time()
        self._task = asyncio.create_task(self._heartbeat_loop())
        logger.info(
            f"Heartbeat started: interval={self.config.interval_seconds}s, "
            f"target={self.config.host}:{self.config.port}"
        )

    async def stop(self) -> HeartbeatSummary:
        """Stop the heartbeat monitoring and return summary."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

        if self._client:
            await self._client.aclose()
            self._client = None

        summary = self.get_summary()
        logger.info(f"Heartbeat stopped: {summary.total_pings} pings, {summary.uptime_percentage:.1f}% uptime")
        return summary

    async def ping(self) -> HeartbeatEvent:
        """Send a single heartbeat ping and return the result."""
        import httpx

        self._sequence += 1
        event = HeartbeatEvent(sequence=self._sequence)
        errors: list[str] = []
        checks: dict[str, bool] = {}

        start = time.time()

        try:
            if not self._client:
                self._client = httpx.AsyncClient(
                    base_url=f"http://{self.config.host}:{self.config.port}",
                    timeout=self.config.timeout_seconds,
                )

            # 1. Health check
            resp = await self._client.get("/api/v1/health")
            resp.raise_for_status()
            health_data = resp.json()

            latency = (time.time() - start) * 1000
            event.latency_ms = round(latency, 2)
            self._latencies.append(latency)

            event.sidecar_version = health_data.get("version", "")
            event.policies_loaded = health_data.get("policies_loaded", 0)
            event.active_sessions = health_data.get("active_sessions", 0)
            event.tokens_active = health_data.get("tokens_active", 0)

            checks["health"] = True

            # 2. Policy version check
            if self.config.check_policy_version:
                try:
                    policies_resp = await self._client.get("/api/v1/policies")
                    policies_resp.raise_for_status()
                    policies_data = policies_resp.json()
                    # Simple hash of policy names and rule counts
                    import hashlib
                    policy_str = str(sorted(
                        (p.get("name", ""), p.get("rules_count", 0))
                        for p in policies_data
                    ))
                    policy_hash = hashlib.md5(policy_str.encode()).hexdigest()[:12]
                    event.policy_hash = policy_hash

                    if self._last_policy_hash and policy_hash != self._last_policy_hash:
                        self._policy_changes += 1
                        errors.append("Policy configuration changed")
                        checks["policy_version"] = False
                        if self.on_policy_change:
                            self.on_policy_change(event)
                    else:
                        checks["policy_version"] = True

                    self._last_policy_hash = policy_hash
                except Exception as e:
                    checks["policy_version"] = False
                    errors.append(f"Policy check failed: {e}")

            # 3. License check
            if self.config.check_license:
                try:
                    license_resp = await self._client.get("/api/v1/license/status")
                    license_resp.raise_for_status()
                    license_data = license_resp.json()
                    event.license_status = license_data.get("status", "unknown")
                    checks["license"] = license_data.get("status", "") != "expired"
                    if not checks["license"]:
                        errors.append("License expired")
                except Exception:
                    # License endpoint may not exist in all deployments
                    checks["license"] = True

            # 4. Session check
            if self.config.check_sessions:
                try:
                    sessions_resp = await self._client.get("/api/v1/sessions")
                    sessions_resp.raise_for_status()
                    checks["sessions"] = True
                except Exception as e:
                    checks["sessions"] = False
                    errors.append(f"Session check failed: {e}")

            # Determine overall status
            event.checks = checks
            event.errors = errors
            failed_checks = [k for k, v in checks.items() if not v]

            if not failed_checks:
                event.status = HeartbeatStatus.HEALTHY
                self._missed_count = 0
                self._reconnect_attempts = 0
            elif "health" in failed_checks:
                event.status = HeartbeatStatus.UNHEALTHY
            else:
                event.status = HeartbeatStatus.DEGRADED

        except Exception as e:
            event.status = HeartbeatStatus.DISCONNECTED
            event.errors = [f"Connection failed: {e}"]
            event.latency_ms = (time.time() - start) * 1000
            self._missed_count += 1

            # Reset client on connection failure
            if self._client:
                try:
                    await self._client.aclose()
                except Exception:
                    pass
                self._client = None

        # Update overall status
        old_status = self._status
        if event.status == HeartbeatStatus.DISCONNECTED:
            if self._missed_count >= self.config.max_missed:
                self._status = HeartbeatStatus.DISCONNECTED
                if old_status != HeartbeatStatus.DISCONNECTED:
                    self._disconnections += 1
            elif self._missed_count > 1:
                self._status = HeartbeatStatus.DEGRADED
        else:
            if old_status == HeartbeatStatus.DISCONNECTED and event.status in (
                HeartbeatStatus.HEALTHY, HeartbeatStatus.DEGRADED
            ):
                self._reconnections += 1
                self._reconnect_attempts = 0
                if self.on_reconnect:
                    self.on_reconnect(event)
            self._status = event.status

        # Fire callbacks
        if event.status == HeartbeatStatus.HEALTHY and self.on_healthy:
            self.on_healthy(event)
        elif event.status == HeartbeatStatus.DEGRADED and self.on_degraded:
            self.on_degraded(event)
        elif event.status == HeartbeatStatus.UNHEALTHY and self.on_unhealthy:
            self.on_unhealthy(event)
        elif event.status == HeartbeatStatus.DISCONNECTED and self.on_disconnect:
            self.on_disconnect(event)

        # Store history (keep last 1000)
        self._history.append(event)
        if len(self._history) > 1000:
            self._history = self._history[-500:]

        return event

    async def _heartbeat_loop(self) -> None:
        """Main heartbeat monitoring loop."""
        while self._running:
            try:
                await self.ping()

                # Auto-reconnect logic
                if (
                    self._status == HeartbeatStatus.DISCONNECTED
                    and self.config.auto_reconnect
                    and self._reconnect_attempts < self.config.max_reconnect_attempts
                ):
                    self._reconnect_attempts += 1
                    logger.warning(
                        f"Heartbeat disconnected, reconnect attempt "
                        f"{self._reconnect_attempts}/{self.config.max_reconnect_attempts}"
                    )
                    await asyncio.sleep(self.config.reconnect_delay_seconds)
                else:
                    await asyncio.sleep(self.config.interval_seconds)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat loop error: {e}")
                await asyncio.sleep(self.config.interval_seconds)

    def get_summary(self) -> HeartbeatSummary:
        """Get a summary of the heartbeat monitoring session."""
        total = len(self._history)
        successful = sum(1 for e in self._history if e.status == HeartbeatStatus.HEALTHY)
        failed = total - successful

        avg_latency = sum(self._latencies) / len(self._latencies) if self._latencies else 0
        max_latency = max(self._latencies) if self._latencies else 0
        min_latency = min(self._latencies) if self._latencies else 0
        uptime_pct = (successful / total * 100) if total > 0 else 0

        return HeartbeatSummary(
            total_pings=total,
            successful_pings=successful,
            failed_pings=failed,
            avg_latency_ms=round(avg_latency, 2),
            max_latency_ms=round(max_latency, 2),
            min_latency_ms=round(min_latency, 2),
            uptime_percentage=round(uptime_pct, 1),
            policy_changes_detected=self._policy_changes,
            disconnections=self._disconnections,
            reconnections=self._reconnections,
            start_time=self._start_time,
            duration_seconds=round(time.time() - self._start_time, 2) if self._start_time else 0,
            last_status=self._status.value,
        )


# ---------------------------------------------------------------------------
# Heartbeat server endpoint (added to sidecar)
# ---------------------------------------------------------------------------

class HeartbeatResponse(BaseModel):
    """Response to a heartbeat ping from the sidecar."""
    status: str = "ok"
    timestamp: float = Field(default_factory=time.time)
    version: str = ""
    policies_loaded: int = 0
    policy_hash: str = ""
    active_sessions: int = 0
    tokens_active: int = 0
    license_status: str = ""
    uptime_seconds: float = 0.0


def add_heartbeat_endpoint(app: Any, engine: Any, vault: Any, token_store: Any, start_time: float) -> None:
    """Add heartbeat endpoint to an existing FastAPI app.

    Called by the sidecar to register /api/v1/heartbeat.
    """
    import hashlib

    @app.post("/api/v1/heartbeat")
    async def heartbeat(body: dict[str, Any] = {}) -> HeartbeatResponse:
        """Handle a heartbeat ping from an agent/OpenClaw."""
        # Compute policy hash
        policy_names = sorted(p.name for p in engine._policies)
        policy_hash = hashlib.md5(str(policy_names).encode()).hexdigest()[:12]

        # License status
        license_status = "unknown"
        try:
            from agentgate.licensing.license_manager import LicenseManager
            lm = LicenseManager()
            status = lm.status_dict()
            license_status = status.get("status", "unknown")
        except Exception:
            license_status = "unavailable"

        from agentgate import __version__

        return HeartbeatResponse(
            status="ok",
            version=__version__,
            policies_loaded=len(engine._policies),
            policy_hash=policy_hash,
            active_sessions=getattr(vault, '_active_sessions', {}).__len__() if hasattr(vault, '_active_sessions') else 0,
            tokens_active=getattr(token_store, 'active_count', 0),
            license_status=license_status,
            uptime_seconds=round(time.time() - start_time, 1),
        )

    @app.get("/api/v1/heartbeat/status")
    async def heartbeat_status() -> dict[str, Any]:
        """Get heartbeat endpoint status for monitoring."""
        from agentgate import __version__
        return {
            "status": "ok",
            "version": __version__,
            "uptime_seconds": round(time.time() - start_time, 1),
            "heartbeat_endpoint": "/api/v1/heartbeat",
        }
