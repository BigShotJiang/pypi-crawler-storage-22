"""
AgentGate MCP — Model Context Protocol integration.

AgentGate as MCP Server:
    Exposes AgentGate's firewall tools (evaluate_action, evaluate_mcp_tool,
    classify_risk, list_policies, health) via MCP protocol so any MCP client
    (Claude, GPT, Cursor, etc.) can call them natively.

AgentGate as MCP Proxy:
    Sits between an agent and downstream MCP servers, intercepts every
    tool call, applies policies, records evidence, and forwards or blocks.

Usage:
    # As MCP server (exposes AgentGate tools)
    from agentgate.mcp import create_agentgate_mcp_server

    server = create_agentgate_mcp_server(policy="finance-safe")
    server.run(transport="stdio")

    # As MCP proxy (wraps downstream servers)
    from agentgate.mcp import MCPProxyServer

    proxy = MCPProxyServer(
        mcp_policy="mcp-default",
        servers=[{"name": "stripe", "command": "npx", "args": ["-y", "@stripe/mcp"]}],
    )
    proxy.run(transport="stdio")

    # Evaluate a tool call directly
    from agentgate.mcp import MCPPolicyEngine, MCPToolCall

    engine = MCPPolicyEngine()
    engine.load_policy(create_mcp_default_policy())
    decision = engine.evaluate(MCPToolCall(
        server_name="stripe",
        tool_name="create_payment",
        arguments={"amount": 5000},
    ))
    print(decision.allowed)  # → False
"""

from agentgate.mcp.types import (
    MCPActionType,
    MCPToolCall,
    MCPToolCallDecision,
    MCPServerConfig,
    MCPToolRule,
    MCPPolicy,
)
from agentgate.mcp.policy_engine import (
    MCPPolicyEngine,
    classify_mcp_risk,
    MCP_PRESET_POLICIES,
    create_mcp_default_policy,
    create_mcp_readonly_policy,
    create_mcp_finance_safe_policy,
    create_mcp_devops_safe_policy,
)
from agentgate.mcp.server import create_agentgate_mcp_server
from agentgate.mcp.proxy import MCPProxyServer
from agentgate.mcp.plugin import (
    PluginRegistry,
    PluginContext,
    PluginDecision,
    PluginPriority,
    PolicyPlugin,
    TransformPlugin,
    AuditPlugin,
    ValidatorPlugin,
    SQLInjectionValidator,
    SensitiveDataValidator,
    RateLimitByServerPlugin,
    LoggingAuditPlugin,
    ArgumentNormalizerTransform,
    create_secure_registry,
    BUILTIN_PLUGINS,
)

__all__ = [
    # Types
    "MCPActionType",
    "MCPToolCall",
    "MCPToolCallDecision",
    "MCPServerConfig",
    "MCPToolRule",
    "MCPPolicy",
    # Policy engine
    "MCPPolicyEngine",
    "classify_mcp_risk",
    "MCP_PRESET_POLICIES",
    "create_mcp_default_policy",
    "create_mcp_readonly_policy",
    "create_mcp_finance_safe_policy",
    "create_mcp_devops_safe_policy",
    # Server
    "create_agentgate_mcp_server",
    # Proxy
    "MCPProxyServer",
    # Plugin system
    "PluginRegistry",
    "PluginContext",
    "PluginDecision",
    "PluginPriority",
    "PolicyPlugin",
    "TransformPlugin",
    "AuditPlugin",
    "ValidatorPlugin",
    "SQLInjectionValidator",
    "SensitiveDataValidator",
    "RateLimitByServerPlugin",
    "LoggingAuditPlugin",
    "ArgumentNormalizerTransform",
    "create_secure_registry",
    "BUILTIN_PLUGINS",
]
