"""
AgentGate MCP Plugin System — Extensible policy hooks for MCP tool calls.

The plugin system allows users to register custom policy hooks that
run before, after, or around MCP tool call evaluation. This makes the
MCP policy engine fully extensible without modifying core code.

Plugin types:
    - PolicyPlugin:     Custom evaluation logic (pre/post hooks)
    - TransformPlugin:  Modify tool calls before evaluation
    - AuditPlugin:      Custom logging/alerting after decisions
    - ValidatorPlugin:  Custom argument validation rules

Usage:
    from agentgate.mcp.plugin import (
        PolicyPlugin,
        PluginRegistry,
        plugin_hook,
    )

    class MyCompliancePlugin(PolicyPlugin):
        name = "pci-compliance"

        def pre_evaluate(self, tool_call, context):
            # Block any tool that touches credit card data
            for val in tool_call.arguments.values():
                if re.search(r'\\d{4}[- ]?\\d{4}[- ]?\\d{4}[- ]?\\d{4}', str(val)):
                    return PluginDecision(
                        block=True,
                        reason="PCI compliance: credit card data detected in arguments",
                    )
            return None  # No opinion — let other plugins/engine decide

    registry = PluginRegistry()
    registry.register(MyCompliancePlugin())

    engine = MCPPolicyEngine(plugin_registry=registry)
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from pydantic import BaseModel, Field

from agentgate.mcp.types import MCPToolCall, MCPToolCallDecision

logger = logging.getLogger("agentgate.mcp.plugin")


# ---------------------------------------------------------------------------
# Plugin decision model
# ---------------------------------------------------------------------------

class PluginDecision(BaseModel):
    """A decision returned by a plugin hook.

    If block=True, the tool call is immediately blocked with the given reason.
    If override_decision is set, it replaces the engine's decision.
    If neither is set, the plugin has no opinion (pass-through).
    """
    block: bool = False
    override_decision: str = ""  # allow, block, require_approval, log_only
    reason: str = ""
    risk_override: str = ""  # Override the auto-classified risk level
    metadata: dict[str, Any] = Field(default_factory=dict)
    plugin_name: str = ""


class PluginContext(BaseModel):
    """Context passed to plugin hooks — enriched throughout the pipeline."""
    agent_id: str = ""
    session_id: str = ""
    timestamp: float = Field(default_factory=time.time)
    prior_decisions: list[PluginDecision] = Field(default_factory=list)
    engine_decision: MCPToolCallDecision | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Plugin base classes
# ---------------------------------------------------------------------------

class PluginPriority(int, Enum):
    """Execution order for plugins — lower runs first."""
    CRITICAL = 0      # Security-critical checks (run first)
    HIGH = 10
    NORMAL = 50
    LOW = 90
    AUDIT = 100       # Audit/logging plugins (run last)


class PolicyPlugin(ABC):
    """Base class for MCP policy plugins.

    Subclass this to add custom evaluation logic to the MCP pipeline.
    Plugins can run before the engine evaluates (pre_evaluate) and
    after (post_evaluate).

    Example:
        class BlockWeekendPlugin(PolicyPlugin):
            name = "no-weekends"
            priority = PluginPriority.NORMAL

            def pre_evaluate(self, tool_call, context):
                import datetime
                if datetime.datetime.now().weekday() >= 5:
                    return PluginDecision(
                        block=True,
                        reason="Tool calls blocked on weekends",
                    )
                return None
    """

    name: str = "unnamed-plugin"
    description: str = ""
    priority: PluginPriority = PluginPriority.NORMAL
    enabled: bool = True

    def pre_evaluate(
        self, tool_call: MCPToolCall, context: PluginContext
    ) -> PluginDecision | None:
        """Called BEFORE the engine evaluates the tool call.

        Return a PluginDecision to block/override, or None to pass through.
        """
        return None

    def post_evaluate(
        self,
        tool_call: MCPToolCall,
        decision: MCPToolCallDecision,
        context: PluginContext,
    ) -> PluginDecision | None:
        """Called AFTER the engine evaluates the tool call.

        Can modify or override the engine's decision. Return None to keep it.
        """
        return None


class TransformPlugin(ABC):
    """Plugin that can modify tool calls before evaluation.

    Use this to sanitize arguments, normalize names, inject metadata, etc.
    """

    name: str = "unnamed-transform"
    description: str = ""
    priority: PluginPriority = PluginPriority.NORMAL
    enabled: bool = True

    @abstractmethod
    def transform(
        self, tool_call: MCPToolCall, context: PluginContext
    ) -> MCPToolCall:
        """Transform the tool call before it's evaluated.

        Must return the (potentially modified) tool call.
        """
        ...


class AuditPlugin(ABC):
    """Plugin for custom audit/logging/alerting after decisions.

    Unlike PolicyPlugin.post_evaluate, audit plugins cannot change decisions.
    They are purely observational — for logging, metrics, webhooks, etc.
    """

    name: str = "unnamed-audit"
    description: str = ""
    priority: PluginPriority = PluginPriority.AUDIT
    enabled: bool = True

    @abstractmethod
    def on_decision(
        self,
        tool_call: MCPToolCall,
        decision: MCPToolCallDecision,
        context: PluginContext,
    ) -> None:
        """Called after a final decision is made. Cannot alter the decision."""
        ...


class ValidatorPlugin(ABC):
    """Plugin for custom argument validation rules.

    Validators check tool call arguments against custom rules and can
    block calls with invalid/dangerous arguments.
    """

    name: str = "unnamed-validator"
    description: str = ""
    priority: PluginPriority = PluginPriority.HIGH
    enabled: bool = True

    @abstractmethod
    def validate(
        self, tool_call: MCPToolCall, context: PluginContext
    ) -> PluginDecision | None:
        """Validate tool call arguments.

        Return a PluginDecision with block=True if validation fails.
        Return None if validation passes.
        """
        ...


# ---------------------------------------------------------------------------
# Plugin Registry
# ---------------------------------------------------------------------------

class PluginRegistry:
    """Registry that manages all MCP policy plugins.

    Plugins are executed in priority order (lower priority value = runs first).
    The pipeline is:
        1. Transform plugins (modify the tool call)
        2. Validator plugins (check arguments)
        3. Pre-evaluate policy plugins (custom pre-checks)
        4. Engine evaluation (core policy rules)
        5. Post-evaluate policy plugins (override decisions)
        6. Audit plugins (logging/alerting — cannot change decisions)
    """

    def __init__(self) -> None:
        self._policy_plugins: list[PolicyPlugin] = []
        self._transform_plugins: list[TransformPlugin] = []
        self._audit_plugins: list[AuditPlugin] = []
        self._validator_plugins: list[ValidatorPlugin] = []

    def register(self, plugin: PolicyPlugin | TransformPlugin | AuditPlugin | ValidatorPlugin) -> None:
        """Register a plugin with the registry."""
        if isinstance(plugin, ValidatorPlugin):
            self._validator_plugins.append(plugin)
            self._validator_plugins.sort(key=lambda p: p.priority)
        elif isinstance(plugin, TransformPlugin):
            self._transform_plugins.append(plugin)
            self._transform_plugins.sort(key=lambda p: p.priority)
        elif isinstance(plugin, AuditPlugin):
            self._audit_plugins.append(plugin)
            self._audit_plugins.sort(key=lambda p: p.priority)
        elif isinstance(plugin, PolicyPlugin):
            self._policy_plugins.append(plugin)
            self._policy_plugins.sort(key=lambda p: p.priority)
        else:
            raise TypeError(f"Unknown plugin type: {type(plugin)}")

        logger.info(f"Registered plugin: {plugin.name} ({type(plugin).__name__})")

    def unregister(self, plugin_name: str) -> bool:
        """Unregister a plugin by name. Returns True if found and removed."""
        for plugin_list in [
            self._policy_plugins,
            self._transform_plugins,
            self._audit_plugins,
            self._validator_plugins,
        ]:
            for i, p in enumerate(plugin_list):
                if p.name == plugin_name:
                    plugin_list.pop(i)
                    logger.info(f"Unregistered plugin: {plugin_name}")
                    return True
        return False

    def get_plugin(self, plugin_name: str) -> PolicyPlugin | TransformPlugin | AuditPlugin | ValidatorPlugin | None:
        """Get a plugin by name."""
        for plugin_list in [
            self._policy_plugins,
            self._transform_plugins,
            self._audit_plugins,
            self._validator_plugins,
        ]:
            for p in plugin_list:
                if p.name == plugin_name:
                    return p
        return None

    def list_plugins(self) -> list[dict[str, Any]]:
        """List all registered plugins with their metadata."""
        result = []
        for category, plugins in [
            ("policy", self._policy_plugins),
            ("transform", self._transform_plugins),
            ("audit", self._audit_plugins),
            ("validator", self._validator_plugins),
        ]:
            for p in plugins:
                result.append({
                    "name": p.name,
                    "description": p.description,
                    "category": category,
                    "priority": p.priority,
                    "enabled": p.enabled,
                    "type": type(p).__name__,
                })
        return result

    def run_transforms(
        self, tool_call: MCPToolCall, context: PluginContext
    ) -> MCPToolCall:
        """Run all transform plugins on a tool call."""
        for plugin in self._transform_plugins:
            if not plugin.enabled:
                continue
            try:
                tool_call = plugin.transform(tool_call, context)
            except Exception as e:
                logger.error(f"Transform plugin '{plugin.name}' failed: {e}")
        return tool_call

    def run_validators(
        self, tool_call: MCPToolCall, context: PluginContext
    ) -> PluginDecision | None:
        """Run all validator plugins. Returns first blocking decision, or None."""
        for plugin in self._validator_plugins:
            if not plugin.enabled:
                continue
            try:
                result = plugin.validate(tool_call, context)
                if result and result.block:
                    result.plugin_name = plugin.name
                    return result
            except Exception as e:
                logger.error(f"Validator plugin '{plugin.name}' failed: {e}")
        return None

    def run_pre_evaluate(
        self, tool_call: MCPToolCall, context: PluginContext
    ) -> PluginDecision | None:
        """Run all pre-evaluate hooks. Returns first blocking decision, or None."""
        for plugin in self._policy_plugins:
            if not plugin.enabled:
                continue
            try:
                result = plugin.pre_evaluate(tool_call, context)
                if result:
                    result.plugin_name = plugin.name
                    context.prior_decisions.append(result)
                    if result.block:
                        return result
            except Exception as e:
                logger.error(f"Pre-evaluate plugin '{plugin.name}' failed: {e}")
        return None

    def run_post_evaluate(
        self,
        tool_call: MCPToolCall,
        decision: MCPToolCallDecision,
        context: PluginContext,
    ) -> MCPToolCallDecision:
        """Run all post-evaluate hooks. May modify the decision."""
        context.engine_decision = decision
        for plugin in self._policy_plugins:
            if not plugin.enabled:
                continue
            try:
                result = plugin.post_evaluate(tool_call, decision, context)
                if result:
                    result.plugin_name = plugin.name
                    context.prior_decisions.append(result)
                    if result.block:
                        decision = MCPToolCallDecision(
                            allowed=False,
                            decision="block",
                            risk_level=result.risk_override or decision.risk_level,
                            reason=f"[{plugin.name}] {result.reason}",
                            policy_name=decision.policy_name,
                            matched_rule=f"plugin:{plugin.name}",
                            server_name=decision.server_name,
                            tool_name=decision.tool_name,
                            tool_fingerprint=decision.tool_fingerprint,
                        )
                    elif result.override_decision:
                        is_allowed = result.override_decision in ("allow", "log_only")
                        decision = MCPToolCallDecision(
                            allowed=is_allowed,
                            decision=result.override_decision,
                            risk_level=result.risk_override or decision.risk_level,
                            reason=f"[{plugin.name}] {result.reason}" if result.reason else decision.reason,
                            policy_name=decision.policy_name,
                            matched_rule=f"plugin:{plugin.name}",
                            server_name=decision.server_name,
                            tool_name=decision.tool_name,
                            tool_fingerprint=decision.tool_fingerprint,
                        )
            except Exception as e:
                logger.error(f"Post-evaluate plugin '{plugin.name}' failed: {e}")
        return decision

    def run_audit(
        self,
        tool_call: MCPToolCall,
        decision: MCPToolCallDecision,
        context: PluginContext,
    ) -> None:
        """Run all audit plugins (non-blocking, fire-and-forget)."""
        for plugin in self._audit_plugins:
            if not plugin.enabled:
                continue
            try:
                plugin.on_decision(tool_call, decision, context)
            except Exception as e:
                logger.error(f"Audit plugin '{plugin.name}' failed: {e}")

    @property
    def plugin_count(self) -> int:
        return (
            len(self._policy_plugins)
            + len(self._transform_plugins)
            + len(self._audit_plugins)
            + len(self._validator_plugins)
        )

    def clear(self) -> None:
        """Remove all plugins."""
        self._policy_plugins.clear()
        self._transform_plugins.clear()
        self._audit_plugins.clear()
        self._validator_plugins.clear()


# ---------------------------------------------------------------------------
# Built-in plugins
# ---------------------------------------------------------------------------

class SQLInjectionValidator(ValidatorPlugin):
    """Blocks tool calls with SQL injection patterns in arguments."""

    name = "sql-injection-guard"
    description = "Blocks MCP tool calls containing SQL injection patterns"
    priority = PluginPriority.CRITICAL

    SQL_PATTERNS = [
        r";\s*DROP\s+",
        r";\s*DELETE\s+",
        r";\s*TRUNCATE\s+",
        r";\s*UPDATE\s+.*\s+SET\s+",
        r"'\s*OR\s+'1'\s*=\s*'1",
        r"'\s*OR\s+1\s*=\s*1",
        r"UNION\s+SELECT\s+",
        r"--\s*$",
        r";\s*INSERT\s+INTO\s+",
    ]

    def validate(self, tool_call: MCPToolCall, context: PluginContext) -> PluginDecision | None:
        import re
        for arg_name, arg_value in tool_call.arguments.items():
            val = str(arg_value)
            for pattern in self.SQL_PATTERNS:
                if re.search(pattern, val, re.IGNORECASE):
                    return PluginDecision(
                        block=True,
                        reason=f"SQL injection pattern detected in argument '{arg_name}'",
                        risk_override="critical",
                    )
        return None


class SensitiveDataValidator(ValidatorPlugin):
    """Blocks tool calls with sensitive data patterns (credit cards, SSNs, etc.)."""

    name = "sensitive-data-guard"
    description = "Blocks MCP tool calls containing credit card numbers, SSNs, etc."
    priority = PluginPriority.CRITICAL

    PATTERNS = {
        "credit_card": r"\b(?:\d{4}[- ]?){3}\d{4}\b",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "api_key": r"\b(?:sk|pk|api)[-_][a-zA-Z0-9]{20,}\b",
    }

    def validate(self, tool_call: MCPToolCall, context: PluginContext) -> PluginDecision | None:
        import re
        for arg_name, arg_value in tool_call.arguments.items():
            val = str(arg_value)
            for data_type, pattern in self.PATTERNS.items():
                if re.search(pattern, val):
                    return PluginDecision(
                        block=True,
                        reason=f"Sensitive data ({data_type}) detected in argument '{arg_name}'",
                        risk_override="critical",
                    )
        return None


class RateLimitByServerPlugin(PolicyPlugin):
    """Per-server rate limiting plugin (more granular than policy-level)."""

    name = "per-server-rate-limit"
    description = "Rate limits tool calls per-server (customizable limits)"
    priority = PluginPriority.HIGH

    def __init__(self, limits: dict[str, int] | None = None, default_limit: int = 60) -> None:
        self._limits = limits or {}  # server_name -> max calls per minute
        self._default_limit = default_limit
        self._counters: dict[str, list[float]] = {}

    def pre_evaluate(self, tool_call: MCPToolCall, context: PluginContext) -> PluginDecision | None:
        server = tool_call.server_name or "__default__"
        limit = self._limits.get(server, self._default_limit)

        now = time.time()
        key = f"srv:{server}"
        if key not in self._counters:
            self._counters[key] = []
        self._counters[key] = [ts for ts in self._counters[key] if now - ts < 60]
        self._counters[key].append(now)

        if len(self._counters[key]) > limit:
            return PluginDecision(
                block=True,
                reason=f"Server '{server}' rate limit exceeded ({limit}/min)",
            )
        return None


class LoggingAuditPlugin(AuditPlugin):
    """Simple audit plugin that logs all decisions."""

    name = "decision-logger"
    description = "Logs all MCP tool call decisions"
    priority = PluginPriority.AUDIT

    def __init__(self) -> None:
        self.log: list[dict[str, Any]] = []

    def on_decision(
        self,
        tool_call: MCPToolCall,
        decision: MCPToolCallDecision,
        context: PluginContext,
    ) -> None:
        entry = {
            "timestamp": time.time(),
            "server": tool_call.server_name,
            "tool": tool_call.tool_name,
            "agent_id": tool_call.agent_id,
            "allowed": decision.allowed,
            "decision": decision.decision,
            "risk_level": decision.risk_level,
            "reason": decision.reason,
            "policy": decision.policy_name,
        }
        self.log.append(entry)
        logger.info(
            f"MCP Decision: {tool_call.server_name}/{tool_call.tool_name} "
            f"→ {decision.decision} ({decision.reason})"
        )


class ArgumentNormalizerTransform(TransformPlugin):
    """Normalizes tool call arguments (strip whitespace, lowercase keys)."""

    name = "arg-normalizer"
    description = "Strips whitespace from argument values and normalizes keys"
    priority = PluginPriority.NORMAL

    def transform(self, tool_call: MCPToolCall, context: PluginContext) -> MCPToolCall:
        normalized_args = {}
        for key, value in tool_call.arguments.items():
            clean_key = key.strip()
            if isinstance(value, str):
                normalized_args[clean_key] = value.strip()
            else:
                normalized_args[clean_key] = value
        tool_call.arguments = normalized_args
        return tool_call


# ---------------------------------------------------------------------------
# Convenience: built-in plugin presets
# ---------------------------------------------------------------------------

BUILTIN_PLUGINS = {
    "sql-injection-guard": SQLInjectionValidator,
    "sensitive-data-guard": SensitiveDataValidator,
    "per-server-rate-limit": RateLimitByServerPlugin,
    "decision-logger": LoggingAuditPlugin,
    "arg-normalizer": ArgumentNormalizerTransform,
}


def create_secure_registry() -> PluginRegistry:
    """Create a registry with all built-in security plugins enabled."""
    registry = PluginRegistry()
    registry.register(SQLInjectionValidator())
    registry.register(SensitiveDataValidator())
    registry.register(LoggingAuditPlugin())
    registry.register(ArgumentNormalizerTransform())
    return registry
