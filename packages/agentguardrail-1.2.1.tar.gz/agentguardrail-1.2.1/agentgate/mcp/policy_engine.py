"""
AgentGate MCP Policy Engine — Evaluates MCP tool calls against policies.

This is the MCP equivalent of agentgate.policy.engine.PolicyEngine.
It reuses the same 3-layer intent matching pipeline (keywords → phonetic
→ NLP semantic) but applies it to tool names and argument values instead
of browser element text.

Usage:
    from agentgate.mcp.policy_engine import MCPPolicyEngine

    engine = MCPPolicyEngine()
    engine.load_policy(mcp_policy)

    decision = engine.evaluate(tool_call)
    if decision.allowed:
        # Forward the call to the downstream MCP server
        ...
    else:
        print(f"Blocked: {decision.reason}")
"""

from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Any

import yaml

from agentgate.mcp.types import (
    MCPPolicy,
    MCPToolCall,
    MCPToolCallDecision,
    MCPToolRule,
)
from agentgate.policy.intent_matcher import (
    detect_intents,
    phonetic_detect_intents,
)
from agentgate.policy.semantic_matcher import (
    semantic_detect_intents,
    semantic_risk,
    is_semantic_available,
)


# ---------------------------------------------------------------------------
# Intent → risk mapping (same categories as browser engine)
# ---------------------------------------------------------------------------

CRITICAL_INTENTS = {"destructive_system"}
HIGH_RISK_INTENTS = {
    "payment", "delete", "admin", "authentication",
    "sensitive_field", "financial", "system_destructive",
    "system", "permission", "api_call",
}
MEDIUM_RISK_INTENTS = {
    "confirm", "modify", "share", "export", "upload", "messaging",
    "modifying", "sharing", "posting", "uploading", "downloading",
    "data_entry",
}
LOW_RISK_INTENTS = {"navigation", "social"}

RISK_ORDER = {
    "none": 0, "low": 1, "medium": 2, "high": 3, "critical": 4,
}


def classify_mcp_risk(tool_call: MCPToolCall) -> str:
    """Auto-classify risk of an MCP tool call using the 3-layer pipeline.

    Works exactly like the browser engine's classify_risk() — runs the
    combined text (server + tool + arguments) through keywords → phonetic
    → NLP semantic matching to detect intent and assign risk.
    """
    combined = tool_call.combined_text.lower()

    # Layer 1: keyword intent matching
    matched_intents = detect_intents(combined)

    # Layer 2: phonetic matching (catches typos)
    if not matched_intents:
        phonetic_results = phonetic_detect_intents(combined)
        matched_intents = [intent for intent, _ in phonetic_results]

    # Layer 3: NLP semantic matching (catches novel phrasings)
    if not matched_intents:
        semantic_results = semantic_detect_intents(combined, threshold=0.65)
        if semantic_results:
            matched_intents = [intent for intent, _ in semantic_results]

    # Map intents to risk levels
    for intent in matched_intents:
        if intent in CRITICAL_INTENTS:
            return "critical"
    for intent in matched_intents:
        if intent in HIGH_RISK_INTENTS:
            return "high"
    for intent in matched_intents:
        if intent in MEDIUM_RISK_INTENTS:
            return "medium"

    return "low"


def _glob_match(pattern: str, text: str) -> bool:
    """Match a glob-style pattern against text (case-insensitive).

    Supports:
        *         → match anything
        *_payment → match anything ending in _payment
        create_*  → match anything starting with create_
        stripe    → exact match
        pay*|del* → multiple patterns separated by |
    """
    if not pattern or pattern == "*":
        return True

    text_lower = text.lower()

    # Support | for multiple patterns
    for sub_pattern in pattern.split("|"):
        sub_pattern = sub_pattern.strip().lower()
        if not sub_pattern:
            continue
        # Convert glob to regex
        regex = "^" + sub_pattern.replace("*", ".*") + "$"
        if re.match(regex, text_lower):
            return True

    return False


def _rule_matches_tool_call(rule: MCPToolRule, tool_call: MCPToolCall) -> bool:
    """Check if a single MCPToolRule matches an MCPToolCall."""
    # Check server pattern
    if not _glob_match(rule.server_pattern, tool_call.server_name):
        return False

    # Check tool pattern
    if not _glob_match(rule.tool_pattern, tool_call.tool_name):
        return False

    # Check argument patterns (regex)
    for arg_name, pattern in rule.arg_patterns.items():
        arg_value = str(tool_call.arguments.get(arg_name, ""))
        if not re.search(pattern, arg_value, re.IGNORECASE):
            return False

    # Check blocked argument values
    for arg_name, blocked_values in rule.arg_block_values.items():
        arg_value = str(tool_call.arguments.get(arg_name, "")).lower()
        if not any(bv.lower() in arg_value for bv in blocked_values):
            return False

    # Check intent-based matching (uses the same 3-layer pipeline)
    if rule.intent:
        combined = tool_call.combined_text.lower()
        matched_intents = detect_intents(combined)
        if not matched_intents:
            phonetic_results = phonetic_detect_intents(combined)
            matched_intents = [intent for intent, _ in phonetic_results]
        if not matched_intents:
            semantic_results = semantic_detect_intents(combined, threshold=0.65)
            if semantic_results:
                matched_intents = [intent for intent, _ in semantic_results]

        if rule.intent.lower() not in [i.lower() for i in matched_intents]:
            return False

    return True


# ---------------------------------------------------------------------------
# MCP Policy Engine
# ---------------------------------------------------------------------------

class MCPPolicyEngine:
    """Evaluates MCP tool calls against loaded MCP policies.

    This is the core of AgentGate's MCP governance. It works just like
    the browser PolicyEngine but for MCP tool calls.

    Usage:
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="safe",
            tool_rules=[
                MCPToolRule(tool_pattern="delete_*", decision="block"),
            ]
        ))

        decision = engine.evaluate(MCPToolCall(
            server_name="database",
            tool_name="delete_table",
            arguments={"table": "users"},
        ))
        # → blocked
    """

    def __init__(self, plugin_registry: Any | None = None) -> None:
        self._policies: list[MCPPolicy] = []
        self._call_counts: dict[str, list[float]] = {}
        self._plugin_registry = plugin_registry  # Optional PluginRegistry for extensible hooks

    def load_policy(self, policy: MCPPolicy) -> None:
        """Load an MCP policy into the engine."""
        self._policies.append(policy)

    def load_policy_from_yaml(self, path: str | Path) -> MCPPolicy:
        """Load an MCP policy from a YAML file."""
        with open(path) as f:
            data = yaml.safe_load(f)
        # Check if it's an MCP policy (has tool_rules or mcp_ prefix)
        policy = MCPPolicy.from_dict(data)
        self.load_policy(policy)
        return policy

    def load_policy_from_yaml_string(self, yaml_string: str) -> MCPPolicy:
        """Load an MCP policy from a YAML string."""
        data = yaml.safe_load(yaml_string)
        policy = MCPPolicy.from_dict(data)
        self.load_policy(policy)
        return policy

    def load_policies_from_dir(self, directory: str | Path) -> int:
        """Load all MCP policy YAML files from a directory. Returns count loaded."""
        directory = Path(directory)
        count = 0
        for yaml_file in list(directory.glob("*.yaml")) + list(directory.glob("*.yml")):
            try:
                with open(yaml_file) as f:
                    data = yaml.safe_load(f)
                # Only load if it looks like an MCP policy
                if data and ("tool_rules" in data or data.get("name", "").startswith("mcp-")):
                    policy = MCPPolicy.from_dict(data)
                    self.load_policy(policy)
                    count += 1
            except Exception:
                continue
        return count

    def clear_policies(self) -> None:
        """Remove all loaded MCP policies."""
        self._policies.clear()

    def evaluate(self, tool_call: MCPToolCall) -> MCPToolCallDecision:
        """Evaluate an MCP tool call against all loaded policies.

        Most restrictive decision wins (same as browser engine):
        BLOCK > REQUIRE_APPROVAL > LOG_ONLY > ALLOW

        If a plugin_registry is set, the full pipeline is:
        1. Transform plugins (modify tool call)
        2. Validator plugins (argument checks)
        3. Pre-evaluate policy plugins
        4. Core engine evaluation
        5. Post-evaluate policy plugins
        6. Audit plugins (non-blocking)
        """
        # --- Plugin pipeline ---
        context = None
        if self._plugin_registry:
            from agentgate.mcp.plugin import PluginContext
            context = PluginContext(
                agent_id=tool_call.agent_id,
                session_id=tool_call.session_id,
            )

            # 1. Transform
            tool_call = self._plugin_registry.run_transforms(tool_call, context)

            # 2. Validators
            validator_result = self._plugin_registry.run_validators(tool_call, context)
            if validator_result and validator_result.block:
                decision = MCPToolCallDecision(
                    allowed=False,
                    decision="block",
                    risk_level=validator_result.risk_override or "high",
                    reason=f"[{validator_result.plugin_name}] {validator_result.reason}",
                    matched_rule=f"plugin:{validator_result.plugin_name}",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )
                self._plugin_registry.run_audit(tool_call, decision, context)
                return decision

            # 3. Pre-evaluate
            pre_result = self._plugin_registry.run_pre_evaluate(tool_call, context)
            if pre_result and pre_result.block:
                decision = MCPToolCallDecision(
                    allowed=False,
                    decision="block",
                    risk_level=pre_result.risk_override or "high",
                    reason=f"[{pre_result.plugin_name}] {pre_result.reason}",
                    matched_rule=f"plugin:{pre_result.plugin_name}",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )
                self._plugin_registry.run_audit(tool_call, decision, context)
                return decision

        risk = classify_mcp_risk(tool_call)
        decisions: list[MCPToolCallDecision] = []

        for policy in self._policies:
            if not policy.enabled:
                continue
            decision = self._evaluate_single_policy(tool_call, policy, risk)
            decisions.append(decision)

        if not decisions:
            no_policy_decision = MCPToolCallDecision(
                allowed=True,
                decision="allow",
                risk_level=risk,
                reason="No MCP policies loaded",
                server_name=tool_call.server_name,
                tool_name=tool_call.tool_name,
                tool_fingerprint=tool_call.fingerprint,
            )
            # Still run post-evaluate and audit even with no policies
            if self._plugin_registry and context:
                no_policy_decision = self._plugin_registry.run_post_evaluate(
                    tool_call, no_policy_decision, context
                )
                self._plugin_registry.run_audit(tool_call, no_policy_decision, context)
            return no_policy_decision

        # Most restrictive wins
        priority = {"block": 4, "require_approval": 3, "log_only": 2, "allow": 1}
        decisions.sort(key=lambda d: priority.get(d.decision, 0), reverse=True)
        final_decision = decisions[0]

        # --- Plugin post-evaluate and audit ---
        if self._plugin_registry and context:
            # 5. Post-evaluate
            final_decision = self._plugin_registry.run_post_evaluate(
                tool_call, final_decision, context
            )
            # 6. Audit
            self._plugin_registry.run_audit(tool_call, final_decision, context)

        return final_decision

    def _evaluate_single_policy(
        self, tool_call: MCPToolCall, policy: MCPPolicy, risk: str
    ) -> MCPToolCallDecision:
        """Evaluate a tool call against a single MCP policy."""

        # --- Rate limiting ---
        if policy.max_calls_per_minute > 0:
            if self._check_rate_limit(tool_call.agent_id, policy.max_calls_per_minute):
                return MCPToolCallDecision(
                    allowed=False,
                    decision="block",
                    risk_level="high",
                    reason=f"Rate limit exceeded: {policy.max_calls_per_minute}/min",
                    policy_name=policy.name,
                    matched_rule="rate_limit",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )

        # --- Server allowlist/blocklist ---
        if policy.blocked_servers:
            if any(s.lower() == tool_call.server_name.lower() for s in policy.blocked_servers):
                return MCPToolCallDecision(
                    allowed=False,
                    decision="block",
                    risk_level="high",
                    reason=f"Server '{tool_call.server_name}' is blocked by policy",
                    policy_name=policy.name,
                    matched_rule=f"blocked_server:{tool_call.server_name}",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )

        if policy.allowed_servers:
            if not any(s.lower() == tool_call.server_name.lower() for s in policy.allowed_servers):
                return MCPToolCallDecision(
                    allowed=False,
                    decision="block",
                    risk_level="high",
                    reason=f"Server '{tool_call.server_name}' not in allowlist",
                    policy_name=policy.name,
                    matched_rule="server_not_in_allowlist",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )

        # --- Tool allowlist/blocklist (quick check) ---
        if policy.blocked_tools:
            if any(_glob_match(bt, tool_call.tool_name) for bt in policy.blocked_tools):
                return MCPToolCallDecision(
                    allowed=False,
                    decision="block",
                    risk_level="high",
                    reason=f"Tool '{tool_call.tool_name}' is blocked by policy",
                    policy_name=policy.name,
                    matched_rule=f"blocked_tool:{tool_call.tool_name}",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )

        if policy.allowed_tools:
            if not any(_glob_match(at, tool_call.tool_name) for at in policy.allowed_tools):
                return MCPToolCallDecision(
                    allowed=False,
                    decision="block",
                    risk_level="high",
                    reason=f"Tool '{tool_call.tool_name}' not in allowlist",
                    policy_name=policy.name,
                    matched_rule="tool_not_in_allowlist",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )
            else:
                # Tool IS in the allowlist — explicitly allow it
                return MCPToolCallDecision(
                    allowed=True,
                    decision="allow",
                    risk_level=risk,
                    reason=f"Tool '{tool_call.tool_name}' is in allowlist",
                    policy_name=policy.name,
                    matched_rule="tool_in_allowlist",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )

        # --- Argument length check ---
        if policy.max_arg_length > 0:
            for arg_name, arg_value in tool_call.arguments.items():
                if len(str(arg_value)) > policy.max_arg_length:
                    return MCPToolCallDecision(
                        allowed=False,
                        decision="block",
                        risk_level="medium",
                        reason=f"Argument '{arg_name}' exceeds max length ({policy.max_arg_length})",
                        policy_name=policy.name,
                        matched_rule=f"max_arg_length:{arg_name}",
                        server_name=tool_call.server_name,
                        tool_name=tool_call.tool_name,
                        tool_fingerprint=tool_call.fingerprint,
                    )

        # --- Tool rules (detailed matching) ---
        for rule in policy.tool_rules:
            if _rule_matches_tool_call(rule, tool_call):
                is_allowed = rule.decision in ("allow", "log_only")
                effective_risk = rule.risk if rule.risk != "none" else risk
                return MCPToolCallDecision(
                    allowed=is_allowed,
                    decision=rule.decision,
                    risk_level=effective_risk,
                    reason=rule.reason or f"Matched rule: {rule.tool_pattern} on {rule.server_pattern}",
                    policy_name=policy.name,
                    matched_rule=f"tool_rule:{rule.server_pattern}/{rule.tool_pattern}",
                    server_name=tool_call.server_name,
                    tool_name=tool_call.tool_name,
                    tool_fingerprint=tool_call.fingerprint,
                )

        # --- Default decision ---
        is_allowed = policy.default_decision in ("allow", "log_only")
        return MCPToolCallDecision(
            allowed=is_allowed,
            decision=policy.default_decision,
            risk_level=risk,
            reason=f"Default MCP policy decision: {policy.default_decision}",
            policy_name=policy.name,
            matched_rule="default",
            server_name=tool_call.server_name,
            tool_name=tool_call.tool_name,
            tool_fingerprint=tool_call.fingerprint,
        )

    def _check_rate_limit(self, agent_id: str, max_per_minute: int) -> bool:
        """Check if an agent has exceeded its MCP call rate limit."""
        now = time.time()
        key = f"mcp:{agent_id}"
        if key not in self._call_counts:
            self._call_counts[key] = []
        self._call_counts[key] = [
            ts for ts in self._call_counts[key] if now - ts < 60
        ]
        self._call_counts[key].append(now)
        return len(self._call_counts[key]) > max_per_minute


# ---------------------------------------------------------------------------
# Preset MCP policies
# ---------------------------------------------------------------------------

def create_mcp_default_policy() -> MCPPolicy:
    """Default MCP policy — block dangerous tools, allow the rest."""
    return MCPPolicy.from_dict({
        "name": "mcp-default",
        "description": "Block dangerous MCP tools (delete, payment, admin), allow everything else",
        "default_decision": "allow",
        "max_calls_per_minute": 60,
        "tool_rules": [
            {
                "intent": "delete",
                "decision": "block",
                "risk": "high",
                "reason": "Deletion tools are blocked by default policy",
            },
            {
                "intent": "payment",
                "decision": "block",
                "risk": "high",
                "reason": "Payment tools are blocked by default policy",
            },
            {
                "intent": "admin",
                "decision": "require_approval",
                "risk": "high",
                "reason": "Admin tools require approval",
            },
            {
                "tool_pattern": "drop_*|truncate_*|destroy_*|wipe_*",
                "decision": "block",
                "risk": "critical",
                "reason": "Destructive operations are blocked",
            },
        ],
    })


def create_mcp_readonly_policy() -> MCPPolicy:
    """Read-only MCP policy — only allow read/get/list/search tools."""
    return MCPPolicy.from_dict({
        "name": "mcp-readonly",
        "description": "Only allow read operations — block all writes, deletes, and mutations",
        "default_decision": "block",
        "allowed_tools": [
            "get_*", "list_*", "read_*", "search_*", "find_*",
            "fetch_*", "query_*", "show_*", "describe_*", "count_*",
        ],
    })


def create_mcp_finance_safe_policy() -> MCPPolicy:
    """Finance-safe MCP policy — block payment/billing tools."""
    return MCPPolicy.from_dict({
        "name": "mcp-finance-safe",
        "description": "Block all payment, billing, and financial mutation tools",
        "default_decision": "allow",
        "max_calls_per_minute": 30,
        "tool_rules": [
            {
                "intent": "payment",
                "decision": "block",
                "risk": "high",
                "reason": "Payment operations are blocked",
            },
            {
                "intent": "financial",
                "decision": "block",
                "risk": "high",
                "reason": "Financial mutation tools are blocked",
            },
            {
                "intent": "delete",
                "decision": "block",
                "risk": "high",
                "reason": "Deletion tools are blocked",
            },
            {
                "tool_pattern": "create_charge|create_payment*|transfer_*|refund_*|payout_*",
                "decision": "block",
                "risk": "high",
                "reason": "Financial transaction tools are blocked",
            },
            {
                "tool_pattern": "update_subscription|cancel_subscription",
                "decision": "require_approval",
                "risk": "medium",
                "reason": "Subscription changes require approval",
            },
        ],
    })


def create_mcp_devops_safe_policy() -> MCPPolicy:
    """DevOps-safe MCP policy — block destructive infra operations."""
    return MCPPolicy.from_dict({
        "name": "mcp-devops-safe",
        "description": "Block destructive infrastructure operations, allow reads",
        "default_decision": "allow",
        "tool_rules": [
            {
                "tool_pattern": "delete_*|destroy_*|terminate_*|drop_*",
                "decision": "block",
                "risk": "critical",
                "reason": "Destructive operations are blocked",
            },
            {
                "tool_pattern": "deploy_*|rollback_*|scale_*",
                "decision": "require_approval",
                "risk": "high",
                "reason": "Deployment operations require approval",
            },
            {
                "tool_pattern": "create_*|update_*|modify_*",
                "decision": "require_approval",
                "risk": "medium",
                "reason": "Infrastructure mutations require approval",
            },
            {
                "server_pattern": "production*",
                "tool_pattern": "*",
                "decision": "require_approval",
                "risk": "high",
                "reason": "All production operations require approval",
            },
        ],
    })


# Preset registry (mirrors browser PRESET_POLICIES)
MCP_PRESET_POLICIES = {
    "mcp-default": create_mcp_default_policy,
    "mcp-readonly": create_mcp_readonly_policy,
    "mcp-finance-safe": create_mcp_finance_safe_policy,
    "mcp-devops-safe": create_mcp_devops_safe_policy,
}
