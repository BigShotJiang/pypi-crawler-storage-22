"""
AgentGate MCP Proxy — Security gateway for downstream MCP servers.

This is the core innovation. Instead of connecting your agent directly
to an MCP server (Stripe, GitHub, database, etc.), you route it through
AgentGate. Every tool call is intercepted, evaluated against policies,
recorded in the evidence vault, and then forwarded (or blocked).

Architecture:
    Agent  ──→  AgentGate MCP Proxy  ──→  Downstream MCP Server
                 │                          (Stripe, GitHub, etc.)
                 │ Policy check
                 │ Evidence recording
                 │ Risk classification
                 │ ALLOW / BLOCK

The proxy itself is an MCP server. It discovers tools from downstream
servers and re-exposes them — but with policy enforcement wrapped around
every call.

Usage:
    # In Python
    from agentgate.mcp.proxy import MCPProxyServer

    proxy = MCPProxyServer(
        mcp_policy="mcp-finance-safe",
        servers=[
            {"name": "stripe", "command": "npx", "args": ["-y", "@stripe/mcp"]},
            {"name": "github", "url": "http://localhost:8200/mcp"},
        ],
    )
    proxy.run(transport="stdio")

    # Via CLI
    agentgate mcp proxy --config mcp_servers.yaml --policy mcp-default
"""

from __future__ import annotations

import asyncio
import logging
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from agentgate.mcp.types import (
    MCPServerConfig,
    MCPToolCall,
    MCPToolCallDecision,
)
from agentgate.mcp.policy_engine import (
    MCPPolicyEngine,
    MCPPolicy,
    MCP_PRESET_POLICIES,
    classify_mcp_risk,
)

logger = logging.getLogger("agentgate.mcp.proxy")


# ---------------------------------------------------------------------------
# Downstream MCP client manager
# ---------------------------------------------------------------------------

class DownstreamServer:
    """Manages a connection to a single downstream MCP server.

    Connects via the MCP Python SDK's client, discovers tools, and
    forwards calls — with AgentGate policy checks in between.
    """

    def __init__(self, config: MCPServerConfig) -> None:
        self.config = config
        self.name = config.name
        self._tools: list[dict[str, Any]] = []
        self._session: Any = None
        self._read_stream: Any = None
        self._write_stream: Any = None
        self._connected = False

    async def connect(self) -> None:
        """Connect to the downstream MCP server and discover tools."""
        try:
            if self.config.transport == "stdio":
                from mcp.client.stdio import stdio_client, StdioServerParameters
                params = StdioServerParameters(
                    command=self.config.command,
                    args=self.config.args,
                    env=self.config.env or None,
                )
                # We store the context managers to keep the connection alive
                self._stdio_cm = stdio_client(params)
                streams = await self._stdio_cm.__aenter__()
                self._read_stream, self._write_stream = streams

            elif self.config.transport in ("sse", "streamable-http"):
                from mcp.client.streamable_http import streamablehttp_client
                self._http_cm = streamablehttp_client(self.config.url)
                streams = await self._http_cm.__aenter__()
                self._read_stream, self._write_stream = streams[0], streams[1]

            # Create client session
            from mcp.client.session import ClientSession
            self._session_cm = ClientSession(
                self._read_stream, self._write_stream
            )
            self._session = await self._session_cm.__aenter__()
            await self._session.initialize()

            # Discover tools
            tools_result = await self._session.list_tools()
            self._tools = []
            for tool in tools_result.tools:
                self._tools.append({
                    "name": tool.name,
                    "description": tool.description or "",
                    "input_schema": tool.inputSchema if hasattr(tool, 'inputSchema') else {},
                })

            self._connected = True
            logger.info(
                f"Connected to downstream MCP server '{self.name}': "
                f"{len(self._tools)} tools discovered"
            )

        except Exception as e:
            logger.error(f"Failed to connect to MCP server '{self.name}': {e}")
            self._connected = False

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        """Forward a tool call to the downstream MCP server."""
        if not self._connected or not self._session:
            raise RuntimeError(f"Not connected to MCP server '{self.name}'")

        result = await self._session.call_tool(tool_name, arguments)
        return result

    async def disconnect(self) -> None:
        """Disconnect from the downstream MCP server."""
        try:
            if hasattr(self, '_session_cm'):
                await self._session_cm.__aexit__(None, None, None)
            if hasattr(self, '_stdio_cm'):
                await self._stdio_cm.__aexit__(None, None, None)
            if hasattr(self, '_http_cm'):
                await self._http_cm.__aexit__(None, None, None)
        except Exception:
            pass
        self._connected = False

    @property
    def tools(self) -> list[dict[str, Any]]:
        return self._tools

    @property
    def is_connected(self) -> bool:
        return self._connected


# ---------------------------------------------------------------------------
# MCP Proxy Server
# ---------------------------------------------------------------------------

class MCPProxyServer:
    """MCP security gateway that proxies tool calls through AgentGate policies.

    This creates an MCP server that re-exposes tools from downstream
    servers, but wraps every call with:
        1. Policy evaluation (allow/block/require_approval)
        2. Risk classification (3-layer NLP pipeline)
        3. Evidence recording
        4. Rate limiting

    Usage:
        proxy = MCPProxyServer(
            mcp_policy="mcp-default",
            servers=[
                {"name": "stripe", "command": "npx", "args": ["-y", "@stripe/mcp"]},
            ],
        )
        proxy.run(transport="stdio")
    """

    def __init__(
        self,
        mcp_policy: str | MCPPolicy | None = None,
        policy_dir: str | Path | None = None,
        servers: list[dict[str, Any] | MCPServerConfig] | None = None,
    ) -> None:
        self._policy_engine = MCPPolicyEngine()
        self._downstream: dict[str, DownstreamServer] = {}
        self._server_configs: list[MCPServerConfig] = []
        self._mcp: FastMCP | None = None
        self._start_time = time.time()

        # Load MCP policies
        if isinstance(mcp_policy, MCPPolicy):
            self._policy_engine.load_policy(mcp_policy)
        elif isinstance(mcp_policy, str) and mcp_policy in MCP_PRESET_POLICIES:
            self._policy_engine.load_policy(MCP_PRESET_POLICIES[mcp_policy]())

        if policy_dir:
            pdir = Path(policy_dir)
            if pdir.is_dir():
                self._policy_engine.load_policies_from_dir(pdir)

        # Parse server configs
        if servers:
            for s in servers:
                if isinstance(s, MCPServerConfig):
                    self._server_configs.append(s)
                elif isinstance(s, dict):
                    self._server_configs.append(MCPServerConfig(**s))

    def _create_proxy_server(self) -> FastMCP:
        """Build the FastMCP server that proxies downstream tools."""
        mcp = FastMCP(
            "AgentGate Proxy",
            instructions=(
                "This is an AgentGate security proxy. All tool calls are "
                "evaluated against security policies before being forwarded "
                "to the downstream MCP server. If a tool call is blocked, "
                "the reason will be returned."
            ),
        )

        engine = self._policy_engine
        downstream = self._downstream

        # Register a proxy tool for each downstream tool
        for server_name, server in downstream.items():
            for tool_info in server.tools:
                original_name = tool_info["name"]
                # Prefix with server name to avoid collisions
                proxy_name = f"{server_name}__{original_name}"
                description = (
                    f"[via {server_name}] {tool_info.get('description', '')}\n\n"
                    f"⚠️ This tool call is governed by AgentGate policies."
                )

                # Create the proxy tool dynamically
                _create_proxy_tool(
                    mcp, engine, downstream,
                    server_name, original_name, proxy_name, description,
                )

        # Add proxy-specific management tools

        @mcp.tool()
        def agentgate_proxy_status() -> dict[str, Any]:
            """Check the status of the AgentGate MCP proxy.

            Returns:
                Dict with connected servers, total tools, and policy info.
            """
            from agentgate import __version__

            server_info = []
            total_tools = 0
            for name, srv in downstream.items():
                tool_count = len(srv.tools)
                total_tools += tool_count
                server_info.append({
                    "name": name,
                    "connected": srv.is_connected,
                    "tools_count": tool_count,
                    "transport": srv.config.transport,
                })

            return {
                "status": "ok",
                "version": __version__,
                "uptime_seconds": round(time.time() - self._start_time, 1),
                "servers": server_info,
                "total_tools_proxied": total_tools,
                "mcp_policies_loaded": len(engine._policies),
            }

        @mcp.tool()
        def agentgate_check_tool(
            server_name: str,
            tool_name: str,
            arguments: dict[str, Any] | None = None,
        ) -> dict[str, Any]:
            """Pre-check if a tool call would be allowed WITHOUT executing it.

            Use this to check permission before calling a proxied tool.

            Args:
                server_name: Name of the downstream MCP server.
                tool_name: Name of the tool to check.
                arguments: The arguments that would be passed.

            Returns:
                Dict with allowed (bool), decision, risk_level, and reason.
            """
            tool_call = MCPToolCall(
                server_name=server_name,
                tool_name=tool_name,
                arguments=arguments or {},
            )
            decision = engine.evaluate(tool_call)
            return {
                "allowed": decision.allowed,
                "decision": decision.decision,
                "risk_level": decision.risk_level,
                "reason": decision.reason,
                "policy_name": decision.policy_name,
            }

        self._mcp = mcp
        return mcp

    async def connect_all(self) -> None:
        """Connect to all configured downstream MCP servers."""
        for config in self._server_configs:
            if not config.enabled:
                continue
            server = DownstreamServer(config)
            try:
                await server.connect()
                self._downstream[config.name] = server
            except Exception as e:
                logger.error(f"Failed to connect to '{config.name}': {e}")

    async def disconnect_all(self) -> None:
        """Disconnect from all downstream MCP servers."""
        for server in self._downstream.values():
            await server.disconnect()
        self._downstream.clear()

    def run(
        self,
        transport: str = "stdio",
        host: str = "127.0.0.1",
        port: int = 8100,
    ) -> None:
        """Connect to downstream servers, build proxy, and run.

        Args:
            transport: "stdio", "sse", or "streamable-http"
            host: Host for HTTP transports.
            port: Port for HTTP transports.
        """
        async def _run() -> None:
            await self.connect_all()
            self._create_proxy_server()

        # Connect and build proxy
        asyncio.run(_run())

        if self._mcp is None:
            raise RuntimeError("Failed to create proxy server")

        # Run the MCP server
        if transport == "stdio":
            self._mcp.run(transport="stdio")
        elif transport == "sse":
            self._mcp.run(transport="sse", host=host, port=port)
        elif transport == "streamable-http":
            self._mcp.run(transport="streamable-http", host=host, port=port)
        else:
            raise ValueError(f"Unknown transport: {transport}")


def _create_proxy_tool(
    mcp: FastMCP,
    engine: MCPPolicyEngine,
    downstream: dict[str, DownstreamServer],
    server_name: str,
    original_name: str,
    proxy_name: str,
    description: str,
) -> None:
    """Register a single proxy tool on the FastMCP server.

    Each proxied tool:
    1. Evaluates the call against MCP policies
    2. If allowed → forwards to the downstream server
    3. If blocked → returns the block reason
    4. Records everything for evidence
    """

    @mcp.tool(name=proxy_name, description=description)
    async def proxy_tool(**kwargs: Any) -> Any:
        # Build the tool call model
        tool_call = MCPToolCall(
            server_name=server_name,
            tool_name=original_name,
            arguments=kwargs,
        )

        # Evaluate against policies
        decision = engine.evaluate(tool_call)

        if not decision.allowed:
            return {
                "error": "blocked_by_agentgate",
                "allowed": False,
                "decision": decision.decision,
                "risk_level": decision.risk_level,
                "reason": decision.reason,
                "policy_name": decision.policy_name,
                "server": server_name,
                "tool": original_name,
            }

        # Forward to downstream server
        server = downstream.get(server_name)
        if not server or not server.is_connected:
            return {
                "error": "server_not_connected",
                "reason": f"Downstream server '{server_name}' is not connected",
            }

        try:
            result = await server.call_tool(original_name, kwargs)
            # Extract content from MCP result
            if hasattr(result, 'content'):
                contents = []
                for block in result.content:
                    if hasattr(block, 'text'):
                        contents.append(block.text)
                    else:
                        contents.append(str(block))
                return "\n".join(contents) if contents else str(result)
            return str(result)

        except Exception as e:
            return {
                "error": "tool_call_failed",
                "reason": str(e),
                "server": server_name,
                "tool": original_name,
            }
