"""
AgentGate MCP Server — Exposes AgentGate as an MCP tool server.

This lets any MCP-compatible client (Claude, GPT, Cursor, etc.) call
AgentGate's firewall tools natively via the MCP protocol — no REST API
or SDK needed.

Tools exposed:
    - evaluate_action      Check if a browser action is allowed
    - evaluate_mcp_tool    Check if an MCP tool call is allowed
    - classify_risk        Classify the risk level of any text
    - list_policies        List all loaded policies
    - list_sessions        List evidence sessions
    - health               Health check

Transports:
    - stdio     (default)  — for Claude Desktop, Cursor, etc.
    - sse                  — Server-Sent Events over HTTP
    - streamable-http      — Recommended for production

Usage:
    # Run standalone
    agentgate mcp serve --transport stdio

    # Run as HTTP server
    agentgate mcp serve --transport streamable-http --port 8100

    # In Python
    from agentgate.mcp.server import create_agentgate_mcp_server
    server = create_agentgate_mcp_server(policy="finance-safe")
    server.run(transport="stdio")
"""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    Decision,
    Policy,
    PolicyDecision,
    PolicyEngine,
    RiskLevel,
    classify_risk,
    create_finance_safe_policy,
    create_readonly_policy,
    create_permissive_policy,
)
from agentgate.mcp.types import MCPToolCall, MCPToolCallDecision
from agentgate.mcp.policy_engine import (
    MCPPolicyEngine,
    MCPPolicy,
    classify_mcp_risk,
    MCP_PRESET_POLICIES,
)

# Browser policy presets
BROWSER_PRESET_POLICIES = {
    "finance-safe": create_finance_safe_policy,
    "readonly": create_readonly_policy,
    "permissive": create_permissive_policy,
}


def create_agentgate_mcp_server(
    policy: str | Policy | None = None,
    mcp_policy: str | MCPPolicy | None = None,
    policy_dir: str | Path | None = None,
) -> FastMCP:
    """Create an AgentGate MCP server with tools for action governance.

    This server exposes AgentGate's firewall capabilities as MCP tools
    that any AI agent can call.

    Args:
        policy: Browser policy preset name or Policy object.
        mcp_policy: MCP policy preset name or MCPPolicy object.
        policy_dir: Directory containing YAML policy files.

    Returns:
        A FastMCP server instance ready to run.
    """

    mcp = FastMCP(
        "AgentGate",
        instructions=(
            "AgentGate is an execution firewall for AI agents. "
            "Use these tools to check whether actions are allowed before "
            "performing them. Every action is evaluated against security "
            "policies and recorded in a tamper-evident evidence vault."
        ),
    )

    # --- Initialize engines ---
    browser_engine = PolicyEngine()
    mcp_engine = MCPPolicyEngine()
    start_time = time.time()

    # Load browser policies
    if isinstance(policy, Policy):
        browser_engine.load_policy(policy)
    elif isinstance(policy, str) and policy in BROWSER_PRESET_POLICIES:
        browser_engine.load_policy(BROWSER_PRESET_POLICIES[policy]())

    # Load MCP policies
    if isinstance(mcp_policy, MCPPolicy):
        mcp_engine.load_policy(mcp_policy)
    elif isinstance(mcp_policy, str) and mcp_policy in MCP_PRESET_POLICIES:
        mcp_engine.load_policy(MCP_PRESET_POLICIES[mcp_policy]())

    # Load from directory
    if policy_dir:
        pdir = Path(policy_dir)
        if pdir.is_dir():
            browser_engine.load_policies_from_dir(pdir)
            mcp_engine.load_policies_from_dir(pdir)

    # ------------------------------------------------------------------
    # Tool: evaluate_action (browser actions)
    # ------------------------------------------------------------------

    @mcp.tool()
    def evaluate_action(
        action_type: str,
        url: str = "",
        element_text: str = "",
        selector: str = "",
        value: str = "",
        agent_id: str = "",
    ) -> dict[str, Any]:
        """Check if a browser action is allowed by AgentGate policies.

        Call this BEFORE your agent performs any browser action (click, type,
        navigate, etc.). If the result says allowed=true, proceed. If
        allowed=false, do NOT perform the action.

        Args:
            action_type: The type of action — click, type, navigate, submit,
                download, upload, copy, scroll, hover, etc.
            url: The URL of the page where the action is happening.
            element_text: The visible text of the element being acted on
                (e.g. "Pay Now", "Delete Account").
            selector: CSS selector of the target element.
            value: The value being typed (for type actions).
            agent_id: Identifier for the agent making the request.

        Returns:
            Dict with allowed (bool), decision, risk_level, and reason.
        """
        try:
            at = ActionType(action_type)
        except ValueError:
            return {
                "allowed": False,
                "decision": "block",
                "risk_level": "critical",
                "reason": f"Unknown action_type: '{action_type}'. Valid: {[a.value for a in ActionType]}",
            }

        event = ActionEvent(
            action_type=at,
            url=url,
            element_text=element_text,
            selector=selector,
            value=value,
            agent_id=agent_id,
        )

        decision = browser_engine.evaluate(event)
        is_allowed = decision.decision in (Decision.ALLOW, Decision.LOG_ONLY)

        return {
            "allowed": is_allowed,
            "decision": decision.decision.value,
            "risk_level": decision.risk_level.value if isinstance(decision.risk_level, RiskLevel) else str(decision.risk_level),
            "reason": decision.reason,
            "policy_name": decision.policy_name,
            "matched_rule": decision.matched_rule,
            "fingerprint": event.fingerprint,
        }

    # ------------------------------------------------------------------
    # Tool: evaluate_mcp_tool (MCP tool calls)
    # ------------------------------------------------------------------

    @mcp.tool()
    def evaluate_mcp_tool(
        server_name: str,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        agent_id: str = "",
    ) -> dict[str, Any]:
        """Check if an MCP tool call is allowed by AgentGate policies.

        Call this BEFORE calling a tool on any MCP server. AgentGate will
        evaluate the tool call against loaded MCP policies and return
        whether it's allowed.

        Args:
            server_name: Name of the MCP server being called (e.g. "stripe",
                "github", "slack", "database").
            tool_name: Name of the tool being called (e.g. "create_payment",
                "delete_repo", "send_message").
            arguments: The arguments being passed to the tool.
            agent_id: Identifier for the agent making the request.

        Returns:
            Dict with allowed (bool), decision, risk_level, and reason.
        """
        tool_call = MCPToolCall(
            server_name=server_name,
            tool_name=tool_name,
            arguments=arguments or {},
            agent_id=agent_id,
        )

        decision = mcp_engine.evaluate(tool_call)

        return {
            "allowed": decision.allowed,
            "decision": decision.decision,
            "risk_level": decision.risk_level,
            "reason": decision.reason,
            "policy_name": decision.policy_name,
            "matched_rule": decision.matched_rule,
            "server_name": decision.server_name,
            "tool_name": decision.tool_name,
            "fingerprint": decision.tool_fingerprint,
        }

    # ------------------------------------------------------------------
    # Tool: classify_risk
    # ------------------------------------------------------------------

    @mcp.tool()
    def classify_text_risk(
        text: str,
        context: str = "browser",
    ) -> dict[str, str]:
        """Classify the risk level of any text using AgentGate's 3-layer NLP pipeline.

        Uses keywords → phonetic codes → NLP sentence embeddings to understand
        the INTENT of the text and assign a risk level.

        Args:
            text: The text to classify (e.g. "Pay Now", "Delete Account",
                "View Dashboard").
            context: Either "browser" or "mcp" — determines which risk
                classifier to use.

        Returns:
            Dict with risk_level (none/low/medium/high/critical).
        """
        if context == "mcp":
            tool_call = MCPToolCall(tool_name=text)
            risk = classify_mcp_risk(tool_call)
        else:
            event = ActionEvent(
                action_type=ActionType.CLICK,
                element_text=text,
            )
            risk_enum = classify_risk(event)
            risk = risk_enum.value if isinstance(risk_enum, RiskLevel) else str(risk_enum)

        return {"text": text, "risk_level": risk, "context": context}

    # ------------------------------------------------------------------
    # Tool: list_policies
    # ------------------------------------------------------------------

    @mcp.tool()
    def list_policies() -> dict[str, Any]:
        """List all loaded AgentGate policies (both browser and MCP).

        Returns:
            Dict with browser_policies and mcp_policies lists.
        """
        browser_policies = [
            {
                "name": p.name,
                "description": p.description,
                "rules_count": len(p.rules),
            }
            for p in browser_engine._policies
        ]

        mcp_policies = [
            {
                "name": p.name,
                "description": p.description,
                "tool_rules_count": len(p.tool_rules),
            }
            for p in mcp_engine._policies
        ]

        return {
            "browser_policies": browser_policies,
            "mcp_policies": mcp_policies,
            "total": len(browser_policies) + len(mcp_policies),
        }

    # ------------------------------------------------------------------
    # Tool: health
    # ------------------------------------------------------------------

    @mcp.tool()
    def health() -> dict[str, Any]:
        """Check AgentGate health and status.

        Returns:
            Dict with status, version, uptime, and loaded policy counts.
        """
        from agentgate import __version__

        return {
            "status": "ok",
            "version": __version__,
            "uptime_seconds": round(time.time() - start_time, 1),
            "browser_policies_loaded": len(browser_engine._policies),
            "mcp_policies_loaded": len(mcp_engine._policies),
            "transport": "mcp",
        }

    # ------------------------------------------------------------------
    # Resource: available presets
    # ------------------------------------------------------------------

    @mcp.resource("agentgate://presets")
    def get_presets() -> str:
        """Get all available AgentGate policy presets."""
        lines = ["# AgentGate Policy Presets\n"]
        lines.append("## Browser Policies")
        for name in BROWSER_PRESET_POLICIES:
            lines.append(f"- {name}")
        lines.append("\n## MCP Policies")
        for name in MCP_PRESET_POLICIES:
            lines.append(f"- {name}")
        return "\n".join(lines)

    @mcp.resource("agentgate://help")
    def get_help() -> str:
        """Get AgentGate usage guide for MCP integration."""
        return (
            "# AgentGate MCP Integration Guide\n\n"
            "AgentGate is an execution firewall for AI agents. It controls "
            "what agents can do and proves what they did.\n\n"
            "## Tools\n\n"
            "- **evaluate_action**: Check if a browser action (click, type, "
            "navigate) is allowed.\n"
            "- **evaluate_mcp_tool**: Check if an MCP tool call is allowed.\n"
            "- **classify_text_risk**: Classify the risk level of any text.\n"
            "- **list_policies**: List all loaded policies.\n"
            "- **health**: Check AgentGate status.\n\n"
            "## Usage Pattern\n\n"
            "1. Before performing any action, call evaluate_action or "
            "evaluate_mcp_tool.\n"
            "2. If allowed=true, proceed with the action.\n"
            "3. If allowed=false, inform the user and suggest alternatives.\n"
        )

    return mcp
