"""
AgentGate MCP Types — Data models for MCP tool-call interception.

These models mirror the existing ActionEvent/PolicyDecision pattern
from the browser policy engine, but adapted for MCP tool calls.

In browser world:   ActionEvent(action_type="click", element_text="Pay Now")
In MCP world:       MCPToolCall(server="stripe", tool="create_payment", args={...})
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field as dc_field
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# MCP-specific action types
# ---------------------------------------------------------------------------

class MCPActionType(str, Enum):
    """Action types specific to MCP interactions."""
    TOOL_CALL = "tool_call"           # Agent calls a tool on an MCP server
    RESOURCE_READ = "resource_read"   # Agent reads a resource
    RESOURCE_WRITE = "resource_write" # Agent writes/creates a resource
    PROMPT_USE = "prompt_use"         # Agent uses a prompt template


# ---------------------------------------------------------------------------
# Core MCP data models
# ---------------------------------------------------------------------------

class MCPToolCall(BaseModel):
    """Represents a single MCP tool call an agent is attempting.

    This is the MCP equivalent of ActionEvent. When an agent tries to
    call a tool on any MCP server, we capture it here for policy evaluation.
    """
    server_name: str = ""             # Name of the downstream MCP server (e.g. "stripe", "github")
    tool_name: str = ""               # Name of the tool being called (e.g. "create_payment")
    arguments: dict[str, Any] = Field(default_factory=dict)  # Tool arguments
    action_type: MCPActionType = MCPActionType.TOOL_CALL
    agent_id: str = ""
    session_id: str = ""
    timestamp: float = Field(default_factory=time.time)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def fingerprint(self) -> str:
        """Unique hash for this tool call."""
        raw = f"mcp:{self.server_name}:{self.tool_name}:{sorted(self.arguments.items())}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    @property
    def combined_text(self) -> str:
        """Combine server name, tool name, and argument values into searchable text.

        This is what the policy engine runs intent matching against — the same
        3-layer pipeline (keywords → phonetic → NLP semantic) that the browser
        engine uses for element_text.
        """
        parts = [self.server_name, self.tool_name]
        for key, value in self.arguments.items():
            parts.append(str(key))
            parts.append(str(value))
        return " ".join(parts)


class MCPToolCallDecision(BaseModel):
    """Result of evaluating an MCP tool call against policies.

    Mirrors PolicyDecision but includes MCP-specific fields.
    """
    allowed: bool
    decision: str  # allow, block, require_approval, log_only
    risk_level: str = "low"
    reason: str = ""
    policy_name: str = ""
    matched_rule: str = ""
    tool_fingerprint: str = ""
    record_id: str = ""
    server_name: str = ""
    tool_name: str = ""
    timestamp: float = Field(default_factory=time.time)


# ---------------------------------------------------------------------------
# MCP Server registration
# ---------------------------------------------------------------------------

class MCPServerConfig(BaseModel):
    """Configuration for a downstream MCP server that AgentGate proxies.

    When you register an MCP server with AgentGate, this defines
    how to connect to it and what policies to apply.
    """
    name: str                         # Logical name (e.g. "stripe", "github")
    command: str = ""                 # Command to spawn stdio server
    args: list[str] = Field(default_factory=list)  # Command arguments
    env: dict[str, str] = Field(default_factory=dict)  # Environment variables
    url: str = ""                     # URL for HTTP/SSE transport
    transport: str = "stdio"          # "stdio", "sse", or "streamable-http"
    policy: str = ""                  # Policy name or path to apply
    description: str = ""
    enabled: bool = True


# ---------------------------------------------------------------------------
# MCP policy rule models
# ---------------------------------------------------------------------------

class MCPToolRule(BaseModel):
    """A rule that matches MCP tool calls — the MCP equivalent of ElementRule.

    Examples:
        # Block a specific tool
        MCPToolRule(tool_pattern="create_payment", decision="block")

        # Block tools on a specific server
        MCPToolRule(server_pattern="stripe", tool_pattern="*", decision="block")

        # Block based on argument content
        MCPToolRule(tool_pattern="send_email",
                    arg_patterns={"to": ".*@competitor\\.com"},
                    decision="block")

        # Block by intent (uses the same NLP pipeline as browser engine)
        MCPToolRule(intent="payment", decision="block")
    """
    server_pattern: str = "*"         # Glob pattern for server name
    tool_pattern: str = "*"           # Glob pattern for tool name
    arg_patterns: dict[str, str] = Field(default_factory=dict)  # Regex on argument values
    arg_block_values: dict[str, list[str]] = Field(default_factory=dict)  # Blocked argument values
    intent: str = ""                  # Use NLP intent matching (e.g. "payment", "delete")
    risk: str = "none"                # Risk override: none, low, medium, high, critical
    decision: str = "block"           # allow, block, require_approval
    reason: str = ""                  # Human-readable reason for the rule


class MCPPolicy(BaseModel):
    """A complete policy for MCP tool-call governance.

    This is loaded from YAML alongside browser policies. It defines
    what MCP tools an agent can and cannot call.

    Example YAML:
        name: mcp-finance-safe
        description: Block payment and deletion tools across all MCP servers
        default_decision: allow
        tool_rules:
          - tool_pattern: "create_payment|charge_*|transfer_*"
            decision: block
            reason: Payment tools are restricted
          - intent: delete
            decision: block
          - server_pattern: "production-db"
            tool_pattern: "*"
            decision: require_approval
            reason: All production database operations need approval
        blocked_servers:
          - "dangerous-server"
        max_calls_per_minute: 30
    """
    name: str
    description: str = ""
    version: str = "1.0"
    enabled: bool = True
    default_decision: str = "allow"   # allow, block, require_approval
    tool_rules: list[MCPToolRule] = Field(default_factory=list)
    blocked_servers: list[str] = Field(default_factory=list)
    allowed_servers: list[str] = Field(default_factory=list)  # Allowlist (empty = all allowed)
    blocked_tools: list[str] = Field(default_factory=list)    # Quick blocklist
    allowed_tools: list[str] = Field(default_factory=list)    # Quick allowlist
    max_calls_per_minute: int = 0     # 0 = unlimited
    max_arg_length: int = 0           # 0 = unlimited, max chars per argument value

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MCPPolicy:
        """Parse an MCP policy from a dictionary (e.g. loaded from YAML)."""
        tool_rules = []
        for rule_data in data.get("tool_rules", []):
            tool_rules.append(MCPToolRule(
                server_pattern=rule_data.get("server_pattern", "*"),
                tool_pattern=rule_data.get("tool_pattern", "*"),
                arg_patterns=rule_data.get("arg_patterns", {}),
                arg_block_values=rule_data.get("arg_block_values", {}),
                intent=rule_data.get("intent", ""),
                risk=rule_data.get("risk", "none"),
                decision=rule_data.get("decision", "block"),
                reason=rule_data.get("reason", ""),
            ))

        return cls(
            name=data.get("name", "unnamed-mcp-policy"),
            description=data.get("description", ""),
            version=data.get("version", "1.0"),
            enabled=data.get("enabled", True),
            default_decision=data.get("default_decision", "allow"),
            tool_rules=tool_rules,
            blocked_servers=data.get("blocked_servers", []),
            allowed_servers=data.get("allowed_servers", []),
            blocked_tools=data.get("blocked_tools", []),
            allowed_tools=data.get("allowed_tools", []),
            max_calls_per_minute=data.get("max_calls_per_minute", 0),
            max_arg_length=data.get("max_arg_length", 0),
        )
