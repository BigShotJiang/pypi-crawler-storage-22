"""
AgentGate Multi-Agent Session Manager — Coordinated governance for agent swarms.

When multiple agents collaborate (CrewAI teams, LangGraph multi-agent,
AutoGen groups, etc.), each agent needs its own session, but the
orchestrator needs a unified view of what ALL agents did.

Features:
    - Create/manage sessions for multiple agents under one orchestration
    - Cross-agent policy enforcement (e.g. collective rate limits)
    - Shared state: one agent's actions affect another's permissions
    - Unified evidence trail across all agents
    - Session lifecycle management (pause, resume, transfer)
    - Agent role-based policy assignment
    - Coordination locks (only one agent acts at a time)

Usage:
    from agentgate.sessions import MultiAgentSessionManager, AgentRole

    manager = MultiAgentSessionManager(evidence_dir="./evidence")

    # Register agents with roles
    manager.register_agent("researcher", role=AgentRole.READER)
    manager.register_agent("writer", role=AgentRole.WRITER)
    manager.register_agent("admin", role=AgentRole.ADMIN)

    # Start orchestrated session
    session = await manager.start_orchestration("crewai-task-123")

    # Evaluate with cross-agent awareness
    decision = await manager.evaluate("writer", action_event)
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field as dc_field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from pydantic import BaseModel, Field

from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    Decision,
    Policy,
    PolicyDecision,
    PolicyEngine,
    RiskLevel,
    classify_risk,
)
from agentgate.evidence.vault import (
    EvidenceVault,
    EvidenceSession,
    EvidenceRecord,
    SessionSummary,
)

logger = logging.getLogger("agentgate.sessions")


# ---------------------------------------------------------------------------
# Agent roles and status
# ---------------------------------------------------------------------------

class AgentRole(str, Enum):
    """Pre-defined roles for multi-agent systems."""
    READER = "reader"          # Can only read/observe
    WRITER = "writer"          # Can read + write/modify
    ADMIN = "admin"            # Full access
    EXECUTOR = "executor"      # Can execute actions but not configure
    OBSERVER = "observer"      # Can only observe, no actions
    CUSTOM = "custom"          # Custom role — uses agent-specific policy


class AgentStatus(str, Enum):
    """Lifecycle status of an agent in the session."""
    REGISTERED = "registered"      # Agent registered but not started
    ACTIVE = "active"              # Agent is actively working
    PAUSED = "paused"              # Agent temporarily paused
    COMPLETED = "completed"        # Agent finished its work
    TERMINATED = "terminated"      # Agent was force-terminated
    ERROR = "error"                # Agent encountered an error


class OrchestrationStatus(str, Enum):
    """Status of the overall multi-agent orchestration."""
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


# ---------------------------------------------------------------------------
# Agent registration model
# ---------------------------------------------------------------------------

class AgentRegistration(BaseModel):
    """Registration info for a single agent in a multi-agent session."""
    agent_id: str
    role: AgentRole = AgentRole.WRITER
    display_name: str = ""
    status: AgentStatus = AgentStatus.REGISTERED
    policy_name: str = ""              # Agent-specific policy override
    max_actions_per_minute: int = 0    # 0 = use orchestration default
    allowed_action_types: list[str] = Field(default_factory=list)  # Empty = all
    blocked_action_types: list[str] = Field(default_factory=list)

    # Runtime state
    actions_taken: int = 0
    actions_blocked: int = 0
    actions_allowed: int = 0
    highest_risk_seen: str = "none"
    last_action_time: float = 0.0
    registered_at: float = Field(default_factory=time.time)
    session_id: str = ""               # Evidence session for this agent
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Orchestration session
# ---------------------------------------------------------------------------

class OrchestrationSession(BaseModel):
    """A multi-agent orchestration session.

    This groups multiple agent sessions under a single orchestration,
    providing a unified view of all agent activity.
    """
    orchestration_id: str
    name: str = ""
    status: OrchestrationStatus = OrchestrationStatus.INITIALIZING
    agents: dict[str, AgentRegistration] = Field(default_factory=dict)
    start_time: float = Field(default_factory=time.time)
    end_time: float = 0.0

    # Cross-agent settings
    max_total_actions: int = 0         # 0 = unlimited
    max_concurrent_agents: int = 0     # 0 = unlimited
    collective_rate_limit: int = 0     # Total calls/min across all agents
    require_sequential: bool = False   # Force sequential execution

    # Runtime state
    total_actions: int = 0
    total_allowed: int = 0
    total_blocked: int = 0
    _action_timestamps: list[float] = []  # For collective rate limiting

    model_config = {"arbitrary_types_allowed": True}


class OrchestrationSummary(BaseModel):
    """Summary of a completed multi-agent orchestration."""
    orchestration_id: str
    name: str = ""
    start_time: float = 0.0
    end_time: float = 0.0
    duration_seconds: float = 0.0
    status: str = ""
    total_agents: int = 0
    total_actions: int = 0
    total_allowed: int = 0
    total_blocked: int = 0
    agents: list[dict[str, Any]] = Field(default_factory=list)
    highest_risk: str = "none"
    all_chains_valid: bool = True


# ---------------------------------------------------------------------------
# Role-based policy defaults
# ---------------------------------------------------------------------------

ROLE_POLICY_DEFAULTS: dict[AgentRole, dict[str, Any]] = {
    AgentRole.READER: {
        "allowed_action_types": ["navigate", "scroll", "hover", "screenshot"],
        "blocked_action_types": ["click", "type", "submit", "download", "upload",
                                  "evaluate_js", "copy", "drag"],
        "max_actions_per_minute": 60,
    },
    AgentRole.WRITER: {
        "allowed_action_types": [],  # All allowed
        "blocked_action_types": ["evaluate_js"],
        "max_actions_per_minute": 30,
    },
    AgentRole.ADMIN: {
        "allowed_action_types": [],  # All allowed
        "blocked_action_types": [],
        "max_actions_per_minute": 0,  # Unlimited
    },
    AgentRole.EXECUTOR: {
        "allowed_action_types": ["click", "type", "submit", "navigate", "select",
                                  "scroll"],
        "blocked_action_types": ["evaluate_js", "download", "upload"],
        "max_actions_per_minute": 45,
    },
    AgentRole.OBSERVER: {
        "allowed_action_types": ["screenshot", "scroll"],
        "blocked_action_types": ["click", "type", "submit", "navigate",
                                  "download", "upload", "evaluate_js",
                                  "copy", "drag", "select", "hover", "key_press"],
        "max_actions_per_minute": 30,
    },
    AgentRole.CUSTOM: {
        "allowed_action_types": [],
        "blocked_action_types": [],
        "max_actions_per_minute": 0,
    },
}


# ---------------------------------------------------------------------------
# Multi-Agent Session Manager
# ---------------------------------------------------------------------------

class MultiAgentSessionManager:
    """Manages coordinated sessions for multiple AI agents.

    This is the central orchestrator for multi-agent governance.
    It provides:
    - Agent registration with role-based permissions
    - Cross-agent policy enforcement
    - Unified evidence trail
    - Session lifecycle management
    - Collective rate limiting

    Usage:
        manager = MultiAgentSessionManager(evidence_dir="./evidence")
        manager.register_agent("agent-1", role=AgentRole.WRITER)
        manager.register_agent("agent-2", role=AgentRole.READER)

        orch = await manager.start_orchestration("task-123")

        # Evaluate actions with multi-agent awareness
        decision = await manager.evaluate("agent-1", action_event)
    """

    def __init__(
        self,
        evidence_dir: str | Path = "./agentgate_evidence",
        policy_engine: PolicyEngine | None = None,
        default_policy: str | Policy | None = None,
    ) -> None:
        self._vault = EvidenceVault(evidence_dir)
        self._engine = policy_engine or PolicyEngine()
        self._orchestrations: dict[str, OrchestrationSession] = {}
        self._agents: dict[str, AgentRegistration] = {}
        self._agent_sessions: dict[str, EvidenceSession] = {}
        self._agent_to_orchestration: dict[str, str] = {}  # agent_id -> orch_id
        self._agent_action_timestamps: dict[str, list[float]] = {}
        self._coordination_lock = asyncio.Lock()
        self._active_agent: str | None = None  # For sequential mode

        # Load default policy
        if default_policy:
            if isinstance(default_policy, Policy):
                self._engine.load_policy(default_policy)
            elif isinstance(default_policy, str):
                from agentgate.runner import PRESET_POLICIES
                if default_policy in PRESET_POLICIES:
                    self._engine.load_policy(PRESET_POLICIES[default_policy]())

    @property
    def vault(self) -> EvidenceVault:
        return self._vault

    @property
    def engine(self) -> PolicyEngine:
        return self._engine

    # ------------------------------------------------------------------
    # Agent Registration
    # ------------------------------------------------------------------

    def register_agent(
        self,
        agent_id: str,
        role: AgentRole = AgentRole.WRITER,
        display_name: str = "",
        policy_name: str = "",
        max_actions_per_minute: int = 0,
        allowed_action_types: list[str] | None = None,
        blocked_action_types: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AgentRegistration:
        """Register an agent for multi-agent session management.

        If allowed/blocked action types are not specified, they default
        to the role's defaults.
        """
        if agent_id in self._agents:
            raise ValueError(f"Agent '{agent_id}' is already registered")

        # Apply role defaults if not overridden
        role_defaults = ROLE_POLICY_DEFAULTS.get(role, {})
        if allowed_action_types is None:
            allowed_action_types = role_defaults.get("allowed_action_types", [])
        if blocked_action_types is None:
            blocked_action_types = role_defaults.get("blocked_action_types", [])
        if max_actions_per_minute == 0:
            max_actions_per_minute = role_defaults.get("max_actions_per_minute", 0)

        registration = AgentRegistration(
            agent_id=agent_id,
            role=role,
            display_name=display_name or agent_id,
            policy_name=policy_name,
            max_actions_per_minute=max_actions_per_minute,
            allowed_action_types=allowed_action_types,
            blocked_action_types=blocked_action_types,
            metadata=metadata or {},
        )

        self._agents[agent_id] = registration
        self._agent_action_timestamps[agent_id] = []
        logger.info(f"Registered agent '{agent_id}' with role '{role.value}'")
        return registration

    def unregister_agent(self, agent_id: str) -> bool:
        """Unregister an agent. Returns True if found and removed."""
        if agent_id not in self._agents:
            return False
        reg = self._agents.pop(agent_id)
        reg.status = AgentStatus.TERMINATED
        self._agent_action_timestamps.pop(agent_id, None)
        self._agent_to_orchestration.pop(agent_id, None)
        logger.info(f"Unregistered agent '{agent_id}'")
        return True

    def get_agent(self, agent_id: str) -> AgentRegistration | None:
        """Get an agent's registration info."""
        return self._agents.get(agent_id)

    def list_agents(self) -> list[AgentRegistration]:
        """List all registered agents."""
        return list(self._agents.values())

    def update_agent_status(self, agent_id: str, status: AgentStatus) -> None:
        """Update an agent's lifecycle status."""
        if agent_id not in self._agents:
            raise ValueError(f"Agent '{agent_id}' not registered")
        self._agents[agent_id].status = status
        logger.info(f"Agent '{agent_id}' status → {status.value}")

    # ------------------------------------------------------------------
    # Orchestration Lifecycle
    # ------------------------------------------------------------------

    async def start_orchestration(
        self,
        name: str = "",
        orchestration_id: str | None = None,
        max_total_actions: int = 0,
        max_concurrent_agents: int = 0,
        collective_rate_limit: int = 0,
        require_sequential: bool = False,
    ) -> OrchestrationSession:
        """Start a new multi-agent orchestration session.

        This creates evidence sessions for all registered agents and
        groups them under a single orchestration.
        """
        orch_id = orchestration_id or f"orch_{uuid.uuid4().hex[:16]}"

        orch = OrchestrationSession(
            orchestration_id=orch_id,
            name=name or orch_id,
            status=OrchestrationStatus.RUNNING,
            max_total_actions=max_total_actions,
            max_concurrent_agents=max_concurrent_agents,
            collective_rate_limit=collective_rate_limit,
            require_sequential=require_sequential,
        )

        # Create evidence sessions for all registered agents
        for agent_id, reg in self._agents.items():
            session = await self._vault.start_session(agent_id=agent_id)
            self._agent_sessions[agent_id] = session
            reg.session_id = session.session_id
            reg.status = AgentStatus.ACTIVE
            orch.agents[agent_id] = reg
            self._agent_to_orchestration[agent_id] = orch_id

        self._orchestrations[orch_id] = orch
        logger.info(
            f"Started orchestration '{orch_id}' with {len(orch.agents)} agents"
        )
        return orch

    async def end_orchestration(self, orchestration_id: str) -> OrchestrationSummary:
        """End a multi-agent orchestration and generate a unified summary."""
        orch = self._orchestrations.get(orchestration_id)
        if not orch:
            raise ValueError(f"Orchestration '{orchestration_id}' not found")

        orch.end_time = time.time()
        orch.status = OrchestrationStatus.COMPLETED

        # End all agent sessions
        agent_summaries = []
        all_chains_valid = True
        highest_risk = "none"
        risk_order = {"none": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}

        for agent_id, reg in orch.agents.items():
            session = self._agent_sessions.get(agent_id)
            if session and not session._ended:
                summary = await session.end()
                agent_summaries.append({
                    "agent_id": agent_id,
                    "role": reg.role.value,
                    "display_name": reg.display_name,
                    "status": reg.status.value,
                    "actions_taken": reg.actions_taken,
                    "actions_allowed": reg.actions_allowed,
                    "actions_blocked": reg.actions_blocked,
                    "highest_risk": reg.highest_risk_seen,
                    "session_id": reg.session_id,
                    "chain_valid": summary.chain_valid,
                })
                if not summary.chain_valid:
                    all_chains_valid = False
                if risk_order.get(reg.highest_risk_seen, 0) > risk_order.get(highest_risk, 0):
                    highest_risk = reg.highest_risk_seen
            else:
                agent_summaries.append({
                    "agent_id": agent_id,
                    "role": reg.role.value,
                    "status": reg.status.value,
                    "actions_taken": reg.actions_taken,
                })

            reg.status = AgentStatus.COMPLETED

        summary = OrchestrationSummary(
            orchestration_id=orchestration_id,
            name=orch.name,
            start_time=orch.start_time,
            end_time=orch.end_time,
            duration_seconds=round(orch.end_time - orch.start_time, 2),
            status=orch.status.value,
            total_agents=len(orch.agents),
            total_actions=orch.total_actions,
            total_allowed=orch.total_allowed,
            total_blocked=orch.total_blocked,
            agents=agent_summaries,
            highest_risk=highest_risk,
            all_chains_valid=all_chains_valid,
        )

        logger.info(
            f"Ended orchestration '{orchestration_id}': "
            f"{orch.total_actions} actions, {orch.total_blocked} blocked"
        )
        return summary

    def get_orchestration(self, orchestration_id: str) -> OrchestrationSession | None:
        """Get an orchestration session by ID."""
        return self._orchestrations.get(orchestration_id)

    def list_orchestrations(self) -> list[OrchestrationSession]:
        """List all orchestration sessions."""
        return list(self._orchestrations.values())

    # ------------------------------------------------------------------
    # Action Evaluation — Cross-Agent Aware
    # ------------------------------------------------------------------

    async def evaluate(
        self, agent_id: str, event: ActionEvent
    ) -> PolicyDecision:
        """Evaluate an action with cross-agent awareness.

        This runs the full pipeline:
        1. Check agent registration and status
        2. Check role-based action type restrictions
        3. Check per-agent rate limits
        4. Check collective rate limits
        5. Check max-total-actions limit
        6. Check sequential execution constraint
        7. Run policy engine evaluation
        8. Record in evidence vault
        """
        reg = self._agents.get(agent_id)
        if not reg:
            return PolicyDecision(
                decision=Decision.BLOCK,
                risk_level=RiskLevel.HIGH,
                reason=f"Agent '{agent_id}' is not registered",
                matched_rule="unregistered_agent",
            )

        if reg.status not in (AgentStatus.ACTIVE, AgentStatus.REGISTERED):
            return PolicyDecision(
                decision=Decision.BLOCK,
                risk_level=RiskLevel.MEDIUM,
                reason=f"Agent '{agent_id}' is {reg.status.value} — cannot take actions",
                matched_rule="agent_status",
            )

        action_type_str = event.action_type.value

        # Check role-based action type restrictions
        if reg.blocked_action_types and action_type_str in reg.blocked_action_types:
            decision = PolicyDecision(
                decision=Decision.BLOCK,
                risk_level=RiskLevel.MEDIUM,
                reason=f"Action type '{action_type_str}' is blocked for role '{reg.role.value}'",
                matched_rule=f"role_block:{reg.role.value}",
                policy_name="multi-agent-roles",
                action_fingerprint=event.fingerprint,
            )
            reg.actions_taken += 1
            reg.actions_blocked += 1
            await self._record_decision(agent_id, event, decision)
            return decision

        if reg.allowed_action_types and action_type_str not in reg.allowed_action_types:
            decision = PolicyDecision(
                decision=Decision.BLOCK,
                risk_level=RiskLevel.MEDIUM,
                reason=f"Action type '{action_type_str}' not in allowed types for role '{reg.role.value}'",
                matched_rule=f"role_allowlist:{reg.role.value}",
                policy_name="multi-agent-roles",
                action_fingerprint=event.fingerprint,
            )
            reg.actions_taken += 1
            reg.actions_blocked += 1
            await self._record_decision(agent_id, event, decision)
            return decision

        # Check per-agent rate limit
        if reg.max_actions_per_minute > 0:
            if self._check_agent_rate_limit(agent_id, reg.max_actions_per_minute):
                decision = PolicyDecision(
                    decision=Decision.BLOCK,
                    risk_level=RiskLevel.HIGH,
                    reason=f"Agent '{agent_id}' rate limit exceeded ({reg.max_actions_per_minute}/min)",
                    matched_rule="agent_rate_limit",
                    policy_name="multi-agent-rate",
                    action_fingerprint=event.fingerprint,
                )
                reg.actions_taken += 1
                reg.actions_blocked += 1
                await self._record_decision(agent_id, event, decision)
                return decision

        # Check cross-agent limits
        orch_id = self._agent_to_orchestration.get(agent_id)
        if orch_id:
            orch = self._orchestrations.get(orch_id)
            if orch:
                # Collective rate limit
                if orch.collective_rate_limit > 0:
                    now = time.time()
                    orch._action_timestamps = [
                        ts for ts in orch._action_timestamps if now - ts < 60
                    ]
                    if len(orch._action_timestamps) >= orch.collective_rate_limit:
                        decision = PolicyDecision(
                            decision=Decision.BLOCK,
                            risk_level=RiskLevel.HIGH,
                            reason=f"Collective rate limit exceeded ({orch.collective_rate_limit}/min)",
                            matched_rule="collective_rate_limit",
                            policy_name="multi-agent-collective",
                            action_fingerprint=event.fingerprint,
                        )
                        reg.actions_taken += 1
                        reg.actions_blocked += 1
                        await self._record_decision(agent_id, event, decision)
                        return decision
                    orch._action_timestamps.append(now)

                # Max total actions
                if orch.max_total_actions > 0 and orch.total_actions >= orch.max_total_actions:
                    decision = PolicyDecision(
                        decision=Decision.BLOCK,
                        risk_level=RiskLevel.HIGH,
                        reason=f"Max total actions ({orch.max_total_actions}) reached across all agents",
                        matched_rule="max_total_actions",
                        policy_name="multi-agent-limits",
                        action_fingerprint=event.fingerprint,
                    )
                    reg.actions_taken += 1
                    reg.actions_blocked += 1
                    await self._record_decision(agent_id, event, decision)
                    return decision

                # Sequential execution check
                if orch.require_sequential:
                    if self._active_agent and self._active_agent != agent_id:
                        decision = PolicyDecision(
                            decision=Decision.BLOCK,
                            risk_level=RiskLevel.MEDIUM,
                            reason=f"Sequential mode: agent '{self._active_agent}' is currently active",
                            matched_rule="sequential_lock",
                            policy_name="multi-agent-sequential",
                            action_fingerprint=event.fingerprint,
                        )
                        reg.actions_taken += 1
                        reg.actions_blocked += 1
                        await self._record_decision(agent_id, event, decision)
                        return decision
                    self._active_agent = agent_id

        # Enrich event with agent context
        event.agent_id = agent_id
        if reg.session_id:
            event.session_id = reg.session_id

        # Run the policy engine
        decision = self._engine.evaluate(event)

        # Update agent stats
        reg.actions_taken += 1
        reg.last_action_time = time.time()
        is_allowed = decision.decision in (Decision.ALLOW, Decision.LOG_ONLY)
        if is_allowed:
            reg.actions_allowed += 1
        else:
            reg.actions_blocked += 1

        # Update risk tracking
        risk_order = {"none": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
        current_risk = decision.risk_level.value if isinstance(decision.risk_level, RiskLevel) else str(decision.risk_level)
        if risk_order.get(current_risk, 0) > risk_order.get(reg.highest_risk_seen, 0):
            reg.highest_risk_seen = current_risk

        # Update orchestration stats
        if orch_id:
            orch = self._orchestrations.get(orch_id)
            if orch:
                orch.total_actions += 1
                if is_allowed:
                    orch.total_allowed += 1
                else:
                    orch.total_blocked += 1

        # Record in evidence vault
        await self._record_decision(agent_id, event, decision)

        return decision

    async def _record_decision(
        self, agent_id: str, event: ActionEvent, decision: PolicyDecision
    ) -> None:
        """Record an action+decision in the agent's evidence session."""
        session = self._agent_sessions.get(agent_id)
        if session and not session._ended:
            await session.record(event, decision)

    def _check_agent_rate_limit(self, agent_id: str, max_per_minute: int) -> bool:
        """Check per-agent rate limit."""
        now = time.time()
        timestamps = self._agent_action_timestamps.get(agent_id, [])
        timestamps = [ts for ts in timestamps if now - ts < 60]
        timestamps.append(now)
        self._agent_action_timestamps[agent_id] = timestamps
        return len(timestamps) > max_per_minute

    # ------------------------------------------------------------------
    # Agent coordination helpers
    # ------------------------------------------------------------------

    def release_sequential_lock(self, agent_id: str) -> None:
        """Release the sequential execution lock (call when agent is done)."""
        if self._active_agent == agent_id:
            self._active_agent = None

    def pause_agent(self, agent_id: str) -> None:
        """Pause an agent — blocks all further actions until resumed."""
        self.update_agent_status(agent_id, AgentStatus.PAUSED)

    def resume_agent(self, agent_id: str) -> None:
        """Resume a paused agent."""
        if agent_id in self._agents and self._agents[agent_id].status == AgentStatus.PAUSED:
            self.update_agent_status(agent_id, AgentStatus.ACTIVE)

    def transfer_active(self, from_agent: str, to_agent: str) -> None:
        """Transfer sequential execution lock from one agent to another."""
        if self._active_agent == from_agent:
            self._active_agent = to_agent
            logger.info(f"Transferred active lock: {from_agent} → {to_agent}")

    # ------------------------------------------------------------------
    # Cross-agent queries
    # ------------------------------------------------------------------

    def get_orchestration_stats(self, orchestration_id: str) -> dict[str, Any]:
        """Get real-time stats for an orchestration."""
        orch = self._orchestrations.get(orchestration_id)
        if not orch:
            return {}

        active_agents = sum(1 for a in orch.agents.values() if a.status == AgentStatus.ACTIVE)
        return {
            "orchestration_id": orchestration_id,
            "name": orch.name,
            "status": orch.status.value,
            "total_agents": len(orch.agents),
            "active_agents": active_agents,
            "total_actions": orch.total_actions,
            "total_allowed": orch.total_allowed,
            "total_blocked": orch.total_blocked,
            "duration_seconds": round(time.time() - orch.start_time, 1),
            "agents": {
                aid: {
                    "role": a.role.value,
                    "status": a.status.value,
                    "actions": a.actions_taken,
                    "blocked": a.actions_blocked,
                    "highest_risk": a.highest_risk_seen,
                }
                for aid, a in orch.agents.items()
            },
        }

    def get_agent_stats(self, agent_id: str) -> dict[str, Any]:
        """Get stats for a specific agent."""
        reg = self._agents.get(agent_id)
        if not reg:
            return {}
        return {
            "agent_id": agent_id,
            "role": reg.role.value,
            "display_name": reg.display_name,
            "status": reg.status.value,
            "actions_taken": reg.actions_taken,
            "actions_allowed": reg.actions_allowed,
            "actions_blocked": reg.actions_blocked,
            "highest_risk": reg.highest_risk_seen,
            "last_action_time": reg.last_action_time,
            "session_id": reg.session_id,
        }
