# 🛡️ AgentGate — A Plain-English Guide

> **For anyone who uses AI assistants — not just developers.**  
> If you use OpenClaw, ChatGPT, or any AI that can browse the web for you, this is for you.

---

## What Is AgentGate?

Think of AgentGate as a **security guard for your AI assistant**.

When you tell an AI like OpenClaw "Go check my bank balance," that AI has to click around on websites just like you would. But what if it accidentally (or due to a bug) clicks **"Transfer $10,000"** instead of **"View Balance"**?

**AgentGate prevents that.** It watches every single thing your AI does in the browser and blocks anything dangerous — before it happens.

---

## Real-World Analogy

Imagine you hire a personal assistant to handle your mail:

| Without AgentGate | With AgentGate |
|---|---|
| You hand them your mailbox key and hope for the best | You give them access but with a rule: **"You can READ any mail but you may NEVER sign or send anything"** |
| No record of what they did | You get a tamper-proof log of every letter they opened |
| They have full access forever | Their access expires in 1 hour and is limited to your personal mailbox |

That's exactly what AgentGate does for your AI assistant's browser access.

---

## The Three Layers of Protection

### 🧱 Layer 1: The Action Firewall (Policies)

**What it is:** A set of rules (in plain English YAML files) that say what the AI can and can't do.

**Example rules:**
- ✅ "You MAY navigate to bank.com"
- ✅ "You MAY click on 'View Invoice'"
- 🚫 "You may NOT click on anything that says 'Pay', 'Transfer', or 'Delete'"
- ⚠️ "If you want to click 'Submit', ask me first"

**How it looks in practice:**

```
Your AI tries to click "Pay Now" on a banking website.
     ↓
AgentGate checks the policy...
     ↓
🚫 BLOCKED — "Payment actions are not allowed"
     ↓
Your AI gets the message and tells you:
"I wanted to click Pay Now but I'm not allowed to. Want to do it yourself?"
```

### 📋 Layer 2: The Evidence Vault (Audit Trail)

**What it is:** A tamper-proof record of everything your AI did.

Think of it like a black-box flight recorder — but for your AI's browser session. Every click, every page visit, every form entry is recorded with:
- What happened (clicked a button, typed text, visited a page)
- When it happened
- Whether it was allowed or blocked
- A screenshot hash (proof of what was on screen)

**Why this matters:**
- Your company's compliance team can verify what the AI did
- If something goes wrong, you have proof of every step
- The records are cryptographically chained — nobody can edit or delete entries

### 🔑 Layer 3: Capability Tokens (Scoped Permissions)

**What it is:** A temporary, limited-access pass for your AI.

Instead of giving your AI blanket access to everything, you give it a **token** that says:
- "You can access bank.com for the next 30 minutes"
- "You can view up to 50 pages"
- "You cannot touch anything with the word 'Pay' or 'Delete'"

When the 30 minutes are up, the token expires automatically. No cleanup needed.

### 🤖 Layer 4: Multi-Agent Coordination

**What it is:** A traffic controller for when multiple AI agents work together.

Imagine you have a **team** of AI assistants:
- One researcher reads articles and finds information
- One writer drafts responses
- One admin manages your calendar

Without coordination, they might step on each other's toes. **Multi-Agent Session Management** gives each agent:

| Feature | What It Does |
|---|---|
| **Roles** | The researcher can only READ, the writer can READ + WRITE, the admin can do everything |
| **Rate Limits** | Each agent has its own speed limit, PLUS a combined limit for the whole team |
| **Sequential Mode** | Only one agent acts at a time — like a talking stick |
| **Unified Trail** | One combined record of what ALL agents did |

**Real-world analogy:** It's like a construction site where the electrician, plumber, and carpenter each have their own badge showing what areas they can access and what tools they can use.

### 💓 Layer 5: Health Monitoring (Heartbeat)

**What it is:** A continuous pulse check to make sure AgentGate is still alive and working.

Just like a heart monitor in a hospital, the Heartbeat Client:
- **Pings** the AgentGate sidecar every few seconds
- **Detects** if the sidecar goes offline
- **Alerts** you if security policies change unexpectedly
- **Auto-reconnects** if the connection drops
- **Tracks** response speed (latency)

**Why this matters:**
- If AgentGate goes down without heartbeat, your AI might not realize it’s unprotected
- If someone changes the policies mid-session, you’ll know immediately
- If the connection drops, the heartbeat will automatically try to reconnect

### 🔌 Layer 6: MCP Plugin Security

**What it is:** Extra security guards specifically for MCP tool calls.

When AI agents call external tools (like Stripe for payments, GitHub for code, or a database), these plugins add automatic checks:

| Plugin | What It Catches |
|---|---|
| **SQL Injection Guard** | Blocks attempts to sneak database commands into tool arguments |
| **Sensitive Data Guard** | Blocks credit card numbers, Social Security numbers, and API keys from being sent |
| **Rate Limiter** | Prevents an agent from calling the same tool too many times |
| **Argument Normalizer** | Cleans up messy input before it reaches the tool |

Think of these as additional security checkpoints at the airport — they catch things the main policy might miss.

---

## How to Use AgentGate (Non-Developer Version)

### If You Use OpenClaw

OpenClaw is a popular AI assistant that runs on WhatsApp, Telegram, Slack, and more. Here's how to add AgentGate protection:

#### Step 1: Ask someone technical to install it

Tell your developer or IT person:

> "Install AgentGate as a sidecar for our OpenClaw. Use the `finance-safe` policy to start."

They'll run three commands and it's done.

#### Step 2: Choose your safety level

AgentGate comes with two ready-made policies for OpenClaw:

| Policy | Best For | What It Does |
|---|---|---|
| **Default** | Everyday use | Blocks payments, deletes, and account changes. Requires approval for form submissions. |
| **Strict** | Banking, HR, admin tasks | Blocks everything except reading. No downloads, no form entries, no clicking action buttons. |

#### Step 3: Use OpenClaw normally

You don't need to change anything about how you use OpenClaw. Just keep chatting normally:

- ✅ "Check my latest invoices" → Works perfectly
- ✅ "Summarize my emails" → Works perfectly
- 🚫 "Pay invoice #1234" → Blocked! AgentGate stops it and tells you.
- ⚠️ "Submit this expense report" → AgentGate asks for your approval first.

#### Step 4: Review what happened (optional)

Open the AgentGate dashboard in your browser:

```
http://localhost:7860
```

You'll see:
- How many actions your AI took
- How many were blocked
- A full timeline of everything that happened
- Whether the evidence chain is intact (nobody tampered with records)

---

## If You Use Other AI Agents

AgentGate works with any AI that uses a browser. Here's how:

### Browser-Use (78k ⭐ on GitHub)
The most popular browser automation for AI agents. AgentGate wraps its browser to enforce policies.

### Anthropic Computer Use
Anthropic's Claude can control your computer. AgentGate sits between Claude and the browser.

### OpenAI CUA (Computer Use Agent)
OpenAI's agent can browse for you. AgentGate adds the safety layer.

### Any Playwright-Based Agent
If the AI agent uses Playwright (the browser automation tool), AgentGate can protect it directly.

### Any Agent via the Sidecar API
Even if the agent is written in JavaScript, Go, Rust, or any other language, it can call AgentGate's REST API before taking any action. This works with literally any agent framework.

---

## Common Questions

### "Will it slow down my AI?"

No. Each policy check takes less than 1 millisecond. Your AI won't notice the difference.

### "Can the AI bypass AgentGate?"

No. AgentGate wraps the browser at the lowest level. The AI never gets direct access to the browser — it can only act through AgentGate.

### "What if AgentGate goes down?"

AgentGate is **fail-closed** — if it crashes or is unreachable, the AI is blocked from doing anything. It doesn't fail open and let the AI run wild.

### "Can I customize the rules?"

Yes. Policies are simple text files. You can create your own rules or modify the built-in ones. If you're not technical, ask your developer to adjust them — it takes minutes.

### "Do I need to change my AI assistant?"

For OpenClaw: No, just install the AgentGate skill and it works.  
For other agents: A developer needs to add a few lines of code (usually under 10 lines).

### "Is my data safe?"

AgentGate runs **100% locally** on your machine or server. No data is ever sent to external servers. The evidence vault is stored on your own disk.

### "How much does it cost?"

AgentGate is **open source and free** to use. There will be optional paid features for enterprise teams (approval workflows, team management, compliance reporting), but the core security engine is and always will be free.

---

## Use Case Scenarios

### 💰 Finance Team
> "Our AI reads invoices, compares quotes, and generates reports — but it can never make payments, change billing info, or export financial data."

### 🏥 Healthcare
> "Our AI reviews patient records and schedules appointments — but it can never modify medical records or share data externally."

### 🛒 Procurement
> "Our AI researches vendors and creates comparison spreadsheets — but it needs approval before placing any order."

### 📞 Customer Support
> "Our AI views customer accounts and finds solutions — but it can never change passwords, issue refunds, or access admin panels."

### 🔧 IT Operations
> "Our AI monitors dashboards and generates alerts — but it can never click 'Delete', 'Restart', or 'Deploy'."

### 🎓 Education
> "Our AI helps students with research — but it can never submit assignments, make purchases, or access restricted systems."

---

## The Bottom Line

| What You Get | How It Works |
|---|---|
| **Peace of mind** | Your AI can't do anything dangerous |
| **Proof** | Every action is recorded and tamper-proof |
| **Control** | You set the rules, the AI follows them |
| **Flexibility** | Works with any AI agent, any browser task |
| **Free** | Open source, runs on your machine |

---

## Next Steps

1. **Using OpenClaw?** → Ask your developer to install the AgentGate skill (5 minutes)
2. **Running multiple AI agents?** → Ask about Multi-Agent Session Management — it coordinates the whole team
3. **Using another AI agent?** → Share this guide with your developer and point them to the [README](../README.md)
4. **Want to learn more?** → Read the [Architecture docs](ARCHITECTURE.md) to understand how each piece works
5. **Questions?** → Open an issue on [GitHub](https://github.com/Nitin-100/agentgate/issues)

---

<p align="center">
  <strong>🛡️ AgentGate — Your AI's safety net.</strong>
</p>
