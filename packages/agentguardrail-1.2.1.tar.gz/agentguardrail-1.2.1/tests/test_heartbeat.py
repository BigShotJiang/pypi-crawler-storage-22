"""Tests for AgentGate OpenClaw Heartbeat Client."""

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio

from agentgate.heartbeat import (
    HeartbeatClient,
    HeartbeatConfig,
    HeartbeatEvent,
    HeartbeatResponse,
    HeartbeatStatus,
    HeartbeatSummary,
)


# ---------------------------------------------------------------------------
# Model Tests
# ---------------------------------------------------------------------------

class TestHeartbeatModels:
    def test_heartbeat_status_values(self):
        assert HeartbeatStatus.HEALTHY == "healthy"
        assert HeartbeatStatus.DEGRADED == "degraded"
        assert HeartbeatStatus.UNHEALTHY == "unhealthy"
        assert HeartbeatStatus.DISCONNECTED == "disconnected"
        assert HeartbeatStatus.UNKNOWN == "unknown"

    def test_heartbeat_config_defaults(self):
        cfg = HeartbeatConfig()
        assert cfg.host == "127.0.0.1"
        assert cfg.port == 18790
        assert cfg.interval_seconds == 10.0
        assert cfg.timeout_seconds == 3.0
        assert cfg.max_missed == 3
        assert cfg.check_policy_version is True
        assert cfg.check_license is True
        assert cfg.check_sessions is True
        assert cfg.auto_reconnect is True
        assert cfg.reconnect_delay_seconds == 5.0
        assert cfg.max_reconnect_attempts == 10
        assert cfg.agent_id == "openclaw"

    def test_heartbeat_config_custom(self):
        cfg = HeartbeatConfig(
            host="10.0.0.1",
            port=9999,
            interval_seconds=5.0,
            max_missed=5,
        )
        assert cfg.host == "10.0.0.1"
        assert cfg.port == 9999
        assert cfg.interval_seconds == 5.0
        assert cfg.max_missed == 5

    def test_heartbeat_event_defaults(self):
        ev = HeartbeatEvent()
        assert ev.sequence == 0
        assert ev.status == HeartbeatStatus.UNKNOWN
        assert ev.latency_ms == 0.0
        assert ev.sidecar_version == ""
        assert ev.policy_hash == ""
        assert ev.errors == []
        assert ev.checks == {}
        assert ev.timestamp > 0

    def test_heartbeat_event_custom(self):
        ev = HeartbeatEvent(
            sequence=5,
            status=HeartbeatStatus.HEALTHY,
            latency_ms=12.5,
            sidecar_version="1.2.0",
            policies_loaded=3,
            policy_hash="abc123",
            active_sessions=2,
        )
        assert ev.sequence == 5
        assert ev.status == HeartbeatStatus.HEALTHY
        assert ev.latency_ms == 12.5
        assert ev.policies_loaded == 3

    def test_heartbeat_summary_defaults(self):
        s = HeartbeatSummary()
        assert s.total_pings == 0
        assert s.successful_pings == 0
        assert s.failed_pings == 0
        assert s.avg_latency_ms == 0.0
        assert s.uptime_percentage == 0.0
        assert s.policy_changes_detected == 0
        assert s.disconnections == 0
        assert s.reconnections == 0

    def test_heartbeat_response_defaults(self):
        r = HeartbeatResponse()
        assert r.status == "ok"
        assert r.version == ""
        assert r.policies_loaded == 0
        assert r.timestamp > 0


# ---------------------------------------------------------------------------
# Client Initialization Tests
# ---------------------------------------------------------------------------

class TestHeartbeatClientInit:
    def test_default_config(self):
        hb = HeartbeatClient()
        assert hb.config.host == "127.0.0.1"
        assert hb.config.port == 18790
        assert hb.status == HeartbeatStatus.UNKNOWN
        assert hb.is_healthy is False
        assert hb.is_connected is True  # UNKNOWN != DISCONNECTED
        assert hb.last_event is None
        assert hb.history == []

    def test_custom_config(self):
        cfg = HeartbeatConfig(host="10.0.0.1", port=9999)
        hb = HeartbeatClient(config=cfg)
        assert hb.config.host == "10.0.0.1"
        assert hb.config.port == 9999

    def test_callbacks(self):
        healthy_cb = MagicMock()
        degraded_cb = MagicMock()
        unhealthy_cb = MagicMock()
        disconnect_cb = MagicMock()
        policy_cb = MagicMock()
        reconnect_cb = MagicMock()

        hb = HeartbeatClient(
            on_healthy=healthy_cb,
            on_degraded=degraded_cb,
            on_unhealthy=unhealthy_cb,
            on_disconnect=disconnect_cb,
            on_policy_change=policy_cb,
            on_reconnect=reconnect_cb,
        )
        assert hb.on_healthy is healthy_cb
        assert hb.on_degraded is degraded_cb
        assert hb.on_unhealthy is unhealthy_cb
        assert hb.on_disconnect is disconnect_cb
        assert hb.on_policy_change is policy_cb
        assert hb.on_reconnect is reconnect_cb


# ---------------------------------------------------------------------------
# Ping Tests (mocked HTTP)
# ---------------------------------------------------------------------------

class TestPing:
    @pytest.mark.asyncio
    async def test_ping_disconnected_when_no_server(self):
        """Ping with no server should result in DISCONNECTED status."""
        cfg = HeartbeatConfig(
            host="127.0.0.1",
            port=19999,  # unlikely to have a real server
            timeout_seconds=0.5,
        )
        hb = HeartbeatClient(config=cfg)
        event = await hb.ping()
        assert event.status == HeartbeatStatus.DISCONNECTED
        assert len(event.errors) > 0
        assert hb.last_event is not None
        # Cleanup
        if hb._client:
            await hb._client.aclose()

    @pytest.mark.asyncio
    async def test_ping_records_history(self):
        """Even failed pings should be recorded in history."""
        cfg = HeartbeatConfig(
            host="127.0.0.1",
            port=19999,
            timeout_seconds=0.5,
        )
        hb = HeartbeatClient(config=cfg)
        await hb.ping()
        await hb.ping()
        assert len(hb.history) == 2
        assert hb.history[0].sequence == 1
        assert hb.history[1].sequence == 2
        if hb._client:
            await hb._client.aclose()

    @pytest.mark.asyncio
    async def test_ping_increments_sequence(self):
        cfg = HeartbeatConfig(
            host="127.0.0.1",
            port=19999,
            timeout_seconds=0.5,
        )
        hb = HeartbeatClient(config=cfg)
        e1 = await hb.ping()
        e2 = await hb.ping()
        e3 = await hb.ping()
        assert e1.sequence == 1
        assert e2.sequence == 2
        assert e3.sequence == 3
        if hb._client:
            await hb._client.aclose()

    @pytest.mark.asyncio
    async def test_ping_disconnect_callback(self):
        callback = MagicMock()
        cfg = HeartbeatConfig(
            host="127.0.0.1",
            port=19999,
            timeout_seconds=0.5,
            max_missed=2,
        )
        hb = HeartbeatClient(config=cfg, on_disconnect=callback)
        # Need to miss max_missed to trigger disconnected
        for _ in range(3):
            await hb.ping()
        assert hb.status == HeartbeatStatus.DISCONNECTED
        callback.assert_called()
        if hb._client:
            await hb._client.aclose()

    @pytest.mark.asyncio
    async def test_missed_count_increments(self):
        cfg = HeartbeatConfig(
            host="127.0.0.1",
            port=19999,
            timeout_seconds=0.5,
            max_missed=10,
        )
        hb = HeartbeatClient(config=cfg)
        await hb.ping()
        assert hb._missed_count == 1
        await hb.ping()
        assert hb._missed_count == 2
        if hb._client:
            await hb._client.aclose()


# ---------------------------------------------------------------------------
# Summary Tests
# ---------------------------------------------------------------------------

class TestSummary:
    def test_empty_summary(self):
        hb = HeartbeatClient()
        hb._start_time = time.time()
        summary = hb.get_summary()
        assert summary.total_pings == 0
        assert summary.successful_pings == 0
        assert summary.uptime_percentage == 0.0

    def test_summary_with_events(self):
        hb = HeartbeatClient()
        hb._start_time = time.time() - 60
        hb._history = [
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY, latency_ms=10),
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY, latency_ms=20),
            HeartbeatEvent(status=HeartbeatStatus.DISCONNECTED, latency_ms=0),
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY, latency_ms=15),
        ]
        hb._latencies = [10, 20, 15]
        hb._policy_changes = 1
        hb._disconnections = 1

        summary = hb.get_summary()
        assert summary.total_pings == 4
        assert summary.successful_pings == 3
        assert summary.failed_pings == 1
        assert summary.uptime_percentage == 75.0
        assert summary.avg_latency_ms == 15.0
        assert summary.max_latency_ms == 20.0
        assert summary.min_latency_ms == 10.0
        assert summary.policy_changes_detected == 1
        assert summary.disconnections == 1
        assert summary.duration_seconds > 0

    def test_summary_100_percent_uptime(self):
        hb = HeartbeatClient()
        hb._start_time = time.time()
        hb._history = [
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY),
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY),
        ]
        hb._latencies = [5, 5]
        summary = hb.get_summary()
        assert summary.uptime_percentage == 100.0

    def test_summary_0_percent_uptime(self):
        hb = HeartbeatClient()
        hb._start_time = time.time()
        hb._history = [
            HeartbeatEvent(status=HeartbeatStatus.DISCONNECTED),
            HeartbeatEvent(status=HeartbeatStatus.DISCONNECTED),
        ]
        hb._latencies = []
        summary = hb.get_summary()
        assert summary.uptime_percentage == 0.0

    def test_summary_last_status(self):
        hb = HeartbeatClient()
        hb._start_time = time.time()
        hb._status = HeartbeatStatus.DEGRADED
        summary = hb.get_summary()
        assert summary.last_status == "degraded"


# ---------------------------------------------------------------------------
# Start / Stop Tests
# ---------------------------------------------------------------------------

class TestStartStop:
    @pytest.mark.asyncio
    async def test_start_creates_task(self):
        cfg = HeartbeatConfig(interval_seconds=100)  # Large interval
        hb = HeartbeatClient(config=cfg)
        await hb.start()
        assert hb._running is True
        assert hb._task is not None
        await hb.stop()

    @pytest.mark.asyncio
    async def test_start_idempotent(self):
        cfg = HeartbeatConfig(interval_seconds=100)
        hb = HeartbeatClient(config=cfg)
        await hb.start()
        task1 = hb._task
        await hb.start()  # Should not create new task
        assert hb._task is task1
        await hb.stop()

    @pytest.mark.asyncio
    async def test_stop_returns_summary(self):
        cfg = HeartbeatConfig(interval_seconds=100)
        hb = HeartbeatClient(config=cfg)
        await hb.start()
        summary = await hb.stop()
        assert isinstance(summary, HeartbeatSummary)
        assert hb._running is False
        assert hb._task is None

    @pytest.mark.asyncio
    async def test_stop_without_start(self):
        hb = HeartbeatClient()
        summary = await hb.stop()
        assert isinstance(summary, HeartbeatSummary)


# ---------------------------------------------------------------------------
# Status Property Tests
# ---------------------------------------------------------------------------

class TestStatusProperties:
    def test_is_healthy_when_healthy(self):
        hb = HeartbeatClient()
        hb._status = HeartbeatStatus.HEALTHY
        assert hb.is_healthy is True

    def test_is_healthy_when_not(self):
        hb = HeartbeatClient()
        hb._status = HeartbeatStatus.DEGRADED
        assert hb.is_healthy is False

    def test_is_connected_when_healthy(self):
        hb = HeartbeatClient()
        hb._status = HeartbeatStatus.HEALTHY
        assert hb.is_connected is True

    def test_is_connected_when_degraded(self):
        hb = HeartbeatClient()
        hb._status = HeartbeatStatus.DEGRADED
        assert hb.is_connected is True

    def test_is_connected_when_disconnected(self):
        hb = HeartbeatClient()
        hb._status = HeartbeatStatus.DISCONNECTED
        assert hb.is_connected is False


# ---------------------------------------------------------------------------
# Policy Change Detection Tests
# ---------------------------------------------------------------------------

class TestPolicyChangeDetection:
    @pytest.mark.asyncio
    async def test_policy_hash_change_detection(self):
        """Test that policy changes are tracked via internal state."""
        hb = HeartbeatClient()
        # Simulate first hash
        hb._last_policy_hash = "hash_v1"
        hb._policy_changes = 0

        # Manually set different hash and increment
        hb._last_policy_hash = "hash_v2"
        hb._policy_changes = 1

        assert hb._policy_changes == 1

    def test_policy_change_callback_setup(self):
        callback = MagicMock()
        hb = HeartbeatClient(on_policy_change=callback)
        assert hb.on_policy_change is callback

    @pytest.mark.asyncio
    async def test_policy_changes_in_summary(self):
        hb = HeartbeatClient()
        hb._start_time = time.time()
        hb._policy_changes = 3
        summary = hb.get_summary()
        assert summary.policy_changes_detected == 3


# ---------------------------------------------------------------------------
# History Management Tests
# ---------------------------------------------------------------------------

class TestHistoryManagement:
    def test_empty_history(self):
        hb = HeartbeatClient()
        assert hb.history == []
        assert hb.last_event is None

    def test_last_event(self):
        hb = HeartbeatClient()
        ev1 = HeartbeatEvent(sequence=1)
        ev2 = HeartbeatEvent(sequence=2)
        hb._history = [ev1, ev2]
        assert hb.last_event.sequence == 2

    def test_history_returns_copy(self):
        hb = HeartbeatClient()
        hb._history = [HeartbeatEvent(sequence=1)]
        history = hb.history
        history.append(HeartbeatEvent(sequence=999))
        assert len(hb._history) == 1  # Internal not modified


# ---------------------------------------------------------------------------
# Reconnection Logic Tests
# ---------------------------------------------------------------------------

class TestReconnection:
    def test_reconnect_counter(self):
        hb = HeartbeatClient()
        hb._reconnections = 0
        hb._reconnections += 1
        assert hb._reconnections == 1

    def test_reconnect_attempts_tracking(self):
        hb = HeartbeatClient()
        hb._reconnect_attempts = 0
        for i in range(5):
            hb._reconnect_attempts += 1
        assert hb._reconnect_attempts == 5

    @pytest.mark.asyncio
    async def test_max_reconnect_config(self):
        cfg = HeartbeatConfig(max_reconnect_attempts=5)
        hb = HeartbeatClient(config=cfg)
        assert hb.config.max_reconnect_attempts == 5

    def test_auto_reconnect_config(self):
        cfg1 = HeartbeatConfig(auto_reconnect=True)
        assert cfg1.auto_reconnect is True

        cfg2 = HeartbeatConfig(auto_reconnect=False)
        assert cfg2.auto_reconnect is False

    def test_reconnect_delay_config(self):
        cfg = HeartbeatConfig(reconnect_delay_seconds=15.0)
        assert cfg.reconnect_delay_seconds == 15.0


# ---------------------------------------------------------------------------
# Latency Tracking Tests
# ---------------------------------------------------------------------------

class TestLatencyTracking:
    def test_latency_tracking(self):
        hb = HeartbeatClient()
        hb._start_time = time.time()
        hb._latencies = [10, 20, 30]
        hb._history = [
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY),
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY),
            HeartbeatEvent(status=HeartbeatStatus.HEALTHY),
        ]

        summary = hb.get_summary()
        assert summary.avg_latency_ms == 20.0
        assert summary.max_latency_ms == 30.0
        assert summary.min_latency_ms == 10.0

    def test_empty_latencies(self):
        hb = HeartbeatClient()
        hb._start_time = time.time()
        summary = hb.get_summary()
        assert summary.avg_latency_ms == 0.0
        assert summary.max_latency_ms == 0.0
        assert summary.min_latency_ms == 0.0


# ---------------------------------------------------------------------------
# Callback Invocation Tests (simulated status changes)
# ---------------------------------------------------------------------------

class TestCallbacks:
    def test_healthy_callback_binding(self):
        cb = MagicMock()
        hb = HeartbeatClient(on_healthy=cb)
        assert hb.on_healthy is cb

    def test_degraded_callback_binding(self):
        cb = MagicMock()
        hb = HeartbeatClient(on_degraded=cb)
        assert hb.on_degraded is cb

    def test_unhealthy_callback_binding(self):
        cb = MagicMock()
        hb = HeartbeatClient(on_unhealthy=cb)
        assert hb.on_unhealthy is cb

    def test_disconnect_callback_binding(self):
        cb = MagicMock()
        hb = HeartbeatClient(on_disconnect=cb)
        assert hb.on_disconnect is cb

    def test_reconnect_callback_binding(self):
        cb = MagicMock()
        hb = HeartbeatClient(on_reconnect=cb)
        assert hb.on_reconnect is cb

    def test_policy_change_callback_binding(self):
        cb = MagicMock()
        hb = HeartbeatClient(on_policy_change=cb)
        assert hb.on_policy_change is cb
