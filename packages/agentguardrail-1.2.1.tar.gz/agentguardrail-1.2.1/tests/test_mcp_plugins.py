"""Tests for AgentGate MCP Plugin System."""

import re
import time
import pytest

from agentgate.mcp.types import MCPToolCall, MCPToolCallDecision, MCPPolicy, MCPToolRule
from agentgate.mcp.policy_engine import MCPPolicyEngine
from agentgate.mcp.plugin import (
    PluginRegistry,
    PluginContext,
    PluginDecision,
    PluginPriority,
    PolicyPlugin,
    TransformPlugin,
    AuditPlugin,
    ValidatorPlugin,
    SQLInjectionValidator,
    SensitiveDataValidator,
    RateLimitByServerPlugin,
    LoggingAuditPlugin,
    ArgumentNormalizerTransform,
    create_secure_registry,
    BUILTIN_PLUGINS,
)


# ---------------------------------------------------------------------------
# Test helpers — concrete plugin implementations for testing
# ---------------------------------------------------------------------------

class BlockAllPlugin(PolicyPlugin):
    name = "block-all"
    description = "Blocks everything"
    priority = PluginPriority.CRITICAL

    def pre_evaluate(self, tool_call, context):
        return PluginDecision(block=True, reason="Blocked by test plugin")


class AllowOverridePlugin(PolicyPlugin):
    name = "allow-override"
    description = "Overrides to allow"
    priority = PluginPriority.NORMAL

    def post_evaluate(self, tool_call, decision, context):
        if not decision.allowed:
            return PluginDecision(
                override_decision="allow",
                reason="Overridden by test plugin",
            )
        return None


class PostBlockPlugin(PolicyPlugin):
    name = "post-block"
    description = "Blocks in post-evaluate"
    priority = PluginPriority.NORMAL

    def post_evaluate(self, tool_call, decision, context):
        if "dangerous" in tool_call.tool_name:
            return PluginDecision(block=True, reason="Post-blocked dangerous tool")
        return None


class UpperCaseTransform(TransformPlugin):
    name = "uppercase-args"
    description = "Uppercases all string arguments"
    priority = PluginPriority.NORMAL

    def transform(self, tool_call, context):
        for key, value in tool_call.arguments.items():
            if isinstance(value, str):
                tool_call.arguments[key] = value.upper()
        return tool_call


class StubAuditPlugin(AuditPlugin):
    name = "test-audit"
    description = "Records decisions for testing"
    priority = PluginPriority.AUDIT

    def __init__(self):
        self.recorded: list[dict] = []

    def on_decision(self, tool_call, decision, context):
        self.recorded.append({
            "tool": tool_call.tool_name,
            "allowed": decision.allowed,
            "decision": decision.decision,
        })


class LengthValidator(ValidatorPlugin):
    name = "length-check"
    description = "Blocks args longer than max"
    priority = PluginPriority.HIGH

    def __init__(self, max_len=50):
        self.max_len = max_len

    def validate(self, tool_call, context):
        for arg_name, arg_value in tool_call.arguments.items():
            if len(str(arg_value)) > self.max_len:
                return PluginDecision(
                    block=True,
                    reason=f"Arg '{arg_name}' exceeds {self.max_len} chars",
                )
        return None


# ---------------------------------------------------------------------------
# PluginRegistry Tests
# ---------------------------------------------------------------------------

class TestPluginRegistry:
    def test_empty_registry(self):
        registry = PluginRegistry()
        assert registry.plugin_count == 0
        assert registry.list_plugins() == []

    def test_register_policy_plugin(self):
        registry = PluginRegistry()
        plugin = BlockAllPlugin()
        registry.register(plugin)
        assert registry.plugin_count == 1
        listed = registry.list_plugins()
        assert len(listed) == 1
        assert listed[0]["name"] == "block-all"
        assert listed[0]["category"] == "policy"

    def test_register_transform_plugin(self):
        registry = PluginRegistry()
        plugin = UpperCaseTransform()
        registry.register(plugin)
        assert registry.plugin_count == 1
        listed = registry.list_plugins()
        assert listed[0]["category"] == "transform"

    def test_register_audit_plugin(self):
        registry = PluginRegistry()
        plugin = StubAuditPlugin()
        registry.register(plugin)
        assert registry.plugin_count == 1
        listed = registry.list_plugins()
        assert listed[0]["category"] == "audit"

    def test_register_validator_plugin(self):
        registry = PluginRegistry()
        plugin = LengthValidator()
        registry.register(plugin)
        assert registry.plugin_count == 1
        listed = registry.list_plugins()
        assert listed[0]["category"] == "validator"

    def test_register_multiple_plugins(self):
        registry = PluginRegistry()
        registry.register(BlockAllPlugin())
        registry.register(UpperCaseTransform())
        registry.register(StubAuditPlugin())
        registry.register(LengthValidator())
        assert registry.plugin_count == 4

    def test_unregister_plugin(self):
        registry = PluginRegistry()
        registry.register(BlockAllPlugin())
        assert registry.plugin_count == 1
        removed = registry.unregister("block-all")
        assert removed is True
        assert registry.plugin_count == 0

    def test_unregister_nonexistent(self):
        registry = PluginRegistry()
        removed = registry.unregister("nonexistent")
        assert removed is False

    def test_get_plugin(self):
        registry = PluginRegistry()
        plugin = BlockAllPlugin()
        registry.register(plugin)
        found = registry.get_plugin("block-all")
        assert found is plugin

    def test_get_plugin_nonexistent(self):
        registry = PluginRegistry()
        assert registry.get_plugin("nonexistent") is None

    def test_clear_registry(self):
        registry = PluginRegistry()
        registry.register(BlockAllPlugin())
        registry.register(UpperCaseTransform())
        registry.register(StubAuditPlugin())
        registry.register(LengthValidator())
        assert registry.plugin_count == 4
        registry.clear()
        assert registry.plugin_count == 0

    def test_priority_ordering(self):
        registry = PluginRegistry()

        class LowPriPlugin(PolicyPlugin):
            name = "low"
            priority = PluginPriority.LOW
        class HighPriPlugin(PolicyPlugin):
            name = "high"
            priority = PluginPriority.HIGH
        class CritPlugin(PolicyPlugin):
            name = "crit"
            priority = PluginPriority.CRITICAL

        # Register in wrong order
        registry.register(LowPriPlugin())
        registry.register(CritPlugin())
        registry.register(HighPriPlugin())

        names = [p.name for p in registry._policy_plugins]
        assert names == ["crit", "high", "low"]


# ---------------------------------------------------------------------------
# Transform Plugin Tests
# ---------------------------------------------------------------------------

class TestTransformPlugins:
    def test_uppercase_transform(self):
        registry = PluginRegistry()
        registry.register(UpperCaseTransform())

        call = MCPToolCall(
            server_name="test",
            tool_name="send_message",
            arguments={"text": "hello world"},
        )
        context = PluginContext()
        result = registry.run_transforms(call, context)
        assert result.arguments["text"] == "HELLO WORLD"

    def test_arg_normalizer(self):
        registry = PluginRegistry()
        registry.register(ArgumentNormalizerTransform())

        call = MCPToolCall(
            server_name="test",
            tool_name="action",
            arguments={"  key  ": "  value  ", "num": 42},
        )
        context = PluginContext()
        result = registry.run_transforms(call, context)
        assert "key" in result.arguments
        assert result.arguments["key"] == "value"
        assert result.arguments["num"] == 42

    def test_disabled_transform_skipped(self):
        registry = PluginRegistry()
        plugin = UpperCaseTransform()
        plugin.enabled = False
        registry.register(plugin)

        call = MCPToolCall(
            tool_name="test",
            arguments={"text": "hello"},
        )
        result = registry.run_transforms(call, PluginContext())
        assert result.arguments["text"] == "hello"  # Not uppercased


# ---------------------------------------------------------------------------
# Validator Plugin Tests
# ---------------------------------------------------------------------------

class TestValidatorPlugins:
    def test_length_validator_pass(self):
        registry = PluginRegistry()
        registry.register(LengthValidator(max_len=100))

        call = MCPToolCall(
            tool_name="action",
            arguments={"msg": "short message"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is None  # Passed

    def test_length_validator_block(self):
        registry = PluginRegistry()
        registry.register(LengthValidator(max_len=10))

        call = MCPToolCall(
            tool_name="action",
            arguments={"msg": "this is a very long message"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True
        assert "exceeds" in result.reason

    def test_sql_injection_validator_clean(self):
        validator = SQLInjectionValidator()
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="query",
            arguments={"sql": "SELECT * FROM users WHERE id = 5"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is None

    def test_sql_injection_validator_drop(self):
        validator = SQLInjectionValidator()
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="query",
            arguments={"sql": "SELECT 1; DROP TABLE users"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True
        assert "SQL injection" in result.reason

    def test_sql_injection_validator_union_select(self):
        validator = SQLInjectionValidator()
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="query",
            arguments={"search": "admin' UNION SELECT password FROM users"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True

    def test_sensitive_data_validator_clean(self):
        validator = SensitiveDataValidator()
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="send",
            arguments={"msg": "Hello, how are you?"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is None

    def test_sensitive_data_validator_credit_card(self):
        validator = SensitiveDataValidator()
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="send",
            arguments={"card": "4532-1234-5678-9012"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True
        assert "credit_card" in result.reason

    def test_sensitive_data_validator_ssn(self):
        validator = SensitiveDataValidator()
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="store",
            arguments={"ssn": "123-45-6789"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True
        assert "ssn" in result.reason

    def test_sensitive_data_validator_api_key(self):
        validator = SensitiveDataValidator()
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="config",
            arguments={"key": "sk-abcdefghijklmnopqrstuvwxyz"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True
        assert "api_key" in result.reason

    def test_disabled_validator_skipped(self):
        validator = SQLInjectionValidator()
        validator.enabled = False
        registry = PluginRegistry()
        registry.register(validator)

        call = MCPToolCall(
            tool_name="query",
            arguments={"sql": "'; DROP TABLE users; --"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is None  # Skipped


# ---------------------------------------------------------------------------
# Policy Plugin Tests (pre/post evaluate)
# ---------------------------------------------------------------------------

class TestPolicyPlugins:
    def test_pre_evaluate_block(self):
        registry = PluginRegistry()
        registry.register(BlockAllPlugin())

        call = MCPToolCall(tool_name="anything")
        context = PluginContext()
        result = registry.run_pre_evaluate(call, context)
        assert result is not None
        assert result.block is True
        assert result.plugin_name == "block-all"

    def test_pre_evaluate_pass(self):
        registry = PluginRegistry()
        # AllowOverridePlugin only has post_evaluate, not pre_evaluate
        registry.register(AllowOverridePlugin())

        call = MCPToolCall(tool_name="anything")
        context = PluginContext()
        result = registry.run_pre_evaluate(call, context)
        assert result is None  # No pre-evaluate opinion

    def test_post_evaluate_override_to_allow(self):
        registry = PluginRegistry()
        registry.register(AllowOverridePlugin())

        call = MCPToolCall(tool_name="blocked_thing")
        blocked_decision = MCPToolCallDecision(
            allowed=False, decision="block", reason="original block"
        )
        context = PluginContext()
        result = registry.run_post_evaluate(call, blocked_decision, context)
        assert result.allowed is True
        assert result.decision == "allow"
        assert "Overridden" in result.reason

    def test_post_evaluate_block(self):
        registry = PluginRegistry()
        registry.register(PostBlockPlugin())

        call = MCPToolCall(tool_name="dangerous_action")
        allowed_decision = MCPToolCallDecision(
            allowed=True, decision="allow", reason="normally allowed"
        )
        context = PluginContext()
        result = registry.run_post_evaluate(call, allowed_decision, context)
        assert result.allowed is False
        assert result.decision == "block"

    def test_post_evaluate_no_change(self):
        registry = PluginRegistry()
        registry.register(PostBlockPlugin())

        call = MCPToolCall(tool_name="safe_action")
        allowed_decision = MCPToolCallDecision(
            allowed=True, decision="allow", reason="normally allowed"
        )
        context = PluginContext()
        result = registry.run_post_evaluate(call, allowed_decision, context)
        assert result.allowed is True
        assert result.decision == "allow"

    def test_context_tracks_prior_decisions(self):
        registry = PluginRegistry()

        class TrackingPlugin(PolicyPlugin):
            name = "tracker"
            def pre_evaluate(self, tool_call, context):
                return PluginDecision(reason="tracked", metadata={"test": True})

        registry.register(TrackingPlugin())
        call = MCPToolCall(tool_name="test")
        context = PluginContext()
        registry.run_pre_evaluate(call, context)
        assert len(context.prior_decisions) == 1
        assert context.prior_decisions[0].reason == "tracked"


# ---------------------------------------------------------------------------
# Audit Plugin Tests
# ---------------------------------------------------------------------------

class TestAuditPlugins:
    def test_audit_records_decisions(self):
        registry = PluginRegistry()
        audit = StubAuditPlugin()
        registry.register(audit)

        call = MCPToolCall(tool_name="test_tool")
        decision = MCPToolCallDecision(
            allowed=True, decision="allow"
        )
        context = PluginContext()
        registry.run_audit(call, decision, context)

        assert len(audit.recorded) == 1
        assert audit.recorded[0]["tool"] == "test_tool"
        assert audit.recorded[0]["allowed"] is True

    def test_logging_audit_plugin(self):
        plugin = LoggingAuditPlugin()
        registry = PluginRegistry()
        registry.register(plugin)

        call = MCPToolCall(server_name="db", tool_name="query")
        decision = MCPToolCallDecision(
            allowed=True, decision="allow", risk_level="low"
        )
        context = PluginContext()
        registry.run_audit(call, decision, context)

        assert len(plugin.log) == 1
        assert plugin.log[0]["server"] == "db"
        assert plugin.log[0]["tool"] == "query"

    def test_audit_disabled_skipped(self):
        audit = StubAuditPlugin()
        audit.enabled = False
        registry = PluginRegistry()
        registry.register(audit)

        call = MCPToolCall(tool_name="test")
        decision = MCPToolCallDecision(allowed=True, decision="allow")
        registry.run_audit(call, decision, PluginContext())
        assert len(audit.recorded) == 0

    def test_multiple_audits(self):
        audit1 = StubAuditPlugin()
        audit1.name = "audit-1"
        audit2 = StubAuditPlugin()
        audit2.name = "audit-2"

        registry = PluginRegistry()
        registry.register(audit1)
        registry.register(audit2)

        call = MCPToolCall(tool_name="test")
        decision = MCPToolCallDecision(allowed=True, decision="allow")
        registry.run_audit(call, decision, PluginContext())

        assert len(audit1.recorded) == 1
        assert len(audit2.recorded) == 1


# ---------------------------------------------------------------------------
# Rate Limit Plugin Tests
# ---------------------------------------------------------------------------

class TestRateLimitPlugin:
    def test_within_limit(self):
        plugin = RateLimitByServerPlugin(
            limits={"stripe": 5},
            default_limit=10,
        )
        registry = PluginRegistry()
        registry.register(plugin)

        call = MCPToolCall(server_name="stripe", tool_name="get_balance")
        for _ in range(5):
            result = registry.run_pre_evaluate(call, PluginContext())
            assert result is None  # Within limit

    def test_exceeds_limit(self):
        plugin = RateLimitByServerPlugin(
            limits={"stripe": 3},
            default_limit=10,
        )
        registry = PluginRegistry()
        registry.register(plugin)

        call = MCPToolCall(server_name="stripe", tool_name="get_balance")
        for _ in range(3):
            registry.run_pre_evaluate(call, PluginContext())

        result = registry.run_pre_evaluate(call, PluginContext())
        assert result is not None
        assert result.block is True
        assert "rate limit" in result.reason.lower()

    def test_different_servers_independent(self):
        plugin = RateLimitByServerPlugin(
            limits={"stripe": 2},
            default_limit=10,
        )
        registry = PluginRegistry()
        registry.register(plugin)

        # Exhaust stripe limit
        call_stripe = MCPToolCall(server_name="stripe", tool_name="pay")
        for _ in range(2):
            registry.run_pre_evaluate(call_stripe, PluginContext())

        # Github should still work
        call_github = MCPToolCall(server_name="github", tool_name="list")
        result = registry.run_pre_evaluate(call_github, PluginContext())
        assert result is None


# ---------------------------------------------------------------------------
# Engine + Plugin Integration Tests
# ---------------------------------------------------------------------------

class TestEnginePluginIntegration:
    def test_engine_with_no_plugins(self):
        """Engine with no registry should work normally."""
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(name="test", default_decision="allow"))
        decision = engine.evaluate(MCPToolCall(tool_name="anything"))
        assert decision.allowed is True

    def test_engine_with_plugin_registry(self):
        """Engine with an empty registry should work normally."""
        registry = PluginRegistry()
        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(name="test", default_decision="allow"))
        decision = engine.evaluate(MCPToolCall(tool_name="anything"))
        assert decision.allowed is True

    def test_engine_validator_blocks_before_policy(self):
        """Validator plugin should block before engine even evaluates."""
        registry = PluginRegistry()
        registry.register(LengthValidator(max_len=5))

        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(name="allow-all", default_decision="allow"))

        # Short args → allowed
        d1 = engine.evaluate(MCPToolCall(
            tool_name="test", arguments={"msg": "hi"}
        ))
        assert d1.allowed is True

        # Long args → blocked by validator
        d2 = engine.evaluate(MCPToolCall(
            tool_name="test", arguments={"msg": "this is way too long"}
        ))
        assert d2.allowed is False
        assert "length-check" in d2.matched_rule

    def test_engine_pre_evaluate_blocks(self):
        """Pre-evaluate plugin should block before engine evaluation."""
        registry = PluginRegistry()
        registry.register(BlockAllPlugin())

        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(name="allow-all", default_decision="allow"))

        decision = engine.evaluate(MCPToolCall(tool_name="anything"))
        assert decision.allowed is False
        assert "block-all" in decision.matched_rule

    def test_engine_post_evaluate_overrides(self):
        """Post-evaluate plugin should override engine decision."""
        registry = PluginRegistry()
        registry.register(AllowOverridePlugin())

        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(
            name="block-all",
            default_decision="block",
        ))

        decision = engine.evaluate(MCPToolCall(tool_name="anything"))
        assert decision.allowed is True
        assert "allow-override" in decision.matched_rule

    def test_engine_audit_fires(self):
        """Audit plugins should record all decisions."""
        audit = StubAuditPlugin()
        registry = PluginRegistry()
        registry.register(audit)

        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(name="test", default_decision="allow"))

        engine.evaluate(MCPToolCall(tool_name="tool1"))
        engine.evaluate(MCPToolCall(tool_name="tool2"))

        assert len(audit.recorded) == 2
        assert audit.recorded[0]["tool"] == "tool1"
        assert audit.recorded[1]["tool"] == "tool2"

    def test_engine_transform_then_evaluate(self):
        """Transform should modify tool call before evaluation."""
        registry = PluginRegistry()
        registry.register(UpperCaseTransform())

        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(
            name="test",
            default_decision="allow",
            tool_rules=[
                MCPToolRule(
                    tool_pattern="*",
                    arg_patterns={"cmd": "DANGEROUS"},
                    decision="block",
                    reason="Blocked dangerous command",
                ),
            ],
        ))

        # "dangerous" gets uppercased to "DANGEROUS" by transform → matches rule
        decision = engine.evaluate(MCPToolCall(
            tool_name="execute",
            arguments={"cmd": "dangerous"},
        ))
        assert decision.allowed is False

    def test_engine_sql_injection_guard(self):
        """Built-in SQL injection guard should work with engine."""
        registry = create_secure_registry()
        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(name="test", default_decision="allow"))

        # Clean query → allowed
        d1 = engine.evaluate(MCPToolCall(
            tool_name="query",
            arguments={"sql": "SELECT * FROM users"},
        ))
        assert d1.allowed is True

        # SQL injection → blocked
        d2 = engine.evaluate(MCPToolCall(
            tool_name="query",
            arguments={"sql": "SELECT 1; DROP TABLE users"},
        ))
        assert d2.allowed is False

    def test_engine_no_policies_with_plugins(self):
        """Engine with no policies but with plugins should still run pipeline."""
        audit = StubAuditPlugin()
        registry = PluginRegistry()
        registry.register(audit)

        engine = MCPPolicyEngine(plugin_registry=registry)

        decision = engine.evaluate(MCPToolCall(tool_name="test"))
        assert decision.allowed is True
        assert "No MCP policies loaded" in decision.reason
        assert len(audit.recorded) == 1

    def test_full_pipeline(self):
        """Test the complete plugin pipeline: transform → validate → pre → engine → post → audit."""
        audit = StubAuditPlugin()
        registry = PluginRegistry()
        registry.register(ArgumentNormalizerTransform())
        registry.register(LengthValidator(max_len=200))
        registry.register(audit)

        engine = MCPPolicyEngine(plugin_registry=registry)
        engine.load_policy(MCPPolicy(
            name="test",
            default_decision="allow",
            tool_rules=[
                MCPToolRule(tool_pattern="delete_*", decision="block"),
            ],
        ))

        # Normal call → transform → validate pass → engine allow → audit
        d1 = engine.evaluate(MCPToolCall(
            tool_name="get_users",
            arguments={"  filter  ": "  active  "},
        ))
        assert d1.allowed is True
        assert len(audit.recorded) == 1

        # Delete call → transform → validate pass → engine block → audit
        d2 = engine.evaluate(MCPToolCall(tool_name="delete_user"))
        assert d2.allowed is False
        assert len(audit.recorded) == 2


# ---------------------------------------------------------------------------
# Built-in plugin presets
# ---------------------------------------------------------------------------

class TestBuiltinPlugins:
    def test_builtin_registry_has_all(self):
        assert "sql-injection-guard" in BUILTIN_PLUGINS
        assert "sensitive-data-guard" in BUILTIN_PLUGINS
        assert "per-server-rate-limit" in BUILTIN_PLUGINS
        assert "decision-logger" in BUILTIN_PLUGINS
        assert "arg-normalizer" in BUILTIN_PLUGINS

    def test_create_secure_registry(self):
        registry = create_secure_registry()
        assert registry.plugin_count >= 4
        plugins = registry.list_plugins()
        names = {p["name"] for p in plugins}
        assert "sql-injection-guard" in names
        assert "sensitive-data-guard" in names
        assert "decision-logger" in names
        assert "arg-normalizer" in names

    def test_secure_registry_blocks_sql_injection(self):
        registry = create_secure_registry()
        call = MCPToolCall(
            tool_name="query",
            arguments={"sql": "1=1; DELETE FROM accounts"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True

    def test_secure_registry_blocks_credit_card(self):
        registry = create_secure_registry()
        call = MCPToolCall(
            tool_name="store",
            arguments={"number": "4111 1111 1111 1111"},
        )
        result = registry.run_validators(call, PluginContext())
        assert result is not None
        assert result.block is True


# ---------------------------------------------------------------------------
# PluginDecision model Tests
# ---------------------------------------------------------------------------

class TestPluginDecision:
    def test_default_decision(self):
        d = PluginDecision()
        assert d.block is False
        assert d.override_decision == ""
        assert d.reason == ""

    def test_block_decision(self):
        d = PluginDecision(block=True, reason="test block")
        assert d.block is True
        assert d.reason == "test block"

    def test_override_decision(self):
        d = PluginDecision(override_decision="allow", reason="overridden")
        assert d.override_decision == "allow"

    def test_risk_override(self):
        d = PluginDecision(risk_override="critical")
        assert d.risk_override == "critical"

    def test_metadata(self):
        d = PluginDecision(metadata={"key": "value"})
        assert d.metadata["key"] == "value"


# ---------------------------------------------------------------------------
# PluginContext model Tests
# ---------------------------------------------------------------------------

class TestPluginContext:
    def test_default_context(self):
        ctx = PluginContext()
        assert ctx.agent_id == ""
        assert ctx.session_id == ""
        assert ctx.prior_decisions == []
        assert ctx.engine_decision is None
        assert ctx.metadata == {}

    def test_context_with_values(self):
        ctx = PluginContext(
            agent_id="agent-1",
            session_id="ses-123",
            metadata={"trace": "abc"},
        )
        assert ctx.agent_id == "agent-1"
        assert ctx.session_id == "ses-123"
        assert ctx.metadata["trace"] == "abc"

    def test_timestamp_auto_set(self):
        before = time.time()
        ctx = PluginContext()
        after = time.time()
        assert before <= ctx.timestamp <= after
