"""Tests for AgentGate MCP Policy Engine."""

import time
import pytest
import tempfile
import os

from agentgate.mcp.types import (
    MCPToolCall,
    MCPToolCallDecision,
    MCPToolRule,
    MCPPolicy,
)
from agentgate.mcp.policy_engine import (
    MCPPolicyEngine,
    classify_mcp_risk,
    _glob_match,
    _rule_matches_tool_call,
    MCP_PRESET_POLICIES,
    create_mcp_default_policy,
    create_mcp_readonly_policy,
    create_mcp_finance_safe_policy,
    create_mcp_devops_safe_policy,
)


# ---------------------------------------------------------------------------
# glob_match Tests
# ---------------------------------------------------------------------------

class TestGlobMatch:
    def test_wildcard_matches_everything(self):
        assert _glob_match("*", "anything")
        assert _glob_match("*", "")
        assert _glob_match("*", "create_payment")

    def test_empty_pattern_matches_everything(self):
        assert _glob_match("", "anything")

    def test_exact_match(self):
        assert _glob_match("stripe", "stripe")
        assert _glob_match("stripe", "Stripe")  # case insensitive
        assert not _glob_match("stripe", "github")

    def test_prefix_wildcard(self):
        assert _glob_match("create_*", "create_payment")
        assert _glob_match("create_*", "create_user")
        assert not _glob_match("create_*", "delete_payment")

    def test_suffix_wildcard(self):
        assert _glob_match("*_payment", "create_payment")
        assert _glob_match("*_payment", "delete_payment")
        assert not _glob_match("*_payment", "create_user")

    def test_pipe_separated_patterns(self):
        assert _glob_match("create_*|delete_*", "create_payment")
        assert _glob_match("create_*|delete_*", "delete_repo")
        assert not _glob_match("create_*|delete_*", "get_users")

    def test_multiple_patterns(self):
        pattern = "get_*|list_*|read_*|search_*"
        assert _glob_match(pattern, "get_users")
        assert _glob_match(pattern, "list_repos")
        assert _glob_match(pattern, "read_file")
        assert _glob_match(pattern, "search_issues")
        assert not _glob_match(pattern, "delete_user")

    def test_case_insensitive(self):
        assert _glob_match("Stripe", "stripe")
        assert _glob_match("CREATE_*", "create_payment")

    def test_middle_wildcard(self):
        assert _glob_match("create_*_payment", "create_new_payment")
        assert not _glob_match("create_*_payment", "create_new_user")


# ---------------------------------------------------------------------------
# rule_matches_tool_call Tests
# ---------------------------------------------------------------------------

class TestRuleMatchesToolCall:
    def test_wildcard_rule_matches_all(self):
        rule = MCPToolRule()  # defaults: server=*, tool=*
        call = MCPToolCall(server_name="any", tool_name="anything")
        assert _rule_matches_tool_call(rule, call)

    def test_server_pattern_match(self):
        rule = MCPToolRule(server_pattern="stripe", tool_pattern="*")
        match = MCPToolCall(server_name="stripe", tool_name="create_payment")
        no_match = MCPToolCall(server_name="github", tool_name="create_payment")
        assert _rule_matches_tool_call(rule, match)
        assert not _rule_matches_tool_call(rule, no_match)

    def test_tool_pattern_match(self):
        rule = MCPToolRule(tool_pattern="delete_*")
        match = MCPToolCall(server_name="any", tool_name="delete_user")
        no_match = MCPToolCall(server_name="any", tool_name="create_user")
        assert _rule_matches_tool_call(rule, match)
        assert not _rule_matches_tool_call(rule, no_match)

    def test_both_patterns_must_match(self):
        rule = MCPToolRule(server_pattern="stripe", tool_pattern="create_*")
        match = MCPToolCall(server_name="stripe", tool_name="create_payment")
        no_match_server = MCPToolCall(server_name="github", tool_name="create_repo")
        no_match_tool = MCPToolCall(server_name="stripe", tool_name="get_balance")
        assert _rule_matches_tool_call(rule, match)
        assert not _rule_matches_tool_call(rule, no_match_server)
        assert not _rule_matches_tool_call(rule, no_match_tool)

    def test_arg_pattern_match(self):
        rule = MCPToolRule(
            tool_pattern="send_email",
            arg_patterns={"to": r".*@competitor\.com"},
        )
        match = MCPToolCall(
            tool_name="send_email",
            arguments={"to": "bob@competitor.com", "subject": "hello"},
        )
        no_match = MCPToolCall(
            tool_name="send_email",
            arguments={"to": "alice@company.com"},
        )
        assert _rule_matches_tool_call(rule, match)
        assert not _rule_matches_tool_call(rule, no_match)

    def test_arg_pattern_missing_arg(self):
        rule = MCPToolRule(
            tool_pattern="query",
            arg_patterns={"sql": "DROP"},
        )
        call = MCPToolCall(tool_name="query", arguments={})
        # Missing arg → empty string → no match on "DROP"
        assert not _rule_matches_tool_call(rule, call)

    def test_arg_block_values_match(self):
        rule = MCPToolRule(
            tool_pattern="query",
            arg_block_values={"sql": ["DROP", "DELETE"]},
        )
        match = MCPToolCall(
            tool_name="query",
            arguments={"sql": "DROP TABLE users"},
        )
        no_match = MCPToolCall(
            tool_name="query",
            arguments={"sql": "SELECT * FROM users"},
        )
        assert _rule_matches_tool_call(rule, match)
        assert not _rule_matches_tool_call(rule, no_match)

    def test_intent_matching(self):
        """Intent-based rule should match when combined text has the intent."""
        rule = MCPToolRule(intent="delete", decision="block")
        call = MCPToolCall(
            server_name="db",
            tool_name="delete_all_records",
            arguments={"table": "users"},
        )
        # "delete" keyword should be detected in "db delete_all_records table users"
        assert _rule_matches_tool_call(rule, call)

    def test_intent_no_match(self):
        """Intent rule should NOT match when no matching intent is detected."""
        rule = MCPToolRule(intent="payment", decision="block")
        call = MCPToolCall(
            server_name="github",
            tool_name="list_repos",
        )
        assert not _rule_matches_tool_call(rule, call)


# ---------------------------------------------------------------------------
# classify_mcp_risk Tests
# ---------------------------------------------------------------------------

class TestClassifyMCPRisk:
    def test_high_risk_payment(self):
        call = MCPToolCall(tool_name="create_payment", arguments={"amount": 100})
        risk = classify_mcp_risk(call)
        assert risk in ("high", "critical")

    def test_high_risk_delete(self):
        call = MCPToolCall(tool_name="delete_user", arguments={"id": "123"})
        risk = classify_mcp_risk(call)
        assert risk in ("high", "critical")

    def test_low_risk_read(self):
        call = MCPToolCall(tool_name="get_users")
        risk = classify_mcp_risk(call)
        assert risk == "low"

    def test_low_risk_list(self):
        call = MCPToolCall(tool_name="list_repos")
        risk = classify_mcp_risk(call)
        assert risk == "low"

    def test_high_risk_admin(self):
        call = MCPToolCall(tool_name="admin_reset_system")
        risk = classify_mcp_risk(call)
        assert risk in ("high", "critical")

    def test_risk_from_arguments(self):
        call = MCPToolCall(
            tool_name="execute",
            arguments={"command": "delete everything"},
        )
        risk = classify_mcp_risk(call)
        assert risk in ("high", "critical")


# ---------------------------------------------------------------------------
# MCPPolicyEngine Tests
# ---------------------------------------------------------------------------

class TestMCPPolicyEngine:
    def test_no_policies_allows_all(self):
        engine = MCPPolicyEngine()
        call = MCPToolCall(server_name="s", tool_name="anything")
        decision = engine.evaluate(call)
        assert decision.allowed is True
        assert decision.decision == "allow"
        assert "No MCP policies loaded" in decision.reason

    def test_load_policy(self):
        engine = MCPPolicyEngine()
        policy = MCPPolicy(name="test")
        engine.load_policy(policy)
        assert len(engine._policies) == 1

    def test_clear_policies(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(name="a"))
        engine.load_policy(MCPPolicy(name="b"))
        assert len(engine._policies) == 2
        engine.clear_policies()
        assert len(engine._policies) == 0

    def test_block_by_tool_rule(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="block-delete",
            tool_rules=[
                MCPToolRule(tool_pattern="delete_*", decision="block", reason="No deletes"),
            ],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="db",
            tool_name="delete_user",
        ))
        assert decision.allowed is False
        assert decision.decision == "block"
        assert "No deletes" in decision.reason

    def test_allow_by_default(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="allow-default",
            default_decision="allow",
            tool_rules=[
                MCPToolRule(tool_pattern="delete_*", decision="block"),
            ],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="db",
            tool_name="get_users",
        ))
        assert decision.allowed is True
        assert decision.decision == "allow"

    def test_block_by_default(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="block-default",
            default_decision="block",
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="anything",
        ))
        assert decision.allowed is False
        assert decision.decision == "block"

    def test_blocked_server(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="server-block",
            blocked_servers=["evil-server"],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="evil-server",
            tool_name="anything",
        ))
        assert decision.allowed is False
        assert "blocked" in decision.reason.lower()

    def test_allowed_server_whitelist(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="server-allow",
            allowed_servers=["safe-server"],
        ))
        # Not in allowlist
        decision = engine.evaluate(MCPToolCall(
            server_name="other-server",
            tool_name="anything",
        ))
        assert decision.allowed is False
        assert "allowlist" in decision.reason.lower()

        # In allowlist
        decision2 = engine.evaluate(MCPToolCall(
            server_name="safe-server",
            tool_name="anything",
        ))
        assert decision2.allowed is True

    def test_blocked_tool(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="tool-block",
            blocked_tools=["drop_*", "truncate_*"],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="db",
            tool_name="drop_table",
        ))
        assert decision.allowed is False
        assert "blocked" in decision.reason.lower()

    def test_allowed_tool_whitelist(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="tool-allow",
            allowed_tools=["get_*", "list_*"],
        ))
        # Not in allowlist
        decision = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="delete_user",
        ))
        assert decision.allowed is False

        # In allowlist
        decision2 = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="get_users",
        ))
        assert decision2.allowed is True

    def test_max_arg_length(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="arg-length",
            max_arg_length=100,
        ))
        # Short args — allowed
        decision = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="t",
            arguments={"msg": "hello"},
        ))
        assert decision.allowed is True

        # Long args — blocked
        decision2 = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="t",
            arguments={"msg": "x" * 200},
        ))
        assert decision2.allowed is False
        assert "max length" in decision2.reason.lower()

    def test_require_approval(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="approval",
            tool_rules=[
                MCPToolRule(tool_pattern="deploy_*", decision="require_approval"),
            ],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="infra",
            tool_name="deploy_service",
        ))
        assert decision.allowed is False
        assert decision.decision == "require_approval"

    def test_log_only_is_allowed(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="log",
            tool_rules=[
                MCPToolRule(tool_pattern="read_*", decision="log_only"),
            ],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="read_file",
        ))
        assert decision.allowed is True
        assert decision.decision == "log_only"

    def test_most_restrictive_wins(self):
        """When multiple policies loaded, most restrictive decision wins."""
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="permissive",
            default_decision="allow",
        ))
        engine.load_policy(MCPPolicy(
            name="strict",
            tool_rules=[
                MCPToolRule(tool_pattern="delete_*", decision="block", reason="blocked"),
            ],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="db",
            tool_name="delete_user",
        ))
        assert decision.allowed is False
        assert decision.decision == "block"

    def test_disabled_policy_skipped(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="disabled",
            enabled=False,
            default_decision="block",
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="anything",
        ))
        # Disabled → skipped → no decisions → allowed
        assert decision.allowed is True

    def test_decision_contains_metadata(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="test-meta",
            tool_rules=[
                MCPToolRule(tool_pattern="pay_*", decision="block", reason="blocked"),
            ],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="stripe",
            tool_name="pay_invoice",
        ))
        assert decision.policy_name == "test-meta"
        assert decision.server_name == "stripe"
        assert decision.tool_name == "pay_invoice"
        assert decision.tool_fingerprint != ""
        assert decision.matched_rule != ""

    def test_rule_risk_override(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="risk-override",
            tool_rules=[
                MCPToolRule(
                    tool_pattern="get_*",
                    decision="allow",
                    risk="critical",
                ),
            ],
        ))
        decision = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="get_data",
        ))
        assert decision.allowed is True
        assert decision.risk_level == "critical"

    def test_rate_limit(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="rate-limited",
            max_calls_per_minute=3,
        ))
        # Make 3 calls — should be allowed
        for _ in range(3):
            d = engine.evaluate(MCPToolCall(
                server_name="s",
                tool_name="t",
                agent_id="agent-1",
            ))
            assert d.allowed is True

        # 4th call should be rate limited
        d4 = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="t",
            agent_id="agent-1",
        ))
        assert d4.allowed is False
        assert "Rate limit" in d4.reason

    def test_rate_limit_different_agents(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="rate",
            max_calls_per_minute=2,
        ))
        # Agent 1 at limit
        for _ in range(2):
            engine.evaluate(MCPToolCall(server_name="s", tool_name="t", agent_id="a1"))

        # Agent 2 should still be allowed (separate counter)
        d = engine.evaluate(MCPToolCall(server_name="s", tool_name="t", agent_id="a2"))
        assert d.allowed is True

    def test_server_pattern_with_glob(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="server-glob",
            tool_rules=[
                MCPToolRule(
                    server_pattern="production*",
                    tool_pattern="*",
                    decision="require_approval",
                    reason="Prod needs approval",
                ),
            ],
        ))
        d = engine.evaluate(MCPToolCall(
            server_name="production-db",
            tool_name="query",
        ))
        assert d.decision == "require_approval"
        assert "Prod" in d.reason


# ---------------------------------------------------------------------------
# YAML loading Tests
# ---------------------------------------------------------------------------

class TestMCPPolicyYAML:
    def test_load_from_yaml_string(self):
        yaml_str = """
name: yaml-test
description: Test YAML loading
default_decision: block
tool_rules:
  - tool_pattern: "get_*"
    decision: allow
  - tool_pattern: "delete_*"
    decision: block
    reason: No deletes
blocked_servers:
  - evil-server
max_calls_per_minute: 30
"""
        engine = MCPPolicyEngine()
        policy = engine.load_policy_from_yaml_string(yaml_str)
        assert policy.name == "yaml-test"
        assert policy.default_decision == "block"
        assert len(policy.tool_rules) == 2
        assert "evil-server" in policy.blocked_servers
        assert policy.max_calls_per_minute == 30

    def test_load_from_yaml_file(self, tmp_path):
        yaml_content = """
name: mcp-file-test
description: From file
default_decision: allow
tool_rules:
  - tool_pattern: "destroy_*"
    decision: block
"""
        yaml_file = tmp_path / "mcp-test.yaml"
        yaml_file.write_text(yaml_content)

        engine = MCPPolicyEngine()
        policy = engine.load_policy_from_yaml(str(yaml_file))
        assert policy.name == "mcp-file-test"
        assert len(policy.tool_rules) == 1
        assert len(engine._policies) == 1

    def test_load_policies_from_dir(self, tmp_path):
        # Create two MCP policy YAML files
        (tmp_path / "mcp-a.yaml").write_text("""
name: mcp-a
tool_rules:
  - tool_pattern: "delete_*"
    decision: block
""")
        (tmp_path / "mcp-b.yml").write_text("""
name: mcp-b
tool_rules:
  - tool_pattern: "drop_*"
    decision: block
""")
        # Create a non-MCP file (should be skipped)
        (tmp_path / "browser-policy.yaml").write_text("""
name: browser-only
rules:
  - element_text: "Pay Now"
    decision: block
""")

        engine = MCPPolicyEngine()
        count = engine.load_policies_from_dir(tmp_path)
        assert count == 2
        assert len(engine._policies) == 2

    def test_load_from_invalid_dir(self, tmp_path):
        engine = MCPPolicyEngine()
        count = engine.load_policies_from_dir(tmp_path / "nonexistent")
        assert count == 0


# ---------------------------------------------------------------------------
# Preset Policies Tests
# ---------------------------------------------------------------------------

class TestMCPPresetPolicies:
    def test_preset_registry_has_all(self):
        assert "mcp-default" in MCP_PRESET_POLICIES
        assert "mcp-readonly" in MCP_PRESET_POLICIES
        assert "mcp-finance-safe" in MCP_PRESET_POLICIES
        assert "mcp-devops-safe" in MCP_PRESET_POLICIES

    def test_presets_are_callables(self):
        for name, factory in MCP_PRESET_POLICIES.items():
            policy = factory()
            assert isinstance(policy, MCPPolicy)
            assert policy.name == name

    # --- mcp-default ---

    def test_default_blocks_delete(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_default_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="db", tool_name="delete_user",
        ))
        assert d.allowed is False

    def test_default_blocks_drop(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_default_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="db", tool_name="drop_table",
        ))
        assert d.allowed is False

    def test_default_allows_read(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_default_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="db", tool_name="get_users",
        ))
        assert d.allowed is True

    def test_default_has_rate_limit(self):
        policy = create_mcp_default_policy()
        assert policy.max_calls_per_minute > 0

    # --- mcp-readonly ---

    def test_readonly_allows_get(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_readonly_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="api", tool_name="get_data",
        ))
        assert d.allowed is True

    def test_readonly_allows_list(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_readonly_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="api", tool_name="list_items",
        ))
        assert d.allowed is True

    def test_readonly_allows_search(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_readonly_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="api", tool_name="search_products",
        ))
        assert d.allowed is True

    def test_readonly_blocks_create(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_readonly_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="api", tool_name="create_user",
        ))
        assert d.allowed is False

    def test_readonly_blocks_delete(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_readonly_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="api", tool_name="delete_item",
        ))
        assert d.allowed is False

    def test_readonly_blocks_update(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_readonly_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="api", tool_name="update_profile",
        ))
        assert d.allowed is False

    # --- mcp-finance-safe ---

    def test_finance_safe_blocks_payment(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_finance_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="stripe", tool_name="create_payment_intent",
        ))
        assert d.allowed is False

    def test_finance_safe_blocks_charge(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_finance_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="stripe", tool_name="create_charge",
        ))
        assert d.allowed is False

    def test_finance_safe_blocks_transfer(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_finance_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="stripe", tool_name="transfer_funds",
        ))
        assert d.allowed is False

    def test_finance_safe_allows_read(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_finance_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="stripe", tool_name="list_customers",
        ))
        assert d.allowed is True

    # --- mcp-devops-safe ---

    def test_devops_blocks_destroy(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_devops_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="aws", tool_name="destroy_stack",
        ))
        assert d.allowed is False

    def test_devops_blocks_terminate(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_devops_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="aws", tool_name="terminate_instance",
        ))
        assert d.allowed is False

    def test_devops_requires_approval_for_deploy(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_devops_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="k8s", tool_name="deploy_service",
        ))
        assert d.decision == "require_approval"

    def test_devops_requires_approval_for_production(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_devops_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="production-db",
            tool_name="query",
        ))
        assert d.decision == "require_approval"

    def test_devops_allows_read(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_devops_safe_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="aws", tool_name="get_instance_status",
        ))
        assert d.allowed is True


# ---------------------------------------------------------------------------
# Complex Scenario Tests
# ---------------------------------------------------------------------------

class TestMCPComplexScenarios:
    def test_multiple_policies_most_restrictive(self):
        """Load both default + finance-safe, most restrictive wins."""
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_default_policy())
        engine.load_policy(create_mcp_finance_safe_policy())

        # Payment blocked by both
        d = engine.evaluate(MCPToolCall(
            server_name="stripe",
            tool_name="create_payment",
        ))
        assert d.allowed is False

    def test_server_block_beats_tool_allow(self):
        """Server blocklist takes priority over tool rules."""
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="mixed",
            blocked_servers=["evil"],
            tool_rules=[
                MCPToolRule(tool_pattern="get_*", decision="allow"),
            ],
        ))
        d = engine.evaluate(MCPToolCall(
            server_name="evil",
            tool_name="get_data",
        ))
        assert d.allowed is False

    def test_arg_length_check_with_rules(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="with-args",
            max_arg_length=50,
            tool_rules=[
                MCPToolRule(tool_pattern="execute", decision="allow"),
            ],
        ))
        # Tool rule allows it but arg is too long
        d = engine.evaluate(MCPToolCall(
            server_name="s",
            tool_name="execute",
            arguments={"code": "x" * 100},
        ))
        assert d.allowed is False
        assert "max length" in d.reason.lower()

    def test_empty_server_name_matches_wildcard(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="test",
            tool_rules=[
                MCPToolRule(tool_pattern="delete_*", decision="block"),
            ],
        ))
        d = engine.evaluate(MCPToolCall(
            server_name="",
            tool_name="delete_user",
        ))
        assert d.allowed is False

    def test_decision_risk_level_populated(self):
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_default_policy())
        d = engine.evaluate(MCPToolCall(
            server_name="db", tool_name="get_users",
        ))
        assert d.risk_level in ("low", "medium", "high", "critical", "none")

    def test_pipe_tool_pattern_in_rule(self):
        engine = MCPPolicyEngine()
        engine.load_policy(MCPPolicy(
            name="pipe-pattern",
            tool_rules=[
                MCPToolRule(
                    tool_pattern="drop_*|truncate_*|destroy_*",
                    decision="block",
                    reason="Destructive ops blocked",
                ),
            ],
        ))
        for tool in ["drop_table", "truncate_log", "destroy_cluster"]:
            d = engine.evaluate(MCPToolCall(server_name="s", tool_name=tool))
            assert d.allowed is False, f"{tool} should be blocked"

        d2 = engine.evaluate(MCPToolCall(server_name="s", tool_name="get_status"))
        assert d2.allowed is True
