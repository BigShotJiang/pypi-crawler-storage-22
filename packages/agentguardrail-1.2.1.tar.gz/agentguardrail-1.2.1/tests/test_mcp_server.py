"""Tests for AgentGate MCP Server (FastMCP tools and resources)."""

import pytest
import time
from unittest.mock import patch, MagicMock

from agentgate.mcp.server import (
    create_agentgate_mcp_server,
    BROWSER_PRESET_POLICIES,
)
from agentgate.mcp.policy_engine import (
    MCPPolicyEngine,
    MCP_PRESET_POLICIES,
    create_mcp_default_policy,
)
from agentgate.mcp.types import MCPPolicy, MCPToolRule


# ---------------------------------------------------------------------------
# Server creation Tests
# ---------------------------------------------------------------------------

class TestCreateServer:
    def test_create_default_server(self):
        server = create_agentgate_mcp_server()
        assert server is not None
        assert server.name == "AgentGate"

    def test_create_with_browser_policy(self):
        server = create_agentgate_mcp_server(policy="finance-safe")
        assert server is not None

    def test_create_with_mcp_policy(self):
        server = create_agentgate_mcp_server(mcp_policy="mcp-default")
        assert server is not None

    def test_create_with_both_policies(self):
        server = create_agentgate_mcp_server(
            policy="finance-safe",
            mcp_policy="mcp-finance-safe",
        )
        assert server is not None

    def test_create_with_policy_object(self):
        from agentgate.policy.engine import create_finance_safe_policy
        policy = create_finance_safe_policy()
        server = create_agentgate_mcp_server(policy=policy)
        assert server is not None

    def test_create_with_mcp_policy_object(self):
        policy = create_mcp_default_policy()
        server = create_agentgate_mcp_server(mcp_policy=policy)
        assert server is not None

    def test_create_with_nonexistent_policy_dir(self, tmp_path):
        # Should not crash — just loads nothing from the dir
        server = create_agentgate_mcp_server(
            policy_dir=str(tmp_path / "nonexistent")
        )
        assert server is not None

    def test_create_with_policy_dir(self, tmp_path):
        # Create MCP policy file
        (tmp_path / "mcp-test.yaml").write_text("""
name: mcp-test
tool_rules:
  - tool_pattern: "delete_*"
    decision: block
""")
        server = create_agentgate_mcp_server(policy_dir=str(tmp_path))
        assert server is not None


# ---------------------------------------------------------------------------
# Server tool names Tests
# ---------------------------------------------------------------------------

class TestServerTools:
    """Test that the MCP server registers all expected tools."""

    def test_server_has_tools(self):
        server = create_agentgate_mcp_server()
        # FastMCP should have tools registered
        assert server is not None
        # The server object should have the tool decorator functions defined

    def test_browser_presets_available(self):
        assert "finance-safe" in BROWSER_PRESET_POLICIES
        assert "readonly" in BROWSER_PRESET_POLICIES
        assert "permissive" in BROWSER_PRESET_POLICIES


# ---------------------------------------------------------------------------
# MCP Proxy types Tests
# ---------------------------------------------------------------------------

class TestMCPProxyTypes:
    """Test the proxy server can be instantiated."""

    def test_proxy_creation_no_servers(self):
        from agentgate.mcp.proxy import MCPProxyServer
        proxy = MCPProxyServer(mcp_policy="mcp-default")
        assert proxy is not None
        assert len(proxy._server_configs) == 0

    def test_proxy_creation_with_server_dicts(self):
        from agentgate.mcp.proxy import MCPProxyServer
        proxy = MCPProxyServer(
            mcp_policy="mcp-default",
            servers=[
                {"name": "test", "command": "echo", "args": ["hello"]},
            ],
        )
        assert len(proxy._server_configs) == 1
        assert proxy._server_configs[0].name == "test"

    def test_proxy_creation_with_server_config(self):
        from agentgate.mcp.proxy import MCPProxyServer
        from agentgate.mcp.types import MCPServerConfig

        config = MCPServerConfig(
            name="github",
            url="http://localhost:8200/mcp",
            transport="streamable-http",
        )
        proxy = MCPProxyServer(
            mcp_policy="mcp-default",
            servers=[config],
        )
        assert len(proxy._server_configs) == 1
        assert proxy._server_configs[0].transport == "streamable-http"

    def test_proxy_with_policy_object(self):
        from agentgate.mcp.proxy import MCPProxyServer
        policy = create_mcp_default_policy()
        proxy = MCPProxyServer(mcp_policy=policy)
        assert len(proxy._policy_engine._policies) == 1

    def test_proxy_with_policy_dir(self, tmp_path):
        from agentgate.mcp.proxy import MCPProxyServer
        (tmp_path / "mcp-test.yaml").write_text("""
name: mcp-dir-test
tool_rules:
  - tool_pattern: "delete_*"
    decision: block
""")
        proxy = MCPProxyServer(
            mcp_policy="mcp-default",
            policy_dir=str(tmp_path),
        )
        # Should have both the preset and the YAML policy
        assert len(proxy._policy_engine._policies) == 2


# ---------------------------------------------------------------------------
# DownstreamServer Tests
# ---------------------------------------------------------------------------

class TestDownstreamServer:
    def test_downstream_creation(self):
        from agentgate.mcp.proxy import DownstreamServer
        from agentgate.mcp.types import MCPServerConfig

        config = MCPServerConfig(
            name="test-server",
            command="echo",
            args=["hello"],
        )
        server = DownstreamServer(config)
        assert server.name == "test-server"
        assert server.is_connected is False
        assert server.tools == []

    def test_downstream_not_connected_raises(self):
        from agentgate.mcp.proxy import DownstreamServer
        from agentgate.mcp.types import MCPServerConfig

        server = DownstreamServer(MCPServerConfig(name="test"))
        with pytest.raises(RuntimeError, match="Not connected"):
            import asyncio
            asyncio.run(server.call_tool("any", {}))


# ---------------------------------------------------------------------------
# Module exports Tests
# ---------------------------------------------------------------------------

class TestMCPModuleExports:
    def test_mcp_init_exports(self):
        from agentgate.mcp import (
            MCPToolCall,
            MCPToolCallDecision,
            MCPServerConfig,
            MCPToolRule,
            MCPPolicy,
            MCPActionType,
            MCPPolicyEngine,
            create_mcp_default_policy,
            create_mcp_readonly_policy,
            create_mcp_finance_safe_policy,
            create_mcp_devops_safe_policy,
            MCP_PRESET_POLICIES,
            create_agentgate_mcp_server,
            MCPProxyServer,
            classify_mcp_risk,
        )
        # All imports should succeed
        assert MCPToolCall is not None
        assert MCPPolicyEngine is not None

    def test_main_init_mcp_exports(self):
        """MCP types should be importable from top-level agentgate package."""
        from agentgate import MCPToolCall, MCPToolCallDecision, MCPPolicyEngine
        assert MCPToolCall is not None
        assert MCPToolCallDecision is not None
        assert MCPPolicyEngine is not None


# ---------------------------------------------------------------------------
# Integration: Server + Policy Engine
# ---------------------------------------------------------------------------

class TestMCPIntegration:
    """Integration tests that verify end-to-end behavior."""

    def test_server_with_default_policy_blocks_delete(self):
        """Verify the MCP server + default policy correctly blocks delete tools."""
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_default_policy())

        from agentgate.mcp.types import MCPToolCall
        call = MCPToolCall(server_name="db", tool_name="delete_table")
        decision = engine.evaluate(call)
        assert decision.allowed is False

    def test_server_with_readonly_allows_list(self):
        from agentgate.mcp.policy_engine import create_mcp_readonly_policy
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_readonly_policy())

        from agentgate.mcp.types import MCPToolCall
        call = MCPToolCall(server_name="api", tool_name="list_items")
        decision = engine.evaluate(call)
        assert decision.allowed is True

    def test_server_with_finance_safe_blocks_payment(self):
        from agentgate.mcp.policy_engine import create_mcp_finance_safe_policy
        engine = MCPPolicyEngine()
        engine.load_policy(create_mcp_finance_safe_policy())

        from agentgate.mcp.types import MCPToolCall
        call = MCPToolCall(
            server_name="stripe",
            tool_name="create_charge",
            arguments={"amount": 1000},
        )
        decision = engine.evaluate(call)
        assert decision.allowed is False

    def test_yaml_roundtrip(self, tmp_path):
        """Write a YAML policy, load it, evaluate against it."""
        yaml_content = """
name: mcp-roundtrip-test
description: Test YAML roundtrip
default_decision: allow
tool_rules:
  - tool_pattern: "nuke_*"
    decision: block
    reason: No nuking
  - server_pattern: "production*"
    tool_pattern: "*"
    decision: require_approval
    reason: Prod needs approval
blocked_servers:
  - evil-corp
max_calls_per_minute: 10
max_arg_length: 1000
"""
        yaml_file = tmp_path / "mcp-roundtrip.yaml"
        yaml_file.write_text(yaml_content)

        engine = MCPPolicyEngine()
        engine.load_policy_from_yaml(str(yaml_file))

        # Test 1: nuke tool is blocked
        from agentgate.mcp.types import MCPToolCall
        d1 = engine.evaluate(MCPToolCall(
            server_name="infra", tool_name="nuke_everything",
        ))
        assert d1.allowed is False
        assert "No nuking" in d1.reason

        # Test 2: production server requires approval
        d2 = engine.evaluate(MCPToolCall(
            server_name="production-db", tool_name="query",
        ))
        assert d2.decision == "require_approval"

        # Test 3: evil-corp server is blocked
        d3 = engine.evaluate(MCPToolCall(
            server_name="evil-corp", tool_name="get_data",
        ))
        assert d3.allowed is False

        # Test 4: normal read is allowed
        d4 = engine.evaluate(MCPToolCall(
            server_name="safe-api", tool_name="get_users",
        ))
        assert d4.allowed is True

        # Test 5: long args are blocked
        d5 = engine.evaluate(MCPToolCall(
            server_name="s", tool_name="t",
            arguments={"data": "x" * 2000},
        ))
        assert d5.allowed is False
