"""Tests for AgentGate MCP types and data models."""

import time
import pytest

from agentgate.mcp.types import (
    MCPActionType,
    MCPToolCall,
    MCPToolCallDecision,
    MCPServerConfig,
    MCPToolRule,
    MCPPolicy,
)


# ---------------------------------------------------------------------------
# MCPActionType Tests
# ---------------------------------------------------------------------------

class TestMCPActionType:
    def test_tool_call_value(self):
        assert MCPActionType.TOOL_CALL == "tool_call"

    def test_resource_read_value(self):
        assert MCPActionType.RESOURCE_READ == "resource_read"

    def test_resource_write_value(self):
        assert MCPActionType.RESOURCE_WRITE == "resource_write"

    def test_prompt_use_value(self):
        assert MCPActionType.PROMPT_USE == "prompt_use"

    def test_string_enum(self):
        assert isinstance(MCPActionType.TOOL_CALL, str)


# ---------------------------------------------------------------------------
# MCPToolCall Tests
# ---------------------------------------------------------------------------

class TestMCPToolCall:
    def test_basic_creation(self):
        call = MCPToolCall(
            server_name="stripe",
            tool_name="create_payment",
            arguments={"amount": 100, "currency": "usd"},
        )
        assert call.server_name == "stripe"
        assert call.tool_name == "create_payment"
        assert call.arguments == {"amount": 100, "currency": "usd"}

    def test_default_values(self):
        call = MCPToolCall()
        assert call.server_name == ""
        assert call.tool_name == ""
        assert call.arguments == {}
        assert call.action_type == MCPActionType.TOOL_CALL
        assert call.agent_id == ""
        assert call.session_id == ""
        assert call.metadata == {}

    def test_fingerprint_deterministic(self):
        call1 = MCPToolCall(server_name="s", tool_name="t", arguments={"a": 1})
        call2 = MCPToolCall(server_name="s", tool_name="t", arguments={"a": 1})
        assert call1.fingerprint == call2.fingerprint

    def test_fingerprint_unique_by_server(self):
        call1 = MCPToolCall(server_name="stripe", tool_name="pay")
        call2 = MCPToolCall(server_name="github", tool_name="pay")
        assert call1.fingerprint != call2.fingerprint

    def test_fingerprint_unique_by_tool(self):
        call1 = MCPToolCall(server_name="db", tool_name="read")
        call2 = MCPToolCall(server_name="db", tool_name="write")
        assert call1.fingerprint != call2.fingerprint

    def test_fingerprint_unique_by_args(self):
        call1 = MCPToolCall(server_name="s", tool_name="t", arguments={"a": 1})
        call2 = MCPToolCall(server_name="s", tool_name="t", arguments={"a": 2})
        assert call1.fingerprint != call2.fingerprint

    def test_fingerprint_is_hex_string(self):
        call = MCPToolCall(server_name="test", tool_name="action")
        assert len(call.fingerprint) == 16
        int(call.fingerprint, 16)  # Should not raise — valid hex

    def test_combined_text_includes_server(self):
        call = MCPToolCall(server_name="stripe", tool_name="pay")
        assert "stripe" in call.combined_text

    def test_combined_text_includes_tool(self):
        call = MCPToolCall(server_name="s", tool_name="create_payment")
        assert "create_payment" in call.combined_text

    def test_combined_text_includes_args(self):
        call = MCPToolCall(
            server_name="s",
            tool_name="t",
            arguments={"amount": "500", "to": "bob@example.com"},
        )
        ct = call.combined_text
        assert "amount" in ct
        assert "500" in ct
        assert "bob@example.com" in ct

    def test_combined_text_empty_call(self):
        call = MCPToolCall()
        assert call.combined_text.strip() == ""

    def test_timestamp_auto_set(self):
        before = time.time()
        call = MCPToolCall(server_name="test", tool_name="action")
        after = time.time()
        assert before <= call.timestamp <= after

    def test_custom_action_type(self):
        call = MCPToolCall(action_type=MCPActionType.RESOURCE_READ)
        assert call.action_type == MCPActionType.RESOURCE_READ

    def test_metadata(self):
        call = MCPToolCall(metadata={"trace_id": "abc123"})
        assert call.metadata["trace_id"] == "abc123"


# ---------------------------------------------------------------------------
# MCPToolCallDecision Tests
# ---------------------------------------------------------------------------

class TestMCPToolCallDecision:
    def test_allowed_decision(self):
        d = MCPToolCallDecision(allowed=True, decision="allow")
        assert d.allowed is True
        assert d.decision == "allow"

    def test_blocked_decision(self):
        d = MCPToolCallDecision(
            allowed=False,
            decision="block",
            risk_level="high",
            reason="Payment tools are restricted",
            policy_name="mcp-finance-safe",
            matched_rule="tool_rule:*/create_payment",
        )
        assert d.allowed is False
        assert d.risk_level == "high"
        assert "Payment" in d.reason
        assert d.policy_name == "mcp-finance-safe"

    def test_require_approval_decision(self):
        d = MCPToolCallDecision(
            allowed=False,
            decision="require_approval",
        )
        assert d.allowed is False
        assert d.decision == "require_approval"

    def test_defaults(self):
        d = MCPToolCallDecision(allowed=True, decision="allow")
        assert d.risk_level == "low"
        assert d.reason == ""
        assert d.policy_name == ""
        assert d.matched_rule == ""
        assert d.tool_fingerprint == ""
        assert d.record_id == ""
        assert d.server_name == ""
        assert d.tool_name == ""


# ---------------------------------------------------------------------------
# MCPServerConfig Tests
# ---------------------------------------------------------------------------

class TestMCPServerConfig:
    def test_stdio_server(self):
        config = MCPServerConfig(
            name="stripe",
            command="npx",
            args=["-y", "@stripe/mcp"],
        )
        assert config.name == "stripe"
        assert config.command == "npx"
        assert config.args == ["-y", "@stripe/mcp"]
        assert config.transport == "stdio"

    def test_http_server(self):
        config = MCPServerConfig(
            name="github",
            url="http://localhost:8200/mcp",
            transport="streamable-http",
        )
        assert config.url == "http://localhost:8200/mcp"
        assert config.transport == "streamable-http"

    def test_defaults(self):
        config = MCPServerConfig(name="test")
        assert config.command == ""
        assert config.args == []
        assert config.env == {}
        assert config.url == ""
        assert config.transport == "stdio"
        assert config.policy == ""
        assert config.description == ""
        assert config.enabled is True

    def test_disabled_server(self):
        config = MCPServerConfig(name="risky", enabled=False)
        assert config.enabled is False

    def test_env_vars(self):
        config = MCPServerConfig(
            name="stripe",
            command="npx",
            env={"STRIPE_KEY": "sk_test_xxx"},
        )
        assert config.env["STRIPE_KEY"] == "sk_test_xxx"


# ---------------------------------------------------------------------------
# MCPToolRule Tests
# ---------------------------------------------------------------------------

class TestMCPToolRule:
    def test_block_specific_tool(self):
        rule = MCPToolRule(
            tool_pattern="create_payment",
            decision="block",
            reason="No payments",
        )
        assert rule.tool_pattern == "create_payment"
        assert rule.decision == "block"
        assert rule.reason == "No payments"

    def test_wildcard_defaults(self):
        rule = MCPToolRule()
        assert rule.server_pattern == "*"
        assert rule.tool_pattern == "*"
        assert rule.decision == "block"

    def test_arg_patterns(self):
        rule = MCPToolRule(
            tool_pattern="send_email",
            arg_patterns={"to": r".*@competitor\.com"},
        )
        assert "to" in rule.arg_patterns

    def test_arg_block_values(self):
        rule = MCPToolRule(
            tool_pattern="query",
            arg_block_values={"sql": ["DROP", "DELETE", "TRUNCATE"]},
        )
        assert "DROP" in rule.arg_block_values["sql"]

    def test_intent_rule(self):
        rule = MCPToolRule(intent="payment", decision="block")
        assert rule.intent == "payment"

    def test_risk_override(self):
        rule = MCPToolRule(
            tool_pattern="delete_*",
            risk="critical",
            decision="block",
        )
        assert rule.risk == "critical"

    def test_server_specific_rule(self):
        rule = MCPToolRule(
            server_pattern="production*",
            tool_pattern="*",
            decision="require_approval",
        )
        assert rule.server_pattern == "production*"


# ---------------------------------------------------------------------------
# MCPPolicy Tests
# ---------------------------------------------------------------------------

class TestMCPPolicy:
    def test_basic_policy(self):
        policy = MCPPolicy(
            name="test-policy",
            description="A test policy",
            default_decision="allow",
        )
        assert policy.name == "test-policy"
        assert policy.description == "A test policy"
        assert policy.default_decision == "allow"

    def test_defaults(self):
        policy = MCPPolicy(name="minimal")
        assert policy.version == "1.0"
        assert policy.enabled is True
        assert policy.default_decision == "allow"
        assert policy.tool_rules == []
        assert policy.blocked_servers == []
        assert policy.allowed_servers == []
        assert policy.blocked_tools == []
        assert policy.allowed_tools == []
        assert policy.max_calls_per_minute == 0
        assert policy.max_arg_length == 0

    def test_from_dict_basic(self):
        data = {
            "name": "test-dict",
            "description": "From dict",
            "default_decision": "block",
        }
        policy = MCPPolicy.from_dict(data)
        assert policy.name == "test-dict"
        assert policy.default_decision == "block"

    def test_from_dict_with_rules(self):
        data = {
            "name": "with-rules",
            "tool_rules": [
                {
                    "tool_pattern": "delete_*",
                    "decision": "block",
                    "reason": "No deletes",
                },
                {
                    "server_pattern": "stripe",
                    "tool_pattern": "create_payment",
                    "decision": "require_approval",
                },
            ],
        }
        policy = MCPPolicy.from_dict(data)
        assert len(policy.tool_rules) == 2
        assert policy.tool_rules[0].tool_pattern == "delete_*"
        assert policy.tool_rules[0].decision == "block"
        assert policy.tool_rules[1].server_pattern == "stripe"

    def test_from_dict_blocklists(self):
        data = {
            "name": "lists",
            "blocked_servers": ["evil-server"],
            "blocked_tools": ["rm_rf", "drop_table"],
            "allowed_servers": ["safe-server"],
        }
        policy = MCPPolicy.from_dict(data)
        assert "evil-server" in policy.blocked_servers
        assert "rm_rf" in policy.blocked_tools
        assert "safe-server" in policy.allowed_servers

    def test_from_dict_rate_limit(self):
        data = {
            "name": "rated",
            "max_calls_per_minute": 30,
            "max_arg_length": 5000,
        }
        policy = MCPPolicy.from_dict(data)
        assert policy.max_calls_per_minute == 30
        assert policy.max_arg_length == 5000

    def test_from_dict_missing_name(self):
        data = {"description": "no name given"}
        policy = MCPPolicy.from_dict(data)
        assert policy.name == "unnamed-mcp-policy"

    def test_from_dict_empty_rules(self):
        data = {"name": "no-rules"}
        policy = MCPPolicy.from_dict(data)
        assert policy.tool_rules == []

    def test_disabled_policy(self):
        data = {"name": "disabled", "enabled": False}
        policy = MCPPolicy.from_dict(data)
        assert policy.enabled is False
