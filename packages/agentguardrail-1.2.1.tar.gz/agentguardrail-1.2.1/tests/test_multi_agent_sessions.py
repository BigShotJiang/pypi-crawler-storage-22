"""Tests for AgentGate Multi-Agent Session Manager."""

import asyncio
import shutil
import tempfile
import time
from pathlib import Path

import pytest
import pytest_asyncio

from agentgate.sessions import (
    MultiAgentSessionManager,
    AgentRole,
    AgentStatus,
    OrchestrationStatus,
    AgentRegistration,
    OrchestrationSession,
    OrchestrationSummary,
    ROLE_POLICY_DEFAULTS,
)
from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    Decision,
    Policy,
    PolicyDecision,
    PolicyEngine,
    RiskLevel,
    create_finance_safe_policy,
)


@pytest.fixture
def temp_dir():
    d = tempfile.mkdtemp()
    yield d
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def manager(temp_dir):
    return MultiAgentSessionManager(evidence_dir=temp_dir)


def make_event(
    action_type=ActionType.CLICK,
    url="https://example.com",
    text="Button",
    agent_id="",
):
    return ActionEvent(
        action_type=action_type,
        url=url,
        element_text=text,
        agent_id=agent_id,
    )


# ---------------------------------------------------------------------------
# Agent Registration Tests
# ---------------------------------------------------------------------------

class TestAgentRegistration:
    def test_register_agent(self, manager):
        reg = manager.register_agent("agent-1", role=AgentRole.WRITER)
        assert reg.agent_id == "agent-1"
        assert reg.role == AgentRole.WRITER
        assert reg.status == AgentStatus.REGISTERED

    def test_register_with_display_name(self, manager):
        reg = manager.register_agent("agent-1", display_name="Research Agent")
        assert reg.display_name == "Research Agent"

    def test_register_default_display_name(self, manager):
        reg = manager.register_agent("agent-1")
        assert reg.display_name == "agent-1"

    def test_register_duplicate_raises(self, manager):
        manager.register_agent("agent-1")
        with pytest.raises(ValueError, match="already registered"):
            manager.register_agent("agent-1")

    def test_register_reader_role_defaults(self, manager):
        reg = manager.register_agent("reader", role=AgentRole.READER)
        assert "navigate" in reg.allowed_action_types
        assert "click" in reg.blocked_action_types
        assert reg.max_actions_per_minute == 60

    def test_register_writer_role_defaults(self, manager):
        reg = manager.register_agent("writer", role=AgentRole.WRITER)
        assert reg.allowed_action_types == []  # All allowed
        assert "evaluate_js" in reg.blocked_action_types
        assert reg.max_actions_per_minute == 30

    def test_register_admin_role_defaults(self, manager):
        reg = manager.register_agent("admin", role=AgentRole.ADMIN)
        assert reg.allowed_action_types == []
        assert reg.blocked_action_types == []
        assert reg.max_actions_per_minute == 0  # Unlimited

    def test_register_observer_role_defaults(self, manager):
        reg = manager.register_agent("observer", role=AgentRole.OBSERVER)
        assert "screenshot" in reg.allowed_action_types
        assert "click" in reg.blocked_action_types

    def test_register_executor_role_defaults(self, manager):
        reg = manager.register_agent("exec", role=AgentRole.EXECUTOR)
        assert "click" in reg.allowed_action_types
        assert "evaluate_js" in reg.blocked_action_types

    def test_register_custom_overrides(self, manager):
        reg = manager.register_agent(
            "custom",
            role=AgentRole.READER,
            allowed_action_types=["click", "navigate"],
            blocked_action_types=[],
            max_actions_per_minute=100,
        )
        assert reg.allowed_action_types == ["click", "navigate"]
        assert reg.blocked_action_types == []
        assert reg.max_actions_per_minute == 100

    def test_unregister_agent(self, manager):
        manager.register_agent("agent-1")
        result = manager.unregister_agent("agent-1")
        assert result is True
        assert manager.get_agent("agent-1") is None

    def test_unregister_nonexistent(self, manager):
        result = manager.unregister_agent("nonexistent")
        assert result is False

    def test_get_agent(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        reg = manager.get_agent("agent-1")
        assert reg is not None
        assert reg.role == AgentRole.ADMIN

    def test_list_agents(self, manager):
        manager.register_agent("agent-1")
        manager.register_agent("agent-2")
        manager.register_agent("agent-3")
        agents = manager.list_agents()
        assert len(agents) == 3

    def test_update_agent_status(self, manager):
        manager.register_agent("agent-1")
        manager.update_agent_status("agent-1", AgentStatus.PAUSED)
        assert manager.get_agent("agent-1").status == AgentStatus.PAUSED

    def test_update_status_unregistered_raises(self, manager):
        with pytest.raises(ValueError, match="not registered"):
            manager.update_agent_status("nonexistent", AgentStatus.ACTIVE)

    def test_register_with_metadata(self, manager):
        reg = manager.register_agent(
            "agent-1",
            metadata={"framework": "crewai", "model": "gpt-4"},
        )
        assert reg.metadata["framework"] == "crewai"


# ---------------------------------------------------------------------------
# Orchestration Lifecycle Tests
# ---------------------------------------------------------------------------

class TestOrchestrationLifecycle:
    @pytest.mark.asyncio
    async def test_start_orchestration(self, manager):
        manager.register_agent("agent-1")
        manager.register_agent("agent-2")
        orch = await manager.start_orchestration("test-task")
        assert orch.orchestration_id.startswith("orch_")
        assert orch.name == "test-task"
        assert orch.status == OrchestrationStatus.RUNNING
        assert len(orch.agents) == 2

    @pytest.mark.asyncio
    async def test_orchestration_custom_id(self, manager):
        manager.register_agent("agent-1")
        orch = await manager.start_orchestration(
            name="my-task",
            orchestration_id="custom-orch-123",
        )
        assert orch.orchestration_id == "custom-orch-123"

    @pytest.mark.asyncio
    async def test_agents_activated_on_start(self, manager):
        manager.register_agent("agent-1")
        await manager.start_orchestration("test")
        reg = manager.get_agent("agent-1")
        assert reg.status == AgentStatus.ACTIVE
        assert reg.session_id.startswith("ses_")

    @pytest.mark.asyncio
    async def test_end_orchestration(self, manager):
        manager.register_agent("agent-1")
        manager.register_agent("agent-2")
        orch = await manager.start_orchestration("test")

        summary = await manager.end_orchestration(orch.orchestration_id)
        assert summary.orchestration_id == orch.orchestration_id
        assert summary.total_agents == 2
        assert summary.status == "completed"
        assert summary.all_chains_valid is True

    @pytest.mark.asyncio
    async def test_end_nonexistent_raises(self, manager):
        with pytest.raises(ValueError, match="not found"):
            await manager.end_orchestration("nonexistent-orch")

    @pytest.mark.asyncio
    async def test_get_orchestration(self, manager):
        manager.register_agent("agent-1")
        orch = await manager.start_orchestration("test")
        found = manager.get_orchestration(orch.orchestration_id)
        assert found is not None
        assert found.name == "test"

    @pytest.mark.asyncio
    async def test_list_orchestrations(self, manager):
        manager.register_agent("agent-1")
        await manager.start_orchestration("task-1")
        manager.register_agent("agent-2")
        await manager.start_orchestration("task-2")
        orchs = manager.list_orchestrations()
        assert len(orchs) == 2

    @pytest.mark.asyncio
    async def test_orchestration_with_settings(self, manager):
        manager.register_agent("agent-1")
        orch = await manager.start_orchestration(
            name="limited",
            max_total_actions=100,
            collective_rate_limit=30,
            require_sequential=True,
        )
        assert orch.max_total_actions == 100
        assert orch.collective_rate_limit == 30
        assert orch.require_sequential is True


# ---------------------------------------------------------------------------
# Action Evaluation Tests — Role-Based
# ---------------------------------------------------------------------------

class TestRoleBasedEvaluation:
    @pytest.mark.asyncio
    async def test_reader_can_navigate(self, manager):
        manager.register_agent("reader", role=AgentRole.READER)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.NAVIGATE, url="https://example.com")
        decision = await manager.evaluate("reader", event)
        assert decision.decision in (Decision.ALLOW, Decision.LOG_ONLY)

    @pytest.mark.asyncio
    async def test_reader_cannot_click(self, manager):
        manager.register_agent("reader", role=AgentRole.READER)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.CLICK, text="Button")
        decision = await manager.evaluate("reader", event)
        assert decision.decision == Decision.BLOCK
        assert "blocked for role" in decision.reason.lower() or "not in allowed" in decision.reason.lower()

    @pytest.mark.asyncio
    async def test_writer_can_click(self, manager):
        manager.register_agent("writer", role=AgentRole.WRITER)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.CLICK, text="View")
        decision = await manager.evaluate("writer", event)
        # Writer can click — unless blocked by policy engine
        assert decision.decision != Decision.BLOCK or "role" not in decision.matched_rule

    @pytest.mark.asyncio
    async def test_writer_cannot_eval_js(self, manager):
        manager.register_agent("writer", role=AgentRole.WRITER)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.EVALUATE_JS)
        decision = await manager.evaluate("writer", event)
        assert decision.decision == Decision.BLOCK

    @pytest.mark.asyncio
    async def test_admin_can_do_everything(self, manager):
        manager.register_agent("admin", role=AgentRole.ADMIN)
        await manager.start_orchestration("test")

        for action_type in [ActionType.CLICK, ActionType.NAVIGATE, ActionType.TYPE]:
            event = make_event(action_type=action_type, text="View Dashboard")
            decision = await manager.evaluate("admin", event)
            # Admin should not be blocked by role restrictions
            if decision.decision == Decision.BLOCK:
                assert "role" not in decision.matched_rule

    @pytest.mark.asyncio
    async def test_observer_can_screenshot(self, manager):
        manager.register_agent("observer", role=AgentRole.OBSERVER)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.SCREENSHOT)
        decision = await manager.evaluate("observer", event)
        assert decision.decision != Decision.BLOCK or "role" not in decision.matched_rule

    @pytest.mark.asyncio
    async def test_unregistered_agent_blocked(self, manager):
        await manager.start_orchestration("test")
        event = make_event()
        decision = await manager.evaluate("unknown-agent", event)
        assert decision.decision == Decision.BLOCK
        assert "not registered" in decision.reason


# ---------------------------------------------------------------------------
# Agent Status Tests
# ---------------------------------------------------------------------------

class TestAgentStatusRestrictions:
    @pytest.mark.asyncio
    async def test_paused_agent_blocked(self, manager):
        manager.register_agent("agent-1")
        await manager.start_orchestration("test")
        manager.pause_agent("agent-1")

        event = make_event()
        decision = await manager.evaluate("agent-1", event)
        assert decision.decision == Decision.BLOCK
        assert "paused" in decision.reason

    @pytest.mark.asyncio
    async def test_resumed_agent_allowed(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        await manager.start_orchestration("test")
        manager.pause_agent("agent-1")
        manager.resume_agent("agent-1")

        event = make_event(action_type=ActionType.NAVIGATE, text="Dashboard")
        decision = await manager.evaluate("agent-1", event)
        # Should not be blocked for status reasons
        if decision.decision == Decision.BLOCK:
            assert "paused" not in decision.reason

    @pytest.mark.asyncio
    async def test_completed_agent_blocked(self, manager):
        manager.register_agent("agent-1")
        await manager.start_orchestration("test")
        manager.update_agent_status("agent-1", AgentStatus.COMPLETED)

        event = make_event()
        decision = await manager.evaluate("agent-1", event)
        assert decision.decision == Decision.BLOCK
        assert "completed" in decision.reason


# ---------------------------------------------------------------------------
# Rate Limiting Tests
# ---------------------------------------------------------------------------

class TestMultiAgentRateLimiting:
    @pytest.mark.asyncio
    async def test_per_agent_rate_limit(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN, max_actions_per_minute=3)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        # 3 allowed
        for _ in range(3):
            d = await manager.evaluate("agent-1", event)
            assert d.decision != Decision.BLOCK or "rate limit" not in d.reason

        # 4th should hit rate limit
        d4 = await manager.evaluate("agent-1", event)
        assert d4.decision == Decision.BLOCK
        assert "rate limit" in d4.reason.lower()

    @pytest.mark.asyncio
    async def test_collective_rate_limit(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        manager.register_agent("agent-2", role=AgentRole.ADMIN)
        await manager.start_orchestration("test", collective_rate_limit=4)

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        # Agent 1 takes 2 actions
        for _ in range(2):
            await manager.evaluate("agent-1", event)
        # Agent 2 takes 2 actions
        for _ in range(2):
            await manager.evaluate("agent-2", event)

        # 5th action (any agent) should hit collective limit
        d = await manager.evaluate("agent-1", event)
        assert d.decision == Decision.BLOCK
        assert "collective" in d.reason.lower()

    @pytest.mark.asyncio
    async def test_max_total_actions(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        await manager.start_orchestration("test", max_total_actions=3)

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        for _ in range(3):
            await manager.evaluate("agent-1", event)

        d = await manager.evaluate("agent-1", event)
        assert d.decision == Decision.BLOCK
        assert "max total" in d.reason.lower()


# ---------------------------------------------------------------------------
# Sequential Execution Tests
# ---------------------------------------------------------------------------

class TestSequentialExecution:
    @pytest.mark.asyncio
    async def test_sequential_mode_blocks_concurrent(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        manager.register_agent("agent-2", role=AgentRole.ADMIN)
        await manager.start_orchestration("test", require_sequential=True)

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        # Agent 1 takes an action → acquires lock
        await manager.evaluate("agent-1", event)

        # Agent 2 should be blocked
        d = await manager.evaluate("agent-2", event)
        assert d.decision == Decision.BLOCK
        assert "sequential" in d.reason.lower()

    @pytest.mark.asyncio
    async def test_sequential_lock_release(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        manager.register_agent("agent-2", role=AgentRole.ADMIN)
        await manager.start_orchestration("test", require_sequential=True)

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        await manager.evaluate("agent-1", event)

        # Release lock
        manager.release_sequential_lock("agent-1")

        # Agent 2 should now work
        d = await manager.evaluate("agent-2", event)
        if d.decision == Decision.BLOCK:
            assert "sequential" not in d.reason.lower()

    @pytest.mark.asyncio
    async def test_transfer_active(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        manager.register_agent("agent-2", role=AgentRole.ADMIN)
        await manager.start_orchestration("test", require_sequential=True)

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        await manager.evaluate("agent-1", event)

        # Transfer lock to agent-2
        manager.transfer_active("agent-1", "agent-2")

        # Agent 2 should work
        d = await manager.evaluate("agent-2", event)
        if d.decision == Decision.BLOCK:
            assert "sequential" not in d.reason.lower()


# ---------------------------------------------------------------------------
# Stats Tracking Tests
# ---------------------------------------------------------------------------

class TestStatsTracking:
    @pytest.mark.asyncio
    async def test_agent_stats_tracking(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.NAVIGATE, text="Dashboard")
        await manager.evaluate("agent-1", event)
        await manager.evaluate("agent-1", event)

        stats = manager.get_agent_stats("agent-1")
        assert stats["actions_taken"] == 2
        assert stats["role"] == "admin"
        assert stats["status"] == "active"

    @pytest.mark.asyncio
    async def test_orchestration_stats(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        manager.register_agent("agent-2", role=AgentRole.ADMIN)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.NAVIGATE, text="Dashboard")
        await manager.evaluate("agent-1", event)
        await manager.evaluate("agent-2", event)

        orch = manager.list_orchestrations()[0]
        stats = manager.get_orchestration_stats(orch.orchestration_id)
        assert stats["total_actions"] == 2
        assert stats["total_agents"] == 2
        assert stats["active_agents"] == 2

    @pytest.mark.asyncio
    async def test_empty_stats(self, manager):
        stats = manager.get_orchestration_stats("nonexistent")
        assert stats == {}

        stats = manager.get_agent_stats("nonexistent")
        assert stats == {}

    @pytest.mark.asyncio
    async def test_orchestration_summary_after_end(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        orch = await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        await manager.evaluate("agent-1", event)

        summary = await manager.end_orchestration(orch.orchestration_id)
        assert summary.total_agents == 1
        assert summary.total_actions >= 1
        assert summary.duration_seconds >= 0
        assert len(summary.agents) == 1
        assert summary.agents[0]["agent_id"] == "agent-1"


# ---------------------------------------------------------------------------
# Evidence Integration Tests
# ---------------------------------------------------------------------------

class TestEvidenceIntegration:
    @pytest.mark.asyncio
    async def test_actions_recorded_in_vault(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        orch = await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.NAVIGATE, text="Page")
        await manager.evaluate("agent-1", event)
        await manager.evaluate("agent-1", event)

        reg = manager.get_agent("agent-1")
        records = await manager.vault.get_session_records(reg.session_id)
        assert len(records) == 2

    @pytest.mark.asyncio
    async def test_evidence_chain_valid(self, manager):
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        orch = await manager.start_orchestration("test")

        for i in range(5):
            event = make_event(action_type=ActionType.NAVIGATE, text=f"Page {i}")
            await manager.evaluate("agent-1", event)

        summary = await manager.end_orchestration(orch.orchestration_id)
        assert summary.all_chains_valid is True

    @pytest.mark.asyncio
    async def test_blocked_actions_still_recorded(self, manager):
        manager.register_agent("reader", role=AgentRole.READER)
        orch = await manager.start_orchestration("test")

        # Click is blocked for READER role
        event = make_event(action_type=ActionType.CLICK, text="Delete")
        await manager.evaluate("reader", event)

        reg = manager.get_agent("reader")
        records = await manager.vault.get_session_records(reg.session_id)
        assert len(records) == 1
        assert records[0].decision == "block"


# ---------------------------------------------------------------------------
# Policy Engine Integration Tests
# ---------------------------------------------------------------------------

class TestPolicyIntegration:
    @pytest.mark.asyncio
    async def test_with_finance_safe_policy(self, temp_dir):
        engine = PolicyEngine()
        engine.load_policy(create_finance_safe_policy())
        manager = MultiAgentSessionManager(
            evidence_dir=temp_dir,
            policy_engine=engine,
        )
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        await manager.start_orchestration("test")

        # Payment text → blocked by finance-safe policy
        event = make_event(action_type=ActionType.CLICK, text="Pay Now")
        decision = await manager.evaluate("agent-1", event)
        assert decision.decision == Decision.BLOCK

    @pytest.mark.asyncio
    async def test_with_default_policy(self, temp_dir):
        manager = MultiAgentSessionManager(
            evidence_dir=temp_dir,
            default_policy="finance-safe",
        )
        manager.register_agent("agent-1", role=AgentRole.ADMIN)
        await manager.start_orchestration("test")

        event = make_event(action_type=ActionType.CLICK, text="Pay Now")
        decision = await manager.evaluate("agent-1", event)
        assert decision.decision == Decision.BLOCK


# ---------------------------------------------------------------------------
# Model Tests
# ---------------------------------------------------------------------------

class TestModels:
    def test_agent_role_values(self):
        assert AgentRole.READER == "reader"
        assert AgentRole.WRITER == "writer"
        assert AgentRole.ADMIN == "admin"
        assert AgentRole.EXECUTOR == "executor"
        assert AgentRole.OBSERVER == "observer"
        assert AgentRole.CUSTOM == "custom"

    def test_agent_status_values(self):
        assert AgentStatus.REGISTERED == "registered"
        assert AgentStatus.ACTIVE == "active"
        assert AgentStatus.PAUSED == "paused"
        assert AgentStatus.COMPLETED == "completed"
        assert AgentStatus.TERMINATED == "terminated"
        assert AgentStatus.ERROR == "error"

    def test_orchestration_status_values(self):
        assert OrchestrationStatus.INITIALIZING == "initializing"
        assert OrchestrationStatus.RUNNING == "running"
        assert OrchestrationStatus.PAUSED == "paused"
        assert OrchestrationStatus.COMPLETED == "completed"
        assert OrchestrationStatus.FAILED == "failed"

    def test_role_policy_defaults_exist(self):
        for role in AgentRole:
            assert role in ROLE_POLICY_DEFAULTS

    def test_agent_registration_model(self):
        reg = AgentRegistration(agent_id="test", role=AgentRole.WRITER)
        assert reg.actions_taken == 0
        assert reg.actions_blocked == 0
        assert reg.actions_allowed == 0
        assert reg.highest_risk_seen == "none"

    def test_orchestration_summary_model(self):
        s = OrchestrationSummary(orchestration_id="orch-1")
        assert s.total_agents == 0
        assert s.total_actions == 0
        assert s.all_chains_valid is True
