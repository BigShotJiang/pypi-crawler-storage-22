"""Skills Registry CLI."""
