"""CLI configuration management — ~/.agenthub/config.toml"""

import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".agenthub"
CONFIG_FILE = CONFIG_DIR / "config.toml"

DEFAULTS = {
    "registry": {"url": "http://localhost:8000", "api_key": ""},
    "client": {"agent_type": "kiro"},
}


def _ensure_config():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(_serialize(DEFAULTS), encoding="utf-8")


def _serialize(config: dict) -> str:
    lines = []
    for section, values in config.items():
        lines.append(f"[{section}]")
        for k, v in values.items():
            lines.append(f'{k} = "{v}"')
        lines.append("")
    return "\n".join(lines)


def get_config() -> dict:
    _ensure_config()
    config = {s: dict(v) for s, v in DEFAULTS.items()}  # deep copy defaults
    current_section = "registry"
    for line in CONFIG_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            current_section = line[1:-1]
            if current_section not in config:
                config[current_section] = {}
        elif "=" in line and not line.startswith("#"):
            key, val = line.split("=", 1)
            config[current_section][key.strip()] = val.strip().strip('"')
    return config


def set_config(key: str, value: str):
    _ensure_config()
    config = get_config()
    parts = key.split(".")
    if len(parts) == 2:
        section, field = parts
        if section not in config:
            config[section] = {}
        config[section][field] = value
    else:
        # Default to registry section
        config["registry"][key] = value
    CONFIG_FILE.write_text(_serialize(config), encoding="utf-8")


def get_registry_url() -> str:
    return os.getenv("SKILLS_REGISTRY_URL", get_config()["registry"]["url"])


def get_api_key() -> str:
    return os.getenv("SKILLS_REGISTRY_API_KEY", get_config()["registry"]["api_key"])


def get_agent_type() -> str:
    return os.getenv("AGENTHUB_AGENT_TYPE", get_config().get("client", {}).get("agent_type", "kiro"))
