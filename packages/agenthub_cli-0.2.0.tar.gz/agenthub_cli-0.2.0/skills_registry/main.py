"""AgentHub CLI — main entry point (Iteration 3)."""

import subprocess
from pathlib import Path

import httpx
import typer
from rich.console import Console
from rich.table import Table

from .client import RegistryClient
from .config import set_config, get_config, get_registry_url, get_agent_type
from skills_registry_shared.parsers import parse_skill_md_file, parse_agent_md_file
from skills_registry_shared.adapters import AdapterFactory, Scope, InstallMethod

app = typer.Typer(name="agenthub", help="AgentHub CLI — AI Agent Skills Registry", pretty_exceptions_enable=False)
skill_app = typer.Typer(name="skill", help="Skill commands", pretty_exceptions_enable=False)
mcp_app = typer.Typer(name="mcp", help="MCP Server commands", pretty_exceptions_enable=False)
agent_app = typer.Typer(name="agent", help="Agent config commands", pretty_exceptions_enable=False)
config_app = typer.Typer(name="config", help="CLI configuration", pretty_exceptions_enable=False)
app.add_typer(skill_app)
app.add_typer(mcp_app)
app.add_typer(agent_app)
app.add_typer(config_app)

console = Console(stderr=True)
IGNORE_DIRS = {".git", "__pycache__", "node_modules", ".DS_Store", ".skills-registry"}


def _client() -> RegistryClient:
    return RegistryClient()


def _handle_error(e: Exception) -> None:
    if isinstance(e, httpx.ConnectError):
        console.print(f"[red]✗ Cannot connect to registry at {get_registry_url()}[/red]")
    elif isinstance(e, RuntimeError) and "API error" in str(e):
        console.print(f"[red]✗ {e}[/red]")
    elif isinstance(e, httpx.TimeoutException):
        console.print("[red]✗ Request timed out.[/red]")
    else:
        console.print(f"[red]✗ {e}[/red]")
    raise typer.Exit(1)


def _collect_files(directory: Path = Path(".")) -> dict[str, str]:
    files: dict[str, str] = {}
    for f in directory.rglob("*"):
        if f.is_file() and not any(part in IGNORE_DIRS for part in f.parts):
            try:
                files[str(f.relative_to(directory))] = f.read_text(encoding="utf-8")
            except (UnicodeDecodeError, PermissionError):
                pass
    return files


def _get_git_info() -> tuple[str, str, Path] | None:
    try:
        git_url = subprocess.check_output(["git", "remote", "get-url", "origin"], text=True, stderr=subprocess.DEVNULL).strip()
        commit_hash = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
        repo_root = Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"], text=True, stderr=subprocess.DEVNULL).strip())
        return git_url, commit_hash, repo_root
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _find_exact(items: list[dict], name: str) -> dict | None:
    for item in items:
        if item["name"] == name:
            return item
    return items[0] if items else None


# ── Config ──────────────────────────────────────────

@config_app.command("set")
def config_set(key: str, value: str):
    """Set a config value (e.g. registry.url, registry.api_key)."""
    set_config(key, value)
    console.print(f"✓ Set {key}")


@config_app.command("show")
def config_show():
    """Show current configuration."""
    cfg = get_config()
    console.print(f"Registry URL: {cfg['registry']['url']}")
    api_key = cfg["registry"]["api_key"]
    console.print(f"API Key: {api_key[:6] + '...' if len(api_key) > 6 else '(not set)'}")
    console.print(f"Agent Type: {cfg.get('client', {}).get('agent_type', 'kiro')}")


# ── Top-level: find (cross-type search) ─────────────

@app.command()
def find(keyword: str = typer.Argument("")):
    """Search across all asset types (skills, MCPs, agents)."""
    try:
        client = _client()
        if keyword:
            results = client.search_all(keyword)
        else:
            results = {
                "skills": client.search_skills(),
                "mcps": client.search_mcps(),
                "agents": client.search_agents(),
            }

        found = False
        for asset_type, data in results.items():
            items = data.get("items", []) if isinstance(data, dict) else []
            if not items:
                continue
            found = True
            table = Table(title=asset_type.capitalize())
            table.add_column("Name")
            table.add_column("Description")
            table.add_column("Installs", justify="right")
            for item in items[:20]:
                table.add_row(item["name"], item["description"][:60], str(item.get("installs", 0)))
            console.print(table)

        if not found:
            console.print(f"[yellow]No results found{' for ' + repr(keyword) if keyword else ''}.[/yellow]")
    except Exception as e:
        _handle_error(e)


@app.command("sync")
def sync_git(git_url: str = typer.Argument(..., help="Git repository URL to sync skills from")):
    """Sync skills from a remote Git repository."""
    try:
        results = _client().sync_from_git(git_url)
        if results:
            console.print(f"✓ Synced {len(results)} skill(s) from {git_url}")
            for s in results:
                console.print(f"  • {s['name']}")
        else:
            console.print(f"[yellow]No new skills found in {git_url}[/yellow]")
    except Exception as e:
        _handle_error(e)


# ── Skill ───────────────────────────────────────────

@skill_app.command("list")
def skill_list():
    """List available skills on the registry."""
    try:
        results = _client().search_skills()
        items = results.get("items", [])
        table = Table(title="Skills")
        table.add_column("Name")
        table.add_column("Description")
        table.add_column("Source")
        table.add_column("Installs", justify="right")
        for item in items:
            table.add_row(item["name"], item["description"][:50], item.get("source", ""), str(item.get("installs", 0)))
        console.print(table)
    except Exception as e:
        _handle_error(e)


@skill_app.command("add")
def skill_add(name: str, scope: str = "workspace", method: str = "copy", agent: str = "kiro"):
    """Install a skill from the registry."""
    try:
        client = _client()
        results = client.search_skills(keyword=name)
        skill = _find_exact(results.get("items", []), name)
        if not skill:
            console.print(f"[yellow]No skill found matching '{name}'[/yellow]")
            raise typer.Exit(1)

        package = client.get_skill_install(skill["id"])
        adapter = AdapterFactory.get_adapter(agent)
        path = adapter.install_skill(package["files"], package["name"], Scope(scope), InstallMethod(method))
        client.record_skill_install(skill["id"], agent_type=agent)
        console.print(f"✓ Installed [bold]{package['name']}[/bold] → {path}")
    except typer.Exit:
        raise
    except Exception as e:
        _handle_error(e)


@skill_app.command("remove")
def skill_remove(name: str, scope: str = "workspace"):
    """Remove a locally installed skill."""
    import shutil
    bases = [Path(".kiro/skills")] if scope == "workspace" else [Path.home() / ".kiro/skills"]
    if scope == "workspace":
        bases = [Path(".kiro/skills")]
    elif scope == "global":
        bases = [Path.home() / ".kiro/skills"]
    else:
        bases = [Path(".kiro/skills"), Path.home() / ".kiro/skills"]

    for base in bases:
        target = base / name
        if target.exists() or target.is_symlink():
            if target.is_symlink():
                target.unlink()
            else:
                shutil.rmtree(target)
            console.print(f"✓ Removed skill [bold]{name}[/bold] from {base}")
            return
    console.print(f"[yellow]Skill '{name}' not found locally.[/yellow]")


@skill_app.command("publish")
def skill_publish(
    upload: bool = typer.Option(False, "--upload", help="Upload files directly"),
    git: bool = typer.Option(False, "--git", help="Force Git reference mode"),
):
    """Publish a skill from the current directory."""
    skill_md = Path("SKILL.md")
    if not skill_md.exists():
        console.print("[red]✗ SKILL.md not found in current directory.[/red]")
        raise typer.Exit(1)

    if upload:
        try:
            files = _collect_files()
            result = _client().upload_skill(files)
            console.print(f"✓ Published [bold]{result['name']}[/bold] (uploaded, id: {result['id']})")
        except Exception as e:
            _handle_error(e)
        return

    git_info = _get_git_info()
    if not git_info:
        if git:
            console.print("[red]✗ Not a git repository.[/red]")
        else:
            console.print("[yellow]Not in a git repo. Use --upload to upload files, or --git in a git repo.[/yellow]")
        raise typer.Exit(1)

    git_url, commit_hash, repo_root = git_info
    try:
        meta = parse_skill_md_file(skill_md)
    except Exception as e:
        console.print(f"[red]✗ Failed to parse SKILL.md: {e}[/red]")
        raise typer.Exit(1)

    skill_path = str(skill_md.parent.resolve().relative_to(repo_root))
    if skill_path == ".":
        skill_path = ""

    data = {
        "name": meta.name, "description": meta.description, "version": meta.version,
        "tags": meta.metadata.get("tags", []), "git_url": git_url, "git_ref": None,
        "commit_hash": commit_hash, "skill_path": skill_path,
        "readme_content": skill_md.read_text(encoding="utf-8"),
    }
    try:
        result = _client().create_skill(data)
        console.print(f"✓ Published [bold]{result['name']}[/bold] (git, id: {result['id']})")
    except Exception as e:
        _handle_error(e)


@skill_app.command("installed")
def skill_installed():
    """List locally installed skills."""
    table = Table(title="Installed Skills")
    table.add_column("Name")
    table.add_column("Scope")
    table.add_column("Path")
    for scope_name, base in [("workspace", Path(".kiro/skills")), ("global", Path.home() / ".kiro/skills")]:
        if base.exists():
            for d in base.iterdir():
                if d.is_dir() and (d / "SKILL.md").exists():
                    table.add_row(d.name, scope_name, str(d))
    console.print(table)


@skill_app.command("add-from-git")
def skill_add_from_git(
    git_url: str = typer.Argument(..., help="Git repository URL"),
    name: str = typer.Option(None, "--name", "-n", help="Install only the skill with this name"),
    scope: str = "workspace",
    method: str = "copy",
):
    """Install skill(s) directly from a public Git repo (no server needed)."""
    import shutil
    import tempfile
    import glob as globmod

    console.print(f"Cloning {git_url}...")
    tmp = Path(tempfile.mkdtemp(prefix="agenthub-git-"))
    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", git_url, str(tmp)],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode != 0:
            console.print(f"[red]✗ git clone failed: {result.stderr.strip()}[/red]")
            raise typer.Exit(1)

        # Discover SKILL.md files
        patterns = [
            "SKILL.md", "skills/**/SKILL.md", ".kiro/skills/**/SKILL.md",
            ".claude/skills/**/SKILL.md", ".agents/skills/**/SKILL.md",
        ]
        found = []
        for pattern in patterns:
            for match in globmod.glob(str(tmp / pattern), recursive=True):
                p = Path(match)
                found.append(p.parent)

        if not found:
            console.print("[yellow]No SKILL.md files found in repository.[/yellow]")
            raise typer.Exit(1)

        adapter = AdapterFactory.get_adapter(get_agent_type())
        installed = 0
        for skill_dir in found:
            try:
                meta = parse_skill_md_file(skill_dir / "SKILL.md")
            except Exception:
                continue

            if name and meta.name != name:
                continue

            # Collect files
            files: dict[str, str] = {}
            for f in skill_dir.rglob("*"):
                if f.is_file():
                    try:
                        files[str(f.relative_to(skill_dir))] = f.read_text(encoding="utf-8")
                    except UnicodeDecodeError:
                        pass

            path = adapter.install_skill(files, meta.name, Scope(scope), InstallMethod(method))
            console.print(f"  ✓ {meta.name} → {path}")
            installed += 1

        if installed == 0 and name:
            console.print(f"[yellow]Skill '{name}' not found in repository.[/yellow]")
        else:
            console.print(f"✓ Installed {installed} skill(s) from {git_url}")
    except typer.Exit:
        raise
    except subprocess.TimeoutExpired:
        console.print("[red]✗ git clone timed out.[/red]")
        raise typer.Exit(1)
    except Exception as e:
        _handle_error(e)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ── MCP ─────────────────────────────────────────────

@mcp_app.command("list")
def mcp_list():
    """List available MCP servers on the registry."""
    try:
        results = _client().search_mcps()
        items = results.get("items", [])
        table = Table(title="MCP Servers")
        table.add_column("Name")
        table.add_column("Description")
        table.add_column("Transport")
        table.add_column("Installs", justify="right")
        for item in items:
            table.add_row(item["name"], item["description"][:50], item.get("transport", ""), str(item.get("installs", 0)))
        console.print(table)
    except Exception as e:
        _handle_error(e)


@mcp_app.command("add")
def mcp_add(name: str, scope: str = "workspace"):
    """Install an MCP server config to local mcp.json."""
    try:
        client = _client()
        results = client.search_mcps(keyword=name)
        mcp = _find_exact(results.get("items", []), name)
        if not mcp:
            console.print(f"[yellow]No MCP server found matching '{name}'[/yellow]")
            raise typer.Exit(1)

        config = client.get_mcp_install(mcp["id"])
        adapter = AdapterFactory.get_adapter(get_agent_type())
        inner = config["config"].get("mcpServers", {})
        adapter.install_mcp(inner, Scope(scope))
        client.record_mcp_install(mcp["id"])

        server_config = list(inner.values())[0] if inner else {}
        kind = "remote" if "url" in server_config else "local"
        console.print(f"✓ Added {kind} MCP Server [bold]{config['name']}[/bold] to mcp.json ({scope})")

        if "url" in server_config:
            try:
                resp = httpx.head(server_config["url"], timeout=5.0, follow_redirects=True)
                console.print(f"  ✓ Remote server reachable (HTTP {resp.status_code})")
            except Exception:
                console.print("  ⚠ Remote server not reachable (may require auth)")

        if config.get("env_vars_needed"):
            console.print("  Environment variables to configure:")
            for var in config["env_vars_needed"]:
                console.print(f"    export {var}=<your-value>")
    except typer.Exit:
        raise
    except Exception as e:
        _handle_error(e)


@mcp_app.command("remove")
def mcp_remove(name: str, scope: str = "workspace"):
    """Remove an MCP server from local mcp.json."""
    import json
    adapter = AdapterFactory.get_adapter(get_agent_type())
    mcp_path = adapter.get_mcp_config_path(Scope(scope))
    if not mcp_path.exists():
        console.print(f"[yellow]No mcp.json found ({scope})[/yellow]")
        return
    config = json.loads(mcp_path.read_text(encoding="utf-8"))
    servers = config.get("mcpServers", {})
    if name not in servers:
        console.print(f"[yellow]MCP server '{name}' not found in mcp.json ({scope})[/yellow]")
        return
    del servers[name]
    mcp_path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    console.print(f"✓ Removed MCP Server [bold]{name}[/bold] from mcp.json ({scope})")


@mcp_app.command("publish")
def mcp_publish(
    name: str = typer.Option(..., prompt="MCP Server name"),
    description: str = typer.Option(..., prompt="Description"),
    transport: str = typer.Option(..., prompt="Transport (stdio / streamable-http / sse)"),
    command: str = typer.Option(None, help="Command (stdio only)"),
    url: str = typer.Option(None, help="Remote URL (streamable-http/sse only)"),
):
    """Register an MCP server to the platform."""
    data: dict = {"name": name, "description": description, "transport": transport}
    if transport == "stdio":
        if not command:
            command = typer.prompt("Command")
        args_str = typer.prompt("Args (comma-separated, or empty)", default="")
        data["command"] = command
        data["args"] = [a.strip() for a in args_str.split(",") if a.strip()] if args_str else []
    else:
        if not url:
            url = typer.prompt("Remote URL")
        data["url"] = url
        headers_str = typer.prompt("Headers (key=value,key=value or empty)", default="")
        if headers_str:
            data["headers"] = {k.strip(): v.strip() for pair in headers_str.split(",") if "=" in pair for k, v in [pair.split("=", 1)]}
    env_str = typer.prompt("Env vars (key=value,key=value or empty)", default="")
    if env_str:
        data["env"] = {k.strip(): v.strip() for pair in env_str.split(",") if "=" in pair for k, v in [pair.split("=", 1)]}
    try:
        result = _client().create_mcp(data)
        console.print(f"✓ Published MCP Server [bold]{result['name']}[/bold] ({transport}, id: {result['id']})")
    except Exception as e:
        _handle_error(e)


@mcp_app.command("installed")
def mcp_installed():
    """List locally installed MCP servers."""
    import json
    adapter = AdapterFactory.get_adapter(get_agent_type())
    table = Table(title="Installed MCP Servers")
    table.add_column("Name")
    table.add_column("Scope")
    table.add_column("Type")
    for scope_name, scope_val in [("workspace", Scope.WORKSPACE), ("global", Scope.GLOBAL)]:
        mcp_path = adapter.get_mcp_config_path(scope_val)
        if mcp_path.exists():
            config = json.loads(mcp_path.read_text(encoding="utf-8"))
            for name, cfg in config.get("mcpServers", {}).items():
                kind = "remote" if "url" in cfg else "local"
                table.add_row(name, scope_name, kind)
    console.print(table)


# ── Agent ───────────────────────────────────────────

@agent_app.command("list")
def agent_list():
    """List available agent configs on the registry."""
    try:
        results = _client().search_agents()
        items = results.get("items", [])
        table = Table(title="Agent Configs")
        table.add_column("Name")
        table.add_column("Description")
        table.add_column("Skills")
        table.add_column("MCPs")
        table.add_column("Installs", justify="right")
        for item in items:
            table.add_row(
                item["name"], item["description"][:50],
                str(len(item.get("skill_names", []))),
                str(len(item.get("mcp_names", []))),
                str(item.get("installs", 0)),
            )
        console.print(table)
    except Exception as e:
        _handle_error(e)


@agent_app.command("add")
def agent_add(name: str, scope: str = "workspace", method: str = "copy"):
    """Install an agent config (skills + MCPs + prompt) with backup/rollback."""
    adapter = AdapterFactory.get_adapter(get_agent_type())
    s = Scope(scope)
    m = InstallMethod(method)
    backup_dir = None

    try:
        client = _client()
        results = client.search_agents(keyword=name)
        agent = _find_exact(results.get("items", []), name)
        if not agent:
            console.print(f"[yellow]No agent config found matching '{name}'[/yellow]")
            raise typer.Exit(1)

        package_data = client.get_agent_install(agent["id"])
        backup_dir = adapter.backup(s)
        console.print("  Backed up current state")

        for skill_name in package_data.get("skill_names", []):
            skill_results = client.search_skills(keyword=skill_name)
            skill = _find_exact(skill_results.get("items", []), skill_name)
            if not skill:
                raise RuntimeError(f"Referenced skill '{skill_name}' not found")
            pkg = client.get_skill_install(skill["id"])
            adapter.install_skill(pkg["files"], pkg["name"], s, m)
            client.record_skill_install(skill["id"])
            console.print(f"  ✓ Skill: {skill_name}")

        for mcp_name in package_data.get("mcp_names", []):
            mcp_results = client.search_mcps(keyword=mcp_name)
            mcp = _find_exact(mcp_results.get("items", []), mcp_name)
            if not mcp:
                raise RuntimeError(f"Referenced MCP '{mcp_name}' not found")
            mcp_config = client.get_mcp_install(mcp["id"])
            adapter.install_mcp(mcp_config["config"].get("mcpServers", {}), s)
            client.record_mcp_install(mcp["id"])
            console.print(f"  ✓ MCP: {mcp_name}")
            for var in mcp_config.get("env_vars_needed", []):
                console.print(f"    → export {var}=<your-value>")

        from skills_registry_shared.schemas.agent import AgentInstallPackage
        adapter.install_agent_config(AgentInstallPackage(**package_data), s, m)
        console.print(f"  ✓ Agent config: {package_data['name']}")

        client.record_agent_install(agent["id"])
        console.print(f"✓ Installed Agent: [bold]{package_data['name']}[/bold]")
        console.print(adapter.get_post_install_hints())

    except typer.Exit:
        raise
    except Exception as e:
        if backup_dir:
            console.print(f"[red]✗ Installation failed: {e}[/red]")
            console.print("Rolling back...")
            adapter.rollback(backup_dir, s)
            console.print("✓ Rolled back to previous state")
        else:
            _handle_error(e)
        raise typer.Exit(1)
    finally:
        if backup_dir:
            adapter.cleanup_backup(backup_dir)


@agent_app.command("remove")
def agent_remove(name: str, scope: str = "workspace"):
    """Remove a locally installed agent config."""
    adapter = AdapterFactory.get_adapter(get_agent_type())
    agents_dir = adapter.get_agents_dir(Scope(scope))
    removed = False
    for ext in (".md", ".json"):
        target = agents_dir / f"{name}{ext}"
        if target.exists():
            target.unlink()
            console.print(f"✓ Removed agent [bold]{name}[/bold] ({target})")
            removed = True
    if not removed:
        console.print(f"[yellow]Agent '{name}' not found in {agents_dir}[/yellow]")


@agent_app.command("attach-skill")
def agent_attach_skill(agent_name: str, skill_name: str, scope: str = "workspace"):
    """Attach a skill to an existing local agent config."""
    import json as jsonlib
    import yaml

    adapter = AdapterFactory.get_adapter(get_agent_type())
    agents_dir = adapter.get_agents_dir(Scope(scope))

    # Update JSON config
    json_file = agents_dir / f"{agent_name}.json"
    if json_file.exists():
        config = jsonlib.loads(json_file.read_text(encoding="utf-8"))
        resources = config.get("resources", [])
        skill_ref = f"file://.kiro/skills/{skill_name}/SKILL.md"
        if skill_ref not in resources:
            resources.append(skill_ref)
            config["resources"] = resources
            json_file.write_text(jsonlib.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
        console.print(f"✓ Attached skill [bold]{skill_name}[/bold] to {agent_name}.json")
    else:
        console.print(f"[yellow]{agent_name}.json not found in {agents_dir}[/yellow]")

    # Update MD config
    md_file = agents_dir / f"{agent_name}.md"
    if md_file.exists():
        content = md_file.read_text(encoding="utf-8")
        from skills_registry_shared.parsers import parse_agent_md
        try:
            meta = parse_agent_md(content)
            if skill_name not in meta.skill_names:
                meta.skill_names.append(skill_name)
                fm_data: dict[str, object] = {"name": meta.name, "description": meta.description}
                if meta.skill_names:
                    fm_data["skills"] = meta.skill_names
                if meta.mcp_names:
                    fm_data["mcps"] = meta.mcp_names
                fm_str = yaml.dump(fm_data, allow_unicode=True, default_flow_style=False).strip()
                new_content = f"---\n{fm_str}\n---\n\n{meta.body}\n"
                md_file.write_text(new_content, encoding="utf-8")
            console.print(f"✓ Attached skill [bold]{skill_name}[/bold] to {agent_name}.md")
        except Exception as e:
            console.print(f"[yellow]Could not update {agent_name}.md: {e}[/yellow]")


@agent_app.command("attach-mcp")
def agent_attach_mcp(agent_name: str, mcp_name: str, scope: str = "workspace"):
    """Attach an MCP server to an existing local agent config."""
    import json as jsonlib
    import yaml

    adapter = AdapterFactory.get_adapter(get_agent_type())
    agents_dir = adapter.get_agents_dir(Scope(scope))

    # Update JSON config — add MCP to mcpServers and tools
    json_file = agents_dir / f"{agent_name}.json"
    if json_file.exists():
        config = jsonlib.loads(json_file.read_text(encoding="utf-8"))

        # Try to get MCP config from local mcp.json
        mcp_path = adapter.get_mcp_config_path(Scope(scope))
        if mcp_path.exists():
            mcp_config = jsonlib.loads(mcp_path.read_text(encoding="utf-8"))
            servers = mcp_config.get("mcpServers", {})
            if mcp_name in servers:
                if "mcpServers" not in config:
                    config["mcpServers"] = {}
                config["mcpServers"][mcp_name] = servers[mcp_name]

        tools = config.get("tools", [])
        tool_ref = f"@{mcp_name}"
        if tool_ref not in tools:
            tools.append(tool_ref)
            config["tools"] = tools

        json_file.write_text(jsonlib.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
        console.print(f"✓ Attached MCP [bold]{mcp_name}[/bold] to {agent_name}.json")
    else:
        console.print(f"[yellow]{agent_name}.json not found in {agents_dir}[/yellow]")

    # Update MD config
    md_file = agents_dir / f"{agent_name}.md"
    if md_file.exists():
        content = md_file.read_text(encoding="utf-8")
        from skills_registry_shared.parsers import parse_agent_md
        try:
            meta = parse_agent_md(content)
            if mcp_name not in meta.mcp_names:
                meta.mcp_names.append(mcp_name)
                fm_data: dict[str, object] = {"name": meta.name, "description": meta.description}
                if meta.skill_names:
                    fm_data["skills"] = meta.skill_names
                if meta.mcp_names:
                    fm_data["mcps"] = meta.mcp_names
                fm_str = yaml.dump(fm_data, allow_unicode=True, default_flow_style=False).strip()
                new_content = f"---\n{fm_str}\n---\n\n{meta.body}\n"
                md_file.write_text(new_content, encoding="utf-8")
            console.print(f"✓ Attached MCP [bold]{mcp_name}[/bold] to {agent_name}.md")
        except Exception as e:
            console.print(f"[yellow]Could not update {agent_name}.md: {e}[/yellow]")


@agent_app.command("detach-skill")
def agent_detach_skill(agent_name: str, skill_name: str, scope: str = "workspace"):
    """Detach a skill from an existing local agent config."""
    import json as jsonlib
    import yaml

    adapter = AdapterFactory.get_adapter(get_agent_type())
    agents_dir = adapter.get_agents_dir(Scope(scope))

    json_file = agents_dir / f"{agent_name}.json"
    if json_file.exists():
        config = jsonlib.loads(json_file.read_text(encoding="utf-8"))
        resources = config.get("resources", [])
        skill_ref = f"file://.kiro/skills/{skill_name}/SKILL.md"
        if skill_ref in resources:
            resources.remove(skill_ref)
            config["resources"] = resources
            json_file.write_text(jsonlib.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
        console.print(f"✓ Detached skill [bold]{skill_name}[/bold] from {agent_name}.json")

    md_file = agents_dir / f"{agent_name}.md"
    if md_file.exists():
        content = md_file.read_text(encoding="utf-8")
        from skills_registry_shared.parsers import parse_agent_md
        try:
            meta = parse_agent_md(content)
            if skill_name in meta.skill_names:
                meta.skill_names.remove(skill_name)
                fm_data: dict[str, object] = {"name": meta.name, "description": meta.description}
                if meta.skill_names:
                    fm_data["skills"] = meta.skill_names
                if meta.mcp_names:
                    fm_data["mcps"] = meta.mcp_names
                fm_str = yaml.dump(fm_data, allow_unicode=True, default_flow_style=False).strip()
                md_file.write_text(f"---\n{fm_str}\n---\n\n{meta.body}\n", encoding="utf-8")
            console.print(f"✓ Detached skill [bold]{skill_name}[/bold] from {agent_name}.md")
        except Exception as e:
            console.print(f"[yellow]Could not update {agent_name}.md: {e}[/yellow]")


@agent_app.command("detach-mcp")
def agent_detach_mcp(agent_name: str, mcp_name: str, scope: str = "workspace"):
    """Detach an MCP server from an existing local agent config."""
    import json as jsonlib
    import yaml

    adapter = AdapterFactory.get_adapter(get_agent_type())
    agents_dir = adapter.get_agents_dir(Scope(scope))

    json_file = agents_dir / f"{agent_name}.json"
    if json_file.exists():
        config = jsonlib.loads(json_file.read_text(encoding="utf-8"))
        mcps = config.get("mcpServers", {})
        if mcp_name in mcps:
            del mcps[mcp_name]
        tools = config.get("tools", [])
        tool_ref = f"@{mcp_name}"
        if tool_ref in tools:
            tools.remove(tool_ref)
        json_file.write_text(jsonlib.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
        console.print(f"✓ Detached MCP [bold]{mcp_name}[/bold] from {agent_name}.json")

    md_file = agents_dir / f"{agent_name}.md"
    if md_file.exists():
        content = md_file.read_text(encoding="utf-8")
        from skills_registry_shared.parsers import parse_agent_md
        try:
            meta = parse_agent_md(content)
            if mcp_name in meta.mcp_names:
                meta.mcp_names.remove(mcp_name)
                fm_data: dict[str, object] = {"name": meta.name, "description": meta.description}
                if meta.skill_names:
                    fm_data["skills"] = meta.skill_names
                if meta.mcp_names:
                    fm_data["mcps"] = meta.mcp_names
                fm_str = yaml.dump(fm_data, allow_unicode=True, default_flow_style=False).strip()
                md_file.write_text(f"---\n{fm_str}\n---\n\n{meta.body}\n", encoding="utf-8")
            console.print(f"✓ Detached MCP [bold]{mcp_name}[/bold] from {agent_name}.md")
        except Exception as e:
            console.print(f"[yellow]Could not update {agent_name}.md: {e}[/yellow]")


@agent_app.command("publish")
def agent_publish():
    """Publish an agent config from AGENT.md in the current directory."""
    agent_md = Path("AGENT.md")
    if not agent_md.exists():
        console.print("[red]✗ AGENT.md not found in current directory.[/red]")
        raise typer.Exit(1)
    try:
        meta = parse_agent_md_file(agent_md)
    except Exception as e:
        console.print(f"[red]✗ Failed to parse AGENT.md: {e}[/red]")
        raise typer.Exit(1)

    data = {
        "name": meta.name, "description": meta.description, "tags": meta.tags,
        "prompt": meta.body, "agent_md_content": agent_md.read_text(encoding="utf-8"),
        "skill_names": meta.skill_names, "mcp_names": meta.mcp_names,
    }
    try:
        result = _client().create_agent(data)
        console.print(f"✓ Published agent [bold]{result['name']}[/bold] (id: {result['id']})")
        for rs in result.get("referenced_skills", []):
            status = " [yellow](deprecated)[/yellow]" if rs["status"] == "deprecated" else ""
            console.print(f"  • Skill: {rs['name']}{status}")
        for rm in result.get("referenced_mcps", []):
            status = " [yellow](deprecated)[/yellow]" if rm["status"] == "deprecated" else ""
            console.print(f"  • MCP: {rm['name']}{status}")
    except Exception as e:
        _handle_error(e)


@agent_app.command("installed")
def agent_installed():
    """List locally installed agents."""
    adapter = AdapterFactory.get_adapter(get_agent_type())
    table = Table(title="Installed Agents")
    table.add_column("Name")
    table.add_column("Scope")
    table.add_column("Format")
    for scope_name, scope_val in [("workspace", Scope.WORKSPACE), ("global", Scope.GLOBAL)]:
        agents_dir = adapter.get_agents_dir(scope_val)
        if agents_dir.exists():
            seen: set[str] = set()
            for f in agents_dir.iterdir():
                if f.is_file() and f.suffix in (".md", ".json"):
                    name = f.stem
                    if name not in seen:
                        seen.add(name)
                        formats = []
                        if (agents_dir / f"{name}.md").exists(): formats.append("md")
                        if (agents_dir / f"{name}.json").exists(): formats.append("json")
                        table.add_row(name, scope_name, "+".join(formats))
    console.print(table)


if __name__ == "__main__":
    app()
