"""Kiro IDE/CLI adapter implementation — Iteration 3."""

import json
import shutil
import tempfile
from pathlib import Path

import yaml

from .base import BaseAdapter, Scope, InstallMethod, InstallSummary
from ..schemas.agent import AgentInstallPackage

CACHE_DIR = ".skills-registry/cache"


class KiroAdapter(BaseAdapter):
    agent_type = "kiro"
    config_dir_name = ".kiro"

    def _home(self) -> Path:
        return Path.home()

    def get_skills_dir(self, scope: Scope) -> Path:
        if scope == Scope.GLOBAL:
            return self._home() / ".kiro" / "skills"
        return Path(".kiro") / "skills"

    def get_mcp_config_path(self, scope: Scope) -> Path:
        if scope == Scope.GLOBAL:
            return self._home() / ".kiro" / "settings" / "mcp.json"
        return Path(".kiro") / "settings" / "mcp.json"

    def get_agents_dir(self, scope: Scope) -> Path:
        if scope == Scope.GLOBAL:
            return self._home() / ".kiro" / "agents"
        return Path(".kiro") / "agents"

    def install_skill(
        self,
        skill_files: dict[str, str],
        name: str,
        scope: Scope,
        method: InstallMethod,
    ) -> Path:
        target_dir = self.get_skills_dir(scope) / name

        if method == InstallMethod.SYMLINK:
            cache_dir = Path(CACHE_DIR) / name
            cache_dir.mkdir(parents=True, exist_ok=True)
            for rel_path, content in skill_files.items():
                file_path = cache_dir / rel_path
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content, encoding="utf-8")
            target_dir.parent.mkdir(parents=True, exist_ok=True)
            if target_dir.is_symlink() or target_dir.exists():
                if target_dir.is_symlink():
                    target_dir.unlink()
                else:
                    shutil.rmtree(target_dir)
            target_dir.symlink_to(cache_dir.resolve())
        else:
            if target_dir.exists():
                shutil.rmtree(target_dir)
            target_dir.mkdir(parents=True, exist_ok=True)
            for rel_path, content in skill_files.items():
                file_path = target_dir / rel_path
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content, encoding="utf-8")

        return target_dir

    def install_mcp(self, config: dict, scope: Scope) -> None:
        mcp_path = self.get_mcp_config_path(scope)
        mcp_path.parent.mkdir(parents=True, exist_ok=True)

        existing: dict = {}
        if mcp_path.exists():
            existing = json.loads(mcp_path.read_text(encoding="utf-8"))

        if "mcpServers" not in existing:
            existing["mcpServers"] = {}

        existing["mcpServers"].update(config)
        mcp_path.write_text(json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")

    def install_agent_config(
        self,
        package: AgentInstallPackage,
        scope: Scope,
        method: InstallMethod,
    ) -> InstallSummary:
        """Write agent config as both .json (CLI) and .md (IDE)."""
        summary = InstallSummary(agent_type=self.agent_type)

        agents_dir = self.get_agents_dir(scope)
        agents_dir.mkdir(parents=True, exist_ok=True)

        # 1. Generate CLI JSON format
        tools_list = ["@builtin"]
        agent_json: dict[str, object] = {
            "name": package.name,
            "description": f"Agent with {len(package.skill_names)} skills and {len(package.mcp_names)} MCPs",
            "prompt": package.prompt,
            "tools": tools_list,
            "allowedTools": ["fs_read"],
            "resources": ["file://.kiro/skills/**/SKILL.md"],
        }
        # Include MCP servers inline (CLI reads from agent config directly)
        if package.mcp_names:
            mcp_path = self.get_mcp_config_path(scope)
            if mcp_path.exists():
                existing = json.loads(mcp_path.read_text(encoding="utf-8"))
                mcp_servers = existing.get("mcpServers", {})
                agent_mcps = {}
                for name in package.mcp_names:
                    if name in mcp_servers:
                        agent_mcps[name] = mcp_servers[name]
                        tools_list.append(f"@{name}")
                if agent_mcps:
                    agent_json["mcpServers"] = agent_mcps

        json_file = agents_dir / f"{package.name}.json"
        json_file.write_text(json.dumps(agent_json, indent=2, ensure_ascii=False), encoding="utf-8")

        # 2. Generate IDE Markdown format
        fm_data: dict[str, object] = {
            "name": package.name,
            "description": f"Agent with skills: {', '.join(package.skill_names)}" if package.skill_names else "Custom agent",
        }
        if package.skill_names:
            fm_data["skills"] = package.skill_names
        if package.mcp_names:
            fm_data["mcps"] = package.mcp_names

        fm_str = yaml.dump(fm_data, allow_unicode=True, default_flow_style=False).strip()
        md_content = f"---\n{fm_str}\n---\n\n{package.prompt}\n"
        md_file = agents_dir / f"{package.name}.md"
        md_file.write_text(md_content, encoding="utf-8")

        summary.agent_config_path = str(json_file)
        summary.skills_installed = list(package.skill_names)
        summary.mcps_installed = list(package.mcp_names)
        summary.hints = self.get_post_install_hints()
        return summary

    # --- Backup / Rollback ---

    def backup(self, scope: Scope) -> Path:
        """Backup current skills, mcp.json, and agents to a temp directory."""
        backup_dir = Path(tempfile.mkdtemp(prefix="agenthub-backup-"))
        skills_dir = self.get_skills_dir(scope)
        mcp_path = self.get_mcp_config_path(scope)
        agents_dir = self.get_agents_dir(scope)

        if skills_dir.exists():
            shutil.copytree(skills_dir, backup_dir / "skills", dirs_exist_ok=True)
        if mcp_path.exists():
            (backup_dir / "settings").mkdir(parents=True, exist_ok=True)
            shutil.copy2(mcp_path, backup_dir / "settings" / "mcp.json")
        if agents_dir.exists():
            shutil.copytree(agents_dir, backup_dir / "agents", dirs_exist_ok=True)

        return backup_dir

    def rollback(self, backup_dir: Path, scope: Scope) -> None:
        """Restore from backup."""
        skills_dir = self.get_skills_dir(scope)
        mcp_path = self.get_mcp_config_path(scope)
        agents_dir = self.get_agents_dir(scope)

        backup_skills = backup_dir / "skills"
        backup_mcp = backup_dir / "settings" / "mcp.json"
        backup_agents = backup_dir / "agents"

        if backup_skills.exists():
            if skills_dir.exists():
                shutil.rmtree(skills_dir)
            shutil.copytree(backup_skills, skills_dir)

        if backup_mcp.exists():
            mcp_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup_mcp, mcp_path)

        if backup_agents.exists():
            if agents_dir.exists():
                shutil.rmtree(agents_dir)
            shutil.copytree(backup_agents, agents_dir)

    @staticmethod
    def cleanup_backup(backup_dir: Path) -> None:
        """Remove backup directory."""
        if backup_dir.exists():
            shutil.rmtree(backup_dir, ignore_errors=True)

    def get_post_install_hints(self) -> str:
        return (
            "Kiro IDE: Skills installed — IDE will auto-discover them.\n"
            "Kiro CLI: Add to agent resources: \"skill://.kiro/skills/**/SKILL.md\""
        )
