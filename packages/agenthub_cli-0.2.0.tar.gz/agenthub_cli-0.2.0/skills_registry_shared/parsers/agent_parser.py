"""AGENT.md parser — extracts YAML frontmatter and prompt body."""

import re
import yaml
from pathlib import Path
from pydantic import BaseModel

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n?(.*)", re.DOTALL)
NAME_RE = re.compile(r"^[a-z0-9-]+$")


class AgentMetadata(BaseModel):
    name: str
    description: str
    tags: list[str] = []
    skill_names: list[str] = []
    mcp_names: list[str] = []
    body: str = ""  # prompt content


class AgentParseError(Exception):
    def __init__(self, message: str):
        super().__init__(message)


def parse_agent_md(content: str) -> AgentMetadata:
    """Parse AGENT.md content and return structured metadata."""
    content = content.strip()
    if not content:
        raise AgentParseError("AGENT.md is empty")

    match = FRONTMATTER_RE.match(content)
    if not match:
        raise AgentParseError("AGENT.md must start with YAML frontmatter (--- delimiters)")

    yaml_str, body = match.group(1), match.group(2).strip()

    try:
        data = yaml.safe_load(yaml_str)
    except yaml.YAMLError as e:
        raise AgentParseError(f"Invalid YAML in frontmatter: {e}") from e

    if not isinstance(data, dict):
        raise AgentParseError("Frontmatter must be a YAML mapping")

    name = data.get("name")
    if not name or not isinstance(name, str):
        raise AgentParseError("'name' is required in frontmatter")
    if not NAME_RE.match(name):
        raise AgentParseError("'name' must be lowercase alphanumeric with hyphens only")

    description = data.get("description")
    if not description or not isinstance(description, str):
        raise AgentParseError("'description' is required in frontmatter")

    tags = data.get("tags", [])
    if not isinstance(tags, list):
        tags = []

    skills = data.get("skills", [])
    if not isinstance(skills, list):
        skills = []

    mcps = data.get("mcps", [])
    if not isinstance(mcps, list):
        mcps = []

    return AgentMetadata(
        name=name,
        description=description,
        tags=[str(t) for t in tags],
        skill_names=[str(s) for s in skills],
        mcp_names=[str(m) for m in mcps],
        body=body,
    )


def parse_agent_md_file(path: Path) -> AgentMetadata:
    """Parse an AGENT.md file from disk."""
    if not path.exists():
        raise AgentParseError(f"File not found: {path}")
    content = path.read_text(encoding="utf-8")
    return parse_agent_md(content)
