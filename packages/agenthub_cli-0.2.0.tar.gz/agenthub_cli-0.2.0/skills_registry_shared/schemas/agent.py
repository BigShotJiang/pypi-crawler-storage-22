"""Agent configuration schemas — reference-based (Iteration 3)."""

from datetime import datetime
from pydantic import BaseModel, Field

from .user import UserBrief


class ReferencedAsset(BaseModel):
    """Summary of a referenced Skill or MCP."""
    name: str
    description: str
    status: str = "active"  # active | deprecated | missing


class AgentConfigCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=64)
    description: str = Field(..., max_length=1024)
    tags: list[str] = Field(default_factory=list, max_length=10)
    prompt: str
    agent_md_content: str = ""
    skill_names: list[str] = Field(default_factory=list)
    mcp_names: list[str] = Field(default_factory=list)
    git_url: str | None = None
    git_ref: str | None = None
    commit_hash: str | None = None


class AgentConfigResponse(BaseModel):
    id: int
    name: str
    description: str
    tags: list[str]
    prompt: str
    agent_md_content: str = ""
    skill_names: list[str]
    mcp_names: list[str]
    referenced_skills: list[ReferencedAsset] = []
    referenced_mcps: list[ReferencedAsset] = []
    author: UserBrief
    installs: int
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AgentInstallPackage(BaseModel):
    name: str
    prompt: str
    skill_names: list[str]
    mcp_names: list[str]
