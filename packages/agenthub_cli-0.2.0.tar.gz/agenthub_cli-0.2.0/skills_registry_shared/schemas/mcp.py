"""MCP Server configuration schemas — supports local + remote servers."""

from datetime import datetime
from pydantic import BaseModel, Field, model_validator

from .user import UserBrief


class MCPServerCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=64)
    description: str = Field(..., max_length=1024)
    version: str | None = None
    tags: list[str] = Field(default_factory=list, max_length=10)
    transport: str = Field(..., pattern=r"^(stdio|sse|streamable-http)$")
    # Local server fields
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    # Remote server fields
    url: str | None = None
    headers: dict[str, str] = Field(default_factory=dict)
    # Common fields
    env: dict[str, str] = Field(default_factory=dict)
    auto_approve: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_server_type(self):
        if self.transport == "stdio":
            if not self.command:
                raise ValueError("'command' is required for stdio transport")
            if self.url:
                raise ValueError("'url' must not be set for stdio transport")
        else:  # sse or streamable-http
            if not self.url:
                raise ValueError("'url' is required for remote transport")
            if self.command:
                raise ValueError("'command' must not be set for remote transport")
        return self


class MCPServerResponse(BaseModel):
    id: int
    name: str
    description: str
    version: str | None = None
    tags: list[str]
    transport: str
    config: dict
    author: UserBrief
    installs: int
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class MCPInstallConfig(BaseModel):
    name: str
    config: dict  # {"mcpServers": {name: {...}}}
    env_vars_needed: list[str]
    oauth_hint: str | None = None
