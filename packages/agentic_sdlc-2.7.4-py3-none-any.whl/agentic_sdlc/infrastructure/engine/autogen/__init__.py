# AutoGen Integration Module
# Provides multi-agent conversation capabilities for complex tasks

from .automation import agents