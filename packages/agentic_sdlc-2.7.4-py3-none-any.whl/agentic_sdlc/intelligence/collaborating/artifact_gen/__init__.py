# Artifact Generator Module - Automated Documentation
from .generator import ArtifactGenerator

__all__ = ['ArtifactGenerator']
