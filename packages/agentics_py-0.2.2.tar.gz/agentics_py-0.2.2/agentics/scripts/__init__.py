"""Scripts package for agentics."""
