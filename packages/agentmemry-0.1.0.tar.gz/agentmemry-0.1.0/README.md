# AgentMemory Python SDK

Persistent memory for AI agents with semantic search.

## Installation

```bash
pip install agentmemory
```

## Quick Start

```python
from agentmemory import AgentMemory

# Initialize with your API key
mem = AgentMemory("am_your_api_key")

# Store memories
mem.store("User loves Thai food and is vegetarian")
mem.store("User prefers morning meetings")
mem.store("User's favorite color is blue")

# Semantic search - find by meaning, not keywords
results = mem.search("what restaurants would they enjoy?")
print(results[0]['content'])  # "User loves Thai food and is vegetarian"
print(results[0]['similarity'])  # 0.72

# Recall by exact key
memory = mem.recall("mem_abc123")

# List all memories
all_memories = mem.list()

# Delete a memory
mem.forget("mem_abc123")

# Check usage
stats = mem.usage()
print(f"Memories: {stats['memory_count']}")
```

## Features

- **Semantic Search**: Find memories by meaning, not just keywords
- **Simple API**: Store, search, recall, forget
- **Namespaces**: Organize memories by user, project, or context
- **TTL Support**: Auto-expire memories after a set time
- **Fast**: <50ms latency globally via Cloudflare edge

## API Reference

### `AgentMemory(api_key, base_url=None, timeout=30)`

Initialize the client.

```python
mem = AgentMemory("am_your_api_key")
```

### `store(content, key=None, namespace="default", metadata=None, ttl=None)`

Store a memory. Returns the created memory info.

```python
# Simple
mem.store("User likes coffee")

# With options
mem.store(
    content="User's birthday is March 15",
    key="user_birthday",
    namespace="user_123",
    metadata={"type": "personal"},
    ttl=86400 * 365  # 1 year
)
```

### `search(query, namespace="default", limit=10, threshold=0.0)`

Semantic search. Returns list of matching memories with similarity scores.

```python
results = mem.search("what does the user like to drink?")
for r in results:
    print(f"{r['similarity']:.0%} - {r['content']}")
```

### `recall(key, namespace="default")`

Get a memory by exact key.

```python
memory = mem.recall("user_birthday", namespace="user_123")
```

### `forget(key, namespace="default")`

Delete a memory.

```python
mem.forget("user_birthday")
```

### `list(namespace="default", limit=50)`

List all memories in a namespace.

```python
memories = mem.list(namespace="user_123")
```

### `usage()`

Get usage statistics.

```python
stats = mem.usage()
print(f"Total memories: {stats['memory_count']}")
print(f"Storage used: {stats['storage_bytes']} bytes")
```

## Use Cases

### Personal AI Assistant

```python
# Store user preferences as you learn them
mem.store("User prefers concise responses")
mem.store("User works in finance")
mem.store("User is based in London, UK")

# Later, retrieve relevant context
context = mem.search("what's their communication style?")
```

### Multi-User App

```python
# Use namespaces to separate users
mem.store("Loves hiking", namespace="user_alice")
mem.store("Loves gaming", namespace="user_bob")

# Search only within a user's memories
results = mem.search("hobbies", namespace="user_alice")
```

### Conversation Memory

```python
# Store important facts from conversations
mem.store("User mentioned they have a dog named Max")
mem.store("User is planning a trip to Japan in April")

# Recall when relevant
mem.search("pets")  # Returns the dog fact
```

## Get Your API Key

Visit [agentmemry.ai](https://agentmemry.ai) to get your API key.

## License

MIT
