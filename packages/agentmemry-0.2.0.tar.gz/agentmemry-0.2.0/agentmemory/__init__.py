"""
AgentMemory - Persistent memory for AI agents
https://agentmemry.ai
"""

from .client import AgentMemory

__version__ = "0.1.0"
__all__ = ["AgentMemory"]
