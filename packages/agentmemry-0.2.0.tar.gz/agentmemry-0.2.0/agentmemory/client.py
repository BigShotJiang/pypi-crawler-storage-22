"""
AgentMemory Python Client
"""

import requests
from typing import Optional, Dict, List, Any


class AgentMemory:
    """
    Client for the AgentMemory API.
    
    Example:
        >>> from agentmemory import AgentMemory
        >>> mem = AgentMemory("am_your_api_key")
        >>> mem.store("User loves Thai food and is vegetarian")
        >>> results = mem.search("what restaurants would they enjoy?")
    """
    
    def __init__(
        self, 
        api_key: str, 
        base_url: str = "https://api.agentmemry.ai/v1",
        timeout: int = 30
    ):
        """
        Initialize the AgentMemory client.
        
        Args:
            api_key: Your AgentMemory API key (starts with 'am_')
            base_url: API base URL (default: https://api.agentmemry.ai/v1)
            timeout: Request timeout in seconds (default: 30)
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def store(
        self, 
        content: str, 
        key: Optional[str] = None,
        namespace: str = "default",
        metadata: Optional[Dict[str, Any]] = None,
        ttl: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Store a memory.
        
        Args:
            content: The memory content to store
            key: Optional custom key (auto-generated if not provided)
            namespace: Namespace for organization (default: "default")
            metadata: Optional metadata dict
            ttl: Time-to-live in seconds (optional)
            
        Returns:
            Dict with 'success', 'key', 'namespace', 'semantic_enabled'
            
        Example:
            >>> mem.store("User prefers dark mode")
            {'success': True, 'key': 'mem_1234...', 'semantic_enabled': True}
        """
        payload = {"content": content, "namespace": namespace}
        if key:
            payload["key"] = key
        if metadata:
            payload["metadata"] = metadata
        if ttl:
            payload["ttl"] = ttl
            
        response = self._session.post(
            f"{self.base_url}/store",
            json=payload,
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()
    
    def recall(
        self, 
        key: str, 
        namespace: str = "default"
    ) -> Dict[str, Any]:
        """
        Recall a memory by exact key.
        
        Args:
            key: The memory key
            namespace: Namespace (default: "default")
            
        Returns:
            The memory object with 'key', 'content', 'created_at', etc.
            
        Raises:
            requests.HTTPError: If memory not found (404)
        """
        response = self._session.get(
            f"{self.base_url}/recall/{key}",
            params={"namespace": namespace},
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()
    
    def search(
        self, 
        query: str, 
        namespace: str = "default",
        limit: int = 10,
        threshold: float = 0.0
    ) -> List[Dict[str, Any]]:
        """
        Semantic search for memories.
        
        Args:
            query: Natural language query (e.g., "what food do they like?")
            namespace: Namespace to search in (default: "default")
            limit: Max results to return (default: 10, max: 50)
            threshold: Minimum similarity score 0-1 (default: 0.0)
            
        Returns:
            List of matching memories with 'content', 'similarity', 'key'
            
        Example:
            >>> mem.store("User loves Thai food and is vegetarian")
            >>> results = mem.search("what restaurants would they enjoy?")
            >>> print(results[0]['similarity'])  # e.g., 0.72
        """
        response = self._session.post(
            f"{self.base_url}/search",
            json={
                "query": query,
                "namespace": namespace,
                "limit": limit,
                "threshold": threshold
            },
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json()
        return data.get("results", [])
    
    def forget(
        self, 
        key: str, 
        namespace: str = "default"
    ) -> Dict[str, Any]:
        """
        Delete a memory.
        
        Args:
            key: The memory key to delete
            namespace: Namespace (default: "default")
            
        Returns:
            Dict with 'deleted': True, 'key': ...
        """
        response = self._session.delete(
            f"{self.base_url}/forget/{key}",
            params={"namespace": namespace},
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()
    
    def list(
        self, 
        namespace: str = "default", 
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        List all memories in a namespace.
        
        Args:
            namespace: Namespace to list (default: "default")
            limit: Max memories to return (default: 50, max: 100)
            
        Returns:
            List of memory objects
        """
        response = self._session.get(
            f"{self.base_url}/list",
            params={"namespace": namespace, "limit": limit},
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json()
        return data.get("memories", [])
    
    def usage(self) -> Dict[str, Any]:
        """
        Get usage statistics.
        
        Returns:
            Dict with 'memory_count', 'storage_bytes', 'requests_today', etc.
        """
        response = self._session.get(
            f"{self.base_url}/usage",
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()
    
    def __repr__(self) -> str:
        masked_key = self.api_key[:6] + "..." + self.api_key[-4:]
        return f"AgentMemory(api_key='{masked_key}')"
