"""
AgentMemory LangChain Integration

Provides a LangChain-compatible retriever for semantic memory search.

Usage:
    from agentmemry.langchain import AgentMemoryRetriever
    
    retriever = AgentMemoryRetriever(
        api_key="am_your_key",
        namespace="user_123"
    )
    
    # Use with LangChain
    from langchain.chains import ConversationalRetrievalChain
    from langchain.chat_models import ChatOpenAI
    
    chain = ConversationalRetrievalChain.from_llm(
        llm=ChatOpenAI(),
        retriever=retriever
    )
"""

from typing import List, Optional, Any
import requests

try:
    from langchain.schema import BaseRetriever, Document
    from langchain.callbacks.manager import CallbackManagerForRetrieverRun
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    # Stub classes for when langchain isn't installed
    class BaseRetriever:
        pass
    class Document:
        def __init__(self, page_content: str, metadata: dict = None):
            self.page_content = page_content
            self.metadata = metadata or {}


class AgentMemoryRetriever(BaseRetriever if LANGCHAIN_AVAILABLE else object):
    """
    LangChain retriever that uses AgentMemory for semantic search.
    
    Args:
        api_key: Your AgentMemory API key (starts with 'am_')
        namespace: Memory namespace to search (default: "default")
        base_url: API base URL (default: https://api.agentmemry.ai/v1)
        top_k: Maximum number of results to return (default: 5)
        threshold: Minimum similarity score 0-1 (default: 0.0)
    """
    
    def __init__(
        self,
        api_key: str,
        namespace: str = "default",
        base_url: str = "https://api.agentmemry.ai/v1",
        top_k: int = 5,
        threshold: float = 0.0,
        **kwargs
    ):
        if LANGCHAIN_AVAILABLE:
            super().__init__(**kwargs)
        
        if not api_key:
            raise ValueError("api_key is required")
            
        self.api_key = api_key
        self.namespace = namespace
        self.base_url = base_url.rstrip('/')
        self.top_k = top_k
        self.threshold = threshold
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def _search(self, query: str) -> List[dict]:
        """Execute semantic search against AgentMemory API."""
        response = self._session.post(
            f"{self.base_url}/search",
            json={
                "query": query,
                "namespace": self.namespace,
                "limit": self.top_k,
                "threshold": self.threshold
            },
            timeout=30
        )
        response.raise_for_status()
        return response.json().get("results", [])
    
    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[Any] = None
    ) -> List[Document]:
        """
        Retrieve relevant documents for a query.
        
        This is the main method called by LangChain.
        """
        results = self._search(query)
        
        documents = []
        for r in results:
            doc = Document(
                page_content=r.get("content", r.get("value", "")),
                metadata={
                    "key": r.get("key"),
                    "similarity": r.get("similarity"),
                    "namespace": self.namespace,
                    "source": "agentmemory"
                }
            )
            documents.append(doc)
        
        return documents
    
    async def _aget_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[Any] = None
    ) -> List[Document]:
        """Async version - falls back to sync for now."""
        return self._get_relevant_documents(query, run_manager=run_manager)
    
    def get_relevant_documents(self, query: str) -> List[Document]:
        """Public method for retrieving documents."""
        return self._get_relevant_documents(query)
    
    # Convenience methods
    
    def add_memory(self, content: str, key: Optional[str] = None, metadata: Optional[dict] = None) -> dict:
        """
        Store a new memory.
        
        Args:
            content: The memory content
            key: Optional custom key
            metadata: Optional metadata dict
        
        Returns:
            API response with key and status
        """
        payload = {
            "content": content,
            "namespace": self.namespace
        }
        if key:
            payload["key"] = key
        if metadata:
            payload["metadata"] = metadata
            
        response = self._session.post(
            f"{self.base_url}/store",
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        return response.json()
    
    def clear_namespace(self) -> int:
        """
        Delete all memories in the current namespace.
        
        Returns:
            Number of memories deleted
        """
        # List all memories
        response = self._session.get(
            f"{self.base_url}/list",
            params={"namespace": self.namespace, "limit": 1000},
            timeout=30
        )
        response.raise_for_status()
        memories = response.json().get("memories", [])
        
        # Delete each one
        deleted = 0
        for mem in memories:
            try:
                self._session.delete(
                    f"{self.base_url}/forget/{mem['key']}",
                    params={"namespace": self.namespace},
                    timeout=10
                )
                deleted += 1
            except:
                pass
        
        return deleted


# For backwards compatibility
MemoryRetriever = AgentMemoryRetriever


def create_retriever(api_key: str, **kwargs) -> AgentMemoryRetriever:
    """
    Factory function to create an AgentMemoryRetriever.
    
    Args:
        api_key: Your AgentMemory API key
        **kwargs: Additional arguments passed to AgentMemoryRetriever
    
    Returns:
        Configured AgentMemoryRetriever instance
    """
    return AgentMemoryRetriever(api_key=api_key, **kwargs)
