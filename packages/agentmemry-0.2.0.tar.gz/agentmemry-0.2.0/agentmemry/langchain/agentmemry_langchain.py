"""
AgentMemry LangChain Integration

Semantic memory for LangChain agents and chains.
Automatically stores and retrieves relevant context using meaning-based search.

Usage:
    from agentmemry.langchain import AgentMemryMemory
    
    memory = AgentMemryMemory(api_key="am_xxx", namespace="user_123")
    chain = ConversationChain(llm=llm, memory=memory)
"""

from typing import Any, Dict, List, Optional
import requests

try:
    from langchain.memory.chat_memory import BaseChatMemory
    from langchain.schema import BaseMessage, HumanMessage, AIMessage
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    BaseChatMemory = object


class AgentMemryMemory(BaseChatMemory if LANGCHAIN_AVAILABLE else object):
    """
    LangChain memory backed by AgentMemry semantic search.
    
    Stores conversation turns and retrieves relevant context
    based on meaning, not just recent history.
    
    Args:
        api_key: Your AgentMemry API key
        namespace: Namespace for memory isolation (e.g., user ID)
        base_url: API base URL (default: https://api.agentmemry.ai)
        k: Number of relevant memories to retrieve (default: 5)
        score_threshold: Minimum similarity score (default: 0.5)
        memory_key: Key to use in chain input (default: "history")
        input_key: Key for human input (default: "input")
        output_key: Key for AI output (default: "output")
        auto_extract: Extract facts from conversation (default: True)
    """
    
    api_key: str
    namespace: str = "default"
    base_url: str = "https://api.agentmemry.ai"
    k: int = 5
    score_threshold: float = 0.5
    memory_key: str = "history"
    input_key: str = "input"
    output_key: str = "output"
    auto_extract: bool = True
    
    def __init__(
        self,
        api_key: str,
        namespace: str = "default",
        base_url: str = "https://api.agentmemry.ai",
        k: int = 5,
        score_threshold: float = 0.5,
        memory_key: str = "history",
        input_key: str = "input",
        output_key: str = "output",
        auto_extract: bool = True,
        **kwargs
    ):
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "LangChain is required for AgentMemryMemory. "
                "Install it with: pip install langchain"
            )
        
        super().__init__(**kwargs)
        self.api_key = api_key
        self.namespace = namespace
        self.base_url = base_url.rstrip('/')
        self.k = k
        self.score_threshold = score_threshold
        self.memory_key = memory_key
        self.input_key = input_key
        self.output_key = output_key
        self.auto_extract = auto_extract
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    @property
    def memory_variables(self) -> List[str]:
        """Return memory variables."""
        return [self.memory_key]
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, str]:
        """
        Load relevant memories based on current input.
        
        Uses semantic search to find memories related to the input,
        rather than just returning recent conversation history.
        """
        query = inputs.get(self.input_key, "")
        if not query:
            return {self.memory_key: ""}
        
        # Semantic search for relevant context
        try:
            response = requests.post(
                f"{self.base_url}/v1/search",
                headers=self._headers,
                json={
                    "query": query,
                    "namespace": self.namespace,
                    "limit": self.k
                },
                timeout=10
            )
            response.raise_for_status()
            results = response.json().get("results", [])
            
            # Filter by score threshold and format
            relevant = [
                r["content"] for r in results 
                if r.get("similarity", 0) >= self.score_threshold
            ]
            
            if not relevant:
                return {self.memory_key: ""}
            
            # Format as context
            context = "Relevant context from memory:\n" + "\n".join(
                f"- {mem}" for mem in relevant
            )
            return {self.memory_key: context}
            
        except Exception as e:
            # Fail silently - don't break the chain
            print(f"AgentMemry: Failed to load memories: {e}")
            return {self.memory_key: ""}
    
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """
        Save conversation turn to memory.
        
        Stores both the human input and AI response as searchable memories.
        """
        human_input = inputs.get(self.input_key, "")
        ai_output = outputs.get(self.output_key, "")
        
        if not human_input and not ai_output:
            return
        
        # Store the conversation turn
        conversation = f"Human: {human_input}\nAssistant: {ai_output}"
        
        try:
            requests.post(
                f"{self.base_url}/v1/store",
                headers=self._headers,
                json={
                    "content": conversation,
                    "namespace": self.namespace,
                    "metadata": {
                        "type": "conversation",
                        "input": human_input[:200],  # Truncate for metadata
                    }
                },
                timeout=10
            )
        except Exception as e:
            print(f"AgentMemry: Failed to save memory: {e}")
        
        # Also call parent to maintain chat_memory if needed
        if hasattr(super(), 'save_context'):
            super().save_context(inputs, outputs)
    
    def clear(self) -> None:
        """Clear all memories in this namespace."""
        try:
            # List all memories
            response = requests.get(
                f"{self.base_url}/v1/list",
                headers=self._headers,
                params={"namespace": self.namespace, "limit": 1000},
                timeout=30
            )
            response.raise_for_status()
            memories = response.json().get("memories", [])
            
            # Delete each one
            for mem in memories:
                requests.delete(
                    f"{self.base_url}/v1/forget/{mem['key']}",
                    headers=self._headers,
                    params={"namespace": self.namespace},
                    timeout=10
                )
        except Exception as e:
            print(f"AgentMemry: Failed to clear memories: {e}")
    
    def store(self, content: str, metadata: Optional[Dict] = None) -> None:
        """
        Manually store a memory.
        
        Useful for storing facts, preferences, or other context
        outside of normal conversation flow.
        """
        try:
            requests.post(
                f"{self.base_url}/v1/store",
                headers=self._headers,
                json={
                    "content": content,
                    "namespace": self.namespace,
                    "metadata": metadata or {}
                },
                timeout=10
            )
        except Exception as e:
            print(f"AgentMemry: Failed to store memory: {e}")
    
    def search(self, query: str, k: Optional[int] = None) -> List[Dict]:
        """
        Manually search memories.
        
        Returns list of matching memories with similarity scores.
        """
        try:
            response = requests.post(
                f"{self.base_url}/v1/search",
                headers=self._headers,
                json={
                    "query": query,
                    "namespace": self.namespace,
                    "limit": k or self.k
                },
                timeout=10
            )
            response.raise_for_status()
            return response.json().get("results", [])
        except Exception as e:
            print(f"AgentMemry: Failed to search memories: {e}")
            return []


# Convenience class for simpler use cases
class SemanticMemory(AgentMemryMemory):
    """
    Simplified semantic memory for basic use cases.
    
    Usage:
        memory = SemanticMemory("am_xxx")
        memory.store("User prefers dark mode")
        results = memory.search("UI preferences")
    """
    
    def __init__(self, api_key: str, namespace: str = "default", **kwargs):
        # Don't require LangChain for basic usage
        self.api_key = api_key
        self.namespace = namespace
        self.base_url = kwargs.get("base_url", "https://api.agentmemry.ai").rstrip('/')
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def store(self, content: str, metadata: Optional[Dict] = None) -> Dict:
        """Store a memory."""
        response = requests.post(
            f"{self.base_url}/v1/store",
            headers=self._headers,
            json={
                "content": content,
                "namespace": self.namespace,
                "metadata": metadata or {}
            },
            timeout=10
        )
        response.raise_for_status()
        return response.json()
    
    def search(self, query: str, limit: int = 5) -> List[Dict]:
        """Search memories by meaning."""
        response = requests.post(
            f"{self.base_url}/v1/search",
            headers=self._headers,
            json={
                "query": query,
                "namespace": self.namespace,
                "limit": limit
            },
            timeout=10
        )
        response.raise_for_status()
        return response.json().get("results", [])
    
    def list(self, limit: int = 50) -> List[Dict]:
        """List all memories."""
        response = requests.get(
            f"{self.base_url}/v1/list",
            headers=self._headers,
            params={"namespace": self.namespace, "limit": limit},
            timeout=10
        )
        response.raise_for_status()
        return response.json().get("memories", [])
    
    def forget(self, key: str) -> bool:
        """Delete a memory by key."""
        response = requests.delete(
            f"{self.base_url}/v1/forget/{key}",
            headers=self._headers,
            params={"namespace": self.namespace},
            timeout=10
        )
        return response.status_code == 200
