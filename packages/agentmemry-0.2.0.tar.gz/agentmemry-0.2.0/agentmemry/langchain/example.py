"""
AgentMemry + LangChain Example

Shows how to create an AI assistant with persistent semantic memory.
The assistant remembers user preferences and retrieves relevant context
automatically based on the conversation.
"""

from langchain.chains import ConversationChain
from langchain.chat_models import ChatOpenAI
from agentmemry.langchain import AgentMemryMemory

# Initialize memory with your API key
memory = AgentMemryMemory(
    api_key="am_your_api_key",  # Get yours at agentmemry.ai
    namespace="user_alice",     # Isolate memories per user
    k=3,                        # Retrieve top 3 relevant memories
    score_threshold=0.5         # Only use memories with >50% similarity
)

# Pre-store some user preferences (optional - can also learn from conversation)
memory.store("Alice is vegetarian and loves Thai food")
memory.store("Alice prefers morning meetings before 10am")
memory.store("Alice is a software engineer working on ML projects")

# Create the conversation chain
llm = ChatOpenAI(temperature=0.7)
chain = ConversationChain(
    llm=llm,
    memory=memory,
    verbose=True  # See what's happening
)

# Have a conversation - memory automatically provides relevant context!
print("=" * 50)
print("Conversation 1: Restaurant recommendations")
print("=" * 50)
response = chain.run("Can you recommend some restaurants for dinner?")
print(f"Assistant: {response}")
# Memory will retrieve "Alice is vegetarian and loves Thai food" as context

print("\n" + "=" * 50)
print("Conversation 2: Scheduling")  
print("=" * 50)
response = chain.run("When should we schedule our next meeting?")
print(f"Assistant: {response}")
# Memory will retrieve "Alice prefers morning meetings before 10am"

print("\n" + "=" * 50)
print("Conversation 3: Work discussion")
print("=" * 50)
response = chain.run("What tools would help me be more productive?")
print(f"Assistant: {response}")
# Memory will retrieve "Alice is a software engineer working on ML projects"

# The assistant learns from conversation too!
chain.run("I just adopted a cat named Whiskers")
# This gets stored automatically

# Later searches will find it
results = memory.search("pets")
print(f"\nSearch for 'pets': {results}")


# ============================================
# Simpler usage without LangChain dependency
# ============================================

from agentmemry.langchain import SemanticMemory

# Just need basic store/search? Use SemanticMemory
mem = SemanticMemory(api_key="am_your_api_key")

# Store facts
mem.store("User's favorite color is blue")
mem.store("User works at a startup called TechCo")
mem.store("User has 2 kids aged 5 and 8")

# Search by meaning
results = mem.search("family information")
for r in results:
    print(f"{r['similarity']:.0%} - {r['content']}")

# List all
all_memories = mem.list()
print(f"Total memories: {len(all_memories)}")
