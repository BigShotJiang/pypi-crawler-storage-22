# agentcost

Know what your AI agents actually cost. Track LLM tokens, tool API calls, and compute costs — per agent, per task, per tool.

## Get Started (3 commands)

```bash
pip install agentcost
agentcost login
agentcost run my_agent.py
```

That's it. Every OpenAI and Anthropic call inside your script is automatically tracked — zero code changes needed.

## How It Works

`agentcost run` wraps your script, detects installed LLM libraries, and captures token usage from every API response. Events are sent to your dashboard in the background. No slowdown, no side effects.

## Setup

### 1. Install

```bash
pip install agentcost
```

### 2. Login (one time)

```bash
agentcost login
```

Stores your API key securely in `~/.config/agentcost/`. Get your key from [agentmeter.com](https://agentmeter.com).

### 3. Run

```bash
agentcost run my_agent.py
```

Works with any Python script that uses OpenAI or Anthropic SDKs.

## CLI Commands

```bash
agentcost login       # Save your API key (one-time setup)
agentcost run app.py  # Track a script automatically
agentcost status      # Check login status and connection
agentcost summary     # View cost summary in terminal
agentcost agents      # List all tracked agents
agentcost logout      # Remove stored credentials
```

## Alternative: Python API

For more control, use the Python API directly:

```python
import agentcost

# Auto-patch all LLM calls (after login, no key needed)
agentcost.init(agent_id="my-agent")

# Or with explicit key
agentcost.init(api_key="ac_xxxxx", agent_id="my-agent")
```

### Track tool costs

```python
from agentcost import AgentCost

ac = AgentCost()

@ac.track_tool(name="stripe_api", cost_per_call=0.02)
def charge_customer(amount):
    return stripe.charges.create(amount=amount)
```

### Group calls into runs

```python
with ac.track_run("support-agent", task="process_refund") as run:
    run.record("stripe_api", cost=0.02)
    run.record_llm("gpt-4o", tokens_in=500, tokens_out=200)

print(f"Run cost: ${run.total_cost:.4f}")
```

## Custom Pricing

```python
ac = AgentCost(
    pricing_overrides={
        "my_custom_api": 0.05,
        "my-fine-tuned-model": {"input": 5.00, "output": 15.00},
    }
)
```

## Supported Providers

- **OpenAI** — gpt-4o, gpt-4o-mini, gpt-4-turbo, o1, o1-mini, and more
- **Anthropic** — Claude Opus, Sonnet, Haiku (all versions)
- **30+ tool APIs** — Stripe, Salesforce, SendGrid, Twilio, etc.

Ships with built-in pricing for all models. Override any price with `pricing_overrides`.

## Dashboard

View cost dashboards, set budgets, and get alerts at [agentmeter.com](https://agentmeter.com).
