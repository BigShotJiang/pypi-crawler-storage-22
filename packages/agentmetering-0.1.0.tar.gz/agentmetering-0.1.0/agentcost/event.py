from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional
import uuid


@dataclass
class CostEvent:
    """A single cost event tracked by AgentCost."""

    agent_id: str
    component_name: str
    event_type: str  # "llm_call" or "tool_call"
    cost_usd: float
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    run_id: Optional[str] = None
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    duration_ms: Optional[int] = None
    tokens_in: Optional[int] = None
    tokens_out: Optional[int] = None
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)
