"""OpenAI integration for AgentCost.

Wraps an OpenAI client to automatically track token usage and cost
from every chat completion call. Zero overhead — reads usage from
the response object that's already returned.

Usage:
    from agentcost import AgentCost
    from agentcost.integrations.openai import track_openai
    import openai

    ac = AgentCost(api_key="ac_xxxxx")
    client = track_openai(openai.OpenAI(), ac, agent_id="my-agent")

    # Every call is now auto-tracked
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}]
    )
"""

from __future__ import annotations

import time
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from agentcost import AgentCost

from ..event import CostEvent
from ..tracker import _active_run


class _TrackedCompletions:
    """Wraps client.chat.completions to auto-track create() calls."""

    def __init__(self, original_completions: Any, ac: "AgentCost", agent_id: str):
        self._original = original_completions
        self._ac = ac
        self._agent_id = agent_id

    def create(self, **kwargs: Any) -> Any:
        start = time.time()
        response = self._original.create(**kwargs)
        duration_ms = int((time.time() - start) * 1000)

        model = getattr(response, "model", kwargs.get("model", "unknown"))
        usage = getattr(response, "usage", None)

        tokens_in = getattr(usage, "prompt_tokens", 0) if usage else 0
        tokens_out = getattr(usage, "completion_tokens", 0) if usage else 0
        cost = self._ac.pricing.llm_cost(model, tokens_in, tokens_out)

        active = _active_run.get(None)
        effective_agent = active._agent_id if active else self._agent_id
        effective_run_id = active._run_id if active else None

        event = CostEvent(
            agent_id=effective_agent,
            run_id=effective_run_id,
            component_name=model,
            event_type="llm_call",
            cost_usd=cost,
            duration_ms=duration_ms,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
        )

        if active:
            active._events.append(event)

        self._ac._client.enqueue(event)
        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _TrackedChat:
    """Wraps client.chat to provide tracked completions."""

    def __init__(self, original_chat: Any, ac: "AgentCost", agent_id: str):
        self._original = original_chat
        self.completions = _TrackedCompletions(
            original_chat.completions, ac, agent_id
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _TrackedOpenAIClient:
    """Wraps an OpenAI client to auto-track all chat completion calls."""

    def __init__(self, client: Any, ac: "AgentCost", agent_id: str):
        self._original = client
        self.chat = _TrackedChat(client.chat, ac, agent_id)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


def track_openai(
    client: Any,
    ac: "AgentCost",
    agent_id: str = "openai-agent",
) -> Any:
    """Wrap an OpenAI client to automatically track all chat completions.

    Args:
        client: An openai.OpenAI() or openai.AsyncOpenAI() instance.
        ac: Your AgentCost instance.
        agent_id: Agent name for tracking (default: "openai-agent").

    Returns:
        A wrapped client that behaves identically but tracks costs.
    """
    return _TrackedOpenAIClient(client, ac, agent_id)
