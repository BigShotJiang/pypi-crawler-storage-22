import uuid

from agentcost.event import CostEvent


class TestCostEvent:
    def test_creates_with_required_fields(self):
        event = CostEvent(
            agent_id="test-agent",
            component_name="stripe_api",
            event_type="tool_call",
            cost_usd=0.02,
        )
        assert event.agent_id == "test-agent"
        assert event.component_name == "stripe_api"
        assert event.event_type == "tool_call"
        assert event.cost_usd == 0.02

    def test_auto_generates_event_id(self):
        event = CostEvent(
            agent_id="a", component_name="b", event_type="tool_call", cost_usd=0.0
        )
        # Should be a valid UUID
        uuid.UUID(event.event_id)

    def test_auto_generates_timestamp(self):
        event = CostEvent(
            agent_id="a", component_name="b", event_type="tool_call", cost_usd=0.0
        )
        assert event.timestamp is not None
        assert "T" in event.timestamp  # ISO format

    def test_to_dict(self):
        event = CostEvent(
            agent_id="test-agent",
            component_name="gpt-4o",
            event_type="llm_call",
            cost_usd=0.0125,
            tokens_in=500,
            tokens_out=200,
            metadata={"task": "refund"},
        )
        d = event.to_dict()
        assert d["agent_id"] == "test-agent"
        assert d["component_name"] == "gpt-4o"
        assert d["event_type"] == "llm_call"
        assert d["cost_usd"] == 0.0125
        assert d["tokens_in"] == 500
        assert d["tokens_out"] == 200
        assert d["metadata"] == {"task": "refund"}

    def test_optional_fields_default_to_none(self):
        event = CostEvent(
            agent_id="a", component_name="b", event_type="tool_call", cost_usd=0.0
        )
        assert event.run_id is None
        assert event.duration_ms is None
        assert event.tokens_in is None
        assert event.tokens_out is None
        assert event.metadata == {}
