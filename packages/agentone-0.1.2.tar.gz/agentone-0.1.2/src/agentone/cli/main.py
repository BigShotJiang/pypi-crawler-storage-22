"""Точка входа в CLI интерфейс AgentOne."""
from sys import argv, exit


def show_help():
    """Показать справку по командам."""
    print("""
AgentOne - Smart utilities for AI agents infrastructure

Usage:
    agentone do         Запустить CLI операции
    agentone control    Запустить TUI конфигуратор
    agentone --help     Показать эту справку
    agentone --version  Показать версию
""")


def show_version():
    """Показать версию."""
    print("AgentOne v0.1.1")


def do_command():
    """CLI режим - операции и команды."""
    print("AgentOne CLI Mode")
    print("Hello, I'm AgentOne. Ready to work!")
    # Здесь будет логика CLI команд


def control_command():
    """TUI режим - конфигуратор."""
    try:
        from agentone.tui.main import main as tui_main
        tui_main()
    except ImportError:
        print("ERROR: TUI not available. Install with: pip install agentone[tui]")
        exit(1)


def main():
    """Главная точка входа CLI."""
    # TODO Переделать на ArgsParser когда дойдет до реализации.
    args = argv[1:]
    
    if not args or args[0] in ['--help', '-h', 'help']:
        show_help()
        return
    
    if args[0] in ['--version', '-v', 'version']:
        show_version()
        return
    
    command = args[0]
    
    if command == 'do':
        do_command()
    elif command == 'control':
        control_command()
    else:
        print(f"ERROR: Unknown command: {command}")
        print("Use 'agentone --help' for help")
        exit(1)


if __name__ == "__main__":
    main()
