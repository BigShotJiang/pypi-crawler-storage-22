"""
Модуль ядра AgentOne.
"""
