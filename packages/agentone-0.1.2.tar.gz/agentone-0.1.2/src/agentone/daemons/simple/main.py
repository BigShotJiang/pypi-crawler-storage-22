from __future__ import annotations
from typing import List, Union, Callable, Dict, Any, Optional
from deepagents import create_deep_agent, CompiledSubAgent
from langchain_core.language_models import BaseChatModel
from langchain_core.tools import BaseTool, tool as create_tool_wrapper
from langfuse import Langfuse
from langgraph.graph.state import CompiledStateGraph


class Agent:
    """Фабрика базового демона"""

    def __init__(self, llm: BaseChatModel):
        self.llm: BaseChatModel = llm
        self.tools: List[BaseTool] = []
        self.subagents: List[CompiledSubAgent] = []
        self.agent: Optional[CompiledStateGraph] = None
        self._system_prompt: Optional[str] = None

    def system_prompt(self, text: str) -> Agent:
        """Добавляет системный промпт для агента напрямую"""
        self._system_prompt = text
        return self

    def langfuse_system_prompt(self, path: str, langfuse: Langfuse) -> Agent:
        """Добавляет системный промпт для агента из LangFuse"""
        system_prompt = langfuse.get_prompt(path)
        self._system_prompt = system_prompt.compile()
        return self

    def add_tool(self, tool: Union[BaseTool, Callable] = None, tools: list[BaseTool] = None) -> Agent:
        """
        Добавляет инструмент к собираемому агенту из обычной функции оборачивает в @tool
        и динамически упаковывает его в список инструментов инстанса агента в self.tool.

        Должен быть передан или tool, или tools.
        :param tool: Один инструмент
        :param tools: Список инструментов сразу
        :return: Текущее состояние инстанса Agent.
        """
        if not tool and not tools:
            raise ValueError('Even of one value should be filled: "tool" or "tools"')

        items_to_process = []
        items_to_process.append(tool) if tool else items_to_process.extend(tools)

        for item in items_to_process:
            if isinstance(item, BaseTool):
                self.tools.append(item)
            elif callable(item):
                wrapped_tool = create_tool_wrapper(item)
                self.tools.append(wrapped_tool)
            else:
                raise TypeError(f"Object {item} is neither a BaseTool nor a Callable function")
        return self

    def add_subagent(
            self,
            agent: Union[CompiledSubAgent, Dict[str, Any]] = None,
            agents: List[Union[CompiledSubAgent, Dict[str, Any]]] = None
    ) -> Agent:
        """
        Добавляет субагента.
        Поддерживает два типа субагентов согласно документации deepagents:

        1. Dict (Simple): Конфигурация для создания стандартного субагента на лету.
           Обязательные ключи: "name", "description", "system_prompt", "tools".

        2. CompiledSubAgent (Advanced): Заранее скомпилированный граф LangGraph.
           Используется, когда нужна кастомная логика внутри субагента.
        """
        if not agent and not agents:
            raise ValueError('Either "agent" or "agents" must be provided')

        items_to_process = []
        items_to_process.append(agent) if agent else items_to_process.extend(agents)

        for item in items_to_process:
            self.subagents.append(item)

        return self

    def reset(self) -> Agent:
        """Сбрасывает скомпилированный агент для пересборки с новыми параметрами"""
        self.agent = None
        return self

    def build(self) -> CompiledStateGraph:
        """
        Финальная сборка агента.
        """
        if self.agent is not None:
            return self.agent

        if not self._system_prompt:
            raise ValueError("System prompt is required. Use system_prompt() or langfuse_system_prompt()")

        self.agent = create_deep_agent(
            model=self.llm,
            system_prompt=self._system_prompt,
            tools=self.tools,
            subagents=self.subagents
        )

        return self.agent
