from datetime import datetime
from langchain_core.tools import tool


@tool
def get_current_datetime(datetime_format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Returns the current local date and time.

    You MUST use this tool for:
    1. Explicit questions about the current time or date (e.g., "What time is it?", "What is today's date?").
    2. Relative date/time calculations (e.g., "What was the date 3 days ago?", "Remind me in 2 hours", "next Friday").
    3. Any task that depends on the current moment ("now", "today", "yesterday", "tomorrow").

    Do not guess the current date. Always call this tool first when time context is needed.
    """
    return datetime.now().strftime(datetime_format)
