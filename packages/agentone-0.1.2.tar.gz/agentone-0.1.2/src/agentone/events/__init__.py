"""Модуль шины событий для распределенной коммуникации агентов.

Предоставляет NATS/JetStream-based реализацию шины событий для надежной
передачи сообщений между агентами в рое.
"""
from .bus import BusConfig, Topic, EventBus, EventBusBuilder
from .envelope import EventEnvelope
