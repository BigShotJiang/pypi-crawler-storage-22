"""
Реализация шины событий для распределенной коммуникации агентов.

Модуль предоставляет NATS-based event bus с поддержкой JetStream для надежной
доставки сообщений между агентами в рое. Реализует CloudEvents-совместимый
формат сообщений и структурированную маршрутизацию.
"""
from __future__ import annotations
from logging import getLogger
from typing import Optional, List, Callable, Awaitable
from dataclasses import dataclass, field
from datetime import datetime, UTC

from nats import connect
from nats.js import JetStreamContext
from nats.aio.client import Client
from pydantic import BaseModel

from .models import Signal, LogLevel, Priority, TaskPayload, ResultPayload, LogPayload, SwarmEvent
from .envelope import EventEnvelope

logger = getLogger("agentone.bus")


@dataclass
class BusConfig:
    """Конфигурация подключения к шине событий."""
    urls: List[str] = field(default_factory=lambda: ["nats://localhost:4222"])
    client_name: str = "unknown-client"
    root_subject: str = "swarm"
    stream_name: str = "SWARM"


class Topic:
    """Фабрика для генерации структурированных NATS subject строк."""

    @staticmethod
    def task(root: str, domain: str, zone: str, entity: str, aspect: str, signal: Signal) -> str:
        """Генерирует subject для задач. Формат: root.domain.zone.entity.aspect.signal"""
        return f"{root}.{domain}.{zone}.{entity}.{aspect}.{signal.value}"

    @staticmethod
    def log(root: str, zone: str, entity: str, level: LogLevel) -> str:
        """Генерирует subject для логов. Формат: root.logs.zone.entity.record.level"""
        return f"{root}.logs.{zone}.{entity}.record.{level.value}"

    @staticmethod
    def system(root: str, zone: str, entity: str, aspect: str, signal: str) -> str:
        """Генерирует subject для системных событий. Формат: root.core.zone.entity.aspect.signal"""
        return f"{root}.core.{zone}.{entity}.{aspect}.{signal}"


class EventBus:
    """Основная шина событий для коммуникации агентов через NATS/JetStream."""

    def __init__(self, config: BusConfig):
        """Инициализация шины с конфигурацией."""
        self.cfg = config
        self.nc: Optional[Client] = None
        self.js: Optional[JetStreamContext] = None

    async def connect(self):
        """Устанавливает соединение с NATS сервером и инициализирует JetStream контекст."""
        try:
            self.nc = await connect(
                servers=self.cfg.urls,
                name=self.cfg.client_name,
            )
            self.js = self.nc.jetstream()
            logger.info(f"[CONNECTED] Connected to NATS as {self.cfg.client_name}")
        except Exception as e:
            logger.error(f"Failed to connect to NATS: {e}")
            raise

    async def close(self):
        """Корректно закрывает соединение с NATS, дожидаясь отправки pending сообщений."""
        if self.nc:
            await self.nc.drain()
            await self.nc.close()
            logger.info("[DISCONNECTED] Disconnected from NATS")

    async def publish(
            self,
            subject: str,
            data_payload: BaseModel | dict,
            ticket_id: Optional[str] = None,
            trace_id: Optional[str] = None,
            timeout: Optional[int] = None,
            priority: Priority = Priority.NORMAL,
            use_jetstream: bool = True,
            source_type: str = "agent"
    ):
        """
        Единая точка отправки. Позволяет также строить свои кастомные события.
        1. Body: SwarmEvent JSON.
        2. Headers: NATS Headers (Strict list: trace_id, ticket_id, timeout, priority).
        """

        # тело (SwarmEvent)
        event = SwarmEvent(
            source=f"/{source_type}/{self.cfg.client_name}",
            type=subject,
            data=data_payload
        )
        body_bytes = event.model_dump_json().encode()

        # заголовки
        headers = {}
        if ticket_id: headers["ticket_id"] = str(ticket_id)
        if trace_id: headers["trace_id"] = str(trace_id)
        if timeout is not None: headers["timeout"] = str(timeout)
        if priority: headers["priority"] = priority.value

        # отправка
        if use_jetstream:
            return await self.js.publish(subject, body_bytes, headers=headers)
        else:
            await self.nc.publish(subject, body_bytes, headers=headers)
            return None

    # =========================================================
    # PUBLIC API: TASKS (JetStream)
    # =========================================================
    async def create_stream(
            self,
            retention: str = "limits",
            max_age: int = 86400,
            storage: str = "file"
    ) -> EventBus:
        """Создает стрим в NATS JetStream на основе проинициализированного объекта шины"""
        try:
            await self.js.add_stream(
                name=self.cfg.stream_name,
                subjects=[f"{self.cfg.root_subject}.>"],  # все топики идут в один стрим.
                retention=retention,
                max_age=max_age,  # в секундах (время жизни события в очереди)
                storage=storage
            )
            logger.info('Stream SWARM successful created!')
        except Exception as e:
            logger.warning(f"Stream already existed or error: {e}")
        return self

    async def publish_task(
            self,
            domain: str,
            zone: str,
            entity: str,
            aspect: str,
            payload: TaskPayload,
            ticket_id: str,
            trace_id: str,
            timeout: int = 30,
            priority: Priority = Priority.NORMAL
    ):
        """Публикация бизнес-задачи (.pending)"""
        subject = Topic.task(
            self.cfg.root_subject, domain, zone, entity, aspect, Signal.PENDING
        )
        return await self.publish(
            subject=subject, data_payload=payload,
            ticket_id=ticket_id, trace_id=trace_id,
            timeout=timeout, priority=priority, use_jetstream=True
        )

    async def publish_result(
            self,
            original_subject: str,
            payload: ResultPayload,
            ticket_id: str,
            trace_id: str,
            priority: Optional[Priority]
    ):
        """Публикация результата по задаче (сигнал .done)"""
        #  TODO Подумать как лучше публиковать .processing Signal при взятии задачи в обработку.
        done_subject = original_subject.replace(f".{Signal.PENDING.value}", f".{Signal.DONE.value}")
        # Ответы шлем с высоким приоритетом (если не указано иное)
        return await self.publish(
            subject=done_subject, data_payload=payload, ticket_id=ticket_id, trace_id=trace_id,
            priority=priority if priority else Priority.HIGH, use_jetstream=True
        )

    async def publish_failure(
            self,
            original_subject: str,
            reason: str,
            ticket_id: str,
            trace_id: str,
            priority: Optional[Priority]
    ):
        """Сообщение об ошибке при выполнении задачи (сигнал .failed)"""
        fail_subject = original_subject.replace(f".{Signal.PENDING.value}", f".{Signal.FAILED.value}")
        payload = ResultPayload(output=None, logs=[f"{priority.value.capitalize()}: {reason}"])
        # Ошибки - обычно наивысший приоритет, может быть что иные задачи не имеет смысла завершать, но можно кастомно понизить.
        return await self.publish(
            subject=fail_subject, data_payload=payload,
            ticket_id=ticket_id, trace_id=trace_id,
            priority=priority if priority else Priority.CRITICAL, use_jetstream=True
        )

    # =========================================================
    # PUBLIC API: SYSTEM & LOGS (Core NATS)
    # =========================================================

    async def publish_log(
            self,
            zone: str,
            level: LogLevel,
            message: str,
            meta: dict = None,
            trace_id: Optional[str] = None
    ):
        """Системное логирование (Fire-and-forget)"""
        subject = Topic.log(self.cfg.root_subject, zone, self.cfg.client_name, level)
        payload = LogPayload(message=message, meta=meta or {})

        await self.publish(subject=subject, data_payload=payload, trace_id=trace_id, use_jetstream=False)

    async def publish_heartbeat(self, zone: str, status: str, load: dict):
        """Хартбит агента"""
        # swarm.core.{zone}.{entity}.status.{status}
        subject = Topic.system(
            self.cfg.root_subject, zone, self.cfg.client_name, "status", status
        )
        # Упрощенный payload для статуса
        payload = {"ts": datetime.now(UTC), "load": load}

        await self.publish(subject=subject, data_payload=payload, use_jetstream=False)

    # =========================================================
    # SUBSCRIPTIONS
    # =========================================================

    async def subscribe_task(
            self,
            subject: str,
            queue_group: str,
            callback: Callable[[EventEnvelope], Awaitable[None]]
    ):
        """
        Подписка на топик по специализации агента (Durable Consumer).
        """

        async def _internal_cb(msg):
            envelope = EventEnvelope(msg)
            try:
                await callback(envelope)
                # Важно: в реализации код должен сам вызывать ack()
                # внутри callback, если надо подтвердить выполнение.
            except Exception as e:
                logger.error(f"Error handling task: {e}")
                #  TODO Может вызывать бесконечный цикл забора задачи
                #   при ошибках валидации, надо почерепить над обработкой.
                await envelope.nak()

        await self.js.subscribe(
            subject=subject,
            queue=queue_group,
            durable=queue_group,
            cb=_internal_cb,
            manual_ack=True
        )


# Сборка шины
class EventBusBuilder:
    """Fluent builder для конфигурации EventBus."""

    def __init__(self):
        """Инициализация builder с конфигурацией по умолчанию."""
        self._cfg = BusConfig()

    def connection(self, url: str, client_name: str) -> EventBusBuilder:
        """Настройка параметров подключения к NATS."""
        self._cfg.urls = [url]
        self._cfg.client_name = client_name
        return self

    def routing(self, root: str, stream: str) -> EventBusBuilder:
        """Настройка маршрутизации и параметров stream."""
        self._cfg.root_subject = root
        self._cfg.stream_name = stream
        return self

    def build(self) -> EventBus:
        """Создает и возвращает сконфигурированный экземпляр EventBus."""
        return EventBus(self._cfg)
