"""
Обертка сообщений для удобного доступа к заголовкам и ленивого парсинга тела.

Модуль предоставляет EventEnvelope для эффективной инспекции заголовков
без парсинга тела сообщения до момента необходимости. Что позволяет отделить
транспортный уровень от уровня полезной нагрузки формируемой агентами.
"""
from json import loads
from typing import Optional
from nats.aio.msg import Msg
from pydantic import BaseModel
from .models import SwarmEvent, Priority
from logging import getLogger

logger = getLogger("agentone.events")


class EventEnvelope:
    """
    Обертка над NATS-сообщением для ленивого парсинга.
    Позволяет читать заголовки без парсинга JSON тела.
    """

    def __init__(self, msg: Msg):
        self._msg = msg
        self._event_cache: Optional[SwarmEvent] = None
        self._headers = msg.headers or {}

    @property
    def ticket_id(self) -> Optional[str]:
        """Идентификатор тикета для связки событий"""
        return self._headers.get("ticket_id")

    @property
    def trace_id(self) -> Optional[str]:
        """Идентификатор трассировки для отслеживания выполнения"""
        return self._headers.get("trace_id")

    @property
    def timeout(self) -> Optional[int]:
        """Unix timestamp таймаута сообщения"""
        val = self._headers.get("timeout")
        return int(val) if val else None

    @property
    def priority(self) -> Priority:
        """Уровень приоритета сообщения"""
        val = self._headers.get("priority", Priority.NORMAL)
        try:
            return Priority(val)
        except ValueError:
            logger.warning(f'Unknown priority received: {val}. Downgraded to LOW!')
            return Priority.LOW

    @property
    def subject(self) -> str:
        """NATS subject (топик) сообщения"""
        return self._msg.subject

    def get_event(self, data_model: type[BaseModel] = dict) -> SwarmEvent:
        """
        Парсит и валидирует тело сообщения как SwarmEvent. Результат кешируется.
        :param data_model: Модель данных в соответствии с которой надо провалидировать тело ответа.
        """
        if self._event_cache:
            return self._event_cache

        raw_json = loads(self._msg.data.decode())
        event = SwarmEvent[data_model](**raw_json)
        self._event_cache = event
        return event

    async def ack(self):
        """Подтверждение успешной обработки сообщения"""
        await self._msg.ack()

    async def nak(self):
        """Отрицательное подтверждение (сообщение будет переотправлено)"""
        await self._msg.nak()
