"""
Модели данных для событий шины.

Модуль содержит CloudEvents-совместимые структуры сообщений,
перечисления для маршрутизации и модели payload для коммуникации агентов.
"""
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, TypeVar, Generic, Optional
from pydantic import BaseModel, Field


class Zone(str, Enum):
    """Базовые зоны развертывания демонов и выполнения задач"""
    CLUSTER = "cluster"
    UPLINK = "uplink"
    SANDBOX = "sandbox"
    CORE = "core"
    LOCAL = "local"


class Signal(str, Enum):
    """Сигналы жизненного цикла задачи назначаемой демонам в рое"""
    PENDING = "pending"
    PROCESSING = "processing"
    DONE = "done"
    FAILED = "failed"


class LogLevel(str, Enum):
    """Уровни серьезности лог-сообщений"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class Priority(str, Enum):
    """Уровни приоритета сообщений для маршрутизации и приоритизации обработки"""
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"


class TaskPayload(BaseModel):
    """Модель payload для задачи агенту"""
    instruction: str = Field(
        description="Primary task instruction for the agent"
    )
    context: List[str] = Field(
        default_factory=list,
        description="Contextual information needed to complete the task"
    )
    constraints: Dict[str, Any] = Field(
        default_factory=dict,
        description="Task constraints and requirements (e.g., checklists, prohibited actions, quality criteria)"
    )
    artifacts: List[str] = Field(
        default_factory=list,
        description="References to external artifacts (e.g., S3/R2 URIs)"
    )
    structured_output: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Optional pydantic scheme for structured output if required."
    )


class ResultPayload(BaseModel):
    """Модель payload для результата выполнения задачи"""
    output: Any = Field(description="Task execution result in any required format")
    logs: List[str] = Field(
        default_factory=list,
        description="Execution logs (reasoning chains, tool calls, etc.)"
    )
    metrics: Dict[str, Any] = Field(
        default_factory=dict,
        description="Performance metrics (tokens used, execution time, etc.)"
    )


class LogPayload(BaseModel):
    """Модель payload для лог-сообщения"""
    message: str = Field(description="Текст лог-сообщения")
    meta: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional log metadata"
    )


T = TypeVar("T")


class SwarmEvent(BaseModel, Generic[T]):
    """
    JSON Body сообщения в формате CloudEvents v1.0.
    Generic тип T представляет тип payload'а события.
    """
    specversion: str = Field(
        default="1.0",
        description="Version of CloudEvents specification"
    )
    id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="Unique event identifier"
    )
    source: str = Field(description="Event source (for example, agent/ops/minerva)")
    type: str = Field(description="Event type/subject (for example, swarm.dev.sandbox.code.generate.done)")
    time: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Event timestamp (UTC)"
    )
    datacontenttype: str = Field(default="application/json", description="Type content for event bus")
    data: T = Field(description="Event's payload")
