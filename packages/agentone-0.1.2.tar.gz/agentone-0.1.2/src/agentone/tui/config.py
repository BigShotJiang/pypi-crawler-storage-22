from pathlib import Path
from agentone.tui.utils import Styles

styles = Styles(styles_directory=Path(__file__).parent / 'styles')
