from configparser import ConfigParser
from os import environ
from pathlib import Path
from typing import Optional


class Config:
    """Обеспечивает чтение конфигурационного файла и интеграцию его параметров в системные переменные окружения.

    Этот класс предоставляет функциональность для чтения конфигурационного файла,
    использования его параметров в коде и опционально записывает их в переменные окружения.
    """

    def __init__(self, path: Path, filename: str = 'app.ini'):
        """Инициализирует объект Config, загружает файл конфигурации.

        Метод инициализирует объект конфигурации и проверяет существование указанного конфигурационного файла.
        Если файл не найден, выбрасывается исключение `FileNotFoundError`.

        Args:
            path (Path): Путь к каталогу, где находится конфигурационный файл.
            filename (str): Имя конфигурационного файла, по умолчанию 'app.ini'.

        Raises:
            FileNotFoundError: Если файл конфигурации не найден по указанному пути.
        """
        fullpath: Path = path.joinpath(filename)
        if not fullpath.exists():
            raise FileNotFoundError(f'Config file {filename} not found! You gave fullpath: {fullpath}')
        self.config: ConfigParser = ConfigParser()
        self.config.read(fullpath)

    def read(
        self,
        debug: bool = False,
        to_env: bool = True,
        return_config: bool = False,
        override_env: bool = False
    ) -> Optional[ConfigParser]:
        """
        Читает конфигурационный файл и опционально записывает параметры в переменные окружения.

        Этот метод считывает конфигурационные параметры из файла и записывает их в переменные окружения
        для доступа к ним через формат `SECTION_PARAMETER`. Также можно включить режим отладки,
        чтобы увидеть параметры в выводе консоли, или вернуть сам объект конфигурации.

        Args:
            debug (bool): Если True, выводит параметры в консоль для отладки. По умолчанию False.
            to_env (bool): Если True, записывает параметры в системные переменные окружения. По умолчанию True.
            return_config (bool): Если True, возвращает объект конфигурации ConfigParser. По умолчанию False.
            override_env (bool): Перезаписывать ли имеющиеся системные переменные значениями из конфигурации.

        Returns:
            Optional[ConfigParser]: Возвращает объект ConfigParser, если параметр `return_config` установлен в True.
            Если False, возвращает None.

        Raises:
            None: Этот метод не выбрасывает исключений, но возможны ошибки при доступе к переменным окружения
            через другие части программы, если они некорректно установлены.

        Пример использования:
            Если параметр в конфиге выглядит так:

                [database]
                host = localhost
                port = 5432

            После вызова метода с `to_env=True`, в системных переменных будут доступны следующие ключи:

                DATABASE_HOST=localhost
                DATABASE_PORT=5432
        """
        if to_env:
            for section in self.config:
                for parameter in self.config[section]:
                    key = f"{section.upper()}_{parameter.upper()}"
                    value = self.config[section][parameter]
                    if debug:
                        print(f"CONFIG DEBUG: {key}: {value}")
                    if override_env or key not in environ:
                        environ.update({key: value})
        if return_config:
            return self.config
        return None
