from pathlib import Path
from platformdirs import user_log_dir


def get_log_directory(app_name: str, create: bool = True) -> Path:
    r"""
        Получает правильную, платформо-зависимую директорию для логов.
        Linux: ~/.local/share/{app_name}/logs/
        Windows: C:\Users\<user>\AppData\Local\{app_name}\Logs\
        macOS: ~/Library/Logs/{app_name}/
    """
    log_dir = Path(user_log_dir(app_name, appauthor=False))
    if create:
        log_dir.mkdir(parents=True, exist_ok=True)

    return log_dir
