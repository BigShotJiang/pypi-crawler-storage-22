"""
AgentOne - Smart utilities for AI agents swarm infrastructure
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("agentone")
except PackageNotFoundError:
    __version__ = "dev"

__all__ = ["__version__"]
