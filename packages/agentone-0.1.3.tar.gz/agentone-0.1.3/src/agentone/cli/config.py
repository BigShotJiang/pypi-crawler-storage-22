from pathlib import Path
from typer import Typer, Argument, Option
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from enum import Enum
from yaml import dump
from agentone.utils.config import YAMLConfig

configuration = Typer(help='Работа с конфигурациями AgentOne')
console = Console()


class ConfigType(str, Enum):
    """Типы конфигураций для проверки (зависит от того, по какой модели валидируем)"""
    DAEMON = "daemon"
    MINERVA = "minerva"


@configuration.command()
def check(
        config_path: str = Argument(
            ...,
            help="Путь к конфигурационному файлу относительно текущей директории"
        ),
        config_type: ConfigType = Option(
            ConfigType.DAEMON,
            "--type", "-t",
            help="Тип конфигурации для валидации"
        ),
        show: bool = Option(
            False,
            "--show", "-s",
            help='Показать ли JSON детали конфигурации'
        )
):
    """Проверка конфигурации на валидное заполнение"""
    try:
        file_path = Path.cwd() / config_path
        if not file_path.exists():
            console.print(f"[red][ERROR][/red] Файл не найден: {file_path}")
            raise SystemExit(1)
        config_loader = YAMLConfig(file_path.parent, file_path.name)
        with console.status("[bold green]Проверяем модель данных...[/bold green]", spinner="dots") as status:
            match config_type:
                case ConfigType.MINERVA:
                    console.print("[yellow][WARNING][/yellow] Тип 'minerva' еще не имплементирован")
                    raise NotImplementedError("Config type 'minerva' is not implemented yet")
                case ConfigType.DAEMON:
                    from agentone.daemons.models.config import DaemonConfig
                    loaded_config = config_loader.load(DaemonConfig)
                case _:
                    raise ValueError('')

            console.log(f"[green][SUCCESS][/green] Конфигурация валидна{'!' if not show else ', содержимое проверяемого конфига:'}")
            if show:
                yaml_str = dump(loaded_config.model_dump(), sort_keys=False, allow_unicode=True)
                syntax = Syntax(yaml_str, "yaml", theme="monokai", line_numbers=True)
                console.print(Panel(
                    syntax,
                    title=f"[bold green]{file_path}[/bold green]",
                    expand=False
                ))

    except Exception as e:
        console.print(Panel(
            f"[red][ERROR][/red] Ошибка валидации:\n\n{str(e)}",
            title="[bold red]Ошибка[/bold red]",
            border_style="red"
        ))
        raise SystemExit(1)
