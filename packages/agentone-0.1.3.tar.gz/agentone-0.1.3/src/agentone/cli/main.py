"""
Entry point for CLI
"""
from rich.panel import Panel
from typer import Typer
from rich.console import Console
from agentone.cli.config import configuration
from agentone import __version__

app = Typer(help='AgentOne - agents swarm framework')
console = Console()

app.add_typer(configuration, name='config')


@app.command()
def version():
    """Версия AgentOne."""
    console.print(Panel(f"[bold blue]AgentOne:[/bold blue] v{__version__}", expand=False))


def main():
    """Entry point для CLI"""
    app()


if __name__ == '__main__':
    main()
