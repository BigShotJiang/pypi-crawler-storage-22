from typing import Optional, List
from pydantic import BaseModel, Field
from agentone.daemons.models.config.agent import AgentConfig
from agentone.daemons.models.config.integrations import IntegrationsConfig
from agentone.daemons.models.config.llm_model import ModelConfig
from agentone.daemons.models.config.mcp import MCPConnection
from agentone.daemons.models.config.skills import SkillConfig
from agentone.daemons.models.config.swarm import SwarmConfig


class DaemonConfig(BaseModel):
    """
    Корневая схема конфигурации демона роя.
    """
    name: str = Field(..., description='Человекочитаемое имя агента.')
    version: str = Field(..., description='Версия агента.')

    model: ModelConfig = Field(..., description='LLM модель используемая агентом и ее настройки.')
    agent: AgentConfig = Field(..., description='Настройки личности демона/агента.')
    integrations: Optional[IntegrationsConfig] = Field(None, description='Настройки интеграций сервисов (Например: Langfuse).')
    swarm: SwarmConfig = Field(..., description='Настройки роя, к которому подкючен демон.')

    mcp: List[MCPConnection] = Field(default_factory=list, description='Настройки MCP подключений.')
    skills: List[SkillConfig] = Field(default_factory=list, description='Настройки скиллов агента для загрузки.')

    class Config:
        extra = "forbid"


__all__ = [
    "DaemonConfig"
]
