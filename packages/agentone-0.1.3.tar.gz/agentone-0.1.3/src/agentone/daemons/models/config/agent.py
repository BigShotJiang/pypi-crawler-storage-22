from pydantic import BaseModel, Field
from agentone.daemons.models.config.prompts import SystemPromptConfig


class AgentConfig(BaseModel):
    """Конфигурация личности агента."""
    role: str = Field(..., description="Роль (идентификатор в БД).")
    system_prompt: SystemPromptConfig
