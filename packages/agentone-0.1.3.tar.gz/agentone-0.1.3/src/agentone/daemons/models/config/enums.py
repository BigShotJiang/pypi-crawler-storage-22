from enum import Enum


class MCPTransport(str, Enum):
    STREAMABLE_HTTP = "streamable-http"
    SSE = "sse"


class MCPType(str, Enum):
    HTTP = "http"
    STDIO = "stdio"


class SkillSourceType(str, Enum):
    HTTP = "http"
    FILE = "file"
    DIRECTORY = "directory"


class PromptFileType(str, Enum):
    HTTP = "http"
    LOCAL = "local"
