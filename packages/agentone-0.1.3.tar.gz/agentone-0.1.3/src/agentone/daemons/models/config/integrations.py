from typing import Optional
from pydantic import BaseModel, Field, SecretStr
from agentone.daemons.models.config.types import URLField


class LangfuseIntegration(BaseModel):
    """Глобальные настройки подключения к Langfuse."""
    base_url: URLField = Field(..., description="Хост Langfuse (Cloud или Self-hosted).")
    public_key: str = Field(..., description="Public Key проекта.")
    secret_key: SecretStr = Field(..., description="Secret Key проекта.")


class IntegrationsConfig(BaseModel):
    """Блок внешних интеграций."""
    langfuse: Optional[LangfuseIntegration] = Field(None, description="Настройки Langfuse.")
