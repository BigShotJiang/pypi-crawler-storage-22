from pydantic import BaseModel, Field, SecretStr
from agentone.daemons.models.config.types import URLField


class ModelParameters(BaseModel):
    """Параметры инференса LLM"""
    temperature: float = Field(0.1, ge=0.0, le=2.0, description="Температура генерации.")
    max_tokens: int = Field(4096, gt=0, description="Лимит токенов на вывод.")
    top_p: float = Field(0.95, ge=0.0, le=1.0, description="Nucleus sampling.")
    context_window: int = Field(16000, gt=0, description="Размер контекстного окна.")


class ModelConfig(BaseModel):
    """Настройки LLM провайдера."""
    name: str = Field(..., description="ID модели (напр. qwen/qwen3-14b).")
    base_url: URLField = Field(..., description="API Endpoint.")
    api_key: SecretStr = Field(..., description="API ключ.")
    parameters: ModelParameters
