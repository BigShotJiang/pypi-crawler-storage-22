from typing import Literal, Optional, List, Dict, Annotated, Union
from pydantic import BaseModel, SecretStr, Field
from agentone.daemons.models.config.enums import MCPType, MCPTransport


class MCPHttp(BaseModel):
    """
    Конфигурация подключения к удаленному MCP-серверу по протоколу HTTP или SSE.
    Используется для интеграции с внешними инструментами, API и сервисами, доступными через сеть.
    """
    type: Literal[MCPType.HTTP] = Field(
        MCPType.HTTP,
        description="Тип подключения (дискриминатор). Для сетевых подключений всегда 'http'."
    )
    title: str = Field(
        ...,
        min_length=1,
        description="Человекочитаемое название подключения. Используется в логах и для идентификации агентом."
    )
    url: str = Field(
        ...,
        description="Полный URL эндпоинта MCP-сервера (например, 'https://mcp.agentone.sh/sse')."
    )
    transport: MCPTransport = Field(
        default=MCPTransport.STREAMABLE_HTTP,
        description="Тип транспорта: 'sse' (Server-Sent Events) или 'streamable-http' для постоянного соединения."
    )
    key: Optional[SecretStr] = Field(
        default=None,
        description="Секретный ключ или токен авторизации (передается в заголовках запроса)."
    )
    timeout: int = Field(
        default=30,
        ge=1,
        description="Таймаут ожидания ответа от сервера в секундах."
    )
    description: Optional[str] = Field(
        default=None,
        description="Дополнительное описание возможностей сервера для системного промпта агента."
    )


class MCPStdio(BaseModel):
    """
    Конфигурация локального MCP-сервера, запускаемого через стандартный ввод/вывод (STDIO).
    Используется для запуска локальных скриптов, бинарных файлов или Docker-контейнеров
    (через 'docker run ...'), которые работают по протоколу MCP.
    """
    type: Literal[MCPType.STDIO] = Field(
        MCPType.STDIO,
        description="Тип подключения (дискриминатор). Для локальных процессов всегда 'stdio'."
    )
    title: str = Field(
        ...,
        min_length=1,
        description="Человекочитаемое название инструмента."
    )
    command: str = Field(
        ...,
        description="Основная команда для запуска процесса (например, 'docker', 'python', 'uv')."
    )
    args: List[str] = Field(
        default_factory=list,
        description="Список аргументов командной строки (например, ['run', '-i', '--rm', 'image:tag'])."
    )
    env: Dict[str, str] = Field(
        default_factory=dict,
        description="Словарь переменных окружения, которые будут переданы в запускаемый процесс."
    )


# Union тип с дискриминатором для полиморфного списка
MCPConnection = Annotated[
    Union[MCPHttp, MCPStdio],
    Field(discriminator="type", description="Полиморфное подключение MCP (HTTP или STDIO).")
]