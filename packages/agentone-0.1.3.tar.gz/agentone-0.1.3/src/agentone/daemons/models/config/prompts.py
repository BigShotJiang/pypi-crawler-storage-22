from typing import Optional
from pydantic import BaseModel, Field, model_validator
from agentone.daemons.models.config.enums import PromptFileType


class LangfusePromptRef(BaseModel):
    """Ссылка на промпт в реестре Langfuse."""
    name: str = Field(..., description="Имя промпта (prompt name).")
    version: str = Field(..., description="Версия или тег (production/latest).")


class PromptFileSource(BaseModel):
    """Источник промпта из файла."""
    type: PromptFileType = Field(..., description="Тип источника (http/local).")
    path: str = Field(..., description="Путь к файлу или URL.")


class SystemPromptConfig(BaseModel):
    """
    Конфигурация системного промпта (Waterfall priority).
    """
    langfuse: Optional[LangfusePromptRef] = Field(None, description="1. Загрузка из Langfuse.")
    file: Optional[PromptFileSource] = Field(None, description="2. Загрузка из файла.")
    content: Optional[str] = Field(None, description="3. Hardcoded fallback.")

    @model_validator(mode='after')
    def check_at_least_one_source(self):
        if not self.langfuse and not self.file and not self.content:
            raise ValueError(
                "System Prompt Configuration Error: "
                "You must provide at least one prompt source: 'langfuse', 'file', or 'content'."
            )
        return self
