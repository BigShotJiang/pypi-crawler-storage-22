from pydantic import BaseModel, Field
from agentone.daemons.models.config.enums import SkillSourceType


class SkillConfig(BaseModel):
    """Подключаемые для агента навыки."""
    title: str = Field(..., description='Человекочитаемое название навыка для логов.')
    source: str = Field(..., description='Строка содержащая путь/ссылку к файлу/директории с загружаемым навыком.')
    type: SkillSourceType = Field(..., description='Тип источника. Ссылка, локальный файл или локальная директория с файлами.')

