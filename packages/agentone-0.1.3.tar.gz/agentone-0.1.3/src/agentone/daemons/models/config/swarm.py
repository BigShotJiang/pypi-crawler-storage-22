from typing import List
from pydantic import BaseModel, Field, SecretStr
from agentone.daemons.models.config.types import TopicMaskString


class NatsAuth(BaseModel):
    """Аутентификация NATS (NKeys/JWT)."""
    jwt: str = Field(..., description="User JWT токен.")
    seed: SecretStr = Field(..., description="NKeys User Seed (SU...).")


class NatsConfig(BaseModel):
    """Транспортный уровень NATS."""
    host: str = Field("127.0.0.1")
    port: int = Field(4222, ge=1, le=65535)
    auth: NatsAuth


class SwarmSubscriptions(BaseModel):
    """Топики подписки демона в рое."""
    workload: List[TopicMaskString] = Field(..., description="Задачи с балансировкой (Queue Group).")
    broadcast: List[TopicMaskString] = Field(..., description="Управляющие команды (Broadcast).")


class SwarmConfig(BaseModel):
    """Настройки роя."""
    nats: NatsConfig
    queue_group: str = Field(..., description="Имя группы для балансировки (Load Balancing).")
    subscriptions: SwarmSubscriptions

