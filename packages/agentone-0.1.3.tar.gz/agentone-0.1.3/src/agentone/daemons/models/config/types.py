from typing import Annotated
from pydantic import HttpUrl, AfterValidator


def validate_http_url(url: str) -> str:
    """
    Пытается привести строку к типу HttpUrl для валидации.
    Если успешно -- возвращается строка в исходном виде.
    Если не успешно -- выкидывается исключение ValidationError.
    Обеспечивает валидацию сохраняя строковый тип значения в модели.

    url: Строка с http ссылкой которую необходимо провалидировать.
    """
    HttpUrl(url)
    return url


def validate_topic_structure(topic: str) -> str:
    """
    Валидирует топик подписки демона на предмет наличия 6 секций
    разделенных точкой или окончание на * если секций меньше.
    """
    parts = topic.split('.')
    count = len(parts)

    if count > 6:
        raise ValueError(f"Too many sections ({count}). Maximum allowed is 6.")
    if count == 6:
        return topic
    if count < 6:
        if parts[-1] != '*':
            raise ValueError(f"Incomplete topic path ({count}/6). Must end with wildcard '*' if less than 6 sections.")
    return topic


URLField = Annotated[str, AfterValidator(validate_http_url)]
TopicMaskString = Annotated[str, AfterValidator(validate_topic_structure)]
