from os import environ
from typing import Optional, Any
from ._config import Config
from ._yaml import YAMLConfig

__all__ = [
    'Config',
    'env',
    'YAMLConfig',
]


def env(key: str, default: Optional[Any] = None, cast=None) -> str | Any:
    """Читаем переменную окружения с опциональным кастом типа."""
    v = environ.get(key, default)
    if cast and v is not None:
        try:
            return cast(v)
        except Exception as e:
            print(e)
            return default
    return v

