from os import environ
from pathlib import Path
from typing import TypeVar, Type
from re import compile
import yaml
from pydantic import BaseModel, ValidationError


T = TypeVar('T', bound=BaseModel)


class YAMLConfig:
    """
    Атомарный класс для чтения и валидации YAML конфигураций по Pydantic моделям.
    Возможности:
    - Чтение YAML файлов
    - Подстановка переменных окружения ${VAR} или ${VAR:default}
    - Валидация по Pydantic схеме
    - Удобное API
    """

    ENV_VAR_PATTERN = compile(r'\$\{([^}:]+)(?::([^}]*))?\}')

    def __init__(self, path: Path, filename: str = 'config.yml'):
        """
        Инициализирует конфигурацию.
        Args:
            path: Путь к директории с конфигурационным файлом
            filename: Имя YAML файла
        Raises:
            FileNotFoundError: Если файл не найден
        """
        self.filepath = path / filename
        if not self.filepath.exists():
            raise FileNotFoundError(
                f'Config file {filename} not found at {self.filepath}'
            )
        self._raw_data = None

    def _substitute_env_vars(self, value):
        """
        Рекурсивно подставляет переменные окружения в значения.
        Поддерживает формат: ${VAR} или ${VAR:default_value}
        """
        if isinstance(value, str):
            def replace_var(match):
                var_name = match.group(1)
                default_value = match.group(2)
                return environ.get(var_name, default_value or '')

            return self.ENV_VAR_PATTERN.sub(replace_var, value)

        elif isinstance(value, dict):
            return {k: self._substitute_env_vars(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._substitute_env_vars(item) for item in value]

        return value

    def load_raw(self, substitute_env: bool = True) -> dict:
        """
        Загружает YAML файл в словарь без валидации.
        Args:
            substitute_env: Подставлять ли переменные окружения
        Returns:
            Словарь с конфигурацией
        """
        with open(self.filepath, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)

        if substitute_env:
            data = self._substitute_env_vars(data)

        self._raw_data = data
        return data

    def load(
            self,
            model: Type[T],
            substitute_env: bool = True,
            strict: bool = True
    ) -> T | dict:
        """
        Загружает и валидирует YAML конфигурацию по Pydantic модели.
        Args:
            model: Pydantic модель для валидации
            substitute_env: Подставлять ли переменные окружения
            strict: Строгая ли валидация (выбрасывать ошибки)
        Returns:
            Валидированный объект Pydantic модели
        Raises:
            ValidationError: Если валидация не прошла (при strict=True)
        Example:
            >>> from agentone.daemons.models.config import DaemonConfig
            >>> config = YamlConfig(Path(__file__).parent.resolve(), 'daemon.yml')
            >>> daemon_cfg = config.load(DaemonConfig)
            >>> print(daemon_cfg.name)
        """
        raw_data = self.load_raw(substitute_env=substitute_env)

        try:
            return model(**raw_data)
        except ValidationError as e:
            if strict:
                raise e
            else:
                print("[WARNING] Confing invalid, but strict=False. Returned raw data.")
                print(e)
                return raw_data
