# Init for eval module
