"""Agentrial test suite."""
