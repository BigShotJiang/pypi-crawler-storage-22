"""Basic usage examples for the AgentSandbox SDK."""

import os
import sys

from agentsandbox import AgentSandbox, AsyncAgentSandbox, Language


def check_api_key() -> bool:
    """Check if API key is set and prompt user if not."""
    if not os.environ.get("AGENTSANDBOX_API_KEY"):
        print("Error: AGENTSANDBOX_API_KEY environment variable is not set.")
        print()
        print("Please set it before running this example:")
        print("  export AGENTSANDBOX_API_KEY='your-api-key'")
        return False
    return True


def test_basic_execution():
    """Test basic code execution."""
    print("\n=== Test: Basic Execution ===")
    client = AgentSandbox()

    result = client.run("print('Hello, World!')")
    print(f"stdout: {result.stdout}")
    print(f"return_code: {result.return_code}")
    print(f"exit_code (alias): {result.exit_code}")
    print(f"success: {result.success}")
    assert result.success, "Basic execution should succeed"
    assert "Hello, World!" in result.stdout
    print("PASSED")
    client.close()


def test_bash_execution():
    """Test bash code execution."""
    print("\n=== Test: Bash Execution ===")
    client = AgentSandbox()

    result = client.run("echo 'Hello from bash!' && pwd", language=Language.BASH)
    print(f"stdout: {result.stdout}")
    assert result.success, "Bash execution should succeed"
    assert "Hello from bash!" in result.stdout
    print("PASSED")
    client.close()


def test_env_vars_injection():
    """Test environment variables injection during execution."""
    print("\n=== Test: Environment Variables Injection ===")
    client = AgentSandbox()

    # Test env_vars parameter on execute
    result = client.run(
        """
import os
print(f"MY_VAR={os.environ.get('MY_VAR', 'NOT_SET')}")
print(f"SECRET_KEY={os.environ.get('SECRET_KEY', 'NOT_SET')}")
""",
        env_vars={"MY_VAR": "hello_world", "SECRET_KEY": "supersecret123"},
    )
    print(f"stdout: {result.stdout}")
    assert result.success, "Execution with env_vars should succeed"
    assert "MY_VAR=hello_world" in result.stdout
    assert "SECRET_KEY=supersecret123" in result.stdout
    print("PASSED")
    client.close()


def test_file_injection_on_execute():
    """Test file injection during execution via file_ids parameter."""
    print("\n=== Test: File Injection on Execute ===")
    client = AgentSandbox()

    # Upload a file first
    uploaded = client.files.upload(
        b"name,value\nalice,100\nbob,200",
        filename="data.csv",
        content_type="text/csv",
    )
    print(f"Uploaded file: {uploaded.file_id}")

    # Execute code with file_ids - file should be in /workspace
    result = client.run(
        """
import os
# List workspace contents
print("Workspace contents:", os.listdir('/workspace'))

# Read the injected file
with open('/workspace/data.csv') as f:
    content = f.read()
print("File content:")
print(content)
""",
        file_ids=[uploaded.file_id],
    )
    print(f"stdout: {result.stdout}")
    assert result.success, "Execution with file_ids should succeed"
    assert "data.csv" in result.stdout
    assert "alice,100" in result.stdout
    print("PASSED")

    # Cleanup
    client.files.delete(uploaded.file_id)
    client.close()


def test_session_with_env_vars():
    """Test session creation with environment variables."""
    print("\n=== Test: Session with Environment Variables ===")
    client = AgentSandbox()

    # Create session with env_vars
    with client.sessions.context(env_vars={"SESSION_VAR": "from_session"}) as session:
        print(f"Created session: {session.session_id}")

        result = client.run(
            """
import os
print(f"SESSION_VAR={os.environ.get('SESSION_VAR', 'NOT_SET')}")
""",
            session_id=session.session_id,
        )
        print(f"stdout: {result.stdout}")
        assert result.success
        assert "SESSION_VAR=from_session" in result.stdout

    print("PASSED")
    client.close()


def test_session_with_file_ids():
    """Test session creation with pre-injected files via file_ids."""
    print("\n=== Test: Session with file_ids ===")
    client = AgentSandbox()

    # Upload a file
    uploaded = client.files.upload(
        b"config_value=42",
        filename="config.txt",
    )
    print(f"Uploaded file: {uploaded.file_id}")

    # Create session with file_ids - file should be pre-loaded in /workspace
    with client.sessions.context(file_ids=[uploaded.file_id]) as session:
        print(f"Created session: {session.session_id}")

        result = client.run(
            """
import os
print("Workspace contents:", os.listdir('/workspace'))
with open('/workspace/config.txt') as f:
    print("Config:", f.read())
""",
            session_id=session.session_id,
        )
        print(f"stdout: {result.stdout}")
        assert result.success
        assert "config.txt" in result.stdout
        assert "config_value=42" in result.stdout

    print("PASSED")
    client.files.delete(uploaded.file_id)
    client.close()


def test_inject_files_into_session():
    """Test injecting files into an existing session via inject_files()."""
    print("\n=== Test: Inject Files into Existing Session ===")
    client = AgentSandbox()

    # Create a session first
    session = client.sessions.create()
    print(f"Created session: {session.session_id}")

    # Verify workspace is empty initially
    result = client.run(
        "import os; print('Files:', os.listdir('/workspace'))",
        session_id=session.session_id,
    )
    print(f"Initial workspace: {result.stdout}")

    # Upload a file
    uploaded = client.files.upload(
        b"injected_content=123",
        filename="injected.txt",
    )
    print(f"Uploaded file: {uploaded.file_id}")

    # Inject file into existing session
    client.sessions.inject_files(session.session_id, [uploaded.file_id])
    print("Injected file into session")

    # Verify file is now in workspace
    result = client.run(
        """
import os
print("Files:", os.listdir('/workspace'))
with open('/workspace/injected.txt') as f:
    print("Content:", f.read())
""",
        session_id=session.session_id,
    )
    print(f"stdout: {result.stdout}")
    assert result.success
    assert "injected.txt" in result.stdout
    assert "injected_content=123" in result.stdout

    print("PASSED")
    client.sessions.delete(session.session_id)
    client.files.delete(uploaded.file_id)
    client.close()


def test_execution_log():
    """Test retrieving execution logs (verifies ExecutionLog model)."""
    print("\n=== Test: Execution Log Retrieval ===")
    client = AgentSandbox()

    # Run code that produces output files
    result = client.run(
        """
print('Testing execution log')
with open('/workspace/output.txt', 'w') as f:
    f.write('test output')
"""
    )
    print(f"Execution session_id: {result.session_id}")
    print(f"stdout: {result.stdout}")
    print(f"Files created: {result.files}")

    # The session_id from execute response can be used to get execution details
    # Note: The API returns execution_id differently - let's verify the response structure
    if result.files:
        print(f"Created file: {result.files[0].file_id} - {result.files[0].filename}")
        # Clean up the created file
        client.files.delete(result.files[0].file_id)

    print("PASSED")
    client.close()


def test_session_lifecycle():
    """Test full session lifecycle: create, use, list, get, delete."""
    print("\n=== Test: Session Lifecycle ===")
    client = AgentSandbox()

    # Create
    session = client.sessions.create()
    print(f"Created: {session.session_id}")
    assert session.session_id
    assert session.created is True

    # List
    sessions = client.sessions.list()
    print(f"Sessions: {sessions.sessions}")
    assert session.session_id in sessions.sessions

    # Get
    fetched = client.sessions.get(session.session_id)
    print(f"Fetched: {fetched.session_id}, created={fetched.created}")
    assert fetched.session_id == session.session_id
    assert fetched.created is False  # Already existed

    # Use
    result = client.run("print('in session')", session_id=session.session_id)
    assert result.success

    # Delete
    client.sessions.delete(session.session_id)
    print("Deleted session")

    # Verify deleted
    sessions = client.sessions.list()
    assert session.session_id not in sessions.sessions

    print("PASSED")
    client.close()


def test_file_operations():
    """Test file upload, list, download, delete."""
    print("\n=== Test: File Operations ===")
    client = AgentSandbox()

    # Upload
    content = b"Hello, this is test content!"
    uploaded = client.files.upload(content, filename="test.txt", content_type="text/plain")
    print(f"Uploaded: {uploaded.file_id}, {uploaded.filename}, {uploaded.size_bytes} bytes")
    assert uploaded.filename == "test.txt"
    assert uploaded.size_bytes == len(content)

    # List
    files = client.files.list()
    print(f"Total files: {files.total}")
    file_ids = [f.file_id for f in files.files]
    assert uploaded.file_id in file_ids

    # Download
    downloaded = client.files.download(uploaded.file_id)
    print(f"Downloaded: {len(downloaded)} bytes")
    assert downloaded == content

    # Delete
    client.files.delete(uploaded.file_id)
    print("Deleted file")

    # Verify deleted
    files = client.files.list()
    file_ids = [f.file_id for f in files.files]
    assert uploaded.file_id not in file_ids

    print("PASSED")
    client.close()


def sync_examples():
    """Run all synchronous examples/tests."""
    test_basic_execution()
    test_bash_execution()
    test_env_vars_injection()
    test_file_injection_on_execute()
    test_session_with_env_vars()
    test_session_with_file_ids()
    test_inject_files_into_session()
    test_execution_log()
    test_session_lifecycle()
    test_file_operations()


async def async_examples():
    """Asynchronous client examples."""
    print("\n" + "=" * 50)
    print("ASYNC EXAMPLES")
    print("=" * 50)

    client = AsyncAgentSandbox()

    print("\n=== Async: Basic Execution ===")
    result = await client.run("print('Hello from async!')")
    print(f"stdout: {result.stdout}")
    assert result.success

    print("\n=== Async: Env Vars ===")
    result = await client.run(
        "import os; print(os.environ.get('ASYNC_VAR', 'NOT_SET'))",
        env_vars={"ASYNC_VAR": "async_value"},
    )
    print(f"stdout: {result.stdout}")
    assert "async_value" in result.stdout

    print("\n=== Async: Session with Files ===")
    uploaded = await client.files.upload(b"async data", filename="async.txt")
    print(f"Uploaded: {uploaded.file_id}")

    async with client.sessions.context(file_ids=[uploaded.file_id]) as session:
        result = await client.run(
            "import os; print(os.listdir('/workspace'))",
            session_id=session.session_id,
        )
        print(f"stdout: {result.stdout}")
        assert "async.txt" in result.stdout

    await client.files.delete(uploaded.file_id)
    print("ASYNC TESTS PASSED")

    await client.close()


if __name__ == "__main__":
    print("AgentSandbox SDK - Verification Tests")
    print("=" * 50)

    if not check_api_key():
        sys.exit(1)

    print("\n" + "=" * 50)
    print("SYNC EXAMPLES")
    print("=" * 50)
    sync_examples()

    print("\n" + "=" * 50)
    print("Running async examples...")
    print("=" * 50)
    import asyncio

    asyncio.run(async_examples())

    print("\n" + "=" * 50)
    print("ALL TESTS PASSED!")
    print("=" * 50)
