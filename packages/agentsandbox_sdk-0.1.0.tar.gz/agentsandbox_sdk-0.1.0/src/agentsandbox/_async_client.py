"""Asynchronous AgentSandbox client."""

from __future__ import annotations

from types import TracebackType
from typing import TYPE_CHECKING

import httpx

from agentsandbox._base_client import AsyncHTTPClient
from agentsandbox.resources.execute import AsyncExecuteResource
from agentsandbox.resources.executions import AsyncExecutionsResource
from agentsandbox.resources.files import AsyncFilesResource
from agentsandbox.resources.sessions import AsyncSessionsResource
from agentsandbox.types.execute import ExecuteResponse
from agentsandbox.types.shared import Language


class AsyncAgentSandbox:
    """Asynchronous client for the AgentSandbox API.

    Example:
        >>> client = AsyncAgentSandbox(api_key="your-api-key")
        >>> result = await client.run("print('Hello, World!')")
        >>> print(result.stdout)
        Hello, World!

    The client can also be used as an async context manager:
        >>> async with AsyncAgentSandbox(api_key="your-api-key") as client:
        ...     result = await client.run("print('Hello!')")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        """Initialize the AsyncAgentSandbox client.

        Args:
            api_key: API key for authentication. If not provided, reads from
                AGENTSANDBOX_API_KEY environment variable.
            base_url: Base URL for the API. If not provided, reads from
                AGENTSANDBOX_BASE_URL or uses the default.
            timeout: Request timeout in seconds. Defaults to 120 seconds.
            http_client: Optional pre-configured httpx.AsyncClient to use.
        """
        self._http = AsyncHTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            http_client=http_client,
        )

        # Initialize resources
        self.execute = AsyncExecuteResource(self._http)
        self.sessions = AsyncSessionsResource(self._http)
        self.files = AsyncFilesResource(self._http)
        self.executions = AsyncExecutionsResource(self._http)

    async def run(
        self,
        code: str,
        *,
        language: Language | str = Language.PYTHON,
        session_id: str | None = None,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> ExecuteResponse:
        """Execute code in a sandbox (convenience method).

        This is a shorthand for `await client.execute.create()`.

        Args:
            code: The code to execute.
            language: Programming language ('python' or 'bash').
            session_id: Optional session ID for persistent workspace.
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace before execution.

        Returns:
            ExecuteResponse with stdout, stderr, and exit_code.

        Note:
            Each execution runs in a fresh process. Variables do NOT persist
            between executions. Use /workspace files to share state within
            a session.

        Example:
            >>> result = await client.run("print(1 + 1)")
            >>> print(result.stdout)
            2
        """
        return await self.execute.create(
            code,
            language=language,
            session_id=session_id,
            env_vars=env_vars,
            file_ids=file_ids,
        )

    async def close(self) -> None:
        """Close the HTTP client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> AsyncAgentSandbox:
        """Enter async context manager."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context manager and close client."""
        await self.close()
