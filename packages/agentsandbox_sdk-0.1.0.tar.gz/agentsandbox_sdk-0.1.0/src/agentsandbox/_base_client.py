"""Base client with shared HTTP logic for sync and async clients."""

from __future__ import annotations

import os
from typing import Any, Mapping

import httpx

from agentsandbox._constants import API_VERSION, DEFAULT_BASE_URL, DEFAULT_TIMEOUT
from agentsandbox._exceptions import raise_for_status


class BaseClient:
    """Shared configuration and utilities for HTTP clients."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("AGENTSANDBOX_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key must be provided either as an argument or via "
                "the AGENTSANDBOX_API_KEY environment variable"
            )

        self.base_url = (base_url or os.environ.get("AGENTSANDBOX_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout or DEFAULT_TIMEOUT
        self.api_version = API_VERSION

    def _build_url(self, path: str) -> str:
        """Build full URL for an API endpoint."""
        path = path.lstrip("/")
        if not path.startswith(f"{self.api_version}/"):
            path = f"{self.api_version}/{path}"
        return f"{self.base_url}/{path}"

    def _build_headers(self, extra_headers: Mapping[str, str] | None = None) -> dict[str, str]:
        """Build headers for a request."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def _handle_response(self, response: httpx.Response) -> Any:
        """Handle response and raise appropriate exceptions for errors."""
        if response.status_code >= 400:
            try:
                body = response.json()
                message = body.get("error", {}).get("message", response.text)
            except Exception:
                body = None
                message = response.text or f"HTTP {response.status_code}"

            raise_for_status(response.status_code, message, body)

        if response.status_code == 204:
            return None

        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            return response.json()
        return response.content


class SyncHTTPClient(BaseClient):
    """Synchronous HTTP client."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__(api_key, base_url, timeout)
        self._client = http_client
        self._owns_client = http_client is None

    @property
    def client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(timeout=self.timeout)
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None and self._owns_client:
            self._client.close()
            self._client = None

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        content: bytes | None = None,
        files: Any = None,
    ) -> Any:
        """Make an HTTP request."""
        url = self._build_url(path)
        request_headers = self._build_headers(headers)

        if files is not None:
            # Remove Content-Type for multipart uploads
            request_headers.pop("Content-Type", None)

        response = self.client.request(
            method,
            url,
            json=json,
            params=params,
            headers=request_headers,
            content=content,
            files=files,
        )
        return self._handle_response(response)

    def get(self, path: str, **kwargs: Any) -> Any:
        """Make a GET request."""
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> Any:
        """Make a POST request."""
        return self.request("POST", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Any:
        """Make a DELETE request."""
        return self.request("DELETE", path, **kwargs)

    def get_raw(self, path: str, **kwargs: Any) -> bytes:
        """Make a GET request and return raw bytes."""
        url = self._build_url(path)
        headers = self._build_headers(kwargs.pop("headers", None))
        headers.pop("Accept", None)  # Accept any content type

        response = self.client.get(url, headers=headers, **kwargs)
        if response.status_code >= 400:
            self._handle_response(response)
        return response.content


class AsyncHTTPClient(BaseClient):
    """Asynchronous HTTP client."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(api_key, base_url, timeout)
        self._client = http_client
        self._owns_client = http_client is None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None and self._owns_client:
            await self._client.aclose()
            self._client = None

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        content: bytes | None = None,
        files: Any = None,
    ) -> Any:
        """Make an HTTP request."""
        url = self._build_url(path)
        request_headers = self._build_headers(headers)

        if files is not None:
            request_headers.pop("Content-Type", None)

        response = await self.client.request(
            method,
            url,
            json=json,
            params=params,
            headers=request_headers,
            content=content,
            files=files,
        )
        return self._handle_response(response)

    async def get(self, path: str, **kwargs: Any) -> Any:
        """Make a GET request."""
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> Any:
        """Make a POST request."""
        return await self.request("POST", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> Any:
        """Make a DELETE request."""
        return await self.request("DELETE", path, **kwargs)

    async def get_raw(self, path: str, **kwargs: Any) -> bytes:
        """Make a GET request and return raw bytes."""
        url = self._build_url(path)
        headers = self._build_headers(kwargs.pop("headers", None))
        headers.pop("Accept", None)

        response = await self.client.get(url, headers=headers, **kwargs)
        if response.status_code >= 400:
            self._handle_response(response)
        return response.content
