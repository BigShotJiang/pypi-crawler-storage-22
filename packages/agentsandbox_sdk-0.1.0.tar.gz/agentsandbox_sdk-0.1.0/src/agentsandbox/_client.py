"""Synchronous AgentSandbox client."""

from __future__ import annotations

from types import TracebackType
from typing import TYPE_CHECKING

import httpx

from agentsandbox._base_client import SyncHTTPClient
from agentsandbox.resources.execute import ExecuteResource
from agentsandbox.resources.executions import ExecutionsResource
from agentsandbox.resources.files import FilesResource
from agentsandbox.resources.sessions import SessionsResource
from agentsandbox.types.execute import ExecuteResponse
from agentsandbox.types.shared import Language


class AgentSandbox:
    """Synchronous client for the AgentSandbox API.

    Example:
        >>> client = AgentSandbox(api_key="your-api-key")
        >>> result = client.run("print('Hello, World!')")
        >>> print(result.stdout)
        Hello, World!

    The client can also be used as a context manager:
        >>> with AgentSandbox(api_key="your-api-key") as client:
        ...     result = client.run("print('Hello!')")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        """Initialize the AgentSandbox client.

        Args:
            api_key: API key for authentication. If not provided, reads from
                AGENTSANDBOX_API_KEY environment variable.
            base_url: Base URL for the API. If not provided, reads from
                AGENTSANDBOX_BASE_URL or uses the default.
            timeout: Request timeout in seconds. Defaults to 120 seconds.
            http_client: Optional pre-configured httpx.Client to use.
        """
        self._http = SyncHTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            http_client=http_client,
        )

        # Initialize resources
        self.execute = ExecuteResource(self._http)
        self.sessions = SessionsResource(self._http)
        self.files = FilesResource(self._http)
        self.executions = ExecutionsResource(self._http)

    def run(
        self,
        code: str,
        *,
        language: Language | str = Language.PYTHON,
        session_id: str | None = None,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> ExecuteResponse:
        """Execute code in a sandbox (convenience method).

        This is a shorthand for `client.execute.create()`.

        Args:
            code: The code to execute.
            language: Programming language ('python' or 'bash').
            session_id: Optional session ID for persistent workspace.
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace before execution.

        Returns:
            ExecuteResponse with stdout, stderr, and exit_code.

        Note:
            Each execution runs in a fresh process. Variables do NOT persist
            between executions. Use /workspace files to share state within
            a session.

        Example:
            >>> result = client.run("print(1 + 1)")
            >>> print(result.stdout)
            2
        """
        return self.execute.create(
            code,
            language=language,
            session_id=session_id,
            env_vars=env_vars,
            file_ids=file_ids,
        )

    def close(self) -> None:
        """Close the HTTP client and release resources."""
        self._http.close()

    def __enter__(self) -> AgentSandbox:
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit context manager and close client."""
        self.close()
