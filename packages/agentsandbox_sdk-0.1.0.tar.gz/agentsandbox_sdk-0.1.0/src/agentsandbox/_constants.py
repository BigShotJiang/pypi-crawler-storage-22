"""Constants for the AgentSandbox SDK."""

DEFAULT_BASE_URL = "https://api.agentsandbox.co"
DEFAULT_TIMEOUT = 120.0  # seconds
API_VERSION = "v1"
