"""Exception hierarchy for the AgentSandbox SDK."""

from __future__ import annotations

from typing import Any


class AgentSandboxError(Exception):
    """Base exception for all AgentSandbox errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_body = response_body

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(AgentSandboxError):
    """Raised when authentication fails (401)."""

    pass


class ForbiddenError(AgentSandboxError):
    """Raised when access is forbidden (403)."""

    pass


class NotFoundError(AgentSandboxError):
    """Raised when a resource is not found (404)."""

    pass


class ValidationError(AgentSandboxError):
    """Raised when request validation fails (422)."""

    pass


class RateLimitError(AgentSandboxError):
    """Raised when rate limit is exceeded (429)."""

    pass


class ServerError(AgentSandboxError):
    """Raised when the server encounters an error (500)."""

    pass


class ServiceUnavailableError(AgentSandboxError):
    """Raised when the service is unavailable (503)."""

    pass


def raise_for_status(status_code: int, message: str, response_body: Any = None) -> None:
    """Raise an appropriate exception based on status code."""
    error_classes: dict[int, type[AgentSandboxError]] = {
        401: AuthenticationError,
        403: ForbiddenError,
        404: NotFoundError,
        422: ValidationError,
        429: RateLimitError,
        500: ServerError,
        503: ServiceUnavailableError,
    }

    error_class = error_classes.get(status_code, AgentSandboxError)
    raise error_class(message, status_code=status_code, response_body=response_body)
