"""Pagination helpers for list operations."""

from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Generic,
    Iterator,
    TypeVar,
)

from pydantic import BaseModel

if TYPE_CHECKING:
    from agentsandbox._base_client import AsyncHTTPClient, SyncHTTPClient

T = TypeVar("T", bound=BaseModel)


class SyncPaginator(Generic[T]):
    """Synchronous paginator for lazily fetching pages of results using offset pagination."""

    def __init__(
        self,
        client: SyncHTTPClient,
        path: str,
        item_key: str,
        model_class: type[T],
        params: dict[str, Any] | None = None,
    ) -> None:
        self._client = client
        self._path = path
        self._item_key = item_key
        self._model_class = model_class
        self._params = params or {}
        self._current_page: list[T] = []
        self._page_index = 0
        self._offset = 0
        self._total: int | None = None
        self._started = False

    def _fetch_page(self) -> None:
        """Fetch the next page of results."""
        params = dict(self._params)
        params["offset"] = self._offset

        response = self._client.get(self._path, params=params)

        items = response.get(self._item_key, [])
        self._current_page = [self._model_class.model_validate(item) for item in items]
        self._page_index = 0
        self._total = response.get("total", 0)
        self._offset += len(items)

    @property
    def _has_more(self) -> bool:
        """Check if there are more items to fetch."""
        if self._total is None:
            return True
        return self._offset < self._total

    def __iter__(self) -> Iterator[T]:
        """Iterate over all items across all pages."""
        return self

    def __next__(self) -> T:
        """Get the next item, fetching new pages as needed."""
        while True:
            if self._page_index < len(self._current_page):
                item = self._current_page[self._page_index]
                self._page_index += 1
                return item

            if not self._started:
                self._started = True
                self._fetch_page()
            elif self._has_more:
                self._fetch_page()
            else:
                raise StopIteration


class AsyncPaginator(Generic[T]):
    """Asynchronous paginator for lazily fetching pages of results using offset pagination."""

    def __init__(
        self,
        client: AsyncHTTPClient,
        path: str,
        item_key: str,
        model_class: type[T],
        params: dict[str, Any] | None = None,
    ) -> None:
        self._client = client
        self._path = path
        self._item_key = item_key
        self._model_class = model_class
        self._params = params or {}
        self._current_page: list[T] = []
        self._page_index = 0
        self._offset = 0
        self._total: int | None = None
        self._started = False

    async def _fetch_page(self) -> None:
        """Fetch the next page of results."""
        params = dict(self._params)
        params["offset"] = self._offset

        response = await self._client.get(self._path, params=params)

        items = response.get(self._item_key, [])
        self._current_page = [self._model_class.model_validate(item) for item in items]
        self._page_index = 0
        self._total = response.get("total", 0)
        self._offset += len(items)

    @property
    def _has_more(self) -> bool:
        """Check if there are more items to fetch."""
        if self._total is None:
            return True
        return self._offset < self._total

    def __aiter__(self) -> AsyncIterator[T]:
        """Iterate over all items across all pages."""
        return self

    async def __anext__(self) -> T:
        """Get the next item, fetching new pages as needed."""
        while True:
            if self._page_index < len(self._current_page):
                item = self._current_page[self._page_index]
                self._page_index += 1
                return item

            if not self._started:
                self._started = True
                await self._fetch_page()
            elif self._has_more:
                await self._fetch_page()
            else:
                raise StopAsyncIteration
