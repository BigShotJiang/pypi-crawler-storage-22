"""Execute resource for running code in sandboxes."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agentsandbox.types.execute import ExecuteRequest, ExecuteResponse
from agentsandbox.types.shared import Language

if TYPE_CHECKING:
    from agentsandbox._base_client import AsyncHTTPClient, SyncHTTPClient


class ExecuteResource:
    """Synchronous resource for code execution."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def create(
        self,
        code: str,
        *,
        language: Language | str = Language.PYTHON,
        session_id: str | None = None,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> ExecuteResponse:
        """Execute code in a sandbox.

        Args:
            code: The code to execute.
            language: Programming language ('python' or 'bash').
            session_id: Optional session ID for persistent workspace.
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace before execution.

        Returns:
            ExecuteResponse with stdout, stderr, and exit_code.

        Note:
            Each execution runs in a fresh process. Variables do NOT persist
            between executions. Use /workspace files to share state.
        """
        if isinstance(language, str):
            language = Language(language)

        request = ExecuteRequest(
            code=code,
            language=language,
            session_id=session_id,
            env_vars=env_vars,
            file_ids=file_ids,
        )

        response = self._client.post(
            "execute",
            json=request.model_dump(exclude_none=True),
        )
        return ExecuteResponse.model_validate(response)


class AsyncExecuteResource:
    """Asynchronous resource for code execution."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def create(
        self,
        code: str,
        *,
        language: Language | str = Language.PYTHON,
        session_id: str | None = None,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> ExecuteResponse:
        """Execute code in a sandbox.

        Args:
            code: The code to execute.
            language: Programming language ('python' or 'bash').
            session_id: Optional session ID for persistent workspace.
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace before execution.

        Returns:
            ExecuteResponse with stdout, stderr, and exit_code.

        Note:
            Each execution runs in a fresh process. Variables do NOT persist
            between executions. Use /workspace files to share state.
        """
        if isinstance(language, str):
            language = Language(language)

        request = ExecuteRequest(
            code=code,
            language=language,
            session_id=session_id,
            env_vars=env_vars,
            file_ids=file_ids,
        )

        response = await self._client.post(
            "execute",
            json=request.model_dump(exclude_none=True),
        )
        return ExecuteResponse.model_validate(response)
