"""Executions resource for retrieving execution logs."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agentsandbox.types.executions import ExecutionLog

if TYPE_CHECKING:
    from agentsandbox._base_client import AsyncHTTPClient, SyncHTTPClient


class ExecutionsResource:
    """Synchronous resource for execution log retrieval."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def get(self, execution_id: str) -> ExecutionLog:
        """Get details about a specific execution.

        Args:
            execution_id: The execution ID.

        Returns:
            ExecutionLog with the execution's details.
        """
        response = self._client.get(f"executions/{execution_id}")
        return ExecutionLog.model_validate(response)


class AsyncExecutionsResource:
    """Asynchronous resource for execution log retrieval."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def get(self, execution_id: str) -> ExecutionLog:
        """Get details about a specific execution.

        Args:
            execution_id: The execution ID.

        Returns:
            ExecutionLog with the execution's details.
        """
        response = await self._client.get(f"executions/{execution_id}")
        return ExecutionLog.model_validate(response)
