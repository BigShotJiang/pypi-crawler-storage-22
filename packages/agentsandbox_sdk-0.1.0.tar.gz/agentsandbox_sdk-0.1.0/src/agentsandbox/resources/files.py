"""Files resource for file upload/download operations."""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncIterator, BinaryIO, Iterator, Union

from agentsandbox._pagination import AsyncPaginator, SyncPaginator
from agentsandbox.types.files import FileListResponse, FileUploadResponse
from agentsandbox.types.shared import FileInfo

if TYPE_CHECKING:
    from agentsandbox._base_client import AsyncHTTPClient, SyncHTTPClient

# Type alias for file input
FileInput = Union[str, Path, bytes, BinaryIO]


class FilesResource:
    """Synchronous resource for file operations."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def list(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
    ) -> FileListResponse:
        """List uploaded files with pagination.

        Args:
            limit: Number of files to return (1-100, default 50).
            offset: Number of files to skip (default 0).

        Returns:
            FileListResponse with files and pagination info.
        """
        response = self._client.get(
            "files",
            params={"limit": limit, "offset": offset},
        )
        return FileListResponse.model_validate(response)

    def list_all(self, *, limit: int = 50) -> Iterator[FileInfo]:
        """Iterate over all files, automatically handling pagination.

        Args:
            limit: Number of items to fetch per page (1-100, default 50).

        Yields:
            FileInfo objects for each file.
        """
        return SyncPaginator(
            client=self._client,
            path="files",
            item_key="files",
            model_class=FileInfo,
            params={"limit": limit},
        )

    def upload(
        self,
        file: FileInput,
        *,
        filename: str | None = None,
        content_type: str | None = None,
    ) -> FileUploadResponse:
        """Upload a file.

        Args:
            file: File to upload. Can be:
                - str or Path: Path to a file on disk
                - bytes: Raw file content
                - File-like object: An open binary file
            filename: Optional filename (inferred from path if not provided).
            content_type: Optional MIME type.

        Returns:
            FileUploadResponse with the uploaded file's details.
        """
        file_data: Any
        file_name: str

        if isinstance(file, (str, Path)):
            path = Path(file)
            file_name = filename or path.name
            with open(path, "rb") as f:
                file_data = f.read()
        elif isinstance(file, bytes):
            file_data = file
            file_name = filename or "file"
        else:
            # File-like object
            file_data = file.read()
            file_name = filename or getattr(file, "name", "file")
            if hasattr(file_name, "__fspath__"):
                file_name = os.path.basename(file_name)

        files = {"file": (file_name, file_data, content_type or "application/octet-stream")}
        response = self._client.post("files", files=files)
        return FileUploadResponse.model_validate(response)

    def download(self, file_id: str) -> bytes:
        """Download a file's contents.

        Args:
            file_id: The file ID.

        Returns:
            The file contents as bytes.
        """
        return self._client.get_raw(f"files/{file_id}")

    def download_to(self, file_id: str, path: str | Path) -> Path:
        """Download a file to disk.

        Args:
            file_id: The file ID.
            path: Destination path on disk.

        Returns:
            The path where the file was saved.
        """
        content = self.download(file_id)
        path = Path(path)
        path.write_bytes(content)
        return path

    def delete(self, file_id: str) -> None:
        """Delete an uploaded file.

        Args:
            file_id: The file ID to delete.
        """
        self._client.delete(f"files/{file_id}")


class AsyncFilesResource:
    """Asynchronous resource for file operations."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def list(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
    ) -> FileListResponse:
        """List uploaded files with pagination.

        Args:
            limit: Number of files to return (1-100, default 50).
            offset: Number of files to skip (default 0).

        Returns:
            FileListResponse with files and pagination info.
        """
        response = await self._client.get(
            "files",
            params={"limit": limit, "offset": offset},
        )
        return FileListResponse.model_validate(response)

    def list_all(self, *, limit: int = 50) -> AsyncIterator[FileInfo]:
        """Iterate over all files, automatically handling pagination.

        Args:
            limit: Number of items to fetch per page (1-100, default 50).

        Yields:
            FileInfo objects for each file.
        """
        return AsyncPaginator(
            client=self._client,
            path="files",
            item_key="files",
            model_class=FileInfo,
            params={"limit": limit},
        )

    async def upload(
        self,
        file: FileInput,
        *,
        filename: str | None = None,
        content_type: str | None = None,
    ) -> FileUploadResponse:
        """Upload a file.

        Args:
            file: File to upload. Can be:
                - str or Path: Path to a file on disk
                - bytes: Raw file content
                - File-like object: An open binary file
            filename: Optional filename (inferred from path if not provided).
            content_type: Optional MIME type.

        Returns:
            FileUploadResponse with the uploaded file's details.
        """
        file_data: Any
        file_name: str

        if isinstance(file, (str, Path)):
            path = Path(file)
            file_name = filename or path.name
            with open(path, "rb") as f:
                file_data = f.read()
        elif isinstance(file, bytes):
            file_data = file
            file_name = filename or "file"
        else:
            file_data = file.read()
            file_name = filename or getattr(file, "name", "file")
            if hasattr(file_name, "__fspath__"):
                file_name = os.path.basename(file_name)

        files = {"file": (file_name, file_data, content_type or "application/octet-stream")}
        response = await self._client.post("files", files=files)
        return FileUploadResponse.model_validate(response)

    async def download(self, file_id: str) -> bytes:
        """Download a file's contents.

        Args:
            file_id: The file ID.

        Returns:
            The file contents as bytes.
        """
        return await self._client.get_raw(f"files/{file_id}")

    async def download_to(self, file_id: str, path: str | Path) -> Path:
        """Download a file to disk.

        Args:
            file_id: The file ID.
            path: Destination path on disk.

        Returns:
            The path where the file was saved.
        """
        content = await self.download(file_id)
        path = Path(path)
        path.write_bytes(content)
        return path

    async def delete(self, file_id: str) -> None:
        """Delete an uploaded file.

        Args:
            file_id: The file ID to delete.
        """
        await self._client.delete(f"files/{file_id}")
