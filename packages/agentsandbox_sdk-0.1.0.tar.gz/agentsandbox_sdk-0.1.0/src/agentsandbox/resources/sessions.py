"""Sessions resource for managing sandbox sessions."""

from __future__ import annotations

from contextlib import contextmanager, asynccontextmanager
from typing import TYPE_CHECKING, AsyncIterator, Iterator

from agentsandbox.types.sessions import (
    SessionCreateRequest,
    SessionInfo,
    SessionListResponse,
)

if TYPE_CHECKING:
    from agentsandbox._base_client import AsyncHTTPClient, SyncHTTPClient


class SessionsResource:
    """Synchronous resource for session management."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def create(
        self,
        *,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> SessionInfo:
        """Create a new sandbox session.

        Args:
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace on session creation.

        Returns:
            SessionInfo with the new session's details.
        """
        request = SessionCreateRequest(env_vars=env_vars, file_ids=file_ids)
        response = self._client.post(
            "sessions",
            json=request.model_dump(exclude_none=True),
        )
        return SessionInfo.model_validate(response)

    def list(self) -> SessionListResponse:
        """List all active sessions.

        Returns:
            SessionListResponse containing all sessions.
        """
        response = self._client.get("sessions")
        return SessionListResponse.model_validate(response)

    def get(self, session_id: str) -> SessionInfo:
        """Get details about a specific session.

        Args:
            session_id: The session ID.

        Returns:
            SessionInfo with the session's details.
        """
        response = self._client.get(f"sessions/{session_id}")
        return SessionInfo.model_validate(response)

    def delete(self, session_id: str) -> None:
        """Delete a session.

        Args:
            session_id: The session ID to delete.
        """
        self._client.delete(f"sessions/{session_id}")

    def inject_files(
        self,
        session_id: str,
        file_ids: list[str],
    ) -> None:
        """Inject files into a session's /workspace directory.

        Args:
            session_id: The session ID.
            file_ids: List of file IDs to inject.
        """
        self._client.post(
            f"sessions/{session_id}/files",
            json={"file_ids": file_ids},
        )

    @contextmanager
    def context(
        self,
        *,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> Iterator[SessionInfo]:
        """Context manager that creates a session and deletes it on exit.

        Args:
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace on session creation.

        Yields:
            SessionInfo for the created session.

        Example:
            with client.sessions.context() as session:
                result = client.run("print('hello')", session_id=session.session_id)
            # Session is automatically deleted here
        """
        session = self.create(env_vars=env_vars, file_ids=file_ids)
        try:
            yield session
        finally:
            try:
                self.delete(session.session_id)
            except Exception:
                pass  # Best effort cleanup


class AsyncSessionsResource:
    """Asynchronous resource for session management."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def create(
        self,
        *,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> SessionInfo:
        """Create a new sandbox session.

        Args:
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace on session creation.

        Returns:
            SessionInfo with the new session's details.
        """
        request = SessionCreateRequest(env_vars=env_vars, file_ids=file_ids)
        response = await self._client.post(
            "sessions",
            json=request.model_dump(exclude_none=True),
        )
        return SessionInfo.model_validate(response)

    async def list(self) -> SessionListResponse:
        """List all active sessions.

        Returns:
            SessionListResponse containing all sessions.
        """
        response = await self._client.get("sessions")
        return SessionListResponse.model_validate(response)

    async def get(self, session_id: str) -> SessionInfo:
        """Get details about a specific session.

        Args:
            session_id: The session ID.

        Returns:
            SessionInfo with the session's details.
        """
        response = await self._client.get(f"sessions/{session_id}")
        return SessionInfo.model_validate(response)

    async def delete(self, session_id: str) -> None:
        """Delete a session.

        Args:
            session_id: The session ID to delete.
        """
        await self._client.delete(f"sessions/{session_id}")

    async def inject_files(
        self,
        session_id: str,
        file_ids: list[str],
    ) -> None:
        """Inject files into a session's /workspace directory.

        Args:
            session_id: The session ID.
            file_ids: List of file IDs to inject.
        """
        await self._client.post(
            f"sessions/{session_id}/files",
            json={"file_ids": file_ids},
        )

    @asynccontextmanager
    async def context(
        self,
        *,
        env_vars: dict[str, str] | None = None,
        file_ids: list[str] | None = None,
    ) -> AsyncIterator[SessionInfo]:
        """Async context manager that creates a session and deletes it on exit.

        Args:
            env_vars: Environment variables to inject into the sandbox.
            file_ids: File IDs to inject into /workspace on session creation.

        Yields:
            SessionInfo for the created session.

        Example:
            async with client.sessions.context() as session:
                result = await client.run("print('hello')", session_id=session.session_id)
            # Session is automatically deleted here
        """
        session = await self.create(env_vars=env_vars, file_ids=file_ids)
        try:
            yield session
        finally:
            try:
                await self.delete(session.session_id)
            except Exception:
                pass  # Best effort cleanup
