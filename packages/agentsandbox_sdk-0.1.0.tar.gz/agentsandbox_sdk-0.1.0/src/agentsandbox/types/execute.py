"""Type definitions for code execution."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field, ConfigDict

from agentsandbox.types.shared import Language


class ExecutionFile(BaseModel):
    """A file created during execution."""

    file_id: str = Field(..., description="Unique identifier for the file")
    filename: str = Field(..., description="Name of the file")


class ExecuteRequest(BaseModel):
    """Request to execute code in a sandbox."""

    code: str = Field(..., description="The code to execute")
    language: Language = Field(
        default=Language.PYTHON,
        description="The programming language of the code",
    )
    session_id: Optional[str] = Field(
        None,
        description="Optional session ID for persistent workspace",
    )
    env_vars: Optional[dict[str, str]] = Field(
        None,
        description="Environment variables to inject into the sandbox",
    )
    file_ids: Optional[list[str]] = Field(
        None,
        description="File IDs to inject into /workspace before execution",
    )


class ExecuteResponse(BaseModel):
    """Response from code execution."""

    model_config = ConfigDict(populate_by_name=True)

    session_id: Optional[str] = Field(None, description="Session ID for this execution")
    stdout: str = Field(default="", description="Standard output from the execution")
    stderr: str = Field(default="", description="Standard error from the execution")
    return_code: int = Field(..., description="Return code of the execution (0 = success)")
    files: list[ExecutionFile] = Field(default_factory=list, description="Files created during execution")

    @property
    def exit_code(self) -> int:
        """Alias for return_code for convenience."""
        return self.return_code

    @property
    def success(self) -> bool:
        """Check if the execution completed successfully."""
        return self.return_code == 0
