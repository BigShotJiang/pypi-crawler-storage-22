"""Type definitions for execution logs."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field

from agentsandbox.types.shared import Language


class ExecutionLog(BaseModel):
    """Detailed log of a code execution."""

    id: str = Field(..., description="Unique identifier for the execution")
    endpoint: str = Field(..., description="The API endpoint that was called")
    method: str = Field(..., description="HTTP method")
    status_code: Optional[int] = Field(None, description="HTTP status code of the execution")
    duration_ms: Optional[float] = Field(None, description="Execution duration in milliseconds")
    session_id: Optional[str] = Field(None, description="Session ID if executed in a session")
    language: Optional[Language] = Field(None, description="The programming language used")
    code: Optional[str] = Field(None, description="The code that was executed")
    stdout: Optional[str] = Field(None, description="Standard output")
    stderr: Optional[str] = Field(None, description="Standard error")
    return_code: Optional[int] = Field(None, description="Process exit code")
    files_count: int = Field(default=0, description="Number of output files produced")
    error: Optional[str] = Field(None, description="Error message if execution failed")
    request_meta: Optional[dict[str, Any]] = Field(None, description="Additional request metadata")
    created_at: datetime = Field(..., description="When the execution started")

    @property
    def execution_id(self) -> str:
        """Alias for id for backwards compatibility."""
        return self.id

    @property
    def exit_code(self) -> Optional[int]:
        """Alias for return_code for backwards compatibility."""
        return self.return_code

    @property
    def success(self) -> bool:
        """Check if the execution completed successfully."""
        return self.return_code == 0
