"""Type definitions for file operations."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from agentsandbox.types.shared import FileInfo


class FileListResponse(BaseModel):
    """Paginated response containing a list of files."""

    files: list[FileInfo] = Field(default_factory=list)
    total: int = Field(default=0, description="Total number of files")
    limit: int = Field(default=50, description="Limit used for this request")
    offset: int = Field(default=0, description="Offset used for this request")


class FileUploadResponse(BaseModel):
    """Response from uploading a file."""

    file_id: str = Field(..., description="Unique identifier for the uploaded file")
    filename: str = Field(..., description="Original filename")
    mime_type: str = Field(
        default="application/octet-stream", description="MIME type of the file"
    )
    size_bytes: int = Field(..., description="File size in bytes")
    session_id: Optional[str] = Field(None, description="Session the file was injected into")
    created_at: str = Field(..., description="ISO 8601 creation timestamp")
