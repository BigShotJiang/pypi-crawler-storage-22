"""Type definitions for sessions."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class SessionInfo(BaseModel):
    """Information about a sandbox session."""

    session_id: str = Field(..., description="Unique identifier for the session")
    created: Optional[bool] = Field(None, description="Whether the session was just created")


class SessionListResponse(BaseModel):
    """Response containing a list of sessions."""

    sessions: list[str] = Field(default_factory=list, description="List of active session IDs")


class SessionCreateRequest(BaseModel):
    """Request to create a new session."""

    env_vars: Optional[dict[str, str]] = Field(
        None,
        description="Environment variables to inject into the sandbox",
    )
    file_ids: Optional[list[str]] = Field(
        None,
        description="File IDs to inject into /workspace on session creation",
    )
