"""Shared type definitions used across the SDK."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Language(str, Enum):
    """Supported execution languages."""

    PYTHON = "python"
    BASH = "bash"


class FileRef(BaseModel):
    """Reference to a file for injection into a session."""

    file_id: str = Field(..., description="The ID of the uploaded file")
    path: str = Field(..., description="The target path in the session's /workspace directory")


class FileInfo(BaseModel):
    """Information about an uploaded file."""

    file_id: str = Field(..., description="Unique identifier for the file")
    filename: str = Field(..., description="Original filename")
    mime_type: str = Field(
        default="application/octet-stream", description="MIME type of the file"
    )
    size_bytes: int = Field(..., description="File size in bytes")
    session_id: Optional[str] = Field(None, description="Session that produced the file")
    created_at: datetime = Field(..., description="When the file was uploaded")
