# -*- coding: utf-8 -*-
"""The Mem0 long-term memory module for AgentScope."""

from ._mem0_long_term_memory import Mem0LongTermMemory


__all__ = [
    "Mem0LongTermMemory",
]
