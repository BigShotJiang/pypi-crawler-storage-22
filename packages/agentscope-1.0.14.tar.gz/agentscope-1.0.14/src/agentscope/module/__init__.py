# -*- coding: utf-8 -*-
"""The module in agentscope."""

from ._state_module import StateModule

__all__ = [
    "StateModule",
]
