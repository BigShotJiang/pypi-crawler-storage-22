# -*- coding: utf-8 -*-
"""This module has been deprecated and renamed to 'agentscope.tuner'."""

raise ImportError(
    "The 'agentscope.tune' module has been renamed to 'agentscope.tuner'. "
    "Please update your imports: 'from agentscope.tuner import ...'",
)
