"""Utility functions for agentsec."""
