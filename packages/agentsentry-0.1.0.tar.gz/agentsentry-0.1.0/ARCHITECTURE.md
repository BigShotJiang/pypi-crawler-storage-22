# AgentSentry Project Structure

This document describes the architecture and organization of the AgentSentry codebase.

## Directory Structure

```
agentsentry/
├── agentsentry/              # Main package
│   ├── __init__.py          # Package initialization
│   ├── core/                # Core orchestration engine
│   │   ├── __init__.py
│   │   ├── base_adapter.py  # Abstract adapter interface
│   │   ├── config.py        # Configuration management
│   │   └── runner.py        # Main AgentRunner class
│   ├── adapters/            # Framework-specific adapters
│   │   ├── __init__.py
│   │   ├── crewai.py       # CrewAI adapter
│   │   ├── autogen.py      # AutoGen adapter
│   │   └── langchain.py    # LangChain adapter
│   ├── middleware/          # Interception & control layer
│   │   ├── __init__.py
│   │   └── token_guardrail.py  # Budget & loop enforcement
│   ├── observability/       # Telemetry & tracking
│   │   ├── __init__.py
│   │   ├── tracking.py     # Execution tracker
│   │   └── telemetry.py    # OpenTelemetry provider
│   ├── persistence/         # Database layer
│   │   ├── __init__.py
│   │   ├── database.py     # SQLAlchemy logger
│   │   └── models.py       # ORM models
│   └── cli/                # Command-line interface
│       ├── __init__.py
│       ├── main.py         # CLI entry point
│       └── commands/       # CLI command groups
│           ├── __init__.py
│           ├── stack.py    # Stack management
│           ├── monitor.py  # Monitoring tools
│           └── init.py     # Project initialization
├── examples/               # Usage examples
│   ├── crewai_example.py
│   └── guardrail_example.py
├── tests/                 # Test suite
├── docs/                  # Documentation
├── agentsentry.yaml       # Example configuration
├── .env.template         # Environment variables template
├── requirements.txt      # Python dependencies
├── setup.py             # Package setup
├── README.md            # Main documentation
├── CONTRIBUTING.md      # Contribution guide
├── CHANGELOG.md         # Version history
└── LICENSE              # MIT license

```

## Module Responsibilities

### Core (`agentsentry/core/`)

**Purpose**: Central orchestration engine for agent lifecycle management.

- **`runner.py`**: Main `AgentRunner` class that coordinates execution
- **`config.py`**: Configuration loading from files/environment
- **`base_adapter.py`**: Abstract interface that all adapters implement

**Key Classes**:
- `AgentRunner`: Orchestrates agent execution with middleware
- `Config`: Manages configuration from multiple sources
- `BaseAdapter`: Abstract base class for framework adapters

### Adapters (`agentsentry/adapters/`)

**Purpose**: Framework-specific integrations that implement the `BaseAdapter` interface.

Each adapter provides:
- Initialization of framework dependencies
- Execution with AgentSentry controls
- Token tracking integration
- Clean shutdown

**Current Adapters**:
- `crewai.py`: CrewAI framework integration
- `autogen.py`: Microsoft AutoGen integration
- `langchain.py`: LangChain framework integration

### Middleware (`agentsentry/middleware/`)

**Purpose**: Interception layer for tracking, controlling, and securing agent execution.

**Key Components**:
- **`TokenGuardrail`**: Implements circuit breaker pattern for cost/loop control
  - Tracks token usage per session
  - Calculates costs based on model pricing
  - Enforces budget and loop thresholds
  - Raises `BudgetExceededError` when limits exceeded

### Observability (`agentsentry/observability/`)

**Purpose**: Distributed tracing and metrics collection using OpenTelemetry.

- **`tracking.py`**: `ExecutionTracker` for logging events
- **`telemetry.py`**: `TelemetryProvider` for OpenTelemetry setup

**Integration Points**:
- API call tracking
- Threshold breach events
- Session lifecycle events

### Persistence (`agentsentry/persistence/`)

**Purpose**: Database persistence for audit logs and metrics using SQLAlchemy.

- **`database.py`**: `DatabaseLogger` for writing to database
- **`models.py`**: ORM models for session logs and breaches

**Tables**:
- `session_logs`: Records of agent executions
- `threshold_breaches`: Audit trail of budget/loop violations

### CLI (`agentsentry/cli/`)

**Purpose**: Command-line interface for deployment and monitoring.

**Command Groups**:
- **`stack`**: Deploy, teardown, and check status of stacks
- **`monitor`**: View sessions, costs, and metrics
- **`init`**: Initialize new projects with templates

## Data Flow

```
1. User Code
   ↓
2. AgentRunner.run()
   ↓
3. Framework Adapter (e.g., CrewAIAdapter)
   ↓
4. TokenGuardrail.track_execution()
   ↓
5. Agent Execution (with API call interception)
   ↓
6. TokenGuardrail.intercept_api_call()
   ↓
7. Check thresholds (budget, loops)
   ↓
8. Log to database & telemetry
   ↓
9. Return results with metrics
```

## Extension Points

### Adding a New Adapter

1. Create `agentsentry/adapters/your_framework.py`
2. Inherit from `BaseAdapter`
3. Implement required methods: `initialize()`, `execute()`, `shutdown()`
4. Integrate `TokenGuardrail` for tracking
5. Add tests and examples

### Adding Middleware

1. Create new middleware class
2. Implement context manager for session tracking
3. Add hooks to `AgentRunner`
4. Update configuration schema

### Adding Observability Backend

1. Extend `TelemetryProvider` with new exporter
2. Add configuration options
3. Update `ExecutionTracker` to publish metrics

## Design Principles

1. **Modularity**: Each component has a single, well-defined responsibility
2. **Extensibility**: Plugin architecture via adapters and middleware
3. **Framework Agnostic**: Core is independent of specific agent frameworks
4. **Production Ready**: Built-in observability, error handling, and audit trails
5. **Contributor Friendly**: Clear interfaces and comprehensive documentation

## Dependencies

### Core Dependencies
- `click`: CLI framework
- `sqlalchemy`: Database ORM
- `pyyaml`: Configuration parsing
- `opentelemetry-api/sdk`: Distributed tracing

### Optional Dependencies
- `crewai`: For CrewAI adapter
- `pyautogen`: For AutoGen adapter
- `langchain`: For LangChain adapter

## Testing Strategy

- **Unit Tests**: Each module has isolated unit tests
- **Integration Tests**: Test adapter integration with frameworks
- **End-to-End Tests**: Full workflow tests with real agents
- **Coverage Target**: Minimum 80% code coverage

## Configuration Hierarchy

Configuration is loaded in this order (later overrides earlier):

1. Default values in `Config.DEFAULT_CONFIG`
2. YAML file specified by user
3. Environment variables (prefixed with `AGENTSENTRY_`)
4. Programmatic overrides in code
