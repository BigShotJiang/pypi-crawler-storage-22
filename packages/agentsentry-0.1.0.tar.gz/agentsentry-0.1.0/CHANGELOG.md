# Changelog

All notable changes to AgentSentry will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Core orchestration engine with `AgentRunner` class
- Framework adapters for CrewAI, AutoGen, and LangChain
- Token guardrail middleware with circuit breaker pattern
- Budget enforcement (max USD cost) and loop detection
- OpenTelemetry integration for distributed tracing
- SQLAlchemy-based persistence layer for audit logs
- CLI tools: `stack deploy`, `monitor sessions`, `init`
- Configuration management with YAML and environment variable support
- Comprehensive examples and documentation

### Changed
- N/A (initial release)

### Deprecated
- N/A

### Removed
- N/A

### Fixed
- N/A

### Security
- N/A

## [0.1.0] - 2026-02-13

### Added
- Initial private beta release
- Core infrastructure for production AI agent deployment
- Framework-agnostic adapter system
- Cost control and observability features

---

**Legend:**
- `Added`: New features
- `Changed`: Changes in existing functionality
- `Deprecated`: Soon-to-be removed features
- `Removed`: Removed features
- `Fixed`: Bug fixes
- `Security`: Security improvements
