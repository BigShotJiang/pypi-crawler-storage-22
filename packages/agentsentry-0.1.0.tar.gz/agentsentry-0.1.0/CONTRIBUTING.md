# Contributing to AgentSentry

Thank you for your interest in contributing to AgentSentry! This document provides guidelines and instructions for contributing.

## 🎯 How Can I Contribute?

### 1. Building Framework Adapters

The most valuable contributions are new framework adapters. Here's what we're looking for:

**Priority Frameworks:**
- OpenAI Assistants API
- Microsoft Semantic Kernel
- LlamaIndex Agents
- Amazon Bedrock Agents
- Google Vertex AI Agent Builder

**Adapter Requirements:**
- Inherit from `BaseAdapter`
- Implement `initialize()`, `execute()`, and `shutdown()` methods
- Integrate with `TokenGuardrail` middleware
- Include comprehensive tests
- Add usage examples

### 2. Enhancing Observability

Help us improve monitoring and telemetry:
- Add exporters (Prometheus, Datadog, New Relic)
- Build custom dashboards
- Improve tracing granularity
- Add custom metrics

### 3. Documentation

Documentation improvements are always welcome:
- Tutorial content
- API documentation
- Architecture diagrams
- Use case examples

## 🚀 Development Setup

### Prerequisites
- Python 3.9 or higher
- Git
- Virtual environment tool (venv, conda, etc.)

### Setup Steps

```bash
# Fork and clone the repository
git clone https://github.com/YOUR_USERNAME/agentsentry.git
cd agentsentry

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run linting
ruff check .
black --check .

# Run type checking
mypy agentsentry/
```

## 📝 Code Standards

### Style Guide
- **Formatter**: Black (line length: 88)
- **Linter**: Ruff with default rules
- **Type Hints**: Required for all public APIs
- **Docstrings**: Google style for all public classes/methods

### Example Docstring

```python
def calculate_cost(self, model: str, tokens: int) -> Decimal:
    """
    Calculate the cost of an API call.
    
    Args:
        model: Model identifier (e.g., 'gpt-4')
        tokens: Total number of tokens used
        
    Returns:
        Cost in USD as Decimal
        
    Raises:
        ValueError: If model is not supported
    """
```

### Testing Requirements
- Unit tests for all new functionality
- Integration tests for adapters
- Minimum 80% code coverage
- Use pytest for all tests

### Example Test

```python
def test_token_guardrail_budget_exceeded():
    """Test that guardrail raises error when budget exceeded."""
    guardrail = TokenGuardrail(config={'max_budget_usd': 1.0})
    
    with pytest.raises(BudgetExceededError) as exc_info:
        with guardrail.track_execution('session-1'):
            # Simulate expensive call
            guardrail.intercept_api_call(
                session_id='session-1',
                model='gpt-4',
                prompt_tokens=10000,
                completion_tokens=10000
            )
    
    assert exc_info.value.threshold_type == 'budget'
```

## 🔄 Pull Request Process

### Before Submitting

1. **Create an issue** describing the feature or bug
2. **Fork the repository** and create a feature branch
3. **Write tests** that cover your changes
4. **Update documentation** (README, docstrings, etc.)
5. **Run the test suite** and ensure all tests pass
6. **Run linting and formatting** tools

### Branch Naming

- Feature: `feature/description-of-feature`
- Bug fix: `fix/description-of-bug`
- Documentation: `docs/description-of-change`

### Commit Messages

Follow conventional commits format:

```
type(scope): description

[optional body]

[optional footer]
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `test`: Adding or updating tests
- `refactor`: Code refactoring
- `perf`: Performance improvements

**Examples:**
```
feat(adapters): add OpenAI Assistants adapter

- Implement BaseAdapter interface
- Add token tracking hooks
- Include integration tests

Closes #123
```

### Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] New feature
- [ ] Bug fix
- [ ] Documentation update
- [ ] Performance improvement

## Testing
Describe the testing you've done

## Checklist
- [ ] Tests pass locally
- [ ] Code follows style guidelines
- [ ] Documentation updated
- [ ] CHANGELOG.md updated (if applicable)
```

## 🐛 Reporting Bugs

### Before Reporting
1. Check existing issues to avoid duplicates
2. Gather relevant information (Python version, OS, error messages)
3. Create a minimal reproducible example

### Bug Report Template

```markdown
**Describe the bug**
A clear description of the bug

**To Reproduce**
Steps to reproduce:
1. ...
2. ...

**Expected behavior**
What you expected to happen

**Environment**
- OS: [e.g., macOS 14.2]
- Python version: [e.g., 3.11.5]
- AgentSentry version: [e.g., 0.1.0]
- Framework: [e.g., CrewAI 0.1.0]

**Additional context**
Any other relevant information
```

## 💡 Feature Requests

We welcome feature requests! Please:
1. Search existing issues first
2. Describe the problem you're trying to solve
3. Explain your proposed solution
4. Consider if this fits AgentSentry's scope

## 📜 Code of Conduct

### Our Standards
- Be respectful and inclusive
- Welcome newcomers
- Accept constructive criticism
- Focus on what's best for the community

### Unacceptable Behavior
- Harassment or discriminatory language
- Trolling or insulting comments
- Publishing others' private information
- Other unprofessional conduct

## 📞 Getting Help

- **Questions**: Open a GitHub Discussion
- **Chat**: Join our Discord (link coming soon)
- **Email**: contact@agentsentry.dev

## 🏆 Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Credited in release notes
- Given contributor badge on Discord

Thank you for contributing to AgentSentry! 🎉
