"""
Complete Integration Example: AgentSentry with Custom Agent
============================================================
This example shows end-to-end usage of AgentSentry with all features.
"""

import logging
from decimal import Decimal
from agentsentry import AgentRunner, Config, BudgetExceededError
from agentsentry.adapters.crewai import CrewAIAdapter
from agentsentry.middleware import TokenGuardrail

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    """Demonstrate complete AgentSentry integration."""
    
    print("🛡️  AgentSentry - Complete Integration Example\n")
    
    # ========================================
    # 1. LOAD CONFIGURATION
    # ========================================
    print("📋 Step 1: Loading configuration...")
    
    # Option A: Load from YAML file
    config = Config.from_file('agentsentry.yaml')
    
    # Option B: Load from environment variables
    # config = Config.from_env()
    
    # Option C: Programmatic configuration
    # config = Config({
    #     'max_budget_usd': 5.0,
    #     'max_loops': 20,
    #     'enable_db_logging': True,
    #     'database_url': 'sqlite:///agentsentry.db'
    # })
    
    print(f"   ✓ Budget limit: ${config.get('max_budget_usd')}")
    print(f"   ✓ Loop limit: {config.get('max_loops')}")
    print(f"   ✓ Database logging: {config.get('enable_db_logging')}\n")
    
    # ========================================
    # 2. INITIALIZE AGENT RUNNER
    # ========================================
    print("🚀 Step 2: Initializing AgentRunner...")
    
    runner = AgentRunner(config=config)
    
    # Register framework adapters
    runner.register_adapter('crewai', CrewAIAdapter)
    # runner.register_adapter('autogen', AutoGenAdapter)
    # runner.register_adapter('langchain', LangChainAdapter)
    
    print("   ✓ Runner initialized")
    print("   ✓ Adapters registered: crewai\n")
    
    # ========================================
    # 3. DEFINE AGENT CONFIGURATION
    # ========================================
    print("🤖 Step 3: Configuring agent...")
    
    agent_config = {
        'name': 'market-research-agent',
        'task': 'Research trends in AI agent infrastructure',
        'model': 'gpt-4',
        'max_iterations': 5,
        # Add framework-specific config here
    }
    
    print(f"   ✓ Agent: {agent_config['name']}")
    print(f"   ✓ Model: {agent_config['model']}")
    print(f"   ✓ Task: {agent_config['task']}\n")
    
    # ========================================
    # 4. EXECUTE AGENT WITH PROTECTION
    # ========================================
    print("▶️  Step 4: Executing agent with AgentSentry protection...\n")
    
    try:
        # Run the agent
        result = runner.run(
            framework='crewai',
            agent_config=agent_config,
            session_id='demo-session-001'
        )
        
        # ========================================
        # 5. DISPLAY RESULTS
        # ========================================
        print("\n✅ EXECUTION COMPLETED SUCCESSFULLY!\n")
        print("=" * 60)
        print("📊 Execution Metrics:")
        print("=" * 60)
        
        metrics = result['metrics']
        print(f"Session ID:       {result['session_id']}")
        print(f"Status:           {result.get('status', 'success')}")
        print(f"\nCost Breakdown:")
        print(f"  Total Cost:     ${metrics['total_cost_usd']:.4f}")
        print(f"  Total Tokens:   {metrics['total_tokens']:,}")
        print(f"  Prompt Tokens:  {metrics.get('prompt_tokens', 0):,}")
        print(f"  Completion:     {metrics.get('completion_tokens', 0):,}")
        print(f"\nExecution Stats:")
        print(f"  API Calls:      {metrics.get('api_calls', 0)}")
        print(f"  Loops:          {metrics['loops_executed']}")
        print(f"  Duration:       {metrics.get('duration_seconds', 0):.2f}s")
        print(f"\nBudget Status:")
        budget = Decimal(str(config.get('max_budget_usd')))
        spent = Decimal(str(metrics['total_cost_usd']))
        remaining = budget - spent
        utilization = (spent / budget * 100) if budget > 0 else 0
        print(f"  Budget:         ${budget}")
        print(f"  Spent:          ${spent:.4f} ({utilization:.1f}%)")
        print(f"  Remaining:      ${remaining:.4f}")
        print("=" * 60)
        
    except BudgetExceededError as e:
        # ========================================
        # HANDLE BUDGET/LOOP EXCEEDED
        # ========================================
        print("\n⚠️  CIRCUIT BREAKER TRIGGERED!\n")
        print("=" * 60)
        print(f"Threshold Type:   {e.threshold_type.upper()}")
        print(f"Message:          {e.message}")
        print(f"\nSession Details:")
        print(f"  Session ID:     {e.session_id}")
        print(f"  Total Cost:     ${e.total_cost:.4f}")
        print(f"  Total Tokens:   {e.total_tokens:,}")
        print(f"  Loops:          {e.loops_executed}")
        print("=" * 60)
        print("\n💡 The agent was automatically terminated to prevent")
        print("   runaway costs. This is a safety feature.")
        
    except Exception as e:
        # ========================================
        # HANDLE OTHER ERRORS
        # ========================================
        print(f"\n❌ EXECUTION FAILED: {e}")
        logger.exception("Agent execution failed")
        
    finally:
        # ========================================
        # 6. CLEANUP
        # ========================================
        print("\n🧹 Cleaning up...")
        runner.shutdown()
        print("   ✓ Resources released")
        print("\n✨ Done!\n")


def demonstrate_direct_guardrail():
    """
    Example 2: Using TokenGuardrail directly for custom integrations.
    """
    print("\n" + "="*60)
    print("Example 2: Direct TokenGuardrail Usage")
    print("="*60 + "\n")
    
    # Initialize guardrail
    guardrail = TokenGuardrail(config={
        'max_budget_usd': 1.0,
        'max_loops': 5
    })
    
    session_id = 'custom-session-001'
    
    try:
        with guardrail.track_execution(session_id=session_id):
            print("Running custom agent with guardrail...\n")
            
            # Simulate agent making API calls
            for i in range(10):  # Will hit loop limit at 5
                print(f"Loop {i+1}: Making API call...")
                
                # Simulate LLM API call
                # response = openai.ChatCompletion.create(...)
                
                # Track the call
                guardrail.intercept_api_call(
                    session_id=session_id,
                    model='gpt-3.5-turbo',
                    prompt_tokens=150,
                    completion_tokens=75,
                    is_loop_iteration=True
                )
                
                # Display current metrics
                metrics = guardrail.get_session_metrics(session_id)
                print(f"  Cost: ${metrics['total_cost_usd']:.4f} | "
                      f"Tokens: {metrics['total_tokens']} | "
                      f"Loops: {metrics['loops_executed']}")
                
    except BudgetExceededError as e:
        print(f"\n⚠️  Circuit breaker: {e.message}")
        print(f"Final cost: ${e.total_cost:.4f}")


def demonstrate_monitoring():
    """
    Example 3: Monitoring active sessions.
    """
    print("\n" + "="*60)
    print("Example 3: Session Monitoring")
    print("="*60 + "\n")
    
    config = Config({'max_budget_usd': 10.0})
    runner = AgentRunner(config=config)
    
    # Get active sessions
    active_sessions = runner.get_active_sessions()
    
    print(f"Active Sessions: {len(active_sessions)}")
    for session_id, metrics in active_sessions.items():
        print(f"\n  {session_id}:")
        print(f"    Cost: ${metrics['total_cost_usd']:.4f}")
        print(f"    Tokens: {metrics['total_tokens']}")
        print(f"    Loops: {metrics['loops_executed']}")


if __name__ == '__main__':
    # Run main example
    main()
    
    # Uncomment to run additional examples:
    # demonstrate_direct_guardrail()
    # demonstrate_monitoring()
