"""
Example: Running a CrewAI Agent with AgentSentry
=================================================
This example demonstrates how to integrate AgentSentry with a CrewAI agent
to add cost controls and observability.
"""

from agentsentry import AgentRunner, Config
from agentsentry.adapters.crewai import CrewAIAdapter

# Configure AgentSentry with budget limits
config = Config({
    'max_budget_usd': 5.0,     # Stop if cost exceeds $5
    'max_loops': 20,            # Stop after 20 iterations
    'enable_db_logging': True
})

# Initialize the runner
runner = AgentRunner(config=config)

# Register the CrewAI adapter
runner.register_adapter('crewai', CrewAIAdapter)

# Define your agent configuration
agent_config = {
    'name': 'research-agent',
    'task': 'Research the latest trends in AI agents',
    'model': 'gpt-4',
    # Add your CrewAI-specific configuration here
}

try:
    # Run the agent with AgentSentry protection
    result = runner.run('crewai', agent_config)
    
    print("✅ Agent execution completed!")
    print(f"Session ID: {result['session_id']}")
    print(f"Total Cost: ${result['metrics']['total_cost_usd']:.4f}")
    print(f"Total Tokens: {result['metrics']['total_tokens']}")
    print(f"Loops Executed: {result['metrics']['loops_executed']}")

except Exception as e:
    print(f"❌ Agent execution failed: {e}")

finally:
    runner.shutdown()
