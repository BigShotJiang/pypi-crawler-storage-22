"""
Example: Token Guardrail Middleware
====================================
Demonstrates how to use the TokenGuardrail middleware directly
for custom integrations.
"""

from agentsentry.middleware import TokenGuardrail, BudgetExceededError

# Initialize guardrail with custom limits
guardrail = TokenGuardrail(config={
    'max_budget_usd': 2.0,
    'max_loops': 10
})

session_id = 'custom-session-123'

try:
    with guardrail.track_execution(session_id=session_id):
        # Simulate agent making API calls
        for i in range(15):  # Will hit loop limit
            # Your LLM API call here
            print(f"Loop {i+1}: Making API call...")
            
            # Track the call after receiving response
            guardrail.intercept_api_call(
                session_id=session_id,
                model='gpt-3.5-turbo',
                prompt_tokens=100,
                completion_tokens=50,
                is_loop_iteration=True
            )
            
            print(f"  Cost so far: ${guardrail.get_session_metrics(session_id)['total_cost_usd']:.4f}")

except BudgetExceededError as e:
    print(f"\n⚠️  CIRCUIT BREAKER TRIGGERED!")
    print(f"Reason: {e.threshold_type.upper()} threshold exceeded")
    print(f"Message: {e.message}")
    print(f"Total Cost: ${e.total_cost:.4f}")
    print(f"Total Tokens: {e.total_tokens}")
    print(f"Loops: {e.loops_executed}")
