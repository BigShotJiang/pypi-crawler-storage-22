"""Agent skill packaging. Part of the skillmd ecosystem."""
__version__ = '0.0.1'
