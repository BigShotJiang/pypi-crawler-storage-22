"""Tinman test suite."""
