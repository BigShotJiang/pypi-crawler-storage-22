"""Tinman CLI - command line interface."""

from .main import cli, main

__all__ = ["cli", "main"]
