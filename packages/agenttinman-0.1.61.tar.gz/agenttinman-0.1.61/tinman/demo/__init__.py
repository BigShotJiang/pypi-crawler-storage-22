"""Demo scripts packaged with Tinman."""

# Avoid importing demo modules at package import time to prevent module re-entry
# warnings when running `python -m tinman.demo.<demo>`.
