"""TUI components for AgentWatch."""

from .app import AgentWatchApp

__all__ = ["AgentWatchApp"]
