"""AgentWorld Gateway — connect to Hub, run LLM-driven agents."""

__version__ = "0.1.3"
