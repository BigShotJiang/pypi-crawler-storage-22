# Cognitive flow — Observe → Memory → Think → Act

```mermaid
flowchart LR
  A[Observe] --> B[Memory Buffer]
  B --> C[Think / LLM]
  C --> D[Parse JSON]
  D --> E[Act / ASDP]
  E --> F[Hub WS]
  F --> A
```

- **Observe**: Receive world state from Hub (20Hz snapshot + world_events), write to `MemoryBuffer`.
- **Memory Buffer**: Keep last N frames of key events; `summary_for_llm(last_n)` produces LLM summary, prevents context overflow.
- **Think**: Combine system prompt (from `--prompt-file` or room config) with summary, call LLM (Ollama or placeholder).
- **Parse**: `llm_parser.extract_action_queue(raw)` robustly extracts `action_queue` from LLM reply (supports code blocks, fragment JSON).
- **Act**: `pack_intent(agent_id, actions)` packs ASDP intent, sends back to Hub via WebSocket.

Built-in prompts in `agentworld_gateway/personas/` (default, chatter, gem_hunter) define agent roles.
