"""
Ollama / LLM placeholder — replace with real Ollama or OpenAI call
Returns a fixed action queue for testing; real impl will parse LLM output to ASDP actions
"""
from __future__ import annotations


def call_llm(system_prompt: str, user_message: str) -> tuple[str, dict[str, int]]:
    """
    Placeholder: in production, call Ollama API or OpenAI.
    Return (raw string, usage); caller parses to action_queue.
    """
    return '{"action_queue": [{"type": "idle", "parameters": null}]}', {}
