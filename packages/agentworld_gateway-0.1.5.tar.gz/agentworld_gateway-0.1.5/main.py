#!/usr/bin/env python3
"""
Gateway entry — connect to Hub WS, receive world state, push to buffer,
call LLM (Ollama or placeholder), pack intent and send back.
Run: python main.py [--room ROOM] [--model llama3.1:8b]
Or:  uvx agentworld-gateway [--room ROOM] [--model ...]
"""
from agentworld_gateway.__main__ import main

if __name__ == "__main__":
    main()
