# AllowMapCompiled

A map of hostname lookup to RuleCompiled 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**any string name** | [**[AllowRuleCompiled]**](AllowRuleCompiled.md) | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


