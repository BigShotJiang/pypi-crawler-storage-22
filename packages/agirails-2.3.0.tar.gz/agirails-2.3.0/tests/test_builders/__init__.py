"""Tests for builder patterns."""
