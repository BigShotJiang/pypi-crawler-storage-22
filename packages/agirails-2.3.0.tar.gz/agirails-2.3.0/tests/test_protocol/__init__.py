"""Tests for protocol modules."""
