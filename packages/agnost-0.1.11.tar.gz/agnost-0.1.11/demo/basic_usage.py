"""
Basic usage example for Agnost Conversation SDK.

This example demonstrates how to track AI conversations and events.
"""

import agnost_conversation as agnost
import uuid

# Initialize with your organization ID
agnost.init("your-org-id", debug=True)

# Identify a user
agnost.identify("user_123", {
    "name": "John Doe",
    "email": "john@example.com",
    "plan": "paid"
})

# Create a conversation ID to group related events
convo_id = "conv_" + str(uuid.uuid4())

# Track a simple AI interaction
event_id = agnost.track(
    user_id="user_123",
    input="What is the weather today?",
    output="The weather is sunny with a high of 72F.",
    agent_name="weather-agent",
    convo_id=convo_id,
    properties={"temperature": "0.7"},
    latency=1500
)
print(f"Tracked event: {event_id}")

# Track a follow-up message in the same conversation
agnost.track(
    user_id="user_123",
    input="Should I bring an umbrella?",
    output="No, you won't need an umbrella today. The forecast shows clear skies.",
    agent_name="weather-agent",
    convo_id=convo_id,
    latency=1200
)

# Example using partial events (begin/finish)
interaction = agnost.begin(
    user_id="user_123",
    agent_name="weather-agent",
    convo_id=convo_id
)

interaction.set_input("What should I wear?")
interaction.set_property("context", "weather_followup")

# Simulate some processing time...
import time
start = time.time()
time.sleep(0.5)  # Simulated API call
latency_ms = int((time.time() - start) * 1000)

interaction.finish(
    output="I recommend light clothing - a t-shirt and shorts would be perfect for today's weather.",
    latency=latency_ms
)

# Track an error case
agnost.track(
    user_id="user_123",
    input="Generate an image of a sunset",
    success=False,
    agent_name="image-agent",
    properties={"error": "Rate limit exceeded", "error_code": "429"}
)

# Ensure all events are sent before exiting
agnost.shutdown()
print("Demo complete!")
