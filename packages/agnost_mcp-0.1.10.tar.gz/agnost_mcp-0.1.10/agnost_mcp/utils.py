import logging
from typing import Any, Tuple
from mcp.server import Server
from mcp import ServerResult

logger = logging.getLogger("agnost.analytics")

def is_fastmcp_server(server: Any) -> bool:
    """
    Check if the server is a FastMCP instance.
    """
    return hasattr(server, "_mcp_server") and hasattr(server, "_tool_manager")


def extract_result_text(response: Any) -> str:
    """
    Extract text content from an MCP ServerResult or any response object.
    This is used for eval/SOP checking which needs the actual text content.
    """
    if response is None:
        return ""

    try:
        # Handle MCP ServerResult
        if hasattr(response, 'root'):
            result = response.root
            if hasattr(result, 'content') and result.content:
                text_parts = []
                for content_item in result.content:
                    # Handle TextContent
                    if hasattr(content_item, 'text'):
                        text_parts.append(str(content_item.text))
                    # Handle other content types with text attribute
                    elif hasattr(content_item, 'type') and content_item.type == 'text':
                        if hasattr(content_item, 'content'):
                            text_parts.append(str(content_item.content))
                        elif hasattr(content_item, 'text'):
                            text_parts.append(str(content_item.text))
                if text_parts:
                    return "\n".join(text_parts)

        # Handle dict-like responses
        if isinstance(response, dict):
            # Look for common text fields
            for key in ['text', 'content', 'message', 'output', 'result', 'response']:
                if key in response:
                    val = response[key]
                    if isinstance(val, str):
                        return val
                    elif isinstance(val, list):
                        return "\n".join(str(item) for item in val)
            # Fallback to JSON representation
            import json
            return json.dumps(response)

        # Handle list responses
        if isinstance(response, list):
            return "\n".join(str(item) for item in response)

        # Default: convert to string
        return str(response)

    except Exception as e:
        logger.debug(f"Error extracting result text: {e}")
        return str(response)

def is_mcp_error_response(response: ServerResult) -> Tuple[bool, str]:
    """
    Check if the response is an MCP error.
    """
    try:
        if hasattr(response, 'root'):
            result = response.root
            if hasattr(result, 'isError') and result.isError:
                if hasattr(result, 'content') and result.content:
                    for content_item in result.content:
                        if hasattr(content_item, 'text'):
                            return True, str(content_item.text)
                        elif hasattr(content_item, 'type') and hasattr(content_item, 'content'):
                            if content_item.type == 'text':
                                return True, str(content_item.content)
                    if result.content and len(result.content) > 0:
                        return True, str(result.content[0])
                    return True, "Unknown error"
                return True, "Unknown error"
        return False, ""
    except (AttributeError, IndexError):
        return False, ""
    except Exception as e:
        logger.debug(f"Error checking response: {str(e)}")
        return False, f"Error checking response: {str(e)}"
