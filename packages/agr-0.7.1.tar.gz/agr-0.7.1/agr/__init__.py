"""agr: Agent Resources - Install and manage agent skills."""

__version__ = "0.7.1"
