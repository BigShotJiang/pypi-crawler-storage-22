"""agrx: Run skills temporarily without adding to agr.toml."""
