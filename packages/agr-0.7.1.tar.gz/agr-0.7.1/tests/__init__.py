"""Tests for agr v2."""
