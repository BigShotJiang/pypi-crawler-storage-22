from __future__ import annotations

from agrobr.contracts import (
    BreakingChangePolicy,
    Column,
    ColumnType,
    Contract,
    register_contract,
)

CREDITO_RURAL_V1 = Contract(
    name="bcb.credito_rural",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["safra", "produto", "uf", "finalidade"],
    columns=[
        Column(
            name="safra",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="produto",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="uf",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="finalidade",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="agregacao",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="volume",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            min_value=0,
        ),
        Column(
            name="valor",
            type=ColumnType.FLOAT,
            nullable=True,
            unit="BRL",
            stable=True,
            min_value=0,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'safra' always matches pattern YYYY/YY",
        "'uf' is always a valid Brazilian state code when present",
        "Numeric values are always >= 0",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

EXPORTACAO_V1 = Contract(
    name="comexstat.exportacao",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["ano", "mes", "produto", "uf"],
    columns=[
        Column(
            name="ano",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=1997,
        ),
        Column(
            name="mes",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=1,
            max_value=12,
        ),
        Column(
            name="produto",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="uf",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="kg_liquido",
            type=ColumnType.FLOAT,
            nullable=True,
            unit="kg",
            stable=True,
            min_value=0,
        ),
        Column(
            name="valor_fob_usd",
            type=ColumnType.FLOAT,
            nullable=True,
            unit="USD",
            stable=True,
            min_value=0,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'ano' is always >= 1997",
        "'mes' is between 1 and 12",
        "Numeric values are always >= 0",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

FERTILIZANTE_V1 = Contract(
    name="anda.fertilizante",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["ano", "mes", "uf", "produto_fertilizante"],
    columns=[
        Column(
            name="ano",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=2000,
        ),
        Column(
            name="mes",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=1,
            max_value=12,
        ),
        Column(
            name="uf",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="produto_fertilizante",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="volume_ton",
            type=ColumnType.FLOAT,
            nullable=True,
            unit="ton",
            stable=True,
            min_value=0,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'ano' is always >= 2000",
        "'mes' is between 1 and 12",
        "Numeric values are always >= 0",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

FOCOS_QUEIMADAS_V1 = Contract(
    name="queimadas.focos",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["data", "lat", "lon", "satelite", "hora_gmt"],
    columns=[
        Column(
            name="data",
            type=ColumnType.DATE,
            nullable=False,
            stable=True,
        ),
        Column(
            name="hora_gmt",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="lat",
            type=ColumnType.FLOAT,
            nullable=False,
            stable=True,
            min_value=-35.0,
            max_value=6.0,
        ),
        Column(
            name="lon",
            type=ColumnType.FLOAT,
            nullable=False,
            stable=True,
            min_value=-74.0,
            max_value=-30.0,
        ),
        Column(
            name="satelite",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="municipio",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="municipio_id",
            type=ColumnType.INTEGER,
            nullable=True,
            stable=True,
        ),
        Column(
            name="estado",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="uf",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="bioma",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="numero_dias_sem_chuva",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            min_value=0,
        ),
        Column(
            name="precipitacao",
            type=ColumnType.FLOAT,
            nullable=True,
            unit="mm",
            stable=True,
            min_value=0,
        ),
        Column(
            name="risco_fogo",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            min_value=0,
            max_value=1,
        ),
        Column(
            name="frp",
            type=ColumnType.FLOAT,
            nullable=True,
            unit="MW",
            stable=True,
            min_value=0,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'lat' is always between -35 and 6 (Brazil bounding box)",
        "'lon' is always between -74 and -30 (Brazil bounding box)",
        "'data' is always a valid date",
        "Numeric values are always >= 0 when present",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

DESMATAMENTO_PRODES_V1 = Contract(
    name="desmatamento.prodes",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["ano", "uf", "classe", "bioma"],
    columns=[
        Column(
            name="ano",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=2000,
        ),
        Column(
            name="uf",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="area_km2",
            type=ColumnType.FLOAT,
            nullable=False,
            unit="km2",
            stable=True,
            min_value=0,
        ),
        Column(
            name="satelite",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="sensor",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="bioma",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'ano' is always >= 2000",
        "'area_km2' is always >= 0",
        "'uf' is always a valid Brazilian state code",
        "'bioma' is always a valid Brazilian biome name",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

DESMATAMENTO_DETER_V1 = Contract(
    name="desmatamento.deter",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["data", "classe", "uf", "municipio", "bioma"],
    columns=[
        Column(
            name="data",
            type=ColumnType.DATE,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="uf",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="municipio",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="municipio_id",
            type=ColumnType.INTEGER,
            nullable=True,
            stable=True,
        ),
        Column(
            name="area_km2",
            type=ColumnType.FLOAT,
            nullable=False,
            unit="km2",
            stable=True,
            min_value=0,
        ),
        Column(
            name="satelite",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="sensor",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="bioma",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'data' is always a valid date",
        "'area_km2' is always >= 0",
        "'uf' is always a valid Brazilian state code",
        "'bioma' is always 'Amazônia' or 'Cerrado'",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

MAPBIOMAS_COBERTURA_V1 = Contract(
    name="mapbiomas.cobertura",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["bioma", "estado", "classe_id", "ano"],
    columns=[
        Column(
            name="bioma",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="estado",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe_id",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="nivel_0",
            type=ColumnType.STRING,
            nullable=True,
            stable=True,
        ),
        Column(
            name="ano",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=1985,
        ),
        Column(
            name="area_ha",
            type=ColumnType.FLOAT,
            nullable=False,
            unit="ha",
            stable=True,
            min_value=0,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'bioma' is always a valid Brazilian biome name",
        "'estado' is always a valid Brazilian state code (UF)",
        "'ano' is always between 1985 and current year",
        "'area_ha' is always >= 0",
        "'classe_id' maps to MapBiomas LULC legend codes",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

MAPBIOMAS_TRANSICAO_V1 = Contract(
    name="mapbiomas.transicao",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["bioma", "estado", "classe_de_id", "classe_para_id", "periodo"],
    columns=[
        Column(
            name="bioma",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="estado",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe_de_id",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe_de",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe_para_id",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
        ),
        Column(
            name="classe_para",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="periodo",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="area_ha",
            type=ColumnType.FLOAT,
            nullable=False,
            unit="ha",
            stable=True,
            min_value=0,
        ),
    ],
    guarantees=[
        "Column names never change (additions only)",
        "'bioma' is always a valid Brazilian biome name",
        "'estado' is always a valid Brazilian state code (UF)",
        "'periodo' always matches pattern YYYY-YYYY",
        "'area_ha' is always >= 0",
        "'classe_de_id' and 'classe_para_id' map to MapBiomas LULC legend codes",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

CONAB_PROGRESSO_V1 = Contract(
    name="conab.progresso_safra",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["cultura", "safra", "operacao", "estado", "semana_atual"],
    columns=[
        Column(
            name="cultura",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
            description="Cultura (ex: Soja, Milho 2a)",
        ),
        Column(
            name="safra",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
            description="Safra no formato YYYY/YY",
        ),
        Column(
            name="operacao",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
            description="Semeadura ou Colheita",
        ),
        Column(
            name="estado",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
            description="Codigo UF (ex: MT, GO, PR)",
        ),
        Column(
            name="semana_atual",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
            description="Data da semana no formato YYYY-MM-DD",
        ),
        Column(
            name="pct_ano_anterior",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            unit="fracao",
            min_value=0.0,
            max_value=1.0,
        ),
        Column(
            name="pct_semana_anterior",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            unit="fracao",
            min_value=0.0,
            max_value=1.0,
        ),
        Column(
            name="pct_semana_atual",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            unit="fracao",
            min_value=0.0,
            max_value=1.0,
        ),
        Column(
            name="pct_media_5_anos",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            unit="fracao",
            min_value=0.0,
            max_value=1.0,
        ),
    ],
    guarantees=[
        "PK unica por combinacao cultura + safra + operacao + estado + semana",
        "Valores percentuais entre 0.0 e 1.0 (fracao, nao %)",
        "Dados semanais publicados pela CONAB",
        "'estado' e codigo UF de 2 letras (ex: MT, GO, PR)",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

AJUSTE_DIARIO_V1 = Contract(
    name="b3.ajuste_diario",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["data", "ticker", "vencimento_codigo"],
    columns=[
        Column(name="data", type=ColumnType.DATE, nullable=False, stable=True),
        Column(name="ticker", type=ColumnType.STRING, nullable=False, stable=True),
        Column(name="descricao", type=ColumnType.STRING, nullable=True, stable=True),
        Column(
            name="vencimento_codigo",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="vencimento_mes",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=1,
            max_value=12,
        ),
        Column(
            name="vencimento_ano",
            type=ColumnType.INTEGER,
            nullable=False,
            stable=True,
            min_value=2000,
        ),
        Column(
            name="ajuste_anterior",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            min_value=0,
        ),
        Column(
            name="ajuste_atual",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
            min_value=0,
        ),
        Column(name="variacao", type=ColumnType.FLOAT, nullable=True, stable=True),
        Column(
            name="ajuste_por_contrato",
            type=ColumnType.FLOAT,
            nullable=True,
            stable=True,
        ),
        Column(name="unidade", type=ColumnType.STRING, nullable=True, stable=True),
    ],
    guarantees=[
        "PK unica por combinacao data + ticker + vencimento_codigo",
        "'ticker' sempre em {BGI, CCM, ICF, CNL, ETH, SJC, SOY}",
        "'vencimento_mes' entre 1 e 12",
        "'ajuste_atual' e 'ajuste_anterior' sempre >= 0 quando presentes",
        "Dados apenas para dias uteis (sem pregao em weekends/feriados)",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

PRECO_ATACADO_V1 = Contract(
    name="conab.preco_atacado",
    version="1.0",
    effective_from="0.10.0",
    primary_key=["data", "produto", "ceasa"],
    columns=[
        Column(
            name="data",
            type=ColumnType.DATE,
            nullable=False,
            stable=True,
        ),
        Column(
            name="produto",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="categoria",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="unidade",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="ceasa",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="ceasa_uf",
            type=ColumnType.STRING,
            nullable=False,
            stable=True,
        ),
        Column(
            name="preco",
            type=ColumnType.FLOAT,
            nullable=False,
            unit="BRL",
            stable=True,
            min_value=0,
        ),
    ],
    guarantees=[
        "PK unica por combinacao data + produto + ceasa",
        "'produto' sempre em maiusculas (ex: TOMATE, ABACAXI)",
        "'categoria' sempre FRUTAS ou HORTALICAS",
        "'unidade' sempre KG, UN ou DZ",
        "'ceasa_uf' sempre codigo UF de 2 letras",
        "'preco' sempre > 0 (nulls filtrados)",
    ],
    breaking_policy=BreakingChangePolicy.MAJOR_VERSION,
)

register_contract("ajuste_diario", AJUSTE_DIARIO_V1)
register_contract("conab_progresso", CONAB_PROGRESSO_V1)
register_contract("preco_atacado", PRECO_ATACADO_V1)
register_contract("credito_rural", CREDITO_RURAL_V1)
register_contract("desmatamento_prodes", DESMATAMENTO_PRODES_V1)
register_contract("desmatamento_deter", DESMATAMENTO_DETER_V1)
register_contract("exportacao", EXPORTACAO_V1)
register_contract("fertilizante", FERTILIZANTE_V1)
register_contract("focos_queimadas", FOCOS_QUEIMADAS_V1)
register_contract("mapbiomas_cobertura", MAPBIOMAS_COBERTURA_V1)
register_contract("mapbiomas_transicao", MAPBIOMAS_TRANSICAO_V1)

__all__ = [
    "AJUSTE_DIARIO_V1",
    "CONAB_PROGRESSO_V1",
    "PRECO_ATACADO_V1",
    "CREDITO_RURAL_V1",
    "DESMATAMENTO_DETER_V1",
    "DESMATAMENTO_PRODES_V1",
    "EXPORTACAO_V1",
    "FERTILIZANTE_V1",
    "FOCOS_QUEIMADAS_V1",
    "MAPBIOMAS_COBERTURA_V1",
    "MAPBIOMAS_TRANSICAO_V1",
]
