"""Tests for CEPEA module."""
