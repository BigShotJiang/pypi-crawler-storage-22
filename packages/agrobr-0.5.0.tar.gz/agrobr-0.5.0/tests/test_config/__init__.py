"""Tests for config module."""
