"""Tests for contracts module."""
