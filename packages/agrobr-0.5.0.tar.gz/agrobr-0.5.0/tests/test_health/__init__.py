"""Tests for health module."""
