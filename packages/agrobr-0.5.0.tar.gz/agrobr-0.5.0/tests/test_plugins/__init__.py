"""Tests for plugins module."""
