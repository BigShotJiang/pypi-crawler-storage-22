"""SERA - SWE-agent to Claude Code translation proxy."""

from sera.main import main

__all__ = ["main"]
