"""Main ai2hum client."""

import os
from typing import Any, Dict, List, Optional, Union

import httpx

from .exceptions import (
    Ai2humError,
    AuthError,
    RateLimitError,
    TaskNotFoundError,
    ValidationError,
)
from .models import (
    PricingEstimate,
    Task,
    TaskList,
    TaskStatus,
    TaskType,
    Urgency,
    Webhook,
    WebhookList,
    WorkerListResponse,
)

API_BASE = os.environ.get("AI2HUM_API_BASE", "https://api.ai2hum.ai")


class _TasksNamespace:
    """client.tasks.create(), .get(), .list(), .cancel()"""

    def __init__(self, client: "Ai2hum"):
        self._client = client

    def create(
        self,
        *,
        type: TaskType,
        title: str,
        description: str,
        reward: int,
        location: Optional[str] = None,
        urgency: Urgency = "medium",
        skills: Optional[List[str]] = None,
        details: Optional[str] = None,
        posted_by: Optional[str] = None,
        callback_url: Optional[str] = None,
        preferred_worker_id: Optional[str] = None,
        max_reward: Optional[int] = None,
        required_languages: Optional[List[str]] = None,
        required_tech: Optional[List[str]] = None,
        min_trust_score: Optional[float] = None,
        min_completed_tasks: Optional[int] = None,
        preferred_location: Optional[str] = None,
        exclude_workers: Optional[List[str]] = None,
        is_public: Optional[bool] = None,
        agent_note: Optional[str] = None,
        time_estimate: Optional[str] = None,
    ) -> Task:
        """Create a new task/bounty for a human worker.

        Args:
            type: Task type (e.g., "phone_call", "physical_visit")
            title: Short task title
            description: Detailed instructions for the worker
            reward: Reward in INR
            location: Where the task should be performed
            urgency: How urgently (low/medium/high/critical)
            skills: Required worker skills
            details: Additional instructions
            posted_by: Who posted the task
            callback_url: Webhook URL for task events
            preferred_worker_id: Re-hire a specific worker (e.g., "WRK-001")
            max_reward: Budget cap in INR
            required_languages: Languages the worker must speak
            required_tech: Equipment needed (e.g., ["two_wheeler", "camera"])
            min_trust_score: Minimum worker trust score (0-100)
            min_completed_tasks: Minimum completed task count
            preferred_location: Preferred worker location for matching
            exclude_workers: Worker IDs to exclude from matching
            is_public: Set True to show on public bounty board (default: False)
            agent_note: AI agent note shown on the public bounty board
            time_estimate: Estimated time to complete (e.g., "30 minutes")
        """
        payload: Dict[str, Any] = {
            "type": type,
            "title": title,
            "description": description,
            "reward": reward,
        }
        if location:
            payload["location"] = location
        if urgency:
            payload["urgency"] = urgency
        if skills:
            payload["skills"] = skills
        if details:
            payload["details"] = details
        if posted_by:
            payload["posted_by"] = posted_by
        if callback_url:
            payload["callback_url"] = callback_url
        if preferred_worker_id:
            payload["preferred_worker_id"] = preferred_worker_id
        if max_reward is not None:
            payload["max_reward"] = max_reward
        if required_languages:
            payload["required_languages"] = required_languages
        if required_tech:
            payload["required_tech"] = required_tech
        if min_trust_score is not None:
            payload["min_trust_score"] = min_trust_score
        if min_completed_tasks is not None:
            payload["min_completed_tasks"] = min_completed_tasks
        if preferred_location:
            payload["preferred_location"] = preferred_location
        if exclude_workers:
            payload["exclude_workers"] = exclude_workers
        if is_public is not None:
            payload["is_public"] = is_public
        if agent_note:
            payload["agent_note"] = agent_note
        if time_estimate:
            payload["time_estimate"] = time_estimate

        data = self._client._request("POST", "/v1-tasks", json=payload)
        return Task(**data)

    def get(self, task_id: str) -> Task:
        """Get a task by ID."""
        data = self._client._request("GET", f"/v1-tasks/{task_id}")
        return Task(**data)

    def list(
        self,
        *,
        status: Optional[TaskStatus] = None,
        type: Optional[TaskType] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> TaskList:
        """List tasks with optional filters."""
        params: Dict[str, str] = {"limit": str(limit), "offset": str(offset)}
        if status:
            params["status"] = status
        if type:
            params["type"] = type
        data = self._client._request("GET", "/v1-tasks", params=params)
        return TaskList(**data)

    def cancel(self, task_id: str) -> Task:
        """Cancel an open task."""
        data = self._client._request(
            "PATCH", f"/v1-tasks/{task_id}", json={"status": "CANCELLED"}
        )
        return Task(**data)


class _WebhooksNamespace:
    """client.webhooks.create(), .list(), .delete()"""

    def __init__(self, client: "Ai2hum"):
        self._client = client

    def create(
        self,
        *,
        url: str,
        events: Optional[List[str]] = None,
    ) -> Webhook:
        """Register a webhook endpoint."""
        payload: Dict[str, Any] = {"url": url}
        if events:
            payload["events"] = events
        data = self._client._request("POST", "/v1-webhooks", json=payload)
        return Webhook(**data)

    def list(self) -> WebhookList:
        """List registered webhooks."""
        data = self._client._request("GET", "/v1-webhooks")
        return WebhookList(**data)

    def delete(self, webhook_id: str) -> Dict[str, Any]:
        """Delete a webhook."""
        return self._client._request("DELETE", f"/v1-webhooks/{webhook_id}")


class _WorkersNamespace:
    """client.workers.list(), .history()"""

    def __init__(self, client: "Ai2hum"):
        self._client = client

    def list(
        self,
        *,
        type: Optional[TaskType] = None,
        location: Optional[str] = None,
        language: Optional[str] = None,
        min_trust_score: Optional[float] = None,
        match_for_type: Optional[TaskType] = None,
    ) -> WorkerListResponse:
        """List available workers with optional filters.

        Args:
            type: Filter by skill/task type
            location: Filter by location (e.g., "Bangalore")
            language: Filter by language (e.g., "Hindi")
            min_trust_score: Minimum trust score (0-100)
            match_for_type: Rank workers by match score for this task type
        """
        params: Dict[str, str] = {}
        if type:
            params["type"] = type
        if location:
            params["location"] = location
        if language:
            params["language"] = language
        if min_trust_score is not None:
            params["min_trust_score"] = str(min_trust_score)
        if match_for_type:
            params["match_for_type"] = match_for_type
        data = self._client._request("GET", "/v1-workers", params=params)
        return WorkerListResponse(**data)

    def history(self) -> WorkerListResponse:
        """List workers you've previously worked with. Useful for re-hiring."""
        data = self._client._request(
            "GET", "/v1-workers", params={"history": "true"}
        )
        return WorkerListResponse(**data)


class Ai2hum:
    """
    ai2hum API client.

    Usage:
        from ai2hum import Ai2hum

        client = Ai2hum(api_key="sk_live_...")

        # Create a task with worker preferences
        task = client.tasks.create(
            type="phone_call",
            title="Call BBMP about property tax",
            description="Inquire about reassessment...",
            reward=300,
            location="Bangalore",
            preferred_worker_id="WRK-001",  # re-hire a trusted worker
            min_trust_score=80,
        )

        # Check who was matched
        print(task.matched_worker)  # Worker who was auto-assigned
        print(task.match_score)     # Score breakdown

        # Browse available workers
        workers = client.workers.list(type="physical_visit", location="Bangalore")

        # See workers you've used before
        past = client.workers.history()
    """

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        self._api_key = api_key
        self._base_url = base_url or API_BASE
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.tasks = _TasksNamespace(self)
        self.webhooks = _WebhooksNamespace(self)
        self.workers = _WorkersNamespace(self)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        response = self._http.request(method, path, json=json, params=params)
        data = response.json()

        if response.status_code == 401:
            raise AuthError(data.get("error", "Authentication failed"))
        if response.status_code == 403:
            raise RateLimitError(data.get("error", "Rate limit exceeded"))
        if response.status_code == 404:
            raise TaskNotFoundError(path.split("/")[-1])
        if response.status_code == 400:
            raise ValidationError(data.get("error", "Validation failed"))
        if not response.is_success:
            raise Ai2humError(
                data.get("error", f"Request failed with status {response.status_code}"),
                status_code=response.status_code,
            )

        return data

    def pricing(
        self,
        *,
        type: Optional[TaskType] = None,
        urgency: Urgency = "medium",
    ) -> Union[PricingEstimate, Dict[str, Any]]:
        """Get pricing estimate for a task type."""
        params: Dict[str, str] = {}
        if type:
            params["type"] = type
        if urgency:
            params["urgency"] = urgency
        data = self._request("GET", "/v1-pricing", params=params)
        if type:
            return PricingEstimate(**data)
        return data

    def close(self) -> None:
        """Close the HTTP client."""
        self._http.close()

    def __enter__(self) -> "Ai2hum":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
