"""Custom exceptions for the ai2hum SDK."""

from __future__ import annotations


class Ai2humError(Exception):
    """Base exception for ai2hum SDK."""

    def __init__(self, message: str, status_code: int | None = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class AuthError(Ai2humError):
    """Raised when API key is invalid or missing."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, status_code=401)


class RateLimitError(Ai2humError):
    """Raised when task limit is exceeded."""

    def __init__(self, message: str = "Task limit reached. Upgrade your plan."):
        super().__init__(message, status_code=403)


class TaskNotFoundError(Ai2humError):
    """Raised when a task is not found."""

    def __init__(self, task_id: str):
        super().__init__(f"Task {task_id} not found", status_code=404)


class ValidationError(Ai2humError):
    """Raised when request validation fails."""

    def __init__(self, message: str):
        super().__init__(message, status_code=400)
