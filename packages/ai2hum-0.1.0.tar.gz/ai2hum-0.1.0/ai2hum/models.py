"""Pydantic models for ai2hum API responses."""

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel


TaskType = Literal[
    "phone_call",
    "verification",
    "physical_visit",
    "research",
    "expert_review",
    "portal_navigation",
    "pickup",
    "meeting",
    "document_signing",
    "recon",
    "event_attendance",
    "hardware_setup",
    "real_estate",
    "product_testing",
    "errand",
    "photography",
    "purchase",
]

TaskStatus = Literal[
    "OPEN",
    "ASSIGNED",
    "IN_PROGRESS",
    "COMPLETED",
    "CANCELLED",
    "EXPIRED",
]

Urgency = Literal["low", "medium", "high", "critical"]


class MatchScore(BaseModel):
    total: int
    skill: Optional[int] = None
    location: Optional[int] = None
    trust: Optional[int] = None
    history: Optional[int] = None
    availability: Optional[int] = None
    preferred: Optional[bool] = None


class Worker(BaseModel):
    id: str
    name: str
    trust_score: Optional[float] = None
    rating: Optional[float] = None
    location: Optional[str] = None
    skills: Optional[List[str]] = None
    completed_tasks: Optional[int] = None
    available: Optional[bool] = None
    match_score: Optional[int] = None


class WorkerHistory(BaseModel):
    id: str
    name: str
    trust_score: Optional[float] = None
    rating: Optional[float] = None
    location: Optional[str] = None
    skills: Optional[List[str]] = None
    completed_tasks: Optional[int] = None
    available: Optional[bool] = None
    past_tasks: Optional[int] = None
    last_task_at: Optional[str] = None


class Task(BaseModel):
    id: str
    status: TaskStatus
    type: str
    title: str
    description: Optional[str] = None
    reward: int
    currency: str = "INR"
    urgency: Urgency = "medium"
    location: Optional[str] = None
    posted_by: Optional[str] = None
    skills: Optional[List[str]] = None
    details: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    worker: Optional[Worker] = None
    matched_worker: Optional[Worker] = None
    match_score: Optional[MatchScore] = None
    match_preferences: Optional[Dict[str, Any]] = None
    is_public: Optional[bool] = None
    time_estimate: Optional[str] = None
    eta: Optional[str] = None
    url: Optional[str] = None
    created_at: Optional[str] = None
    assigned_at: Optional[str] = None
    completed_at: Optional[str] = None
    updated_at: Optional[str] = None


class TaskList(BaseModel):
    tasks: List[Task]
    total: int
    limit: int
    offset: int


class WorkerListResponse(BaseModel):
    available_workers: int
    estimated_wait: Optional[str] = None
    history: Optional[bool] = None
    workers: List[Worker]


class Webhook(BaseModel):
    id: str
    url: str
    events: List[str]
    secret: Optional[str] = None
    is_active: bool = True
    created_at: Optional[str] = None


class WebhookList(BaseModel):
    webhooks: List[Webhook]
    total: int


class PricingEstimate(BaseModel):
    type: str
    urgency: str
    currency: str = "INR"
    estimated_reward: Dict[str, int]
    estimated_eta: str
    note: Optional[str] = None
