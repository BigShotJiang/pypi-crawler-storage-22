# Changelog

All notable changes to AgentGate (`ai-agents-warden`) will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-17

**First public release** 🎉

### Core Engine
- **Policy Engine** — YAML-based rules with URL, element, and action matching
- **14 Action Types** intercepted: navigate, click, type, select, submit, download, upload, copy, screenshot, scroll, hover, drag, key_press, evaluate_js
- **5 Risk Levels**: critical, high, medium, low, info — with automatic classification
- **4 Decision Types**: allow, block, require_approval, audit_only
- **5 Policy Presets**: `finance-safe`, `readonly`, `permissive`, `procurement-safe`, `support-agent`
- Most-restrictive-wins evaluation across multiple loaded policies

### 3-Layer NLP Intent Detection
- **Layer 1: Keyword matching** — 13 intent categories with 200+ synonyms (payment, delete, admin, etc.)
- **Layer 2: Phonetic matching** — catches typos and morphological variants ("Chekout" → "checkout")
- **Layer 3: Semantic NLP** — sentence embeddings (BAAI/bge-small-en-v1.5 ONNX) with 19 intent categories
- Runs entirely on CPU (~67 MB model), zero API keys, ~2ms per classification
- Custom intent support — add/remove intents at runtime
- Optional install: `pip install ai-agents-warden[nlp]`

### Browser Interceptor
- `InterceptedPage` wrapping Playwright's Page with policy enforcement
- Every `goto()`, `click()`, `fill()`, `type()`, `evaluate()` intercepted
- `ActionBlockedError` and `ApprovalRequiredError` exceptions

### Evidence Vault
- **SHA-256 hash-chained** tamper-evident evidence records
- Session-based tracking with per-agent-id support
- JSONL storage with integrity verification
- Session listing, replay, and export (JSON)

### Capability Tokens
- Scoped, time-bound permission tokens (domain, URL, action type, element text restrictions)
- Rate limiting (per-minute and total actions)
- HMAC-SHA256 signing, verification, and revocation

### Sidecar Service
- FastAPI REST API with 18 endpoints on port 18790
- `/api/v1/evaluate` — single action evaluation
- `/api/v1/evaluate/batch` — batch preflight checks
- `/api/v1/sessions` — evidence session management
- `/api/v1/tokens` — capability token CRUD
- `/api/v1/policies` — policy listing and loading
- `/api/v1/health` — health check
- `/api/v1/license/status`, `/api/v1/license/activate` — license management
- `/api/v1/heartbeat`, `/api/v1/heartbeat/status` — health monitoring
- Python SDK: `AgentGateClient` (sync) and `AsyncAgentGateClient`

### MCP Integration (Model Context Protocol)
- **MCP Server** — expose AgentGate firewall tools via MCP protocol
  - 5 tools: evaluate_action, evaluate_mcp_tool, classify_text_risk, list_policies, health
  - 2 resources: agentgate://presets, agentgate://help
  - Supports stdio, SSE, and streamable-http transports
  - Works with Claude Desktop, Cursor, GPT, and any MCP client
- **MCP Proxy Gateway** — intercept and guard downstream MCP server tool calls
  - Re-exposes downstream tools with policy wrapping
  - Auto-discovers tools from downstream servers
  - YAML config for server definitions
- **MCP Policy Engine** — dedicated policy engine for tool-call governance
  - Same 3-layer intent matching pipeline (keywords → phonetic → NLP semantic)
  - Glob pattern matching for server names and tool names
  - Argument pattern matching, blocked argument values
  - Rate limiting per agent, max argument length enforcement
- **4 MCP Policy Presets**: `mcp-default`, `mcp-readonly`, `mcp-finance-safe`, `mcp-devops-safe`
- **Extensible Plugin System** — transform, validate, audit, and policy plugins
  - Built-in: SQL injection guard, sensitive data guard, rate limiter, argument normalizer, audit logger
  - `PluginRegistry` with priority-ordered pipeline execution
  - `create_secure_registry()` factory for one-line setup
- Install: `pip install ai-agents-warden[mcp]`

### Multi-Agent Session Management
- `MultiAgentSessionManager` — coordinated governance for agent teams
- 6 agent roles: READER, WRITER, ADMIN, EXECUTOR, OBSERVER, CUSTOM
- Role-based policy defaults (allowed/blocked action types, rate limits per role)
- `OrchestrationSession` — group multiple agents under one governed session
- Cross-agent rate limiting (per-agent + collective limits)
- Sequential execution mode — one agent acts at a time
- Pause, resume, and transfer control between agents
- Per-agent evidence sessions with unified orchestration summary

### Heartbeat Integration
- `HeartbeatClient` — async background health monitoring for the sidecar
- Configurable interval, timeout, max missed pings, auto-reconnect
- Policy change detection via hash comparison
- Latency tracking (avg/min/max) and uptime percentage
- 6 event callbacks: on_healthy, on_degraded, on_unhealthy, on_disconnect, on_policy_change, on_reconnect

### Licensing
- Open-core model: Community (free), Trial (24h), Pro ($49/mo), Enterprise ($199/mo)
- Enterprise-grade anti-tamper protection (clock rollback detection, HMAC file integrity, machine binding)
- CLI: `agentgate license status|activate|deactivate`
- Feature gating decorators: `@require_feature()`, `@require_tier()`

### CLI
- `agentgate init` — project scaffolding
- `agentgate sidecar` — start the sidecar service
- `agentgate policies list|show` — policy management
- `agentgate sessions list|replay|verify|export` — evidence management
- `agentgate dashboard` — launch web dashboard
- `agentgate mcp serve|proxy|policies|check` — MCP commands
- `agentgate license status|activate|deactivate` — license management
- `agentgate version` — version info

### Dashboard
- FastAPI web dashboard on port 7860
- Session list, session detail, replay, statistics
- Policy browser and chain integrity verification

### OpenClaw Skill
- Ready-to-use skill package (`skills/agentgate/`)
- `SKILL.md` with full instructions for OpenClaw
- Default and strict policy presets

### Documentation
- README with quickstart, architecture diagram, integration guides (8 frameworks)
- Non-technical user guide (`docs/GUIDE.md`)
- Architecture deep-dive (`docs/ARCHITECTURE.md`)
- Operations guide (`docs/OPERATIONS.md`)
- Agent compatibility matrix (`docs/AGENTS.md`)
- PyPI description (`PYPI_README.md`)

### Testing
- 641 tests across 15 test files, all passing
- Coverage: policy engine, intent matching, semantic NLP, evidence vault, capability tokens, sidecar, SDK client, MCP types, MCP policy engine, MCP plugins, multi-agent sessions, heartbeat

[1.0.0]: https://github.com/Nitin-100/agentgate/releases/tag/v1.0.0
