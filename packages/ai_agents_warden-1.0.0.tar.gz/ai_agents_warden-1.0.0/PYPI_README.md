# AgentGate — Guardrails & Policy Enforcement for AI Agents

[![PyPI](https://img.shields.io/pypi/v/ai-agents-warden?color=blue&label=PyPI)](https://pypi.org/project/ai-agents-warden/)
[![Downloads](https://img.shields.io/pypi/dm/ai-agents-warden?color=green&label=Downloads)](https://pypi.org/project/ai-agents-warden/)
[![Python 3.11+](https://img.shields.io/pypi/pyversions/ai-agents-warden)](https://pypi.org/project/ai-agents-warden/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-green)](https://github.com/Nitin-100/agentgate/blob/master/LICENSE)

**AgentGate** stops AI agents from doing things they shouldn't — before they happen.

Your AI agent wants to click "Pay $5,000"? **Blocked.** Call `delete_database` via MCP? **Blocked.** Export customer PII? **Requires your approval first.** Every action is recorded in a tamper-proof audit trail.

> **Not guardrails-ai.** That project validates LLM text outputs. AgentGate enforces policies on agent **actions** — clicks, tool calls, browser interactions, MCP requests.

---

## Who Is This For?

| You are... | AgentGate helps you... |
|---|---|
| **A developer** building AI agents | Add policy enforcement to your agent in 3 lines of code |
| **A team lead** deploying agents at work | Control what agents can do, prove what they did |
| **A solo user** running OpenClaw / browser-use | Protect yourself from agent mistakes on banking, shopping, admin sites |
| **A business** using AI automation | Meet compliance requirements with tamper-proof audit trails |

---

## Install

```bash
pip install ai-agents-warden
```

Optional extras:

```bash
pip install ai-agents-warden[nlp]   # NLP intent detection (~67MB model, CPU-only, zero API keys)
pip install ai-agents-warden[mcp]   # MCP tool-call governance
pip install ai-agents-warden[all]   # Everything
```

---

## How It Works (30-Second Version)

```
Your AI Agent decides to do something
    ↓
AgentGate checks it against your policies (< 1ms)
    ↓
ALLOWED  → action proceeds normally
BLOCKED  → agent is told "no" and picks an alternative
APPROVAL → you decide whether to allow it
    ↓
Everything is recorded in a tamper-proof evidence trail
```

---

## Quick Start

### Option A: I'm a developer — give me code

**Step 1.** Start the AgentGate sidecar (one terminal):

```bash
agentgate sidecar --policy finance-safe
```

**Step 2.** In your agent code, check before every action:

```python
from agentgate.sidecar.client import AgentGateClient

gate = AgentGateClient()  # connects to localhost:18790

result = gate.check_click("https://bank.com", "Pay Now")
# result.allowed → False
# result.reason  → "Element blocked: payment action"

result = gate.check_navigate("https://bank.com/invoices")
# result.allowed → True
```

**Step 3.** That's it. Every action is now policy-checked and evidence-recorded.

### Option B: I use Playwright — wrap my browser

```python
from agentgate import SecureBrowser

async with SecureBrowser(policy="finance-safe") as browser:
    page = await browser.new_page()
    await page.goto("https://example.com")    # Allowed
    await page.click("button#pay")            # Blocked automatically
```

### Option C: I'm not using Python — REST API

```bash
# Start AgentGate
agentgate sidecar --policy finance-safe

# Check any action from any language
curl -X POST http://localhost:18790/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{"action_type":"click", "url":"https://bank.com", "element_text":"Pay Now"}'

# Response: {"allowed": false, "decision": "block", "reason": "Element blocked"}
```

Works from JavaScript, Go, Rust, TypeScript, C# — anything that can POST JSON.

### Option D: I use OpenClaw

```bash
pip install ai-agents-warden
agentgate sidecar --policy finance-safe
cp -r skills/agentgate ~/.openclaw/workspace/skills/
# Done. OpenClaw now checks every action through AgentGate.
```

---

## What Can AgentGate Do?

### Policy Engine — Control what agents do

Write simple YAML rules. AgentGate enforces them on every action.

```yaml
name: finance-safe
rules:
  - action: click
    block_elements:
      - text_contains: ["Pay", "Transfer", "Delete"]
        risk: high
    require_approval:
      - text_contains: ["Submit", "Confirm"]
        risk: medium
  - action: navigate
    block:
      - pattern: "*/admin/*"
```

**Built-in presets:** `finance-safe`, `readonly`, `permissive`, `procurement-safe`, `support-agent`

### NLP Intent Detection — Understands meaning, not just keywords

3-layer pipeline:

1. **Keywords** — 200+ synonyms across 13 categories (payment, delete, admin, etc.)
2. **Phonetic matching** — catches typos ("Chekout" → "checkout")
3. **Semantic NLP** — sentence embeddings understand novel phrases ("Process Transaction" → payment intent)

Runs entirely on CPU, ~2ms per check, zero API keys.

### Evidence Vault — Prove what agents did

Every action is recorded in a SHA-256 hash-chained evidence trail. Tamper-proof by design.

```bash
agentgate sessions list              # See all sessions
agentgate sessions verify <id>       # Verify chain integrity
agentgate sessions export <id>       # Export for compliance
```

### Capability Tokens — Limit agent permissions

Give agents scoped, time-limited access:

- "Access bank.com for 30 minutes"
- "Max 50 actions, no clicks on anything with 'Pay'"
- Auto-expires, HMAC-signed, instantly revocable

### MCP Gateway — Guard tool calls

Intercept and policy-check MCP tool calls to Stripe, GitHub, databases, etc.

```bash
agentgate mcp proxy --config servers.yaml --mcp-policy mcp-finance-safe
```

**Presets:** `mcp-default`, `mcp-readonly`, `mcp-finance-safe`, `mcp-devops-safe`

### Multi-Agent Sessions — Govern agent teams

When multiple agents work together (CrewAI, LangGraph, AutoGen):

- 6 agent roles (READER, WRITER, ADMIN, EXECUTOR, OBSERVER, CUSTOM)
- Cross-agent rate limiting
- Sequential execution locks
- Unified evidence trail across all agents

### Health Monitoring — Know when things break

Background heartbeat monitors the sidecar and alerts you if:

- Sidecar goes offline
- Policies change mid-session
- Connection drops (auto-reconnects)

---

## Works With Every AI Agent Framework

| Framework | How to integrate |
|---|---|
| **OpenAI** (GPT-4, Assistants) | Python SDK or REST API |
| **Anthropic** (Claude, Computer Use) | Python SDK or REST API |
| **Google ADK** | Python SDK or REST API |
| **LangChain / LangGraph** | Python SDK or REST API |
| **CrewAI** | Python SDK or REST API |
| **browser-use** | `SecureBrowser` wraps Playwright directly |
| **OpenClaw** | Built-in skill — copy folder and go |
| **MCP Servers** (Stripe, GitHub, etc.) | MCP proxy gateway |
| **Any HTTP client** | REST API on port 18790 |

---

## Pricing

| Tier | Price | What You Get |
|---|---|---|
| **Community** | Free forever | Core engine, 2 policies, basic sidecar |
| **Trial** | Free 24 hours | All features — starts automatically on first install |
| **Pro** | $49/month | Unlimited policies, evidence vault, tokens, webhooks |
| **Enterprise** | $199/month | Everything + SSO, priority support, 365-day audit logs |

---

## Links

- **GitHub:** [github.com/Nitin-100/agentgate](https://github.com/Nitin-100/agentgate)
- **PyPI:** [pypi.org/project/ai-agents-warden](https://pypi.org/project/ai-agents-warden/)
- **User Guide (non-technical):** [docs/GUIDE.md](https://github.com/Nitin-100/agentgate/blob/master/docs/GUIDE.md)
- **Developer Docs:** [docs/](https://github.com/Nitin-100/agentgate/tree/master/docs)
- **Changelog:** [CHANGELOG.md](https://github.com/Nitin-100/agentgate/blob/master/CHANGELOG.md)

**Apache 2.0** — free to use, modify, and distribute.

---

**AgentGate — Control what AI agents do. Prove what they did.**

*Keywords: ai-agents-warden, agentgate, agent guardrails, ai agent guardrails, ai guardrails, agent security, agent safety, agent policy enforcement, agent runtime safety, mcp gateway, llm guardrails, ai agent security, runtime enforcement, tool security, agentic ai guardrails, multi-agent session management, agent heartbeat, mcp plugin system*
