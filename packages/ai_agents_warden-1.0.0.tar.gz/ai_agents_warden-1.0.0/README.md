<p align="center">
  <h1 align="center">🛡️ AgentGate</h1>
  <p align="center">
    <strong>Guardrails & policy enforcement for AI agents — open-source Python framework</strong>
  </p>
  <p align="center">
    Control what agents can do. Prove what they did.
  </p>
  <p align="center">
    <a href="https://pypi.org/project/ai-agents-warden/"><img src="https://img.shields.io/pypi/v/ai-agents-warden?color=blue&label=PyPI" alt="PyPI"></a>
    <a href="https://pypi.org/project/ai-agents-warden/"><img src="https://img.shields.io/pypi/dm/ai-agents-warden?color=green&label=Downloads" alt="Downloads"></a>
    <a href="https://pypi.org/project/ai-agents-warden/"><img src="https://img.shields.io/pypi/pyversions/ai-agents-warden" alt="Python"></a>
    <a href="https://github.com/Nitin-100/agentgate/blob/master/LICENSE"><img src="https://img.shields.io/badge/License-Apache%202.0-green" alt="License"></a>
  </p>
  <p align="center">
    <a href="#what-is-agentgate">What is it?</a> •
    <a href="#quickstart">Quickstart</a> •
    <a href="#-integrate-with-any-ai-agent">Integrate</a> •
    <a href="#policies">Policies</a> •
    <a href="#-mcp-integration-model-context-protocol">MCP Gateway</a> •
    <a href="#-multi-agent-session-management">Multi-Agent</a> •
    <a href="#evidence-vault">Evidence</a> •
    <a href="#sidecar-api-reference">API</a> •
    <a href="#dashboard">Dashboard</a> •
    <a href="#-licensing--pricing">Pricing</a> •
    <a href="#-documentation">Docs</a>
  </p>
</p>

---

> **AI agents can now click buttons, fill forms, make payments, call tools, and take real actions.**  
> **AgentGate makes sure they only do what they're allowed to — and proves it.**

## What is AgentGate?

**AgentGate** (PyPI: `ai-agents-warden`, import: `agentgate`) is an open-source Python guardrails framework for AI agents. It sits between your AI agent and the browser/MCP server. Before the agent does anything, AgentGate checks the action against your policies and decides: **allow**, **block**, or **require approval**.

> **Not guardrails-ai.** That project validates LLM text outputs. AgentGate enforces policies on agent **actions** — clicks, tool calls, navigation, MCP requests.

### Who is this for?

| You are... | AgentGate helps you... |
|---|---|
| **A developer** building AI agents | Add policy enforcement in 3 lines of code |
| **A team lead** deploying agents | Control what agents can do, prove what they did |
| **A solo user** running OpenClaw / browser-use | Protect yourself from agent mistakes |
| **A business** using AI automation | Meet compliance requirements with tamper-proof audit trails |

### How it works (30-second version)

```
Your AI Agent decides to do something
    ↓
AgentGate checks it against your policies (< 1ms)
    ↓
ALLOWED  → action proceeds normally
BLOCKED  → agent is told "no" and picks an alternative
APPROVAL → you decide whether to allow it
    ↓
Everything is recorded in a tamper-proof evidence trail
```

**Works with:** OpenAI, Anthropic Claude, Google ADK, LangChain, CrewAI, browser-use, OpenClaw, MCP servers, and any HTTP client.

## Architecture

```
AI Agent (OpenAI, Claude, LangChain, CrewAI, etc.)
    ↓
┌──────────────────────────────────────────────────────────┐
│                  AgentGate Runtime                    │
│                                                          │
│  ┌──────────────────────┐   ┌──────────────────────────┐ │
│  │  Browser Firewall    │   │   MCP Proxy Gateway      │ │
│  │                      │   │                          │ │
│  │  Action Interceptor  │   │  Intercepts tool calls   │ │
│  │  (click/type/nav)    │   │  to downstream MCP       │ │
│  └──────────┬───────────┘   │  servers (Stripe,        │ │
│             │               │  GitHub, DB, etc.)       │ │
│             │               └────────────┬─────────────┘ │
│             └──────────┬─────────────────┘               │
│                        ↓                                 │
│  ┌────────────────────────────────────────────────────┐  │
│  │              Policy Engine (shared)                 │  │
│  │                                                    │  │
│  │  Layer 1: Keyword Match    (200+ terms)            │  │
│  │  Layer 2: Phonetic Match   (typo-proof)            │  │
│  │  Layer 3: NLP Semantic     (sentence embeddings)   │  │
│  │                                                    │  │
│  │  → ALLOW / BLOCK / REQUIRE_APPROVAL                │  │
│  └────────────────────────┬───────────────────────────┘  │
│                           ↓                              │
│  ┌────────────────────────────────────────────────────┐  │
│  │           Evidence Vault + Capability Tokens        │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
    ↓                                    ↓
Target Website                    Downstream MCP Servers
(Playwright)                      (Stripe, GitHub, Slack, etc.)
```

## Quickstart

### Install

```bash
pip install ai-agents-warden
playwright install chromium
```

**Want NLP-powered intent detection?** Install with the `nlp` extra:

```bash
pip install ai-agents-warden[nlp]
```

This adds sentence-embedding AI (~67 MB model, runs 100% on CPU, no GPU needed) that can understand the **meaning** of any agent action — not just keyword matches.

**Want MCP (Model Context Protocol) support?** Install with the `mcp` extra:

```bash
pip install ai-agents-warden[mcp]
```

This lets AgentGate act as an **MCP server** (expose firewall tools) or **MCP proxy gateway** (guard downstream MCP servers like Stripe, GitHub, Slack).

**Want everything?**

```bash
pip install ai-agents-warden[all]
```

### Initialize a Project

```bash
agentgate init
```

This creates:
- `policies/` — YAML policy files
- `sample_agent.py` — working example
- `agentgate_evidence/` — evidence storage

### Run Your First Secure Agent

```python
import asyncio
from agentgate import SecureBrowser
from agentgate.interceptor.browser import ActionBlockedError

async def main():
    async with SecureBrowser(policy="finance-safe") as browser:
        page = await browser.new_page()

        # ✅ Reading is allowed
        await page.goto("https://example.com")
        print(await page.title())

        # 🚫 Payment actions are BLOCKED
        try:
            await page.click("button#pay")
        except ActionBlockedError as e:
            print(f"Blocked: {e}")

asyncio.run(main())
```

**That's it.** Your agent can read but can never pay, delete, or export.

## Policies

Policies are simple YAML files that define what an agent can and cannot do:

```yaml
name: finance-safe
description: Allow reading invoices, block all payment actions

block_js_evaluation: true
block_clipboard: true
max_actions_per_minute: 60

rules:
  - action: navigate
    block:
      - pattern: "*/admin/*"
      - pattern: "*/payments/*"

  - action: click
    block_elements:
      - text_contains: ["Pay", "Transfer", "Delete"]
        risk: high
    require_approval:
      - text_contains: ["Submit", "Confirm"]
        risk: medium

  - action: type
    block_elements:
      - selector: "input[type='password']"
      - selector: "input[name='credit_card']"
```

### Built-in Presets

| Policy | Description |
|---|---|
| `finance-safe` | Read financial data, block payments |
| `readonly` | No clicks, typing, or downloads |
| `permissive` | Block only critical-risk actions |

## 🔌 MCP Integration (Model Context Protocol)

AgentGate extends beyond browser actions to guard **MCP tool calls** — the emerging standard for how AI agents interact with external services.

### Two modes of operation:

**1. AgentGate as MCP Server** — Expose firewall tools to any MCP client (Claude Desktop, Cursor, etc.)

```bash
# stdio transport (for Claude Desktop, Cursor)
agentgate mcp serve

# HTTP transport (for production)
agentgate mcp serve --transport streamable-http --port 8100

# With policies
agentgate mcp serve --mcp-policy mcp-finance-safe
```

**2. AgentGate as MCP Proxy Gateway** — Sit between your agent and downstream MCP servers, enforcing policies on every tool call

```bash
# Create a config file
cat > mcp_servers.yaml << EOF
servers:
  - name: stripe
    command: npx
    args: ["-y", "@stripe/mcp"]
  - name: github
    url: http://localhost:8200/mcp
    transport: streamable-http
EOF

# Start the proxy
agentgate mcp proxy --config mcp_servers.yaml --mcp-policy mcp-finance-safe
```

### MCP Policy Presets

| Preset | Description |
|---|---|
| `mcp-default` | Block dangerous tools (delete, payment, admin), allow the rest |
| `mcp-readonly` | Only allow read operations (get_*, list_*, search_*) |
| `mcp-finance-safe` | Block all payment, billing, and financial mutation tools |
| `mcp-devops-safe` | Block destructive infra ops, require approval for deploys |

### MCP Policy YAML

```yaml
name: mcp-custom
description: Custom MCP policy

default_decision: allow
max_calls_per_minute: 30
max_arg_length: 5000

blocked_servers:
  - evil-server

tool_rules:
  - tool_pattern: "delete_*|drop_*|destroy_*"
    decision: block
    reason: Destructive operations are blocked

  - server_pattern: "stripe"
    tool_pattern: "create_payment*|charge_*"
    decision: block
    reason: Payment tools are restricted

  - server_pattern: "production*"
    tool_pattern: "*"
    decision: require_approval
    reason: All production operations need approval

  - intent: payment
    decision: block
    reason: NLP detects payment intent
```

### Check MCP Tool Calls from CLI

```bash
# Quick check if a tool call would be allowed
agentgate mcp check stripe create_payment
# 🚫 BLOCK — Payment tools are blocked by default policy

agentgate mcp check github list_repos
# ✅ ALLOW — Tool is allowed

agentgate mcp check database drop_table --policy mcp-devops-safe
# 🚫 BLOCK — Destructive operations are blocked
```

### Use in Python

```python
from agentgate.mcp import MCPPolicyEngine, MCPToolCall, create_mcp_default_policy

engine = MCPPolicyEngine()
engine.load_policy(create_mcp_default_policy())

# Check any MCP tool call
decision = engine.evaluate(MCPToolCall(
    server_name="stripe",
    tool_name="create_payment",
    arguments={"amount": 100, "currency": "usd"},
))

if decision.allowed:
    # Forward to downstream server
    ...
else:
    print(f"🚫 Blocked: {decision.reason}")
```

### MCP Proxy Architecture

```
AI Agent (Claude, GPT, etc.)
    ↓
┌────────────────────────────────────────┐
│     AgentGate MCP Proxy              │
│                                        │
│  ┌──────────────────────────────────┐  │
│  │  Tool: stripe__create_payment   │  │ ← Agent calls proxied tool
│  └──────────────┬───────────────────┘  │
│                 ↓                      │
│  ┌──────────────────────────────────┐  │
│  │  Policy Check                    │  │ ← MCP policy engine evaluates
│  │  → BLOCK (payment tools blocked) │  │
│  └──────────────────────────────────┘  │
│                                        │
│  If ALLOWED:                           │
│  ┌──────────────────────────────────┐  │
│  │  Forward to downstream Stripe   │  │
│  └──────────────────────────────────┘  │
└────────────────────────────────────────┘
```

## 🤖 Multi-Agent Session Management

When multiple agents collaborate (CrewAI teams, LangGraph multi-agent, AutoGen groups), each agent needs its own governance session with cross-agent coordination.

### Register Agents with Roles

```python
from agentgate.sessions import MultiAgentSessionManager, AgentRole

manager = MultiAgentSessionManager(evidence_dir="./evidence")

# Register agents with role-based permissions
manager.register_agent("researcher", role=AgentRole.READER)    # Can only read/observe
manager.register_agent("writer",     role=AgentRole.WRITER)    # Can read + write
manager.register_agent("admin",      role=AgentRole.ADMIN)     # Full access
manager.register_agent("executor",   role=AgentRole.EXECUTOR)  # Execute but not configure
manager.register_agent("monitor",    role=AgentRole.OBSERVER)  # Observe only
```

### Start an Orchestration

```python
# Group all agents under one orchestration with cross-agent limits
orth = await manager.start_orchestration(
    name="crewai-research-task",
    max_total_actions=500,           # Total actions across ALL agents
    collective_rate_limit=60,        # 60 actions/min across all agents combined
    require_sequential=False,        # Allow parallel execution
)

# Evaluate actions with cross-agent awareness
decision = await manager.evaluate("researcher", action_event)
# Checks: agent role → agent status → per-agent rate limit →
#         collective rate limit → max total actions → sequential lock →
#         policy engine → evidence vault
```

### Agent Roles

| Role | Allowed Actions | Blocked Actions | Rate Limit |
|---|---|---|---|
| `READER` | navigate, scroll, hover, screenshot | click, type, submit, download, upload, evaluate_js | 60/min |
| `WRITER` | All except evaluate_js | evaluate_js | 30/min |
| `ADMIN` | All | None | Unlimited |
| `EXECUTOR` | click, type, submit, navigate, select, scroll | evaluate_js, download, upload | 45/min |
| `OBSERVER` | screenshot, scroll | Everything else | 30/min |
| `CUSTOM` | Custom | Custom | Custom |

### Coordination Features

```python
# Pause/resume agents
manager.pause_agent("researcher")   # All actions blocked until resumed
manager.resume_agent("researcher")

# Sequential execution — only one agent at a time
orth = await manager.start_orchestration("task", require_sequential=True)
await manager.evaluate("agent-1", event)       # ✅ Acquires lock
await manager.evaluate("agent-2", event)       # 🚫 Blocked — agent-1 has the lock
manager.release_sequential_lock("agent-1")      # Release
await manager.evaluate("agent-2", event)       # ✅ Now allowed

# Transfer control between agents
manager.transfer_active("agent-1", "agent-2")

# Get unified summary
summary = await manager.end_orchestration(orth.orchestration_id)
print(summary.total_actions, summary.all_chains_valid)
```

## 🔌 MCP Plugin System

Extend the MCP policy engine with custom plugins for validation, transformation, auditing, and policy decisions.

### Built-in Security Plugins

```python
from agentgate.mcp import MCPPolicyEngine, PluginRegistry, create_secure_registry

# One-line setup with all built-in security plugins
registry = create_secure_registry()

# Or build your own
registry = PluginRegistry()
registry.register(SQLInjectionValidator())     # Detects SQL injection in arguments
registry.register(SensitiveDataValidator())    # Detects credit cards, SSNs, API keys
registry.register(RateLimitByServerPlugin())   # Per-server rate limiting
registry.register(LoggingAuditPlugin())        # Structured audit logging
registry.register(ArgumentNormalizerTransform()) # Trim & normalize arguments

# Attach to engine
engine = MCPPolicyEngine(plugin_registry=registry)
```

### Write Custom Plugins

```python
from agentgate.mcp.plugin import PolicyPlugin, ValidatorPlugin, PluginDecision, PluginContext

# Custom validator — block tool calls with arguments over 10KB
class MaxArgSizeValidator(ValidatorPlugin):
    name = "max-arg-size"
    description = "Block oversized arguments"

    def validate(self, tool_call, context):
        for key, value in tool_call.arguments.items():
            if len(str(value)) > 10_000:
                return PluginDecision(block=True, reason=f"Argument '{key}' too large")
        return None  # Pass

# Custom policy plugin — enforce business rules
class BusinessHoursPlugin(PolicyPlugin):
    name = "business-hours"
    description = "Only allow tool calls during business hours"

    def pre_evaluate(self, tool_call, context):
        import datetime
        hour = datetime.datetime.now().hour
        if hour < 9 or hour > 17:
            return PluginDecision(block=True, reason="Tool calls blocked outside business hours")
        return None
```

### Plugin Pipeline

```
MCP Tool Call arrives
    ↓
1. Transform plugins     (normalize arguments, trim whitespace)
    ↓
2. Validator plugins      (SQL injection, sensitive data, size limits)
    ↓
3. Pre-evaluate plugins   (business rules, custom blocks)
    ↓
4. Policy Engine          (YAML rules, keyword/phonetic/NLP matching)
    ↓
5. Post-evaluate plugins  (override decisions, add context)
    ↓
6. Audit plugins          (logging, metrics, alerting)
    ↓
Final Decision
```

## 💓 OpenClaw Heartbeat Integration

Monitor the health of your AgentGate sidecar with continuous heartbeat pings.

```python
from agentgate.heartbeat import HeartbeatClient, HeartbeatConfig

# Configure heartbeat
hb = HeartbeatClient(
    config=HeartbeatConfig(
        interval_seconds=10,     # Ping every 10 seconds
        timeout_seconds=3,       # 3-second timeout per ping
        max_missed=3,            # 3 missed pings → UNHEALTHY
        auto_reconnect=True,     # Auto-reconnect on failure
    ),
    on_healthy=lambda e: print("✅ AgentGate is healthy"),
    on_unhealthy=lambda e: print(f"⚠️ Problem: {e.errors}"),
    on_policy_change=lambda e: print("📢 Policies changed mid-session!"),
    on_disconnect=lambda e: print("🚨 Lost connection to AgentGate!"),
    on_reconnect=lambda e: print("🔄 Reconnected!"),
)

# Start background monitoring
await hb.start()

# Check status anytime
if hb.is_healthy:
    print("All systems operational")

# Get monitoring summary
summary = await hb.stop()
print(f"Uptime: {summary.uptime_percentage}%")
print(f"Avg latency: {summary.avg_latency_ms}ms")
print(f"Policy changes: {summary.policy_changes_detected}")
```

### What Heartbeat Monitors

| Check | Description |
|---|---|
| **Sidecar health** | Is the AgentGate sidecar alive and responding? |
| **Policy version** | Have policies changed since the session started? |
| **License status** | Is the license still valid? |
| **Active sessions** | Are evidence sessions still recording? |
| **Latency** | How fast is the sidecar responding? (avg/min/max) |
| **Auto-reconnect** | Automatic recovery on connection loss |

### Risk Auto-Detection — 3-Layer Intelligent Matching

AgentGate uses a **3-layer intent detection engine** to understand what an agent is actually trying to do — even if the UI text doesn't contain obvious keywords.

#### Layer 1 — Keyword Matching
Exact synonyms and substring matching across **13 intent categories** with **200+ terms**:
- **payment**: pay, checkout, purchase, transfer, billing, invoice …
- **delete**: remove, erase, destroy, drop, purge, wipe …
- **admin**: administrator, root access, superuser, sudo …
- And 9 more categories.

#### Layer 2 — Phonetic Matching
Catches **typos and morphological variants** that keywords miss:
- "Chekout" → matches "checkout" (same phonetic code)
- "Purchasing" → matches "purchase" (prefix match)
- "Transfering" → matches "transfer"

#### Layer 3 — NLP Semantic Matching *(optional, install with `[nlp]`)*
Uses **sentence embeddings** (BAAI/bge-small-en-v1.5 ONNX model) to understand the **meaning** of any action text — even completely novel phrases:

| Agent Action Text | Detected Intent | Risk |
|---|---|---|
| "Process Transaction" | payment | 🔴 HIGH |
| "Purge All Records" | destructive_system | 🔴 CRITICAL |
| "Grant Admin Privileges" | permission | 🔴 HIGH |
| "Post a Comment" | posting | 🟡 MEDIUM |
| "Share on Twitter" | sharing | 🟡 MEDIUM |
| "Download Backup" | downloading | 🟡 MEDIUM |
| "View Dashboard" | navigation | 🟢 LOW |

**19 semantic intent categories**: payment, delete, authentication, admin, posting, messaging, sharing, modifying, downloading, uploading, financial, permission, social, system, data_entry, sensitive_field, navigation, api_call, and destructive_system.

The NLP layer runs **entirely on CPU** (~67 MB model), adds ~2ms per classification, and requires **zero API keys** or cloud calls.

#### Risk Levels
- 🔴 **CRITICAL**: destructive_system
- 🔴 **HIGH**: payment, delete, admin, authentication, financial, permission, system, api_call, sensitive_field
- 🟡 **MEDIUM**: confirm, modify, share, export, upload, messaging, posting, downloading, data_entry
- 🟢 **LOW**: navigation, view, read, scroll

#### Using the Semantic Matcher Directly

```python
from agentgate.policy.semantic_matcher import semantic_classify, semantic_risk

# Classify any action text — no hardcoded keywords needed
result = semantic_classify("Process the wire transfer")
print(result.intent)     # → "payment"
print(result.risk)       # → "high"
print(result.score)      # → 0.82
print(result.confident)  # → True (score ≥ 0.65)

# Get risk level for any text
risk = semantic_risk("Wipe the production database")
print(risk)  # → "critical"

# Add custom intents at runtime
from agentgate.policy.semantic_matcher import add_intent
add_intent(
    "compliance_review",
    "reviewing documents for regulatory compliance and audit",
    risk="medium",
)
```

## Evidence Vault

Every action is recorded in a **tamper-evident chain**:

```
Session: ses_a1b2c3d4e5f6
├── #001 ✅ NAVIGATE → https://bank.com/invoices     ALLOWED
├── #002 ✅ CLICK    → "View Invoice #1234"           ALLOWED
├── #003 🚫 CLICK   → "Pay Now"                      BLOCKED (payment action)
├── #004 ⚠️  CLICK   → "Submit Report"                APPROVAL REQUIRED
└── #005 ✅ NAVIGATE → https://bank.com/reports       ALLOWED

Chain integrity: ✅ Verified
```

Each record includes:
- Action details (type, URL, selector, element text)
- Policy decision and reason
- DOM snapshot hash
- Screenshot hash
- Cryptographic chain to previous record

### Verify Integrity

```bash
agentgate sessions verify ses_a1b2c3d4e5f6
# ✅ Chain integrity verified! All records intact.
```

### Export for Compliance

```bash
agentgate sessions export ses_a1b2c3d4e5f6 -o audit.json
```

## Capability Tokens

Grant agents **scoped, time-bound permissions**:

```python
from agentgate.tokens.capability import CapabilityToken, Scope
from agentgate.policy.engine import ActionType

token = CapabilityToken.create(
    agent_id="finance-bot",
    issuer="admin@company.com",
    purpose="Read Q4 invoices",
    scopes=[
        Scope(
            domains=["accounting.company.com"],
            exclude_text=["Pay", "Delete", "Transfer"],
            max_risk=RiskLevel.MEDIUM,
        ),
    ],
    ttl_minutes=30,  # Auto-expires in 30 minutes
    max_actions_total=100,
)

# Validate before each action
result = token.validate(action_event)
if not result.valid:
    print(f"Denied: {result.reason}")
```

Features:
- **Time-bound**: Auto-expire after TTL
- **Scoped**: Domain, URL, action, element restrictions
- **Rate-limited**: Max actions total / per minute
- **Revocable**: Instant revocation
- **Signed**: HMAC integrity verification

## Dashboard

```bash
agentgate dashboard
# 🛡️ AgentGate Dashboard running at http://127.0.0.1:7860
```

The dashboard provides:
- 📊 Real-time statistics (sessions, actions, blocks)
- 📋 Session list with evidence summaries
- ▶️ Session replay viewer
- 🔐 Chain integrity verification
- 📜 Policy browser

## CLI Reference

```bash
agentgate init                    # Initialize project
agentgate policies list           # List policies
agentgate policies show <name>    # Show policy details
agentgate sessions list           # List sessions
agentgate sessions replay <id>    # Replay session
agentgate sessions verify <id>    # Verify chain integrity
agentgate sessions export <id>    # Export evidence
agentgate dashboard               # Launch web dashboard
agentgate version                 # Show version

# MCP Commands
agentgate mcp serve               # Start AgentGate as MCP server (stdio)
agentgate mcp serve --transport streamable-http  # HTTP MCP server
agentgate mcp proxy --config servers.yaml        # Start MCP proxy gateway
agentgate mcp policies            # List MCP policy presets
agentgate mcp check <server> <tool>              # Check if tool call is allowed
```

## Use Cases

| Scenario | What the agent can do | What AgentGate blocks | Suggested policy |
|---|---|---|---|
| **Finance** | Read invoices, view balances | Pay, Transfer, Delete | `finance-safe` |
| **Procurement** | Compare vendors, read quotes | Place orders, sign contracts | `procurement-safe` |
| **Customer Support** | View accounts, read tickets | Change passwords, modify billing | `support-agent` |
| **HR / Admin** | Read profiles, view org chart | Modify payroll, change permissions | Custom policy |
| **QA / Testing** | Run test flows end-to-end | Nothing — full evidence trail | `readonly` + evidence |
| **Research** | Browse, read, extract data | Submit forms, click ads | `readonly` |

## 🧪 Integrate with Any AI Agent

No matter what framework you use, the integration pattern is the same:

1. Start the AgentGate sidecar: `agentgate sidecar --policy finance-safe`
2. Before every agent action, call the sidecar to check if it's allowed
3. If allowed → do it. If blocked → tell the agent "no".

```
┌─────────────────────┐
│   Your AI Agent     │   (OpenAI, Claude, LangChain, CrewAI, etc.)
│   decides to act    │
└────────┬────────────┘
         │ "I want to click Pay Now"
         ▼
┌─────────────────────┐
│   AgentGate Check   │   POST /api/v1/evaluate (~1ms)
└────────┬────────────┘
    ┌────┴────┐
  allowed?  blocked?
    │         │
    ▼         ▼
  ✅ Do it   🚫 Tell agent "no"
```

### Python SDK (any Python agent)

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="my-agent")

# Check before each action
result = gate.check_click("https://bank.com", "Pay Now")
if result.allowed:
    await page.click("#pay-now")
else:
    print(f"🚫 Blocked: {result.reason}")
```

### Direct Playwright wrapper (no sidecar needed)

```python
from agentgate import SecureBrowser

async with SecureBrowser(policy="finance-safe") as browser:
    page = await browser.new_page()
    await page.goto("https://bank.com")     # ✅ Policy-checked
    await page.click("#pay-now")             # 🚫 Blocked by policy
```

### REST API (any language)

```bash
curl -X POST http://localhost:18790/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{"action_type":"click","url":"https://bank.com","element_text":"Pay Now"}'
# → {"allowed":false,"decision":"block","reason":"Element blocked: ['Pay']"}
```

### Framework-specific examples

<details>
<summary><strong>OpenAI (GPT-4, CUA, Assistants)</strong></summary>

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="my-openai-agent")

# In your OpenAI agent's action handler:
result = gate.check_click("https://bank.com", "Pay Now")
if result.allowed:
    await page.click("#pay-now")
else:
    # Tell the agent it can't do this
    return f"Action blocked: {result.reason}"
```
</details>

<details>
<summary><strong>Anthropic Claude (Computer Use)</strong></summary>

```python
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="claude-computer-use")

def handle_tool_use(tool_name, tool_input):
    if tool_name == "computer":
        action = tool_input.get("action")
        if action == "click":
            result = gate.check_click(current_url, element_text_at_coords)
            if not result.allowed:
                return f"Action blocked: {result.reason}"
        elif action == "type":
            result = gate.check_type(current_url, selector, tool_input["text"])
            if not result.allowed:
                return f"Action blocked: {result.reason}"
    return execute_computer_action(tool_name, tool_input)
```
</details>

<details>
<summary><strong>Google ADK</strong></summary>

```python
import requests

def is_allowed(action_type: str, url: str, element_text: str = "") -> bool:
    response = requests.post("http://localhost:18790/api/v1/evaluate", json={
        "action_type": action_type,
        "url": url,
        "element_text": element_text,
        "agent_id": "google-adk-agent",
    })
    return response.json()["allowed"]

def browse_and_click(url: str, button_text: str):
    if not is_allowed("navigate", url):
        return "Navigation blocked by security policy"
    if not is_allowed("click", url, button_text):
        return f"Click on '{button_text}' blocked by security policy"
    return perform_browser_action(url, button_text)
```
</details>

<details>
<summary><strong>LangChain / LangGraph</strong></summary>

```python
from langchain.tools import tool
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="langchain-agent")

@tool
def safe_click(url: str, button_text: str) -> str:
    """Click a button on a webpage, enforced by AgentGate."""
    result = gate.check_click(url, button_text)
    if not result.allowed:
        return f"🚫 Blocked: {result.reason}"
    # ... do the actual click ...
    return f"✅ Clicked '{button_text}'"

@tool
def safe_navigate(url: str) -> str:
    """Navigate to a URL, enforced by AgentGate."""
    result = gate.check_navigate(url)
    if not result.allowed:
        return f"🚫 Blocked: {result.reason}"
    return f"✅ Navigated to {url}"
```
</details>

<details>
<summary><strong>CrewAI</strong></summary>

```python
from crewai import Agent, Task, Crew
from agentgate import AgentGateClient

gate = AgentGateClient(port=18790, agent_id="crewai-researcher")

class GuardedBrowserTool:
    name = "guarded_browser"
    description = "Browse the web with AgentGate security enforcement"

    def _run(self, url: str, action: str = "navigate", text: str = ""):
        if action == "navigate":
            result = gate.check_navigate(url)
        elif action == "click":
            result = gate.check_click(url, text)
        else:
            result = gate.evaluate(action, url=url, element_text=text)
        if not result.allowed:
            return f"🚫 Blocked by policy: {result.reason}"
        return f"✅ Action allowed, proceeding..."
```
</details>

<details>
<summary><strong>JavaScript / TypeScript</strong></summary>

```javascript
const response = await fetch('http://localhost:18790/api/v1/evaluate', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    action_type: 'click',
    url: 'https://bank.com',
    element_text: 'Pay Now',
    agent_id: 'my-js-agent'
  })
});
const { allowed, reason } = await response.json();
if (!allowed) console.log(`Blocked: ${reason}`);
```
</details>

<details>
<summary><strong>Go</strong></summary>

```go
payload := map[string]string{
    "action_type":  "click",
    "url":          "https://bank.com",
    "element_text": "Pay Now",
    "agent_id":     "my-go-agent",
}
body, _ := json.Marshal(payload)
resp, _ := http.Post("http://localhost:18790/api/v1/evaluate", "application/json", bytes.NewReader(body))
```
</details>

<details>
<summary><strong>OpenClaw</strong></summary>

```bash
# 1. Install AgentGate
pip install ai-agents-warden

# 2. Start the sidecar
agentgate sidecar --policy finance-safe --port 18790

# 3. Copy the skill to your OpenClaw workspace
cp -r skills/agentgate ~/.openclaw/workspace/skills/
```

OpenClaw reads the `SKILL.md` and automatically calls AgentGate before every browser action. Includes two policy presets:
- `openclaw-default.yaml` — blocks payments, deletes; requires approval for submissions
- `openclaw-strict.yaml` — blocks everything except reading

</details>

### Test without any agent (pure policy testing)

```python
from agentgate.policy.engine import (
    PolicyEngine, ActionEvent, ActionType,
    create_finance_safe_policy,
)

engine = PolicyEngine()
engine.load_policy(create_finance_safe_policy())

event = ActionEvent(
    action_type=ActionType.CLICK,
    url="https://bank.com",
    element_text="Pay Now",
)
result = engine.evaluate(event)
print(f"Decision: {result.decision.value}")  # → "block"
print(f"Reason: {result.reason}")
```

## 🦞 OpenClaw Integration

AgentGate includes a ready-to-use [OpenClaw](https://github.com/openclaw/openclaw) skill. Setup takes under 5 minutes:

```bash
pip install ai-agents-warden
agentgate sidecar --policy finance-safe --port 18790
cp -r skills/agentgate ~/.openclaw/workspace/skills/
```

```
┌──────────────────┐     ┌──────────────────────┐     ┌─────────────┐
│    OpenClaw       │────▶│   AgentGate Sidecar   │────▶│   Browser   │
│ (your AI agent)   │◀────│   localhost:18790     │◀────│  (Playwright)│
└──────────────────┘     └──────────────────────┘     └─────────────┘
```

The `skills/agentgate/` directory contains:
- `SKILL.md` — Instructions for OpenClaw to understand AgentGate
- `policies/openclaw-default.yaml` — Balanced security policy
- `policies/openclaw-strict.yaml` — Maximum safety for high-risk tasks

For code examples and Python SDK usage, see the [integration section above](#-integrate-with-any-ai-agent).

## Sidecar API Reference

All endpoints are available at `http://localhost:18790` (default port).

| Endpoint | Method | Description |
|---|---|---|
| `/api/v1/evaluate` | POST | Check if an action is allowed |
| `/api/v1/evaluate/batch` | POST | Check multiple actions (preflight) |
| `/api/v1/record` | POST | Manually record an action in the evidence vault |
| `/api/v1/sessions` | POST | Start an evidence session |
| `/api/v1/sessions` | GET | List sessions |
| `/api/v1/sessions/{id}` | GET | Get session details |
| `/api/v1/sessions/{id}/end` | POST | End a session and save evidence |
| `/api/v1/sessions/{id}/records` | GET | Get all evidence records for a session |
| `/api/v1/sessions/{id}/verify` | GET | Verify evidence chain integrity |
| `/api/v1/tokens` | POST | Issue a capability token |
| `/api/v1/tokens` | GET | List active tokens |
| `/api/v1/tokens/validate` | POST | Validate a token against an action |
| `/api/v1/tokens/{id}/revoke` | POST | Revoke a token |
| `/api/v1/policies` | GET | List loaded policies |
| `/api/v1/policies/load` | POST | Load a policy from YAML |
| `/api/v1/health` | GET | Health check |
| `/api/v1/license/status` | GET | Check license tier and status |
| `/api/v1/license/activate` | POST | Activate a license key |

## Project Structure

```
agentgate/
├── __init__.py              # Public API
├── cli.py                   # CLI commands (incl. sidecar + MCP)
├── runner.py                # SecureBrowser & AgentGateRunner
├── policy/
│   ├── engine.py            # Policy engine, rules, risk classification
│   ├── intent_matcher.py    # Keyword + phonetic intent matching
│   └── semantic_matcher.py  # NLP sentence-embedding classifier
├── interceptor/
│   └── browser.py           # Playwright action interceptor
├── evidence/
│   └── vault.py             # Tamper-evident evidence vault
├── tokens/
│   └── capability.py        # Capability tokens & token store
├── sidecar/
│   ├── service.py           # FastAPI sidecar service (OpenClaw proxy)
│   └── client.py            # Python SDK (sync + async clients)
├── mcp/
│   ├── __init__.py          # MCP module public API
│   ├── types.py             # MCP data models (MCPToolCall, MCPPolicy, etc.)
│   ├── policy_engine.py     # MCP policy engine + preset policies
│   ├── plugin.py            # Extensible plugin system (validators, transforms, audit)
│   ├── server.py            # AgentGate as MCP server (FastMCP)
│   └── proxy.py             # MCP proxy gateway for downstream servers
├── sessions.py              # Multi-agent session manager
├── heartbeat.py             # OpenClaw heartbeat client & server endpoint
└── dashboard/
    └── app.py               # FastAPI dashboard with embedded UI

skills/
└── agentgate/               # Ready-to-use OpenClaw skill
    ├── SKILL.md             # Skill instructions for OpenClaw
    └── policies/            # OpenClaw-specific YAML policies
```

## Roadmap

### Phase 1 (Current) — Core Engine
- [x] Policy engine with YAML rules
- [x] Action interceptor (Playwright)
- [x] Tamper-evident evidence vault
- [x] Capability tokens
- [x] CLI tools
- [x] Web dashboard
- [x] Built-in policy presets
- [x] **Sidecar HTTP proxy for OpenClaw**
- [x] **Python SDK (sync + async)**
- [x] **OpenClaw skill package**
- [x] **Batch action evaluation**
- [x] **Smart intent matching** — 13 categories, 200+ keyword synonyms
- [x] **Phonetic matching** — catches typos & morphological variants
- [x] **🧠 NLP semantic matching** — sentence embeddings (BAAI/bge-small-en-v1.5), 19 intent categories, runs on CPU, zero API keys
- [x] **3-layer risk detection** — keywords → phonetic → NLP semantic
- [x] **Custom intent support** — add/remove intents at runtime

### Phase 2 — Enterprise Features
- [ ] Approval workflows (Slack, email, webhook)
- [x] **🤖 Multi-agent session management** — role-based agent governance, orchestration lifecycle, cross-agent rate limits, sequential execution
- [x] **💓 OpenClaw heartbeat integration** — async health monitoring, policy change detection, auto-reconnect, latency tracking
- [x] **🔌 MCP extensible plugin system** — transform, validate, audit, policy plugins with built-in security guards
- [x] **🔌 MCP server** — expose AgentGate tools via Model Context Protocol
- [x] **🔌 MCP proxy gateway** — guard downstream MCP servers (Stripe, GitHub, etc.)
- [x] **🔌 MCP policy presets** — mcp-default, mcp-readonly, mcp-finance-safe, mcp-devops-safe
- [x] **🔌 MCP CLI** — serve, proxy, check, policies commands
- [ ] SIEM/SOAR export (Splunk, Datadog, Sentinel)
- [ ] Team/org management
- [ ] SSO integration
- [ ] Fine-tuned domain-specific NLP models
- [ ] Multi-language intent detection

### Phase 3 — Platform
- [ ] ClawHub skill distribution
- [ ] Policy marketplace
- [ ] Agent registry
- [ ] Real-time monitoring WebSocket
- [ ] Threat detection ML
- [ ] Compliance report generation
- [ ] Kubernetes operator

## Why Open Source?

Infrastructure tools win by becoming the **default standard**. Just like:
- Linux → every cloud runs on it
- Kubernetes → backbone of modern infra
- Playwright → browser automation standard

AgentGate aims to become the **default execution control layer** for AI agents. Open source is how that happens.

## 📚 Documentation

| Document | Description |
|---|---|
| [User Guide](docs/GUIDE.md) | Non-technical guide — how AgentGate works in plain English |
| [Architecture](docs/ARCHITECTURE.md) | Deep-dive into every module, data flow, and design decisions |
| [Operations](docs/OPERATIONS.md) | Installation, configuration, running, updating, troubleshooting |
| [Agent Compatibility](docs/AGENTS.md) | Which agents work with AgentGate, integration guides, scaling |
| [Licensing & Monetization](docs/LICENSING.md) | Open-core model, enterprise features, IP strategy |
| [Changelog](CHANGELOG.md) | Version history and release notes |
| [Security Policy](SECURITY.md) | How to report vulnerabilities responsibly |
| [CLA](CLA.md) | Contributor License Agreement |

## Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for full guidelines.

```bash
git clone https://github.com/Nitin-100/agentgate.git
cd agentgate
pip install -e ".[dev]"
pytest
```

All contributors must sign our [CLA](CLA.md) before their first PR is merged.

## 💰 Licensing & Pricing

AgentGate uses an **open-core model** — the core engine is free and open-source forever.

| Tier | Price | Features |
|---|---|---|
| **Community** | Free forever | 2 policies, basic sidecar, rate-limited |
| **Trial** | Free for 24 hours | All features unlocked, auto-activates on first use |
| **Pro** | $49/mo | Unlimited policies, evidence vault, capability tokens, webhooks |
| **Enterprise** | $199/mo | Everything + SSO, priority support, audit log retention |

### How It Works

1. **Install:** `pip install ai-agents-warden`
2. **Auto-trial:** First run activates a 24-hour trial with ALL features
3. **Continue free:** After trial, falls back to Community tier (still functional)
4. **Upgrade:** Purchase a license key at [agentgate.dev/pricing](https://agentgate.dev/pricing)
5. **Activate:** `agentgate license activate YOUR-KEY`

### License CLI

```bash
agentgate license status          # Check your current tier & remaining time
agentgate license activate KEY    # Activate a Pro or Enterprise key
agentgate license deactivate      # Revert to Community tier
```

### Anti-Tamper Protection

AgentGate's licensing includes enterprise-grade tamper protection:
- 🔒 **Clock rollback detection** — NTP verification + monotonic elapsed tracking
- 🔒 **File integrity seal** — HMAC-SHA256 on every field in the license file
- 🔒 **Deletion protection** — Redundant breadcrumb survives file deletion
- 🔒 **Machine binding** — License is bound to hardware fingerprint
- 🔒 **Key signing** — PBKDF2-derived keys, not stored in plaintext

## License

Apache 2.0 — See [LICENSE](LICENSE) and [NOTICE](NOTICE)

---

<p align="center">
  <strong>🛡️ AgentGate — Guardrails & policy enforcement for AI agents. Control what agents do. Prove what they did.</strong>
</p>
