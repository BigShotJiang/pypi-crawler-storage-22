"""
AgentGate — The open-source execution firewall for AI agents.

Control what agents can do. Prove what they did.

Modules:
    - policy: Define and enforce action-level policies
    - interceptor: Intercept browser/UI actions in real-time
    - evidence: Tamper-evident audit trail and session replay
    - tokens: Capability-based permission tokens for agents
    - runner: Secure browser runner with policy enforcement
    - sidecar: HTTP proxy service for OpenClaw and other frameworks
    - mcp: Model Context Protocol server and proxy integration
    - sessions: Multi-agent session management
    - heartbeat: OpenClaw heartbeat integration
    - cli: Command-line interface
    - dashboard: Web UI for policies, replay, and management
"""

__version__ = "1.0.0"
__all__ = [
    "SecureBrowser",
    "Policy",
    "PolicyEngine",
    "EvidenceVault",
    "CapabilityToken",
    "AgentGateRunner",
    "AgentGateClient",
    "AsyncAgentGateClient",
    # MCP exports
    "MCPToolCall",
    "MCPToolCallDecision",
    "MCPPolicyEngine",
    "create_agentgate_mcp_server",
    "MCPProxyServer",
    # Plugin system
    "PluginRegistry",
    "PolicyPlugin",
    # Multi-agent sessions
    "MultiAgentSessionManager",
    "AgentRole",
    # Heartbeat
    "HeartbeatClient",
    "HeartbeatConfig",
]

from agentgate.runner import SecureBrowser
from agentgate.policy.engine import Policy, PolicyEngine
from agentgate.evidence.vault import EvidenceVault
from agentgate.tokens.capability import CapabilityToken
from agentgate.runner import AgentGateRunner
from agentgate.sidecar.client import AgentGateClient, AsyncAgentGateClient

# Multi-agent sessions
from agentgate.sessions import MultiAgentSessionManager, AgentRole

# Heartbeat
from agentgate.heartbeat import HeartbeatClient, HeartbeatConfig

# MCP imports (lazy — only available when mcp extra is installed)
try:
    from agentgate.mcp.types import MCPToolCall, MCPToolCallDecision
    from agentgate.mcp.policy_engine import MCPPolicyEngine
    from agentgate.mcp.server import create_agentgate_mcp_server
    from agentgate.mcp.proxy import MCPProxyServer
    from agentgate.mcp.plugin import PluginRegistry, PolicyPlugin
except ImportError:
    pass
