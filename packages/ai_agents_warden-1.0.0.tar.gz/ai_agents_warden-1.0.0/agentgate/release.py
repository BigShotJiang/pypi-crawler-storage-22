"""
AgentGate Release Scripts — Build, package, and publish.

Usage:
    python -m agentgate.release build      Build the wheel + sdist
    python -m agentgate.release publish     Publish to PyPI
    python -m agentgate.release docker      Build Docker image
    python -m agentgate.release gen-key     Generate a license key
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).parent.parent


def build():
    """Build the Python package (wheel + sdist)."""
    print("📦 Building AgentGate package...")
    subprocess.run([sys.executable, "-m", "build", str(ROOT)], check=True)
    print("✅ Build complete — see dist/")


def publish_pypi(test: bool = False):
    """Publish to PyPI (or Test PyPI)."""
    repo = "testpypi" if test else "pypi"
    url = "https://test.pypi.org/legacy/" if test else "https://upload.pypi.org/legacy/"
    print(f"🚀 Publishing to {repo}...")
    cmd = [
        sys.executable, "-m", "twine", "upload",
        "--repository-url", url,
        str(ROOT / "dist" / "*"),
    ]
    subprocess.run(cmd, check=True)
    print(f"✅ Published to {repo}!")


def build_docker():
    """Build the Docker image."""
    from agentgate import __version__
    print("\U0001f433 Building Docker image...")
    subprocess.run([
        "docker", "build",
        "-t", "agentgate:latest",
        "-t", f"agentgate:{__version__}",
        str(ROOT),
    ], check=True)
    print("✅ Docker image built: agentgate:latest")


def generate_key(tier: str, email: str, org: str = "", days: int = 365):
    """Generate a license key."""
    from agentgate.licensing.license_manager import LicenseTier, generate_license_key
    t = LicenseTier(tier)
    key = generate_license_key(t, email, org, days)
    print(f"License key for {tier.upper()} ({email}):")
    print(key)
    return key


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="AgentGate Release Tools")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("build", help="Build package")
    sub.add_parser("publish", help="Publish to PyPI")
    sub.add_parser("publish-test", help="Publish to Test PyPI")
    sub.add_parser("docker", help="Build Docker image")

    gen = sub.add_parser("gen-key", help="Generate license key")
    gen.add_argument("--tier", choices=["pro", "enterprise"], required=True)
    gen.add_argument("--email", required=True)
    gen.add_argument("--org", default="")
    gen.add_argument("--days", type=int, default=365)

    args = parser.parse_args()

    if args.command == "build":
        build()
    elif args.command == "publish":
        publish_pypi(test=False)
    elif args.command == "publish-test":
        publish_pypi(test=True)
    elif args.command == "docker":
        build_docker()
    elif args.command == "gen-key":
        generate_key(args.tier, args.email, args.org, args.days)
    else:
        parser.print_help()
