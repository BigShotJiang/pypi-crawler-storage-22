"""
AgentGate Sidecar Service — REST API for agent action governance.

This is the core sidecar that sits between any agent framework and the
browser/tools. External agents call these endpoints before taking actions:

    POST /api/v1/evaluate     — Check if an action is allowed
    POST /api/v1/record       — Record an action + decision in the vault
    POST /api/v1/tokens       — Issue a capability token
    POST /api/v1/tokens/validate — Validate a token against an action
    GET  /api/v1/sessions     — List evidence sessions
    GET  /api/v1/health       — Health check

OpenClaw integration:
    OpenClaw calls /api/v1/evaluate before every browser action.
    If the decision is ALLOW, OpenClaw proceeds. If BLOCK, it stops.
    Every action is recorded in the Evidence Vault automatically.
"""

from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from agentgate.policy.engine import (
    ActionEvent,
    ActionType,
    Decision,
    Policy,
    PolicyDecision,
    PolicyEngine,
    RiskLevel,
    classify_risk,
    create_finance_safe_policy,
    create_readonly_policy,
    create_permissive_policy,
)
from agentgate.evidence.vault import EvidenceVault, EvidenceSession
from agentgate.tokens.capability import CapabilityToken, Scope, TokenStore
from agentgate import __version__ as _agentgate_version


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class EvaluateRequest(BaseModel):
    """Request to evaluate whether an agent action should be allowed."""
    action_type: str  # navigate, click, type, etc.
    url: str = ""
    selector: str = ""
    element_text: str = ""
    element_tag: str = ""
    element_type: str = ""
    element_id: str = ""
    element_classes: list[str] = Field(default_factory=list)
    value: str = ""
    agent_id: str = ""
    session_id: str = ""
    token_id: str | None = None  # Optional capability token to validate
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvaluateResponse(BaseModel):
    """Response from the policy evaluation."""
    allowed: bool
    decision: str  # allow, block, require_approval, log_only
    risk_level: str
    reason: str
    policy_name: str = ""
    matched_rule: str = ""
    action_fingerprint: str = ""
    record_id: str = ""  # Evidence record ID (auto-recorded)
    timestamp: float = Field(default_factory=time.time)


class RecordRequest(BaseModel):
    """Request to manually record an action (for actions not going through /evaluate)."""
    action_type: str
    url: str = ""
    selector: str = ""
    element_text: str = ""
    value: str = ""
    agent_id: str = ""
    session_id: str = ""
    decision: str = "allow"
    reason: str = "manually recorded"
    screenshot_b64: str | None = None


class TokenIssueRequest(BaseModel):
    """Request to issue a new capability token."""
    agent_id: str
    issuer: str = "sidecar"
    purpose: str = ""
    ttl_minutes: int = 60
    max_actions_total: int | None = None
    domains: list[str] = Field(default_factory=list)
    url_patterns: list[str] = Field(default_factory=list)
    exclude_text: list[str] = Field(default_factory=list)
    max_risk: str = "high"


class TokenIssueResponse(BaseModel):
    """Response after issuing a capability token."""
    token_id: str
    agent_id: str
    expires_at: float
    remaining_ttl: float
    max_actions_total: int | None = None
    scopes: list[dict[str, Any]] = Field(default_factory=list)


class TokenValidateRequest(BaseModel):
    """Request to validate a token against a specific action."""
    token_id: str
    action_type: str
    url: str = ""
    element_text: str = ""
    agent_id: str = ""


class TokenValidateResponse(BaseModel):
    """Response from token validation."""
    valid: bool
    reason: str
    remaining_actions: int | None = None
    remaining_ttl: float | None = None


class SessionStartRequest(BaseModel):
    """Request to start a new evidence session."""
    agent_id: str = "default-agent"
    purpose: str = ""
    session_id: str | None = None


class SessionInfo(BaseModel):
    """Info about an evidence session."""
    session_id: str
    agent_id: str
    start_time: float
    record_count: int
    is_active: bool


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = "ok"
    version: str = _agentgate_version
    uptime_seconds: float = 0
    active_sessions: int = 0
    policies_loaded: int = 0
    tokens_active: int = 0


# ---------------------------------------------------------------------------
# Preset policy registry (same as runner.py)
# ---------------------------------------------------------------------------

PRESET_POLICIES = {
    "finance-safe": create_finance_safe_policy,
    "readonly": create_readonly_policy,
    "permissive": create_permissive_policy,
}


# ---------------------------------------------------------------------------
# Sidecar App factory
# ---------------------------------------------------------------------------

def create_sidecar(
    policy: str | Policy | None = None,
    policy_dir: str | Path | None = None,
    evidence_dir: str | Path = "./agentgate_evidence",
    default_agent_id: str = "openclaw",
) -> FastAPI:
    """
    Create the AgentGate sidecar FastAPI application.

    This is the main integration point for external agent frameworks
    like OpenClaw. The sidecar exposes a REST API that agents call
    before executing browser/tool actions.
    """

    app = FastAPI(
        title="AgentGate Sidecar",
        description="Action-level governance proxy for AI agents. Designed for OpenClaw and other agent frameworks.",
        version=_agentgate_version,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # --- State ---
    engine = PolicyEngine()
    vault = EvidenceVault(evidence_dir)
    token_store = TokenStore()
    sessions: dict[str, EvidenceSession] = {}
    start_time = time.time()

    # --- Load policies ---
    if isinstance(policy, Policy):
        engine.load_policy(policy)
    elif isinstance(policy, str):
        if policy in PRESET_POLICIES:
            engine.load_policy(PRESET_POLICIES[policy]())
        else:
            # Try loading from YAML file path first, then as YAML string
            try:
                engine.load_policy(Policy.from_yaml(policy))
            except Exception:
                engine.load_policy(Policy.from_yaml_string(policy))

    if policy_dir:
        policy_path = Path(policy_dir)
        if policy_path.is_dir():
            engine.load_policies_from_dir(policy_path)

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    @app.get("/api/v1/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        return HealthResponse(
            status="ok",
            version=_agentgate_version,
            uptime_seconds=round(time.time() - start_time, 1),
            active_sessions=len([s for s in sessions.values() if not s._ended]),
            policies_loaded=len(engine._policies),
            tokens_active=token_store.active_count,
        )

    # ------------------------------------------------------------------
    # Evaluate — the core endpoint
    # ------------------------------------------------------------------

    @app.post("/api/v1/evaluate", response_model=EvaluateResponse)
    async def evaluate(req: EvaluateRequest) -> EvaluateResponse:
        """
        Evaluate whether an agent action should be allowed.

        This is the main endpoint. Call this BEFORE executing any browser
        action. If the response says allowed=true, proceed. If allowed=false,
        do NOT execute the action.

        The action is automatically recorded in the Evidence Vault.
        """

        # Build ActionEvent from request
        try:
            action_type = ActionType(req.action_type)
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown action_type: '{req.action_type}'. "
                       f"Valid types: {[a.value for a in ActionType]}",
            )

        event = ActionEvent(
            action_type=action_type,
            url=req.url,
            selector=req.selector,
            element_text=req.element_text,
            element_tag=req.element_tag,
            element_type=req.element_type,
            element_id=req.element_id,
            element_classes=req.element_classes,
            value=req.value,
            agent_id=req.agent_id or default_agent_id,
            session_id=req.session_id,
            metadata=req.metadata,
        )

        # Evaluate against policies
        decision = engine.evaluate(event)

        # Optional: also validate against a capability token
        if req.token_id:
            token = token_store.get(req.token_id)
            if token is None:
                decision = PolicyDecision(
                    decision=Decision.BLOCK,
                    risk_level=classify_risk(event),
                    reason=f"Token '{req.token_id}' not found or expired",
                    policy_name="capability-token",
                )
            else:
                token_result = token.validate(event)
                if not token_result.valid:
                    decision = PolicyDecision(
                        decision=Decision.BLOCK,
                        risk_level=classify_risk(event),
                        reason=f"Token rejected: {token_result.reason}",
                        policy_name="capability-token",
                    )
                elif decision.decision == Decision.ALLOW:
                    # Token is valid and policy allows — consume a use
                    token.use()

        # Auto-record in evidence vault
        record_id = ""
        sid = req.session_id or req.agent_id or default_agent_id
        if sid not in sessions:
            session = await vault.start_session(agent_id=req.agent_id or default_agent_id)
            sessions[session.session_id] = session
            sid = session.session_id

        session = sessions.get(sid)
        if session and not session._ended:
            record = await session.record(event=event, decision=decision)
            record_id = record.record_id

        is_allowed = decision.decision in (Decision.ALLOW, Decision.LOG_ONLY)

        return EvaluateResponse(
            allowed=is_allowed,
            decision=decision.decision.value,
            risk_level=decision.risk_level.value if isinstance(decision.risk_level, RiskLevel) else str(decision.risk_level),
            reason=decision.reason,
            policy_name=decision.policy_name,
            matched_rule=decision.matched_rule,
            action_fingerprint=event.fingerprint,
            record_id=record_id,
        )

    # ------------------------------------------------------------------
    # Record — manual recording
    # ------------------------------------------------------------------

    @app.post("/api/v1/record")
    async def record_action(req: RecordRequest) -> dict[str, Any]:
        """Manually record an action in the Evidence Vault."""

        try:
            action_type = ActionType(req.action_type)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Unknown action_type: {req.action_type}")

        event = ActionEvent(
            action_type=action_type,
            url=req.url,
            selector=req.selector,
            element_text=req.element_text,
            value=req.value,
            agent_id=req.agent_id or default_agent_id,
            session_id=req.session_id,
        )

        try:
            decision_enum = Decision(req.decision)
        except ValueError:
            decision_enum = Decision.ALLOW

        decision = PolicyDecision(
            decision=decision_enum,
            risk_level=classify_risk(event),
            reason=req.reason,
        )

        sid = req.session_id or req.agent_id or default_agent_id
        if sid not in sessions:
            session = await vault.start_session(agent_id=req.agent_id or default_agent_id)
            sessions[session.session_id] = session
            sid = session.session_id

        session = sessions.get(sid)
        if session and not session._ended:
            record = await session.record(event=event, decision=decision)
            return {"status": "recorded", "record_id": record.record_id}

        return {"status": "no_active_session"}

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    @app.post("/api/v1/sessions", response_model=SessionInfo)
    async def start_session(req: SessionStartRequest) -> SessionInfo:
        """Start a new evidence session."""
        session = await vault.start_session(
            agent_id=req.agent_id,
            session_id=req.session_id,
        )
        sessions[session.session_id] = session
        return SessionInfo(
            session_id=session.session_id,
            agent_id=session.agent_id,
            start_time=session.start_time,
            record_count=0,
            is_active=True,
        )

    @app.get("/api/v1/sessions")
    async def list_sessions() -> list[dict[str, Any]]:
        """List all evidence sessions."""
        result = []
        for sid, session in sessions.items():
            result.append({
                "session_id": sid,
                "agent_id": session.agent_id,
                "start_time": session.start_time,
                "record_count": len(session._records),
                "is_active": not session._ended,
            })
        return result

    @app.get("/api/v1/sessions/{session_id}")
    async def get_session(session_id: str) -> dict[str, Any]:
        """Get session details with summary."""
        session = sessions.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        return {
            "session_id": session.session_id,
            "agent_id": session.agent_id,
            "start_time": session.start_time,
            "record_count": len(session._records),
            "is_active": not session._ended,
            "chain_valid": session._verify_chain(),
        }

    @app.post("/api/v1/sessions/{session_id}/end")
    async def end_session(session_id: str) -> dict[str, Any]:
        """End a session and save evidence to disk."""
        session = sessions.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        summary = await session.end()
        return {"status": "ended", "summary": summary.model_dump()}

    @app.get("/api/v1/sessions/{session_id}/records")
    async def get_session_records(session_id: str) -> list[dict[str, Any]]:
        """Get all evidence records for a session."""
        session = sessions.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        return [r.model_dump() for r in session._records]

    @app.get("/api/v1/sessions/{session_id}/verify")
    async def verify_session(session_id: str) -> dict[str, Any]:
        """Verify the integrity chain of a session."""
        session = sessions.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        is_valid = session._verify_chain()
        return {
            "session_id": session_id,
            "chain_valid": is_valid,
            "record_count": len(session._records),
        }

    # ------------------------------------------------------------------
    # Tokens
    # ------------------------------------------------------------------

    @app.post("/api/v1/tokens", response_model=TokenIssueResponse)
    async def issue_token(req: TokenIssueRequest) -> TokenIssueResponse:
        """Issue a new capability token for an agent."""
        try:
            max_risk = RiskLevel(req.max_risk)
        except ValueError:
            max_risk = RiskLevel.HIGH

        scopes = []
        if req.domains or req.url_patterns or req.exclude_text:
            scopes.append(Scope(
                domains=req.domains,
                url_patterns=req.url_patterns,
                exclude_text=req.exclude_text,
                max_risk=max_risk,
            ))

        token = CapabilityToken.create(
            agent_id=req.agent_id,
            issuer=req.issuer,
            purpose=req.purpose,
            scopes=scopes if scopes else None,
            ttl_minutes=req.ttl_minutes,
            max_actions_total=req.max_actions_total or 0,
        )
        token_store.store(token)

        return TokenIssueResponse(
            token_id=token.token_id,
            agent_id=token.agent_id,
            expires_at=token.valid_until,
            remaining_ttl=token.remaining_ttl,
            max_actions_total=token.max_actions_total,
            scopes=[s.model_dump() if hasattr(s, "model_dump") else {} for s in (token.scopes or [])],
        )

    @app.post("/api/v1/tokens/validate", response_model=TokenValidateResponse)
    async def validate_token(req: TokenValidateRequest) -> TokenValidateResponse:
        """Validate a capability token against a specific action."""
        token = token_store.get(req.token_id)
        if token is None:
            return TokenValidateResponse(
                valid=False,
                reason="Token not found or expired",
            )

        try:
            action_type = ActionType(req.action_type)
        except ValueError:
            return TokenValidateResponse(valid=False, reason=f"Unknown action_type: {req.action_type}")

        event = ActionEvent(
            action_type=action_type,
            url=req.url,
            element_text=req.element_text,
            agent_id=req.agent_id,
        )

        result = token.validate(event)
        return TokenValidateResponse(
            valid=result.valid,
            reason=result.reason,
            remaining_actions=(token.max_actions_total - token.actions_used) if token.max_actions_total else None,
            remaining_ttl=token.remaining_ttl,
        )

    @app.post("/api/v1/tokens/{token_id}/revoke")
    async def revoke_token(token_id: str, by: str = "sidecar", reason: str = "") -> dict[str, str]:
        """Revoke a capability token."""
        token = token_store.get(token_id)
        if not token:
            raise HTTPException(status_code=404, detail="Token not found")

        token.revoke(by=by, reason=reason)
        return {"status": "revoked", "token_id": token_id}

    @app.get("/api/v1/tokens")
    async def list_tokens() -> list[dict[str, Any]]:
        """List all active tokens."""
        return [
            {
                "token_id": t.token_id,
                "agent_id": t.agent_id,
                "purpose": t.purpose,
                "expires_at": t.valid_until,
                "remaining_ttl": t.remaining_ttl,
                "actions_used": t.actions_used,
                "max_actions_total": t.max_actions_total,
                "is_revoked": t.revoked,
            }
            for t in token_store._tokens.values()
        ]

    # ------------------------------------------------------------------
    # Policies
    # ------------------------------------------------------------------

    @app.get("/api/v1/policies")
    async def list_policies() -> list[dict[str, Any]]:
        """List loaded policies."""
        return [
            {
                "name": p.name,
                "description": p.description,
                "version": p.version,
                "default_decision": p.default_decision.value,
                "rules_count": len(p.rules),
                "block_js_evaluation": p.block_js_evaluation,
                "block_all_downloads": p.block_all_downloads,
                "block_all_uploads": p.block_all_uploads,
            }
            for p in engine._policies
        ]

    @app.post("/api/v1/policies/load")
    async def load_policy_yaml(body: dict[str, str]) -> dict[str, str]:
        """Load a new policy from YAML string."""
        yaml_str = body.get("yaml", "")
        if not yaml_str:
            raise HTTPException(status_code=400, detail="Missing 'yaml' field")

        try:
            policy = Policy.from_yaml_string(yaml_str)
            engine.load_policy(policy)
            return {"status": "loaded", "policy_name": policy.name}
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid policy YAML: {e}")

    # ------------------------------------------------------------------
    # Batch evaluate (for preflight checks)
    # ------------------------------------------------------------------

    @app.post("/api/v1/evaluate/batch")
    async def evaluate_batch(actions: list[EvaluateRequest]) -> list[EvaluateResponse]:
        """Evaluate multiple actions at once (preflight check)."""
        results = []
        for req in actions:
            # Reuse the single evaluate logic
            try:
                action_type = ActionType(req.action_type)
            except ValueError:
                results.append(EvaluateResponse(
                    allowed=False,
                    decision="block",
                    risk_level="critical",
                    reason=f"Unknown action_type: {req.action_type}",
                ))
                continue

            event = ActionEvent(
                action_type=action_type,
                url=req.url,
                selector=req.selector,
                element_text=req.element_text,
                value=req.value,
                agent_id=req.agent_id or default_agent_id,
            )
            decision = engine.evaluate(event)
            is_allowed = decision.decision in (Decision.ALLOW, Decision.LOG_ONLY)

            results.append(EvaluateResponse(
                allowed=is_allowed,
                decision=decision.decision.value,
                risk_level=decision.risk_level.value if isinstance(decision.risk_level, RiskLevel) else str(decision.risk_level),
                reason=decision.reason,
                policy_name=decision.policy_name,
                matched_rule=decision.matched_rule,
                action_fingerprint=event.fingerprint,
            ))

        return results

    # ------------------------------------------------------------------
    # License endpoints
    # ------------------------------------------------------------------

    @app.get("/api/v1/license/status")
    async def license_status():
        """Get current license status."""
        from agentgate.licensing.license_manager import LicenseManager
        lm = LicenseManager()
        return lm.status_dict()

    @app.post("/api/v1/license/activate")
    async def license_activate(body: dict):
        """Activate a license key."""
        from agentgate.licensing.license_manager import LicenseManager
        lm = LicenseManager()
        key = body.get("key", "")
        if not key:
            raise HTTPException(400, "Missing 'key' in request body")
        try:
            info = lm.activate_license(key)
            return {
                "status": "activated",
                "tier": info.tier.value,
                "owner": info.owner_email,
                "organization": info.organization,
                "remaining": info.remaining_human,
            }
        except ValueError as e:
            raise HTTPException(400, str(e))

    # ------------------------------------------------------------------
    # Heartbeat endpoints (OpenClaw integration)
    # ------------------------------------------------------------------

    from agentgate.heartbeat import add_heartbeat_endpoint
    add_heartbeat_endpoint(app, engine, vault, token_store, start_time)

    return app
