# AgentGate — User Guide

> **For everyone** — whether you're a developer, a team lead, a solo user, or a business deploying AI agents.
> This guide explains what AgentGate does, how to set it up, and how to use it — in plain English.

---

## Table of Contents

1. [What is AgentGate?](#what-is-agentgate)
2. [Why do you need it?](#why-do-you-need-it)
3. [Setup (step by step)](#setup-step-by-step)
4. [Choose your safety level](#choose-your-safety-level)
5. [Using AgentGate day-to-day](#using-agentgate-day-to-day)
6. [The dashboard — see what your agent did](#the-dashboard)
7. [How the protection works (under the hood)](#how-the-protection-works)
8. [FAQ](#faq)
9. [Use case scenarios](#use-case-scenarios)

---

## What is AgentGate?

AgentGate is a **security guard for AI agents**.

AI assistants like OpenAI, Claude, LangChain, CrewAI, OpenClaw, and browser-use can now click buttons, fill forms, navigate websites, call APIs, and make real-world decisions. But there's a problem: **nothing stops them from clicking "Pay $5,000" or "Delete All Records."**

AgentGate sits between your AI agent and the browser (or MCP tool server). Before the agent does anything, AgentGate checks the action against your rules:

- **Allowed?** → The action proceeds normally.
- **Blocked?** → The action is stopped. The agent is told "no" and tries something else.
- **Needs approval?** → You get asked first.

Every action (allowed or blocked) is recorded in a **tamper-proof evidence trail** — like a flight recorder for your AI.

### Real-World Analogy

Imagine you hire a personal assistant to handle your mail:

| Without AgentGate | With AgentGate |
|---|---|
| You hand them your mailbox key and hope for the best | You give them access with a rule: "You can READ mail but NEVER sign or send anything" |
| No record of what they did | You get a tamper-proof log of every letter they opened |
| They have full access forever | Their access expires in 1 hour and is limited to your personal mailbox |

That's exactly what AgentGate does for your AI assistant.

---

## Why Do You Need It?

| What can go wrong | How AgentGate prevents it |
|---|---|
| Agent clicks "Pay Now" on a banking site | **Blocked** — payment actions are not allowed by policy |
| Agent calls `delete_database` via a tool | **Blocked** — destructive tool calls are policy-checked |
| Agent exports customer data | **Requires your approval** before it can proceed |
| You don't know what the agent actually did | **Evidence vault** records every action with hash-chain integrity |
| Agent has unlimited access | **Capability tokens** limit access by time, domain, and action count |
| Multiple agents step on each other | **Multi-agent sessions** coordinate them with role-based rules |

---

## Setup (Step by Step)

### What you need

- **Python 3.11 or newer** (check with `python --version`)
- **A terminal** (Command Prompt, PowerShell, Terminal, etc.)
- 2 minutes

### Step 1: Install AgentGate

Open your terminal and run:

```bash
pip install ai-agents-warden
```

That's it. AgentGate is now installed.

**Optional:** If you want smarter intent detection (understands phrases like "Process Transaction" = payment):

```bash
pip install ai-agents-warden[nlp]
```

**Optional:** If you use MCP tools (Stripe, GitHub, databases):

```bash
pip install ai-agents-warden[mcp]
```

### Step 2: Start the sidecar

The "sidecar" is AgentGate's background service. It runs on your computer and checks every action your agent wants to take.

```bash
agentgate sidecar --policy finance-safe
```

You'll see:

```
AgentGate sidecar running at http://127.0.0.1:18790
Policy loaded: finance-safe
```

**Leave this terminal open.** The sidecar needs to stay running while your agent works.

### Step 3: Connect your agent

How you connect depends on what agent you're using:

#### If you use OpenClaw

Copy the AgentGate skill to your OpenClaw workspace:

```bash
cp -r skills/agentgate ~/.openclaw/workspace/skills/
```

OpenClaw will automatically read the skill instructions and start checking every action through AgentGate.

#### If you use browser-use, Playwright, or any Python agent

Add these lines to your agent code:

```python
from agentgate.sidecar.client import AgentGateClient

gate = AgentGateClient()  # connects to the sidecar on localhost:18790

# Before your agent clicks anything:
result = gate.check_click("https://bank.com", "Pay Now")
if result.allowed:
    # proceed with the click
    ...
else:
    print(f"Blocked: {result.reason}")
```

#### If you use OpenAI, Claude, Google ADK, LangChain, CrewAI, or any other agent

The pattern is always the same:

1. Your agent decides to do something (click, navigate, type, etc.)
2. Before doing it, call AgentGate: `POST http://localhost:18790/api/v1/evaluate`
3. If `allowed: true` → do it
4. If `allowed: false` → don't do it, tell the agent it was blocked

```bash
curl -X POST http://localhost:18790/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{"action_type": "click", "url": "https://bank.com", "element_text": "Pay Now"}'
```

This works from **any programming language** — Python, JavaScript, TypeScript, Go, Rust, C#, Java — anything that can make an HTTP request.

### Step 4: You're done

Your agent is now protected. Every action is checked against your policy and recorded in the evidence vault.

---

## Choose Your Safety Level

AgentGate comes with ready-made policies. Pick one that matches your use case:

| Policy | Best for | What it does |
|---|---|---|
| **`finance-safe`** | Banking, invoices, financial tools | Blocks payments, transfers, deletes. Requires approval for form submissions. Allows reading. |
| **`readonly`** | Monitoring, research, data collection | Blocks ALL writes — no clicks, no typing, no downloads. Read-only. |
| **`permissive`** | Low-risk tasks, testing | Allows most things. Only blocks critical-risk actions (admin, JS execution). |
| **`procurement-safe`** | Vendor research, purchasing workflows | Blocks order placement. Allows browsing and comparison. |
| **`support-agent`** | Customer support, helpdesk | View accounts, find solutions. Cannot change passwords, billing, or admin settings. |

### How to switch policies

```bash
# Stop the sidecar (Ctrl+C in its terminal)
# Restart with a different policy:
agentgate sidecar --policy readonly
```

### Create your own policy

Create a file called `my-policy.yaml`:

```yaml
name: my-custom-policy
description: My own rules for what the agent can do

rules:
  - action: click
    block_elements:
      - text_contains: ["Purchase", "Buy", "Order"]
        risk: high
  - action: navigate
    block:
      - pattern: "*/checkout/*"
      - pattern: "*/admin/*"
```

Use it:

```bash
agentgate sidecar --policy my-policy.yaml
```

---

## Using AgentGate Day-to-Day

Once AgentGate is set up, **you don't need to do anything different**. Just use your AI agent normally.

### What you'll see

- Your agent browses, reads, scrolls → **everything works normally**
- Your agent tries to click "Pay Now" → **blocked**, agent tells you it can't do that
- Your agent tries to submit a form → **asks for your approval** (if policy says so)
- Your agent tries to visit `/admin/` → **blocked**, agent picks a different page

### Example conversation with your agent

> **You:** "Check my latest invoices on bank.com"
> **Agent:** *navigates to bank.com* ✔ *clicks "Invoices"* ✔ *reads invoice list* ✔
> **Agent:** "Here are your latest invoices: ..."

> **You:** "Pay invoice #1234"
> **Agent:** *tries to click "Pay Now"*
> **AgentGate:** BLOCKED — payment actions not allowed
> **Agent:** "I tried to pay invoice #1234 but my security policy prevents payment actions. Would you like to do it yourself?"

---

## The Dashboard

AgentGate includes a web dashboard where you can see everything your agent did.

### Start the dashboard

```bash
agentgate dashboard
```

Open your browser to `http://localhost:7860`.

### What you'll see

- **Session list** — every agent session with timestamps
- **Action timeline** — what the agent did, step by step
- **Blocked actions** — what was stopped and why
- **Chain integrity** — verification that nobody tampered with the records
- **Policy browser** — what rules are currently active

---

## How the Protection Works

AgentGate has 6 layers of protection. You don't need to understand all of them, but here's what they do:

### Layer 1: Policy Engine (the rules)

Simple YAML files that say what the agent can and can't do. Examples:
- "Block clicks on anything containing 'Pay', 'Transfer', or 'Delete'"
- "Block navigation to any URL with '/admin/' in it"
- "Require approval for form submissions"

### Layer 2: NLP Intent Detection (understanding meaning)

AgentGate doesn't just match keywords — it understands *what the action means*.

| Agent action | What AgentGate understands | Risk level |
|---|---|---|
| "Process Transaction" | This is a payment action | HIGH |
| "Purge All Records" | This is a destructive action | CRITICAL |
| "Chekout" (typo) | This matches "checkout" | HIGH |
| "View Dashboard" | This is just navigation | LOW |

This works through 3 layers:
1. **Keyword matching** — 200+ known dangerous words
2. **Phonetic matching** — catches typos and misspellings
3. **AI semantic matching** — understands novel phrases (optional, install with `[nlp]`)

### Layer 3: Evidence Vault (the flight recorder)

Every action is recorded with:
- What happened (clicked a button, typed text, visited a page)
- When it happened
- Whether it was allowed or blocked
- A cryptographic hash linking it to the previous record

This means **nobody can edit or delete entries** without breaking the chain.

### Layer 4: Capability Tokens (time-limited passes)

Instead of giving your agent unlimited access, you can give it a token that says:
- "You can access bank.com for the next 30 minutes"
- "You can view up to 50 pages"
- "You cannot touch anything with the word 'Pay'"

When the time is up, the token expires automatically.

### Layer 5: Multi-Agent Sessions (team coordination)

When you have multiple agents working together, each one gets a role:

| Role | What it can do | What it can't do |
|---|---|---|
| **READER** | Browse, scroll, take screenshots | Click buttons, type, submit forms |
| **WRITER** | Read + write (click, type) | Execute JavaScript |
| **ADMIN** | Everything | Nothing is blocked |
| **EXECUTOR** | Click, type, submit, navigate | Download, upload, execute JS |
| **OBSERVER** | Take screenshots, scroll | Everything else |

Plus: rate limits per agent, rate limits across all agents combined, and one-at-a-time execution mode.

### Layer 6: Health Monitoring (heartbeat)

A background process that pings AgentGate every few seconds to make sure it's still running. If it goes down:
- Your agent is automatically blocked (fail-closed — never fails open)
- You get alerted
- Auto-reconnect kicks in

---

## FAQ

### "Will it slow down my AI?"

No. Each policy check takes less than 1 millisecond. Your AI won't notice.

### "Can the AI bypass AgentGate?"

No. AgentGate wraps the browser at the lowest level. The AI never gets direct access — it can only act through AgentGate. And AgentGate is **fail-closed**: if it crashes, the AI is blocked entirely.

### "What if I don't know Python?"

You don't need Python to use AgentGate with most agents. The sidecar runs as a background service and speaks HTTP — any language can talk to it. For OpenClaw, you just copy a folder and it works.

### "Can I customize the rules?"

Yes. Policies are simple YAML text files. You can create your own or modify the built-in ones. See the [Choose your safety level](#choose-your-safety-level) section above.

### "Is my data safe?"

AgentGate runs **100% locally** on your machine. No data is ever sent to external servers. Evidence is stored on your own disk.

### "How much does it cost?"

AgentGate is **open source and free** (Apache 2.0). First install gives you a 24-hour trial of all features. After that, the free Community tier keeps working. Paid tiers are optional for teams and enterprises.

### "What about MCP tool calls?"

If your agent calls external tools via MCP (Stripe, GitHub, databases), AgentGate can sit as a proxy and policy-check every tool call. Install with `pip install ai-agents-warden[mcp]` and use `agentgate mcp proxy`.

---

## Use Case Scenarios

### Finance Team
> "Our AI reads invoices, compares quotes, and generates reports — but it can never make payments, change billing info, or export financial data."
>
> **Policy:** `finance-safe`

### Healthcare
> "Our AI reviews patient records and schedules appointments — but it can never modify medical records or share data externally."
>
> **Policy:** `readonly` + custom rules for scheduling

### Procurement
> "Our AI researches vendors and creates comparison spreadsheets — but it needs approval before placing any order."
>
> **Policy:** `procurement-safe`

### Customer Support
> "Our AI views customer accounts and finds solutions — but it can never change passwords, issue refunds, or access admin panels."
>
> **Policy:** `support-agent`

### IT Operations
> "Our AI monitors dashboards and generates alerts — but it can never click 'Delete', 'Restart', or 'Deploy'."
>
> **Policy:** Custom policy blocking destructive actions

### Education
> "Our AI helps students with research — but it can never submit assignments, make purchases, or access restricted systems."
>
> **Policy:** `readonly`

### Solo User / Personal AI
> "I use OpenClaw to check my bank balance and read emails — but I don't want it accidentally clicking 'Transfer' or 'Delete'."
>
> **Policy:** `finance-safe` (for banking) or `readonly` (maximum safety)

---

## What's Next?

| Your situation | Next step |
|---|---|
| I just installed AgentGate | Run `agentgate sidecar --policy finance-safe` and connect your agent |
| I want to see what my agent did | Run `agentgate dashboard` and open `http://localhost:7860` |
| I need a custom policy | Copy a built-in preset and edit the YAML |
| I use multiple agents | Read about Multi-Agent Sessions in the [README](../README.md) |
| I need MCP tool governance | Install `ai-agents-warden[mcp]` and use `agentgate mcp proxy` |
| I want to learn the architecture | Read [ARCHITECTURE.md](ARCHITECTURE.md) |
| I need help | Open an issue on [GitHub](https://github.com/Nitin-100/agentgate/issues) |

---

<p align="center">
  <strong>AgentGate — Your AI's safety net.</strong>
</p>
