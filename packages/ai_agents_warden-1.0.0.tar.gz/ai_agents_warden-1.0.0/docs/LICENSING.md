# Licensing & Monetization Strategy

> This document outlines AgentGate's open-source licensing model and commercial monetization strategy.

---

## License: Apache 2.0

AgentGate is licensed under the **Apache License, Version 2.0**.

### Why Apache 2.0?

| Feature | Apache 2.0 | MIT | GPL | AGPL |
|---|---|---|---|---|
| Commercial use | ✅ | ✅ | ✅ | ✅ |
| Patent grant | ✅ | ❌ | ❌ | ❌ |
| Trademark protection | ✅ | ❌ | ❌ | ❌ |
| Copyleft (forces open-source) | ❌ | ❌ | ✅ | ✅ |
| Can embed in proprietary software | ✅ | ✅ | ❌ | ❌ |
| Used by | K8s, TF, Spark | Express, React | Linux | MongoDB* |

**Apache 2.0 is ideal because:**

1. **Patent protection** — Contributors grant patent rights, protecting you from patent trolls
2. **Trademark protection** — "AgentGate" name is protected; others can't claim it
3. **Corporate-friendly** — Enterprises freely adopt Apache 2.0 (legal teams approve it fast)
4. **No copyleft** — Companies can embed AgentGate without open-sourcing their agent code
5. **Industry standard** — Kubernetes, TensorFlow, Apache Spark, Playwright all use it

---

## Monetization Model: Open-Core

The proven open-core model used by GitLab, HashiCorp, Elastic, Grafana, and others.

### What's Free (Apache 2.0 Core)

Everything in this repository is free and always will be:

- ✅ Policy Engine (all 14 action types, YAML rules, risk classification)
- ✅ Evidence Vault (hash-chained audit trails, integrity verification)
- ✅ Capability Tokens (scoped, time-bound, signed)
- ✅ Browser Interceptor (full Playwright wrapper)
- ✅ Sidecar Service (REST API, all 18 endpoints)
- ✅ Python SDK (sync + async clients)
- ✅ CLI tools (init, policies, sessions, dashboard, sidecar)
- ✅ Web Dashboard (statistics, session replay, policy browser)
- ✅ OpenClaw Skill
- ✅ All built-in policies and examples
- ✅ Community support (GitHub Issues, Discussions)

### What's Paid (AgentGate Enterprise — Future)

Enterprise features that organizations need at scale:

#### Team Plan (~$29/agent/month)
- 🔒 Team management (roles, permissions)
- 🔒 Shared policy registry
- 🔒 Centralized evidence storage (cloud)
- 🔒 Email/Slack approval workflows
- 🔒 Priority support (48h SLA)

#### Enterprise Plan (~$99/agent/month)
- 🔒 SSO / SAML / OIDC integration
- 🔒 SIEM export (Splunk, Datadog, Sentinel, QRadar)
- 🔒 Compliance reporting (SOC 2, ISO 27001, GDPR)
- 🔒 Multi-tenant agent registry
- 🔒 Advanced threat detection (ML-based anomaly detection)
- 🔒 Kubernetes operator (auto-inject sidecars)
- 🔒 Dedicated support (24h SLA, Slack channel)
- 🔒 Custom policy consulting

#### Platform Plan (Custom pricing)
- 🔒 On-premise deployment
- 🔒 Air-gapped environments
- 🔒 Custom integrations
- 🔒 Dedicated account manager
- 🔒 SLA guarantees

---

## Revenue Streams

### 1. SaaS (Primary)
Host AgentGate Cloud — managed sidecar, centralized policies, team dashboard.

### 2. Enterprise Licenses
Self-hosted enterprise edition with premium features.

### 3. Support Contracts
Priority support, implementation consulting, custom policy development.

### 4. Marketplace
Take a cut from community-contributed premium policies and integrations.

### 5. Training & Certification
"AgentGate Certified Administrator" program for enterprises adopting AI agents.

---

## Intellectual Property Protection

### What You Need (Checklist)

- [x] **Apache 2.0 License** — in `LICENSE` file
- [x] **NOTICE file** — required by Apache 2.0, includes copyright + attribution
- [x] **Copyright headers** — in source files (recommended, not required by Apache 2.0)
- [x] **CLA (Contributor License Agreement)** — ensures contributors grant IP rights to you
- [x] **DCO (Developer Certificate of Origin)** — lightweight alternative, certifies contributions are original
- [x] **SECURITY.md** — responsible vulnerability disclosure
- [x] **CHANGELOG.md** — version history for releases

### Trademark

Consider registering "AgentGate" as a trademark:
- **USPTO** (United States): ~$250-350 per class
- **EUIPO** (Europe): ~€850 for one class
- **Classes**: Class 9 (software), Class 42 (SaaS)
- Apache 2.0 already restricts trademark use, but registration provides stronger protection

### Patent Strategy

Apache 2.0 includes a patent grant from contributors. Consider filing patents on:
- Hash-chain evidence verification for AI agent actions
- Policy-as-code execution firewall for browser automation
- Capability token system for agent permission scoping

---

## Contributor License Agreement (CLA)

All external contributors must sign the CLA before their PRs are merged. This ensures:

1. **You own the IP** — Contributors grant you full rights to their contributions
2. **You can relicense** — You can offer enterprise features under a different license
3. **No patent trolling** — Contributors grant patent rights

The CLA is documented in [CLA.md](CLA.md) (individual) and will be enforced via a CLA bot on GitHub.

### How CLA Works

1. Contributor opens a PR
2. CLA bot checks if they've signed
3. If not signed → bot comments with signing instructions
4. Contributor signs electronically (one-time)
5. PR can be merged

### CLA vs DCO

| | CLA | DCO |
|---|---|---|
| IP assignment | ✅ Full rights transfer | ❌ Just certification |
| Relicensing possible | ✅ Yes | ❌ No |
| Contributor friction | Higher | Lower |
| Used by | Google, Microsoft, Meta | Linux kernel, GitLab |
| **Our recommendation** | ✅ Use CLA | Use DCO as supplement |

We use **both**: CLA for IP protection, DCO for lightweight certification.

---

## Comparable Companies

| Company | License | Revenue Model | ARR |
|---|---|---|---|
| **HashiCorp** | BSL (was MPL) | Enterprise + Cloud | $583M |
| **GitLab** | MIT (CE) + Proprietary (EE) | SaaS + Self-hosted | $580M |
| **Elastic** | SSPL (was Apache) | Cloud + Enterprise | $1.2B |
| **Grafana Labs** | AGPL (core) + Proprietary | Cloud + Enterprise | $300M+ |
| **Snyk** | Apache (CLI) + Proprietary | SaaS | $200M+ |
| **Datadog** | Apache (agent) + Proprietary | SaaS | $2.1B |

**Key takeaway**: All started as open-source with Apache/MIT, built community, then added paid enterprise features. The core stays free — the enterprise layer drives revenue.

---

## Next Steps for Monetization

1. **Now**: Build community around open-source core (GitHub stars, contributors)
2. **1,000 stars**: Launch Discord community, start collecting enterprise feature requests
3. **5,000 stars**: Release AgentGate Cloud beta (managed sidecar + dashboard)
4. **10,000 stars**: Launch Team Plan, hire first sales person
5. **25,000+ stars**: Enterprise Plan, Series A fundraising
