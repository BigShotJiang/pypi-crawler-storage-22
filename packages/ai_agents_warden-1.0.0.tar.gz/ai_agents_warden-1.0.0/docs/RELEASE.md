# 🚀 AgentGate Commercial Release Guide

> How to release AgentGate as a paid product with a free 24-hour trial.

---

## 📋 Table of Contents

1. [Business Model](#business-model)
2. [Pricing Tiers](#pricing-tiers)
3. [How the License System Works](#how-the-license-system-works)
4. [Where to Release](#where-to-release)
5. [Release Checklist](#release-checklist)
6. [Step-by-Step Release Process](#step-by-step-release-process)
7. [Payment & Billing Setup](#payment--billing-setup)
8. [Marketing Channels](#marketing-channels)
9. [Post-Launch Operations](#post-launch-operations)

---

## 💰 Business Model

**Open-Core Freemium** — the most successful model for developer tools.

| What's free | What's paid |
|-------------|-------------|
| Core policy engine | Evidence Vault & audit trails |
| 2 built-in policies | Unlimited custom YAML policies |
| Basic sidecar API | Capability Tokens |
| 100 evaluations/hour | 100,000+ evaluations/hour |
| | Multi-agent support |
| | Dashboard & replay |
| | Export & compliance reports |
| | Webhook alerts |
| | Commercial use license |
| | Priority support |
| | SSO (Enterprise) |

**Free trial**: First-time users get **24 hours of full access** (all Pro features). After trial expires, they fall back to the free Community tier. No credit card required.

---

## 💳 Pricing Tiers

| Tier | Price | Target |
|------|-------|--------|
| **Community** | Free forever | Individual developers, OSS projects |
| **Trial** | Free for 24 hours | Everyone (auto-activated on first use) |
| **Pro** | $49/month ($39/mo annual) | Startups, small teams |
| **Enterprise** | $199/month ($159/mo annual) | Companies needing SLA, SSO, support |

### Feature Comparison

| Feature | Community | Trial (24h) | Pro | Enterprise |
|---------|-----------|-------------|-----|------------|
| Policies | 2 max | Unlimited | Unlimited | Unlimited |
| Custom YAML policies | ❌ | ✅ | ✅ | ✅ |
| Evidence Vault | ❌ | ✅ | ✅ | ✅ |
| Capability Tokens | ❌ | ✅ | ✅ | ✅ |
| Multi-agent | ❌ | ✅ | ✅ | ✅ |
| Dashboard | ❌ | ✅ | ✅ | ✅ |
| Evaluations/hour | 100 | 10,000 | 100,000 | Unlimited |
| Export & Compliance | ❌ | ✅ | ✅ | ✅ |
| Webhook Alerts | ❌ | ✅ | ✅ | ✅ |
| Commercial Use | ❌ | ❌ | ✅ | ✅ |
| Priority Support | ❌ | ❌ | ✅ | ✅ |
| SSO / SAML | ❌ | ❌ | ❌ | ✅ |
| SLA | ❌ | ❌ | ❌ | ✅ (99.9%) |
| Audit Retention | 1 day | 1 day | 90 days | 365 days |

---

## 🔐 How the License System Works

### Automatic Trial Activation
```
User installs AgentGate
    → First use: 24-hour trial auto-activates
    → All Pro features unlocked
    → After 24 hours: falls back to Community (free)
    → User can upgrade anytime with a license key
```

### License Key Flow
```
1. Customer pays at https://agentgate.dev/pricing
2. Payment processor (Stripe) triggers webhook
3. License server generates signed key
4. Customer receives key via email
5. Customer runs: agentgate license activate <KEY>
6. Key is validated locally (HMAC-SHA256 signature)
7. Features unlocked immediately
```

### CLI Commands
```bash
# Check license status
agentgate license status

# Activate a paid license
agentgate license activate <LICENSE_KEY>

# Deactivate (revert to community)
agentgate license deactivate

# Generate keys (admin/server side only)
agentgate license generate-key --tier pro --email customer@company.com --days 365
```

### API Endpoints
```
GET  /api/v1/license/status     → Current license info
POST /api/v1/license/activate   → Activate a key { "key": "..." }
```

---

## 🌍 Where to Release

### Primary Distribution Channels

#### 1. **PyPI** (Python Package Index) — Main distribution
```bash
# Build
python -m build

# Publish to Test PyPI first
python -m twine upload --repository testpypi dist/*

# Publish to production PyPI
python -m twine upload dist/*
```
Users install with: `pip install ai-agents-warden`

#### 2. **GitHub Releases** — Source + binaries
- Create a Release on GitHub with changelog
- Attach wheel + sdist + Dockerfile
- Tag: `v0.1.0`

#### 3. **Docker Hub** — Container distribution
```bash
docker build -t nitin100/agentgate:0.1.0 .
docker push nitin100/agentgate:0.1.0
```
Users run with: `docker run -p 18790:18790 nitin100/agentgate`

#### 4. **Your Website** — https://agentgate.dev
- Landing page with product info
- Pricing page
- Documentation
- Dashboard for license management
- Blog for launch post

### Secondary / Growth Channels

| Channel | What to Post | Expected Impact |
|---------|-------------|-----------------|
| **Product Hunt** | Launch post with demo GIF | 500-2000 signups day 1 |
| **Hacker News** | "Show HN: AgentGate — Firewall for AI Agents" | 200-1000 visitors |
| **Reddit** | r/MachineLearning, r/Python, r/artificial | Ongoing traffic |
| **Twitter/X** | Thread showing the demo | Viral potential |
| **LinkedIn** | Article on AI agent security | Enterprise leads |
| **Dev.to** | Tutorial: "Securing AI Agents with AgentGate" | Developer trust |
| **YouTube** | 5-min demo video | Long-tail traffic |
| **Discord** | AI/ML communities, LangChain, CrewAI servers | Direct users |
| **GitHub Topics** | Tag repo with ai, security, agents | Organic discovery |

### Marketplaces to List On

| Marketplace | Type | Notes |
|-------------|------|-------|
| **AWS Marketplace** | SaaS listing | Enterprise customers find you here |
| **Google Cloud Marketplace** | Container | Easy deployment for GCP users |
| **Hugging Face** | Space/Demo | AI community discovery |
| **Vercel Marketplace** | Integration | If you build a hosted version |

---

## ✅ Release Checklist

### Before Release
- [ ] All 91+ tests passing
- [ ] Version bumped in `pyproject.toml` and `__init__.py`
- [ ] CHANGELOG.md updated
- [ ] README has install instructions
- [ ] License system tested (trial → expire → community → activate pro)
- [ ] Docker image builds and runs
- [ ] Demo script works: `python demo.py`
- [ ] All 5 agent tests pass: `python examples/test_all_agents.py`

### Accounts to Set Up
- [ ] **PyPI account** — https://pypi.org/account/register/
- [ ] **PyPI API token** — https://pypi.org/manage/account/token/
- [ ] **Docker Hub account** — https://hub.docker.com/
- [ ] **Stripe account** — https://dashboard.stripe.com/register
- [ ] **Domain** — agentgate.dev (register on Namecheap/Cloudflare)
- [ ] **Landing page** — Vercel/Netlify (or simple HTML)
- [ ] **Email** — hello@agentgate.dev
- [ ] **Product Hunt** — https://www.producthunt.com/

### For Payment Processing (Stripe)
- [ ] Create Stripe products for Pro ($49/mo) and Enterprise ($199/mo)
- [ ] Set up Checkout Sessions or Payment Links
- [ ] Create webhook endpoint for `payment_intent.succeeded`
- [ ] On payment success → generate license key → email to customer
- [ ] Set up Stripe Customer Portal for self-service billing

---

## 📦 Step-by-Step Release Process

### Step 1: Set Up PyPI
```bash
# Create account at pypi.org
# Generate API token
# Store in ~/.pypirc or environment variable

pip install build twine
python -m build
python -m twine upload --repository testpypi dist/*  # Test first
python -m twine upload dist/*                         # Production
```

### Step 2: Create GitHub Release
```bash
git tag -a v0.1.0 -m "AgentGate v0.1.0 — Initial commercial release"
git push origin v0.1.0
```
Then on GitHub → Releases → Create → Upload wheel/sdist.

### Step 3: Docker Hub
```bash
docker build -t nitin100/agentgate:0.1.0 -t nitin100/agentgate:latest .
docker login
docker push nitin100/agentgate:0.1.0
docker push nitin100/agentgate:latest
```

### Step 4: Set Up Stripe
1. Go to https://dashboard.stripe.com
2. Create Product "AgentGate Pro" → Price $49/month
3. Create Product "AgentGate Enterprise" → Price $199/month
4. Create Payment Links for each
5. Add webhook: on payment → call your server → generate key → email

### Step 5: Landing Page
Build a simple page at **agentgate.dev** with:
- Hero: "The Execution Firewall for AI Agents"
- 3 feature blocks
- Pricing table
- "Start Free Trial" CTA → `pip install ai-agents-warden`
- "Buy Pro" CTA → Stripe Checkout

### Step 6: Launch! 🚀
1. Post on Product Hunt (schedule for Tuesday 12:01 AM PT)
2. Post on Hacker News: "Show HN: AgentGate — Open-source firewall for AI agents"
3. Tweet/post thread with demo GIF
4. Post on Reddit (r/Python, r/MachineLearning)
5. Send to relevant Discord communities

---

## 💵 Payment & Billing Setup

### Recommended Stack
| Component | Service | Cost |
|-----------|---------|------|
| Payments | **Stripe** | 2.9% + $0.30 per transaction |
| Landing page | **Vercel** (free) | $0 |
| Email | **Resend** or **Postmark** | ~$0 for low volume |
| License server | **Vercel Functions** or **Railway** | ~$5/mo |
| Domain | **Cloudflare** | ~$10/year |
| Analytics | **Plausible** or **PostHog** | Free tier |

### Simple License Server (Optional)
For v1, you can generate keys manually:
```bash
agentgate license generate-key --tier pro --email buyer@example.com --days 365
```
Then email the key to the customer.

For v2, build an automated server:
```
Stripe webhook → Your API → generate_license_key() → Email to customer
```

### Revenue Projections
| Users | Free | Pro ($49) | Enterprise ($199) | Monthly Revenue |
|-------|------|-----------|-------------------|-----------------|
| 100 | 90 | 8 | 2 | $790 |
| 500 | 430 | 55 | 15 | $5,680 |
| 1,000 | 850 | 120 | 30 | $11,850 |
| 5,000 | 4,200 | 650 | 150 | $61,700 |

---

## 📊 Post-Launch Operations

### Week 1
- Monitor installs: `pip install ai-agents-warden` stats on PyPI
- Watch GitHub stars and issues
- Reply to HN/Reddit/PH comments
- Track trial → paid conversion rate

### Month 1
- Publish 2-3 blog posts / tutorials
- Create YouTube demo
- Reach out to AI agent framework maintainers for partnerships
- Start building the automated license server

### Quarter 1
- Analyze which features drive conversions
- Consider annual pricing discount
- Build integrations with popular platforms
- Apply to AWS/GCP Marketplaces
- Hire part-time support if needed

---

## 🔑 Quick Commands Reference

```bash
# Build & publish
python -m build
python -m twine upload dist/*

# Docker
docker compose up -d

# License management
agentgate license status
agentgate license activate <KEY>
agentgate license generate-key --tier pro --email user@co.com

# Run tests
python -m pytest tests/ -q
python examples/test_all_agents.py

# Run demo
python demo.py
```

---

**Questions?** hello@agentgate.dev | https://agentgate.dev
