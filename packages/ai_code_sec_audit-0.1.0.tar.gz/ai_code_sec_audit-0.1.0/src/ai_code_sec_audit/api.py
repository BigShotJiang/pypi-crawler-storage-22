"""Public API for ai_code_sec_audit."""

from __future__ import annotations

from pathlib import Path

from ai_code_sec_audit.orchestrator import run_audit
from ai_code_sec_audit.schema import AuditReport
from ai_code_sec_audit.version import __version__


def audit_path(
    target: str,
    profile: str = "default",
    fail_on: str | None = None,
    how_to_reproduce: str = "",
) -> AuditReport:
    """Run a security audit for a target path."""
    resolved = Path(target).resolve()
    report, _warnings = run_audit(
        target=resolved,
        profile=profile,
        fail_on=fail_on,
        how_to_reproduce=how_to_reproduce,
        tool_version=__version__,
    )
    return report
