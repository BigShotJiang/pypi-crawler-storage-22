"""CLI entry point for ai_code_sec_audit."""

from __future__ import annotations

import argparse
import json
import shlex
import sys
from pathlib import Path

from ai_code_sec_audit.orchestrator import run_audit
from ai_code_sec_audit.scoring import FAIL_ORDER
from ai_code_sec_audit.version import __version__


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ai-code-sec-audit")
    subparsers = parser.add_subparsers(dest="command", required=True)

    audit_parser = subparsers.add_parser("audit", help="Audit a file or directory")
    audit_parser.add_argument("path")
    audit_parser.add_argument("-o", required=True, dest="output", help="Output JSON report path")
    audit_parser.add_argument("-p", default="default", dest="profile", help="Profile name")
    audit_parser.add_argument("-f", choices=tuple(FAIL_ORDER.keys()), dest="fail_on")
    audit_parser.add_argument("-P", action="store_true", dest="pretty", help="Pretty-print JSON")
    return parser


def _reproduce_command(
    target: Path, output: Path, profile: str, fail_on: str | None, pretty: bool
) -> str:
    parts = [
        "ai-code-sec-audit",
        "audit",
        str(target),
        "-o",
        str(output),
        "-p",
        profile,
    ]
    if fail_on:
        parts.extend(["-f", fail_on])
    if pretty:
        parts.append("-P")
    return " ".join(shlex.quote(p) for p in parts)


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command != "audit":
        parser.error("Unknown command")

    target = Path(args.path).resolve()
    output = Path(args.output).resolve()
    reproduce = _reproduce_command(target, output, args.profile, args.fail_on, args.pretty)

    report, warnings = run_audit(
        target=target,
        profile=args.profile,
        fail_on=args.fail_on,
        how_to_reproduce=reproduce,
        tool_version=__version__,
    )

    output.parent.mkdir(parents=True, exist_ok=True)
    payload = report.model_dump(mode="json")
    if args.pretty:
        rendered = json.dumps(payload, indent=2, sort_keys=True)
    else:
        rendered = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    output.write_text(rendered + "\n", encoding="utf-8")

    for warning in warnings:
        print(f"warning: {warning}", file=sys.stderr)

    print(
        f"score={report.summary.score} total={report.summary.total_findings} "
        f"fail={report.summary.should_fail}"
    )
    print(f"reproduce: {report.meta.how_to_reproduce}")

    return 2 if report.summary.should_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
