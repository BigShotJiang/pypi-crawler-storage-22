"""Audit orchestration across supported scanners."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from ai_code_sec_audit.scanners.bandit import run_bandit
from ai_code_sec_audit.scanners.semgrep import run_semgrep
from ai_code_sec_audit.schema import AuditReport, Finding, Meta, Summary, SummaryCounts
from ai_code_sec_audit.scoring import score_from_counts, should_fail


def _count_findings(findings: list[Finding]) -> SummaryCounts:
    counts = SummaryCounts()
    for finding in findings:
        setattr(counts, finding.severity.value, getattr(counts, finding.severity.value) + 1)
    return counts


def run_audit(
    *,
    target: Path,
    profile: str,
    fail_on: str | None,
    how_to_reproduce: str,
    tool_version: str,
) -> tuple[AuditReport, list[str]]:
    """Run all scanners and build an audit report."""
    findings: list[Finding] = []
    warnings: list[str] = []

    bandit_findings, bandit_warnings = run_bandit(target)
    semgrep_findings, semgrep_warnings = run_semgrep(target)

    findings.extend(bandit_findings)
    findings.extend(semgrep_findings)
    warnings.extend(bandit_warnings)
    warnings.extend(semgrep_warnings)

    findings.sort(
        key=lambda x: (x.severity.value, x.file, x.start_line, x.rule_id, x.tool, x.title)
    )

    counts = _count_findings(findings)
    summary = Summary(
        score=score_from_counts(counts),
        total_findings=len(findings),
        counts=counts,
        should_fail=should_fail(counts, fail_on),
    )

    report = AuditReport(
        meta=Meta(
            tool_version=tool_version,
            timestamp=datetime.now(timezone.utc),
            target=str(target),
            profile=profile,
            how_to_reproduce=how_to_reproduce,
        ),
        summary=summary,
        findings=findings,
    )
    return report, warnings
