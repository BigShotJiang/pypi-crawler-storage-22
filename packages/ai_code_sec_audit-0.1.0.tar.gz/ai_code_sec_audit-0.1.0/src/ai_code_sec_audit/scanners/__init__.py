"""Scanner adapters."""
