"""Bandit scanner adapter and normalizer."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

from ai_code_sec_audit.schema import Finding, Severity
from ai_code_sec_audit.utils import make_fingerprint

SEVERITY_MAP: dict[str, Severity] = {
    "LOW": Severity.LOW,
    "MEDIUM": Severity.MEDIUM,
    "HIGH": Severity.HIGH,
}


def run_bandit(target: Path) -> tuple[list[Finding], list[str]]:
    """Run Bandit and return normalized findings and warnings."""
    cmd = ["bandit"]
    if target.is_dir():
        cmd.extend(["-r", str(target)])
    else:
        cmd.append(str(target))
    cmd.extend(["-f", "json"])

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except FileNotFoundError:
        return [], ["Bandit not found. Install with: pip install bandit"]

    if not proc.stdout.strip():
        return [], []

    try:
        payload = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return [], ["Bandit produced invalid JSON output"]

    return normalize_bandit(payload), []


def normalize_bandit(payload: dict[str, object]) -> list[Finding]:
    """Normalize Bandit JSON into canonical findings."""
    raw_results = payload.get("results", [])
    if not isinstance(raw_results, list):
        return []

    findings: list[Finding] = []
    for item in raw_results:
        if not isinstance(item, dict):
            continue
        rule_id = str(item.get("test_id", "bandit.unknown"))
        title = str(item.get("test_name", "bandit finding"))
        file_path = str(item.get("filename", ""))
        line = int(item.get("line_number", 1))
        issue_text = str(item.get("issue_text", ""))
        issue_severity = str(item.get("issue_severity", "LOW"))
        issue_confidence = str(item.get("issue_confidence", ""))
        cwe_id = None
        cwe_value = item.get("issue_cwe")
        if isinstance(cwe_value, dict):
            cwe_id = cwe_value.get("id")

        severity = SEVERITY_MAP.get(issue_severity.upper(), Severity.LOW)
        cwe = [f"CWE-{cwe_id}"] if cwe_id is not None else []
        references = [f"https://bandit.readthedocs.io/en/latest/plugins/{rule_id.lower()}.html"]
        fingerprint = make_fingerprint(
            tool="bandit",
            rule_id=rule_id,
            file=file_path,
            start_line=line,
            end_line=line,
            title=title,
        )

        findings.append(
            Finding(
                tool="bandit",
                rule_id=rule_id,
                title=title,
                description=issue_text,
                severity=severity,
                confidence=issue_confidence.lower() or None,
                cwe=cwe,
                file=file_path,
                start_line=line,
                end_line=line,
                fingerprint=fingerprint,
                references=references,
            )
        )

    return findings
