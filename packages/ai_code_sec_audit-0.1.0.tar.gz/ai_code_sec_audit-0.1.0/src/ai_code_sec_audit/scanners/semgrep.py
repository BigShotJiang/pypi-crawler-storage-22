"""Semgrep scanner adapter and normalizer."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

from ai_code_sec_audit.schema import Finding, Severity
from ai_code_sec_audit.utils import make_fingerprint

SEVERITY_MAP: dict[str, Severity] = {
    "ERROR": Severity.HIGH,
    "WARNING": Severity.MEDIUM,
    "INFO": Severity.INFO,
}


def run_semgrep(target: Path) -> tuple[list[Finding], list[str]]:
    """Run Semgrep and return normalized findings and warnings."""
    cmd = ["semgrep", "--config", "auto", "--json", str(target)]

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except FileNotFoundError:
        return [], ["Semgrep not found. Install with: pip install semgrep"]

    if not proc.stdout.strip():
        return [], []

    try:
        payload = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return [], ["Semgrep produced invalid JSON output"]

    return normalize_semgrep(payload), []


def normalize_semgrep(payload: dict[str, object]) -> list[Finding]:
    """Normalize Semgrep JSON into canonical findings."""
    raw_results = payload.get("results", [])
    if not isinstance(raw_results, list):
        return []

    findings: list[Finding] = []
    for item in raw_results:
        if not isinstance(item, dict):
            continue

        check_id = str(item.get("check_id", "semgrep.unknown"))
        path = str(item.get("path", ""))
        start_line = 1
        end_line = 1
        extra = item.get("extra", {})
        if isinstance(item.get("start"), dict):
            start_line = int(item["start"].get("line", 1))
        if isinstance(item.get("end"), dict):
            end_line = int(item["end"].get("line", start_line))

        message = ""
        severity = Severity.MEDIUM
        metadata: dict[str, object] = {}
        if isinstance(extra, dict):
            message = str(extra.get("message", ""))
            severity = SEVERITY_MAP.get(
                str(extra.get("severity", "WARNING")).upper(), Severity.MEDIUM
            )
            raw_meta = extra.get("metadata", {})
            if isinstance(raw_meta, dict):
                metadata = raw_meta

        title = str(metadata.get("shortlink", check_id))
        cwe_raw = metadata.get("cwe", [])
        cwe = [str(x) for x in cwe_raw] if isinstance(cwe_raw, list) else []
        references_raw = metadata.get("references", [])
        references = [str(x) for x in references_raw] if isinstance(references_raw, list) else []
        confidence = metadata.get("confidence")

        fingerprint = make_fingerprint(
            tool="semgrep",
            rule_id=check_id,
            file=path,
            start_line=start_line,
            end_line=end_line,
            title=title,
        )

        findings.append(
            Finding(
                tool="semgrep",
                rule_id=check_id,
                title=title,
                description=message,
                severity=severity,
                confidence=str(confidence).lower() if confidence is not None else None,
                cwe=cwe,
                file=path,
                start_line=start_line,
                end_line=end_line,
                fingerprint=fingerprint,
                references=references,
            )
        )

    return findings
