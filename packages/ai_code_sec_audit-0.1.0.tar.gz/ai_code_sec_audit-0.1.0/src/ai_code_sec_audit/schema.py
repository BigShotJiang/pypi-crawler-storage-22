"""Pydantic models for canonical audit output."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class Finding(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool: str
    rule_id: str
    title: str
    description: str
    severity: Severity
    file: str
    start_line: int
    end_line: int
    fingerprint: str
    confidence: str | None = None
    cwe: list[str] = Field(default_factory=list)
    references: list[str] = Field(default_factory=list)


class SummaryCounts(BaseModel):
    model_config = ConfigDict(extra="forbid")

    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    info: int = 0


class Summary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    score: int
    total_findings: int
    counts: SummaryCounts
    should_fail: bool


class Meta(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool_version: str
    timestamp: datetime
    target: str
    profile: str
    how_to_reproduce: str


class AuditReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    meta: Meta
    summary: Summary
    findings: list[Finding]
