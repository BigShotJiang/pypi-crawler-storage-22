"""Scoring and fail threshold logic."""

from __future__ import annotations

from ai_code_sec_audit.schema import Severity, SummaryCounts

WEIGHTS: dict[Severity, int] = {
    Severity.CRITICAL: 20,
    Severity.HIGH: 10,
    Severity.MEDIUM: 4,
    Severity.LOW: 1,
    Severity.INFO: 0,
}


FAIL_ORDER: dict[str, tuple[Severity, ...]] = {
    "critical": (Severity.CRITICAL,),
    "high": (Severity.CRITICAL, Severity.HIGH),
    "medium": (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM),
    "low": (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW),
    "info": (
        Severity.CRITICAL,
        Severity.HIGH,
        Severity.MEDIUM,
        Severity.LOW,
        Severity.INFO,
    ),
}


def score_from_counts(counts: SummaryCounts) -> int:
    """Calculate deterministic 0..100 score from severity counts."""
    deduction = (
        counts.critical * WEIGHTS[Severity.CRITICAL]
        + counts.high * WEIGHTS[Severity.HIGH]
        + counts.medium * WEIGHTS[Severity.MEDIUM]
        + counts.low * WEIGHTS[Severity.LOW]
        + counts.info * WEIGHTS[Severity.INFO]
    )
    return max(0, min(100, 100 - deduction))


def should_fail(counts: SummaryCounts, fail_on: str | None) -> bool:
    """Return whether report should fail for threshold."""
    if fail_on is None:
        return False
    levels = FAIL_ORDER[fail_on]
    return any(getattr(counts, level.value) > 0 for level in levels)
