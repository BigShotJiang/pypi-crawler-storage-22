"""Utility helpers for ai_code_sec_audit."""

from __future__ import annotations

import hashlib


def make_fingerprint(
    *,
    tool: str,
    rule_id: str,
    file: str,
    start_line: int,
    end_line: int,
    title: str,
) -> str:
    """Create stable fingerprint for a finding."""
    data = f"{tool}|{rule_id}|{file}|{start_line}|{end_line}|{title}"
    return hashlib.sha256(data.encode("utf-8")).hexdigest()
