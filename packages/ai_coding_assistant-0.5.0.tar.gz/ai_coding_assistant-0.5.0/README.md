# AI Coding Assistant

A terminal-based AI coding assistant that helps you understand, navigate, and work with your codebase using natural language.

[![Python Version](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.5.0-orange.svg)](https://github.com/your-username/ai-coding-assistant)

---

## Features

- **Natural Language Queries**: Ask questions about your codebase in plain English
- **Semantic Code Search**: Find code by meaning, not just keywords
- **Code Explanation**: Get detailed explanations of files and functions
- **Interactive Chat Mode**: Explore your codebase conversationally
- **Local-First**: Works with Ollama (free, no API key required)
- **Privacy-Focused**: Everything runs locally with Ollama
- **Multi-Language Support**: Python, JavaScript, TypeScript, Java, Go, Rust, and more

---

## Quick Start

### Installation

```bash
pip install ai-coding-assistant
```

### Setup (Ollama - Free & Local)

```bash
# Install Ollama
curl https://ollama.ai/install.sh | sh

# Pull a code model
ollama pull codellama

# Start Ollama service
ollama serve
```

### Index Your Codebase

```bash
cd your-project
assistant index
```

### Ask Questions

```bash
assistant ask "How does authentication work?"
assistant explain src/auth/login.py
assistant search "JWT token validation"
```

### Interactive Mode

```bash
assistant chat
```

---

## Why AI Coding Assistant?

### No API Key Required

Works great with **Ollama** (free, local, open source). Optionally supports OpenAI and Claude APIs.

### Privacy-First

With Ollama, everything runs locally on your machine. Your code never leaves your computer.

### Fast & Efficient

- Hybrid search (vector + keyword)
- Smart caching
- Incremental indexing
- Only reprocess changed files

---

## Commands

| Command | Purpose |
|---------|---------|
| `assistant ask` | Ask questions about your code |
| `assistant index` | Index your codebase |
| `assistant explain` | Explain specific code |
| `assistant search` | Search for code |
| `assistant chat` | Interactive mode |
| `assistant config` | Manage configuration |

See [Command Reference](docs/commands/README.md) for details.

---

## Documentation

- [Installation Guide](docs/INSTALLATION.md) - Complete setup instructions
- [Quick Start Guide](docs/QUICKSTART.md) - Get started in 5 minutes
- [Configuration Guide](docs/CONFIGURATION.md) - Customize settings
- [Command Reference](docs/commands/README.md) - All commands
- [Troubleshooting](docs/TROUBLESHOOTING.md) - Common issues
- [FAQ](docs/FAQ.md) - Frequently asked questions

---

## System Requirements

### Minimum
- Python 3.11+
- 2GB RAM
- 1GB disk space

### Recommended
- Python 3.11+
- 8GB RAM (for Ollama)
- 5GB disk space

### Supported Platforms
- Linux (Ubuntu, Debian, Fedora, etc.)
- macOS (10.15+)
- Windows (WSL2 recommended)

---

## Development

### Install from Source

```bash
git clone https://github.com/your-username/ai-coding-assistant.git
cd ai-coding-assistant

# Install with Poetry
poetry install

# Or with pip
pip install -e .
```

### Run Tests

```bash
poetry run pytest
```

---

## Contributing

Contributions are welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## License

MIT License. See [LICENSE](LICENSE) for details.

---

## Support

- **GitHub Issues**: https://github.com/your-username/ai-coding-assistant/issues
- **Discussions**: https://github.com/your-username/ai-coding-assistant/discussions

---

**Start coding smarter with AI assistance!**

```bash
pip install ai-coding-assistant
assistant index
assistant ask "Let's build something amazing!"
```
