"""Entry point for the AI coding assistant."""
import sys
from coding_assistant.cli.app import app


def main():
    """Run the CLI application."""
    try:
        app()
    except KeyboardInterrupt:
        print("\n\nGoodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
