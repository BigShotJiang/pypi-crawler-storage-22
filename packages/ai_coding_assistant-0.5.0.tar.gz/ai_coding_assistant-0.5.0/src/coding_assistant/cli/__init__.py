"""CLI module for the coding assistant."""
