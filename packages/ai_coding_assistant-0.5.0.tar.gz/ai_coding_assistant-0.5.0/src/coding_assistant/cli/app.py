"""Main CLI application using Typer."""
import typer
from rich.console import Console
from pathlib import Path
from typing import Optional

from coding_assistant.config.settings import settings
from coding_assistant.cli.commands import (
    ask_command,
    index_command,
    explain_command,
    search_command,
    refactor_command,
    fix_command,
    config_command,
)
from coding_assistant.cli.commands.document import document_app
from coding_assistant.cli.commands.diagram import diagram_app
from coding_assistant.cli.commands.serve_docs import serve_docs_app

app = typer.Typer(
    name="assistant",
    help="AI-powered coding assistant for your terminal",
    add_completion=False,
    rich_markup_mode="rich",
)

console = Console()


@app.callback()
def callback(
    project_path: Optional[Path] = typer.Option(
        None,
        "--project",
        "-p",
        help="Path to the project directory (defaults to current directory)"
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose output"
    ),
    llm_provider: Optional[str] = typer.Option(
        None,
        "--llm",
        help="LLM provider to use (ollama, groq, gemini, together, mock)"
    ),
):
    """AI coding assistant - understand and improve your codebase.

    Phase 4: Advanced Features
    - Intelligent code explanations
    - Hybrid semantic + keyword search
    - AI-powered refactoring with validation
    - Automated bug fixing and linting
    """
    if project_path:
        settings.set_project_path(project_path)
    settings.verbose = verbose
    if llm_provider:
        settings.llm_provider = llm_provider


# Register commands
app.command(name="ask", help="Ask questions about your codebase")(ask_command)
app.command(name="index", help="Index codebase for semantic search")(index_command)
app.command(name="explain", help="Explain how code works")(explain_command)
app.command(name="search", help="Search codebase with hybrid search")(search_command)
app.command(name="refactor", help="Refactor code with AI assistance")(refactor_command)
app.command(name="fix", help="Fix linting issues and bugs")(fix_command)
app.add_typer(config_command, name="config", help="Manage configuration and API keys")

# CodeWiki integration commands
app.add_typer(document_app, name="document", help="Generate comprehensive documentation")
app.add_typer(diagram_app, name="diagram", help="Generate visual diagrams")
app.add_typer(serve_docs_app, name="serve-docs", help="Serve documentation locally")


@app.command()
def version():
    """Show version information."""
    from rich.panel import Panel
    from rich.table import Table

    # Version info
    version_text = """[bold cyan]AI Coding Assistant[/bold cyan]
[bold]Version:[/bold] 0.4.0
[bold]Phase:[/bold] 4 - Advanced Features

[dim]A local-first, AI-powered coding assistant[/dim]"""

    console.print(Panel(version_text, border_style="cyan"))

    # Features table
    table = Table(title="Features", show_header=True, header_style="bold magenta")
    table.add_column("Feature", style="cyan")
    table.add_column("Status", justify="center")

    features = [
        ("Semantic Code Search", "✓"),
        ("Hybrid Search (Vector + BM25)", "✓"),
        ("Smart Code Chunking", "✓"),
        ("Context-Aware Ranking", "✓"),
        ("Code Validation", "✓"),
        ("Linter Integration", "✓"),
        ("AI-Powered Refactoring", "✓"),
        ("Automated Bug Fixing", "✓"),
        ("Diff Preview", "✓"),
        ("Local LLM Support (Ollama)", "✓"),
    ]

    for feature, status in features:
        table.add_row(feature, f"[green]{status}[/green]")

    console.print(table)

    # Commands info
    console.print("\n[bold]Available Commands:[/bold]")
    commands_info = [
        ("ask", "Ask questions about your codebase"),
        ("search", "Search code with hybrid search"),
        ("explain", "Explain how code works"),
        ("index", "Index codebase for search"),
        ("refactor", "Refactor code with AI"),
        ("fix", "Fix linting issues and bugs"),
        ("config", "Manage configuration and API keys"),
    ]

    for cmd, desc in commands_info:
        console.print(f"  [cyan]{cmd:12}[/cyan] {desc}")

    console.print("\n[dim]Run 'assistant <command> --help' for more information[/dim]\n")


@app.command()
def chat():
    """Start interactive chat mode (REPL).

    Interactive mode allows multi-turn conversations with context awareness.
    The assistant remembers your previous questions and can provide
    more contextual and helpful responses.

    Features:
    - Multi-turn conversations
    - Context-aware responses
    - Code search and retrieval
    - Special commands (/help, /history, etc.)

    Press Ctrl+D to exit.
    """
    from coding_assistant.cli.repl import start_repl
    start_repl(settings.project_path)


if __name__ == "__main__":
    app()
