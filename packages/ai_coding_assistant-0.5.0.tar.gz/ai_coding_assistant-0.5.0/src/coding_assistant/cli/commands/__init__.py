"""CLI commands for the coding assistant."""

from coding_assistant.cli.commands.ask import ask_command
from coding_assistant.cli.commands.index import index_command
from coding_assistant.cli.commands.explain import explain_command
from coding_assistant.cli.commands.search import search_command
from coding_assistant.cli.commands.refactor import refactor_command
from coding_assistant.cli.commands.fix import fix_command
from coding_assistant.cli.commands.config import config_command

__all__ = [
    'ask_command',
    'index_command',
    'explain_command',
    'search_command',
    'refactor_command',
    'fix_command',
    'config_command',
]
