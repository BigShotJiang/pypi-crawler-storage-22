"""Ask command - Ask questions about your codebase."""

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.live import Live
from rich.spinner import Spinner
from pathlib import Path

from coding_assistant.config.settings import settings
from coding_assistant.context.enhanced_retriever import EnhancedSemanticRetriever
from coding_assistant.codebase.crawler import CodebaseCrawler
from coding_assistant.llm.client import LLMClientFactory
from coding_assistant.llm.prompts import PromptBuilder
from coding_assistant.cli.theme import get_console, COLORS, ICONS

console = get_console()


def ask_command(
    question: str = typer.Argument(..., help="Your question about the codebase"),
    context_chunks: int = typer.Option(
        5,
        "--context",
        "-c",
        help="Number of code chunks to include as context"
    ),
    use_hybrid: bool = typer.Option(
        True,
        "--hybrid/--no-hybrid",
        help="Use hybrid search (vector + keyword)"
    ),
):
    """Ask a question about your codebase with intelligent context retrieval.

    The assistant will:
    1. Find relevant code using hybrid search (semantic + keyword)
    2. Rank results with language-aware intelligence
    3. Build context with smart chunking
    4. Generate answer using LLM

    Examples:
      assistant ask "how does authentication work?"
      assistant ask "where are database queries defined?" --context 10
      assistant ask "explain the JWT implementation"
    """

    # Display question in a beautiful panel
    question_panel = Panel(
        f"[question]{question}[/question]",
        title=f"[primary]{ICONS['question']} Question[/primary]",
        border_style="primary",
        padding=(0, 2)
    )
    console.print(question_panel)

    file_contents = []

    # Try enhanced semantic retrieval
    try:
        with console.status(f"[spinner]{ICONS['search']} Finding relevant code...[/spinner]", spinner="dots"):
            retriever = EnhancedSemanticRetriever(settings.project_path)

            # Check if indexed
            stats = retriever.get_stats()
            if stats['total_chunks'] == 0:
                console.print(f"[warning]{ICONS['warning']} Codebase not indexed.[/warning]")
                console.print("[dim]   Run 'assistant index' first for best results.[/dim]")
                console.print("[dim]   Falling back to simple file scan...[/dim]\n")
                use_semantic = False
            else:
                # Retrieve with enhanced retrieval
                results = retriever.retrieve(
                    query=question,
                    k=context_chunks,
                    use_hybrid=use_hybrid,
                    use_ranking=True
                )

                if settings.verbose:
                    console.print(f"\n[dim]Retrieved {len(results)} relevant chunks:[/dim]")
                    for i, r in enumerate(results, 1):
                        score_type = "Rank" if use_hybrid else "Similarity"
                        score = r.get('rank_score', r.get('similarity', 0.0))
                        console.print(
                            f"[dim]  {i}. {r['path']}:{r['start_line']} - "
                            f"{r['name']} ({score_type}: {score:.2f})[/dim]"
                        )
                    console.print()

                # Convert to file_contents format
                for result in results:
                    file_contents.append({
                        'path': f"{result['path']}:{result['start_line']}-{result['end_line']}",
                        'content': result['content'],
                        'language': result.get('language', 'python')
                    })

                use_semantic = True

    except Exception as e:
        console.print(f"[yellow]⚠️  Enhanced retrieval failed: {e}[/yellow]")
        console.print("[yellow]   Falling back to simple file scan...[/yellow]\n")
        use_semantic = False

    # Fallback to simple scan if needed
    if not use_semantic:
        with console.status("[bold green]Scanning codebase..."):
            crawler = CodebaseCrawler(settings.project_path)
            files = crawler.scan(max_files=context_chunks * 2)

            for file_info in files[:context_chunks]:
                try:
                    content = crawler.read_file(file_info['path'])
                    file_contents.append({
                        'path': file_info['path'],
                        'content': content[:2000],  # Limit content
                        'language': file_info['extension'][1:] if file_info['extension'] else 'text'
                    })
                except:
                    continue

            if settings.verbose:
                console.print(f"[dim]Scanned {len(files)} files, using {len(file_contents)} for context[/dim]\n")

    if not file_contents:
        console.print("[red]✗ No code found to provide context.[/red]")
        console.print("[yellow]Try indexing first: assistant index[/yellow]\n")
        raise typer.Exit(1)

    # Build prompt
    prompt_builder = PromptBuilder()
    messages = prompt_builder.build_ask_prompt(question, file_contents)

    # Get LLM client
    llm = LLMClientFactory.create_client(settings.llm_provider)

    # Generate response with beautiful formatting
    console.print()  # Spacing
    console.print(Panel(
        f"[provider]{ICONS['sparkles']} Generating answer...[/provider]",
        border_style="secondary",
        padding=(0, 2)
    ))

    try:
        response_text = ""
        for chunk in llm.generate(messages, stream=True):
            response_text += chunk

        # Render markdown answer in a panel
        answer_md = Markdown(response_text)
        answer_panel = Panel(
            answer_md,
            title=f"[success]{ICONS['answer']} Answer[/success]",
            border_style="success",
            padding=(1, 2)
        )
        console.print(answer_panel)

        # Show tips
        if not use_semantic:
            console.print(f"\n[dim]{ICONS['info']} Tip: Run 'assistant index' for better context retrieval[/dim]")

    except Exception as e:
        error_panel = Panel(
            f"[error]{str(e)}[/error]",
            title=f"[error]{ICONS['error']} Error[/error]",
            border_style="error",
            padding=(0, 2)
        )
        console.print(error_panel)
        if settings.verbose:
            import traceback
            traceback.print_exc()
        raise typer.Exit(1)
