"""Configuration management commands."""

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from pathlib import Path
from typing import Optional

from coding_assistant.config.settings import settings
from coding_assistant.config.config_manager import Config
from coding_assistant.utils.keystore import KeyStore
from coding_assistant.utils.hardware import HardwareDetector

console = Console()
app = typer.Typer(help="Manage configuration and API keys")


@app.command(name="show")
def show_config():
    """Display current configuration."""
    console.print("\n[bold cyan]Current Configuration[/bold cyan]\n")

    # LLM Provider settings
    table = Table(title="LLM Provider Settings", show_header=True, header_style="bold magenta")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Provider", settings.llm_provider or "[dim]auto-detect[/dim]")
    table.add_row("Ollama Model", settings.ollama_model)
    table.add_row("Ollama URL", settings.ollama_base_url)
    table.add_row("Groq Model", settings.groq_model)
    table.add_row("Together Model", settings.together_model)

    console.print(table)
    console.print()

    # API Keys status
    keystore = KeyStore()
    masked_keys = keystore.get_masked_keys()

    keys_table = Table(title="API Keys Status", show_header=True, header_style="bold magenta")
    keys_table.add_column("Provider", style="cyan")
    keys_table.add_column("Status", style="green")
    keys_table.add_column("Key Preview", style="dim")

    for provider in ["groq", "gemini", "together", "openai", "claude"]:
        if provider in masked_keys:
            status = "✓ Configured"
            preview = masked_keys[provider]
        else:
            env_key = getattr(settings, f"{provider}_api_key", None)
            if env_key:
                status = "✓ From env var"
                preview = keystore.mask_key(env_key)
            else:
                status = "✗ Not set"
                preview = "-"

        keys_table.add_row(provider.capitalize(), status, preview)

    console.print(keys_table)
    console.print()

    # General settings
    general_table = Table(title="General Settings", show_header=True, header_style="bold magenta")
    general_table.add_column("Setting", style="cyan")
    general_table.add_column("Value", style="green")

    general_table.add_row("Project Path", str(settings.project_path))
    general_table.add_row("Data Directory", str(settings.data_dir))
    general_table.add_row("Verbose", str(settings.verbose))
    general_table.add_row("Max Context Files", str(settings.max_context_files))

    console.print(general_table)
    console.print()


@app.command(name="set-api-key")
def set_api_key(
    provider: str = typer.Argument(..., help="Provider name (groq, together, openai, claude)"),
    api_key: str = typer.Argument(..., help="API key to store"),
):
    """Store API key securely for a provider."""
    try:
        keystore = KeyStore()
        keystore.set_key(provider, api_key)

        console.print(f"\n[green]✓ API key for {provider} stored successfully![/green]\n")

        # Show masked key
        masked = keystore.mask_key(api_key)
        console.print(f"[dim]Stored key: {masked}[/dim]\n")

        # Next steps
        console.print("[bold]Next steps:[/bold]")
        console.print(f"  1. Test the connection: assistant ask \"test question\"")
        console.print(f"  2. View config: assistant config show")
        console.print()

    except ValueError as e:
        console.print(f"\n[red]✗ Error: {e}[/red]\n")
        console.print("[yellow]Valid providers: groq, together, openai, claude[/yellow]\n")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"\n[red]✗ Failed to store API key: {e}[/red]\n")
        raise typer.Exit(1)


@app.command(name="remove-api-key")
def remove_api_key(
    provider: str = typer.Argument(..., help="Provider name to remove key for"),
):
    """Remove stored API key for a provider."""
    keystore = KeyStore()

    if keystore.remove_key(provider):
        console.print(f"\n[green]✓ API key for {provider} removed successfully![/green]\n")
    else:
        console.print(f"\n[yellow]⚠  No API key found for {provider}[/yellow]\n")


@app.command(name="list-keys")
def list_keys():
    """Show all configured providers with masked keys."""
    console.print("\n[bold cyan]Configured API Keys[/bold cyan]\n")

    keystore = KeyStore()
    providers = keystore.list_providers()

    if not providers:
        console.print("[yellow]No API keys configured yet.[/yellow]\n")
        console.print("[dim]Set a key with: assistant config set-api-key <provider> <key>[/dim]\n")
        return

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("#", style="dim", width=4)
    table.add_column("Provider", style="cyan")
    table.add_column("Key Preview", style="green")

    masked_keys = keystore.get_masked_keys()
    for i, provider in enumerate(providers, 1):
        table.add_row(
            str(i),
            provider.capitalize(),
            masked_keys.get(provider, "***")
        )

    console.print(table)
    console.print()

    console.print("[dim]Remove a key with: assistant config remove-api-key <provider>[/dim]\n")


@app.command(name="check-hardware")
def check_hardware():
    """Display hardware information and provider recommendations."""
    console.print("\n[bold cyan]Hardware Detection & Recommendations[/bold cyan]\n")

    hw_info = HardwareDetector.get_hardware_info()

    # Hardware info table
    hw_table = Table(show_header=True, header_style="bold magenta")
    hw_table.add_column("Specification", style="cyan")
    hw_table.add_column("Value", style="green")

    hw_table.add_row("Total RAM", f"{hw_info.total_ram_gb:.1f} GB")
    hw_table.add_row("Available RAM", f"{hw_info.available_ram_gb:.1f} GB")
    hw_table.add_row("Can Run Local Models", "Yes" if hw_info.can_run_local else "No")
    hw_table.add_row("Recommended Provider", hw_info.recommended_provider.upper())
    hw_table.add_row("Recommended Model", hw_info.recommended_model)

    console.print(hw_table)
    console.print()

    # Detailed recommendation
    recommendation = HardwareDetector.format_recommendation(hw_info)
    panel = Panel(
        recommendation,
        title="[bold]Setup Recommendation[/bold]",
        border_style="green" if hw_info.can_run_local else "yellow"
    )
    console.print(panel)
    console.print()


@app.command(name="models")
def select_model():
    """Interactively select and switch LLM provider/model."""
    from rich.prompt import Prompt
    from coding_assistant.llm.client import LLMClientFactory, OllamaClient
    from coding_assistant.llm.groq_client import GroqClient
    from coding_assistant.llm.together_client import TogetherClient
    from coding_assistant.llm.gemini_client import GeminiClient

    console.print("\n[bold cyan]Available LLM Models[/bold cyan]\n")

    # Build provider list with status
    providers = []
    keystore = KeyStore()

    # Check each provider
    provider_info = [
        {
            "name": "together",
            "display": "Together AI",
            "model": "Qwen2.5-Coder-32B",
            "description": "Best for coding (32B params)",
            "client_class": TogetherClient,
            "needs_key": True,
            "color": "cyan"
        },
        {
            "name": "groq",
            "display": "Groq",
            "model": "Llama 3.3 70B",
            "description": "Fast & capable general model",
            "client_class": GroqClient,
            "needs_key": True,
            "color": "green"
        },
        {
            "name": "gemini",
            "display": "Google Gemini",
            "model": "Gemini 2.0 Flash",
            "description": "Fast, may have quotas",
            "client_class": GeminiClient,
            "needs_key": True,
            "color": "yellow"
        },
        {
            "name": "ollama",
            "display": "Ollama (Local)",
            "model": settings.ollama_model,
            "description": "Privacy-first, runs offline",
            "client_class": OllamaClient,
            "needs_key": False,
            "color": "magenta"
        },
    ]

    # Create table
    table = Table(show_header=True, header_style="bold magenta", title="LLM Providers")
    table.add_column("#", style="dim", width=4)
    table.add_column("Provider", style="bold")
    table.add_column("Model", style="cyan")
    table.add_column("Description", style="dim")
    table.add_column("Status", justify="center")

    available_choices = []

    for i, provider in enumerate(provider_info, 1):
        # Check if configured
        if provider["needs_key"]:
            has_key = (
                keystore.get_key(provider["name"]) is not None or
                getattr(settings, f"{provider['name']}_api_key", None) is not None
            )
        else:
            has_key = True

        # Check if available (running/accessible)
        is_available = False
        if has_key:
            try:
                if provider["name"] == "ollama":
                    client = provider["client_class"](
                        model=settings.ollama_model,
                        base_url=settings.ollama_base_url
                    )
                elif provider["name"] == "groq":
                    client = provider["client_class"](
                        api_key=settings.groq_api_key,
                        model=settings.groq_model
                    )
                elif provider["name"] == "gemini":
                    client = provider["client_class"](
                        api_key=settings.gemini_api_key,
                        model=settings.gemini_model
                    )
                elif provider["name"] == "together":
                    client = provider["client_class"](
                        api_key=settings.together_api_key,
                        model=settings.together_model
                    )

                is_available = client.is_available()
            except:
                is_available = False

        # Determine status
        if is_available:
            status = "[green]✓ Ready[/green]"
            available_choices.append(str(i))
        elif has_key:
            status = "[yellow]⚠ Offline[/yellow]"
        else:
            status = "[red]✗ No API Key[/red]"

        # Check if current default
        current_provider = settings.llm_provider or "auto"
        is_current = (current_provider == provider["name"])

        provider_display = provider["display"]
        if is_current:
            provider_display = f"→ {provider_display}"

        table.add_row(
            str(i),
            provider_display,
            provider["model"],
            provider["description"],
            status
        )

    console.print(table)
    console.print()

    if not available_choices:
        console.print("[yellow]⚠  No providers are currently available.[/yellow]\n")
        console.print("[bold]To set up a provider:[/bold]")
        console.print("  1. Get an API key (Groq is FREE: https://console.groq.com)")
        console.print("  2. Set it: assistant config set-api-key groq <your-key>")
        console.print("  3. Or install Ollama: curl -fsSL https://ollama.com/install.sh | sh\n")
        return

    # Prompt for selection
    console.print(f"[dim]Current: {settings.llm_provider or 'auto-detect'}[/dim]")
    choice = Prompt.ask(
        "\n[bold]Select provider[/bold]",
        choices=available_choices + ["q"],
        default="q"
    )

    if choice == "q":
        console.print("\n[dim]No changes made.[/dim]\n")
        return

    # Get selected provider
    selected = provider_info[int(choice) - 1]

    # Save to config file
    config_file = Path(".assistant.yml")
    try:
        if config_file.exists():
            config = Config.from_file(config_file)
        else:
            config = Config.default()

        config.llm.provider = selected["name"]
        config.save(config_file)

        console.print(f"\n[green]✓ Default provider set to: {selected['display']}[/green]")
        console.print(f"[dim]Saved to: {config_file}[/dim]\n")

        console.print("[bold]Test it:[/bold]")
        console.print(f"  assistant ask \"test question\"\n")

    except Exception as e:
        console.print(f"\n[yellow]⚠  Could not save to config file: {e}[/yellow]")
        console.print(f"\n[bold]Alternative: Set environment variable[/bold]")
        console.print(f"  export LLM_PROVIDER={selected['name']}")
        console.print(f"  # Or add to ~/.bashrc:\n")
        console.print(f"  echo 'export LLM_PROVIDER={selected['name']}' >> ~/.bashrc\n")


@app.command(name="generate")
def generate_config(
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path (default: .assistant.yml)"
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing config file"
    ),
):
    """Generate default configuration file."""
    if output is None:
        output = Path(".assistant.yml")

    # Check if file exists
    if output.exists() and not force:
        console.print(f"\n[yellow]⚠  Config file already exists: {output}[/yellow]")
        console.print("[dim]Use --force to overwrite[/dim]\n")
        raise typer.Exit(1)

    try:
        # Generate default config
        config = Config()
        config.save(output)

        console.print(f"\n[green]✓ Configuration file generated: {output}[/green]\n")

        console.print("[bold]Next steps:[/bold]")
        console.print(f"  1. Edit the file: {output}")
        console.print(f"  2. Set your API keys: assistant config set-api-key <provider> <key>")
        console.print(f"  3. Check hardware: assistant config check-hardware")
        console.print()

    except Exception as e:
        console.print(f"\n[red]✗ Failed to generate config: {e}[/red]\n")
        raise typer.Exit(1)


def config_command(
    ctx: typer.Context,
):
    """
    Manage configuration and API keys.

    Subcommands:
    - show: Display current configuration
    - models: Interactively select LLM provider
    - set-api-key: Store API key for a provider
    - remove-api-key: Remove stored API key
    - list-keys: Show all configured providers
    - check-hardware: Display hardware recommendations
    - generate: Generate default config file

    Examples:
      assistant config show
      assistant config models
      assistant config set-api-key groq gsk_xxxxx
      assistant config check-hardware
      assistant config list-keys
    """
    # This function serves as the entry point
    # Actual command handling is done by subcommands via app
    pass


# Export the Typer app as the command
config_command = app
