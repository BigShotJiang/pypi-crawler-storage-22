"""Diagram generation command.

This module provides CLI commands for generating visual diagrams
of code structure, dependencies, and data flow.
"""

from pathlib import Path
from typing import Optional
import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel
from rich.table import Table

from coding_assistant.documentation.graph.dependency_builder import DependencyGraphBuilder
from coding_assistant.documentation.graph.module_analyzer import ModuleAnalyzer
from coding_assistant.documentation.decomposition.partitioner import HierarchicalPartitioner
from coding_assistant.documentation.generators.diagram_generator import MermaidDiagramGenerator
from coding_assistant.documentation.generators.dataflow_generator import DataFlowGenerator
from coding_assistant.codebase.parser import CodeParser
from coding_assistant.utils.logger import get_logger

logger = get_logger(__name__)
console = Console()

# Create Typer app for diagram subcommands
diagram_app = typer.Typer(
    name="diagram",
    help="Generate visual diagrams of code structure",
    no_args_is_help=True
)


@diagram_app.command("generate")
def generate_diagram_command(
    diagram_type: str = typer.Argument(
        ...,
        help="Diagram type: architecture, dependency, class, dataflow"
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file (default: <type>.mmd)"
    ),
    codebase_path: Optional[Path] = typer.Option(
        None,
        "--path",
        "-p",
        help="Path to codebase (default: current directory)"
    ),
    max_nodes: int = typer.Option(
        40,
        "--max-nodes",
        help="Maximum nodes in graph diagrams"
    ),
    direction: str = typer.Option(
        "TB",
        "--direction",
        "-d",
        help="Graph direction (TB, LR, RL, BT)"
    ),
):
    """
    Generate a single diagram of the codebase.

    Supported diagram types:
    - architecture: High-level module structure
    - dependency: File/module dependencies
    - class: OOP structure with inheritance
    - dataflow: Data movement through system

    Examples:
        assistant diagram generate architecture
        assistant diagram generate dependency --max-nodes 30
        assistant diagram generate class --output classes.mmd
    """
    codebase = codebase_path or Path.cwd()

    console.print(Panel.fit(
        f"[bold cyan]Generating {diagram_type} Diagram[/bold cyan]\\n"
        f"Analyzing: {codebase}",
        border_style="cyan"
    ))

    try:
        # Build dependency graph
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:

            task1 = progress.add_task("[cyan]Building dependency graph...", total=None)
            builder = DependencyGraphBuilder(codebase)
            file_graph = builder.build_file_graph()
            progress.update(task1, completed=True)

            diagram_gen = MermaidDiagramGenerator()
            dataflow_gen = DataFlowGenerator()

            # Generate requested diagram type
            diagram_code = None

            if diagram_type == "architecture":
                task2 = progress.add_task("[cyan]Detecting modules...", total=None)
                analyzer = ModuleAnalyzer(file_graph)
                modules = analyzer.detect_modules()
                progress.update(task2, completed=True)

                task3 = progress.add_task("[cyan]Creating partitions...", total=None)
                file_sizes = {
                    node: file_graph.nodes[node].get('line_count', 0)
                    for node in file_graph.nodes()
                }
                partitioner = HierarchicalPartitioner()
                partitions = partitioner.partition(file_graph, file_sizes, modules)
                progress.update(task3, completed=True)

                task4 = progress.add_task("[cyan]Generating architecture diagram...", total=None)
                diagram_code = diagram_gen.generate_architecture_diagram(
                    partitions,
                    file_graph,
                    direction=direction
                )
                progress.update(task4, completed=True)

            elif diagram_type == "dependency":
                task2 = progress.add_task("[cyan]Generating dependency graph...", total=None)
                diagram_code = diagram_gen.generate_dependency_graph(
                    file_graph,
                    max_nodes=max_nodes,
                    show_files=True
                )
                progress.update(task2, completed=True)

            elif diagram_type == "class":
                task2 = progress.add_task("[cyan]Parsing files...", total=None)
                parser = CodeParser()
                parsed_files = {}

                sample_files = list(file_graph.nodes())[:30]
                for file_path in sample_files:
                    try:
                        parsed = parser.parse_file(file_path)
                        parsed_files[file_path] = parsed
                    except Exception:
                        pass

                progress.update(task2, completed=True)

                task3 = progress.add_task("[cyan]Generating class diagram...", total=None)
                diagram_code = diagram_gen.generate_class_diagram(
                    parsed_files,
                    max_classes=25
                )
                progress.update(task3, completed=True)

            elif diagram_type == "dataflow":
                task2 = progress.add_task("[cyan]Parsing files...", total=None)
                parser = CodeParser()
                parsed_files = {}

                sample_files = list(file_graph.nodes())[:30]
                for file_path in sample_files:
                    try:
                        parsed = parser.parse_file(file_path)
                        parsed_files[file_path] = parsed
                    except Exception:
                        pass

                progress.update(task2, completed=True)

                task3 = progress.add_task("[cyan]Extracting data flow...", total=None)
                dataflow_info = dataflow_gen.extract_dataflow_from_parsed_files(
                    parsed_files,
                    max_entities=35
                )
                progress.update(task3, completed=True)

                task4 = progress.add_task("[cyan]Generating dataflow diagram...", total=None)
                diagram_code = dataflow_gen.generate_dataflow_diagram(
                    dataflow_info['entities'],
                    dataflow_info['transformations'],
                    dataflow_info['external_systems']
                )
                progress.update(task4, completed=True)

            else:
                console.print(f"[red]Error:[/red] Unknown diagram type: {diagram_type}")
                console.print("[yellow]Supported types:[/yellow] architecture, dependency, class, dataflow")
                raise typer.Exit(1)

        # Determine output path
        if output is None:
            output = Path(f"{diagram_type}.mmd")

        # Write diagram
        output.write_text(diagram_code)

        # Success message
        console.print(f"\\n[green]✓[/green] Diagram generated: {output}")
        console.print(f"[dim]Lines:[/dim] {len(diagram_code.splitlines())}")
        console.print(f"[dim]Size:[/dim] {len(diagram_code)} chars")

        # Viewing instructions
        console.print("\\n[cyan]How to view:[/cyan]")
        console.print("  1. Visit https://mermaid.live")
        console.print(f"  2. Copy contents of {output}")
        console.print("  3. Paste and view rendered diagram")
        console.print("")

    except Exception as e:
        console.print(f"\\n[bold red]Error:[/bold red] {e}")
        logger.exception("Diagram generation failed")
        raise typer.Exit(1)


@diagram_app.command("list")
def list_diagrams_command():
    """
    List available diagram types and their descriptions.

    Examples:
        assistant diagram list
    """
    console.print("[bold cyan]Available Diagram Types[/bold cyan]\\n")

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Type")
    table.add_column("Description")
    table.add_column("Best For")

    table.add_row(
        "architecture",
        "High-level module structure",
        "Understanding overall system design"
    )

    table.add_row(
        "dependency",
        "File/module dependencies",
        "Finding tightly coupled components"
    )

    table.add_row(
        "class",
        "OOP structure with inheritance",
        "Understanding class relationships"
    )

    table.add_row(
        "dataflow",
        "Data movement through system",
        "Tracing data transformations"
    )

    console.print(table)

    console.print("\\n[cyan]Example usage:[/cyan]")
    console.print("  assistant diagram generate architecture")
    console.print("  assistant diagram generate dependency --max-nodes 50")
    console.print("")


# Export the Typer app
__all__ = ['diagram_app']
