"""Documentation generation command.

This module provides the main CLI command for generating comprehensive
repository documentation using the CodeWiki integration.
"""

import asyncio
from pathlib import Path
from typing import Optional, Dict
import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.panel import Panel
from rich.table import Table

from coding_assistant.documentation.graph.dependency_builder import DependencyGraphBuilder
from coding_assistant.documentation.graph.module_analyzer import ModuleAnalyzer
from coding_assistant.documentation.decomposition.partitioner import HierarchicalPartitioner
from coding_assistant.documentation.decomposition.context_preserver import ContextPreserver
from coding_assistant.documentation.agents.coordinator import MultiAgentCoordinator
from coding_assistant.documentation.agents.synthesizer import DocumentationSynthesizer
from coding_assistant.documentation.generators.diagram_generator import MermaidDiagramGenerator
from coding_assistant.documentation.generators.dataflow_generator import DataFlowGenerator
from coding_assistant.codebase.parser import CodeParser
from coding_assistant.utils.logger import get_logger

logger = get_logger(__name__)
console = Console()

# Create Typer app for document subcommands
document_app = typer.Typer(
    name="document",
    help="Generate comprehensive documentation for the codebase",
    no_args_is_help=True
)


@document_app.command("generate")
def generate_command(
    output_dir: Path = typer.Option(
        "./docs/generated",
        "--output",
        "-o",
        help="Output directory for documentation"
    ),
    codebase_path: Optional[Path] = typer.Option(
        None,
        "--path",
        "-p",
        help="Path to codebase (default: current directory)"
    ),
    include_diagrams: bool = typer.Option(
        True,
        "--diagrams/--no-diagrams",
        help="Include visual diagrams"
    ),
    max_agents: int = typer.Option(
        3,
        "--agents",
        "-a",
        help="Maximum concurrent documentation agents"
    ),
    format_type: str = typer.Option(
        "markdown",
        "--format",
        "-f",
        help="Output format (markdown, html)"
    ),
):
    """
    Generate comprehensive documentation for the codebase.

    This command uses the CodeWiki integration to:
    - Analyze code structure and dependencies
    - Partition repository into logical modules
    - Generate documentation using parallel LLM agents
    - Create visual diagrams (architecture, dependencies, etc.)
    - Synthesize repository overview

    Examples:
        assistant document generate
        assistant document generate --output ./docs
        assistant document generate --agents 5 --no-diagrams
    """
    asyncio.run(_generate_documentation_async(
        output_dir=output_dir,
        codebase_path=codebase_path or Path.cwd(),
        include_diagrams=include_diagrams,
        max_agents=max_agents,
        format_type=format_type
    ))


async def _generate_documentation_async(
    output_dir: Path,
    codebase_path: Path,
    include_diagrams: bool,
    max_agents: int,
    format_type: str
):
    """Generate documentation asynchronously."""

    console.print(Panel.fit(
        "[bold cyan]CodeWiki Documentation Generation[/bold cyan]\\n"
        f"Analyzing: {codebase_path}",
        border_style="cyan"
    ))

    try:
        # Phase 1: Build dependency graph
        console.print("\\n[bold]Phase 1: Code Analysis[/bold]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:

            task1 = progress.add_task("[cyan]Building dependency graph...", total=None)
            builder = DependencyGraphBuilder(codebase_path)
            file_graph = builder.build_file_graph()
            module_graph = builder.build_module_graph(file_graph)
            progress.update(task1, completed=True)

            task2 = progress.add_task("[cyan]Detecting modules...", total=None)
            analyzer = ModuleAnalyzer(file_graph)
            modules = analyzer.detect_modules()
            progress.update(task2, completed=True)

            task3 = progress.add_task("[cyan]Computing metrics...", total=None)
            metrics = builder.compute_metrics(file_graph)
            progress.update(task3, completed=True)

        console.print(f"[green]✓[/green] Analyzed {file_graph.number_of_nodes()} files, "
                     f"detected {len(modules)} modules\\n")

        # Phase 2: Partition repository
        console.print("[bold]Phase 2: Repository Partitioning[/bold]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:

            task1 = progress.add_task("[cyan]Partitioning repository...", total=None)

            file_sizes = {
                node: file_graph.nodes[node].get('line_count', 0)
                for node in file_graph.nodes()
            }

            partitioner = HierarchicalPartitioner(
                max_partition_size=2000,
                min_partition_size=100,
                min_cohesion=0.3
            )

            partitions = partitioner.partition(file_graph, file_sizes, modules)
            progress.update(task1, completed=True)

            task2 = progress.add_task("[cyan]Extracting context...", total=None)

            preserver = ContextPreserver()
            contexts = {}

            for partition in partitions:
                context = preserver.extract_context(partition, partitions, file_graph)
                contexts[partition.name] = context

            progress.update(task2, completed=True)

        console.print(f"[green]✓[/green] Created {len(partitions)} partitions with architectural context\\n")

        # Phase 3: Generate documentation
        console.print("[bold]Phase 3: Documentation Generation[/bold]")

        coordinator = MultiAgentCoordinator(
            max_concurrent_agents=max_agents,
            use_async=True
        )

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console
        ) as progress:

            task = progress.add_task(
                "[cyan]Generating module documentation...",
                total=len(partitions)
            )

            # Parse files for detailed documentation
            parser = CodeParser()
            parsed_files = {}

            for partition in partitions:
                for file_path in partition.files[:10]:  # Limit files per partition
                    try:
                        parsed = parser.parse_file(file_path)
                        parsed_files[file_path] = parsed
                    except Exception as e:
                        logger.debug(f"Failed to parse {file_path}: {e}")

            # Generate module documentation
            module_docs = await coordinator.generate_documentation(
                partitions,
                contexts,
                parsed_files
            )

            progress.update(task, completed=len(partitions))

        stats = coordinator.get_completion_stats()
        console.print(f"[green]✓[/green] Generated documentation for {stats['completed']}/{stats['total']} modules "
                     f"({stats['completion_rate']:.0%} success rate)\\n")

        # Phase 4: Generate diagrams
        diagrams = {}

        if include_diagrams:
            console.print("[bold]Phase 4: Diagram Generation[/bold]")

            diagram_gen = MermaidDiagramGenerator()
            dataflow_gen = DataFlowGenerator()

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:

                task1 = progress.add_task("[cyan]Generating architecture diagram...", total=None)
                diagrams['architecture'] = diagram_gen.generate_architecture_diagram(
                    partitions,
                    file_graph,
                    direction="TB"
                )
                progress.update(task1, completed=True)

                task2 = progress.add_task("[cyan]Generating dependency graph...", total=None)
                diagrams['dependencies'] = diagram_gen.generate_dependency_graph(
                    file_graph,
                    max_nodes=40,
                    show_files=True
                )
                progress.update(task2, completed=True)

                if parsed_files:
                    task3 = progress.add_task("[cyan]Generating class diagram...", total=None)
                    diagrams['classes'] = diagram_gen.generate_class_diagram(
                        parsed_files,
                        max_classes=20
                    )
                    progress.update(task3, completed=True)

                    task4 = progress.add_task("[cyan]Generating data flow diagram...", total=None)
                    dataflow_info = dataflow_gen.extract_dataflow_from_parsed_files(
                        parsed_files,
                        max_entities=30
                    )

                    if dataflow_info['entities'] or dataflow_info['transformations']:
                        diagrams['dataflow'] = dataflow_gen.generate_dataflow_diagram(
                            dataflow_info['entities'],
                            dataflow_info['transformations'],
                            dataflow_info['external_systems']
                        )
                        progress.update(task4, completed=True)

            console.print(f"[green]✓[/green] Generated {len(diagrams)} diagrams\\n")

        # Phase 5: Synthesize overview
        console.print("[bold]Phase 5: Repository Overview[/bold]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:

            task = progress.add_task("[cyan]Synthesizing repository overview...", total=None)

            synthesizer = DocumentationSynthesizer()

            repo_metadata = {
                'name': codebase_path.name,
                'path': str(codebase_path),
                'total_files': file_graph.number_of_nodes(),
                'total_modules': len(modules),
                'total_partitions': len(partitions)
            }

            overview = await synthesizer.synthesize_overview(
                module_docs,
                partitions,
                repo_metadata
            )

            progress.update(task, completed=True)

        console.print(f"[green]✓[/green] Repository overview synthesized\\n")

        # Phase 6: Write output
        console.print("[bold]Phase 6: Writing Documentation[/bold]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:

            task = progress.add_task("[cyan]Writing documentation files...", total=None)

            from coding_assistant.documentation.writers.markdown_writer import MarkdownWriter

            writer = MarkdownWriter(output_dir)

            written_files = writer.write_documentation(
                overview=overview,
                module_docs=module_docs,
                diagrams=diagrams,
                partitions=partitions,
                repo_metadata=repo_metadata
            )

            progress.update(task, completed=True)

        console.print(f"[green]✓[/green] Wrote {len(written_files)} documentation files\\n")

        # Success summary
        console.print("\\n" + "=" * 70)
        console.print("[bold green]Documentation Generation Complete![/bold green]")
        console.print("=" * 70)

        summary_table = Table(show_header=False, box=None, padding=(0, 2))
        summary_table.add_column("Metric", style="cyan")
        summary_table.add_column("Value", style="green")

        summary_table.add_row("Output Directory", str(output_dir))
        summary_table.add_row("Files Analyzed", str(file_graph.number_of_nodes()))
        summary_table.add_row("Modules Detected", str(len(modules)))
        summary_table.add_row("Partitions Created", str(len(partitions)))
        summary_table.add_row("Module Docs Generated", f"{stats['completed']}/{stats['total']}")
        summary_table.add_row("Diagrams Generated", str(len(diagrams)))
        summary_table.add_row("Documentation Files", str(len(written_files)))

        console.print("\\n")
        console.print(summary_table)

        console.print(f"\\n[cyan]View documentation:[/cyan] {output_dir}/README.md")
        console.print(f"[dim]Or run:[/dim] [yellow]assistant serve-docs --dir {output_dir}[/yellow]\\n")

    except Exception as e:
        console.print(f"\\n[bold red]Error:[/bold red] {e}")
        logger.exception("Documentation generation failed")
        raise typer.Exit(1)


@document_app.command("status")
def status_command(
    output_dir: Path = typer.Option(
        "./docs/generated",
        "--output",
        "-o",
        help="Documentation output directory"
    ),
):
    """
    Show status of generated documentation.

    Examples:
        assistant document status
        assistant document status --output ./docs
    """
    console.print(f"[bold cyan]Documentation Status[/bold cyan]\\n")

    if not output_dir.exists():
        console.print(f"[yellow]⚠[/yellow] Documentation directory does not exist: {output_dir}")
        console.print(f"[dim]Run:[/dim] [cyan]assistant document generate[/cyan] to create documentation\\n")
        return

    # Count documentation files
    md_files = list(output_dir.glob("**/*.md"))
    diagram_files = list(output_dir.glob("**/*.mmd"))

    status_table = Table(show_header=True, header_style="bold magenta")
    status_table.add_column("Item")
    status_table.add_column("Count", justify="right")

    status_table.add_row("Markdown Files", str(len(md_files)))
    status_table.add_row("Diagram Files", str(len(diagram_files)))
    status_table.add_row("Total Files", str(len(md_files) + len(diagram_files)))

    console.print(status_table)

    console.print(f"\\n[cyan]Location:[/cyan] {output_dir}")

    if (output_dir / "README.md").exists():
        console.print(f"[green]✓[/green] Repository overview available")
        console.print(f"[dim]View:[/dim] {output_dir}/README.md\\n")
    else:
        console.print(f"[yellow]⚠[/yellow] README.md not found\\n")


# Export the Typer app
__all__ = ['document_app']
