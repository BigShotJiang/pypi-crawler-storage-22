"""Explain command - Explain how code works with enhanced context."""

import typer
from rich.console import Console
from rich.syntax import Syntax
from rich.panel import Panel
from pathlib import Path
from typing import Optional

from coding_assistant.config.settings import settings
from coding_assistant.context.enhanced_retriever import EnhancedSemanticRetriever
from coding_assistant.llm.client import LLMClientFactory
from coding_assistant.llm.prompts import PromptBuilder
from coding_assistant.codebase.parser import CodeParser

console = Console()


def explain_command(
    target: str = typer.Argument(..., help="File path or file::function to explain"),
    context_size: int = typer.Option(
        5,
        "--context",
        "-c",
        help="Number of related code chunks to include"
    ),
    detailed: bool = typer.Option(
        False,
        "--detailed",
        "-d",
        help="Provide detailed explanation with examples"
    ),
):
    """Explain how code works with intelligent context.

    Examples:
      assistant explain src/auth/login.py
      assistant explain src/auth/login.py::authenticate_user
      assistant explain src/utils.py --detailed
    """

    console.print("\n🔍 [bold cyan]Code Explanation[/bold cyan]\n")

    # Parse target (file or file::function)
    if '::' in target:
        file_path, function_name = target.split('::', 1)
    else:
        file_path = target
        function_name = None

    file_path = Path(file_path)

    # Check if file exists
    if not file_path.exists():
        console.print(f"[red]✗ File not found: {file_path}[/red]")
        raise typer.Exit(1)

    # Read the code
    try:
        code = file_path.read_text(encoding='utf-8')
    except Exception as e:
        console.print(f"[red]✗ Error reading file: {e}[/red]")
        raise typer.Exit(1)

    # If function specified, try to extract it
    target_code = code
    if function_name:
        parser = CodeParser()
        try:
            parsed = parser.parse_file(str(file_path), code)

            # Find the function
            found = False
            for chunk in parsed.get('chunks', []):
                if chunk.get('name') == function_name:
                    target_code = chunk['content']
                    found = True
                    console.print(f"[dim]Found function: {function_name}[/dim]\n")
                    break

            if not found:
                console.print(f"[yellow]⚠️  Function '{function_name}' not found, explaining entire file[/yellow]\n")
        except:
            console.print(f"[yellow]⚠️  Could not parse file, explaining entire content[/yellow]\n")

    # Show the code we're explaining
    console.print(Panel(
        Syntax(target_code[:500] + ("..." if len(target_code) > 500 else ""),
               "python" if file_path.suffix == '.py' else "javascript",
               theme="monokai",
               line_numbers=True),
        title=f"Code to Explain: {file_path.name}" + (f"::{function_name}" if function_name else ""),
        border_style="blue"
    ))

    # Get relevant context using enhanced retrieval
    context_chunks = []
    try:
        with console.status("[bold green]Finding relevant context..."):
            retriever = EnhancedSemanticRetriever(settings.project_path)

            # Check if indexed
            stats = retriever.get_stats()
            if stats['total_chunks'] > 0:
                # Search for related code
                query = f"code related to {file_path.name}" + (f" {function_name}" if function_name else "")

                results = retriever.retrieve(
                    query=query,
                    k=context_size,
                    current_file=str(file_path),
                    language='python' if file_path.suffix == '.py' else 'javascript',
                    use_hybrid=True,
                    use_ranking=True
                )

                if settings.verbose and results:
                    console.print("\n[dim]Related code found:[/dim]")
                    for r in results:
                        console.print(f"[dim]  • {r['path']} - {r['name']} (score: {r['rank_score']:.2f})[/dim]")
                    console.print()

                context_chunks = results
            else:
                console.print("[yellow]⚠️  Codebase not indexed. Run 'assistant index' for better context.[/yellow]\n")

    except Exception as e:
        if settings.verbose:
            console.print(f"[yellow]⚠️  Could not retrieve context: {e}[/yellow]\n")

    # Build explanation prompt
    prompt_builder = PromptBuilder()

    system_prompt = """You are an expert code reviewer and educator. Your task is to explain code clearly and thoroughly.

When explaining code:
1. Start with a high-level overview of what the code does
2. Explain the main components and their purposes
3. Highlight important logic and design decisions
4. Point out any potential issues or improvements
5. Use clear, concise language suitable for developers

If the code uses specific patterns or frameworks, mention them."""

    if detailed:
        system_prompt += """

Provide a detailed explanation including:
- Step-by-step walkthrough of the logic
- Example inputs and outputs
- Edge cases handled
- Dependencies and integrations
- Best practices applied or missing"""

    # Build context section
    context_text = f"# Code to Explain\n\nFile: `{file_path}`\n"
    if function_name:
        context_text += f"Function: `{function_name}`\n"
    context_text += f"\n```{file_path.suffix[1:] if file_path.suffix else 'text'}\n{target_code}\n```\n\n"

    # Add related code context
    if context_chunks:
        context_text += "# Related Code (for context)\n\n"
        for chunk in context_chunks[:3]:  # Limit to top 3
            context_text += f"## {chunk['path']}\n"
            context_text += f"```{chunk.get('language', 'text')}\n{chunk['content'][:300]}...\n```\n\n"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": context_text + "\nPlease explain this code."}
    ]

    # Get LLM client
    llm = LLMClientFactory.create_client(settings.llm_provider)

    # Generate explanation
    console.print("[bold blue]Explanation:[/bold blue]\n")

    try:
        response_text = ""
        for chunk in llm.generate(messages, stream=True):
            console.print(chunk, end="")
            response_text += chunk
        console.print("\n")

        # Show helpful tips
        if not detailed:
            console.print("[dim]💡 Tip: Use --detailed for a more thorough explanation[/dim]")

    except Exception as e:
        console.print(f"\n[red]✗ Error generating explanation: {e}[/red]")
        raise typer.Exit(1)
