"""Fix command - Fix linting issues and bugs."""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from pathlib import Path
from typing import Optional

from coding_assistant.config.settings import settings
from coding_assistant.operations.validator import SyntaxValidator
from coding_assistant.operations.linter import LinterIntegration
from coding_assistant.operations.generator import CodeGenerator
from coding_assistant.operations.differ import DiffGenerator
from coding_assistant.llm.client import LLMClientFactory

console = Console()


def fix_command(
    file_path: str = typer.Argument(..., help="File path to fix"),
    error: Optional[str] = typer.Option(
        None,
        "--error",
        "-e",
        help="Specific error message to fix"
    ),
    auto_apply: bool = typer.Option(
        False,
        "--auto-apply",
        "-y",
        help="Apply fixes without confirmation"
    ),
    lint_only: bool = typer.Option(
        False,
        "--lint-only",
        help="Only fix linting issues (no AI fixes)"
    ),
):
    """Fix linting issues and bugs in code.

    The fix process:
    1. Validate syntax
    2. Run linter to find issues
    3. Try auto-fix for linting issues
    4. If error specified, get AI fix
    5. Validate fixed code
    6. Show diff
    7. Apply with confirmation

    Examples:
      assistant fix src/module.py
      assistant fix src/auth.py --error "TypeError: expected str, got int"
      assistant fix src/utils.py --lint-only --auto-apply
    """

    console.print("\n🔧 [bold cyan]Fix Code Issues[/bold cyan]\n")

    file_path_obj = Path(file_path)

    # Check file exists
    if not file_path_obj.exists():
        console.print(f"[red]✗ File not found: {file_path}[/red]")
        raise typer.Exit(1)

    # Detect language
    language_map = {
        '.py': 'python',
        '.js': 'javascript',
        '.ts': 'typescript',
        '.jsx': 'jsx',
        '.tsx': 'tsx'
    }
    language = language_map.get(file_path_obj.suffix, 'python')

    # Read original code
    try:
        original_code = file_path_obj.read_text(encoding='utf-8')
    except Exception as e:
        console.print(f"[red]✗ Error reading file: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"[bold]File:[/bold] {file_path}")
    console.print(f"[dim]Language: {language}[/dim]\n")

    # Step 1: Validate syntax
    console.print("[bold]1. Validating syntax...[/bold]")
    validator = SyntaxValidator()
    validation_result = validator.validate(original_code, language)

    if not validation_result.is_valid:
        console.print(f"[red]✗ Syntax error at line {validation_result.line}:[/red]")
        console.print(f"[red]  {validation_result.error_message}[/red]\n")

        if lint_only:
            console.print("[yellow]Cannot auto-fix syntax errors with --lint-only.[/yellow]")
            console.print("[yellow]Use without --lint-only to get AI-powered fix.[/yellow]\n")
            raise typer.Exit(1)

        # Will need AI fix
        error = error or validation_result.error_message
    else:
        console.print("[green]✓ Syntax valid[/green]\n")

    # Step 2: Run linter
    console.print("[bold]2. Running linter...[/bold]")
    linter = LinterIntegration(project_root=str(settings.project_path))
    lint_result = linter.lint(original_code, language, auto_fix=True)

    if lint_result.error_count == 0 and lint_result.warning_count == 0:
        console.print("[green]✓ No linting issues found[/green]\n")

        if not error:
            console.print("[green]✓ Code is clean! No fixes needed.[/green]\n")
            return
    else:
        console.print(f"[yellow]Found {lint_result.error_count} errors, {lint_result.warning_count} warnings[/yellow]")
        linter.display_issues(lint_result)
        console.print()

    # Step 3: Apply auto-fixes
    fixed_code = original_code

    if lint_result.fixed_code:
        console.print("[bold]3. Applying linter auto-fixes...[/bold]")
        fixed_code = lint_result.fixed_code
        console.print("[green]✓ Auto-fixed linting issues[/green]\n")

        # If lint-only mode and we have fixes, show and apply
        if lint_only:
            differ = DiffGenerator()
            diff = differ.generate_diff(original_code, fixed_code, file_path)
            differ.display_diff(diff, title="Linting Fixes")

            if not auto_apply:
                if not typer.confirm("\nApply these fixes?"):
                    console.print("[yellow]Cancelled.[/yellow]\n")
                    raise typer.Exit(0)

            file_path_obj.write_text(fixed_code, encoding='utf-8')
            console.print(f"\n[green]✓ Fixes applied to {file_path}[/green]\n")
            return

    # Step 4: AI-powered fix (if error specified or syntax invalid)
    if error and not lint_only:
        console.print(f"[bold]4. Getting AI fix for error...[/bold]")
        console.print(f"[dim]Error: {error}[/dim]\n")

        llm = LLMClientFactory.create_client(settings.llm_provider)

        system_prompt = f"""You are an expert {language} debugger and code fixer.

Your task: Fix the code error while preserving functionality.

Guidelines:
- Fix ONLY the specific error mentioned
- Preserve all other functionality
- Follow {language} best practices
- Add comments explaining the fix if needed
- Return ONLY the fixed code in a code block
- Do not include explanations outside the code block"""

        user_prompt = f"""Fix this {language} code error:

Error: {error}

Code:
```{language}
{fixed_code}
```

Please provide the fixed code."""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        # Get fix from LLM
        with console.status("[bold green]Generating fix..."):
            try:
                response = ""
                for chunk in llm.generate(messages, stream=False):
                    response += chunk
            except Exception as e:
                console.print(f"[red]✗ Error generating fix: {e}[/red]")
                raise typer.Exit(1)

        # Extract fixed code
        generator = CodeGenerator()
        blocks = generator.extract_code_blocks(response, validate=True)

        if not blocks:
            console.print("[red]✗ No code found in fix response[/red]")
            raise typer.Exit(1)

        ai_fixed_code = blocks[0].code

        # Validate AI fix
        validation_result = validator.validate(ai_fixed_code, language)
        if not validation_result.is_valid:
            console.print(f"[red]✗ AI-generated fix has syntax errors:[/red]")
            console.print(f"[red]  {validation_result.error_message}[/red]")
            raise typer.Exit(1)

        fixed_code = ai_fixed_code
        console.print("[green]✓ AI fix generated and validated[/green]\n")

    # Step 5: Show diff and apply
    if fixed_code != original_code:
        console.print("[bold]Changes Preview:[/bold]\n")
        differ = DiffGenerator()
        diff = differ.generate_diff(original_code, fixed_code, file_path)
        differ.display_diff(diff, title=f"Fixes for {file_path_obj.name}")

        stats = differ.get_change_stats(diff)
        console.print(f"\n[dim]Lines changed: {stats['lines_added'] + stats['lines_removed']}[/dim]\n")

        # Confirm
        if not auto_apply:
            if not typer.confirm("Apply these fixes?"):
                console.print("[yellow]Cancelled. No changes made.[/yellow]\n")
                raise typer.Exit(0)

        # Apply
        try:
            file_path_obj.write_text(fixed_code, encoding='utf-8')
            console.print(f"\n[bold green]✓ Fixes applied to {file_path}[/bold green]\n")

            # Verify fix worked
            console.print("[bold]Verifying fix...[/bold]")
            final_validation = validator.validate(fixed_code, language)
            final_lint = linter.lint(fixed_code, language, auto_fix=False)

            if final_validation.is_valid:
                console.print("[green]✓ Syntax valid[/green]")

            if final_lint.error_count == 0:
                console.print("[green]✓ No linting errors[/green]")
            else:
                console.print(f"[yellow]⚠️  Still has {final_lint.error_count} linting issues[/yellow]")

            console.print()

        except Exception as e:
            console.print(f"[red]✗ Error writing file: {e}[/red]")
            raise typer.Exit(1)
    else:
        console.print("[green]No changes needed![/green]\n")
