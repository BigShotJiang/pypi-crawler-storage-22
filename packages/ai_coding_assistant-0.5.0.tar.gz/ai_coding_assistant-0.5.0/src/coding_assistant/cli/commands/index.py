"""Index command - Index codebase for semantic search."""

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table

from coding_assistant.config.settings import settings
from coding_assistant.context.enhanced_retriever import EnhancedSemanticRetriever

console = Console()


def index_command(
    max_files: int = typer.Option(
        100,
        "--max-files",
        "-m",
        help="Maximum number of files to index"
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Force re-index (clear existing index)"
    ),
    stats: bool = typer.Option(
        False,
        "--stats",
        "-s",
        help="Show index statistics only (don't index)"
    ),
):
    """Index your codebase for semantic search with smart chunking.

    This command:
    - Crawls your codebase
    - Chunks code at function/class level
    - Generates embeddings
    - Builds vector + BM25 search index

    Examples:
      assistant index
      assistant index --force --max-files 200
      assistant index --stats
    """

    console.print("\n📚 [bold cyan]Codebase Indexing[/bold cyan]\n")

    # Initialize retriever
    try:
        retriever = EnhancedSemanticRetriever(settings.project_path)
    except Exception as e:
        console.print(f"[red]✗ Error initializing retriever: {e}[/red]")
        raise typer.Exit(1)

    # If just showing stats
    if stats:
        try:
            stats_data = retriever.get_stats()

            # Create stats table
            table = Table(title="Index Statistics", show_header=True, header_style="bold magenta")
            table.add_column("Metric", style="cyan")
            table.add_column("Value", justify="right", style="green")

            table.add_row("Total Chunks", str(stats_data.get('total_chunks', 0)))
            table.add_row("Indexed Chunks", str(stats_data.get('indexed_chunks', 0)))
            table.add_row("Embedding Dimension", str(stats_data.get('embedding_dimension', 0)))
            table.add_row("Hybrid Search", "✓" if stats_data.get('hybrid_search_enabled') else "✗")
            table.add_row("Vector Store Size", str(stats_data.get('vector_store_count', 0)))

            console.print(table)
            console.print()

            if stats_data.get('total_chunks', 0) == 0:
                console.print("[yellow]⚠️  Codebase not indexed yet. Run 'assistant index' to index.[/yellow]\n")
            else:
                console.print(f"[green]✓ Index is ready for search![/green]\n")

            return
        except Exception as e:
            console.print(f"[red]✗ Error getting stats: {e}[/red]")
            raise typer.Exit(1)

    # Clear if force flag
    if force:
        console.print("[yellow]Clearing existing index...[/yellow]")
        try:
            retriever.clear_index()
            console.print("[green]✓ Index cleared[/green]\n")
        except Exception as e:
            console.print(f"[yellow]⚠️  Could not clear index: {e}[/yellow]\n")

    # Check if already indexed (unless force)
    if not force:
        try:
            stats_data = retriever.get_stats()
            if stats_data.get('total_chunks', 0) > 0:
                console.print(f"[yellow]⚠️  Codebase already indexed ({stats_data['total_chunks']} chunks).[/yellow]")
                console.print("[yellow]   Use --force to re-index.[/yellow]\n")

                if not typer.confirm("Continue anyway?"):
                    console.print("[dim]Cancelled.[/dim]")
                    raise typer.Exit(0)
                console.print()
        except:
            pass

    # Index with progress bar
    console.print(f"[bold]Indexing up to {max_files} files...[/bold]")
    console.print("[dim]This may take a minute for large codebases...[/dim]\n")

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
            transient=False
        ) as progress:

            task = progress.add_task("[cyan]Indexing codebase...", total=100)

            # Index codebase
            retriever.index_codebase(max_files=max_files, force_reindex=force)

            progress.update(task, completed=100)

        # Get final stats
        stats_data = retriever.get_stats()

        # Success message
        console.print(f"\n[bold green]✓ Indexing complete![/bold green]\n")

        # Show stats table
        table = Table(show_header=False, box=None)
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right", style="bold green")

        table.add_row("Total chunks indexed", str(stats_data['total_chunks']))
        table.add_row("Indexed chunks", str(stats_data.get('indexed_chunks', stats_data['total_chunks'])))
        table.add_row("Embedding dimension", str(stats_data['embedding_dimension']))
        table.add_row("Hybrid search", "✓ Enabled" if stats_data.get('hybrid_search_enabled') else "✗ Disabled")

        console.print(table)
        console.print()

        # Next steps
        console.print("[bold]Next steps:[/bold]")
        console.print("  • Search: [cyan]assistant search 'your query'[/cyan]")
        console.print("  • Ask: [cyan]assistant ask 'your question'[/cyan]")
        console.print("  • Explain: [cyan]assistant explain path/to/file.py[/cyan]")
        console.print()

    except Exception as e:
        console.print(f"\n[red]✗ Indexing failed: {e}[/red]")
        if settings.verbose:
            import traceback
            traceback.print_exc()
        raise typer.Exit(1)
