"""Refactor command - Refactor code with validation and preview."""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from pathlib import Path
from typing import Optional

from coding_assistant.config.settings import settings
from coding_assistant.context.enhanced_retriever import EnhancedSemanticRetriever
from coding_assistant.operations.generator import CodeGenerator
from coding_assistant.operations.validator import SyntaxValidator
from coding_assistant.operations.linter import LinterIntegration
from coding_assistant.operations.differ import DiffGenerator
from coding_assistant.llm.client import LLMClientFactory

console = Console()


def refactor_command(
    target: str = typer.Argument(..., help="File path or file::function to refactor"),
    strategy: str = typer.Option(
        "improve readability and efficiency",
        "--strategy",
        "-s",
        help="Refactoring strategy"
    ),
    auto_apply: bool = typer.Option(
        False,
        "--auto-apply",
        "-y",
        help="Apply changes without confirmation"
    ),
    run_linter: bool = typer.Option(
        True,
        "--lint/--no-lint",
        help="Run linter on refactored code"
    ),
):
    """Refactor code with AI assistance, validation, and preview.

    The refactoring process:
    1. Read original code
    2. Get LLM refactoring suggestion
    3. Extract and validate refactored code
    4. Run linter (optional)
    5. Show diff preview
    6. Ask for confirmation (unless --auto-apply)
    7. Apply changes

    Examples:
      assistant refactor src/utils.py
      assistant refactor src/auth.py --strategy "extract helper functions"
      assistant refactor src/module.py::process_data --auto-apply
    """

    console.print("\n🔧 [bold cyan]Code Refactoring[/bold cyan]\n")

    # Parse target
    if '::' in target:
        file_path_str, function_name = target.split('::', 1)
    else:
        file_path_str = target
        function_name = None

    file_path = Path(file_path_str)

    # Check file exists
    if not file_path.exists():
        console.print(f"[red]✗ File not found: {file_path}[/red]")
        raise typer.Exit(1)

    # Detect language
    language_map = {
        '.py': 'python',
        '.js': 'javascript',
        '.ts': 'typescript',
        '.jsx': 'jsx',
        '.tsx': 'tsx'
    }
    language = language_map.get(file_path.suffix, 'python')

    # Read original code
    try:
        original_code = file_path.read_text(encoding='utf-8')
    except Exception as e:
        console.print(f"[red]✗ Error reading file: {e}[/red]")
        raise typer.Exit(1)

    # If function specified, extract it
    target_code = original_code
    if function_name:
        # TODO: Extract specific function
        console.print(f"[dim]Targeting function: {function_name}[/dim]")

    # Show original code preview
    console.print("[bold]Original Code:[/bold]")
    console.print(Panel(
        Syntax(original_code[:300] + ("..." if len(original_code) > 300 else ""),
               language, theme="monokai", line_numbers=True),
        title=str(file_path),
        border_style="dim"
    ))
    console.print()

    # Get context for better refactoring
    context_chunks = []
    try:
        retriever = EnhancedSemanticRetriever(settings.project_path)
        stats = retriever.get_stats()

        if stats['total_chunks'] > 0:
            with console.status("[bold green]Finding related code for context..."):
                results = retriever.retrieve(
                    query=f"code related to {file_path.name}",
                    k=3,
                    current_file=str(file_path),
                    language=language
                )
                context_chunks = results
    except:
        pass

    # Build refactoring prompt
    with console.status("[bold green]Generating refactoring suggestions..."):
        llm = LLMClientFactory.create_client(settings.llm_provider)

        system_prompt = f"""You are an expert code refactoring assistant.

Your task: Refactor the provided {language} code according to the strategy: "{strategy}"

Guidelines:
- Preserve functionality (same inputs → same outputs)
- Improve code quality, readability, and efficiency
- Follow {language} best practices
- Add helpful comments where appropriate
- Return ONLY the refactored code in a code block
- Do not include explanations outside the code block

Strategy: {strategy}"""

        user_prompt = f"""Refactor this {language} code:

```{language}
{target_code}
```
"""

        if context_chunks:
            user_prompt += "\n\nRelated code for context:\n"
            for chunk in context_chunks[:2]:
                user_prompt += f"\n```{chunk.get('language', language)}\n{chunk['content'][:200]}...\n```\n"

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        # Get refactored code
        try:
            response = ""
            for chunk in llm.generate(messages, stream=False):
                response += chunk
        except Exception as e:
            console.print(f"[red]✗ Error generating refactoring: {e}[/red]")
            raise typer.Exit(1)

    # Extract code blocks
    console.print("[bold green]✓[/bold green] Refactoring generated\n")

    generator = CodeGenerator()
    blocks = generator.extract_code_blocks(response, validate=True)

    if not blocks:
        console.print("[red]✗ No code found in refactoring response[/red]")
        console.print("[dim]Response was:[/dim]")
        console.print(response[:500])
        raise typer.Exit(1)

    refactored_code = blocks[0].code

    # Validate syntax
    console.print("[bold]Validating refactored code...[/bold]")
    validator = SyntaxValidator()
    validation_result = validator.validate(refactored_code, language)

    if not validation_result.is_valid:
        console.print(f"[red]✗ Refactored code has syntax errors:[/red]")
        console.print(f"[red]  Line {validation_result.line}: {validation_result.error_message}[/red]")
        console.print("\n[yellow]Refactoring failed. Original code unchanged.[/yellow]\n")
        raise typer.Exit(1)

    console.print("[green]✓ Syntax valid[/green]\n")

    # Run linter if requested
    if run_linter:
        console.print("[bold]Running linter...[/bold]")
        linter = LinterIntegration(project_root=str(settings.project_path))
        lint_result = linter.lint(refactored_code, language, auto_fix=True)

        if lint_result.error_count > 0:
            console.print(f"[yellow]⚠️  Found {lint_result.error_count} linting issues[/yellow]")
            linter.display_issues(lint_result)

            if lint_result.fixed_code:
                console.print("[green]✓ Auto-fixed linting issues[/green]")
                refactored_code = lint_result.fixed_code
        else:
            console.print("[green]✓ No linting issues[/green]")
        console.print()

    # Generate and show diff
    console.print("[bold]Changes Preview:[/bold]\n")
    differ = DiffGenerator()
    diff = differ.generate_diff(original_code, refactored_code, str(file_path))
    differ.display_diff(diff, title=f"Refactoring: {file_path}")

    stats = differ.get_change_stats(diff)
    console.print(f"\n[bold]Change Summary:[/bold]")
    console.print(f"  Lines added: [green]{stats['lines_added']}[/green]")
    console.print(f"  Lines removed: [red]{stats['lines_removed']}[/red]")
    console.print(f"  Net change: {stats['net_change']:+d}")
    console.print()

    # Ask for confirmation
    if not auto_apply:
        if not typer.confirm("Apply these changes?"):
            console.print("[yellow]Refactoring cancelled. No changes made.[/yellow]\n")
            raise typer.Exit(0)

    # Apply changes
    try:
        file_path.write_text(refactored_code, encoding='utf-8')
        console.print(f"\n[bold green]✓ Refactoring applied to {file_path}[/bold green]\n")

        # Show next steps
        console.print("[dim]Next steps:")
        console.print(f"  • Review: git diff {file_path}")
        console.print(f"  • Test: Run your tests")
        console.print(f"  • Commit: git commit -m 'Refactor {file_path.name}'[/dim]\n")

    except Exception as e:
        console.print(f"[red]✗ Error writing file: {e}[/red]")
        raise typer.Exit(1)
