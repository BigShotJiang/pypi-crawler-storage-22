"""Search command - Search codebase with hybrid search."""

import typer
from rich.console import Console
from rich.syntax import Syntax
from rich.table import Table
from rich.panel import Panel
from pathlib import Path
from typing import Optional

from coding_assistant.config.settings import settings
from coding_assistant.context.enhanced_retriever import EnhancedSemanticRetriever

console = Console()


def search_command(
    query: str = typer.Argument(..., help="Search query (natural language)"),
    limit: int = typer.Option(
        5,
        "--limit",
        "-l",
        help="Number of results to return"
    ),
    file_type: Optional[str] = typer.Option(
        None,
        "--type",
        "-t",
        help="Filter by file type (e.g., python, javascript)"
    ),
    directory: Optional[str] = typer.Option(
        None,
        "--dir",
        "-d",
        help="Filter by directory"
    ),
    show_content: bool = typer.Option(
        True,
        "--content/--no-content",
        help="Show code content in results"
    ),
):
    """Search your codebase with hybrid semantic + keyword search.

    Examples:
      assistant search "authentication implementation"
      assistant search "JWT validation" --type python
      assistant search "database queries" --dir src/db --limit 10
    """

    console.print("\n🔍 [bold cyan]Searching Codebase[/bold cyan]\n")
    console.print(f"Query: [bold]{query}[/bold]\n")

    # Initialize retriever
    try:
        retriever = EnhancedSemanticRetriever(settings.project_path)
    except Exception as e:
        console.print(f"[red]✗ Error initializing retriever: {e}[/red]")
        raise typer.Exit(1)

    # Check if indexed
    stats = retriever.get_stats()
    if stats['total_chunks'] == 0:
        console.print("[yellow]⚠️  Codebase not indexed.[/yellow]")
        console.print("[yellow]   Run 'assistant index' first to enable search.[/yellow]\n")
        raise typer.Exit(1)

    # Show search stats
    if settings.verbose:
        console.print(f"[dim]Index stats:[/dim]")
        console.print(f"[dim]  • Total chunks: {stats['total_chunks']}[/dim]")
        console.print(f"[dim]  • Hybrid search: {stats['hybrid_search_enabled']}[/dim]")
        console.print()

    # Perform search
    try:
        with console.status("[bold green]Searching..."):
            results = retriever.retrieve(
                query=query,
                k=limit * 2,  # Get more, then filter
                language=file_type,
                use_hybrid=True,
                use_ranking=True
            )

            # Apply filters
            if directory:
                dir_path = Path(directory)
                results = [r for r in results if str(dir_path) in r['path']]

            if file_type:
                results = [r for r in results if r.get('language') == file_type]

            # Limit results
            results = results[:limit]

    except Exception as e:
        console.print(f"[red]✗ Search error: {e}[/red]")
        if settings.verbose:
            import traceback
            traceback.print_exc()
        raise typer.Exit(1)

    # Display results
    if not results:
        console.print("[yellow]No results found.[/yellow]\n")
        console.print("[dim]Try:")
        console.print("  • Broadening your search query")
        console.print("  • Removing filters")
        console.print("  • Re-indexing with 'assistant index --force'[/dim]\n")
        return

    console.print(f"[bold green]✓ Found {len(results)} results[/bold green]\n")

    # Create results table
    table = Table(
        title=f"Search Results for: '{query}'",
        show_header=True,
        header_style="bold magenta",
        border_style="blue",
        show_lines=True
    )

    table.add_column("#", width=3, style="dim")
    table.add_column("File", style="cyan")
    table.add_column("Type", width=10)
    table.add_column("Name", style="bold")
    table.add_column("Score", width=8, justify="right")
    table.add_column("Lines", width=10, justify="center")

    for i, result in enumerate(results, 1):
        # Determine score color
        score = result.get('rank_score', result.get('similarity', 0.0))
        if score > 0.8:
            score_style = "bold green"
        elif score > 0.6:
            score_style = "yellow"
        else:
            score_style = "dim"

        table.add_row(
            str(i),
            result['path'],
            result.get('type', 'file'),
            result.get('name', '-'),
            f"[{score_style}]{score:.2f}[/{score_style}]",
            f"{result.get('start_line', 0)}-{result.get('end_line', 0)}"
        )

    console.print(table)
    console.print()

    # Show detailed content if requested
    if show_content:
        for i, result in enumerate(results[:3], 1):  # Show top 3 in detail
            console.print(f"[bold]Result {i}: {result['path']}[/bold]")

            # Show code with syntax highlighting
            code = result.get('content', '')
            if code:
                lang = result.get('language', 'text')
                syntax = Syntax(
                    code[:300] + ("..." if len(code) > 300 else ""),
                    lang if lang in ('python', 'javascript', 'typescript') else 'text',
                    theme="monokai",
                    line_numbers=True,
                    start_line=result.get('start_line', 1)
                )
                console.print(Panel(syntax, border_style="dim"))
            console.print()

        if len(results) > 3:
            console.print(f"[dim]... and {len(results) - 3} more results[/dim]")
            console.print(f"[dim]Use --no-content to see all results in table only[/dim]\n")

    # Show search tips
    console.print("[dim]💡 Search Tips:[/dim]")
    console.print("[dim]  • Use natural language: 'how to authenticate users'[/dim]")
    console.print("[dim]  • Or keywords: 'JWT token validation'[/dim]")
    console.print("[dim]  • Filter by type: --type python[/dim]")
    console.print("[dim]  • Filter by directory: --dir src/auth[/dim]")
    console.print("[dim]  • Increase results: --limit 20[/dim]\n")
