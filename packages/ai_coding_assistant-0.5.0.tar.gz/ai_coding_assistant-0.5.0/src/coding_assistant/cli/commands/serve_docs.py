"""Documentation server command.

This module provides a simple HTTP server for viewing generated
documentation locally.
"""

from pathlib import Path
import http.server
import socketserver
import webbrowser
import typer
from rich.console import Console
from rich.panel import Panel

console = Console()

# Create Typer app
serve_docs_app = typer.Typer(
    name="serve-docs",
    help="Serve documentation locally with HTTP server",
    no_args_is_help=True
)


@serve_docs_app.command()
def serve_command(
    docs_dir: Path = typer.Option(
        "./docs/generated",
        "--dir",
        "-d",
        help="Documentation directory to serve"
    ),
    port: int = typer.Option(
        8000,
        "--port",
        "-p",
        help="Server port"
    ),
    open_browser: bool = typer.Option(
        True,
        "--open/--no-open",
        help="Open browser automatically"
    ),
):
    """
    Serve documentation locally via HTTP.

    This command starts a simple HTTP server to view the generated
    documentation in a web browser. Markdown files will be served
    as plain text (for rendering, use a static site generator).

    Examples:
        assistant serve-docs
        assistant serve-docs --port 3000
        assistant serve-docs --dir ./my-docs --no-open
    """
    if not docs_dir.exists():
        console.print(f"[red]Error:[/red] Documentation directory not found: {docs_dir}")
        console.print(f"[dim]Run:[/dim] [cyan]assistant document generate[/cyan] first")
        raise typer.Exit(1)

    # Change to docs directory
    import os
    original_dir = os.getcwd()
    os.chdir(docs_dir)

    try:
        # Create HTTP server
        handler = http.server.SimpleHTTPRequestHandler

        # Custom handler to add basic routing
        class DocHandler(handler):
            def do_GET(self):
                # Redirect root to README.md
                if self.path == '/':
                    self.path = '/README.md'
                return super().do_GET()

            def log_message(self, format, *args):
                # Custom logging to console
                console.print(f"[dim]{args[0]}[/dim] - {args[1]} - {args[2]}")

        with socketserver.TCPServer(("", port), DocHandler) as httpd:
            url = f"http://localhost:{port}"

            console.print(Panel.fit(
                f"[bold cyan]Documentation Server Running[/bold cyan]\\n"
                f"URL: {url}\\n"
                f"Directory: {docs_dir.resolve()}",
                border_style="cyan"
            ))

            console.print("")
            console.print("[green]✓[/green] Server started successfully")
            console.print(f"[cyan]→[/cyan] Visit {url} in your browser")
            console.print("")
            console.print("[dim]Press Ctrl+C to stop the server[/dim]")
            console.print("")

            # Open browser if requested
            if open_browser:
                try:
                    webbrowser.open(url)
                    console.print("[green]✓[/green] Browser opened")
                except Exception:
                    pass

            # Serve forever
            httpd.serve_forever()

    except KeyboardInterrupt:
        console.print("\\n\\n[yellow]Server stopped[/yellow]")

    except OSError as e:
        if "Address already in use" in str(e):
            console.print(f"[red]Error:[/red] Port {port} is already in use")
            console.print(f"[dim]Try a different port:[/dim] [cyan]--port {port + 1}[/cyan]")
        else:
            console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    finally:
        # Change back to original directory
        os.chdir(original_dir)


# Export the Typer app
__all__ = ['serve_docs_app']
