"""Interactive REPL for the coding assistant."""

from typing import List, Dict, Optional
from pathlib import Path
import sys
import random

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.styles import Style
from prompt_toolkit.formatted_text import HTML
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax

from coding_assistant.config.settings import settings
from coding_assistant.llm.client import LLMClientFactory
from coding_assistant.llm.prompts import PromptBuilder
from coding_assistant.context.enhanced_retriever import EnhancedSemanticRetriever
from coding_assistant.storage.session import SessionManager


console = Console()

# Creative loading messages
THINKING_MESSAGES = [
    "🧠 Thinking...",
    "🍳 Cooking up a response...",
    "☕ Brewing ideas...",
    "🔮 Consulting the code oracle...",
    "🎯 Targeting the perfect answer...",
    "🚀 Launching neurons...",
    "🎨 Crafting a masterpiece...",
    "🔍 Searching the knowledge base...",
    "⚡ Charging up the response...",
    "🎪 Juggling bits and bytes...",
    "🌟 Manifesting brilliance...",
    "🧪 Mixing up some wisdom...",
    "🎵 Composing a reply...",
    "🏗️ Building the answer...",
    "🎲 Rolling for insight...",
]


class AssistantREPL:
    """Interactive REPL for multi-turn conversations."""

    def __init__(self, project_path: Optional[Path] = None, persist_session: bool = True):
        """Initialize REPL.

        Args:
            project_path: Path to project (defaults to current directory)
            persist_session: Whether to persist session to database
        """
        self.project_path = project_path or settings.project_path

        # Setup prompt session with history
        history_file = self.project_path / '.assistant_history'
        self.session = PromptSession(
            history=FileHistory(str(history_file)),
            auto_suggest=AutoSuggestFromHistory(),
        )

        # Chat history for context
        self.chat_history: List[Dict[str, str]] = []

        # Initialize components
        self.llm = LLMClientFactory.create_client(settings.llm_provider)
        self.prompt_builder = PromptBuilder()

        # Try to initialize retriever
        try:
            self.retriever = EnhancedSemanticRetriever(self.project_path)
            self.retriever_available = True
        except Exception:
            self.retriever = None
            self.retriever_available = False

        # Initialize session persistence
        self.persist_session = persist_session
        self.session_id: Optional[int] = None
        if persist_session:
            db_path = self.project_path / '.assistant' / 'sessions.db'
            self.session_manager = SessionManager(str(db_path))
            # Create new session
            self.session_id = self.session_manager.create_session(
                project_path=str(self.project_path),
                title="Interactive Session"
            )
        else:
            self.session_manager = None

        # REPL state
        self.running = True
        self.context_chunks: List[Dict] = []

    def get_prompt_message(self) -> HTML:
        """Get formatted prompt message."""
        return HTML('<ansigreen><b>assistant&gt;&gt;&gt;</b></ansigreen> ')

    def run(self):
        """Run the REPL loop."""
        # Show welcome message
        self.show_welcome()

        while self.running:
            try:
                # Get user input
                user_input = self.session.prompt(self.get_prompt_message())

                # Skip empty input
                if not user_input.strip():
                    continue

                # Handle special commands
                if user_input.startswith('/'):
                    self.handle_command(user_input)
                    continue

                # Process regular message
                self.process_message(user_input)

            except KeyboardInterrupt:
                console.print("\n[dim]Press Ctrl+D to exit[/dim]")
                continue

            except EOFError:
                # Ctrl+D pressed
                self.handle_exit()
                break

            except Exception as e:
                console.print(f"\n[red]Error: {e}[/red]")
                if settings.verbose:
                    import traceback
                    traceback.print_exc()

    def show_welcome(self):
        """Show welcome message."""
        welcome_text = """[bold cyan]AI Coding Assistant - Interactive Mode[/bold cyan]

[bold]Available Commands:[/bold]
  /help      Show this help message
  /clear     Clear screen
  /history   Show conversation history
  /context   Show current context
  /reset     Reset conversation
  /exit      Exit REPL

[dim]Type your questions or requests. Press Ctrl+D to exit.[/dim]
"""
        console.print(Panel(welcome_text, border_style="cyan"))
        console.print()

        # Show retriever status
        if not self.retriever_available:
            console.print("[yellow]⚠️  Codebase not indexed. Run 'assistant index' for better context.[/yellow]\n")

    def process_message(self, user_input: str):
        """Process a user message.

        Args:
            user_input: User's message
        """
        # Add user message to history
        self.chat_history.append({
            'role': 'user',
            'content': user_input
        })

        # Persist user message if session persistence enabled
        user_message_id = None
        if self.persist_session and self.session_manager and self.session_id:
            user_message_id = self.session_manager.add_message(
                self.session_id,
                'user',
                user_input
            )

        # Retrieve context if available
        if self.retriever_available and self.retriever:
            try:
                with console.status("[bold green]🔍 Searching codebase...[/bold green]", spinner="dots"):
                    results = self.retriever.retrieve(
                        query=user_input,
                        k=5,
                        use_hybrid=True,
                        use_ranking=True
                    )
                    self.context_chunks = results

                if settings.verbose:
                    console.print(f"[dim]✓ Retrieved {len(results)} relevant chunks[/dim]")

            except Exception as e:
                if settings.verbose:
                    console.print(f"[yellow]Context retrieval failed: {e}[/yellow]")
                self.context_chunks = []

        # Build prompt with context
        if self.context_chunks:
            # Convert chunks to file_contents format
            file_contents = []
            for chunk in self.context_chunks:
                file_contents.append({
                    'path': f"{chunk['path']}:{chunk['start_line']}-{chunk['end_line']}",
                    'content': chunk['content'],
                    'language': chunk.get('language', 'python')
                })

            # Build prompt with context
            system_msg = self.prompt_builder.build_system_prompt()
            user_msg = self.prompt_builder.build_ask_prompt(user_input, file_contents)[1]['content']

            messages = [
                {'role': 'system', 'content': system_msg},
                *self.chat_history[:-1],  # Previous conversation
                {'role': 'user', 'content': user_msg}  # Current with context
            ]
        else:
            # No context, just use chat history
            messages = [
                {'role': 'system', 'content': self.prompt_builder.build_system_prompt()},
                *self.chat_history
            ]

        # Generate response
        console.print()

        # Show creative thinking message
        thinking_msg = random.choice(THINKING_MESSAGES)

        try:
            response_text = ""
            first_chunk = True
            status_running = False

            # Create status context
            status = console.status(f"[bold cyan]{thinking_msg}[/bold cyan]", spinner="dots")
            status.start()
            status_running = True

            try:
                for chunk in self.llm.generate(messages, stream=True):
                    # Stop spinner on first chunk and start printing
                    if first_chunk:
                        status.stop()
                        status_running = False
                        first_chunk = False

                    console.print(chunk, end="")
                    response_text += chunk
            finally:
                # Ensure status is stopped
                if status_running:
                    status.stop()

            console.print("\n")

            # Add assistant response to history
            self.chat_history.append({
                'role': 'assistant',
                'content': response_text
            })

            # Persist assistant message if session persistence enabled
            assistant_message_id = None
            if self.persist_session and self.session_manager and self.session_id:
                assistant_message_id = self.session_manager.add_message(
                    self.session_id,
                    'assistant',
                    response_text
                )

                # Save context snapshot if we retrieved context
                if self.context_chunks and assistant_message_id:
                    self.session_manager.save_context_snapshot(
                        self.session_id,
                        assistant_message_id,
                        self.context_chunks
                    )

        except Exception as e:
            console.print(f"\n[red]Error generating response: {e}[/red]\n")
            # Remove user message from history since we couldn't respond
            self.chat_history.pop()

    def handle_command(self, command: str):
        """Handle special REPL commands.

        Args:
            command: Command string (starts with /)
        """
        parts = command.split(maxsplit=1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        handlers = {
            '/help': self.cmd_help,
            '/clear': self.cmd_clear,
            '/history': self.cmd_history,
            '/context': self.cmd_context,
            '/reset': self.cmd_reset,
            '/exit': self.handle_exit,
            '/quit': self.handle_exit,
        }

        handler = handlers.get(cmd)
        if handler:
            handler(args)
        else:
            console.print(f"[red]Unknown command: {cmd}[/red]")
            console.print("[dim]Type /help for available commands[/dim]\n")

    def cmd_help(self, args: str = ""):
        """Show help message."""
        self.show_welcome()

    def cmd_clear(self, args: str = ""):
        """Clear the screen."""
        console.clear()
        console.print("[dim]Screen cleared[/dim]\n")

    def cmd_history(self, args: str = ""):
        """Show conversation history."""
        if not self.chat_history:
            console.print("[yellow]No conversation history yet.[/yellow]\n")
            return

        console.print("\n[bold cyan]Conversation History[/bold cyan]\n")
        for i, msg in enumerate(self.chat_history, 1):
            role = msg['role']
            content = msg['content'][:100] + "..." if len(msg['content']) > 100 else msg['content']

            if role == 'user':
                console.print(f"[bold green]{i}. You:[/bold green] {content}")
            else:
                console.print(f"[bold blue]{i}. Assistant:[/bold blue] {content}")
        console.print()

    def cmd_context(self, args: str = ""):
        """Show current context chunks."""
        if not self.context_chunks:
            console.print("[yellow]No context retrieved yet.[/yellow]\n")
            return

        console.print(f"\n[bold cyan]Current Context ({len(self.context_chunks)} chunks)[/bold cyan]\n")
        for i, chunk in enumerate(self.context_chunks, 1):
            console.print(f"[bold]{i}. {chunk['path']}:{chunk['start_line']}-{chunk['end_line']}[/bold]")
            console.print(f"[dim]   Type: {chunk.get('type', 'unknown')} | Name: {chunk.get('name', '-')}[/dim]")
        console.print()

    def cmd_reset(self, args: str = ""):
        """Reset conversation history."""
        self.chat_history = []
        self.context_chunks = []
        console.print("[green]Conversation reset.[/green]\n")

    def handle_exit(self, args: str = ""):
        """Exit the REPL."""
        # End session if persistence enabled
        if self.persist_session and self.session_manager and self.session_id:
            self.session_manager.end_session(self.session_id)
            if settings.verbose:
                summary = self.session_manager.get_session_summary(self.session_id)
                console.print(f"\n[dim]Session saved: {summary['total_messages']} messages[/dim]")

        console.print("\n[cyan]Goodbye![/cyan]\n")
        self.running = False


def start_repl(project_path: Optional[Path] = None):
    """Start the interactive REPL.

    Args:
        project_path: Path to project
    """
    repl = AssistantREPL(project_path)
    repl.run()
