"""Dark theme configuration for CLI."""

from rich.theme import Theme
from rich.console import Console

# Dark theme color palette
COLORS = {
    # Primary colors
    "primary": "#8B5CF6",      # Purple
    "secondary": "#06B6D4",    # Cyan
    "accent": "#F59E0B",       # Amber

    # Status colors
    "success": "#10B981",      # Green
    "warning": "#F59E0B",      # Amber
    "error": "#EF4444",        # Red
    "info": "#3B82F6",         # Blue

    # Text colors
    "text": "#E5E7EB",         # Light gray
    "text_dim": "#9CA3AF",     # Medium gray
    "text_muted": "#6B7280",   # Dark gray

    # UI elements
    "border": "#4B5563",       # Gray border
    "background": "#1F2937",   # Dark background
    "highlight": "#374151",    # Slightly lighter background
}

# Rich theme
dark_theme = Theme({
    # Semantic styles
    "primary": f"bold {COLORS['primary']}",
    "secondary": f"bold {COLORS['secondary']}",
    "accent": COLORS['accent'],

    # Status styles
    "success": f"bold {COLORS['success']}",
    "warning": f"bold {COLORS['warning']}",
    "error": f"bold {COLORS['error']}",
    "info": COLORS['info'],

    # Component styles
    "header": f"bold {COLORS['primary']}",
    "subheader": f"bold {COLORS['secondary']}",
    "label": f"bold {COLORS['text']}",
    "value": COLORS['success'],
    "dim": f"dim {COLORS['text_dim']}",
    "muted": COLORS['text_muted'],

    # Question/Answer styles
    "question": f"bold {COLORS['primary']}",
    "answer": COLORS['text'],
    "code": f"{COLORS['secondary']}",

    # Provider styles
    "provider": f"bold {COLORS['accent']}",

    # Progress styles
    "spinner": COLORS['secondary'],
    "progress": COLORS['primary'],
})

# Styled console
styled_console = Console(theme=dark_theme)


def get_console() -> Console:
    """Get themed console instance."""
    return styled_console


# Emoji/icon mapping
ICONS = {
    "success": "✓",
    "error": "✗",
    "warning": "⚠",
    "info": "ℹ",
    "question": "💭",
    "answer": "💡",
    "code": "📝",
    "search": "🔍",
    "loading": "⏳",
    "rocket": "🚀",
    "sparkles": "✨",
    "gear": "⚙",
    "file": "📄",
    "folder": "📁",
    "link": "🔗",
}
