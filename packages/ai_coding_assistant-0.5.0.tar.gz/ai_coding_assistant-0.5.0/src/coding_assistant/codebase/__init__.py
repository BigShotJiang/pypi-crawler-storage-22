"""Codebase intelligence module."""
