"""File system crawler to discover code files."""
from pathlib import Path
from typing import List, Dict, Set
import pathspec


class CodebaseCrawler:
    """Crawl the codebase and find relevant files."""

    # Common patterns to ignore
    DEFAULT_IGNORE_PATTERNS = [
        '.git/',
        '__pycache__/',
        '*.pyc',
        '.venv/',
        'venv/',
        'node_modules/',
        '.env',
        '*.log',
        'dist/',
        'build/',
        '.pytest_cache/',
        '.mypy_cache/',
        '.ruff_cache/',
        '*.egg-info/',
    ]

    # Code file extensions to include
    CODE_EXTENSIONS = {
        '.py', '.js', '.ts', '.jsx', '.tsx',
        '.java', '.go', '.rs', '.c', '.cpp', '.h', '.hpp',
        '.rb', '.php', '.swift', '.kt', '.scala',
        '.md', '.txt', '.yaml', '.yml', '.json', '.toml'
    }

    def __init__(self, root_path: Path):
        self.root_path = root_path.resolve()
        self.gitignore_spec = self._load_gitignore()

    def _load_gitignore(self) -> pathspec.PathSpec:
        """Load .gitignore patterns."""
        gitignore_path = self.root_path / '.gitignore'
        patterns = list(self.DEFAULT_IGNORE_PATTERNS)

        if gitignore_path.exists():
            with open(gitignore_path, 'r') as f:
                patterns.extend(line.strip() for line in f if line.strip() and not line.startswith('#'))

        return pathspec.PathSpec.from_lines('gitwildmatch', patterns)

    def scan(self, max_files: int = 100) -> List[Dict[str, str]]:
        """Scan the codebase and return file information."""
        files = []

        for file_path in self.root_path.rglob('*'):
            # Skip if not a file
            if not file_path.is_file():
                continue

            # Skip if ignored by gitignore
            relative_path = file_path.relative_to(self.root_path)
            if self.gitignore_spec.match_file(str(relative_path)):
                continue

            # Skip if not a code file
            if file_path.suffix not in self.CODE_EXTENSIONS:
                continue

            # Skip large files (> 1MB)
            if file_path.stat().st_size > 1_000_000:
                continue

            files.append({
                'path': str(relative_path),
                'absolute_path': str(file_path),
                'extension': file_path.suffix,
                'size': file_path.stat().st_size,
            })

            # Limit number of files
            if len(files) >= max_files:
                break

        return files

    def read_file(self, file_path: str) -> str:
        """Read a file's contents."""
        try:
            full_path = self.root_path / file_path
            with open(full_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            return f"Error reading file: {e}"
