"""Code parser using tree-sitter for better code understanding."""
from pathlib import Path
from typing import List, Dict, Optional
import tree_sitter_python as tspython
from tree_sitter import Language, Parser, Node

# Optional language imports - gracefully handle missing languages
try:
    import tree_sitter_javascript as tsjs
    JAVASCRIPT_AVAILABLE = True
except ImportError:
    JAVASCRIPT_AVAILABLE = False

try:
    import tree_sitter_java as tsjava
    JAVA_AVAILABLE = True
except ImportError:
    JAVA_AVAILABLE = False


class CodeParser:
    """Parse code files and extract structured information across multiple languages."""

    def __init__(self):
        """Initialize parsers for multiple programming languages."""
        # Python (always available)
        self.PY_LANGUAGE = Language(tspython.language())

        # Initialize parsers dict
        self.parsers = {
            'python': Parser(self.PY_LANGUAGE)
        }

        # JavaScript/TypeScript (optional)
        if JAVASCRIPT_AVAILABLE:
            self.JS_LANGUAGE = Language(tsjs.language())
            self.parsers['javascript'] = Parser(self.JS_LANGUAGE)
            self.parsers['typescript'] = Parser(self.JS_LANGUAGE)

        # Java (optional)
        if JAVA_AVAILABLE:
            self.JAVA_LANGUAGE = Language(tsjava.language())
            self.parsers['java'] = Parser(self.JAVA_LANGUAGE)

        # Default parser for backward compatibility
        self.parser = self.parsers['python']

    def detect_language(self, file_path: str) -> str:
        """
        Detect programming language from file extension.

        Args:
            file_path: Path to the file

        Returns:
            Language name (python, javascript, typescript, java, etc.)
        """
        extension = Path(file_path).suffix.lower()

        extension_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.jsx': 'javascript',
            '.ts': 'typescript',
            '.tsx': 'typescript',
            '.java': 'java',
        }

        return extension_map.get(extension, 'python')

    def parse_file(self, file_path: str, content: str, language: Optional[str] = None) -> Dict:
        """
        Parse a code file and extract functions, classes, and metadata.

        Supports multiple languages: Python, JavaScript, TypeScript, Java.

        Args:
            file_path: Path to the file
            content: File contents
            language: Programming language (auto-detected if not provided)

        Returns:
            Dictionary with parsed information
        """
        # Detect language if not provided
        if language is None:
            language = self.detect_language(file_path)

        # Get appropriate parser
        parser = self.parsers.get(language, self.parser)

        # Parse the content
        tree = parser.parse(bytes(content, "utf8"))
        root = tree.root_node

        return {
            'file_path': file_path,
            'language': language,
            'functions': self._extract_functions(root, content, language),
            'classes': self._extract_classes(root, content, language),
            'imports': self._extract_imports(root, content, language),
            'chunks': self._create_chunks(root, content, file_path, language)
        }

    def _extract_functions(self, node: Node, content: str, language: str = 'python') -> List[Dict]:
        """Extract all function definitions (language-aware)."""
        functions = []

        # Define function node types per language
        function_types = {
            'python': ['function_definition'],
            'javascript': ['function_declaration', 'function', 'arrow_function', 'method_definition'],
            'typescript': ['function_declaration', 'function', 'arrow_function', 'method_definition'],
            'java': ['method_declaration']
        }

        target_types = function_types.get(language, ['function_definition'])

        def traverse(n: Node):
            if n.type in target_types:
                name_node = n.child_by_field_name('name')
                if name_node:
                    functions.append({
                        'name': content[name_node.start_byte:name_node.end_byte],
                        'start_line': n.start_point[0],
                        'end_line': n.end_point[0],
                        'code': content[n.start_byte:n.end_byte]
                    })
                elif language in ['javascript', 'typescript'] and n.type == 'arrow_function':
                    # Arrow functions might not have a name node
                    # Try to get name from parent variable declaration
                    parent = n.parent
                    if parent and parent.type == 'variable_declarator':
                        name_node = parent.child_by_field_name('name')
                        if name_node:
                            functions.append({
                                'name': content[name_node.start_byte:name_node.end_byte],
                                'start_line': n.start_point[0],
                                'end_line': n.end_point[0],
                                'code': content[n.start_byte:n.end_byte]
                            })

            for child in n.children:
                traverse(child)

        traverse(node)
        return functions

    def _extract_classes(self, node: Node, content: str, language: str = 'python') -> List[Dict]:
        """Extract all class definitions (language-aware)."""
        classes = []

        # Define class node types per language
        class_types = {
            'python': ['class_definition'],
            'javascript': ['class_declaration'],
            'typescript': ['class_declaration'],
            'java': ['class_declaration']
        }

        target_types = class_types.get(language, ['class_definition'])

        def traverse(n: Node):
            if n.type in target_types:
                name_node = n.child_by_field_name('name')
                if name_node:
                    classes.append({
                        'name': content[name_node.start_byte:name_node.end_byte],
                        'start_line': n.start_point[0],
                        'end_line': n.end_point[0],
                        'code': content[n.start_byte:n.end_byte]
                    })

            for child in n.children:
                traverse(child)

        traverse(node)
        return classes

    def _extract_imports(self, node: Node, content: str, language: str = 'python') -> List[str]:
        """Extract all import statements (language-aware)."""
        imports = []

        # Define import node types per language
        import_types = {
            'python': ['import_statement', 'import_from_statement'],
            'javascript': ['import_statement'],
            'typescript': ['import_statement'],
            'java': ['import_declaration']
        }

        target_types = import_types.get(language, ['import_statement', 'import_from_statement'])

        def traverse(n: Node):
            if n.type in target_types:
                imports.append(content[n.start_byte:n.end_byte])

            for child in n.children:
                traverse(child)

        traverse(node)
        return imports

    def _create_chunks(self, node: Node, content: str, file_path: str, language: str = 'python') -> List[Dict]:
        """
        Create smart code chunks for embedding.

        Strategy:
        1. Each function is a chunk
        2. Each class is a chunk
        3. File header (imports, module docstring) is a chunk
        """
        chunks = []

        # Extract file header (imports + module docstring)
        header_lines = []
        lines = content.split('\n')

        # Get module docstring if exists
        if node.children and node.children[0].type == 'expression_statement':
            first_expr = node.children[0]
            if first_expr.children and first_expr.children[0].type == 'string':
                header_lines.append(content[first_expr.start_byte:first_expr.end_byte])

        # Get all imports
        imports = self._extract_imports(node, content, language)
        if imports:
            header_lines.extend(imports)

        if header_lines:
            chunks.append({
                'type': 'header',
                'file_path': file_path,
                'content': '\n'.join(header_lines),
                'start_line': 0,
                'end_line': len(header_lines),
                'language': language
            })

        # Extract function chunks
        functions = self._extract_functions(node, content, language)
        for func in functions:
            chunks.append({
                'type': 'function',
                'file_path': file_path,
                'name': func['name'],
                'content': func['code'],
                'start_line': func['start_line'],
                'end_line': func['end_line'],
                'language': language
            })

        # Extract class chunks
        classes = self._extract_classes(node, content, language)
        for cls in classes:
            chunks.append({
                'type': 'class',
                'file_path': file_path,
                'name': cls['name'],
                'content': cls['code'],
                'start_line': cls['start_line'],
                'end_line': cls['end_line'],
                'language': language
            })

        return chunks
