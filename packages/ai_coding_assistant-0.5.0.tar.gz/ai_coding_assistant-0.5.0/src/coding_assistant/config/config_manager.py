"""Configuration management system."""

import os
import yaml
from pathlib import Path
from typing import Any, Dict, Optional, List
from dataclasses import dataclass, asdict, field

from coding_assistant.exceptions.validation import ConfigurationError


@dataclass
class ProjectConfig:
    """Project-specific configuration."""

    name: str = "my-project"
    root: str = "."
    exclude: List[str] = field(default_factory=lambda: [
        "node_modules",
        "venv",
        ".venv",
        "__pycache__",
        ".git",
        ".pytest_cache",
        "dist",
        "build",
        "*.egg-info"
    ])
    include_hidden: bool = False
    max_file_size_mb: int = 10

    def __post_init__(self):
        """Validate configuration."""
        if not self.name:
            raise ConfigurationError(
                Path("config"),
                "Project name cannot be empty"
            )


@dataclass
class LLMConfig:
    """LLM provider configuration."""

    provider: str = "ollama"
    model: str = "qwen2.5-coder:7b"
    endpoint: Optional[str] = None
    api_key: Optional[str] = None
    max_tokens: int = 200000
    temperature: float = 0.7
    timeout_seconds: int = 120

    def __post_init__(self):
        """Validate and set defaults."""
        # Get API key from environment if not set
        if not self.api_key:
            if self.provider == "openai":
                self.api_key = os.getenv("OPENAI_API_KEY")
            elif self.provider == "claude":
                self.api_key = os.getenv("ANTHROPIC_API_KEY")
            elif self.provider == "groq":
                self.api_key = os.getenv("GROQ_API_KEY")
            elif self.provider == "together":
                self.api_key = os.getenv("TOGETHER_API_KEY")

        # Set default endpoint if not provided
        if not self.endpoint:
            if self.provider == "ollama":
                self.endpoint = "http://localhost:11434"
            elif self.provider == "openai":
                self.endpoint = "https://api.openai.com/v1"
            elif self.provider == "claude":
                self.endpoint = "https://api.anthropic.com/v1"
            elif self.provider == "groq":
                self.endpoint = "https://api.groq.com/openai/v1"
            elif self.provider == "together":
                self.endpoint = "https://api.together.xyz/v1"

        # Validate provider
        valid_providers = ["ollama", "openai", "claude", "groq", "together", "mock"]
        if self.provider not in valid_providers:
            raise ConfigurationError(
                Path("config"),
                f"Invalid LLM provider: {self.provider}. "
                f"Must be one of: {', '.join(valid_providers)}"
            )

        # Validate temperature
        if not 0.0 <= self.temperature <= 2.0:
            raise ConfigurationError(
                Path("config"),
                f"Temperature must be between 0.0 and 2.0, got {self.temperature}"
            )


@dataclass
class EmbeddingConfig:
    """Embedding model configuration."""

    model: str = "all-MiniLM-L6-v2"
    cache_dir: str = ".assistant/cache"
    batch_size: int = 32
    device: str = "cpu"  # cpu, cuda, mps

    def __post_init__(self):
        """Validate configuration."""
        valid_devices = ["cpu", "cuda", "mps"]
        if self.device not in valid_devices:
            raise ConfigurationError(
                Path("config"),
                f"Invalid device: {self.device}. "
                f"Must be one of: {', '.join(valid_devices)}"
            )


@dataclass
class SearchConfig:
    """Search and retrieval configuration."""

    top_k: int = 10
    hybrid_alpha: float = 0.7  # Weight for vector search (0.0 = keyword only, 1.0 = vector only)
    min_similarity: float = 0.3
    max_context_chunks: int = 20

    def __post_init__(self):
        """Validate configuration."""
        if not 1 <= self.top_k <= 100:
            raise ConfigurationError(
                Path("config"),
                f"top_k must be between 1 and 100, got {self.top_k}"
            )

        if not 0.0 <= self.hybrid_alpha <= 1.0:
            raise ConfigurationError(
                Path("config"),
                f"hybrid_alpha must be between 0.0 and 1.0, got {self.hybrid_alpha}"
            )

        if not 0.0 <= self.min_similarity <= 1.0:
            raise ConfigurationError(
                Path("config"),
                f"min_similarity must be between 0.0 and 1.0, got {self.min_similarity}"
            )


@dataclass
class CacheConfig:
    """Caching configuration."""

    enabled: bool = True
    max_size_mb: int = 500
    ttl_seconds: int = 3600
    embedding_cache_enabled: bool = True
    response_cache_enabled: bool = True

    def __post_init__(self):
        """Validate configuration."""
        if self.max_size_mb < 0:
            raise ConfigurationError(
                Path("config"),
                f"max_size_mb must be positive, got {self.max_size_mb}"
            )


@dataclass
class UIConfig:
    """User interface configuration."""

    color: bool = True
    progress_bars: bool = True
    verbose: bool = False
    editor: Optional[str] = None
    pager: Optional[str] = None

    def __post_init__(self):
        """Set defaults from environment."""
        if not self.editor:
            self.editor = os.getenv("EDITOR", "vim")

        if not self.pager:
            self.pager = os.getenv("PAGER", "less")


@dataclass
class StorageConfig:
    """Storage and database configuration."""

    db_path: str = ".assistant/sessions.db"
    auto_save: bool = True
    max_sessions: int = 100
    compress_old_sessions: bool = True


@dataclass
class Config:
    """
    Main configuration class.

    Aggregates all configuration sections and provides
    methods for loading, saving, and validating config.
    """

    project: ProjectConfig = field(default_factory=ProjectConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    embeddings: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    search: SearchConfig = field(default_factory=SearchConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)

    @classmethod
    def from_file(cls, config_file: Path) -> 'Config':
        """
        Load configuration from YAML file.

        Args:
            config_file: Path to config file (.assistant.yml)

        Returns:
            Config object

        Raises:
            ConfigurationError: If config file is invalid
        """
        if not config_file.exists():
            # Return default config if file doesn't exist
            return cls.default()

        try:
            with open(config_file, 'r') as f:
                data = yaml.safe_load(f)

            if data is None:
                data = {}

            # Create config with data
            return cls(
                project=ProjectConfig(**data.get('project', {})),
                llm=LLMConfig(**data.get('llm', {})),
                embeddings=EmbeddingConfig(**data.get('embeddings', {})),
                search=SearchConfig(**data.get('search', {})),
                cache=CacheConfig(**data.get('cache', {})),
                ui=UIConfig(**data.get('ui', {})),
                storage=StorageConfig(**data.get('storage', {}))
            )

        except yaml.YAMLError as e:
            raise ConfigurationError(
                config_file,
                f"Invalid YAML syntax: {e}"
            )
        except TypeError as e:
            raise ConfigurationError(
                config_file,
                f"Invalid configuration structure: {e}"
            )
        except Exception as e:
            raise ConfigurationError(
                config_file,
                f"Failed to load configuration: {e}"
            )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Config':
        """
        Create config from dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            Config object
        """
        return cls(
            project=ProjectConfig(**data.get('project', {})),
            llm=LLMConfig(**data.get('llm', {})),
            embeddings=EmbeddingConfig(**data.get('embeddings', {})),
            search=SearchConfig(**data.get('search', {})),
            cache=CacheConfig(**data.get('cache', {})),
            ui=UIConfig(**data.get('ui', {})),
            storage=StorageConfig(**data.get('storage', {}))
        )

    @classmethod
    def default(cls) -> 'Config':
        """
        Create default configuration.

        Returns:
            Config with default values
        """
        return cls()

    def save(self, config_file: Path, create_dirs: bool = True) -> None:
        """
        Save configuration to YAML file.

        Args:
            config_file: Path to save config
            create_dirs: Whether to create parent directories

        Raises:
            ConfigurationError: If cannot save config
        """
        try:
            # Create parent directories if needed
            if create_dirs:
                config_file.parent.mkdir(parents=True, exist_ok=True)

            # Convert to dict
            data = self.to_dict()

            # Write YAML
            with open(config_file, 'w') as f:
                yaml.dump(
                    data,
                    f,
                    default_flow_style=False,
                    sort_keys=False,
                    indent=2
                )

        except Exception as e:
            raise ConfigurationError(
                config_file,
                f"Failed to save configuration: {e}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert config to dictionary.

        Returns:
            Dictionary representation
        """
        return {
            'project': asdict(self.project),
            'llm': asdict(self.llm),
            'embeddings': asdict(self.embeddings),
            'search': asdict(self.search),
            'cache': asdict(self.cache),
            'ui': asdict(self.ui),
            'storage': asdict(self.storage)
        }

    def merge(self, other: 'Config') -> 'Config':
        """
        Merge with another config (other takes precedence).

        Args:
            other: Config to merge with

        Returns:
            New merged config
        """
        merged_dict = self.to_dict()

        for section, values in other.to_dict().items():
            if section in merged_dict:
                merged_dict[section].update(values)

        return Config.from_dict(merged_dict)

    def validate(self) -> List[str]:
        """
        Validate configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        # Validate project root exists
        project_root = Path(self.project.root)
        if not project_root.exists():
            errors.append(f"Project root does not exist: {project_root}")

        # Validate cache directory is writable
        cache_dir = Path(self.embeddings.cache_dir)
        try:
            cache_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            errors.append(f"Cannot create cache directory: {e}")

        # Validate database directory is writable
        db_path = Path(self.storage.db_path)
        try:
            db_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            errors.append(f"Cannot create database directory: {e}")

        return errors


class ConfigManager:
    """
    Manages configuration loading and saving.

    Handles config file discovery, environment variables,
    and command-line overrides.
    """

    DEFAULT_CONFIG_FILES = [
        ".assistant.yml",
        ".assistant.yaml",
        "assistant.yml",
        "assistant.yaml"
    ]

    @staticmethod
    def find_config_file(start_path: Path = None) -> Optional[Path]:
        """
        Find configuration file in current or parent directories.

        Args:
            start_path: Starting directory (default: current directory)

        Returns:
            Path to config file or None
        """
        if start_path is None:
            start_path = Path.cwd()

        # Check current directory and parents
        current = start_path.resolve()

        while True:
            for config_name in ConfigManager.DEFAULT_CONFIG_FILES:
                config_file = current / config_name
                if config_file.exists():
                    return config_file

            # Move to parent
            parent = current.parent
            if parent == current:  # Reached root
                break
            current = parent

        return None

    @staticmethod
    def load(config_file: Optional[Path] = None) -> Config:
        """
        Load configuration.

        Search order:
        1. Provided config_file
        2. Found config file (search up from cwd)
        3. Default config

        Args:
            config_file: Optional explicit config file path

        Returns:
            Loaded configuration
        """
        # Use provided file or search for one
        if config_file is None:
            config_file = ConfigManager.find_config_file()

        # Load from file or use default
        if config_file and config_file.exists():
            config = Config.from_file(config_file)
        else:
            config = Config.default()

        # Apply environment variable overrides
        ConfigManager._apply_env_overrides(config)

        return config

    @staticmethod
    def _apply_env_overrides(config: Config) -> None:
        """
        Apply environment variable overrides to config.

        Environment variables follow pattern:
        ASSISTANT_SECTION_KEY=value

        Examples:
        - ASSISTANT_LLM_PROVIDER=ollama
        - ASSISTANT_UI_VERBOSE=true
        - ASSISTANT_CACHE_ENABLED=false

        Args:
            config: Config to modify
        """
        prefix = "ASSISTANT_"

        for env_var, value in os.environ.items():
            if not env_var.startswith(prefix):
                continue

            # Parse env var name
            parts = env_var[len(prefix):].lower().split('_', 1)
            if len(parts) != 2:
                continue

            section, key = parts

            # Get config section
            if section == "project":
                obj = config.project
            elif section == "llm":
                obj = config.llm
            elif section == "embeddings":
                obj = config.embeddings
            elif section == "search":
                obj = config.search
            elif section == "cache":
                obj = config.cache
            elif section == "ui":
                obj = config.ui
            elif section == "storage":
                obj = config.storage
            else:
                continue

            # Set value if attribute exists
            if hasattr(obj, key):
                # Parse value based on current type
                current_value = getattr(obj, key)

                if isinstance(current_value, bool):
                    parsed = value.lower() in ('true', '1', 'yes', 'on')
                elif isinstance(current_value, int):
                    parsed = int(value)
                elif isinstance(current_value, float):
                    parsed = float(value)
                else:
                    parsed = value

                setattr(obj, key, parsed)

    @staticmethod
    def generate_default_config(output_file: Path) -> None:
        """
        Generate default configuration file with comments.

        Args:
            output_file: Where to save config file
        """
        config = Config.default()

        # Format exclude list properly (quote items with special chars)
        def format_item(item):
            if any(char in item for char in ['*', '?', '[', ']', '{', '}', '!', '@', '#', '$', '%', '^', '&']):
                return f"    - '{item}'"
            return f'    - {item}'

        exclude_list = '\n'.join(format_item(item) for item in config.project.exclude)

        # Create commented YAML
        content = f"""# AI Coding Assistant Configuration
# Generated by: assistant config --generate

# Project Settings
project:
  name: {config.project.name}
  root: {config.project.root}
  exclude:
{exclude_list}
  include_hidden: {str(config.project.include_hidden).lower()}
  max_file_size_mb: {config.project.max_file_size_mb}

# LLM Provider Settings
llm:
  provider: {config.llm.provider}  # Options: ollama, openai, claude, mock
  model: {config.llm.model}
  # endpoint: http://localhost:11434  # Optional: custom endpoint
  # api_key: your-api-key-here  # Or set OPENAI_API_KEY / ANTHROPIC_API_KEY env var
  max_tokens: {config.llm.max_tokens}
  temperature: {config.llm.temperature}  # 0.0 = deterministic, 1.0 = creative
  timeout_seconds: {config.llm.timeout_seconds}

# Embedding Model Settings
embeddings:
  model: {config.embeddings.model}
  cache_dir: {config.embeddings.cache_dir}
  batch_size: {config.embeddings.batch_size}
  device: {config.embeddings.device}  # cpu, cuda, or mps

# Search Settings
search:
  top_k: {config.search.top_k}  # Number of results to return
  hybrid_alpha: {config.search.hybrid_alpha}  # 0.0 = keyword only, 1.0 = vector only
  min_similarity: {config.search.min_similarity}
  max_context_chunks: {config.search.max_context_chunks}

# Cache Settings
cache:
  enabled: {str(config.cache.enabled).lower()}
  max_size_mb: {config.cache.max_size_mb}
  ttl_seconds: {config.cache.ttl_seconds}  # Time to live for cached items
  embedding_cache_enabled: {str(config.cache.embedding_cache_enabled).lower()}
  response_cache_enabled: {str(config.cache.response_cache_enabled).lower()}

# UI Settings
ui:
  color: {str(config.ui.color).lower()}
  progress_bars: {str(config.ui.progress_bars).lower()}
  verbose: {str(config.ui.verbose).lower()}
  # editor: vim  # Or use $EDITOR env var
  # pager: less  # Or use $PAGER env var

# Storage Settings
storage:
  db_path: {config.storage.db_path}
  auto_save: {str(config.storage.auto_save).lower()}
  max_sessions: {config.storage.max_sessions}
  compress_old_sessions: {str(config.storage.compress_old_sessions).lower()}
"""

        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_text(content)
