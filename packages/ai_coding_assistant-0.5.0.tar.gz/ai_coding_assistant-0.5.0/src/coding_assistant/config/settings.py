"""Configuration management for the assistant."""
from pathlib import Path
from typing import Optional
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Import keystore for API key loading
from coding_assistant.utils.keystore import KeyStore


class Settings:
    """Application settings."""

    def __init__(self):
        # Project paths
        self.project_path: Path = Path.cwd()
        self.data_dir: Path = Path.home() / ".coding_assistant"
        self.data_dir.mkdir(exist_ok=True)

        # Initialize keystore for API key loading
        keystore = KeyStore()

        # LLM settings
        # Priority: env var > config file > auto-detect
        self.llm_provider: Optional[str] = os.getenv("LLM_PROVIDER")
        if not self.llm_provider:
            # Try to load from config file
            config_file = Path(".assistant.yml")
            if config_file.exists():
                try:
                    from coding_assistant.config.config_manager import Config
                    config = Config.from_file(config_file)
                    self.llm_provider = config.llm.provider if config.llm.provider != "ollama" else None
                except:
                    pass  # If config load fails, fall back to auto-detect
        self.ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.ollama_model: str = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:7b")

        # Groq settings (free tier cloud provider)
        # Priority: env var > keystore
        self.groq_api_key: Optional[str] = (
            os.getenv("GROQ_API_KEY") or keystore.get_key("groq")
        )
        self.groq_model: str = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

        # Together AI settings (free trial cloud provider)
        # Priority: env var > keystore
        self.together_api_key: Optional[str] = (
            os.getenv("TOGETHER_API_KEY") or keystore.get_key("together")
        )
        self.together_model: str = os.getenv("TOGETHER_MODEL", "Qwen/Qwen2.5-Coder-32B-Instruct")

        # Google Gemini settings (free tier cloud provider)
        # Priority: env var > keystore
        self.gemini_api_key: Optional[str] = (
            os.getenv("GEMINI_API_KEY") or keystore.get_key("gemini")
        )
        self.gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash-exp")

        # API keys (optional - for future expansion)
        # Priority: env var > keystore
        self.anthropic_api_key: Optional[str] = (
            os.getenv("ANTHROPIC_API_KEY") or keystore.get_key("claude") or keystore.get_key("anthropic")
        )
        self.openai_api_key: Optional[str] = (
            os.getenv("OPENAI_API_KEY") or keystore.get_key("openai")
        )

        # General settings
        self.verbose: bool = False
        self.max_context_files: int = 10

    def set_project_path(self, path: Path):
        """Set the project path."""
        self.project_path = path.resolve()


# Global settings instance
settings = Settings()
