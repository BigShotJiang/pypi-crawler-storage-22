"""Enhanced semantic retriever with hybrid search and context ranking."""

from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime

from coding_assistant.codebase.crawler import CodebaseCrawler
from coding_assistant.codebase.parser import CodeParser
from coding_assistant.embeddings.generator import EmbeddingGenerator
from coding_assistant.embeddings.store import VectorStore
from coding_assistant.context.chunker import SmartChunker
from coding_assistant.context.hybrid_search import HybridSearch
from coding_assistant.context.ranker import ContextRanker
from coding_assistant.vcs.git import GitIntegration


class EnhancedSemanticRetriever:
    """
    Enhanced retriever with hybrid search and intelligent ranking.

    Combines:
    - Vector similarity search
    - BM25 keyword search
    - Smart code chunking
    - Context-aware ranking
    """

    def __init__(self, project_path: Path, dependency_graph=None):
        """
        Initialize the enhanced retriever.

        Args:
            project_path: Path to the project root
            dependency_graph: Optional dependency graph for file relationships
        """
        self.project_path = Path(project_path).resolve()
        self.crawler = CodebaseCrawler(self.project_path)
        self.parser = CodeParser()
        self.embedder = EmbeddingGenerator()

        # Vector store
        persist_dir = self.project_path / ".coding_assistant" / "chroma_db"
        self.store = VectorStore(persist_dir=persist_dir)

        # Smart chunker
        self.chunker = SmartChunker(max_chunk_tokens=500)

        # Hybrid search (will be initialized after indexing)
        self.hybrid_search = None

        # Context ranker
        self.ranker = ContextRanker(dependency_graph=dependency_graph)

        # Git integration (optional - won't fail if not a git repo)
        try:
            self.git = GitIntegration(str(self.project_path))
        except Exception:
            self.git = None

        # Cache for indexed chunks
        self._indexed_chunks = []

    def clear_index(self):
        """Clear the existing index."""
        self.store.clear()
        self._indexed_chunks = []
        self.hybrid_search = None

    def index_codebase(self, max_files: int = 100, force_reindex: bool = False):
        """
        Index the codebase with smart chunking.

        Args:
            max_files: Maximum number of files to index
            force_reindex: Force re-indexing even if already indexed
        """
        if self._indexed_chunks and not force_reindex:
            print("Codebase already indexed. Use force_reindex=True to re-index.")
            return

        print("Indexing codebase with smart chunking...")

        # Scan files
        files = self.crawler.scan(max_files=max_files)

        all_chunks = []

        # Parse and chunk each file
        for file_info in files:
            try:
                content = self.crawler.read_file(file_info['path'])
                language = self._detect_language(file_info['extension'])

                if language in ('python', 'javascript', 'typescript', 'jsx', 'tsx'):
                    # Use smart chunking for supported languages
                    chunks = self.chunker.chunk_code(
                        content,
                        file_info['path'],
                        language
                    )

                    # Convert to dict format
                    for chunk in chunks:
                        all_chunks.append({
                            'type': chunk.type,
                            'file_path': chunk.file_path,
                            'content': chunk.content,
                            'start_line': chunk.start_line,
                            'end_line': chunk.end_line,
                            'language': chunk.language,
                            'name': chunk.name,
                            'docstring': chunk.docstring,
                            'last_modified': datetime.fromtimestamp(
                                Path(chunk.file_path).stat().st_mtime
                            ).isoformat()
                        })
                else:
                    # For other files, create simple file-level chunk
                    all_chunks.append({
                        'type': 'file',
                        'file_path': file_info['path'],
                        'content': content[:5000],
                        'start_line': 0,
                        'end_line': len(content.split('\n')),
                        'language': language,
                        'name': Path(file_info['path']).name,
                        'last_modified': datetime.fromtimestamp(
                            Path(file_info['path']).stat().st_mtime
                        ).isoformat()
                    })

            except Exception as e:
                print(f"Warning: Could not process {file_info['path']}: {e}")
                continue

        if not all_chunks:
            print("No chunks to index")
            return

        print(f"Generating embeddings for {len(all_chunks)} chunks...")

        # Generate embeddings
        embedded_chunks = self.embedder.embed_code_chunks(all_chunks)

        # Store in vector database
        print("Storing in vector database...")
        self.store.add_chunks(embedded_chunks)

        # Cache chunks for BM25
        self._indexed_chunks = embedded_chunks

        # Initialize hybrid search
        print("Building BM25 index...")
        self.hybrid_search = HybridSearch(self.store, self.embedder)
        self.hybrid_search.index_corpus(embedded_chunks)

        print(f"✓ Indexed {len(all_chunks)} code chunks")

    def retrieve(self, query: str, k: int = 5,
                current_file: Optional[str] = None,
                language: Optional[str] = None,
                use_hybrid: bool = True,
                use_ranking: bool = True) -> List[Dict]:
        """
        Retrieve relevant code chunks with hybrid search and ranking.

        Args:
            query: User query/question
            k: Number of results to return
            current_file: Current file for proximity scoring
            language: Programming language for language-aware ranking
            use_hybrid: Whether to use hybrid search (vector + BM25)
            use_ranking: Whether to apply context ranking

        Returns:
            List of relevant chunks with metadata
        """
        if use_hybrid and self.hybrid_search:
            # Hybrid search (vector + BM25)
            results = self.hybrid_search.search(query, n_results=k * 2)

            # Convert hybrid results to full chunk data
            enriched_results = []
            for result in results:
                chunk_id = result['id']
                # Find full chunk data
                for chunk in self._indexed_chunks:
                    if chunk.get('id') == chunk_id:
                        chunk_copy = chunk.copy()
                        chunk_copy['similarity'] = result.get('vector_score', 0.0)
                        chunk_copy['bm25_score'] = result.get('bm25_score', 0.0)
                        chunk_copy['rrf_score'] = result.get('rrf_score', 0.0)
                        enriched_results.append(chunk_copy)
                        break
        else:
            # Fallback to vector-only search
            query_embedding = self.embedder.generate_embedding(query)
            results = self.store.search(query_embedding, n_results=k * 2)
            enriched_results = results

        if not enriched_results:
            return []

        # Apply context ranking
        if use_ranking:
            ranked_results = self.ranker.rank(
                enriched_results,
                query,
                current_file=current_file,
                language=language
            )
        else:
            ranked_results = enriched_results

        # Format results
        formatted_results = []
        for result in ranked_results[:k]:
            metadata = result.get('metadata', {})
            formatted_results.append({
                'path': result.get('file_path', metadata.get('file_path', 'unknown')),
                'type': result.get('type', metadata.get('type', 'file')),
                'name': result.get('name', metadata.get('name', '')),
                'similarity': result.get('similarity', 0.0),
                'rank_score': result.get('rank_score', result.get('similarity', 0.0)),
                'start_line': result.get('start_line', metadata.get('start_line', 0)),
                'end_line': result.get('end_line', metadata.get('end_line', 0)),
                'content': result.get('content', ''),
                'language': result.get('language', metadata.get('language', 'unknown')),
                'bm25_score': result.get('bm25_score', 0.0),
                'rrf_score': result.get('rrf_score', 0.0)
            })

        return formatted_results

    def get_stats(self) -> Dict:
        """
        Get statistics about the indexed codebase.

        Returns:
            Dictionary with stats
        """
        stats = {
            'total_chunks': self.store.count(),
            'embedding_dimension': self.embedder.dimension,
            'indexed_chunks': len(self._indexed_chunks),
            'hybrid_search_enabled': self.hybrid_search is not None
        }

        if self.hybrid_search:
            stats.update(self.hybrid_search.get_stats())

        return stats

    def explain_retrieval(self, query: str, chunk_id: str) -> Dict:
        """
        Explain why a specific chunk was retrieved for a query.

        Args:
            query: The search query
            chunk_id: ID of the chunk to explain

        Returns:
            Dict with retrieval explanation
        """
        explanation = {}

        if self.hybrid_search:
            explanation['hybrid_search'] = self.hybrid_search.explain_ranking(query, chunk_id)

        # Find the chunk
        for chunk in self._indexed_chunks:
            if chunk.get('id') == chunk_id:
                if self.ranker:
                    explanation['ranking'] = self.ranker.explain_ranking(chunk, query)
                break

        return explanation

    def _detect_language(self, extension: str) -> str:
        """Detect language from file extension."""
        extension = extension.lower()
        language_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.jsx': 'jsx',
            '.ts': 'typescript',
            '.tsx': 'tsx',
            '.mjs': 'javascript',
            '.cjs': 'javascript',
        }
        return language_map.get(extension, 'text')

    def update_chunk_metadata(self, file_path: str, **metadata):
        """
        Update metadata for chunks from a specific file.

        Useful for updating reference counts, popularity, etc.
        """
        for chunk in self._indexed_chunks:
            if chunk.get('file_path') == file_path:
                chunk.update(metadata)

    def configure_ranker(self, **weights):
        """
        Configure context ranker weights.

        Args:
            **weights: New weights (similarity, file_proximity, etc.)
        """
        self.ranker.update_weights(**weights)

    def configure_hybrid_search(self, vector_weight: float = 0.5,
                                keyword_weight: float = 0.5):
        """
        Configure hybrid search weights.

        Args:
            vector_weight: Weight for vector search
            keyword_weight: Weight for keyword search
        """
        if self.hybrid_search:
            self.hybrid_search.update_weights(vector_weight, keyword_weight)
