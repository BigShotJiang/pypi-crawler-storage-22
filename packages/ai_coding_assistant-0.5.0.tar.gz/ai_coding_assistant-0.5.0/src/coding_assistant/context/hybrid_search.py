"""Hybrid search combining vector similarity and keyword search (BM25)."""

from typing import List, Dict, Optional, Tuple
from rank_bm25 import BM25Okapi
import re


class HybridSearch:
    """
    Hybrid search that combines vector similarity with BM25 keyword search.

    Uses Reciprocal Rank Fusion (RRF) to combine results from both methods.
    """

    RRF_CONSTANT = 60  # Standard RRF constant

    def __init__(self, vector_store, embedding_generator):
        """
        Initialize hybrid search.

        Args:
            vector_store: VectorStore instance for semantic search
            embedding_generator: EmbeddingGenerator for query embeddings
        """
        self.vector_store = vector_store
        self.embedding_generator = embedding_generator

        # BM25 index (will be built from corpus)
        self.bm25 = None
        self.corpus = []
        self.chunk_ids = []

    def index_corpus(self, chunks: List[Dict]):
        """
        Build BM25 index from code chunks.

        Args:
            chunks: List of code chunks with 'id' and 'content' keys
        """
        self.corpus = []
        self.chunk_ids = []

        for chunk in chunks:
            content = chunk.get('content', '')
            self.corpus.append(content)
            self.chunk_ids.append(chunk.get('id'))

        # Tokenize corpus for BM25
        tokenized_corpus = [self._tokenize(doc) for doc in self.corpus]

        # Build BM25 index
        self.bm25 = BM25Okapi(tokenized_corpus)

    def search(self, query: str, n_results: int = 10,
               vector_weight: float = 0.5,
               keyword_weight: float = 0.5) -> List[Dict]:
        """
        Hybrid search combining vector and keyword search.

        Args:
            query: Search query
            n_results: Number of results to return
            vector_weight: Weight for vector search (0-1)
            keyword_weight: Weight for keyword search (0-1)

        Returns:
            List of ranked results
        """
        if not self.bm25 or not self.corpus:
            # Fallback to vector-only search
            return self._vector_only_search(query, n_results)

        # 1. Vector similarity search
        vector_results = self._vector_search(query, n_results * 2)

        # 2. BM25 keyword search
        bm25_results = self._bm25_search(query, n_results * 2)

        # 3. Combine using Reciprocal Rank Fusion
        combined = self._reciprocal_rank_fusion(
            vector_results,
            bm25_results,
            vector_weight,
            keyword_weight
        )

        # Return top N results
        return combined[:n_results]

    def _vector_search(self, query: str, k: int) -> List[Tuple[str, float]]:
        """
        Perform vector similarity search.

        Returns:
            List of (chunk_id, score) tuples
        """
        # Generate query embedding
        query_embedding = self.embedding_generator.generate_embedding(query)

        # Search vector store
        results = self.vector_store.search(query_embedding, n_results=k)

        # Extract chunk IDs and scores (similarity)
        return [(r['id'], r['similarity']) for r in results]

    def _bm25_search(self, query: str, k: int) -> List[Tuple[str, float]]:
        """
        Perform BM25 keyword search.

        Returns:
            List of (chunk_id, score) tuples
        """
        if not self.bm25:
            return []

        # Tokenize query
        tokenized_query = self._tokenize(query)

        # Get BM25 scores
        scores = self.bm25.get_scores(tokenized_query)

        # Sort by score and get top K
        scored_docs = [(self.chunk_ids[i], scores[i]) for i in range(len(scores))]
        scored_docs.sort(key=lambda x: x[1], reverse=True)

        return scored_docs[:k]

    def _reciprocal_rank_fusion(
        self,
        vector_results: List[Tuple[str, float]],
        bm25_results: List[Tuple[str, float]],
        vector_weight: float = 0.5,
        keyword_weight: float = 0.5
    ) -> List[Dict]:
        """
        Combine results using Reciprocal Rank Fusion.

        RRF formula: score = Σ weight / (rank + constant)

        Args:
            vector_results: Results from vector search
            bm25_results: Results from BM25 search
            vector_weight: Weight for vector results
            keyword_weight: Weight for keyword results

        Returns:
            Combined and ranked results
        """
        rrf_scores = {}

        # Add scores from vector search
        for rank, (chunk_id, score) in enumerate(vector_results):
            rrf_score = vector_weight / (rank + self.RRF_CONSTANT)
            if chunk_id in rrf_scores:
                rrf_scores[chunk_id]['rrf_score'] += rrf_score
                rrf_scores[chunk_id]['vector_score'] = score
            else:
                rrf_scores[chunk_id] = {
                    'id': chunk_id,
                    'rrf_score': rrf_score,
                    'vector_score': score,
                    'bm25_score': 0.0,
                    'vector_rank': rank + 1,
                    'bm25_rank': None
                }

        # Add scores from BM25 search
        for rank, (chunk_id, score) in enumerate(bm25_results):
            rrf_score = keyword_weight / (rank + self.RRF_CONSTANT)
            if chunk_id in rrf_scores:
                rrf_scores[chunk_id]['rrf_score'] += rrf_score
                rrf_scores[chunk_id]['bm25_score'] = score
                rrf_scores[chunk_id]['bm25_rank'] = rank + 1
            else:
                rrf_scores[chunk_id] = {
                    'id': chunk_id,
                    'rrf_score': rrf_score,
                    'vector_score': 0.0,
                    'bm25_score': score,
                    'vector_rank': None,
                    'bm25_rank': rank + 1
                }

        # Sort by RRF score
        ranked = sorted(
            rrf_scores.values(),
            key=lambda x: x['rrf_score'],
            reverse=True
        )

        return ranked

    def _vector_only_search(self, query: str, k: int) -> List[Dict]:
        """Fallback to vector-only search."""
        query_embedding = self.embedding_generator.generate_embedding(query)
        results = self.vector_store.search(query_embedding, n_results=k)

        return [{
            'id': r['id'],
            'rrf_score': r['similarity'],
            'vector_score': r['similarity'],
            'bm25_score': 0.0,
            'vector_rank': i + 1,
            'bm25_rank': None
        } for i, r in enumerate(results)]

    def _tokenize(self, text: str) -> List[str]:
        """
        Tokenize text for BM25 search.

        Uses code-aware tokenization that preserves identifiers and keywords.
        """
        # Convert to lowercase
        text = text.lower()

        # Split on non-alphanumeric characters but keep underscores
        # This preserves Python/JS identifiers like my_function_name
        tokens = re.findall(r'\b\w+\b', text)

        # Also split camelCase into separate tokens
        expanded_tokens = []
        for token in tokens:
            # Split camelCase: myFunctionName -> my, function, name
            camel_split = re.sub('([A-Z][a-z]+)', r' \1', token)
            camel_split = re.sub('([A-Z]+)', r' \1', camel_split)
            expanded_tokens.extend(camel_split.split())

        # Remove very short tokens (< 2 chars) and common code words
        stop_words = {'if', 'for', 'while', 'do', 'is', 'to', 'in', 'of', 'and', 'or', 'not'}
        filtered = [t for t in expanded_tokens if len(t) >= 2 and t not in stop_words]

        return filtered

    def get_stats(self) -> Dict:
        """Get statistics about the search index."""
        return {
            'corpus_size': len(self.corpus),
            'bm25_indexed': self.bm25 is not None,
            'vector_store_count': self.vector_store.count() if self.vector_store else 0
        }

    def update_weights(self, vector_weight: float, keyword_weight: float):
        """
        Update the weights for vector vs keyword search.

        Args:
            vector_weight: Weight for vector search (0-1)
            keyword_weight: Weight for keyword search (0-1)
        """
        # Normalize weights to sum to 1
        total = vector_weight + keyword_weight
        if total > 0:
            self.vector_weight = vector_weight / total
            self.keyword_weight = keyword_weight / total
        else:
            self.vector_weight = 0.5
            self.keyword_weight = 0.5

    def explain_ranking(self, query: str, chunk_id: str) -> Dict:
        """
        Explain why a specific chunk was ranked for a query.

        Args:
            query: The search query
            chunk_id: ID of the chunk to explain

        Returns:
            Dict with ranking explanation
        """
        # Get vector score
        query_embedding = self.embedding_generator.generate_embedding(query)
        vector_results = self.vector_store.search(query_embedding, n_results=100)
        vector_rank = None
        vector_score = 0.0

        for i, result in enumerate(vector_results):
            if result['id'] == chunk_id:
                vector_rank = i + 1
                vector_score = result['similarity']
                break

        # Get BM25 score
        tokenized_query = self._tokenize(query)
        bm25_scores = self.bm25.get_scores(tokenized_query) if self.bm25 else []

        bm25_rank = None
        bm25_score = 0.0

        try:
            idx = self.chunk_ids.index(chunk_id)
            bm25_score = bm25_scores[idx]

            # Find rank
            sorted_scores = sorted(enumerate(bm25_scores), key=lambda x: x[1], reverse=True)
            for rank, (i, score) in enumerate(sorted_scores):
                if i == idx:
                    bm25_rank = rank + 1
                    break
        except (ValueError, IndexError):
            pass

        return {
            'chunk_id': chunk_id,
            'query': query,
            'vector_rank': vector_rank,
            'vector_score': vector_score,
            'bm25_rank': bm25_rank,
            'bm25_score': bm25_score,
            'appears_in_vector': vector_rank is not None,
            'appears_in_bm25': bm25_rank is not None
        }
