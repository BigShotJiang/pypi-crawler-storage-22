"""Semantic retriever for code search using embeddings."""
from pathlib import Path
from typing import List, Dict, Optional
from coding_assistant.codebase.crawler import CodebaseCrawler
from coding_assistant.codebase.parser import CodeParser
from coding_assistant.embeddings.generator import EmbeddingGenerator
from coding_assistant.embeddings.store import VectorStore


class SemanticRetriever:
    """Retrieve relevant code using semantic search."""

    def __init__(self, project_path: Path):
        """
        Initialize the semantic retriever.

        Args:
            project_path: Path to the project root
        """
        self.project_path = Path(project_path).resolve()
        self.crawler = CodebaseCrawler(self.project_path)
        self.parser = CodeParser()
        self.embedder = EmbeddingGenerator()
        self.store = VectorStore(persist_dir=self.project_path / ".coding_assistant" / "chroma_db")

    def clear_index(self):
        """Clear the existing index."""
        self.store.clear()

    def index_codebase(self, max_files: int = 100):
        """
        Index the codebase for semantic search.

        Args:
            max_files: Maximum number of files to index
        """
        # Scan files
        files = self.crawler.scan(max_files=max_files)

        all_chunks = []

        # Parse each file
        for file_info in files:
            try:
                content = self.crawler.read_file(file_info['path'])
                
                # Only parse Python files for now (parser supports Python)
                if file_info['extension'] == '.py':
                    parsed = self.parser.parse_file(file_info['path'], content)
                    all_chunks.extend(parsed['chunks'])
                else:
                    # For non-Python files, create a simple file-level chunk
                    all_chunks.append({
                        'type': 'file',
                        'file_path': file_info['path'],
                        'content': content[:5000],  # Limit content size
                        'start_line': 0,
                        'end_line': len(content.split('\n'))
                    })
            except Exception as e:
                # Skip files that can't be parsed
                if hasattr(self, '_verbose') and self._verbose:
                    print(f"Warning: Could not parse {file_info['path']}: {e}")
                continue

        if not all_chunks:
            print("No chunks to index")
            return

        # Generate embeddings
        embedded_chunks = self.embedder.embed_code_chunks(all_chunks)

        # Store in vector database
        self.store.add_chunks(embedded_chunks)

    def get_stats(self) -> Dict:
        """
        Get statistics about the indexed codebase.

        Returns:
            Dictionary with stats including total_chunks and embedding_dimension
        """
        return {
            'total_chunks': self.store.count(),
            'embedding_dimension': self.embedder.dimension
        }

    def retrieve(self, query: str, k: int = 5) -> List[Dict]:
        """
        Retrieve relevant code chunks for a query.

        Args:
            query: User query/question
            k: Number of results to return

        Returns:
            List of relevant chunks with metadata
        """
        # Generate query embedding
        query_embedding = self.embedder.generate_embedding(query)

        # Search vector store
        results = self.store.search(query_embedding, n_results=k)

        # Format results to match expected structure
        formatted_results = []
        for result in results:
            metadata = result['metadata']
            formatted_results.append({
                'path': metadata['file_path'],
                'type': metadata['type'],
                'similarity': result['similarity'],
                'start_line': metadata['start_line'],
                'end_line': metadata['end_line'],
                'content': result['content']
            })

        return formatted_results

