"""Documentation generation module for AI Coding Assistant.

This module provides CodeWiki-style automated documentation generation:
- Repository-level architecture understanding
- Hierarchical decomposition for scalability
- Multi-agent documentation generation
- Visual diagram creation (Mermaid)
- Incremental updates and continuous synchronization
"""

from coding_assistant.documentation.graph.dependency_builder import (
    DependencyGraphBuilder,
    CodeEntity,
)
from coding_assistant.documentation.graph.module_analyzer import ModuleAnalyzer

__all__ = [
    'DependencyGraphBuilder',
    'CodeEntity',
    'ModuleAnalyzer',
]

__version__ = '0.5.0'
