"""Multi-agent documentation generation system.

This module implements parallel documentation generation using multiple LLM agents,
inspired by CodeWiki's recursive multi-agent approach.
"""

from coding_assistant.documentation.agents.coordinator import (
    MultiAgentCoordinator,
    DocumentationTask,
)
from coding_assistant.documentation.agents.module_documenter import (
    ModuleDocumenter,
)
from coding_assistant.documentation.agents.synthesizer import (
    DocumentationSynthesizer,
)
from coding_assistant.documentation.agents.task_delegator import (
    TaskDelegator,
)

__all__ = [
    'MultiAgentCoordinator',
    'DocumentationTask',
    'ModuleDocumenter',
    'DocumentationSynthesizer',
    'TaskDelegator',
]
