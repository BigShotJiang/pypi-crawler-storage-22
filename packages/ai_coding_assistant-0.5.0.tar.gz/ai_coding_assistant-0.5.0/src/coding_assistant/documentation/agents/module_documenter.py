"""Per-module documentation generation.

This module provides utilities for generating documentation for individual
code modules/partitions.
"""

from typing import Dict, List, Optional
from pathlib import Path

from coding_assistant.documentation.decomposition.partitioner import Partition
from coding_assistant.documentation.decomposition.context_preserver import ModuleContext
from coding_assistant.utils.logger import get_logger

logger = get_logger(__name__)


class ModuleDocumenter:
    """
    Generate documentation for individual modules.

    This class encapsulates the logic for documenting a single module/partition,
    which is then used by the coordinator for parallel execution.
    """

    def __init__(self, llm_client=None):
        """
        Initialize module documenter.

        Args:
            llm_client: LLM client instance
        """
        from coding_assistant.llm.client import LLMClientFactory
        self.llm_client = llm_client or LLMClientFactory.create_client()

    def generate(self,
                 partition: Partition,
                 context: ModuleContext,
                 parsed_files: Optional[Dict[str, Dict]] = None) -> str:
        """
        Generate documentation for a single partition.

        Args:
            partition: Partition to document
            context: Architectural context
            parsed_files: Optional parsed file data

        Returns:
            Generated documentation as markdown
        """
        logger.info(f"Generating documentation for module: {partition.name}")

        prompt = self._build_prompt(partition, context, parsed_files)

        try:
            # LLM clients use messages format and return generators
            messages = [{"role": "user", "content": prompt}]

            # Generate and collect response chunks
            response_chunks = []
            for chunk in self.llm_client.generate(messages=messages, stream=True):
                response_chunks.append(chunk)

            response = ''.join(response_chunks)
            return response

        except Exception as e:
            logger.error(f"Documentation generation failed: {e}")
            return self._generate_fallback(partition, context)

    def _build_prompt(self,
                       partition: Partition,
                       context: ModuleContext,
                       parsed_files: Optional[Dict[str, Dict]]) -> str:
        """Build prompt for module documentation."""
        # Similar to coordinator's prompt builder
        file_list = "\n".join(f"- {Path(f).name}" for f in partition.files[:15])

        if len(partition.files) > 15:
            file_list += f"\n- ... and {len(partition.files) - 15} more files"

        return f"""Document the following code module:

**Module**: {partition.name}
**Role**: {context.architectural_role}
**Files**: {len(partition.files)}
**LOC**: {partition.size_loc}

**Files**:
{file_list}

**Design Patterns**: {', '.join(context.common_patterns) if context.common_patterns else 'None'}

Generate concise, professional documentation covering:
1. Purpose and overview
2. Key components
3. Architecture
4. Public API (if any)

Format as markdown."""

    def _generate_fallback(self, partition: Partition, context: ModuleContext) -> str:
        """Generate fallback documentation."""
        return f"""# {partition.name}

## Overview
Module with {len(partition.files)} files ({partition.size_loc} LOC).

**Role**: {context.architectural_role}

*Detailed documentation could not be generated.*
"""
