"""Synthesize module documentation into repository overview.

This module combines individual module documentation into a cohesive
repository-level documentation.
"""

from typing import Dict, List
from pathlib import Path

from coding_assistant.documentation.decomposition.partitioner import Partition
from coding_assistant.utils.logger import get_logger

logger = get_logger(__name__)


class DocumentationSynthesizer:
    """
    Synthesize module-level documentation into repository overview.

    Creates:
    - Repository overview
    - Architecture documentation
    - Module index
    - Cross-module relationships
    """

    def __init__(self, llm_client=None):
        """
        Initialize synthesizer.

        Args:
            llm_client: LLM client instance
        """
        from coding_assistant.llm.client import LLMClientFactory
        self.llm_client = llm_client or LLMClientFactory.create_client()

    async def synthesize_overview(self,
                                    module_docs: Dict[str, str],
                                    partitions: List[Partition],
                                    repo_metadata: Dict) -> str:
        """
        Synthesize repository overview from module documentation.

        Args:
            module_docs: Module name -> documentation mapping
            partitions: List of partitions
            repo_metadata: Repository metadata

        Returns:
            Repository overview documentation as markdown
        """
        logger.info(f"Synthesizing overview from {len(module_docs)} module documents")

        # Extract summaries from each module doc
        summaries = self._extract_summaries(module_docs)

        # Build synthesis prompt
        prompt = self._build_synthesis_prompt(summaries, partitions, repo_metadata)

        try:
            # LLM clients use messages format and return generators
            messages = [{"role": "user", "content": prompt}]

            # Generate and collect response chunks
            response_chunks = []
            for chunk in self.llm_client.generate(messages=messages, stream=True):
                response_chunks.append(chunk)

            overview = ''.join(response_chunks)
            return overview

        except Exception as e:
            logger.error(f"Synthesis failed: {e}")
            return self._generate_fallback_overview(summaries, partitions)

    def _extract_summaries(self, module_docs: Dict[str, str]) -> Dict[str, str]:
        """Extract one-sentence summaries from module docs."""
        summaries = {}

        for module_name, doc in module_docs.items():
            # Extract first paragraph or first meaningful line
            lines = [l.strip() for l in doc.split('\n') if l.strip() and not l.strip().startswith('#')]
            summary = lines[0] if lines else "No summary available"
            summaries[module_name] = summary[:200]  # Limit length

        return summaries

    def _build_synthesis_prompt(self,
                                  summaries: Dict[str, str],
                                  partitions: List[Partition],
                                  repo_metadata: Dict) -> str:
        """Build prompt for repository overview."""
        module_list = "\n".join(f"- **{name}**: {summary}" for name, summary in summaries.items())

        total_files = sum(len(p.files) for p in partitions)
        total_loc = sum(p.size_loc for p in partitions)

        return f"""Create a comprehensive repository overview from the following module documentation.

**Repository**: {repo_metadata.get('name', 'Code Repository')}
**Modules**: {len(summaries)}
**Total Files**: {total_files}
**Total LOC**: {total_loc}

**Module Summaries**:
{module_list}

Generate a professional README-style overview that includes:

1. **Executive Summary** - What this repository does (2-3 paragraphs)
2. **Architecture Overview** - High-level system design
3. **Module Organization** - How modules are organized
4. **Key Features** - Main capabilities
5. **Technology Stack** - Languages, frameworks, tools
6. **Getting Started** - Quick start guide for new developers

Format as markdown. Be concise but comprehensive.
"""

    def _generate_fallback_overview(self,
                                      summaries: Dict[str, str],
                                      partitions: List[Partition]) -> str:
        """Generate basic overview without LLM."""
        total_files = sum(len(p.files) for p in partitions)
        total_loc = sum(p.size_loc for p in partitions)

        doc = f"""# Repository Documentation

## Overview

This repository contains {len(partitions)} modules with {total_files} files ({total_loc} lines of code).

## Modules

"""
        for module_name, summary in summaries.items():
            doc += f"### {module_name}\n\n{summary}\n\n"

        return doc
