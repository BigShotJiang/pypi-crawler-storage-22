"""Dynamic task delegation for workload optimization.

This module optimizes how tasks are assigned to agents based on
workload, priority, and resource availability.
"""

from typing import List, Dict, Optional
from collections import defaultdict

from coding_assistant.documentation.agents.coordinator import DocumentationTask
from coding_assistant.utils.logger import get_logger

logger = get_logger(__name__)


class TaskDelegator:
    """
    Optimize task delegation across agents.

    Handles:
    - Load balancing
    - Priority scheduling
    - Resource optimization
    - Adaptive scheduling
    """

    def __init__(self, num_agents: int = 3):
        """
        Initialize task delegator.

        Args:
            num_agents: Number of available agents
        """
        self.num_agents = num_agents
        self.agent_loads: Dict[int, int] = defaultdict(int)  # Agent ID -> current load

    def delegate_tasks(self, tasks: List[DocumentationTask]) -> Dict[int, List[DocumentationTask]]:
        """
        Delegate tasks to agents optimally.

        Args:
            tasks: List of tasks to delegate

        Returns:
            Dictionary mapping agent IDs to their assigned tasks
        """
        logger.info(f"Delegating {len(tasks)} tasks across {self.num_agents} agents")

        # Sort tasks by priority (lower number = higher priority)
        sorted_tasks = sorted(tasks, key=lambda t: (t.priority, -t.partition.size_loc))

        # Assign tasks using greedy load balancing
        assignments: Dict[int, List[DocumentationTask]] = defaultdict(list)

        for task in sorted_tasks:
            # Find agent with lowest current load
            agent_id = min(range(self.num_agents), key=lambda i: self.agent_loads[i])

            # Assign task
            assignments[agent_id].append(task)

            # Update load (use partition size as weight)
            self.agent_loads[agent_id] += task.partition.size_loc

        # Log delegation stats
        for agent_id, agent_tasks in assignments.items():
            logger.debug(f"Agent {agent_id}: {len(agent_tasks)} tasks, "
                        f"{self.agent_loads[agent_id]} LOC")

        return dict(assignments)

    def get_load_balance_score(self) -> float:
        """
        Compute load balance quality (0-1, higher is better).

        Returns:
            Balance score
        """
        if not self.agent_loads:
            return 1.0

        loads = list(self.agent_loads.values())
        if not loads:
            return 1.0

        avg_load = sum(loads) / len(loads)
        if avg_load == 0:
            return 1.0

        # Compute coefficient of variation
        variance = sum((load - avg_load) ** 2 for load in loads) / len(loads)
        std_dev = variance ** 0.5
        cv = std_dev / avg_load

        # Convert to 0-1 score (lower CV = better balance)
        return max(0, 1.0 - cv)

    def reset_loads(self):
        """Reset agent load tracking."""
        self.agent_loads.clear()
