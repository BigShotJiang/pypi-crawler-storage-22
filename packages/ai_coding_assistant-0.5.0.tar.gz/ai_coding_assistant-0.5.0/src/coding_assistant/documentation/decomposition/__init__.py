"""Hierarchical decomposition for scalable repository processing."""

from coding_assistant.documentation.decomposition.partitioner import (
    HierarchicalPartitioner,
    Partition,
)
from coding_assistant.documentation.decomposition.context_preserver import (
    ContextPreserver,
    ModuleContext,
)
from coding_assistant.documentation.decomposition.module_detector import (
    ModuleDetector,
)

__all__ = [
    'HierarchicalPartitioner',
    'Partition',
    'ContextPreserver',
    'ModuleContext',
    'ModuleDetector',
]
