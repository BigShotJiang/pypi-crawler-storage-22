"""Documentation writers for various output formats.

This module provides writers that convert generated documentation
and diagrams into different output formats (markdown, HTML, etc.).
"""

from .markdown_writer import MarkdownWriter

__all__ = [
    'MarkdownWriter',
]
