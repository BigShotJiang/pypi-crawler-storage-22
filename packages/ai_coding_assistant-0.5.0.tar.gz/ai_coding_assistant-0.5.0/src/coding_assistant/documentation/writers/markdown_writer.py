"""Markdown documentation writer.

This module writes generated documentation and diagrams to markdown files
with proper structure, formatting, and navigation.
"""

from pathlib import Path
from typing import Dict, List
from datetime import datetime

from coding_assistant.documentation.decomposition.partitioner import Partition
from coding_assistant.utils.logger import get_logger

logger = get_logger(__name__)


class MarkdownWriter:
    """
    Write documentation to markdown files.

    Creates:
    - README.md (repository overview)
    - modules/ (per-module documentation)
    - diagrams/ (visual diagrams)
    - index.md (navigation)
    """

    def __init__(self, output_dir: Path):
        """
        Initialize markdown writer.

        Args:
            output_dir: Directory to write documentation
        """
        self.output_dir = Path(output_dir)
        self.modules_dir = self.output_dir / "modules"
        self.diagrams_dir = self.output_dir / "diagrams"

        # Create directories
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.modules_dir.mkdir(exist_ok=True)
        self.diagrams_dir.mkdir(exist_ok=True)

    def write_documentation(self,
                             overview: str,
                             module_docs: Dict[str, str],
                             diagrams: Dict[str, str],
                             partitions: List[Partition],
                             repo_metadata: Dict) -> List[Path]:
        """
        Write all documentation to files.

        Args:
            overview: Repository overview markdown
            module_docs: Module name -> documentation mapping
            diagrams: Diagram type -> mermaid code mapping
            partitions: List of partitions
            repo_metadata: Repository metadata

        Returns:
            List of paths to written files
        """
        logger.info(f"Writing documentation to {self.output_dir}")

        written_files = []

        # 1. Write README.md (overview)
        readme_path = self._write_readme(overview, diagrams, repo_metadata)
        written_files.append(readme_path)

        # 2. Write module documentation
        module_paths = self._write_modules(module_docs, partitions)
        written_files.extend(module_paths)

        # 3. Write diagrams
        diagram_paths = self._write_diagrams(diagrams)
        written_files.extend(diagram_paths)

        # 4. Write index/navigation
        index_path = self._write_index(module_docs, diagrams, repo_metadata)
        written_files.append(index_path)

        logger.info(f"Wrote {len(written_files)} documentation files")

        return written_files

    def _write_readme(self,
                       overview: str,
                       diagrams: Dict[str, str],
                       repo_metadata: Dict) -> Path:
        """Write README.md with repository overview."""

        readme_path = self.output_dir / "README.md"

        content = []

        # Header
        repo_name = repo_metadata.get('name', 'Repository')
        content.append(f"# {repo_name} Documentation")
        content.append("")
        content.append(f"*Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*")
        content.append("")

        # Overview
        content.append(overview)
        content.append("")

        # Architecture diagram (if available)
        if 'architecture' in diagrams:
            content.append("## Architecture")
            content.append("")
            content.append("```mermaid")
            content.append(diagrams['architecture'])
            content.append("```")
            content.append("")

        # Navigation
        content.append("## Documentation")
        content.append("")
        content.append("- [Module Index](index.md) - Browse all modules")
        content.append("- [Modules](modules/) - Detailed module documentation")
        content.append("- [Diagrams](diagrams/) - Visual diagrams")
        content.append("")

        # Repository stats
        content.append("## Repository Statistics")
        content.append("")
        content.append(f"- **Total Files**: {repo_metadata.get('total_files', 'N/A')}")
        content.append(f"- **Modules Detected**: {repo_metadata.get('total_modules', 'N/A')}")
        content.append(f"- **Partitions**: {repo_metadata.get('total_partitions', 'N/A')}")
        content.append("")

        # Footer
        content.append("---")
        content.append("")
        content.append("*This documentation was auto-generated using CodeWiki integration.*")
        content.append("")

        readme_path.write_text("\\n".join(content))

        logger.debug(f"Wrote README.md ({len(content)} lines)")

        return readme_path

    def _write_modules(self,
                        module_docs: Dict[str, str],
                        partitions: List[Partition]) -> List[Path]:
        """Write individual module documentation files."""

        written_paths = []

        # Create partition lookup
        partition_map = {p.name: p for p in partitions}

        for module_name, doc_content in module_docs.items():
            # Sanitize module name for filename
            safe_name = self._sanitize_filename(module_name)
            module_path = self.modules_dir / f"{safe_name}.md"

            content = []

            # Header
            content.append(f"# {module_name}")
            content.append("")

            # Metadata (if partition available)
            partition = partition_map.get(module_name)
            if partition:
                content.append("## Module Information")
                content.append("")
                content.append(f"- **Files**: {len(partition.files)}")
                content.append(f"- **Lines of Code**: {partition.size_loc}")
                content.append(f"- **Cohesion Score**: {partition.cohesion_score:.2f}")
                content.append(f"- **Dependencies**: {len(partition.dependencies)}")
                content.append("")

                # File list
                if partition.files:
                    content.append("### Files in Module")
                    content.append("")
                    for file_path in partition.files[:20]:  # Limit to 20
                        rel_path = Path(file_path).name
                        content.append(f"- `{rel_path}`")

                    if len(partition.files) > 20:
                        content.append(f"- *... and {len(partition.files) - 20} more files*")

                    content.append("")

            # Main documentation
            content.append("## Documentation")
            content.append("")
            content.append(doc_content)
            content.append("")

            # Navigation
            content.append("---")
            content.append("")
            content.append("[← Back to Index](../index.md)")
            content.append("")

            module_path.write_text("\\n".join(content))
            written_paths.append(module_path)

        logger.debug(f"Wrote {len(written_paths)} module documentation files")

        return written_paths

    def _write_diagrams(self, diagrams: Dict[str, str]) -> List[Path]:
        """Write diagram files in mermaid format."""

        written_paths = []

        for diagram_type, diagram_code in diagrams.items():
            diagram_path = self.diagrams_dir / f"{diagram_type}.mmd"

            diagram_path.write_text(diagram_code)
            written_paths.append(diagram_path)

            # Also create markdown file with embedded diagram
            md_path = self.diagrams_dir / f"{diagram_type}.md"

            content = []
            content.append(f"# {diagram_type.title()} Diagram")
            content.append("")
            content.append(f"*Generated diagram for {diagram_type}*")
            content.append("")
            content.append("```mermaid")
            content.append(diagram_code)
            content.append("```")
            content.append("")
            content.append("---")
            content.append("")
            content.append(f"[Download .mmd file]({diagram_type}.mmd) | [Back to Index](../index.md)")
            content.append("")

            md_path.write_text("\\n".join(content))
            written_paths.append(md_path)

        logger.debug(f"Wrote {len(written_paths)} diagram files")

        return written_paths

    def _write_index(self,
                      module_docs: Dict[str, str],
                      diagrams: Dict[str, str],
                      repo_metadata: Dict) -> Path:
        """Write index.md with navigation."""

        index_path = self.output_dir / "index.md"

        content = []

        # Header
        content.append("# Documentation Index")
        content.append("")
        content.append(f"*{repo_metadata.get('name', 'Repository')} Documentation*")
        content.append("")

        # Modules section
        content.append("## Modules")
        content.append("")
        content.append(f"This repository contains {len(module_docs)} documented modules:")
        content.append("")

        # Sort modules alphabetically
        sorted_modules = sorted(module_docs.keys())

        for module_name in sorted_modules:
            safe_name = self._sanitize_filename(module_name)
            content.append(f"- [{module_name}](modules/{safe_name}.md)")

        content.append("")

        # Diagrams section
        if diagrams:
            content.append("## Diagrams")
            content.append("")
            content.append("Visual representations of the codebase:")
            content.append("")

            for diagram_type in sorted(diagrams.keys()):
                content.append(f"- [{diagram_type.title()}](diagrams/{diagram_type}.md)")

            content.append("")

        # Quick links
        content.append("## Quick Links")
        content.append("")
        content.append("- [Repository Overview](README.md)")
        content.append("")

        # Footer
        content.append("---")
        content.append("")
        content.append(f"*Total: {len(module_docs)} modules, {len(diagrams)} diagrams*")
        content.append("")

        index_path.write_text("\\n".join(content))

        logger.debug("Wrote index.md")

        return index_path

    def _sanitize_filename(self, name: str) -> str:
        """
        Sanitize module name for use as filename.

        Replaces special characters with underscores.
        """
        import re

        # Replace path separators, dots, spaces with underscores
        sanitized = re.sub(r'[/\\\\.\\s]', '_', name)

        # Remove any remaining special characters
        sanitized = re.sub(r'[^a-zA-Z0-9_-]', '', sanitized)

        # Remove leading/trailing underscores
        sanitized = sanitized.strip('_')

        return sanitized or 'unnamed_module'
