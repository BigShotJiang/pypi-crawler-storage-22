"""Embedding generation using sentence-transformers (local, no API needed)."""
from typing import List, Dict
import numpy as np
from sentence_transformers import SentenceTransformer
from rich.console import Console

console = Console()


class EmbeddingGenerator:
    """Generate embeddings for code using local sentence-transformers."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize the embedding generator.

        Args:
            model_name: Model to use. Default is all-MiniLM-L6-v2
                       (fast, 384 dimensions, good for code)
        """
        console.print(f"[dim]Loading embedding model: [bold #06B6D4]{model_name}[/bold #06B6D4]...[/dim]")
        self.model = SentenceTransformer(model_name)
        self.dimension = self.model.get_sentence_embedding_dimension()
        console.print(f"[bold #10B981]✓[/bold #10B981] [dim]Model loaded (dimension: {self.dimension})[/dim]")

    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector as list of floats
        """
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding.tolist()

    def generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts (more efficient).

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        embeddings = self.model.encode(
            texts,
            convert_to_numpy=True,
            show_progress_bar=len(texts) > 10
        )
        return embeddings.tolist()

    def embed_code_chunks(self, chunks: List[Dict]) -> List[Dict]:
        """
        Embed code chunks with metadata.

        Args:
            chunks: List of code chunks from parser

        Returns:
            Chunks with embeddings added
        """
        if not chunks:
            return []

        # Extract texts to embed
        texts = []
        for chunk in chunks:
            # Combine type, name (if exists), and content for embedding
            text_parts = [chunk['type']]

            if 'name' in chunk:
                text_parts.append(chunk['name'])

            text_parts.append(chunk['content'])

            texts.append(' '.join(text_parts))

        # Generate embeddings in batch
        embeddings = self.generate_embeddings_batch(texts)

        # Add embeddings to chunks
        for chunk, embedding in zip(chunks, embeddings):
            chunk['embedding'] = embedding

        return chunks
