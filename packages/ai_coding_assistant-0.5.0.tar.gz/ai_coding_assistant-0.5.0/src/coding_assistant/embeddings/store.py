"""Vector store using ChromaDB for semantic code search."""
from pathlib import Path
from typing import List, Dict, Optional
import chromadb
from chromadb.config import Settings
import hashlib
import warnings
import sys
import os


class VectorStore:
    """Manages code embeddings in ChromaDB."""

    def __init__(self, persist_dir: Optional[Path] = None):
        """
        Initialize ChromaDB vector store.

        Args:
            persist_dir: Directory to persist the database
        """
        if persist_dir is None:
            persist_dir = Path.home() / ".coding_assistant" / "chroma_db"

        persist_dir.mkdir(parents=True, exist_ok=True)

        # Suppress ChromaDB telemetry warnings during initialization
        # Save original stderr
        original_stderr = sys.stderr
        try:
            # Redirect stderr to devnull during initialization
            sys.stderr = open(os.devnull, 'w')

            self.client = chromadb.PersistentClient(
                path=str(persist_dir),
                settings=Settings(
                    anonymized_telemetry=False,
                    allow_reset=True
                )
            )

            # Get or create collection
            self.collection = self.client.get_or_create_collection(
                name="codebase",
                metadata={"hnsw:space": "cosine"}  # Use cosine similarity
            )
        finally:
            # Restore original stderr
            sys.stderr.close()
            sys.stderr = original_stderr

        from rich.console import Console
        console = Console()
        console.print(f"[bold #10B981]✓[/bold #10B981] [dim]ChromaDB initialized ({self.collection.count()} chunks)[/dim]")

    def add_chunks(self, chunks: List[Dict]):
        """
        Add code chunks with embeddings to the store.

        Args:
            chunks: List of chunks with embeddings
        """
        if not chunks:
            return

        ids = []
        embeddings = []
        documents = []
        metadatas = []

        for chunk in chunks:
            # Create unique ID from file path + chunk type + position
            chunk_id = self._generate_chunk_id(chunk)
            ids.append(chunk_id)

            embeddings.append(chunk['embedding'])
            documents.append(chunk['content'])

            # Store metadata (without embedding to save space)
            metadata = {
                'file_path': chunk['file_path'],
                'type': chunk['type'],
                'start_line': chunk['start_line'],
                'end_line': chunk['end_line']
            }

            if 'name' in chunk:
                metadata['name'] = chunk['name']

            metadatas.append(metadata)

        # Add to ChromaDB
        self.collection.add(
            ids=ids,
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas
        )

        print(f"✓ Added {len(chunks)} chunks to vector store")

    def search(
        self,
        query_embedding: List[float],
        n_results: int = 10,
        filter_metadata: Optional[Dict] = None
    ) -> List[Dict]:
        """
        Search for similar code chunks.

        Args:
            query_embedding: Query embedding vector
            n_results: Number of results to return
            filter_metadata: Optional metadata filters

        Returns:
            List of matching chunks with similarity scores
        """
        # Suppress ChromaDB warnings during query
        original_stderr = sys.stderr
        try:
            sys.stderr = open(os.devnull, 'w')

            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=n_results,
                where=filter_metadata,
                include=['documents', 'metadatas', 'distances']
            )
        finally:
            sys.stderr.close()
            sys.stderr = original_stderr

        return self._format_results(results)

    def delete_by_file(self, file_path: str):
        """
        Delete all chunks from a specific file.

        Args:
            file_path: Path to the file
        """
        # Get all IDs for this file
        results = self.collection.get(
            where={"file_path": file_path}
        )

        if results['ids']:
            self.collection.delete(ids=results['ids'])
            print(f"✓ Deleted {len(results['ids'])} chunks from {file_path}")

    def clear(self):
        """Clear all chunks from the store."""
        self.client.delete_collection("codebase")
        self.collection = self.client.create_collection(
            name="codebase",
            metadata={"hnsw:space": "cosine"}
        )
        print("✓ Vector store cleared")

    def count(self) -> int:
        """Get total number of chunks in the store."""
        return self.collection.count()

    def _generate_chunk_id(self, chunk: Dict) -> str:
        """Generate unique ID for a chunk."""
        # Use file path + type + start line
        id_string = f"{chunk['file_path']}:{chunk['type']}:{chunk['start_line']}"
        return hashlib.md5(id_string.encode()).hexdigest()

    def _format_results(self, raw_results: Dict) -> List[Dict]:
        """Format ChromaDB results into usable structure."""
        formatted = []

        if not raw_results['ids'] or not raw_results['ids'][0]:
            return formatted

        for i in range(len(raw_results['ids'][0])):
            formatted.append({
                'id': raw_results['ids'][0][i],
                'content': raw_results['documents'][0][i],
                'metadata': raw_results['metadatas'][0][i],
                'distance': raw_results['distances'][0][i],
                'similarity': 1 - raw_results['distances'][0][i]  # Convert distance to similarity
            })

        return formatted
