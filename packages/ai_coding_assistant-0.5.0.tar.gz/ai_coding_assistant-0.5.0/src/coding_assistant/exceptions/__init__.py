"""Custom exceptions for the AI Coding Assistant."""

from coding_assistant.exceptions.base import AssistantError
from coding_assistant.exceptions.llm import (
    LLMError,
    LLMConnectionError,
    LLMResponseError,
    LLMTimeoutError
)
from coding_assistant.exceptions.storage import (
    StorageError,
    IndexError,
    IndexNotFoundError,
    SessionError
)
from coding_assistant.exceptions.validation import (
    ValidationError,
    FileNotFoundError,
    InvalidQueryError,
    InvalidParameterError,
    ConfigurationError
)
from coding_assistant.exceptions.recovery import ErrorRecovery

__all__ = [
    # Base
    'AssistantError',

    # LLM
    'LLMError',
    'LLMConnectionError',
    'LLMResponseError',
    'LLMTimeoutError',

    # Storage
    'StorageError',
    'IndexError',
    'IndexNotFoundError',
    'SessionError',

    # Validation
    'ValidationError',
    'FileNotFoundError',
    'InvalidQueryError',
    'InvalidParameterError',
    'ConfigurationError',

    # Recovery
    'ErrorRecovery',
]
