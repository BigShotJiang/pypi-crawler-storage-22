"""Base exception classes for the AI Coding Assistant."""

from typing import Optional, Dict, Any


class AssistantError(Exception):
    """
    Base exception for all assistant errors.

    Attributes:
        message: Human-readable error message
        recoverable: Whether the error can be recovered from
        suggestion: Suggested action to fix the error
        details: Additional error details
        error_code: Unique error code for categorization
    """

    def __init__(
        self,
        message: str,
        recoverable: bool = True,
        suggestion: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        error_code: Optional[str] = None
    ):
        """
        Initialize assistant error.

        Args:
            message: Error message
            recoverable: Whether error can be recovered from
            suggestion: Suggestion for fixing the error
            details: Additional error details
            error_code: Unique error code
        """
        super().__init__(message)
        self.message = message
        self.recoverable = recoverable
        self.suggestion = suggestion
        self.details = details or {}
        self.error_code = error_code or self.__class__.__name__

    def format_message(self, color: bool = True) -> str:
        """
        Format error message for display.

        Args:
            color: Whether to include Rich color markup

        Returns:
            Formatted error message
        """
        if color:
            lines = [f"[red]❌ Error: {self.message}[/red]"]

            if self.suggestion:
                lines.append(f"\n[yellow]💡 Suggestion: {self.suggestion}[/yellow]")

            if self.details:
                lines.append("\n[dim]Details:[/dim]")
                for key, value in self.details.items():
                    lines.append(f"  [dim]{key}: {value}[/dim]")

            if not self.recoverable:
                lines.append("\n[red bold]⚠️  This error is not recoverable.[/red bold]")

        else:
            lines = [f"Error: {self.message}"]

            if self.suggestion:
                lines.append(f"\nSuggestion: {self.suggestion}")

            if self.details:
                lines.append("\nDetails:")
                for key, value in self.details.items():
                    lines.append(f"  {key}: {value}")

            if not self.recoverable:
                lines.append("\n⚠️  This error is not recoverable.")

        return "\n".join(lines)

    def __str__(self) -> str:
        """String representation."""
        return self.format_message(color=False)

    def __repr__(self) -> str:
        """Developer representation."""
        return (
            f"{self.__class__.__name__}("
            f"message={self.message!r}, "
            f"recoverable={self.recoverable}, "
            f"error_code={self.error_code})"
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert error to dictionary.

        Returns:
            Dictionary representation of error
        """
        return {
            'error_code': self.error_code,
            'message': self.message,
            'recoverable': self.recoverable,
            'suggestion': self.suggestion,
            'details': self.details,
            'error_type': self.__class__.__name__
        }
