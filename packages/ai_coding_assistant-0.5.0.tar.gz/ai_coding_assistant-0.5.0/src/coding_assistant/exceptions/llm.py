"""LLM-related exceptions."""

from typing import Optional
from coding_assistant.exceptions.base import AssistantError


class LLMError(AssistantError):
    """Base exception for LLM-related errors."""

    def __init__(
        self,
        message: str,
        recoverable: bool = True,
        suggestion: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            message=message,
            recoverable=recoverable,
            suggestion=suggestion,
            error_code="LLM_ERROR",
            **kwargs
        )


class LLMConnectionError(LLMError):
    """
    LLM connection failed.

    Raised when cannot connect to LLM provider.
    """

    def __init__(self, provider: str, endpoint: str, reason: Optional[str] = None):
        """
        Initialize connection error.

        Args:
            provider: LLM provider name (ollama, openai, etc.)
            endpoint: Connection endpoint
            reason: Optional reason for failure
        """
        message = f"Failed to connect to {provider} LLM at {endpoint}"
        if reason:
            message += f": {reason}"

        suggestion = self._get_suggestion(provider, endpoint)

        super().__init__(
            message=message,
            recoverable=True,
            suggestion=suggestion,
            details={
                'provider': provider,
                'endpoint': endpoint,
                'reason': reason
            }
        )

    @staticmethod
    def _get_suggestion(provider: str, endpoint: str) -> str:
        """Get provider-specific suggestion."""
        if provider.lower() == "ollama":
            return (
                f"Make sure Ollama is running:\n"
                f"  1. Install Ollama: https://ollama.ai\n"
                f"  2. Start Ollama service: ollama serve\n"
                f"  3. Check it's running: curl {endpoint}"
            )
        elif provider.lower() == "groq":
            return (
                "Check your Groq API configuration:\n"
                "  1. Get free API key: https://console.groq.com\n"
                "  2. Set API key: assistant config set-api-key groq <your-key>\n"
                "  3. Or set env var: GROQ_API_KEY=<your-key>"
            )
        elif provider.lower() == "together":
            return (
                "Check your Together AI configuration:\n"
                "  1. Get API key ($25 free trial): https://api.together.xyz\n"
                "  2. Set API key: assistant config set-api-key together <your-key>\n"
                "  3. Or set env var: TOGETHER_API_KEY=<your-key>"
            )
        elif provider.lower() == "gemini":
            return (
                "Check your Google Gemini configuration:\n"
                "  1. Get free API key: https://makersuite.google.com/app/apikey\n"
                "  2. Set API key: assistant config set-api-key gemini <your-key>\n"
                "  3. Or set env var: GEMINI_API_KEY=<your-key>"
            )
        elif provider.lower() in ["openai", "claude"]:
            return (
                f"Check your API configuration:\n"
                f"  1. Verify API key is set\n"
                f"  2. Check network connectivity\n"
                f"  3. Verify endpoint: {endpoint}"
            )
        else:
            return f"Check that {provider} is running at {endpoint}"


class LLMResponseError(LLMError):
    """
    LLM returned invalid or error response.

    Raised when LLM response is malformed or indicates an error.
    """

    def __init__(
        self,
        message: str,
        provider: str,
        status_code: Optional[int] = None,
        response_text: Optional[str] = None
    ):
        """
        Initialize response error.

        Args:
            message: Error message
            provider: LLM provider
            status_code: HTTP status code if applicable
            response_text: Raw response text
        """
        suggestion = "Try again or switch to a different LLM provider"

        if status_code == 429:
            suggestion = "Rate limit exceeded. Wait a moment and try again."
        elif status_code == 401:
            suggestion = "Authentication failed. Check your API key."
        elif status_code == 503:
            suggestion = "Service unavailable. Try again later."

        super().__init__(
            message=message,
            recoverable=True,
            suggestion=suggestion,
            details={
                'provider': provider,
                'status_code': status_code,
                'response_preview': response_text[:200] if response_text else None
            }
        )


class LLMTimeoutError(LLMError):
    """
    LLM request timed out.

    Raised when LLM takes too long to respond.
    """

    def __init__(self, provider: str, timeout_seconds: int):
        """
        Initialize timeout error.

        Args:
            provider: LLM provider
            timeout_seconds: Timeout duration
        """
        super().__init__(
            message=f"LLM request to {provider} timed out after {timeout_seconds}s",
            recoverable=True,
            suggestion=(
                "Try one of the following:\n"
                "  1. Increase timeout in settings\n"
                "  2. Reduce context size (use fewer code chunks)\n"
                "  3. Try a faster model"
            ),
            details={
                'provider': provider,
                'timeout_seconds': timeout_seconds
            }
        )


class LLMModelNotFoundError(LLMError):
    """
    Requested LLM model not found.

    Raised when specified model is not available.
    """

    def __init__(self, provider: str, model: str, available_models: Optional[list] = None):
        """
        Initialize model not found error.

        Args:
            provider: LLM provider
            model: Requested model name
            available_models: List of available models
        """
        message = f"Model '{model}' not found for provider '{provider}'"

        suggestion = f"Available models:\n"
        if available_models:
            for m in available_models[:5]:  # Show first 5
                suggestion += f"  - {m}\n"
            if len(available_models) > 5:
                suggestion += f"  ... and {len(available_models) - 5} more"
        else:
            suggestion = f"Check model name or pull the model:\n  ollama pull {model}"

        super().__init__(
            message=message,
            recoverable=True,
            suggestion=suggestion,
            details={
                'provider': provider,
                'requested_model': model,
                'available_models': available_models
            }
        )


class LLMContextTooLargeError(LLMError):
    """
    Context exceeds model's token limit.

    Raised when total context is too large for model.
    """

    def __init__(self, tokens_used: int, max_tokens: int, model: str):
        """
        Initialize context too large error.

        Args:
            tokens_used: Number of tokens used
            max_tokens: Maximum tokens allowed
            model: Model name
        """
        super().__init__(
            message=(
                f"Context size ({tokens_used:,} tokens) exceeds "
                f"model limit ({max_tokens:,} tokens)"
            ),
            recoverable=True,
            suggestion=(
                "Reduce context size:\n"
                "  1. Use fewer code chunks (--top-k parameter)\n"
                "  2. Clear conversation history (/reset in chat)\n"
                "  3. Use a model with larger context window"
            ),
            details={
                'tokens_used': tokens_used,
                'max_tokens': max_tokens,
                'model': model,
                'overflow': tokens_used - max_tokens
            }
        )
