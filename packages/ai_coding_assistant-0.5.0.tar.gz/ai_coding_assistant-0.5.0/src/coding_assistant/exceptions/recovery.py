"""Error recovery utilities."""

import time
from typing import Callable, Any, Optional, Type
from functools import wraps
from rich.console import Console

from coding_assistant.exceptions.base import AssistantError

console = Console()


class ErrorRecovery:
    """
    Utilities for error recovery and retry logic.

    Provides decorators and helpers for handling transient failures.
    """

    @staticmethod
    def retry(
        max_attempts: int = 3,
        delay: float = 1.0,
        backoff: float = 2.0,
        exceptions: tuple = (Exception,),
        on_retry: Optional[Callable] = None
    ):
        """
        Retry decorator with exponential backoff.

        Args:
            max_attempts: Maximum number of attempts
            delay: Initial delay between retries (seconds)
            backoff: Backoff multiplier
            exceptions: Exceptions to catch and retry
            on_retry: Callback function called on each retry

        Usage:
            @ErrorRecovery.retry(max_attempts=3, delay=1.0)
            def flaky_function():
                # May fail occasionally
                pass
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                current_delay = delay

                for attempt in range(1, max_attempts + 1):
                    try:
                        return func(*args, **kwargs)

                    except exceptions as e:
                        if attempt == max_attempts:
                            # Last attempt failed, re-raise
                            raise

                        # Log retry
                        if on_retry:
                            on_retry(attempt, max_attempts, e)
                        else:
                            console.print(
                                f"[yellow]⚠️  Attempt {attempt}/{max_attempts} failed: {e}[/yellow]"
                            )
                            console.print(
                                f"[yellow]   Retrying in {current_delay:.1f}s...[/yellow]"
                            )

                        # Wait before retry
                        time.sleep(current_delay)
                        current_delay *= backoff

            return wrapper
        return decorator

    @staticmethod
    def fallback(
        fallback_func: Callable,
        exceptions: tuple = (Exception,),
        log_error: bool = True
    ):
        """
        Fallback decorator - use fallback function on error.

        Args:
            fallback_func: Function to call on error
            exceptions: Exceptions to catch
            log_error: Whether to log the error

        Usage:
            def fallback_handler(*args, **kwargs):
                return default_value

            @ErrorRecovery.fallback(fallback_handler)
            def risky_function():
                # May fail
                pass
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                try:
                    return func(*args, **kwargs)

                except exceptions as e:
                    if log_error:
                        console.print(
                            f"[yellow]⚠️  {func.__name__} failed: {e}[/yellow]"
                        )
                        console.print(
                            f"[yellow]   Using fallback...[/yellow]"
                        )

                    return fallback_func(*args, **kwargs)

            return wrapper
        return decorator

    @staticmethod
    def graceful_degradation(
        default_value: Any = None,
        exceptions: tuple = (Exception,),
        log_error: bool = True
    ):
        """
        Graceful degradation - return default value on error.

        Args:
            default_value: Value to return on error
            exceptions: Exceptions to catch
            log_error: Whether to log the error

        Usage:
            @ErrorRecovery.graceful_degradation(default_value=[])
            def get_items():
                # May fail
                return items
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                try:
                    return func(*args, **kwargs)

                except exceptions as e:
                    if log_error:
                        console.print(
                            f"[yellow]⚠️  {func.__name__} failed: {e}[/yellow]"
                        )
                        console.print(
                            f"[yellow]   Returning default value: {default_value}[/yellow]"
                        )

                    return default_value

            return wrapper
        return decorator

    @staticmethod
    def handle_error(
        error: Exception,
        console: Optional[Console] = None,
        exit_on_fatal: bool = True
    ) -> None:
        """
        Handle error with appropriate user feedback.

        Args:
            error: Error to handle
            console: Rich console for output
            exit_on_fatal: Whether to exit on non-recoverable errors
        """
        if console is None:
            console = Console()

        # Check if it's our custom error
        if isinstance(error, AssistantError):
            # Show formatted error message
            console.print(error.format_message())

            # Exit if not recoverable
            if not error.recoverable and exit_on_fatal:
                console.print("\n[red]Exiting due to fatal error.[/red]")
                raise SystemExit(1)

        else:
            # Generic error
            console.print(f"[red]❌ Unexpected error: {error}[/red]")
            console.print(f"[dim]Error type: {type(error).__name__}[/dim]")

            if exit_on_fatal:
                console.print("\n[yellow]💡 Suggestion: Run with --verbose for more details[/yellow]")
                raise SystemExit(1)

    @staticmethod
    def safe_execute(
        func: Callable,
        *args,
        default_value: Any = None,
        log_error: bool = True,
        **kwargs
    ) -> Any:
        """
        Safely execute function, returning default value on error.

        Args:
            func: Function to execute
            *args: Function arguments
            default_value: Value to return on error
            log_error: Whether to log errors
            **kwargs: Function keyword arguments

        Returns:
            Function result or default value
        """
        try:
            return func(*args, **kwargs)

        except Exception as e:
            if log_error:
                console.print(
                    f"[yellow]⚠️  {func.__name__} failed: {e}[/yellow]"
                )

            return default_value

    @staticmethod
    def validate_or_exit(
        condition: bool,
        error_message: str,
        suggestion: Optional[str] = None
    ) -> None:
        """
        Validate condition or exit with error message.

        Args:
            condition: Condition to check
            error_message: Error message if condition fails
            suggestion: Optional suggestion
        """
        if not condition:
            console.print(f"[red]❌ Error: {error_message}[/red]")

            if suggestion:
                console.print(f"[yellow]💡 Suggestion: {suggestion}[/yellow]")

            raise SystemExit(1)


# Convenience decorators
def retry_on_failure(max_attempts: int = 3, delay: float = 1.0):
    """Shorthand for retry decorator."""
    return ErrorRecovery.retry(max_attempts=max_attempts, delay=delay)


def with_fallback(fallback_func: Callable):
    """Shorthand for fallback decorator."""
    return ErrorRecovery.fallback(fallback_func)


def ignore_errors(default_value: Any = None):
    """Shorthand for graceful degradation decorator."""
    return ErrorRecovery.graceful_degradation(default_value=default_value)
