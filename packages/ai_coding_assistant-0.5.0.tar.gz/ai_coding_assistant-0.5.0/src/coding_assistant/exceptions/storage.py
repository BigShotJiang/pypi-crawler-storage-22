"""Storage and index-related exceptions."""

from typing import Optional
from pathlib import Path
from coding_assistant.exceptions.base import AssistantError


class StorageError(AssistantError):
    """Base exception for storage-related errors."""

    def __init__(
        self,
        message: str,
        recoverable: bool = True,
        suggestion: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            message=message,
            recoverable=recoverable,
            suggestion=suggestion,
            error_code="STORAGE_ERROR",
            **kwargs
        )


class IndexError(StorageError):
    """Base exception for index-related errors."""
    pass


class IndexNotFoundError(IndexError):
    """
    Codebase index not found.

    Raised when trying to query/search before indexing.
    """

    def __init__(self, project_path: Optional[Path] = None):
        """
        Initialize index not found error.

        Args:
            project_path: Path to project
        """
        message = "Codebase has not been indexed yet"
        if project_path:
            message += f" for project: {project_path}"

        super().__init__(
            message=message,
            recoverable=True,
            suggestion=(
                "Index your codebase first:\n"
                "  assistant index\n"
                "\n"
                "Or specify max files:\n"
                "  assistant index --max-files 200"
            ),
            details={'project_path': str(project_path) if project_path else None}
        )


class IndexCorruptedError(IndexError):
    """
    Index is corrupted or unreadable.

    Raised when index exists but cannot be loaded.
    """

    def __init__(self, reason: Optional[str] = None):
        """
        Initialize index corrupted error.

        Args:
            reason: Reason for corruption
        """
        message = "Index is corrupted and cannot be loaded"
        if reason:
            message += f": {reason}"

        super().__init__(
            message=message,
            recoverable=True,
            suggestion=(
                "Rebuild the index:\n"
                "  assistant index --force\n"
                "\n"
                "This will recreate the index from scratch."
            ),
            details={'reason': reason}
        )


class IndexingError(IndexError):
    """
    Error occurred during indexing.

    Raised when indexing process fails.
    """

    def __init__(self, file_path: Optional[str] = None, reason: Optional[str] = None):
        """
        Initialize indexing error.

        Args:
            file_path: File being indexed when error occurred
            reason: Reason for failure
        """
        message = "Indexing failed"
        if file_path:
            message += f" while processing {file_path}"
        if reason:
            message += f": {reason}"

        super().__init__(
            message=message,
            recoverable=True,
            suggestion="Try indexing again or exclude problematic files",
            details={
                'file_path': file_path,
                'reason': reason
            }
        )


class SessionError(StorageError):
    """Base exception for session-related errors."""
    pass


class SessionNotFoundError(SessionError):
    """
    Session not found.

    Raised when trying to access non-existent session.
    """

    def __init__(self, session_id: int):
        """
        Initialize session not found error.

        Args:
            session_id: Session ID
        """
        super().__init__(
            message=f"Session {session_id} not found",
            recoverable=True,
            suggestion="Check session ID or start a new session with 'assistant chat'",
            details={'session_id': session_id}
        )


class DatabaseError(StorageError):
    """
    Database operation failed.

    Raised when SQLite operations fail.
    """

    def __init__(self, operation: str, reason: Optional[str] = None):
        """
        Initialize database error.

        Args:
            operation: Database operation being performed
            reason: Reason for failure
        """
        message = f"Database operation '{operation}' failed"
        if reason:
            message += f": {reason}"

        super().__init__(
            message=message,
            recoverable=True,
            suggestion="Check database permissions and disk space",
            details={
                'operation': operation,
                'reason': reason
            }
        )


class CacheError(StorageError):
    """
    Cache operation failed.

    Raised when cache read/write fails.
    """

    def __init__(self, operation: str, cache_type: str, reason: Optional[str] = None):
        """
        Initialize cache error.

        Args:
            operation: Cache operation (get, set, delete)
            cache_type: Type of cache (embedding, response)
            reason: Reason for failure
        """
        message = f"Cache {operation} failed for {cache_type} cache"
        if reason:
            message += f": {reason}"

        super().__init__(
            message=message,
            recoverable=True,  # Cache failures should not break functionality
            suggestion="Cache will be bypassed. Clear cache if issues persist:\n  rm -rf .assistant/cache",
            details={
                'operation': operation,
                'cache_type': cache_type,
                'reason': reason
            }
        )
