"""Input validation exceptions."""

from typing import Optional
from pathlib import Path
from coding_assistant.exceptions.base import AssistantError


class ValidationError(AssistantError):
    """
    Base exception for validation errors.

    Raised when user input is invalid.
    """

    def __init__(
        self,
        field: str,
        reason: str,
        value: Optional[str] = None,
        suggestion: Optional[str] = None
    ):
        """
        Initialize validation error.

        Args:
            field: Field name that failed validation
            reason: Reason for validation failure
            value: Invalid value (optional)
            suggestion: Suggestion for fixing
        """
        message = f"Invalid {field}: {reason}"

        if not suggestion:
            suggestion = f"Please provide a valid {field}"

        super().__init__(
            message=message,
            recoverable=True,
            suggestion=suggestion,
            error_code="VALIDATION_ERROR",
            details={
                'field': field,
                'reason': reason,
                'value': value
            }
        )


class FileNotFoundError(ValidationError):
    """
    File not found.

    Raised when specified file does not exist.
    """

    def __init__(self, file_path: Path):
        """
        Initialize file not found error.

        Args:
            file_path: Path to missing file
        """
        super().__init__(
            field="file path",
            reason=f"File not found: {file_path}",
            value=str(file_path),
            suggestion=f"Check that the file exists:\n  ls {file_path}"
        )


class InvalidQueryError(ValidationError):
    """
    Invalid search query.

    Raised when search query is malformed or too short/long.
    """

    def __init__(self, query: str, reason: str):
        """
        Initialize invalid query error.

        Args:
            query: Invalid query
            reason: Reason for invalidity
        """
        super().__init__(
            field="query",
            reason=reason,
            value=query[:50] + "..." if len(query) > 50 else query,
            suggestion="Provide a clear, specific query (3-500 characters)"
        )


class InvalidParameterError(ValidationError):
    """
    Invalid parameter value.

    Raised when command parameter is invalid.
    """

    def __init__(
        self,
        parameter: str,
        value: any,
        expected: str,
        suggestion: Optional[str] = None
    ):
        """
        Initialize invalid parameter error.

        Args:
            parameter: Parameter name
            value: Invalid value
            expected: Expected value description
            suggestion: Optional suggestion
        """
        super().__init__(
            field=parameter,
            reason=f"Expected {expected}, got {type(value).__name__}: {value}",
            value=str(value),
            suggestion=suggestion or f"Provide a valid {parameter} ({expected})"
        )


class EmptyInputError(ValidationError):
    """
    Empty input provided.

    Raised when required input is empty.
    """

    def __init__(self, field: str):
        """
        Initialize empty input error.

        Args:
            field: Field name
        """
        super().__init__(
            field=field,
            reason="Input cannot be empty",
            value="",
            suggestion=f"Provide a non-empty {field}"
        )


class PathSecurityError(ValidationError):
    """
    Potentially dangerous file path.

    Raised when path contains suspicious patterns.
    """

    def __init__(self, file_path: Path, reason: str):
        """
        Initialize path security error.

        Args:
            file_path: Suspicious path
            reason: Security concern
        """
        super().__init__(
            field="file path",
            reason=f"Security concern: {reason}",
            value=str(file_path),
            suggestion="Use a safe, absolute path within your project"
        )


class CodeSyntaxError(ValidationError):
    """
    Code has syntax errors.

    Raised when generated/modified code is invalid.
    """

    def __init__(
        self,
        file_path: Optional[str] = None,
        line: Optional[int] = None,
        message: Optional[str] = None
    ):
        """
        Initialize code syntax error.

        Args:
            file_path: File with syntax error
            line: Line number
            message: Error message from parser
        """
        reason = "Code has syntax errors"
        if file_path:
            reason += f" in {file_path}"
        if line:
            reason += f" at line {line}"
        if message:
            reason += f": {message}"

        super().__init__(
            field="code",
            reason=reason,
            value=None,
            suggestion="Fix syntax errors before applying changes"
        )


class ConfigurationError(ValidationError):
    """
    Configuration is invalid.

    Raised when config file has errors.
    """

    def __init__(self, config_file: Path, reason: str):
        """
        Initialize configuration error.

        Args:
            config_file: Configuration file path
            reason: What's wrong with the config
        """
        super().__init__(
            field="configuration",
            reason=reason,
            value=str(config_file),
            suggestion=(
                "Fix configuration errors or regenerate default config:\n"
                "  assistant config --generate"
            )
        )
