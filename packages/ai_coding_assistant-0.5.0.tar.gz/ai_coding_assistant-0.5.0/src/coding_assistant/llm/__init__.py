"""LLM integration module."""
