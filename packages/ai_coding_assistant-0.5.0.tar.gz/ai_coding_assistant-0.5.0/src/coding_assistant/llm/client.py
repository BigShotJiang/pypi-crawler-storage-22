"""LLM client implementations with pluggable providers."""
from abc import ABC, abstractmethod
from typing import List, Dict, Iterator
import requests
import json
import os


class BaseLLMClient(ABC):
    """Base class for all LLM clients."""

    @abstractmethod
    def generate(self, messages: List[Dict[str, str]], stream: bool = True) -> Iterator[str]:
        """Generate a response from the LLM."""
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Check if this provider is configured and available."""
        pass


class MockLLMClient(BaseLLMClient):
    """Mock LLM for testing and development without API keys."""

    def generate(self, messages: List[Dict[str, str]], stream: bool = True) -> Iterator[str]:
        """Generate a mock response."""
        # Extract user query from messages
        user_msg = messages[-1]['content'] if messages else "No query"

        response = f"[MOCK RESPONSE]\n\n"
        response += f"I received your query: {user_msg[:100]}...\n\n"
        response += "This is a mock LLM client for testing the infrastructure.\n\n"
        response += "To get real responses, choose one of these options:\n\n"
        response += "Option 1 - Local (FREE, Private, 8GB+ RAM needed):\n"
        response += "  1. Install Ollama: curl -fsSL https://ollama.com/install.sh | sh\n"
        response += "  2. Pull model: ollama pull qwen2.5-coder:7b\n"
        response += "  3. Start: ollama serve\n"
        response += "  4. The system will auto-detect and use it!\n\n"
        response += "Option 2 - Cloud (FREE tier, No local resources):\n"
        response += "  1. Get Groq API key: https://console.groq.com (FREE!)\n"
        response += "  2. Set key: assistant config set-api-key groq <your-key>\n"
        response += "  3. Start using immediately!\n\n"
        response += "Option 3 - Cloud (FREE tier, Google):\n"
        response += "  1. Get Gemini key: https://makersuite.google.com/app/apikey\n"
        response += "  2. Set key: assistant config set-api-key gemini <your-key>\n\n"
        response += "Option 4 - Cloud (FREE trial, $25 credits):\n"
        response += "  1. Get Together AI key: https://api.together.xyz\n"
        response += "  2. Set key: assistant config set-api-key together <your-key>\n\n"
        response += "Check your hardware: assistant config check-hardware\n"

        if stream:
            for char in response:
                yield char
        else:
            yield response

    def is_available(self) -> bool:
        """Always available."""
        return True


class OllamaClient(BaseLLMClient):
    """Local LLM via Ollama (no API keys needed)."""

    def __init__(self, model: str = "deepseek-coder:6.7b", base_url: str = "http://localhost:11434"):
        self.model = model
        self.base_url = base_url

    def generate(self, messages: List[Dict[str, str]], stream: bool = True) -> Iterator[str]:
        """Generate response from Ollama."""
        try:
            # Use the chat API which is better for multi-turn conversations
            # Convert messages to Ollama format (role: user/assistant/system)
            ollama_messages = []
            for msg in messages:
                role = msg.get('role', 'user')
                # Map OpenAI roles to Ollama roles
                if role == 'system':
                    ollama_role = 'system'
                elif role == 'assistant':
                    ollama_role = 'assistant'
                else:
                    ollama_role = 'user'
                
                ollama_messages.append({
                    'role': ollama_role,
                    'content': msg.get('content', '')
                })

            response = requests.post(
                f"{self.base_url}/api/chat",
                json={
                    "model": self.model,
                    "messages": ollama_messages,
                    "stream": stream
                },
                stream=stream,
                timeout=120  # Increased timeout for slower models
            )
            response.raise_for_status()

            if stream:
                for line in response.iter_lines():
                    if line:
                        try:
                            chunk = json.loads(line)
                            if 'message' in chunk and 'content' in chunk['message']:
                                content = chunk['message']['content']
                                if content:
                                    yield content
                            elif 'response' in chunk:
                                # Fallback for generate API format
                                yield chunk['response']
                        except json.JSONDecodeError:
                            continue
            else:
                result = response.json()
                if 'message' in result and 'content' in result['message']:
                    yield result['message']['content']
                else:
                    yield result.get('response', '')

        except requests.exceptions.Timeout:
            yield f"Error: Request to Ollama timed out after 120 seconds.\n"
            yield "The model might be slow to respond. Try:\n"
            yield "  1. Using a smaller/faster model\n"
            yield "  2. Checking system resources (CPU/RAM)\n"
            yield "  3. Using a cloud provider (Groq/Together AI)\n"
        except Exception as e:
            yield f"Error connecting to Ollama: {e}\n"
            yield "Make sure Ollama is running: ollama serve\n"

    def _messages_to_prompt(self, messages: List[Dict[str, str]]) -> str:
        """Convert chat messages to a single prompt."""
        prompt = ""
        for msg in messages:
            role = msg.get('role', 'user').upper()
            content = msg.get('content', '')
            prompt += f"{role}: {content}\n\n"
        prompt += "ASSISTANT: "
        return prompt

    def is_available(self) -> bool:
        """Check if Ollama is running."""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=2)
            return response.status_code == 200
        except:
            return False


class LLMClientFactory:
    """Factory to create the best available LLM client."""

    @staticmethod
    def create_client(preferred_provider: str = None) -> BaseLLMClient:
        """
        Create an LLM client, trying providers in order of preference.

        Priority is hardware-aware:
        - High RAM (8GB+): Ollama → Groq → Together → Mock
        - Low RAM (<8GB): Groq → Together → Ollama → Mock
        """
        from coding_assistant.config.settings import settings
        # Import here to avoid import issues if psutil not available
        from coding_assistant.utils.hardware import HardwareDetector

        # Check if user specified a preferred provider
        if preferred_provider:
            client = LLMClientFactory._create_specific(preferred_provider)
            if client and client.is_available():
                return client
            else:
                print(f"⚠️  {preferred_provider} not available, trying alternatives...")

        # Get hardware info for smart provider selection
        hw_info = HardwareDetector.get_hardware_info()

        # Import here to avoid circular import
        from coding_assistant.llm.groq_client import GroqClient
        from coding_assistant.llm.together_client import TogetherClient
        from coding_assistant.llm.gemini_client import GeminiClient

        # Build provider list based on hardware capabilities
        if hw_info.can_run_local:
            # Sufficient RAM for local models - prefer Ollama
            providers = [
                ('Ollama', lambda: OllamaClient(
                    model=settings.ollama_model,
                    base_url=settings.ollama_base_url
                )),
                ('Groq', lambda: GroqClient(
                    api_key=settings.groq_api_key,
                    model=settings.groq_model
                )),
                ('Gemini', lambda: GeminiClient(
                    api_key=settings.gemini_api_key,
                    model=settings.gemini_model
                )),
                ('Together AI', lambda: TogetherClient(
                    api_key=settings.together_api_key,
                    model=settings.together_model
                )),
                ('Mock', MockLLMClient),
            ]
        else:
            # Limited RAM - prefer cloud providers
            providers = [
                ('Groq', lambda: GroqClient(
                    api_key=settings.groq_api_key,
                    model=settings.groq_model
                )),
                ('Gemini', lambda: GeminiClient(
                    api_key=settings.gemini_api_key,
                    model=settings.gemini_model
                )),
                ('Together AI', lambda: TogetherClient(
                    api_key=settings.together_api_key,
                    model=settings.together_model
                )),
                ('Ollama', lambda: OllamaClient(
                    model=settings.ollama_model,
                    base_url=settings.ollama_base_url
                )),
                ('Mock', MockLLMClient),
            ]

        # Try providers in order
        for name, ClientClass in providers:
            try:
                client = ClientClass()
                if client.is_available():
                    from rich.console import Console
                    console = Console()
                    console.print(f"[bold #10B981]✓[/bold #10B981] [bold #8B5CF6]Using {name}[/bold #8B5CF6] [dim]LLM provider[/dim]")
                    return client
            except Exception as e:
                continue

        # Fallback to mock (should never reach here)
        print("⚠️  No LLM providers available, using Mock client")
        print("💡 Tip: Run 'assistant config check-hardware' for setup recommendations")
        return MockLLMClient()

    @staticmethod
    def _create_specific(provider_name: str) -> BaseLLMClient:
        """Create a specific provider by name."""
        from coding_assistant.config.settings import settings
        # Import here to avoid circular import
        from coding_assistant.llm.groq_client import GroqClient
        from coding_assistant.llm.together_client import TogetherClient
        from coding_assistant.llm.gemini_client import GeminiClient

        if provider_name.lower() == 'ollama':
            return OllamaClient(
                model=settings.ollama_model,
                base_url=settings.ollama_base_url
            )
        elif provider_name.lower() == 'groq':
            return GroqClient(
                api_key=settings.groq_api_key,
                model=settings.groq_model
            )
        elif provider_name.lower() == 'gemini':
            return GeminiClient(
                api_key=settings.gemini_api_key,
                model=settings.gemini_model
            )
        elif provider_name.lower() == 'together':
            return TogetherClient(
                api_key=settings.together_api_key,
                model=settings.together_model
            )
        elif provider_name.lower() == 'mock':
            return MockLLMClient()
        return None
