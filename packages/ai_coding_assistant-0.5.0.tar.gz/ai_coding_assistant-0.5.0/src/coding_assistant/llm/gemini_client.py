"""Google Gemini LLM client implementation."""

from typing import List, Dict, Iterator, Optional
import requests
import json
from coding_assistant.llm.client import BaseLLMClient
from coding_assistant.exceptions.llm import (
    LLMConnectionError,
    LLMResponseError,
    LLMTimeoutError
)


class GeminiClient(BaseLLMClient):
    """Google Gemini cloud LLM client."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-2.0-flash-exp",
        base_url: str = "https://generativelanguage.googleapis.com/v1beta"
    ):
        """
        Initialize Gemini client.

        Args:
            api_key: Gemini API key
            model: Model name (gemini-2.0-flash-exp, gemini-1.5-pro, etc.)
            base_url: API base URL
        """
        self.api_key = api_key
        self.model = model
        self.base_url = base_url

    def generate(self, messages: List[Dict[str, str]], stream: bool = True) -> Iterator[str]:
        """
        Generate response from Gemini.

        Args:
            messages: List of message dicts with 'role' and 'content'
            stream: Whether to stream the response

        Yields:
            Response chunks
        """
        if not self.api_key:
            raise LLMConnectionError(
                provider="gemini",
                endpoint=self.base_url,
                reason="API key not set"
            )

        # Convert messages to Gemini format
        gemini_contents = []
        for msg in messages:
            role = msg.get('role', 'user')
            # Map roles: user -> user, assistant -> model, system -> user (with prefix)
            if role == 'system':
                gemini_contents.append({
                    "role": "user",
                    "parts": [{"text": f"System: {msg.get('content', '')}"}]
                })
            elif role == 'assistant':
                gemini_contents.append({
                    "role": "model",
                    "parts": [{"text": msg.get('content', '')}]
                })
            else:  # user
                gemini_contents.append({
                    "role": "user",
                    "parts": [{"text": msg.get('content', '')}]
                })

        payload = {
            "contents": gemini_contents
        }

        try:
            # Gemini uses API key as query parameter
            url = f"{self.base_url}/models/{self.model}:{'streamGenerateContent' if stream else 'generateContent'}"
            params = {"key": self.api_key}

            response = requests.post(
                url,
                params=params,
                headers={"Content-Type": "application/json"},
                json=payload,
                stream=stream,
                timeout=120
            )

            # Check for errors
            if response.status_code == 400:
                raise LLMResponseError(
                    message="Invalid request. Check your message format.",
                    provider="gemini",
                    status_code=response.status_code,
                    response_text=response.text
                )
            elif response.status_code == 401 or response.status_code == 403:
                raise LLMResponseError(
                    message="Authentication failed. Check your API key.",
                    provider="gemini",
                    status_code=response.status_code,
                    response_text=response.text
                )
            elif response.status_code == 429:
                raise LLMResponseError(
                    message="Rate limit exceeded. Please wait and try again.",
                    provider="gemini",
                    status_code=429,
                    response_text=response.text
                )
            elif response.status_code >= 400:
                raise LLMResponseError(
                    message=f"API error: {response.status_code}",
                    provider="gemini",
                    status_code=response.status_code,
                    response_text=response.text
                )

            if stream:
                # Parse streaming response (JSON lines)
                for line in response.iter_lines():
                    if line:
                        try:
                            chunk = json.loads(line)
                            # Extract content from candidates
                            if 'candidates' in chunk and len(chunk['candidates']) > 0:
                                candidate = chunk['candidates'][0]
                                if 'content' in candidate and 'parts' in candidate['content']:
                                    for part in candidate['content']['parts']:
                                        if 'text' in part:
                                            yield part['text']
                        except json.JSONDecodeError:
                            continue
            else:
                # Non-streaming response
                result = response.json()
                if 'candidates' in result and len(result['candidates']) > 0:
                    candidate = result['candidates'][0]
                    if 'content' in candidate and 'parts' in candidate['content']:
                        for part in candidate['content']['parts']:
                            if 'text' in part:
                                yield part['text']

        except requests.exceptions.Timeout:
            raise LLMTimeoutError(
                provider="gemini",
                timeout_seconds=120
            )
        except requests.exceptions.ConnectionError as e:
            raise LLMConnectionError(
                provider="gemini",
                endpoint=self.base_url,
                reason=str(e)
            )
        except (LLMConnectionError, LLMResponseError, LLMTimeoutError):
            # Re-raise our custom exceptions
            raise
        except Exception as e:
            raise LLMConnectionError(
                provider="gemini",
                endpoint=self.base_url,
                reason=f"Unexpected error: {str(e)}"
            )

    def is_available(self) -> bool:
        """
        Check if Gemini is available.

        Returns:
            True if API key is set
        """
        # Basic check: API key is set
        if not self.api_key:
            return False

        # Could optionally validate with API call here
        # but keeping it simple for now to avoid unnecessary API calls
        return True
