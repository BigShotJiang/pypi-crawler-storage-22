"""Groq LLM client implementation."""

from typing import List, Dict, Iterator, Optional
import requests
import json
from coding_assistant.llm.client import BaseLLMClient
from coding_assistant.exceptions.llm import (
    LLMConnectionError,
    LLMResponseError,
    LLMTimeoutError
)


class GroqClient(BaseLLMClient):
    """Groq cloud LLM client (OpenAI-compatible API)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "llama-3.3-70b-versatile",
        base_url: str = "https://api.groq.com/openai/v1"
    ):
        """
        Initialize Groq client.

        Args:
            api_key: Groq API key
            model: Model name (default: qwen-2.5-coder-32b-instruct)
            base_url: API base URL
        """
        self.api_key = api_key
        self.model = model
        self.base_url = base_url

    def generate(self, messages: List[Dict[str, str]], stream: bool = True) -> Iterator[str]:
        """
        Generate response from Groq.

        Args:
            messages: List of message dicts with 'role' and 'content'
            stream: Whether to stream the response

        Yields:
            Response chunks
        """
        if not self.api_key:
            raise LLMConnectionError(
                provider="groq",
                endpoint=self.base_url,
                reason="API key not set"
            )

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": self.model,
            "messages": messages,
            "stream": stream
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                stream=stream,
                timeout=120
            )

            # Check for errors
            if response.status_code == 401 or response.status_code == 403:
                raise LLMResponseError(
                    message="Authentication failed. Check your API key.",
                    provider="groq",
                    status_code=response.status_code,
                    response_text=response.text
                )
            elif response.status_code == 429:
                raise LLMResponseError(
                    message="Rate limit exceeded. Please wait and try again.",
                    provider="groq",
                    status_code=429,
                    response_text=response.text
                )
            elif response.status_code >= 400:
                raise LLMResponseError(
                    message=f"API error: {response.status_code}",
                    provider="groq",
                    status_code=response.status_code,
                    response_text=response.text
                )

            if stream:
                # Parse Server-Sent Events (SSE)
                for line in response.iter_lines():
                    if line:
                        line_str = line.decode('utf-8')
                        # SSE format: "data: {json}"
                        if line_str.startswith('data: '):
                            data_str = line_str[6:]  # Remove "data: " prefix

                            # Check for end of stream
                            if data_str.strip() == '[DONE]':
                                break

                            try:
                                chunk = json.loads(data_str)
                                # Extract content from delta
                                if 'choices' in chunk and len(chunk['choices']) > 0:
                                    delta = chunk['choices'][0].get('delta', {})
                                    content = delta.get('content', '')
                                    if content:
                                        yield content
                            except json.JSONDecodeError:
                                continue
            else:
                # Non-streaming response
                result = response.json()
                if 'choices' in result and len(result['choices']) > 0:
                    content = result['choices'][0]['message']['content']
                    yield content

        except requests.exceptions.Timeout:
            raise LLMTimeoutError(
                provider="groq",
                timeout_seconds=120
            )
        except requests.exceptions.ConnectionError as e:
            raise LLMConnectionError(
                provider="groq",
                endpoint=self.base_url,
                reason=str(e)
            )
        except (LLMConnectionError, LLMResponseError, LLMTimeoutError):
            # Re-raise our custom exceptions
            raise
        except Exception as e:
            raise LLMConnectionError(
                provider="groq",
                endpoint=self.base_url,
                reason=f"Unexpected error: {str(e)}"
            )

    def is_available(self) -> bool:
        """
        Check if Groq is available.

        Returns:
            True if API key is set
        """
        # Basic check: API key is set
        if not self.api_key:
            return False

        # Could optionally validate with API call here
        # but keeping it simple for now to avoid unnecessary API calls
        return True
