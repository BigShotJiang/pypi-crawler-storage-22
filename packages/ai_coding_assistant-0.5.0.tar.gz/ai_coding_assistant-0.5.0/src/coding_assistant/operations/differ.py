"""Generate and display code diffs."""

import difflib
from typing import List, Optional, Tuple
from pathlib import Path
from rich.console import Console
from rich.syntax import Syntax
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


class DiffGenerator:
    """Generate and display code differences."""

    def __init__(self):
        """Initialize the diff generator."""
        self.console = Console()

    def generate_diff(self, original: str, modified: str,
                     filepath: Optional[str] = None,
                     context_lines: int = 3) -> str:
        """
        Generate a unified diff between two code versions.

        Args:
            original: The original code
            modified: The modified code
            filepath: Optional file path for diff headers
            context_lines: Number of context lines to include

        Returns:
            Unified diff as a string
        """
        original_lines = original.splitlines(keepends=True)
        modified_lines = modified.splitlines(keepends=True)

        filename = filepath or 'file'

        diff = difflib.unified_diff(
            original_lines,
            modified_lines,
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}",
            lineterm='',
            n=context_lines
        )

        return ''.join(diff)

    def generate_side_by_side_diff(self, original: str, modified: str) -> List[Tuple[str, str, str]]:
        """
        Generate a side-by-side diff.

        Args:
            original: The original code
            modified: The modified code

        Returns:
            List of (status, original_line, modified_line) tuples
            status can be: 'unchanged', 'modified', 'added', 'removed'
        """
        original_lines = original.splitlines()
        modified_lines = modified.splitlines()

        matcher = difflib.SequenceMatcher(None, original_lines, modified_lines)
        result = []

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                for i in range(i1, i2):
                    result.append(('unchanged', original_lines[i], modified_lines[j1 + (i - i1)]))
            elif tag == 'replace':
                # Lines were modified
                for i in range(i1, i2):
                    old_line = original_lines[i] if i < len(original_lines) else ''
                    new_line = modified_lines[j1 + (i - i1)] if (j1 + (i - i1)) < len(modified_lines) else ''
                    result.append(('modified', old_line, new_line))
            elif tag == 'delete':
                for i in range(i1, i2):
                    result.append(('removed', original_lines[i], ''))
            elif tag == 'insert':
                for j in range(j1, j2):
                    result.append(('added', '', modified_lines[j]))

        return result

    def display_diff(self, diff_text: str, language: str = 'diff',
                    title: Optional[str] = None):
        """
        Display a unified diff in the terminal with syntax highlighting.

        Args:
            diff_text: The unified diff text
            language: Language for syntax highlighting (default: diff)
            title: Optional title for the diff panel
        """
        if not diff_text.strip():
            self.console.print("[yellow]No changes detected[/yellow]")
            return

        syntax = Syntax(
            diff_text,
            'diff',
            theme='monokai',
            line_numbers=False,
            word_wrap=False
        )

        if title:
            self.console.print(Panel(syntax, title=title, border_style="blue"))
        else:
            self.console.print(syntax)

    def display_side_by_side(self, original: str, modified: str,
                            title: Optional[str] = None,
                            language: str = 'python'):
        """
        Display a side-by-side diff with color coding.

        Args:
            original: The original code
            modified: The modified code
            title: Optional title
            language: Programming language for context
        """
        diff_lines = self.generate_side_by_side_diff(original, modified)

        table = Table(
            title=title,
            show_header=True,
            header_style="bold magenta",
            border_style="blue",
            show_lines=True
        )

        table.add_column("", width=3)  # Status indicator
        table.add_column("Line", width=5)
        table.add_column("Original", style="dim")
        table.add_column("Modified", style="dim")

        line_num = 1
        for status, old_line, new_line in diff_lines:
            if status == 'unchanged':
                icon = " "
                style = "dim"
            elif status == 'modified':
                icon = "~"
                style = "yellow"
            elif status == 'added':
                icon = "+"
                style = "green"
            elif status == 'removed':
                icon = "-"
                style = "red"

            table.add_row(
                f"[{style}]{icon}[/{style}]",
                str(line_num),
                old_line[:80],  # Truncate long lines
                new_line[:80],
                style=style
            )
            line_num += 1

        self.console.print(table)

    def display_summary(self, diff_text: str):
        """
        Display a summary of changes.

        Args:
            diff_text: The unified diff text
        """
        lines = diff_text.split('\n')

        added = sum(1 for line in lines if line.startswith('+') and not line.startswith('+++'))
        removed = sum(1 for line in lines if line.startswith('-') and not line.startswith('---'))
        modified = min(added, removed)
        net_added = added - modified
        net_removed = removed - modified

        summary = Text()
        summary.append("Changes: ", style="bold")

        if modified > 0:
            summary.append(f"{modified} modified ", style="yellow")
        if net_added > 0:
            summary.append(f"{net_added} added ", style="green")
        if net_removed > 0:
            summary.append(f"{net_removed} removed ", style="red")

        if not any([modified, net_added, net_removed]):
            summary.append("No changes", style="dim")

        self.console.print(summary)

    def generate_patch(self, original: str, modified: str,
                      filepath: str) -> str:
        """
        Generate a patch file that can be applied with `patch` command.

        Args:
            original: The original code
            modified: The modified code
            filepath: The file path for the patch

        Returns:
            Patch content as string
        """
        return self.generate_diff(original, modified, filepath, context_lines=3)

    def apply_patch(self, original: str, patch: str) -> Optional[str]:
        """
        Apply a patch to original content.

        Args:
            original: The original code
            patch: The unified diff patch

        Returns:
            Modified content if successful, None otherwise
        """
        try:
            original_lines = original.splitlines(keepends=True)
            patch_lines = patch.splitlines(keepends=True)

            # Use difflib to apply patch
            # This is a simple implementation
            # For production, consider using a proper patch library

            result_lines = original_lines.copy()

            # Parse patch and apply
            # This is simplified - full patch parsing is complex
            # For now, just return None to indicate manual application needed

            return None  # TODO: Implement proper patch application

        except Exception:
            return None

    def compare_files(self, file1_path: str, file2_path: str,
                     display: bool = True) -> str:
        """
        Compare two files and generate a diff.

        Args:
            file1_path: Path to first file
            file2_path: Path to second file
            display: Whether to display the diff

        Returns:
            Unified diff as string
        """
        path1 = Path(file1_path)
        path2 = Path(file2_path)

        if not path1.exists():
            raise FileNotFoundError(f"File not found: {file1_path}")
        if not path2.exists():
            raise FileNotFoundError(f"File not found: {file2_path}")

        content1 = path1.read_text(encoding='utf-8')
        content2 = path2.read_text(encoding='utf-8')

        diff = self.generate_diff(content1, content2, file1_path)

        if display:
            self.display_diff(diff, title=f"{file1_path} vs {file2_path}")

        return diff

    def get_change_stats(self, diff_text: str) -> dict:
        """
        Get statistics about changes in a diff.

        Args:
            diff_text: The unified diff text

        Returns:
            Dict with stats: lines_added, lines_removed, files_changed, etc.
        """
        lines = diff_text.split('\n')

        stats = {
            'lines_added': 0,
            'lines_removed': 0,
            'lines_modified': 0,
            'files_changed': 0,
            'hunks': 0
        }

        for line in lines:
            if line.startswith('+++'):
                stats['files_changed'] += 1
            elif line.startswith('@@'):
                stats['hunks'] += 1
            elif line.startswith('+') and not line.startswith('+++'):
                stats['lines_added'] += 1
            elif line.startswith('-') and not line.startswith('---'):
                stats['lines_removed'] += 1

        stats['lines_modified'] = min(stats['lines_added'], stats['lines_removed'])
        stats['net_change'] = stats['lines_added'] - stats['lines_removed']

        return stats

    def highlight_changes(self, original: str, modified: str,
                         language: str = 'python') -> Tuple[str, str]:
        """
        Highlight specific character-level changes between lines.

        Args:
            original: Original code line
            modified: Modified code line
            language: Programming language

        Returns:
            Tuple of (highlighted_original, highlighted_modified)
        """
        # Use SequenceMatcher for character-level diff
        matcher = difflib.SequenceMatcher(None, original, modified)

        orig_highlighted = []
        mod_highlighted = []

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                orig_highlighted.append(original[i1:i2])
                mod_highlighted.append(modified[j1:j2])
            elif tag == 'replace':
                orig_highlighted.append(f"[red]{original[i1:i2]}[/red]")
                mod_highlighted.append(f"[green]{modified[j1:j2]}[/green]")
            elif tag == 'delete':
                orig_highlighted.append(f"[red]{original[i1:i2]}[/red]")
            elif tag == 'insert':
                mod_highlighted.append(f"[green]{modified[j1:j2]}[/green]")

        return ''.join(orig_highlighted), ''.join(mod_highlighted)

    def format_diff_for_display(self, diff_text: str) -> str:
        """
        Format diff text for better terminal display.

        Args:
            diff_text: Raw unified diff

        Returns:
            Formatted diff with colors
        """
        lines = diff_text.split('\n')
        formatted = []

        for line in lines:
            if line.startswith('+++'):
                formatted.append(f"[blue]{line}[/blue]")
            elif line.startswith('---'):
                formatted.append(f"[blue]{line}[/blue]")
            elif line.startswith('@@'):
                formatted.append(f"[cyan]{line}[/cyan]")
            elif line.startswith('+'):
                formatted.append(f"[green]{line}[/green]")
            elif line.startswith('-'):
                formatted.append(f"[red]{line}[/red]")
            else:
                formatted.append(line)

        return '\n'.join(formatted)
