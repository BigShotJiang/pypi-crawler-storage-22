"""Linter integration for code quality checking."""

import subprocess
import json
import tempfile
import os
from typing import List, Dict, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass
from rich.console import Console
from rich.table import Table
from rich.panel import Panel


@dataclass
class LintIssue:
    """Represents a single linting issue."""
    file_path: str
    line: int
    column: int
    severity: str  # 'error', 'warning', 'info'
    code: str  # Error code (e.g., 'E501', 'no-unused-vars')
    message: str
    rule: Optional[str] = None
    fixable: bool = False

    def __repr__(self):
        return f"{self.file_path}:{self.line}:{self.column} [{self.severity}] {self.code}: {self.message}"


class LinterResult:
    """Result of linting operation."""

    def __init__(self, issues: List[LintIssue], fixed_code: Optional[str] = None):
        self.issues = issues
        self.fixed_code = fixed_code

    @property
    def has_errors(self) -> bool:
        """Check if there are any errors."""
        return any(issue.severity == 'error' for issue in self.issues)

    @property
    def has_warnings(self) -> bool:
        """Check if there are any warnings."""
        return any(issue.severity == 'warning' for issue in self.issues)

    @property
    def error_count(self) -> int:
        """Count of errors."""
        return sum(1 for issue in self.issues if issue.severity == 'error')

    @property
    def warning_count(self) -> int:
        """Count of warnings."""
        return sum(1 for issue in self.issues if issue.severity == 'warning')

    def __repr__(self):
        return f"LinterResult(errors={self.error_count}, warnings={self.warning_count})"


class LinterIntegration:
    """Integration with code linters (ruff for Python, eslint for JS/TS)."""

    def __init__(self, project_root: Optional[str] = None):
        """
        Initialize the linter integration.

        Args:
            project_root: Root directory of the project (for config files)
        """
        self.project_root = Path(project_root) if project_root else Path.cwd()
        self.console = Console()

        # Check availability of linters
        self._ruff_available = self._check_command('ruff')
        self._eslint_available = self._check_command('eslint') or self._check_command('npx')

    def lint(self, code: str, language: str,
            file_path: Optional[str] = None,
            auto_fix: bool = False) -> LinterResult:
        """
        Lint code for the given language.

        Args:
            code: The code to lint
            language: Programming language ('python', 'javascript', 'typescript')
            file_path: Optional file path (for better error messages)
            auto_fix: Whether to attempt automatic fixes

        Returns:
            LinterResult with issues and optionally fixed code
        """
        language = language.lower()

        if language == 'python':
            return self._lint_python(code, file_path, auto_fix)
        elif language in ('javascript', 'typescript', 'jsx', 'tsx'):
            return self._lint_javascript(code, file_path, language, auto_fix)
        else:
            # Unsupported language, return empty result
            return LinterResult(issues=[])

    def _lint_python(self, code: str, file_path: Optional[str] = None,
                    auto_fix: bool = False) -> LinterResult:
        """Lint Python code using ruff."""
        if not self._ruff_available:
            return LinterResult(issues=[])

        issues = []
        fixed_code = None

        # Create temp file for linting
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_path = f.name

        try:
            # Run ruff check
            result = subprocess.run(
                ['ruff', 'check', '--output-format=json', temp_path],
                capture_output=True,
                text=True,
                timeout=10
            )

            # Parse JSON output
            if result.stdout:
                try:
                    ruff_output = json.loads(result.stdout)
                    for item in ruff_output:
                        issues.append(LintIssue(
                            file_path=file_path or temp_path,
                            line=item.get('location', {}).get('row', 0),
                            column=item.get('location', {}).get('column', 0),
                            severity='error' if item.get('type') == 'Error' else 'warning',
                            code=item.get('code', 'unknown'),
                            message=item.get('message', ''),
                            rule=item.get('code'),
                            fixable=item.get('fix', {}).get('applicability') == 'automatic'
                        ))
                except json.JSONDecodeError:
                    pass

            # Try auto-fix if requested
            if auto_fix and issues:
                fix_result = subprocess.run(
                    ['ruff', 'check', '--fix', temp_path],
                    capture_output=True,
                    timeout=10
                )

                if fix_result.returncode == 0:
                    # Read fixed code
                    with open(temp_path, 'r') as f:
                        fixed_code = f.read()

                    # Format with ruff
                    format_result = subprocess.run(
                        ['ruff', 'format', temp_path],
                        capture_output=True,
                        timeout=10
                    )

                    if format_result.returncode == 0:
                        with open(temp_path, 'r') as f:
                            fixed_code = f.read()

        except subprocess.TimeoutExpired:
            issues.append(LintIssue(
                file_path=file_path or 'unknown',
                line=0,
                column=0,
                severity='error',
                code='timeout',
                message='Linter timed out'
            ))
        except Exception as e:
            issues.append(LintIssue(
                file_path=file_path or 'unknown',
                line=0,
                column=0,
                severity='error',
                code='error',
                message=f'Linter error: {str(e)}'
            ))
        finally:
            # Clean up temp file
            try:
                os.unlink(temp_path)
            except:
                pass

        return LinterResult(issues=issues, fixed_code=fixed_code)

    def _lint_javascript(self, code: str, file_path: Optional[str] = None,
                        language: str = 'javascript',
                        auto_fix: bool = False) -> LinterResult:
        """Lint JavaScript/TypeScript code using eslint."""
        if not self._eslint_available:
            return LinterResult(issues=[])

        issues = []
        fixed_code = None

        # Determine file extension
        extension_map = {
            'javascript': '.js',
            'typescript': '.ts',
            'jsx': '.jsx',
            'tsx': '.tsx'
        }
        extension = extension_map.get(language, '.js')

        # Create temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix=extension, delete=False) as f:
            f.write(code)
            temp_path = f.name

        try:
            # Build eslint command
            cmd = ['npx', 'eslint', '--format=json']
            if auto_fix:
                cmd.append('--fix')
            cmd.append(temp_path)

            # Run eslint
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=self.project_root,
                timeout=15
            )

            # Parse JSON output
            if result.stdout:
                try:
                    eslint_output = json.loads(result.stdout)
                    for file_result in eslint_output:
                        for msg in file_result.get('messages', []):
                            issues.append(LintIssue(
                                file_path=file_path or temp_path,
                                line=msg.get('line', 0),
                                column=msg.get('column', 0),
                                severity='error' if msg.get('severity') == 2 else 'warning',
                                code=msg.get('ruleId', 'unknown'),
                                message=msg.get('message', ''),
                                rule=msg.get('ruleId'),
                                fixable=msg.get('fix') is not None
                            ))
                except json.JSONDecodeError:
                    pass

            # If auto-fix was requested, read the fixed code
            if auto_fix:
                try:
                    with open(temp_path, 'r') as f:
                        fixed_code = f.read()
                except:
                    pass

        except subprocess.TimeoutExpired:
            issues.append(LintIssue(
                file_path=file_path or 'unknown',
                line=0,
                column=0,
                severity='error',
                code='timeout',
                message='Linter timed out'
            ))
        except FileNotFoundError:
            # eslint not found, skip silently
            pass
        except Exception as e:
            # Other errors, add as issue
            issues.append(LintIssue(
                file_path=file_path or 'unknown',
                line=0,
                column=0,
                severity='warning',
                code='linter-error',
                message=f'Linter unavailable: {str(e)}'
            ))
        finally:
            # Clean up temp file
            try:
                os.unlink(temp_path)
            except:
                pass

        return LinterResult(issues=issues, fixed_code=fixed_code)

    def lint_file(self, file_path: str, auto_fix: bool = False) -> LinterResult:
        """
        Lint a file based on its extension.

        Args:
            file_path: Path to the file to lint
            auto_fix: Whether to apply automatic fixes

        Returns:
            LinterResult
        """
        path = Path(file_path)

        if not path.exists():
            return LinterResult(issues=[LintIssue(
                file_path=file_path,
                line=0,
                column=0,
                severity='error',
                code='file-not-found',
                message=f'File not found: {file_path}'
            )])

        # Determine language from extension
        extension = path.suffix.lower()
        language_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.jsx': 'jsx',
            '.ts': 'typescript',
            '.tsx': 'tsx',
            '.mjs': 'javascript',
            '.cjs': 'javascript',
        }

        language = language_map.get(extension)
        if not language:
            return LinterResult(issues=[])

        # Read file and lint
        try:
            code = path.read_text(encoding='utf-8')
            result = self.lint(code, language, str(file_path), auto_fix)

            # If auto-fix produced fixed code, write it back
            if auto_fix and result.fixed_code:
                path.write_text(result.fixed_code, encoding='utf-8')

            return result

        except Exception as e:
            return LinterResult(issues=[LintIssue(
                file_path=file_path,
                line=0,
                column=0,
                severity='error',
                code='read-error',
                message=f'Error reading file: {str(e)}'
            )])

    def display_issues(self, result: LinterResult, title: Optional[str] = None):
        """
        Display linting issues in a formatted table.

        Args:
            result: The LinterResult to display
            title: Optional title for the display
        """
        if not result.issues:
            self.console.print("[green]✓ No linting issues found[/green]")
            return

        # Create summary
        summary = f"[red]✗ {result.error_count} errors[/red]"
        if result.warning_count > 0:
            summary += f", [yellow]⚠ {result.warning_count} warnings[/yellow]"

        self.console.print(f"\n{summary}\n")

        # Create table
        table = Table(
            title=title or "Linting Issues",
            show_header=True,
            header_style="bold magenta",
            border_style="blue"
        )

        table.add_column("Severity", width=8)
        table.add_column("Line:Col", width=10)
        table.add_column("Code", width=15)
        table.add_column("Message", width=60)

        for issue in result.issues:
            # Color code by severity
            if issue.severity == 'error':
                severity_style = "red"
                icon = "✗"
            elif issue.severity == 'warning':
                severity_style = "yellow"
                icon = "⚠"
            else:
                severity_style = "blue"
                icon = "ℹ"

            table.add_row(
                f"[{severity_style}]{icon} {issue.severity}[/{severity_style}]",
                f"{issue.line}:{issue.column}",
                f"[cyan]{issue.code}[/cyan]",
                issue.message[:60],
                style=severity_style if issue.severity == 'error' else None
            )

        self.console.print(table)

        # Show fixable issues count
        fixable_count = sum(1 for issue in result.issues if issue.fixable)
        if fixable_count > 0:
            self.console.print(f"\n[blue]ℹ {fixable_count} issues can be auto-fixed[/blue]")

    def _check_command(self, command: str) -> bool:
        """Check if a command is available."""
        try:
            subprocess.run(
                [command, '--version'],
                capture_output=True,
                timeout=5
            )
            return True
        except:
            return False

    def get_linter_info(self) -> Dict[str, bool]:
        """Get information about available linters."""
        return {
            'ruff': self._ruff_available,
            'eslint': self._eslint_available
        }
