"""Syntax validation for Python and JavaScript/TypeScript code."""

import ast
import sys
from typing import Dict, Optional, Tuple
from pathlib import Path


class ValidationResult:
    """Result of syntax validation."""

    def __init__(self, is_valid: bool, error_message: Optional[str] = None,
                 line: Optional[int] = None, column: Optional[int] = None):
        self.is_valid = is_valid
        self.error_message = error_message
        self.line = line
        self.column = column

    def __bool__(self):
        return self.is_valid

    def __repr__(self):
        if self.is_valid:
            return "ValidationResult(valid=True)"
        return f"ValidationResult(valid=False, line={self.line}, error={self.error_message})"


class SyntaxValidator:
    """Validate syntax for Python and JavaScript/TypeScript code."""

    SUPPORTED_LANGUAGES = {'python', 'javascript', 'typescript', 'jsx', 'tsx'}

    def __init__(self):
        """Initialize the syntax validator."""
        self._tree_sitter_available = False
        self._ts_parser = None
        self._js_language = None
        self._ts_language = None

        # Try to initialize tree-sitter for JS/TS
        try:
            from tree_sitter import Language, Parser
            # Check if language libraries are built
            # This would need tree-sitter language grammars pre-built
            self._tree_sitter_available = True
        except ImportError:
            pass

    def validate(self, code: str, language: str,
                 file_path: Optional[str] = None) -> ValidationResult:
        """
        Validate code syntax for the given language.

        Args:
            code: The source code to validate
            language: The programming language (python, javascript, typescript)
            file_path: Optional file path for better error messages

        Returns:
            ValidationResult indicating if code is valid

        Raises:
            ValueError: If language is not supported
        """
        language = language.lower()

        if language not in self.SUPPORTED_LANGUAGES:
            raise ValueError(
                f"Unsupported language: {language}. "
                f"Supported: {', '.join(self.SUPPORTED_LANGUAGES)}"
            )

        if language == 'python':
            return self._validate_python(code, file_path)
        elif language in ('javascript', 'jsx'):
            return self._validate_javascript(code, file_path)
        elif language in ('typescript', 'tsx'):
            return self._validate_typescript(code, file_path)

    def _validate_python(self, code: str,
                        file_path: Optional[str] = None) -> ValidationResult:
        """
        Validate Python code using AST parsing.

        This provides the most accurate validation for Python code.
        """
        if not code.strip():
            return ValidationResult(False, "Empty code", line=1, column=1)

        try:
            # First try: compile to check syntax
            compile(code, file_path or '<string>', 'exec')

            # Second try: parse AST for deeper validation
            ast.parse(code, filename=file_path or '<string>')

            return ValidationResult(True)

        except SyntaxError as e:
            return ValidationResult(
                is_valid=False,
                error_message=f"SyntaxError: {e.msg}",
                line=e.lineno,
                column=e.offset
            )
        except IndentationError as e:
            return ValidationResult(
                is_valid=False,
                error_message=f"IndentationError: {e.msg}",
                line=e.lineno,
                column=e.offset
            )
        except Exception as e:
            return ValidationResult(
                is_valid=False,
                error_message=f"Error: {str(e)}",
                line=None,
                column=None
            )

    def _validate_javascript(self, code: str,
                            file_path: Optional[str] = None) -> ValidationResult:
        """
        Validate JavaScript code.

        Uses tree-sitter if available, otherwise basic heuristics.
        """
        if not code.strip():
            return ValidationResult(False, "Empty code", line=1, column=1)

        # Try tree-sitter first (most accurate)
        if self._tree_sitter_available:
            return self._validate_with_tree_sitter(code, 'javascript', file_path)

        # Fallback: Try using Node.js if available
        result = self._validate_with_nodejs(code, file_path)
        if result:
            return result

        # Last resort: Basic syntax checks
        return self._basic_javascript_validation(code)

    def _validate_typescript(self, code: str,
                            file_path: Optional[str] = None) -> ValidationResult:
        """
        Validate TypeScript code.

        Uses tree-sitter if available, otherwise tries tsc.
        """
        if not code.strip():
            return ValidationResult(False, "Empty code", line=1, column=1)

        # Try tree-sitter first
        if self._tree_sitter_available:
            return self._validate_with_tree_sitter(code, 'typescript', file_path)

        # Fallback: Try TypeScript compiler if available
        result = self._validate_with_tsc(code, file_path)
        if result:
            return result

        # TypeScript is superset of JavaScript, try JS validation
        return self._validate_javascript(code, file_path)

    def _validate_with_tree_sitter(self, code: str, language: str,
                                   file_path: Optional[str] = None) -> ValidationResult:
        """Validate using tree-sitter parser."""
        try:
            from tree_sitter import Language, Parser

            # Initialize parser if needed
            if not self._ts_parser:
                self._ts_parser = Parser()

            # This requires pre-built language files
            # For now, return a basic validation result
            # TODO: Build tree-sitter language grammars
            return ValidationResult(
                is_valid=True,
                error_message="Tree-sitter validation not fully implemented yet"
            )

        except Exception as e:
            # If tree-sitter fails, don't block - return warning
            return ValidationResult(
                is_valid=True,
                error_message=f"Tree-sitter validation unavailable: {e}"
            )

    def _validate_with_nodejs(self, code: str,
                             file_path: Optional[str] = None) -> Optional[ValidationResult]:
        """Validate JavaScript using Node.js if available."""
        import subprocess
        import tempfile
        import os

        try:
            # Create temp file with code
            with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
                f.write(code)
                temp_path = f.name

            try:
                # Try to parse with Node.js (--check flag)
                result = subprocess.run(
                    ['node', '--check', temp_path],
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                if result.returncode == 0:
                    return ValidationResult(True)
                else:
                    # Parse error message
                    error_msg = result.stderr.strip()
                    return self._parse_nodejs_error(error_msg)

            finally:
                # Clean up temp file
                os.unlink(temp_path)

        except FileNotFoundError:
            # Node.js not available
            return None
        except Exception:
            return None

    def _validate_with_tsc(self, code: str,
                          file_path: Optional[str] = None) -> Optional[ValidationResult]:
        """Validate TypeScript using tsc if available."""
        import subprocess
        import tempfile
        import os

        try:
            # Create temp file with code
            with tempfile.NamedTemporaryFile(mode='w', suffix='.ts', delete=False) as f:
                f.write(code)
                temp_path = f.name

            try:
                # Try to compile with TypeScript compiler
                result = subprocess.run(
                    ['npx', 'tsc', '--noEmit', temp_path],
                    capture_output=True,
                    text=True,
                    timeout=10
                )

                if result.returncode == 0:
                    return ValidationResult(True)
                else:
                    # Parse error message
                    error_msg = result.stdout.strip()
                    return self._parse_tsc_error(error_msg)

            finally:
                # Clean up temp file
                os.unlink(temp_path)

        except FileNotFoundError:
            # tsc not available
            return None
        except Exception:
            return None

    def _basic_javascript_validation(self, code: str) -> ValidationResult:
        """
        Basic JavaScript syntax validation using heuristics.

        This is a fallback when no proper parser is available.
        """
        lines = code.split('\n')

        # Basic bracket matching
        stack = []
        bracket_pairs = {'(': ')', '[': ']', '{': '}'}

        for line_num, line in enumerate(lines, 1):
            # Skip comments
            if line.strip().startswith('//'):
                continue

            for col_num, char in enumerate(line, 1):
                if char in bracket_pairs:
                    stack.append((char, line_num, col_num))
                elif char in bracket_pairs.values():
                    if not stack:
                        return ValidationResult(
                            is_valid=False,
                            error_message=f"Unexpected closing bracket '{char}'",
                            line=line_num,
                            column=col_num
                        )
                    opening, _, _ = stack.pop()
                    if bracket_pairs[opening] != char:
                        return ValidationResult(
                            is_valid=False,
                            error_message=f"Mismatched brackets: '{opening}' and '{char}'",
                            line=line_num,
                            column=col_num
                        )

        if stack:
            char, line_num, col_num = stack[-1]
            return ValidationResult(
                is_valid=False,
                error_message=f"Unclosed bracket '{char}'",
                line=line_num,
                column=col_num
            )

        # If basic checks pass, assume valid
        # (This is not comprehensive but better than nothing)
        return ValidationResult(True)

    def _parse_nodejs_error(self, error_msg: str) -> ValidationResult:
        """Parse Node.js error message."""
        # Node.js errors typically format as: file:line
        # Example: "SyntaxError: Unexpected token '}'"
        try:
            if 'SyntaxError' in error_msg:
                return ValidationResult(
                    is_valid=False,
                    error_message=error_msg.split('\n')[0],
                    line=None,
                    column=None
                )
        except:
            pass

        return ValidationResult(
            is_valid=False,
            error_message=error_msg[:200],  # Limit message length
            line=None,
            column=None
        )

    def _parse_tsc_error(self, error_msg: str) -> ValidationResult:
        """Parse TypeScript compiler error message."""
        # tsc errors format: file(line,col): error TS####: message
        try:
            if error_msg:
                return ValidationResult(
                    is_valid=False,
                    error_message=error_msg.split('\n')[0],
                    line=None,
                    column=None
                )
        except:
            pass

        return ValidationResult(
            is_valid=False,
            error_message=error_msg[:200],
            line=None,
            column=None
        )

    def validate_file(self, file_path: str) -> ValidationResult:
        """
        Validate a file based on its extension.

        Args:
            file_path: Path to the file to validate

        Returns:
            ValidationResult
        """
        path = Path(file_path)

        if not path.exists():
            return ValidationResult(
                is_valid=False,
                error_message=f"File not found: {file_path}"
            )

        # Determine language from extension
        extension = path.suffix.lower()
        language_map = {
            '.py': 'python',
            '.js': 'javascript',
            '.jsx': 'jsx',
            '.ts': 'typescript',
            '.tsx': 'tsx',
            '.mjs': 'javascript',
            '.cjs': 'javascript',
        }

        language = language_map.get(extension)
        if not language:
            return ValidationResult(
                is_valid=False,
                error_message=f"Unsupported file extension: {extension}"
            )

        # Read and validate
        try:
            code = path.read_text(encoding='utf-8')
            return self.validate(code, language, str(file_path))
        except Exception as e:
            return ValidationResult(
                is_valid=False,
                error_message=f"Error reading file: {e}"
            )
