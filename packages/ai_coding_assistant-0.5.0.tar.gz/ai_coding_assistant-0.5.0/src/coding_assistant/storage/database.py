"""Database layer for session persistence."""

import sqlite3
import json
from pathlib import Path
from typing import List, Dict, Optional, Any
from datetime import datetime
from contextlib import contextmanager


class Database:
    """SQLite database for storing sessions, messages, and code changes."""

    def __init__(self, db_path: str):
        """Initialize database.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    @contextmanager
    def get_connection(self):
        """Get database connection context manager."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row  # Return rows as dicts
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self):
        """Initialize database schema."""
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Sessions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_path TEXT NOT NULL,
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    ended_at TIMESTAMP,
                    title TEXT,
                    metadata TEXT
                )
            """)

            # Messages table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
                    content TEXT NOT NULL,
                    tokens INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    metadata TEXT,
                    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
                )
            """)

            # Code changes table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS code_changes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER NOT NULL,
                    message_id INTEGER,
                    file_path TEXT NOT NULL,
                    change_type TEXT CHECK(change_type IN ('create', 'modify', 'delete')),
                    original_content TEXT,
                    new_content TEXT,
                    diff TEXT,
                    applied BOOLEAN DEFAULT 0,
                    applied_at TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
                    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE SET NULL
                )
            """)

            # Context snapshots table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS context_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER NOT NULL,
                    message_id INTEGER NOT NULL,
                    retrieved_chunks TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
                    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
                )
            """)

            # Create indexes
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_messages_session
                ON messages(session_id)
            """)

            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_code_changes_session
                ON code_changes(session_id)
            """)

            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_sessions_project
                ON sessions(project_path)
            """)

    # Session operations

    def insert_session(self, project_path: str, title: Optional[str] = None,
                      metadata: Optional[Dict] = None) -> int:
        """Create a new session.

        Args:
            project_path: Path to project
            title: Optional session title
            metadata: Optional metadata dict

        Returns:
            Session ID
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO sessions (project_path, title, metadata)
                VALUES (?, ?, ?)
            """, (project_path, title, json.dumps(metadata) if metadata else None))
            return cursor.lastrowid

    def update_session(self, session_id: int, ended_at: Optional[datetime] = None,
                      title: Optional[str] = None, metadata: Optional[Dict] = None):
        """Update session.

        Args:
            session_id: Session ID
            ended_at: End timestamp
            title: New title
            metadata: New metadata
        """
        updates = []
        params = []

        if ended_at:
            updates.append("ended_at = ?")
            params.append(ended_at.isoformat())

        if title is not None:
            updates.append("title = ?")
            params.append(title)

        if metadata is not None:
            updates.append("metadata = ?")
            params.append(json.dumps(metadata))

        if not updates:
            return

        params.append(session_id)
        query = f"UPDATE sessions SET {', '.join(updates)} WHERE id = ?"

        with self.get_connection() as conn:
            conn.execute(query, params)

    def get_session(self, session_id: int) -> Optional[Dict]:
        """Get session by ID.

        Args:
            session_id: Session ID

        Returns:
            Session dict or None
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM sessions WHERE id = ?", (session_id,))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None

    def get_recent_sessions(self, limit: int = 10, project_path: Optional[str] = None) -> List[Dict]:
        """Get recent sessions.

        Args:
            limit: Maximum number of sessions
            project_path: Filter by project path

        Returns:
            List of session dicts
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()

            if project_path:
                cursor.execute("""
                    SELECT * FROM sessions
                    WHERE project_path = ?
                    ORDER BY started_at DESC
                    LIMIT ?
                """, (project_path, limit))
            else:
                cursor.execute("""
                    SELECT * FROM sessions
                    ORDER BY started_at DESC
                    LIMIT ?
                """, (limit,))

            return [dict(row) for row in cursor.fetchall()]

    # Message operations

    def insert_message(self, session_id: int, role: str, content: str,
                      tokens: Optional[int] = None, metadata: Optional[Dict] = None) -> int:
        """Add message to session.

        Args:
            session_id: Session ID
            role: Message role (user/assistant/system)
            content: Message content
            tokens: Token count
            metadata: Optional metadata

        Returns:
            Message ID
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO messages (session_id, role, content, tokens, metadata)
                VALUES (?, ?, ?, ?, ?)
            """, (session_id, role, content, tokens, json.dumps(metadata) if metadata else None))
            return cursor.lastrowid

    def get_messages_by_session(self, session_id: int) -> List[Dict]:
        """Get all messages in a session.

        Args:
            session_id: Session ID

        Returns:
            List of message dicts
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM messages
                WHERE session_id = ?
                ORDER BY created_at ASC
            """, (session_id,))
            return [dict(row) for row in cursor.fetchall()]

    # Code change operations

    def insert_code_change(self, session_id: int, file_path: str,
                          change_type: str, original_content: Optional[str] = None,
                          new_content: Optional[str] = None, diff: Optional[str] = None,
                          message_id: Optional[int] = None) -> int:
        """Record a code change.

        Args:
            session_id: Session ID
            file_path: Path to changed file
            change_type: Type of change (create/modify/delete)
            original_content: Original file content
            new_content: New file content
            diff: Diff text
            message_id: Associated message ID

        Returns:
            Code change ID
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO code_changes
                (session_id, message_id, file_path, change_type,
                 original_content, new_content, diff)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (session_id, message_id, file_path, change_type,
                  original_content, new_content, diff))
            return cursor.lastrowid

    def mark_change_applied(self, change_id: int):
        """Mark a code change as applied.

        Args:
            change_id: Code change ID
        """
        with self.get_connection() as conn:
            conn.execute("""
                UPDATE code_changes
                SET applied = 1, applied_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (change_id,))

    def get_code_changes(self, session_id: int) -> List[Dict]:
        """Get all code changes for a session.

        Args:
            session_id: Session ID

        Returns:
            List of code change dicts
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM code_changes
                WHERE session_id = ?
                ORDER BY created_at ASC
            """, (session_id,))
            return [dict(row) for row in cursor.fetchall()]

    # Context snapshot operations

    def insert_context_snapshot(self, session_id: int, message_id: int,
                               retrieved_chunks: List[Dict]) -> int:
        """Save a context snapshot.

        Args:
            session_id: Session ID
            message_id: Message ID
            retrieved_chunks: List of retrieved chunks

        Returns:
            Snapshot ID
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO context_snapshots (session_id, message_id, retrieved_chunks)
                VALUES (?, ?, ?)
            """, (session_id, message_id, json.dumps(retrieved_chunks)))
            return cursor.lastrowid

    def get_context_snapshot(self, message_id: int) -> Optional[List[Dict]]:
        """Get context snapshot for a message.

        Args:
            message_id: Message ID

        Returns:
            List of chunks or None
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT retrieved_chunks FROM context_snapshots
                WHERE message_id = ?
            """, (message_id,))
            row = cursor.fetchone()
            if row:
                return json.loads(row['retrieved_chunks'])
            return None
