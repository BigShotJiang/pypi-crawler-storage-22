"""Session management for persistent conversations."""

from typing import List, Dict, Optional
from datetime import datetime
from pathlib import Path

from coding_assistant.storage.database import Database
from coding_assistant.operations.differ import DiffGenerator


class SessionManager:
    """Manages conversation sessions with persistence."""

    def __init__(self, db_path: str):
        """Initialize session manager.

        Args:
            db_path: Path to SQLite database
        """
        self.db = Database(db_path)
        self.diff_generator = DiffGenerator()

    def create_session(self, project_path: str, title: Optional[str] = None) -> int:
        """Create a new session.

        Args:
            project_path: Path to project
            title: Optional session title

        Returns:
            Session ID
        """
        return self.db.insert_session(project_path, title)

    def end_session(self, session_id: int):
        """Mark session as ended.

        Args:
            session_id: Session ID
        """
        self.db.update_session(session_id, ended_at=datetime.now())

    def update_session_title(self, session_id: int, title: str):
        """Update session title.

        Args:
            session_id: Session ID
            title: New title
        """
        self.db.update_session(session_id, title=title)

    def add_message(self, session_id: int, role: str, content: str,
                   tokens: Optional[int] = None) -> int:
        """Add message to session.

        Args:
            session_id: Session ID
            role: Message role (user/assistant/system)
            content: Message content
            tokens: Optional token count

        Returns:
            Message ID
        """
        return self.db.insert_message(session_id, role, content, tokens)

    def get_session_history(self, session_id: int) -> List[Dict]:
        """Get all messages in a session.

        Args:
            session_id: Session ID

        Returns:
            List of messages
        """
        messages = self.db.get_messages_by_session(session_id)
        # Convert to format expected by LLM
        return [
            {
                'role': msg['role'],
                'content': msg['content']
            }
            for msg in messages
        ]

    def record_code_change(self, session_id: int, file_path: str,
                          original_content: str, new_content: str,
                          message_id: Optional[int] = None) -> int:
        """Record a code change.

        Args:
            session_id: Session ID
            file_path: Path to file
            original_content: Original content
            new_content: New content
            message_id: Associated message ID

        Returns:
            Code change ID
        """
        # Generate diff
        diff = self.diff_generator.generate_diff(
            original_content,
            new_content,
            file_path
        )

        # Determine change type
        if not original_content:
            change_type = 'create'
        elif not new_content:
            change_type = 'delete'
        else:
            change_type = 'modify'

        return self.db.insert_code_change(
            session_id=session_id,
            file_path=file_path,
            change_type=change_type,
            original_content=original_content,
            new_content=new_content,
            diff=diff,
            message_id=message_id
        )

    def mark_change_applied(self, change_id: int):
        """Mark a code change as applied.

        Args:
            change_id: Code change ID
        """
        self.db.mark_change_applied(change_id)

    def get_code_changes(self, session_id: int) -> List[Dict]:
        """Get all code changes for a session.

        Args:
            session_id: Session ID

        Returns:
            List of code changes
        """
        return self.db.get_code_changes(session_id)

    def save_context_snapshot(self, session_id: int, message_id: int,
                             retrieved_chunks: List[Dict]) -> int:
        """Save context snapshot for a message.

        Args:
            session_id: Session ID
            message_id: Message ID
            retrieved_chunks: Retrieved context chunks

        Returns:
            Snapshot ID
        """
        return self.db.insert_context_snapshot(
            session_id,
            message_id,
            retrieved_chunks
        )

    def get_context_snapshot(self, message_id: int) -> Optional[List[Dict]]:
        """Get context snapshot for a message.

        Args:
            message_id: Message ID

        Returns:
            List of chunks or None
        """
        return self.db.get_context_snapshot(message_id)

    def list_sessions(self, limit: int = 10, project_path: Optional[str] = None) -> List[Dict]:
        """List recent sessions.

        Args:
            limit: Maximum number of sessions
            project_path: Filter by project path

        Returns:
            List of sessions
        """
        return self.db.get_recent_sessions(limit, project_path)

    def get_session(self, session_id: int) -> Optional[Dict]:
        """Get session info.

        Args:
            session_id: Session ID

        Returns:
            Session dict or None
        """
        return self.db.get_session(session_id)

    def get_session_summary(self, session_id: int) -> Dict:
        """Get summary of a session.

        Args:
            session_id: Session ID

        Returns:
            Summary dict with message count, code changes, etc.
        """
        session = self.get_session(session_id)
        if not session:
            return {}

        messages = self.db.get_messages_by_session(session_id)
        code_changes = self.get_code_changes(session_id)

        # Count by role
        user_messages = sum(1 for m in messages if m['role'] == 'user')
        assistant_messages = sum(1 for m in messages if m['role'] == 'assistant')

        # Count applied changes
        applied_changes = sum(1 for c in code_changes if c['applied'])

        return {
            'session_id': session_id,
            'project_path': session['project_path'],
            'started_at': session['started_at'],
            'ended_at': session['ended_at'],
            'title': session['title'],
            'total_messages': len(messages),
            'user_messages': user_messages,
            'assistant_messages': assistant_messages,
            'code_changes': len(code_changes),
            'applied_changes': applied_changes,
        }
