"""Utility functions and helpers."""

from coding_assistant.utils.cache import (
    Cache,
    EmbeddingCache,
    ResponseCache,
    CacheEntry,
    compute_context_hash
)
from coding_assistant.utils.progress import (
    ProgressManager,
    ProgressCallback,
    status,
    progress_bar,
    show_operation,
    get_progress_manager
)

__all__ = [
    'Cache',
    'EmbeddingCache',
    'ResponseCache',
    'CacheEntry',
    'compute_context_hash',
    'ProgressManager',
    'ProgressCallback',
    'status',
    'progress_bar',
    'show_operation',
    'get_progress_manager',
]
