"""Caching system for embeddings, responses, and search results."""

import hashlib
import pickle
import json
from pathlib import Path
from typing import Any, Optional, Dict, List
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import threading


@dataclass
class CacheEntry:
    """Cache entry with metadata."""
    key: str
    value: Any
    created_at: datetime
    expires_at: Optional[datetime]
    hits: int = 0
    size_bytes: int = 0

    def is_expired(self) -> bool:
        """Check if entry is expired."""
        if self.expires_at is None:
            return False
        return datetime.now() > self.expires_at

    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return {
            'key': self.key,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'hits': self.hits,
            'size_bytes': self.size_bytes,
        }


class Cache:
    """
    LRU cache with TTL support and persistence.

    Features:
    - In-memory caching with disk persistence
    - TTL (Time To Live) support
    - LRU eviction policy
    - Thread-safe operations
    - Cache statistics
    - File hash-based invalidation
    """

    def __init__(
        self,
        cache_dir: Path,
        max_size_mb: int = 500,
        default_ttl: int = 3600  # 1 hour
    ):
        """
        Initialize cache.

        Args:
            cache_dir: Directory to store cache files
            max_size_mb: Maximum cache size in MB
            default_ttl: Default TTL in seconds
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.default_ttl = default_ttl

        # In-memory cache for fast access
        self._memory_cache: Dict[str, CacheEntry] = {}
        self._lock = threading.Lock()

        # Statistics
        self.stats = {
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'size_bytes': 0
        }

    def get(self, key: str) -> Optional[Any]:
        """
        Get cached value.

        Args:
            key: Cache key

        Returns:
            Cached value or None if not found/expired
        """
        with self._lock:
            # Check memory cache first
            if key in self._memory_cache:
                entry = self._memory_cache[key]

                if entry.is_expired():
                    # Remove expired entry
                    self._remove_entry(key)
                    self.stats['misses'] += 1
                    return None

                # Update stats
                entry.hits += 1
                self.stats['hits'] += 1
                return entry.value

            # Check disk cache
            cache_file = self._get_cache_file(key)
            if cache_file.exists():
                try:
                    entry = self._load_from_disk(key)
                    if entry and not entry.is_expired():
                        # Load into memory
                        self._memory_cache[key] = entry
                        self.stats['hits'] += 1
                        return entry.value
                    else:
                        # Remove expired file
                        cache_file.unlink()
                except Exception:
                    pass

            self.stats['misses'] += 1
            return None

    def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ) -> bool:
        """
        Set cached value with TTL.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds (None = use default)

        Returns:
            True if cached successfully
        """
        with self._lock:
            ttl = ttl if ttl is not None else self.default_ttl

            # Create cache entry
            expires_at = datetime.now() + timedelta(seconds=ttl) if ttl > 0 else None

            # Serialize value to get size
            try:
                serialized = pickle.dumps(value)
                size_bytes = len(serialized)
            except Exception:
                return False

            entry = CacheEntry(
                key=key,
                value=value,
                created_at=datetime.now(),
                expires_at=expires_at,
                size_bytes=size_bytes
            )

            # Check if we need to evict
            while self._should_evict(size_bytes):
                self._evict_lru()

            # Store in memory
            self._memory_cache[key] = entry
            self.stats['size_bytes'] += size_bytes

            # Persist to disk
            try:
                self._save_to_disk(key, entry, serialized)
            except Exception:
                pass

            return True

    def delete(self, key: str) -> bool:
        """
        Delete cached value.

        Args:
            key: Cache key

        Returns:
            True if deleted
        """
        with self._lock:
            return self._remove_entry(key)

    def invalidate_pattern(self, pattern: str) -> int:
        """
        Invalidate cache entries matching pattern.

        Args:
            pattern: Glob pattern (e.g., "embeddings:*")

        Returns:
            Number of entries invalidated
        """
        count = 0

        with self._lock:
            # Invalidate memory cache
            keys_to_remove = [
                k for k in self._memory_cache.keys()
                if self._matches_pattern(k, pattern)
            ]

            for key in keys_to_remove:
                if self._remove_entry(key):
                    count += 1

            # Invalidate disk cache
            for cache_file in self.cache_dir.glob("*"):
                try:
                    meta_file = cache_file.with_suffix('.meta')
                    if meta_file.exists():
                        with open(meta_file, 'r') as f:
                            meta = json.load(f)
                            if self._matches_pattern(meta['key'], pattern):
                                cache_file.unlink()
                                meta_file.unlink()
                                count += 1
                except Exception:
                    pass

        return count

    def clear(self) -> None:
        """Clear all cache entries."""
        with self._lock:
            self._memory_cache.clear()
            self.stats['size_bytes'] = 0
            self.stats['evictions'] = 0

            # Clear disk cache
            for cache_file in self.cache_dir.glob("*"):
                try:
                    cache_file.unlink()
                except Exception:
                    pass

    def get_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Dictionary with cache stats
        """
        with self._lock:
            total = self.stats['hits'] + self.stats['misses']
            hit_rate = (self.stats['hits'] / total * 100) if total > 0 else 0

            return {
                'hits': self.stats['hits'],
                'misses': self.stats['misses'],
                'hit_rate': f"{hit_rate:.1f}%",
                'entries': len(self._memory_cache),
                'size_mb': self.stats['size_bytes'] / (1024 * 1024),
                'max_size_mb': self.max_size_bytes / (1024 * 1024),
                'evictions': self.stats['evictions'],
            }

    def _should_evict(self, new_size: int) -> bool:
        """Check if we need to evict entries."""
        return self.stats['size_bytes'] + new_size > self.max_size_bytes

    def _evict_lru(self) -> None:
        """Evict least recently used entry."""
        if not self._memory_cache:
            return

        # Find LRU entry (lowest hits, oldest)
        lru_key = min(
            self._memory_cache.keys(),
            key=lambda k: (
                self._memory_cache[k].hits,
                self._memory_cache[k].created_at
            )
        )

        self._remove_entry(lru_key)
        self.stats['evictions'] += 1

    def _remove_entry(self, key: str) -> bool:
        """Remove entry from cache."""
        if key in self._memory_cache:
            entry = self._memory_cache.pop(key)
            self.stats['size_bytes'] -= entry.size_bytes

            # Remove from disk
            cache_file = self._get_cache_file(key)
            meta_file = cache_file.with_suffix('.meta')

            try:
                if cache_file.exists():
                    cache_file.unlink()
                if meta_file.exists():
                    meta_file.unlink()
            except Exception:
                pass

            return True

        return False

    def _get_cache_file(self, key: str) -> Path:
        """Get cache file path for key."""
        key_hash = hashlib.sha256(key.encode()).hexdigest()
        return self.cache_dir / f"{key_hash}.cache"

    def _save_to_disk(self, key: str, entry: CacheEntry, serialized: bytes) -> None:
        """Save cache entry to disk."""
        cache_file = self._get_cache_file(key)
        meta_file = cache_file.with_suffix('.meta')

        # Save data
        with open(cache_file, 'wb') as f:
            f.write(serialized)

        # Save metadata
        with open(meta_file, 'w') as f:
            json.dump(entry.to_dict(), f)

    def _load_from_disk(self, key: str) -> Optional[CacheEntry]:
        """Load cache entry from disk."""
        cache_file = self._get_cache_file(key)
        meta_file = cache_file.with_suffix('.meta')

        if not cache_file.exists() or not meta_file.exists():
            return None

        try:
            # Load metadata
            with open(meta_file, 'r') as f:
                meta = json.load(f)

            # Load data
            with open(cache_file, 'rb') as f:
                value = pickle.load(f)

            # Reconstruct entry
            entry = CacheEntry(
                key=key,
                value=value,
                created_at=datetime.fromisoformat(meta['created_at']),
                expires_at=datetime.fromisoformat(meta['expires_at']) if meta['expires_at'] else None,
                hits=meta['hits'],
                size_bytes=meta['size_bytes']
            )

            return entry

        except Exception:
            return None

    def _matches_pattern(self, key: str, pattern: str) -> bool:
        """Check if key matches glob pattern."""
        import fnmatch
        return fnmatch.fnmatch(key, pattern)


class EmbeddingCache(Cache):
    """Specialized cache for code embeddings."""

    def __init__(self, cache_dir: Path):
        super().__init__(
            cache_dir=cache_dir / "embeddings",
            max_size_mb=1000,  # 1GB for embeddings
            default_ttl=0  # No expiration for embeddings
        )

    def get_embedding(self, file_path: str, file_hash: str) -> Optional[List[float]]:
        """
        Get cached embedding for file.

        Args:
            file_path: Path to file
            file_hash: Hash of file content

        Returns:
            Embedding vector or None
        """
        key = f"{file_path}:{file_hash}"
        return self.get(key)

    def set_embedding(self, file_path: str, file_hash: str, embedding: List[float]) -> bool:
        """
        Cache embedding for file.

        Args:
            file_path: Path to file
            file_hash: Hash of file content
            embedding: Embedding vector

        Returns:
            True if cached successfully
        """
        key = f"{file_path}:{file_hash}"
        return self.set(key, embedding, ttl=0)  # No expiration

    def invalidate_file(self, file_path: str) -> int:
        """Invalidate cache for specific file."""
        return self.invalidate_pattern(f"{file_path}:*")


class ResponseCache(Cache):
    """Specialized cache for LLM responses."""

    def __init__(self, cache_dir: Path):
        super().__init__(
            cache_dir=cache_dir / "responses",
            max_size_mb=200,  # 200MB for responses
            default_ttl=1800  # 30 minutes
        )

    def get_response(self, query: str, context_hash: str) -> Optional[str]:
        """
        Get cached response.

        Args:
            query: User query
            context_hash: Hash of context chunks

        Returns:
            Cached response or None
        """
        key = self._make_key(query, context_hash)
        return self.get(key)

    def set_response(self, query: str, context_hash: str, response: str, ttl: int = 1800) -> bool:
        """
        Cache response.

        Args:
            query: User query
            context_hash: Hash of context chunks
            response: LLM response
            ttl: Time to live in seconds

        Returns:
            True if cached successfully
        """
        key = self._make_key(query, context_hash)
        return self.set(key, response, ttl=ttl)

    def _make_key(self, query: str, context_hash: str) -> str:
        """Create cache key from query and context."""
        query_hash = hashlib.md5(query.encode()).hexdigest()[:16]
        return f"response:{query_hash}:{context_hash}"


def compute_context_hash(chunks: List[Dict]) -> str:
    """
    Compute hash of context chunks for cache keying.

    Args:
        chunks: List of context chunks

    Returns:
        Hash string
    """
    # Create deterministic string from chunks
    chunk_strings = []
    for chunk in chunks:
        chunk_str = f"{chunk.get('file', '')}:{chunk.get('start_line', 0)}"
        chunk_strings.append(chunk_str)

    combined = "|".join(sorted(chunk_strings))
    return hashlib.md5(combined.encode()).hexdigest()[:16]
