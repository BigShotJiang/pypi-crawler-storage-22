"""Hardware detection for LLM provider recommendations."""

from dataclasses import dataclass
from typing import Optional
import psutil


@dataclass
class HardwareInfo:
    """Hardware information and recommendations."""

    total_ram_gb: float
    available_ram_gb: float
    recommended_provider: str
    recommended_model: str
    can_run_local: bool

    def to_dict(self):
        """Convert to dictionary."""
        return {
            'total_ram_gb': self.total_ram_gb,
            'available_ram_gb': self.available_ram_gb,
            'recommended_provider': self.recommended_provider,
            'recommended_model': self.recommended_model,
            'can_run_local': self.can_run_local
        }


class HardwareDetector:
    """
    Hardware detection for optimal LLM provider selection.

    Detects available RAM and recommends the best provider based on hardware capabilities.
    """

    # RAM thresholds in GB
    MIN_RAM_FOR_7B = 8.0
    MIN_RAM_FOR_32B = 32.0

    @staticmethod
    def get_hardware_info() -> HardwareInfo:
        """
        Get hardware information and provider recommendations.

        Returns:
            HardwareInfo with system specs and recommendations
        """
        # Get memory info
        mem = psutil.virtual_memory()
        total_ram_gb = mem.total / (1024 ** 3)
        available_ram_gb = mem.available / (1024 ** 3)

        # Determine recommendations based on available RAM
        if total_ram_gb >= HardwareDetector.MIN_RAM_FOR_32B:
            recommended_provider = "ollama"
            recommended_model = "qwen2.5-coder:32b"
            can_run_local = True
        elif total_ram_gb >= HardwareDetector.MIN_RAM_FOR_7B:
            recommended_provider = "ollama"
            recommended_model = "qwen2.5-coder:7b"
            can_run_local = True
        else:
            recommended_provider = "groq"
            recommended_model = "llama-3.3-70b-versatile"
            can_run_local = False

        return HardwareInfo(
            total_ram_gb=total_ram_gb,
            available_ram_gb=available_ram_gb,
            recommended_provider=recommended_provider,
            recommended_model=recommended_model,
            can_run_local=can_run_local
        )

    @staticmethod
    def format_recommendation(info: HardwareInfo) -> str:
        """
        Format hardware info as user-friendly message.

        Args:
            info: Hardware information

        Returns:
            Formatted recommendation message
        """
        message = f"💻 System RAM: {info.total_ram_gb:.1f}GB total, {info.available_ram_gb:.1f}GB available\n\n"

        if info.can_run_local:
            message += f"✓ Your system can run local models!\n"
            message += f"  Recommended: {info.recommended_provider} with {info.recommended_model}\n\n"
            message += "To get started:\n"
            message += f"  1. Install Ollama: curl -fsSL https://ollama.com/install.sh | sh\n"
            message += f"  2. Pull model: ollama pull {info.recommended_model}\n"
            message += f"  3. Start using: assistant ask \"your question\"\n\n"
            message += "Alternative: Use cloud providers (Groq free tier, Together AI free trial)\n"
            message += "  Run: assistant config set-api-key groq <your-key>"
        else:
            message += f"⚠️  Limited RAM detected ({info.total_ram_gb:.1f}GB)\n"
            message += f"  Local models need {HardwareDetector.MIN_RAM_FOR_7B}GB+ RAM\n\n"
            message += f"✓ Recommended: Use cloud provider ({info.recommended_provider})\n"
            message += f"  Model: {info.recommended_model}\n\n"
            message += "To get started with Groq (FREE tier):\n"
            message += "  1. Get API key: https://console.groq.com\n"
            message += "  2. Set key: assistant config set-api-key groq <your-key>\n"
            message += "  3. Start using: assistant ask \"your question\"\n\n"
            message += "Alternative: Together AI ($25 free trial)\n"
            message += "  1. Get API key: https://api.together.xyz\n"
            message += "  2. Set key: assistant config set-api-key together <your-key>"

        return message

    @staticmethod
    def get_recommended_provider() -> str:
        """
        Get recommended provider name based on hardware.

        Returns:
            Provider name (ollama, groq, or together)
        """
        info = HardwareDetector.get_hardware_info()
        return info.recommended_provider

    @staticmethod
    def can_run_local_models() -> bool:
        """
        Check if system can run local LLM models.

        Returns:
            True if system has sufficient RAM for local models
        """
        info = HardwareDetector.get_hardware_info()
        return info.can_run_local
