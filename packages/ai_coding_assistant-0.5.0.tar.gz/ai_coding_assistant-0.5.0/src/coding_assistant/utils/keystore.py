"""Secure API key storage for cloud LLM providers."""

import json
import os
from pathlib import Path
from typing import Optional, List, Dict


class KeyStore:
    """
    Secure storage for API keys.

    Stores API keys in a JSON file with restricted permissions (600).
    Keys are stored at: ~/.coding_assistant/api_keys.json
    """

    # Valid provider names (allowlist for security)
    VALID_PROVIDERS = ["groq", "together", "gemini", "openai", "claude", "anthropic"]

    def __init__(self, storage_dir: Optional[Path] = None):
        """
        Initialize keystore.

        Args:
            storage_dir: Directory to store keys (default: ~/.coding_assistant)
        """
        if storage_dir is None:
            storage_dir = Path.home() / ".coding_assistant"

        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.keys_file = self.storage_dir / "api_keys.json"

        # Ensure file has secure permissions if it exists
        if self.keys_file.exists():
            self._ensure_secure_permissions()

    def set_key(self, provider: str, api_key: str) -> bool:
        """
        Store API key for a provider.

        Args:
            provider: Provider name (groq, together, openai, claude)
            api_key: API key to store

        Returns:
            True if key was stored successfully

        Raises:
            ValueError: If provider is not in allowlist
        """
        # Validate provider
        if provider.lower() not in self.VALID_PROVIDERS:
            raise ValueError(
                f"Invalid provider: {provider}. "
                f"Must be one of: {', '.join(self.VALID_PROVIDERS)}"
            )

        # Load existing keys
        keys = self._load_keys()

        # Update key
        keys[provider.lower()] = api_key

        # Save with secure permissions
        self._save_keys(keys)

        return True

    def get_key(self, provider: str) -> Optional[str]:
        """
        Get API key for a provider.

        Args:
            provider: Provider name

        Returns:
            API key if found, None otherwise
        """
        keys = self._load_keys()
        return keys.get(provider.lower())

    def remove_key(self, provider: str) -> bool:
        """
        Remove API key for a provider.

        Args:
            provider: Provider name

        Returns:
            True if key was removed, False if key didn't exist
        """
        keys = self._load_keys()

        if provider.lower() in keys:
            del keys[provider.lower()]
            self._save_keys(keys)
            return True

        return False

    def list_providers(self) -> List[str]:
        """
        List all providers with stored API keys.

        Returns:
            List of provider names
        """
        keys = self._load_keys()
        return list(keys.keys())

    def get_all_keys(self) -> Dict[str, str]:
        """
        Get all stored API keys.

        Returns:
            Dictionary of provider -> API key
        """
        return self._load_keys()

    def clear_all(self) -> bool:
        """
        Remove all stored API keys.

        Returns:
            True if keys were cleared
        """
        self._save_keys({})
        return True

    def _load_keys(self) -> Dict[str, str]:
        """
        Load API keys from storage.

        Returns:
            Dictionary of provider -> API key
        """
        if not self.keys_file.exists():
            return {}

        try:
            with open(self.keys_file, 'r') as f:
                keys = json.load(f)
                # Ensure it's a dict
                if not isinstance(keys, dict):
                    return {}
                return keys
        except (json.JSONDecodeError, IOError):
            # If file is corrupted, return empty dict
            return {}

    def _save_keys(self, keys: Dict[str, str]) -> None:
        """
        Save API keys to storage with secure permissions.

        Args:
            keys: Dictionary of provider -> API key
        """
        # Write to file
        with open(self.keys_file, 'w') as f:
            json.dump(keys, f, indent=2)

        # Set secure permissions (owner read/write only)
        self._ensure_secure_permissions()

    def _ensure_secure_permissions(self) -> None:
        """
        Ensure keys file has secure permissions (600).

        Only the owner should be able to read/write the file.
        """
        try:
            # chmod 600 (owner read/write only)
            os.chmod(self.keys_file, 0o600)
        except Exception:
            # If chmod fails (e.g., on Windows), continue anyway
            # Windows doesn't use UNIX permissions
            pass

    def mask_key(self, api_key: str) -> str:
        """
        Mask an API key for display (show only first 8 and last 4 characters).

        Args:
            api_key: API key to mask

        Returns:
            Masked API key (e.g., "gsk_1234...xyz9")
        """
        if not api_key or len(api_key) < 12:
            return "***"

        return f"{api_key[:8]}...{api_key[-4:]}"

    def get_masked_keys(self) -> Dict[str, str]:
        """
        Get all keys with masking for safe display.

        Returns:
            Dictionary of provider -> masked API key
        """
        keys = self._load_keys()
        return {
            provider: self.mask_key(key)
            for provider, key in keys.items()
        }
