"""Progress indicators and status utilities for consistent UX."""

from typing import Optional, Callable, Any
from contextlib import contextmanager
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
    TimeRemainingColumn
)


class ProgressManager:
    """
    Centralized progress management for consistent UX.

    Provides:
    - Simple status spinners
    - Detailed progress bars
    - Consistent styling
    """

    def __init__(self, console: Optional[Console] = None):
        """
        Initialize progress manager.

        Args:
            console: Rich console (creates new one if not provided)
        """
        self.console = console or Console()

    @contextmanager
    def status(self, message: str, spinner: str = "dots"):
        """
        Show a simple status spinner.

        Args:
            message: Status message to display
            spinner: Spinner style (dots, line, arc, etc.)

        Usage:
            with progress_manager.status("Processing..."):
                # Long operation
                pass
        """
        with self.console.status(f"[bold green]{message}[/bold green]", spinner=spinner):
            yield

    @contextmanager
    def progress_bar(
        self,
        description: str,
        total: Optional[int] = None,
        show_time: bool = False
    ):
        """
        Show a detailed progress bar.

        Args:
            description: Task description
            total: Total steps (None for indeterminate)
            show_time: Show time remaining

        Usage:
            with progress_manager.progress_bar("Indexing", total=100) as progress:
                for i in range(100):
                    progress.update(i + 1)

        Yields:
            Progress updater function
        """
        columns = [
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
        ]

        if total is not None:
            columns.append(BarColumn())
            columns.append(TaskProgressColumn())

            if show_time:
                columns.append(TimeRemainingColumn())

        with Progress(*columns, console=self.console, transient=False) as progress:
            task = progress.add_task(f"[cyan]{description}", total=total)

            class Updater:
                """Simple updater interface."""

                def update(self, completed: Optional[int] = None, advance: Optional[int] = None):
                    """Update progress."""
                    if completed is not None:
                        progress.update(task, completed=completed)
                    elif advance is not None:
                        progress.advance(task, advance)

                def set_description(self, description: str):
                    """Update description."""
                    progress.update(task, description=f"[cyan]{description}")

            yield Updater()

    def show_operation(
        self,
        operation_name: str,
        operation_fn: Callable,
        *args,
        **kwargs
    ) -> Any:
        """
        Execute an operation with automatic progress indication.

        Args:
            operation_name: Name of the operation
            operation_fn: Function to execute
            *args, **kwargs: Arguments for operation_fn

        Returns:
            Result of operation_fn

        Usage:
            result = progress_manager.show_operation(
                "Indexing codebase",
                retriever.index_codebase,
                max_files=100
            )
        """
        with self.status(operation_name):
            return operation_fn(*args, **kwargs)

    def show_steps(self, steps: list[tuple[str, Callable]]) -> list[Any]:
        """
        Execute multiple steps with progress tracking.

        Args:
            steps: List of (step_name, step_function) tuples

        Returns:
            List of results from each step

        Usage:
            results = progress_manager.show_steps([
                ("Parsing code", parser.parse),
                ("Generating embeddings", embedder.embed),
                ("Storing results", storage.save)
            ])
        """
        results = []

        with self.progress_bar("Executing steps", total=len(steps)) as progress:
            for i, (step_name, step_fn) in enumerate(steps, 1):
                progress.set_description(f"{step_name}...")

                try:
                    result = step_fn()
                    results.append(result)
                except Exception as e:
                    self.console.print(f"[red]✗ {step_name} failed: {e}[/red]")
                    raise

                progress.update(i)

        return results


# Global instance for convenience
_default_progress_manager: Optional[ProgressManager] = None


def get_progress_manager(console: Optional[Console] = None) -> ProgressManager:
    """
    Get global progress manager instance.

    Args:
        console: Optional console to use

    Returns:
        ProgressManager instance
    """
    global _default_progress_manager

    if _default_progress_manager is None or console is not None:
        _default_progress_manager = ProgressManager(console)

    return _default_progress_manager


# Convenience functions
def status(message: str, console: Optional[Console] = None):
    """Context manager for simple status spinner."""
    return get_progress_manager(console).status(message)


def progress_bar(
    description: str,
    total: Optional[int] = None,
    show_time: bool = False,
    console: Optional[Console] = None
):
    """Context manager for progress bar."""
    return get_progress_manager(console).progress_bar(description, total, show_time)


def show_operation(
    operation_name: str,
    operation_fn: Callable,
    *args,
    console: Optional[Console] = None,
    **kwargs
) -> Any:
    """Execute operation with progress."""
    return get_progress_manager(console).show_operation(
        operation_name, operation_fn, *args, **kwargs
    )


# Progress callback helpers
class ProgressCallback:
    """
    Progress callback for long-running operations.

    Usage:
        callback = ProgressCallback(total=100)
        for i in range(100):
            # ... work ...
            callback.update(i + 1)
    """

    def __init__(
        self,
        total: int,
        description: str = "Processing",
        console: Optional[Console] = None
    ):
        """
        Initialize progress callback.

        Args:
            total: Total number of items
            description: Progress description
            console: Rich console
        """
        self.total = total
        self.description = description
        self.console = console or Console()
        self.current = 0

        self.progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=self.console
        )

        self.task = None
        self._started = False

    def __enter__(self):
        """Start progress display."""
        self.progress.__enter__()
        self.task = self.progress.add_task(
            f"[cyan]{self.description}",
            total=self.total
        )
        self._started = True
        return self

    def __exit__(self, *args):
        """Stop progress display."""
        self.progress.__exit__(*args)
        self._started = False

    def update(self, current: int, description: Optional[str] = None):
        """
        Update progress.

        Args:
            current: Current progress value
            description: Optional new description
        """
        if not self._started:
            return

        self.current = current

        if description:
            self.progress.update(
                self.task,
                completed=current,
                description=f"[cyan]{description}"
            )
        else:
            self.progress.update(self.task, completed=current)

    def advance(self, amount: int = 1):
        """Advance progress by amount."""
        if self._started:
            self.current += amount
            self.progress.advance(self.task, amount)

    def set_description(self, description: str):
        """Update description."""
        if self._started:
            self.progress.update(
                self.task,
                description=f"[cyan]{description}"
            )
