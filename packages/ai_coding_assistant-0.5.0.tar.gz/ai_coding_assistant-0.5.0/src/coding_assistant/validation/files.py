"""File path validation."""

import os
from pathlib import Path
from typing import Optional, List

from coding_assistant.exceptions.validation import (
    ValidationError,
    FileNotFoundError,
    PathSecurityError
)


class FileValidator:
    """
    Validates file paths for safety and existence.

    Prevents path traversal and other security issues.
    """

    # Dangerous path patterns
    DANGEROUS_PATTERNS = [
        '..',  # Path traversal
        '~/',  # Home directory
        '/etc',  # System config
        '/sys',  # System files
        '/proc',  # Process info
        '/dev',  # Devices
    ]

    @staticmethod
    def validate_file_path(
        path: str,
        must_exist: bool = False,
        must_be_file: bool = False,
        must_be_dir: bool = False,
        allowed_extensions: Optional[List[str]] = None,
        base_dir: Optional[Path] = None
    ) -> Path:
        """
        Validate file path for safety and correctness.

        Args:
            path: File path to validate
            must_exist: Whether file must exist
            must_be_file: Whether path must be a file (not directory)
            must_be_dir: Whether path must be a directory
            allowed_extensions: List of allowed file extensions (e.g., ['.py', '.js'])
            base_dir: Base directory to restrict paths to

        Returns:
            Validated Path object

        Raises:
            ValidationError: If path is invalid
            FileNotFoundError: If file doesn't exist when required
            PathSecurityError: If path is potentially dangerous
        """
        if not path:
            raise ValidationError(
                "file path",
                "Path cannot be empty"
            )

        # Convert to Path
        try:
            file_path = Path(path)
        except Exception as e:
            raise ValidationError(
                "file path",
                f"Invalid path format: {e}",
                value=path
            )

        # Security checks
        FileValidator._check_path_security(file_path)

        # Resolve to absolute path
        try:
            file_path = file_path.resolve()
        except Exception as e:
            raise ValidationError(
                "file path",
                f"Cannot resolve path: {e}",
                value=path
            )

        # Check if within base directory
        if base_dir:
            base_dir = base_dir.resolve()
            try:
                file_path.relative_to(base_dir)
            except ValueError:
                raise PathSecurityError(
                    file_path,
                    f"Path is outside allowed directory: {base_dir}"
                )

        # Check existence
        if must_exist and not file_path.exists():
            raise FileNotFoundError(file_path)

        # Check file vs directory
        if file_path.exists():
            if must_be_file and not file_path.is_file():
                raise ValidationError(
                    "file path",
                    f"Path is not a file: {file_path}",
                    value=str(file_path)
                )

            if must_be_dir and not file_path.is_dir():
                raise ValidationError(
                    "file path",
                    f"Path is not a directory: {file_path}",
                    value=str(file_path)
                )

        # Check extension
        if allowed_extensions and file_path.suffix.lower() not in allowed_extensions:
            raise ValidationError(
                "file path",
                f"File type not allowed. Allowed: {', '.join(allowed_extensions)}",
                value=str(file_path),
                suggestion=f"Use a file with one of these extensions: {', '.join(allowed_extensions)}"
            )

        return file_path

    @staticmethod
    def _check_path_security(file_path: Path) -> None:
        """
        Check path for security issues.

        Args:
            file_path: Path to check

        Raises:
            PathSecurityError: If path is dangerous
        """
        path_str = str(file_path)

        # Check for dangerous patterns
        for pattern in FileValidator.DANGEROUS_PATTERNS:
            if pattern in path_str:
                # Allow .. only in resolved paths that don't escape
                if pattern == '..' and not path_str.startswith('..'):
                    continue

                raise PathSecurityError(
                    file_path,
                    f"Path contains dangerous pattern: {pattern}"
                )

        # Check for absolute paths to system directories
        if file_path.is_absolute():
            parts = file_path.parts
            if len(parts) > 1 and parts[1] in ['etc', 'sys', 'proc', 'dev', 'boot']:
                raise PathSecurityError(
                    file_path,
                    "Access to system directories not allowed"
                )

    @staticmethod
    def validate_project_path(path: str) -> Path:
        """
        Validate project root path.

        Args:
            path: Project path

        Returns:
            Validated Path object

        Raises:
            ValidationError: If path is invalid
        """
        project_path = FileValidator.validate_file_path(
            path,
            must_exist=True,
            must_be_dir=True
        )

        # Check if it looks like a code project
        # (has common files like .git, src/, package.json, etc.)
        indicators = [
            '.git',
            'src',
            'lib',
            'package.json',
            'requirements.txt',
            'pyproject.toml',
            'Cargo.toml',
            'go.mod',
            '.gitignore'
        ]

        has_indicator = any(
            (project_path / indicator).exists()
            for indicator in indicators
        )

        if not has_indicator:
            # Just a warning, not an error
            pass  # Could add warning log

        return project_path

    @staticmethod
    def validate_output_path(
        path: str,
        allow_overwrite: bool = False
    ) -> Path:
        """
        Validate output file path.

        Args:
            path: Output file path
            allow_overwrite: Whether to allow overwriting existing files

        Returns:
            Validated Path object

        Raises:
            ValidationError: If path is invalid or file exists
        """
        output_path = FileValidator.validate_file_path(path)

        # Check if file exists
        if output_path.exists() and not allow_overwrite:
            raise ValidationError(
                "output path",
                "File already exists",
                value=str(output_path),
                suggestion="Use a different path or enable overwrite"
            )

        # Check if parent directory exists and is writable
        parent = output_path.parent
        if not parent.exists():
            raise ValidationError(
                "output path",
                f"Parent directory does not exist: {parent}",
                value=str(output_path),
                suggestion=f"Create directory first: mkdir -p {parent}"
            )

        if not os.access(parent, os.W_OK):
            raise ValidationError(
                "output path",
                f"Parent directory is not writable: {parent}",
                value=str(output_path)
            )

        return output_path

    @staticmethod
    def is_code_file(file_path: Path) -> bool:
        """
        Check if file is a code file.

        Args:
            file_path: File path to check

        Returns:
            True if file appears to be code
        """
        code_extensions = {
            '.py', '.js', '.ts', '.jsx', '.tsx',
            '.java', '.c', '.cpp', '.h', '.hpp',
            '.cs', '.go', '.rs', '.rb', '.php',
            '.swift', '.kt', '.scala', '.R',
            '.sql', '.sh', '.bash', '.zsh',
            '.html', '.css', '.scss', '.less',
            '.json', '.yaml', '.yml', '.toml',
            '.xml', '.md', '.rst'
        }

        return file_path.suffix.lower() in code_extensions

    @staticmethod
    def get_relative_path(
        file_path: Path,
        base_path: Path
    ) -> Path:
        """
        Get relative path from base.

        Args:
            file_path: File path
            base_path: Base path

        Returns:
            Relative path

        Raises:
            ValidationError: If file_path is not under base_path
        """
        try:
            return file_path.relative_to(base_path)
        except ValueError:
            raise ValidationError(
                "file path",
                f"Path {file_path} is not under {base_path}"
            )
