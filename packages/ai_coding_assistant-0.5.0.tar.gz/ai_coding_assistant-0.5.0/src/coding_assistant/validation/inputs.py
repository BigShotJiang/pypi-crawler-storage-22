"""Input validation utilities."""

import re
from pathlib import Path
from typing import Optional, List

from coding_assistant.exceptions.validation import (
    ValidationError,
    InvalidQueryError,
    InvalidParameterError,
    EmptyInputError
)


class InputValidator:
    """
    Validates user inputs for safety and correctness.

    Provides methods for validating queries, parameters, and other inputs.
    """

    # Constants
    MIN_QUERY_LENGTH = 3
    MAX_QUERY_LENGTH = 500
    MAX_FILE_PATH_LENGTH = 4096

    @staticmethod
    def validate_query(
        query: str,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None
    ) -> str:
        """
        Validate search/ask query.

        Args:
            query: User query
            min_length: Minimum query length (default: 3)
            max_length: Maximum query length (default: 500)

        Returns:
            Cleaned query string

        Raises:
            InvalidQueryError: If query is invalid
            EmptyInputError: If query is empty
        """
        min_length = min_length or InputValidator.MIN_QUERY_LENGTH
        max_length = max_length or InputValidator.MAX_QUERY_LENGTH

        # Check for None or empty
        if query is None:
            raise EmptyInputError("query")

        # Strip whitespace
        query = query.strip()

        if not query:
            raise EmptyInputError("query")

        # Check length
        if len(query) < min_length:
            raise InvalidQueryError(
                query,
                f"Query too short (minimum {min_length} characters)"
            )

        if len(query) > max_length:
            raise InvalidQueryError(
                query,
                f"Query too long (maximum {max_length} characters)"
            )

        # Check for suspicious patterns (injection attempts)
        suspicious_patterns = [
            r'<script',  # XSS
            r'javascript:',  # XSS
            r'\$\{',  # Template injection
            r'`[^`]*`',  # Command substitution
        ]

        for pattern in suspicious_patterns:
            if re.search(pattern, query, re.IGNORECASE):
                raise InvalidQueryError(
                    query,
                    "Query contains suspicious patterns"
                )

        return query

    @staticmethod
    def validate_positive_int(
        value: any,
        name: str,
        min_value: int = 1,
        max_value: Optional[int] = None
    ) -> int:
        """
        Validate positive integer parameter.

        Args:
            value: Value to validate
            name: Parameter name
            min_value: Minimum value (default: 1)
            max_value: Maximum value (optional)

        Returns:
            Validated integer

        Raises:
            InvalidParameterError: If value is invalid
        """
        # Check type
        if not isinstance(value, int):
            raise InvalidParameterError(
                name,
                value,
                "positive integer"
            )

        # Check positive
        if value < min_value:
            raise InvalidParameterError(
                name,
                value,
                f"positive integer >= {min_value}"
            )

        # Check maximum
        if max_value is not None and value > max_value:
            raise InvalidParameterError(
                name,
                value,
                f"positive integer <= {max_value}",
                suggestion=f"Use a value between {min_value} and {max_value}"
            )

        return value

    @staticmethod
    def validate_float_range(
        value: any,
        name: str,
        min_value: float = 0.0,
        max_value: float = 1.0
    ) -> float:
        """
        Validate float in range.

        Args:
            value: Value to validate
            name: Parameter name
            min_value: Minimum value
            max_value: Maximum value

        Returns:
            Validated float

        Raises:
            InvalidParameterError: If value is invalid
        """
        # Check type
        if not isinstance(value, (int, float)):
            raise InvalidParameterError(
                name,
                value,
                f"number between {min_value} and {max_value}"
            )

        value = float(value)

        # Check range
        if value < min_value or value > max_value:
            raise InvalidParameterError(
                name,
                value,
                f"number between {min_value} and {max_value}"
            )

        return value

    @staticmethod
    def validate_choice(
        value: str,
        name: str,
        choices: List[str],
        case_sensitive: bool = False
    ) -> str:
        """
        Validate value is in list of choices.

        Args:
            value: Value to validate
            name: Parameter name
            choices: List of valid choices
            case_sensitive: Whether to enforce case sensitivity

        Returns:
            Validated choice

        Raises:
            InvalidParameterError: If value not in choices
        """
        if not value:
            raise EmptyInputError(name)

        # Normalize case if not case-sensitive
        if not case_sensitive:
            value_lower = value.lower()
            choices_map = {c.lower(): c for c in choices}

            if value_lower in choices_map:
                return choices_map[value_lower]
        else:
            if value in choices:
                return value

        # Not found
        raise InvalidParameterError(
            name,
            value,
            f"one of: {', '.join(choices)}",
            suggestion=f"Choose from: {', '.join(choices)}"
        )

    @staticmethod
    def validate_boolean(value: any, name: str) -> bool:
        """
        Validate boolean parameter.

        Args:
            value: Value to validate
            name: Parameter name

        Returns:
            Boolean value

        Raises:
            InvalidParameterError: If value is not boolean-like
        """
        if isinstance(value, bool):
            return value

        if isinstance(value, str):
            value_lower = value.lower()

            if value_lower in ('true', 'yes', '1', 'on', 'y'):
                return True
            elif value_lower in ('false', 'no', '0', 'off', 'n'):
                return False

        raise InvalidParameterError(
            name,
            value,
            "boolean (true/false)",
            suggestion="Use true/false, yes/no, or 1/0"
        )

    @staticmethod
    def validate_non_empty(value: str, name: str) -> str:
        """
        Validate string is not empty.

        Args:
            value: Value to validate
            name: Field name

        Returns:
            Non-empty string

        Raises:
            EmptyInputError: If value is empty
        """
        if not value or not value.strip():
            raise EmptyInputError(name)

        return value.strip()

    @staticmethod
    def validate_pattern(
        value: str,
        name: str,
        pattern: str,
        description: str
    ) -> str:
        """
        Validate string matches regex pattern.

        Args:
            value: Value to validate
            name: Field name
            pattern: Regex pattern
            description: Pattern description for error message

        Returns:
            Validated string

        Raises:
            ValidationError: If value doesn't match pattern
        """
        if not re.match(pattern, value):
            raise ValidationError(
                name,
                f"Does not match expected format: {description}",
                value=value
            )

        return value

    @staticmethod
    def sanitize_string(value: str, max_length: Optional[int] = None) -> str:
        """
        Sanitize string input.

        Args:
            value: String to sanitize
            max_length: Maximum length (optional)

        Returns:
            Sanitized string
        """
        if not value:
            return ""

        # Strip whitespace
        value = value.strip()

        # Remove null bytes
        value = value.replace('\x00', '')

        # Truncate if needed
        if max_length and len(value) > max_length:
            value = value[:max_length]

        return value
