"""Parameter validation for CLI commands."""

from typing import Optional, List, Any

from coding_assistant.exceptions.validation import (
    ValidationError,
    InvalidParameterError
)


class ParameterValidator:
    """
    Validates CLI command parameters.

    Ensures parameters are within acceptable ranges and formats.
    """

    @staticmethod
    def validate_top_k(value: int) -> int:
        """
        Validate top_k parameter for search results.

        Args:
            value: Number of results to return

        Returns:
            Validated value

        Raises:
            InvalidParameterError: If value is invalid
        """
        if not isinstance(value, int):
            raise InvalidParameterError(
                "top_k",
                value,
                "positive integer"
            )

        if value < 1:
            raise InvalidParameterError(
                "top_k",
                value,
                "positive integer (>= 1)"
            )

        if value > 100:
            raise InvalidParameterError(
                "top_k",
                value,
                "positive integer (<= 100)",
                suggestion="Use a smaller value (1-100) for better performance"
            )

        return value

    @staticmethod
    def validate_max_files(value: int) -> int:
        """
        Validate max_files parameter for indexing.

        Args:
            value: Maximum number of files to index

        Returns:
            Validated value

        Raises:
            InvalidParameterError: If value is invalid
        """
        if not isinstance(value, int):
            raise InvalidParameterError(
                "max_files",
                value,
                "positive integer"
            )

        if value < 1:
            raise InvalidParameterError(
                "max_files",
                value,
                "positive integer (>= 1)"
            )

        if value > 10000:
            raise InvalidParameterError(
                "max_files",
                value,
                "positive integer (<= 10000)",
                suggestion="Use a smaller value for better performance. 100-1000 is usually sufficient."
            )

        return value

    @staticmethod
    def validate_temperature(value: float) -> float:
        """
        Validate LLM temperature parameter.

        Args:
            value: Temperature value

        Returns:
            Validated value

        Raises:
            InvalidParameterError: If value is invalid
        """
        if not isinstance(value, (int, float)):
            raise InvalidParameterError(
                "temperature",
                value,
                "number between 0.0 and 2.0"
            )

        value = float(value)

        if value < 0.0 or value > 2.0:
            raise InvalidParameterError(
                "temperature",
                value,
                "number between 0.0 and 2.0",
                suggestion="Use 0.0 for deterministic, 0.7 for balanced, 1.0+ for creative"
            )

        return value

    @staticmethod
    def validate_hybrid_alpha(value: float) -> float:
        """
        Validate hybrid search alpha parameter.

        Args:
            value: Alpha value (weight for vector search)

        Returns:
            Validated value

        Raises:
            InvalidParameterError: If value is invalid
        """
        if not isinstance(value, (int, float)):
            raise InvalidParameterError(
                "hybrid_alpha",
                value,
                "number between 0.0 and 1.0"
            )

        value = float(value)

        if value < 0.0 or value > 1.0:
            raise InvalidParameterError(
                "hybrid_alpha",
                value,
                "number between 0.0 and 1.0",
                suggestion="Use 0.0 for keyword-only, 0.5 for balanced, 1.0 for vector-only"
            )

        return value

    @staticmethod
    def validate_provider(value: str, allowed_providers: Optional[List[str]] = None) -> str:
        """
        Validate LLM provider parameter.

        Args:
            value: Provider name
            allowed_providers: List of allowed providers

        Returns:
            Validated provider name

        Raises:
            InvalidParameterError: If provider is invalid
        """
        if allowed_providers is None:
            allowed_providers = ['ollama', 'openai', 'claude', 'mock']

        value_lower = value.lower()

        if value_lower not in allowed_providers:
            raise InvalidParameterError(
                "provider",
                value,
                f"one of: {', '.join(allowed_providers)}",
                suggestion=f"Choose from: {', '.join(allowed_providers)}"
            )

        return value_lower

    @staticmethod
    def validate_file_type(value: str) -> str:
        """
        Validate file type filter parameter.

        Args:
            value: File type (extension or language)

        Returns:
            Validated file type

        Raises:
            InvalidParameterError: If file type is invalid
        """
        common_types = [
            'python', 'py',
            'javascript', 'js', 'jsx',
            'typescript', 'ts', 'tsx',
            'java',
            'cpp', 'c', 'h',
            'csharp', 'cs',
            'go',
            'rust', 'rs',
            'ruby', 'rb',
            'php',
            'swift',
            'kotlin', 'kt'
        ]

        value_lower = value.lower()

        # Map common names to extensions
        type_map = {
            'python': 'py',
            'javascript': 'js',
            'typescript': 'ts',
            'csharp': 'cs',
            'rust': 'rs',
            'ruby': 'rb',
            'kotlin': 'kt'
        }

        if value_lower in type_map:
            return type_map[value_lower]

        if value_lower in common_types:
            return value_lower

        # Allow any extension starting with .
        if value.startswith('.'):
            return value[1:]  # Remove dot

        return value_lower

    @staticmethod
    def validate_context_size(value: int) -> int:
        """
        Validate context size parameter.

        Args:
            value: Number of context chunks

        Returns:
            Validated value

        Raises:
            InvalidParameterError: If value is invalid
        """
        if not isinstance(value, int):
            raise InvalidParameterError(
                "context_size",
                value,
                "positive integer"
            )

        if value < 1:
            raise InvalidParameterError(
                "context_size",
                value,
                "positive integer (>= 1)"
            )

        if value > 50:
            raise InvalidParameterError(
                "context_size",
                value,
                "positive integer (<= 50)",
                suggestion="Use a smaller value (1-20) for better performance"
            )

        return value
