"""Input sanitization utilities."""

import re
import html
from typing import Optional


class InputSanitizer:
    """
    Sanitizes user inputs to prevent injection attacks.

    Provides methods for cleaning and escaping potentially dangerous input.
    """

    @staticmethod
    def sanitize_query(query: str, max_length: int = 500) -> str:
        """
        Sanitize search query.

        Args:
            query: User query
            max_length: Maximum query length

        Returns:
            Sanitized query
        """
        if not query:
            return ""

        # Strip whitespace
        query = query.strip()

        # Remove null bytes
        query = query.replace('\x00', '')

        # Remove control characters except newline and tab
        query = ''.join(char for char in query if ord(char) >= 32 or char in '\n\t')

        # Normalize whitespace
        query = re.sub(r'\s+', ' ', query)

        # Truncate if needed
        if len(query) > max_length:
            query = query[:max_length]

        return query

    @staticmethod
    def sanitize_file_path(path: str) -> str:
        """
        Sanitize file path.

        Args:
            path: File path

        Returns:
            Sanitized path
        """
        if not path:
            return ""

        # Remove null bytes
        path = path.replace('\x00', '')

        # Remove dangerous characters
        dangerous_chars = ['<', '>', '|', '&', ';', '`', '$', '(', ')']
        for char in dangerous_chars:
            path = path.replace(char, '')

        # Normalize path separators
        path = path.replace('\\', '/')

        # Remove consecutive slashes
        path = re.sub(r'/+', '/', path)

        return path.strip()

    @staticmethod
    def sanitize_command(command: str) -> str:
        """
        Sanitize command string.

        Args:
            command: Command string

        Returns:
            Sanitized command
        """
        if not command:
            return ""

        # Remove null bytes
        command = command.replace('\x00', '')

        # Remove dangerous shell characters
        dangerous_chars = ['|', '&', ';', '`', '$', '(', ')', '<', '>', '\n']
        for char in dangerous_chars:
            command = command.replace(char, '')

        return command.strip()

    @staticmethod
    def escape_html(text: str) -> str:
        """
        Escape HTML special characters.

        Args:
            text: Text to escape

        Returns:
            HTML-escaped text
        """
        if not text:
            return ""

        return html.escape(text)

    @staticmethod
    def sanitize_code(code: str, language: Optional[str] = None) -> str:
        """
        Sanitize code input.

        Args:
            code: Code string
            language: Programming language (optional)

        Returns:
            Sanitized code
        """
        if not code:
            return ""

        # Remove null bytes
        code = code.replace('\x00', '')

        # Remove BOM if present
        if code.startswith('\ufeff'):
            code = code[1:]

        # Normalize line endings
        code = code.replace('\r\n', '\n')
        code = code.replace('\r', '\n')

        return code

    @staticmethod
    def sanitize_identifier(identifier: str) -> str:
        """
        Sanitize variable/function identifier.

        Args:
            identifier: Identifier name

        Returns:
            Sanitized identifier (only alphanumeric and underscore)
        """
        if not identifier:
            return ""

        # Keep only alphanumeric and underscore
        identifier = re.sub(r'[^a-zA-Z0-9_]', '', identifier)

        # Ensure doesn't start with number
        if identifier and identifier[0].isdigit():
            identifier = '_' + identifier

        return identifier

    @staticmethod
    def sanitize_string(
        value: str,
        max_length: Optional[int] = None,
        allowed_chars: Optional[str] = None
    ) -> str:
        """
        General string sanitization.

        Args:
            value: String to sanitize
            max_length: Maximum length
            allowed_chars: Regex pattern of allowed characters

        Returns:
            Sanitized string
        """
        if not value:
            return ""

        # Remove null bytes
        value = value.replace('\x00', '')

        # Filter by allowed characters
        if allowed_chars:
            value = ''.join(char for char in value if re.match(allowed_chars, char))

        # Strip whitespace
        value = value.strip()

        # Truncate if needed
        if max_length and len(value) > max_length:
            value = value[:max_length]

        return value

    @staticmethod
    def remove_ansi_codes(text: str) -> str:
        """
        Remove ANSI color codes from text.

        Args:
            text: Text with potential ANSI codes

        Returns:
            Text without ANSI codes
        """
        if not text:
            return ""

        # Remove ANSI escape sequences
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    @staticmethod
    def truncate_string(
        text: str,
        max_length: int,
        suffix: str = "..."
    ) -> str:
        """
        Truncate string to maximum length.

        Args:
            text: Text to truncate
            max_length: Maximum length
            suffix: Suffix to add when truncated

        Returns:
            Truncated string
        """
        if not text or len(text) <= max_length:
            return text

        return text[:max_length - len(suffix)] + suffix
