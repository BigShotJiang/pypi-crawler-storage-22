"""Version control system integration."""

from coding_assistant.vcs.git import GitIntegration

__all__ = ['GitIntegration']
