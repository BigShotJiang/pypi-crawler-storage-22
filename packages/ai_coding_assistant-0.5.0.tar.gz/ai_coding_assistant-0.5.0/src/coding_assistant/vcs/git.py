"""Git integration for context retrieval."""

from typing import List, Dict, Optional
from pathlib import Path
from datetime import datetime, timedelta
import git


class GitIntegration:
    """Git repository integration for enhanced context."""

    def __init__(self, repo_path: str):
        """Initialize Git integration.

        Args:
            repo_path: Path to git repository

        Raises:
            git.exc.InvalidGitRepositoryError: If not a git repository
        """
        self.repo_path = Path(repo_path)
        try:
            self.repo = git.Repo(repo_path, search_parent_directories=True)
        except git.exc.InvalidGitRepositoryError:
            self.repo = None

    def is_git_repo(self) -> bool:
        """Check if path is a git repository.

        Returns:
            True if git repo, False otherwise
        """
        return self.repo is not None

    def get_recent_changes(self, days: int = 7, max_files: int = 20) -> List[Dict]:
        """Get files changed in last N days.

        Args:
            days: Number of days to look back
            max_files: Maximum number of files to return

        Returns:
            List of dicts with file change information
        """
        if not self.is_git_repo():
            return []

        since = datetime.now() - timedelta(days=days)

        try:
            # Get commits since date
            commits = list(self.repo.iter_commits(
                all=True,
                since=since.isoformat()
            ))

            # Track file changes
            file_changes = {}

            for commit in commits:
                # Skip merge commits
                if len(commit.parents) > 1:
                    continue

                for file_path in commit.stats.files.keys():
                    if file_path not in file_changes:
                        file_changes[file_path] = {
                            'file': file_path,
                            'commits': [],
                            'total_changes': 0,
                            'last_modified': commit.committed_datetime,
                            'last_author': commit.author.name
                        }

                    stats = commit.stats.files[file_path]
                    file_changes[file_path]['commits'].append({
                        'sha': commit.hexsha[:7],
                        'message': commit.message.split('\n')[0],  # First line only
                        'author': commit.author.name,
                        'date': commit.committed_datetime.isoformat(),
                        'insertions': stats.get('insertions', 0),
                        'deletions': stats.get('deletions', 0),
                    })
                    file_changes[file_path]['total_changes'] += (
                        stats.get('insertions', 0) + stats.get('deletions', 0)
                    )

            # Sort by total changes (most active files first)
            sorted_files = sorted(
                file_changes.values(),
                key=lambda x: x['total_changes'],
                reverse=True
            )

            return sorted_files[:max_files]

        except Exception as e:
            # Git operations can fail for various reasons
            return []

    def get_uncommitted_changes(self) -> List[str]:
        """Get list of files with uncommitted changes.

        Returns:
            List of file paths
        """
        if not self.is_git_repo():
            return []

        try:
            # Get both staged and unstaged changes
            changed_files = set()

            # Unstaged changes
            changed_files.update(item.a_path for item in self.repo.index.diff(None))

            # Staged changes
            changed_files.update(item.a_path for item in self.repo.index.diff('HEAD'))

            # Untracked files
            changed_files.update(self.repo.untracked_files)

            return list(changed_files)

        except Exception:
            return []

    def get_file_history(self, file_path: str, limit: int = 5) -> List[Dict]:
        """Get commit history for a specific file.

        Args:
            file_path: Path to file (relative to repo root)
            limit: Maximum number of commits

        Returns:
            List of commit dicts
        """
        if not self.is_git_repo():
            return []

        try:
            commits = list(self.repo.iter_commits(paths=file_path, max_count=limit))

            history = []
            for commit in commits:
                history.append({
                    'sha': commit.hexsha[:7],
                    'message': commit.message.split('\n')[0],
                    'author': commit.author.name,
                    'date': commit.committed_datetime.isoformat(),
                    'email': commit.author.email
                })

            return history

        except Exception:
            return []

    def get_current_branch(self) -> Optional[str]:
        """Get current branch name.

        Returns:
            Branch name or None
        """
        if not self.is_git_repo():
            return None

        try:
            return self.repo.active_branch.name
        except Exception:
            return None

    def get_diff(self, file_path: Optional[str] = None) -> str:
        """Get diff for uncommitted changes.

        Args:
            file_path: Optional specific file path

        Returns:
            Diff string
        """
        if not self.is_git_repo():
            return ""

        try:
            if file_path:
                # Get diff for specific file
                diff = self.repo.git.diff(file_path)
            else:
                # Get all diffs
                diff = self.repo.git.diff()

            return diff

        except Exception:
            return ""

    def get_recent_commit_messages(self, count: int = 10) -> List[str]:
        """Get recent commit messages for context.

        Args:
            count: Number of commits

        Returns:
            List of commit messages
        """
        if not self.is_git_repo():
            return []

        try:
            commits = list(self.repo.iter_commits(max_count=count))
            return [commit.message.split('\n')[0] for commit in commits]
        except Exception:
            return []

    def get_contributors(self, limit: int = 10) -> List[Dict]:
        """Get repository contributors.

        Args:
            limit: Maximum number of contributors

        Returns:
            List of contributor dicts
        """
        if not self.is_git_repo():
            return []

        try:
            # Count commits per author
            author_counts = {}
            for commit in self.repo.iter_commits():
                author = commit.author.name
                if author not in author_counts:
                    author_counts[author] = {
                        'name': author,
                        'email': commit.author.email,
                        'commits': 0,
                        'last_commit': commit.committed_datetime
                    }
                author_counts[author]['commits'] += 1

            # Sort by commit count
            sorted_contributors = sorted(
                author_counts.values(),
                key=lambda x: x['commits'],
                reverse=True
            )

            return sorted_contributors[:limit]

        except Exception:
            return []

    def is_ignored(self, file_path: str) -> bool:
        """Check if file is in .gitignore.

        Args:
            file_path: Path to file

        Returns:
            True if ignored, False otherwise
        """
        if not self.is_git_repo():
            return False

        try:
            return file_path in self.repo.ignored(file_path)
        except Exception:
            return False
