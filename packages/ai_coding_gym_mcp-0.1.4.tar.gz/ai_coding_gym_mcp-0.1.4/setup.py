from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ai-coding-gym-mcp",
    version="0.1.4",
    author="AICodingGym Team",
    author_email="datasmithlab@gmail.com",
    description="MCP server for AI Coding Gym - fetch and submit AI coding challenges",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/ai-coding-gym-mcp",
    py_modules=["server"],
    install_requires=[
        "mcp>=0.9.0",
        "requests>=2.31.0",
    ],
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "ai-coding-gym-mcp=server:main",
            "ai_coding_gym_mcp=server:main",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
