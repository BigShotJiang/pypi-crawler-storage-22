"""Tests for commander module."""
