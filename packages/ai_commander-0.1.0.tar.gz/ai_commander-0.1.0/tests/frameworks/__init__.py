"""Tests for framework implementations."""
