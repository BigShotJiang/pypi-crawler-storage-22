"""Tests for output proxy and summarization."""
