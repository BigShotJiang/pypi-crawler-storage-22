"""Tests for runtime integration components."""
