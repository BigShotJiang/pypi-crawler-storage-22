"""Anti-pattern detectors for identifying code smells and architectural issues."""
