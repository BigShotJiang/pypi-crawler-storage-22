"""Design pattern detectors for Python and QGIS codebases."""
