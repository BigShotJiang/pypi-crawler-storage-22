"""Java debug adapter implementation."""
