"""Breakpoint service for managing breakpoints."""

from .manager import BreakpointService

__all__ = [
    "BreakpointService",
]
