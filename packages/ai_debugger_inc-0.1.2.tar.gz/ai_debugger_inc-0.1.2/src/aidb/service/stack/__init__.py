"""Stack service for call stack and thread introspection."""

from .navigator import StackService

__all__ = [
    "StackService",
]
