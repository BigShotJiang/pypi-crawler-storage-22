"""Variable service for inspecting and modifying variables."""

from .inspector import VariableService

__all__ = [
    "VariableService",
]
