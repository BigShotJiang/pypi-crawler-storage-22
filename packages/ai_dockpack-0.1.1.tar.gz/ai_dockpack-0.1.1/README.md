# ai-dockpack
AI-readable doc pack generator (CLI)
