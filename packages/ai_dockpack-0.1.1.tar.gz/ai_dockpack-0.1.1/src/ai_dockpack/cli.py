import typer
from rich import print

app = typer.Typer(help="ai-dockpack: AI-readable doc pack generator (CLI)")

@app.command()
def build(
    repo: str = typer.Option(".", help="要扫描的仓库路径（默认当前目录）"),
    out: str = typer.Option("docpack.zip", help="输出压缩包文件名（先占位）"),
):
    """生成 docpack.zip（Step1 先把命令跑通，后续再实现真正打包逻辑）"""
    from .build_impl import build_docpack
    out_path = build_docpack(repo, out)
    print(f"[green]OK[/green] 已生成：{out_path}")


@app.command()
def about():
    """显示工具信息（用于强制进入“多命令模式”）"""
    print("[cyan]ai-dockpack[/cyan] - AI-readable doc pack generator (CLI)")

if __name__ == "__main__":
    app()

@app.command("init")
def init_cmd(
    repo: str = typer.Option(".", help="要写入 workflow 的仓库路径（默认当前目录）"),
    release: bool = typer.Option(True, "--release/--no-release", help="是否发布到 GitHub Releases"),
    force: bool = typer.Option(False, "--force", help="覆盖已存在的 docpack.yml"),
):
    """一键生成 .github/workflows/docpack.yml（让仓库自动产出 docpack.zip）"""
    from .init_impl import init_workflow

    wf = init_workflow(repo, publish_release=release, force=force)
    print(f"[green]OK[/green] 已生成 workflow：{wf}")
