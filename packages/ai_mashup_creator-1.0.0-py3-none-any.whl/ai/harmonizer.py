"""AI harmonizer module for automatic key and chord compatibility."""

import numpy as np
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class HarmonicMatch:
    """Container for harmonic matching results."""
    target_key: str
    source_key: str
    transposition: int
    compatibility_score: float
    recommended_action: str


class Harmonizer:
    """AI-powered harmonizer for matching keys between tracks."""

    KEY_DISTANCE_MATRIX = {
        ("major", "major"): {
            0: 1.0, 1: 0.7, 2: 0.8, 3: 0.5, 4: 0.9, 5: 0.7, 
            6: 0.6, 7: 1.0, 8: 0.7, 9: 0.8, 10: 0.5, 11: 0.6
        },
        ("minor", "minor"): {
            0: 1.0, 1: 0.6, 2: 0.8, 3: 0.7, 4: 0.5, 5: 0.9, 
            6: 0.7, 7: 1.0, 8: 0.6, 9: 0.8, 10: 0.7, 11: 0.5
        },
        ("major", "minor"): {
            0: 0.5, 1: 0.6, 2: 0.7, 3: 0.4, 4: 0.6, 5: 0.5,
            6: 0.7, 7: 0.5, 8: 0.6, 9: 0.7, 10: 0.4, 11: 0.6
        },
        ("minor", "major"): {
            0: 0.5, 1: 0.6, 2: 0.7, 3: 0.4, 4: 0.6, 5: 0.5,
            6: 0.7, 7: 0.5, 8: 0.6, 9: 0.7, 10: 0.4, 11: 0.6
        }
    }

    SHIFT_NOTES = {
        "C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5,
        "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11
    }

    NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

    def __init__(self, sample_rate: int = 44100):
        """Initialize Harmonizer."""
        self.sample_rate = sample_rate

    def match_key(self, source_key: str, source_mode: str, 
                  target_key: str, target_mode: str) -> HarmonicMatch:
        """
        Calculate best key matching between source and target.

        Args:
            source_key: Source track key (e.g., "C", "G#")
            source_mode: Source mode ("major" or "minor")
            target_key: Target track key
            target_mode: Target mode

        Returns:
            HarmonicMatch with transposition info
        """
        source_idx = self.SHIFT_NOTES.get(source_key.upper().replace("♯", "#").replace("♭", "B"), 0)
        target_idx = self.SHIFT_NOTES.get(target_key.upper().replace("♯", "#").replace("♭", "B"), 0)

        distance = (target_idx - source_idx) % 12
        
        mode_key = (source_mode, target_mode)
        compatibility = self.KEY_DISTANCE_MATRIX.get(mode_key, {}).get(distance, 0.5)

        if compatibility > 0.8:
            action = "direct"
        elif compatibility > 0.6:
            action = "good"
        elif compatibility > 0.4:
            action = "moderate"
        else:
            action = "transpose"

        return HarmonicMatch(
            target_key=target_key,
            source_key=source_key,
            transposition=distance,
            compatibility_score=compatibility,
            recommended_action=action
        )

    def get_best_transposition(self, source_key: str, source_mode: str,
                               target_keys: List[str]) -> Tuple[int, str, float]:
        """
        Find best transposition to match any of the target keys.

        Args:
            source_key: Source key
            source_mode: Source mode
            target_keys: List of acceptable target keys

        Returns:
            Tuple of (transposition, best_target_key, score)
        """
        best_score = 0
        best_trans = 0
        best_target = target_keys[0] if target_keys else source_key

        for target in target_keys:
            target_clean = target.strip()[:-1]
            match = self.match_key(source_key, source_mode, target_clean, "major")
            if match.compatibility_score > best_score:
                best_score = match.compatibility_score
                best_trans = match.transposition
                best_target = target

        return best_trans, best_target, best_score

    def transpose_audio(self, audio: np.ndarray, semitones: int) -> np.ndarray:
        """
        Transpose audio by semitones.

        Args:
            audio: Audio data
            semitones: Number of semitones to shift

        Returns:
            Transposed audio
        """
        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for transposition")

        return librosa.effects.pitch_shift(audio, sr=self.sample_rate, n_steps=semitones)

    def harmonize(self, audio: np.ndarray, source_key: str, source_mode: str,
                  target_key: str, target_mode: str) -> np.ndarray:
        """
        Harmonize audio to match target key.

        Args:
            audio: Source audio
            source_key: Source key
            source_mode: Source mode
            target_key: Target key
            target_mode: Target mode

        Returns:
            Harmonized audio
        """
        match = self.match_key(source_key, source_mode, target_key, target_mode)
        
        if match.transposition == 0 or match.compatibility_score > 0.9:
            return audio

        return self.transpose_audio(audio, match.transposition)

    def suggest_key_change(self, current_key: str, mode: str, 
                           direction: str = "up") -> str:
        """
        Suggest a harmonically related key.

        Args:
            current_key: Current key
            mode: Current mode
            direction: 'up', 'down', or 'relative'

        Returns:
            Suggested key name
        """
        current_idx = self.SHIFT_NOTES.get(current_key.upper(), 0)
        
        if direction == "up":
            new_idx = (current_idx + 5) % 12
        elif direction == "down":
            new_idx = (current_idx - 5) % 12
        elif direction == "relative":
            if mode == "major":
                new_idx = (current_idx + 9) % 12
            else:
                new_idx = (current_idx + 3) % 12
        else:
            new_idx = current_idx

        return self.NOTE_NAMES[new_idx]

    def get_circle_of_fifths_neighbors(self, key: str, mode: str) -> List[str]:
        """
        Get harmonically related keys from circle of fifths.

        Args:
            key: Key name
            mode: Mode

        Returns:
            List of related Camelot codes
        """
        camelot_map = {
            "C": "8B", "G": "9B", "D": "10B", "A": "11B", "E": "12B", "B": "1B",
            "F#": "2B", "C#": "3B", "G#": "4B", "D#": "5B", "A#": "6B", "F": "7B",
            "Am": "5A", "Em": "9A", "Bm": "10A", "F#m": "11A", "C#m": "12A", "G#m": "1A",
            "D#m": "2A", "A#m": "3A", "Fm": "4A", "Cm": "5A", "Gm": "6A", "Dm": "7A"
        }
        
        current = camelot_map.get(key, "8B")
        num = int(current[0])
        letter = current[1]
        
        neighbors = [
            f"{num}{letter}",
            f"{(num - 1) % 12 + 1}{letter}",
            f"{(num + 1) % 12 + 1}{letter}",
        ]
        
        if letter == "B":
            neighbors.append(f"{num}A")
        else:
            neighbors.append(f"{num}B")
            
        return neighbors
