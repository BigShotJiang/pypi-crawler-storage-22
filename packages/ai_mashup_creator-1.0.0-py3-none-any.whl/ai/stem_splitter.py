"""AI stem splitter for separating audio into individual instrument stems."""

import numpy as np
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass
from pathlib import Path
import tempfile
import os


@dataclass
class StemInfo:
    """Container for stem information."""
    stem_type: str
    audio: np.ndarray
    confidence: float
    duration: float


class StemSplitter:
    """AI-powered stem splitter for separating audio into components."""

    STEM_TYPES = ["vocals", "drums", "bass", "other"]

    def __init__(self, model: str = "demucs", sample_rate: int = 44100):
        """
        Initialize StemSplitter.

        Args:
            model: Model to use ('demucs', 'spleeter', 'openunmix')
            sample_rate: Target sample rate
        """
        self.model = model
        self.sample_rate = sample_rate
        self._model_loaded = False

    def split(self, audio: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Split audio into separate stems.

        Args:
            audio: Audio waveform (mono or stereo)

        Returns:
            Dictionary with stem types as keys and audio arrays as values
        """
        if self.model == "demucs":
            return self._split_demucs(audio)
        elif self.model == "spleeter":
            return self._split_spleeter(audio)
        elif self.model == "simple":
            return self._split_simple(audio)
        else:
            raise ValueError(f"Unknown model: {self.model}")

    def _split_demucs(self, audio: np.ndarray) -> Dict[str, np.ndarray]:
        """Split using Demucs model."""
        try:
            import torch
            import torchaudio
            from demucs import pretrained
            from demucs.apply import apply_model
        except ImportError:
            return self._split_fallback(audio, "demucs")

        if not self._model_loaded:
            self._model = pretrained.get_model("demucs")
            self._model_loaded = True

        if len(audio.shape) == 1:
            audio = np.stack([audio, audio])

        audio_tensor = torch.from_numpy(audio).float().unsqueeze(0)
        
        with torch.no_grad():
            stems = apply_model(self._model, audio_tensor)

        stem_names = ["drums", "bass", "other", "vocals"]
        result = {}
        
        for i, name in enumerate(stem_names):
            result[name] = stems[0, i].numpy()

        result["vocals"] = self._ensure_mono(result["vocals"])
        return result

    def _split_spleeter(self, audio: np.ndarray) -> Dict[str, np.ndarray]:
        """Split using Spleeter model."""
        try:
            from spleeter.separator import Separator
        except ImportError:
            return self._split_fallback(audio, "spleeter")

        if not self._model_loaded:
            self._separator = Separator("spleeter:4stems")
            self._model_loaded = True

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            import soundfile as sf
            sf.write(tmp.name, audio.T, self.sample_rate)
            
            self._separator.separate_to_file(tmp.name, tempfile.gettempdir())
            
            result = {}
            for stem in ["vocals", "drums", "bass", "other"]:
                stem_path = Path(tempfile.gettempdir()) / f"{Path(tmp.name).stem}" / f"{stem}.wav"
                if stem_path.exists():
                    result[stem], _ = sf.read(stem_path)
            
            os.unlink(tmp.name)

        return result

    def _split_simple(self, audio: np.ndarray) -> Dict[str, np.ndarray]:
        """Simple frequency-based separation."""
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for simple stem splitting")

        stft = librosa.stft(audio, n_fft=2048, hop_length=512)
        magnitude = np.abs(stft)
        phase = np.angle(stft)

        freq_bins = magnitude.shape[0]
        
        drums_mask = np.zeros_like(magnitude)
        drums_mask[:freq_bins//8, :] = 1
        
        bass_mask = np.zeros_like(magnitude)
        bass_mask[freq_bins//8:freq_bins//4, :] = 1
        
        vocals_mask = np.zeros_like(magnitude)
        vocals_mask[freq_bins//4:freq_bins//2, :] = 1
        
        other_mask = np.zeros_like(magnitude)
        other_mask[freq_bins//2:, :] = 1

        result = {}
        
        for name, mask in [("drums", drums_mask), ("bass", bass_mask), 
                           ("vocals", vocals_mask), ("other", other_mask)]:
            stem_stft = magnitude * mask * np.exp(1j * phase)
            result[name] = librosa.istft(stem_stft, hop_length=512)

        return result

    def _split_fallback(self, audio: np.ndarray, model_name: str) -> Dict[str, np.ndarray]:
        """Fallback to simple separation if model unavailable."""
        return self._split_simple(audio)

    def _ensure_mono(self, audio: np.ndarray) -> np.ndarray:
        """Ensure audio is mono."""
        if len(audio.shape) > 1:
            return np.mean(audio, axis=0)
        return audio

    def split_to_files(self, audio: np.ndarray, output_dir: str, 
                       filename_prefix: str = "stem") -> Dict[str, str]:
        """
        Split audio and save stems to files.

        Args:
            audio: Audio to split
            output_dir: Output directory
            filename_prefix: Prefix for output files

        Returns:
            Dictionary mapping stem type to file path
        """
        import soundfile as sf
        from pathlib import Path

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        stems = self.split(audio)
        file_paths = {}

        for stem_type, stem_audio in stems.items():
            file_path = output_path / f"{filename_prefix}_{stem_type}.wav"
            sf.write(str(file_path), stem_audio, self.sample_rate)
            file_paths[stem_type] = str(file_path)

        return file_paths

    def remix_stems(self, stems: Dict[str, np.ndarray], 
                    volumes: Dict[str, float] = None) -> np.ndarray:
        """
        Remix stems with different volume levels.

        Args:
            stems: Dictionary of stems
            volumes: Dictionary of volume levels (0-1)

        Returns:
            Mixed audio
        """
        if volumes is None:
            volumes = {stem: 1.0 for stem in stems}

        mixed = None
        
        for stem_type, stem_audio in stems.items():
            vol = volumes.get(stem_type, 1.0)
            stem_audio = stem_audio * vol
            
            if mixed is None:
                mixed = stem_audio
            else:
                mixed = mixed + stem_audio

        if mixed is not None:
            mixed = mixed / len(stems)

        return mixed

    def get_stem_info(self, audio: np.ndarray) -> List[StemInfo]:
        """
        Get information about stems without full separation.

        Args:
            audio: Audio to analyze

        Returns:
            List of StemInfo objects
        """
        if len(audio.shape) > 1:
            audio_mono = np.mean(audio, axis=0)
        else:
            audio_mono = audio

        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for stem info")

        rms = librosa.feature.rms(y=audio_mono)[0]
        spectral_centroid = librosa.feature.spectral_centroid(y=audio_mono, sr=self.sample_rate)[0]

        duration = len(audio_mono) / self.sample_rate

        stems_info = []
        
        freq_ranges = {
            "bass": (20, 250),
            "drums": (250, 5000),
            "vocals": (300, 8000),
            "other": (5000, 20000)
        }

        for stem_type, (low, high) in freq_ranges.items():
            stems_info.append(StemInfo(
                stem_type=stem_type,
                audio=np.array([]),
                confidence=0.5,
                duration=duration
            ))

        return stems_info
