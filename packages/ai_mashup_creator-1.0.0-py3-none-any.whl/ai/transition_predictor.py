"""AI transition predictor for intelligent mix point selection."""

import numpy as np
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum


class TransitionType(Enum):
    """Types of transitions between tracks."""
    BEAT_MATCHED = "beat_matched"
    HARMONIC = "harmonic"
    ENERGY_BASED = "energy_based"
    PHRASE_ALIGNED = "phrase_aligned"
    FREE = "free"


@dataclass
class TransitionPoint:
    """Container for transition point data."""
    start_time: float
    end_time: float
    transition_type: TransitionType
    confidence: float
    energy_level: float
    bar_alignment: int


class TransitionPredictor:
    """AI-powered predictor for optimal mix points between tracks."""

    def __init__(self, sample_rate: int = 44100, hop_length: int = 512):
        """
        Initialize TransitionPredictor.

        Args:
            sample_rate: Audio sample rate
            hop_length: Hop length for analysis
        """
        self.sample_rate = sample_rate
        self.hop_length = hop_length
        self._energy_cache = {}

    def predict(self, track1_audio: np.ndarray, track2_audio: np.ndarray,
                track1_bpm: float, track2_bpm: float,
                track1_key: Optional[str] = None, track2_key: Optional[str] = None,
                track1_duration: float = 0.0, track2_duration: float = 0.0,
                transition_duration: float = 8.0) -> List[TransitionPoint]:
        """
        Predict optimal transition points between two tracks.

        Args:
            track1_audio: First track audio
            track2_audio: Second track audio
            track1_bpm: First track BPM
            track2_bpm: Second track BPM
            track1_key: First track key
            track2_key: Second track key
            track1_duration: First track duration in seconds
            track2_duration: Second track duration in seconds
            transition_duration: Desired transition duration in seconds

        Returns:
            List of predicted transition points
        """
        energy1 = self._get_energy_envelope(track1_audio)
        energy2 = self._get_energy_envelope(track2_audio)

        beat_interval_1 = 60.0 / track1_bpm
        beat_interval_2 = 60.0 / track2_bpm

        transition_points = []

        candidate_times = self._find_energy_peaks(energy1, min_distance=int(transition_duration * self.sample_rate / self.hop_length))

        for time_idx in candidate_times[:10]:
            time_sec = time_idx * self.hop_length / self.sample_rate
            
            confidence = self._calculate_confidence(
                time_sec, energy1, energy2, 
                track1_bpm, track2_bpm,
                track1_key, track2_key
            )

            energy_level = float(energy1[time_idx]) if time_idx < len(energy1) else 0.5
            bar_alignment = int((time_sec % (beat_interval_1 * 4)) / beat_interval_1)

            trans_type = self._determine_transition_type(
                track1_bpm, track2_bpm, track1_key, track2_key
            )

            transition_points.append(TransitionPoint(
                start_time=time_sec,
                end_time=time_sec + transition_duration,
                transition_type=trans_type,
                confidence=confidence,
                energy_level=energy_level,
                bar_alignment=bar_alignment
            ))

        transition_points.sort(key=lambda x: x.confidence, reverse=True)
        return transition_points[:5]

    def _get_energy_envelope(self, audio: np.ndarray) -> np.ndarray:
        """Calculate energy envelope of audio."""
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for energy analysis")

        energy = librosa.feature.rms(y=audio, hop_length=self.hop_length)[0]
        energy = energy / (np.max(energy) + 1e-10)
        return energy

    def _find_energy_peaks(self, energy: np.ndarray, min_distance: int = 100) -> List[int]:
        """Find peaks in energy envelope."""
        peaks = []
        for i in range(1, len(energy) - 1):
            if energy[i] > energy[i-1] and energy[i] > energy[i+1]:
                if energy[i] > np.mean(energy) * 0.8:
                    if not peaks or i - peaks[-1] > min_distance:
                        peaks.append(i)
        return peaks

    def _calculate_confidence(self, time_sec: float, energy1: np.ndarray,
                               energy2: np.ndarray, bpm1: float, bpm2: float,
                               key1: Optional[str], key2: Optional[str]) -> float:
        """Calculate confidence score for transition point."""
        time_idx = int(time_sec * self.sample_rate / self.hop_length)
        
        if time_idx >= len(energy1):
            return 0.0

        energy_score = float(energy1[time_idx])

        bpm_diff = abs(bpm1 - bpm2) / max(bpm1, bpm2)
        bpm_score = 1.0 - min(bpm_diff, 1.0)

        key_score = 0.5
        if key1 and key2:
            key_score = self._key_compatibility_score(key1, key2)

        total_score = (energy_score * 0.4) + (bpm_score * 0.4) + (key_score * 0.2)
        return min(total_score, 1.0)

    def _key_compatibility_score(self, key1: str, key2: str) -> float:
        """Calculate key compatibility score."""
        compatible_pairs = [
            ("C", "C"), ("C", "Am"), ("G", "G"), ("G", "Em"),
            ("A", "A"), ("A", "F#m"), ("E", "E"), ("E", "C#m"),
            ("D", "D"), ("D", "Bm"), ("F", "F"), ("F", "Dm")
        ]
        
        key1_clean = key1.strip()
        key2_clean = key2.strip()
        
        if (key1_clean, key2_clean) in compatible_pairs or (key2_clean, key1_clean) in compatible_pairs:
            return 1.0
        elif key1_clean == key2_clean:
            return 0.9
        else:
            return 0.3

    def _determine_transition_type(self, bpm1: float, bpm2: float,
                                   key1: Optional[str], key2: Optional[str]) -> TransitionType:
        """Determine the best transition type."""
        bpm_ratio = min(bpm1, bpm2) / max(bpm1, bpm2)
        
        if bpm_ratio > 0.95:
            return TransitionType.BEAT_MATCHED
        elif key1 and key2 and key1 == key2:
            return TransitionType.HARMONIC
        elif bpm_ratio > 0.8:
            return TransitionType.ENERGY_BASED
        else:
            return TransitionType.FREE

    def find_phrase_boundary(self, audio: np.ndarray, bpm: float) -> List[float]:
        """
        Find phrase boundaries (4-bar, 8-bar sections).

        Args:
            audio: Audio data
            bpm: Track BPM

        Returns:
            List of phrase boundary times in seconds
        """
        energy = self._get_energy_envelope(audio)
        
        bar_duration = 60.0 / bpm * 4
        phrase_duration = bar_duration * 4
        
        boundaries = []
        num_phrases = int(len(audio) / self.sample_rate / phrase_duration)
        
        for i in range(num_phrases):
            time_sec = i * phrase_duration
            boundaries.append(time_sec)
        
        return boundaries

    def suggest_transition_style(self, source_energy: float, target_energy: float,
                                 key_compatible: bool) -> str:
        """
        Suggest transition style based on track characteristics.

        Args:
            source_energy: Source track energy (0-1)
            target_energy: Target track energy (0-1)
            key_compatible: Whether keys are harmonically compatible

        Returns:
            Suggested transition style name
        """
        energy_diff = abs(source_energy - target_energy)
        
        if energy_diff < 0.2 and key_compatible:
            return "smooth_blend"
        elif energy_diff < 0.3:
            return "progressive"
        elif source_energy < target_energy:
            return "energy_ramp"
        else:
            return "impact_drop"

    def optimize_crossfade(self, point: TransitionPoint, 
                           target_duration: float = 8.0) -> Dict[str, Any]:
        """
        Optimize crossfade parameters for transition point.

        Returns:
            Dictionary with optimized crossfade parameters
        """
        if point.transition_type == TransitionType.BEAT_MATCHED:
            return {
                "curve": "linear",
                "midpoint": target_duration / 2,
                "eq_matching": True,
                "high_pass_fade": True
            }
        elif point.transition_type == TransitionType.HARMONIC:
            return {
                "curve": "sigmoid",
                "midpoint": target_duration / 2,
                "eq_matching": True,
                "reverb_sync": True
            }
        else:
            return {
                "curve": "exponential",
                "midpoint": target_duration * 0.4,
                "eq_matching": False,
                "filter_sweep": True
            }
