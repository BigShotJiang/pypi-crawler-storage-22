"""Audio processing module for loading, analyzing and manipulating audio files."""

import numpy as np
from typing import Optional, Tuple, Dict, Any
from pathlib import Path


class AudioProcessor:
    """Main audio processing class for loading and manipulating audio."""

    def __init__(self, sample_rate: int = 44100, bit_depth: int = 16):
        """
        Initialize AudioProcessor.

        Args:
            sample_rate: Target sample rate (default: 44100 Hz)
            bit_depth: Target bit depth (default: 16)
        """
        self.sample_rate = sample_rate
        self.bit_depth = bit_depth
        self._audio_data: Optional[np.ndarray] = None
        self._original_sr: Optional[int] = None
        self._file_path: Optional[Path] = None

    def load(self, file_path: str) -> np.ndarray:
        """
        Load audio file.

        Args:
            file_path: Path to audio file

        Returns:
            Audio data as numpy array
        """
        try:
            import librosa
            audio, sr = librosa.load(file_path, sr=self.sample_rate, mono=False)
            self._audio_data = audio
            self._original_sr = sr
            self._file_path = Path(file_path)
            return audio
        except ImportError:
            raise ImportError("librosa is required for audio loading. Install with: pip install librosa")

    def save(self, file_path: str, audio_data: Optional[np.ndarray] = None) -> None:
        """
        Save audio to file.

        Args:
            file_path: Output file path
            audio_data: Audio data to save (uses loaded audio if None)
        """
        if audio_data is None:
            audio_data = self._audio_data

        if audio_data is None:
            raise ValueError("No audio data to save")

        try:
            import librosa
            import soundfile as sf
            sf.write(file_path, audio_data.T, self.sample_rate)
        except ImportError:
            raise ImportError("soundfile is required for audio saving. Install with: pip install soundfile")

    def get_duration(self) -> float:
        """Get audio duration in seconds."""
        if self._audio_data is None:
            return 0.0
        return len(self._audio_data[0] if len(self._audio_data.shape) > 1 else self._audio_data) / self.sample_rate

    def get_waveform(self) -> np.ndarray:
        """Get mono waveform representation."""
        if self._audio_data is None:
            raise ValueError("No audio loaded")
        
        if len(self._audio_data.shape) > 1:
            return np.mean(self._audio_data, axis=0)
        return self._audio_data

    def get_spectrogram(self, n_fft: int = 2048, hop_length: int = 512) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute spectrogram.

        Returns:
            Tuple of (magnitude, frequencies)
        """
        if self._audio_data is None:
            raise ValueError("No audio loaded")

        try:
            import librosa
            waveform = self.get_waveform()
            stft = librosa.stft(waveform, n_fft=n_fft, hop_length=hop_length)
            magnitude = np.abs(stft)
            frequencies = librosa.fft_frequencies(sr=self.sample_rate, n_fft=n_fft)
            return magnitude, frequencies
        except ImportError:
            raise ImportError("librosa is required for spectrogram")

    def normalize(self, audio_data: Optional[np.ndarray] = None, target_db: float = -3.0) -> np.ndarray:
        """
        Normalize audio to target dB level.

        Args:
            audio_data: Audio to normalize
            target_db: Target peak level in dB

        Returns:
            Normalized audio
        """
        if audio_data is None:
            audio_data = self._audio_data

        if audio_data is None:
            raise ValueError("No audio data")

        peak = np.abs(audio_data).max()
        if peak == 0:
            return audio_data

        target_amplitude = 10 ** (target_db / 20)
        scale = target_amplitude / peak
        return audio_data * scale

    def fade_in(self, duration: float = 0.5) -> np.ndarray:
        """Apply fade in effect."""
        if self._audio_data is None:
            raise ValueError("No audio loaded")

        samples = int(duration * self.sample_rate)
        waveform = self.get_waveform()
        fade_curve = np.linspace(0, 1, samples)
        
        if len(waveform) > samples:
            waveform[:samples] *= fade_curve
        return waveform

    def fade_out(self, duration: float = 0.5) -> np.ndarray:
        """Apply fade out effect."""
        if self._audio_data is None:
            raise ValueError("No audio loaded")

        waveform = self.get_waveform()
        samples = int(duration * self.sample_rate)
        
        if len(waveform) > samples:
            fade_curve = np.linspace(1, 0, samples)
            waveform[-samples:] *= fade_curve
        return waveform

    def trim_silence(self, threshold_db: float = -40.0, frame_length: int = 2048) -> np.ndarray:
        """Trim silence from beginning and end."""
        if self._audio_data is None:
            raise ValueError("No audio loaded")

        try:
            import librosa
            waveform = self.get_waveform()
            trimmed, _ = librosa.effects.trim(waveform, top_db=-threshold_db)
            return trimmed
        except ImportError:
            raise ImportError("librosa is required for trim")

    def get_info(self) -> Dict[str, Any]:
        """Get audio file information."""
        if self._file_path is None:
            return {}

        return {
            "file_path": str(self._file_path),
            "sample_rate": self.sample_rate,
            "bit_depth": self.bit_depth,
            "duration": self.get_duration(),
            "channels": 2 if len(self._audio_data.shape) > 1 else 1 if self._audio_data is not None else 0
        }
