"""Beat detection module for analyzing tempo and beat positions in audio."""

import numpy as np
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class BeatInfo:
    """Container for beat detection results."""
    bpm: float
    beat_times: np.ndarray
    downbeat_times: Optional[np.ndarray] = None
    bar_length: Optional[float] = None


class BeatDetector:
    """Detects beats, tempo, and downbeats in audio."""

    def __init__(self, sample_rate: int = 44100, hop_length: int = 512):
        """
        Initialize BeatDetector.

        Args:
            sample_rate: Audio sample rate
            hop_length: Hop length for STFT
        """
        self.sample_rate = sample_rate
        self.hop_length = hop_length

    def detect(self, audio: np.ndarray, method: str = "default") -> BeatInfo:
        """
        Detect beats in audio.

        Args:
            audio: Audio waveform (mono or stereo)
            method: Detection method ('default', 'madmom', 'crepe')

        Returns:
            BeatInfo object with detected beats
        """
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for beat detection")

        if method == "default":
            tempo, beats = librosa.beat.beat_track(y=audio, sr=self.sample_rate, hop_length=self.hop_length)
            beat_times = librosa.frames_to_time(beats, sr=self.sample_rate, hop_length=self.hop_length)
            
            bar_length = 60.0 / tempo * 4 if tempo > 0 else None
            downbeat_times = self._detect_downbeats(beat_times, bar_length)
            
            return BeatInfo(
                bpm=float(tempo),
                beat_times=beat_times,
                downbeat_times=downbeat_times,
                bar_length=bar_length
            )
        else:
            return self._detect_with_dl(audio, method)

    def _detect_downbeats(self, beat_times: np.ndarray, bar_length: Optional[float]) -> Optional[np.ndarray]:
        """Detect downbeats from beat times."""
        if bar_length is None or len(beat_times) < 4:
            return None

        downbeats = []
        for i, beat in enumerate(beat_times):
            position_in_bar = (beat % bar_length) / bar_length
            if position_in_bar < 0.1 or position_in_bar > 0.9:
                downbeats.append(beat)

        return np.array(downbeats) if downbeats else None

    def _detect_with_dl(self, audio: np.ndarray, method: str) -> BeatInfo:
        """Detect beats using deep learning methods."""
        raise NotImplementedError(f"Deep learning method '{method}' not implemented yet")

    def get_beat_grid(self, duration: float, bpm: float, offset: float = 0.0) -> np.ndarray:
        """
        Generate a beat grid for given duration and BPM.

        Args:
            duration: Track duration in seconds
            bpm: Beats per minute
            offset: Time offset in seconds

        Returns:
            Array of beat times
        """
        beat_interval = 60.0 / bpm
        num_beats = int(duration / beat_interval) + 1
        return np.array([offset + i * beat_interval for i in range(num_beats)])

    def align_to_grid(self, beat_times: np.ndarray, target_bpm: float) -> np.ndarray:
        """
        Align beat times to a target BPM grid.

        Args:
            beat_times: Original beat times
            target_bpm: Target BPM

        Returns:
            Aligned beat times
        """
        target_interval = 60.0 / target_bpm
        aligned = np.round(beat_times / target_interval) * target_interval
        return aligned

    def analyze_tempo(self, audio: np.ndarray) -> Dict[str, Any]:
        """
        Analyze tempo characteristics.

        Returns:
            Dictionary with tempo analysis
        """
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for tempo analysis")

        tempo, frames = librosa.beat.beat_track(y=audio, sr=self.sample_rate)
        
        return {
            "bpm": float(tempo),
            "beat_frames": frames.tolist(),
            "estimated_time_signature": 4
        }

    def get_beat_intervals(self, beat_times: np.ndarray) -> np.ndarray:
        """Calculate intervals between consecutive beats."""
        if len(beat_times) < 2:
            return np.array([])
        return np.diff(beat_times)

    def detect_tempo_changes(self, beat_times: np.ndarray, window_size: int = 8) -> List[Tuple[float, float, float]]:
        """
        Detect tempo changes within a track.

        Returns:
            List of (start_time, end_time, local_bpm) tuples
        """
        if len(beat_times) < window_size * 2:
            return []

        intervals = self.get_beat_intervals(beat_times)
        changes = []

        for i in range(0, len(intervals) - window_size, window_size):
            window = intervals[i:i + window_size]
            local_bpm = 60.0 / np.mean(window) if np.mean(window) > 0 else 0
            changes.append((beat_times[i], beat_times[i + window_size], local_bpm))

        return changes

    def sync_to_reference(self, source_bpm: float, target_bpm: float, 
                          source_beat_times: np.ndarray) -> np.ndarray:
        """
        Sync source beats to target BPM.

        Args:
            source_bpm: Source track BPM
            target_bpm: Target BPM to sync to
            source_beat_times: Source beat times

        Returns:
            Beat times adjusted to target BPM
        """
        ratio = target_bpm / source_bpm
        return source_beat_times * ratio
