"""Key detection module for analyzing musical key and harmony."""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass


@dataclass
class KeyInfo:
    """Container for key detection results."""
    key: str
    mode: str
    camelot_code: str
    confidence: float
    chords_detected: Optional[List[Tuple[float, float, str]]] = None


class KeyDetector:
    """Detects musical key and analyzes harmony."""

    CAMELOT_WHEEL = {
        "C": "8B", "C#": "3B", "D": "10B", "D#": "5B", "E": "12B", "F": "7B",
        "F#": "2B", "G": "9B", "G#": "4B", "A": "11B", "A#": "6B", "B": "1B",
        "Cm": "5A", "C#m": "12A", "Dm": "7A", "D#m": "2A", "Em": "9A",
        "Fm": "4A", "F#m": "11A", "Gm": "6A", "G#m": "1A", "Am": "8A",
        "A#m": "3A", "Bm": "10A"
    }

    KEY_TO_ROOT = {
        "C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5,
        "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11
    }

    MODE_NAMES = ["major", "minor"]

    def __init__(self, sample_rate: int = 44100, hop_length: int = 512):
        """
        Initialize KeyDetector.

        Args:
            sample_rate: Audio sample rate
            hop_length: Hop length for STFT
        """
        self.sample_rate = sample_rate
        self.hop_length = hop_length

    def detect(self, audio: np.ndarray, method: str = "krumhansl") -> KeyInfo:
        """
        Detect musical key in audio.

        Args:
            audio: Audio waveform
            method: Detection method ('krumhansl', 'shanks', 'simple')

        Returns:
            KeyInfo object with detected key
        """
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        if method == "krumhansl":
            return self._detect_krumhansl(audio)
        elif method == "shanks":
            return self._detect_shanks(audio)
        else:
            return self._detect_simple(audio)

    def _detect_krumhansl(self, audio: np.ndarray) -> KeyInfo:
        """Detect key using Krumhansl-Schmuckler algorithm."""
        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for key detection")

        chroma = librosa.feature.chroma_cqt(y=audio, sr=self.sample_rate, hop_length=self.hop_length)
        chroma_mean = np.mean(chroma, axis=1)

        major_profile = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
        minor_profile = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]

        major_corrs = np.correlate(chroma_mean, major_profile, mode='full')
        minor_corrs = np.correlate(chroma_mean, minor_profile, mode='full')

        key_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        
        major_idx = np.argmax(major_corrs)
        minor_idx = np.argmax(minor_corrs)

        if major_corrs[major_idx] > minor_corrs[minor_idx]:
            root = major_idx % 12
            key = key_names[root]
            mode = "major"
            confidence = float(major_corrs[major_idx] / (np.sum(chroma_mean) + 1e-10))
        else:
            root = minor_idx % 12
            key = key_names[root]
            mode = "minor"
            confidence = float(minor_corrs[minor_idx] / (np.sum(chroma_mean) + 1e-10))

        camelot = self._get_camelot_code(key, mode)

        return KeyInfo(
            key=key,
            mode=mode,
            camelot_code=camelot,
            confidence=confidence
        )

    def _detect_shanks(self, audio: np.ndarray) -> KeyInfo:
        """Detect key using Shanks algorithm."""
        return self._detect_krumhansl(audio)

    def _detect_simple(self, audio: np.ndarray) -> KeyInfo:
        """Simple key detection based on chroma peaks."""
        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for key detection")

        chroma = librosa.feature.chroma_cqt(y=audio, sr=self.sample_rate, hop_length=self.hop_length)
        chroma_mean = np.mean(chroma, axis=1)

        key_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        
        peak_idx = np.argmax(chroma_mean)
        key = key_names[peak_idx]
        
        major_energy = sum(chroma_mean[i] for i in [0, 2, 4, 5, 7, 9, 11])
        minor_energy = sum(chroma_mean[i] for i in [0, 2, 3, 5, 7, 8, 10])
        
        mode = "major" if major_energy > minor_energy else "minor"
        confidence = float(max(major_energy, minor_energy) / (sum(chroma_mean) + 1e-10))

        return KeyInfo(
            key=key,
            mode=mode,
            camelot_code=self._get_camelot_code(key, mode),
            confidence=confidence
        )

    def _get_camelot_code(self, key: str, mode: str) -> str:
        """Convert key and mode to Camelot code."""
        if mode == "major":
            camelot_map = {
                "C": "8B", "C#": "3B", "D": "10B", "D#": "5B", "E": "12B", "F": "7B",
                "F#": "2B", "G": "9B", "G#": "4B", "A": "11B", "A#": "6B", "B": "1B"
            }
        else:
            camelot_map = {
                "C": "5A", "C#": "12A", "D": "7A", "D#": "2A", "E": "9A", "F": "4A",
                "F#": "11A", "G": "6A", "G#": "1A", "A": "8A", "A#": "3A", "B": "10A"
            }
        return camelot_map.get(key, "8B")

    def get_compatible_keys(self, key_info: KeyInfo, mode: str = "both") -> List[str]:
        """
        Get harmonically compatible keys.

        Args:
            key_info: Current key info
            mode: 'both', 'mixable' (same mode), or 'all' (all compatible)

        Returns:
            List of compatible Camelot codes
        """
        code = key_info.camelot_code
        if not code:
            return []

        number = int(code[0])
        letter = code[1]

        compatible = []

        if letter == "B":
            compatible.extend([f"{number}B", f"{(number - 1) % 12 + 1}B", f"{(number + 1) % 12 + 1}B"])
            if mode in ["both", "all"]:
                compatible.extend([f"{number}A", f"{(number - 1) % 12 + 1}A", f"{(number + 1) % 12 + 1}A"])
        else:
            compatible.extend([f"{number}A", f"{(number - 1) % 12 + 1}A", f"{(number + 1) % 12 + 1}A"])
            if mode in ["both", "all"]:
                compatible.extend([f"{number}B", f"{(number - 1) % 12 + 1}B", f"{(number + 1) % 12 + 1}B"])

        return compatible

    def transpose_key(self, key_info: KeyInfo, semitones: int) -> KeyInfo:
        """
        Transpose key by semitones.

        Args:
            key_info: Original key info
            semitones: Number of semitones to transpose

        Returns:
            Transposed KeyInfo
        """
        key_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        
        current_idx = self.KEY_TO_ROOT.get(key_info.key, 0)
        new_idx = (current_idx + semitones) % 12
        new_key = key_names[new_idx]

        return KeyInfo(
            key=new_key,
            mode=key_info.mode,
            camelot_code=self._get_camelot_code(new_key, key_info.mode),
            confidence=key_info.confidence
        )

    def analyze_chords(self, audio: np.ndarray, n_fft: int = 4096) -> List[Tuple[float, float, str]]:
        """
        Detect chord progression in audio.

        Returns:
            List of (start_time, end_time, chord_name) tuples
        """
        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for chord detection")

        chroma = librosa.feature.chroma_cqt(y=audio, sr=self.sample_rate, n_octaves=3)
        
        chords = []
        frame_times = librosa.frames_to_time(np.arange(chroma.shape[1]), sr=self.sample_rate, hop_length=self.hop_length)
        
        chord_names = ["C", "Dm", "Em", "F", "G", "Am"]
        
        for i in range(0, len(chroma[0]), 10):
            if i + 10 < chroma.shape[1]:
                segment = np.mean(chroma[:, i:i+10], axis=1)
                chord_idx = np.argmax(segment[:6])
                start_time = frame_times[i]
                end_time = frame_times[min(i+10, len(frame_times)-1)]
                chords.append((start_time, end_time, chord_names[chord_idx]))

        return chords
