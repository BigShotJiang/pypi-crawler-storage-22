"""Equalizer module for frequency band manipulation."""

import numpy as np
from typing import Optional, List, Tuple, Dict, Any
from dataclasses import dataclass


@dataclass
class EQBand:
    """Equalizer band parameters."""
    frequency: float
    gain_db: float
    q: float = 1.0
    filter_type: str = "peaking"


class Equalizer:
    """Multi-band equalizer for audio frequency manipulation."""

    DEFAULT_BANDS = [
        EQBand(32, 0),
        EQBand(64, 0),
        EQBand(125, 0),
        EQBand(250, 0),
        EQBand(500, 0),
        EQBand(1000, 0),
        EQBand(2000, 0),
        EQBand(4000, 0),
        EQBand(8000, 0),
        EQBand(16000, 0),
    ]

    def __init__(self, sample_rate: int = 44100):
        """
        Initialize Equalizer.

        Args:
            sample_rate: Audio sample rate
        """
        self.sample_rate = sample_rate
        self.bands = self.DEFAULT_BANDS.copy()
        self._filters_cache = {}

    def set_band(self, index: int, gain_db: float, 
                 frequency: Optional[float] = None, 
                 q: Optional[float] = None) -> None:
        """
        Set parameters for a specific EQ band.

        Args:
            index: Band index
            gain_db: Gain in dB
            frequency: Center frequency (optional)
            q: Q factor (optional)
        """
        if 0 <= index < len(self.bands):
            self.bands[index].gain_db = gain_db
            if frequency is not None:
                self.bands[index].frequency = frequency
            if q is not None:
                self.bands[index].q = q
            self._filters_cache.clear()

    def apply(self, audio: np.ndarray) -> np.ndarray:
        """
        Apply equalization to audio.

        Args:
            audio: Audio data

        Returns:
            Equalized audio
        """
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        filtered = audio.copy()
        
        for band in self.bands:
            if band.gain_db != 0:
                filtered = self._apply_filter(filtered, band)

        return filtered

    def _apply_filter(self, audio: np.ndarray, band: EQBand) -> np.ndarray:
        """Apply single band filter."""
        try:
            import scipy.signal as signal
        except ImportError:
            return audio

        w0 = 2 * np.pi * band.frequency / self.sample_rate
        alpha = np.sin(w0) / (2 * band.q)
        A = 10 ** (band.gain_db / 40)

        if band.filter_type == "peaking":
            b = [
                1 + alpha * A,
                -2 * np.cos(w0),
                1 - alpha * A
            ]
            a = [
                1 + alpha / A,
                -2 * np.cos(w0),
                1 - alpha / A
            ]
        elif band.filter_type == "low_shelf":
            b = [
                A * ((A + 1) + (A - 1) * np.cos(w0) + 2 * np.sqrt(A) * alpha),
                -2 * A * ((A - 1) + (A + 1) * np.cos(w0)),
                A * ((A + 1) + (A - 1) * np.cos(w0) - 2 * np.sqrt(A) * alpha)
            ]
            a = [
                (A + 1) - (A - 1) * np.cos(w0) + 2 * np.sqrt(A) * alpha,
                2 * ((A - 1) - (A + 1) * np.cos(w0)),
                (A + 1) - (A - 1) * np.cos(w0) - 2 * np.sqrt(A) * alpha
            ]
        elif band.filter_type == "high_shelf":
            b = [
                A * ((A + 1) - (A - 1) * np.cos(w0) + 2 * np.sqrt(A) * alpha),
                2 * A * ((A - 1) - (A + 1) * np.cos(w0)),
                A * ((A + 1) - (A - 1) * np.cos(w0) - 2 * np.sqrt(A) * alpha)
            ]
            a = [
                (A + 1) + (A - 1) * np.cos(w0) + 2 * np.sqrt(A) * alpha,
                -2 * ((A - 1) + (A + 1) * np.cos(w0)),
                (A + 1) + (A - 1) * np.cos(w0) - 2 * np.sqrt(A) * alpha
            ]
        elif band.filter_type == "low_pass":
            b = [(1 - np.cos(w0)) / 2, 1 - np.cos(w0), (1 - np.cos(w0)) / 2]
            a = [1 + alpha, -2 * np.cos(w0), 1 - alpha]
        elif band.filter_type == "high_pass":
            b = [(1 + np.cos(w0)) / 2, -(1 + np.cos(w0)), (1 + np.cos(w0)) / 2]
            a = [1 + alpha, -2 * np.cos(w0), 1 - alpha]
        else:
            return audio

        try:
            return signal.filtfilt(b, a, audio)
        except:
            return audio

    def preset(self, name: str) -> None:
        """
        Apply EQ preset.

        Args:
            name: Preset name ('bass_boost', 'vocal', 'club', etc.)
        """
        presets = {
            "flat": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            "bass_boost": [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
            "bass_cut": [-6, -5, -4, -2, 0, 0, 0, 0, 0, 0],
            "vocal": [-2, -1, 0, 2, 4, 4, 2, 0, -1, -2],
            "club": [4, 3, 2, 1, -1, -1, 0, 2, 3, 4],
            "warm": [3, 2, 1, 0, 0, 0, 1, 2, 2, 1],
            "bright": [0, 0, 0, 1, 2, 2, 3, 4, 4, 3],
            "telephone": [-4, -2, 0, 2, 0, 0, 0, -2, -4, -6],
            "lofi": [-2, 0, 2, 3, 2, 0, -2, -4, -6, -8],
        }

        if name in presets:
            for i, gain in enumerate(presets[name]):
                if i < len(self.bands):
                    self.bands[i].gain_db = gain

    def get_response(self, num_points: int = 512) -> Tuple[np.ndarray, np.ndarray]:
        """
        Get frequency response curve.

        Returns:
            Tuple of (frequencies, magnitudes)
        """
        try:
            import scipy.signal as signal
        except ImportError:
            return np.array([]), np.array([])

        freqs = np.logspace(np.log10(20), np.log10(self.sample_rate / 2), num_points)
        magnitudes = np.ones(num_points)

        for band in self.bands:
            if band.gain_db != 0:
                w0 = 2 * np.pi * band.frequency / self.sample_rate
                alpha = np.sin(w0) / (2 * band.q)
                A = 10 ** (band.gain_db / 40)
                
                if band.filter_type == "peaking":
                    b = [1 + alpha * A, -2 * np.cos(w0), 1 - alpha * A]
                    a = [1 + alpha / A, -2 * np.cos(w0), 1 - alpha / A]
                else:
                    continue

                try:
                    w, h = signal.freqz(b, a, 2 * np.pi * freqs / self.sample_rate)
                    magnitudes *= np.abs(h)
                except:
                    pass

        return freqs, magnitudes

    def sweep(self, audio: np.ndarray, start_freq: float, 
              end_freq: float, duration: float = 4.0) -> np.ndarray:
        """
        Apply frequency sweep effect.

        Args:
            audio: Audio data
            start_freq: Starting frequency in Hz
            end_freq: Ending frequency in Hz
            duration: Sweep duration in seconds

        Returns:
            Audio with sweep applied
        """
        try:
            from scipy.signal import chirp
        except ImportError:
            return audio

        n_samples = int(duration * self.sample_rate)
        t = np.linspace(0, duration, n_samples)
        
        sweep = chirp(t, start_freq, duration, end_freq, method="logarithmic")
        sweep = sweep * 0.3
        
        if len(audio) >= n_samples:
            audio = audio[:n_samples].copy()
            audio = audio * (1 + sweep)
        else:
            padded = np.zeros(n_samples)
            padded[:len(audio)] = audio
            audio = padded * (1 + sweep)

        return audio

    def parametric_eq(self, audio: np.ndarray, center_freq: float, 
                      gain_db: float, q: float = 1.0) -> np.ndarray:
        """
        Apply parametric EQ to specific frequency range.

        Args:
            audio: Audio data
            center_freq: Center frequency
            gain_db: Gain in dB
            q: Q factor

        Returns:
            Processed audio
        """
        band = EQBand(center_freq, gain_db, q, "peaking")
        return self._apply_filter(audio, band)
