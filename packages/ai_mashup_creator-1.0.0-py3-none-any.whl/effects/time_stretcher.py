"""Time stretcher module for tempo manipulation without pitch change."""

import numpy as np
from typing import Optional, Tuple, Dict, Any
from enum import Enum


class StretchMethod(Enum):
    """Time stretching methods."""
    PHASE_VOCODER = "phase_vocoder"
    WSOLA = "wsola"
    ELASTIQUE = "elastique"
    FFT = "fft"


class TimeStretcher:
    """Time stretching module for tempo manipulation without pitch change."""

    def __init__(self, sample_rate: int = 44100, method: str = "wsola"):
        """
        Initialize TimeStretcher.

        Args:
            sample_rate: Audio sample rate
            method: Stretching method
        """
        self.sample_rate = sample_rate
        self.method = StretchMethod(method)

    def stretch(self, audio: np.ndarray, ratio: float, 
                preserve_pitch: bool = True) -> np.ndarray:
        """
        Stretch audio by ratio.

        Args:
            audio: Audio data
            ratio: Stretch ratio (>1 = slower, <1 = faster)
            preserve_pitch: Whether to preserve original pitch

        Returns:
            Stretched audio
        """
        if ratio == 1.0:
            return audio

        if self.method == StretchMethod.PHASE_VOCODER:
            return self._stretch_phase_vocoder(audio, ratio, preserve_pitch)
        elif self.method == StretchMethod.WSOLA:
            return self._stretch_wSOLA(audio, ratio)
        elif self.method == StretchMethod.FFT:
            return self._stretch_fft(audio, ratio, preserve_pitch)
        else:
            return self._stretch_simple(audio, ratio)

    def _stretch_phase_vocoder(self, audio: np.ndarray, ratio: float, 
                               preserve_pitch: bool) -> np.ndarray:
        """Stretch using phase vocoder."""
        try:
            import librosa
        except ImportError:
            return self._stretch_simple(audio, ratio)

        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        if preserve_pitch:
            stretched = librosa.effects.time_stretch(audio, rate=1/ratio)
        else:
            stretched = librosa.effects.time_stretch(audio, rate=1/ratio)

        return stretched

    def _stretch_wSOLA(self, audio: np.ndarray, ratio: float) -> np.ndarray:
        """Stretch using WSOLA algorithm."""
        try:
            import pyworld as pw
        except ImportError:
            return self._stretch_phase_vocoder(audio, ratio, True)

        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0).astype(np.float64)

        f0, timeaxis = pw.dio(audio, self.sample_rate)
        f0 = pw.stonemask(audio, f0, timeaxis, self.sample_rate)
        
        spectrogram = pw.cheaptrick(audio, f0, timeaxis, self.sample_rate)
        
        stretched_len = int(len(audio) * ratio)
        stretched = pw.synthesize(spectrogram * ratio, f0, stretched_len, self.sample_rate)
        
        return stretched.astype(np.float32)

    def _stretch_fft(self, audio: np.ndarray, ratio: float, 
                     preserve_pitch: bool) -> np.ndarray:
        """Stretch using FFT-based method."""
        try:
            import scipy.signal as signal
            import librosa
        except ImportError:
            return self._stretch_simple(audio, ratio)

        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        n_fft = 2048
        hop_length = 512

        stft = librosa.stft(audio, n_fft=n_fft, hop_length=hop_length)
        magnitude = np.abs(stft)
        phase = np.angle(stft)

        new_length = int(magnitude.shape[1] * ratio)
        
        if preserve_pitch:
            freq_shift = 0
        else:
            freq_shift = (1 - ratio) / 2

        stretched_magnitude = signal.resample(magnitude, new_length, axis=1)
        
        stretched_stft = stretched_magnitude * np.exp(1j * phase[:, :new_length])
        
        stretched = librosa.istft(stretched_stft, hop_length=hop_length)
        
        return stretched

    def _stretch_simple(self, audio: np.ndarray, ratio: float) -> np.ndarray:
        """Simple linear interpolation stretch."""
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        original_length = len(audio)
        new_length = int(original_length * ratio)
        
        indices = np.linspace(0, original_length - 1, new_length)
        
        stretched = np.interp(indices, np.arange(original_length), audio)
        
        return stretched

    def match_tempo(self, source_audio: np.ndarray, source_bpm: float,
                    target_bpm: float) -> np.ndarray:
        """
        Match source tempo to target BPM.

        Args:
            source_audio: Source audio
            source_bpm: Source BPM
            target_bpm: Target BPM

        Returns:
            Tempo-matched audio
        """
        ratio = source_bpm / target_bpm
        return self.stretch(source_audio, ratio)

    def beat_sync(self, audio: np.ndarray, current_bpm: float,
                  target_bpm: float, beats: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Synchronize audio to target BPM at beat positions.

        Args:
            audio: Audio data
            current_bpm: Current BPM
            target_bpm: Target BPM
            beat_times: Beat timestamps

        Returns:
            Tuple of (synced_audio, new_beat_times)
        """
        ratio = current_bpm / target_bpm
        stretched = self.stretch(audio, ratio)
        
        new_beat_times = beats * ratio
        
        return stretched, new_beat_times

    def get_stretch_info(self, audio: np.ndarray, ratio: float) -> Dict[str, Any]:
        """
        Get information about stretch operation.

        Args:
            audio: Original audio
            ratio: Stretch ratio

        Returns:
            Dictionary with stretch info
        """
        original_duration = len(audio) / self.sample_rate
        new_duration = original_duration * ratio

        return {
            "original_duration": original_duration,
            "new_duration": new_duration,
            "ratio": ratio,
            "method": self.method.value,
            "original_samples": len(audio),
            "new_samples": int(len(audio) * ratio)
        }

    def warp_time(self, audio: np.ndarray, warp_curve: np.ndarray) -> np.ndarray:
        """
        Apply non-linear time warping.

        Args:
            audio: Audio data
            warp_curve: Time warp curve (0-1 range)

        Returns:
            Warped audio
        """
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        original_length = len(audio)
        new_length = len(warp_curve)
        
        warped_indices = warp_curve * (original_length - 1)
        warped = np.interp(warped_indices, np.arange(original_length), audio)
        
        return warped

    def elastic_time(self, audio: np.ndarray, start_ratio: float = 1.0,
                     end_ratio: float = 1.0, mid_point: float = 0.5) -> np.ndarray:
        """
        Apply elastic time stretching with variable rate.

        Args:
            audio: Audio data
            start_ratio: Initial stretch ratio
            end_ratio: Final stretch ratio
            mid_point: Position of transition (0-1)

        Returns:
            Elastically stretched audio
        """
        length = len(audio)
        
        warp_curve = np.zeros(length)
        for i in range(length):
            t = i / length
            if t < mid_point:
                warp_curve[i] = t * start_ratio / mid_point
            else:
                warp_curve[i] = start_ratio + (t - mid_point) * (end_ratio - start_ratio) / (1 - mid_point)
        
        return self.warp_time(audio, warp_curve)

    def auto_stretch(self, audio: np.ndarray, target_duration: float) -> np.ndarray:
        """
        Automatically stretch to target duration.

        Args:
            audio: Audio data
            target_duration: Target duration in seconds

        Returns:
            Stretched audio
        """
        current_duration = len(audio) / self.sample_rate
        ratio = target_duration / current_duration
        
        return self.stretch(audio, ratio)
