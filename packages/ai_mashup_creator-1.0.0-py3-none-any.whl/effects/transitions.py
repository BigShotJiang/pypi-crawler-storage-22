"""Transition effects module for smooth track mixing."""

import numpy as np
from typing import Optional, Callable, Tuple, List, Dict, Any
from enum import Enum
from dataclasses import dataclass


class TransitionCurve(Enum):
    """Crossfade curve types."""
    LINEAR = "linear"
    EXPONENTIAL = "exponential"
    LOGARITHMIC = "logarithmic"
    SIGMOID = "sigmoid"
    EQUAL_POWER = "equal_power"


class TransitionEffect(Enum):
    """Special transition effects."""
    NONE = "none"
    FILTER_SWEEP = "filter_sweep"
    REVERB = "reverb"
    DELAY = "delay"
    BITCRUSH = "bitcrush"
    FILTER_LPF = "low_pass_filter"
    FILTER_HPF = "high_pass_filter"


@dataclass
class TransitionParams:
    """Parameters for transition."""
    duration: float
    curve: TransitionCurve
    effect: TransitionEffect
    effect_params: Dict[str, Any]


class TransitionEngine:
    """Engine for creating various transition effects."""

    def __init__(self, sample_rate: int = 44100):
        """
        Initialize TransitionEngine.

        Args:
            sample_rate: Audio sample rate
        """
        self.sample_rate = sample_rate

    def crossfade(self, audio1: np.ndarray, audio2: np.ndarray,
                  position: float, duration: float,
                  curve: TransitionCurve = TransitionCurve.LINEAR) -> np.ndarray:
        """
        Create crossfade between two audio segments.

        Args:
            audio1: First audio
            audio2: Second audio
            position: Start position in seconds
            duration: Crossfade duration in seconds
            curve: Crossfade curve type

        Returns:
            Mixed audio
        """
        fade_samples = int(duration * self.sample_rate)
        
        if fade_samples == 0:
            return np.concatenate([audio1, audio2])

        fade_in = self._get_fade_curve(fade_samples, curve)
        fade_out = 1 - fade_in

        if len(audio1) < fade_samples or len(audio2) < fade_samples:
            audio1 = np.pad(audio1, (0, fade_samples), mode='constant')
            audio2 = np.pad(audio2, (0, fade_samples), mode='constant')

        fade_in = fade_in[:len(audio1)]
        fade_out = fade_out[:len(audio2)]

        result = audio1 * fade_in + audio2 * fade_out
        
        return result

    def _get_fade_curve(self, length: int, curve: TransitionCurve) -> np.ndarray:
        """Generate fade curve."""
        t = np.linspace(0, 1, length)
        
        if curve == TransitionCurve.LINEAR:
            return t
        elif curve == TransitionCurve.EXPONENTIAL:
            return t ** 2
        elif curve == TransitionCurve.LOGARITHMIC:
            return np.log1p(9 * t)
        elif curve == TransitionCurve.SIGMOID:
            return 1 / (1 + np.exp(-10 * (t - 0.5)))
        elif curve == TransitionCurve.EQUAL_POWER:
            return np.sin(t * np.pi / 2)
        else:
            return t

    def filter_sweep(self, audio: np.ndarray, start_freq: float,
                    end_freq: float, duration: float,
                    filter_type: str = "lowpass") -> np.ndarray:
        """
        Apply filter sweep transition.

        Args:
            audio: Audio data
            start_freq: Starting frequency
            end_freq: Ending frequency
            duration: Sweep duration
            filter_type: Filter type

        Returns:
            Processed audio
        """
        try:
            import scipy.signal as signal
            from scipy.signal import sosfilt
        except ImportError:
            return audio

        num_samples = int(duration * self.sample_rate)
        if num_samples > len(audio):
            num_samples = len(audio)

        freq_curve = np.linspace(start_freq, end_freq, num_samples)
        
        filtered = audio.copy()
        
        for i in range(num_samples - 1):
            sos = signal.butter(2, freq_curve[i] / (self.sample_rate / 2), 
                                btype=filter_type, output='sos')
            filtered[i] = sosfilt(sos, audio[i:i+2])[0] if i > 0 else filtered[i]
        
        return filtered[:num_samples]

    def reverb_transition(self, audio: np.ndarray, transition_point: float,
                          reverb_amount: float = 0.5) -> np.ndarray:
        """
        Add reverb at transition point.

        Args:
            audio: Audio data
            transition_point: Transition point in seconds
            reverb_amount: Reverb amount (0-1)

        Returns:
            Processed audio
        """
        try:
            import scipy.signal as signal
        except ImportError:
            return audio

        impulse_length = int(2 * self.sample_rate)
        impulse = np.random.randn(impulse_length) * 0.3
        impulse = signal.lfilter([1], [1, -0.5], impulse)
        
        point_samples = int(transition_point * self.sample_rate)
        
        wet = signal.fftconvolve(audio[:point_samples], impulse, mode='same')
        
        dry_wet_mix = reverb_amount
        result = audio.copy()
        result[:point_samples] = wet * dry_wet_mix + audio[:point_samples] * (1 - dry_wet_mix)
        
        return result

    def delay_transition(self, audio: np.ndarray, delay_time: float = 0.5,
                         feedback: float = 0.5, mix: float = 0.3) -> np.ndarray:
        """
        Apply delay effect at transition.

        Args:
            audio: Audio data
            delay_time: Delay time in seconds
            feedback: Feedback amount (0-1)
            mix: Wet/dry mix

        Returns:
            Processed audio
        """
        try:
            import scipy.signal as signal
        except ImportError:
            return audio

        delay_samples = int(delay_time * self.sample_rate)
        
        delayed = np.zeros_like(audio)
        delayed[delay_samples:] = audio[:-delay_samples]
        
        for i in range(1, 4):
            offset = delay_samples * i
            if offset < len(audio):
                delayed[offset:] += audio[:-offset] * (feedback ** i)
        
        return audio + delayed * mix

    def auto_transition(self, audio1: np.ndarray, audio2: np.ndarray,
                       transition_type: str, duration: float = 8.0) -> np.ndarray:
        """
        Apply automatic transition between tracks.

        Args:
            audio1: First track
            audio2: Second track
            transition_type: Type of transition
            duration: Transition duration

        Returns:
            Mixed audio with transition
        """
        if transition_type == "smooth":
            return self.crossfade(audio1, audio2, 0, duration, TransitionCurve.SIGMOID)
        elif transition_type == "cut":
            return self._hard_cut(audio1, audio2)
        elif transition_type == "echo":
            faded = self.crossfade(audio1, audio2, 0, duration * 0.5, TransitionCurve.LINEAR)
            return self.delay_transition(faded, 0.25, 0.4, 0.3)
        elif transition_type == "filter":
            return self.crossfade(audio1, audio2, 0, duration, TransitionCurve.EXPONENTIAL)
        elif transition_type == "reverb":
            return self.crossfade(audio1, audio2, 0, duration, TransitionCurve.EQUAL_POWER)
        else:
            return self.crossfade(audio1, audio2, 0, duration, TransitionCurve.LINEAR)

    def _hard_cut(self, audio1: np.ndarray, audio2: np.ndarray) -> np.ndarray:
        """Hard cut transition."""
        return np.concatenate([audio1, audio2])

    def build_transition(self, audio1: np.ndarray, audio2: np.ndarray,
                        params: TransitionParams) -> np.ndarray:
        """
        Build custom transition with parameters.

        Args:
            audio1: First audio
            audio2: Second audio
            params: Transition parameters

        Returns:
            Transitioned audio
        """
        base_transition = self.crossfade(audio1, audio2, 0, params.duration, params.curve)

        if params.effect == TransitionEffect.FILTER_SWEEP:
            effect_audio = self.filter_sweep(
                audio1[:int(params.duration * self.sample_rate)],
                params.effect_params.get("start_freq", 20000),
                params.effect_params.get("end_freq", 100),
                params.duration
            )
            base_transition = effect_audio + base_transition * 0.5

        elif params.effect == TransitionEffect.REVERB:
            base_transition = self.reverb_transition(
                base_transition,
                params.duration * 0.5,
                params.effect_params.get("amount", 0.5)
            )

        elif params.effect == TransitionEffect.DELAY:
            base_transition = self.delay_transition(
                base_transition,
                params.effect_params.get("delay_time", 0.5),
                params.effect_params.get("feedback", 0.5),
                params.effect_params.get("mix", 0.3)
            )

        return base_transition

    def eq_transition(self, audio1: np.ndarray, audio2: np.ndarray,
                     duration: float, high_pass_first: bool = True) -> np.ndarray:
        """
        EQ-based transition (high-pass first track, low-pass second).

        Args:
            audio1: First audio
            audio2: Second audio
            duration: Transition duration
            high_pass_first: Whether to high-pass first track

        Returns:
            Transitioned audio
        """
        try:
            from .equalizer import Equalizer
        except ImportError:
            return self.crossfade(audio1, audio2, 0, duration)

        eq = Equalizer(self.sample_rate)
        
        fade_samples = int(duration * self.sample_rate)
        
        if high_pass_first:
            eq.set_band(0, 0)
            eq.set_band(1, 0)
            eq.set_band(2, 0)
            eq.set_band(3, 0)
            eq.set_band(4, -12)
            eq.set_band(5, -6)
            audio1_eq = eq.apply(audio1)
            
            eq2 = Equalizer(self.sample_rate)
            for i in range(4, 10):
                eq2.set_band(i, -12)
            audio2_eq = eq2.apply(audio2)
        else:
            audio1_eq = audio1
            audio2_eq = audio2

        return self.crossfade(audio1_eq, audio2_eq, 0, duration, TransitionCurve.SIGMOID)
