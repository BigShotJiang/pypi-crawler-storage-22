"""Arrangement engine for creating mashup structures."""

import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class ArrangementType(Enum):
    """Types of mashup arrangements."""
    SEQUENTIAL = "sequential"
    INTERLEAVED = "interleaved"
    LAYERED = "layered"
    INTRO_OUTRO = "intro_outro"
    A_B_A = "a_b_a"
    VERSE_CHORUS = "verse_chorus"


@dataclass
class Segment:
    """Audio segment with metadata."""
    audio: np.ndarray
    source_name: str
    start_time: float = 0.0
    duration: float = 0.0
    gain: float = 1.0
    fade_in: float = 0.0
    fade_out: float = 0.0


@dataclass
class ArrangementSection:
    """Section in the arrangement."""
    name: str
    segments: List[Segment]
    start_time: float = 0.0
    duration: float = 0.0
    loop: bool = False


class ArrangementEngine:
    """Engine for arranging and structuring mashups."""

    def __init__(self, sample_rate: int = 44100):
        """
        Initialize ArrangementEngine.

        Args:
            sample_rate: Audio sample rate
        """
        self.sample_rate = sample_rate
        self.sections: List[ArrangementSection] = []
        self.global_offset: float = 0.0

    def create_mashup(self, tracks: Dict[str, np.ndarray], 
                     structure: List[Tuple[str, float, float]],
                     arrangement_type: ArrangementType = ArrangementType.SEQUENTIAL) -> np.ndarray:
        """
        Create mashup from tracks according to structure.

        Args:
            tracks: Dictionary of track_name -> audio
            structure: List of (section_name, start_time, duration)
            arrangement_type: Type of arrangement

        Returns:
            Final mashup audio
        """
        if arrangement_type == ArrangementType.SEQUENTIAL:
            return self._sequential_arrangement(tracks, structure)
        elif arrangement_type == ArrangementType.INTERLEAVED:
            return self._interleaved_arrangement(tracks, structure)
        elif arrangement_type == ArrangementType.LAYERED:
            return self._layered_arrangement(tracks, structure)
        elif arrangement_type == ArrangementType.INTRO_OUTRO:
            return self._intro_outro_arrangement(tracks, structure)
        elif arrangement_type == ArrangementType.A_B_A:
            return self._aba_arrangement(tracks, structure)
        else:
            return self._sequential_arrangement(tracks, structure)

    def _sequential_arrangement(self, tracks: Dict[str, np.ndarray],
                                structure: List[Tuple[str, float, float]]) -> np.ndarray:
        """Create sequential arrangement."""
        total_duration = sum(duration for _, _, duration in structure)
        total_samples = int(total_duration * self.sample_rate)
        
        result = np.zeros(total_samples)
        
        current_time = 0.0
        for track_name, start_offset, duration in structure:
            if track_name in tracks:
                track_audio = tracks[track_name]
                start_sample = int(current_time * self.sample_rate)
                end_sample = min(start_sample + int(duration * self.sample_rate), total_samples)
                
                segment = track_audio[:int(duration * self.sample_rate)]
                if len(segment) > 0:
                    result[start_sample:end_sample] += segment[:end_sample - start_sample]

            current_time += duration

        return result

    def _interleaved_arrangement(self, tracks: Dict[str, np.ndarray],
                                  structure: List[Tuple[str, float, float]]) -> np.ndarray:
        """Create interleaved arrangement (alternating segments)."""
        total_duration = sum(duration for _, _, duration in structure)
        total_samples = int(total_duration * self.sample_rate)
        
        result = np.zeros(total_samples)
        
        segment_duration = structure[0][2] if structure else 1.0
        
        for i, (track_name, start_offset, duration) in enumerate(structure):
            if track_name in tracks:
                track_audio = tracks[track_name]
                
                if i % 2 == 0:
                    start_sample = int(start_offset * self.sample_rate)
                else:
                    start_sample = int(start_offset * self.sample_rate) + int(segment_duration * 0.3 * self.sample_rate)
                
                end_sample = min(start_sample + int(duration * self.sample_rate), total_samples)
                
                segment = track_audio[:int(duration * self.sample_rate)]
                if len(segment) > 0:
                    result[start_sample:end_sample] += segment[:end_sample - start_sample]

        return result

    def _layered_arrangement(self, tracks: Dict[str, np.ndarray],
                             structure: List[Tuple[str, float, float]]) -> np.ndarray:
        """Create layered arrangement (multiple tracks playing together)."""
        total_duration = max(
            start_offset + duration 
            for _, start_offset, duration in structure
        )
        total_samples = int(total_duration * self.sample_rate)
        
        result = np.zeros(total_samples)
        
        for track_name, start_offset, duration in structure:
            if track_name in tracks:
                track_audio = tracks[track_name]
                start_sample = int(start_offset * self.sample_rate)
                end_sample = min(start_sample + int(duration * self.sample_rate), total_samples)
                
                segment = track_audio[:int(duration * self.sample_rate)]
                if len(segment) > 0:
                    segment = segment / max(1, len([t for t in structure if t[0] == track_name]))
                    result[start_sample:end_sample] += segment[:end_sample - start_sample]

        return result

    def _intro_outro_arrangement(self, tracks: Dict[str, np.ndarray],
                                 structure: List[Tuple[str, float, float]]) -> np.ndarray:
        """Create intro-outro style arrangement."""
        if len(tracks) < 2:
            return self._sequential_arrangement(tracks, structure)

        track_names = list(tracks.keys())
        intro_track = track_names[0]
        outro_track = track_names[-1]
        
        total_duration = sum(duration for _, _, duration in structure)
        total_samples = int(total_duration * self.sample_rate)
        
        result = np.zeros(total_samples)
        
        current_time = 0.0
        for i, (track_name, start_offset, duration) in enumerate(structure):
            if track_name in tracks:
                track_audio = tracks[track_name]
                start_sample = int(current_time * self.sample_rate)
                
                segment = track_audio[:int(duration * self.sample_rate)]
                
                if i == 0:
                    segment = self._apply_fade(segment, fade_in=0.5)
                elif i == len(structure) - 1:
                    segment = self._apply_fade(segment, fade_out=0.5)
                
                end_sample = start_sample + len(segment)
                if end_sample <= total_samples:
                    result[start_sample:end_sample] += segment

            current_time += duration

        return result

    def _aba_arrangement(self, tracks: Dict[str, np.ndarray],
                         structure: List[Tuple[str, float, float]]) -> np.ndarray:
        """Create A-B-A arrangement."""
        if len(tracks) < 2:
            return self._sequential_arrangement(tracks, structure)

        track_names = list(tracks.keys())
        a_track = track_names[0]
        b_track = track_names[1] if len(track_names) > 1 else track_names[0]
        
        structure = [
            (a_track, 0.0, structure[0][2] if structure else 10.0),
            (b_track, structure[0][2] if structure else 10.0, structure[1][2] if len(structure) > 1 else 10.0),
            (a_track, (structure[0][2] + structure[1][2]) if len(structure) > 1 else 20.0, structure[2][2] if len(structure) > 2 else 10.0),
        ]
        
        return self._sequential_arrangement(tracks, structure)

    def _apply_fade(self, audio: np.ndarray, fade_in: float = 0.0, 
                   fade_out: float = 0.0) -> np.ndarray:
        """Apply fade in/out to audio segment."""
        result = audio.copy()
        
        if fade_in > 0:
            fade_samples = int(fade_in * self.sample_rate)
            fade_curve = np.linspace(0, 1, fade_samples)
            result[:fade_samples] *= fade_curve
        
        if fade_out > 0:
            fade_samples = int(fade_out * self.sample_rate)
            fade_curve = np.linspace(1, 0, fade_samples)
            result[-fade_samples:] *= fade_curve
        
        return result

    def add_section(self, name: str, segments: List[Segment]) -> None:
        """Add a section to the arrangement."""
        duration = sum(s.duration for s in segments)
        section = ArrangementSection(
            name=name,
            segments=segments,
            duration=duration
        )
        self.sections.append(section)

    def get_arrangement_info(self) -> Dict[str, Any]:
        """Get arrangement information."""
        return {
            "num_sections": len(self.sections),
            "total_duration": sum(s.duration for s in self.sections),
            "sections": [
                {
                    "name": s.name,
                    "num_segments": len(s.segments),
                    "duration": s.duration
                }
                for s in self.sections
            ]
        }

    def optimize_transitions(self, mashup: np.ndarray, 
                            beat_times: List[np.ndarray]) -> np.ndarray:
        """
        Optimize transitions based on beat alignment.

        Args:
            mashup: Current mashup audio
            beat_times: List of beat time arrays for each track

        Returns:
            Optimized mashup
        """
        return mashup

    def auto_arrange(self, tracks: Dict[str, Dict[str, Any]],
                    target_duration: float = 180.0) -> List[Tuple[str, float, float]]:
        """
        Automatically create arrangement based on track analysis.

        Args:
            tracks: Dictionary of track info
            target_duration: Target total duration

        Returns:
            Arrangement structure
        """
        arrangement = []
        current_time = 0.0
        
        sorted_tracks = sorted(
            tracks.items(),
            key=lambda x: x[1].get("energy", 0.5),
            reverse=True
        )
        
        for track_name, track_info in sorted_tracks:
            track_duration = track_info.get("duration", 30.0)
            
            if current_time + track_duration > target_duration:
                track_duration = target_duration - current_time
            
            if track_duration <= 0:
                break
            
            arrangement.append((track_name, current_time, track_duration))
            current_time += track_duration
            
            if current_time >= target_duration:
                break

        return arrangement

    def create_verse_chorus(self, verse_tracks: List[str], chorus_tracks: List[str],
                           verse_duration: float = 32.0, 
                           chorus_duration: float = 16.0,
                           num_verses: int = 2,
                           num_choruses: int = 2) -> List[Tuple[str, float, float]]:
        """
        Create verse-chorus arrangement structure.

        Args:
            verse_tracks: Track names for verses
            chorus_tracks: Track names for choruses
            verse_duration: Duration of each verse in seconds
            chorus_duration: Duration of each chorus in seconds
            num_verses: Number of verses
            num_choruses: Number of choruses

        Returns:
            Arrangement structure
        """
        arrangement = []
        current_time = 0.0
        
        for i in range(num_verses):
            if i < len(verse_tracks):
                arrangement.append((verse_tracks[i], current_time, verse_duration))
                current_time += verse_duration
        
        for i in range(num_choruses):
            if i < len(chorus_tracks):
                arrangement.append((chorus_tracks[i], current_time, chorus_duration))
                current_time += chorus_duration

        return arrangement
