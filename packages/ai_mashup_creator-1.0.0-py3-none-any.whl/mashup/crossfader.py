"""Crossfader module for smooth audio transitions between tracks."""

import numpy as np
from typing import Optional, Callable, Tuple, List, Dict, Any
from dataclasses import dataclass
from enum import Enum


class FaderCurve(Enum):
    """Crossfader curve types."""
    LINEAR = "linear"
    S_CURVE = "s_curve"
    EQUAL_POWER = "equal_power"
    CONSTANT_POWER = "constant_power"


class CrossfadePattern(Enum):
    """Crossfade pattern types."""
    A_TO_B = "a_to_b"
    B_TO_A = "b_to_a"
    A_ONLY = "a_only"
    B_ONLY = "b_only"
    PARALLEL = "parallel"


@dataclass
class CrossfadeState:
    """Current state of crossfader."""
    position: float
    fade_a: float
    fade_b: float
    curve: FaderCurve


class Crossfader:
    """Crossfader for mixing between two audio sources."""

    def __init__(self, sample_rate: int = 44100):
        """
        Initialize Crossfader.

        Args:
            sample_rate: Audio sample rate
        """
        self.sample_rate = sample_rate
        self.position: float = 0.0
        self.curve: FaderCurve = FaderCurve.EQUAL_POWER
        self._audio_a: Optional[np.ndarray] = None
        self._audio_b: Optional[np.ndarray] = None

    def set_audio(self, audio_a: Optional[np.ndarray] = None,
                  audio_b: Optional[np.ndarray] = None) -> None:
        """
        Set audio sources for crossfader.

        Args:
            audio_a: First audio source
            audio_b: Second audio source
        """
        self._audio_a = audio_a
        self._audio_b = audio_b

    def set_position(self, position: float) -> None:
        """
        Set crossfader position.

        Args:
            position: Position from -1 (full A) to 1 (full B)
        """
        self.position = max(-1.0, min(1.0, position))

    def set_curve(self, curve: FaderCurve) -> None:
        """Set crossfader curve type."""
        self.curve = curve

    def get_fade_gains(self) -> Tuple[float, float]:
        """
        Calculate fade gains based on current position and curve.

        Returns:
            Tuple of (gain_a, gain_b)
        """
        p = (self.position + 1) / 2
        
        if self.curve == FaderCurve.LINEAR:
            fade_b = p
            fade_a = 1 - p
        elif self.curve == FaderCurve.S_CURVE:
            fade_b = 3 * p ** 2 - 2 * p ** 3
            fade_a = 1 - fade_b
        elif self.curve == FaderCurve.EQUAL_POWER:
            fade_b = np.sin(p * np.pi / 2)
            fade_a = np.cos(p * np.pi / 2)
        elif self.curve == FaderCurve.CONSTANT_POWER:
            fade_b = np.sqrt(max(0, p))
            fade_a = np.sqrt(max(0, 1 - p))
        else:
            fade_b = p
            fade_a = 1 - p

        return fade_a, fade_b

    def mix(self) -> np.ndarray:
        """
        Mix audio based on current crossfader position.

        Returns:
            Mixed audio
        """
        if self._audio_a is None and self._audio_b is None:
            return np.array([])

        max_length = 0
        if self._audio_a is not None:
            max_length = max(max_length, len(self._audio_a))
        if self._audio_b is not None:
            max_length = max(max_length, len(self._audio_b))

        if max_length == 0:
            return np.array([])

        gain_a, gain_b = self.get_fade_gains()

        mixed = np.zeros(max_length)

        if self._audio_a is not None:
            padded_a = self._pad_audio(self._audio_a, max_length)
            mixed += padded_a * gain_a

        if self._audio_b is not None:
            padded_b = self._pad_audio(self._audio_b, max_length)
            mixed += padded_b * gain_b

        return mixed

    def _pad_audio(self, audio: np.ndarray, target_length: int) -> np.ndarray:
        """Pad audio to target length."""
        if len(audio) >= target_length:
            return audio[:target_length]
        padded = np.zeros(target_length)
        padded[:len(audio)] = audio
        return padded

    def fade_to(self, target_position: float, duration: float,
                callback: Optional[Callable[[float], None]] = None) -> np.ndarray:
        """
        Perform automated fade to target position.

        Args:
            target_position: Target crossfader position
            duration: Fade duration in seconds
            callback: Optional callback for progress updates

        Returns:
            Mixed audio after fade
        """
        start_position = self.position
        num_samples = int(duration * self.sample_rate)
        
        result = np.zeros(0)
        
        for i in range(num_samples):
            progress = i / num_samples
            self.position = start_position + (target_position - start_position) * progress
            
            if callback:
                callback(self.position)
            
            if i % 1024 == 0:
                chunk = self.mix()
                result = np.concatenate([result, chunk]) if len(result) > 0 else chunk

        self.position = target_position
        final_chunk = self.mix()
        result = np.concatenate([result, final_chunk])

        return result

    def beat_crossfade(self, audio_a: np.ndarray, audio_b: np.ndarray,
                       beat_times_a: np.ndarray, beat_times_b: np.ndarray,
                       bpm: float, num_beats: int = 4) -> np.ndarray:
        """
        Perform crossfade aligned to beats.

        Args:
            audio_a: First audio
            audio_b: Second audio
            beat_times_a: Beat times for first audio
            beat_times_b: Beat times for second audio
            bpm: Target BPM
            num_beats: Number of beats for crossfade

        Returns:
            Crossfaded audio
        """
        beat_duration = 60.0 / bpm
        crossfade_duration = beat_duration * num_beats
        
        beat_interval = int(crossfade_duration * self.sample_rate)
        
        max_len = max(len(audio_a), len(audio_b)) + beat_interval
        result = np.zeros(max_len)
        
        start_section = audio_a[:beat_interval]
        result[:len(start_section)] += start_section * 0.7
        
        self._audio_a = audio_a[beat_interval:]
        self._audio_b = audio_b[:beat_interval]
        
        self.position = -1.0
        
        fade_samples = int(crossfade_duration * self.sample_rate)
        
        for i in range(fade_samples):
            progress = i / fade_samples
            fade_a, fade_b = self.get_fade_gains()
            
            idx_a = i if i < len(self._audio_a) else -1
            idx_b = i if i < len(self._audio_b) else -1
            
            if idx_a >= 0 and idx_b >= 0:
                result[beat_interval + i] = self._audio_a[idx_a] * fade_a + self._audio_b[idx_b] * fade_b
        
        self.position = 1.0
        
        remaining_a = self._audio_a[fade_samples:] if len(self._audio_a) > fade_samples else np.array([])
        remaining_b = self._audio_b[fade_samples:] if len(self._audio_b) > fade_samples else np.array([])
        
        offset = beat_interval + fade_samples
        
        for i, sample in enumerate(remaining_a):
            result[offset + i] += sample
        
        for i, sample in enumerate(remaining_b):
            result[offset + i] += sample * 0.3

        return result[:offset + max(len(remaining_a), len(remaining_b))]

    def eq_crossfade(self, audio_a: np.ndarray, audio_b: np.ndarray,
                     duration: float) -> np.ndarray:
        """
        Crossfade with EQ matching.

        Args:
            audio_a: First audio
            audio_b: Second audio
            duration: Crossfade duration in seconds

        Returns:
            Crossfaded audio
        """
        try:
            import scipy.signal as signal
        except ImportError:
            return self.mix()

        fade_samples = int(duration * self.sample_rate)
        
        sos_lp = signal.butter(2, 5000 / (self.sample_rate / 2), btype='low', output='sos')
        sos_hp = signal.butter(2, 5000 / (self.sample_rate / 2), btype='high', output='sos')

        audio_a_lp = signal.sosfilt(sos_lp, audio_a)
        audio_a_hp = signal.sosfilt(sos_hp, audio_a)
        
        audio_b_lp = signal.sosfilt(sos_lp, audio_b)
        audio_b_hp = signal.sosfilt(sos_hp, audio_b)

        self._audio_a = audio_a_lp
        self._audio_b = audio_b_lp

        mid_cross = self.mix()

        self._audio_a = audio_a_hp
        self._audio_b = audio_b_hp

        high_cross = self.mix()

        return mid_cross + high_cross

    def get_current_state(self) -> CrossfadeState:
        """Get current crossfader state."""
        fade_a, fade_b = self.get_fade_gains()
        return CrossfadeState(
            position=self.position,
            fade_a=fade_a,
            fade_b=fade_b,
            curve=self.curve
        )

    def reset(self) -> None:
        """Reset crossfader to default state."""
        self.position = 0.0
        self._audio_a = None
        self._audio_b = None
