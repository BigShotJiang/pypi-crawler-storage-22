"""Audio mixer module for combining multiple audio tracks."""

import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Track:
    """Represents a track in the mixer."""
    name: str
    audio: np.ndarray
    volume: float = 1.0
    pan: float = 0.0
    muted: bool = False
    solo: bool = False
    effects_chain: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class Mixer:
    """Multi-track audio mixer."""

    def __init__(self, sample_rate: int = 44100):
        """
        Initialize Mixer.

        Args:
            sample_rate: Audio sample rate
        """
        self.sample_rate = sample_rate
        self.tracks: List[Track] = []
        self.master_volume: float = 1.0

    def add_track(self, name: str, audio: np.ndarray, 
                  volume: float = 1.0, pan: float = 0.0) -> int:
        """
        Add a track to the mixer.

        Args:
            name: Track name
            audio: Audio data
            volume: Track volume (0-1)
            pan: Pan position (-1 to 1)

        Returns:
            Track index
        """
        track = Track(name=name, audio=audio, volume=volume, pan=pan)
        self.tracks.append(track)
        return len(self.tracks) - 1

    def remove_track(self, index: int) -> None:
        """Remove track by index."""
        if 0 <= index < len(self.tracks):
            self.tracks.pop(index)

    def set_volume(self, index: int, volume: float) -> None:
        """Set track volume."""
        if 0 <= index < len(self.tracks):
            self.tracks[index].volume = max(0.0, min(1.0, volume))

    def set_pan(self, index: int, pan: float) -> None:
        """Set track pan position."""
        if 0 <= index < len(self.tracks):
            self.tracks[index].pan = max(-1.0, min(1.0, pan))

    def set_mute(self, index: int, muted: bool) -> None:
        """Set track mute state."""
        if 0 <= index < len(self.tracks):
            self.tracks[index].muted = muted

    def set_solo(self, index: int, solo: bool) -> None:
        """Set track solo state."""
        if 0 <= index < len(self.tracks):
            self.tracks[index].solo = solo

    def mix(self, normalize: bool = True) -> np.ndarray:
        """
        Mix all tracks together.

        Args:
            normalize: Whether to normalize output

        Returns:
            Mixed audio
        """
        if not self.tracks:
            return np.array([])

        has_solo = any(track.solo for track in self.tracks)

        max_length = max(len(track.audio) for track in self.tracks if not track.muted)
        
        if has_solo:
            mixed = self._mix_with_solo(max_length)
        else:
            mixed = self._mix_all_tracks(max_length)

        mixed *= self.master_volume

        if normalize:
            peak = np.abs(mixed).max()
            if peak > 0:
                mixed = mixed / peak * 0.95

        return mixed

    def _mix_all_tracks(self, max_length: int) -> np.ndarray:
        """Mix all non-muted tracks."""
        mixed = np.zeros(max_length)

        for track in self.tracks:
            if track.muted:
                continue

            audio = track.audio
            
            if len(audio) < max_length:
                audio = np.pad(audio, (0, max_length - len(audio)))

            panned = self._apply_pan(audio, track.pan)
            mixed += panned * track.volume

        if len(self.tracks) > 0:
            mixed /= len([t for t in self.tracks if not t.muted])

        return mixed

    def _mix_with_solo(self, max_length: int) -> np.ndarray:
        """Mix only tracks with solo enabled."""
        mixed = np.zeros(max_length)
        solo_tracks = [t for t in self.tracks if t.solo]

        if not solo_tracks:
            return self._mix_all_tracks(max_length)

        for track in solo_tracks:
            audio = track.audio
            
            if len(audio) < max_length:
                audio = np.pad(audio, (0, max_length - len(audio)))

            panned = self._apply_pan(audio, track.pan)
            mixed += panned * track.volume

        mixed /= len(solo_tracks)

        return mixed

    def _apply_pan(self, audio: np.ndarray, pan: float) -> np.ndarray:
        """Apply panning to audio."""
        if len(audio.shape) == 1:
            left_gain = np.sqrt((1 - pan) / 2)
            right_gain = np.sqrt((1 + pan) / 2)
            stereo = np.zeros((2, len(audio)))
            stereo[0] = audio * left_gain
            stereo[1] = audio * right_gain
            return np.mean(stereo, axis=0)
        
        if audio.shape[0] == 2:
            left_gain = np.sqrt((1 - pan) / 2)
            right_gain = np.sqrt((1 + pan) / 2)
            stereo = np.zeros_like(audio)
            stereo[0] = audio[0] * left_gain
            stereo[1] = audio[1] * right_gain
            return stereo

        return audio

    def get_track_levels(self) -> Dict[str, float]:
        """Get current volume levels for all tracks."""
        levels = {}
        for i, track in enumerate(self.tracks):
            if len(track.audio) > 0 and not track.muted:
                rms = np.sqrt(np.mean(track.audio ** 2))
                levels[track.name] = float(rms * track.volume)
            else:
                levels[track.name] = 0.0
        return levels

    def fade_track(self, index: int, duration: float, 
                   target_volume: float) -> np.ndarray:
        """
        Fade track volume over duration.

        Args:
            index: Track index
            duration: Fade duration in seconds
            target_volume: Target volume

        Returns:
            New mixed audio
        """
        if 0 <= index < len(self.tracks):
            track = self.tracks[index]
            fade_samples = int(duration * self.sample_rate)
            fade_curve = np.linspace(track.volume, target_volume, fade_samples)
            
            if len(track.audio) >= fade_samples:
                faded_audio = track.audio.copy()
                faded_audio[:fade_samples] *= fade_curve
            else:
                faded_audio = track.audio.copy()
                
            original_audio = track.audio
            track.audio = faded_audio
            
            result = self.mix()
            
            track.audio = original_audio
            
            return result

        return self.mix()

    def duplicate_track(self, index: int, new_name: str) -> int:
        """Duplicate a track with new name."""
        if 0 <= index < len(self.tracks):
            original = self.tracks[index]
            return self.add_track(new_name, original.audio.copy(), original.volume, original.pan)
        return -1

    def clear(self) -> None:
        """Clear all tracks."""
        self.tracks.clear()

    def get_info(self) -> Dict[str, Any]:
        """Get mixer state information."""
        return {
            "num_tracks": len(self.tracks),
            "master_volume": self.master_volume,
            "tracks": [
                {
                    "name": t.name,
                    "volume": t.volume,
                    "pan": t.pan,
                    "muted": t.muted,
                    "solo": t.solo,
                    "duration": len(t.audio) / self.sample_rate
                }
                for t in self.tracks
            ]
        }
