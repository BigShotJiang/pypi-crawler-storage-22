"""File handler module for audio file operations."""

import os
import json
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple, Union
import numpy as np


class FileHandler:
    """Handler for audio file operations."""

    SUPPORTED_FORMATS = [".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aiff"]
    EXPORT_FORMATS = [".wav", ".mp3", ".flac", ".ogg"]

    def __init__(self, default_sample_rate: int = 44100, default_bit_depth: int = 16):
        """
        Initialize FileHandler.

        Args:
            default_sample_rate: Default sample rate
            default_bit_depth: Default bit depth
        """
        self.default_sample_rate = default_sample_rate
        self.default_bit_depth = default_bit_depth

    def load(self, file_path: str, sample_rate: Optional[int] = None) -> Tuple[np.ndarray, int]:
        """
        Load audio file.

        Args:
            file_path: Path to audio file
            sample_rate: Target sample rate (None = original)

        Returns:
            Tuple of (audio_data, sample_rate)
        """
        if sample_rate is None:
            sample_rate = self.default_sample_rate

        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if path.suffix.lower() not in self.SUPPORTED_FORMATS:
            raise ValueError(f"Unsupported format: {path.suffix}")

        try:
            import librosa
        except ImportError:
            raise ImportError("librosa is required for audio loading")

        audio, sr = librosa.load(file_path, sr=sample_rate, mono=False)
        
        return audio, sr

    def save(self, audio: np.ndarray, file_path: str, 
             sample_rate: Optional[int] = None,
             format: Optional[str] = None) -> None:
        """
        Save audio to file.

        Args:
            audio: Audio data
            file_path: Output file path
            sample_rate: Sample rate (None = default)
            format: Audio format (None = from extension)
        """
        if sample_rate is None:
            sample_rate = self.default_sample_rate

        path = Path(file_path)
        
        path.parent.mkdir(parents=True, exist_ok=True)

        if format is None:
            format = path.suffix.lower()
        
        try:
            import soundfile as sf
        except ImportError:
            raise ImportError("soundfile is required for audio saving")

        if len(audio.shape) > 1 and audio.shape[0] == 2:
            sf.write(file_path, audio.T, sample_rate, format=format.replace(".", "").upper())
        else:
            if len(audio.shape) > 1:
                audio = np.mean(audio, axis=0)
            sf.write(file_path, audio, sample_rate, format=format.replace(".", "").upper())

    def batch_load(self, file_paths: List[str], 
                   sample_rate: Optional[int] = None) -> Dict[str, Tuple[np.ndarray, int]]:
        """
        Load multiple audio files.

        Args:
            file_paths: List of file paths
            sample_rate: Target sample rate

        Returns:
            Dictionary mapping file paths to (audio, sample_rate)
        """
        results = {}
        
        for path in file_paths:
            try:
                audio, sr = self.load(path, sample_rate)
                results[path] = (audio, sr)
            except Exception as e:
                print(f"Error loading {path}: {e}")

        return results

    def batch_save(self, audio_dict: Dict[str, np.ndarray], 
                   output_dir: str,
                   sample_rate: Optional[int] = None,
                   prefix: str = "") -> List[str]:
        """
        Save multiple audio files.

        Args:
            audio_dict: Dictionary of name -> audio
            output_dir: Output directory
            sample_rate: Sample rate
            prefix: Filename prefix

        Returns:
            List of saved file paths
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        saved_files = []
        
        for name, audio in audio_dict.items():
            filename = f"{prefix}{name}.wav"
            file_path = output_path / filename
            self.save(audio, str(file_path), sample_rate)
            saved_files.append(str(file_path))

        return saved_files

    def get_file_info(self, file_path: str) -> Dict[str, Any]:
        """
        Get audio file metadata.

        Args:
            file_path: Path to audio file

        Returns:
            Dictionary with file information
        """
        path = Path(file_path)
        
        if not path.exists():
            return {}

        info = {
            "path": str(path),
            "name": path.name,
            "extension": path.suffix,
            "size_bytes": path.stat().st_size,
        }

        try:
            import mutagen
            audio = mutagen.File(file_path)
            if audio:
                info["duration"] = audio.info.length
                info["sample_rate"] = audio.info.sample_rate
                info["channels"] = audio.info.channels
                info["bitrate"] = getattr(audio.info, "bitrate", None)
        except ImportError:
            try:
                import librosa
                audio, sr = librosa.load(file_path, sr=None)
                info["duration"] = len(audio) / sr
                info["sample_rate"] = sr
                info["channels"] = 1 if len(audio.shape) == 1 else audio.shape[0]
            except:
                pass

        return info

    def list_audio_files(self, directory: str, 
                        recursive: bool = False) -> List[str]:
        """
        List audio files in directory.

        Args:
            directory: Directory to search
            recursive: Whether to search recursively

        Returns:
            List of audio file paths
        """
        path = Path(directory)
        
        if not path.exists() or not path.is_dir():
            return []

        audio_files = []
        
        if recursive:
            for ext in self.SUPPORTED_FORMATS:
                audio_files.extend(path.rglob(f"*{ext}"))
        else:
            for ext in self.SUPPORTED_FORMATS:
                audio_files.extend(path.glob(f"*{ext}"))

        return [str(f) for f in audio_files]

    def create_project(self, name: str, base_dir: str) -> Dict[str, str]:
        """
        Create project directory structure.

        Args:
            name: Project name
            base_dir: Base directory

        Returns:
            Dictionary of created paths
        """
        project_dir = Path(base_dir) / name
        
        dirs = {
            "project": str(project_dir),
            "tracks": str(project_dir / "tracks"),
            "stems": str(project_dir / "stems"),
            "output": str(project_dir / "output"),
            "analysis": str(project_dir / "analysis"),
        }

        for dir_path in dirs.values():
            Path(dir_path).mkdir(parents=True, exist_ok=True)

        return dirs

    def export_analysis(self, analysis_data: Dict[str, Any], 
                       output_path: str) -> None:
        """
        Export analysis data to JSON.

        Args:
            analysis_data: Analysis results
            output_path: Output JSON file path
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(analysis_data, f, indent=2, ensure_ascii=False)

    def import_analysis(self, file_path: str) -> Dict[str, Any]:
        """
        Import analysis data from JSON.

        Args:
            file_path: JSON file path

        Returns:
            Analysis data
        """
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def convert_format(self, input_path: str, output_path: str,
                     output_format: str) -> None:
        """
        Convert audio file format.

        Args:
            input_path: Input file path
            output_path: Output file path
            output_format: Target format
        """
        audio, sr = self.load(input_path)
        self.save(audio, output_path, sr, format=output_format)

    def normalize_path(self, file_path: str) -> str:
        """
        Normalize file path.

        Args:
            file_path: File path

        Returns:
            Normalized path
        """
        return str(Path(file_path).resolve())
