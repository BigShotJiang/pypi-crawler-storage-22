"""Visualization module for audio analysis and mashup visualization."""

import numpy as np
from typing import Optional, List, Tuple, Dict, Any, Callable
from pathlib import Path
import json


class Visualizer:
    """Visualizer for audio analysis and mashup results."""

    def __init__(self, sample_rate: int = 44100):
        """
        Initialize Visualizer.

        Args:
            sample_rate: Audio sample rate
        """
        self.sample_rate = sample_rate

    def generate_waveform_data(self, audio: np.ndarray, 
                               num_points: int = 1000) -> List[float]:
        """
        Generate waveform visualization data.

        Args:
            audio: Audio data
            num_points: Number of data points

        Returns:
            List of waveform amplitude values
        """
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        if len(audio) <= num_points:
            return audio.tolist()

        segment_size = len(audio) // num_points
        waveform = []

        for i in range(num_points):
            start = i * segment_size
            end = start + segment_size
            segment = audio[start:end]
            max_val = np.max(np.abs(segment))
            waveform.append(float(max_val))

        return waveform

    def generate_spectrogram_data(self, audio: np.ndarray, 
                                  n_fft: int = 2048,
                                  hop_length: int = 512) -> Dict[str, Any]:
        """
        Generate spectrogram data for visualization.

        Args:
            audio: Audio data
            n_fft: FFT size
            hop_length: Hop length

        Returns:
            Dictionary with spectrogram data
        """
        try:
            import librosa
        except ImportError:
            return {}

        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        stft = librosa.stft(audio, n_fft=n_fft, hop_length=hop_length)
        magnitude = np.abs(stft)
        db_scale = librosa.amplitude_to_db(magnitude, ref=np.max)

        freqs = librosa.fft_frequencies(sr=self.sample_rate, n_fft=n_fft)
        times = librosa.frames_to_time(np.arange(db_scale.shape[1]), 
                                       sr=self.sample_rate, 
                                       hop_length=hop_length)

        height, width = db_scale.shape
        step_x = max(1, width // 100)
        step_y = max(1, height // 50)

        compressed = db_scale[::step_y, ::step_x].tolist()

        return {
            "spectrogram": compressed,
            "frequencies": freqs[::step_y].tolist(),
            "times": times[::step_x].tolist(),
            "min_db": float(np.min(db_scale)),
            "max_db": float(np.max(db_scale))
        }

    def generate_beat_grid_data(self, beat_times: np.ndarray,
                                duration: float) -> List[Dict[str, float]]:
        """
        Generate beat grid visualization data.

        Args:
            beat_times: Beat timestamps
            duration: Total duration

        Returns:
            List of beat positions
        """
        return [{"time": float(t), "position": float(t / duration)} 
                for t in beat_times if t <= duration]

    def generate_key_timeline(self, key_changes: List[Tuple[float, str, str]],
                             duration: float) -> List[Dict[str, Any]]:
        """
        Generate key timeline visualization data.

        Args:
            key_changes: List of (time, key, mode) tuples
            duration: Total duration

        Returns:
            Key timeline data
        """
        timeline = []
        for time, key, mode in key_changes:
            if time <= duration:
                timeline.append({
                    "time": float(time),
                    "key": key,
                    "mode": mode,
                    "position": float(time / duration)
                })
        return timeline

    def generate_energy_envelope(self, audio: np.ndarray,
                                num_points: int = 200) -> List[float]:
        """
        Generate energy envelope for visualization.

        Args:
            audio: Audio data
            num_points: Number of data points

        Returns:
            Energy values
        """
        try:
            import librosa
        except ImportError:
            return []

        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        hop_length = len(audio) // num_points
        rms = librosa.feature.rms(y=audio, hop_length=hop_length)[0]

        return [float(v) for v in rms[:num_points]]

    def generate_mashup_structure(self, tracks: List[Dict[str, Any]],
                                  arrangement: List[Tuple[str, float, float]]) -> Dict[str, Any]:
        """
        Generate mashup structure visualization.

        Args:
            tracks: Track information
            arrangement: Arrangement structure

        Returns:
            Structure visualization data
        """
        total_duration = sum(d for _, _, d in arrangement)
        
        sections = []
        colors = ["#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7", "#DDA0DD"]
        
        for i, (track_name, start_time, duration) in enumerate(arrangement):
            sections.append({
                "id": i,
                "track": track_name,
                "start": float(start_time),
                "duration": float(duration),
                "end": float(start_time + duration),
                "position_start": float(start_time / total_duration),
                "position_end": float((start_time + duration) / total_duration),
                "color": colors[i % len(colors)]
            })

        return {
            "total_duration": float(total_duration),
            "sections": sections,
            "num_tracks": len(tracks)
        }

    def generate_transition_markers(self, transitions: List[Dict[str, Any]],
                                   duration: float) -> List[Dict[str, Any]]:
        """
        Generate transition markers for visualization.

        Args:
            transitions: Transition information
            duration: Total duration

        Returns:
            Transition markers
        """
        markers = []
        
        for i, trans in enumerate(transitions):
            markers.append({
                "id": i,
                "time": float(trans.get("time", 0)),
                "position": float(trans.get("time", 0) / duration),
                "type": trans.get("type", "unknown"),
                "confidence": float(trans.get("confidence", 0)),
                "style": trans.get("style", "default")
            })

        return markers

    def create_html_report(self, output_path: str,
                          mashup_data: Dict[str, Any]) -> None:
        """
        Create HTML visualization report.

        Args:
            output_path: Output HTML file path
            mashup_data: Mashup data to visualize
        """
        html = self._generate_html_template(mashup_data)
        
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

    def _generate_html_template(self, data: Dict[str, Any]) -> str:
        """Generate HTML template for visualization."""
        waveform_json = json.dumps(data.get("waveform", []))
        structure_json = json.dumps(data.get("structure", {}))
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>AI Mashup Visualization</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #1a1a2e; color: #eee; }}
        h1 {{ color: #4ECDC4; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .section {{ background: #16213e; padding: 20px; margin: 20px 0; border-radius: 10px; }}
        .waveform {{ width: 100%; height: 150px; background: #0f3460; border-radius: 5px; }}
        .structure {{ min-height: 100px; display: flex; align-items: center; }}
        .track-segment {{ height: 60px; display: inline-block; border-radius: 3px; margin: 2px; }}
        .info {{ color: #aaa; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>AI Mashup Visualization</h1>
        
        <div class="section">
            <h2>Waveform</h2>
            <canvas id="waveform" class="waveform"></canvas>
        </div>
        
        <div class="section">
            <h2>Track Structure</h2>
            <div id="structure" class="structure"></div>
        </div>
        
        <div class="section">
            <h2>Information</h2>
            <p class="info">Duration: {data.get("duration", 0):.2f}s</p>
            <p class="info">Tracks: {data.get("num_tracks", 0)}</p>
        </div>
    </div>
    
    <script>
        const waveformData = {waveform_json};
        const structureData = {structure_json};
        
        function drawWaveform() {{
            const canvas = document.getElementById('waveform');
            const ctx = canvas.getContext('2d');
            const width = canvas.width = canvas.offsetWidth;
            const height = canvas.height;
            
            ctx.fillStyle = '#0f3460';
            ctx.fillRect(0, 0, width, height);
            
            ctx.strokeStyle = '#4ECDC4';
            ctx.lineWidth = 1;
            ctx.beginPath();
            
            for (let i = 0; i < waveformData.length; i++) {{
                const x = (i / waveformData.length) * width;
                const y = height / 2 - waveformData[i] * height / 2;
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }}
            ctx.stroke();
        }}
        
        function drawStructure() {{
            const container = document.getElementById('structure');
            const sections = structureData.sections || [];
            
            sections.forEach(section => {{
                const el = document.createElement('div');
                el.className = 'track-segment';
                el.style.width = (section.position_end - section.position_start) * 100 + '%';
                el.style.backgroundColor = section.color;
                el.title = section.track;
                container.appendChild(el);
            }});
        }}
        
        window.onload = function() {{
            drawWaveform();
            drawStructure();
        }};
    </script>
</body>
</html>"""
        return html

    def generate_json_report(self, output_path: str,
                            analysis_data: Dict[str, Any]) -> None:
        """
        Generate JSON report.

        Args:
            output_path: Output JSON file path
            analysis_data: Analysis data
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(analysis_data, f, indent=2, ensure_ascii=False)

    def generate_analysis_summary(self, audio: np.ndarray,
                                  beat_info: Optional[Dict[str, Any]] = None,
                                  key_info: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Generate comprehensive analysis summary.

        Args:
            audio: Audio data
            beat_info: Beat detection results
            key_info: Key detection results

        Returns:
            Analysis summary
        """
        duration = len(audio[0] if len(audio.shape) > 1 else audio) / self.sample_rate
        
        summary = {
            "duration": float(duration),
            "sample_rate": self.sample_rate,
            "channels": 2 if len(audio.shape) > 1 else 1,
            "waveform": self.generate_waveform_data(audio),
            "energy": self.generate_energy_envelope(audio),
        }

        if beat_info:
            summary["beat_grid"] = self.generate_beat_grid_data(
                beat_info.get("beat_times", np.array([])),
                duration
            )
            summary["bpm"] = beat_info.get("bpm", 0)

        if key_info:
            summary["key"] = key_info.get("key", "unknown")
            summary["mode"] = key_info.get("mode", "unknown")
            summary["camelot"] = key_info.get("camelot_code", "")

        return summary
