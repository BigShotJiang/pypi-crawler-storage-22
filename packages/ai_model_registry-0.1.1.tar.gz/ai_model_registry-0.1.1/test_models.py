"""Test script to print model IDs for providers."""

from ai_model_registry import get_latest, get_providers, get_models, get_model

def test_get_latest():
    """Test getting the latest model ID for each provider."""
    print("=" * 60)
    print("Testing get_latest() - Recommended model for each provider")
    print("=" * 60)
    
    try:
        providers = get_providers()
        print(f"\nFound {len(providers)} providers: {', '.join(providers)}\n")
        
        for provider in providers:
            try:
                model_id = get_latest(provider)
                print(f"✓ {provider:12} → {model_id}")
            except Exception as e:
                print(f"✗ {provider:12} → Error: {e}")
    except Exception as e:
        print(f"Error getting providers: {e}")


def test_get_models_by_provider():
    """Test getting all models for a specific provider."""
    print("\n" + "=" * 60)
    print("Testing get_models() - All models for OpenAI")
    print("=" * 60)
    
    try:
        result = get_models(provider="openai")
        if "models" in result:
            print(f"\nFound {len(result['models'])} OpenAI models:\n")
            for model in result["models"]:
                status = model.get("status", "unknown")
                model_id = model.get("model_id", "unknown")
                print(f"  {status:10} {model_id}")
        else:
            print(result)
    except Exception as e:
        print(f"Error: {e}")


def test_get_specific_model():
    """Test getting details for a specific model."""
    print("\n" + "=" * 60)
    print("Testing get_model() - Specific model details")
    print("=" * 60)
    
    try:
        # Get the latest Anthropic model and then get its details
        model_id = get_latest("anthropic")
        print(f"\nGetting details for: anthropic/{model_id}\n")
        
        model = get_model("anthropic", model_id)
        for key, value in model.items():
            print(f"  {key:15} : {value}")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    print("\n🔍 AI Model Registry - Test Suite\n")
    
    # Run tests
    test_get_latest()
    test_get_models_by_provider()
    test_get_specific_model()
    
    print("\n" + "=" * 60)
    print("✅ Testing complete!")
    print("=" * 60 + "\n")
