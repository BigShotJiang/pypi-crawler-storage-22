import os
import time
from typing import Any, Optional

import httpx
from dotenv import load_dotenv

from src.utils.logging import log_dec

load_dotenv()

BASE_URL = os.getenv("MPCDF_BASE_URL")
API_KEY = os.getenv("MPCDF_API_KEY")
MODEL_NAME = "center-for-humans-and-machines/assembl_nk_1"


@log_dec
def mpcdf_vllm_request(
    prompt: str,
    model: Optional[str] = None,
    max_tokens: int = 150,
    temperature: float = 0.7,
    timeout: float = 30.0,
    max_retries: int = 3,
    initial_backoff: float = 1.0,
    **kwargs: Any,
) -> str:
    """Make request to vLLM model with tokenized input.

    Uses the /v1/completions endpoint which supports prompt_token_ids
    directly, bypassing the tokenizer. This function tokenizes the prompt
    and sends it as token IDs.

    Args:
        prompt: Text prompt string to send to the model.
        model: Model name (defaults to MODEL_NAME).
        max_tokens: Maximum tokens to generate.
        temperature: Sampling temperature.
        timeout: Request timeout in seconds.
        max_retries: Maximum number of retry attempts (default: 3).
        initial_backoff: Initial backoff delay in seconds (default: 1.0).
        **kwargs: Additional parameters for completion request.

    Returns:
        Generated text content.
    """
    # Build request URL - ensure /v1 prefix if not present
    base = BASE_URL.rstrip("/")
    if not base.endswith("/v1"):
        base = f"{base}/v1"
    url = f"{base}/completions"

    # Prepare payload - use prompt_token_ids for completions endpoint
    payload = {
        "model": model or MODEL_NAME,
        "prompt": prompt,
        "max_tokens": max_tokens,
        "temperature": temperature,
        **kwargs,
    }

    # Make HTTP request
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }

    last_exception = None
    for attempt in range(max_retries + 1):
        try:
            with httpx.Client(timeout=timeout) as http_client:
                response = http_client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                result = response.json()

            # Completions endpoint returns text directly
            return result["choices"][0]["text"]
        except (
            httpx.HTTPStatusError,
            httpx.RequestError,
            httpx.TimeoutException,
            httpx.NetworkError,
        ) as e:
            last_exception = e
            if attempt < max_retries:
                backoff = initial_backoff * (2**attempt)
                time.sleep(backoff)
                continue
            raise

    # This should never be reached, but type checker needs it
    if last_exception:
        raise last_exception
    raise RuntimeError("Request failed unexpectedly")
