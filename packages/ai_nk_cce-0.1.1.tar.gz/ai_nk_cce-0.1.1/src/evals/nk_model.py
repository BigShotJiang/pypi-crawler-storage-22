"""
NK Model evaluation functions for analyzing fitness landscapes.

This module provides functions to evaluate statistical properties of NK
fitness landscapes, including payoff distributions and peak prominence
analysis.
"""

from collections import Counter
from typing import Dict, Tuple

import numpy as np
import pandas as pd

from src.nk_model.nk_landscape import NKLandscape


def calculate_payoff_distribution(
    landscape: NKLandscape, bins: int = 50
) -> pd.DataFrame:
    """
    Calculate the average payoff distribution for an NK fitness landscape.

    Args:
        landscape: NKLandscape instance to analyze
        bins: Number of bins for the histogram (default: 50)

    Returns:
        pd.DataFrame with columns ['bin_center', 'frequency', 'bin_edges_left',
        'bin_edges_right'] suitable for plotting
    """
    # Extract payoffs from all items in the landscape
    payoffs = [item.payoff for item in landscape.items]

    # Calculate histogram
    hist, bin_edges = np.histogram(payoffs, bins=bins, range=(0, 1))

    # Calculate bin centers for plotting
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

    # Create DataFrame for easy plotting
    return pd.DataFrame(
        {
            "bin_center": bin_centers,
            "frequency": hist,
            "bin_edges_left": bin_edges[:-1],
            "bin_edges_right": bin_edges[1:],
        }
    )


def calculate_peaks_prominence(landscape: NKLandscape) -> pd.DataFrame:
    """
    Calculate peaks and their prominence distribution in NK landscape.

    Prominence is defined as the minimum Hamming distance to reach a
    higher payoff. A prominence of n+1 indicates a global peak.

    This elegant implementation uses vectorized operations for better
    performance and readability.

    Args:
        landscape: NKLandscape instance to analyze

    Returns:
        pd.DataFrame with columns ['prominence', 'count', 'proportion',
        'coordinates'] where prominence ranges from 1 to n+1, and coordinates
        contains lists of coordinate tuples for points at each prominence level
    """
    n = landscape.params.n
    items = landscape.items
    total_items = len(items)

    # Convert all coordinates and payoffs to numpy arrays for vectorization
    coords = np.array(
        [item.coordinates for item in items]
    )  # Shape: (total_items, n)
    payoffs = np.array(
        [item.payoff for item in items]
    )  # Shape: (total_items,)

    # Calculate prominence for each point using vectorized operations
    prominence_values = np.full(
        total_items, n + 1, dtype=int
    )  # Start with global peak assumption

    # For each Hamming distance from 1 to n
    for distance in range(1, n + 1):
        # Find items that haven't found a higher payoff yet
        unresolved_mask = prominence_values == n + 1
        unresolved_indices = np.where(unresolved_mask)[0]

        if len(unresolved_indices) == 0:
            break  # All items have found their prominence

        # For unresolved items, check if any other item is at this distance
        # with higher payoff
        for i in unresolved_indices:
            current_coords = coords[i]
            current_payoff = payoffs[i]

            # Calculate Hamming distances to all other points
            hamming_distances = np.sum(coords != current_coords, axis=1)

            # Find items at exactly this distance with higher payoff
            at_distance_mask = hamming_distances == distance
            higher_payoff_mask = payoffs > current_payoff
            found_higher = np.any(at_distance_mask & higher_payoff_mask)

            if found_higher:
                prominence_values[i] = distance

    # Create DataFrame with all prominence levels (1 to n+1) and collect
    # coordinates
    prominence_range = np.arange(1, n + 2)
    results = []

    for prom_val in prominence_range:
        mask = prominence_values == prom_val
        count = np.sum(mask)
        proportion = count / total_items

        # Collect coordinates for this prominence level
        coords_at_prominence = [tuple(coords[i]) for i in np.where(mask)[0]]

        results.append(
            {
                "prominence": prom_val,
                "count": count,
                "proportion": proportion,
                "coordinates": coords_at_prominence,
            }
        )

    df = pd.DataFrame(results)

    # Add summary statistics as metadata
    peak_mask = df["prominence"] >= 2  # Prominence >= 2 indicates peaks
    df.attrs["peak_count"] = df.loc[peak_mask, "count"].sum()
    df.attrs["peak_proportion"] = df.loc[peak_mask, "proportion"].sum()
    df.attrs["global_peaks"] = df.loc[df["prominence"] == n + 1, "count"].iloc[
        0
    ]

    return df


def _hill_climb_to_maximum(
    start_coords: np.ndarray, landscape: NKLandscape
) -> Tuple[np.ndarray, float]:
    """
    Perform hill-climbing from a starting point to find the local maximum
    it reaches.

    Args:
        start_coords: Starting coordinates
        landscape: NKLandscape instance

    Returns:
        Tuple of (final_coordinates, final_payoff) of the local maximum reached
    """
    current_coords = start_coords.copy()
    current_payoff = landscape.get_payoff(current_coords)

    improved = True
    while improved:
        improved = False
        best_coords = current_coords.copy()
        best_payoff = current_payoff

        # Check all neighbors at Hamming distance 1
        for i in range(len(current_coords)):
            neighbor_coords = current_coords.copy()
            neighbor_coords[i] = 1 - neighbor_coords[i]  # Flip bit
            neighbor_payoff = landscape.get_payoff(neighbor_coords)

            if neighbor_payoff > best_payoff:
                best_coords = neighbor_coords.copy()
                best_payoff = neighbor_payoff
                improved = True

        if improved:
            current_coords = best_coords
            current_payoff = best_payoff

    return current_coords, current_payoff


def calculate_basin_analysis(landscape: NKLandscape) -> pd.DataFrame:
    """
    Analyze basins of attraction for all local maxima in the NK landscape.

    This implements a simplified basin analysis: for each point in the
    landscape, hill-climb to find which local maximum it reaches, then count
    unique destinations.

    Args:
        landscape: NKLandscape instance to analyze

    Returns:
        pd.DataFrame with columns:
        - 'coordinates': tuple of coordinates for each local maximum
        - 'payoff': payoff value of the local maximum
        - 'basin_size': number of points in the basin of attraction
        - 'is_global_max': boolean indicating if this is a global maximum
    """
    # Collect all destinations from hill-climbing
    destinations = []
    for item in landscape.items:
        final_coords, final_payoff = _hill_climb_to_maximum(
            item.coordinates, landscape
        )
        destinations.append((tuple(final_coords), final_payoff))

    # Count unique destinations (basin sizes)
    basin_counts = Counter(dest[0] for dest in destinations)

    # Get payoffs for each unique destination
    payoff_map = {dest[0]: dest[1] for dest in destinations}

    # Find global maximum payoff
    global_max_payoff = max(payoff_map.values())

    # Create results
    results = []
    for coords_tuple, basin_size in basin_counts.items():
        results.append(
            {
                "coordinates": coords_tuple,
                "payoff": payoff_map[coords_tuple],
                "basin_size": basin_size,
                "is_global_max": payoff_map[coords_tuple] == global_max_payoff,
            }
        )

    df = pd.DataFrame(results)

    # Sort by payoff (descending) for better readability
    df = df.sort_values("payoff", ascending=False).reset_index(drop=True)

    # Add summary statistics as metadata
    df.attrs["total_local_maxima"] = len(df)
    df.attrs["total_points"] = len(landscape.items)
    df.attrs["global_maxima_count"] = df["is_global_max"].sum()
    df.attrs["average_basin_size"] = df["basin_size"].mean()

    return df


def evaluate_nk_landscape(
    landscape: NKLandscape, bins: int = 50, include_basins: bool = False
) -> Dict[str, pd.DataFrame]:
    """
    Comprehensive evaluation of an NK fitness landscape.

    Args:
        landscape: NKLandscape instance to analyze
        bins: Number of bins for payoff distribution histogram
        include_basins: If True, include basin analysis (computationally
            expensive)

    Returns:
        Dict containing:
        - 'payoff_distribution': DataFrame with payoff distribution
        - 'peaks_prominence': DataFrame with peaks and prominence analysis
        - 'basin_analysis': DataFrame with basin analysis
            (if include_basins=True)
    """
    results = {
        "payoff_distribution": calculate_payoff_distribution(landscape, bins),
        "peaks_prominence": calculate_peaks_prominence(landscape),
    }

    if include_basins:
        results["basin_analysis"] = calculate_basin_analysis(landscape)

    return results
