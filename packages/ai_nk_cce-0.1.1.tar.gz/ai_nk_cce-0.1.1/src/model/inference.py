import argparse

from datasets import load_from_disk

from src.model.config import InferenceConfig
from src.model.nk_assistant import NKAssistant
from src.utils.utils import load_config_from_yaml


def run_inference(config: InferenceConfig):
    # Load dataset and model
    ds = load_from_disk(config.dataset_file)

    # Load model and tokenizer
    ass = NKAssistant.from_pretrained(config.model_path)

    if config.generation_params:
        ass.generation_params = config.generation_params

    # Process each split
    result_ds = ds
    for split in config.splits:
        if split in ds:
            print(f"Processing {split} split...")
            if config.max_test_samples:
                print(f"Processing {config.max_test_samples} test samples...")
                ds[split] = ds[split].select(range(config.max_test_samples))
            result_ds[split] = ds[split].map(ass.suggest_from_row)

    # Save the dataset with suggestions
    result_ds.save_to_disk(config.output_dataset_file)
    print(f"Dataset with suggestions saved to {config.output_dataset_file}")


if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(
        description="Run inference with a fine-tuned model."
    )
    parser.add_argument(
        "--config", type=str, required=True, help="Path to YAML config file"
    )
    args = parser.parse_args()

    # Load config from YAML file
    config = load_config_from_yaml(args.config, InferenceConfig)

    # Run inference
    run_inference(config)

    print("Inference completed successfully.")
