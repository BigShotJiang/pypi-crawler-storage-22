import json
from pathlib import Path
from typing import List, Optional, Union

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from src.api.mpcdf_vllm import mpcdf_vllm_request
from src.model.config import NKAssistantConfig, TrainConfig
from src.model.parser import create_context, create_target, target_to_int


def load_model_and_tokenizer(model_path: str):
    """Load the model and tokenizer from the given path"""
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path)
    except Exception:
        # Fix if tokenizer is not found
        tokenizer = AutoTokenizer.from_pretrained("gpt2")
    model = AutoModelForCausalLM.from_pretrained(model_path)

    # Ensure pad_token is set
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Move model to GPU if available
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    return model, tokenizer, device


class NKAssistant:
    def __init__(
        self, config: NKAssistantConfig, metadata: Optional[TrainConfig] = None
    ):
        if not config.use_mpcdf_vllm:
            model, tokenizer, device = load_model_and_tokenizer(
                config.model_path
            )
        else:
            model = None
            tokenizer = None
            device = None
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.config = config
        self.metadata = metadata
        self.generation_params = config.generation_params

    def _save_pretrained(self, save_directory: Path) -> None:
        save_directory.mkdir(parents=True, exist_ok=True)
        self.model.save_pretrained(save_directory)
        self.tokenizer.save_pretrained(save_directory)
        if self.metadata:
            with open(save_directory / "metadata.json", "w") as f:
                json.dump(self.metadata.model_dump(), f)

    @classmethod
    def from_pretrained(
        cls, pretrained_model_name_or_path: Union[str, Path], **kwargs
    ):
        # Use Hugging Face logic to locate the local or remote files
        model_path = Path(pretrained_model_name_or_path)

        if not model_path.exists():
            # Download files from Hub into cache
            from huggingface_hub import snapshot_download

            model_path = Path(
                snapshot_download(repo_id=pretrained_model_name_or_path)
            )

        metadata_path = model_path / "metadata.json"
        metadata = None
        if metadata_path.exists():
            with open(metadata_path) as f:
                metadata = TrainConfig(**json.load(f))

        config = metadata.assistant_config
        config.model_path = str(model_path)

        return cls(config=config, metadata=metadata)

    @staticmethod
    def create_text_from_row(row, include_payoff=True, include_target=True):
        sample_payoff = np.array(row["payoffs"])[row["sample_idx"]]

        context = create_context(
            n=row["n"],
            k=row["k"],
            power_scale=row["power_scale"],
            sample_idxs=row["sample_idx"],
            origin_idx=row["origin_idx"],
            hamming_distance=row["hamming_distance"],
            payoff=sample_payoff,
            include_payoff=include_payoff,
        )
        if include_target:
            target = create_target(target_idx=row["target_idx"])
            return {"context": context, "target": target}
        return {"context": context}

    @staticmethod
    def create_prompt_for_rl_from_row(row):
        sample_payoff = np.array(row["payoffs"])[row["sample_idx"]]
        context = create_context(
            n=row["n"],
            k=row["k"],
            power_scale=row["power_scale"],
            sample_idxs=row["sample_idx"],
            origin_idx=row["origin_idx"],
            hamming_distance=row["hamming_distance"],
            payoff=sample_payoff,
            include_payoff=True,
        )
        return {"prompt": context}

    def suggest_target_from_context(
        self, context: str, target_length: int
    ) -> str:
        # Tokenize input
        input_ids = self.tokenizer.encode(context, return_tensors="pt").to(
            self.device
        )
        n_input = input_ids.shape[1]

        # Generate output
        with torch.no_grad():
            output = self.model.generate(
                input_ids,
                max_length=n_input + target_length,
                pad_token_id=self.tokenizer.eos_token_id,
                **self.generation_params,
            )

        # Decode only the new tokens (exclude the input tokens)
        suggestion = self.tokenizer.decode(
            output[0, n_input:], skip_special_tokens=True
        )

        return suggestion

    def suggest_from_row(self, row):
        context = self.create_text_from_row(row, include_target=False)[
            "context"
        ]
        n = row["n"]
        target_length = n * 2 - 1
        if self.config.use_mpcdf_vllm:
            binary_string = mpcdf_vllm_request(
                prompt=context,
                max_tokens=target_length,
                **self.generation_params,
            )
        else:
            binary_string = self.suggest_target_from_context(
                context, target_length
            )
        return {"suggestion": binary_string}

    def suggest(
        self,
        n: int,
        k: int,
        power_scale: float,
        hamming_distance: int,
        sample_idxs: List[int],
        origin_idx: int,
        payoffs: List[float],
    ) -> int:
        # Create context from input data
        context = create_context(
            n=n,
            k=k,
            power_scale=power_scale,
            sample_idxs=sample_idxs,
            origin_idx=origin_idx,
            hamming_distance=hamming_distance,
            payoff=payoffs,
        )

        # Set max suggestion length based on n
        target_length = (
            n * 2 - 1
        )  # Length needed for binary string with commas

        if self.config.use_mpcdf_vllm:
            binary_string = mpcdf_vllm_request(
                prompt=context,
                max_tokens=target_length,
                **self.generation_params,
            )
        else:
            binary_string = self.suggest_target_from_context(
                context, target_length
            )

        # Parse the suggestion to an integer
        try:
            suggestion_int = target_to_int(binary_string)
            return suggestion_int
        except Exception as e:
            print(f"Error parsing suggestion '{binary_string}': {e}")
            return -1
