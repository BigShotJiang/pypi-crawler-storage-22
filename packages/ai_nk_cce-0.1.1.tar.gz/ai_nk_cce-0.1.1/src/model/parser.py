import logging
from typing import List, Optional, Union

from src.utils.binary_conversion import binary_str_to_int, int_to_binary_str

logger = logging.getLogger()


def create_context(
    *,
    n: int,
    k: int,
    power_scale: float,
    sample_idxs: List[int],
    origin_idx: int,
    hamming_distance: int,
    payoff: Optional[List[Union[float, int]]] = None,
    include_payoff=True,
    **kwargs,
) -> str:
    # Header
    doc = ""
    doc += f"n: {n}\n"
    doc += f"k: {k}\n"
    doc += f"p: {power_scale:.2f}\n"
    doc += f"h: {hamming_distance}\n"
    doc += "\n"
    # Sample rows
    if include_payoff:
        assert (
            payoff is not None
        ), "Payoff values must be provided when include_payoff is True"
        doc += "sample,payoff\n"
        doc += "\n".join(
            [
                f"{int_to_binary_str(idx)},{p}"
                for idx, p in zip(sample_idxs, payoff)
            ]
        )
    else:
        doc += "sample\n"
        doc += "\n".join([int_to_binary_str(idx) for idx in sample_idxs])
    doc += "\n"
    doc += "\n"
    # Constraints
    doc += "user\n"
    doc += int_to_binary_str(origin_idx) + "\n"
    doc += "\n"
    # Target
    doc += "assistant\n"
    return doc


def create_target(*, target_idx: int) -> str:
    """
    Create a target string from a target index.
    """
    return int_to_binary_str(target_idx)


def target_to_int(target):
    """Convert target string to integer (deprecated, use binary_str_to_int)."""
    int_target = binary_str_to_int(target)
    logger.debug(f"target: {target}, int_target: {int_target}")
    return int_target


def eval_target(target, ranks):
    target_idx = binary_str_to_int(target)
    return ranks[target_idx]
