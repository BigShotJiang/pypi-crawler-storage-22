import json
from pathlib import Path
from typing import Any, Dict, Literal, Optional

import numpy as np

from src.nk_model.models import Item, NKLandscapeCache, NKParams


class LandscapeCache:
    """
    A file-based cache for NKLandscape objects.

    This class handles saving and loading landscape data to/from disk
    using Pydantic models for simplified serialization.
    The cache is stored in JSON format in the data directory.
    """

    def __init__(
        self,
        cache_dir: str = "data/landscape_cache",
        cache_type: Literal["memory", "disk", "none"] = "memory",
    ):
        """
        Initialize the landscape cache.

        Args:
            cache_dir: Directory to store the cache files
            cache_type: Type of caching to use:
                - "none": No caching
                - "memory": Only in-memory caching
                - "disk": Both memory and disk caching (default)
        """
        self.cache_type = cache_type

        # Set the cache file path
        self.cache_file = Path(cache_dir) / "landscape_cache.json"
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)

        # Load existing cache
        self._cache: Dict[str, Dict[str, Any]] = self.load_from_disk()

    def load_from_disk(self) -> Dict[str, Dict[str, Any]]:
        """
        Load the landscape cache from disk, if it exists.

        Returns:
            A dictionary mapping landscape UUIDs to their cached data
            or an empty dict in certain cases.
        """
        if self.cache_type == "none" or not self.cache_file.exists():
            return {}
        with open(self.cache_file, "r") as f:
            return json.load(f)

    def get(self, uuid: str) -> Optional[NKLandscapeCache]:
        """
        Get a landscape from the cache.

        Args:
            uuid: The UUID of the landscape to retrieve

        Returns:
            NKLandscapeCache instance or None if not found
        """
        if uuid not in self._cache:
            return None

        cached_data = self._cache[uuid]

        # Try loading as new format first
        try:
            return NKLandscapeCache(
                params=NKParams(**cached_data["params"]),
                items=[
                    Item(
                        coordinates=np.array(item["coordinates"]),
                        payoff=item["payoff"],
                    )
                    for item in cached_data["items"]
                ],
            )
        except (KeyError, TypeError, ValueError):
            # Fall back to legacy format if new format fails
            return self._load_legacy_cache(cached_data)

    def save(self, uuid: str, data: NKLandscapeCache) -> None:
        """
        Save a landscape to the cache.

        Args:
            uuid: The UUID of the landscape
            data: NKLandscapeCache instance to cache
        """
        if self.cache_type == "none":
            return

        # Serialize using Pydantic model
        data_dict = json.loads(data.model_dump_json())

        # Save to in-memory cache
        self._cache[uuid] = data_dict

        # Save to disk if cache_type is "disk"
        if self.cache_type == "disk":
            with open(self.cache_file, "w") as f:
                json.dump(self._cache, f)

    def clear(self) -> None:
        """Clear the entire cache."""
        if self.cache_type == "none":
            return

        self._cache = {}
        if self.cache_type == "disk" and self.cache_file.exists():
            self.cache_file.unlink()

    def _load_legacy_cache(
        self, cached_data: Dict[str, Any]
    ) -> NKLandscapeCache:
        """
        Load cache data from legacy format.

        Args:
            cached_data: Dictionary containing legacy cache data

        Returns:
            NKLandscapeCache instance reconstructed from legacy format
        """
        # Extract params from old format
        # Default to float for legacy cache (was the original behavior)
        params = NKParams(
            n=cached_data.get("nk_param_n", 0),
            k=cached_data.get("nk_param_k", 0),
            m=cached_data.get("nk_param_m", 0),
            power=cached_data.get("payoff_scaling", 1.0),
            max_val=cached_data.get("value_format", 1.0),
            neighborhood=cached_data.get("neighborhood_method"),
            convolution=cached_data.get("convolution_method"),
            payoff_type="float",
        )
        items = [
            Item(
                coordinates=np.array(item["coordinates"]),
                payoff=item["payoff"],
            )
            for item in cached_data["items"]
        ]
        return NKLandscapeCache(params=params, items=items)
