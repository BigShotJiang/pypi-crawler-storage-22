import numpy as np
from tqdm.auto import tqdm

from src.nk_model.models import NKParams
from src.nk_model.nk_landscape import NKLandscape
from src.simulation.hill_climber_simulation import (
    AgentType,
    HillClimberSimConfig,
    HillClimberSimulation,
    StopCondition,
)


def hill_climber_vs_ai_simulation(
    config: HillClimberSimConfig,
    landscape: NKLandscape,
):
    if config.agent_start_idx is None:
        config.agent_start_idx = np.random.choice(config.start_idxs)

    if config.agent_type == AgentType.HILL_CLIMBER:
        hill_climber_config = config
        ai_config = config.model_copy(
            update={"agent_type": AgentType.AI_HILL_CLIMBER}
        )
    elif config.agent_type == AgentType.AI_HILL_CLIMBER:
        ai_config = config
        hill_climber_config = config.model_copy(
            update={"agent_type": AgentType.HILL_CLIMBER}
        )

    hill_climber_simulation = HillClimberSimulation.from_cached_landscape(
        config=hill_climber_config, landscape_uuid=landscape.uuid
    )
    ai_simulation = HillClimberSimulation.from_cached_landscape(
        config=ai_config, landscape_uuid=landscape.uuid
    )

    hill_climber_trajectory = hill_climber_simulation.run()
    ai_trajectory = ai_simulation.run()

    return hill_climber_trajectory, ai_trajectory


def compare_hill_climber_vs_ai(
    nk_params: NKParams,
    hamming_distance: int,
    max_iterations: int,
    repetitions: int,
    n_start_idxs: int = 1,
):
    hill_climber_payoff_trajectories = []
    ai_payoff_trajectories = []
    for _ in tqdm(range(repetitions), desc="Comparing hill climber vs AI"):
        start_idxs = [
            np.random.choice(list(range(2**nk_params.n)))
            for _ in range(n_start_idxs)
        ]
        start_idx = np.random.choice(start_idxs)

        config = HillClimberSimConfig(
            nk_params=nk_params,
            agent_type=AgentType.HILL_CLIMBER,
            start_idxs=start_idxs,
            agent_start_idx=start_idx,
            use_trajectory=True,
            stop_condition=StopCondition.MAX_ITERATIONS,
            stop_condition_kwargs={"max_iterations": max_iterations},
            hamming_distance=hamming_distance,
        )
        landscape = NKLandscape(params=nk_params)
        payoff_list = landscape.get_ordered_payoffs()

        hill_climber_trajectory, ai_trajectory = hill_climber_vs_ai_simulation(
            config, landscape
        )

        hill_climber_payoff_traj = [
            payoff_list[idx] for idx in hill_climber_trajectory
        ]
        ai_payoff_traj = [payoff_list[idx] for idx in ai_trajectory]

        hill_climber_payoff_trajectories.append(hill_climber_payoff_traj)
        ai_payoff_trajectories.append(ai_payoff_traj)

    return hill_climber_payoff_trajectories, ai_payoff_trajectories


def average_payoff_trajectories(
    payoff_trajectories: list[list[float]],
) -> list[float]:
    """Transform list of payoff trajectories into list of averaged payoffs.

    Args:
        payoff_trajectories: List of payoff trajectories, where each
            trajectory is a list of payoffs.

    Returns:
        List of averaged payoffs at each step position.
    """
    if not payoff_trajectories:
        return []

    max_len = max(len(traj) for traj in payoff_trajectories)
    averaged = []

    for step_idx in range(max_len):
        step_payoffs = [
            traj[step_idx]
            for traj in payoff_trajectories
            if step_idx < len(traj)
        ]
        averaged.append(np.mean(step_payoffs))

    return averaged


def average_last_payoff(payoff_trajectories: list[list[float]]) -> float:
    """Return the average of the last payoff in each trajectory.

    Args:
        payoff_trajectories: List of payoff trajectories, where each
            trajectory is a list of payoffs.

    Returns:
        Average of the last payoff across all trajectories.
    """
    if not payoff_trajectories:
        return 0.0

    last_payoffs = [traj[-1] for traj in payoff_trajectories if traj]
    return np.mean(last_payoffs)
