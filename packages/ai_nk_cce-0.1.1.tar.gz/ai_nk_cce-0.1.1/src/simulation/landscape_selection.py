"""Utilities for finding and selecting average performing landscapes."""

import json
from datetime import datetime
from pathlib import Path
from typing import List, Tuple

import numpy as np
from tqdm import tqdm

from src.nk_model.models import NKParams
from src.nk_model.nk_landscape import NKLandscape
from src.simulation.hill_climber_simulation import (
    AgentType,
    HillClimberSimConfig,
    HillClimberSimulation,
    StopCondition,
)


def run_simulation_with_landscape(
    landscape_uuid: str,
    nk_params: NKParams,
    hamming_distance: int,
    max_iterations: int,
) -> float:
    """Run simulation on a specific landscape and return final payoff.

    Args:
        landscape_uuid: UUID of the cached landscape
        nk_params: NK model parameters
        hamming_distance: Hamming distance for neighbor selection
        max_iterations: Maximum number of iterations
        start_idxs: List of starting indices

    Returns:
        Final payoff from the simulation
    """

    start_idxs = np.random.choice(list(range(2**nk_params.n)), 1)

    config = HillClimberSimConfig(
        nk_params=nk_params,
        agent_type=AgentType.HILL_CLIMBER,
        start_idxs=start_idxs,
        stop_condition=StopCondition.MAX_ITERATIONS,
        stop_condition_kwargs={"max_iterations": max_iterations},
        hamming_distance=hamming_distance,
    )

    simulation = HillClimberSimulation.from_cached_landscape(
        config=config, landscape_uuid=landscape_uuid
    )
    trajectory = simulation.run()

    final_idx = trajectory[-1]
    final_payoff = simulation.ordered_payoffs[final_idx]

    return final_payoff


def select_average_landscape(
    results: List[Tuple[str, float]],
    percentile_low: float = 25.0,
    percentile_high: float = 75.0,
) -> str:
    """Select an average landscape from tested results.

    Args:
        results: List of tuples (landscape_uuid, average_payoff)
        percentile_low: Lower percentile threshold (default: 25.0)
        percentile_high: Upper percentile threshold (default: 75.0)

    Returns:
        UUID of the selected landscape
    """
    # Sort by average payoff
    results.sort(key=lambda x: x[1])

    # Select from percentile range
    start_idx = int((percentile_low / 100.0) * len(results))
    end_idx = int((percentile_high / 100.0) * len(results))
    candidates = results[start_idx:end_idx]

    # Randomly select one landscape
    selected_idx = np.random.choice(range(len(candidates)))
    return candidates[selected_idx][0]


def find_average_landscape_for_k(
    nk_params: NKParams,
    num_landscapes: int = 100,
    repetitions: int = 100,
    hamming_distance: int = 1,
    max_iterations: int = 10,
) -> str:
    """Find an average landscape for a specific k value.

    Args:
        nk_params: NK model parameters
        num_landscapes: Number of landscapes to generate and test
        repetitions: Number of repetitions per landscape
        hamming_distance: Hamming distance for neighbor selection
        max_iterations: Maximum number of iterations

    Returns:
        UUID of the selected average landscape
    """

    # Generate landscapes
    landscape_uuids = [
        NKLandscape(params=nk_params).uuid for _ in range(num_landscapes)
    ]

    # Test landscapes and collect results
    results = []
    for uuid in tqdm(landscape_uuids, desc="Testing landscapes"):
        final_payoffs = []
        for _ in range(repetitions):
            payoff = run_simulation_with_landscape(
                landscape_uuid=uuid,
                nk_params=nk_params,
                hamming_distance=hamming_distance,
                max_iterations=max_iterations,
            )
            final_payoffs.append(payoff)
        avg_payoff = np.mean(final_payoffs)
        results.append((uuid, avg_payoff))

    # Select average landscape
    selected_uuid = select_average_landscape(results)

    return selected_uuid


def save_landscape_json(
    landscape_uuid: str,
    output_path: Path,
    n: int,
    k: int,
    add_timestamp: bool = True,
) -> Path:
    """Save a landscape to disk as JSON.

    Args:
        landscape_uuid: UUID of the landscape to save
        output_path: Path where to save the JSON file
        n: Number of components
        k: Number of interactions
        add_timestamp: Whether to add timestamp to filename

    Returns:
        Path to the saved file (with timestamp if added)
    """
    landscape = NKLandscape.from_cache(landscape_uuid)
    json_data = []
    nk_str = f"({n}, {k})"

    for item in landscape.items:
        location = "".join([str(int(coord)) for coord in item.coordinates])
        fitness = int(item.payoff)

        json_data.append(
            {"N_NK": nk_str, "location": location, "fitness": fitness}
        )

    # Add timestamp to filename if requested
    if add_timestamp:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = output_path.stem
        suffix = output_path.suffix
        output_path = output_path.parent / f"{stem}_{timestamp}{suffix}"

    output_path.parent.mkdir(parents=True, exist_ok=True)
    print(f"Saving landscape to {output_path}")
    with open(output_path, "w") as f:
        json.dump(json_data, f, indent=4)

    return output_path
