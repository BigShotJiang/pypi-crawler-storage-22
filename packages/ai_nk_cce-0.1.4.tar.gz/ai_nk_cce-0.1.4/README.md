# human-ai-social-learning

[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black) [![PEP8](https://img.shields.io/badge/code%20style-pep8-orange.svg)](https://www.python.org/dev/peps/pep-0008/)

## Description

## Installation

This project uses Poetry for package management. If you haven't installed Poetry yet, please follow the instructions on the [official Poetry website](https://python-poetry.org/docs/#installation).

To install the project:

1. Clone the repository:

   ```bash
   git clone https://github.com/your-username/human-ai-social-learning.git
   cd human-ai-social-learning
   ```

2. Install dependencies with Poetry:

   ```bash
   poetry install
   ```

3. Activate the virtual environment:

   ```bash
   poetry shell
   ```

4. (Optional) Set up Jupyter kernel for notebooks:

   ```bash
   poetry run python -m ipykernel install --user --name nk-cce-kernel
   ```

Now your development environment is set up and ready to use.

## Contributing

We welcome contributions! Please note:

1. Please create a descriptive branch for each contribution (naming convention *feature_type/feature_name*)
2. Follow the project style (PEP 8 for Python).
3. Add tests and run all before commit. (At least one test per function or method.)
4. Write meaningful commit messages.
5. Keep in line with pre-commit linting.
6. Submit a Pull Request, to include your code into main.

### Pre-commit Hooks

We use pre-commit hooks. Installation:

```bash
poetry add pre-commit
pre-commit install
pre-commit run --all-files
```

### Running Tests

Tests need to be run in the virtual environment. You can use Poetry or Visual Studio Code settings to do so automatically.

To run all tests using Poetry run:

```bash
poetry run pytest
```

We included Visual Studio Code settings in the repository.
You can try to use them to run the tests within Visual Studio Code.

```text
.vscode/
├── settings.json
├── launch.json
```

## Documentation

For an overview of the repository structure, module organization, and
dependencies, see the [Repository Structure Guide](doc/repository_structure.md).

Additional documentation is available in the `doc/` directory:

- [How to compare hill climber vs AI](doc/how_to_compare_hill_climber_vs_ai.md)
- [How to find average hill climber landscape](doc/how_to_find_average_hill_climber_landscape.md)
- [Using MPCDF LLM inference](doc/use_mpcdf_llm_inference.md)
