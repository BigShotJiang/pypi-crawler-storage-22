
# Debug

## Create Dataset

```
python src/model/dataset.py --config src/model/config/dataset_debug.yml
```

# Train Model

```
python src/model/train.py --config src/model/config/train_debug.yml
```

# Train Model on Cluster

```
python src/model/run_slurm.py --config_file src/model/config/train_debug.yml --group_name debug --job_name debug --n_gpu 1 --time 00:10:00 --ds debug_1000
```

## Evaluate Model

```
python src/model/run_slurm.py --script src/model/inference.py --config_file src/model/config/inference.yml --group_name debug --job_name debug --ds debug_1000 --n_gpu 1 --model gpt2_debug_1000
```

# Train RL Model on Cluster

python src/model/run_slurm.py --template  src/model/scripts/template_rl.slurm --config_file src/model/config/train_grpo_debug.yml --image /u/lumi/projects/llm-strategic-tuning/images/ai_nk_rl.sif --group_name debug --job_name rl_debug --n_gpu 1 --lr 1e-5 --time 00:10:00 --ds v5_xxl_3.0

# Train RL Model with vLLM on Cluster

python src/model/run_slurm.py --template  src/model/scripts/template_rl.slurm --config_file src/model/config/train_grpo_debug_vllm.yml --image /u/lumi/projects/llm-strategic-tuning/images/ai_nk_trl_vllm.sif --group_name debug --job_name rl_debug --n_gpu 1 --lr 1e-5 --time 00:10:00 --ds v5_xxl_3.0

# Actual Run

## Create Dataset

```
python src/model/dataset.py --config src/model/config/dataset.yml
```

## Train Model

```
python src/model/run_slurm.py --config_file src/model/config/train.yml --group_name gpt2_v4 --job_name 5e-5 --n_gpu 4 --lr 1e-5 --ds v4 --time 04:00:00
```

## Evaluate Model

```
python src/model/run_slurm.py --script src/model/inference.py --config_file src/model/config/inference.yml  --n_gpu 1 --group_name gpt2_v4 --job_name 5e-5 --ds v4 --train_job_id 2025_04_08__13_11_40 --time 01:30:00
```

# Train RL Model on Cluster

python src/model/run_slurm.py --template  src/model/scripts/template_rl.slurm --config_file src/model/config/train_grpo.yml --image /u/lumi/projects/llm-strategic-tuning/images/ai_nk_rl.sif --group_name gpt2_v6 --job_name rl --n_gpu 4 --lr 1e-5 --time 24:00:00 --ds v5_xxl_3.0

## Push Model

```
huggingface-cli upload center-for-humans-and-machines/nk-1 models/gpt2_v4/5e-5/2025_03_25__10_09_45
```
