from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field


class ParserConfig(BaseModel):
    include_payoff: bool = True


class NKAssistantConfig(BaseModel):
    parser_config: ParserConfig
    use_mpcdf_vllm: bool = False
    model_path: Optional[str] = None
    generation_params: Optional[Dict[str, Any]] = None


class TrainConfig(BaseModel):
    trainer_args: Any
    dataset_file: str = Field(..., description="The path to the dataset file")
    final_model_path: str = Field(
        ..., description="The path to save the final model"
    )
    assistant_config: NKAssistantConfig


class InferenceConfig(BaseModel):
    dataset_file: str = Field(..., description="The path to the dataset file")
    model_path: str = Field(
        ..., description="The path to the fine-tuned model"
    )
    output_dataset_file: str = Field(
        ..., description="The path to save the dataset with suggestions"
    )
    generation_params: Optional[Dict[str, Any]] = Field(
        default=None, description="Generation parameters"
    )
    splits: List[str] = Field(
        default=["train", "test"], description="Dataset splits to process"
    )
    max_test_samples: Optional[int] = Field(
        default=None, description="Maximum number of test samples to process"
    )


class DataSetConfig(BaseModel):
    input_file: str
    output_file: str
    samples_per_landscapes: int = 1
    constraints_range: Tuple[int, int] = (0, 8)
    n_samples: List[int] = [8]
    include_payoff: bool = True
    test_ratio: float = 0.1
    exp_ratio: float = 0.1
    debug_size: Optional[int] = None
