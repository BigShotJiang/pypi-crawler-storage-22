import argparse
import os
import re

# import shutil
import subprocess
import sys
from datetime import datetime

# from collections import OrderedDict
import yaml


def generate_local_job_id():
    """
    Generates a local job ID based on timestamp.
    """
    return datetime.now().strftime("%Y_%m_%d__%H_%M_%S")


def parse_unknown_args(unknown_args, argv):
    # Process unknown arguments to create a dictionary
    dynamic_args = {}
    for arg in unknown_args:
        if arg.startswith("--"):
            key = arg.lstrip("-")
            # Assuming the next item in the list is the value
            if argv.index(arg) + 1 < len(argv):
                value = argv[argv.index(arg) + 1]
                dynamic_args[key] = value

    return dynamic_args


def define_output(args):
    # Compute additional arguments
    if args["output_dir"] is None:
        args["output_dir"] = os.path.join(
            "experiments",
            args["group_name"],
            args["job_name"],
            args["job_id"],
        )
    if not os.path.exists(args["output_dir"]):
        os.makedirs(args["output_dir"])
    return args


def define_compute_resources(args):
    if args["n_gpu"] > 4:
        assert args["n_gpu"] % 4 == 0
        n_nodes = args["n_gpu"] // 4
        n_gpu = 4
    else:
        n_nodes = 1
        n_gpu = args["n_gpu"]

    if n_gpu >= 4:
        memory = 0
    else:
        memory = 125000 * n_gpu
    partition = "gpu"
    cpu = n_gpu * 18  # 18 cores per GPU

    args = {
        **args,
        "n_nodes": n_nodes,
        "n_gpu": n_gpu,
        "n_cpu": cpu,
        "partition": partition,
        "memory": memory,
    }
    return args


def deep_merge_configs(main_config, included_config):
    """
    Deep merges two configurations with the main config retaining its order.
    """
    for key, value in included_config.items():
        if (
            key in main_config
            and isinstance(main_config[key], dict)
            and isinstance(value, dict)
        ):
            deep_merge_configs(main_config[key], value)
        else:
            main_config[key] = value


def find_include_value(data, target_key):
    if isinstance(data, dict):
        for key, value in data.items():
            if key == target_key:
                return value
            elif isinstance(value, dict):
                result = find_include_value(value, target_key)
                if result is not None:
                    return result
    return None


def _convert_to_float(value):
    """Convert value to float, return None on error."""
    try:
        return float(value)
    except ValueError:
        return None


def _convert_to_int(value):
    """Convert value to int, return None on error."""
    try:
        return int(value)
    except ValueError:
        return None


def _convert_to_list_int(value):
    """Convert comma-separated string to list of ints, return None on error."""
    try:
        return list(map(int, value.split(",")))
    except ValueError:
        return None


def _convert_replacement_value(placeholder_type, replacement_value):
    """Convert replacement value to specified type."""
    if replacement_value is None:
        return replacement_value
    if placeholder_type == "float":
        return _convert_to_float(replacement_value)
    if placeholder_type == "int":
        return _convert_to_int(replacement_value)
    if placeholder_type == "bool":
        return replacement_value.lower() == "true"
    if placeholder_type == "list_int":
        return _convert_to_list_int(replacement_value)
    return replacement_value


def replace_placeholder(element, replacements=None):
    if replacements is None:
        replacements = {}

    if isinstance(element, dict):
        for key, value in element.items():
            element[key] = replace_placeholder(value, replacements)
    elif isinstance(element, list):
        return [replace_placeholder(item, replacements) for item in element]
    elif isinstance(element, str):

        def replacement_function(match):
            placeholder_type = match.group(1) if match.group(1) else "str"
            placeholder_variable = match.group(2)
            replacement_value = replacements.get(
                placeholder_variable, match.group(0)
            )
            return _convert_replacement_value(
                placeholder_type, replacement_value
            )

        pattern = r"<<(?:(\w+): )?(\w+)>>"
        matches = list(re.finditer(pattern, element))

        # If exactly one match and it spans the entire string, perform
        # type conversion
        if len(matches) == 1 and matches[0].span() == (0, len(element)):
            return replacement_function(matches[0])

        # For strings with multiple placeholders or additional text, replace
        # without type conversion
        def string_replacement_function(match):
            return str(replacement_function(match))

        result = re.sub(pattern, string_replacement_function, element)
        return result

    return element


def load_and_merge_configs(
    config_path,
):
    """
    Loads configuration from the main file and merges included configurations
    while preserving the order.
    """
    with open(config_path, "r") as file:
        # Load the main configuration with FullLoader to preserve the order
        main_config = yaml.load(file, Loader=yaml.FullLoader)

    # Check if there are included configs and process them
    includes = find_include_value(main_config, "__include")
    if includes is not None:
        for include_path in includes:
            with open(include_path, "r") as inc_file:
                included_config = yaml.load(inc_file, Loader=yaml.FullLoader)
                deep_merge_configs(main_config, included_config)

    return main_config


def copy_config(config, args):
    """
    Copies the given config file to a job-specific directory after merging
    included configurations. Preserves the order of parameters in the main
    config file.
    """
    dest_filename = f"{args['job_id']}.yml"
    dest_path = os.path.join(args["output_dir"], dest_filename)

    with open(dest_path, "w") as file:
        yaml.dump(
            config, file, sort_keys=False
        )  # Prevent sorting keys on dump
    args["copied_config_file"] = dest_path
    return args


def generate_bash_script(args):
    """
    Reads in a bash template file and replaces placeholders with the given
    config path. Writes the modified script to the job-specific directory.
    """
    output_path = os.path.join(args["output_dir"], f"{args['job_id']}.sh")

    with open(args["template"], "r") as file:
        script = file.read().format(**args)

    with open(output_path, "w") as file:
        file.write(script)
    return output_path


def submit_script(script_path):
    """
    Submits the given bash script to sbatch.
    """
    subprocess.run(["sbatch", script_path])


def main():
    parser = argparse.ArgumentParser(
        description="Submit jobs with documentation of the YAML configuration."
    )
    parser.add_argument(
        "--config_file",
        type=str,
        required=True,
        help="Path to the YAML configuration file.",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=None,
        help=(
            "Path to the output data. If both are None, path of config file "
            "is used."
        ),
    )
    parser.add_argument(
        "--template",
        type=str,
        default="src/model/scripts/template.slurm",
        help="Path to the bash script template.",
    )
    parser.add_argument(
        "--dry",
        action="store_true",
        help="Only create files, do not submit the job.",
    )
    parser.add_argument(
        "--n_gpu", type=int, default=1, help="Number of GPUs to use."
    )
    parser.add_argument(
        "--time",
        type=str,
        default="00:10:00",
        help="Expected runtime in HH:MM:SS format.",
    )
    parser.add_argument(
        "--script",
        type=str,
        default="src/model/train.py",
        help="Script to run.",
    )
    parser.add_argument(
        "--job_name", type=str, default="v1", help="Name of the job."
    )
    parser.add_argument(
        "--group_name",
        type=str,
        default="debug",
        help="Name of the experiment group.",
    )
    parser.add_argument(
        "--project_name",
        type=str,
        default="NK-Landscape",
        help="Project to charge.",
    )
    parser.add_argument(
        "--image",
        type=str,
        default="/u/lumi/projects/llm-strategic-tuning/images/ai_nk_rl.sif",
        help="Apptainer image to use",
    )
    argv = sys.argv[1:]

    known_args, unknown_args = parser.parse_known_args(sys.argv[1:])
    dynamic_args = parse_unknown_args(unknown_args, argv)
    args_dict = vars(known_args)
    args_dict.update(dynamic_args)

    args_dict = define_compute_resources(args_dict)
    args_dict["job_id"] = generate_local_job_id()
    args_dict = args_dict.copy()

    args_dict = define_output(args_dict)
    config = load_and_merge_configs(args_dict["config_file"])
    config = replace_placeholder(config, args_dict)
    args_dict = copy_config(config, args_dict)

    args_dict["config_file"] = args_dict["copied_config_file"]
    generated_script = generate_bash_script(args_dict)

    if not args_dict["dry"]:
        submit_script(generated_script)
    else:
        print(f"Generated script at {generated_script} without submission.")


if __name__ == "__main__":
    main()
