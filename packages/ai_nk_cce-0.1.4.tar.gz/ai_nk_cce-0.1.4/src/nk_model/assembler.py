"""Utilities for assembling sequences (vectors) and simple bit operations.

This module provides:
- Bit helper (`reverse01`) for boolean bit values
- Random selection helper (`random_elem`)
- Simple assemblers (`assembler_v1`, `assembler_v1_v2`, `assembler_v1_sym`)
- `ensemble_builder` to grow a set of vectors up to a target length
  while avoiding duplicates and invalid outputs.
"""

from random import choice
from typing import Callable, Optional, TypeVar

T = TypeVar("T")


def reverse01(bits: list[int]) -> list[int]:
    """Return a new list where each bit is flipped."""
    return [1 - bit for bit in bits]


def random_elem(items: list[T]) -> Optional[T]:
    """Return a random element from the list, or None if the list is empty."""
    return choice(items) if items else None


def assembler_v1(vectors: list[list[T]]) -> Optional[list[T]]:
    """
    Concatenate a randomly chosen vector with itself.

    Returns None if the input list is empty.
    """
    if not vectors:
        return None
    v1 = random_elem(vectors)
    return None if v1 is None else v1 + v1


def assembler_v1_v2(vectors: list[list[T]]) -> Optional[list[T]]:
    """
    Concatenate two randomly chosen vectors from the input.

    Returns None if the input list is empty.
    """
    if not vectors:
        return None
    v1 = random_elem(vectors)
    v2 = random_elem(vectors)
    if v1 is None or v2 is None:
        return None
    return v1 + v2


def assembler_v1_sym(
    vectors: list[list[int]],
) -> Optional[list[int]]:
    """
    For integer vectors: pick v1 at random, then concatenate with v1
    or its flip.

    Returns None if the input list is empty.
    """
    if not vectors:
        return None
    v1 = random_elem(vectors)
    if v1 is None:
        return None
    v2 = random_elem([v1, reverse01(v1)])
    return None if v2 is None else v1 + v2


def ensemble_builder(
    assembler: Callable[[list[list[T]]], Optional[list[T]]],
    n: int,
    max_len: int,
    vectors: list[list[T]],
) -> list[list[T]]:
    """
    Grow the starting ensemble of vectors by repeatedly assembling new vectors.

    Args:
        assembler:
            Function to assemble new vectors from the current ensemble. Should
            take a list of vectors and return a new vector.
        n:
            Number of vectors the ensemble should return of length max_len.
        max_len:
            Maximum length of the vectors in the ensemble.
            The ensemble will return vectors of length max_len.
        vectors:
            Starting ensemble of vectors.
            The ensemble will start with these vectors.

    Returns:
        List of vectors in the ensemble of length max_len.
    """
    if n == 0 or not vectors:
        return vectors

    new_vector = assembler(vectors)
    if (
        new_vector is None
        or new_vector in vectors
        or len(new_vector) > max_len
    ):
        return ensemble_builder(assembler, n, max_len, vectors)

    new_vectors = vectors + [new_vector]
    if len(new_vector) < max_len:
        return ensemble_builder(assembler, n, max_len, new_vectors)

    return ensemble_builder(assembler, n - 1, max_len, new_vectors)
