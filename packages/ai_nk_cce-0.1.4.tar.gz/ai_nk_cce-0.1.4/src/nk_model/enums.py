from enum import Enum


class NeighborhoodMethod(Enum):
    """
    Method to determine the nearest neighbor for a given node in the NK model.
    """

    RANDOM = "random"
    NEAREST = "nearest"
    RING = "ring"


class ConvolutionMethod(Enum):
    """
    Method to determine the convolution method to apply to the NK model
    landscape.
    """

    RANDOM = "random"
    SYMMETRIC = "symmetric"
