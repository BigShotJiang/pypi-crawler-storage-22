import json
from typing import Literal, Union

import numpy as np
from pydantic import (
    BaseModel,
    Field,
    NonNegativeInt,
    PositiveFloat,
    PositiveInt,
    field_validator,
    model_validator,
)

from nk_model.enums import ConvolutionMethod, NeighborhoodMethod


class NKParams(BaseModel):
    n: PositiveInt
    k: NonNegativeInt
    power: PositiveFloat
    max_val: PositiveFloat = Field(
        default=1.0,
        description="Maximum value for NK-landscape values. All values "
        "will be scaled so that the maximum value equals this float. "
        "Example: 1000.0 means the maximum value will be 1000.0.",
    )
    m: PositiveInt = Field(
        description=(
            "Number of convolutions to apply to the NK model landscape. "
            "Default is m=n, which means no convolutions are applied."
        ),
    )
    neighborhood: NeighborhoodMethod = Field(
        default=NeighborhoodMethod.RANDOM,
        description=(
            "Method to determine the nearest neighbor for a given node in "
            "the NK model."
        ),
    )
    convolution: ConvolutionMethod = Field(
        default=ConvolutionMethod.RANDOM,
        description=(
            "Method to determine the convolution method to apply to the NK "
            "model landscape."
        ),
    )
    payoff_type: Literal["int", "float"] = Field(
        description=(
            "Type for payoff values. If 'int', all payoffs will be integers. "
            "If 'float', all payoffs will be floats."
        ),
    )

    @field_validator("payoff_type", mode="before")
    @classmethod
    def validate_payoff_type(cls, v):
        """Convert type objects to strings and validate."""
        # Allow both type objects and strings
        if v == int or v == "int":
            return "int"
        elif v == float or v == "float":
            return "float"
        else:
            raise ValueError(
                "payoff_type must be int, float, 'int', or 'float'"
            )

    @property
    def payoff_type_class(self) -> type[int] | type[float]:
        """Get the actual Python type for payoff_type."""
        return int if self.payoff_type == "int" else float

    @model_validator(mode="before")
    @classmethod
    def set_m_default(cls, data: dict) -> dict:
        """Set m to n if not provided or None."""
        if isinstance(data, dict):
            data = data.copy()
            # Set m to n if m is missing or None, and n is present
            if ("m" not in data or data.get("m") is None) and "n" in data:
                data["m"] = data["n"]
        return data

    @model_validator(mode="after")
    def validate_and_set_defaults(self) -> "NKParams":
        """Validate k and m."""
        if self.k >= self.n:
            raise ValueError("The value of k must be less than n.")

        if self.m > self.n:
            raise ValueError("The value of m must be less than or equal to n.")
        return self


class Item(BaseModel):
    """
    Represents an item in an NK model landscape.

    Attributes:
        coordinates (np.ndarray):
            Binary coordinates of the item (e.g., np.array([0, 1, 1, 0])).
        payoff (Union[int, float]):
            Payoff value. Type depends on NKParams.payoff_type.
    """

    # Allows np.ndarray as attribute
    model_config = {"arbitrary_types_allowed": True}

    coordinates: np.ndarray
    payoff: Union[int, float] = Field(..., ge=0)

    @field_validator("coordinates")
    def _validate_state(cls, coordinates: np.ndarray):
        assert coordinates.ndim == 1, "Coordinates must be a 1D array."
        assert all(
            x in [0, 1] for x in coordinates
        ), "Coordinates must be binary."
        return coordinates

    def __lt__(self, other: "Item") -> bool:
        "Compare two items based on their payoffs"
        return self.payoff < other.payoff

    def model_dump(self) -> dict:
        """
        Return a dictionary of the Item,
        because arrays cannot be serialized to JSON.
        """
        return {
            "coordinates": self.coordinates.tolist(),
            "payoff": self.payoff,
        }


class NKLandscapeCache(BaseModel):
    """
    Pydantic model for caching NKLandscape data.

    This model simplifies the serialization and deserialization
    of cached landscape data by using Pydantic's built-in
    serialization capabilities.
    """

    model_config = {"arbitrary_types_allowed": True}

    params: NKParams
    items: list[Item]

    def model_dump_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(
            {
                "params": self.params.model_dump(mode="json"),
                "items": [item.model_dump() for item in self.items],
            }
        )

    @classmethod
    def model_validate_json(cls, json_str: str) -> "NKLandscapeCache":
        """Deserialize from JSON string."""
        data = json.loads(json_str)
        return cls(
            params=NKParams(**data["params"]),
            items=[
                Item(
                    coordinates=np.array(item["coordinates"]),
                    payoff=item["payoff"],
                )
                for item in data["items"]
            ],
        )
