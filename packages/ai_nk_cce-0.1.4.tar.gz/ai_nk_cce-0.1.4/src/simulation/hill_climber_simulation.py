import logging
from enum import Enum
from typing import List, Optional, Type

import numpy as np
from pydantic import BaseModel

from model.config import ParserConfig
from model.dataset import binary_vectors_within_radius
from model.nk_assistant import NKAssistant, NKAssistantConfig
from nk_model.models import NKParams
from nk_model.nk_landscape import NKLandscape

logger = logging.getLogger()


class StopCondition(Enum):
    MAX_ITERATIONS = "max_iterations"
    REACH_PEAK = "reach_peak"


class AgentType(Enum):
    HILL_CLIMBER = "hill_climber"
    AI_HILL_CLIMBER = "ai_hill_climber"

    def agent_class(self) -> Type["HillClimberAgent"]:
        if self == AgentType.HILL_CLIMBER:
            return HillClimberAgent
        elif self == AgentType.AI_HILL_CLIMBER:
            return AIHillClimberAgent
        else:
            raise ValueError(f"Invalid agent type: {self}")


class HillClimberSimConfig(BaseModel):
    nk_params: NKParams
    hamming_distance: int
    agent_type: AgentType
    start_idxs: List[int]
    agent_start_idx: Optional[int] = None
    use_trajectory: Optional[bool] = False
    stop_condition: StopCondition
    stop_condition_kwargs: dict


class HillClimberAgent:
    def __init__(self, start_idx: int):
        self.trajectory = [start_idx]

    def _get_current_idx(self) -> int:
        return self.trajectory[-1]

    def hill_climb(
        self,
        n: int,
        hamming_distance: int,
    ) -> int:
        neighbors = binary_vectors_within_radius(
            origin=self._get_current_idx(),
            radius=hamming_distance,
            n_dim=n,
        )
        next_idx = np.random.choice(neighbors)

        # Only advance if the next index is not in the trajectory
        if next_idx is not self._get_current_idx():
            self.trajectory.append(next_idx)
            return next_idx
        else:
            return self.hill_climb(n, hamming_distance)


class AIHillClimberAgent(HillClimberAgent):
    def __init__(self, start_idx: int, use_trajectory: bool):
        super().__init__(start_idx)
        self.use_trajectory = use_trajectory
        assistant_config = NKAssistantConfig(
            parser_config=ParserConfig(include_payoff=True),
            use_mpcdf_vllm=True,
            generation_params={"temperature": 0.7},
        )
        self.assistant = NKAssistant(config=assistant_config)

    def hill_climb(
        self,
        n: int,
        k: int,
        power_scale: float,
        hamming_distance: int,
        sample_idxs: List[int],
        payoffs: List[float],
    ) -> int:
        logger.debug(f"sample_idxs: {sample_idxs}")
        if self.use_trajectory:
            sample_idxs = self.trajectory
            logger.debug(f"Using trajectory: {sample_idxs}")
        else:
            sample_idxs = sample_idxs[-16:]
        extracted_payoffs = [payoffs[idx] for idx in sample_idxs]
        logger.debug(f"extracted_payoffs: {extracted_payoffs}")

        origin_idx = self._get_current_idx()
        suggestion = self.assistant.suggest(
            n=n,
            k=k,
            power_scale=power_scale,
            hamming_distance=hamming_distance,
            sample_idxs=sample_idxs,
            origin_idx=origin_idx,
            payoffs=extracted_payoffs,
        )
        self.trajectory.append(suggestion)
        return suggestion


class HillClimberSimulation:
    def __init__(self, config: HillClimberSimConfig):
        landscape = NKLandscape(params=config.nk_params)
        self._initialize(config, landscape)

    def _initialize(
        self, config: HillClimberSimConfig, landscape: NKLandscape
    ):
        """Initialize shared components of the simulation.

        Args:
            config: Configuration for the simulation
            landscape: The NK landscape instance to use
        """
        self.config = config
        self.visited_idxs = set(config.start_idxs)
        self.landscape = landscape
        self.ordered_payoffs = landscape.get_ordered_payoffs()

        # Initialize the agent
        if (
            config.agent_start_idx is None
            or config.agent_start_idx not in config.start_idxs
        ):
            self.agent_start_idx = np.random.choice(config.start_idxs)
        else:
            self.agent_start_idx = config.agent_start_idx

        if config.agent_type == AgentType.HILL_CLIMBER:
            self.agent = HillClimberAgent(start_idx=self.agent_start_idx)
        elif config.agent_type == AgentType.AI_HILL_CLIMBER:
            self.agent = AIHillClimberAgent(
                start_idx=self.agent_start_idx,
                use_trajectory=config.use_trajectory,
            )

    @classmethod
    def from_cached_landscape(
        cls, config: HillClimberSimConfig, landscape_uuid: str
    ) -> "HillClimberSimulation":
        """Create simulation using a cached landscape by UUID.

        Args:
            config: Configuration for the simulation
            landscape_uuid: UUID of the cached landscape to use

        Returns:
            HillClimberSimulation instance with the cached landscape
        """
        instance = cls.__new__(cls)
        landscape = NKLandscape.from_cache(landscape_uuid)
        instance._initialize(config, landscape)
        return instance

    def run(self):
        while not self._break_hill_climber(self.agent.trajectory):
            if self.config.agent_type == AgentType.HILL_CLIMBER:
                self.agent.hill_climb(
                    n=self.config.nk_params.n,
                    hamming_distance=self.config.hamming_distance,
                )
            elif self.config.agent_type == AgentType.AI_HILL_CLIMBER:
                self.agent.hill_climb(
                    n=self.config.nk_params.n,
                    k=self.config.nk_params.k,
                    power_scale=self.config.nk_params.power,
                    hamming_distance=self.config.hamming_distance,
                    sample_idxs=list(self.visited_idxs),
                    payoffs=self.ordered_payoffs,
                )
            # Update visited indices
            self.visited_idxs.update(self.agent.trajectory)
            logger.debug(f"visited_idxs: {self.visited_idxs}")

        return self.agent.trajectory

    def _break_hill_climber(self, trajectory: List[int]) -> bool:
        if self.config.stop_condition == StopCondition.MAX_ITERATIONS:
            # Break if the number of iterations where reached
            return (
                len(trajectory)
                >= self.config.stop_condition_kwargs["max_iterations"]
            )
        elif self.config.stop_condition == StopCondition.REACH_PEAK:
            # Break if the agent is stuck on a local maximum
            stuck_for_until_break = self.config.stop_condition_kwargs[
                "stuck_for_until_break"
            ]
            if len(trajectory) < stuck_for_until_break * 2:
                return False
            if set(trajectory[:-stuck_for_until_break]) >= set(
                trajectory[-stuck_for_until_break:]
            ):
                return True
            else:
                return False
