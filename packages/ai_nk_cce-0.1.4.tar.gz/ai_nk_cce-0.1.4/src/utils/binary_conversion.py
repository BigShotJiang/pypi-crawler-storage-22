"""Binary conversion utilities for transforming between int, array, and string.

This module provides functions to convert between different representations
of binary states:
- Integer (0-255): Represents an 8-bit binary number
- Binary array: NumPy array of shape (8,) with values 0 or 1
- Binary string: String representation like "0,0,0,0,0,0,0,0"
"""

import numpy as np

from utils.utils import BIN_ARRAY


def int_to_binary_str(value: int, separator: str = ",") -> str:
    """Convert integer to binary string representation.

    Args:
        value: Integer value (0-255) to convert
        separator: String separator for binary digits. Defaults to ",".

    Returns:
        Binary string representation, e.g., "0,0,0,0,0,0,0,0"

    Examples:
        >>> int_to_binary_str(0)
        '0,0,0,0,0,0,0,0'
        >>> int_to_binary_str(255)
        '1,1,1,1,1,1,1,1'
        >>> int_to_binary_str(15)
        '0,0,0,0,1,1,1,1'
    """
    return separator.join([str(v) for v in BIN_ARRAY[value]])


def binary_str_to_int(binary_str: str, separator: str = ",") -> int:
    """Convert binary string to integer.

    Args:
        binary_str: Binary string representation, e.g., "0,0,0,0,0,0,0,0"
        separator: String separator used in binary_str. Defaults to ",".

    Returns:
        Integer value (0-255)

    Examples:
        >>> binary_str_to_int("0,0,0,0,0,0,0,0")
        0
        >>> binary_str_to_int("1,1,1,1,1,1,1,1")
        255
        >>> binary_str_to_int("0,0,0,0,1,1,1,1")
        15
    """
    return int(binary_str.replace(separator, ""), 2)


def int_to_binary_array(value: int) -> np.ndarray:
    """Convert integer to binary array.

    Args:
        value: Integer value (0-255) to convert

    Returns:
        Binary array of shape (8,) with values 0 or 1

    Examples:
        >>> int_to_binary_array(0)
        array([0, 0, 0, 0, 0, 0, 0, 0])
        >>> int_to_binary_array(255)
        array([1, 1, 1, 1, 1, 1, 1, 1])
    """
    return BIN_ARRAY[value].copy()


def binary_array_to_int(binary_array: np.ndarray) -> int:
    """Convert binary array to integer.

    Args:
        binary_array: Binary array of shape (8,) with values 0 or 1

    Returns:
        Integer value (0-255)

    Examples:
        >>> binary_array_to_int(np.array([0, 0, 0, 0, 0, 0, 0, 0]))
        0
        >>> binary_array_to_int(np.array([1, 1, 1, 1, 1, 1, 1, 1]))
        255
    """
    return int("".join([str(int(v)) for v in binary_array]), 2)


def binary_array_to_str(binary_array: np.ndarray, separator: str = ",") -> str:
    """Convert binary array to string representation.

    Args:
        binary_array: Binary array of shape (n,) with values 0 or 1
        separator: String separator for binary digits. Defaults to ",".

    Returns:
        Binary string representation, e.g., "1,0,1,0,1"

    Examples:
        >>> binary_array_to_str(np.array([1, 0, 1, 0, 1]))
        '1,0,1,0,1'
        >>> binary_array_to_str(np.array([1, 0, 1]), separator=" ")
        '1 0 1'
    """
    return separator.join([str(int(item)) for item in binary_array])


def binary_str_to_array(binary_str: str, separator: str = ",") -> np.ndarray:
    """Convert binary string to array.

    Args:
        binary_str: Binary string representation, e.g., "0,0,0,0,0,0,0,0"
        separator: String separator used in binary_str. Defaults to ",".

    Returns:
        Binary array of shape (n,) with values 0 or 1

    Examples:
        >>> binary_str_to_array("0,0,0,0,0,0,0,0")
        array([0, 0, 0, 0, 0, 0, 0, 0])
        >>> binary_str_to_array("1,1,1,1,1,1,1,1")
        array([1, 1, 1, 1, 1, 1, 1, 1])
    """
    return np.array([int(x) for x in binary_str.split(separator)])
