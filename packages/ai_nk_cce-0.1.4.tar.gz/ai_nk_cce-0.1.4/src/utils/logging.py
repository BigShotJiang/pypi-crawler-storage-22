import functools
import logging
from time import time

# logging settings
logging.basicConfig(
    format=("%(asctime)s %(levelname)-8s %(message)s"),
    # log.INFO for normal run
    level=logging.INFO,
    # log.DEBUG for diagnostics
    # level=logging.DEBUG,
    datefmt="%Y-%m-%d %H:%M:%S",
)


def log_dec(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger = logging.getLogger(func.__module__)
        try:
            start_time = time()
            logger.info("%-30s started", func.__name__)
            return func(*args, **kwargs)
        except Exception as ex:
            logger.error(f"%-30s raised an exception: {ex}", func.__name__)
            raise ex
        finally:
            duration = time() - start_time
            logger.info(
                "%-30s finished in %s seconds", func.__name__, duration
            )

    return wrapper
