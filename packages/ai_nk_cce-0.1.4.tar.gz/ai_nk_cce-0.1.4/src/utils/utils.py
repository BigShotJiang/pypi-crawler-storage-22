from typing import Type, TypeVar

import numpy as np
import yaml
from pydantic import BaseModel

# Define a generic type variable that must inherit from BaseModel
T = TypeVar("T", bound=BaseModel)

# Precomputed binary array for fast lookups
BIN_ARRAY = np.unpackbits(np.arange(0, 256, dtype=np.uint8)[:, None], axis=1)


# array_to_str moved to binary_conversion.binary_array_to_str
# Import from binary_conversion module instead


def mod_sub_vec(a, b, n):
    """
    Subtract two vectors in the ring Z_n.
    Args:
        a: First vector
        b: Second vector
        n: Modulus
    Returns:
        np.ndarray: Result of the subtraction
    Examples:
        >>> mod_sub_vec(np.array([1, 2, 3]), np.array([4, 5, 6]), 7)
        array([4, 4, 4])
        >>> mod_sub_vec(np.array([9, 2, 7]), np.array([4, 4, 4]), 10)
        array([5, 8, 3])
        >>> mod_sub_vec(np.array([1, 2, 3]), np.array([0, 1, 6]), 2)
        array([1, 1, 1])
    """
    return np.mod(np.mod(a, n) - np.mod(b, n), n)


def load_config_from_yaml(filepath: str, model: Type[T]) -> T:
    """
    Load a YAML configuration file and parse it into a Pydantic model.

    Args:
        filepath: Path to the YAML configuration file
        model: Pydantic model class to parse the data into

    Returns:
        Instance of the provided model class with data from YAML
    """
    with open(filepath, "r") as file:
        data = yaml.safe_load(file)
    return model(**data)
