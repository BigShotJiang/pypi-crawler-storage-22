# AI Token Optimizer CLI

Command-line tool for optimizing prompts sent to AI coding assistants.

## Installation

```bash
pip install ai-optimize
```

Or install from source:

```bash
pip install -e .
```

## Usage

### Basic optimization

```bash
# Use default optimization (lite mode)
ai-opt "fix the bug in auth.py"

# Use ultra mode for maximum savings
ai-opt --mode ultra "add error handling"

# Use verbose mode for detailed explanations
ai-opt --mode verbose "explain this algorithm"
```

### Dry run

Preview the optimized prompt without executing:

```bash
ai-opt --dry-run "refactor this function"
```

### Statistics

```bash
# Show usage statistics
ai-opt stats

# Show today's statistics
ai-opt stats --today

# Export statistics
ai-opt stats --export json
ai-opt stats --export csv
```

### Configuration

```bash
# Create a config file in the current directory
ai-opt config init

# Create a global config file
ai-opt config init --global

# Show current configuration
ai-opt config show

# Validate configuration
ai-opt config validate
```

### Tool management

```bash
# List supported tools
ai-opt tools list

# Detect available tools
ai-opt tools detect
```

## Optimization modes

| Mode | Savings | Description |
|------|---------|-------------|
| ultra | 60-80% | Code only, no explanations |
| lite | 40-60% | Code-first with brief explanations |
| verbose | 0-20% | Full explanations and context |

## Configuration file

Create `.ai-optimize.yml` in your project root:

```yaml
version: "1.0"

optimization:
  mode: "lite"

rules:
  skip_preamble: true
  skip_postamble: true
  code_first: true
  max_explanation_length: 50

context:
  exclude_patterns:
    - "node_modules/**"
    - "dist/**"

tracking:
  enabled: true
```

## License

MIT
