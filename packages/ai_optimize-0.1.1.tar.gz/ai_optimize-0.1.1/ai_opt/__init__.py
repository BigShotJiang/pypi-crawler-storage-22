"""
AI Token Optimizer CLI

A universal optimization system for AI coding assistants that reduces
token consumption by 40-80% through intelligent prompt optimization.
"""

__version__ = "0.1.0"
__author__ = "AI Token Optimizer Contributors"

from ai_opt.optimizer import optimize, Optimizer
from ai_opt.config import load_config, DEFAULT_CONFIG
from ai_opt.modes import OptimizationMode, get_mode_prefix

__all__ = [
    "optimize",
    "Optimizer",
    "load_config",
    "DEFAULT_CONFIG",
    "OptimizationMode",
    "get_mode_prefix",
]
