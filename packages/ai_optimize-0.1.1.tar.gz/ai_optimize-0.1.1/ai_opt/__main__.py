"""Entry point for running ai_opt as a module: python -m ai_opt"""

from ai_opt.cli import main

if __name__ == "__main__":
    main()
