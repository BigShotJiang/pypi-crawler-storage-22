"""
AI tool adapters.

Provides adapters for different AI coding tools to integrate
with the optimization system.
"""

from ai_opt.adapters.base import BaseAdapter, AdapterResult
from ai_opt.adapters.claude import ClaudeAdapter
from ai_opt.adapters.aider import AiderAdapter
from ai_opt.adapters.generic import GenericAdapter

__all__ = [
    "BaseAdapter",
    "AdapterResult",
    "ClaudeAdapter",
    "AiderAdapter",
    "GenericAdapter",
    "get_adapter",
    "detect_tool",
]


def get_adapter(tool: str) -> BaseAdapter:
    """
    Get an adapter instance for the specified tool.

    Args:
        tool: Tool name (claude, aider, generic)

    Returns:
        Adapter instance

    Raises:
        ValueError: If tool is not supported
    """
    adapters: dict[str, type[BaseAdapter]] = {
        "claude": ClaudeAdapter,
        "aider": AiderAdapter,
        "generic": GenericAdapter,
    }

    adapter_class = adapters.get(tool.lower())
    if adapter_class is None:
        valid_tools = ", ".join(adapters.keys())
        raise ValueError(f"Unknown tool '{tool}'. Valid tools: {valid_tools}")

    return adapter_class()


def detect_tool() -> str:
    """
    Detect which AI tool is available on the system.

    Returns:
        Name of the detected tool, or 'generic' if none found
    """
    import shutil

    # Check for Claude Code CLI
    if shutil.which("claude"):
        return "claude"

    # Check for Aider
    if shutil.which("aider"):
        return "aider"

    return "generic"
