"""
Aider CLI adapter.
"""

from ai_opt.adapters.base import BaseAdapter


class AiderAdapter(BaseAdapter):
    """
    Adapter for Aider CLI.

    Aider is an AI pair programming tool that works with Claude,
    GPT-4, and other LLMs from the command line.
    """

    @property
    def name(self) -> str:
        return "aider"

    @property
    def command(self) -> str:
        return "aider"

    def build_command(self, optimized_prompt: str) -> list[str]:
        """
        Build the Aider CLI command.

        Args:
            optimized_prompt: The optimized prompt to send

        Returns:
            Command list for subprocess
        """
        # Aider accepts messages via --message flag
        return [self.command, "--message", optimized_prompt]
