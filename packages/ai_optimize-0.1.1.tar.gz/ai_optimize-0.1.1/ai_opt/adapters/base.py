"""
Base adapter class for AI tool integration.
"""

import subprocess
from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class AdapterResult:
    """Result from executing an AI tool command."""

    return_code: int
    stdout: str
    stderr: str
    success: bool

    @classmethod
    def from_completed_process(cls, process: subprocess.CompletedProcess[str]) -> "AdapterResult":
        """Create from a completed subprocess."""
        return cls(
            return_code=process.returncode,
            stdout=process.stdout or "",
            stderr=process.stderr or "",
            success=process.returncode == 0,
        )

    @classmethod
    def dry_run_result(cls, command: list[str]) -> "AdapterResult":
        """Create a dry-run result showing what would be executed."""
        cmd_str = " ".join(command)
        return cls(
            return_code=0,
            stdout=f"[DRY RUN] Would execute: {cmd_str}",
            stderr="",
            success=True,
        )


class BaseAdapter(ABC):
    """
    Base class for AI tool adapters.

    Subclasses must implement build_command() to construct the CLI
    command for their specific tool.
    """

    def __init__(self) -> None:
        """Initialize the adapter."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Get the adapter/tool name."""
        ...

    @property
    @abstractmethod
    def command(self) -> str:
        """Get the base command to execute."""
        ...

    @abstractmethod
    def build_command(self, optimized_prompt: str) -> list[str]:
        """
        Build the CLI command to execute.

        Args:
            optimized_prompt: The optimized prompt to send to the tool

        Returns:
            List of command arguments
        """
        ...

    def execute(
        self,
        optimized_prompt: str,
        dry_run: bool = False,
        timeout: int | None = None,
        file_path: str | None = None,
    ) -> AdapterResult:
        """
        Execute the command using subprocess, streaming output in real time.

        Args:
            optimized_prompt: The optimized prompt to send
            dry_run: If True, return what would be executed without running
            timeout: Optional timeout in seconds

        Returns:
            AdapterResult with command output
        """
        import sys
        import threading
        command = self.build_command(optimized_prompt, file_path=file_path)

        if dry_run:
            return AdapterResult.dry_run_result(command)

        try:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                shell=False,
            )

            stdout_lines = []
            stderr_lines = []

            def stream_output(stream, lines, is_stdout=True):
                for line in iter(stream.readline, ''):
                    lines.append(line)
                    if is_stdout:
                        print(line, end='')
                        sys.stdout.flush()
                    else:
                        print(line, end='', file=sys.stderr)
                        sys.stderr.flush()
                stream.close()

            threads = []
            threads.append(threading.Thread(target=stream_output, args=(process.stdout, stdout_lines, True)))
            threads.append(threading.Thread(target=stream_output, args=(process.stderr, stderr_lines, False)))
            for t in threads:
                t.start()

            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.kill()
                return AdapterResult(
                    return_code=124,
                    stdout=''.join(stdout_lines),
                    stderr=f"Command timed out after {timeout} seconds\n{''.join(stderr_lines)}",
                    success=False,
                )

            for t in threads:
                t.join()

            return AdapterResult(
                return_code=process.returncode,
                stdout=''.join(stdout_lines),
                stderr=''.join(stderr_lines),
                success=process.returncode == 0,
            )
        except FileNotFoundError:
            return AdapterResult(
                return_code=127,
                stdout="",
                stderr=f"Command not found: {self.command}",
                success=False,
            )
        except Exception as e:
            return AdapterResult(
                return_code=1,
                stdout="",
                stderr=str(e),
                success=False,
            )

    def is_available(self) -> bool:
        """Check if the tool is available on the system."""
        import shutil
        return shutil.which(self.command) is not None
