"""
Claude Code CLI adapter.
"""

from ai_opt.adapters.base import BaseAdapter


class ClaudeAdapter(BaseAdapter):
    """
    Adapter for Claude Code CLI.

    Claude Code is Anthropic's official CLI for Claude, providing
    terminal-based access to Claude's capabilities.
    """

    @property
    def name(self) -> str:
        return "claude"

    @property
    def command(self) -> str:
        return "claude"

    def build_command(self, optimized_prompt: str, file_path: str | None = None) -> list[str]:
        """
        Build the Claude CLI command.

        Args:
            optimized_prompt: The optimized prompt to send
            file_path: Optional file to edit with Claude

        Returns:
            Command list for subprocess
        """
        # If file_path is provided, pass it to Claude CLI (if supported)
        cmd = [self.command, "-p", optimized_prompt]
        if file_path:
            cmd += ["--edit", file_path]
        return cmd
