"""
Generic adapter for unsupported tools.
"""

from ai_opt.adapters.base import BaseAdapter, AdapterResult


class GenericAdapter(BaseAdapter):
    """
    Generic adapter that outputs the optimized prompt.

    Used when no specific AI tool is detected or when the user
    wants to manually copy the optimized prompt.
    """

    @property
    def name(self) -> str:
        return "generic"

    @property
    def command(self) -> str:
        return "echo"

    def build_command(self, optimized_prompt: str) -> list[str]:
        """
        Build a command that outputs the prompt.

        For the generic adapter, we simply echo the prompt so users
        can copy it to their preferred tool.

        Args:
            optimized_prompt: The optimized prompt to output

        Returns:
            Command list for subprocess
        """
        return ["echo", optimized_prompt]

    def execute(
        self,
        optimized_prompt: str,
        dry_run: bool = False,
        timeout: int | None = None,
    ) -> AdapterResult:
        """
        Output the optimized prompt directly.

        The generic adapter doesn't execute any external tool.
        Instead, it returns the optimized prompt as output.

        Args:
            optimized_prompt: The optimized prompt
            dry_run: If True, indicates this is a preview
            timeout: Ignored for generic adapter

        Returns:
            AdapterResult with the optimized prompt as stdout
        """
        prefix = "[OPTIMIZED PROMPT]" if not dry_run else "[DRY RUN - OPTIMIZED PROMPT]"
        return AdapterResult(
            return_code=0,
            stdout=f"{prefix}\n\n{optimized_prompt}",
            stderr="",
            success=True,
        )

    def is_available(self) -> bool:
        """Generic adapter is always available."""
        return True
