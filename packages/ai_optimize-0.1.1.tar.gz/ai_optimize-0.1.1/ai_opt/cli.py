"""
Main CLI entry point for AI Token Optimizer.

Provides command-line interface for optimizing prompts sent to
AI coding assistants.
"""

import argparse
import sys
from pathlib import Path
from typing import NoReturn

from ai_opt import __version__
from ai_opt.config import (
    OptimizationConfig,
    create_default_config,
    find_config_file,
    load_config,
)
from ai_opt.modes import (
    OptimizationMode,
    get_available_modes,
    parse_mode,
)
from ai_opt.optimizer import optimize
from ai_opt.stats import (
    export_stats_csv,
    export_stats_json,
    format_stats,
    get_today_stats,
    reset_stats,
)
from ai_opt.token_estimator import format_cost, format_token_count
from ai_opt.adapters import detect_tool, get_adapter


def create_main_parser() -> argparse.ArgumentParser:
    """Create the main argument parser for optimize command."""
    parser = argparse.ArgumentParser(
        prog="ai-opt",
        description="AI Token Optimizer - Reduce AI coding assistant token usage by 40-80%",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  ai-opt "prompt"           Optimize and execute a prompt
  ai-opt config init        Create default config file
  ai-opt config show        Display current configuration
  ai-opt stats              Show usage statistics
  ai-opt tools list         List supported tools

Examples:
  ai-opt "fix the bug in auth.py"
  ai-opt --mode ultra "add error handling"
  ai-opt --dry-run "complex refactoring task"
  ai-opt stats --today
  ai-opt config init
        """,
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    parser.add_argument(
        "request",
        nargs="?",
        help="The request/prompt to optimize and send",
    )
    parser.add_argument(
        "-m", "--mode",
        choices=[m.value for m in get_available_modes()],
        help="Optimization mode (ultra, lite, verbose)",
    )
    parser.add_argument(
        "-t", "--tool",
        choices=["claude", "aider", "generic"],
        help="AI tool to use (auto-detected if not specified)",
    )
    parser.add_argument(
        "-d", "--dry-run",
        action="store_true",
        help="Preview optimization without executing",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output",
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Minimal output",
    )

    return parser


def create_config_parser() -> argparse.ArgumentParser:
    """Create parser for config subcommand."""
    parser = argparse.ArgumentParser(
        prog="ai-opt config",
        description="Configuration management",
    )
    subparsers = parser.add_subparsers(dest="config_command", required=True)

    init_parser = subparsers.add_parser("init", help="Create default config file")
    init_parser.add_argument(
        "--global",
        dest="is_global",
        action="store_true",
        help="Create global config instead of project config",
    )
    init_parser.add_argument(
        "--format",
        choices=["yaml", "json"],
        default="yaml",
        help="Config file format (default: yaml)",
    )

    subparsers.add_parser("show", help="Display current configuration")
    subparsers.add_parser("validate", help="Validate configuration file")

    return parser


def create_stats_parser() -> argparse.ArgumentParser:
    """Create parser for stats subcommand."""
    parser = argparse.ArgumentParser(
        prog="ai-opt stats",
        description="Usage statistics",
    )
    parser.add_argument(
        "--today",
        action="store_true",
        help="Show today's statistics only",
    )
    parser.add_argument(
        "--week",
        action="store_true",
        help="Show this week's statistics",
    )
    parser.add_argument(
        "--export",
        choices=["json", "csv"],
        help="Export statistics in specified format",
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset all statistics",
    )
    return parser


def create_tools_parser() -> argparse.ArgumentParser:
    """Create parser for tools subcommand."""
    parser = argparse.ArgumentParser(
        prog="ai-opt tools",
        description="Tool management",
    )
    subparsers = parser.add_subparsers(dest="tools_command", required=True)
    subparsers.add_parser("list", help="List supported tools")
    subparsers.add_parser("detect", help="Detect available tools")
    return parser


def cmd_config_init(args: argparse.Namespace) -> int:
    """Handle 'config init' command."""
    if args.is_global:
        from ai_opt.config import get_global_config_dir
        config_dir = get_global_config_dir()
    else:
        config_dir = Path.cwd()

    ext = ".json" if args.format == "json" else ".yml"
    output_path = config_dir / f".ai-optimize{ext}"

    if output_path.exists():
        print(f"Config file already exists: {output_path}")
        return 1

    create_default_config(output_path, args.format)
    print(f"Created config file: {output_path}")
    return 0


def cmd_config_show(_args: argparse.Namespace) -> int:
    """Handle 'config show' command."""
    config = load_config()

    print("Current Configuration")
    print("=====================")
    print(f"Mode: {config.mode.value}")
    print(f"Version: {config.version}")
    print()
    print("Rules:")
    print(f"  Skip preamble: {config.rules.skip_preamble}")
    print(f"  Skip postamble: {config.rules.skip_postamble}")
    print(f"  Code first: {config.rules.code_first}")
    print(f"  Minimal comments: {config.rules.minimal_comments}")
    print(f"  Diff mode: {config.rules.diff_mode}")
    print(f"  Max explanation length: {config.rules.max_explanation_length}")
    print()
    print("Context:")
    print(f"  Exclude patterns: {len(config.context.exclude_patterns)} patterns")
    print(f"  Max file size: {config.context.max_file_size_kb} KB")
    print()
    print("Tracking:")
    print(f"  Enabled: {config.tracking.enabled}")
    print(f"  Save history: {config.tracking.save_history}")

    config_path = find_config_file(Path.cwd())
    print()
    if config_path:
        print(f"Config file: {config_path}")
    else:
        print("Config file: (using defaults)")

    return 0


def cmd_config_validate(_args: argparse.Namespace) -> int:
    """Handle 'config validate' command."""
    config_path = find_config_file(Path.cwd())

    if not config_path:
        print("No config file found in current directory or parents.")
        return 1

    try:
        config = load_config()
        print(f"Config file is valid: {config_path}")
        print(f"  Mode: {config.mode.value}")
        print(f"  Version: {config.version}")
        return 0
    except Exception as e:
        print(f"Config file is invalid: {config_path}")
        print(f"  Error: {e}")
        return 1


def cmd_stats(args: argparse.Namespace) -> int:
    """Handle 'stats' command."""
    if args.reset:
        reset_stats()
        print("Statistics have been reset.")
        return 0

    if args.export == "json":
        print(export_stats_json())
        return 0

    if args.export == "csv":
        print(export_stats_csv())
        return 0

    if args.today:
        today = get_today_stats()
        if today:
            print("Today's Statistics")
            print("==================")
            print(f"Requests: {today.total_requests}")
            print(f"Tokens Saved: {format_token_count(today.total_tokens_saved)}")
            print(f"Average Reduction: {today.avg_reduction_percent}%")
        else:
            print("No statistics for today yet.")
        return 0

    days = 7 if args.week else 30
    print(format_stats(days))
    return 0


def cmd_tools_list(_args: argparse.Namespace) -> int:
    """Handle 'tools list' command."""
    print("Supported AI Tools")
    print("==================")
    print("  claude  - Claude Code CLI (Anthropic)")
    print("  aider   - Aider AI pair programming")
    print("  generic - Output optimized prompt only")
    return 0


def cmd_tools_detect(_args: argparse.Namespace) -> int:
    """Handle 'tools detect' command."""
    detected = detect_tool()
    print(f"Detected tool: {detected}")

    from ai_opt.adapters import ClaudeAdapter, AiderAdapter

    print()
    print("Tool availability:")
    print(f"  claude: {'available' if ClaudeAdapter().is_available() else 'not found'}")
    print(f"  aider:  {'available' if AiderAdapter().is_available() else 'not found'}")

    return 0


def cmd_optimize(args: argparse.Namespace, config: OptimizationConfig) -> int:
    """Handle the main optimize command."""
    if not args.request:
        print("Error: No request provided. Use 'ai-opt --help' for usage.")
        return 1

    # Determine mode
    mode = config.mode
    if args.mode:
        mode = parse_mode(args.mode)

    # Determine tool
    tool_name = args.tool if args.tool else detect_tool()

    # Optimize the prompt
    result = optimize(
        prompt=args.request,
        config=config,
        mode=mode,
    )

    # Get the adapter
    adapter = get_adapter(tool_name)

    # Output info if not quiet
    if not args.quiet:
        print(f"[ai-opt] Mode: {result.mode.value}")
        print(f"[ai-opt] Tool: {tool_name}")
        print(f"[ai-opt] Optimizing prompt...")
        print(
            f"[ai-opt] Estimated tokens: {result.estimated_tokens_before} -> "
            f"{result.estimated_tokens_after} ({result.reduction_percent}% savings)"
        )
        print()

    # Execute or dry run
    # If the prompt looks like an edit (e.g. contains a file path), try to extract it
    import re
    file_path = None
    # Simple heuristic: look for a file path in the prompt (e.g. "edit foo.py" or "fix bug in bar.js")
    match = re.search(r"([\w./\\-]+\.(py|js|ts|tsx|json|md|txt|yaml|yml))", args.request)
    if match:
        file_path = match.group(1)

    adapter_result = adapter.execute(
        result.optimized_prompt,
        dry_run=args.dry_run,
        file_path=file_path,
    )

    # Output result
    if adapter_result.stdout:
        print(adapter_result.stdout)

    if adapter_result.stderr and not args.quiet:
        print(adapter_result.stderr, file=sys.stderr)

    # Show summary if not quiet
    if not args.quiet and not args.dry_run:
        print()
        print(
            f"[ai-opt] Estimated tokens saved: {result.tokens_saved} "
            f"({format_cost(result.tokens_saved * 0.000015)})"
        )

    return adapter_result.return_code


def main() -> NoReturn:
    """Main entry point."""
    # Check for subcommands first
    if len(sys.argv) > 1:
        command = sys.argv[1]

        if command == "config":
            parser = create_config_parser()
            args = parser.parse_args(sys.argv[2:])
            if args.config_command == "init":
                sys.exit(cmd_config_init(args))
            elif args.config_command == "show":
                sys.exit(cmd_config_show(args))
            elif args.config_command == "validate":
                sys.exit(cmd_config_validate(args))

        elif command == "stats":
            parser = create_stats_parser()
            args = parser.parse_args(sys.argv[2:])
            sys.exit(cmd_stats(args))

        elif command == "tools":
            parser = create_tools_parser()
            args = parser.parse_args(sys.argv[2:])
            if args.tools_command == "list":
                sys.exit(cmd_tools_list(args))
            elif args.tools_command == "detect":
                sys.exit(cmd_tools_detect(args))

    # Parse as main optimize command
    parser = create_main_parser()
    args = parser.parse_args()

    # Load configuration
    try:
        config = load_config()
    except Exception as e:
        print(f"Error loading config: {e}", file=sys.stderr)
        sys.exit(1)

    # No request provided - show help
    if not args.request:
        parser.print_help()
        sys.exit(0)

    # Run optimize command
    sys.exit(cmd_optimize(args, config))


if __name__ == "__main__":
    main()
