"""
Configuration loading and validation.

Handles loading configuration from YAML/JSON files with
support for project-level and global configuration hierarchy.
"""

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from ai_opt.modes import OptimizationMode, is_valid_mode


@dataclass
class OptimizationRules:
    """Rules that control optimization behavior."""

    skip_preamble: bool = True
    skip_postamble: bool = True
    code_first: bool = True
    minimal_comments: bool = True
    diff_mode: bool = True
    max_explanation_length: int = 50


@dataclass
class ContextConfig:
    """Context filtering configuration."""

    exclude_patterns: list[str] = field(
        default_factory=lambda: [
            "node_modules/**",
            "dist/**",
            "build/**",
            ".git/**",
            "*.log",
            "*.lock",
            "__pycache__/**",
            ".venv/**",
        ]
    )
    max_file_size_kb: int = 100
    prioritize_extensions: list[str] = field(
        default_factory=lambda: [".py", ".js", ".ts", ".tsx"]
    )


@dataclass
class TrackingConfig:
    """Statistics tracking configuration."""

    enabled: bool = True
    save_history: bool = True
    estimate_tokens: bool = True


@dataclass
class OptimizationConfig:
    """Complete configuration for the optimizer."""

    version: str = "1.0"
    mode: OptimizationMode = OptimizationMode.LITE
    rules: OptimizationRules = field(default_factory=OptimizationRules)
    context: ContextConfig = field(default_factory=ContextConfig)
    tracking: TrackingConfig = field(default_factory=TrackingConfig)


# Default configuration instance
DEFAULT_CONFIG = OptimizationConfig()

# Configuration file names to search for (in order of priority)
CONFIG_FILE_NAMES = [
    ".ai-optimize.yml",
    ".ai-optimize.yaml",
    ".ai-optimize.json",
    "ai-optimize.yml",
    "ai-optimize.yaml",
    "ai-optimize.json",
    ".aiconfig",
]


class ConfigError(Exception):
    """Error raised when configuration is invalid."""

    def __init__(self, message: str, field: str | None = None):
        super().__init__(message)
        self.field = field


def find_config_file(start_dir: str | Path, search_parents: bool = True) -> Path | None:
    """
    Find the configuration file path starting from a directory.

    Args:
        start_dir: Directory to start searching from
        search_parents: Whether to search parent directories

    Returns:
        Path to config file or None if not found
    """
    current_dir = Path(start_dir).resolve()

    while True:
        for file_name in CONFIG_FILE_NAMES:
            file_path = current_dir / file_name
            if file_path.exists():
                return file_path

        if not search_parents:
            break

        parent_dir = current_dir.parent
        if parent_dir == current_dir:
            break
        current_dir = parent_dir

    return None


def get_global_config_dir() -> Path:
    """Get the global configuration directory path."""
    if os.name == "nt":  # Windows
        base = os.environ.get("APPDATA", "")
        return Path(base) / "ai-optimize"

    return Path.home() / ".config" / "ai-optimize"


def get_global_config_path() -> Path | None:
    """Get the global configuration file path."""
    config_dir = get_global_config_dir()

    for file_name in CONFIG_FILE_NAMES:
        file_path = config_dir / file_name
        if file_path.exists():
            return file_path

    return None


def parse_config_file(file_path: Path) -> dict[str, Any]:
    """
    Parse a configuration file.

    Args:
        file_path: Path to the configuration file

    Returns:
        Parsed configuration dictionary
    """
    content = file_path.read_text(encoding="utf-8")
    ext = file_path.suffix.lower()

    if ext == ".json" or file_path.name == ".aiconfig":
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            # Try YAML if JSON fails (for .aiconfig files)
            return yaml.safe_load(content) or {}

    return yaml.safe_load(content) or {}


def _parse_rules(data: dict[str, Any] | None) -> OptimizationRules:
    """Parse and validate rules configuration."""
    if not data:
        return OptimizationRules()

    def get_bool(key: str, snake_key: str, default: bool) -> bool:
        if key in data and isinstance(data[key], bool):
            return data[key]
        if snake_key in data and isinstance(data[snake_key], bool):
            return data[snake_key]
        return default

    def get_int(key: str, snake_key: str, default: int) -> int:
        if key in data and isinstance(data[key], int):
            return data[key]
        if snake_key in data and isinstance(data[snake_key], int):
            return data[snake_key]
        return default

    defaults = OptimizationRules()
    return OptimizationRules(
        skip_preamble=get_bool("skipPreamble", "skip_preamble", defaults.skip_preamble),
        skip_postamble=get_bool(
            "skipPostamble", "skip_postamble", defaults.skip_postamble
        ),
        code_first=get_bool("codeFirst", "code_first", defaults.code_first),
        minimal_comments=get_bool(
            "minimalComments", "minimal_comments", defaults.minimal_comments
        ),
        diff_mode=get_bool("diffMode", "diff_mode", defaults.diff_mode),
        max_explanation_length=get_int(
            "maxExplanationLength",
            "max_explanation_length",
            defaults.max_explanation_length,
        ),
    )


def _parse_context(data: dict[str, Any] | None) -> ContextConfig:
    """Parse and validate context configuration."""
    if not data:
        return ContextConfig()

    defaults = ContextConfig()

    exclude = data.get("excludePatterns") or data.get("exclude_patterns")
    if not isinstance(exclude, list):
        exclude = defaults.exclude_patterns

    max_size = data.get("maxFileSizeKb") or data.get("max_file_size_kb")
    if not isinstance(max_size, int):
        max_size = defaults.max_file_size_kb

    prioritize = data.get("prioritizeExtensions") or data.get("prioritize_extensions")
    if not isinstance(prioritize, list):
        prioritize = defaults.prioritize_extensions

    return ContextConfig(
        exclude_patterns=exclude,
        max_file_size_kb=max_size,
        prioritize_extensions=prioritize,
    )


def _parse_tracking(data: dict[str, Any] | None) -> TrackingConfig:
    """Parse and validate tracking configuration."""
    if not data:
        return TrackingConfig()

    defaults = TrackingConfig()

    enabled = data.get("enabled")
    if not isinstance(enabled, bool):
        enabled = defaults.enabled

    save_history = data.get("saveHistory") or data.get("save_history")
    if not isinstance(save_history, bool):
        save_history = defaults.save_history

    estimate_tokens = data.get("estimateTokens") or data.get("estimate_tokens")
    if not isinstance(estimate_tokens, bool):
        estimate_tokens = defaults.estimate_tokens

    return TrackingConfig(
        enabled=enabled,
        save_history=save_history,
        estimate_tokens=estimate_tokens,
    )


def validate_config(data: dict[str, Any] | None) -> OptimizationConfig:
    """
    Validate and normalize a configuration dictionary.

    Args:
        data: Raw configuration dictionary

    Returns:
        Validated and normalized configuration
    """
    if not data:
        return OptimizationConfig()

    # Parse mode
    mode = OptimizationMode.LITE
    raw_mode = data.get("mode")
    if raw_mode is None and "optimization" in data:
        raw_mode = data["optimization"].get("mode")
    if isinstance(raw_mode, str) and is_valid_mode(raw_mode):
        mode = OptimizationMode(raw_mode.lower())

    # Parse version
    version = data.get("version", "1.0")
    if not isinstance(version, str):
        version = "1.0"

    return OptimizationConfig(
        version=version,
        mode=mode,
        rules=_parse_rules(data.get("rules")),
        context=_parse_context(data.get("context")),
        tracking=_parse_tracking(data.get("tracking")),
    )


def load_config(start_dir: str | Path | None = None) -> OptimizationConfig:
    """
    Load configuration with full hierarchy support.

    Priority order:
    1. Project-level config (in start_dir or parent directories)
    2. Global config (~/.config/ai-optimize/ or %APPDATA%/ai-optimize/)
    3. Default configuration

    Args:
        start_dir: Directory to start searching from (defaults to cwd)

    Returns:
        Merged configuration
    """
    if start_dir is None:
        start_dir = Path.cwd()
    else:
        start_dir = Path(start_dir)

    merged_data: dict[str, Any] = {}

    # Try global config first
    global_path = get_global_config_path()
    if global_path:
        try:
            global_data = parse_config_file(global_path)
            merged_data.update(global_data)
        except Exception:
            pass  # Ignore global config errors

    # Try project config (overrides global)
    project_path = find_config_file(start_dir)
    if project_path:
        try:
            project_data = parse_config_file(project_path)
            merged_data.update(project_data)
        except Exception as e:
            raise ConfigError(f"Failed to parse config file: {project_path}") from e

    return validate_config(merged_data) if merged_data else OptimizationConfig()


def create_default_config(
    output_path: Path, file_format: str = "yaml"
) -> None:
    """
    Create a default configuration file.

    Args:
        output_path: Path to write the config file
        file_format: File format ('yaml' or 'json')
    """
    config_content = {
        "version": "1.0",
        "optimization": {"mode": "lite"},
        "rules": {
            "skip_preamble": True,
            "skip_postamble": True,
            "code_first": True,
            "minimal_comments": True,
            "diff_mode": True,
            "max_explanation_length": 50,
        },
        "context": {
            "exclude_patterns": [
                "node_modules/**",
                "dist/**",
                "build/**",
                ".git/**",
                "*.log",
                "*.lock",
                "__pycache__/**",
                ".venv/**",
            ],
            "max_file_size_kb": 100,
            "prioritize_extensions": [".py", ".js", ".ts", ".tsx"],
        },
        "tracking": {
            "enabled": True,
            "save_history": True,
            "estimate_tokens": True,
        },
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)

    if file_format == "json":
        content = json.dumps(config_content, indent=2)
    else:
        content = yaml.dump(config_content, default_flow_style=False, sort_keys=False)

    output_path.write_text(content, encoding="utf-8")
