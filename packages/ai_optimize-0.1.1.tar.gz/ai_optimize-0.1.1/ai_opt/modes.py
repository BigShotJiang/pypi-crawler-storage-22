"""
Optimization mode definitions and prefixes.
"""

from enum import Enum
from typing import NamedTuple


class OptimizationMode(str, Enum):
    """Available optimization modes."""

    ULTRA = "ultra"
    LITE = "lite"
    VERBOSE = "verbose"


class ReductionTarget(NamedTuple):
    """Expected reduction range for a mode."""

    min_percent: int
    max_percent: int


# Mode prefix strings that are prepended to user prompts
MODE_PREFIXES: dict[OptimizationMode, str] = {
    OptimizationMode.ULTRA: (
        "CODE_ONLY: No explanations. Show minimal diff. Expert user."
    ),
    OptimizationMode.LITE: (
        "CONCISE: Code-first. Brief explanations only for complex changes. No fluff."
    ),
    OptimizationMode.VERBOSE: (
        "DETAILED: Include explanations, context, and reasoning."
    ),
}

# Expected token reduction percentages for each mode
MODE_REDUCTION_TARGETS: dict[OptimizationMode, ReductionTarget] = {
    OptimizationMode.ULTRA: ReductionTarget(60, 80),
    OptimizationMode.LITE: ReductionTarget(40, 60),
    OptimizationMode.VERBOSE: ReductionTarget(0, 20),
}

# Human-readable descriptions for each mode
MODE_DESCRIPTIONS: dict[OptimizationMode, str] = {
    OptimizationMode.ULTRA: (
        "Maximum token savings (60-80%), code only with no explanations"
    ),
    OptimizationMode.LITE: (
        "Balanced savings (40-60%), code-first with brief explanations"
    ),
    OptimizationMode.VERBOSE: (
        "Minimal savings (0-20%), full explanations and context"
    ),
}


def get_mode_prefix(mode: OptimizationMode) -> str:
    """Get the prefix string for a given optimization mode."""
    return MODE_PREFIXES[mode]


def get_mode_description(mode: OptimizationMode) -> str:
    """Get the description for a given optimization mode."""
    return MODE_DESCRIPTIONS[mode]


def get_mode_reduction_target(mode: OptimizationMode) -> ReductionTarget:
    """Get the expected reduction range for a given mode."""
    return MODE_REDUCTION_TARGETS[mode]


def is_valid_mode(value: str) -> bool:
    """Check if a string is a valid optimization mode."""
    try:
        OptimizationMode(value.lower())
        return True
    except ValueError:
        return False


def parse_mode(value: str) -> OptimizationMode:
    """Parse a string into an OptimizationMode, raising ValueError if invalid."""
    try:
        return OptimizationMode(value.lower())
    except ValueError:
        valid_modes = ", ".join(m.value for m in OptimizationMode)
        raise ValueError(
            f"Invalid mode '{value}'. Valid modes are: {valid_modes}"
        ) from None


def get_available_modes() -> list[OptimizationMode]:
    """Get all available optimization modes."""
    return list(OptimizationMode)
