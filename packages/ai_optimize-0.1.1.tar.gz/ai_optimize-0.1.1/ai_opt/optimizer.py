"""
Core optimization engine.

Transforms user prompts into optimized versions based on the
selected mode and configuration rules.
"""

from dataclasses import dataclass
from typing import Any

from ai_opt.config import OptimizationConfig, load_config, DEFAULT_CONFIG
from ai_opt.modes import OptimizationMode, get_mode_prefix
from ai_opt.token_estimator import estimate_tokens


@dataclass
class OptimizationResult:
    """Result of an optimization operation."""

    original_prompt: str
    optimized_prompt: str
    estimated_tokens_before: int
    estimated_tokens_after: int
    tokens_saved: int
    reduction_percent: int
    mode: OptimizationMode


def optimize(
    prompt: str,
    config: OptimizationConfig | None = None,
    mode: OptimizationMode | None = None,
    model: str = "default",
    skip_estimation: bool = False,
) -> OptimizationResult:
    """
    Optimize a user prompt based on configuration.

    Args:
        prompt: Original user prompt
        config: Configuration to use (defaults to loaded config)
        mode: Override the mode from config
        model: Model family for token estimation
        skip_estimation: Skip token estimation

    Returns:
        Optimization result with original and optimized prompts
    """
    effective_config = config if config is not None else DEFAULT_CONFIG
    effective_mode = mode if mode is not None else effective_config.mode

    # Get the mode prefix
    prefix = get_mode_prefix(effective_mode)

    # Build the optimized prompt
    optimized_prompt = f"{prefix}\n\n{prompt}"

    # Apply additional rules
    if effective_config.rules.code_first:
        optimized_prompt = _add_code_first_instruction(optimized_prompt)

    if effective_config.rules.diff_mode and effective_mode != OptimizationMode.VERBOSE:
        optimized_prompt = _add_diff_mode_instruction(optimized_prompt)

    if (
        effective_config.rules.max_explanation_length > 0
        and effective_mode != OptimizationMode.VERBOSE
    ):
        optimized_prompt = _add_explanation_limit_instruction(
            optimized_prompt, effective_config.rules.max_explanation_length
        )

    # Calculate token estimates
    if skip_estimation:
        tokens_before = 0
        tokens_after = 0
        tokens_saved = 0
        reduction_percent = 0
    else:
        result = _estimate_response_reduction(prompt, effective_mode, model)
        tokens_before = result["before"]
        tokens_after = result["after"]
        tokens_saved = result["saved"]
        reduction_percent = result["percent"]

    return OptimizationResult(
        original_prompt=prompt,
        optimized_prompt=optimized_prompt,
        estimated_tokens_before=tokens_before,
        estimated_tokens_after=tokens_after,
        tokens_saved=tokens_saved,
        reduction_percent=reduction_percent,
        mode=effective_mode,
    )


def _add_code_first_instruction(prompt: str) -> str:
    """Add code-first instruction to prompt."""
    if "Show code first" not in prompt:
        # Insert after the mode prefix
        import re

        return re.sub(
            r"^([A-Z_]+:)",
            r"\1 Show code first, then explain if necessary.",
            prompt,
        )
    return prompt


def _add_diff_mode_instruction(prompt: str) -> str:
    """Add diff mode instruction to prompt."""
    if "diff format" not in prompt and "minimal changes" not in prompt:
        return prompt + "\nUse diff format for file changes when possible."
    return prompt


def _add_explanation_limit_instruction(prompt: str, max_words: int) -> str:
    """Add explanation limit instruction to prompt."""
    if "words" not in prompt and "brief" not in prompt:
        return prompt + f"\nLimit explanations to {max_words} words maximum."
    return prompt


def _estimate_response_reduction(
    original_prompt: str,
    mode: OptimizationMode,
    model: str,
) -> dict[str, Any]:
    """
    Estimate the total token reduction including response.

    Since we can't know the actual response size, we estimate based on
    typical reduction rates for each mode.
    """
    input_tokens = estimate_tokens(original_prompt, model)

    # Estimate typical response sizes (rough averages)
    avg_response_multiplier = 3  # Response is typically 3x input
    estimated_response_before = input_tokens * avg_response_multiplier

    # Reduction factors based on mode
    reduction_factors = {
        OptimizationMode.ULTRA: 0.3,  # 70% reduction
        OptimizationMode.LITE: 0.5,  # 50% reduction
        OptimizationMode.VERBOSE: 0.9,  # 10% reduction
    }

    estimated_response_after = round(
        estimated_response_before * reduction_factors[mode]
    )

    total_before = input_tokens + estimated_response_before
    total_after = input_tokens + estimated_response_after
    saved = total_before - total_after
    percent = round((saved / total_before) * 100) if total_before > 0 else 0

    return {
        "before": total_before,
        "after": total_after,
        "saved": saved,
        "percent": percent,
    }


class Optimizer:
    """Optimizer instance with pre-loaded configuration."""

    def __init__(self, config: OptimizationConfig | None = None):
        """
        Create an optimizer instance.

        Args:
            config: Configuration to use (loads from disk if not provided)
        """
        self._config = config if config is not None else load_config()

    @property
    def config(self) -> OptimizationConfig:
        """Get the current configuration."""
        return self._config

    @config.setter
    def config(self, value: OptimizationConfig) -> None:
        """Set the configuration."""
        self._config = value

    @property
    def mode(self) -> OptimizationMode:
        """Get the current mode."""
        return self._config.mode

    @mode.setter
    def mode(self, value: OptimizationMode) -> None:
        """Set the optimization mode."""
        self._config.mode = value

    def optimize(
        self,
        prompt: str,
        mode: OptimizationMode | None = None,
        model: str = "default",
        skip_estimation: bool = False,
    ) -> OptimizationResult:
        """
        Optimize a prompt using the instance configuration.

        Args:
            prompt: User prompt to optimize
            mode: Override mode (uses instance mode if not provided)
            model: Model family for token estimation
            skip_estimation: Skip token estimation

        Returns:
            Optimization result
        """
        return optimize(
            prompt=prompt,
            config=self._config,
            mode=mode,
            model=model,
            skip_estimation=skip_estimation,
        )

    def reload_config(self, start_dir: str | None = None) -> None:
        """Reload configuration from disk."""
        self._config = load_config(start_dir)


def create_optimizer(config: OptimizationConfig | None = None) -> Optimizer:
    """Create a new optimizer instance."""
    return Optimizer(config)
