"""
Statistics tracking and persistence.

Tracks token usage, savings, and provides aggregated statistics.
Data is stored locally in JSON format.
"""

import json
import os
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, date
from pathlib import Path
from typing import Any

from ai_opt.modes import OptimizationMode
from ai_opt.token_estimator import format_token_count, format_cost, estimate_cost


@dataclass
class StatsRecord:
    """A single statistics record for a request."""

    id: str
    timestamp: str
    tool: str
    mode: str
    tokens_before: int
    tokens_after: int
    tokens_saved: int
    success: bool


@dataclass
class DailyStats:
    """Aggregated daily statistics."""

    date: str
    total_requests: int
    total_tokens_saved: int
    avg_reduction_percent: int
    by_mode: dict[str, int] = field(
        default_factory=lambda: {"ultra": 0, "lite": 0, "verbose": 0}
    )


@dataclass
class StatsStorage:
    """Statistics storage format."""

    version: str = "1.0"
    records: list[StatsRecord] = field(default_factory=list)
    daily_stats: list[DailyStats] = field(default_factory=list)


def get_stats_file_path() -> Path:
    """Get the stats file path."""
    if os.name == "nt":  # Windows
        base_dir = os.environ.get("APPDATA", "")
    else:
        base_dir = str(Path.home() / ".config")

    return Path(base_dir) / "ai-optimize" / "stats.json"


def _ensure_stats_dir() -> None:
    """Ensure the stats directory exists."""
    stats_path = get_stats_file_path()
    stats_path.parent.mkdir(parents=True, exist_ok=True)


def load_stats() -> StatsStorage:
    """Load statistics from disk."""
    stats_path = get_stats_file_path()

    if not stats_path.exists():
        return StatsStorage()

    try:
        content = stats_path.read_text(encoding="utf-8")
        data = json.loads(content)

        records = [StatsRecord(**r) for r in data.get("records", [])]
        daily_stats = [DailyStats(**d) for d in data.get("daily_stats", [])]

        return StatsStorage(
            version=data.get("version", "1.0"),
            records=records,
            daily_stats=daily_stats,
        )
    except Exception:
        return StatsStorage()


def save_stats(storage: StatsStorage) -> None:
    """Save statistics to disk."""
    _ensure_stats_dir()
    stats_path = get_stats_file_path()

    data = {
        "version": storage.version,
        "records": [asdict(r) for r in storage.records],
        "daily_stats": [asdict(d) for d in storage.daily_stats],
    }

    stats_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _generate_id() -> str:
    """Generate a unique ID for a stats record."""
    return f"{int(datetime.now().timestamp())}-{uuid.uuid4().hex[:7]}"


def _get_today_string() -> str:
    """Get today's date string in YYYY-MM-DD format."""
    return date.today().isoformat()


def record_request(
    tool: str,
    mode: OptimizationMode,
    tokens_before: int,
    tokens_after: int,
    success: bool = True,
) -> StatsRecord:
    """Record a new optimization request."""
    record = StatsRecord(
        id=_generate_id(),
        timestamp=datetime.now().isoformat(),
        tool=tool,
        mode=mode.value,
        tokens_before=tokens_before,
        tokens_after=tokens_after,
        tokens_saved=max(0, tokens_before - tokens_after),
        success=success,
    )

    storage = load_stats()
    storage.records.append(record)

    # Update daily stats
    _update_daily_stats(storage, record)

    # Keep only last 30 days of records
    cutoff = datetime.now().timestamp() - (30 * 24 * 60 * 60)
    storage.records = [
        r for r in storage.records if datetime.fromisoformat(r.timestamp).timestamp() > cutoff
    ]

    cutoff_date = date.fromtimestamp(cutoff).isoformat()
    storage.daily_stats = [d for d in storage.daily_stats if d.date >= cutoff_date]

    save_stats(storage)

    return record


def _update_daily_stats(storage: StatsStorage, record: StatsRecord) -> None:
    """Update daily statistics with a new record."""
    date_str = _get_today_string()

    daily = next((d for d in storage.daily_stats if d.date == date_str), None)

    if daily is None:
        daily = DailyStats(
            date=date_str,
            total_requests=0,
            total_tokens_saved=0,
            avg_reduction_percent=0,
            by_mode={"ultra": 0, "lite": 0, "verbose": 0},
        )
        storage.daily_stats.append(daily)

    daily.total_requests += 1
    daily.total_tokens_saved += record.tokens_saved
    daily.by_mode[record.mode] = daily.by_mode.get(record.mode, 0) + 1

    # Recalculate average reduction
    today_records = [
        r for r in storage.records if r.timestamp.startswith(date_str)
    ]

    if today_records:
        total_reduction = sum(
            (r.tokens_saved / r.tokens_before * 100) if r.tokens_before > 0 else 0
            for r in today_records
        )
        daily.avg_reduction_percent = round(total_reduction / len(today_records))


def get_today_stats() -> DailyStats | None:
    """Get statistics for today."""
    storage = load_stats()
    today = _get_today_string()
    return next((d for d in storage.daily_stats if d.date == today), None)


def get_recent_stats(days: int = 7) -> list[DailyStats]:
    """Get statistics for the last N days."""
    storage = load_stats()
    cutoff = date.fromtimestamp(
        datetime.now().timestamp() - (days * 24 * 60 * 60)
    ).isoformat()

    return sorted(
        [d for d in storage.daily_stats if d.date >= cutoff],
        key=lambda d: d.date,
        reverse=True,
    )


@dataclass
class AggregateStats:
    """Aggregated statistics result."""

    total_requests: int
    total_tokens_saved: int
    avg_reduction_percent: int
    estimated_cost_saved: float
    by_mode: dict[str, dict[str, int]]


def get_aggregate_stats(days: int = 30) -> AggregateStats:
    """Get aggregate statistics."""
    recent_stats = get_recent_stats(days)

    total_requests = sum(d.total_requests for d in recent_stats)
    total_tokens_saved = sum(d.total_tokens_saved for d in recent_stats)

    avg_reduction_percent = (
        round(sum(d.avg_reduction_percent for d in recent_stats) / len(recent_stats))
        if recent_stats
        else 0
    )

    by_mode: dict[str, dict[str, int]] = {
        "ultra": {"requests": 0, "tokens_saved": 0},
        "lite": {"requests": 0, "tokens_saved": 0},
        "verbose": {"requests": 0, "tokens_saved": 0},
    }

    for daily in recent_stats:
        for mode_name in by_mode:
            by_mode[mode_name]["requests"] += daily.by_mode.get(mode_name, 0)

    # Estimate cost saved
    estimated_cost_saved = estimate_cost(0, total_tokens_saved)

    return AggregateStats(
        total_requests=total_requests,
        total_tokens_saved=total_tokens_saved,
        avg_reduction_percent=avg_reduction_percent,
        estimated_cost_saved=estimated_cost_saved,
        by_mode=by_mode,
    )


def format_stats(days: int = 30) -> str:
    """Format statistics for display."""
    stats = get_aggregate_stats(days)
    today = get_today_stats()

    lines = [
        "AI Token Optimizer - Usage Statistics",
        "=====================================",
        "",
        f"Overall (Last {days} days)",
        f"  Total Requests:        {stats.total_requests}",
        f"  Tokens Saved:          {format_token_count(stats.total_tokens_saved)}",
        f"  Average Reduction:     {stats.avg_reduction_percent}%",
        f"  Estimated Savings:     {format_cost(stats.estimated_cost_saved)}",
        "",
        "By Mode",
        f"  Ultra:    {stats.by_mode['ultra']['requests']} requests",
        f"  Lite:     {stats.by_mode['lite']['requests']} requests",
        f"  Verbose:  {stats.by_mode['verbose']['requests']} requests",
    ]

    if today:
        lines.extend([
            "",
            "Today",
            f"  Requests:              {today.total_requests}",
            f"  Tokens Saved:          {format_token_count(today.total_tokens_saved)}",
            f"  Average Reduction:     {today.avg_reduction_percent}%",
        ])

    return "\n".join(lines)


def reset_stats() -> None:
    """Reset all statistics."""
    save_stats(StatsStorage())


def export_stats_json() -> str:
    """Export statistics as JSON."""
    storage = load_stats()
    return json.dumps(asdict(storage), indent=2, default=str)


def export_stats_csv() -> str:
    """Export statistics as CSV."""
    storage = load_stats()
    header = "timestamp,tool,mode,tokens_before,tokens_after,tokens_saved,success"
    rows = [
        f"{r.timestamp},{r.tool},{r.mode},{r.tokens_before},{r.tokens_after},{r.tokens_saved},{r.success}"
        for r in storage.records
    ]
    return "\n".join([header, *rows])
