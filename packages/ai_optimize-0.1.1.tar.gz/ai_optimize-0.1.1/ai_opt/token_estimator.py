"""
Token estimation utilities.

Provides approximate token counts for text without requiring
external tokenizer libraries.
"""

import re
from dataclasses import dataclass

# Average characters per token for different model families
DEFAULT_CHARS_PER_TOKEN = 3.75
CHARS_PER_TOKEN: dict[str, float] = {
    "claude": 3.5,
    "openai": 4.0,
    "default": DEFAULT_CHARS_PER_TOKEN,
}


@dataclass
class TokenDifference:
    """Result of calculating token difference between two texts."""

    before: int
    after: int
    saved: int
    percent: int


def estimate_tokens(text: str, model: str = "default") -> int:
    """
    Estimate the number of tokens in a text string.

    Uses a simple character-based estimation. For more accurate results
    with specific models, use the model-specific estimation functions.

    Args:
        text: The text to estimate tokens for
        model: Optional model family for more accurate estimation

    Returns:
        Estimated token count
    """
    if not text:
        return 0

    chars_per_token = CHARS_PER_TOKEN.get(model, DEFAULT_CHARS_PER_TOKEN)
    estimate = -(-len(text) // int(chars_per_token))  # Ceiling division

    # Add overhead for whitespace and special characters
    whitespace_count = len(re.findall(r"\s+", text))
    special_char_count = len(re.findall(r"[^\w\s]", text))
    overhead = -(-int((whitespace_count + special_char_count) * 0.1) // 1)

    return estimate + overhead


def estimate_claude_tokens(text: str) -> int:
    """Estimate tokens for Claude models specifically."""
    return estimate_tokens(text, "claude")


def estimate_openai_tokens(text: str) -> int:
    """Estimate tokens for OpenAI models specifically."""
    return estimate_tokens(text, "openai")


def calculate_token_difference(
    original: str,
    optimized: str,
    model: str = "default",
) -> TokenDifference:
    """
    Calculate the token difference between two texts.

    Args:
        original: Original text
        optimized: Optimized text
        model: Optional model family

    Returns:
        TokenDifference with before, after, saved, and percent values
    """
    before = estimate_tokens(original, model)
    after = estimate_tokens(optimized, model)
    saved = max(0, before - after)
    percent = round((saved / before) * 100) if before > 0 else 0

    return TokenDifference(before=before, after=after, saved=saved, percent=percent)


def format_token_count(count: int) -> str:
    """
    Format a token count for display.

    Args:
        count: Token count

    Returns:
        Formatted string (e.g., "1.2K" for 1200)
    """
    if count >= 1_000_000:
        return f"{count / 1_000_000:.1f}M"
    if count >= 1_000:
        return f"{count / 1_000:.1f}K"
    return str(count)


def estimate_cost(input_tokens: int, output_tokens: int = 0) -> float:
    """
    Estimate cost based on token count.

    Uses approximate pricing for Claude API.
    Input: $3 per million tokens, Output: $15 per million tokens

    Args:
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens (estimated)

    Returns:
        Estimated cost in USD
    """
    input_cost = (input_tokens / 1_000_000) * 3
    output_cost = (output_tokens / 1_000_000) * 15
    return round(input_cost + output_cost, 4)


def format_cost(cost: float) -> str:
    """
    Format a cost value for display.

    Args:
        cost: Cost in USD

    Returns:
        Formatted string (e.g., "$0.12")
    """
    if cost < 0.01:
        return f"${cost:.4f}"
    return f"${cost:.2f}"
