"""Tests for optimization modes."""

import pytest
from ai_opt.modes import (
    OptimizationMode,
    get_mode_prefix,
    get_mode_description,
    is_valid_mode,
    parse_mode,
    get_available_modes,
)


class TestOptimizationMode:
    def test_modes_exist(self):
        assert OptimizationMode.ULTRA.value == "ultra"
        assert OptimizationMode.LITE.value == "lite"
        assert OptimizationMode.VERBOSE.value == "verbose"


class TestGetModePrefix:
    def test_ultra_prefix(self):
        prefix = get_mode_prefix(OptimizationMode.ULTRA)
        assert "CODE_ONLY" in prefix

    def test_lite_prefix(self):
        prefix = get_mode_prefix(OptimizationMode.LITE)
        assert "CONCISE" in prefix

    def test_verbose_prefix(self):
        prefix = get_mode_prefix(OptimizationMode.VERBOSE)
        assert "DETAILED" in prefix


class TestGetModeDescription:
    def test_descriptions_exist(self):
        assert get_mode_description(OptimizationMode.ULTRA)
        assert get_mode_description(OptimizationMode.LITE)
        assert get_mode_description(OptimizationMode.VERBOSE)


class TestIsValidMode:
    def test_valid_modes(self):
        assert is_valid_mode("ultra")
        assert is_valid_mode("lite")
        assert is_valid_mode("verbose")

    def test_invalid_modes(self):
        assert not is_valid_mode("invalid")
        assert not is_valid_mode("")
        assert not is_valid_mode("super")

    def test_case_insensitive(self):
        # is_valid_mode is case-insensitive
        assert is_valid_mode("ULTRA")
        assert is_valid_mode("Lite")
        assert is_valid_mode("VERBOSE")


class TestParseMode:
    def test_parse_valid_mode(self):
        assert parse_mode("ultra") == OptimizationMode.ULTRA
        assert parse_mode("lite") == OptimizationMode.LITE
        assert parse_mode("verbose") == OptimizationMode.VERBOSE

    def test_parse_case_insensitive(self):
        assert parse_mode("ULTRA") == OptimizationMode.ULTRA
        assert parse_mode("Lite") == OptimizationMode.LITE

    def test_parse_invalid_raises(self):
        with pytest.raises(ValueError):
            parse_mode("invalid")


class TestGetAvailableModes:
    def test_returns_all_modes(self):
        modes = get_available_modes()
        assert len(modes) == 3
        assert OptimizationMode.ULTRA in modes
        assert OptimizationMode.LITE in modes
        assert OptimizationMode.VERBOSE in modes
