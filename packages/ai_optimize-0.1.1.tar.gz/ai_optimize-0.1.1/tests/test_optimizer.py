"""Tests for the optimizer module."""

from ai_opt.optimizer import optimize, Optimizer, create_optimizer
from ai_opt.config import OptimizationConfig, DEFAULT_CONFIG
from ai_opt.modes import OptimizationMode


class TestOptimize:
    def test_prepends_mode_prefix(self):
        result = optimize("Fix the bug", DEFAULT_CONFIG)
        assert "Fix the bug" in result.optimized_prompt
        assert len(result.optimized_prompt) > len("Fix the bug")

    def test_ultra_mode(self):
        result = optimize("Fix the bug", mode=OptimizationMode.ULTRA)
        assert "CODE_ONLY" in result.optimized_prompt
        assert result.mode == OptimizationMode.ULTRA

    def test_lite_mode(self):
        result = optimize("Fix the bug", mode=OptimizationMode.LITE)
        assert "CONCISE" in result.optimized_prompt
        assert result.mode == OptimizationMode.LITE

    def test_verbose_mode(self):
        result = optimize("Explain this", mode=OptimizationMode.VERBOSE)
        assert "DETAILED" in result.optimized_prompt
        assert result.mode == OptimizationMode.VERBOSE

    def test_preserves_original_prompt(self):
        original = "My original prompt"
        result = optimize(original)
        assert result.original_prompt == original

    def test_returns_token_estimates(self):
        result = optimize("A test prompt")
        assert result.estimated_tokens_before > 0
        assert result.estimated_tokens_after > 0
        assert isinstance(result.tokens_saved, int)
        assert isinstance(result.reduction_percent, int)

    def test_skip_estimation(self):
        result = optimize("Test", skip_estimation=True)
        assert result.estimated_tokens_before == 0
        assert result.estimated_tokens_after == 0


class TestOptimizerClass:
    def test_creates_with_default_config(self):
        optimizer = Optimizer()
        assert optimizer.mode == OptimizationMode.LITE

    def test_creates_with_custom_config(self):
        config = OptimizationConfig(mode=OptimizationMode.ULTRA)
        optimizer = Optimizer(config)
        assert optimizer.mode == OptimizationMode.ULTRA

    def test_mode_property(self):
        optimizer = Optimizer()
        optimizer.mode = OptimizationMode.VERBOSE
        assert optimizer.mode == OptimizationMode.VERBOSE

    def test_optimize_uses_instance_config(self):
        optimizer = Optimizer()
        optimizer.mode = OptimizationMode.ULTRA
        result = optimizer.optimize("Test prompt")
        assert result.mode == OptimizationMode.ULTRA

    def test_optimize_respects_mode_override(self):
        optimizer = Optimizer()
        optimizer.mode = OptimizationMode.ULTRA
        result = optimizer.optimize("Test", mode=OptimizationMode.VERBOSE)
        assert result.mode == OptimizationMode.VERBOSE


class TestCreateOptimizer:
    def test_creates_optimizer(self):
        optimizer = create_optimizer()
        assert isinstance(optimizer, Optimizer)

    def test_creates_with_custom_config(self):
        config = OptimizationConfig(mode=OptimizationMode.VERBOSE)
        optimizer = create_optimizer(config)
        assert optimizer.mode == OptimizationMode.VERBOSE
