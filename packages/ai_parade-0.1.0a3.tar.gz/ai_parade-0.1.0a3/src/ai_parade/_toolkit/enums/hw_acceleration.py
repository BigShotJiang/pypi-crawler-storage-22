from enum import StrEnum


class HardwareAcceleration(StrEnum):
	"""Enumeration for hardware acceleration options."""

	CPU = "CPU"
	GPU = "GPU"
	XNNPACK = "XNNPACK"
	NNAPI = "NNAPI"
	QNN = "QNN"
	Vulkan = "Vulkan"
	OpenGLES = "OpenGLES"
	OpenCL = "OpenCL"
	Mediatek = "Mediatek"
	Metal = "Metal"
	CoreML = "CoreML"
	GoogleTensor = "GoogleTensor"
	Exynos = "Exynos"
