from ..enums import (
	AIRuntime,
	HardwareAcceleration,
	ModelFormat,
	Platform,
	Quantization,
)
from ._common import ModelAttributes

runtime = AIRuntime.ExecuTorch
capabilities = {
	Platform.Android: {
		Quantization.none: {
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.Vulkan,
			HardwareAcceleration.QNN,
			# HardwareAcceleration.Exynos
			# HardwareAcceleration.Mediatek
		},
		Quantization.int8: {
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.Vulkan,
			HardwareAcceleration.QNN,
			# HardwareAcceleration.Exynos
			# HardwareAcceleration.Mediatek
		},
		Quantization.float16: {
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.Vulkan,
			HardwareAcceleration.QNN,
			# HardwareAcceleration.Exynos
			# HardwareAcceleration.Mediatek
		},
	},
	Platform.IOS: {
		Quantization.none: {
			HardwareAcceleration.XNNPACK,
			# HardwareAcceleration.Metal
			# HardwareAcceleration.CoreML
		},
		Quantization.int8: {
			HardwareAcceleration.XNNPACK,
			# HardwareAcceleration.Metal
			# HardwareAcceleration.CoreML
		},
		Quantization.float16: {
			HardwareAcceleration.XNNPACK,
			# HardwareAcceleration.Metal
			# HardwareAcceleration.CoreML
		},
	},
}

format = ModelFormat.ExecutorTorch
format_distinguishes = [ModelAttributes.Quantization, ModelAttributes.HWAcceleration]
