import filecmp
from pathlib import Path


def setup_cwd_any(tmp_path: Path, monkeypatch, repo_path: Path, skip: list[str] = []):
	skip = skip + ["build"]
	for item in (Path(__file__).parent.parent / repo_path).iterdir():
		if item.name in skip:
			continue
		(tmp_path / item.name).symlink_to(item.resolve())

	monkeypatch.chdir(tmp_path)
	monkeypatch.setenv("VIRTUAL_ENV", str(tmp_path / ".venv"))


def text_files_equal(expected: Path, actual: Path) -> None:
	"""Assert that text files at expected and actual paths are identical."""
	from difflib import unified_diff

	with open(expected, "r") as expected_file, open(actual, "r") as actual_file:
		diff = list(
			unified_diff(
				expected_file.readlines(),
				actual_file.readlines(),
				fromfile=str(expected),
				tofile=str(actual),
			)
		)
		assert diff == [], "Unexpected file contents:\n" + "".join(diff)


def files_equal(expected: Path, actual: Path) -> None:
	"""Assert that files/directories at expected and actual paths are identical."""
	if expected.is_file():
		assert filecmp.cmp(expected, actual, shallow=False)

	if expected.is_dir():
		for child in sorted(expected.iterdir()):
			assert child.is_file(), f"Nested directories are not supported: {child}"
			assert filecmp.cmp(child, actual / child.name, shallow=False), (
				f"Artifact mismatch for {expected} vs {actual}"
			)
