from pathlib import Path

import pytest
from typer.testing import CliRunner

from ai_parade._cli.ai_parade.main import app

from ._common import setup_cwd_any

runner = CliRunner()


class TestInference:
	repo_path = Path("fixtures/FooBarModel")

	@pytest.fixture(autouse=True)
	def copy_repo(self, tmp_path, monkeypatch):
		setup_cwd_any(
			tmp_path,
			monkeypatch,
			repo_path=self.repo_path,
			skip=[],
		)

	@pytest.mark.parametrize(
		[
			"args",
		],
		[
			pytest.param(*p, id=" ".join(p[0].split()[1:-1]))
			for p in [
				("inference weights.pth FooBarModel --separate-env",),
				("inference models/onnx.float32.all.onnx.json --separate-env",),
				("inference models/onnx.float16.all.onnx.json --separate-env",),
				("inference models/onnx.int8.all.onnx.json --separate-env",),
			]
		],
	)
	def test_inference(self, args):
		result = runner.invoke(app, [*args.split(" ")])

		assert result.exit_code == 0

	@pytest.mark.parametrize(
		[
			"args",
		],
		[
			pytest.param(*p, id=" ".join(p[0].split()[1:-3]))
			for p in [
				("inference weights.pth FooBarModel -o output.json",),
				(
					"inference models/onnx.float32.all.onnx.json -o output.json --separate-env",
				),
			]
		],
	)
	def test_inference_output(self, args):
		result = runner.invoke(app, [*args.split(" ")])

		assert result.exit_code == 0

		assert Path("output.json").exists()
