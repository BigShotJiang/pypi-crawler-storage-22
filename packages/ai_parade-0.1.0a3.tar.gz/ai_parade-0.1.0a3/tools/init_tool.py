from src import ModelFormat
from src.data.imageInput import ImageInput


def get_DL_Lib_preset(dl_lib: ModelFormat):
	ii = ImageInput()
	ii.channelOrder = ImageInput.ChannelOrder.RGB
	ii.batchSize = 1

	match dl_lib:
		case ModelFormat.TensorFlow:
			ii.dataOrder = ImageInput.DataOrder.NHWC
		case ModelFormat.PyTorch:
			ii.dataOrder = ImageInput.DataOrder.NCHW
