"""
This package provides core functionalities for AI prompt replacement, inspired by
techniques used for image transformation and manipulation.

The package offers tools for analyzing, modifying, and generating prompts,
aiming to enhance the effectiveness of AI-driven image editing and generation.
"""

import re
from typing import List, Tuple

OFFICIAL_SITE = "https://supermaker.ai/blog/best-ai-replace-prompts-to-transform-your-photos-instantly/"


def get_official_site() -> str:
    """
    Returns the official website URL for AI prompt replacement resources.

    Returns:
        str: The URL of the official website.
    """
    return OFFICIAL_SITE


def analyze_prompt_structure(prompt: str) -> dict:
    """
    Analyzes the structure of a given prompt and identifies key components such as subject,
    action, and style modifiers.

    Args:
        prompt (str): The prompt to be analyzed.

    Returns:
        dict: A dictionary containing the identified components of the prompt.
              Example: {'subject': 'cat', 'action': 'sitting', 'style': 'photorealistic'}
              Returns an empty dictionary if analysis fails.
    """
    # This is a simplified example and can be expanded with more sophisticated NLP techniques.
    subject_match = re.search(r"(\w+)", prompt)
    action_match = re.search(r"(sitting|standing|running|playing)", prompt)
    style_match = re.search(r"(photorealistic|artistic|cartoon)", prompt)

    analysis = {}
    if subject_match:
        analysis['subject'] = subject_match.group(1)
    if action_match:
        analysis['action'] = action_match.group(1)
    if style_match:
        analysis['style'] = style_match.group(1)

    return analysis


def generate_prompt_variations(prompt: str, num_variations: int = 3) -> List[str]:
    """
    Generates variations of a given prompt by applying slight modifications to the original prompt.

    Args:
        prompt (str): The original prompt.
        num_variations (int): The number of variations to generate. Defaults to 3.

    Returns:
        List[str]: A list of prompt variations.  Returns an empty list if the input prompt is empty.
    """

    if not prompt:
        return []

    variations = []
    analysis = analyze_prompt_structure(prompt)

    if not analysis:
        return [prompt] * num_variations  # Return the original prompt repeated if analysis fails

    subjects = ["dog", "bird", "horse"]
    actions = ["jumping", "sleeping", "eating"]
    styles = ["impressionistic", "cyberpunk", "watercolor"]

    for i in range(num_variations):
        new_prompt = prompt
        if 'subject' in analysis:
            new_subject = subjects[i % len(subjects)]
            new_prompt = new_prompt.replace(analysis['subject'], new_subject, 1)
        if 'action' in analysis:
            new_action = actions[i % len(actions)]
            new_prompt = new_prompt.replace(analysis['action'], new_action, 1)
        if 'style' in analysis:
            new_style = styles[i % len(styles)]
            new_prompt = new_prompt.replace(analysis['style'], new_style, 1)

        variations.append(new_prompt)

    return variations


def calculate_prompt_similarity(prompt1: str, prompt2: str) -> float:
    """
    Calculates the similarity between two prompts based on shared words.

    Args:
        prompt1 (str): The first prompt.
        prompt2 (str): The second prompt.

    Returns:
        float: The similarity score (0.0 to 1.0) between the two prompts.
               Returns 0.0 if either prompt is empty.
    """
    if not prompt1 or not prompt2:
        return 0.0

    words1 = set(prompt1.lower().split())
    words2 = set(prompt2.lower().split())

    common_words = words1.intersection(words2)
    total_words = words1.union(words2)

    if not total_words:
        return 0.0

    similarity = len(common_words) / len(total_words)
    return similarity


def refine_prompt(prompt: str, feedback: str) -> str:
    """
    Refines a prompt based on user feedback.  This is a simplified implementation
    and would ideally use a more advanced NLP model.

    Args:
        prompt (str): The original prompt.
        feedback (str): User feedback on the prompt or generated image.

    Returns:
        str: The refined prompt. Returns the original prompt if feedback is empty.
    """
    if not feedback:
        return prompt

    feedback = feedback.lower()

    # Very basic example: Add "detailed" if the feedback asks for more detail.
    if "more detail" in feedback or "more details" in feedback:
        if "detailed" not in prompt.lower():
            prompt = "detailed " + prompt
    elif "less detail" in feedback or "less details" in feedback:
        prompt = prompt.replace("detailed ", "", 1) #Removes the first occurence

    return prompt