from setuptools import setup, find_packages

setup(
    name="ai-replace-prompt",
    version="1770195.248.27",
    description="High-quality integration for https://supermaker.ai/blog/best-ai-replace-prompts-to-transform-your-photos-instantly/",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="SuperMaker",
    url="https://supermaker.ai/blog/best-ai-replace-prompts-to-transform-your-photos-instantly/",
    packages=find_packages(),
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
