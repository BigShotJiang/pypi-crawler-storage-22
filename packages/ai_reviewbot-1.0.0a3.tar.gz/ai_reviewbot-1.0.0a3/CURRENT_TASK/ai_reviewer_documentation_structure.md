# 📘 AI Reviewer — Documentation Structure & Guidelines

Цей документ описує рекомендовану структуру документації для модуля **AI Reviewer**, який інтегрується в CI-процеси **GitHub** та **GitLab** і автоматично створює code review під час PR/MR.

Мета документації — бути **максимально user‑friendly**, знижувати поріг входу та плавно вести користувача від "просто спробувати" до "глибоко кастомізувати або розширювати".

---

## 🎯 Ключові принципи

1. **Читач не хоче читати** — він хоче, щоб інструмент запрацював якомога швидше.
2. **Шаруватість** — від мінімального використання до глибокої кастомізації.
3. **Платформна прозорість** — GitHub і GitLab різні, але базовий UX має бути однаковим.
4. **Пріоритет користувача над реалізацією** — спочатку "що буде", а не "як це реалізовано".

---

## 🧭 Загальна структура документації

```text
README.md
/docs
  quick-start.md
  configuration.md
  github.md
  gitlab.md
  error-handling.md
  advanced.md
  /development
    architecture.md
    flow.md
    exceptions.md
    logging.md
    ai-integration.md
    extending.md
/examples
  /github
  /gitlab
```

---

## 0️⃣ README.md — Landing Page

**Це найважливіший файл.** Він має відповідати на питання:
> “Що це?” і “Як мені спробувати це за 30 секунд?”

### Рекомендована структура README

### 🔹 What is AI Reviewer?
Короткий опис:
- що робить інструмент
- коли запускається (PR/MR)
- які джерела контексту аналізує (diff, опис, коментарі)
- що саме публікує як результат

### 🔹 What you get
Маркований список переваг:
- code quality feedback
- potential bugs
- best practices
- context‑aware review

### 🔹 Quick Start (30 seconds)
Один **мінімальний приклад** для GitHub або GitLab — без пояснень.

### 🔹 Supported platforms
- GitHub Actions
- GitLab CI
- self‑hosted runners

### 🔹 How it works
Короткий список кроків або проста схема:
1. Trigger (PR/MR)
2. Collect context
3. Run AI analysis
4. Post review

### 🔹 Links
- Configuration
- Examples
- FAQ

---

## 1️⃣ Quick Start
**docs/quick-start.md**

Документ для копіпасти. Мінімум тексту.

### GitHub
- GitHub Action (Marketplace)
- Docker image

### GitLab
- Docker image у `.gitlab-ci.yml`

👉 Без опцій, без нюансів — лише "працює з дефолтами".

---

## 2️⃣ Configuration Guide
**docs/configuration.md**

Для користувачів, які хочуть керувати поведінкою AI, але не лізти в код.

### 🔹 Configuration sources
- environment variables
- yaml options
- default values

### 🔹 Common options
- пріоритет мов
- глибина ревʼю
- strict / lenient mode
- max tokens
- fail_on_error

### 🔹 AI behavior
- prompts
- tone (friendly / strict)
- focus areas

### 🔹 CI behavior
- retry policy
- fail vs warn
- comment vs annotation

> ⚠️ Тут **не показуємо класи** — лише ефект для користувача.

---

## 3️⃣ Platform‑specific documentation

### 📄 docs/github.md
- Permissions
- PR triggers
- Workflow annotations
- Secrets
- GitHub‑specific limitations

### 📄 docs/gitlab.md
- MR triggers
- Job tokens
- API permissions
- GitLab‑specific differences

👉 Це знімає більшість питань типу "чому в нас не так".

---

## 4️⃣ Examples

Живі, робочі приклади.

```text
examples/
  github/
    minimal.yml
    advanced.yml
    custom-prompts.yml
  gitlab/
    minimal.yml
    advanced.yml
    self-hosted.yml
```

Кожна папка містить `README.md` з поясненням:
> “Що робить цей приклад і коли його використовувати”.

---

## 5️⃣ Error Handling & UX Behavior
**docs/error-handling.md**

Критично важливий документ для довіри користувача.

Описати:
- що відбувається, якщо:
  - AI API недоступний
  - rate limit
  - GitHub/GitLab API недоступний
- де користувач побачить повідомлення:
  - PR/MR comment
  - workflow annotation (GitHub)
  - CI logs
- чи падає pipeline

---

## 6️⃣ Advanced Usage
**docs/advanced.md**

Для power users:
- custom prompts
- multi‑step / multi‑agent review
- partial reviews
- dry‑run
- local execution

---

## 7️⃣ Developer Documentation
**docs/development/**

Окремий світ для тих, хто хоче створити власного бота або розширити функціональність.

### Рекомендовані файли
- `architecture.md` — загальна архітектура
- `flow.md` — життєвий цикл ревʼю
- `exceptions.md` — ієрархія помилок
- `logging.md` — логування і CI‑поведінка
- `ai-integration.md` — робота з LLM
- `extending.md` — як додати новий SCM або AI provider

---

## 8️⃣ API / Code Reference (опційно)

- auto‑generated документація (mkdocs / pdoc)
- **не змішувати з user docs**
- лише для тих, хто шукає

---

## 👥 Типи користувачів і їх шлях

| Користувач | Документ |
|-----------|----------|
| Хочу швидко | README → Quick Start |
| Хочу налаштувати | Configuration + Examples |
| GitHub / GitLab специфіка | platform docs |
| Щось зламалось | Error handling |
| Хочу свій бот | Development docs |

---

## 🧠 Підсумок

Добра документація для AI Reviewer — це:
- мінімум барʼєрів на старті
- прозора поведінка в CI
- чітке розділення user / advanced / dev рівнів
- довіра користувача навіть у випадку помилок

Ця структура дозволяє масштабувати як **продукт**, а не просто бібліотеку.
