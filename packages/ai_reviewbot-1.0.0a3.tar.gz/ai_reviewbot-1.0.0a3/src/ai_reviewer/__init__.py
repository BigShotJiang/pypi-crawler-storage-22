"""AI Code Reviewer - Autonomous AI agent for intelligent code review."""

__version__ = "0.1.0"
