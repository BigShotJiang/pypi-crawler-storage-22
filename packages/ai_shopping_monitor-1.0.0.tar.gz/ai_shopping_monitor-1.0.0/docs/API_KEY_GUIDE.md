# DeepSeek API 密钥获取指南

本指南将帮助你获取 DeepSeek API 密钥，这是使用 AI Agent 显卡监控系统的必要步骤。

## 目录

- [什么是 DeepSeek API](#什么是-deepseek-api)
- [注册账号](#注册账号)
- [创建 API 密钥](#创建-api-密钥)
- [配置 API 密钥](#配置-api-密钥)
- [验证 API 密钥](#验证-api-密钥)
- [API 使用限制](#api-使用限制)
- [费用说明](#费用说明)
- [常见问题](#常见问题)

## 什么是 DeepSeek API

DeepSeek API 是一个大语言模型 API 服务，提供强大的自然语言理解和生成能力。本系统使用 DeepSeek API 来：

- 理解 Best Buy 页面内容
- 识别显卡产品（排除整机和配件）
- 检测库存状态
- 提取价格信息
- 定位购买按钮

相比传统的规则匹配方案，AI 能够更准确地理解页面语义，提供更强的鲁棒性。

## 注册账号

### 步骤 1: 访问 DeepSeek 官网

打开浏览器，访问 [DeepSeek 官网](https://platform.deepseek.com/)

### 步骤 2: 点击注册

1. 点击页面右上角的 "Sign Up" 或 "注册" 按钮
2. 选择注册方式：
   - 邮箱注册（推荐）
   - 手机号注册
   - 第三方账号登录（GitHub、Google 等）

### 步骤 3: 填写注册信息

如果选择邮箱注册：
1. 输入邮箱地址
2. 设置密码（至少 8 位，包含字母和数字）
3. 输入验证码
4. 同意服务条款
5. 点击 "注册" 按钮

### 步骤 4: 验证邮箱

1. 检查你的邮箱收件箱
2. 找到来自 DeepSeek 的验证邮件
3. 点击邮件中的验证链接
4. 完成邮箱验证

### 步骤 5: 完善个人信息

1. 登录 DeepSeek 平台
2. 完善个人资料（可选）
3. 进入控制台

## 创建 API 密钥

### 步骤 1: 进入 API Keys 页面

1. 登录 DeepSeek 平台
2. 点击左侧菜单的 "API Keys" 或 "密钥管理"
3. 进入 API 密钥管理页面

### 步骤 2: 创建新密钥

1. 点击 "Create API Key" 或 "创建密钥" 按钮
2. 填写密钥信息：
   - **名称**: 给密钥起一个有意义的名称（如 "GPU Monitor"）
   - **权限**: 选择所需权限（通常选择 "Chat" 权限即可）
   - **有效期**: 选择密钥有效期（建议选择 "永久" 或较长时间）
3. 点击 "创建" 按钮

### 步骤 3: 保存密钥

**重要提示：API 密钥只会显示一次！**

1. 密钥创建成功后，会显示完整的 API 密钥
2. **立即复制并保存密钥**到安全的地方
3. 密钥格式通常为：`sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
4. 如果忘记保存，需要删除旧密钥并创建新密钥

### 步骤 4: 确认密钥状态

1. 在 API Keys 列表中，确认新密钥状态为 "Active" 或 "激活"
2. 记录密钥的创建时间和有效期
3. 如需禁用密钥，可以点击 "Disable" 按钮

## 配置 API 密钥

### 方式 1: 使用配置文件（推荐）

1. 创建或编辑配置文件 `config/config.json`：

```json
{
  "api_config": {
    "api_key": "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "base_url": "https://api.deepseek.com",
    "model_name": "deepseek-chat",
    "timeout": 30,
    "max_retries": 3,
    "temperature": 0.1
  }
}
```

2. 将 `sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` 替换为你的实际 API 密钥

### 方式 2: 使用环境变量

1. 设置环境变量：

**Windows (CMD):**
```cmd
set DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**Windows (PowerShell):**
```powershell
$env:DEEPSEEK_API_KEY="sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

**Linux/macOS:**
```bash
export DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

2. 在配置文件中引用环境变量：

```json
{
  "api_config": {
    "api_key": "${DEEPSEEK_API_KEY}"
  }
}
```

### 方式 3: 使用命令行参数

```bash
python main.py --api-key sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**注意：不推荐在命令行中直接使用密钥，因为会被记录在命令历史中。**

## 验证 API 密钥

### 方式 1: 使用系统自带验证

启动监控系统时，系统会自动验证 API 密钥：

```bash
python main.py
```

如果密钥有效，会显示：
```
✓ 配置加载成功
✓ 前提条件检查通过
```

如果密钥无效，会显示：
```
✗ API 密钥验证失败
```

### 方式 2: 使用测试脚本

创建测试脚本 `test_api_key.py`：

```python
from openai import OpenAI

# 替换为你的 API 密钥
api_key = "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

try:
    client = OpenAI(
        api_key=api_key,
        base_url="https://api.deepseek.com"
    )
    
    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=[{"role": "user", "content": "Hello"}],
        max_tokens=10
    )
    
    print("✓ API 密钥验证成功！")
    print(f"响应: {response.choices[0].message.content}")
    
except Exception as e:
    print(f"✗ API 密钥验证失败: {e}")
```

运行测试：
```bash
python test_api_key.py
```

## API 使用限制

### 速率限制

DeepSeek API 有以下速率限制：

- **免费版**:
  - 每分钟请求数: 60 次
  - 每天请求数: 1000 次
  - 每月 Token 数: 100,000 tokens

- **付费版**:
  - 每分钟请求数: 600 次
  - 每天请求数: 无限制
  - 每月 Token 数: 根据套餐而定

### 本系统的 API 使用量

- 每次检查约消耗 1-2 次 API 调用
- 每次调用约消耗 500-1000 tokens
- 检查间隔 30 秒，每小时约 120 次调用
- 每天约 2,880 次调用（超过免费额度）

**建议：**
- 使用付费版 API
- 或增加检查间隔（如 60 秒）以降低调用频率
- 或启用降级策略，在 API 配额不足时使用规则匹配

### 配置速率限制处理

系统已内置速率限制处理：

```json
{
  "api_config": {
    "max_retries": 3,
    "timeout": 30
  }
}
```

当遇到速率限制时，系统会：
1. 自动等待并重试（指数退避）
2. 最多重试 3 次
3. 如果仍然失败，切换到降级模式

## 费用说明

### 定价模型

DeepSeek API 采用按使用量计费：

- **输入 Token**: $0.14 / 1M tokens
- **输出 Token**: $0.28 / 1M tokens

### 成本估算

以每天运行 24 小时，检查间隔 30 秒为例：

- 每天调用次数: 2,880 次
- 每次输入 tokens: 约 800 tokens
- 每次输出 tokens: 约 200 tokens
- 每天总输入: 2,880 × 800 = 2,304,000 tokens
- 每天总输出: 2,880 × 200 = 576,000 tokens

**每天费用**:
- 输入费用: 2.304M × $0.14 = $0.32
- 输出费用: 0.576M × $0.28 = $0.16
- **总计: $0.48 / 天**

**每月费用**: 约 $14.40

### 降低成本的方法

1. **增加检查间隔**:
   - 从 30 秒改为 60 秒，费用减半
   - 从 30 秒改为 120 秒，费用减少 75%

2. **使用降级策略**:
   - 在非高峰时段使用 API
   - 在高峰时段使用规则匹配
   - 可节省 50% 以上费用

3. **优化 Prompt**:
   - 减少不必要的上下文
   - 使用更简洁的指令
   - 可节省 20-30% tokens

4. **仅在必要时使用 AI**:
   - 先用规则快速过滤
   - 只对可疑产品使用 AI 分析
   - 可节省 70% 以上费用

## 常见问题

### Q: API 密钥丢失了怎么办？

A: API 密钥只显示一次，如果丢失：
1. 登录 DeepSeek 平台
2. 进入 API Keys 页面
3. 删除旧密钥
4. 创建新密钥
5. 更新配置文件

### Q: 可以共享 API 密钥吗？

A: 不建议共享 API 密钥，因为：
- 所有使用该密钥的请求都会计入你的配额
- 如果密钥泄露，可能导致费用激增
- 无法追踪具体是谁在使用密钥

### Q: 如何监控 API 使用量？

A: 
1. 登录 DeepSeek 平台
2. 进入 "Usage" 或 "使用统计" 页面
3. 查看每日/每月的调用次数和 Token 消耗
4. 设置使用量警报

### Q: API 密钥被泄露了怎么办？

A: 立即采取以下措施：
1. 登录 DeepSeek 平台
2. 禁用或删除泄露的密钥
3. 创建新密钥
4. 更新所有使用该密钥的配置
5. 检查账单是否有异常消费

### Q: 为什么 API 调用失败？

A: 可能的原因：
1. **密钥无效**: 检查密钥是否正确复制
2. **配额不足**: 检查是否超过免费额度
3. **速率限制**: 等待一段时间后重试
4. **网络问题**: 检查网络连接
5. **服务故障**: 查看 DeepSeek 状态页面

### Q: 可以使用其他 LLM API 吗？

A: 理论上可以，但需要修改代码：
1. 修改 `src/ai_agent_engine.py` 中的 API 客户端
2. 调整 prompt 格式以适配新 API
3. 更新配置模型

支持的替代方案：
- OpenAI GPT-4
- Anthropic Claude
- Google Gemini
- 本地部署的开源模型

### Q: 如何优化 API 使用效率？

A: 
1. **启用降级策略**: 在 API 失败时使用规则匹配
2. **增加检查间隔**: 减少调用频率
3. **优化 Prompt**: 减少不必要的上下文
4. **缓存结果**: 对相同页面不重复分析
5. **批量处理**: 一次 API 调用分析多个产品

## 安全建议

1. **不要在代码中硬编码密钥**
2. **不要将包含密钥的配置文件提交到 Git**
3. **使用环境变量或密钥管理服务**
4. **定期轮换 API 密钥**
5. **监控 API 使用量，及时发现异常**
6. **为不同环境使用不同的密钥**
7. **设置使用量上限，避免费用失控**

## 相关链接

- [DeepSeek 官网](https://platform.deepseek.com/)
- [DeepSeek API 文档](https://platform.deepseek.com/docs)
- [DeepSeek 定价](https://platform.deepseek.com/pricing)
- [DeepSeek 状态页面](https://status.deepseek.com/)

---

如有其他问题，请查看 [完整使用指南](USAGE_GUIDE.md) 或联系技术支持。
