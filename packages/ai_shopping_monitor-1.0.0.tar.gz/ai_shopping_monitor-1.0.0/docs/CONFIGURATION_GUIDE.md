# 配置指南

本指南详细说明 AI Agent 显卡监控系统的所有配置选项。

## 目录

- [配置文件格式](#配置文件格式)
- [基础配置](#基础配置)
- [API 配置](#api-配置)
- [浏览器配置](#浏览器配置)
- [邮件配置](#邮件配置)
- [监控目标配置](#监控目标配置)
- [日志配置](#日志配置)
- [高级配置](#高级配置)
- [配置示例](#配置示例)
- [配置验证](#配置验证)
- [环境变量](#环境变量)

## 配置文件格式

系统支持两种配置文件格式：

### JSON 格式（推荐）

```json
{
  "check_interval": 30,
  "api_config": {
    "api_key": "sk-xxx"
  }
}
```

**优点**:
- 广泛支持
- 易于解析
- 无需额外依赖

**缺点**:
- 不支持注释
- 格式严格

### YAML 格式

```yaml
check_interval: 30
api_config:
  api_key: sk-xxx
```

**优点**:
- 支持注释
- 更易读
- 格式灵活

**缺点**:
- 需要 pyyaml 依赖
- 缩进敏感

## 基础配置

### check_interval

检查间隔（秒）

**类型**: 整数  
**默认值**: 30  
**范围**: 10 - 300  
**说明**: 每次检查之间的等待时间

```json
{
  "check_interval": 30
}
```

**建议**:
- 开发测试: 10-20 秒
- 正常使用: 30-60 秒
- 节省 API: 60-120 秒

### max_pages

最大检查页数

**类型**: 整数  
**默认值**: 3  
**范围**: 1 - 10  
**说明**: 搜索结果的最大页数

```json
{
  "max_pages": 3
}
```

**注意**: 页数越多，检查时间越长，API 调用越多

## API 配置

### api_key

DeepSeek API 密钥

**类型**: 字符串  
**必需**: 是  
**格式**: `sk-` 开头，约 48 个字符  
**说明**: 用于调用 DeepSeek API

```json
{
  "api_config": {
    "api_key": "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
  }
}
```

**获取方式**: 参考 [API 密钥获取指南](API_KEY_GUIDE.md)

### base_url

API 基础 URL

**类型**: 字符串  
**默认值**: `https://api.deepseek.com`  
**说明**: DeepSeek API 的基础 URL

```json
{
  "api_config": {
    "base_url": "https://api.deepseek.com"
  }
}
```

**使用场景**:
- 使用代理: `http://proxy.example.com/api`
- 使用镜像: `https://mirror.deepseek.com`

### model_name

模型名称

**类型**: 字符串  
**默认值**: `deepseek-chat`  
**可选值**: `deepseek-chat`, `deepseek-coder`  
**说明**: 使用的 DeepSeek 模型

```json
{
  "api_config": {
    "model_name": "deepseek-chat"
  }
}
```

**模型对比**:
- `deepseek-chat`: 通用对话模型，适合页面理解
- `deepseek-coder`: 代码专用模型，不推荐用于本系统

### timeout

API 超时时间

**类型**: 整数  
**默认值**: 30  
**范围**: 10 - 120  
**单位**: 秒  
**说明**: API 调用的最大等待时间

```json
{
  "api_config": {
    "timeout": 30
  }
}
```

**建议**:
- 网络好: 20-30 秒
- 网络差: 40-60 秒
- 使用代理: 60-90 秒

### max_retries

最大重试次数

**类型**: 整数  
**默认值**: 3  
**范围**: 0 - 10  
**说明**: API 调用失败时的重试次数

```json
{
  "api_config": {
    "max_retries": 3
  }
}
```

**重试策略**: 指数退避（1s, 2s, 4s, ...）

### temperature

温度参数

**类型**: 浮点数  
**默认值**: 0.1  
**范围**: 0.0 - 2.0  
**说明**: 控制 AI 输出的随机性

```json
{
  "api_config": {
    "temperature": 0.1
  }
}
```

**效果**:
- 0.0: 最确定，输出一致
- 0.1-0.3: 推荐范围，平衡确定性和灵活性
- 0.5-1.0: 更有创造性，但可能不稳定
- 1.0+: 非常随机，不推荐

## 浏览器配置

### chrome_path

Chrome 可执行文件路径

**类型**: 字符串  
**默认值**: `""` (使用系统默认)  
**说明**: Chrome 浏览器的完整路径

```json
{
  "browser_config": {
    "chrome_path": "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
  }
}
```

**常见路径**:
- Windows: `C:\Program Files\Google\Chrome\Application\chrome.exe`
- macOS: `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`
- Linux: `/usr/bin/google-chrome`

**注意**: 留空则使用系统 PATH 中的 Chrome

### debug_port

Chrome 调试端口

**类型**: 整数  
**默认值**: 9222  
**范围**: 1024 - 65535  
**说明**: Chrome 远程调试端口

```json
{
  "browser_config": {
    "debug_port": 9222
  }
}
```

**注意**: 
- 确保端口未被占用
- 启动 Chrome 时使用相同端口
- 防火墙需允许该端口

### page_load_timeout

页面加载超时

**类型**: 整数  
**默认值**: 30  
**范围**: 10 - 120  
**单位**: 秒  
**说明**: 页面加载的最大等待时间

```json
{
  "browser_config": {
    "page_load_timeout": 30
  }
}
```

### implicit_wait

隐式等待时间

**类型**: 整数  
**默认值**: 10  
**范围**: 5 - 30  
**单位**: 秒  
**说明**: 查找元素时的等待时间

```json
{
  "browser_config": {
    "implicit_wait": 10
  }
}
```

## 邮件配置

### smtp_server

SMTP 服务器地址

**类型**: 字符串  
**默认值**: `smtp.qq.com`  
**说明**: 邮件服务器地址

```json
{
  "email_config": {
    "smtp_server": "smtp.qq.com"
  }
}
```

**常见服务器**:
- QQ 邮箱: `smtp.qq.com`
- 163 邮箱: `smtp.163.com`
- Gmail: `smtp.gmail.com`
- Outlook: `smtp.office365.com`

### smtp_port

SMTP 端口

**类型**: 整数  
**默认值**: 587  
**常用值**: 25, 465, 587  
**说明**: SMTP 服务端口

```json
{
  "email_config": {
    "smtp_port": 587
  }
}
```

**端口说明**:
- 25: 标准 SMTP（不加密）
- 465: SMTP over SSL
- 587: SMTP with STARTTLS（推荐）

### sender_email

发件人邮箱

**类型**: 字符串  
**必需**: 是（如果启用邮件）  
**格式**: 有效的邮箱地址  
**说明**: 发送通知的邮箱

```json
{
  "email_config": {
    "sender_email": "your_email@qq.com"
  }
}
```

### sender_password

发件人密码/授权码

**类型**: 字符串  
**必需**: 是（如果启用邮件）  
**说明**: 邮箱密码或授权码

```json
{
  "email_config": {
    "sender_password": "your_authorization_code"
  }
}
```

**重要**: 
- QQ/163 邮箱使用授权码，不是登录密码
- Gmail 使用应用专用密码
- 参考各邮箱服务商的文档

### receiver_email

收件人邮箱

**类型**: 字符串  
**必需**: 是（如果启用邮件）  
**格式**: 有效的邮箱地址  
**说明**: 接收通知的邮箱

```json
{
  "email_config": {
    "receiver_email": "receiver@example.com"
  }
}
```

**注意**: 可以与发件人邮箱相同

### enabled

是否启用邮件通知

**类型**: 布尔值  
**默认值**: true  
**说明**: 控制是否发送邮件通知

```json
{
  "email_config": {
    "enabled": true
  }
}
```

**使用场景**:
- 测试时设为 false
- 不需要通知时设为 false
- 邮件配置有问题时设为 false

## 监控目标配置

### name

产品名称

**类型**: 字符串  
**必需**: 是  
**说明**: 监控目标的显示名称

```json
{
  "targets": [
    {
      "name": "RTX 5090"
    }
  ]
}
```

### search_url

搜索页面 URL

**类型**: 字符串  
**必需**: 是  
**说明**: Best Buy 搜索结果页面的 URL

```json
{
  "targets": [
    {
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090"
    }
  ]
}
```

**获取方式**:
1. 在 Best Buy 搜索产品
2. 复制浏览器地址栏的 URL
3. 粘贴到配置文件

### keywords

关键词列表

**类型**: 字符串数组  
**默认值**: 从 name 提取  
**说明**: 用于识别产品的关键词

```json
{
  "targets": [
    {
      "keywords": ["RTX 5090", "GeForce 5090", "5090"]
    }
  ]
}
```

**建议**:
- 包含型号: "5090", "RTX 5090"
- 包含品牌: "NVIDIA", "GeForce"
- 避免过于宽泛的词

### max_price

最高价格

**类型**: 浮点数  
**必需**: 是  
**单位**: 美元  
**说明**: 可接受的最高价格

```json
{
  "targets": [
    {
      "max_price": 2650.0
    }
  ]
}
```

**建议**:
- RTX 5090: $2500 - $2800
- RTX 5080: $1400 - $1600
- 根据预算调整

## 日志配置

### level

日志级别

**类型**: 字符串  
**默认值**: `INFO`  
**可选值**: `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`  
**说明**: 日志输出的详细程度

```json
{
  "log_config": {
    "level": "INFO"
  }
}
```

**级别说明**:
- `DEBUG`: 最详细，包括 API 请求/响应
- `INFO`: 一般信息，推荐日常使用
- `WARNING`: 警告信息
- `ERROR`: 错误信息
- `CRITICAL`: 严重错误

### file

日志文件路径

**类型**: 字符串  
**默认值**: `logs/monitor.log`  
**说明**: 日志文件的保存路径

```json
{
  "log_config": {
    "file": "logs/monitor.log"
  }
}
```

**注意**: 目录会自动创建

### console

是否输出到控制台

**类型**: 布尔值  
**默认值**: true  
**说明**: 是否在控制台显示日志

```json
{
  "log_config": {
    "console": true
  }
}
```

**使用场景**:
- 开发调试: true
- 后台运行: false
- 使用 nohup: false

## 高级配置

### 使用环境变量

在配置文件中引用环境变量：

```json
{
  "api_config": {
    "api_key": "${DEEPSEEK_API_KEY}"
  },
  "email_config": {
    "sender_password": "${EMAIL_PASSWORD}"
  }
}
```

设置环境变量：

```bash
# Linux/macOS
export DEEPSEEK_API_KEY=sk-xxx
export EMAIL_PASSWORD=your_password

# Windows (CMD)
set DEEPSEEK_API_KEY=sk-xxx
set EMAIL_PASSWORD=your_password

# Windows (PowerShell)
$env:DEEPSEEK_API_KEY="sk-xxx"
$env:EMAIL_PASSWORD="your_password"
```

### 配置文件继承

创建基础配置和环境特定配置：

**base_config.json**:
```json
{
  "check_interval": 30,
  "api_config": {
    "base_url": "https://api.deepseek.com",
    "model_name": "deepseek-chat"
  }
}
```

**prod_config.json**:
```json
{
  "extends": "base_config.json",
  "api_config": {
    "api_key": "sk-prod-key"
  }
}
```

### 多环境配置

为不同环境创建不同配置：

- `config/dev.json` - 开发环境
- `config/test.json` - 测试环境
- `config/prod.json` - 生产环境

使用时指定配置文件：

```bash
python main.py -c config/dev.json
python main.py -c config/prod.json
```

## 配置示例

### 最小配置

```json
{
  "api_config": {
    "api_key": "sk-xxx"
  },
  "targets": [
    {
      "name": "RTX 5090",
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090",
      "max_price": 2650.0
    }
  ]
}
```

### 完整配置

```json
{
  "check_interval": 30,
  "max_pages": 3,
  "api_config": {
    "api_key": "sk-xxx",
    "base_url": "https://api.deepseek.com",
    "model_name": "deepseek-chat",
    "timeout": 30,
    "max_retries": 3,
    "temperature": 0.1
  },
  "browser_config": {
    "chrome_path": "",
    "debug_port": 9222,
    "page_load_timeout": 30,
    "implicit_wait": 10
  },
  "email_config": {
    "smtp_server": "smtp.qq.com",
    "smtp_port": 587,
    "sender_email": "your@qq.com",
    "sender_password": "auth_code",
    "receiver_email": "receiver@qq.com",
    "enabled": true
  },
  "targets": [
    {
      "name": "RTX 5090",
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090",
      "keywords": ["RTX 5090", "GeForce 5090"],
      "max_price": 2650.0
    },
    {
      "name": "RTX 5080",
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5080",
      "keywords": ["RTX 5080", "GeForce 5080"],
      "max_price": 1500.0
    }
  ],
  "log_config": {
    "level": "INFO",
    "file": "logs/monitor.log",
    "console": true
  }
}
```

### 开发配置

```json
{
  "check_interval": 10,
  "api_config": {
    "api_key": "sk-dev-key",
    "timeout": 60,
    "temperature": 0.0
  },
  "email_config": {
    "enabled": false
  },
  "log_config": {
    "level": "DEBUG",
    "console": true
  }
}
```

### 生产配置

```json
{
  "check_interval": 60,
  "api_config": {
    "api_key": "${DEEPSEEK_API_KEY}",
    "timeout": 30,
    "max_retries": 5
  },
  "email_config": {
    "sender_password": "${EMAIL_PASSWORD}",
    "enabled": true
  },
  "log_config": {
    "level": "INFO",
    "console": false
  }
}
```

## 配置验证

系统启动时会自动验证配置：

### 验证规则

1. **API 配置**:
   - api_key 不为空
   - api_key 不是示例值
   - timeout > 0
   - max_retries >= 0
   - 0 <= temperature <= 2

2. **浏览器配置**:
   - 1024 <= debug_port <= 65535
   - page_load_timeout > 0
   - implicit_wait > 0

3. **邮件配置**:
   - 如果 enabled=true，必须提供所有必需字段
   - sender_email 格式正确
   - receiver_email 格式正确

4. **监控目标**:
   - 至少有一个目标
   - name 不为空
   - search_url 格式正确
   - max_price > 0

5. **日志配置**:
   - level 是有效值
   - file 路径有效

### 跳过验证

如果需要跳过验证（不推荐）：

```bash
python main.py --no-validate
```

### 手动验证

```python
from src.config_loader import ConfigLoader
from src.config_validator import ConfigValidator

config = ConfigLoader.load_from_file("config/config.json")
validator = ConfigValidator()
validator.validate(config)
```

## 环境变量

### 支持的环境变量

- `DEEPSEEK_API_KEY` - DeepSeek API 密钥
- `EMAIL_PASSWORD` - 邮箱密码/授权码
- `CHROME_DEBUG_PORT` - Chrome 调试端口
- `LOG_LEVEL` - 日志级别

### 使用方式

**方式 1: 在配置文件中引用**

```json
{
  "api_config": {
    "api_key": "${DEEPSEEK_API_KEY}"
  }
}
```

**方式 2: 命令行覆盖**

```bash
export DEEPSEEK_API_KEY=sk-xxx
python main.py
```

**方式 3: .env 文件**

创建 `.env` 文件：

```
DEEPSEEK_API_KEY=sk-xxx
EMAIL_PASSWORD=your_password
LOG_LEVEL=DEBUG
```

加载 .env 文件：

```python
from dotenv import load_dotenv
load_dotenv()
```

## 相关文档

- [API 密钥获取指南](API_KEY_GUIDE.md)
- [使用指南](USAGE_GUIDE.md)
- [故障排除指南](TROUBLESHOOTING.md)

---

如有其他配置问题，请查看 [故障排除指南](TROUBLESHOOTING.md) 或提交 Issue。
