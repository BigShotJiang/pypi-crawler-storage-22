# 故障排除指南

本指南帮助你诊断和解决 AI Agent 显卡监控系统的常见问题。

## 目录

- [启动问题](#启动问题)
- [配置问题](#配置问题)
- [浏览器连接问题](#浏览器连接问题)
- [API 调用问题](#api-调用问题)
- [产品识别问题](#产品识别问题)
- [购买流程问题](#购买流程问题)
- [邮件通知问题](#邮件通知问题)
- [性能问题](#性能问题)
- [日志分析](#日志分析)
- [调试工具](#调试工具)

## 启动问题

### 问题: 提示 "ModuleNotFoundError: No module named 'xxx'"

**原因**: 缺少必要的 Python 依赖包

**解决方案**:
```bash
# 安装所有依赖
pip install -r requirements.txt

# 或手动安装缺失的包
pip install selenium openai pyyaml
```

**验证安装**:
```bash
python -c "import selenium; import openai; print('依赖安装成功')"
```

### 问题: 提示 "Python version too old"

**原因**: Python 版本低于 3.8

**解决方案**:
1. 检查 Python 版本:
   ```bash
   python --version
   ```

2. 升级 Python:
   - Windows: 从 [python.org](https://www.python.org/) 下载安装
   - macOS: `brew install python@3.12`
   - Linux: `sudo apt install python3.12`

3. 使用虚拟环境:
   ```bash
   python3.12 -m venv venv
   source venv/bin/activate  # Linux/macOS
   venv\Scripts\activate     # Windows
   ```

### 问题: 提示 "Permission denied"

**原因**: 没有执行权限或文件被占用

**解决方案**:

**Linux/macOS**:
```bash
chmod +x main.py
chmod +x start_my_chrome_debug.bat
```

**Windows**:
- 以管理员身份运行命令提示符
- 检查文件是否被其他程序占用
- 关闭杀毒软件的实时保护（临时）

## 配置问题

### 问题: 提示 "配置文件不存在"

**原因**: 配置文件路径错误或文件未创建

**解决方案**:
```bash
# 创建示例配置文件
python main.py --create-config config/config.json

# 或手动复制示例配置
cp config/example_config.json config/config.json
```

### 问题: 提示 "配置格式错误"

**原因**: JSON 格式不正确

**解决方案**:
1. 使用 JSON 验证工具检查格式:
   - 在线工具: [jsonlint.com](https://jsonlint.com/)
   - VS Code: 安装 JSON 扩展

2. 常见 JSON 错误:
   ```json
   // 错误: 多余的逗号
   {
     "key": "value",
   }
   
   // 正确
   {
     "key": "value"
   }
   
   // 错误: 使用单引号
   {
     'key': 'value'
   }
   
   // 正确: 使用双引号
   {
     "key": "value"
   }
   ```

3. 重新生成配置文件:
   ```bash
   python main.py --create-config config/config_new.json
   ```

### 问题: 提示 "请替换示例 API 密钥"

**原因**: 配置文件中使用的是示例密钥

**解决方案**:
1. 获取真实的 DeepSeek API 密钥（参考 [API 密钥获取指南](API_KEY_GUIDE.md)）
2. 编辑配置文件，替换示例密钥:
   ```json
   {
     "api_config": {
       "api_key": "sk-your-real-api-key-here"
     }
   }
   ```

### 问题: 提示 "配置验证失败"

**原因**: 配置项的值不符合要求

**解决方案**:
检查以下配置项:
- `check_interval`: 必须 > 0
- `max_price`: 必须 > 0
- `debug_port`: 必须在 1024-65535 之间
- `timeout`: 必须 > 0
- `max_retries`: 必须 >= 0

## 浏览器连接问题

### 问题: 提示 "无法连接到浏览器"

**原因**: Chrome 未启动或调试端口不正确

**解决方案**:

1. **确认 Chrome 已启动**:
   ```bash
   # Windows
   start_my_chrome_debug.bat
   
   # 手动启动
   chrome.exe --remote-debugging-port=9222 --user-data-dir="C:\chrome_debug_profile"
   ```

2. **检查端口是否被占用**:
   ```bash
   # Windows
   netstat -ano | findstr :9222
   
   # Linux/macOS
   lsof -i :9222
   ```

3. **更换调试端口**:
   编辑配置文件:
   ```json
   {
     "browser_config": {
       "debug_port": 9223
     }
   }
   ```
   
   然后使用新端口启动 Chrome:
   ```bash
   chrome.exe --remote-debugging-port=9223 --user-data-dir="C:\chrome_debug_profile"
   ```

4. **检查防火墙设置**:
   - 允许 Chrome 通过防火墙
   - 允许本地端口 9222 的连接

### 问题: Chrome 启动后立即关闭

**原因**: 用户数据目录被占用或损坏

**解决方案**:
1. 关闭所有 Chrome 进程:
   ```bash
   # Windows
   taskkill /F /IM chrome.exe
   
   # Linux/macOS
   killall chrome
   ```

2. 删除用户数据目录:
   ```bash
   # Windows
   rmdir /s /q C:\chrome_debug_profile
   
   # Linux/macOS
   rm -rf ~/chrome_debug_profile
   ```

3. 重新启动 Chrome

### 问题: 提示 "页面加载超时"

**原因**: 网络慢或页面加载时间过长

**解决方案**:
1. 增加超时时间:
   ```json
   {
     "browser_config": {
       "page_load_timeout": 60,
       "implicit_wait": 20
     }
   }
   ```

2. 检查网络连接:
   ```bash
   ping www.bestbuy.com
   ```

3. 使用代理（如果需要）:
   ```json
   {
     "browser_config": {
       "proxy": "http://proxy.example.com:8080"
     }
   }
   ```

## API 调用问题

### 问题: 提示 "API 密钥无效"

**原因**: API 密钥错误或已过期

**解决方案**:
1. 检查密钥格式:
   - 应以 `sk-` 开头
   - 长度约 48 个字符
   - 只包含字母、数字和连字符

2. 验证密钥:
   ```bash
   python examples/test_api_key.py
   ```

3. 重新创建密钥:
   - 登录 [DeepSeek 平台](https://platform.deepseek.com/)
   - 删除旧密钥
   - 创建新密钥
   - 更新配置文件

### 问题: 提示 "Rate limit exceeded"

**原因**: 超过 API 速率限制

**解决方案**:
1. **增加检查间隔**:
   ```json
   {
     "check_interval": 60
   }
   ```

2. **启用降级策略**:
   系统会自动切换到规则匹配模式

3. **升级 API 套餐**:
   - 登录 DeepSeek 平台
   - 升级到付费版
   - 获得更高的速率限制

4. **查看当前使用量**:
   - 登录 DeepSeek 平台
   - 进入 "Usage" 页面
   - 查看剩余配额

### 问题: 提示 "API timeout"

**原因**: API 响应超时

**解决方案**:
1. 增加超时时间:
   ```json
   {
     "api_config": {
       "timeout": 60
     }
   }
   ```

2. 检查网络连接:
   ```bash
   curl -I https://api.deepseek.com
   ```

3. 使用代理:
   ```bash
   export HTTPS_PROXY=http://proxy.example.com:8080
   python main.py
   ```

### 问题: 提示 "Insufficient quota"

**原因**: API 配额不足

**解决方案**:
1. 检查账户余额:
   - 登录 DeepSeek 平台
   - 查看账户余额
   - 充值或升级套餐

2. 启用降级策略:
   系统会自动使用规则匹配

3. 减少 API 调用:
   - 增加检查间隔
   - 优化 prompt 长度
   - 使用缓存

## 产品识别问题

### 问题: 一直显示 "未找到产品"

**原因**: 页面无产品或识别逻辑有问题

**解决方案**:
1. **检查页面内容**:
   ```bash
   python examples/browser_driver_demo.py
   ```

2. **查看 AI 分析结果**:
   启用 DEBUG 日志:
   ```bash
   python main.py --log-level DEBUG
   ```

3. **检查搜索 URL**:
   确保 URL 正确且能访问:
   ```json
   {
     "targets": [
       {
         "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090"
       }
     ]
   }
   ```

4. **手动测试**:
   - 在 Chrome 中打开搜索 URL
   - 检查是否有产品显示
   - 检查页面是否需要登录

### 问题: 识别了错误的产品（整机、配件等）

**原因**: AI 判断错误或 prompt 需要优化

**解决方案**:
1. **查看识别详情**:
   ```bash
   python main.py --log-level DEBUG
   ```
   查看 AI 的推理过程（reasoning 字段）

2. **调整 temperature**:
   降低温度提高确定性:
   ```json
   {
     "api_config": {
       "temperature": 0.0
     }
   }
   ```

3. **优化 prompt**:
   编辑 `src/ai_agent_engine.py`，修改 prompt 模板，增强排除规则

4. **使用决策引擎过滤**:
   决策引擎会二次验证产品类型

### 问题: 价格识别错误

**原因**: 价格格式特殊或提取逻辑有问题

**解决方案**:
1. **查看原始价格文本**:
   ```bash
   python main.py --log-level DEBUG
   ```
   查看 `price_text` 字段

2. **测试价格提取**:
   ```python
   from src.price_extractor import PriceExtractor
   
   extractor = PriceExtractor()
   price = extractor.extract_price("$1,999.99")
   print(price)  # 应输出 1999.99
   ```

3. **报告问题**:
   如果价格格式特殊，请提供示例以便改进

## 购买流程问题

### 问题: 无法点击 "Add to Cart" 按钮

**原因**: 按钮定位失败或页面未加载完成

**解决方案**:
1. **增加等待时间**:
   ```json
   {
     "browser_config": {
       "implicit_wait": 20
     }
   }
   ```

2. **检查登录状态**:
   - 在 Chrome 中手动登录 Best Buy
   - 确保登录状态有效

3. **查看 AI 提供的选择器**:
   ```bash
   python main.py --log-level DEBUG
   ```
   查看 `selector_hint` 字段

4. **手动测试**:
   - 在 Chrome 中打开产品页面
   - 检查 "Add to Cart" 按钮是否可见
   - 尝试手动点击

### 问题: 点击 Checkout 后跳转到登录页面

**原因**: 未登录或登录状态过期

**解决方案**:
1. 在 Chrome 中重新登录 Best Buy
2. 确保勾选 "Keep me signed in"
3. 添加支付方式和收货地址
4. 重新启动监控

### 问题: 购买流程卡住

**原因**: 页面加载慢或出现验证码

**解决方案**:
1. **检查日志**:
   ```bash
   tail -f logs/monitor.log
   ```

2. **手动介入**:
   - 切换到 Chrome 窗口
   - 检查是否有验证码或其他提示
   - 手动完成验证

3. **增加超时时间**:
   ```json
   {
     "browser_config": {
       "page_load_timeout": 60
     }
   }
   ```

## 邮件通知问题

### 问题: 未收到邮件通知

**原因**: 邮件配置错误或发送失败

**解决方案**:
1. **检查邮件配置**:
   ```json
   {
     "email_config": {
       "smtp_server": "smtp.qq.com",
       "smtp_port": 587,
       "sender_email": "your@qq.com",
       "sender_password": "authorization_code",
       "receiver_email": "receiver@qq.com",
       "enabled": true
     }
   }
   ```

2. **验证授权码**:
   - 确保使用的是授权码，不是 QQ 密码
   - 重新生成授权码

3. **测试邮件发送**:
   ```bash
   python examples/notification_demo.py
   ```

4. **检查垃圾邮件**:
   - 查看垃圾邮件文件夹
   - 将发件人添加到白名单

5. **查看日志**:
   ```bash
   grep "email" logs/monitor.log
   ```

### 问题: 提示 "SMTP authentication failed"

**原因**: 邮箱或授权码错误

**解决方案**:
1. 确认邮箱地址正确
2. 重新生成 QQ 邮箱授权码:
   - 登录 QQ 邮箱网页版
   - 设置 → 账户 → SMTP 服务
   - 生成新的授权码
3. 更新配置文件

### 问题: 提示 "Connection refused"

**原因**: SMTP 服务器或端口错误

**解决方案**:
1. 检查 SMTP 配置:
   - QQ 邮箱: `smtp.qq.com:587`
   - 163 邮箱: `smtp.163.com:465`
   - Gmail: `smtp.gmail.com:587`

2. 检查防火墙:
   - 允许出站连接到 SMTP 端口
   - 临时关闭防火墙测试

3. 使用 SSL 端口:
   ```json
   {
     "email_config": {
       "smtp_port": 465,
       "use_ssl": true
     }
   }
   ```

## 性能问题

### 问题: 系统运行缓慢

**原因**: 网络慢、API 响应慢或配置不当

**解决方案**:
1. **优化检查间隔**:
   ```json
   {
     "check_interval": 60
   }
   ```

2. **减少超时时间**:
   ```json
   {
     "api_config": {
       "timeout": 20
     },
     "browser_config": {
       "page_load_timeout": 20
     }
   }
   ```

3. **启用降级策略**:
   在 API 慢时自动切换到规则匹配

4. **使用更快的网络**:
   - 使用有线连接
   - 使用 VPN 加速

### 问题: 内存占用过高

**原因**: Chrome 或 Python 进程内存泄漏

**解决方案**:
1. **定期重启 Chrome**:
   系统会在连续失败 5 次后自动重启

2. **限制日志大小**:
   ```json
   {
     "log_config": {
       "max_bytes": 10485760,
       "backup_count": 5
     }
   }
   ```

3. **监控内存使用**:
   ```bash
   # Windows
   tasklist | findstr python
   tasklist | findstr chrome
   
   # Linux/macOS
   ps aux | grep python
   ps aux | grep chrome
   ```

### 问题: CPU 占用过高

**原因**: 检查间隔太短或页面渲染耗时

**解决方案**:
1. 增加检查间隔
2. 使用无头模式（headless）:
   ```json
   {
     "browser_config": {
       "headless": true
     }
   }
   ```
3. 禁用不必要的浏览器功能

## 日志分析

### 查看实时日志

```bash
# Linux/macOS
tail -f logs/monitor.log

# Windows (PowerShell)
Get-Content logs/monitor.log -Wait -Tail 50
```

### 搜索特定错误

```bash
# 搜索错误
grep "ERROR" logs/monitor.log

# 搜索 API 调用
grep "API" logs/monitor.log

# 搜索产品发现
grep "Found.*product" logs/monitor.log
```

### 日志级别说明

- **DEBUG**: 详细的调试信息（包括 API 请求/响应）
- **INFO**: 一般信息（检查进度、产品发现等）
- **WARNING**: 警告信息（连续失败、降级模式等）
- **ERROR**: 错误信息（API 失败、浏览器错误等）
- **CRITICAL**: 严重错误（系统无法继续运行）

### 启用详细日志

```bash
python main.py --log-level DEBUG
```

## 调试工具

### 1. 浏览器驱动测试

```bash
python examples/browser_driver_demo.py
```

功能:
- 测试 Chrome 连接
- 测试页面导航
- 测试上下文提取

### 2. 通知服务测试

```bash
python examples/notification_demo.py
```

功能:
- 测试邮件发送
- 验证 SMTP 配置
- 测试不同类型的通知

### 3. 监控控制器测试

```bash
python examples/monitor_controller_demo.py
```

功能:
- 测试完整监控流程
- 测试配置加载
- 测试错误处理

### 4. 降级策略测试

```bash
python examples/fallback_demo.py
```

功能:
- 测试 API 失败时的降级
- 测试规则匹配逻辑
- 对比 AI 和规则的结果

### 5. 集成测试

```bash
pytest tests/test_full_integration.py -v
```

功能:
- 测试所有组件集成
- 验证端到端流程
- 检查错误处理

## 获取帮助

如果以上方法都无法解决问题，请：

1. **收集信息**:
   - 错误信息的完整文本
   - 相关日志（`logs/monitor.log`）
   - 配置文件（删除敏感信息）
   - 系统信息（OS、Python 版本等）

2. **查看文档**:
   - [使用指南](USAGE_GUIDE.md)
   - [配置说明](../config/README.md)
   - [API 密钥指南](API_KEY_GUIDE.md)

3. **提交 Issue**:
   - 在 GitHub 上提交 Issue
   - 提供详细的问题描述
   - 附上错误日志和配置

4. **联系支持**:
   - 发送邮件到技术支持
   - 加入社区讨论群
   - 查看 FAQ

---

希望本指南能帮助你解决问题！如有其他疑问，请查看其他文档或联系技术支持。
