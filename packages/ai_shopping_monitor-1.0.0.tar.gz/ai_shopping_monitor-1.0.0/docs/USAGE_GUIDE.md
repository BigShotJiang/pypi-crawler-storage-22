# AI Agent 显卡监控系统 - 使用指南

## 概述

AI Agent 显卡监控系统是基于 DeepSeek API 的智能显卡监控抢购系统。与传统的规则匹配方案不同，本系统使用大语言模型理解页面内容，提供更准确的产品识别和更强的鲁棒性。

## 系统要求

- Python 3.8 或更高版本
- Chrome 浏览器
- DeepSeek API 密钥
- QQ 邮箱（用于通知，可选）

## 安装步骤

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

主要依赖包括：
- selenium - 浏览器自动化
- openai - DeepSeek API 客户端
- pyyaml - YAML 配置支持（可选）

### 2. 获取 DeepSeek API 密钥

1. 访问 [DeepSeek 官网](https://platform.deepseek.com/)
2. 注册账号并登录
3. 在 API Keys 页面创建新的 API 密钥
4. 保存密钥（只显示一次）

### 3. 配置系统

#### 方式一：使用命令行创建配置文件

```bash
python main.py --create-config config/my_config.json
```

#### 方式二：手动创建配置文件

复制 `config/example_config.json` 并修改：

```json
{
  "check_interval": 30,
  "targets": [
    {
      "name": "RTX 5090",
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090",
      "keywords": ["RTX 5090", "GeForce 5090"],
      "max_price": 2650.0
    }
  ],
  "api_config": {
    "api_key": "YOUR_DEEPSEEK_API_KEY_HERE",
    "base_url": "https://api.deepseek.com",
    "model_name": "deepseek-chat",
    "timeout": 30,
    "max_retries": 3,
    "temperature": 0.1
  },
  "browser_config": {
    "chrome_path": "",
    "debug_port": 9222,
    "page_load_timeout": 30,
    "implicit_wait": 10
  },
  "email_config": {
    "smtp_server": "smtp.qq.com",
    "smtp_port": 587,
    "sender_email": "your_email@qq.com",
    "sender_password": "your_authorization_code",
    "receiver_email": "receiver@example.com",
    "enabled": true
  },
  "log_config": {
    "level": "INFO",
    "file": "logs/monitor.log",
    "console": true
  }
}
```

**必须修改的配置项：**
1. `api_config.api_key` - 填入你的 DeepSeek API 密钥
2. `email_config.sender_email` - 填入你的 QQ 邮箱
3. `email_config.sender_password` - 填入 QQ 邮箱授权码（不是密码）
4. `email_config.receiver_email` - 填入接收通知的邮箱

**可选修改的配置项：**
- `check_interval` - 检查间隔（秒），默认 30 秒
- `targets[].max_price` - 最高价格，超过此价格不购买
- `browser_config.debug_port` - Chrome 调试端口，默认 9222
- `log_config.level` - 日志级别（DEBUG/INFO/WARNING/ERROR）

## 启动系统

### 1. 启动 Chrome 调试模式

**Windows:**
```bash
start_my_chrome_debug.bat
```

或手动启动：
```bash
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --user-data-dir="C:\chrome_debug_profile"
```

**macOS:**
```bash
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --remote-debugging-port=9222 --user-data-dir="~/chrome_debug_profile"
```

**Linux:**
```bash
google-chrome --remote-debugging-port=9222 --user-data-dir="~/chrome_debug_profile"
```

**重要提示：**
- Chrome 启动后，手动登录 Best Buy 账号
- 确保已添加支付方式和收货地址
- 保持 Chrome 窗口打开

### 2. 启动监控系统

**使用默认配置：**
```bash
python main.py
```

**使用指定配置文件：**
```bash
python main.py -c config/my_config.json
```

**设置日志级别为 DEBUG：**
```bash
python main.py --log-level DEBUG
```

**查看所有命令行选项：**
```bash
python main.py --help
```

## 命令行参数

```
usage: main.py [-h] [-c CONFIG] [--create-config PATH]
               [--log-level {DEBUG,INFO,WARNING,ERROR,CRITICAL}]
               [--log-file LOG_FILE] [--no-console] [--no-validate] [-v]

选项说明：
  -h, --help            显示帮助信息
  -c CONFIG, --config CONFIG
                        配置文件路径 (默认: config/config.json)
  --create-config PATH  创建示例配置文件到指定路径并退出
  --log-level LEVEL     设置日志级别 (覆盖配置文件中的设置)
  --log-file FILE       日志文件路径 (覆盖配置文件中的设置)
  --no-console          禁用控制台日志输出
  --no-validate         跳过配置验证（不推荐）
  -v, --version         显示版本信息
```

## 使用示例

### 示例 1：首次使用

```bash
# 1. 创建配置文件
python main.py --create-config config/my_config.json

# 2. 编辑配置文件，填入 API 密钥和邮箱信息
# 使用文本编辑器打开 config/my_config.json

# 3. 启动 Chrome 调试模式
start_my_chrome_debug.bat

# 4. 在 Chrome 中登录 Best Buy 账号

# 5. 启动监控
python main.py -c config/my_config.json
```

### 示例 2：调试模式

```bash
# 启用 DEBUG 日志级别，查看详细信息
python main.py --log-level DEBUG
```

### 示例 3：仅记录到文件

```bash
# 禁用控制台输出，仅记录到日志文件
python main.py --no-console --log-file logs/monitor_$(date +%Y%m%d).log
```

### 示例 4：监控多个产品

编辑配置文件，添加多个监控目标：

```json
{
  "targets": [
    {
      "name": "RTX 5090",
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090",
      "keywords": ["RTX 5090", "GeForce 5090"],
      "max_price": 2650.0
    },
    {
      "name": "RTX 5080",
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5080",
      "keywords": ["RTX 5080", "GeForce 5080"],
      "max_price": 1500.0
    }
  ]
}
```

## 运行输出示例

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║              AI Agent 显卡监控系统 v1.0.0                                  ║
║                                                                           ║
║              基于 DeepSeek API 的智能监控抢购系统                          ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝

系统信息:
  Python 版本: 3.12.7
  工作目录: /home/user/ai-agent-monitor

加载配置文件: config/config.json
✓ 配置加载成功

检查运行前提条件...
  Chrome 调试端口: 9222
  请确保 Chrome 已使用以下命令启动:
    chrome.exe --remote-debugging-port=9222

✓ 前提条件检查通过

初始化监控系统...
✓ 监控系统初始化完成

===============================================================================
监控配置:
  检查间隔: 30 秒
  监控目标: 2 个
    1. RTX 5090 - 最高价格: $2650.00
    2. RTX 5080 - 最高价格: $1500.00

按 Ctrl+C 停止监控
===============================================================================

[2026-02-05 10:30:00] 开始第 1 次检查
[2026-02-05 10:30:00] 检查目标: RTX 5090
[2026-02-05 10:30:05] 找到 3 个符合条件的产品
[2026-02-05 10:30:05] 处理产品: NVIDIA GeForce RTX 5090 Founders Edition
[2026-02-05 10:30:05] 价格: $1999.99
[2026-02-05 10:30:05] 决策引擎批准购买，发送通知...
[2026-02-05 10:30:10] 开始执行购买流程
[2026-02-05 10:30:15] 成功加入购物车
[2026-02-05 10:30:20] 成功到达结账页面
[2026-02-05 10:30:20] 购买流程完成！请在浏览器中完成支付流程

等待 30 秒后进行下一次检查...
```

## 停止监控

按 `Ctrl+C` 优雅停止监控系统。系统会：
1. 停止监控循环
2. 关闭浏览器连接
3. 记录统计信息
4. 清理资源

```
收到中断信号，正在停止监控...

===============================================================================
停止监控系统
===============================================================================
总检查次数: 42
找到产品数: 15
购买尝试次数: 3
===============================================================================
监控系统已停止
===============================================================================
```

## 常见问题

### Q: 如何获取 QQ 邮箱授权码？

A: 
1. 登录 QQ 邮箱网页版
2. 设置 → 账户 → POP3/IMAP/SMTP/Exchange/CardDAV/CalDAV服务
3. 开启 SMTP 服务
4. 生成授权码（不是 QQ 密码）

### Q: 为什么提示 "无法连接到浏览器"？

A: 
1. 确保 Chrome 已启动并使用 `--remote-debugging-port=9222` 参数
2. 检查端口 9222 是否被占用
3. 尝试修改配置文件中的 `debug_port` 为其他端口（如 9223）

### Q: 如何查看详细的 API 调用日志？

A: 使用 DEBUG 日志级别：
```bash
python main.py --log-level DEBUG
```

### Q: API 调用失败怎么办？

A: 系统会自动：
1. 重试最多 3 次（指数退避）
2. 如果仍然失败，切换到降级模式（基于规则的产品识别）
3. 记录详细错误日志

### Q: 如何禁用邮件通知？

A: 在配置文件中设置：
```json
"email_config": {
  "enabled": false
}
```

### Q: 可以同时监控多个网站吗？

A: 当前版本仅支持 Best Buy。如需支持其他网站，需要修改 prompt 模板。

### Q: 如何调整 AI 分析的准确性？

A: 可以调整以下参数：
- `api_config.temperature` - 降低温度（如 0.1）提高确定性
- `api_config.model_name` - 使用更强大的模型
- 修改 `src/ai_agent_engine.py` 中的 prompt 模板

## 日志文件

系统会生成以下日志：
- `logs/monitor.log` - 主日志文件
- 日志会自动轮转，避免文件过大

日志级别说明：
- **DEBUG** - 详细的调试信息（包括 API 请求/响应）
- **INFO** - 一般信息（检查进度、产品发现等）
- **WARNING** - 警告信息（连续失败、降级模式等）
- **ERROR** - 错误信息（API 失败、浏览器错误等）
- **CRITICAL** - 严重错误（系统无法继续运行）

## 性能优化建议

1. **调整检查间隔**：根据网络状况和 API 配额调整 `check_interval`
2. **使用降级策略**：在 API 配额不足时，系统会自动切换到规则匹配
3. **优化 prompt**：根据实际情况调整 prompt 模板，提高识别准确率
4. **监控 API 使用量**：定期检查 DeepSeek API 使用情况

## 安全建议

1. **保护 API 密钥**：不要将配置文件提交到版本控制系统
2. **使用环境变量**：可以通过环境变量传递敏感信息
3. **定期更新密钥**：定期轮换 API 密钥和邮箱授权码
4. **监控异常活动**：注意 API 调用量和邮件发送量

## 技术支持

如遇到问题，请：
1. 查看日志文件 `logs/monitor.log`
2. 使用 DEBUG 模式运行：`python main.py --log-level DEBUG`
3. 查看相关文档：
   - `docs/fallback_strategy_guide.md` - 降级策略说明
   - `docs/monitor_controller_guide.md` - 监控控制器说明
   - `docs/notification_service_guide.md` - 通知服务说明

## 更新日志

查看 `.kiro/specs/ai-agent-monitor/tasks.md` 了解实现进度和更新历史。

---

**祝你抢购成功！🎉**
