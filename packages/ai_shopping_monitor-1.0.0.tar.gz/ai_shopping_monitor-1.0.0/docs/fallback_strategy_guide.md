# 降级策略和鲁棒性增强指南

本文档描述了 AI Agent 显卡监控系统的降级策略和鲁棒性增强功能。

## 概述

为了提高系统的可靠性和容错能力，我们实现了两个关键的鲁棒性增强功能：

1. **API 降级策略** - 当 DeepSeek API 失败时，自动切换到基于规则的产品识别
2. **Chrome 自动重启** - 检测 Chrome 崩溃并自动重新连接

## 1. API 降级策略

### 功能说明

当 DeepSeek API 调用失败时（网络错误、超时、速率限制等），系统会自动切换到基于规则的降级模式，使用传统的关键词匹配和规则来识别产品。

### 工作原理

#### 降级触发条件

- API 调用抛出异常
- 所有重试都失败
- JSON 解析失败

#### 降级模式规则

降级模式使用以下规则来识别产品：

1. **型号检测**
   - 检查页面是否包含目标型号（如 "RTX 5090"）
   - 支持多种格式：`rtx 5090`, `rtx5090`

2. **库存检测**
   - 检查是否有 "Add to Cart" 按钮
   - 排除 "Sold Out", "Coming Soon" 等状态

3. **整机排除**
   - 排除包含以下关键词的商品：
     - `gaming pc`, `desktop`, `laptop`, `computer system`
     - `gaming computer`, `gaming desktop`, `gaming laptop`
     - `pc with`, `desktop with`, `laptop with`

4. **配件排除**
   - 排除包含以下关键词的商品：
     - `bracket`, `cable`, `adapter`, `mount`, `stand`
     - `support`, `holder`, `riser`, `gpu bracket`, `gpu support`

5. **价格提取**
   - 使用正则表达式提取价格：`\$\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)`
   - 验证价格是否在阈值内

6. **品牌识别**
   - 检测常见品牌关键词：
     - `nvidia`, `asus`, `msi`, `gigabyte`, `evga`, `zotac`, `pny`, `palit`

### 使用示例

```python
from src.ai_agent_engine import AIAgentEngine
from src.page_context import PageContext
from src.config_models import APIConfig

# 创建配置
config = APIConfig(
    api_key="your_api_key",
    base_url="https://api.deepseek.com",
    model_name="deepseek-chat",
    timeout=30,
    max_retries=3,
    temperature=0.7
)

# 创建引擎
engine = AIAgentEngine(config)

# 创建页面上下文
context = PageContext(
    url="https://www.bestbuy.com/...",
    visible_text="NVIDIA GeForce RTX 5090\n$1,999.99\nAdd to Cart",
    # ... 其他字段
)

# 分析页面（如果 API 失败，自动切换到降级模式）
result = engine.analyze_search_page(
    context=context,
    target_model="5090",
    max_price=2650.0
)

# 检查是否使用了降级模式
if engine.fallback_mode:
    print("使用了降级模式")

# 处理结果
for product in result.products_found:
    print(f"产品: {product.name}")
    print(f"置信度: {product.confidence}")  # 降级模式置信度为 0.6
    print(f"识别依据: {product.reasoning}")  # 包含 "【降级模式】" 标记
```

### 降级模式特点

- **置信度较低**: 降级模式识别的产品置信度固定为 0.6（AI 模式通常为 0.8-0.95）
- **日志标记**: 所有降级模式的日志都带有 `【降级模式】` 前缀
- **自动切换**: 无需手动干预，系统自动检测并切换
- **透明性**: 通过 `fallback_mode` 标志和日志可以清楚地知道是否使用了降级模式

### 降级模式限制

- **准确性较低**: 基于简单的关键词匹配，可能产生误判
- **功能受限**: 无法理解复杂的页面结构和语义
- **品牌识别有限**: 只能识别预定义的品牌关键词
- **价格提取简单**: 只提取第一个匹配的价格

### 最佳实践

1. **监控降级模式使用频率**
   - 如果频繁使用降级模式，说明 API 可能存在问题
   - 检查 API 密钥、网络连接、速率限制等

2. **验证降级模式结果**
   - 降级模式的结果应该经过额外的验证
   - 可以设置更严格的价格阈值或其他条件

3. **日志分析**
   - 定期检查日志中的 `【降级模式】` 标记
   - 分析降级模式的识别准确率

## 2. Chrome 自动重启

### 功能说明

系统会自动检测 Chrome 浏览器的连接状态，当检测到崩溃或连接断开时，自动尝试重新连接。

### 工作原理

#### 连接状态检测

`BrowserDriver.is_alive()` 方法通过尝试访问 `driver.current_url` 来检测连接是否有效：

```python
def is_alive(self) -> bool:
    """检测 Chrome 是否仍在运行"""
    if not self.driver:
        return False
    
    try:
        _ = self.driver.current_url
        return True
    except WebDriverException:
        return False
```

#### 自动重新连接

`BrowserDriver.reconnect()` 方法实现了带重试的重新连接逻辑：

```python
def reconnect(self, max_retries: int = 3) -> bool:
    """重新连接到 Chrome（带重试）"""
    # 1. 关闭现有连接
    if self.driver:
        self.driver.quit()
        self.driver = None
    
    # 2. 等待 Chrome 稳定
    time.sleep(2)
    
    # 3. 使用指数退避重试
    for attempt in range(max_retries):
        if self.connect():
            return True
        
        wait_time = 2 ** attempt  # 1s, 2s, 4s
        time.sleep(wait_time)
    
    return False
```

#### 监控循环集成

在 `MonitorController._check_target()` 方法中，每次检查目标前都会先检测 Chrome 状态：

```python
def _check_target(self, target: TargetConfig) -> None:
    # 检查 Chrome 是否存活
    if not self.browser.is_alive():
        logger.warning("检测到 Chrome 崩溃或连接断开")
        
        # 尝试重新连接
        if not self.browser.reconnect():
            logger.error("无法重新连接到 Chrome")
            # 发送错误通知
            return
        
        logger.info("成功重新连接到 Chrome")
    
    # 继续正常的检查流程
    # ...
```

### 重试策略

系统使用**指数退避**策略进行重试：

- 第 1 次重试：等待 1 秒（2^0）
- 第 2 次重试：等待 2 秒（2^1）
- 第 3 次重试：等待 4 秒（2^2）

这种策略可以：
- 快速响应临时性问题
- 避免过度频繁的重试
- 给 Chrome 足够的时间恢复

### 连续失败处理

如果连续失败 5 次，系统会触发完整的浏览器重启流程：

```python
# 在监控循环中
if self.consecutive_failures >= 5:
    logger.warning("连续失败 5 次，尝试重启浏览器连接...")
    self._restart_browser()
    self.consecutive_failures = 0
```

### 使用示例

```python
from src.browser_driver import BrowserDriver
from src.config_models import BrowserConfig

# 创建配置
config = BrowserConfig(
    chrome_path="chrome",
    debug_port=9222,
    page_load_timeout=30,
    implicit_wait=10
)

# 创建驱动
driver = BrowserDriver(config)

# 连接到 Chrome
driver.connect()

# 在监控循环中
while True:
    # 检查连接状态
    if not driver.is_alive():
        print("检测到 Chrome 断开")
        
        # 尝试重新连接
        if driver.reconnect(max_retries=3):
            print("重新连接成功")
        else:
            print("重新连接失败")
            break
    
    # 执行正常的监控任务
    # ...
```

### 错误通知

当重新连接失败时，系统会发送错误通知：

```python
if not self.browser.reconnect():
    # 发送错误通知
    self.notifier.send_error_alert(
        error_msg="Chrome 崩溃且无法重新连接",
        error_type="Chrome 连接失败",
        context={"target": target.name}
    )
```

### 最佳实践

1. **定期检查连接状态**
   - 在每次重要操作前检查 `is_alive()`
   - 不要假设连接始终有效

2. **合理设置重试次数**
   - 默认 3 次重试通常足够
   - 可以根据实际情况调整

3. **监控重启频率**
   - 如果频繁重启，可能是 Chrome 配置问题
   - 检查 Chrome 调试端口、内存使用等

4. **日志分析**
   - 记录每次重启的原因和结果
   - 分析重启模式，找出根本原因

## 测试

### 运行测试

```bash
# 运行所有降级策略和鲁棒性测试
python -m pytest tests/test_fallback_strategy.py -v

# 运行演示
python examples/fallback_demo.py
```

### 测试覆盖

- ✅ API 降级模式初始化
- ✅ 降级模式识别有效产品
- ✅ 降级模式排除整机
- ✅ 降级模式排除配件
- ✅ 降级模式价格阈值检查
- ✅ 降级模式库存检测
- ✅ API 失败自动切换到降级模式
- ✅ Chrome 连接状态检测
- ✅ Chrome 重新连接（成功）
- ✅ Chrome 重新连接（失败）
- ✅ Chrome 重新连接重试逻辑

## 性能影响

### API 降级策略

- **额外开销**: 几乎为零（只在 API 失败时触发）
- **响应时间**: 降级模式通常比 API 调用更快（< 0.1 秒）
- **准确性**: 降级模式准确性较低，但可以作为备用方案

### Chrome 自动重启

- **检测开销**: 每次检查约 0.01 秒（访问 current_url）
- **重连时间**: 2-10 秒（取决于重试次数）
- **影响**: 重连期间会暂停监控，但不会丢失数据

## 故障排除

### API 降级模式问题

**问题**: 降级模式频繁触发

**解决方案**:
1. 检查 API 密钥是否有效
2. 检查网络连接
3. 检查是否达到速率限制
4. 增加 API 超时时间
5. 增加重试次数

**问题**: 降级模式识别不准确

**解决方案**:
1. 调整排除关键词列表
2. 优化价格提取正则表达式
3. 添加更多品牌关键词
4. 考虑使用更复杂的规则

### Chrome 重启问题

**问题**: Chrome 频繁断开

**解决方案**:
1. 检查 Chrome 是否正确启动（使用 `--remote-debugging-port`）
2. 检查调试端口是否被占用
3. 增加 Chrome 内存限制
4. 检查系统资源使用情况

**问题**: 重新连接失败

**解决方案**:
1. 确认 Chrome 进程仍在运行
2. 检查调试端口配置
3. 尝试手动重启 Chrome
4. 检查防火墙设置

## 总结

降级策略和鲁棒性增强功能显著提高了系统的可靠性：

- **API 降级策略**: 确保即使 API 失败，系统仍能继续工作
- **Chrome 自动重启**: 自动处理浏览器崩溃，减少人工干预

这些功能使系统能够在各种异常情况下保持运行，提高了监控的连续性和可靠性。
