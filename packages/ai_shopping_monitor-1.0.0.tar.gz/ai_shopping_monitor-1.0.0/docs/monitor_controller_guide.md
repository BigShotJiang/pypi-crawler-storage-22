# 监控控制器使用指南

## 概述

`MonitorController` 是 AI Agent 显卡监控系统的核心控制器，负责协调所有组件并执行监控循环。

## 主要功能

### 1. 组件初始化

MonitorController 在初始化时会自动创建和配置以下组件：

- **BrowserDriver**: 浏览器驱动，负责页面导航和操作
- **AIAgentEngine**: AI 分析引擎，负责页面理解和产品识别
- **NotificationService**: 通知服务，负责发送邮件通知
- **DecisionEngine**: 决策引擎，负责购买决策

### 2. 监控循环

监控循环的执行流程：

```
1. 连接到 Chrome 浏览器
2. 开始循环:
   a. 遍历所有监控目标
   b. 导航到搜索页面
   c. 提取页面上下文
   d. 使用 AI 分析页面
   e. 处理找到的产品
   f. 执行购买决策
   g. 等待指定间隔
3. 处理错误和重试
4. 优雅关闭
```

### 3. 购买流程

当找到符合条件的产品时，系统会自动执行购买流程：

```
1. 发送产品发现通知
2. 导航到产品页面（如果需要）
3. 点击 "Add to Cart" 按钮
4. 导航到结账页面
5. 发送购买成功通知
```

### 4. 错误处理

系统具有完善的错误处理机制：

- **连续失败检测**: 连续失败 5 次后自动重启浏览器连接
- **异常捕获**: 捕获所有异常并记录详细日志
- **错误通知**: 发送邮件通知用户系统错误
- **优雅关闭**: 确保资源正确释放

## 使用方法

### 基本使用

```python
from src.monitor_controller import MonitorController
from src.config_loader import ConfigLoader

# 加载配置
config = ConfigLoader.load_from_file("config/config.json")

# 创建控制器
controller = MonitorController(config)

# 启动监控
controller.start_monitoring()
```

### 配置文件

配置文件示例 (`config/config.json`):

```json
{
  "check_interval": 30,
  "max_pages": 3,
  "targets": [
    {
      "name": "RTX 5090",
      "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090",
      "keywords": ["RTX 5090", "GeForce 5090"],
      "max_price": 2650.0
    }
  ],
  "api_config": {
    "api_key": "YOUR_DEEPSEEK_API_KEY",
    "base_url": "https://api.deepseek.com",
    "model_name": "deepseek-chat",
    "timeout": 30,
    "max_retries": 3,
    "temperature": 0.1
  },
  "browser_config": {
    "chrome_path": "",
    "debug_port": 9222,
    "page_load_timeout": 30,
    "implicit_wait": 10
  },
  "email_config": {
    "smtp_server": "smtp.qq.com",
    "smtp_port": 587,
    "sender_email": "your_email@qq.com",
    "sender_password": "your_authorization_code",
    "receiver_email": "receiver@example.com",
    "enabled": true
  },
  "log_config": {
    "level": "INFO",
    "file": "logs/monitor.log",
    "console": true
  }
}
```

### 启动 Chrome 调试模式

在启动监控之前，需要先启动 Chrome 浏览器的调试模式：

**Windows:**
```bash
chrome.exe --remote-debugging-port=9222 --user-data-dir="C:/chrome-debug"
```

**Linux/Mac:**
```bash
google-chrome --remote-debugging-port=9222 --user-data-dir="/tmp/chrome-debug"
```

### 运行示例

```bash
python examples/monitor_controller_demo.py
```

## 监控状态

MonitorController 维护以下状态信息：

- `is_running`: 监控是否正在运行
- `consecutive_failures`: 连续失败次数
- `total_checks`: 总检查次数
- `products_found`: 找到的产品数量
- `purchase_attempts`: 购买尝试次数

## 日志记录

系统会记录详细的运行日志，包括：

- 组件初始化状态
- 监控循环执行情况
- 页面分析结果
- 产品检测信息
- 购买决策过程
- 错误和异常信息

日志文件位置由配置文件中的 `log_config.file` 指定。

## 停止监控

监控可以通过以下方式停止：

1. **键盘中断**: 按 `Ctrl+C`
2. **程序调用**: 调用 `controller.stop_monitoring()`
3. **信号处理**: 发送 `SIGINT` 或 `SIGTERM` 信号

停止时系统会：
- 记录统计信息
- 关闭浏览器连接
- 清理资源
- 记录停止日志

## 故障排除

### 1. 无法连接到浏览器

**问题**: `浏览器连接失败`

**解决方案**:
- 确认 Chrome 已启动调试模式
- 检查调试端口是否正确（默认 9222）
- 确认没有其他程序占用该端口

### 2. API 密钥验证失败

**问题**: `API 密钥验证失败`

**解决方案**:
- 检查配置文件中的 `api_config.api_key`
- 确认 API 密钥有效且未过期
- 检查网络连接

### 3. 连续失败

**问题**: `连续失败 5 次，尝试重启浏览器连接`

**解决方案**:
- 检查网络连接
- 确认目标网站可访问
- 检查 Chrome 浏览器是否正常运行
- 查看日志文件了解详细错误信息

### 4. 邮件发送失败

**问题**: `邮件发送失败`

**解决方案**:
- 检查邮件配置是否正确
- 确认 SMTP 服务器和端口
- 使用授权码而不是密码（QQ 邮箱）
- 检查网络连接

## 最佳实践

1. **配置检查间隔**: 建议设置为 30-60 秒，避免过于频繁的请求
2. **监控多个目标**: 可以同时监控多个产品型号
3. **启用邮件通知**: 及时了解系统状态和购买机会
4. **定期检查日志**: 了解系统运行情况和潜在问题
5. **保持浏览器打开**: 监控期间不要关闭 Chrome 浏览器

## API 参考

### MonitorController

#### `__init__(config: MonitorConfig)`

初始化监控控制器。

**参数**:
- `config`: 监控配置对象

**异常**:
- `ValueError`: 配置无效或组件初始化失败

#### `start_monitoring() -> None`

启动监控循环。

该方法会阻塞直到监控停止（通过 Ctrl+C 或调用 `stop_monitoring()`）。

#### `stop_monitoring() -> None`

停止监控并优雅关闭。

清理资源，关闭浏览器连接，记录统计信息。

#### `handle_purchase_opportunity(product: ProductInfo) -> bool`

处理购买机会。

**参数**:
- `product`: 产品信息

**返回**:
- `bool`: 是否成功购买

## 相关文档

- [配置文件说明](../config/README.md)
- [浏览器驱动指南](browser_driver_guide.md)
- [通知服务指南](notification_service_guide.md)
- [AI Agent 引擎指南](ai_agent_engine_guide.md)
