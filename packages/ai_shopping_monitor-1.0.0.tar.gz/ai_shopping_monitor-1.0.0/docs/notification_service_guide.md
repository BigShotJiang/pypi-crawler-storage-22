# 通知服务使用指南

## 概述

NotificationService 是 AI Agent 显卡监控系统的邮件通知组件，负责在关键事件发生时发送邮件通知。该服务支持异步发送、错误处理和多收件人配置。

## 功能特性

### 核心功能

1. **异步邮件发送**
   - 所有邮件都在后台线程中发送
   - 不阻塞主监控流程
   - 确保系统响应性

2. **错误容错**
   - 邮件发送失败不会中断监控
   - 详细的错误日志记录
   - 支持禁用邮件功能

3. **多种通知类型**
   - 产品发现通知
   - 购买成功通知
   - 错误警告通知

4. **灵活配置**
   - 支持 QQ 邮箱、Gmail 等
   - 支持多个收件人
   - 可配置 SMTP 端口（TLS/SSL）

## 快速开始

### 1. 配置邮件

```python
from src.config_models import EmailConfig

email_config = EmailConfig(
    smtp_server="smtp.qq.com",      # SMTP 服务器
    smtp_port=587,                   # 端口（587=TLS, 465=SSL）
    sender_email="your@qq.com",      # 发件人邮箱
    sender_password="auth_code",     # 授权码（不是密码）
    receiver_email="receiver@qq.com", # 收件人邮箱
    enabled=True                     # 启用邮件通知
)
```

### 2. 创建通知服务

```python
from src.notification_service import NotificationService

notification_service = NotificationService(email_config)
```

### 3. 发送通知

```python
from src.ai_agent_engine import ProductInfo

# 创建产品信息
product = ProductInfo(
    name="NVIDIA GeForce RTX 5090 24GB",
    model="5090",
    brand="NVIDIA",
    price=1999.99,
    price_text="$1,999.99",
    is_available=True,
    product_url="https://www.bestbuy.com/product/12345"
)

# 发送产品发现通知
notification_service.send_product_found(product)

# 发送购买成功通知
checkout_url = "https://www.bestbuy.com/checkout"
notification_service.send_purchase_success(product, checkout_url)

# 发送错误警告
notification_service.send_error_alert(
    error_msg="API 调用失败",
    error_type="API 错误",
    context={"url": "https://api.deepseek.com", "status": 500}
)
```

## 邮箱配置指南

### QQ 邮箱配置（推荐）

1. 登录 QQ 邮箱：https://mail.qq.com/
2. 进入 **设置** → **账户**
3. 找到 **POP3/IMAP/SMTP/Exchange/CardDAV/CalDAV服务**
4. 开启 **IMAP/SMTP服务**
5. 发送短信验证
6. 复制 **授权码**（16位字符）
7. 在配置中使用授权码作为 `sender_password`

```python
email_config = EmailConfig(
    smtp_server="smtp.qq.com",
    smtp_port=587,
    sender_email="your_qq_number@qq.com",
    sender_password="your_16_digit_auth_code",  # 授权码
    receiver_email="receiver@qq.com"
)
```

### Gmail 配置

1. 启用两步验证：https://myaccount.google.com/security
2. 生成应用专用密码：https://myaccount.google.com/apppasswords
3. 选择 **邮件** 和 **Windows 计算机**
4. 复制生成的 16 位密码

```python
email_config = EmailConfig(
    smtp_server="smtp.gmail.com",
    smtp_port=587,
    sender_email="your@gmail.com",
    sender_password="xxxx xxxx xxxx xxxx",  # 应用专用密码
    receiver_email="receiver@gmail.com"
)
```

### 其他邮箱

- **Outlook/Hotmail**: `smtp.office365.com:587`
- **163 邮箱**: `smtp.163.com:465`
- **126 邮箱**: `smtp.126.com:465`

## API 参考

### NotificationService

#### 初始化

```python
NotificationService(config: EmailConfig)
```

创建通知服务实例。

**参数:**
- `config`: EmailConfig 对象，包含邮件配置

#### send_product_found

```python
send_product_found(product: ProductInfo) -> bool
```

发送产品发现通知。

**参数:**
- `product`: ProductInfo 对象，包含产品信息

**返回:**
- `bool`: 总是返回 True（异步发送）

**邮件内容:**
- 产品名称、型号、品牌
- 价格和库存状态
- 产品链接
- AI 分析结果（置信度、识别依据）

#### send_purchase_success

```python
send_purchase_success(product: ProductInfo, checkout_url: str) -> bool
```

发送购买成功通知。

**参数:**
- `product`: ProductInfo 对象
- `checkout_url`: 结账页面 URL

**返回:**
- `bool`: 总是返回 True（异步发送）

**邮件内容:**
- 产品信息
- 结账链接
- 操作指南（电脑支付/手机支付）
- 时间提醒

#### send_error_alert

```python
send_error_alert(error_msg: str, error_type: str = "系统错误", 
                context: Optional[dict] = None) -> bool
```

发送错误警告通知。

**参数:**
- `error_msg`: 错误信息
- `error_type`: 错误类型（可选）
- `context`: 错误上下文字典（可选）

**返回:**
- `bool`: 总是返回 True（异步发送）

**邮件内容:**
- 错误类型和信息
- 错误上下文
- 建议操作

## 高级配置

### 多个收件人

```python
email_config = EmailConfig(
    sender_email="sender@qq.com",
    sender_password="auth_code",
    receiver_email=[
        "receiver1@qq.com",
        "receiver2@gmail.com",
        "receiver3@outlook.com"
    ]
)
```

### 禁用邮件通知

```python
email_config = EmailConfig(
    sender_email="sender@qq.com",
    sender_password="auth_code",
    receiver_email="receiver@qq.com",
    enabled=False  # 禁用邮件
)
```

禁用后，所有通知方法仍然可以调用，但不会实际发送邮件。

### SSL 端口配置

```python
# 使用 SSL（端口 465）
email_config = EmailConfig(
    smtp_server="smtp.qq.com",
    smtp_port=465,  # SSL 端口
    sender_email="sender@qq.com",
    sender_password="auth_code",
    receiver_email="receiver@qq.com"
)
```

## 错误处理

### 常见错误

1. **认证失败**
   ```
   SMTP 认证失败: (535, b'Error: authentication failed')
   ```
   **解决方案**: 检查邮箱和授权码是否正确

2. **连接超时**
   ```
   邮件发送失败: [Errno 10060] A connection attempt failed
   ```
   **解决方案**: 检查网络连接和防火墙设置

3. **端口错误**
   ```
   邮件发送失败: [Errno 10061] No connection could be made
   ```
   **解决方案**: 确认 SMTP 端口正确（587 或 465）

### 日志记录

所有邮件发送操作都会记录详细日志：

```python
# 成功发送
2026-02-05 22:28:51 - ai_agent_monitor - INFO - 邮件发送成功: 找到目标显卡
2026-02-05 22:28:51 - ai_agent_monitor - INFO -   发件人: sender@qq.com
2026-02-05 22:28:51 - ai_agent_monitor - INFO -   收件人: receiver@qq.com

# 发送失败
2026-02-05 22:28:51 - ai_agent_monitor - ERROR - SMTP 认证失败: authentication failed
2026-02-05 22:28:51 - ai_agent_monitor - ERROR - 请检查发件人邮箱和密码（授权码）是否正确
```

## 测试

### 运行单元测试

```bash
python -m pytest tests/test_notification_service.py -v
```

### 运行集成测试

```bash
python -m pytest tests/test_notification_integration.py -v
```

### 运行演示

```bash
python examples/notification_demo.py
```

## 最佳实践

1. **使用授权码而非密码**
   - QQ 邮箱、Gmail 等都需要使用授权码
   - 授权码更安全，可以随时撤销

2. **异步发送**
   - 所有通知都是异步的，不会阻塞主流程
   - 适合在监控循环中使用

3. **错误容错**
   - 邮件发送失败不会影响监控
   - 错误会记录到日志中

4. **测试配置**
   - 在生产环境使用前先测试邮件配置
   - 使用演示脚本验证邮件发送

5. **日志监控**
   - 定期检查日志文件
   - 关注邮件发送失败的记录

## 故障排除

### 问题：邮件未收到

1. 检查垃圾邮件文件夹
2. 确认收件人邮箱正确
3. 查看日志确认是否发送成功
4. 检查邮箱服务商的发送限制

### 问题：认证失败

1. 确认使用的是授权码而非密码
2. 检查授权码是否过期
3. 确认 SMTP 服务已开启
4. 尝试重新生成授权码

### 问题：连接超时

1. 检查网络连接
2. 确认防火墙未阻止 SMTP 端口
3. 尝试使用不同的 SMTP 端口
4. 检查 SMTP 服务器地址是否正确

## 相关文档

- [配置管理指南](config_guide.md)
- [日志系统指南](logger_guide.md)
- [AI Agent 引擎指南](ai_agent_guide.md)

## 支持

如有问题，请查看：
1. 日志文件：`logs/monitor.log`
2. 测试文件：`tests/test_notification_service.py`
3. 演示脚本：`examples/notification_demo.py`
