"""
AI Shopping Agent - 智能购物监控代理
基于 AI 的电商产品监控和自动购买系统
"""

from setuptools import setup, find_packages
import os

# 读取 README
def read_file(filename):
    with open(filename, encoding='utf-8') as f:
        return f.read()

# 读取依赖
def read_requirements():
    with open('requirements.txt', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='ai-shopping-monitor',
    version='1.0.0',
    author='Your Name',
    author_email='your.email@example.com',
    description='AI-powered shopping monitor and auto-purchase agent',
    long_description=read_file('README.md'),
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/ai-shopping-monitor',
    packages=find_packages(exclude=['tests', 'tests.*', 'examples', 'docs']),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    python_requires='>=3.8',
    install_requires=read_requirements(),
    entry_points={
        'console_scripts': [
            'ai-shopping-monitor=src.cli:main',
        ],
    },
    include_package_data=True,
    package_data={
        'src': ['*.json'],
    },
    zip_safe=False,
)
