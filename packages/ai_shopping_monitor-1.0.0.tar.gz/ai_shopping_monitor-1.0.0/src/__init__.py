"""
AI Shopping Agent - 智能购物监控代理

基于 DeepSeek AI 的电商产品监控和自动购买系统
"""

__version__ = '1.0.0'
__author__ = 'Your Name'

from src.monitor_controller import MonitorController
from src.config_models import (
    MonitorConfig,
    TargetConfig,
    APIConfig,
    BrowserConfig,
    EmailConfig
)
from src.config_loader import ConfigLoader

# 简化的 API
class ShoppingAgent:
    """简化的购物代理 API"""
    
    def __init__(
        self,
        api_key: str,
        targets: list = None,
        check_interval: int = 30,
        max_pages: int = 3,
        email_config: dict = None,
        chrome_port: int = 9222
    ):
        """
        初始化购物代理
        
        Args:
            api_key: DeepSeek API 密钥
            targets: 监控目标列表，格式: [{"name": "产品名", "url": "搜索URL", "max_price": 价格}]
            check_interval: 检查间隔（秒）
            max_pages: 最大检查页数
            email_config: 邮件配置（可选）
            chrome_port: Chrome 调试端口
        """
        # 构建配置
        target_configs = []
        if targets:
            for t in targets:
                target_configs.append(TargetConfig(
                    name=t['name'],
                    search_url=t['url'],
                    keywords=t.get('keywords', [t['name']]),
                    max_price=t['max_price']
                ))
        
        api_config = APIConfig(
            api_key=api_key,
            base_url="https://api.deepseek.com",
            model_name="deepseek-chat"
        )
        
        browser_config = BrowserConfig(
            debug_port=chrome_port
        )
        
        email_cfg = None
        if email_config:
            email_cfg = EmailConfig(**email_config)
        
        self.config = MonitorConfig(
            check_interval=check_interval,
            max_pages=max_pages,
            targets=target_configs,
            api_config=api_config,
            browser_config=browser_config,
            email_config=email_cfg
        )
        
        self.controller = None
    
    def start(self):
        """启动监控"""
        self.controller = MonitorController(self.config)
        self.controller.start_monitoring()
    
    def stop(self):
        """停止监控"""
        if self.controller:
            self.controller.stop_monitoring()


__all__ = [
    'ShoppingAgent',
    'MonitorController',
    'MonitorConfig',
    'TargetConfig',
    'APIConfig',
    'BrowserConfig',
    'EmailConfig',
    'ConfigLoader',
]
