"""
AI Agent Engine

基于 DeepSeek API 的智能页面分析引擎，负责产品识别、库存检测和价格提取。
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from openai import OpenAI, RateLimitError, APITimeoutError, APIError
import time
import json

from src.config_models import APIConfig
from src.logger import get_logger
from src.page_context import PageContext


@dataclass
class ProductInfo:
    """产品信息数据类"""
    
    name: str                           # 产品名称
    model: str                          # 型号（5090/5080）
    brand: str                          # 品牌
    price: float                        # 价格
    price_text: str                     # 原始价格文本
    is_available: bool                  # 是否可购买
    product_url: str = ""               # 产品详情页 URL
    selector_hint: str = ""             # 按钮选择器提示
    confidence: float = 0.0             # 置信度 (0-1)
    reasoning: str = ""                 # AI 推理过程


@dataclass
class AnalysisResult:
    """AI 分析结果数据类"""
    
    products_found: List[ProductInfo] = field(default_factory=list)  # 找到的产品列表
    page_type: str = "unknown"          # 页面类型（搜索页/详情页）
    analysis_time: float = 0.0          # 分析耗时
    raw_response: str = ""              # 原始 API 响应


class AIAgentEngine:
    """AI Agent 引擎
    
    使用 DeepSeek API 进行页面分析，识别显卡产品、检测库存状态和提取价格信息。
    """
    
    def __init__(self, config: APIConfig):
        """初始化 AI 引擎
        
        Args:
            config: API 配置对象
            
        Raises:
            ValueError: 如果 API 密钥为空
        """
        self.config = config
        self.logger = get_logger()
        self.fallback_mode = False  # 降级模式标志
        
        # 验证 API 密钥
        if not config.api_key or config.api_key.strip() == "":
            raise ValueError("API 密钥不能为空")
        
        # 初始化 OpenAI 客户端（DeepSeek 兼容 OpenAI API）
        self.client = self._init_client()
        
        self.logger.info("AI Agent Engine 初始化完成")
        self.logger.info(f"模型: {config.model_name}")
        self.logger.info(f"API 基础 URL: {config.base_url}")
        self.logger.info(f"超时设置: {config.timeout}秒")
        self.logger.info(f"最大重试次数: {config.max_retries}")
    
    def _init_client(self) -> OpenAI:
        """初始化 DeepSeek API 客户端
        
        Returns:
            OpenAI 客户端实例
        """
        try:
            client = OpenAI(
                api_key=self.config.api_key,
                base_url=self.config.base_url,
                timeout=self.config.timeout
            )
            
            # 验证 API 密钥有效性（通过简单的 API 调用）
            self._validate_api_key(client)
            
            return client
        except Exception as e:
            self.logger.error(f"初始化 API 客户端失败: {e}")
            raise
    
    def _validate_api_key(self, client: OpenAI) -> bool:
        """验证 API 密钥有效性
        
        Args:
            client: OpenAI 客户端
            
        Returns:
            是否有效
            
        Raises:
            ValueError: 如果 API 密钥无效
        """
        try:
            # 发送一个简单的测试请求
            response = client.chat.completions.create(
                model=self.config.model_name,
                messages=[{"role": "user", "content": "test"}],
                max_tokens=5,
                timeout=10
            )
            
            self.logger.info("API 密钥验证成功")
            return True
        except Exception as e:
            error_msg = f"API 密钥验证失败: {e}"
            self.logger.error(error_msg)
            raise ValueError(error_msg)
    
    def analyze_search_page(self, context: PageContext, 
                           target_model: str,
                           max_price: float) -> AnalysisResult:
        """分析搜索结果页面
        
        使用 AI 分析搜索结果页面，识别符合条件的显卡产品。
        如果 API 失败，自动切换到基于规则的降级模式。
        
        Args:
            context: 页面上下文
            target_model: 目标型号（5090/5080）
            max_price: 最高价格
            
        Returns:
            分析结果，包含找到的产品列表
        """
        start_time = time.time()
        
        self.logger.info(f"开始分析搜索页面 - 目标型号: RTX {target_model}, 最高价格: ${max_price}")
        self.logger.debug(f"页面 URL: {context.url}")
        
        try:
            # 构建 prompt
            prompt = self._build_search_page_prompt(context, target_model, max_price)
            
            # 调用 API
            response = self._call_api(prompt)
            
            # 解析 JSON 响应
            data = self._parse_json_response(response)
            
            if data is None:
                self.logger.error("无法解析 API 响应为 JSON")
                return AnalysisResult(
                    products_found=[],
                    page_type="search",
                    analysis_time=time.time() - start_time,
                    raw_response=response
                )
            
            # 验证响应格式
            if "products" not in data:
                self.logger.warning("API 响应缺少 'products' 字段")
                return AnalysisResult(
                    products_found=[],
                    page_type="search",
                    analysis_time=time.time() - start_time,
                    raw_response=response
                )
            
            # 解析产品列表
            products = []
            for product_data in data["products"]:
                try:
                    product = self._parse_product_data(product_data)
                    if product:
                        products.append(product)
                        self.logger.info(
                            f"找到产品: {product.name} - "
                            f"${product.price} - "
                            f"可购买: {product.is_available} - "
                            f"置信度: {product.confidence:.2f}"
                        )
                        self.logger.debug(f"产品识别依据: {product.reasoning}")
                except Exception as e:
                    self.logger.warning(f"解析产品数据失败: {e}")
                    self.logger.debug(f"产品数据: {product_data}")
                    continue
            
            analysis_time = time.time() - start_time
            
            self.logger.info(
                f"搜索页面分析完成 - 找到 {len(products)} 个符合条件的产品 - "
                f"耗时: {analysis_time:.2f}秒"
            )
            
            return AnalysisResult(
                products_found=products,
                page_type="search",
                analysis_time=analysis_time,
                raw_response=response
            )
            
        except Exception as e:
            analysis_time = time.time() - start_time
            self.logger.error(f"搜索页面分析失败: {e}")
            self.logger.debug(f"错误详情", exc_info=True)
            
            # 切换到降级模式
            self.logger.warning("API 分析失败，切换到基于规则的降级模式")
            return self._fallback_analyze_search_page(context, target_model, max_price, analysis_time)
    
    def _build_search_page_prompt(self, context: PageContext,
                                  target_model: str,
                                  max_price: float) -> str:
        """构建搜索页面分析 Prompt
        
        根据页面上下文和目标参数构建用于 AI 分析的 prompt，包含产品识别规则、
        价格和库存检测指令，以及 JSON 输出格式要求。
        
        Args:
            context: 页面上下文
            target_model: 目标型号（5090/5080）
            max_price: 最高价格
            
        Returns:
            构建好的 prompt 字符串
        """
        prompt = f"""你是一个专业的电商页面分析助手。请分析以下 Best Buy 搜索结果页面，找出所有符合条件的 RTX {target_model} 显卡产品。

**重要规则**：
1. 只识别独立的显卡产品，排除以下类型：
   - 包含显卡的整机（Gaming PC, Desktop, Laptop, Computer System）
   - 显卡配件（支架、线缆、转接头、散热器、支撑架、GPU Bracket、Cable）
   - 礼品卡、保修服务、延保服务
   
2. 产品必须明确标注为 RTX {target_model}

3. 只返回有 "Add to Cart" 按钮的产品（可购买状态）
   - 排除 "Sold Out"（已售罄）
   - 排除 "Coming Soon"（即将上市）
   - 排除 "Check Stores"（仅店内取货）

4. 价格必须在 ${max_price} 以下

**页面内容**：
URL: {context.url}

可见文本：
{context.visible_text[:5000]}

**请以 JSON 格式返回结果**：
{{
  "products": [
    {{
      "name": "产品完整名称",
      "model": "{target_model}",
      "brand": "品牌名称（如 NVIDIA, ASUS, MSI, GIGABYTE 等）",
      "price": 1999.99,
      "price_text": "$1,999.99",
      "is_available": true,
      "product_url": "产品详情页 URL（完整 URL）",
      "selector_hint": "Add to Cart 按钮的文本或位置描述",
      "confidence": 0.95,
      "reasoning": "识别依据（为什么认为这是符合条件的显卡）"
    }}
  ]
}}

如果没有找到符合条件的产品，返回空数组：
{{
  "products": []
}}

注意：
- 确保提取的价格是数值类型（float），不包含货币符号
- product_url 应该是完整的 URL，如果是相对路径请补全为 https://www.bestbuy.com/...
- confidence 应该是 0 到 1 之间的数值，表示识别的置信度
- reasoning 应该简要说明为什么认为这是符合条件的显卡产品
"""
        
        return prompt
    
    def analyze_product_page(self, context: PageContext,
                            expected_model: str,
                            max_price: float) -> Optional[ProductInfo]:
        """分析产品详情页面
        
        使用 AI 分析产品详情页面，验证产品是否符合条件。
        
        Args:
            context: 页面上下文
            expected_model: 期望的型号（5090/5080）
            max_price: 最高价格
            
        Returns:
            产品信息，如果不是有效产品则返回 None
        """
        start_time = time.time()
        
        self.logger.info(f"开始分析产品页面 - 期望型号: RTX {expected_model}, 最高价格: ${max_price}")
        self.logger.debug(f"页面 URL: {context.url}")
        
        try:
            # 构建 prompt
            prompt = self._build_product_page_prompt(context, expected_model, max_price)
            
            # 调用 API
            response = self._call_api(prompt)
            
            # 解析 JSON 响应
            data = self._parse_json_response(response)
            
            if data is None:
                self.logger.error("无法解析 API 响应为 JSON")
                return None
            
            # 解析产品信息
            product = self._parse_product_data(data)
            
            if product is None:
                self.logger.warning("产品数据解析失败")
                return None
            
            analysis_time = time.time() - start_time
            
            # 检查产品是否有效
            if product.model == expected_model and product.confidence > 0.5:
                self.logger.info(
                    f"产品验证成功: {product.name} - "
                    f"${product.price} - "
                    f"可购买: {product.is_available} - "
                    f"置信度: {product.confidence:.2f} - "
                    f"耗时: {analysis_time:.2f}秒"
                )
                self.logger.debug(f"产品分析依据: {product.reasoning}")
                return product
            else:
                self.logger.info(
                    f"产品不符合条件 - "
                    f"型号: {product.model} (期望: {expected_model}) - "
                    f"置信度: {product.confidence:.2f} - "
                    f"耗时: {analysis_time:.2f}秒"
                )
                self.logger.debug(f"不符合原因: {product.reasoning}")
                return None
                
        except Exception as e:
            analysis_time = time.time() - start_time
            self.logger.error(f"产品页面分析失败: {e} - 耗时: {analysis_time:.2f}秒")
            self.logger.debug(f"错误详情", exc_info=True)
            return None
    
    def _build_product_page_prompt(self, context: PageContext,
                                   expected_model: str,
                                   max_price: float) -> str:
        """构建产品详情页分析 Prompt
        
        根据页面上下文和期望参数构建用于 AI 分析的 prompt，包含产品验证规则、
        价格和库存检测指令，以及按钮定位指令。
        
        Args:
            context: 页面上下文
            expected_model: 期望的型号（5090/5080）
            max_price: 最高价格
            
        Returns:
            构建好的 prompt 字符串
        """
        prompt = f"""你是一个专业的电商产品页面分析助手。请分析以下 Best Buy 产品详情页面。

**任务**：
1. 确认这是否是 RTX {expected_model} 显卡（不是整机或配件）
   - 必须是独立的显卡产品
   - 不能是包含显卡的整机（Gaming PC, Desktop, Laptop）
   - 不能是显卡配件（支架、线缆、转接头、散热器）
   
2. 提取准确的价格信息
   - 提取实际销售价格（如果有折扣，使用折扣后的价格）
   - 价格必须在 ${max_price} 以下
   
3. 判断当前库存状态（是否可以加入购物车）
   - 查找 "Add to Cart" 按钮表示可购买
   - "Sold Out" 表示已售罄
   - "Coming Soon" 表示即将上市
   - "Check Stores" 表示仅店内取货
   
4. 如果可购买，提供 "Add to Cart" 按钮的定位信息
   - 按钮的文本内容
   - 按钮的位置描述（如 "页面右侧"、"价格下方" 等）

**页面内容**：
URL: {context.url}

可见文本：
{context.visible_text[:5000]}

**请以 JSON 格式返回结果**：
{{
  "name": "产品完整名称",
  "model": "{expected_model}",
  "brand": "品牌名称（如 NVIDIA, ASUS, MSI, GIGABYTE 等）",
  "price": 1999.99,
  "price_text": "$1,999.99",
  "is_available": true,
  "product_url": "{context.url}",
  "selector_hint": "Add to Cart 按钮的文本或位置描述",
  "confidence": 0.95,
  "reasoning": "分析依据（为什么认为这是/不是符合条件的显卡）"
}}

如果这不是符合条件的 RTX {expected_model} 显卡（例如是整机或配件），请返回：
{{
  "name": "产品名称",
  "model": "",
  "brand": "",
  "price": 0,
  "price_text": "",
  "is_available": false,
  "product_url": "{context.url}",
  "selector_hint": "",
  "confidence": 0.0,
  "reasoning": "不符合条件的原因（如：这是整机而不是独立显卡）"
}}

注意：
- 确保提取的价格是数值类型（float），不包含货币符号
- is_available 应该是布尔值（true/false）
- confidence 应该是 0 到 1 之间的数值
- selector_hint 应该提供足够的信息来定位 "Add to Cart" 按钮
- reasoning 应该清楚说明判断依据
"""
        
        return prompt
    
    def _call_api(self, prompt: str, max_tokens: int = 2000) -> str:
        """调用 DeepSeek API（带超时、重试和速率限制处理）
        
        Args:
            prompt: 输入 prompt
            max_tokens: 最大生成 token 数
            
        Returns:
            API 响应文本
            
        Raises:
            Exception: 如果所有重试都失败
        """
        start_time = time.time()
        last_error = None
        
        for attempt in range(self.config.max_retries):
            try:
                self.logger.debug(f"API 调用尝试 {attempt + 1}/{self.config.max_retries}")
                
                # 调用 API（带超时）
                response = self.client.chat.completions.create(
                    model=self.config.model_name,
                    messages=[
                        {
                            "role": "system",
                            "content": "你是一个专业的电商页面分析助手，擅长识别显卡产品、检测库存状态和提取价格信息。"
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=self.config.temperature,
                    max_tokens=max_tokens,
                    timeout=self.config.timeout
                )
                
                # 提取响应内容
                content = response.choices[0].message.content
                
                # 记录成功的 API 调用
                duration = time.time() - start_time
                self.logger.info(f"API 调用成功 - 耗时: {duration:.2f}秒")
                self.logger.debug(f"请求 prompt 长度: {len(prompt)} 字符")
                self.logger.debug(f"响应内容长度: {len(content)} 字符")
                
                return content
                
            except RateLimitError as e:
                # 速率限制错误 - 使用指数退避
                last_error = e
                wait_time = 2 ** attempt  # 指数退避: 1s, 2s, 4s
                self.logger.warning(
                    f"遇到速率限制 (尝试 {attempt + 1}/{self.config.max_retries}), "
                    f"等待 {wait_time} 秒后重试"
                )
                self.logger.debug(f"速率限制错误详情: {e}")
                
                if attempt < self.config.max_retries - 1:
                    time.sleep(wait_time)
                else:
                    self.logger.error(f"达到最大重试次数，速率限制错误: {e}")
                    
            except APITimeoutError as e:
                # 超时错误
                last_error = e
                self.logger.warning(
                    f"API 调用超时 (尝试 {attempt + 1}/{self.config.max_retries}), "
                    f"超时设置: {self.config.timeout}秒"
                )
                self.logger.debug(f"超时错误详情: {e}")
                
                if attempt < self.config.max_retries - 1:
                    # 短暂等待后重试
                    time.sleep(1)
                else:
                    self.logger.error(f"达到最大重试次数，API 超时: {e}")
                    
            except APIError as e:
                # 其他 API 错误
                last_error = e
                self.logger.error(
                    f"API 调用错误 (尝试 {attempt + 1}/{self.config.max_retries}): {e}"
                )
                self.logger.debug(f"API 错误详情: {e}")
                
                if attempt < self.config.max_retries - 1:
                    # 短暂等待后重试
                    time.sleep(1)
                else:
                    self.logger.error(f"达到最大重试次数，API 错误: {e}")
                    
            except Exception as e:
                # 未预期的错误
                last_error = e
                self.logger.error(
                    f"未预期的错误 (尝试 {attempt + 1}/{self.config.max_retries}): {e}"
                )
                self.logger.debug(f"错误详情: {e}", exc_info=True)
                
                if attempt < self.config.max_retries - 1:
                    time.sleep(1)
                else:
                    self.logger.error(f"达到最大重试次数，未预期错误: {e}")
        
        # 所有重试都失败
        duration = time.time() - start_time
        error_msg = f"API 调用失败，已重试 {self.config.max_retries} 次，总耗时: {duration:.2f}秒"
        self.logger.error(error_msg)
        self.logger.error(f"最后一次错误: {last_error}")
        
        raise Exception(f"{error_msg}. 最后错误: {last_error}")
    
    def _parse_json_response(self, response: str) -> Optional[Dict[str, Any]]:
        """解析 JSON 响应
        
        Args:
            response: API 响应文本
            
        Returns:
            解析后的字典，如果解析失败返回 None
        """
        try:
            # 尝试直接解析
            data = json.loads(response)
            return data
        except json.JSONDecodeError as e:
            self.logger.warning(f"JSON 解析失败: {e}")
            self.logger.debug(f"原始响应: {response[:500]}")
            
            # 尝试提取 JSON 代码块（如果 AI 返回了 markdown 格式）
            try:
                if "```json" in response:
                    start = response.find("```json") + 7
                    end = response.find("```", start)
                    json_str = response[start:end].strip()
                    data = json.loads(json_str)
                    self.logger.info("从 markdown 代码块中成功提取 JSON")
                    return data
                elif "```" in response:
                    start = response.find("```") + 3
                    end = response.find("```", start)
                    json_str = response[start:end].strip()
                    data = json.loads(json_str)
                    self.logger.info("从代码块中成功提取 JSON")
                    return data
            except Exception as e2:
                self.logger.error(f"从代码块提取 JSON 失败: {e2}")
            
            return None
    
    def _parse_product_data(self, data: Dict[str, Any]) -> Optional[ProductInfo]:
        """解析产品数据字典为 ProductInfo 对象
        
        Args:
            data: 产品数据字典
            
        Returns:
            ProductInfo 对象，如果解析失败返回 None
        """
        try:
            # 验证必需字段
            required_fields = ['name', 'model', 'brand', 'price', 'is_available']
            for field in required_fields:
                if field not in data:
                    self.logger.warning(f"产品数据缺少必需字段: {field}")
                    return None
            
            # 验证价格
            price = data['price']
            if not isinstance(price, (int, float)):
                self.logger.warning(f"无效的价格类型: {type(price)}")
                return None
            
            if price < 0 or price > 10000:
                self.logger.warning(f"价格超出合理范围: ${price}")
                return None
            
            # 验证型号
            model = data['model']
            if model not in ['5090', '5080', '']:
                self.logger.warning(f"无效的型号: {model}")
                # 不返回 None，因为可能是不符合条件的产品
            
            # 创建 ProductInfo 对象
            product = ProductInfo(
                name=data['name'],
                model=data['model'],
                brand=data['brand'],
                price=float(price),
                price_text=data.get('price_text', f"${price}"),
                is_available=bool(data['is_available']),
                product_url=data.get('product_url', ''),
                selector_hint=data.get('selector_hint', ''),
                confidence=float(data.get('confidence', 0.0)),
                reasoning=data.get('reasoning', '')
            )
            
            return product
            
        except Exception as e:
            self.logger.error(f"解析产品数据失败: {e}")
            self.logger.debug(f"产品数据: {data}")
            return None

    
    def _fallback_analyze_search_page(self, context: PageContext,
                                      target_model: str,
                                      max_price: float,
                                      api_time: float) -> AnalysisResult:
        """基于规则的备用产品识别方法（降级策略）
        
        当 API 失败时，使用传统的关键词匹配和规则来识别产品。
        
        Args:
            context: 页面上下文
            target_model: 目标型号（5090/5080）
            max_price: 最高价格
            api_time: API 尝试耗时
            
        Returns:
            分析结果
        """
        import re
        
        start_time = time.time()
        
        self.logger.info("【降级模式】使用基于规则的产品识别")
        self.fallback_mode = True
        
        try:
            text = context.visible_text.lower()
            products = []
            
            # 规则 1: 检查是否包含目标型号
            if f"rtx {target_model}" not in text and f"rtx{target_model}" not in text:
                self.logger.info(f"【降级模式】页面不包含 RTX {target_model}")
                return AnalysisResult(
                    products_found=[],
                    page_type="search",
                    analysis_time=api_time + (time.time() - start_time),
                    raw_response="fallback_mode"
                )
            
            # 规则 2: 检查是否有 "Add to Cart" 按钮
            has_add_to_cart = "add to cart" in text
            
            if not has_add_to_cart:
                self.logger.info("【降级模式】页面没有 'Add to Cart' 按钮")
                return AnalysisResult(
                    products_found=[],
                    page_type="search",
                    analysis_time=api_time + (time.time() - start_time),
                    raw_response="fallback_mode"
                )
            
            # 规则 3: 排除整机关键词
            exclude_keywords = [
                "gaming pc", "desktop", "laptop", "computer system",
                "gaming computer", "gaming desktop", "gaming laptop",
                "pc with", "desktop with", "laptop with"
            ]
            
            is_complete_system = any(keyword in text for keyword in exclude_keywords)
            
            if is_complete_system:
                self.logger.info("【降级模式】检测到整机关键词，排除")
                return AnalysisResult(
                    products_found=[],
                    page_type="search",
                    analysis_time=api_time + (time.time() - start_time),
                    raw_response="fallback_mode"
                )
            
            # 规则 4: 排除配件关键词
            accessory_keywords = [
                "bracket", "cable", "adapter", "mount", "stand",
                "support", "holder", "riser", "gpu bracket", "gpu support"
            ]
            
            is_accessory = any(keyword in text for keyword in accessory_keywords)
            
            if is_accessory:
                self.logger.info("【降级模式】检测到配件关键词，排除")
                return AnalysisResult(
                    products_found=[],
                    page_type="search",
                    analysis_time=api_time + (time.time() - start_time),
                    raw_response="fallback_mode"
                )
            
            # 规则 5: 提取价格（简单的正则匹配）
            price_pattern = r'\$\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)'
            price_matches = re.findall(price_pattern, context.visible_text)
            
            extracted_price = None
            if price_matches:
                # 取第一个价格
                price_str = price_matches[0].replace(',', '')
                try:
                    extracted_price = float(price_str)
                except:
                    extracted_price = None
            
            # 如果没有提取到价格或价格超过阈值，返回空结果
            if extracted_price is None:
                self.logger.warning("【降级模式】无法提取价格")
                extracted_price = 0.0
            elif extracted_price > max_price:
                self.logger.info(f"【降级模式】价格 ${extracted_price:.2f} 超过阈值 ${max_price:.2f}")
                return AnalysisResult(
                    products_found=[],
                    page_type="search",
                    analysis_time=api_time + (time.time() - start_time),
                    raw_response="fallback_mode"
                )
            
            # 规则 6: 构建产品信息
            # 尝试提取品牌
            brand_keywords = ["nvidia", "asus", "msi", "gigabyte", "evga", "zotac", "pny", "palit"]
            detected_brand = "Unknown"
            
            for brand in brand_keywords:
                if brand in text:
                    detected_brand = brand.upper()
                    break
            
            # 构建产品名称
            product_name = f"{detected_brand} GeForce RTX {target_model}"
            
            # 创建产品信息
            product = ProductInfo(
                name=product_name,
                model=target_model,
                brand=detected_brand,
                price=extracted_price,
                price_text=f"${extracted_price:.2f}" if extracted_price > 0 else "Unknown",
                is_available=has_add_to_cart,
                product_url=context.url,
                selector_hint="Add to Cart",
                confidence=0.6,  # 降级模式置信度较低
                reasoning="【降级模式】基于规则匹配识别"
            )
            
            products.append(product)
            
            self.logger.info(
                f"【降级模式】找到产品: {product.name} - "
                f"${product.price:.2f} - "
                f"置信度: {product.confidence:.2f}"
            )
            
            analysis_time = api_time + (time.time() - start_time)
            
            return AnalysisResult(
                products_found=products,
                page_type="search",
                analysis_time=analysis_time,
                raw_response="fallback_mode"
            )
            
        except Exception as e:
            self.logger.error(f"【降级模式】分析失败: {e}", exc_info=True)
            
            return AnalysisResult(
                products_found=[],
                page_type="search",
                analysis_time=api_time + (time.time() - start_time),
                raw_response="fallback_mode_error"
            )
