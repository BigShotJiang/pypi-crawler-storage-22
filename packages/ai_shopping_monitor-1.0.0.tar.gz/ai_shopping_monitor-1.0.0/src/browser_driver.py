"""
Browser Driver

封装 Selenium 浏览器操作，提供页面导航、上下文提取和购买操作功能。
"""

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException, 
    NoSuchElementException,
    WebDriverException
)
import time
from typing import Optional, Tuple

from src.config_models import BrowserConfig
from src.page_context import PageContext, PageContextExtractor
from src.logger import get_logger


class BrowserDriver:
    """浏览器驱动
    
    封装 Selenium WebDriver 操作，提供连接、导航、提取和购买功能。
    """
    
    def __init__(self, config: BrowserConfig):
        """初始化浏览器驱动
        
        Args:
            config: 浏览器配置对象
        """
        self.config = config
        self.driver: Optional[WebDriver] = None
        self.extractor = PageContextExtractor()
        self.logger = get_logger()
    
    def connect(self) -> bool:
        """连接到 Chrome 调试端口
        
        连接到已启动的 Chrome 实例（通过调试端口）。
        
        Returns:
            是否连接成功
        """
        try:
            self.logger.info(f"正在连接到 Chrome 调试端口 {self.config.debug_port}...")
            
            # 配置 Chrome 选项
            chrome_options = Options()
            chrome_options.add_experimental_option(
                "debuggerAddress", 
                f"127.0.0.1:{self.config.debug_port}"
            )
            
            # 添加反检测选项
            chrome_options.add_argument('--disable-blink-features=AutomationControlled')
            chrome_options.add_argument('--disable-dev-shm-usage')
            
            # 创建 WebDriver 实例
            self.driver = webdriver.Chrome(options=chrome_options)
            
            # 设置超时
            self.driver.set_page_load_timeout(self.config.page_load_timeout)
            self.driver.implicitly_wait(self.config.implicit_wait)
            
            self.logger.info("成功连接到 Chrome")
            return True
            
        except WebDriverException as e:
            self.logger.error(f"连接到 Chrome 失败: {e}")
            self.driver = None
            return False
        except Exception as e:
            self.logger.error(f"连接过程中发生未知错误: {e}", exc_info=True)
            self.driver = None
            return False
    
    def navigate_to(self, url: str, max_retries: int = 3) -> bool:
        """导航到指定 URL（带重试和超时处理）
        
        Args:
            url: 目标 URL
            max_retries: 最大重试次数（默认 3 次）
            
        Returns:
            是否导航成功
        """
        if not self.driver:
            self.logger.error("WebDriver 未初始化，无法导航")
            return False
        
        for attempt in range(max_retries):
            try:
                self.logger.info(f"导航到 {url} (尝试 {attempt + 1}/{max_retries})")
                
                # 使用 JavaScript 导航（更稳定）
                self.driver.execute_script(f"window.location.href = '{url}';")
                
                # 等待页面加载完成
                time.sleep(2)
                
                # 验证导航成功
                current_url = self.driver.current_url
                if url in current_url or current_url.startswith('http'):
                    self.logger.info(f"成功导航到 {current_url}")
                    return True
                else:
                    raise Exception(f"URL 不匹配: 期望 {url}, 实际 {current_url}")
                    
            except TimeoutException:
                self.logger.warning(f"页面加载超时 (尝试 {attempt + 1}/{max_retries})")
                
                # 尝试停止页面加载
                try:
                    self.driver.execute_script("window.stop();")
                    self.logger.info("已停止页面加载，尝试继续")
                    
                    # 检查是否部分加载成功
                    current_url = self.driver.current_url
                    if url in current_url:
                        self.logger.info("页面部分加载成功，继续")
                        return True
                except:
                    pass
                
                if attempt < max_retries - 1:
                    time.sleep(2)  # 重试前等待
                else:
                    self.logger.error(f"导航失败: 超过最大重试次数")
                    return False
                    
            except Exception as e:
                self.logger.error(f"导航失败 (尝试 {attempt + 1}/{max_retries}): {e}")
                
                if attempt < max_retries - 1:
                    time.sleep(2)  # 重试前等待
                else:
                    self.logger.error(f"导航失败: 超过最大重试次数")
                    return False
        
        return False
    
    def extract_page_context(self, include_screenshot: bool = False) -> Optional[PageContext]:
        """提取页面上下文
        
        Args:
            include_screenshot: 是否包含截图（默认 False）
            
        Returns:
            PageContext 对象，如果提取失败则返回 None
        """
        if not self.driver:
            self.logger.error("WebDriver 未初始化，无法提取页面上下文")
            return None
        
        try:
            self.logger.debug("开始提取页面上下文")
            context = self.extractor.extract_from_driver(
                self.driver, 
                include_screenshot=include_screenshot
            )
            self.logger.info("页面上下文提取成功")
            return context
            
        except Exception as e:
            self.logger.error(f"提取页面上下文失败: {e}", exc_info=True)
            return None
    
    def click_add_to_cart(self, selector_hint: str = "") -> bool:
        """点击加入购物车按钮（使用 AI 提供的选择器提示）
        
        Args:
            selector_hint: AI 提供的选择器提示（可选）
            
        Returns:
            是否点击成功
        """
        if not self.driver:
            self.logger.error("WebDriver 未初始化，无法点击按钮")
            return False
        
        try:
            self.logger.info("查找 Add to Cart 按钮...")
            
            # 使用 JavaScript 查找并点击按钮
            js_click = """
            var buttons = document.querySelectorAll('button');
            for (var i = 0; i < buttons.length; i++) {
                var text = buttons[i].textContent.toLowerCase();
                if (text.includes('add') && text.includes('cart')) {
                    // 检查按钮是否可用
                    if (!buttons[i].disabled) {
                        buttons[i].scrollIntoView();
                        buttons[i].click();
                        return true;
                    }
                }
            }
            return false;
            """
            
            clicked = self.driver.execute_script(js_click)
            
            if clicked:
                self.logger.info("成功点击 Add to Cart 按钮")
                time.sleep(2)  # 等待加入购物车
                return True
            else:
                self.logger.warning("未找到可用的 Add to Cart 按钮")
                return False
                
        except Exception as e:
            self.logger.error(f"点击 Add to Cart 按钮失败: {e}", exc_info=True)
            return False
    
    def navigate_to_checkout(self) -> Tuple[bool, str]:
        """导航到结账页面
        
        执行以下步骤：
        1. 导航到购物车页面
        2. 点击 Checkout 按钮
        3. 验证是否到达结账页面
        
        Returns:
            (是否成功, 结账页面 URL)
        """
        if not self.driver:
            self.logger.error("WebDriver 未初始化，无法导航到结账页面")
            return False, ""
        
        try:
            # 步骤 1: 导航到购物车
            self.logger.info("导航到购物车页面...")
            cart_url = "https://www.bestbuy.com/cart"
            
            if not self.navigate_to(cart_url, max_retries=2):
                self.logger.error("无法导航到购物车页面")
                return False, ""
            
            time.sleep(2)  # 等待购物车加载
            
            # 步骤 2: 点击 Checkout 按钮
            self.logger.info("查找 Checkout 按钮...")
            
            js_checkout = """
            var buttons = document.querySelectorAll('button, a');
            for (var i = 0; i < buttons.length; i++) {
                var text = buttons[i].textContent.toLowerCase();
                if (text.includes('checkout') || text.includes('check out')) {
                    // 检查按钮是否可用
                    if (!buttons[i].disabled && !buttons[i].classList.contains('disabled')) {
                        buttons[i].scrollIntoView();
                        buttons[i].click();
                        return true;
                    }
                }
            }
            return false;
            """
            
            clicked = self.driver.execute_script(js_checkout)
            
            if not clicked:
                self.logger.error("未找到可用的 Checkout 按钮")
                return False, ""
            
            self.logger.info("成功点击 Checkout 按钮")
            time.sleep(3)  # 等待跳转到结账页面
            
            # 步骤 3: 验证是否到达结账页面
            current_url = self.driver.current_url
            
            if 'checkout' in current_url.lower():
                self.logger.info(f"成功到达结账页面: {current_url}")
                return True, current_url
            else:
                self.logger.warning(f"未到达结账页面，当前 URL: {current_url}")
                return False, current_url
                
        except Exception as e:
            self.logger.error(f"导航到结账页面失败: {e}", exc_info=True)
            return False, ""
    
    def close(self):
        """关闭浏览器连接"""
        if self.driver:
            try:
                self.logger.info("关闭浏览器连接...")
                self.driver.quit()
                self.driver = None
                self.logger.info("浏览器连接已关闭")
            except Exception as e:
                self.logger.error(f"关闭浏览器连接失败: {e}")
    
    def is_alive(self) -> bool:
        """检测 Chrome 是否仍在运行
        
        Returns:
            Chrome 是否存活
        """
        if not self.driver:
            self.logger.debug("WebDriver 未初始化")
            return False
        
        try:
            # 尝试获取当前 URL 来检测连接是否有效
            _ = self.driver.current_url
            return True
        except WebDriverException as e:
            self.logger.warning(f"Chrome 连接已断开: {e}")
            return False
        except Exception as e:
            self.logger.error(f"检测 Chrome 状态时发生错误: {e}")
            return False
    
    def reconnect(self, max_retries: int = 3) -> bool:
        """重新连接到 Chrome
        
        尝试重新连接到已启动的 Chrome 实例。
        
        Args:
            max_retries: 最大重试次数（默认 3 次）
            
        Returns:
            是否重新连接成功
        """
        self.logger.info("尝试重新连接到 Chrome...")
        
        # 先关闭现有连接
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None
        
        # 等待一段时间让 Chrome 稳定
        time.sleep(2)
        
        # 尝试重新连接
        for attempt in range(max_retries):
            self.logger.info(f"重新连接尝试 {attempt + 1}/{max_retries}")
            
            if self.connect():
                self.logger.info("重新连接成功")
                return True
            
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # 指数退避: 1s, 2s, 4s
                self.logger.info(f"等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
        
        self.logger.error(f"重新连接失败，已尝试 {max_retries} 次")
        return False
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器退出"""
        self.close()
