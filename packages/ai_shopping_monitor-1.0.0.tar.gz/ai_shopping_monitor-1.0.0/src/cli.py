#!/usr/bin/env python3
"""
AI Shopping Agent - Command Line Interface
"""

import sys
import argparse
from pathlib import Path

from src.config_loader import ConfigLoader
from src.monitor_controller import MonitorController
from src.logger import setup_logger


VERSION = "1.0.0"


def print_banner():
    """打印横幅"""
    banner = f"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║              AI Shopping Agent v{VERSION}                                  ║
║                                                                           ║
║              智能购物监控代理 - 基于 DeepSeek AI                            ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
"""
    print(banner)


def create_parser():
    """创建命令行参数解析器"""
    parser = argparse.ArgumentParser(
        description="AI Shopping Agent - 智能购物监控代理",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 使用默认配置启动
  ai-shopping-agent start
  
  # 使用指定配置文件
  ai-shopping-agent start -c my_config.json
  
  # 创建示例配置
  ai-shopping-agent init
  
  # 运行测试
  ai-shopping-agent test
        """
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {VERSION}')
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # start 命令
    start_parser = subparsers.add_parser('start', help='启动监控')
    start_parser.add_argument(
        '-c', '--config',
        type=str,
        default='config/config.json',
        help='配置文件路径'
    )
    start_parser.add_argument(
        '--no-validate',
        action='store_true',
        help='跳过配置验证'
    )
    start_parser.add_argument(
        '--daemon',
        action='store_true',
        help='以守护进程模式运行'
    )
    
    # init 命令
    init_parser = subparsers.add_parser('init', help='初始化配置文件')
    init_parser.add_argument(
        '-o', '--output',
        type=str,
        default='config/config.json',
        help='输出配置文件路径'
    )
    
    # test 命令
    test_parser = subparsers.add_parser('test', help='运行测试')
    test_parser.add_argument(
        '--api-key',
        type=str,
        help='DeepSeek API 密钥'
    )
    
    return parser


def cmd_start(args):
    """启动监控命令"""
    print_banner()
    print(f"加载配置: {args.config}")
    
    try:
        # 加载配置
        config = ConfigLoader.load_or_create_default(
            config_path=args.config,
            create_if_missing=True,
            validate=not args.no_validate
        )
        
        print("✓ 配置加载成功\n")
        
        # 初始化监控控制器
        print("初始化监控系统...")
        controller = MonitorController(config)
        print("✓ 监控系统初始化完成\n")
        
        # 显示监控信息
        print("=" * 79)
        print("监控配置:")
        print(f"  检查间隔: {config.check_interval} 秒")
        print(f"  最大页数: {config.max_pages}")
        print(f"  监控目标: {len(config.targets)} 个")
        for i, target in enumerate(config.targets, 1):
            print(f"    {i}. {target.name} - 最高价格: ${target.max_price:.2f}")
        print("\n按 Ctrl+C 停止监控")
        print("=" * 79)
        print()
        
        # 启动监控
        if args.daemon:
            print("以守护进程模式运行...")
            # TODO: 实现守护进程模式
            controller.start_monitoring()
        else:
            controller.start_monitoring()
        
        return 0
        
    except KeyboardInterrupt:
        print("\n\n收到中断信号，正在停止...")
        return 0
        
    except Exception as e:
        print(f"\n✗ 错误: {e}", file=sys.stderr)
        return 1


def cmd_init(args):
    """初始化配置命令"""
    print_banner()
    print(f"创建配置文件: {args.output}")
    
    try:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        ConfigLoader.create_example_config(str(output_path))
        
        print(f"✓ 配置文件已创建: {args.output}")
        print("\n请编辑配置文件，填入你的 API 密钥和监控目标")
        return 0
        
    except Exception as e:
        print(f"✗ 创建配置文件失败: {e}", file=sys.stderr)
        return 1


def cmd_test(args):
    """测试命令"""
    print_banner()
    print("运行系统测试...\n")
    
    try:
        import subprocess
        result = subprocess.run(
            [sys.executable, '-m', 'pytest', 'tests/', '-v'],
            capture_output=False
        )
        return result.returncode
        
    except Exception as e:
        print(f"✗ 测试失败: {e}", file=sys.stderr)
        return 1


def main():
    """主入口函数"""
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    # 执行命令
    if args.command == 'start':
        return cmd_start(args)
    elif args.command == 'init':
        return cmd_init(args)
    elif args.command == 'test':
        return cmd_test(args)
    else:
        parser.print_help()
        return 1


if __name__ == '__main__':
    sys.exit(main())
