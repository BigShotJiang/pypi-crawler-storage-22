"""
配置应用器

确保所有组件正确使用配置参数，提供配置应用验证功能。
"""

import logging
from typing import Dict, List, Tuple

from src.config_models import MonitorConfig


logger = logging.getLogger(__name__)


class ConfigApplicator:
    """配置应用器
    
    验证配置是否正确应用到各个组件。
    """
    
    @staticmethod
    def verify_config_application(config: MonitorConfig, 
                                  components: Dict[str, object]) -> Tuple[bool, List[str]]:
        """验证配置是否正确应用到组件
        
        Args:
            config: 监控配置对象
            components: 组件字典 {"component_name": component_instance}
            
        Returns:
            (是否全部正确应用, 警告信息列表)
        """
        warnings = []
        
        # 验证 AI Agent Engine
        if "agent" in components and components["agent"]:
            agent = components["agent"]
            agent_warnings = ConfigApplicator._verify_agent_config(config, agent)
            warnings.extend(agent_warnings)
        
        # 验证 Browser Driver
        if "browser" in components and components["browser"]:
            browser = components["browser"]
            browser_warnings = ConfigApplicator._verify_browser_config(config, browser)
            warnings.extend(browser_warnings)
        
        # 验证 Notification Service
        if "notifier" in components and components["notifier"]:
            notifier = components["notifier"]
            notifier_warnings = ConfigApplicator._verify_notifier_config(config, notifier)
            warnings.extend(notifier_warnings)
        
        # 验证 Monitor Controller
        if "controller" in components and components["controller"]:
            controller = components["controller"]
            controller_warnings = ConfigApplicator._verify_controller_config(config, controller)
            warnings.extend(controller_warnings)
        
        is_valid = len(warnings) == 0
        
        if is_valid:
            logger.info("配置应用验证通过 - 所有组件正确使用配置参数")
        else:
            logger.warning(f"配置应用验证发现 {len(warnings)} 个警告")
            for warning in warnings:
                logger.warning(f"  - {warning}")
        
        return is_valid, warnings
    
    @staticmethod
    def _verify_agent_config(config: MonitorConfig, agent) -> List[str]:
        """验证 AI Agent 配置应用
        
        Args:
            config: 监控配置
            agent: AI Agent 实例
            
        Returns:
            警告信息列表
        """
        warnings = []
        
        if not hasattr(agent, 'config'):
            warnings.append("AI Agent: 缺少 config 属性")
            return warnings
        
        agent_config = agent.config
        expected_config = config.api_config
        
        # 验证 API 密钥
        if agent_config.api_key != expected_config.api_key:
            warnings.append("AI Agent: API 密钥未正确应用")
        
        # 验证 base_url
        if agent_config.base_url != expected_config.base_url:
            warnings.append("AI Agent: base_url 未正确应用")
        
        # 验证 model_name
        if agent_config.model_name != expected_config.model_name:
            warnings.append("AI Agent: model_name 未正确应用")
        
        # 验证 timeout
        if agent_config.timeout != expected_config.timeout:
            warnings.append("AI Agent: timeout 未正确应用")
        
        # 验证 max_retries
        if agent_config.max_retries != expected_config.max_retries:
            warnings.append("AI Agent: max_retries 未正确应用")
        
        # 验证 temperature
        if agent_config.temperature != expected_config.temperature:
            warnings.append("AI Agent: temperature 未正确应用")
        
        return warnings
    
    @staticmethod
    def _verify_browser_config(config: MonitorConfig, browser) -> List[str]:
        """验证浏览器配置应用
        
        Args:
            config: 监控配置
            browser: Browser Driver 实例
            
        Returns:
            警告信息列表
        """
        warnings = []
        
        if not hasattr(browser, 'config'):
            warnings.append("Browser Driver: 缺少 config 属性")
            return warnings
        
        browser_config = browser.config
        expected_config = config.browser_config
        
        # 验证 debug_port
        if browser_config.debug_port != expected_config.debug_port:
            warnings.append("Browser Driver: debug_port 未正确应用")
        
        # 验证 page_load_timeout
        if browser_config.page_load_timeout != expected_config.page_load_timeout:
            warnings.append("Browser Driver: page_load_timeout 未正确应用")
        
        # 验证 implicit_wait
        if browser_config.implicit_wait != expected_config.implicit_wait:
            warnings.append("Browser Driver: implicit_wait 未正确应用")
        
        return warnings
    
    @staticmethod
    def _verify_notifier_config(config: MonitorConfig, notifier) -> List[str]:
        """验证通知服务配置应用
        
        Args:
            config: 监控配置
            notifier: Notification Service 实例
            
        Returns:
            警告信息列表
        """
        warnings = []
        
        if not hasattr(notifier, 'config'):
            warnings.append("Notification Service: 缺少 config 属性")
            return warnings
        
        notifier_config = notifier.config
        expected_config = config.email_config
        
        # 验证 enabled
        if notifier_config.enabled != expected_config.enabled:
            warnings.append("Notification Service: enabled 未正确应用")
        
        # 验证 smtp_server
        if notifier_config.smtp_server != expected_config.smtp_server:
            warnings.append("Notification Service: smtp_server 未正确应用")
        
        # 验证 smtp_port
        if notifier_config.smtp_port != expected_config.smtp_port:
            warnings.append("Notification Service: smtp_port 未正确应用")
        
        # 验证 sender_email
        if notifier_config.sender_email != expected_config.sender_email:
            warnings.append("Notification Service: sender_email 未正确应用")
        
        # 验证 receiver_email
        if notifier_config.receiver_email != expected_config.receiver_email:
            warnings.append("Notification Service: receiver_email 未正确应用")
        
        return warnings
    
    @staticmethod
    def _verify_controller_config(config: MonitorConfig, controller) -> List[str]:
        """验证监控控制器配置应用
        
        Args:
            config: 监控配置
            controller: Monitor Controller 实例
            
        Returns:
            警告信息列表
        """
        warnings = []
        
        if not hasattr(controller, 'config'):
            warnings.append("Monitor Controller: 缺少 config 属性")
            return warnings
        
        controller_config = controller.config
        
        # 验证 check_interval
        if controller_config.check_interval != config.check_interval:
            warnings.append("Monitor Controller: check_interval 未正确应用")
        
        # 验证 max_pages
        if controller_config.max_pages != config.max_pages:
            warnings.append("Monitor Controller: max_pages 未正确应用")
        
        # 验证 targets
        if len(controller_config.targets) != len(config.targets):
            warnings.append("Monitor Controller: targets 数量不匹配")
        
        return warnings
    
    @staticmethod
    def print_config_summary(config: MonitorConfig) -> None:
        """打印配置摘要
        
        Args:
            config: 监控配置对象
        """
        logger.info("=" * 80)
        logger.info("配置摘要")
        logger.info("=" * 80)
        
        # 监控配置
        logger.info("监控配置:")
        logger.info(f"  检查间隔: {config.check_interval} 秒")
        logger.info(f"  最大页数: {config.max_pages}")
        logger.info(f"  监控目标数: {len(config.targets)}")
        
        # 目标配置
        for i, target in enumerate(config.targets, 1):
            logger.info(f"  目标 {i}:")
            logger.info(f"    名称: {target.name}")
            logger.info(f"    最高价格: ${target.max_price:.2f}")
            logger.info(f"    关键词: {', '.join(target.keywords)}")
        
        # API 配置
        if config.api_config:
            logger.info("API 配置:")
            logger.info(f"  模型: {config.api_config.model_name}")
            logger.info(f"  Base URL: {config.api_config.base_url}")
            logger.info(f"  超时: {config.api_config.timeout} 秒")
            logger.info(f"  最大重试: {config.api_config.max_retries}")
            logger.info(f"  温度: {config.api_config.temperature}")
            # 不打印 API 密钥
            logger.info(f"  API 密钥: {'已配置' if config.api_config.api_key else '未配置'}")
        
        # 浏览器配置
        if config.browser_config:
            logger.info("浏览器配置:")
            logger.info(f"  调试端口: {config.browser_config.debug_port}")
            logger.info(f"  页面加载超时: {config.browser_config.page_load_timeout} 秒")
            logger.info(f"  隐式等待: {config.browser_config.implicit_wait} 秒")
        
        # 邮件配置
        if config.email_config:
            logger.info("邮件配置:")
            logger.info(f"  启用状态: {'启用' if config.email_config.enabled else '禁用'}")
            if config.email_config.enabled:
                logger.info(f"  SMTP 服务器: {config.email_config.smtp_server}:{config.email_config.smtp_port}")
                logger.info(f"  发件人: {config.email_config.sender_email}")
                logger.info(f"  收件人: {config.email_config.receiver_email}")
        
        # 日志配置
        if config.log_config:
            logger.info("日志配置:")
            logger.info(f"  级别: {config.log_config.get('level', 'INFO')}")
            logger.info(f"  文件: {config.log_config.get('file', 'logs/monitor.log')}")
            logger.info(f"  控制台: {'启用' if config.log_config.get('console', True) else '禁用'}")
        
        logger.info("=" * 80)
