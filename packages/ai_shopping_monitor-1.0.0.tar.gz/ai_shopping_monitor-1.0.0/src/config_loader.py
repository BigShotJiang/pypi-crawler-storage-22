"""
配置文件加载器

支持从 JSON 和 YAML 文件加载配置，并转换为配置数据模型。
"""

import json
import os
from pathlib import Path
from typing import Optional
import logging

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

from src.config_models import (
    MonitorConfig, APIConfig, BrowserConfig, 
    EmailConfig, TargetConfig
)
from src.config_validator import ConfigValidator


logger = logging.getLogger(__name__)


class ConfigLoader:
    """配置文件加载器"""
    
    @staticmethod
    def load_from_file(config_path: str, validate: bool = True) -> MonitorConfig:
        """从文件加载配置
        
        Args:
            config_path: 配置文件路径（支持 .json 和 .yaml/.yml）
            validate: 是否验证配置（默认为 True）
            
        Returns:
            MonitorConfig 对象
            
        Raises:
            FileNotFoundError: 配置文件不存在
            ValueError: 配置文件格式错误或验证失败
        """
        path = Path(config_path)
        
        if not path.exists():
            logger.error(f"配置文件不存在: {config_path}")
            raise FileNotFoundError(f"配置文件不存在: {config_path}")
        
        # 根据文件扩展名选择加载方式
        suffix = path.suffix.lower()
        
        if suffix == '.json':
            config = ConfigLoader._load_json(path)
        elif suffix in ['.yaml', '.yml']:
            if not YAML_AVAILABLE:
                raise ValueError("YAML 支持需要安装 PyYAML: pip install pyyaml")
            config = ConfigLoader._load_yaml(path)
        else:
            raise ValueError(f"不支持的配置文件格式: {suffix}")
        
        # 验证配置
        if validate:
            is_valid, errors = ConfigValidator.validate_config(config)
            if not is_valid:
                error_msg = "配置验证失败:\n" + "\n".join(f"  - {err}" for err in errors)
                logger.error(error_msg)
                raise ValueError(error_msg)
        
        return config
    
    @staticmethod
    def _load_json(path: Path) -> MonitorConfig:
        """从 JSON 文件加载配置"""
        try:
            with open(path, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
            return ConfigLoader._parse_config(data)
        except json.JSONDecodeError as e:
            logger.error(f"JSON 解析错误: {e}")
            raise ValueError(f"JSON 格式错误: {e}")
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            raise
    
    @staticmethod
    def _load_yaml(path: Path) -> MonitorConfig:
        """从 YAML 文件加载配置"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            return ConfigLoader._parse_config(data)
        except yaml.YAMLError as e:
            logger.error(f"YAML 解析错误: {e}")
            raise ValueError(f"YAML 格式错误: {e}")
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            raise
    
    @staticmethod
    def _parse_config(data: dict) -> MonitorConfig:
        """解析配置字典为 MonitorConfig 对象"""
        try:
            # 解析 API 配置
            api_config = None
            if 'api_config' in data:
                api_data = data['api_config']
                api_config = APIConfig(**api_data)
            
            # 解析浏览器配置
            browser_config = None
            if 'browser_config' in data:
                browser_data = data['browser_config']
                browser_config = BrowserConfig(**browser_data)
            
            # 解析邮件配置
            email_config = None
            if 'email_config' in data:
                email_data = data['email_config']
                email_config = EmailConfig(**email_data)
            
            # 解析监控目标
            targets = []
            if 'targets' in data:
                for target_data in data['targets']:
                    target = TargetConfig(**target_data)
                    targets.append(target)
            
            # 创建主配置对象
            config = MonitorConfig(
                check_interval=data.get('check_interval', 30),
                max_pages=data.get('max_pages', 3),
                targets=targets,
                api_config=api_config,
                browser_config=browser_config,
                email_config=email_config,
                log_config=data.get('log_config', {})
            )
            
            return config
            
        except TypeError as e:
            logger.error(f"配置参数错误: {e}")
            raise ValueError(f"配置参数错误: {e}")
        except Exception as e:
            logger.error(f"解析配置失败: {e}")
            raise
    
    @staticmethod
    def load_or_create_default(config_path: str, 
                               create_if_missing: bool = True,
                               validate: bool = True) -> MonitorConfig:
        """加载配置文件，如果不存在则创建默认配置
        
        Args:
            config_path: 配置文件路径
            create_if_missing: 如果文件不存在是否创建示例配置
            validate: 是否验证配置（默认为 True）
            
        Returns:
            MonitorConfig 对象
        """
        path = Path(config_path)
        
        if not path.exists():
            if create_if_missing:
                logger.warning(f"配置文件不存在，创建示例配置: {config_path}")
                ConfigLoader.create_example_config(config_path)
            else:
                logger.info("使用默认配置")
                return MonitorConfig()
        
        return ConfigLoader.load_from_file(config_path, validate=validate)
    
    @staticmethod
    def create_example_config(output_path: str) -> None:
        """创建示例配置文件
        
        Args:
            output_path: 输出文件路径
        """
        example_config = {
            "check_interval": 30,
            "max_pages": 3,
            "targets": [
                {
                    "name": "RTX 5090",
                    "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5090",
                    "keywords": ["RTX 5090", "GeForce 5090"],
                    "max_price": 2650.0
                },
                {
                    "name": "RTX 5080",
                    "search_url": "https://www.bestbuy.com/site/searchpage.jsp?st=rtx+5080",
                    "keywords": ["RTX 5080", "GeForce 5080"],
                    "max_price": 1500.0
                }
            ],
            "api_config": {
                "api_key": "YOUR_DEEPSEEK_API_KEY_HERE",
                "base_url": "https://api.deepseek.com",
                "model_name": "deepseek-chat",
                "timeout": 30,
                "max_retries": 3,
                "temperature": 0.1
            },
            "browser_config": {
                "chrome_path": "",
                "debug_port": 9222,
                "page_load_timeout": 30,
                "implicit_wait": 10
            },
            "email_config": {
                "smtp_server": "smtp.qq.com",
                "smtp_port": 587,
                "sender_email": "your_email@qq.com",
                "sender_password": "your_authorization_code",
                "receiver_email": "receiver@example.com",
                "enabled": True
            },
            "log_config": {
                "level": "INFO",
                "file": "logs/monitor.log",
                "console": True
            }
        }
        
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        suffix = path.suffix.lower()
        
        if suffix == '.json':
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(example_config, f, indent=2, ensure_ascii=False)
        elif suffix in ['.yaml', '.yml']:
            if not YAML_AVAILABLE:
                logger.warning("YAML 不可用，创建 JSON 格式配置")
                json_path = path.with_suffix('.json')
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(example_config, f, indent=2, ensure_ascii=False)
            else:
                with open(path, 'w', encoding='utf-8') as f:
                    yaml.dump(example_config, f, default_flow_style=False, 
                            allow_unicode=True)
        else:
            # 默认创建 JSON 格式
            json_path = path.with_suffix('.json')
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(example_config, f, indent=2, ensure_ascii=False)
        
        logger.info(f"示例配置文件已创建: {path}")
