"""
配置数据模型

定义系统所需的所有配置数据类，包括 API、浏览器、邮件和监控配置。
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class APIConfig:
    """DeepSeek API 配置"""
    api_key: str                        # API 密钥
    base_url: str = "https://api.deepseek.com"  # API 基础 URL
    model_name: str = "deepseek-chat"   # 模型名称
    timeout: int = 30                   # 超时时间（秒）
    max_retries: int = 3                # 最大重试次数
    temperature: float = 0.1            # 温度参数（低温度提高准确性）


@dataclass
class BrowserConfig:
    """浏览器配置"""
    chrome_path: str = ""               # Chrome 路径（空则使用系统默认）
    debug_port: int = 9222              # 调试端口
    page_load_timeout: int = 30         # 页面加载超时（秒）
    implicit_wait: int = 10             # 隐式等待时间（秒）


@dataclass
class EmailConfig:
    """邮件配置"""
    smtp_server: str = "smtp.qq.com"    # SMTP 服务器
    smtp_port: int = 587                # SMTP 端口
    sender_email: str = ""              # 发件人邮箱
    sender_password: str = ""           # 发件人密码（授权码）
    receiver_email: str = ""            # 收件人邮箱（单个，向后兼容）
    receiver_emails: list = None        # 收件人邮箱列表（支持多个）
    enabled: bool = True                # 是否启用邮件通知
    
    def __post_init__(self):
        """初始化后处理"""
        # 如果没有设置 receiver_emails，使用 receiver_email
        if self.receiver_emails is None:
            if self.receiver_email:
                self.receiver_emails = [self.receiver_email]
            else:
                self.receiver_emails = []
        # 确保 receiver_emails 是列表
        elif isinstance(self.receiver_emails, str):
            self.receiver_emails = [self.receiver_emails]
    
    def get_receivers(self) -> list:
        """获取所有收件人列表"""
        return self.receiver_emails if self.receiver_emails else []


@dataclass
class TargetConfig:
    """监控目标配置"""
    name: str                           # 产品名称（如 "RTX 5090"）
    search_url: str                     # 搜索页面 URL
    keywords: List[str] = field(default_factory=list)  # 关键词列表
    max_price: float = 0.0              # 最高价格


@dataclass
class MonitorConfig:
    """监控配置"""
    check_interval: int = 30            # 检查间隔（秒）
    max_pages: int = 3                  # 最大检查页数
    targets: List[TargetConfig] = field(default_factory=list)  # 监控目标列表
    api_config: Optional[APIConfig] = None      # API 配置
    browser_config: Optional[BrowserConfig] = None  # 浏览器配置
    email_config: Optional[EmailConfig] = None  # 邮件配置
    log_config: Dict[str, Any] = field(default_factory=dict)  # 日志配置
    
    def __post_init__(self):
        """初始化后处理，设置默认配置"""
        if self.api_config is None:
            self.api_config = APIConfig(api_key="")
        if self.browser_config is None:
            self.browser_config = BrowserConfig()
        if self.email_config is None:
            self.email_config = EmailConfig()
        if not self.log_config:
            self.log_config = {
                "level": "INFO",
                "file": "logs/monitor.log",
                "console": True
            }
