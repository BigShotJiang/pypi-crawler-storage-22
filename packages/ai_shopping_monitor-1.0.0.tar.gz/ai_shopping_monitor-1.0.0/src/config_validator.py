"""
配置验证器

验证配置参数的有效性，确保系统使用正确的配置。
"""

import re
import logging
from typing import List, Tuple

from src.config_models import (
    MonitorConfig, APIConfig, BrowserConfig,
    EmailConfig, TargetConfig
)


logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """配置验证错误"""
    pass


class ConfigValidator:
    """配置验证器"""
    
    @staticmethod
    def validate_config(config: MonitorConfig) -> Tuple[bool, List[str]]:
        """验证完整配置
        
        Args:
            config: 监控配置对象
            
        Returns:
            (是否有效, 错误信息列表)
        """
        errors = []
        
        # 验证 API 配置
        if config.api_config:
            api_errors = ConfigValidator.validate_api_config(config.api_config)
            errors.extend(api_errors)
        
        # 验证浏览器配置
        if config.browser_config:
            browser_errors = ConfigValidator.validate_browser_config(config.browser_config)
            errors.extend(browser_errors)
        
        # 验证邮件配置
        if config.email_config:
            email_errors = ConfigValidator.validate_email_config(config.email_config)
            errors.extend(email_errors)
        
        # 验证监控配置
        monitor_errors = ConfigValidator.validate_monitor_config(config)
        errors.extend(monitor_errors)
        
        # 验证目标配置
        for i, target in enumerate(config.targets):
            target_errors = ConfigValidator.validate_target_config(target)
            errors.extend([f"Target {i} ({target.name}): {err}" for err in target_errors])
        
        is_valid = len(errors) == 0
        
        if not is_valid:
            logger.warning(f"配置验证失败，发现 {len(errors)} 个错误")
            for error in errors:
                logger.warning(f"  - {error}")
        else:
            logger.info("配置验证通过")
        
        return is_valid, errors
    
    @staticmethod
    def validate_api_config(config: APIConfig) -> List[str]:
        """验证 API 配置
        
        Args:
            config: API 配置对象
            
        Returns:
            错误信息列表
        """
        errors = []
        
        # 验证 API 密钥格式
        if not config.api_key:
            errors.append("API 密钥不能为空")
        elif config.api_key == "YOUR_DEEPSEEK_API_KEY_HERE":
            errors.append("请设置有效的 API 密钥（当前为示例值）")
        elif len(config.api_key) < 10:
            errors.append("API 密钥长度过短（至少 10 个字符）")
        
        # 验证 base_url
        if not config.base_url:
            errors.append("API base_url 不能为空")
        elif not config.base_url.startswith(("http://", "https://")):
            errors.append("API base_url 必须以 http:// 或 https:// 开头")
        
        # 验证 timeout
        if config.timeout <= 0:
            errors.append("API timeout 必须大于 0")
        elif config.timeout > 300:
            errors.append("API timeout 不应超过 300 秒")
        
        # 验证 max_retries
        if config.max_retries < 0:
            errors.append("API max_retries 不能为负数")
        elif config.max_retries > 10:
            errors.append("API max_retries 不应超过 10")
        
        # 验证 temperature
        if config.temperature < 0 or config.temperature > 2:
            errors.append("API temperature 必须在 0 到 2 之间")
        
        return errors
    
    @staticmethod
    def validate_browser_config(config: BrowserConfig) -> List[str]:
        """验证浏览器配置
        
        Args:
            config: 浏览器配置对象
            
        Returns:
            错误信息列表
        """
        errors = []
        
        # 验证 debug_port
        if config.debug_port < 1024 or config.debug_port > 65535:
            errors.append("Browser debug_port 必须在 1024 到 65535 之间")
        
        # 验证 page_load_timeout
        if config.page_load_timeout <= 0:
            errors.append("Browser page_load_timeout 必须大于 0")
        elif config.page_load_timeout > 300:
            errors.append("Browser page_load_timeout 不应超过 300 秒")
        
        # 验证 implicit_wait
        if config.implicit_wait < 0:
            errors.append("Browser implicit_wait 不能为负数")
        elif config.implicit_wait > 60:
            errors.append("Browser implicit_wait 不应超过 60 秒")
        
        return errors
    
    @staticmethod
    def validate_email_config(config: EmailConfig) -> List[str]:
        """验证邮件配置
        
        Args:
            config: 邮件配置对象
            
        Returns:
            错误信息列表
        """
        errors = []
        
        # 如果邮件功能未启用，跳过验证
        if not config.enabled:
            return errors
        
        # 验证 SMTP 服务器
        if not config.smtp_server:
            errors.append("Email smtp_server 不能为空")
        
        # 验证 SMTP 端口
        if config.smtp_port < 1 or config.smtp_port > 65535:
            errors.append("Email smtp_port 必须在 1 到 65535 之间")
        
        # 验证发件人邮箱
        if not config.sender_email:
            errors.append("Email sender_email 不能为空")
        elif config.sender_email == "your_email@qq.com":
            errors.append("请设置有效的发件人邮箱（当前为示例值）")
        elif not ConfigValidator._is_valid_email(config.sender_email):
            errors.append(f"Email sender_email 格式无效: {config.sender_email}")
        
        # 验证发件人密码
        if not config.sender_password:
            errors.append("Email sender_password 不能为空")
        elif config.sender_password == "your_authorization_code":
            errors.append("请设置有效的发件人密码/授权码（当前为示例值）")
        
        # 验证收件人邮箱
        if not config.receiver_email:
            errors.append("Email receiver_email 不能为空")
        elif config.receiver_email == "receiver@example.com":
            errors.append("请设置有效的收件人邮箱（当前为示例值）")
        elif not ConfigValidator._is_valid_email(config.receiver_email):
            errors.append(f"Email receiver_email 格式无效: {config.receiver_email}")
        
        return errors
    
    @staticmethod
    def validate_monitor_config(config: MonitorConfig) -> List[str]:
        """验证监控配置
        
        Args:
            config: 监控配置对象
            
        Returns:
            错误信息列表
        """
        errors = []
        
        # 验证检查间隔
        if config.check_interval < 5:
            errors.append("Monitor check_interval 不应小于 5 秒（避免过于频繁）")
        elif config.check_interval > 3600:
            errors.append("Monitor check_interval 不应超过 3600 秒（1 小时）")
        
        # 验证最大页数
        if config.max_pages < 1:
            errors.append("Monitor max_pages 必须至少为 1")
        elif config.max_pages > 10:
            errors.append("Monitor max_pages 不应超过 10")
        
        # 验证是否有监控目标
        if not config.targets:
            errors.append("Monitor targets 不能为空（至少需要一个监控目标）")
        
        return errors
    
    @staticmethod
    def validate_target_config(config: TargetConfig) -> List[str]:
        """验证监控目标配置
        
        Args:
            config: 目标配置对象
            
        Returns:
            错误信息列表
        """
        errors = []
        
        # 验证产品名称
        if not config.name:
            errors.append("Target name 不能为空")
        
        # 验证搜索 URL
        if not config.search_url:
            errors.append("Target search_url 不能为空")
        elif not config.search_url.startswith(("http://", "https://")):
            errors.append("Target search_url 必须以 http:// 或 https:// 开头")
        
        # 验证价格阈值
        if config.max_price <= 0:
            errors.append("Target max_price 必须大于 0")
        elif config.max_price < 100:
            errors.append("Target max_price 过低（建议至少 100）")
        elif config.max_price > 50000:
            errors.append("Target max_price 过高（建议不超过 50000）")
        
        # 验证关键词
        if not config.keywords:
            errors.append("Target keywords 不能为空（至少需要一个关键词）")
        
        return errors
    
    @staticmethod
    def _is_valid_email(email: str) -> bool:
        """验证邮箱格式
        
        Args:
            email: 邮箱地址
            
        Returns:
            是否有效
        """
        # 简单的邮箱格式验证
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def validate_and_raise(config: MonitorConfig) -> None:
        """验证配置，如果无效则抛出异常
        
        Args:
            config: 监控配置对象
            
        Raises:
            ValidationError: 配置验证失败
        """
        is_valid, errors = ConfigValidator.validate_config(config)
        
        if not is_valid:
            error_msg = "配置验证失败:\n" + "\n".join(f"  - {err}" for err in errors)
            raise ValidationError(error_msg)
