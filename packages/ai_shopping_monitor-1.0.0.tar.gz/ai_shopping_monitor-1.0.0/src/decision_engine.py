"""
决策引擎

基于产品信息、价格和库存状态做出购买决策。
"""

from typing import Optional, Dict, Any
from src.ai_agent_engine import ProductInfo
from src.logger import get_logger


class DecisionEngine:
    """决策引擎
    
    基于产品信息、价格阈值和库存状态做出购买决策。
    """
    
    # 价格阈值配置
    PRICE_THRESHOLDS = {
        "5090": 2650.0,
        "5080": 1500.0
    }
    
    # 排除的产品类型关键词
    EXCLUDED_KEYWORDS = [
        # 整机关键词
        "gaming pc", "desktop", "laptop", "computer system", "pc system",
        "gaming system", "prebuilt", "pre-built", "complete system",
        # 配件关键词
        "bracket", "cable", "adapter", "mount", "stand", "holder",
        "support", "riser", "extension", "converter", "cooler",
        "cooling", "fan", "thermal", "heatsink", "backplate",
        # 服务关键词
        "warranty", "protection", "insurance", "gift card", "card"
    ]
    
    def __init__(self):
        """初始化决策引擎"""
        self.logger = get_logger()
    
    def should_purchase(self, product: ProductInfo, 
                       max_price: Optional[float] = None) -> bool:
        """判断是否应该购买产品
        
        综合考虑产品类型、价格、库存状态等因素做出购买决策。
        
        Args:
            product: 产品信息
            max_price: 自定义最高价格（可选，如果不提供则使用默认阈值）
            
        Returns:
            是否应该购买
        """
        self.logger.info(f"开始购买决策分析: {product.name}")
        
        # 1. 验证产品类型（排除整机和配件）
        if not self._is_valid_product_type(product):
            reason = "产品类型不符合条件（可能是整机或配件）"
            self.logger.info(f"拒绝购买: {reason}")
            self._log_decision(product, False, reason)
            return False
        
        # 2. 验证型号
        if not self._is_valid_model(product):
            reason = f"型号不符合条件: {product.model}"
            self.logger.info(f"拒绝购买: {reason}")
            self._log_decision(product, False, reason)
            return False
        
        # 3. 检查库存状态
        if not product.is_available:
            reason = "商品当前不可购买（无库存或未上架）"
            self.logger.info(f"拒绝购买: {reason}")
            self._log_decision(product, False, reason)
            return False
        
        # 4. 验证价格阈值
        threshold = max_price if max_price is not None else self._get_price_threshold(product.model)
        
        if not self._is_price_acceptable(product, threshold):
            reason = f"价格超出阈值: ${product.price:.2f} > ${threshold:.2f}"
            self.logger.info(f"拒绝购买: {reason}")
            self._log_decision(product, False, reason)
            return False
        
        # 5. 检查置信度
        if product.confidence < 0.5:
            reason = f"AI 识别置信度过低: {product.confidence:.2f}"
            self.logger.warning(f"拒绝购买: {reason}")
            self._log_decision(product, False, reason)
            return False
        
        # 所有条件都满足，批准购买
        reason = (
            f"产品符合所有条件 - "
            f"型号: {product.model}, "
            f"价格: ${product.price:.2f} (阈值: ${threshold:.2f}), "
            f"库存: 可购买, "
            f"置信度: {product.confidence:.2f}"
        )
        self.logger.info(f"批准购买: {reason}")
        self._log_decision(product, True, reason)
        
        return True
    
    def _is_valid_product_type(self, product: ProductInfo) -> bool:
        """验证产品类型是否有效（不是整机或配件）
        
        Args:
            product: 产品信息
            
        Returns:
            是否是有效的显卡产品
        """
        product_name_lower = product.name.lower()
        
        # 检查是否包含排除关键词
        for keyword in self.EXCLUDED_KEYWORDS:
            if keyword in product_name_lower:
                self.logger.debug(
                    f"产品名称包含排除关键词 '{keyword}': {product.name}"
                )
                return False
        
        # 检查 AI 推理结果
        if product.reasoning:
            reasoning_lower = product.reasoning.lower()
            
            # 如果 AI 明确指出是整机或配件
            if any(word in reasoning_lower for word in ["整机", "配件", "accessory", "complete system"]):
                self.logger.debug(
                    f"AI 推理指出产品不符合条件: {product.reasoning}"
                )
                return False
        
        # 如果型号为空，说明 AI 认为这不是有效的显卡
        if not product.model or product.model == "":
            self.logger.debug(
                f"产品型号为空，可能不是有效的显卡: {product.name}"
            )
            return False
        
        return True
    
    def _is_valid_model(self, product: ProductInfo) -> bool:
        """验证产品型号是否有效
        
        Args:
            product: 产品信息
            
        Returns:
            是否是有效的型号
        """
        valid_models = ["5090", "5080"]
        
        if product.model not in valid_models:
            self.logger.debug(
                f"无效的产品型号: {product.model} (有效型号: {valid_models})"
            )
            return False
        
        return True
    
    def _is_price_acceptable(self, product: ProductInfo, threshold: float) -> bool:
        """检查价格是否可接受
        
        Args:
            product: 产品信息
            threshold: 价格阈值
            
        Returns:
            价格是否在阈值内
        """
        if product.price <= 0:
            self.logger.warning(f"无效的价格: ${product.price:.2f}")
            return False
        
        if product.price > threshold:
            self.logger.debug(
                f"价格超出阈值: ${product.price:.2f} > ${threshold:.2f}"
            )
            return False
        
        return True
    
    def _get_price_threshold(self, model: str) -> float:
        """获取指定型号的价格阈值
        
        Args:
            model: 产品型号
            
        Returns:
            价格阈值
        """
        threshold = self.PRICE_THRESHOLDS.get(model, 0.0)
        
        if threshold == 0.0:
            self.logger.warning(
                f"未找到型号 {model} 的价格阈值，使用默认值 0"
            )
        
        return threshold
    
    def _log_decision(self, product: ProductInfo, decision: bool, reason: str) -> None:
        """记录购买决策日志
        
        Args:
            product: 产品信息
            decision: 决策结果
            reason: 决策原因
        """
        action = "批准购买" if decision else "拒绝购买"
        
        self.logger.info(f"=" * 60)
        self.logger.info(f"购买决策: {action}")
        self.logger.info(f"产品名称: {product.name}")
        self.logger.info(f"产品型号: {product.model}")
        self.logger.info(f"产品品牌: {product.brand}")
        self.logger.info(f"产品价格: ${product.price:.2f}")
        self.logger.info(f"库存状态: {'可购买' if product.is_available else '不可购买'}")
        self.logger.info(f"置信度: {product.confidence:.2f}")
        self.logger.info(f"决策原因: {reason}")
        self.logger.info(f"=" * 60)
    
    def get_decision_summary(self, product: ProductInfo, 
                            max_price: Optional[float] = None) -> Dict[str, Any]:
        """获取决策摘要信息
        
        返回详细的决策分析结果，包括各项检查的通过情况。
        
        Args:
            product: 产品信息
            max_price: 自定义最高价格
            
        Returns:
            决策摘要字典
        """
        threshold = max_price if max_price is not None else self._get_price_threshold(product.model)
        
        summary = {
            "product_name": product.name,
            "model": product.model,
            "price": product.price,
            "price_threshold": threshold,
            "is_available": product.is_available,
            "confidence": product.confidence,
            "checks": {
                "valid_product_type": self._is_valid_product_type(product),
                "valid_model": self._is_valid_model(product),
                "stock_available": product.is_available,
                "price_acceptable": self._is_price_acceptable(product, threshold),
                "confidence_sufficient": product.confidence >= 0.5
            },
            "decision": self.should_purchase(product, max_price),
            "reasoning": product.reasoning
        }
        
        return summary
