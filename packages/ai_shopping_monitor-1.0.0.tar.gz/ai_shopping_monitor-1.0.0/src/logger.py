"""
日志系统

提供统一的日志记录功能，支持文件和控制台输出。
"""

import logging
import os
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime


class Logger:
    """日志管理器"""
    
    _instance: Optional['Logger'] = None
    _initialized: bool = False
    
    def __new__(cls):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        """初始化日志系统（仅执行一次）"""
        if not Logger._initialized:
            self.logger = logging.getLogger('ai_agent_monitor')
            Logger._initialized = True
    
    def setup(self, log_config: Dict[str, Any]) -> None:
        """设置日志系统
        
        Args:
            log_config: 日志配置字典
                - level: 日志级别（DEBUG, INFO, WARNING, ERROR, CRITICAL）
                - file: 日志文件路径
                - console: 是否输出到控制台
        """
        # 清除现有的处理器
        self.logger.handlers.clear()
        
        # 设置日志级别
        level_str = log_config.get('level', 'INFO').upper()
        level = getattr(logging, level_str, logging.INFO)
        self.logger.setLevel(level)
        
        # 创建格式化器
        formatter = logging.Formatter(
            fmt='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # 添加文件处理器
        log_file = log_config.get('file', 'logs/monitor.log')
        if log_file:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            file_handler = logging.FileHandler(
                log_file, 
                encoding='utf-8',
                mode='a'
            )
            file_handler.setLevel(level)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
        
        # 添加控制台处理器
        if log_config.get('console', True):
            console_handler = logging.StreamHandler()
            console_handler.setLevel(level)
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)
        
        # 防止日志传播到根日志记录器
        self.logger.propagate = False
        
        self.logger.info("=" * 60)
        self.logger.info("日志系统初始化完成")
        self.logger.info(f"日志级别: {level_str}")
        self.logger.info(f"日志文件: {log_file}")
        self.logger.info(f"控制台输出: {log_config.get('console', True)}")
        self.logger.info("=" * 60)
    
    def get_logger(self) -> logging.Logger:
        """获取日志记录器
        
        Returns:
            logging.Logger 对象
        """
        return self.logger
    
    def log_operation(self, operation: str, details: Dict[str, Any]) -> None:
        """记录操作日志
        
        Args:
            operation: 操作类型
            details: 操作详情
        """
        timestamp = datetime.now().isoformat()
        log_entry = {
            'timestamp': timestamp,
            'operation': operation,
            **details
        }
        self.logger.info(f"[{operation}] {details}")
    
    def log_api_call(self, request: str, response: str, 
                     duration: float, success: bool) -> None:
        """记录 API 调用日志
        
        Args:
            request: 请求内容（可截断）
            response: 响应内容（可截断）
            duration: 调用耗时（秒）
            success: 是否成功
        """
        status = "成功" if success else "失败"
        self.logger.info(f"API 调用 {status} - 耗时: {duration:.2f}s")
        self.logger.debug(f"请求: {request[:200]}...")
        if success:
            self.logger.debug(f"响应: {response[:200]}...")
        else:
            self.logger.error(f"错误: {response}")
    
    def log_product_detection(self, product_name: str, model: str, 
                             price: float, available: bool, 
                             reasoning: str) -> None:
        """记录产品检测日志
        
        Args:
            product_name: 产品名称
            model: 型号
            price: 价格
            available: 是否可购买
            reasoning: 检测依据
        """
        status = "可购买" if available else "不可购买"
        self.logger.info(f"检测到产品: {product_name} ({model}) - ${price:.2f} - {status}")
        self.logger.debug(f"检测依据: {reasoning}")
    
    def log_purchase_decision(self, product_name: str, decision: bool, 
                             reason: str) -> None:
        """记录购买决策日志
        
        Args:
            product_name: 产品名称
            decision: 是否购买
            reason: 决策原因
        """
        action = "批准购买" if decision else "拒绝购买"
        self.logger.info(f"购买决策: {action} - {product_name}")
        self.logger.info(f"原因: {reason}")
    
    def log_error(self, error_type: str, error_msg: str, 
                  context: Optional[Dict[str, Any]] = None) -> None:
        """记录错误日志
        
        Args:
            error_type: 错误类型
            error_msg: 错误信息
            context: 错误上下文
        """
        self.logger.error(f"[{error_type}] {error_msg}")
        if context:
            self.logger.error(f"上下文: {context}")


# 全局日志实例
_global_logger = Logger()


def get_logger() -> logging.Logger:
    """获取全局日志记录器
    
    Returns:
        logging.Logger 对象
    """
    return _global_logger.get_logger()


def setup_logger(log_config: Dict[str, Any]) -> None:
    """设置全局日志系统
    
    Args:
        log_config: 日志配置字典
    """
    _global_logger.setup(log_config)
