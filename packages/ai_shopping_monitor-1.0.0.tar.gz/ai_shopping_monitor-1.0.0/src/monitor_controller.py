"""
监控控制器

主控制器，负责监控循环、任务调度和组件协调。
"""

import time
import signal
from typing import Optional, List
from datetime import datetime

from src.config_models import MonitorConfig, TargetConfig
from src.browser_driver import BrowserDriver
from src.ai_agent_engine import AIAgentEngine, ProductInfo, AnalysisResult
from src.notification_service import NotificationService
from src.decision_engine import DecisionEngine
from src.logger import get_logger, setup_logger


class MonitorController:
    """监控控制器
    
    负责整个监控流程的编排，包括：
    - 初始化所有组件
    - 执行监控循环
    - 处理购买机会
    - 错误处理和恢复
    """
    
    def __init__(self, config: MonitorConfig):
        """初始化监控控制器
        
        Args:
            config: 监控配置对象
        """
        self.config = config
        
        # 设置日志系统
        setup_logger(config.log_config)
        self.logger = get_logger()
        
        self.logger.info("=" * 80)
        self.logger.info("AI Agent 显卡监控系统")
        self.logger.info("=" * 80)
        
        # 初始化组件
        self.browser: Optional[BrowserDriver] = None
        self.agent: Optional[AIAgentEngine] = None
        self.notifier: Optional[NotificationService] = None
        self.decision_engine: Optional[DecisionEngine] = None
        
        # 监控状态
        self.is_running = False
        self.consecutive_failures = 0
        self.total_checks = 0
        self.products_found = 0
        self.purchase_attempts = 0
        
        # 初始化组件
        self._initialize_components()
        
        # 注册信号处理器（用于优雅关闭）
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _initialize_components(self) -> None:
        """初始化所有组件"""
        self.logger.info("初始化系统组件...")
        
        try:
            # 初始化浏览器驱动
            self.logger.info("初始化浏览器驱动...")
            self.browser = BrowserDriver(self.config.browser_config)
            
            # 初始化 AI Agent 引擎
            self.logger.info("初始化 AI Agent 引擎...")
            self.agent = AIAgentEngine(self.config.api_config)
            
            # 初始化通知服务
            self.logger.info("初始化通知服务...")
            self.notifier = NotificationService(self.config.email_config)
            
            # 初始化决策引擎
            self.logger.info("初始化决策引擎...")
            self.decision_engine = DecisionEngine()
            
            self.logger.info("所有组件初始化完成")
            
        except Exception as e:
            self.logger.error(f"组件初始化失败: {e}", exc_info=True)
            raise
    
    def start_monitoring(self) -> None:
        """启动监控循环
        
        主监控循环，持续检查目标页面并处理购买机会。
        """
        self.logger.info("=" * 80)
        self.logger.info("启动监控循环")
        self.logger.info(f"检查间隔: {self.config.check_interval} 秒")
        self.logger.info(f"监控目标数量: {len(self.config.targets)}")
        
        for i, target in enumerate(self.config.targets, 1):
            self.logger.info(f"  目标 {i}: {target.name} - 最高价格: ${target.max_price:.2f}")
        
        self.logger.info("=" * 80)
        
        # 连接到浏览器（重试直到成功）
        max_connect_retries = 5
        for retry in range(max_connect_retries):
            if self._connect_browser():
                break
            else:
                if retry < max_connect_retries - 1:
                    self.logger.warning(f"浏览器连接失败，{10}秒后重试 ({retry + 1}/{max_connect_retries})...")
                    time.sleep(10)
                else:
                    self.logger.error(f"浏览器连接失败 {max_connect_retries} 次，监控终止")
                    return
        
        self.is_running = True
        
        try:
            while self.is_running:
                self.logger.info(f"\n{'=' * 80}")
                self.logger.info(f"开始第 {self.total_checks + 1} 次检查")
                self.logger.info(f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                self.logger.info(f"{'=' * 80}")
                
                # 检查所有目标
                for target in self.config.targets:
                    if not self.is_running:
                        break
                    
                    self._check_target(target)
                
                self.total_checks += 1
                
                # 检查连续失败次数
                if self.consecutive_failures >= 5:
                    self.logger.warning(
                        f"连续失败 {self.consecutive_failures} 次，尝试重启浏览器连接..."
                    )
                    self._restart_browser()
                    self.consecutive_failures = 0
                
                # 等待下一次检查
                if self.is_running:
                    self.logger.info(f"\n等待 {self.config.check_interval} 秒后进行下一次检查...")
                    time.sleep(self.config.check_interval)
        
        except KeyboardInterrupt:
            self.logger.info("\n收到中断信号，正在停止监控...")
        
        except Exception as e:
            self.logger.error(f"监控循环发生未预期错误: {e}", exc_info=True)
            if self.notifier:
                self.notifier.send_error_alert(
                    error_msg=str(e),
                    error_type="监控循环错误",
                    context={"total_checks": self.total_checks}
                )
        
        finally:
            self.stop_monitoring()
    
    def _check_target(self, target: TargetConfig) -> None:
        """检查单个监控目标
        
        Args:
            target: 监控目标配置
        """
        self.logger.info(f"\n检查目标: {target.name}")
        self.logger.info(f"搜索 URL: {target.search_url}")
        self.logger.info(f"最大检查页数: {self.config.max_pages}")
        
        try:
            # 检查 Chrome 是否存活
            if not self.browser.is_alive():
                self.logger.warning("检测到 Chrome 崩溃或连接断开")
                
                # 尝试重新连接
                if not self.browser.reconnect():
                    self.logger.error("无法重新连接到 Chrome，跳过本次检查")
                    self.consecutive_failures += 1
                    
                    # 发送错误通知
                    if self.notifier:
                        self.notifier.send_error_alert(
                            error_msg="Chrome 崩溃且无法重新连接",
                            error_type="Chrome 连接失败",
                            context={"target": target.name}
                        )
                    
                    return
                
                self.logger.info("成功重新连接到 Chrome")
            
            # 检查多页
            total_products_found = 0
            for page_num in range(1, self.config.max_pages + 1):
                if not self.is_running:
                    break
                
                self.logger.info(f"\n检查第 {page_num} 页...")
                
                # 构建带页码的 URL
                if page_num == 1:
                    page_url = target.search_url
                else:
                    # Best Buy 的分页参数是 cp=页码
                    separator = '&' if '?' in target.search_url else '?'
                    page_url = f"{target.search_url}{separator}cp={page_num}"
                
                # 导航到搜索页面
                if not self.browser.navigate_to(page_url):
                    self.logger.error(f"无法导航到搜索页面: {page_url}")
                    self.consecutive_failures += 1
                    break
                
                # 提取页面上下文
                context = self.browser.extract_page_context()
                if not context:
                    self.logger.error("无法提取页面上下文")
                    self.consecutive_failures += 1
                    break
                
                # 使用 AI 分析页面
                result = self.agent.analyze_search_page(
                    context=context,
                    target_model=self._extract_model_from_name(target.name),
                    max_price=target.max_price
                )
                
                # 处理分析结果
                if result.products_found:
                    self.logger.info(f"第 {page_num} 页找到 {len(result.products_found)} 个符合条件的产品")
                    total_products_found += len(result.products_found)
                    self.products_found += len(result.products_found)
                    
                    # 处理每个产品
                    for product in result.products_found:
                        if not self.is_running:
                            break
                        
                        self._handle_product(product, target)
                else:
                    self.logger.info(f"第 {page_num} 页未找到符合条件的产品")
                
                # 如果这一页没有产品，可能已经到最后一页了
                if not result.products_found and page_num > 1:
                    self.logger.info("已到达最后一页，停止翻页")
                    break
                
                # 等待一下再翻页，避免请求过快
                if page_num < self.config.max_pages:
                    time.sleep(2)
            
            if total_products_found == 0:
                self.logger.info(f"所有 {page_num} 页均未找到符合条件的产品")
            else:
                self.logger.info(f"总共找到 {total_products_found} 个符合条件的产品")
            
            # 重置连续失败计数
            self.consecutive_failures = 0
            
        except Exception as e:
            self.logger.error(f"检查目标失败: {e}", exc_info=True)
            self.consecutive_failures += 1
    
    def _handle_product(self, product: ProductInfo, target: TargetConfig) -> None:
        """处理找到的产品
        
        Args:
            product: 产品信息
            target: 监控目标配置
        """
        self.logger.info(f"\n处理产品: {product.name}")
        
        # 使用决策引擎判断是否购买
        should_buy = self.decision_engine.should_purchase(
            product=product,
            max_price=target.max_price
        )
        
        if should_buy:
            self.logger.info("决策引擎批准购买，发送通知...")
            
            # 发送产品发现通知
            if self.notifier:
                self.notifier.send_product_found(product)
            
            # 尝试购买
            self.handle_purchase_opportunity(product)
        else:
            self.logger.info("决策引擎拒绝购买")
    
    def handle_purchase_opportunity(self, product: ProductInfo) -> bool:
        """处理购买机会
        
        执行购买流程：
        1. 导航到产品页面（如果需要）
        2. 点击加入购物车
        3. 导航到结账页面
        4. 发送成功通知
        
        Args:
            product: 产品信息
            
        Returns:
            是否成功购买
        """
        self.logger.info("=" * 80)
        self.logger.info("开始执行购买流程")
        self.logger.info(f"产品: {product.name}")
        self.logger.info(f"价格: ${product.price:.2f}")
        self.logger.info("=" * 80)
        
        self.purchase_attempts += 1
        
        try:
            # 步骤 1: 如果有产品 URL，先导航到产品页面
            if product.product_url and product.product_url != "":
                self.logger.info(f"导航到产品页面: {product.product_url}")
                
                if not self.browser.navigate_to(product.product_url):
                    self.logger.error("无法导航到产品页面")
                    return False
                
                time.sleep(2)  # 等待页面加载
            
            # 步骤 2: 点击加入购物车
            self.logger.info("尝试点击 Add to Cart 按钮...")
            
            if not self.browser.click_add_to_cart(product.selector_hint):
                self.logger.error("无法点击 Add to Cart 按钮")
                
                if self.notifier:
                    self.notifier.send_error_alert(
                        error_msg=f"无法点击 Add to Cart 按钮: {product.name}",
                        error_type="购买失败",
                        context={
                            "product": product.name,
                            "price": product.price,
                            "url": product.product_url
                        }
                    )
                
                return False
            
            self.logger.info("成功加入购物车")
            
            # 步骤 3: 导航到结账页面
            self.logger.info("导航到结账页面...")
            
            success, checkout_url = self.browser.navigate_to_checkout()
            
            if success:
                self.logger.info(f"成功到达结账页面: {checkout_url}")
                
                # 发送购买成功通知
                if self.notifier:
                    self.notifier.send_purchase_success(product, checkout_url)
                
                self.logger.info("=" * 80)
                self.logger.info("购买流程完成！")
                self.logger.info("请在浏览器中完成支付流程")
                self.logger.info("=" * 80)
                
                return True
            else:
                self.logger.error("无法到达结账页面")
                
                if self.notifier:
                    self.notifier.send_error_alert(
                        error_msg=f"无法到达结账页面: {product.name}",
                        error_type="购买失败",
                        context={
                            "product": product.name,
                            "price": product.price,
                            "current_url": checkout_url
                        }
                    )
                
                return False
        
        except Exception as e:
            self.logger.error(f"购买流程失败: {e}", exc_info=True)
            
            if self.notifier:
                self.notifier.send_error_alert(
                    error_msg=str(e),
                    error_type="购买流程异常",
                    context={
                        "product": product.name,
                        "price": product.price
                    }
                )
            
            return False
    
    def stop_monitoring(self) -> None:
        """停止监控并优雅关闭
        
        清理资源，关闭浏览器连接，记录统计信息。
        """
        self.logger.info("\n" + "=" * 80)
        self.logger.info("停止监控系统")
        self.logger.info("=" * 80)
        
        self.is_running = False
        
        # 记录统计信息
        self.logger.info(f"总检查次数: {self.total_checks}")
        self.logger.info(f"找到产品数: {self.products_found}")
        self.logger.info(f"购买尝试次数: {self.purchase_attempts}")
        
        # 关闭浏览器连接
        if self.browser:
            self.logger.info("关闭浏览器连接...")
            self.browser.close()
        
        self.logger.info("=" * 80)
        self.logger.info("监控系统已停止")
        self.logger.info("=" * 80)
    
    def _connect_browser(self) -> bool:
        """连接到浏览器
        
        Returns:
            是否连接成功
        """
        self.logger.info("连接到 Chrome 浏览器...")
        
        try:
            if self.browser.connect():
                self.logger.info("浏览器连接成功")
                return True
            else:
                self.logger.error("浏览器连接失败")
                
                if self.notifier:
                    self.notifier.send_error_alert(
                        error_msg="无法连接到 Chrome 浏览器",
                        error_type="浏览器连接失败",
                        context={
                            "debug_port": self.config.browser_config.debug_port
                        }
                    )
                
                return False
        
        except Exception as e:
            self.logger.error(f"连接浏览器时发生错误: {e}", exc_info=True)
            return False
    
    def _restart_browser(self) -> bool:
        """重启浏览器连接
        
        Returns:
            是否重启成功
        """
        self.logger.info("重启浏览器连接...")
        
        try:
            # 使用 BrowserDriver 的 reconnect 方法
            if self.browser.reconnect(max_retries=3):
                self.logger.info("浏览器连接重启成功")
                return True
            else:
                self.logger.error("浏览器连接重启失败")
                
                # 发送错误通知
                if self.notifier:
                    self.notifier.send_error_alert(
                        error_msg="浏览器连接重启失败",
                        error_type="Chrome 重启失败",
                        context={"consecutive_failures": self.consecutive_failures}
                    )
                
                return False
        
        except Exception as e:
            self.logger.error(f"重启浏览器失败: {e}", exc_info=True)
            return False
    
    def _extract_model_from_name(self, name: str) -> str:
        """从产品名称中提取型号
        
        Args:
            name: 产品名称（如 "RTX 5090"）
            
        Returns:
            型号（如 "5090"）
        """
        if "5090" in name:
            return "5090"
        elif "5080" in name:
            return "5080"
        else:
            return ""
    
    def _signal_handler(self, signum, frame):
        """信号处理器（用于优雅关闭）
        
        Args:
            signum: 信号编号
            frame: 当前栈帧
        """
        self.logger.info(f"\n收到信号 {signum}，正在停止监控...")
        self.is_running = False
