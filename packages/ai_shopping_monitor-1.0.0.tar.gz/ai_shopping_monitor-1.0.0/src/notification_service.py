"""
通知服务

提供邮件通知功能，支持异步发送和错误处理。
"""

import smtplib
import threading
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from typing import Optional

from src.config_models import EmailConfig
from src.logger import get_logger

# 导入 ProductInfo 以避免循环导入
# 如果需要在没有 ai_agent_engine 的情况下使用，可以使用 TYPE_CHECKING
try:
    from src.ai_agent_engine import ProductInfo
except ImportError:
    # 如果无法导入，定义一个简单的版本
    from dataclasses import dataclass
    
    @dataclass
    class ProductInfo:
        """产品信息数据类（备用定义）"""
        name: str
        model: str
        brand: str
        price: float
        price_text: str
        is_available: bool
        product_url: str = ""
        selector_hint: str = ""
        confidence: float = 0.0
        reasoning: str = ""


class NotificationService:
    """通知服务"""
    
    def __init__(self, config: EmailConfig):
        """初始化通知服务
        
        Args:
            config: 邮件配置
        """
        self.config = config
        self.logger = get_logger()
        self._validate_config()
    
    def _validate_config(self) -> None:
        """验证邮件配置"""
        if not self.config.enabled:
            self.logger.info("邮件通知已禁用")
            return
        
        if not self.config.sender_email:
            self.logger.warning("发件人邮箱未配置，邮件通知将不可用")
        
        if not self.config.sender_password:
            self.logger.warning("发件人密码未配置，邮件通知将不可用")
        
        receivers = self.config.get_receivers()
        if not receivers:
            self.logger.warning("收件人邮箱未配置，邮件通知将不可用")
    
    def _send_email_sync(self, subject: str, body: str) -> bool:
        """同步发送邮件（内部方法）
        
        Args:
            subject: 邮件主题
            body: 邮件正文
            
        Returns:
            是否发送成功
        """
        if not self.config.enabled:
            self.logger.debug("邮件通知已禁用，跳过发送")
            return False
        
        try:
            # 获取所有收件人
            receivers = self.config.get_receivers()
            if not receivers:
                self.logger.error("没有配置收件人邮箱")
                return False
            
            receiver_str = ', '.join(receivers)
            
            # 创建邮件消息
            msg = MIMEMultipart()
            msg['From'] = self.config.sender_email
            msg['To'] = receiver_str
            msg['Subject'] = subject
            
            # 添加邮件正文
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            # 连接到 SMTP 服务器
            self.logger.debug(f"连接到 SMTP 服务器: {self.config.smtp_server}:{self.config.smtp_port}")
            
            smtp_port = self.config.smtp_port
            
            # 根据端口选择连接方式
            if smtp_port == 587:
                # TLS
                server = smtplib.SMTP(self.config.smtp_server, smtp_port, timeout=30)
                server.starttls()
            elif smtp_port == 465:
                # SSL
                server = smtplib.SMTP_SSL(self.config.smtp_server, smtp_port, timeout=30)
            else:
                # 默认使用 TLS
                server = smtplib.SMTP(self.config.smtp_server, smtp_port, timeout=30)
                try:
                    server.starttls()
                except Exception:
                    pass
            
            # 登录
            self.logger.debug("登录 SMTP 服务器...")
            server.login(self.config.sender_email, self.config.sender_password)
            
            # 发送邮件
            self.logger.debug("发送邮件...")
            text = msg.as_string()
            server.sendmail(self.config.sender_email, receivers, text)
            
            # 关闭连接
            server.quit()
            
            self.logger.info(f"邮件发送成功: {subject}")
            self.logger.info(f"  发件人: {self.config.sender_email}")
            self.logger.info(f"  收件人: {receiver_str}")
            
            return True
            
        except smtplib.SMTPAuthenticationError as e:
            self.logger.error(f"SMTP 认证失败: {e}")
            self.logger.error("请检查发件人邮箱和密码（授权码）是否正确")
            return False
        
        except smtplib.SMTPException as e:
            self.logger.error(f"SMTP 错误: {e}")
            return False
        
        except Exception as e:
            self.logger.error(f"邮件发送失败: {e}")
            self.logger.error("请检查邮件配置是否正确")
            return False
    
    def _send_email_async(self, subject: str, body: str) -> None:
        """异步发送邮件（不阻塞主流程）
        
        Args:
            subject: 邮件主题
            body: 邮件正文
        """
        def send():
            try:
                self._send_email_sync(subject, body)
            except Exception as e:
                self.logger.error(f"异步邮件发送异常: {e}")
        
        thread = threading.Thread(target=send, daemon=True, name="EmailSender")
        thread.start()
        self.logger.debug(f"异步邮件发送线程已启动: {subject}")

    def send_product_found(self, product: ProductInfo) -> bool:
        """发送找到产品通知
        
        Args:
            product: 产品信息
            
        Returns:
            是否发送成功
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        subject = f"🎯 找到目标显卡: {product.name}"
        
        body = f"""
AI Agent 显卡监控系统 - 产品发现通知
=====================================

检测到符合条件的显卡产品！

产品信息:
---------
名称: {product.name}
型号: RTX {product.model}
品牌: {product.brand}
价格: {product.price_text} (${product.price:.2f})
库存状态: {"✅ 可购买" if product.is_available else "❌ 不可购买"}

产品链接:
{product.product_url}

AI 分析:
---------
置信度: {product.confidence * 100:.1f}%
识别依据: {product.reasoning}

检测时间: {timestamp}

=====================================
下一步操作:
- 系统将尝试自动加入购物车
- 请保持浏览器打开
- 准备完成支付流程

这是来自 AI Agent 显卡监控系统的自动通知
=====================================
"""
        
        self.logger.info(f"发送产品发现通知: {product.name} - ${product.price:.2f}")
        
        # 异步发送邮件，不阻塞主流程
        self._send_email_async(subject, body)
        
        return True
    
    def send_purchase_success(self, product: ProductInfo, checkout_url: str) -> bool:
        """发送购买成功通知
        
        Args:
            product: 产品信息
            checkout_url: 结账页面 URL
            
        Returns:
            是否发送成功
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        subject = f"🎉 购买成功: {product.name} - 请立即完成支付！"
        
        body = f"""
AI Agent 显卡监控系统 - 购买成功通知
=====================================

✅ 成功加入购物车并到达结账页面！

产品信息:
---------
名称: {product.name}
型号: RTX {product.model}
品牌: {product.brand}
价格: {product.price_text} (${product.price:.2f})

结账链接:
{checkout_url}

⚠️ 重要 - 立即行动！
=====================================

系统已自动完成:
1. ✅ 找到产品
2. ✅ 加入购物车
3. ✅ 点击结账
4. ✅ 到达结账页面

您需要立即完成:
=====================================

方式 1: 电脑支付（推荐）
- 打开您的 Chrome 浏览器（已自动打开）
- 您应该看到 Best Buy 结账页面
- 填写支付信息
- 点击 "Place Order" 按钮

方式 2: 手机支付（如果不在电脑旁）
- 点击上方的结账链接
- 登录您的 Best Buy 账户
- 完成支付流程

⏰ 时间紧迫！
- 请在 10 分钟内完成支付
- 超时订单可能被释放

操作时间: {timestamp}

=====================================
这是来自 AI Agent 显卡监控系统的自动通知
祝您抢购成功！🎉
=====================================
"""
        
        self.logger.info(f"发送购买成功通知: {product.name}")
        self.logger.info(f"结账 URL: {checkout_url}")
        
        # 异步发送邮件，不阻塞主流程
        self._send_email_async(subject, body)
        
        return True
    
    def send_error_alert(self, error_msg: str, error_type: str = "系统错误", 
                        context: Optional[dict] = None) -> bool:
        """发送错误警告
        
        Args:
            error_msg: 错误信息
            error_type: 错误类型
            context: 错误上下文（可选）
            
        Returns:
            是否发送成功
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        subject = f"⚠️ 监控系统错误: {error_type}"
        
        # 构建上下文信息
        context_str = ""
        if context:
            context_str = "\n错误上下文:\n"
            for key, value in context.items():
                context_str += f"  {key}: {value}\n"
        
        body = f"""
AI Agent 显卡监控系统 - 错误警告
=====================================

监控系统遇到错误，需要您的关注。

错误类型: {error_type}

错误信息:
---------
{error_msg}
{context_str}

发生时间: {timestamp}

=====================================
建议操作:
1. 检查系统日志文件 (logs/monitor.log)
2. 确认网络连接正常
3. 确认 Chrome 浏览器正常运行
4. 检查 DeepSeek API 配置
5. 如果错误持续，请重启监控系统

系统状态:
- 监控系统仍在运行
- 将继续尝试监控
- 如果连续失败，系统将自动重启

=====================================
这是来自 AI Agent 显卡监控系统的自动通知
=====================================
"""
        
        self.logger.warning(f"发送错误警告通知: {error_type}")
        
        # 异步发送邮件，不阻塞主流程
        self._send_email_async(subject, body)
        
        return True
