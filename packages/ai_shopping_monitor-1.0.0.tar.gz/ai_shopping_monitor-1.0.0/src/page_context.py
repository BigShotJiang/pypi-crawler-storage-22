"""
Page Context Extractor

负责从 Selenium WebDriver 提取页面上下文信息，供 AI Agent 分析使用。
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from selenium import webdriver
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import base64

from src.logger import get_logger


@dataclass
class PageContext:
    """页面上下文数据类
    
    包含页面的各种信息，用于 AI Agent 分析。
    """
    
    url: str                                    # 当前页面 URL
    html_content: str                           # HTML 内容（可选择性提取）
    text_content: str                           # 纯文本内容
    visible_text: str                           # 可见文本（排除隐藏元素）
    metadata: Dict[str, Any] = field(default_factory=dict)  # 元数据（标题、描述等）
    screenshot_base64: str = ""                 # 页面截图（可选）


class PageContextExtractor:
    """页面上下文提取器
    
    从 Selenium WebDriver 提取页面内容，包括 HTML、文本、可见文本和元数据。
    """
    
    def __init__(self):
        """初始化提取器"""
        self.logger = get_logger()
    
    def extract_from_driver(self, 
                           driver: WebDriver, 
                           include_screenshot: bool = False) -> PageContext:
        """从 WebDriver 提取页面上下文
        
        Args:
            driver: Selenium WebDriver 实例
            include_screenshot: 是否包含截图（默认 False，截图会增加数据量）
            
        Returns:
            PageContext 对象，包含页面的各种信息
            
        Raises:
            Exception: 如果提取过程中发生错误
        """
        try:
            self.logger.debug("开始提取页面上下文")
            
            # 提取基本信息
            url = driver.current_url
            self.logger.debug(f"当前 URL: {url}")
            
            # 提取 HTML 内容
            html_content = driver.page_source
            self.logger.debug(f"HTML 内容长度: {len(html_content)} 字符")
            
            # 提取纯文本内容
            text_content = self._extract_text_content(driver)
            self.logger.debug(f"纯文本内容长度: {len(text_content)} 字符")
            
            # 提取可见文本（排除隐藏元素）
            visible_text = self._extract_visible_text(driver)
            self.logger.debug(f"可见文本长度: {len(visible_text)} 字符")
            
            # 提取元数据
            metadata = self._extract_metadata(driver)
            self.logger.debug(f"元数据: {metadata}")
            
            # 可选：提取截图
            screenshot_base64 = ""
            if include_screenshot:
                screenshot_base64 = self._extract_screenshot(driver)
                self.logger.debug(f"截图大小: {len(screenshot_base64)} 字符")
            
            # 创建 PageContext 对象
            context = PageContext(
                url=url,
                html_content=html_content,
                text_content=text_content,
                visible_text=visible_text,
                metadata=metadata,
                screenshot_base64=screenshot_base64
            )
            
            self.logger.info("页面上下文提取完成")
            return context
            
        except Exception as e:
            self.logger.error(f"提取页面上下文失败: {e}", exc_info=True)
            raise
    
    def _extract_text_content(self, driver: WebDriver) -> str:
        """提取纯文本内容
        
        Args:
            driver: Selenium WebDriver
            
        Returns:
            页面的纯文本内容
        """
        try:
            # 使用 body 元素的 text 属性获取所有文本
            body = driver.find_element(By.TAG_NAME, "body")
            text = body.text
            return text.strip()
        except NoSuchElementException:
            self.logger.warning("未找到 body 元素")
            return ""
        except Exception as e:
            self.logger.error(f"提取纯文本内容失败: {e}")
            return ""
    
    def _extract_visible_text(self, driver: WebDriver) -> str:
        """提取可见文本（排除隐藏元素）
        
        Args:
            driver: Selenium WebDriver
            
        Returns:
            页面的可见文本内容
        """
        try:
            # 使用 JavaScript 提取所有可见元素的文本
            script = """
            function getVisibleText(element) {
                // 检查元素是否可见
                if (element.offsetParent === null && element.tagName !== 'BODY') {
                    return '';
                }
                
                // 获取计算样式
                const style = window.getComputedStyle(element);
                if (style.display === 'none' || 
                    style.visibility === 'hidden' || 
                    style.opacity === '0') {
                    return '';
                }
                
                // 收集文本节点
                let text = '';
                for (let node of element.childNodes) {
                    if (node.nodeType === Node.TEXT_NODE) {
                        text += node.textContent;
                    } else if (node.nodeType === Node.ELEMENT_NODE) {
                        text += getVisibleText(node);
                    }
                }
                
                return text;
            }
            
            return getVisibleText(document.body);
            """
            
            visible_text = driver.execute_script(script)
            
            # 清理文本：移除多余空白
            visible_text = ' '.join(visible_text.split())
            
            return visible_text.strip()
            
        except Exception as e:
            self.logger.error(f"提取可见文本失败: {e}")
            # 降级：返回普通文本内容
            return self._extract_text_content(driver)
    
    def _extract_metadata(self, driver: WebDriver) -> Dict[str, Any]:
        """提取页面元数据
        
        Args:
            driver: Selenium WebDriver
            
        Returns:
            包含元数据的字典（标题、描述、关键词等）
        """
        metadata = {}
        
        try:
            # 提取页面标题
            metadata['title'] = driver.title
            
            # 提取 meta 标签
            try:
                # 描述
                description_meta = driver.find_element(
                    By.CSS_SELECTOR, 
                    "meta[name='description']"
                )
                metadata['description'] = description_meta.get_attribute('content')
            except NoSuchElementException:
                pass
            
            try:
                # 关键词
                keywords_meta = driver.find_element(
                    By.CSS_SELECTOR, 
                    "meta[name='keywords']"
                )
                metadata['keywords'] = keywords_meta.get_attribute('content')
            except NoSuchElementException:
                pass
            
            # 提取 Open Graph 标签（常用于社交媒体分享）
            try:
                og_title = driver.find_element(
                    By.CSS_SELECTOR, 
                    "meta[property='og:title']"
                )
                metadata['og_title'] = og_title.get_attribute('content')
            except NoSuchElementException:
                pass
            
            try:
                og_description = driver.find_element(
                    By.CSS_SELECTOR, 
                    "meta[property='og:description']"
                )
                metadata['og_description'] = og_description.get_attribute('content')
            except NoSuchElementException:
                pass
            
        except Exception as e:
            self.logger.error(f"提取元数据失败: {e}")
        
        return metadata
    
    def _extract_screenshot(self, driver: WebDriver) -> str:
        """提取页面截图（Base64 编码）
        
        Args:
            driver: Selenium WebDriver
            
        Returns:
            Base64 编码的截图字符串
        """
        try:
            # 获取截图（PNG 格式，Base64 编码）
            screenshot_base64 = driver.get_screenshot_as_base64()
            return screenshot_base64
        except Exception as e:
            self.logger.error(f"提取截图失败: {e}")
            return ""
    
    def extract_product_section(self, driver: WebDriver) -> str:
        """提取产品列表区域的 HTML
        
        尝试智能识别产品列表区域，如果失败则返回整个页面的 HTML。
        
        Args:
            driver: Selenium WebDriver
            
        Returns:
            产品区域的 HTML 字符串
        """
        try:
            self.logger.debug("尝试提取产品区域 HTML")
            
            # 常见的产品列表容器选择器（Best Buy 特定）
            product_selectors = [
                ".sku-item",                    # Best Buy 产品项
                ".shop-product-list",           # 产品列表容器
                "[data-testid='product-list']", # 测试 ID
                ".product-list",                # 通用产品列表
                ".search-results",              # 搜索结果
                "#products",                    # 产品容器 ID
            ]
            
            # 尝试每个选择器
            for selector in product_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    if elements:
                        # 找到产品区域，提取 HTML
                        html_parts = []
                        for element in elements:
                            html_parts.append(element.get_attribute('outerHTML'))
                        
                        product_html = '\n'.join(html_parts)
                        self.logger.info(
                            f"使用选择器 '{selector}' 找到 {len(elements)} 个产品元素"
                        )
                        self.logger.debug(f"产品区域 HTML 长度: {len(product_html)} 字符")
                        return product_html
                        
                except NoSuchElementException:
                    continue
                except Exception as e:
                    self.logger.debug(f"选择器 '{selector}' 失败: {e}")
                    continue
            
            # 如果没有找到特定的产品区域，返回整个页面的 HTML
            self.logger.warning("未找到特定的产品区域，返回整个页面 HTML")
            return driver.page_source
            
        except Exception as e:
            self.logger.error(f"提取产品区域 HTML 失败: {e}")
            # 降级：返回整个页面
            return driver.page_source
