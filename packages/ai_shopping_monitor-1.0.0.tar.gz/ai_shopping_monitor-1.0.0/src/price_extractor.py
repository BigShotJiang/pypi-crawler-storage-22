"""
价格提取器

从文本中提取价格信息，支持多种价格格式。
"""

import re
from typing import Optional, List
from src.logger import get_logger


class PriceExtractor:
    """价格提取器
    
    从文本中提取价格信息，处理多种价格格式，并验证价格范围。
    """
    
    # 价格正则表达式模式
    # 匹配格式: $1,999.99, $1999, $1999.99, 1999.99, 1999
    PRICE_PATTERN = re.compile(r'\$?\s*(\d{1,}(?:,\d{3})*(?:\.\d{2})?)')
    
    # 价格范围验证
    MIN_PRICE = 100.0
    MAX_PRICE = 10000.0
    
    def __init__(self):
        """初始化价格提取器"""
        self.logger = get_logger()
    
    def extract_price(self, text: str) -> Optional[float]:
        """从文本中提取价格
        
        Args:
            text: 包含价格信息的文本
            
        Returns:
            提取的价格（float），如果未找到有效价格返回 None
        """
        if not text:
            self.logger.warning("价格提取失败: 输入文本为空")
            return None
        
        # 首先尝试查找带美元符号的价格（优先级更高）
        dollar_pattern = re.compile(r'\$\s*(\d{1,}(?:,\d{3})*(?:\.\d{2})?)')
        dollar_matches = dollar_pattern.findall(text)
        
        if dollar_matches:
            # 使用第一个带美元符号的价格
            price_str = dollar_matches[0]
            price = self._parse_price_string(price_str)
            
            if price is not None and self.validate_price_range(price):
                self.logger.debug(f"成功提取价格: ${price:.2f} (原始文本: ${price_str})")
                return price
        
        # 如果没有找到带美元符号的价格，尝试查找所有数字
        matches = self.PRICE_PATTERN.findall(text)
        
        if not matches:
            self.logger.warning(f"未找到价格信息: {text[:100]}")
            return None
        
        # 解析第一个匹配的价格
        price_str = matches[0]
        price = self._parse_price_string(price_str)
        
        if price is None:
            return None
        
        # 验证价格范围
        if not self.validate_price_range(price):
            self.logger.warning(
                f"价格超出合理范围: ${price:.2f} "
                f"(有效范围: ${self.MIN_PRICE} - ${self.MAX_PRICE})"
            )
            return None
        
        self.logger.debug(f"成功提取价格: ${price:.2f} (原始文本: {price_str})")
        return price
    
    def extract_all_prices(self, text: str) -> List[float]:
        """从文本中提取所有价格
        
        用于处理包含多个价格的情况（如原价、折扣价）。
        
        Args:
            text: 包含价格信息的文本
            
        Returns:
            提取的价格列表
        """
        if not text:
            return []
        
        # 查找所有匹配的价格
        matches = self.PRICE_PATTERN.findall(text)
        
        prices = []
        for price_str in matches:
            price = self._parse_price_string(price_str)
            if price is not None and self.validate_price_range(price):
                prices.append(price)
        
        if prices:
            self.logger.debug(f"提取到 {len(prices)} 个有效价格: {prices}")
        else:
            self.logger.warning(f"未找到有效价格: {text[:100]}")
        
        return prices
    
    def extract_sale_price(self, text: str) -> Optional[float]:
        """提取实际销售价格
        
        如果文本包含多个价格（原价、折扣价），返回最低价格（通常是折扣价）。
        
        Args:
            text: 包含价格信息的文本
            
        Returns:
            实际销售价格，如果未找到返回 None
        """
        prices = self.extract_all_prices(text)
        
        if not prices:
            return None
        
        # 返回最低价格（折扣价）
        sale_price = min(prices)
        
        if len(prices) > 1:
            self.logger.debug(
                f"检测到多个价格 {prices}，使用最低价格: ${sale_price:.2f}"
            )
        
        return sale_price
    
    def _parse_price_string(self, price_str: str) -> Optional[float]:
        """解析价格字符串为浮点数
        
        Args:
            price_str: 价格字符串（如 "1,999.99"）
            
        Returns:
            解析后的价格，如果解析失败返回 None
        """
        try:
            # 移除逗号
            price_str = price_str.replace(',', '')
            
            # 转换为浮点数
            price = float(price_str)
            
            return price
            
        except ValueError as e:
            self.logger.error(f"价格解析失败: {price_str} - {e}")
            return None
    
    def validate_price_range(self, price: float) -> bool:
        """验证价格是否在合理范围内
        
        Args:
            price: 价格
            
        Returns:
            是否在合理范围内
        """
        return self.MIN_PRICE < price < self.MAX_PRICE
    
    def format_price(self, price: float) -> str:
        """格式化价格为标准字符串
        
        Args:
            price: 价格
            
        Returns:
            格式化的价格字符串（如 "$1,999.99"）
        """
        return f"${price:,.2f}"
