import json
from pathlib import Path

try:
    import allure  # type: ignore
except Exception:  # pragma: no cover
    allure = None

from ai_testing_swarm.core.curl_parser import parse_curl
from ai_testing_swarm.orchestrator import SwarmOrchestrator


def test_swarm():
    # Public-only test target (enforced by orchestrator safety guard)
    repo_root = Path(__file__).resolve().parents[1]
    payload = json.loads((repo_root / "input" / "public_example_request.json").read_text())
    request = parse_curl(payload["curl"])

    decision, results = SwarmOrchestrator().run(request)

    if allure:
        allure.attach(decision, "Release Decision")

        for r in results:
            allure.attach(str(r), r["name"])

    assert decision in ["APPROVE_RELEASE", "REJECT_RELEASE"]

