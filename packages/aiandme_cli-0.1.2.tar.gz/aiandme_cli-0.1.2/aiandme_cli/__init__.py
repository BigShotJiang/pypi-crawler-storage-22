"""AIandMe CLI - command line interface for AI agent security testing."""

__version__ = "0.1.0"
