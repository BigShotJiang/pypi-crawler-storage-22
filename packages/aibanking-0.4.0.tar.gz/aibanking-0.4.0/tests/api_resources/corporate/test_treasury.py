# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from jocall3 import Jocall3, AsyncJocall3
from tests.utils import assert_matches_type
from jocall3.types.corporate import TreasuryForecastCashFlowResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTreasury:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_forecast_cash_flow(self, client: Jocall3) -> None:
        treasury = client.corporate.treasury.forecast_cash_flow()
        assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_forecast_cash_flow_with_all_params(self, client: Jocall3) -> None:
        treasury = client.corporate.treasury.forecast_cash_flow(
            forecast_horizon_days=0,
            include_scenario_analysis=True,
        )
        assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_forecast_cash_flow(self, client: Jocall3) -> None:
        response = client.corporate.treasury.with_raw_response.forecast_cash_flow()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        treasury = response.parse()
        assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_forecast_cash_flow(self, client: Jocall3) -> None:
        with client.corporate.treasury.with_streaming_response.forecast_cash_flow() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            treasury = response.parse()
            assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncTreasury:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_forecast_cash_flow(self, async_client: AsyncJocall3) -> None:
        treasury = await async_client.corporate.treasury.forecast_cash_flow()
        assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_forecast_cash_flow_with_all_params(self, async_client: AsyncJocall3) -> None:
        treasury = await async_client.corporate.treasury.forecast_cash_flow(
            forecast_horizon_days=0,
            include_scenario_analysis=True,
        )
        assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_forecast_cash_flow(self, async_client: AsyncJocall3) -> None:
        response = await async_client.corporate.treasury.with_raw_response.forecast_cash_flow()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        treasury = await response.parse()
        assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_forecast_cash_flow(self, async_client: AsyncJocall3) -> None:
        async with async_client.corporate.treasury.with_streaming_response.forecast_cash_flow() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            treasury = await response.parse()
            assert_matches_type(TreasuryForecastCashFlowResponse, treasury, path=["response"])

        assert cast(Any, response.is_closed) is True
