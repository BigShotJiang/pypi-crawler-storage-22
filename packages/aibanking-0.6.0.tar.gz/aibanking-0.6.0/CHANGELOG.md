# Changelog

## 0.6.0 (2026-01-28)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/diplomat-bit/aibank/compare/v0.5.0...v0.6.0)

### Features

* **api:** manual updates ([3d21d63](https://github.com/diplomat-bit/aibank/commit/3d21d6359f500cda24bb257626a4b5b890846b18))

## 0.5.0 (2026-01-28)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/diplomat-bit/aibank/compare/v0.4.0...v0.5.0)

### Features

* **api:** api update ([d584a5d](https://github.com/diplomat-bit/aibank/commit/d584a5d8b749c73cb04bdeb8cc29b278131a7c4e))

## 0.4.0 (2026-01-28)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/diplomat-bit/aibank/compare/v0.3.0...v0.4.0)

### Features

* **api:** manual updates ([48faf13](https://github.com/diplomat-bit/aibank/commit/48faf13e6533cccb96e8393a6098777860955778))
* **api:** manual updates ([ffa52f7](https://github.com/diplomat-bit/aibank/commit/ffa52f757b9fc7a159176dfba0fb2d9dd4a13f2a))

## 0.3.0 (2026-01-28)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/diplomat-bit/aibank/compare/v0.2.0...v0.3.0)

### Features

* **api:** manual updates ([dea44c2](https://github.com/diplomat-bit/aibank/commit/dea44c2f78c1b2c9416b8167bfe7bd24a12503b2))

## 0.2.0 (2026-01-28)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/diplomat-bit/aibank/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([a6f5b4a](https://github.com/diplomat-bit/aibank/commit/a6f5b4a64d01be6f5028b05c464c6ed3fa9a0f91))

## 0.1.0 (2026-01-28)

Full Changelog: [v0.0.3...v0.1.0](https://github.com/diplomat-bit/aibank/compare/v0.0.3...v0.1.0)

### Features

* **api:** api update ([e0f5ef8](https://github.com/diplomat-bit/aibank/commit/e0f5ef8c9c0fad9c4c4dbc3c3f2a8f0cc2dd0ab5))
* **api:** manual updates ([ed40583](https://github.com/diplomat-bit/aibank/commit/ed405836f7f2a71acb2a1ce5520a8df30994744e))


### Chores

* sync repo ([76ad170](https://github.com/diplomat-bit/aibank/commit/76ad170c4796a898a7bcf153699e2591bd13cafb))
* update SDK settings ([aea3cb9](https://github.com/diplomat-bit/aibank/commit/aea3cb9bc22e8aad6924f344c2a1ab3291dc548f))
* update SDK settings ([554e7ce](https://github.com/diplomat-bit/aibank/commit/554e7ce0ce91dce7b1f2c8d5718a2d2965d2291c))
* update SDK settings ([94ca901](https://github.com/diplomat-bit/aibank/commit/94ca90137b8b27ef1037c39c27f76e8c5e8de033))
* update SDK settings ([f6f187d](https://github.com/diplomat-bit/aibank/commit/f6f187dbeb0413b700cf0f8a07eb9f741952f693))
* update SDK settings ([8a0a376](https://github.com/diplomat-bit/aibank/commit/8a0a37670c341862bfbac51d47005662e5656edd))
* update SDK settings ([8cbbaa7](https://github.com/diplomat-bit/aibank/commit/8cbbaa7c744285381ce9696dc700e84c27a0d2a7))

## 0.0.3 (2026-01-25)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/diplomat-bit/jocall3-python/compare/v0.0.2...v0.0.3)

## 0.0.2 (2026-01-25)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/diplomat-bit/jocall3-python/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([f6f187d](https://github.com/diplomat-bit/jocall3-python/commit/f6f187dbeb0413b700cf0f8a07eb9f741952f693))
* update SDK settings ([8a0a376](https://github.com/diplomat-bit/jocall3-python/commit/8a0a37670c341862bfbac51d47005662e5656edd))
* update SDK settings ([8cbbaa7](https://github.com/diplomat-bit/jocall3-python/commit/8cbbaa7c744285381ce9696dc700e84c27a0d2a7))
