#!/usr/bin/env bash
set -euo pipefail

npm view @openai/codex version
