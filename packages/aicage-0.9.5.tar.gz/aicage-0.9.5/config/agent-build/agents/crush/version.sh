#!/usr/bin/env bash
set -euo pipefail

npm view @charmland/crush version
