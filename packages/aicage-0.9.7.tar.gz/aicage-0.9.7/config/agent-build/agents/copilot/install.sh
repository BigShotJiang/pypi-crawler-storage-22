#!/usr/bin/env bash
set -euo pipefail

npm install -g @github/copilot
