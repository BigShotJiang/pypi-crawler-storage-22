#!/usr/bin/env bash
set -euo pipefail

npm view @google/gemini-cli version
