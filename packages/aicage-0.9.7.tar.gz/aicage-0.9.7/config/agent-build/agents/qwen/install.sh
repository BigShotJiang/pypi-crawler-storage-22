#!/usr/bin/env bash
set -euo pipefail

npm install -g @qwen-code/qwen-code@latest
