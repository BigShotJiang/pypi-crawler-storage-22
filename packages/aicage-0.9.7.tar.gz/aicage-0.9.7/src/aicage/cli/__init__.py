from aicage.cli.entrypoint import main as main
