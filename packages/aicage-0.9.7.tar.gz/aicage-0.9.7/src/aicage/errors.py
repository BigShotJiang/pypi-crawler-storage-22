

class AicageError(Exception):
    """Base error for aicage."""
