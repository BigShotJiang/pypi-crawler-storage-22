from aicage.errors import AicageError


class RegistryError(AicageError):
    pass
