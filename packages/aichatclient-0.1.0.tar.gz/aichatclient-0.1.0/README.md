# 🤖 AiClient – کتابخانه چت با هوش مصنوعی (Python)

یک کتابخانه‌ی ساده، تمیز و قابل‌انتشار برای ارتباط با مدل‌های مختلف **هوش مصنوعی (LLM)** با استفاده از SDK رسمی OpenAI و پشتیبانی از **Base URL سفارشی** (مانند Liara AI).

این پروژه برای توسعه‌دهندگانی ساخته شده که می‌خواهند بدون درگیری با جزئیات پیچیده، به‌سرعت یک سیستم چت هوشمند، دستیار AI یا API مبتنی بر LLM بسازند.

---

## ✨ ویژگی‌ها

- ✅ پشتیبانی از مدل‌های متنوع (OpenAI، Google، Anthropic، Qwen، Grok و ...)
- ✅ مدیریت ساده `System Prompt`
- ✅ قابلیت استفاده با Base URL سفارشی
- ✅ ساختار مینیمال و قابل توسعه
- ✅ مناسب برای پروژه‌های واقعی و انتشار عمومی
- ✅ مدیریت خطا به‌صورت ایمن و خوانا

---

## 📦 نصب

```bash
pip install aichatclient
```

> Python نسخه 3.8 یا بالاتر موردنیاز است.

---

## 🚀 شروع سریع (Quick Start)

```python
from aichatclient import AiClient
system_prompt = ""
chat = AiClient(
    system_prompt=system_prompt,
    api_key="",
    base_url="https://ai.liara.ir/api/v1/",
    model="openai/gpt-4o-mini"
)

response = ai.chat("سلام، خودتو معرفی کن")
print(response)
```

---

## 🧠 ساختار کلاس AiClient

### Constructor

```python
AiClient(system_prompt, api_key, model, base_url="https://ai.liara.ir/api/v1")
```

#### پارامترها

| پارامتر | نوع | توضیح |
|-------|----|------|
| system_prompt | str | پیام سیستمی برای کنترل رفتار مدل |
| api_key | str | کلید API سرویس هوش مصنوعی |
| model | str | نام مدل انتخابی |
| base_url | str | آدرس API (قابل تغییر) |

---

## 📚 دریافت لیست مدل‌ها

برای مشاهده مدل‌های پشتیبانی‌شده:

```python
models = ai.list_model()
for model in models:
    print(model)
```

📌 این طراحی باعث می‌شود کتابخانه به یک سرویس خاص وابسته نباشد.

---

## 💬 ارسال پیام (Chat)

```python
reply = ai.chat("هوش مصنوعی چیست؟")
print(reply)
```

### خروجی
- در حالت موفق: `str` (پاسخ مدل)
- در حالت خطا: پیام خطای قابل فهم به زبان فارسی

---

## 🛡️ مدیریت خطا

در متد `chat` از `try / except` استفاده شده تا:

- برنامه کرش نکند
- خطاها قابل ردیابی باشند
- تجربه توسعه‌دهنده بهتر شود

نمونه خروجی خطا:

```text
خطا در ارتباط با API: Connection timeout
```

---

## 🏗️ موارد استفاده (Use Cases)

- 🤖 ربات چت
- 🧠 دستیار هوشمند
- 🌐 API هوش مصنوعی
- 🛠️ ابزارهای مبتنی بر LLM
- 📊 تحلیل متن و تولید محتوا







