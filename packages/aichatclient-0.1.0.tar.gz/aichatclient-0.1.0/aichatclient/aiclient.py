from openai import OpenAI









class AiClient:
    def __init__(self, system_prompt: str,api_key,model,base_url="https://ai.liara.ir/api/v1"):
        self.system_prompt = system_prompt
        self.api_key = api_key
        self.base_url = base_url
        self.model = model

        
        
        
        self.client = OpenAI(
            base_url=self.base_url,
            api_key=self.api_key
        )
        
    def list_model(self):
        # "openai/gpt-4o-mini"
        # لیست تمام مدل‌های موجود برای استفاده در پارامتر model
        MODEL_NAMES = [
            "OpenAI: GPT-4o-mini",
            "Google: Gemini 2.0 Flash",
            "OpenAI: GPT-5 Nano",
            "OpenAI: GPT-5.2 Chat",
            "Google: Gemini 3 Flash Preview",
            "OpenAI: GPT-5.2",
            "Anthropic: Claude Opus 4.5",
            "Google: Gemini Embedding 001",
            "OpenAI: GPT-Image 1",
            "OpenAI: GPT-Image 1 mini",
            "OpenAI: GPT-Image 1.5",
            "OpenAI: GPT-5.1-Codex",
            "OpenAI: GPT-5.1",
            "OpenAI: GPT-5.1 Chat",
            "OpenAI: GPT-5.1-Codex-Mini",
            "Anthropic: Claude Haiku 4.5",
            "MoonshotAI: Kimi K2 Thinking",
            "Google: Gemini 3 Pro Preview",
            "Google: Gemini 2.5 Pro",
            "xAI: Grok 4 Fast",
            "Z.AI: GLM 4.6",
            "OpenAI: o3",
            "OpenAI: o1",
            "OpenAI: GPT-5 Codex",
            "Anthropic: Claude Sonnet 4.5",
            "OpenAI: GPT-5",
            "DeepSeek: DeepSeek V3.1",
            "MoonshotAI: Kimi K2 0905",
            "xAI: Grok Code Fast 1",
            "OpenAI: text-embedding-ada-002",
            "OpenAI: text-embedding-3-small",
            "OpenAI: text-embedding-3-large",
            "Qwen: Qwen-Turbo",
            "Qwen: Qwen-Plus",
            "Qwen2.5 72B Instruct",
            "Qwen: Qwen-Max",
            "Qwen: Qwen3 235B A22B Thinking 2507",
            "Qwen: Qwen3 32B",
            "Qwen: Qwen3 Coder 480B A35B",
            "OpenAI: GPT-5 Mini",
            "OpenAI: GPT-5 Chat",
            "Perplexity: Sonar Reasoning Pro",
            "Perplexity: Sonar Pro",
            "Perplexity: Sonar",
            "Google: Gemma 3 27B",
            "Google: Gemini 2.5 Flash",
            "xAI: Grok 4",
            "OpenAI: o4 Mini",
            "OpenAI: o4 Mini High",
            "Anthropic: Claude Opus 4",
            "Anthropic: Claude Sonnet 4",
            "OpenAI: GPT-4.1 Mini",
            "xAI: Grok 3 Mini Beta",
            "OpenAI: GPT-4.1",
            "xAI: Grok 3 Beta",
            "DeepSeek: R1 Distill Llama 70B",
            "Google: Gemini 2.0 Flash Lite",
            "Meta: Llama 3.3 70B Instruct",
            "Anthropic: Claude 3.7 Sonnet (thinking)",
            "Mistral: Mistral Nemo",
            "Anthropic: Claude 3.5 Sonnet",
            "DeepSeek: DeepSeek V3 0324",
            "Anthropic: Claude 3.7 Sonnet",
            "Google: Gemini 2.5 Pro Preview 06-05"
        ]
        
        return MODEL_NAMES
        
        

    def chat(self, user_input: str) -> str:

        try:
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_input}
                ]
            )
            reply = completion.choices[0].message.content.strip()
            return reply
        except Exception as e:
            return f"خطا در ارتباط با API: {str(e)}"
    

        






