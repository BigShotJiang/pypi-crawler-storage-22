from setuptools import setup, find_packages

setup(
    name="aichatclient",
    version="0.1.0",
    author="Amirhossein Khazaei",
    author_email="",
    description="A simple and extensible Python client for chatting with multiple AI models via OpenAI-compatible APIs",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/amirhossinpython/aichatclient",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "openai>=1.0.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    keywords="ai openai llm chatbot client",
)
