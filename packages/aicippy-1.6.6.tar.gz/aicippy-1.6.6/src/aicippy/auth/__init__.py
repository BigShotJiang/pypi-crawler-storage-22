"""
Authentication module for AiCippy.

Provides secure authentication via AWS Cognito with device flow,
browser-based OAuth PKCE, token management, and OS keychain storage.
"""

from __future__ import annotations

from aicippy.auth.browser_auth import BrowserAuth
from aicippy.auth.cognito import CognitoAuth
from aicippy.auth.file_storage import FileCredentialStorage
from aicippy.auth.keychain import KeychainStorage
from aicippy.auth.models import AuthResult, TokenInfo
from aicippy.auth.social import SOCIAL_PROVIDERS, social_login_url

__all__ = [
    "SOCIAL_PROVIDERS",
    "AuthResult",
    "BrowserAuth",
    "CognitoAuth",
    "FileCredentialStorage",
    "KeychainStorage",
    "TokenInfo",
    "social_login_url",
]
