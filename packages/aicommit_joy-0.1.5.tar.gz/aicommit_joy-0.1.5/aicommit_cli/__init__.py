"""aicommit-cli - AI-powered Git commit message generator."""

__version__ = "0.1.5"
