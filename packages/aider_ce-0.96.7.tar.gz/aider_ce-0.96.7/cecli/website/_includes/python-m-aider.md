{: .tip }
In some environments you may get "cecli command not found" errors.
You can try `python -m cecli` or 
[see here for more info](/docs/troubleshooting/cecli-not-found.html).

