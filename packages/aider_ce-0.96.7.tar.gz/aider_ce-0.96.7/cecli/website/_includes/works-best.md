cecli works best with Claude 3.5 Sonnet, DeepSeek R1 & Chat V3, OpenAI o1, o3-mini & GPT-4o. cecli can [connect to almost any LLM, including local models](https://cecli.chat/docs/llms.html).
