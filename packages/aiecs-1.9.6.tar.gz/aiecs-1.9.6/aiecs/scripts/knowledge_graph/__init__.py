"""
Knowledge Graph Scripts
"""
