
from __future__ import annotations
from typing import Annotated, Optional
import httpx
import typer
from rich.console import Console
from rich.panel import Panel

from ..data_plane import _state
from aiel_cli.auth.credentials import list_profiles
from ..utilities import format_file_tree, default_workspace
from ..cli_utils import friendly_errors
from ..utils.format_integrations import (
    format_integrations_rich, 
    format_integration_rich,
    format_integration_check)

from ..integration_plane import (
        _dp_get_manifest,
        _manifest_to_map,
        _dp_get_resource_manifest,
        _dp_resource_check,
        
    )

console = Console()

# Root Typer app for this module. In the main CLI, this is typically mounted under
# a higher-level namespace (for example: `aiel workspace`).
app = typer.Typer(no_args_is_help=True, help="Manage CLI configuration")

# Sub-app used for attaching concrete commands. In this module, `ls` is exposed
# through this `set_app` instance.
set_app = typer.Typer(no_args_is_help=True, help="Set config values")
app.add_typer(set_app, name="")


@set_app.command("list", help="Display the current project integration and related metadata.", rich_help_panel="Integrations information")
@friendly_errors
def list_project_integrations(
    details: Annotated[bool, typer.Option("--d", help="...")] = False,
    provider: Annotated[Optional[str], typer.Option("--provider", "-p", help="Provider name (e.g., jira, slack)")] = None ):
    """
    Display the current workspace file tree and related metadata.

    Output sections:
        1. Files information:
           - Uses `data_plane._state()` to fetch the latest manifest.
           - Renders the manifest via `format_file_tree(...)` as a Rich-friendly
             tree view, giving a quick visual overview of the workspace files.

        2. Project information:
           - Resolves the active workspace context via `default_workspace(...)`,
             using the profile data from `list_profiles()`.
           - Prints workspace and project slugs so users know which logical
             environment they are inspecting.

        3. Repo information:
           - Prints a small summary panel with:
               • Last commit/pull time (`last_pull_at`)
               • Pending commit ID (if any)
               • Version value from the state (`version`)
           - This helps diagnose whether the local view is up to date and if
             there are unpushed changes.

    Notes:
        - This command is read-only; it does not modify workspace or repo state.
        - Exit codes are standard Typer defaults unless an upstream dependency
          raises or fails.
    """
    with httpx.Client(timeout=30.0) as client:
        # fresh remote
        if provider:
            conn = _dp_get_resource_manifest(client,provider)
            if not conn.get("ok"):
                msg = conn.get("error") or "Unknown error"
                console.print(f"[bold red]Error:[/bold red] {msg}")
                raise typer.Exit(code=1)
            else:
                format_integration_rich(provider,conn, show_details=details)
        else :
          integration_manifest = _dp_get_manifest(client)
          manifest = _manifest_to_map(integration_manifest)
          format_integrations_rich(manifest, show_details=details)


@set_app.command("check", help="Check the integration connection", rich_help_panel="Integration check")
@friendly_errors
def check_integration(
    details: Annotated[bool, typer.Option("--d", help="...")] = False,
    provider: Annotated[Optional[str], typer.Option("--provider", "-p", help="Provider name (e.g., jira, slack)")] = None ):
    """
    Display the current workspace file tree and related metadata.

    Output sections:
        1. Files information:
           - Uses `data_plane._state()` to fetch the latest manifest.
           - Renders the manifest via `format_file_tree(...)` as a Rich-friendly
             tree view, giving a quick visual overview of the workspace files.

        2. Project information:
           - Resolves the active workspace context via `default_workspace(...)`,
             using the profile data from `list_profiles()`.
           - Prints workspace and project slugs so users know which logical
             environment they are inspecting.

        3. Repo information:
           - Prints a small summary panel with:
               • Last commit/pull time (`last_pull_at`)
               • Pending commit ID (if any)
               • Version value from the state (`version`)
           - This helps diagnose whether the local view is up to date and if
             there are unpushed changes.

    Notes:
        - This command is read-only; it does not modify workspace or repo state.
        - Exit codes are standard Typer defaults unless an upstream dependency
          raises or fails.
    """
    with httpx.Client(timeout=30.0) as client:
        # fresh remote
        if provider:
            payload = {} if provider != 'postgres' else { "sql": "select 1 as ok"}
            conn = _dp_resource_check(client,provider, payload)
            if not conn.get("ok"):
                code = conn.get("error" or {}).get('code') or "Unknown error"
                msg = conn.get("error" or {}).get('message') or "Unknown error"
                console.print(f"[bold red]{code}:[/bold red] {msg}")
                raise typer.Exit(code=1)
            else:
                format_integration_check(integration=conn, provider=provider, show_details=details)
        else :
          console.print("Provider not provided!")

