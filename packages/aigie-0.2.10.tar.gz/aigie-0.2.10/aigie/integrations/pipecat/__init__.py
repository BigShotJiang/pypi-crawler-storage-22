"""
Pipecat integration for Aigie.

This module provides automatic tracing for Pipecat real-time voice and
multimodal AI pipelines, capturing conversations, turns, STT/TTS/LLM calls,
and interruptions.

Usage:
    # Manual observer usage
    from pipecat.pipeline.task import PipelineTask
    from aigie.integrations.pipecat import AigieObserver

    observer = AigieObserver(trace_name="my-voice-app")
    task = PipelineTask(pipeline, observers=[observer])

    # Auto-instrumentation
    from aigie.integrations.pipecat import patch_pipecat
    patch_pipecat()  # Patches PipelineTask to auto-register observer

    # Now all pipeline tasks are automatically traced
    task = PipelineTask(pipeline)

    # Session management
    from aigie.integrations.pipecat import voice_session
    with voice_session("Customer Call", user_id="user-123") as session:
        task = PipelineTask(pipeline, observers=[observer])
        await task.run()
        print(f"Turns: {session.total_turns}")

    # Cost tracking
    from aigie.integrations.pipecat import VoiceCostTracker
    tracker = VoiceCostTracker()
    tracker.add_turn(stt_model="deepgram", llm_model="gpt-4o", ...)
    print(tracker.get_summary())

    # Drift detection
    from aigie.integrations.pipecat import VoiceDriftDetector
    detector = VoiceDriftDetector()
    detector.start_conversation()
    # ... record events ...
    print(detector.get_drift_report())
"""

from .handler import AigieObserver
from .auto_instrument import (
    patch_pipecat,
    unpatch_pipecat,
    is_pipecat_patched,
)
from .config import PipecatConfig
from .metrics import VoiceMetrics, MetricsAggregator
from .cost_tracking import (
    VoiceCostTracker,
    calculate_turn_cost,
    calculate_stt_cost,
    calculate_tts_cost,
    calculate_llm_cost,
    get_stt_pricing,
    get_tts_pricing,
    get_llm_pricing,
)
from .session import (
    VoiceSessionContext,
    VoiceSessionManager,
    voice_session,
    get_session_context,
    set_session_context,
    get_or_create_session_context,
    clear_session_context,
)
from .retry import (
    RetryContext,
    RetryExhaustedError,
    TimeoutExceededError,
    PipelineExecutionError,
    VoiceServiceError,
    VoiceServiceRetry,
    retry_decorator,
    with_timeout,
    with_retry,
    with_timeout_and_retry,
)
from .drift_detection import (
    VoiceDriftDetector,
    VoiceDriftType,
    DriftSeverity,
    DetectedDrift,
    VoicePipelineExpectations,
    TurnExecution,
)

__all__ = [
    # Handler
    "AigieObserver",
    # Config
    "PipecatConfig",
    # Auto-instrumentation
    "patch_pipecat",
    "unpatch_pipecat",
    "is_pipecat_patched",
    # Metrics
    "VoiceMetrics",
    "MetricsAggregator",
    # Cost tracking
    "VoiceCostTracker",
    "calculate_turn_cost",
    "calculate_stt_cost",
    "calculate_tts_cost",
    "calculate_llm_cost",
    "get_stt_pricing",
    "get_tts_pricing",
    "get_llm_pricing",
    # Session management
    "VoiceSessionContext",
    "VoiceSessionManager",
    "voice_session",
    "get_session_context",
    "set_session_context",
    "get_or_create_session_context",
    "clear_session_context",
    # Retry utilities
    "RetryContext",
    "RetryExhaustedError",
    "TimeoutExceededError",
    "PipelineExecutionError",
    "VoiceServiceError",
    "VoiceServiceRetry",
    "retry_decorator",
    "with_timeout",
    "with_retry",
    "with_timeout_and_retry",
    # Drift detection
    "VoiceDriftDetector",
    "VoiceDriftType",
    "DriftSeverity",
    "DetectedDrift",
    "VoicePipelineExpectations",
    "TurnExecution",
]
