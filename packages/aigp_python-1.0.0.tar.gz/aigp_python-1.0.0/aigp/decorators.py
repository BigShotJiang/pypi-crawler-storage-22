"""
AIGP Decorators — Vendor-Neutral AI Governance for Agent Functions
==================================================================

Decorator-based API for the AI Governance Proof (AIGP) standard.

These decorators provide the governance orchestration layer for AI agents:
fetch governed policies/prompts/tools from a backend, compute Merkle proofs
of what was delivered, and emit AIGP events for compliance audit — all
without coupling to any specific governance server.

Vendor-specific backends (Sandarb, custom, etc.) plug in via the
``GovernanceBackend`` protocol. The backend decides *how* governance is
enforced (template rendering, rule evaluation, custom logic, etc.); AIGP
handles the proof, events, and developer experience.

Decorators:
  - @aigp: Full governance pipeline — fetch policies/prompts/tools from backend,
    receive enforcement decision + Merkle proof, emit AIGP events.
  - @a2a_traced: Auto-emit AIGP A2A_CALL events for multi-agent calls.
  - @audit_action: Auto-log function calls as AIGP audit events.

Context managers:
  - aigp_action: Inline governance for code blocks (same pipeline as @aigp).

Setup:
    from aigp import configure, aigp

    # With a vendor backend (e.g., Sandarb):
    from sandarb import SandarbBackend
    configure(
        backend=SandarbBackend("https://api.sandarb.ai", token="..."),
        agent_id="agent.my-bot-v1",
    )

    # Or standalone (AIGP events only, no enforcement):
    configure(agent_id="agent.my-bot-v1")

    @aigp(policy="policy.trading-limits")
    def process_trade(order: dict, governance=None) -> dict:
        ...
"""

from __future__ import annotations

import asyncio
import contextlib
import functools
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field as _dc_field
from typing import Any, Callable, Generator, Optional, TypeVar

logger = logging.getLogger("aigp")

F = TypeVar("F", bound=Callable[..., Any])


# =========================================================================
# GovernanceBackend — Vendor-neutral protocol
# =========================================================================


class GovernanceBackend:
    """
    Vendor-neutral protocol for governance backends.

    Implementations (e.g., SandarbBackend) provide the actual governance
    logic: policy rendering, enforcement, tool governance, etc. AIGP
    decorators call this protocol — they never know which backend is in use.

    To create a custom backend, subclass this and implement:
      - inject_governance()
      - log_activity() (optional, for @a2a_traced)
      - audit() (optional, for @audit_action)
    """

    def inject_governance(
        self,
        *,
        policies: dict[str, dict[str, Any]] | None = None,
        prompts: list[str] | None = None,
        tools: list[str] | None = None,
        tool_input: dict[str, Any] | None = None,
        trace_id: str | None = None,
    ) -> dict[str, Any]:
        """Execute the governance pipeline.

        Returns a dict with:
          - allowed: bool
          - denial_reason: str | None
          - merkle_root: str
          - policies: dict[str, dict] — per-policy results
          - prompts: dict[str, dict] — per-prompt results
          - tools: dict[str, dict] — per-tool results
          - raw_response: dict — full backend response
        """
        raise NotImplementedError("GovernanceBackend.inject_governance()")

    def log_activity(
        self,
        *,
        agent_id: str,
        trace_id: str,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        skill: str,
        success: bool = True,
        response_time_ms: int = 0,
    ) -> None:
        """Log A2A activity. Optional — defaults to no-op."""
        pass

    def audit(
        self,
        event_type: str,
        *,
        resource_type: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Log an audit event. Optional — defaults to no-op."""
        pass

    @property
    def agent_id(self) -> str:
        """Agent identifier for this backend."""
        return ""

    def get_trace_id(self) -> str:
        """Generate or retrieve a trace ID."""
        import uuid
        return str(uuid.uuid4())


# =========================================================================
# GovernanceResult — What developers receive
# =========================================================================


@dataclass
class GovernanceResult:
    """
    AI Governance result from the governance pipeline.

    Returned to decorated functions as the ``governance`` kwarg.
    Provides a unified API regardless of which backend is in use.
    """

    allowed: bool = True
    denial_reason: Optional[str] = None
    merkle_root: str = ""
    policies: dict = _dc_field(default_factory=dict)
    prompts: dict = _dc_field(default_factory=dict)
    tools: dict = _dc_field(default_factory=dict)
    raw_response: dict = _dc_field(default_factory=dict)

    @property
    def denied(self) -> bool:
        return not self.allowed

    def get_rendered(self, policy_name: str) -> Optional[str]:
        """Get the rendered content for a specific policy."""
        p = self.policies.get(policy_name, {})
        return p.get("content")

    def get_prompt(self, prompt_name: str) -> Optional[str]:
        """Get the rendered content for a specific prompt."""
        p = self.prompts.get(prompt_name, {})
        return p.get("content")

    def get_tool(self, tool_name: str) -> Optional[dict]:
        """Get the enforcement result for a specific tool."""
        return self.tools.get(tool_name)

    def is_tool_allowed(self, tool_name: str) -> bool:
        """Check if a specific tool was allowed (True if not in result)."""
        t = self.tools.get(tool_name)
        if t is None:
            return True
        return t.get("allowed", True)

    @classmethod
    def from_backend_response(cls, resp: dict[str, Any]) -> "GovernanceResult":
        """Create GovernanceResult from a GovernanceBackend.inject_governance() response."""
        return cls(
            allowed=resp.get("allowed", True),
            denial_reason=resp.get("denial_reason"),
            merkle_root=resp.get("merkle_root", ""),
            policies=resp.get("policies", {}),
            prompts=resp.get("prompts", {}),
            tools=resp.get("tools", {}),
            raw_response=resp.get("raw_response", resp),
        )

    @classmethod
    def error_fallback(cls) -> "GovernanceResult":
        """Create an allowed-but-unenforced result for fail-open scenarios."""
        return cls(
            allowed=True,
            raw_response={"_aigp_error": "backend_unavailable"},
        )


class GovernanceError(Exception):
    """Raised when governance enforcement denies an action (deny_raises=True)."""

    def __init__(self, message: str, result: Optional[GovernanceResult] = None):
        super().__init__(message)
        self.result = result


# =========================================================================
# Global state
# =========================================================================

_global_backend: Optional[GovernanceBackend] = None
_global_instrumentor: Optional[Any] = None
_global_agent_id: str = ""


def configure(
    backend: Optional[GovernanceBackend] = None,
    *,
    agent_id: str = "",
    agent_name: str = "",
    org_id: str = "",
    org_name: str = "",
    event_callback: Optional[Callable[[dict[str, Any]], None]] = None,
    openlineage_callback: Optional[Callable[[dict[str, Any]], None]] = None,
) -> None:
    """
    Configure the AIGP decorator framework.

    Must be called once at startup before using @aigp or aigp_action().

    Args:
        backend: A GovernanceBackend implementation (e.g., SandarbBackend).
                 If None, decorators emit AIGP events only (no enforcement).
        agent_id: AGRN agent identifier (e.g., "agent.my-bot-v1").
        agent_name: Human-readable agent name.
        org_id: AGRN organization identifier.
        org_name: Human-readable organization name.
        event_callback: Callback invoked with each AIGP event dict.
        openlineage_callback: Callback for OpenLineage facets.
    """
    global _global_backend, _global_instrumentor, _global_agent_id

    _global_backend = backend
    _global_agent_id = agent_id or (backend.agent_id if backend else "")

    # Initialize AIGP OTel instrumentor
    try:
        from aigp.instrumentor import AIGPInstrumentor

        _global_instrumentor = AIGPInstrumentor(
            agent_id=_global_agent_id,
            agent_name=agent_name,
            org_id=org_id,
            org_name=org_name,
            event_callback=event_callback,
            openlineage_callback=openlineage_callback,
        )
    except Exception as exc:
        logger.debug("AIGP OTel instrumentor not available: %s", exc)
        _global_instrumentor = None


def get_backend() -> Optional[GovernanceBackend]:
    """Get the configured governance backend."""
    return _global_backend


def get_instrumentor() -> Optional[Any]:
    """Get the AIGP OTel instrumentor (None if not initialized)."""
    return _global_instrumentor


# =========================================================================
# Helpers
# =========================================================================


def _to_list(val: Any) -> list[str]:
    """Normalize a single string, list of strings, or None to a list."""
    if val is None:
        return []
    if isinstance(val, str):
        return [val]
    return list(val)


def _hash_value(val: Any) -> str:
    """SHA-256 hash of a value (string, bytes, or JSON-serializable)."""
    if isinstance(val, str):
        return hashlib.sha256(val.encode("utf-8")).hexdigest()
    if isinstance(val, bytes):
        return hashlib.sha256(val).hexdigest()
    return hashlib.sha256(
        json.dumps(val, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()


def _serialize_args(args: tuple, kwargs: dict) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if args:
        result["positional"] = [_safe_repr(a) for a in args]
    if kwargs:
        result["keyword"] = {k: _safe_repr(v) for k, v in kwargs.items()}
    return result


def _safe_repr(obj: Any, max_length: int = 200) -> str:
    try:
        s = repr(obj)
        return s[:max_length - 3] + "..." if len(s) > max_length else s
    except Exception:
        return f"<{type(obj).__name__}>"


def _emit_otel_event(method_name: str, **kwargs: Any) -> None:
    """Emit an AIGP OTel event if instrumentor is available."""
    if _global_instrumentor is not None:
        try:
            method = getattr(_global_instrumentor, method_name, None)
            if method:
                method(**kwargs)
        except Exception:
            pass


# =========================================================================
# @aigp — Full AI Governance pipeline
# =========================================================================


def aigp(
    policy: Optional[Any] = None,
    *,
    policies: Optional[dict[str, dict[str, Any]]] = None,
    prompt: Optional[Any] = None,
    tool: Optional[Any] = None,
    deny_raises: bool = False,
) -> Callable[[F], F]:
    """
    AI Governance decorator — full governance lifecycle.

    Orchestrates: fetch policies/prompts/tools from the configured backend,
    receive enforcement decision + Merkle proof, emit AIGP events. Supports
    multiple resources atomically.

    The ``GovernanceResult`` is injected as the ``governance`` keyword argument.

    Args:
        policy: Policy SRN(s). Single string or list of SRNs.
        policies: Per-policy variable dicts (merged with ``policy``).
        prompt: Prompt SRN(s). Single string or list of SRNs.
        tool: Tool SRN(s). Single string or list of SRNs.
        deny_raises: If True, raise GovernanceError on denial.
    """

    def decorator(func: F) -> F:
        is_async = asyncio.iscoroutinefunction(func)

        # Normalize resource lists at decoration time
        _policy_list: list[str] = _to_list(policy)
        _prompt_list: list[str] = _to_list(prompt)
        _tool_list: list[str] = _to_list(tool)

        def _do_inject(
            extra_vars: Optional[dict[str, Any]] = None,
            tool_input: Optional[dict[str, Any]] = None,
        ) -> GovernanceResult:
            backend = _global_backend

            if backend is None:
                logger.warning(
                    "AIGP governance backend not configured — allowing action "
                    "without enforcement. Call aigp.configure(backend=...) first.",
                )
                return GovernanceResult.error_fallback()

            # Build policies dict: merge policy list + policies dict + extra_vars
            pv: dict[str, dict[str, Any]] = dict(policies or {})
            for p in _policy_list:
                if p not in pv:
                    pv[p] = {}
            if extra_vars:
                for key in pv:
                    pv[key] = {**pv[key], **extra_vars}

            try:
                resp = backend.inject_governance(
                    policies=pv or None,
                    prompts=_prompt_list or None,
                    tools=_tool_list or None,
                    tool_input=tool_input,
                )
                gov_result = GovernanceResult.from_backend_response(resp)

                # Emit AIGP OTel events
                if gov_result.allowed:
                    for p in _policy_list:
                        _emit_otel_event(
                            "inject_success",
                            policy_name=p,
                            policy_version=0,
                            content=gov_result.merkle_root or "",
                        )
                else:
                    for p in _policy_list:
                        _emit_otel_event(
                            "inject_denied",
                            policy_name=p,
                            denial_reason=gov_result.denial_reason or "denied",
                        )

                for t in _tool_list:
                    if gov_result.is_tool_allowed(t):
                        _emit_otel_event("tool_invoked", tool_name=t)
                    else:
                        tool_info = gov_result.get_tool(t) or {}
                        _emit_otel_event(
                            "tool_denied",
                            tool_name=t,
                            denial_reason=tool_info.get("message", "denied"),
                        )

            except Exception as exc:
                logger.warning(
                    "AIGP governance backend unavailable — allowing action "
                    "without enforcement. Error: %s", exc,
                )
                gov_result = GovernanceResult.error_fallback()

            return gov_result

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            extra_vars = kwargs.pop("governance_vars", None)
            tool_input = kwargs.pop("tool_input", None)
            result = _do_inject(extra_vars, tool_input)
            if deny_raises and result.denied:
                raise GovernanceError(
                    f"Governance denied: {result.denial_reason}",
                    result=result,
                )
            kwargs["governance"] = result
            return await func(*args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            extra_vars = kwargs.pop("governance_vars", None)
            tool_input = kwargs.pop("tool_input", None)
            result = _do_inject(extra_vars, tool_input)
            if deny_raises and result.denied:
                raise GovernanceError(
                    f"Governance denied: {result.denial_reason}",
                    result=result,
                )
            kwargs["governance"] = result
            return func(*args, **kwargs)

        return async_wrapper if is_async else sync_wrapper  # type: ignore

    return decorator


# =========================================================================
# @a2a_traced — Multi-Agent System sub-agent tracing
# =========================================================================


def a2a_traced(
    agent_id: Optional[str] = None,
    skill: Optional[str] = None,
    *,
    source_agent_id: Optional[str] = None,
) -> Callable[[F], F]:
    """Auto-emit A2A_CALL audit events for multi-agent sub-agent calls."""

    def decorator(func: F) -> F:
        is_async = asyncio.iscoroutinefunction(func)
        target = agent_id or f"agent.{func.__name__}"
        skill_name = skill or func.__name__

        def _log_a2a(input_val: Any, result: Any, success: bool, elapsed_ms: int) -> None:
            try:
                backend = _global_backend
                if backend is None:
                    return
                source = source_agent_id or _global_agent_id or "unknown"
                backend.log_activity(
                    agent_id=target,
                    trace_id=backend.get_trace_id(),
                    inputs={"input_hash": _hash_value(input_val), "skill": skill_name},
                    outputs={
                        "output_hash": _hash_value(result) if result is not None else "",
                        "success": success,
                    },
                    skill=skill_name,
                    success=success,
                    response_time_ms=elapsed_ms,
                )
                _emit_otel_event(
                    "a2a_call",
                    request_method="A2A",
                    request_path=f"agent://{target}/{skill_name}",
                    content=_hash_value(input_val),
                )
            except Exception:
                pass

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            input_val = args[0] if args else kwargs
            t0 = time.monotonic()
            try:
                result = await func(*args, **kwargs)
                elapsed = int((time.monotonic() - t0) * 1000)
                _log_a2a(input_val, result, True, elapsed)
                return result
            except Exception as e:
                elapsed = int((time.monotonic() - t0) * 1000)
                _log_a2a(input_val, {"error": str(e)}, False, elapsed)
                raise

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            input_val = args[0] if args else kwargs
            t0 = time.monotonic()
            try:
                result = func(*args, **kwargs)
                elapsed = int((time.monotonic() - t0) * 1000)
                _log_a2a(input_val, result, True, elapsed)
                return result
            except Exception as e:
                elapsed = int((time.monotonic() - t0) * 1000)
                _log_a2a(input_val, {"error": str(e)}, False, elapsed)
                raise

        return async_wrapper if is_async else sync_wrapper  # type: ignore

    return decorator


# =========================================================================
# @audit_action — Simple audit logging
# =========================================================================


def audit_action(
    event_type: str,
    *,
    resource_type: Optional[str] = None,
    include_args: bool = False,
    include_result: bool = False,
) -> Callable[[F], F]:
    """Decorator to automatically audit function calls."""

    def decorator(func: F) -> F:
        is_async = asyncio.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            backend = _global_backend
            t0 = time.monotonic()
            details: dict[str, Any] = {"function": func.__name__}
            if resource_type:
                details["resource_type"] = resource_type
            if include_args:
                details["args"] = _serialize_args(args, kwargs)
            try:
                result = await func(*args, **kwargs)
                details["duration_ms"] = int((time.monotonic() - t0) * 1000)
                details["success"] = True
                if include_result:
                    details["result"] = _safe_repr(result)
                if backend:
                    backend.audit(event_type, details=details)
                return result
            except Exception as e:
                details["success"] = False
                details["error"] = str(e)
                if backend:
                    backend.audit(event_type, details=details)
                raise

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            backend = _global_backend
            t0 = time.monotonic()
            details: dict[str, Any] = {"function": func.__name__}
            if resource_type:
                details["resource_type"] = resource_type
            if include_args:
                details["args"] = _serialize_args(args, kwargs)
            try:
                result = func(*args, **kwargs)
                details["duration_ms"] = int((time.monotonic() - t0) * 1000)
                details["success"] = True
                if include_result:
                    details["result"] = _safe_repr(result)
                if backend:
                    backend.audit(event_type, details=details)
                return result
            except Exception as e:
                details["success"] = False
                details["error"] = str(e)
                if backend:
                    backend.audit(event_type, details=details)
                raise

        return async_wrapper if is_async else sync_wrapper  # type: ignore

    return decorator


# =========================================================================
# GovernedActionContext + aigp_action() context manager
# =========================================================================


class GovernedActionContext:
    """Context returned by aigp_action(). Provides governance result."""

    def __init__(self, result: GovernanceResult):
        self.result = result
        self._action_result: Any = None

    @property
    def allowed(self) -> bool:
        return self.result.allowed

    @property
    def denied(self) -> bool:
        return self.result.denied

    @property
    def denial_reason(self) -> Optional[str]:
        return self.result.denial_reason

    @property
    def merkle_root(self) -> str:
        return self.result.merkle_root

    def get_rendered(self, policy_name: str) -> Optional[str]:
        return self.result.get_rendered(policy_name)

    def get_prompt(self, prompt_name: str) -> Optional[str]:
        return self.result.get_prompt(prompt_name)

    def get_tool(self, tool_name: str) -> Optional[dict]:
        return self.result.get_tool(tool_name)

    def is_tool_allowed(self, tool_name: str) -> bool:
        return self.result.is_tool_allowed(tool_name)

    def set_result(self, result: Any) -> None:
        self._action_result = result


@contextlib.contextmanager
def aigp_action(
    policy: Optional[Any] = None,
    *,
    policies: Optional[dict[str, dict[str, Any]]] = None,
    prompt: Optional[Any] = None,
    tool: Optional[Any] = None,
    tool_input: Optional[dict[str, Any]] = None,
) -> Generator[GovernedActionContext, None, None]:
    """Context manager for inline AI Governance (same pipeline as @aigp)."""
    backend = _global_backend

    _policy_list = _to_list(policy)
    _prompt_list = _to_list(prompt)
    _tool_list = _to_list(tool)

    # Build policies dict
    pv: dict[str, dict[str, Any]] = dict(policies or {})
    for p in _policy_list:
        if p not in pv:
            pv[p] = {}

    if backend is None:
        logger.warning(
            "AIGP governance backend not configured — allowing action "
            "without enforcement. Call aigp.configure(backend=...) first.",
        )
        gov_result = GovernanceResult.error_fallback()
    else:
        try:
            resp = backend.inject_governance(
                policies=pv or None,
                prompts=_prompt_list or None,
                tools=_tool_list or None,
                tool_input=tool_input,
            )
            gov_result = GovernanceResult.from_backend_response(resp)
        except Exception as exc:
            logger.warning(
                "AIGP governance backend unavailable — allowing action "
                "without enforcement. Error: %s", exc,
            )
            gov_result = GovernanceResult.error_fallback()

    ctx = GovernedActionContext(gov_result)
    t0 = time.monotonic()

    try:
        yield ctx
    except Exception as e:
        elapsed = int((time.monotonic() - t0) * 1000)
        if backend:
            try:
                backend.audit(
                    "governed_action_error",
                    details={
                        "policies": _policy_list,
                        "prompts": _prompt_list,
                        "tools": _tool_list,
                        "error": str(e),
                        "duration_ms": elapsed,
                        "allowed": gov_result.allowed,
                    },
                )
            except Exception:
                pass
        raise
    else:
        elapsed = int((time.monotonic() - t0) * 1000)
        if backend:
            try:
                backend.audit(
                    "governed_action_complete",
                    details={
                        "policies": _policy_list,
                        "prompts": _prompt_list,
                        "tools": _tool_list,
                        "allowed": gov_result.allowed,
                        "merkle_root": gov_result.merkle_root,
                        "duration_ms": elapsed,
                    },
                )
            except Exception:
                pass
