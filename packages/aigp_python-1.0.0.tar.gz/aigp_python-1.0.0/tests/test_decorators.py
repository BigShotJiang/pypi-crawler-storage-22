"""
Tests for aigp.decorators — the vendor-neutral AI Governance decorator framework.
"""

import pytest
from aigp.decorators import (
    GovernanceBackend,
    GovernanceResult,
    GovernanceError,
    GovernedActionContext,
    configure,
    aigp,
    aigp_action,
    a2a_traced,
    audit_action,
    get_backend,
    get_instrumentor,
)


# ── Fixtures ─────────────────────────────────────────────────────────


class MockBackend(GovernanceBackend):
    """A mock GovernanceBackend for testing."""

    def __init__(self, *, allowed=True, denial_reason=None, merkle_root="mock-merkle"):
        self._allowed = allowed
        self._denial_reason = denial_reason
        self._merkle_root = merkle_root
        self._inject_calls = []
        self._audit_calls = []
        self._activity_calls = []
        self._agent_id = "agent.test-bot"

    @property
    def agent_id(self) -> str:
        return self._agent_id

    def inject_governance(self, *, policies=None, prompts=None, tools=None, tool_input=None, trace_id=None):
        self._inject_calls.append({
            "policies": policies,
            "prompts": prompts,
            "tools": tools,
            "tool_input": tool_input,
        })
        resp = {
            "allowed": self._allowed,
            "denial_reason": self._denial_reason,
            "merkle_root": self._merkle_root,
            "policies": {},
            "prompts": {},
            "tools": {},
        }
        if policies:
            for name in policies:
                resp["policies"][name] = {"content": f"rendered-{name}"}
        if prompts:
            for name in prompts:
                resp["prompts"][name] = {"content": f"prompt-{name}"}
        return resp

    def log_activity(self, *, agent_id, trace_id, inputs, outputs, skill, success=True, response_time_ms=0):
        self._activity_calls.append({
            "agent_id": agent_id,
            "skill": skill,
            "success": success,
        })

    def audit(self, event_type, *, resource_type=None, details=None):
        self._audit_calls.append({
            "event_type": event_type,
            "resource_type": resource_type,
            "details": details,
        })


@pytest.fixture(autouse=True)
def reset_globals():
    """Reset global state between tests."""
    import aigp.decorators as dec
    dec._global_backend = None
    dec._global_instrumentor = None
    dec._global_agent_id = ""
    yield
    dec._global_backend = None
    dec._global_instrumentor = None
    dec._global_agent_id = ""


# ── Test: imports ────────────────────────────────────────────────────


class TestImports:
    def test_import_from_aigp(self):
        from aigp import configure, aigp, GovernanceResult
        assert callable(configure)
        assert callable(aigp)
        assert GovernanceResult is not None

    def test_import_governance_error(self):
        from aigp import GovernanceError
        assert issubclass(GovernanceError, Exception)

    def test_import_governance_backend(self):
        from aigp import GovernanceBackend
        assert GovernanceBackend is not None

    def test_version(self):
        import aigp
        assert aigp.__version__ == "1.0.0"


# ── Test: GovernanceResult ───────────────────────────────────────────


class TestGovernanceResult:
    def test_default_allowed(self):
        r = GovernanceResult()
        assert r.allowed is True
        assert r.denied is False
        assert r.denial_reason is None

    def test_denied(self):
        r = GovernanceResult(allowed=False, denial_reason="over limit")
        assert r.denied is True
        assert r.allowed is False
        assert r.denial_reason == "over limit"

    def test_get_rendered(self):
        r = GovernanceResult(policies={"policy.x": {"content": "hello"}})
        assert r.get_rendered("policy.x") == "hello"
        assert r.get_rendered("policy.missing") is None

    def test_get_prompt(self):
        r = GovernanceResult(prompts={"prompt.x": {"content": "hi"}})
        assert r.get_prompt("prompt.x") == "hi"
        assert r.get_prompt("prompt.missing") is None

    def test_is_tool_allowed_true(self):
        r = GovernanceResult(tools={"tool.x": {"allowed": True}})
        assert r.is_tool_allowed("tool.x") is True

    def test_is_tool_allowed_false(self):
        r = GovernanceResult(tools={"tool.x": {"allowed": False}})
        assert r.is_tool_allowed("tool.x") is False

    def test_is_tool_allowed_missing(self):
        r = GovernanceResult()
        assert r.is_tool_allowed("tool.missing") is True

    def test_from_backend_response(self):
        resp = {
            "allowed": True,
            "denial_reason": None,
            "merkle_root": "abc123",
            "policies": {"p": {"content": "x"}},
            "prompts": {},
            "tools": {},
        }
        r = GovernanceResult.from_backend_response(resp)
        assert r.allowed is True
        assert r.merkle_root == "abc123"
        assert r.get_rendered("p") == "x"

    def test_error_fallback(self):
        r = GovernanceResult.error_fallback()
        assert r.allowed is True
        assert r.denied is False
        assert "_aigp_error" in r.raw_response


# ── Test: GovernanceError ────────────────────────────────────────────


class TestGovernanceError:
    def test_basic(self):
        r = GovernanceResult(allowed=False)
        err = GovernanceError("denied", result=r)
        assert str(err) == "denied"
        assert err.result is r

    def test_no_result(self):
        err = GovernanceError("oops")
        assert err.result is None


# ── Test: configure ──────────────────────────────────────────────────


class TestConfigure:
    def test_configure_with_backend(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")
        assert get_backend() is backend

    def test_configure_without_backend(self):
        configure(agent_id="agent.test")
        assert get_backend() is None

    def test_agent_id_from_backend(self):
        import aigp.decorators as dec
        backend = MockBackend()
        configure(backend=backend)
        assert dec._global_agent_id == "agent.test-bot"


# ── Test: @aigp decorator ───────────────────────────────────────────


class TestAigpDecorator:
    def test_allowed(self):
        backend = MockBackend(allowed=True, merkle_root="root-123")
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits")
        def my_func(order, governance=None):
            return {"allowed": governance.allowed, "root": governance.merkle_root}

        result = my_func({"amount": 100})
        assert result["allowed"] is True
        assert result["root"] == "root-123"

    def test_denied(self):
        backend = MockBackend(allowed=False, denial_reason="over limit")
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits")
        def my_func(order, governance=None):
            return {"denied": governance.denied, "reason": governance.denial_reason}

        result = my_func({"amount": 999999})
        assert result["denied"] is True
        assert result["reason"] == "over limit"

    def test_deny_raises(self):
        backend = MockBackend(allowed=False, denial_reason="blocked")
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits", deny_raises=True)
        def my_func(order, governance=None):
            return "should not reach"

        with pytest.raises(GovernanceError) as exc_info:
            my_func({"amount": 999999})
        assert "blocked" in str(exc_info.value)
        assert exc_info.value.result is not None
        assert exc_info.value.result.denied is True

    def test_no_backend_allows(self):
        """No backend configured = fail-open with warning."""
        configure(agent_id="agent.test")

        @aigp(policy="policy.limits")
        def my_func(order, governance=None):
            return governance.allowed

        result = my_func({"x": 1})
        assert result is True

    def test_multiple_policies(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy=["policy.a", "policy.b"])
        def my_func(order, governance=None):
            return governance

        result = my_func({})
        assert result.allowed is True
        assert len(backend._inject_calls) == 1
        call = backend._inject_calls[0]
        assert "policy.a" in call["policies"]
        assert "policy.b" in call["policies"]

    def test_governance_vars(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits")
        def my_func(order, governance=None):
            return governance.allowed

        my_func({"x": 1}, governance_vars={"max_amount": 5000})
        call = backend._inject_calls[0]
        assert call["policies"]["policy.limits"]["max_amount"] == 5000

    def test_with_prompt(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits", prompt="prompt.instructions")
        def my_func(order, governance=None):
            return governance.get_prompt("prompt.instructions")

        result = my_func({})
        assert result == "prompt-prompt.instructions"

    def test_with_tool(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits", tool="tool.stripe-api")
        def my_func(order, governance=None):
            return governance

        result = my_func({})
        call = backend._inject_calls[0]
        assert call["tools"] == ["tool.stripe-api"]

    def test_backend_error_fail_open(self):
        """Backend that throws = fail-open with warning."""

        class BrokenBackend(GovernanceBackend):
            def inject_governance(self, **kwargs):
                raise ConnectionError("cannot reach server")

        configure(backend=BrokenBackend(), agent_id="agent.test")

        @aigp(policy="policy.limits")
        def my_func(order, governance=None):
            return governance.allowed

        result = my_func({})
        assert result is True


# ── Test: @aigp async ────────────────────────────────────────────────


class TestAigpAsync:
    @pytest.mark.asyncio
    async def test_async_allowed(self):
        backend = MockBackend(allowed=True)
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits")
        async def my_func(order, governance=None):
            return governance.allowed

        result = await my_func({"x": 1})
        assert result is True

    @pytest.mark.asyncio
    async def test_async_deny_raises(self):
        backend = MockBackend(allowed=False, denial_reason="nope")
        configure(backend=backend, agent_id="agent.test")

        @aigp(policy="policy.limits", deny_raises=True)
        async def my_func(order, governance=None):
            return "unreachable"

        with pytest.raises(GovernanceError):
            await my_func({})


# ── Test: aigp_action context manager ────────────────────────────────


class TestAigpAction:
    def test_basic(self):
        backend = MockBackend(allowed=True, merkle_root="cm-root")
        configure(backend=backend, agent_id="agent.test")

        with aigp_action(policy="policy.limits") as gov:
            assert gov.allowed is True
            assert gov.merkle_root == "cm-root"

    def test_denied(self):
        backend = MockBackend(allowed=False, denial_reason="blocked")
        configure(backend=backend, agent_id="agent.test")

        with aigp_action(policy="policy.limits") as gov:
            assert gov.denied is True
            assert gov.denial_reason == "blocked"

    def test_no_backend_allows(self):
        configure(agent_id="agent.test")

        with aigp_action(policy="policy.limits") as gov:
            assert gov.allowed is True

    def test_audits_on_completion(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        with aigp_action(policy="policy.limits") as gov:
            pass

        assert len(backend._audit_calls) == 1
        assert backend._audit_calls[0]["event_type"] == "governed_action_complete"

    def test_audits_on_error(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        with pytest.raises(ValueError):
            with aigp_action(policy="policy.limits") as gov:
                raise ValueError("boom")

        assert len(backend._audit_calls) == 1
        assert backend._audit_calls[0]["event_type"] == "governed_action_error"


# ── Test: @a2a_traced ────────────────────────────────────────────────


class TestA2aTraced:
    def test_logs_activity(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @a2a_traced(agent_id="agent.sentiment", skill="analyze")
        def run_sentiment(text):
            return {"score": 0.95}

        result = run_sentiment("great product!")
        assert result == {"score": 0.95}
        assert len(backend._activity_calls) == 1
        assert backend._activity_calls[0]["agent_id"] == "agent.sentiment"
        assert backend._activity_calls[0]["skill"] == "analyze"
        assert backend._activity_calls[0]["success"] is True

    def test_logs_on_error(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @a2a_traced(agent_id="agent.bad", skill="fail")
        def bad_func(text):
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError):
            bad_func("input")

        assert len(backend._activity_calls) == 1
        assert backend._activity_calls[0]["success"] is False

    def test_no_backend_no_crash(self):
        configure(agent_id="agent.test")

        @a2a_traced(agent_id="agent.other", skill="do_thing")
        def my_func(x):
            return x + 1

        assert my_func(1) == 2


# ── Test: @audit_action ──────────────────────────────────────────────


class TestAuditAction:
    def test_basic(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @audit_action("data_access", resource_type="database")
        def fetch_data(user_id):
            return {"id": user_id}

        result = fetch_data("user-123")
        assert result == {"id": "user-123"}
        assert len(backend._audit_calls) == 1
        assert backend._audit_calls[0]["event_type"] == "data_access"
        details = backend._audit_calls[0]["details"]
        assert details["function"] == "fetch_data"
        assert details["success"] is True
        assert details["resource_type"] == "database"

    def test_includes_args(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @audit_action("data_access", include_args=True)
        def fetch_data(user_id):
            return {"id": user_id}

        fetch_data("user-123")
        details = backend._audit_calls[0]["details"]
        assert "args" in details

    def test_includes_result(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @audit_action("data_access", include_result=True)
        def fetch_data(user_id):
            return {"id": user_id}

        fetch_data("user-123")
        details = backend._audit_calls[0]["details"]
        assert "result" in details

    def test_logs_error(self):
        backend = MockBackend()
        configure(backend=backend, agent_id="agent.test")

        @audit_action("data_access")
        def bad_func():
            raise ValueError("boom")

        with pytest.raises(ValueError):
            bad_func()

        assert len(backend._audit_calls) == 1
        details = backend._audit_calls[0]["details"]
        assert details["success"] is False
        assert details["error"] == "boom"

    def test_no_backend_no_crash(self):
        configure(agent_id="agent.test")

        @audit_action("data_access")
        def my_func():
            return 42

        assert my_func() == 42


# ── Test: GovernedActionContext ───────────────────────────────────────


class TestGovernedActionContext:
    def test_properties(self):
        r = GovernanceResult(
            allowed=True,
            merkle_root="abc",
            policies={"p": {"content": "x"}},
            prompts={"q": {"content": "y"}},
            tools={"t": {"allowed": True}},
        )
        ctx = GovernedActionContext(r)
        assert ctx.allowed is True
        assert ctx.denied is False
        assert ctx.merkle_root == "abc"
        assert ctx.get_rendered("p") == "x"
        assert ctx.get_prompt("q") == "y"
        assert ctx.is_tool_allowed("t") is True

    def test_set_result(self):
        ctx = GovernedActionContext(GovernanceResult())
        ctx.set_result({"output": "data"})
        assert ctx._action_result == {"output": "data"}
