//
// Created by marcel on 03.09.25.
//

#include "aigverse/types.hpp"

#include <fmt/format.h>
#include <mockturtle/algorithms/balancing.hpp>
#include <mockturtle/algorithms/balancing/esop_balancing.hpp>
#include <mockturtle/algorithms/balancing/sop_balancing.hpp>
#include <pybind11/cast.h>
#include <pybind11/pybind11.h>

#include <cstdint>
#include <stdexcept>
#include <string_view>

namespace aigverse
{

namespace detail
{

template <typename Ntk>
void balancing(pybind11::module_& m)  // NOLINT(misc-use-internal-linkage)
{
    namespace py = pybind11;  // NOLINT(misc-unused-alias-decls)

    m.def(
        "balancing",
        [](Ntk& ntk, const uint32_t cut_size = 4, const uint32_t cut_limit = 8, const bool minimize_truth_table = true,
           const bool only_on_critical_path = false, const std::string_view& rebalance_function = "sop",
           const bool sop_both_phases = true, const bool verbose = false) -> void
        {
            mockturtle::balancing_params ps{};
            ps.cut_enumeration_ps.cut_size             = cut_size;
            ps.cut_enumeration_ps.cut_limit            = cut_limit;
            ps.cut_enumeration_ps.minimize_truth_table = minimize_truth_table;
            ps.only_on_critical_path                   = only_on_critical_path;
            ps.verbose                                 = verbose;

            if (rebalance_function == "sop")
            {
                mockturtle::sop_rebalancing<Ntk> rebalance_fn{};
                rebalance_fn.both_phases_ = sop_both_phases;

                ntk = mockturtle::balancing(ntk, {rebalance_fn}, ps);
            }
            else if (rebalance_function == "esop")
            {
                mockturtle::esop_rebalancing<Ntk> rebalance_fn{};
                rebalance_fn.both_phases = sop_both_phases;

                ntk = mockturtle::balancing(ntk, {rebalance_fn}, ps);
            }
            else
            {
                throw std::invalid_argument(fmt::format(
                    "Unknown rebalance function: '{}'. Possible values are 'sop' and 'esop'.", rebalance_function));
            }
        },
        py::arg("ntk"), py::arg("cut_size") = 4, py::arg("cut_limit") = 8, py::arg("minimize_truth_table") = true,
        py::arg("only_on_critical_path") = false, py::arg("rebalance_function") = "sop",
        py::arg("sop_both_phases") = true, py::arg("verbose") = false,
        pybind11::call_guard<pybind11::gil_scoped_release>());  // NOLINT(misc-include-cleaner)
}

// Explicit instantiation for AIG
template void balancing<aigverse::aig>(pybind11::module_& m);

}  // namespace detail

void bind_balancing(pybind11::module_& m)  // NOLINT(misc-use-internal-linkage)
{
    detail::balancing<aigverse::aig>(m);
}

}  // namespace aigverse
