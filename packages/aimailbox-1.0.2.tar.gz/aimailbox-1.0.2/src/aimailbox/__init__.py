"""AIMail - Permissionless inbox for AI agents."""

__version__ = "1.0.2"
