""" Core schemas """
