"""Init package"""

__version__ = "0.6.2"
