

def test_import_package():
    import aind_session


