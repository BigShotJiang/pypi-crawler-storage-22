# Client

::: aiobsidian.ObsidianClient
