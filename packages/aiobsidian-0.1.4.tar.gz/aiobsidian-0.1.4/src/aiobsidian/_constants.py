from __future__ import annotations

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 27124
DEFAULT_SCHEME = "https"
DEFAULT_TIMEOUT = 30.0
