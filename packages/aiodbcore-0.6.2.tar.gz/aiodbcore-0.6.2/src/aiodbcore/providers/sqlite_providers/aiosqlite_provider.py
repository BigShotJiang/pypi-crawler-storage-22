import asyncio
import re
import typing as ty

from ...exceptions import UniqueRequiredError

try:
    import aiosqlite
except ModuleNotFoundError as err:
    raise RuntimeError(
        "You should install `aiosqlite` backend to connect to this db. "
        "Use `pip install aiosqlite`"
    ) from err

from ..base_async import AsyncConnectionWrapper, BaseAsyncProvider


class AiosqliteProvider(BaseAsyncProvider[aiosqlite.Connection]):
    def __init__(self, db_path, **connection_kwargs) -> None:
        super().__init__(db_path, **connection_kwargs)
        self.connection = None
        self._lock = asyncio.Lock()

    async def create_connection(self) -> None:
        if not self.connection:
            self.connection = await aiosqlite.connect(
                self.db_path, isolation_level=None, **self.connection_kwargs
            )

    async def close_connection(self) -> None:
        if self.connection:
            await self.connection.close()
            self.connection = None

    def ensure_connection(self) -> AsyncConnectionWrapper[aiosqlite.Connection]:
        return AsyncConnectionWrapper(self, self._lock)

    async def _execute(self, query, args=()):
        async with self.ensure_connection() as connection:
            return await connection.execute(query, args)

    async def executescript(self, query):
        async with self.ensure_connection() as connection:
            return await connection.executescript(query)

    async def _fetchone(self, query, args=()) -> tuple[ty.Any, ...] | None:
        if rows := await self._fetchall(query, args):
            return rows[0]

    async def _fetchall(self, query, args=()) -> list[tuple[ty.Any, ...]]:
        async with self.ensure_connection() as connection:
            return list(await connection.execute_fetchall(query, args))

    @staticmethod
    def modify_db_path(db_path: str) -> str:
        return re.sub(r"sqlite(\+aiosqlite)?://", "", db_path)

    def _translate_exception(self, exception, query, params):
        if isinstance(exception, aiosqlite.IntegrityError):
            if exception.sqlite_errorname == "SQLITE_CONSTRAINT_UNIQUE":
                text = exception.args[0]
                return UniqueRequiredError(
                    query,
                    params,
                    exception,
                    field_name=text[text.rfind(": ") + 2 :],
                )
        return super()._translate_exception(exception, query, params)
