"""Tests for aioghost."""
