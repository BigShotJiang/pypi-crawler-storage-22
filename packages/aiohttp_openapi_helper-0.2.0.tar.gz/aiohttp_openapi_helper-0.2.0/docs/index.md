# aiohttp-openapi-helper Documentation

## Overview

`aiohttp-openapi-helper` is a lightweight library that brings OpenAPI 3.0 support to aiohttp applications. It simplifies API development by providing decorator-based route definitions, automatic specification generation, and built-in request/response validation.

## Key Features

### 1. Decorator-Based Routes

Define your API endpoints with decorators that include OpenAPI meta

```python
@openapi_route(
    app,
    "/users/{user_id}",
    method="GET",
    summary="Get user by ID",
    parameters=[
        {"name": "user_id", "in": "path", "required": True, "schema": {"type": "integer"}}
    ],
    responses={
        "200": {
            "description": "Successful response",
            "content": {
                "application/json": {
                    "schema": {"type": "object", "properties": {"id": {"type": "integer"}}}
                }
            }
        }
    }
)
async def get_user(request):
    user_id = int(request.match_info["user_id"])
    return web.json_response({"id": user_id})
```

### 2. Automatic Spec Generatio

Generate OpenAPI 3.0 specification automatically from your route definitions:

```python
spec = generate_openapi_spec(
    title="My API",
    version="1.0.0",
    routes=app.router.routes()
)

# Serve the spec
app.router.add_get("/openapi.json", lambda r: web.json_response(spec))
```

### 3. Request Validation

Validate incoming requests against your OpenAPI schemas:

```python
# Add middleware to your app
app.middlewares.append(OpenAPIMiddleware().middleware)

# Requests are now automatically validated!
@openapi_route(
    app,
    "/users",
    method="POST",
    request_body={
        "required": True,
        "content": {
            "application/json": {
                "schema": {
                    "type": "object",
                    "required": ["name", "email"],
                    "properties": {
                        "name": {"type": "string"},
                        "email": {"type": "string", "format": "email"}
                    }
                }
            }
        }
    },
    responses={"201": {"description": "Created"}}
)
async def create_user(request):
    # No need to manually validate - it's done automatically!
    data = await request.json()
    return web.json_response({"id": 1, **data}, status=201)
```

## Installation

```bash
pip install aiohttp-openapi-helper
```