import functools
from typing import Callable, Dict, Any, List, Optional
from aiohttp import web


def openapi_route(
    app: web.Application,
    path: str,
    method: str,
    summary: Optional[str] = None,
    description: Optional[str] = None,
    tags: Optional[List[str]] = None,
    parameters: Optional[List[Dict[str, Any]]] = None,
    request_body: Optional[Dict[str, Any]] = None,
    responses: Optional[Dict[str, Any]] = None,
    security: Optional[List[Dict[str, Any]]] = None,
    deprecated: bool = False,
    operation_id: Optional[str] = None,
    **kwargs
) -> Callable:
    """
    Decorator to define OpenAPI-compliant routes with automatic spec generation.
    
    This decorator registers a route handler with the aiohttp application and
    stores OpenAPI metadata for automatic spec generation.
    
    Args:
        app: aiohttp Application instance
        path: Route path (e.g., "/users/{user_id}")
        method: HTTP method ("GET", "POST", "PUT", "DELETE", etc.)
        summary: Brief summary of the endpoint
        description: Detailed description of the endpoint
        tags: List of tags for grouping endpoints
        parameters: List of parameter specifications
        request_body: Request body schema (for POST/PUT/PATCH)
        responses: Response schemas keyed by status code
        security: Security requirements
        deprecated: Mark as deprecated
        operation_id: Unique identifier for the operation
        **kwargs: Additional OpenAPI operation parameters
    
    Returns:
        Decorated route handler function
    
    Example:
        >>> @openapi_route(
        ...     app,
        ...     "/users/{user_id}",
        ...     method="GET",
        ...     summary="Get user by ID",
        ...     parameters=[
        ...         {"name": "user_id", "in": "path", "required": True, "schema": {"type": "integer"}}
        ...     ],
        ...     responses={
        ...         "200": {"description": "Successful response"}
        ...     }
        ... )
        ... async def get_user(request):
        ...     user_id = request.match_info["user_id"]
        ...     return web.json_response({"id": user_id})
    """
    
    def decorator(handler: Callable) -> Callable:
        @functools.wraps(handler)
        async def wrapper(request: web.Request) -> web.Response:
            return await handler(request)
        
        # Store OpenAPI metadata on the wrapper function
        wrapper._openapi_metadata = {
            "path": path,
            "method": method.lower(),
            "summary": summary,
            "description": description,
            "tags": tags or [],
            "parameters": parameters or [],
            "request_body": request_body,
            "responses": responses or {},
            "security": security,
            "deprecated": deprecated,
            "operation_id": operation_id,
            **kwargs
        }
        
        # Register route with aiohttp
        app.router.add_route(method.upper(), path, wrapper)
        
        return wrapper
    
    return decorator


def get_route_metadata(handler: Callable) -> Optional[Dict[str, Any]]:
    """
    Extract OpenAPI metadata from a route handler.
    
    Args:
        handler: Route handler function
    
    Returns:
        OpenAPI metadata dictionary or None if not available
    """
    return getattr(handler, "_openapi_metadata", None)


def extract_routes_metadata(routes) -> Dict[str, Dict[str, Any]]:
    """
    Extract OpenAPI metadata from aiohttp routes collection.
    
    Args:
        routes: aiohttp routes collection
    
    Returns:
        Dictionary mapping paths to their methods and metadata
    """
    metadata = {}
    
    for route in routes:
        if not hasattr(route, "handler"):
            continue
        
        handler = route.handler
        # Unwrap nested handlers (e.g., from middleware)
        while hasattr(handler, "__wrapped__"):
            handler = handler.__wrapped__
        
        route_metadata = get_route_metadata(handler)
        if not route_meta
            continue
        
        path = route_metadata["path"]
        method = route_metadata["method"]
        
        if path not in meta
            metadata[path] = {}
        
        metadata[path][method] = route_metadata
    
    return metadata