"""
OpenAPI validation middleware for aiohttp
"""

import json
from typing import Callable, Dict, Any, Optional
from aiohttp import web
from jsonschema import validate, ValidationError


class OpenAPIMiddleware:
    """
    Middleware for validating requests and responses against OpenAPI specification.
    
    This middleware validates incoming requests and outgoing responses
    according to the OpenAPI specification defined via decorators.
    
    Args:
        validate_request: Enable request validation (default: True)
        validate_response: Enable response validation (default: False)
        raise_on_error: Raise exception on validation error, otherwise return 400 (default: True)
        log_errors: Log validation errors to console (default: False)
    
    Example:
        >>> app = web.Application()
        >>> middleware = OpenAPIMiddleware(
        ...     validate_request=True,
        ...     validate_response=False,
        ...     raise_on_error=True
        ... )
        >>> app.middlewares.append(middleware.middleware)
    """
    
    def __init__(
        self,
        validate_request: bool = True,
        validate_response: bool = False,
        raise_on_error: bool = True,
        log_errors: bool = False
    ):
        self.validate_request = validate_request
        self.validate_response = validate_response
        self.raise_on_error = raise_on_error
        self.log_errors = log_errors
        self._route_metadata_cache = {}
    
    @web.middleware
    async def middleware(
        self,
        request: web.Request,
        handler: Callable[[web.Request], web.Response]
    ) -> web.Response:
        """
        Middleware handler that validates requests and responses.
        
        Args:
            request: Incoming aiohttp request
            handler: Next handler in the middleware chain
        
        Returns:
            aiohttp response
        
        Raises:
            web.HTTPBadRequest: If request validation fails and raise_on_error is True
            web.HTTPInternalServerError: If response validation fails and raise_on_error is True
        """
        # Validate request if enabled
        if self.validate_request:
            try:
                await self._validate_request(request, handler)
            except ValidationError as e:
                error_msg = f"Request validation failed: {str(e)}"
                if self.log_errors:
                    print(f"[OpenAPI Validation] {error_msg}")
                if self.raise_on_error:
                    raise web.HTTPBadRequest(text=error_msg)
                return web.json_response(
                    {"error": "Validation failed", "details": str(e)},
                    status=400
                )
            except ValueError as e:
                error_msg = str(e)
                if self.log_errors:
                    print(f"[OpenAPI Validation] {error_msg}")
                if self.raise_on_error:
                    raise web.HTTPBadRequest(text=error_msg)
                return web.json_response(
                    {"error": "Validation failed", "details": str(e)},
                    status=400
                )
        
        # Process request and get response
        response = await handler(request)
        
        # Validate response if enabled
        if self.validate_response:
            try:
                await self._validate_response(request, response, handler)
            except ValidationError as e:
                error_msg = f"Response validation failed: {str(e)}"
                if self.log_errors:
                    print(f"[OpenAPI Validation] {error_msg}")
                if self.raise_on_error:
                    raise web.HTTPInternalServerError(text=error_msg)
        
        return response
    
    async def _validate_request(
        self,
        request: web.Request,
        handler: Callable
    ) -> None:
        """
        Validate incoming request against OpenAPI spec.
        
        Args:
            request: aiohttp request to validate
            handler: Route handler function
        
        Raises:
            ValidationError: If validation fails
            ValueError: If route metadata is not found
        """
        # Get route metadata
        metadata = self._get_route_metadata(handler)
        if not meta
            # No OpenAPI metadata, skip validation
            return
        
        errors = []
        
        # Validate path parameters
        path_errors = self._validate_path_parameters(request, metadata)
        if path_errors:
            errors.extend(path_errors)
        
        # Validate query parameters
        query_errors = self._validate_query_parameters(request, metadata)
        if query_errors:
            errors.extend(query_errors)
        
        # Validate headers
        header_errors = self._validate_headers(request, metadata)
        if header_errors:
            errors.extend(header_errors)
        
        # Validate request body
        if request.method in ["POST", "PUT", "PATCH"]:
            try:
                body_errors = await self._validate_request_body(request, metadata)
                if body_errors:
                    errors.extend(body_errors)
            except Exception as e:
                errors.append(f"Request body validation error: {str(e)}")
        
        if errors:
            raise ValueError("; ".join(errors))
    
    async def _validate_response(
        self,
        request: web.Request,
        response: web.Response,
        handler: Callable
    ) -> None:
        """
        Validate outgoing response against OpenAPI spec.
        
        Args:
            request: Original aiohttp request
            response: aiohttp response to validate
            handler: Route handler function
        
        Raises:
            ValidationError: If validation fails
        """
        # Get route metadata
        metadata = self._get_route_metadata(handler)
        if not meta
            return
        
        # Only validate JSON responses
        if not response.content_type.startswith("application/json"):
            return
        
        try:
            # Get response body
            body = await response.text()
            if not body:
                return
            
            data = json.loads(body)
            
            # Get response schema for this status code
            responses = metadata.get("responses", {})
            status_code = str(response.status)
            response_spec = responses.get(status_code) or responses.get("default")
            
            if not response_spec:
                return
            
            # Get schema from response spec
            content_spec = response_spec.get("content", {})
            json_spec = content_spec.get("application/json", {})
            schema = json_spec.get("schema")
            
            if not schema:
                return
            
            # Validate against schema
            validate(instance=data, schema=schema)
        
        except (json.JSONDecodeError, ValidationError) as e:
            raise ValidationError(f"Response validation failed: {str(e)}")
        except Exception as e:
            raise ValidationError(f"Response validation error: {str(e)}")
    
    def _validate_path_parameters(
        self,
        request: web.Request,
        meta Dict[str, Any]
    ) -> list:
        """
        Validate path parameters against OpenAPI spec.
        
        Args:
            request: aiohttp request
            meta Route OpenAPI metadata
        
        Returns:
            List of validation errors
        """
        errors = []
        parameters = metadata.get("parameters", [])
        
        path_params = [p for p in parameters if p.get("in") == "path"]
        
        for param in path_params:
            param_name = param["name"]
            required = param.get("required", True)
            
            if param_name not in request.match_info and required:
                errors.append(f"Missing required path parameter: {param_name}")
            elif param_name in request.match_info:
                # Validate parameter value if schema is provided
                schema = param.get("schema")
                if schema:
                    try:
                        value = request.match_info[param_name]
                        self._validate_parameter_value(value, schema, param_name)
                    except (ValueError, ValidationError) as e:
                        errors.append(f"Invalid value for path parameter '{param_name}': {str(e)}")
        
        return errors
    
    def _validate_query_parameters(
        self,
        request: web.Request,
        meta Dict[str, Any]
    ) -> list:
        """
        Validate query parameters against OpenAPI spec.
        
        Args:
            request: aiohttp request
            metadata: Route OpenAPI metadata
        
        Returns:
            List of validation errors
        """
        errors = []
        parameters = metadata.get("parameters", [])
        
        query_params = [p for p in parameters if p.get("in") == "query"]
        
        for param in query_params:
            param_name = param["name"]
            required = param.get("required", False)
            
            if required and param_name not in request.query:
                errors.append(f"Missing required query parameter: {param_name}")
            elif param_name in request.query:
                # Validate parameter value if schema is provided
                schema = param.get("schema")
                if schema:
                    try:
                        value = request.query[param_name]
                        self._validate_parameter_value(value, schema, param_name)
                    except (ValueError, ValidationError) as e:
                        errors.append(f"Invalid value for query parameter '{param_name}': {str(e)}")
        
        return errors
    
    def _validate_headers(
        self,
        request: web.Request,
        meta Dict[str, Any]
    ) -> list:
        """
        Validate headers against OpenAPI spec.
        
        Args:
            request: aiohttp request
            metadata: Route OpenAPI metadata
        
        Returns:
            List of validation errors
        """
        errors = []
        parameters = metadata.get("parameters", [])
        
        header_params = [p for p in parameters if p.get("in") == "header"]
        
        for param in header_params:
            param_name = param["name"]
            required = param.get("required", False)
            
            if required and param_name not in request.headers:
                errors.append(f"Missing required header: {param_name}")
            elif param_name in request.headers:
                # Validate header value if schema is provided
                schema = param.get("schema")
                if schema:
                    try:
                        value = request.headers[param_name]
                        self._validate_parameter_value(value, schema, param_name)
                    except (ValueError, ValidationError) as e:
                        errors.append(f"Invalid value for header '{param_name}': {str(e)}")
        
        return errors
    
    async def _validate_request_body(
        self,
        request: web.Request,
        metadata: Dict[str, Any]
    ) -> list:
        """
        Validate request body against OpenAPI spec.
        
        Args:
            request: aiohttp request
            meta Route OpenAPI metadata
        
        Returns:
            List of validation errors
        """
        errors = []
        
        request_body = metadata.get("request_body")
        if not request_body:
            return errors
        
        required = request_body.get("required", False)
        
        # Check if body is required but not provided
        if required:
            try:
                body = await request.text()
                if not body:
                    errors.append("Request body is required but not provided")
                    return errors
            except Exception:
                errors.append("Request body is required but not provided")
                return errors
        
        # Validate content type
        content = request_body.get("content", {})
        
        # Check if JSON content is expected
        json_content = content.get("application/json")
        if json_content:
            try:
                data = await request.json()
                schema = json_content.get("schema", {})
                
                if schema:
                    validate(instance=data, schema=schema)
            except json.JSONDecodeError:
                errors.append("Invalid JSON in request body")
            except ValidationError as e:
                errors.append(f"Request body validation failed: {str(e)}")
            except Exception as e:
                errors.append(f"Request body validation error: {str(e)}")
        
        return errors
    
    def _validate_parameter_value(
        self,
        value: str,
        schema: Dict[str, Any],
        param_name: str
    ) -> None:
        """
        Validate parameter value against schema.
        
        Args:
            value: Parameter value as string
            schema: OpenAPI schema
            param_name: Parameter name for error messages
        
        Raises:
            ValueError: If value cannot be converted
            ValidationError: If validation fails
        """
        # Convert value to appropriate type based on schema
        param_type = schema.get("type", "string")
        
        try:
            if param_type == "integer":
                converted_value = int(value)
            elif param_type == "number":
                converted_value = float(value)
            elif param_type == "boolean":
                converted_value = value.lower() in ["true", "1", "yes", "on"]
            else:
                converted_value = value
            
            # Validate against schema
            validate(instance=converted_value, schema=schema)
        except (ValueError, ValidationError):
            raise
        except Exception as e:
            raise ValueError(f"Invalid value: {str(e)}")
    
    def _get_route_metadata(self, handler: Callable) -> Optional[Dict[str, Any]]:
        """
        Get OpenAPI metadata for a route handler.
        
        Args:
            handler: Route handler function
        
        Returns:
            OpenAPI metadata dictionary or None
        """
        # Unwrap nested handlers
        original_handler = handler
        while hasattr(handler, "__wrapped__"):
            handler = handler.__wrapped__
        
        # Check cache first
        handler_id = id(original_handler)
        if handler_id in self._route_metadata_cache:
            return self._route_metadata_cache[handler_id]
        
        # Get metadata from handler
        metadata = getattr(handler, "_openapi_metadata", None)
        
        # Cache the result
        self._route_metadata_cache[handler_id] = metadata
        
        return metadata