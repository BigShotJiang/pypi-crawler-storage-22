"""
OpenAPI specification generation utilities
"""

import json
from typing import Dict, Any, List, Optional
from .decorators import extract_routes_metadata


def generate_openapi_spec(
    title: str,
    version: str,
    routes,
    description: Optional[str] = None,
    security_schemes: Optional[Dict[str, Any]] = None,
    servers: Optional[List[Dict[str, Any]]] = None,
    tags: Optional[List[Dict[str, Any]]] = None,
    contact: Optional[Dict[str, Any]] = None,
    license_info: Optional[Dict[str, Any]] = None,
    **kwargs
) -> Dict[str, Any]:
    """
    Generate OpenAPI 3.0 specification from registered routes.
    
    Args:
        title: API title
        version: API version
        routes: aiohttp routes collection
        description: API description
        security_schemes: Dictionary of security schemes
        servers: List of server objects
        tags: List of tag definitions
        contact: Contact information
        license_info: License information
        **kwargs: Additional OpenAPI info fields
    
    Returns:
        Dictionary containing OpenAPI 3.0 specification
    
    Example:
        >>> spec = generate_openapi_spec(
        ...     title="My API",
        ...     version="1.0.0",
        ...     description="My awesome API",
        ...     routes=app.router.routes(),
        ...     servers=[{"url": "https://api.example.com", "description": "Production"}],
        ...     tags=[
        ...         {"name": "users", "description": "User operations"},
        ...         {"name": "items", "description": "Item operations"}
        ...     ]
        ... )
    """
    # Extract route metadata
    routes_metadata = extract_routes_metadata(routes)
    
    # Build OpenAPI spec
    spec: Dict[str, Any] = {
        "openapi": "3.0.3",
        "info": {
            "title": title,
            "version": version,
        },
        "paths": {},
    }
    
    # Add optional info fields
    if description:
        spec["info"]["description"] = description
    if contact:
        spec["info"]["contact"] = contact
    if license_info:
        spec["info"]["license"] = license_info
    if kwargs:
        spec["info"].update(kwargs)
    
    # Add servers
    if servers:
        spec["servers"] = servers
    
    # Add security schemes
    if security_schemes:
        spec["components"] = {
            "securitySchemes": security_schemes
        }
    
    # Add tags
    if tags:
        spec["tags"] = tags
    
    # Build paths from route metadata
    for path, methods in routes_metadata.items():
        spec["paths"][path] = {}
        
        for method, metadata in methods.items():
            operation = {}
            
            # Add operation fields
            if metadata.get("summary"):
                operation["summary"] = metadata["summary"]
            if metadata.get("description"):
                operation["description"] = metadata["description"]
            if metadata.get("tags"):
                operation["tags"] = metadata["tags"]
            if metadata.get("parameters"):
                operation["parameters"] = metadata["parameters"]
            if metadata.get("request_body"):
                operation["requestBody"] = metadata["request_body"]
            if metadata.get("responses"):
                operation["responses"] = metadata["responses"]
            if metadata.get("security"):
                operation["security"] = metadata["security"]
            if metadata.get("deprecated") is not None:
                operation["deprecated"] = metadata["deprecated"]
            if metadata.get("operation_id"):
                operation["operationId"] = metadata["operation_id"]
            
            # Add any additional fields
            for key, value in metadata.items():
                if key not in [
                    "path", "method", "summary", "description", "tags",
                    "parameters", "request_body", "responses", "security",
                    "deprecated", "operation_id"
                ]:
                    operation[key] = value
            
            spec["paths"][path][method] = operation
    
    return spec


def security_scheme(
    type: str,
    name: Optional[str] = None,
    in_: Optional[str] = None,
    scheme: Optional[str] = None,
    bearer_format: Optional[str] = None,
    flows: Optional[Dict[str, Any]] = None,
    open_id_connect_url: Optional[str] = None,
    description: Optional[str] = None,
    **kwargs
) -> Dict[str, Any]:
    """
    Helper function to create security scheme definitions.
    
    Args:
        type: Security scheme type ("apiKey", "http", "oauth2", "openIdConnect")
        name: Header, query parameter, or cookie name (for apiKey type)
        in_: Location of the API key ("header", "query", or "cookie")
        scheme: HTTP scheme (e.g., "bearer", "basic")
        bearer_format: Bearer token format hint
        flows: OAuth2 flows configuration
        open_id_connect_url: OpenID Connect discovery URL
        description: Security scheme description
        **kwargs: Additional security scheme parameters
    
    Returns:
        Security scheme dictionary
    
    Examples:
        >>> # API Key in header
        >>> api_key_scheme = security_scheme(
        ...     type="apiKey",
        ...     name="X-API-Key",
        ...     in_="header",
        ...     description="API key authentication"
        ... )
        
        >>> # Bearer token
        >>> bearer_scheme = security_scheme(
        ...     type="http",
        ...     scheme="bearer",
        ...     bearer_format="JWT"
        ... )
        
        >>> # OAuth2
        >>> oauth2_scheme = security_scheme(
        ...     type="oauth2",
        ...     flows={
        ...         "authorizationCode": {
        ...             "authorizationUrl": "https://example.com/oauth/authorize",
        ...             "tokenUrl": "https://example.com/oauth/token",
        ...             "scopes": {
        ...                 "read": "Read access",
        ...                 "write": "Write access"
        ...             }
        ...         }
        ...     }
        ... )
    """
    scheme_dict: Dict[str, Any] = {"type": type}
    
    if description:
        scheme_dict["description"] = description
    
    if type == "apiKey":
        if not name:
            raise ValueError("name is required for apiKey type")
        if not in_:
            raise ValueError("in_ is required for apiKey type")
        scheme_dict["name"] = name
        scheme_dict["in"] = in_
    elif type == "http":
        if not scheme:
            raise ValueError("scheme is required for http type")
        scheme_dict["scheme"] = scheme
        if bearer_format:
            scheme_dict["bearerFormat"] = bearer_format
    elif type == "oauth2":
        if not flows:
            raise ValueError("flows is required for oauth2 type")
        scheme_dict["flows"] = flows
    elif type == "openIdConnect":
        if not open_id_connect_url:
            raise ValueError("open_id_connect_url is required for openIdConnect type")
        scheme_dict["openIdConnectUrl"] = open_id_connect_url
    
    if kwargs:
        scheme_dict.update(kwargs)
    
    return scheme_dict


def save_openapi_spec(
    spec: Dict[str, Any],
    filename: str,
    format: str = "json"
) -> None:
    """
    Save OpenAPI specification to a file.
    
    Args:
        spec: OpenAPI specification dictionary
        filename: Output filename
        format: Output format ("json" or "yaml")
    
    Raises:
        ValueError: If format is not supported
    """
    import yaml
    
    with open(filename, "w", encoding="utf-8") as f:
        if format == "json":
            json.dump(spec, f, indent=2)
        elif format == "yaml":
            yaml.dump(spec, f, default_flow_style=False, sort_keys=False)
        else:
            raise ValueError(f"Unsupported format: {format}")


def print_openapi_spec(spec: Dict[str, Any], format: str = "json") -> None:
    """
    Print OpenAPI specification to console.
    
    Args:
        spec: OpenAPI specification dictionary
        format: Output format ("json" or "yaml")
    """
    import yaml
    
    if format == "json":
        print(json.dumps(spec, indent=2))
    elif format == "yaml":
        print(yaml.dump(spec, default_flow_style=False, sort_keys=False))
    else:
        raise ValueError(f"Unsupported format: {format}")