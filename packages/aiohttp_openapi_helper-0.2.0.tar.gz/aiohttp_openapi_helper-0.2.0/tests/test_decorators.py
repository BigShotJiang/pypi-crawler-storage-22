"""
Tests for decorator functionality
"""

import pytest
from aiohttp import web
from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop

from aiohttp_openapi_helper import openapi_route, generate_openapi_spec


class TestOpenAPIRouteDecorator(AioHTTPTestCase):
    """Test cases for @openapi_route decorator"""

    async def get_application(self):
        """Create test application"""
        app = web.Application()
        
        # Define routes with decorator
        @openapi_route(
            app,
            "/users/{user_id}",
            method="GET",
            summary="Get user by ID",
            description="Retrieve user information",
            tags=["Users"],
            parameters=[
                {
                    "name": "user_id",
                    "in": "path",
                    "required": True,
                    "schema": {"type": "integer"}
                },
                {
                    "name": "include_details",
                    "in": "query",
                    "schema": {"type": "boolean"}
                }
            ],
            responses={
                "200": {
                    "description": "Successful response",
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "integer"},
                                    "name": {"type": "string"}
                                }
                            }
                        }
                    }
                }
            }
        )
        async def get_user(request):
            return web.json_response({"id": 1, "name": "Test User"})
        
        @openapi_route(
            app,
            "/users",
            method="POST",
            summary="Create user",
            request_body={
                "required": True,
                "content": {
                    "application/json": {
                        "schema": {
                            "type": "object",
                            "required": ["name"],
                            "properties": {
                                "name": {"type": "string"},
                                "email": {"type": "string"}
                            }
                        }
                    }
                }
            },
            responses={
                "201": {"description": "Created"}
            }
        )
        async def create_user(request):
            data = await request.json()
            return web.json_response({"id": 1, **data}, status=201)
        
        return app

    @unittest_run_loop
    async def test_route_registration(self):
        """Test that routes are properly registered"""
        # Test GET route
        resp = await self.client.request("GET", "/users/123")
        assert resp.status == 200
        data = await resp.json()
        assert "id" in data
        assert "name" in data
        
        # Test POST route
        resp = await self.client.request(
            "POST",
            "/users",
            json={"name": "New User", "email": "test@example.com"}
        )
        assert resp.status == 201
        data = await resp.json()
        assert data["name"] == "New User"

    @unittest_run_loop
    async def test_spec_generation(self):
        """Test OpenAPI spec generation"""
        spec = generate_openapi_spec(
            title="Test API",
            version="1.0.0",
            routes=self.app.router.routes()
        )
        
        # Check basic structure
        assert spec["openapi"] == "3.0.3"
        assert spec["info"]["title"] == "Test API"
        assert spec["info"]["version"] == "1.0.0"
        
        # Check paths
        assert "/users/{user_id}" in spec["paths"]
        assert "/users" in spec["paths"]
        
        # Check GET operation
        get_op = spec["paths"]["/users/{user_id}"]["get"]
        assert get_op["summary"] == "Get user by ID"
        assert get_op["description"] == "Retrieve user information"
        assert "Users" in get_op["tags"]
        
        # Check parameters
        assert len(get_op["parameters"]) == 2
        path_param = get_op["parameters"][0]
        assert path_param["name"] == "user_id"
        assert path_param["in"] == "path"
        assert path_param["required"] is True
        
        # Check POST operation
        post_op = spec["paths"]["/users"]["post"]
        assert post_op["summary"] == "Create user"
        assert "requestBody" in post_op
        assert post_op["requestBody"]["required"] is True


class TestDecoratorEdgeCases:
    """Test edge cases for decorator"""

    def test_decorator_without_app(self):
        """Test that decorator requires app parameter"""
        app = web.Application()
        
        with pytest.raises(TypeError):
            @openapi_route("/test", method="GET")  # Missing app
            async def handler(request):
                pass

    def test_decorator_with_invalid_method(self):
        """Test that decorator validates HTTP method"""
        app = web.Application()
        
        @openapi_route(app, "/test", method="INVALID")
        async def handler(request):
            return web.Response(text="OK")
        
        # Should still register route, but with invalid method
        routes = list(app.router.routes())
        assert len(routes) > 0

    def test_multiple_decorators_same_path(self):
        """Test multiple methods on same path"""
        app = web.Application()
        
        @openapi_route(app, "/items", method="GET")
        async def get_items(request):
            return web.json_response([])
        
        @openapi_route(app, "/items", method="POST")
        async def create_item(request):
            return web.json_response({}, status=201)
        
        # Both routes should be registered
        routes = list(app.router.routes())
        assert len(routes) >= 2


class TestSpecGeneration:
    """Test OpenAPI spec generation"""

    def test_empty_spec(self):
        """Test generating spec with no routes"""
        app = web.Application()
        
        spec = generate_openapi_spec(
            title="Empty API",
            version="1.0.0",
            routes=app.router.routes()
        )
        
        assert spec["openapi"] == "3.0.3"
        assert spec["info"]["title"] == "Empty API"
        assert spec["paths"] == {}

    def test_spec_with_servers(self):
        """Test spec generation with servers"""
        app = web.Application()
        
        @openapi_route(app, "/test", method="GET")
        async def handler(request):
            return web.Response(text="OK")
        
        spec = generate_openapi_spec(
            title="Test API",
            version="1.0.0",
            routes=app.router.routes(),
            servers=[
                {"url": "https://api.example.com", "description": "Production"},
                {"url": "https://dev.example.com", "description": "Development"}
            ]
        )
        
        assert "servers" in spec
        assert len(spec["servers"]) == 2
        assert spec["servers"][0]["url"] == "https://api.example.com"

    def test_spec_with_security_schemes(self):
        """Test spec generation with security schemes"""
        from aiohttp_openapi_helper import security_scheme
        
        app = web.Application()
        
        @openapi_route(
            app,
            "/protected",
            method="GET",
            security=[{"ApiKeyAuth": []}]
        )
        async def protected_handler(request):
            return web.Response(text="OK")
        
        api_key_scheme = security_scheme(
            type="apiKey",
            name="X-API-Key",
            in_="header"
        )
        
        spec = generate_openapi_spec(
            title="Secure API",
            version="1.0.0",
            routes=app.router.routes(),
            security_schemes={"ApiKeyAuth": api_key_scheme}
        )
        
        assert "components" in spec
        assert "securitySchemes" in spec["components"]
        assert "ApiKeyAuth" in spec["components"]["securitySchemes"]
        assert spec["components"]["securitySchemes"]["ApiKeyAuth"]["type"] == "apiKey"

    def test_spec_with_tags(self):
        """Test spec generation with tags"""
        app = web.Application()
        
        @openapi_route(app, "/users", method="GET", tags=["Users"])
        async def get_users(request):
            return web.json_response([])
        
        spec = generate_openapi_spec(
            title="Test API",
            version="1.0.0",
            routes=app.router.routes(),
            tags=[
                {"name": "Users", "description": "User management endpoints"}
            ]
        )
        
        assert "tags" in spec
        assert len(spec["tags"]) == 1
        assert spec["tags"][0]["name"] == "Users"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])