"""
Tests for OpenAPI middleware
"""

import pytest
from aiohttp import web
from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop

from aiohttp_openapi_helper import (
    openapi_route,
    OpenAPIMiddleware
)


class TestOpenAPIMiddleware(AioHTTPTestCase):
    """Test cases for OpenAPIMiddleware"""

    async def get_application(self):
        """Create test application with middleware"""
        app = web.Application()
        
        # Add middleware
        middleware = OpenAPIMiddleware(
            validate_request=True,
            validate_response=False,
            raise_on_error=True,
            log_errors=False
        )
        app.middlewares.append(middleware.middleware)
        
        # Define routes with validation
        @openapi_route(
            app,
            "/users/{user_id}",
            method="GET",
            parameters=[
                {
                    "name": "user_id",
                    "in": "path",
                    "required": True,
                    "schema": {"type": "integer", "minimum": 1}
                },
                {
                    "name": "active",
                    "in": "query",
                    "schema": {"type": "boolean"}
                }
            ],
            responses={"200": {"description": "OK"}}
        )
        async def get_user(request):
            user_id = int(request.match_info["user_id"])
            return web.json_response({"id": user_id})
        
        @openapi_route(
            app,
            "/users",
            method="POST",
            request_body={
                "required": True,
                "content": {
                    "application/json": {
                        "schema": {
                            "type": "object",
                            "required": ["name", "email"],
                            "properties": {
                                "name": {"type": "string", "minLength": 1},
                                "email": {"type": "string", "format": "email"},
                                "age": {"type": "integer", "minimum": 0}
                            }
                        }
                    }
                }
            },
            responses={"201": {"description": "Created"}}
        )
        async def create_user(request):
            data = await request.json()
            return web.json_response({"id": 1, **data}, status=201)
        
        @openapi_route(
            app,
            "/items/{item_id}",
            method="GET",
            parameters=[
                {
                    "name": "item_id",
                    "in": "path",
                    "required": True,
                    "schema": {"type": "string"}
                }
            ],
            responses={"200": {"description": "OK"}}
        )
        async def get_item(request):
            item_id = request.match_info["item_id"]
            return web.json_response({"id": item_id})
        
        return app

    @unittest_run_loop
    async def test_valid_path_parameter(self):
        """Test valid path parameter passes validation"""
        resp = await self.client.request("GET", "/users/123")
        assert resp.status == 200
        data = await resp.json()
        assert data["id"] == 123

    @unittest_run_loop
    async def test_invalid_path_parameter_type(self):
        """Test invalid path parameter type is rejected"""
        # Path parameter expects integer, but we're testing that non-integer paths won't match
        # This is more about aiohttp routing than our validation
        resp = await self.client.request("GET", "/users/abc")
        # This will likely 404 because aiohttp won't route to our handler
        assert resp.status in [404, 400]

    @unittest_run_loop
    async def test_valid_query_parameter(self):
        """Test valid query parameter passes validation"""
        resp = await self.client.request("GET", "/users/123?active=true")
        assert resp.status == 200

    @unittest_run_loop
    async def test_valid_request_body(self):
        """Test valid request body passes validation"""
        resp = await self.client.request(
            "POST",
            "/users",
            json={"name": "John Doe", "email": "john@example.com", "age": 30}
        )
        assert resp.status == 201
        data = await resp.json()
        assert data["name"] == "John Doe"
        assert data["email"] == "john@example.com"

    @unittest_run_loop
    async def test_missing_required_field(self):
        """Test missing required field in request body is rejected"""
        resp = await self.client.request(
            "POST",
            "/users",
            json={"email": "john@example.com"}  # Missing 'name'
        )
        assert resp.status == 400

    @unittest_run_loop
    async def test_invalid_field_type(self):
        """Test invalid field type in request body is rejected"""
        resp = await self.client.request(
            "POST",
            "/users",
            json={"name": "John", "email": "john@example.com", "age": "invalid"}
        )
        assert resp.status == 400

    @unittest_run_loop
    async def test_invalid_email_format(self):
        """Test invalid email format is rejected"""
        resp = await self.client.request(
            "POST",
            "/users",
            json={"name": "John", "email": "not-an-email"}
        )
        # Note: jsonschema format validation might not be strict by default
        # This test might pass depending on jsonschema configuration
        assert resp.status in [201, 400]

    @unittest_run_loop
    async def test_string_path_parameter(self):
        """Test string path parameter works"""
        resp = await self.client.request("GET", "/items/abc123")
        assert resp.status == 200
        data = await resp.json()
        assert data["id"] == "abc123"


class TestMiddlewareConfig:
    """Test middleware configuration options"""

    def test_middleware_without_validation(self):
        """Test middleware with validation disabled"""
        middleware = OpenAPIMiddleware(
            validate_request=False,
            validate_response=False
        )
        assert middleware.validate_request is False
        assert middleware.validate_response is False

    def test_middleware_with_response_validation(self):
        """Test middleware with response validation enabled"""
        middleware = OpenAPIMiddleware(
            validate_request=True,
            validate_response=True,
            raise_on_error=False
        )
        assert middleware.validate_request is True
        assert middleware.validate_response is True
        assert middleware.raise_on_error is False


class TestMiddlewareWithoutMeta
    """Test middleware behavior when routes don't have OpenAPI metadata"""

    async def test_no_metadata_no_validation(self):
        """Test that routes without metadata skip validation"""
        app = web.Application()
        
        middleware = OpenAPIMiddleware(validate_request=True)
        app.middlewares.append(middleware.middleware)
        
        # Route without OpenAPI metadata
        async def handler(request):
            return web.json_response({"message": "OK"})
        
        app.router.add_get("/test", handler)
        
        # Use test client
        from aiohttp.test_utils import TestClient, TestServer
        
        server = TestServer(app)
        client = TestClient(server)
        
        await client.start_server()
        try:
            resp = await client.request("GET", "/test")
            assert resp.status == 200
            data = await resp.json()
            assert data["message"] == "OK"
        finally:
            await client.close()


class TestErrorHandling:
    """Test error handling in middleware"""

    async def test_raise_on_error_true(self):
        """Test that errors are raised when raise_on_error is True"""
        app = web.Application()
        
        middleware = OpenAPIMiddleware(
            validate_request=True,
            raise_on_error=True
        )
        app.middlewares.append(middleware.middleware)
        
        @openapi_route(
            app,
            "/test",
            method="POST",
            request_body={
                "required": True,
                "content": {
                    "application/json": {
                        "schema": {
                            "type": "object",
                            "required": ["field"],
                            "properties": {"field": {"type": "string"}}
                        }
                    }
                }
            },
            responses={"200": {"description": "OK"}}
        )
        async def handler(request):
            return web.json_response({})
        
        from aiohttp.test_utils import TestClient, TestServer
        
        server = TestServer(app)
        client = TestClient(server)
        
        await client.start_server()
        try:
            # Missing required field should raise HTTPBadRequest
            resp = await client.request("POST", "/test", json={})
            assert resp.status == 400
        finally:
            await client.close()

    async def test_raise_on_error_false(self):
        """Test that errors return 400 when raise_on_error is False"""
        app = web.Application()
        
        middleware = OpenAPIMiddleware(
            validate_request=True,
            raise_on_error=False
        )
        app.middlewares.append(middleware.middleware)
        
        @openapi_route(
            app,
            "/test",
            method="POST",
            request_body={
                "required": True,
                "content": {
                    "application/json": {
                        "schema": {
                            "type": "object",
                            "required": ["field"],
                            "properties": {"field": {"type": "string"}}
                        }
                    }
                }
            },
            responses={"200": {"description": "OK"}}
        )
        async def handler(request):
            return web.json_response({})
        
        from aiohttp.test_utils import TestClient, TestServer
        
        server = TestServer(app)
        client = TestClient(server)
        
        await client.start_server()
        try:
            resp = await client.request("POST", "/test", json={})
            assert resp.status == 400
            data = await resp.json()
            assert "error" in data
        finally:
            await client.close()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])