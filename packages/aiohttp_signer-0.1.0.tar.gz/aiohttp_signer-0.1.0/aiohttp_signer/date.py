from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone

from aiohttp import ClientHandlerType, ClientRequest

GMT_STRING = "%a, %d %b %Y %H:%M:%S GMT"


def default_date_maker():
    return datetime.now(tz=timezone.utc)


@dataclass
class DateMiddleware:
    """Adds the date header, see [RFC 9110](https://httpwg.org/specs/rfc9110.html#field.date)"""

    date_maker: Callable[[], datetime] = field(default=default_date_maker)

    async def __call__(self, req: ClientRequest, handler: ClientHandlerType):
        req.headers.add("date", self.date_maker().strftime(GMT_STRING))

        return await handler(req)
