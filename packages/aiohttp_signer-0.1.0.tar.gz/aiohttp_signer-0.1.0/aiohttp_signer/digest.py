from base64 import b64encode
from dataclasses import dataclass
from enum import StrEnum, auto
import hashlib

from aiohttp import ClientHandlerType, ClientRequest


class DigestMode(StrEnum):
    """Mode to display the digest"""

    rfc9430 = auto()
    rfc3230 = auto()
    rfc3230_upper = auto()


class DigestAlgorithm(StrEnum):
    """Algorithm to use for digest"""

    sha256 = auto()
    sha512 = auto()


def mode_to_header_name(mode: DigestMode):
    match mode:
        case DigestMode.rfc9430:
            return "content-digest"
        case _:
            return "digest"


def compute_digest(body: bytes, mode: DigestMode, algorithm: DigestAlgorithm):
    match algorithm:
        case DigestAlgorithm.sha256:
            digest = b64encode(hashlib.sha256(body).digest()).decode()
            name = "sha-256"
        case DigestAlgorithm.sha512:
            digest = b64encode(hashlib.sha512(body).digest()).decode()
            name = "sha-512"
    match mode:
        case DigestMode.rfc9430:
            return f"{name}=:{digest}:"
        case DigestMode.rfc3230:
            return f"{name}={digest}"
        case DigestMode.rfc3230_upper:
            return f"{name.upper()}={digest}"


@dataclass
class DigestMiddleware:
    """Implements adding the digest header. By default
    [RFC 9530 Digest Fields](https://www.rfc-editor.org/rfc/rfc9530.html)
    is used with sha256."""

    mode: DigestMode = DigestMode.rfc9430
    algorithm: DigestAlgorithm = DigestAlgorithm.sha256

    async def __call__(self, req: ClientRequest, handler: ClientHandlerType):
        if req.body == b"":
            return await handler(req)

        value = compute_digest(await req.body.as_bytes(), self.mode, self.algorithm)
        req.headers.add(mode_to_header_name(self.mode), value)

        return await handler(req)
