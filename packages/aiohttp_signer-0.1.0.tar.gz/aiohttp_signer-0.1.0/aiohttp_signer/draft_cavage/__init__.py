from base64 import b64encode
from collections.abc import Callable
from dataclasses import dataclass, field
from time import time

from aiohttp import ClientHandlerType, ClientRequest

from .draft_fields import DraftCavageFields


def default_created_maker() -> int:
    return int(time())


def default_params() -> list[str]:
    return ["(request-target)", "host", "date", "digest"]


@dataclass
class DraftCavageSigner:
    """Signs using draft cavage"""

    signer: Callable[[bytes], bytes]
    key_id: str
    params: list[str] = field(default_factory=default_params)

    async def __call__(self, req: ClientRequest, handler: ClientHandlerType):
        fields = DraftCavageFields(req.method, str(req.url), headers=req.headers)
        message = self._message(fields).encode()
        signature = b64encode(self.signer(message)).decode()
        req.headers["signature"] = self._build_signature(signature)

        return await handler(req)

    def _build_signature(self, signature: str):
        headers = " ".join(self.params)

        signature_parts = [
            f'keyId="{self.key_id}"',
            'algorithm="rsa-sha256"',
            f'headers="{headers}"',
            f'signature="{signature}"',
        ]

        return ",".join(signature_parts)

    def _message(self, fields: DraftCavageFields):
        lines = []
        for param in self.params:
            if fields.has_component(param):
                lines.append(f"{param}: {fields.value_for_component(param)}")

        return "\n".join(lines)
