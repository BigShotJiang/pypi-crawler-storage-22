from dataclasses import dataclass
from urllib.parse import urlparse

from multidict import CIMultiDict


@dataclass
class DraftCavageFields:
    method: str
    url: str
    headers: CIMultiDict
    expires: str | None = None
    created: str | None = None

    def has_component(self, component: str):
        if component[0] == "(":
            return True
        return component in self.headers

    def value_for_component(self, component: str):
        match component:
            case "(request-target)":
                method = self.method.lower()
                parsed_url = urlparse(self.url)
                path = parsed_url.path
                return f"{method} {path}"
            case "(expires)":
                return self.expires
            case "(created)":
                return self.created
        return self.headers.get(component)
