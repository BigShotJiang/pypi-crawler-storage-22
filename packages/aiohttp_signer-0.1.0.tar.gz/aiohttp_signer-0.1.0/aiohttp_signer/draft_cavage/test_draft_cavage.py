from multidict import CIMultiDict
import pytest
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

from .draft_fields import DraftCavageFields

from . import DraftCavageSigner


private_key_pem = b"""-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDXm+EV0rbvZtsY
PMu3Kmjg2fyY0VjdhIuesA5fjNkqQ2ZaaDKmAM/ypeM2JWwF/x/5iTe0cOznwsx/
xANI/T0D7OuVYEc3WssQufQkGCpP3GPxZKhsMiM6MUEDLgUpSSjuT8ixjBOX9WfH
W3KSE9HVTNto2o3XJBLLTMZshx79eGqXObq763DK4dUK1sY9w+Ht+ivmjRq8p0zC
EBelYys2hz0vYv/2HdSCh4+AC8ITodM9cQE96xQGVNQtxHExchkns/p4yRvakZQI
OVUXgQ29zFkAbw9vsdCn2fNXArg5dlyUqwfVgrQbygEZPGeugG2rtwlusm+o0w04
7liDdy7pAgMBAAECggEAS9TtY4mLAcSBRpMLa06lOIAy0WTABpk5qgRt6blWIAE4
nI+NUMl0WflyYnbi+XDzxAY462PUTuc6ma1NIny+2wSXDyCfq55pUWa1sYQ2TYRM
OniWrAcuUKdGIGItOooatUamZZvIwGd1qq5FK4+A+65edRB5VrO/UHWeTElx4t+z
0SUyfbpeCHvuEEK3OyY464V4ZW/D/zAAONaCF3n+FY9uBS0+9LEme0xvaBq24oF9
zmbFJ5DjFSRpNVouGRmO03Uh9+uNrTYkcylDNgQaFCt7WcQO/3lCs+dqNf2psIht
PCbLRqfXQSjQ6gQbnYPGmIFesVVwJpSyMXpFMcgISQKBgQDfBsmCBN0pFib4vaMf
1KSLVxg7DFFiELf1D0ok4rSa7H5eo5flNND9xu+ESWQpcq9J0PVGZqfX7pen9EJV
HmNPMYsAejTqHM/1bg3TdW3A4Xn0I2ShlZlNK0AzLYZRIBF0ZiCWunZBt8xjSLTm
BGHZxvho1TZIffuudcxP5olY3wKBgQD3fFjQQt/bw/2JYUBFvjPiVOJ5j5MzaGLx
gtpDMUFTuG/DPXUvTWp6xIkQj4xO5D9SfkTqBEPOGH/zc7CVoTMsh5vHDJ9fKE/l
FynQaCzBOrU+zKeHvBscS91orF0nNrD3JYtb4GUe1oSZ/BlbwHjZMZQOAssaLDs1
Bdq5SpLJNwKBgDXiU+k/95cnrP7IApN8Ms0fm9EYZslEtM1WhllnFK+hl96Rs+9C
1YOa/t99Q9/nv4YcIEaEIuU+1hFUKHqcPu4xUB4raIFvuKbZkimW44+IaoibzIJl
vIYyfu5ef2c2UkFHM3R3VH8IQy9xr5MrV+Df+8CIUvcsyRQbjeN4FZMNAoGBAOKB
NxPcsN+FYC11CYsLSpcyE1koc5PQTQY3OaXXla+XFQr+25qgYvzblYrHpqWptt68
XDxGDPy6ZZieYJaBw8FUl9k0j0RbM8w7R/TK83MiVTGVwxqyqalbMdgUMOmr34lD
HmnHVSVFNnVsSpUz8ibufk/YdKSOqN2dbxK40uE/AoGBALGrR5FU2u1vcsUj1IvT
epfA5+8kiQ5MdUWU+E7ORM+SRlnicsdS/IPT4KREBck/+GvXY/XZdMYT+T3a4o3P
R4O3/2egqTchuPkwfSAy7L8jt2GNzFvxmcrvpKYAZzjh1KCrZ15OYr7ZhlEWs6MQ
RbdDq36O45uplOe0heeOsPhj
-----END PRIVATE KEY-----"""

key_id = "https://remote.example/actor#key"


def rsa_signer(x: bytes):
    private_key = load_pem_private_key(private_key_pem, password=None)
    assert isinstance(private_key, rsa.RSAPrivateKey)
    return private_key.sign(x, padding.PKCS1v15(), hashes.SHA256())


@pytest.fixture
def fields():
    return DraftCavageFields(
        method="GET",
        url="/path/to/resource",
        headers=CIMultiDict(
            {
                "date": "Wed, 15 Mar 2023 17:28:15 GMT",
                "host": "myhost.example",
            }
        ),
    )


@pytest.fixture
def sample_signer():
    signer = DraftCavageSigner(
        key_id=key_id,
        signer=rsa_signer,
    )
    return signer


def test_message(sample_signer, fields):
    expected = """(request-target): get /path/to/resource
host: myhost.example
date: Wed, 15 Mar 2023 17:28:15 GMT"""
    assert sample_signer._message(fields) == expected
