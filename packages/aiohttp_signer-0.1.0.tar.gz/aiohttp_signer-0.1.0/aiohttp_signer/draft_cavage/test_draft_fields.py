from multidict import CIMultiDict
from .draft_fields import DraftCavageFields


def test_fields():
    fields = DraftCavageFields(
        method="GET",
        url="/path/to/resource",
        headers=CIMultiDict(
            {
                "date": "Tue, 20 Apr 2021 02:07:55 GMT",
                "host": "myhost.example",
            }
        ),
    )

    assert fields.value_for_component("(request-target)") == "get /path/to/resource"
