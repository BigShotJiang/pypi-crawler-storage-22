from base64 import b64encode
from collections.abc import Callable
from dataclasses import dataclass, field
from time import time

from aiohttp import ClientHandlerType, ClientRequest

from .rfc9421_fields import Rfc9421Fields


def default_created_maker() -> int:
    return int(time())


def default_params() -> list[str]:
    return ["@method", "@target-uri", "content-digest"]


@dataclass
class Rfc9421Signer:
    """Signs using [RFC-9421](https://www.rfc-editor.org/rfc/rfc9421.html)"""

    signer: Callable[[bytes], bytes]
    key_id: str
    created_maker: Callable[[], int] = default_created_maker
    params: list[str] = field(default_factory=default_params)
    nonce: str | None = None
    name: str = field(
        default="sig-b1", metadata={"description": "Name to use for the signature"}
    )

    @property
    def quoted_params(self):
        return [f'"{x}"' for x in self.params]

    async def __call__(self, req: ClientRequest, handler: ClientHandlerType):
        fields = Rfc9421Fields(req.method, str(req.url), req.headers)
        req.headers.add("signature-input", self._input_header())
        req.headers.add("signature", self._signature_header(fields))

        return await handler(req)

    def _signature_params(self):
        parts = [
            "(" + " ".join(self.quoted_params) + ")",
            f"created={self.created_maker()}",
            f'keyid="{self.key_id}"',
        ]
        if self.nonce:
            parts.append(f'nonce="{self.nonce}"')

        return ";".join(parts)

    def _message(self, fields: Rfc9421Fields):
        lines = []
        for param in self.params:
            value = fields.value_for_component(param)
            lines.append(f'"{param}": {value}')

        lines.append(f'"@signature-params": {self._signature_params()}')
        result = "\n".join(lines)

        return result

    def _input_header(self):
        return f"{self.name}={self._signature_params()}"

    def _signature_header(self, fields: Rfc9421Fields):
        message = self._message(fields)
        signature = self.signer(message.encode())
        return f"{self.name}=:{b64encode(signature).decode()}:"
