from dataclasses import dataclass
from urllib.parse import urlparse

from multidict import CIMultiDict


@dataclass
class Rfc9421Fields:
    method: str
    url: str
    headers: CIMultiDict

    def value_for_component(self, component: str):
        match component:
            case "@method":
                return self.method.upper()
            case "@target-uri":
                return self.url
            case "@authority":
                return self.headers["host"]
            case "@scheme":
                return urlparse(self.url).scheme
            case "@path":
                return urlparse(self.url).path
            case "@query":
                return "?" + urlparse(self.url).query
            case "@query-param":
                # FIXME
                ...
            case "@request-target":
                # FIXME
                # https://www.rfc-editor.org/rfc/rfc9421.html#name-request-target
                ...

        return self.headers.get(component)
