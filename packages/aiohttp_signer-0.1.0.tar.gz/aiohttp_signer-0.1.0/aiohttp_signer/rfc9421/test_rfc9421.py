from multidict import CIMultiDict
import pytest
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.primitives.asymmetric import ed25519
from .rfc9421_fields import Rfc9421Fields

from . import Rfc9421Signer

test_key_ed25519_private_pem = b"""
-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEIJ+DYvh6SEqVTm50DFtMDoQikTmiCqirVv9mWG9qfSnF
-----END PRIVATE KEY-----
"""
key_id = "test-key-ed25519"


def ed25519_signer(x: bytes):
    private_key = load_pem_private_key(test_key_ed25519_private_pem, password=None)
    assert isinstance(private_key, ed25519.Ed25519PrivateKey)
    return private_key.sign(x)


@pytest.fixture
def fields():
    return Rfc9421Fields(
        method="POST",
        url="/foo",
        headers=CIMultiDict(
            {
                "date": "Tue, 20 Apr 2021 02:07:55 GMT",
                "host": "example.com",
                "content-type": "application/json",
                "content-length": "18",
            }
        ),
    )


@pytest.fixture
def example_rfc9421_b26():
    signer = Rfc9421Signer(
        key_id=key_id,
        signer=ed25519_signer,
        created_maker=lambda: 1618884473,
        params=[
            "date",
            "@method",
            "@path",
            "@authority",
            "content-type",
            "content-length",
        ],
        name="sig-b26",
    )
    return signer


def test_rfc9421_b26_signature_params(example_rfc9421_b26):
    expected = '("date" "@method" "@path" "@authority" "content-type" "content-length");created=1618884473;keyid="test-key-ed25519"'
    assert example_rfc9421_b26._signature_params() == expected


def test_rfc9421_b26_message(example_rfc9421_b26, fields):
    expected = '''"date": Tue, 20 Apr 2021 02:07:55 GMT
"@method": POST
"@path": /foo
"@authority": example.com
"content-type": application/json
"content-length": 18
"@signature-params": ("date" "@method" "@path" "@authority" "content-type" "content-length");created=1618884473;keyid="test-key-ed25519"'''

    assert example_rfc9421_b26._message(fields) == expected


def test_rfc9421_b26_input_headers(example_rfc9421_b26):
    expected = 'sig-b26=("date" "@method" "@path" "@authority" "content-type" "content-length");created=1618884473;keyid="test-key-ed25519"'

    assert example_rfc9421_b26._input_header() == expected


def test_rfc9421_b26_signature_headers(example_rfc9421_b26, fields):
    expected = "sig-b26=:wqcAqbmYJ2ji2glfAMaRy4gruYYnx2nEFN2HN6jrnDnQCK1u02Gb04v9EDgwUPiu4A0w6vuQv5lIp5WPpBKRCw==:"

    assert example_rfc9421_b26._signature_header(fields) == expected
