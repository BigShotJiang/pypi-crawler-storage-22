from multidict import CIMultiDict
import pytest

from .rfc9421_fields import Rfc9421Fields


@pytest.mark.parametrize(
    "component,expected",
    [
        ("@method", "POST"),
        ("@target-uri", "https://www.example.com/path?param=value"),
        ("@authority", "www.example.com"),
        ("@scheme", "https"),
        ("@path", "/path"),
        ("@query", "?param=value"),
    ],
)
def test_method(component, expected):
    fields = Rfc9421Fields(
        "POST",
        "https://www.example.com/path?param=value",
        CIMultiDict({"host": "www.example.com"}),
    )

    value = fields.value_for_component(component)

    assert value == expected


@pytest.mark.parametrize(
    "url,expected",
    [
        (
            "/path?param=value&foo=bar&baz=bat%2Dman",
            "?param=value&foo=bar&baz=bat%2Dman",
        ),
        ("/path?queryString", "?queryString"),
        ("?", "?"),
    ],
)
def test_query_variations(url, expected):
    fields = Rfc9421Fields("GET", url, CIMultiDict({}))

    value = fields.value_for_component("@query")

    assert value == expected
