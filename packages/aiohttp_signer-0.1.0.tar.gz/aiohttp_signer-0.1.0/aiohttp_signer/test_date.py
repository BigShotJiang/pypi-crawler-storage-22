from datetime import datetime, timezone
from unittest.mock import AsyncMock

from aiohttp import ClientRequest
from multidict import CIMultiDict
from .date import DateMiddleware


async def test_date_middleware():
    middleware = DateMiddleware(
        date_maker=lambda: datetime(2026, 1, 5, 23, 4, 12, tzinfo=timezone.utc)
    )

    request = AsyncMock(ClientRequest)
    request.body = AsyncMock()
    request.headers = CIMultiDict({})
    handler = AsyncMock()

    await middleware(request, handler)

    assert request.headers["Date"] == "Mon, 05 Jan 2026 23:04:12 GMT"
