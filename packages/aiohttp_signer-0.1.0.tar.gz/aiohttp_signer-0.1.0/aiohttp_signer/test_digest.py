from unittest.mock import AsyncMock
from aiohttp import ClientRequest
from multidict import CIMultiDict
import pytest
from .digest import DigestAlgorithm, DigestMiddleware, compute_digest, DigestMode


@pytest.mark.parametrize(
    "mode,algorithm,expected",
    [
        (
            DigestMode.rfc9430,
            DigestAlgorithm.sha256,
            "sha-256=:MILb5lUDD6Z0pDSxhgxj+hMBEw0uTzP3g2qUJGHMp9k=:",
        ),
        (
            DigestMode.rfc9430,
            DigestAlgorithm.sha512,
            "sha-512=:S3whoWr+QjPjztVYoyMrjTHT69+7rL7lKcuL72oBsgxRE396sAM+WNtjrE8cWloUUTlkKSoSDaGCaNGqBBj3qQ==:",
        ),
        (
            DigestMode.rfc3230,
            DigestAlgorithm.sha256,
            "sha-256=MILb5lUDD6Z0pDSxhgxj+hMBEw0uTzP3g2qUJGHMp9k=",
        ),
        (
            DigestMode.rfc3230_upper,
            DigestAlgorithm.sha256,
            "SHA-256=MILb5lUDD6Z0pDSxhgxj+hMBEw0uTzP3g2qUJGHMp9k=",
        ),
    ],
)
def test_compute_digest(mode, algorithm, expected):
    result = compute_digest(b'{"cows": "good"}', mode, algorithm)

    assert result == expected


async def test_digest_empty_payload():
    digest = DigestMiddleware()

    request = AsyncMock(ClientRequest)
    request.body = b""
    request.headers = CIMultiDict({})
    handler = AsyncMock()

    await digest(request, handler)

    handler.assert_awaited_once_with(request)

    assert "content-digest" not in request.headers


async def test_digest():
    digest = DigestMiddleware()

    request = AsyncMock(ClientRequest)
    request.body = AsyncMock()
    request.body.as_bytes.return_value = b"moo"
    request.headers = CIMultiDict({})
    handler = AsyncMock()

    await digest(request, handler)

    handler.assert_awaited_once_with(request)

    assert (
        request.headers.get("content-digest")
        == "sha-256=:R9+ukoir89XSJSq/sL1qyWYmN9ZG5t+dXSdLwzbierw=:"
    )
