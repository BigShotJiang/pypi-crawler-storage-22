import asyncio
import aiohttp
from hypercorn import Config
from hypercorn.asyncio import serve
import pytest

from quart import Quart, request

from .digest import DigestAlgorithm

from .rfc9421.test_rfc9421 import ed25519_signer, key_id
from . import DigestMiddleware, Rfc9421Signer


@pytest.fixture
async def headers_future():
    return asyncio.Future()


@pytest.fixture
async def post_url(headers_future):
    app = Quart(__name__)

    @app.post("/foo")
    async def post():
        headers_future.set_result(request.headers)
        return ""

    @app.get("/")
    async def get():
        headers_future.set_result(request.headers)
        return ""

    bind = "localhost:8080"

    config = Config()
    config.bind = [bind]

    task = asyncio.create_task(serve(app, config))

    yield f"http://{bind}/foo"

    task.cancel()

    try:
        await task
    except asyncio.CancelledError:
        ...


@pytest.mark.timeout(5)
async def test_digest(post_url, headers_future):
    async with aiohttp.ClientSession() as session:
        await session.post(
            post_url,
            json={"cows": "good"},
            middlewares=[
                DigestMiddleware(),
                Rfc9421Signer(key_id=key_id, signer=ed25519_signer),
            ],
        )

        result = await headers_future
        content_digest = result.get_all("content-digest")

        assert content_digest == [
            "sha-256=:MILb5lUDD6Z0pDSxhgxj+hMBEw0uTzP3g2qUJGHMp9k=:"
        ]


@pytest.mark.timeout(5)
async def test_multiple_digests(post_url, headers_future):
    async with aiohttp.ClientSession() as session:
        await session.post(
            post_url,
            json={"cows": "good"},
            middlewares=[
                DigestMiddleware(),
                DigestMiddleware(algorithm=DigestAlgorithm.sha512),
                Rfc9421Signer(key_id=key_id, signer=ed25519_signer),
            ],
        )

        result = await headers_future
        content_digest = result.get_all("content-digest")

        assert content_digest == [
            "sha-256=:MILb5lUDD6Z0pDSxhgxj+hMBEw0uTzP3g2qUJGHMp9k=:",
            "sha-512=:S3whoWr+QjPjztVYoyMrjTHT69+7rL7lKcuL72oBsgxRE396sAM+WNtjrE8cWloUUTlkKSoSDaGCaNGqBBj3qQ==:",
        ]


@pytest.mark.timeout(5)
async def test_digest_on_get(post_url, headers_future):
    async with aiohttp.ClientSession() as session:
        await session.get(
            post_url.removesuffix("foo"),
            middlewares=[
                DigestMiddleware(),
                Rfc9421Signer(key_id=key_id, signer=ed25519_signer),
            ],
        )

        result = await headers_future
        assert "content-digest" not in result


@pytest.mark.timeout(5)
async def test_signature(post_url, headers_future):
    async with aiohttp.ClientSession() as session:
        await session.post(
            post_url,
            json={"cows": "good"},
            headers={
                "content-type": "application/json",
                "content-length": "18",
                "host": "example.com",
                "date": "Tue, 20 Apr 2021 02:07:55 GMT",
            },
            middlewares=[
                Rfc9421Signer(
                    key_id=key_id,
                    signer=ed25519_signer,
                    params=[
                        "date",
                        "@method",
                        "@path",
                        "@authority",
                        "content-type",
                        "content-length",
                    ],
                    name="sig-b26",
                    created_maker=lambda: 1618884473,
                ),
            ],
        )

        result = await headers_future

        assert (
            result.get("Signature-Input")
            == 'sig-b26=("date" "@method" "@path" "@authority" "content-type" "content-length");created=1618884473;keyid="test-key-ed25519"'
        )
        assert (
            result.get("Signature")
            == "sig-b26=:wqcAqbmYJ2ji2glfAMaRy4gruYYnx2nEFN2HN6jrnDnQCK1u02Gb04v9EDgwUPiu4A0w6vuQv5lIp5WPpBKRCw==:"
        )
