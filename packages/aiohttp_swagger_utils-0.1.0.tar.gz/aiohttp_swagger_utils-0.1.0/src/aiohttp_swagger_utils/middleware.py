import json
from typing import Callable, Optional, Awaitable
from aiohttp import web
from .utils import load_openapi_spec, validate_request, validate_response


class SwaggerValidationMiddleware:
    def __init__(
        self,
        spec_path: str,
        validate_request: bool = True,
        validate_response: bool = False,
        raise_on_error: bool = True,
    ):
        self.spec = load_openapi_spec(spec_path)
        self.validate_request = validate_request
        self.validate_response = validate_response
        self.raise_on_error = raise_on_error
        self._paths = self.spec.get("paths", {})

    @web.middleware
    async def middleware(
        self, request: web.Request, handler: Callable[[web.Request], Awaitable[web.Response]]
    ) -> web.Response:
        # Validate request if enabled
        if self.validate_request:
            try:
                await self._validate_request(request)
            except ValueError as e:
                if self.raise_on_error:
                    raise web.HTTPBadRequest(text=str(e))
                return web.json_response(
                    {"error": "Validation failed", "details": str(e)},
                    status=400,
                )

        # Process request
        response = await handler(request)

        # Validate response if enabled
        if self.validate_response:
            try:
                await self._validate_response(request, response)
            except ValueError as e:
                if self.raise_on_error:
                    raise web.HTTPInternalServerError(text=str(e))
                # Log the error but don't modify response in production
                print(f"Response validation error: {e}")

        return response

    async def _validate_request(self, request: web.Request) -> None:
        # Find matching path in spec
        path_template = self._find_matching_path(request.path)
        if not path_template:
            # No matching path in spec, skip validation
            return

        path_spec = self._paths.get(path_template, {})
        method_spec = path_spec.get(request.method.lower())

        if not method_spec:
            # No method spec, skip validation
            return

        # Validate request
        await validate_request(request, method_spec)

    async def _validate_response(self, request: web.Request, response: web.Response) -> None:
        # Find matching path in spec
        path_template = self._find_matching_path(request.path)
        if not path_template:
            return

        path_spec = self._paths.get(path_template, {})
        method_spec = path_spec.get(request.method.lower())

        if not method_spec:
            return

        # Get response spec
        responses_spec = method_spec.get("responses", {})
        status_code = str(response.status)
        response_spec = responses_spec.get(status_code) or responses_spec.get("default")

        if not response_spec:
            return

        # Validate response
        await validate_response(response, response_spec)

    def _find_matching_path(self, path: str) -> Optional[str]:
        # Simple path matching - could be enhanced with regex
        for path_template in self._paths.keys():
            # Replace path parameters with wildcards for matching
            normalized_template = path_template
            normalized_path = path

            # Handle path parameters like /users/{id}
            if "{" in path_template:
                # Simple matching: check if path starts with the static part
                static_part = path_template.split("{")[0]
                if normalized_path.startswith(static_part):
                    return path_template
            elif normalized_template == normalized_path:
                return path_template

        return None