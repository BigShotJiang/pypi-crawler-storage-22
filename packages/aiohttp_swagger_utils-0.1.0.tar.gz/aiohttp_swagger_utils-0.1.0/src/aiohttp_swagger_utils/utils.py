import json
import yaml
from typing import Any, Dict, Optional
from pathlib import Path
from jsonschema import validate, ValidationError
from aiohttp import web


def load_openapi_spec(spec_path: str) -> Dict[str, Any]:
    path = Path(spec_path)
    
    if not path.exists():
        raise FileNotFoundError(f"OpenAPI spec file not found: {spec_path}")
    
    try:
        with open(path, "r", encoding="utf-8") as f:
            if path.suffix in [".yaml", ".yml"]:
                return yaml.safe_load(f)
            elif path.suffix == ".json":
                return json.load(f)
            else:
                # Try YAML first, then JSON
                try:
                    f.seek(0)
                    return yaml.safe_load(f)
                except yaml.YAMLError:
                    f.seek(0)
                    return json.load(f)
    except (yaml.YAMLError, json.JSONDecodeError) as e:
        raise ValueError(f"Invalid OpenAPI spec format: {e}")


async def validate_request(request: web.Request, method_spec: Dict[str, Any]) -> None:
    errors = []

    # Validate query parameters
    query_errors = _validate_query_parameters(request, method_spec)
    if query_errors:
        errors.extend(query_errors)

    # Validate path parameters
    path_errors = _validate_path_parameters(request, method_spec)
    if path_errors:
        errors.extend(path_errors)

    # Validate headers
    header_errors = _validate_headers(request, method_spec)
    if header_errors:
        errors.extend(header_errors)

    # Validate request body
    if request.method in ["POST", "PUT", "PATCH"]:
        try:
            body_errors = await _validate_request_body(request, method_spec)
            if body_errors:
                errors.extend(body_errors)
        except Exception as e:
            errors.append(f"Request body validation error: {str(e)}")

    if errors:
        raise ValueError("; ".join(errors))


async def validate_response(response: web.Response, response_spec: Dict[str, Any]) -> None:
    # Only validate JSON responses
    if not response.content_type.startswith("application/json"):
        return

    try:
        # Get response body
        body = await response.text()
        if not body:
            return

        data = json.loads(body)
        
        # Get schema from response spec
        content_spec = response_spec.get("content", {})
        json_spec = content_spec.get("application/json", {})
        schema = json_spec.get("schema")

        if not schema:
            return

        # Validate against schema
        validate(instance=data, schema=schema)

    except (json.JSONDecodeError, ValidationError) as e:
        raise ValueError(f"Response validation failed: {str(e)}")
    except Exception as e:
        raise ValueError(f"Response validation error: {str(e)}")


def _validate_query_parameters(request: web.Request, method_spec: Dict[str, Any]) -> list:
    errors = []
    parameters_spec = method_spec.get("parameters", [])
    
    query_params_spec = [
        p for p in parameters_spec if p.get("in") == "query"
    ]
    
    for param_spec in query_params_spec:
        param_name = param_spec["name"]
        required = param_spec.get("required", False)
        
        if required and param_name not in request.query:
            errors.append(f"Missing required query parameter: {param_name}")
        elif param_name in request.query:
            # Validate parameter value if schema is provided
            schema = param_spec.get("schema")
            if schema:
                try:
                    value = request.query[param_name]
                    _validate_parameter_value(value, schema, param_name)
                except ValueError as e:
                    errors.append(str(e))
    
    return errors


def _validate_path_parameters(request: web.Request, method_spec: Dict[str, Any]) -> list:
    errors = []
    parameters_spec = method_spec.get("parameters", [])
    
    path_params_spec = [
        p for p in parameters_spec if p.get("in") == "path"
    ]
    
    for param_spec in path_params_spec:
        param_name = param_spec["name"]
        required = param_spec.get("required", True)  # Path params are required by default
        
        # Extract path parameter from request.match_info
        if param_name not in request.match_info and required:
            errors.append(f"Missing required path parameter: {param_name}")
        elif param_name in request.match_info:
            # Validate parameter value if schema is provided
            schema = param_spec.get("schema")
            if schema:
                try:
                    value = request.match_info[param_name]
                    _validate_parameter_value(value, schema, param_name)
                except ValueError as e:
                    errors.append(str(e))
    
    return errors


def _validate_headers(request: web.Request, method_spec: Dict[str, Any]) -> list:
    errors = []
    parameters_spec = method_spec.get("parameters", [])
    
    header_params_spec = [
        p for p in parameters_spec if p.get("in") == "header"
    ]
    
    for param_spec in header_params_spec:
        param_name = param_spec["name"]
        required = param_spec.get("required", False)
        
        if required and param_name not in request.headers:
            errors.append(f"Missing required header: {param_name}")
        elif param_name in request.headers:
            # Validate header value if schema is provided
            schema = param_spec.get("schema")
            if schema:
                try:
                    value = request.headers[param_name]
                    _validate_parameter_value(value, schema, param_name)
                except ValueError as e:
                    errors.append(str(e))
    
    return errors


async def _validate_request_body(request: web.Request, method_spec: Dict[str, Any]) -> list:
    errors = []
    
    request_body_spec = method_spec.get("requestBody")
    if not request_body_spec:
        return errors
    
    required = request_body_spec.get("required", False)
    
    # Check if body is required but not provided
    if required:
        try:
            body = await request.text()
            if not body:
                errors.append("Request body is required but not provided")
                return errors
        except Exception:
            errors.append("Request body is required but not provided")
            return errors
    
    # Validate content type
    content_spec = request_body_spec.get("content", {})
    
    # Check if JSON content is expected
    json_spec = content_spec.get("application/json")
    if json_spec:
        try:
            data = await request.json()
            schema = json_spec.get("schema", {})
            
            if schema:
                validate(instance=data, schema=schema)
        except json.JSONDecodeError:
            errors.append("Invalid JSON in request body")
        except ValidationError as e:
            errors.append(f"Request body validation failed: {str(e)}")
        except Exception as e:
            errors.append(f"Request body validation error: {str(e)}")
    
    return errors


def _validate_parameter_value(value: str, schema: Dict[str, Any], param_name: str) -> None:
    # Convert value to appropriate type based on schema
    param_type = schema.get("type", "string")
    
    try:
        if param_type == "integer":
            converted_value = int(value)
        elif param_type == "number":
            converted_value = float(value)
        elif param_type == "boolean":
            converted_value = value.lower() in ["true", "1", "yes"]
        else:
            converted_value = value
        
        # Validate against schema
        validate(instance=converted_value, schema=schema)
    except (ValueError, ValidationError) as e:
        raise ValueError(f"Invalid value for parameter '{param_name}': {str(e)}")