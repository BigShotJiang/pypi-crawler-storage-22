import asyncio
import json
import tempfile
from pathlib import Path
from aiohttp import web
from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop
import pytest

# Import the package
from aiohttp_swagger_utils import (
    setup_swagger_ui,
    setup_redoc,
    SwaggerValidationMiddleware,
    load_openapi_spec,
)


class TestSwaggerUtils(AioHTTPTestCase):

    async def get_application(self):
        app = web.Application()
        
        # Create temporary OpenAPI spec
        self.spec_file = tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False)
        self.spec_file.write("""
openapi: 3.0.0
info:
  title: Test API
  version: 1.0.0
paths:
  /test:
    get:
      summary: Test endpoint
      responses:
        '200':
          description: Successful response
          content:
            application/json:
              schema:
                type: object
                properties:
                  message:
                    type: string
    post:
      summary: Test POST endpoint
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                name:
                  type: string
              required:
                - name
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema:
                type: object
                properties:
                  id:
                    type: integer
                  name:
                    type: string
  /users/{id}:
    get:
      summary: Get user by ID
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: integer
        - name: include_details
          in: query
          schema:
            type: boolean
      responses:
        '200':
          description: User found
        '404':
          description: User not found
""")
        self.spec_file.close()
        
        # Setup Swagger UI
        setup_swagger_ui(app, spec_path=self.spec_file.name, url_prefix="/docs")
        
        # Setup ReDoc
        setup_redoc(app, spec_path=self.spec_file.name, url_prefix="/redoc")
        
        # Add validation middleware
        validation_middleware = SwaggerValidationMiddleware(
            spec_path=self.spec_file.name,
            validate_request=True,
            validate_response=False
        )
        app.middlewares.append(validation_middleware.middleware)
        
        # Add test routes
        async def test_handler(request):
            return web.json_response({"message": "Hello World"})
        
        async def create_handler(request):
            data = await request.json()
            return web.json_response({"id": 1, "name": data.get("name")}, status=201)
        
        async def user_handler(request):
            user_id = request.match_info['id']
            return web.json_response({"id": int(user_id), "name": "Test User"})
        
        app.router.add_get('/test', test_handler)
        app.router.add_post('/test', create_handler)
        app.router.add_get('/users/{id}', user_handler)
        
        return app

    def tearDown(self):
        if hasattr(self, 'spec_file'):
            Path(self.spec_file.name).unlink(missing_ok=True)
        super().tearDown()

    @unittest_run_loop
    async def test_swagger_ui_endpoint(self):
        resp = await self.client.request("GET", "/docs/")
        assert resp.status == 200
        text = await resp.text()
        assert "<title>API Documentation</title>" in text
        assert "swagger-ui" in text

    @unittest_run_loop
    async def test_swagger_spec_endpoint(self):
        resp = await self.client.request("GET", "/docs/swagger.json")
        assert resp.status == 200
        data = await resp.json()
        assert "openapi" in data
        assert data["openapi"] == "3.0.0"
        assert "paths" in data

    @unittest_run_loop
    async def test_redoc_endpoint(self):
        resp = await self.client.request("GET", "/redoc/")
        assert resp.status == 200
        text = await resp.text()
        assert "<title>API Documentation</title>" in text
        assert "redoc" in text.lower()

    @unittest_run_loop
    async def test_redoc_spec_endpoint(self):
        resp = await self.client.request("GET", "/redoc/openapi.json")
        assert resp.status == 200
        data = await resp.json()
        assert "openapi" in data
        assert "paths" in data

    @unittest_run_loop
    async def test_valid_request(self):
        resp = await self.client.request("GET", "/test")
        assert resp.status == 200
        data = await resp.json()
        assert "message" in data

    @unittest_run_loop
    async def test_valid_post_request(self):
        resp = await self.client.request(
            "POST",
            "/test",
            json={"name": "Test User"}
        )
        assert resp.status == 201
        data = await resp.json()
        assert "id" in data
        assert "name" in data

    @unittest_run_loop
    async def test_invalid_post_request(self):
        resp = await self.client.request(
            "POST",
            "/test",
            json={"invalid_field": "value"}  # Missing required 'name' field
        )
        # Should be rejected by validation middleware
        assert resp.status == 400

    @unittest_run_loop
    async def test_path_parameter_validation(self):
        resp = await self.client.request("GET", "/users/123")
        assert resp.status == 200
        data = await resp.json()
        assert data["id"] == 123

    @unittest_run_loop
    async def test_query_parameter_validation(self):
        resp = await self.client.request(
            "GET",
            "/users/123",
            params={"include_details": "true"}
        )
        assert resp.status == 200


class TestUtils:
    def test_load_openapi_spec_yaml(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write("""
openapi: 3.0.0
info:
  title: Test
  version: 1.0.0
paths: {}
""")
            f.flush()
            spec = load_openapi_spec(f.name)
            assert spec["openapi"] == "3.0.0"
            assert spec["info"]["title"] == "Test"
            Path(f.name).unlink()

    def test_load_openapi_spec_json(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump({
                "openapi": "3.0.0",
                "info": {"title": "Test", "version": "1.0.0"},
                "paths": {}
            }, f)
            f.flush()
            spec = load_openapi_spec(f.name)
            assert spec["openapi"] == "3.0.0"
            assert spec["info"]["title"] == "Test"
            Path(f.name).unlink()

    def test_load_openapi_spec_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_openapi_spec("/nonexistent/file.yaml")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])