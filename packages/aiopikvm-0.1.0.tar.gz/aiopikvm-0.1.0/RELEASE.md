# Инструкция первого релиза aiopikvm v0.1.0

## Статус верификации

Все проверки пройдены локально (15.02.2026):

- **ruff check** — All checks passed
- **ruff format** — 38 files already formatted
- **mypy strict** — Success: no issues found in 24 source files
- **pytest** — 110 passed, coverage 100% (441 statements, 0 missed)

`__version__ = "0.1.0"` добавлен в `src/aiopikvm/__init__.py`.

---

## Шаг 1. Создать репозиторий на GitHub

```bash
gh repo create kudato/aiopikvm --public --source=. --remote=origin
```

Если репозиторий и remote уже существуют — пропустить.

---

## Шаг 2. Создать коммиты

Все файлы сейчас untracked. Рекомендуется разбить на логические коммиты:

```bash
# 1. Инфраструктура проекта
git add LICENSE .gitignore pyproject.toml
git commit -m "chore: initialize project structure"

# 2. Ядро библиотеки
git add src/aiopikvm/_constants.py src/aiopikvm/_exceptions.py src/aiopikvm/_base_resource.py
git commit -m "feat: add core exceptions and base resource class"

# 3. Клиент
git add src/aiopikvm/_client.py
git commit -m "feat: add PiKVM async client"

# 4. Модели
git add src/aiopikvm/models/
git commit -m "feat: add Pydantic response models"

# 5. Ресурсы
git add src/aiopikvm/resources/
git commit -m "feat: add API resource classes"

# 6. WebSocket
git add src/aiopikvm/_ws.py
git commit -m "feat: add WebSocket client for realtime events"

# 7. Публичный API
git add src/aiopikvm/__init__.py src/aiopikvm/py.typed
git commit -m "feat: define public API and PEP 561 marker"

# 8. Тесты
git add tests/
git commit -m "test: add comprehensive test suite"

# 9. CI/CD
git add .github/
git commit -m "ci: add CI and release workflows"

# 10. Документация
git add README.md CONTRIBUTING.md CLAUDE.md RELEASE.md
git commit -m "docs: add README, contributing guide, and project docs"
```

Или одним коммитом, если не важна гранулярная история:

```bash
git add -A
git commit -m "feat: initial implementation of aiopikvm async PiKVM client"
```

---

## Шаг 3. Push и проверка CI

```bash
git push -u origin main
```

Дождаться прохождения CI — зелёная галочка в GitHub Actions.

CI (`ci.yml`) выполняет: ruff check → ruff format → mypy → pytest с coverage.

---

## Шаг 4. Настроить environment на GitHub

Workflow `release.yml` использует `environment: release`. Его нужно создать:

1. GitHub → **Settings** → **Environments** → **New environment**
2. Имя: `release`
3. Опционально: включить **Required reviewers** для защиты от случайного релиза

---

## Шаг 5. Настроить Trusted Publisher на PyPI

Публикация использует OIDC (без API-токенов). Нужно создать «pending publisher» на PyPI:

1. Зайти на https://pypi.org (зарегистрироваться, если нет аккаунта)
2. **Account settings** → **Publishing** → **Add a new pending publisher**
3. Заполнить форму:
   - **PyPI Project Name:** `aiopikvm`
   - **Owner:** `kudato`
   - **Repository name:** `aiopikvm`
   - **Workflow name:** `release.yml`
   - **Environment name:** `release`
4. Нажать **Add**

---

## Шаг 6. Создать тег и выпустить релиз

```bash
git tag v0.1.0
git push origin v0.1.0
```

Push тега автоматически запустит `release.yml`, который:

1. Проверит, что tag `v0.1.0` совпадает с `version` в `pyproject.toml`
2. Соберёт пакет через `uv build`
3. Опубликует на PyPI через trusted publisher (OIDC)
4. Создаст GitHub Release с автоматическими release notes

---

## Шаг 7. Проверка

```bash
pip install aiopikvm
python -c "import aiopikvm; print(aiopikvm.__version__)"
# Ожидаемый вывод: 0.1.0
```

---

## Чеклист

- [ ] Репозиторий создан на GitHub
- [ ] Коммиты созданы и запушены
- [ ] CI проходит (зелёная галочка)
- [ ] Environment `release` создан на GitHub
- [ ] Trusted Publisher настроен на PyPI
- [ ] Тег `v0.1.0` создан и запушен
- [ ] `release.yml` отработал без ошибок
- [ ] `pip install aiopikvm` работает

---

## Следующие релизы

Для будущих версий:

1. Обновить `version` в `pyproject.toml`
2. Обновить `__version__` в `src/aiopikvm/__init__.py`
3. Закоммитить и запушить изменения
4. Создать и запушить тег: `git tag v<X.Y.Z> && git push origin v<X.Y.Z>`
