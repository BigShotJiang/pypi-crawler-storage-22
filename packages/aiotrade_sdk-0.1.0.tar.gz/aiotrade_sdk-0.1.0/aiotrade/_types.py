from typing import Literal

HttpMethod = Literal["GET", "POST", "PUT", "DELETE"]
Exchange = Literal["bingx", "bybit"]
