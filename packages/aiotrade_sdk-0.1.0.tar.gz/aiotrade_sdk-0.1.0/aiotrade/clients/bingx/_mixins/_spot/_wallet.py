class WalletMixin:
    """Wallet-related methods for BingX spot API client.

    This mixin provides methods for managing spot wallets and balance operations.
    """
