"""Types for clients."""
