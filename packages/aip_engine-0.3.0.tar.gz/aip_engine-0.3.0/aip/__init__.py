"""
AIP - Algebraic Independence Processor

Auto-detects structure in your data and picks the optimal computation path.

    import aip
    import numpy as np

    # Matrices: auto-detects sparse vs dense
    C = aip.multiply(A, B)

    # Linear system: auto-detects structure and shape
    x = aip.solve(A, b)

    # Graphs: auto-detects communities, fraud patterns
    info = aip.analyze(edges)

    # MoE: only activate needed experts
    result = aip.moe_forward(x, experts, router)

    # Convert: auto-detect optimal matrix format
    optimal = aip.convert(my_matrix)
"""

__version__ = "0.3.0"

# ── Core engine ──────────────────────────────────────────────
from .detector import detect, detect_matrix, StructureReport
from .matrix import multiply, multiply_verbose, solve
from .graph import analyze, detect_fraud
from .llm import MoEEngine, moe_forward, benchmark_moe
from .convert import (to_dense, to_sparse, convert, analyze_format,
                      benchmark_convert)
