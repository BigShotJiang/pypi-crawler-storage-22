"""
Matrix format conversion engine with automatic structure detection.

AIP detects the internal structure of your matrix (banded, diagonal,
block, symmetric, triangular...) and converts to the optimal storage
format. The chip equivalent: auto-routing data layout for maximum
throughput.
"""

import time
import numpy as np
from scipy import sparse as sp


# ── Structure detection ──────────────────────────────────────

def _detect_structure(A):
    """
    Deep structure analysis of a matrix.

    Returns dict with all detected structural properties.
    This is what the AIP chip does in hardware before routing.
    """
    if sp.issparse(A):
        A_dense = A.toarray()
        m, n = A.shape
        nnz = A.nnz
    else:
        A_dense = np.asarray(A, dtype=float)
        m, n = A_dense.shape
        nnz = np.count_nonzero(A_dense)

    size = m * n
    density = nnz / max(size, 1)

    report = {
        'shape': (m, n),
        'nnz': nnz,
        'density': round(density, 6),
        'is_square': m == n,
        'is_sparse': density < 0.3,
    }

    # Symmetric check (square only)
    if m == n:
        report['is_symmetric'] = np.allclose(A_dense, A_dense.T)
    else:
        report['is_symmetric'] = False

    # Triangular check
    if m == n:
        report['is_upper_triangular'] = np.allclose(A_dense, np.triu(A_dense))
        report['is_lower_triangular'] = np.allclose(A_dense, np.tril(A_dense))
    else:
        report['is_upper_triangular'] = False
        report['is_lower_triangular'] = False

    # Diagonal check
    if m == n:
        diag_only = np.zeros_like(A_dense)
        np.fill_diagonal(diag_only, np.diag(A_dense))
        report['is_diagonal'] = np.allclose(A_dense, diag_only)
    else:
        report['is_diagonal'] = False

    # Band detection: find bandwidth
    if nnz > 0:
        rows, cols = np.nonzero(A_dense)
        if len(rows) > 0:
            bandwidth_upper = int(np.max(cols - rows))
            bandwidth_lower = int(np.max(rows - cols))
            report['bandwidth_upper'] = bandwidth_upper
            report['bandwidth_lower'] = bandwidth_lower
            total_bandwidth = bandwidth_upper + bandwidth_lower + 1
            report['bandwidth'] = total_bandwidth
            # Banded if bandwidth is small relative to matrix size
            report['is_banded'] = total_bandwidth < max(m, n) * 0.3
        else:
            report['bandwidth'] = 0
            report['bandwidth_upper'] = 0
            report['bandwidth_lower'] = 0
            report['is_banded'] = True
    else:
        report['bandwidth'] = 0
        report['bandwidth_upper'] = 0
        report['bandwidth_lower'] = 0
        report['is_banded'] = True

    # Block structure detection
    report['has_block_structure'] = _detect_blocks(A_dense)

    # Memory estimates (bytes)
    report['memory'] = _estimate_memory(m, n, nnz, report)

    return report


def _detect_blocks(A):
    """Detect if matrix has block-diagonal structure."""
    m, n = A.shape
    if m != n or m < 4:
        return False

    # Check if there are zero blocks off-diagonal
    half = m // 2
    top_right = A[:half, half:]
    bottom_left = A[half:, :half]

    top_right_zero = np.count_nonzero(top_right) / max(top_right.size, 1) < 0.05
    bottom_left_zero = np.count_nonzero(bottom_left) / max(bottom_left.size, 1) < 0.05

    return top_right_zero and bottom_left_zero


def _estimate_memory(m, n, nnz, report):
    """Estimate memory usage for each format."""
    dtype_size = 8  # float64

    estimates = {
        'dense': m * n * dtype_size,
        'csr': nnz * dtype_size + nnz * 4 + (m + 1) * 4,
        'csc': nnz * dtype_size + nnz * 4 + (n + 1) * 4,
        'coo': nnz * (dtype_size + 4 + 4),
    }

    if report.get('is_banded') and report.get('bandwidth', 0) > 0:
        bw = report['bandwidth']
        estimates['dia'] = bw * max(m, n) * dtype_size + bw * 4

    if report.get('has_block_structure'):
        # Rough estimate for BSR with block size 2
        bs = 2
        n_blocks = nnz // (bs * bs) + 1
        estimates['bsr'] = n_blocks * bs * bs * dtype_size + n_blocks * 4 + (m // bs + 1) * 4

    return estimates


# ── Format conversion ────────────────────────────────────────

def to_dense(A):
    """
    Convert any matrix to dense numpy array.

    Accepts: numpy array, scipy sparse (any format), list of lists.

    Example:
        dense = aip.to_dense(sparse_matrix)
    """
    if sp.issparse(A):
        return A.toarray()
    return np.asarray(A, dtype=float)


def to_sparse(A, fmt='auto'):
    """
    Convert matrix to optimal sparse format.

    AIP auto-detects the structure and picks the best format:
    - Diagonal → DIA
    - Banded → DIA
    - Block structure → BSR
    - Row operations (default) → CSR
    - Column operations → CSC

    Args:
        A: Input matrix (numpy array or scipy sparse)
        fmt: Force format ('csr', 'csc', 'coo', 'dia', 'bsr', 'lil')
             or 'auto' to let AIP decide

    Returns:
        scipy sparse matrix in optimal format

    Example:
        sparse_A = aip.to_sparse(dense_matrix)          # AIP decides
        sparse_A = aip.to_sparse(dense_matrix, fmt='csc')  # force CSC
    """
    if not sp.issparse(A):
        A_dense = np.asarray(A, dtype=float)
    else:
        A_dense = A.toarray()

    if fmt != 'auto':
        converters = {
            'csr': sp.csr_matrix,
            'csc': sp.csc_matrix,
            'coo': sp.coo_matrix,
            'dia': sp.dia_matrix,
            'bsr': sp.bsr_matrix,
            'lil': sp.lil_matrix,
        }
        if fmt not in converters:
            raise ValueError(f"Unknown format '{fmt}'. Use: {list(converters.keys())}")
        return converters[fmt](A_dense)

    # AIP auto-detection
    report = _detect_structure(A_dense)

    if report['is_diagonal']:
        return sp.dia_matrix(A_dense)
    elif report['is_banded'] and report['bandwidth'] > 0:
        return sp.dia_matrix(A_dense)
    elif report['has_block_structure']:
        return sp.bsr_matrix(A_dense)
    else:
        return sp.csr_matrix(A_dense)


def convert(A, target='auto'):
    """
    Smart matrix conversion: AIP detects structure and converts.

    This is the main entry point. Give it any matrix, it figures
    out the optimal representation.

    Args:
        A: Input matrix (any format)
        target: 'dense', 'sparse', or 'auto'
                'auto' picks whichever is more efficient

    Returns:
        Matrix in optimal format

    Example:
        optimal = aip.convert(my_matrix)  # AIP decides everything
    """
    report = _detect_structure(A)

    if target == 'dense':
        return to_dense(A)
    elif target == 'sparse':
        return to_sparse(A)
    elif target == 'auto':
        if report['is_sparse']:
            return to_sparse(A)
        else:
            return to_dense(A)
    else:
        raise ValueError(f"target must be 'dense', 'sparse', or 'auto'")


# ── Analysis ─────────────────────────────────────────────────

def analyze_format(A):
    """
    Full structural analysis with format recommendations.

    Returns the structure report plus which format is optimal
    and why, with memory comparison.

    Example:
        report = aip.analyze_format(my_matrix)
        print(report['recommended'])   # 'DIA'
        print(report['reason'])        # 'banded matrix, bandwidth=5'
        print(report['memory'])        # memory per format in bytes
    """
    report = _detect_structure(A)

    # Determine recommendation
    if not report['is_sparse']:
        rec = 'DENSE'
        reason = f"density {report['density']:.1%}, dense storage is optimal"
    elif report['is_diagonal']:
        rec = 'DIA'
        reason = 'diagonal matrix, DIA uses minimal memory'
    elif report['is_banded']:
        rec = 'DIA'
        reason = f"banded matrix, bandwidth={report['bandwidth']}"
    elif report['has_block_structure']:
        rec = 'BSR'
        reason = 'block-diagonal structure detected'
    elif report['is_symmetric']:
        rec = 'CSR'
        reason = 'symmetric sparse, CSR for efficient row operations'
    else:
        rec = 'CSR'
        reason = 'general sparse, CSR is the default optimal'

    report['recommended'] = rec
    report['reason'] = reason

    # Find minimum memory format
    mem = report['memory']
    best_fmt = min(mem, key=mem.get)
    report['best_memory_format'] = best_fmt
    report['best_memory_bytes'] = mem[best_fmt]
    report['dense_memory_bytes'] = mem['dense']
    report['compression'] = round(mem['dense'] / max(mem[best_fmt], 1), 2)

    return report


def benchmark_convert(A, n_ops=10):
    """
    Benchmark matrix-vector multiply across all formats.

    Actually times operations to find the fastest format,
    not just memory estimates.

    Args:
        A: Input matrix
        n_ops: Number of multiply operations for timing

    Returns:
        dict with timing per format and winner

    Example:
        result = aip.benchmark_convert(big_matrix)
        print(result['fastest'])      # 'DIA'
        print(result['timings_ms'])   # {'dense': 5.2, 'csr': 1.1, ...}
    """
    A_dense = to_dense(A)
    m, n = A_dense.shape
    x = np.random.randn(n)

    formats = {}

    # Dense
    t0 = time.perf_counter()
    for _ in range(n_ops):
        _ = A_dense @ x
    formats['dense'] = (time.perf_counter() - t0) / n_ops

    # CSR
    A_csr = sp.csr_matrix(A_dense)
    t0 = time.perf_counter()
    for _ in range(n_ops):
        _ = A_csr @ x
    formats['csr'] = (time.perf_counter() - t0) / n_ops

    # CSC
    A_csc = sp.csc_matrix(A_dense)
    t0 = time.perf_counter()
    for _ in range(n_ops):
        _ = A_csc @ x
    formats['csc'] = (time.perf_counter() - t0) / n_ops

    # COO
    A_coo = sp.coo_matrix(A_dense)
    t0 = time.perf_counter()
    for _ in range(n_ops):
        _ = A_coo @ x
    formats['coo'] = (time.perf_counter() - t0) / n_ops

    # DIA (if banded)
    report = _detect_structure(A_dense)
    if report['is_banded'] or report['is_diagonal']:
        A_dia = sp.dia_matrix(A_dense)
        t0 = time.perf_counter()
        for _ in range(n_ops):
            _ = A_dia @ x
        formats['dia'] = (time.perf_counter() - t0) / n_ops

    fastest = min(formats, key=formats.get)
    timings_ms = {k: round(v * 1000, 4) for k, v in formats.items()}

    return {
        'fastest': fastest,
        'timings_ms': timings_ms,
        'speedup_vs_dense': round(formats['dense'] / max(formats[fastest], 1e-12), 2),
        'structure': report,
    }
