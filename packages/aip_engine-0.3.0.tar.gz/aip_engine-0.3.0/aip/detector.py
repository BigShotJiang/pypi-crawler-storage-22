"""
Core: auto-detection of algebraic structure.

This is the brain - analyzes data and decides the optimal computation route.
Same logic as the hardware AIP chip, but running on CPU.
"""

import numpy as np
from collections import defaultdict, deque
from typing import Dict, List, Tuple, Set


class StructureReport:
    """Result of structure analysis."""
    __slots__ = [
        'n_nodes', 'n_edges', 'density', 'max_degree',
        'is_bipartite', 'bipartite_sides',
        'is_sparse', 'n_components', 'components',
        'route', 'route_reason',
    ]

    def __init__(self):
        self.n_nodes = 0
        self.n_edges = 0
        self.density = 0.0
        self.max_degree = 0
        self.is_bipartite = False
        self.bipartite_sides = (set(), set())
        self.is_sparse = False
        self.n_components = 1
        self.components = []
        self.route = 'DENSE'
        self.route_reason = ''

    def __repr__(self):
        return (f"StructureReport(route={self.route}, n={self.n_nodes}, "
                f"m={self.n_edges}, bipartite={self.is_bipartite}, "
                f"sparse={self.is_sparse}, components={self.n_components})")


def detect(n_nodes: int, edges: List[Tuple[int, int]],
           sparsity_threshold: float = 0.3) -> StructureReport:
    """
    Analyze structure of a graph/matrix.

    Same pipeline as the hardware AIP chip:
      1. Load edges, compute live statistics
      2. Check bipartite (BFS 2-coloring)
      3. Check components (BFS)
      4. Route decision

    Args:
        n_nodes: Number of vertices/variables
        edges: List of (u, v) pairs
        sparsity_threshold: Density below this = sparse

    Returns:
        StructureReport with route decision
    """
    report = StructureReport()
    report.n_nodes = n_nodes
    report.n_edges = len(edges)

    if n_nodes == 0 or len(edges) == 0:
        report.route = 'SPARSE'
        report.route_reason = 'empty graph'
        report.is_sparse = True
        return report

    # Build adjacency
    adj = defaultdict(set)
    degrees = [0] * n_nodes
    for u, v in edges:
        adj[u].add(v)
        adj[v].add(u)
        degrees[u] += 1
        degrees[v] += 1

    active_nodes = sum(1 for d in degrees if d > 0)
    report.max_degree = max(degrees) if degrees else 0
    report.density = (2 * len(edges)) / (n_nodes * max(n_nodes - 1, 1))

    # 1. Find components (BFS)
    visited = [False] * n_nodes
    components = []
    for start in range(n_nodes):
        if visited[start] or degrees[start] == 0:
            continue
        comp = set()
        queue = deque([start])
        visited[start] = True
        while queue:
            v = queue.popleft()
            comp.add(v)
            for u in adj[v]:
                if not visited[u]:
                    visited[u] = True
                    queue.append(u)
        components.append(comp)

    report.components = components
    report.n_components = len(components)

    # 2. Check bipartite (BFS 2-coloring)
    color = [-1] * n_nodes
    side_a, side_b = set(), set()
    is_bipartite = True

    for start in range(n_nodes):
        if color[start] != -1 or degrees[start] == 0:
            continue
        queue = deque([start])
        color[start] = 0
        side_a.add(start)

        while queue:
            v = queue.popleft()
            for u in adj[v]:
                if color[u] == -1:
                    color[u] = 1 - color[v]
                    (side_b if color[u] == 1 else side_a).add(u)
                    queue.append(u)
                elif color[u] == color[v]:
                    is_bipartite = False
                    break
            if not is_bipartite:
                break
        if not is_bipartite:
            break

    report.is_bipartite = is_bipartite
    if is_bipartite:
        report.bipartite_sides = (side_a, side_b)

    # 3. Check sparsity
    report.is_sparse = report.density < sparsity_threshold

    # 4. Route decision (same priority as hardware)
    if is_bipartite:
        report.route = 'BIPARTITE'
        report.route_reason = 'graph is 2-colorable'
    elif report.n_components > 1:
        report.route = 'DECOMPOSE'
        report.route_reason = f'{report.n_components} independent components'
    elif report.is_sparse:
        report.route = 'SPARSE'
        report.route_reason = f'density {report.density:.1%} < {sparsity_threshold:.0%}'
    else:
        report.route = 'DENSE'
        report.route_reason = f'dense graph, density {report.density:.1%}'

    return report


def detect_matrix(A: np.ndarray, threshold: float = 0.3) -> StructureReport:
    """
    Detect structure in a matrix.

    Converts non-zero pattern to a graph and analyzes it.
    """
    n = A.shape[0]
    rows, cols = np.nonzero(A)
    edges = [(int(r), int(c)) for r, c in zip(rows, cols) if r != c]
    report = detect(n, edges, sparsity_threshold=threshold)
    return report
