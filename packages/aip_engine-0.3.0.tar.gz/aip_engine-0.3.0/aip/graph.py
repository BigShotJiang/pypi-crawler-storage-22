"""
Graph analysis with automatic structure detection.

Detects communities, fraud patterns, and critical nodes
using the AIP structure detection pipeline.
"""

import numpy as np
from collections import defaultdict, deque
from typing import List, Tuple, Dict, Set
from . import detector


def analyze(edges: List[Tuple[int, int]], n_nodes: int = None) -> Dict:
    """
    Analyze a graph/network structure.

    Args:
        edges: List of (u, v) edge pairs
        n_nodes: Number of nodes (auto-detected if None)

    Returns:
        dict with structure info, communities, critical nodes

    Example:
        import aip

        edges = [(0,1), (1,2), (2,0), (3,4), (4,5)]
        info = aip.analyze(edges)
        print(info['route'])        # 'DECOMPOSE'
        print(info['components'])   # 2 components
    """
    if n_nodes is None:
        n_nodes = max(max(u, v) for u, v in edges) + 1 if edges else 0

    report = detector.detect(n_nodes, edges)

    # Find critical nodes (high degree in core)
    adj = defaultdict(set)
    for u, v in edges:
        adj[u].add(v)
        adj[v].add(u)

    degrees = {v: len(adj[v]) for v in range(n_nodes)}
    if degrees:
        deg_values = [d for d in degrees.values() if d > 0]
        threshold = np.percentile(deg_values, 90) if deg_values else 0
        critical = sorted(
            [v for v in range(n_nodes) if degrees[v] >= threshold],
            key=lambda v: degrees[v], reverse=True
        )[:20]
    else:
        critical = []

    return {
        'route': report.route,
        'route_reason': report.route_reason,
        'n_nodes': n_nodes,
        'n_edges': len(edges),
        'density': round(report.density, 4),
        'max_degree': report.max_degree,
        'is_bipartite': report.is_bipartite,
        'is_sparse': report.is_sparse,
        'n_components': report.n_components,
        'components': [sorted(c) for c in report.components],
        'critical_nodes': critical,
    }


def detect_fraud(transactions: List[Tuple[int, int]],
                 n_entities: int = None) -> Dict:
    """
    Detect structural fraud in transaction networks.

    A fiscal carousel creates odd cycles. AIP detects this in O(n+m).

    Args:
        transactions: List of (sender, receiver) pairs
        n_entities: Number of entities (auto-detected if None)

    Returns:
        dict with fraud diagnosis

    Example:
        import aip

        # Normal transactions
        transactions = [(0,1), (1,2), (2,3), (3,4)]
        result = aip.detect_fraud(transactions)
        print(result['fraud_detected'])  # False

        # Carousel fraud (odd cycle)
        transactions = [(0,1), (1,2), (2,0), (0,3), (3,4)]
        result = aip.detect_fraud(transactions)
        print(result['fraud_detected'])  # True
    """
    if n_entities is None:
        n_entities = max(max(u, v) for u, v in transactions) + 1 if transactions else 0

    info = analyze(transactions, n_entities)

    # Fraud detection logic
    core_pct = len(info['critical_nodes']) / max(n_entities, 1)
    n_critical = len(info['critical_nodes'])

    if info['is_bipartite']:
        fraud_detected = False
        confidence = 'HIGH'
        reason = 'Bipartite network - clean structure'
    elif n_critical > 0 and info['n_components'] <= 3:
        fraud_detected = True
        confidence = 'HIGH' if n_critical >= 3 else 'MEDIUM'
        reason = f'Concentrated core with {n_critical} critical nodes'
    else:
        fraud_detected = False
        confidence = 'MEDIUM'
        reason = 'Non-bipartite but no anomalous concentration'

    info['fraud_detected'] = fraud_detected
    info['fraud_confidence'] = confidence
    info['fraud_reason'] = reason
    info['entities_to_investigate'] = info['critical_nodes'][:10] if fraud_detected else []

    return info
