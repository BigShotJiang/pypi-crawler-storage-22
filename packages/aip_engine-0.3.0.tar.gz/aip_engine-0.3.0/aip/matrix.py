"""
Matrix operations with automatic structure detection.

Detects if matrices are sparse and uses scipy.sparse automatically.
No need to tell it - it figures it out like the AIP chip would.
"""

import time
import numpy as np
from scipy import sparse as sp
from . import detector


def multiply(A, B, threshold=0.3):
    """
    Multiply two matrices, auto-detecting the optimal strategy.

    If both matrices are sparse (density < threshold), uses scipy.sparse.
    Otherwise, uses dense BLAS (numpy).

    Args:
        A: First matrix (numpy array)
        B: Second matrix (numpy array)
        threshold: Density threshold for sparse detection (default 0.3 = 30%)

    Returns:
        Result matrix (numpy array)

    Example:
        import aip
        import numpy as np

        # Sparse matrix (1% density) - AIP auto-detects and uses sparse
        A = np.random.rand(5000, 5000) * (np.random.rand(5000, 5000) < 0.01)
        B = np.random.rand(5000, 5000) * (np.random.rand(5000, 5000) < 0.01)
        C = aip.multiply(A, B)  # Automatically faster than A @ B
    """
    nnz_A = np.count_nonzero(A)
    nnz_B = np.count_nonzero(B)
    density_A = nnz_A / A.size
    density_B = nnz_B / B.size

    if density_A < threshold and density_B < threshold:
        return (sp.csr_matrix(A) @ sp.csr_matrix(B)).toarray()
    else:
        return A @ B


def multiply_verbose(A, B, threshold=0.3):
    """
    Like multiply(), but returns timing and structure info.

    Returns:
        dict with 'result', 'strategy', 'density_A', 'density_B',
        'time_ms', 'speedup_vs_dense'
    """
    nnz_A = np.count_nonzero(A)
    nnz_B = np.count_nonzero(B)
    density_A = nnz_A / A.size
    density_B = nnz_B / B.size
    use_sparse = density_A < threshold and density_B < threshold

    # AIP path
    t0 = time.perf_counter()
    if use_sparse:
        C = (sp.csr_matrix(A) @ sp.csr_matrix(B)).toarray()
    else:
        C = A @ B
    t_aip = time.perf_counter() - t0

    # Dense baseline
    t0 = time.perf_counter()
    C_dense = A @ B
    t_dense = time.perf_counter() - t0

    return {
        'result': C,
        'strategy': 'SPARSE' if use_sparse else 'DENSE',
        'density_A': round(density_A * 100, 2),
        'density_B': round(density_B * 100, 2),
        'time_ms': round(t_aip * 1000, 2),
        'dense_time_ms': round(t_dense * 1000, 2),
        'speedup': round(t_dense / max(t_aip, 1e-9), 2),
    }


def solve(A, b, threshold=0.3):
    """
    Solve Ax = b, auto-detecting structure and shape.

    Auto-routes based on:
    - Square + sparse → scipy spsolve
    - Square + dense → numpy solve
    - Rectangular + sparse → scipy LSQR (least-squares)
    - Rectangular + dense → numpy lstsq

    Args:
        A: Coefficient matrix (m x n, square or rectangular)
        b: Right-hand side vector
        threshold: Density threshold for sparse detection

    Returns:
        Solution vector x (least-squares solution if rectangular)

    Example:
        import aip
        import numpy as np

        # Square system
        A = np.eye(100) * 2
        x = aip.solve(A, np.ones(100))

        # Rectangular system (overdetermined)
        A = np.random.randn(1000, 50)
        b = np.random.randn(1000)
        x = aip.solve(A, b)  # auto uses LSQR/lstsq
    """
    from scipy.sparse import linalg as spla

    m, n = A.shape
    density = np.count_nonzero(A) / A.size
    is_sparse = density < threshold
    is_square = (m == n)

    if is_square and is_sparse:
        # Square sparse: direct solve
        A_sp = sp.csr_matrix(A)
        return spla.spsolve(A_sp, b)
    elif is_square and not is_sparse:
        # Square dense: LAPACK
        return np.linalg.solve(A, b)
    elif not is_square and is_sparse:
        # Rectangular sparse: LSQR (iterative least-squares)
        A_sp = sp.csr_matrix(A)
        result = spla.lsqr(A_sp, b)
        return result[0]  # solution vector
    else:
        # Rectangular dense: lstsq
        result = np.linalg.lstsq(A, b, rcond=None)
        return result[0]  # solution vector
