"""Tests for AIP core engine: detector, matrix, graph, llm, convert."""

import numpy as np
import pytest
import aip


# ── Detector ────────────────────────────────────────────────

class TestDetector:
    def test_detect_sparse_graph(self):
        """Sparse graph should route to DECOMPOSE."""
        edges = [(0, 1), (2, 3), (4, 5)]
        report = aip.detect(6, edges)
        assert report.is_sparse
        assert report.n_components >= 3

    def test_detect_dense_graph(self):
        """Complete graph should not be sparse."""
        n = 10
        edges = [(i, j) for i in range(n) for j in range(i+1, n)]
        report = aip.detect(n, edges)
        assert not report.is_sparse

    def test_detect_bipartite(self):
        """Bipartite graph should be detected."""
        edges = [(0, 3), (1, 4), (2, 5)]
        report = aip.detect(6, edges)
        assert report.is_bipartite

    def test_detect_non_bipartite(self):
        """Triangle is not bipartite."""
        edges = [(0, 1), (1, 2), (2, 0)]
        report = aip.detect(3, edges)
        assert not report.is_bipartite

    def test_structure_report_fields(self):
        """StructureReport should have all expected fields."""
        report = aip.detect(4, [(0, 1), (2, 3)])
        assert hasattr(report, 'route')
        assert hasattr(report, 'density')
        assert hasattr(report, 'is_sparse')
        assert hasattr(report, 'is_bipartite')
        assert hasattr(report, 'n_components')

    def test_detect_matrix_sparse(self):
        """Sparse matrix should be detected."""
        A = np.eye(100)
        report = aip.detect_matrix(A)
        assert report.is_sparse
        assert report.density < 0.1

    def test_detect_matrix_dense(self):
        """Dense matrix should be detected."""
        A = np.random.randn(20, 20)
        report = aip.detect_matrix(A)
        assert not report.is_sparse


# ── Matrix Operations ───────────────────────────────────────

class TestMatrix:
    def test_multiply_dense(self):
        """Dense matrix multiply should return correct result."""
        A = np.random.randn(50, 50)
        B = np.random.randn(50, 50)
        C = aip.multiply(A, B)
        expected = A @ B
        np.testing.assert_allclose(C, expected, rtol=1e-5)

    def test_multiply_sparse(self):
        """Sparse matrix multiply should return correct result."""
        A = np.eye(100) * 3.0
        B = np.eye(100) * 2.0
        C = aip.multiply(A, B)
        expected = np.eye(100) * 6.0
        np.testing.assert_allclose(C, expected, rtol=1e-5)

    def test_multiply_rectangular(self):
        """Rectangular matrices should work."""
        A = np.random.randn(30, 50)
        B = np.random.randn(50, 20)
        C = aip.multiply(A, B)
        assert C.shape == (30, 20)
        expected = A @ B
        np.testing.assert_allclose(C, expected, rtol=1e-5)

    def test_solve_dense(self):
        """Dense linear system should be solved correctly."""
        A = np.random.randn(50, 50)
        A = A @ A.T + np.eye(50)  # Make positive definite
        b = np.random.randn(50)
        x = aip.solve(A, b)
        np.testing.assert_allclose(A @ x, b, rtol=1e-4)

    def test_solve_sparse(self):
        """Sparse linear system should be solved correctly."""
        n = 100
        A = np.eye(n) * 4.0
        for i in range(n - 1):
            A[i, i+1] = -1.0
            A[i+1, i] = -1.0
        b = np.ones(n)
        x = aip.solve(A, b)
        np.testing.assert_allclose(A @ x, b, rtol=1e-4)

    def test_solve_rectangular_overdetermined(self):
        """Rectangular overdetermined system (m > n) should use lstsq."""
        np.random.seed(42)
        A = np.random.randn(100, 20)
        x_true = np.random.randn(20)
        b = A @ x_true
        x = aip.solve(A, b)
        np.testing.assert_allclose(x, x_true, rtol=1e-4)

    def test_solve_rectangular_sparse(self):
        """Sparse rectangular system should use LSQR."""
        np.random.seed(42)
        m, n = 200, 50
        A = np.zeros((m, n))
        for i in range(m):
            cols = np.random.choice(n, size=3, replace=False)
            A[i, cols] = np.random.randn(3)
        x_true = np.random.randn(n)
        b = A @ x_true
        x = aip.solve(A, b)
        np.testing.assert_allclose(A @ x, b, atol=1e-4)

    def test_multiply_verbose(self):
        """Verbose multiply should return dict with result and metadata."""
        A = np.random.randn(30, 30)
        B = np.random.randn(30, 30)
        result = aip.multiply_verbose(A, B)
        assert 'result' in result
        assert result['result'].shape == (30, 30)


# ── Graph ───────────────────────────────────────────────────

class TestGraph:
    def test_analyze_basic(self):
        """Basic graph analysis should work."""
        edges = [(0, 1), (1, 2), (3, 4)]
        info = aip.analyze(edges)
        assert info['n_nodes'] == 5
        assert info['n_edges'] == 3
        assert info['n_components'] == 2

    def test_analyze_connected(self):
        """Connected graph should have 1 component."""
        edges = [(0, 1), (1, 2), (2, 3), (3, 0)]
        info = aip.analyze(edges)
        assert info['n_components'] == 1

    def test_detect_fraud_clean(self):
        """Bipartite (clean) network should not detect fraud."""
        edges = [(0, 3), (1, 4), (2, 5)]
        result = aip.detect_fraud(edges)
        assert not result['fraud_detected']

    def test_detect_fraud_carousel(self):
        """Odd cycle (carousel) should detect fraud."""
        edges = [(0, 1), (1, 2), (2, 0), (0, 3), (3, 4)]
        result = aip.detect_fraud(edges)
        assert result['fraud_detected']

    def test_analyze_returns_expected_keys(self):
        """Analysis result should have all expected keys."""
        edges = [(0, 1), (1, 2)]
        info = aip.analyze(edges)
        for key in ['route', 'n_nodes', 'n_edges', 'density',
                     'is_bipartite', 'is_sparse', 'n_components']:
            assert key in info


# ── LLM / MoE ──────────────────────────────────────────────

class TestMoE:
    def test_moe_forward(self):
        """MoE forward should return output of correct shape."""
        np.random.seed(42)
        n_experts, expert_dim, hidden_dim = 16, 64, 128
        x = np.random.randn(hidden_dim).astype(np.float32)
        experts = np.random.randn(n_experts, expert_dim, hidden_dim).astype(np.float32) * 0.01
        router = np.random.randn(hidden_dim, n_experts).astype(np.float32)
        result = aip.moe_forward(x, experts, router, n_active=4)
        assert result.shape == (expert_dim,)

    def test_moe_engine(self):
        """MoE engine should process tokens and track stats."""
        np.random.seed(42)
        engine = aip.MoEEngine(n_experts=16, n_active=4,
                                hidden_dim=128, expert_dim=64)
        weights = np.random.randn(16, 64, 128).astype(np.float32) * 0.01
        engine.load_experts(weights)

        x = np.random.randn(128).astype(np.float32)
        result = engine.forward(x)
        assert result.shape == (64,)

        stats = engine.get_stats()
        assert stats['tokens'] == 1
        assert stats['experts_per_token'] == 4

    def test_moe_batch(self):
        """Batch processing should handle multiple tokens."""
        np.random.seed(42)
        engine = aip.MoEEngine(n_experts=8, n_active=2,
                                hidden_dim=64, expert_dim=32)
        weights = np.random.randn(8, 32, 64).astype(np.float32) * 0.01
        engine.load_experts(weights)

        X = np.random.randn(5, 64).astype(np.float32)
        result = engine.forward_batch(X)
        assert result.shape == (5, 32)

    def test_moe_sparsity(self):
        """MoE should skip most experts (the whole point)."""
        engine = aip.MoEEngine(n_experts=256, n_active=8)
        stats = engine.get_stats()
        utilization = 8 / 256
        assert utilization < 0.05  # Less than 5% of experts used

    def test_benchmark_moe(self):
        """Benchmark should return timing and memory stats."""
        result = aip.benchmark_moe(n_experts=16, n_active=4,
                                    hidden_dim=64, expert_dim=32,
                                    n_tokens=10)
        assert 'timing' in result
        assert 'memory' in result
        assert 'config' in result
        assert result['config']['n_experts'] == 16


# ── Convert ─────────────────────────────────────────────────

class TestConvert:
    def test_to_dense_from_sparse(self):
        """Converting sparse to dense should work."""
        from scipy import sparse as sp
        A_sp = sp.eye(50, format='csr')
        A_dense = aip.to_dense(A_sp)
        assert isinstance(A_dense, np.ndarray)
        assert A_dense.shape == (50, 50)
        np.testing.assert_allclose(A_dense, np.eye(50))

    def test_to_dense_from_array(self):
        """Converting dense array should return same data."""
        A = np.random.randn(20, 20)
        result = aip.to_dense(A)
        np.testing.assert_allclose(result, A)

    def test_to_sparse_auto_diagonal(self):
        """Diagonal matrix should auto-select DIA format."""
        from scipy import sparse as sp
        A = np.diag([1.0, 2.0, 3.0, 4.0, 5.0])
        result = aip.to_sparse(A)
        assert sp.issparse(result)
        np.testing.assert_allclose(result.toarray(), A)

    def test_to_sparse_forced_format(self):
        """Forcing CSC format should return CSC."""
        from scipy import sparse as sp
        A = np.eye(30)
        result = aip.to_sparse(A, fmt='csc')
        assert sp.issparse(result)
        assert isinstance(result, sp.csc_matrix)

    def test_to_sparse_invalid_format(self):
        """Invalid format should raise ValueError."""
        with pytest.raises(ValueError):
            aip.to_sparse(np.eye(10), fmt='invalid')

    def test_convert_auto_sparse(self):
        """Sparse matrix with auto should return sparse."""
        from scipy import sparse as sp
        A = np.eye(100)
        result = aip.convert(A)
        assert sp.issparse(result)

    def test_convert_auto_dense(self):
        """Dense matrix with auto should return dense."""
        A = np.random.randn(20, 20)
        result = aip.convert(A)
        assert isinstance(result, np.ndarray)

    def test_convert_force_dense(self):
        """Forcing dense conversion should return numpy array."""
        A = np.eye(50)
        result = aip.convert(A, target='dense')
        assert isinstance(result, np.ndarray)

    def test_convert_force_sparse(self):
        """Forcing sparse conversion should return sparse."""
        from scipy import sparse as sp
        A = np.random.randn(20, 20)
        result = aip.convert(A, target='sparse')
        assert sp.issparse(result)

    def test_analyze_format_diagonal(self):
        """Diagonal matrix should be recommended as DIA."""
        A = np.diag(np.arange(1.0, 51.0))
        report = aip.analyze_format(A)
        assert report['is_diagonal']
        assert report['recommended'] == 'DIA'
        assert report['compression'] > 1.0

    def test_analyze_format_dense(self):
        """Dense matrix should be recommended as DENSE."""
        A = np.random.randn(30, 30)
        report = aip.analyze_format(A)
        assert report['recommended'] == 'DENSE'

    def test_analyze_format_banded(self):
        """Banded matrix should be detected."""
        n = 50
        A = np.zeros((n, n))
        for i in range(n):
            for j in range(max(0, i-2), min(n, i+3)):
                A[i, j] = np.random.randn()
        report = aip.analyze_format(A)
        assert report['is_banded']
        assert report['bandwidth'] <= 5

    def test_analyze_format_symmetric(self):
        """Symmetric matrix should be detected."""
        A = np.random.randn(30, 30)
        A = A + A.T
        report = aip.analyze_format(A)
        assert report['is_symmetric']

    def test_analyze_format_triangular(self):
        """Triangular matrix should be detected."""
        A = np.triu(np.random.randn(30, 30))
        report = aip.analyze_format(A)
        assert report['is_upper_triangular']

    def test_analyze_format_memory(self):
        """Memory estimates should be present."""
        A = np.eye(100)
        report = aip.analyze_format(A)
        assert 'memory' in report
        assert 'dense' in report['memory']
        assert 'csr' in report['memory']
        assert report['memory']['csr'] < report['memory']['dense']

    def test_benchmark_convert(self):
        """Benchmark should return timing and fastest format."""
        A = np.eye(100)
        result = aip.benchmark_convert(A, n_ops=5)
        assert 'fastest' in result
        assert 'timings_ms' in result
        assert 'speedup_vs_dense' in result

    def test_convert_roundtrip(self):
        """Dense → sparse → dense should preserve data."""
        A = np.diag([1.0, 2.0, 3.0, 4.0])
        sparse_A = aip.to_sparse(A)
        back = aip.to_dense(sparse_A)
        np.testing.assert_allclose(back, A)

    def test_analyze_format_block(self):
        """Block-diagonal matrix should be detected."""
        A = np.zeros((20, 20))
        A[:10, :10] = np.random.randn(10, 10)
        A[10:, 10:] = np.random.randn(10, 10)
        report = aip.analyze_format(A)
        assert report['has_block_structure']


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
