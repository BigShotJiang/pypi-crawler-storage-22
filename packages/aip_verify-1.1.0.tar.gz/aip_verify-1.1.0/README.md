# Agent Integrity Protocol (AIP)

> **The SSL/TLS for AI Agent Skills** — Cryptographic verification, permission manifests, and reputation scoring for the agentic web.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-orange.svg)]()
[![Version: 1.0.0](https://img.shields.io/badge/Version-1.0.0-blue.svg)]()
[![Tests: 63 Passing](https://img.shields.io/badge/Tests-63%20Passing-brightgreen.svg)]()
[![OWASP: LLM Top 10](https://img.shields.io/badge/OWASP-LLM%20Top%2010-blue.svg)](https://genai.owasp.org/llm-top-10/)
[![CVE-2026-25253: Mitigated](https://img.shields.io/badge/CVE--2026--25253-Mitigated-green.svg)]()

---

## The Problem

The agentic web is exploding. Platforms like Moltbook report **1.5 million agents** operated by only **17,000 humans** — an 88:1 ratio. But there's no standard way to verify:

- **Who authored** a skill or tool
- **What permissions** it actually needs
- **Whether the code** has been tampered with
- **If the author** has a history of malicious behavior

This is the **SSL problem of 1995** — we're transmitting executable code between agents without any verification layer.

### Recent Incidents (February 2026)

| Platform | Vulnerability | Impact |
|----------|--------------|--------|
| **Moltbook** | Credential exfiltration via DNS tunneling | $47K stolen, 2,300 deployments compromised |
| **Moltbook** | 91% indirect prompt injection success rate | 1.5M API keys at risk |
| **OpenClaw** | CVE-2026-25253 WebSocket token exfil RCE | Full system compromise via sandbox escape |
| **ClawHub** | Malicious skills in marketplace | Financial data theft via backdoored extensions |

## The Solution: Agent Integrity Protocol

AIP provides a lightweight, cryptographically-verifiable trust layer for AI agent skills:

```
┌─────────────────────────────────────────────────────────────────┐
│                    AGENT INTEGRITY PROTOCOL                     │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │   AUTHOR    │  │   CONTENT   │  │ PERMISSIONS │             │
│  │  IDENTITY   │  │   HASHES    │  │  MANIFEST   │             │
│  │    (DID)    │  │  (SHA-256)  │  │   (Scope)   │             │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘             │
│         │                │                │                     │
│         └────────────────┼────────────────┘                     │
│                          ▼                                      │
│              ┌───────────────────────┐                          │
│              │   CRYPTOGRAPHIC       │                          │
│              │     SIGNATURE         │                          │
│              │     (EdDSA)           │                          │
│              └───────────────────────┘                          │
│                          │                                      │
│                          ▼                                      │
│              ┌───────────────────────┐                          │
│              │   REPUTATION SCORE    │                          │
│              │      (0-100)          │                          │
│              └───────────────────────┘                          │
└─────────────────────────────────────────────────────────────────┘
```

## Quick Start

### 1. Create an Integrity Manifest

Every skill includes an `integrity.manifest.json`:

```json
{
  "version": "1.0.0",
  "skill": {
    "name": "calendar-booking",
    "version": "2.1.0",
    "description": "Book calendar events via Google Calendar API"
  },
  "author": {
    "did": "did:web:example.com",
    "name": "Trusted Developer",
    "contact": "security@example.com",
    "signature": "eyJhbGciOiJFZERTQSJ9..."
  },
  "integrity": {
    "algorithm": "sha256",
    "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "files": [
      "index.js": "sha256:a1b2c3d4e5f6..."
    ],
    "signed_at": "2026-02-07T10:30:00Z",
    "expires": "2027-02-07T10:30:00Z"
  },
  "permissions": {
    "network": {
      "allowed": ["calendar.google.com"],
      "denied": ["*"]
    },
    "secrets": {
      "required": ["GOOGLE_API_KEY"],
      "optional": []
    },
    "data": {
      "read": ["user.calendar.events"],
      "write": ["user.calendar.events"]
    },
    "filesystem": {
      "read": [],
      "write": []
    }
  }
}
```

### 2. Verify Before Execution

```python
from aip import verify

# Verification is async (checks DIDs, reputation, and crypto)
result = await verify("./calendar-skill/")

if result.trusted:
    print(f"✅ Skill verified!")
    print(f"   Author: {result.author.name} ({result.author.did})")
    print(f"   Reputation: {result.reputation}/100")
    print(f"   Permissions: {result.permissions}")
else:
    print(f"❌ Verification failed: {result.reason}")
```

### 3. Enforce Least Privilege

The executing agent reads the permission manifest and enforces boundaries:

```python
# Agent runtime enforces declared permissions
if skill.requests_permission("network", "https://evil.com"):
    raise PermissionDenied("Network access to https://evil.com not declared")
```

## How It Compares

| Feature | AIP | Monday.com ATP | Raw Skills |
|---------|-----|----------------|------------|
| Author Identity | ✅ DID-based | ❌ None | ❌ None |
| Code Integrity | ✅ SHA-256 hashes | ❌ None | ❌ None |
| Permission Manifest | ✅ Granular scopes | ✅ Basic | ❌ None |
| Cryptographic Signature | ✅ EdDSA | ❌ None | ❌ None |
| Reputation Scoring | ✅ Community-driven | ❌ None | ❌ None |
| Runtime Enforcement | ✅ Built-in | ✅ Sandbox | ❌ None |

**AIP complements ATP** — ATP handles execution/interoperability, AIP handles verification/trust.

## Production Evidence: The Moltbook Case Study

The [Moltbook VedicRoastGuru](https://github.com/santoshmanya/local-ai-agent-lab/tree/moltbook) project demonstrates the need for AIP:

### Bad Karma Tracking (Proto-Reputation)
```python
def _record_bad_karma(self, agent_name: str, reason: str):
    """Record an agent's bad karma"""
    self.bad_karma_agents['agents'][agent_name]['incidents'].append({
        'reason': reason,
        'timestamp': datetime.now().isoformat()
    })
    self.bad_karma_agents['agents'][agent_name]['karma_score'] -= 10
```

### Prompt Injection Detection (Content Verification)
```python
def _detect_prompt_injection(self, text: str) -> bool:
    """Dharma Gatekeeper - detect malicious tokens"""
    dangerous_patterns = [
        r'\{\{.*?\}\}',  # Template injection
        r'<\|.*?\|>',    # Special tokens
        r'ignore previous',
        r'new instructions'
    ]
```

### Shadow Audit (Authenticity Verification)
```python
def _calculate_puppet_score(self, post: dict) -> dict:
    """Calculate puppet vs authentic agency score"""
    # Returns puppet_score, authentic_score, verdict, evidence
```

These patterns emerged organically from real-world agent-to-agent warfare. AIP formalizes them into a standard.

## Documentation

- [**Whitepaper**](docs/WHITEPAPER.md) — Full technical specification
- [**Quick Start Guide**](docs/QUICK_START.md) — 5-minute integration
- [**OpenClaw Integration**](docs/OPENCLAW_INTEGRATION.md) — Framework integration guide (CVE-2026-25253 mitigation)
- [**OWASP Security Addendum**](docs/OWASP_SECURITY.md) — LLM Top 10 protection details
- [**JSON Schema**](spec/integrity.manifest.schema.json) — Formal manifest specification

## Security Test Suite

AIP includes a comprehensive automated test suite with **63 tests** covering:

| Category | Tests | Threats Covered |
|----------|-------|----------------|
| OWASP LLM01 | 5 | Prompt injection in metadata |
| OWASP LLM02 | 6 | Credential theft, secret exfiltration |
| OWASP LLM03 | 7 | Supply chain, DID verification |
| OWASP LLM06 | 9 | Excessive agency, sandbox escape |
| OWASP LLM10 | 5 | Resource exhaustion, API abuse |
| Moltbook-specific | 11 | File deletion, private DM access, larper detection |
| OpenClaw-specific | 20 | CVE-2026-25253, WebSocket exfil, autonomy bypass |

Run the test suite:
```bash
pip install pytest
python -m pytest tests/ -v
```

## Examples

- [Calendar Skill Manifest](examples/calendar-skill/integrity.manifest.json)
- [Python Verification](examples/verify-skill.py)
- [JavaScript Verification](examples/verify-skill.js)

## Roadmap

### Phase 1: Specification ✅ Complete
- [x] Core manifest schema
- [x] Signature verification protocol
- [x] Permission model
- [x] Reputation framework

### Phase 2: Security Validation ✅ Complete
- [x] OWASP LLM Top 10 test coverage
- [x] Moltbook vulnerability mitigations
- [x] OpenClaw CVE-2026-25253 protection
- [x] 63 automated security tests

### Phase 3: Reference Implementation (In Progress)
- [ ] Python SDK
- [ ] JavaScript/TypeScript SDK
- [ ] CLI tools

### Phase 4: Ecosystem
- [ ] Registry service
- [ ] Browser extension
- [ ] IDE plugins

### Phase 5: Standardization
- [ ] W3C submission
- [ ] OpenClaw adoption
- [ ] Platform partnerships

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License — See [LICENSE](LICENSE) for details.

---

**Built with evidence from the agent trenches.**

*"Satyameva Jayate — Truth Alone Triumphs"*
