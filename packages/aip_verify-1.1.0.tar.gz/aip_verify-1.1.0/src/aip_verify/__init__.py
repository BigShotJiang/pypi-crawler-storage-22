"""
Agent Integrity Protocol (AIP) - Python SDK

Cryptographic verification, permission manifests, and reputation scoring
for AI agent skills.

Example:
    from aip_verify import AIPVerifier, TrustPolicy
    
    policy = TrustPolicy(min_reputation=80)
    verifier = AIPVerifier(policy)
    result = verifier.verify("./my-skill/")
    
    if result.trusted:
        print(f"Verified: {result.manifest.author.name}")
    else:
        print(f"Rejected: {result.rejection_reason}")
"""

from .verifier import (
    AIPVerifier,
    TrustPolicy,
    VerificationResult,
    SecurityViolation,
    IntegrityManifest,
    Author,
    Permissions,
)

__version__ = "1.1.0"
__all__ = [
    "AIPVerifier",
    "TrustPolicy", 
    "VerificationResult",
    "SecurityViolation",
    "IntegrityManifest",
    "Author",
    "Permissions",
    "__version__",
]
