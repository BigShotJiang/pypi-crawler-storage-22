"""
AIP Command Line Interface

Usage:
    aip verify <skill_path>
    aip --version
"""

import argparse
import sys
from pathlib import Path

from .verifier import AIPVerifier, TrustPolicy


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="aip",
        description="Agent Integrity Protocol - Verify AI agent skills"
    )
    parser.add_argument(
        "--version", "-v",
        action="version",
        version="aip-verify 1.1.0"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # verify command
    verify_parser = subparsers.add_parser("verify", help="Verify a skill")
    verify_parser.add_argument("skill_path", help="Path to skill directory")
    verify_parser.add_argument(
        "--min-reputation", "-r",
        type=int,
        default=80,
        help="Minimum reputation score (default: 80)"
    )
    verify_parser.add_argument(
        "--no-signature",
        action="store_true",
        help="Don't require signature"
    )
    verify_parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON"
    )
    
    args = parser.parse_args()
    
    if args.command == "verify":
        return verify_skill(args)
    else:
        parser.print_help()
        return 1


def verify_skill(args):
    """Verify a skill against AIP."""
    import json as json_module
    
    skill_path = Path(args.skill_path)
    if not skill_path.exists():
        print(f"Error: Path not found: {skill_path}", file=sys.stderr)
        return 1
    
    policy = TrustPolicy(
        min_reputation=args.min_reputation,
        require_signature=not args.no_signature
    )
    
    verifier = AIPVerifier(policy)
    result = verifier.verify(str(skill_path))
    
    if args.json:
        output = {
            "trusted": result.trusted,
            "signature_valid": result.signature_valid,
            "hash_valid": result.hash_valid,
            "reputation": result.reputation,
            "rejection_reason": result.rejection_reason,
            "violations": [
                {
                    "category": v.category,
                    "severity": v.severity,
                    "message": v.message,
                    "evidence": v.evidence,
                    "mitigation": v.mitigation
                }
                for v in result.violations
            ]
        }
        if result.manifest:
            output["manifest"] = {
                "name": result.manifest.name,
                "version": result.manifest.version,
                "author": {
                    "did": result.manifest.author.did,
                    "name": result.manifest.author.name
                }
            }
        print(json_module.dumps(output, indent=2))
    else:
        if result.manifest:
            print(f"🔍 Verifying skill: {result.manifest.name} v{result.manifest.version}")
            print("─" * 50)
            
            status = "✅" if result.signature_valid else "❌"
            print(f"{status} Signature: {'valid' if result.signature_valid else 'invalid'}")
            
            status = "✅" if result.hash_valid else "❌"
            print(f"{status} Hash: {'matches' if result.hash_valid else 'mismatch'}")
            
            rep_status = "✅" if result.reputation >= policy.min_reputation else "⚠️"
            print(f"{rep_status} Reputation: {result.reputation}/100")
            
            print(f"   Author: {result.manifest.author.name}")
            print(f"   DID: {result.manifest.author.did}")
        
        if result.violations:
            print(f"\n⚠️  Security Violations ({len(result.violations)}):")
            for v in result.violations:
                severity_icon = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}.get(v.severity, "⚪")
                print(f"   {severity_icon} [{v.category}] {v.message}")
        
        print()
        if result.trusted:
            print("✅ TRUSTED - Skill passed verification")
            return 0
        else:
            print(f"❌ REJECTED - {result.rejection_reason}")
            return 1


if __name__ == "__main__":
    sys.exit(main())
