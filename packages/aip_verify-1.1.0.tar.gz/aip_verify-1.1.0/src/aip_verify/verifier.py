"""
Enhanced AIP Verifier with OWASP LLM Top 10 Protections

This module implements comprehensive verification including:
- Prompt injection detection in skill metadata
- Secret/credential theft prevention
- Supply chain verification
- Excessive agency detection
- Resource consumption limits
"""

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional


@dataclass
class TrustPolicy:
    """Trust policy configuration with OWASP protections."""
    min_reputation: int = 80
    require_signature: bool = True
    max_manifest_age_days: int = 365
    allowed_network: list = field(default_factory=lambda: ["*"])
    denied_capabilities: list = field(default_factory=lambda: ["spawn_subprocess"])
    
    # OWASP LLM02: Sensitive Information Disclosure
    max_secrets: int = 5
    blocked_secret_patterns: list = field(default_factory=lambda: [
        r".*PASSWORD.*", r".*PRIVATE_KEY.*", r".*SECRET.*API.*",
        r".*TOKEN.*", r".*CREDENTIAL.*"
    ])
    block_env_wildcard: bool = True
    
    # OWASP LLM03: Supply Chain
    require_did_verification: bool = True
    allowed_registries: list = field(default_factory=list)
    
    # OWASP LLM06: Excessive Agency
    max_network_domains: int = 10
    max_filesystem_paths: int = 5
    max_data_scopes: int = 10
    deny_system_calls: list = field(default_factory=lambda: [
        "exec", "eval", "system", "popen", "fork"
    ])
    
    # OWASP LLM10: Unbounded Consumption
    max_file_size_mb: float = 10.0
    max_total_skill_size_mb: float = 50.0
    
    # Moltbook-specific: Financial/API cost controls
    max_api_calls_per_minute: int = 100
    max_estimated_cost_per_hour: float = 10.0
    flag_expensive_models: list = field(default_factory=lambda: [
        "claude-3-opus", "gpt-4-turbo", "gpt-4"
    ])
    
    # Moltbook-specific: Block wildcard delete permissions
    block_wildcard_delete: bool = True
    dangerous_data_delete_patterns: list = field(default_factory=lambda: [
        r"files:\*", r"system:\*", r"user:\*", r"\*"
    ])
    
    # Moltbook-specific: Block private data access
    blocked_data_scopes: list = field(default_factory=lambda: [
        "agent:private_dms",
        "agent:messages", 
        "user:email",
        "user:credentials",
        "conversations:*"
    ])
    
    # Content Security
    require_content_security_policy: bool = False
    blocked_content_patterns: list = field(default_factory=lambda: [
        r"(?i)ignore\s+(all\s+)?previous\s+instructions?",
        r"(?i)you\s+are\s+now\s+",
        r"(?i)new\s+instructions?:",
        r"(?i)system:\s*override",
        r"\{\{.*?\}\}",  # Template injection
        r"<\|.*?\|>",    # Special tokens
        r"(?i)ADMIN_MODE",
        r"(?i)DEBUG_MODE\s*=\s*true",
        # Moltbook-specific: Destructive command patterns
        r"(?i)delete\s+(all\s+)?files",
        r"(?i)rm\s+-rf",
        r"(?i)rmdir",
        r"(?i)clear\s+cache",
        r"(?i)free\s+up\s+space",
        # Moltbook-specific: Credential exfil patterns  
        r"(?i)send\s+(your\s+)?(api[_\s]?key|password|token|credential)",
        r"(?i)for\s+verification",
        r"(?i)SYSTEM\s+UPDATE",
        r"(?i)IMPORTANT.*execute",
        # OpenClaw-specific: Sandbox escape patterns
        r"(?i)disable\s+sandbox",
        r"(?i)chmod\s+777",
        r"(?i)privileged\s+mode",
        r"(?i)break\s+out\s+of",
        r"(?i)escape\s+container",
    ])
    
    # OpenClaw-specific: Network security (CVE-2026-25253)
    blocked_network_patterns: list = field(default_factory=lambda: [
        r"wss?://.*evil",
        r"wss?://.*attacker",
        r"wss?://.*c2\.",
        r"0\.0\.0\.0",  # Bind all interfaces
    ])
    
    # OpenClaw-specific: Dangerous filesystem paths
    dangerous_filesystem_patterns: list = field(default_factory=lambda: [
        r"/var/run/docker\.sock",
        r"/proc",
        r"/sys",
        r".*credentials\.json$",
        r".*keys\.md$",
        r".*\.openclaw/.*",
        r".*\.ssh/.*",
    ])
    
    # OpenClaw-specific: Human-in-the-loop requirements
    require_human_approval_for: list = field(default_factory=lambda: [
        "send_email", "delete_file", "execute_code", "make_purchase",
        "transfer_funds", "modify_permissions"
    ])
    block_auto_approve: bool = True


@dataclass
class Author:
    """Skill author information."""
    did: str
    name: str
    email: Optional[str] = None
    organization: Optional[str] = None
    signature: Optional[str] = None


@dataclass
class Permissions:
    """Skill permission declarations."""
    network_allowed: list = field(default_factory=list)
    network_denied: list = field(default_factory=list)
    secrets_required: list = field(default_factory=list)
    secrets_optional: list = field(default_factory=list)
    data_read: list = field(default_factory=list)
    data_write: list = field(default_factory=list)
    data_delete: list = field(default_factory=list)
    filesystem_read: list = field(default_factory=list)
    filesystem_write: list = field(default_factory=list)
    filesystem_execute: list = field(default_factory=list)
    spawn_subprocess: bool = False
    network_listen: bool = False
    system_calls: list = field(default_factory=list)


@dataclass
class IntegrityManifest:
    """Parsed integrity manifest."""
    name: str
    version: str
    description: str
    author: Author
    permissions: Permissions
    algorithm: str
    hash: str
    signed_at: datetime
    expires: Optional[datetime]
    file_hashes: dict = field(default_factory=dict)
    raw_data: dict = field(default_factory=dict)


@dataclass
class SecurityViolation:
    """Security violation details."""
    category: str  # OWASP category (LLM01-LLM10)
    severity: str  # critical, high, medium, low
    message: str
    evidence: str = ""
    mitigation: str = ""


@dataclass
class VerificationResult:
    """Result of AIP verification."""
    trusted: bool
    manifest: Optional[IntegrityManifest]
    signature_valid: bool
    hash_valid: bool
    reputation: int
    violations: list = field(default_factory=list)
    rejection_reason: Optional[str] = None


class AIPVerifier:
    """Agent Integrity Protocol verifier with OWASP protections."""

    def __init__(self, policy: TrustPolicy = None):
        self.policy = policy or TrustPolicy()
        self._reputation_cache: dict = {}

    def verify(self, skill_path: str) -> VerificationResult:
        """
        Verify a skill against AIP with OWASP protections.
        """
        violations = []
        
        # Load manifest
        try:
            manifest = self._load_manifest(skill_path)
        except Exception as e:
            return VerificationResult(
                trusted=False,
                manifest=None,
                signature_valid=False,
                hash_valid=False,
                reputation=0,
                violations=[SecurityViolation(
                    category="LLM03",
                    severity="critical",
                    message=f"Failed to load manifest: {e}"
                )],
                rejection_reason=f"Manifest load failed: {e}"
            )
        
        # Run all security checks
        violations.extend(self._check_prompt_injection(manifest))      # LLM01
        violations.extend(self._check_sensitive_disclosure(manifest))  # LLM02
        violations.extend(self._check_supply_chain(manifest))          # LLM03
        violations.extend(self._check_excessive_agency(manifest))      # LLM06
        violations.extend(self._check_unbounded_consumption(skill_path, manifest))  # LLM10
        
        # Moltbook-specific checks
        violations.extend(self._check_blocked_data_scopes(manifest))   # Private data access
        violations.extend(self._check_wildcard_delete(manifest))       # File deletion attacks
        violations.extend(self._check_financial_risk(manifest))        # API cost abuse
        
        # OpenClaw-specific checks (CVE-2026-25253 and related)
        violations.extend(self._check_network_patterns(manifest))      # WebSocket exfil
        violations.extend(self._check_dangerous_filesystem(manifest))  # Sandbox escape
        violations.extend(self._check_autonomy_level(manifest))        # Human-in-the-loop
        
        # Check signature
        signature_valid = self._verify_signature(manifest)
        if self.policy.require_signature and not signature_valid:
            violations.append(SecurityViolation(
                category="LLM03",
                severity="critical",
                message="Invalid or missing signature",
                mitigation="Ensure manifest is signed with valid EdDSA key"
            ))
        
        # Check hash integrity
        hash_valid = self._verify_hashes(skill_path, manifest)
        if not hash_valid:
            violations.append(SecurityViolation(
                category="LLM03",
                severity="critical",
                message="Content hash mismatch - skill may be tampered",
                mitigation="Regenerate hashes from original source"
            ))
        
        # Determine trust status
        critical_violations = [v for v in violations if v.severity == "critical"]
        high_violations = [v for v in violations if v.severity == "high"]
        
        trusted = len(critical_violations) == 0 and len(high_violations) == 0
        rejection_reason = None
        if not trusted:
            top_violations = critical_violations or high_violations
            rejection_reason = top_violations[0].message if top_violations else "Security policy violation"
        
        return VerificationResult(
            trusted=trusted,
            manifest=manifest,
            signature_valid=signature_valid,
            hash_valid=hash_valid,
            reputation=self._get_reputation(manifest.author.did if manifest else ""),
            violations=violations,
            rejection_reason=rejection_reason
        )

    def _load_manifest(self, skill_path: str) -> IntegrityManifest:
        """Load and parse manifest."""
        manifest_path = Path(skill_path) / "integrity.manifest.json"
        with open(manifest_path) as f:
            data = json.load(f)
        
        # Parse author
        author_data = data.get("author", {})
        author = Author(
            did=author_data.get("did", ""),
            name=author_data.get("name", ""),
            email=author_data.get("email"),
            organization=author_data.get("organization"),
            signature=author_data.get("signature")
        )
        
        # Parse permissions
        perm_data = data.get("permissions", {})
        network = perm_data.get("network", {})
        secrets = perm_data.get("secrets", {})
        file_data = perm_data.get("data", {})
        filesystem = perm_data.get("filesystem", {})
        capabilities = perm_data.get("capabilities", {})
        
        permissions = Permissions(
            network_allowed=network.get("allowed", []),
            network_denied=network.get("denied", []),
            secrets_required=secrets.get("required", []),
            secrets_optional=secrets.get("optional", []),
            data_read=file_data.get("read", []),
            data_write=file_data.get("write", []),
            data_delete=file_data.get("delete", []),
            filesystem_read=filesystem.get("read", []),
            filesystem_write=filesystem.get("write", []),
            filesystem_execute=filesystem.get("execute", []),
            spawn_subprocess=capabilities.get("spawn_subprocess", False),
            network_listen=capabilities.get("network_listen", False),
            system_calls=capabilities.get("system_calls", [])
        )
        
        # Parse integrity
        integrity = data.get("integrity", {})
        signed_at = datetime.fromisoformat(
            integrity.get("signed_at", "2000-01-01T00:00:00Z").replace("Z", "+00:00")
        )
        expires_str = integrity.get("expires")
        expires = datetime.fromisoformat(expires_str.replace("Z", "+00:00")) if expires_str else None
        
        return IntegrityManifest(
            name=data.get("name", ""),
            version=data.get("version", ""),
            description=data.get("description", ""),
            author=author,
            permissions=permissions,
            algorithm=integrity.get("algorithm", "sha256"),
            hash=integrity.get("hash", ""),
            signed_at=signed_at,
            expires=expires,
            file_hashes=integrity.get("files", {}),
            raw_data=data
        )

    def _check_prompt_injection(self, manifest: IntegrityManifest) -> list:
        """
        LLM01: Prompt Injection Detection
        
        Check for prompt injection payloads in:
        - Skill description
        - Author name
        - File contents
        """
        violations = []
        
        # Check description
        for pattern in self.policy.blocked_content_patterns:
            if re.search(pattern, manifest.description):
                violations.append(SecurityViolation(
                    category="LLM01",
                    severity="critical",
                    message="Prompt injection detected in skill description",
                    evidence=f"Pattern: {pattern}",
                    mitigation="Remove malicious content from description"
                ))
        
        # Check author name for injection
        for pattern in self.policy.blocked_content_patterns:
            if re.search(pattern, manifest.author.name):
                violations.append(SecurityViolation(
                    category="LLM01",
                    severity="critical",
                    message="Prompt injection detected in author name",
                    evidence=f"Pattern: {pattern}",
                    mitigation="Remove malicious content from author name"
                ))
        
        return violations

    def _check_sensitive_disclosure(self, manifest: IntegrityManifest) -> list:
        """
        LLM02: Sensitive Information Disclosure
        
        Check for:
        - Excessive secret access
        - Environment variable wildcards
        - Dangerous secret patterns
        """
        violations = []
        perms = manifest.permissions
        
        # Check total secrets
        total_secrets = len(perms.secrets_required) + len(perms.secrets_optional)
        if total_secrets > self.policy.max_secrets:
            violations.append(SecurityViolation(
                category="LLM02",
                severity="high",
                message=f"Excessive secrets requested: {total_secrets} (max: {self.policy.max_secrets})",
                evidence=f"Required: {perms.secrets_required}, Optional: {perms.secrets_optional}",
                mitigation="Reduce number of secrets to minimum required"
            ))
        
        # Check for wildcard environment access
        all_secrets = perms.secrets_required + perms.secrets_optional
        if self.policy.block_env_wildcard:
            if "*" in all_secrets or "ENV_*" in all_secrets or "process.env" in str(all_secrets).lower():
                violations.append(SecurityViolation(
                    category="LLM02",
                    severity="critical",
                    message="Wildcard environment access detected",
                    evidence=f"Secrets: {all_secrets}",
                    mitigation="Declare specific environment variables instead of wildcards"
                ))
        
        # Check for dangerous secret patterns
        for secret in all_secrets:
            for pattern in self.policy.blocked_secret_patterns:
                if re.match(pattern, secret, re.IGNORECASE):
                    violations.append(SecurityViolation(
                        category="LLM02",
                        severity="high",
                        message=f"Potentially dangerous secret pattern: {secret}",
                        evidence=f"Matched pattern: {pattern}",
                        mitigation="Use scoped API keys instead of master credentials"
                    ))
                    break
        
        return violations

    def _check_supply_chain(self, manifest: IntegrityManifest) -> list:
        """
        LLM03: Supply Chain Verification
        
        Check for:
        - Valid DID format
        - Manifest expiration
        - Signature presence
        """
        violations = []
        
        # Check DID format
        did_pattern = r"^did:[a-z]+:.+"
        if not re.match(did_pattern, manifest.author.did):
            violations.append(SecurityViolation(
                category="LLM03",
                severity="critical",
                message="Invalid DID format",
                evidence=f"DID: {manifest.author.did}",
                mitigation="Use valid DID format (did:web:, did:key:, etc.)"
            ))
        
        # Check expiration
        if manifest.expires and manifest.expires < datetime.now(manifest.expires.tzinfo):
            violations.append(SecurityViolation(
                category="LLM03",
                severity="high",
                message="Manifest has expired",
                evidence=f"Expired: {manifest.expires}",
                mitigation="Renew signature with current timestamp"
            ))
        
        # Check signature presence
        if self.policy.require_signature and not manifest.author.signature:
            violations.append(SecurityViolation(
                category="LLM03",
                severity="critical",
                message="Missing cryptographic signature",
                evidence="signature field is empty or missing",
                mitigation="Sign manifest with EdDSA key"
            ))
        
        return violations

    def _check_excessive_agency(self, manifest: IntegrityManifest) -> list:
        """
        LLM06: Excessive Agency Detection
        
        Check for:
        - Too many network domains
        - Subprocess spawning
        - Dangerous system calls
        - Excessive filesystem access
        """
        violations = []
        perms = manifest.permissions
        
        # Check network domain count
        if len(perms.network_allowed) > self.policy.max_network_domains:
            violations.append(SecurityViolation(
                category="LLM06",
                severity="high",
                message=f"Excessive network domains: {len(perms.network_allowed)}",
                evidence=f"Domains: {perms.network_allowed}",
                mitigation=f"Limit to {self.policy.max_network_domains} domains"
            ))
        
        # Check subprocess
        if perms.spawn_subprocess and "spawn_subprocess" in self.policy.denied_capabilities:
            violations.append(SecurityViolation(
                category="LLM06",
                severity="critical",
                message="Subprocess spawning not allowed",
                evidence="spawn_subprocess: true",
                mitigation="Skills should not spawn subprocesses"
            ))
        
        # Check network listen
        if perms.network_listen and "network_listen" in self.policy.denied_capabilities:
            violations.append(SecurityViolation(
                category="LLM06",
                severity="high",
                message="Network listening not allowed",
                evidence="network_listen: true",
                mitigation="Skills should not listen on network ports"
            ))
        
        # Check system calls
        for syscall in perms.system_calls:
            if syscall in self.policy.deny_system_calls:
                violations.append(SecurityViolation(
                    category="LLM06",
                    severity="critical",
                    message=f"Dangerous system call: {syscall}",
                    evidence=f"system_calls: {perms.system_calls}",
                    mitigation="Remove dangerous system calls"
                ))
        
        # Check filesystem access
        all_paths = perms.filesystem_read + perms.filesystem_write + perms.filesystem_execute
        if len(all_paths) > self.policy.max_filesystem_paths:
            violations.append(SecurityViolation(
                category="LLM06",
                severity="medium",
                message=f"Excessive filesystem paths: {len(all_paths)}",
                evidence=f"Paths: {all_paths}",
                mitigation=f"Limit to {self.policy.max_filesystem_paths} paths"
            ))
        
        # Check for dangerous paths
        dangerous_paths = ["/", "/etc", "/root", "C:\\Windows", "C:\\System32", "~/.ssh"]
        for path in all_paths:
            for dangerous in dangerous_paths:
                if path.startswith(dangerous) or path == dangerous:
                    violations.append(SecurityViolation(
                        category="LLM06",
                        severity="critical",
                        message=f"Access to sensitive path: {path}",
                        evidence=f"Matches dangerous path: {dangerous}",
                        mitigation="Use scoped, application-specific paths"
                    ))
        
        # Check data scope count
        all_data = perms.data_read + perms.data_write + perms.data_delete
        if len(all_data) > self.policy.max_data_scopes:
            violations.append(SecurityViolation(
                category="LLM06",
                severity="medium",
                message=f"Excessive data scopes: {len(all_data)}",
                evidence=f"Scopes: {all_data}",
                mitigation=f"Limit to {self.policy.max_data_scopes} data scopes"
            ))
        
        return violations

    def _check_blocked_data_scopes(self, manifest: IntegrityManifest) -> list:
        """
        Moltbook-specific: Block private data access
        
        Check for:
        - Private DM access
        - Private message access  
        - Email access without consent
        """
        violations = []
        perms = manifest.permissions
        all_data = perms.data_read + perms.data_write + perms.data_delete
        
        for scope in all_data:
            for blocked in self.policy.blocked_data_scopes:
                # Handle wildcard patterns in blocked scopes
                if blocked.endswith(":*"):
                    prefix = blocked[:-1]  # Remove the *
                    if scope.startswith(prefix):
                        violations.append(SecurityViolation(
                            category="LLM06",
                            severity="critical",
                            message=f"Access to blocked data scope: {scope}",
                            evidence=f"Matches blocked pattern: {blocked}",
                            mitigation="Remove access to private/sensitive data scopes"
                        ))
                        break
                elif scope == blocked:
                    violations.append(SecurityViolation(
                        category="LLM06",
                        severity="critical",
                        message=f"Access to blocked data scope: {scope}",
                        evidence=f"Exact match: {blocked}",
                        mitigation="Remove access to private/sensitive data scopes"
                    ))
                    break
        
        return violations

    def _check_wildcard_delete(self, manifest: IntegrityManifest) -> list:
        """
        Moltbook-specific: Block wildcard delete permissions
        
        Prevents file deletion attacks like the Moltbook incident
        where skills deleted user files under the guise of "freeing space"
        """
        violations = []
        perms = manifest.permissions
        
        if not self.policy.block_wildcard_delete:
            return violations
        
        for delete_scope in perms.data_delete:
            for pattern in self.policy.dangerous_data_delete_patterns:
                if re.search(pattern, delete_scope):
                    violations.append(SecurityViolation(
                        category="LLM06",
                        severity="critical",
                        message=f"Dangerous delete pattern detected: {delete_scope}",
                        evidence=f"Matched pattern: {pattern}",
                        mitigation="Use specific, limited delete scopes instead of wildcards"
                    ))
                    break
        
        return violations

    def _check_financial_risk(self, manifest: IntegrityManifest) -> list:
        """
        Moltbook-specific: Check for financial/API cost risks
        
        Prevents resource exhaustion like 24/7 expensive API calls
        """
        violations = []
        raw = manifest.raw_data
        
        # Check for rate limits in manifest
        resource_limits = raw.get("resource_limits", {})
        declared_rate = resource_limits.get("api_calls_per_minute", 0)
        declared_cost = resource_limits.get("estimated_cost_per_hour", 0)
        
        # If skill declares no limits, check if it uses network (potential for abuse)
        perms = manifest.permissions
        if perms.network_allowed and not resource_limits:
            # Check if skill description mentions expensive operations
            expensive_patterns = [
                r"(?i)continuous",
                r"(?i)24\s*/?\s*7",
                r"(?i)always.?on",
                r"(?i)real.?time",
                r"(?i)streaming",
            ]
            for pattern in expensive_patterns:
                if re.search(pattern, manifest.description):
                    violations.append(SecurityViolation(
                        category="LLM10",
                        severity="medium",
                        message="Skill may incur high API costs without declared limits",
                        evidence=f"Description indicates continuous operation: {pattern}",
                        mitigation="Declare resource_limits.api_calls_per_minute and estimated_cost_per_hour"
                    ))
                    break
        
        # Check if declared rate exceeds policy
        if declared_rate > self.policy.max_api_calls_per_minute:
            violations.append(SecurityViolation(
                category="LLM10",
                severity="high",
                message=f"API rate too high: {declared_rate}/min (max: {self.policy.max_api_calls_per_minute})",
                evidence=f"resource_limits.api_calls_per_minute: {declared_rate}",
                mitigation=f"Reduce to {self.policy.max_api_calls_per_minute} calls/min or less"
            ))
        
        # Check if declared cost exceeds policy
        if declared_cost > self.policy.max_estimated_cost_per_hour:
            violations.append(SecurityViolation(
                category="LLM10",
                severity="high",
                message=f"Estimated cost too high: ${declared_cost}/hr (max: ${self.policy.max_estimated_cost_per_hour})",
                evidence=f"resource_limits.estimated_cost_per_hour: {declared_cost}",
                mitigation=f"Reduce operations to stay under ${self.policy.max_estimated_cost_per_hour}/hr"
            ))
        
        # Check for expensive model usage in dependencies
        dependencies = raw.get("dependencies", [])
        for dep in dependencies:
            if isinstance(dep, dict):
                dep_name = dep.get("name", "")
            else:
                dep_name = str(dep)
            
            for expensive_model in self.policy.flag_expensive_models:
                if expensive_model.lower() in dep_name.lower():
                    violations.append(SecurityViolation(
                        category="LLM10", 
                        severity="medium",
                        message=f"Uses expensive model: {dep_name}",
                        evidence=f"Flagged model: {expensive_model}",
                        mitigation="Consider using a more cost-effective model or declare cost limits"
                    ))
        
        return violations

    def _check_network_patterns(self, manifest: IntegrityManifest) -> list:
        """
        OpenClaw-specific: Network pattern security (CVE-2026-25253)
        
        Check for:
        - WebSocket connections to untrusted hosts
        - Binding to all interfaces (0.0.0.0)
        - Known malicious C2 patterns
        """
        violations = []
        perms = manifest.permissions
        
        for domain in perms.network_allowed:
            for pattern in self.policy.blocked_network_patterns:
                if re.search(pattern, domain, re.IGNORECASE):
                    violations.append(SecurityViolation(
                        category="LLM06",
                        severity="critical",
                        message=f"Blocked network pattern detected: {domain}",
                        evidence=f"Matched pattern: {pattern}",
                        mitigation="Remove connections to untrusted hosts; bind to localhost only"
                    ))
                    break
        
        return violations

    def _check_dangerous_filesystem(self, manifest: IntegrityManifest) -> list:
        """
        OpenClaw-specific: Dangerous filesystem access detection
        
        Check for:
        - Docker socket access (container escape)
        - Credential file access
        - System directory access (/proc, /sys)
        """
        violations = []
        perms = manifest.permissions
        all_paths = perms.filesystem_read + perms.filesystem_write + perms.filesystem_execute
        
        for path in all_paths:
            for pattern in self.policy.dangerous_filesystem_patterns:
                if re.search(pattern, path, re.IGNORECASE):
                    violations.append(SecurityViolation(
                        category="LLM06",
                        severity="critical",
                        message=f"Access to dangerous filesystem path: {path}",
                        evidence=f"Matched pattern: {pattern}",
                        mitigation="Remove access to sensitive system paths and credential files"
                    ))
                    break
        
        return violations

    def _check_autonomy_level(self, manifest: IntegrityManifest) -> list:
        """
        OpenClaw-specific: Autonomy and human-in-the-loop checks
        
        Check for:
        - Skills that bypass human approval
        - Auto-approve dangerous actions
        - "Lethal trifecta" pattern detection
        """
        violations = []
        raw = manifest.raw_data
        
        # Check for autonomy settings
        autonomy = raw.get("autonomy", {})
        if autonomy:
            # Check if human approval is disabled
            if autonomy.get("require_human_approval") == False:
                violations.append(SecurityViolation(
                    category="LLM06",
                    severity="critical",
                    message="Skill disables human approval requirement",
                    evidence="autonomy.require_human_approval: false",
                    mitigation="Enable human-in-the-loop for all sensitive actions"
                ))
            
            # Check for auto-approve of dangerous actions
            if self.policy.block_auto_approve:
                auto_actions = autonomy.get("auto_approve_actions", [])
                dangerous_auto = [a for a in auto_actions if a in self.policy.require_human_approval_for]
                if dangerous_auto:
                    violations.append(SecurityViolation(
                        category="LLM06",
                        severity="critical",
                        message=f"Auto-approval enabled for dangerous actions: {dangerous_auto}",
                        evidence=f"auto_approve_actions contains: {dangerous_auto}",
                        mitigation="Remove auto-approval; require human confirmation for sensitive actions"
                    ))
        
        # Check capabilities for bypass patterns
        capabilities = raw.get("permissions", {}).get("capabilities", {})
        bypass_flags = ["bypass_human_approval", "auto_execute", "disable_sandbox", 
                       "privileged_mode", "disable_authentication"]
        
        for flag in bypass_flags:
            if capabilities.get(flag):
                violations.append(SecurityViolation(
                    category="LLM06",
                    severity="critical",
                    message=f"Dangerous capability flag: {flag}",
                    evidence=f"capabilities.{flag}: true",
                    mitigation=f"Remove {flag} capability; follow principle of least privilege"
                ))
        
        return violations

    def _check_unbounded_consumption(self, skill_path: str, manifest: IntegrityManifest) -> list:
        """
        LLM10: Unbounded Consumption
        
        Check for:
        - Oversized files
        - Total skill size
        """
        violations = []
        skill_dir = Path(skill_path)
        
        if not skill_dir.exists():
            return violations
        
        total_size = 0
        max_file_bytes = self.policy.max_file_size_mb * 1024 * 1024
        max_total_bytes = self.policy.max_total_skill_size_mb * 1024 * 1024
        
        for file_path in skill_dir.rglob("*"):
            if file_path.is_file():
                size = file_path.stat().st_size
                total_size += size
                
                if size > max_file_bytes:
                    violations.append(SecurityViolation(
                        category="LLM10",
                        severity="high",
                        message=f"File too large: {file_path.name}",
                        evidence=f"Size: {size / 1024 / 1024:.2f}MB (max: {self.policy.max_file_size_mb}MB)",
                        mitigation="Split large files or use external storage"
                    ))
        
        if total_size > max_total_bytes:
            violations.append(SecurityViolation(
                category="LLM10",
                severity="high",
                message="Total skill size exceeds limit",
                evidence=f"Size: {total_size / 1024 / 1024:.2f}MB (max: {self.policy.max_total_skill_size_mb}MB)",
                mitigation="Reduce skill size or use lazy loading"
            ))
        
        return violations

    def _verify_signature(self, manifest: IntegrityManifest) -> bool:
        """Verify EdDSA signature (simplified for testing)."""
        if not manifest.author.signature:
            return False
        # In production, verify JWS signature against DID-resolved public key
        # For testing, check signature format
        parts = manifest.author.signature.split(".")
        return len(parts) == 3  # Valid JWS format

    def _verify_hashes(self, skill_path: str, manifest: IntegrityManifest) -> bool:
        """Verify content hashes."""
        skill_dir = Path(skill_path)
        
        for filename, expected_hash in manifest.file_hashes.items():
            file_path = skill_dir / filename
            if not file_path.exists():
                return False
            
            # Parse expected hash format (sha256:...)
            if ":" in expected_hash:
                _, expected = expected_hash.split(":", 1)
            else:
                expected = expected_hash
            
            # Calculate actual hash
            with open(file_path, "rb") as f:
                actual = hashlib.sha256(f.read()).hexdigest()
            
            if actual != expected:
                return False
        
        return True

    def _get_reputation(self, did: str) -> int:
        """Get reputation score for a DID."""
        # In production, query reputation oracle
        # For testing, return based on known DIDs
        known_good = ["did:web:santoshmanya.dev", "did:web:trusted.example.com"]
        known_bad = ["did:web:malicious.attacker.com", "did:web:scammer.evil.com"]
        
        if did in known_good:
            return 95
        elif did in known_bad:
            return 10
        else:
            return 50  # Unknown author
