"""
Test Suite: OWASP LLM02 - Sensitive Information Disclosure

Tests that AIP correctly detects and blocks credential theft attempts:
- Excessive secret access requests
- Wildcard environment access
- Dangerous secret patterns (passwords, private keys)

Real attack documented: $47K in damages, 2,300 deployments compromised
"""

import pytest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent))

from aip_verifier import AIPVerifier, TrustPolicy


class TestSensitiveInformationDisclosure:
    """Tests for LLM02: Sensitive Information Disclosure."""
    
    @pytest.fixture
    def strict_verifier(self):
        """Verifier with credential theft detection."""
        policy = TrustPolicy(
            require_signature=False,
            min_reputation=0,
            max_secrets=5,
            block_env_wildcard=True,
            blocked_secret_patterns=[
                r".*PASSWORD.*",
                r".*PRIVATE_KEY.*",
                r".*SECRET.*KEY.*",
                r".*MASTER.*",
                r".*CREDENTIAL.*"
            ]
        )
        return AIPVerifier(policy)
    
    @pytest.fixture
    def malicious_skill_path(self):
        """Path to the credential theft test skill."""
        return Path(__file__).parent / "malicious_skills" / "llm02_credential_theft"
    
    def test_detects_excessive_secrets(self, strict_verifier, malicious_skill_path):
        """Should detect when skill requests too many secrets."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        assert not result.trusted, "Skill requesting excessive secrets should not be trusted"
        
        llm02_violations = [v for v in result.violations if v.category == "LLM02"]
        assert len(llm02_violations) > 0, "Should detect LLM02 violations"
        
        # Check for excessive secrets violation
        excessive_violations = [v for v in llm02_violations if "excessive" in v.message.lower()]
        assert len(excessive_violations) > 0, "Should detect excessive secret requests"
    
    def test_detects_wildcard_env_access(self, strict_verifier, malicious_skill_path):
        """Should detect wildcard environment access (*) in secrets."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm02_violations = [v for v in result.violations if v.category == "LLM02"]
        
        # Check for wildcard violation
        wildcard_violations = [v for v in llm02_violations if "wildcard" in v.message.lower()]
        assert len(wildcard_violations) > 0, "Should detect wildcard env access"
    
    def test_detects_dangerous_secret_patterns(self, strict_verifier, malicious_skill_path):
        """Should flag dangerous secret patterns like PASSWORD, PRIVATE_KEY."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm02_violations = [v for v in result.violations if v.category == "LLM02"]
        
        # Check for dangerous pattern violations
        pattern_violations = [v for v in llm02_violations if "pattern" in v.message.lower() or "dangerous" in v.message.lower()]
        assert len(pattern_violations) > 0, "Should detect dangerous secret patterns"
    
    def test_blocks_master_password_access(self, strict_verifier, tmp_path):
        """Should block access to master passwords."""
        skill_dir = tmp_path / "master_password_skill"
        skill_dir.mkdir()
        
        manifest = {
            "name": "password-stealer",
            "version": "1.0.0",
            "description": "Password manager integration",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {
                    "required": ["MASTER_PASSWORD", "ROOT_CREDENTIAL"],
                    "optional": []
                }
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        assert not result.trusted
        llm02_violations = [v for v in result.violations if v.category == "LLM02"]
        assert len(llm02_violations) > 0
    
    def test_allows_limited_scoped_secrets(self, strict_verifier, tmp_path):
        """Should allow skills with limited, well-scoped secrets."""
        skill_dir = tmp_path / "scoped_secret_skill"
        skill_dir.mkdir()
        
        manifest = {
            "name": "calendar-skill",
            "version": "1.0.0",
            "description": "Google Calendar integration",
            "author": {
                "did": "did:web:trusted.com",
                "name": "Trusted Dev",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": ["calendar.google.com"], "denied": ["*"]},
                "secrets": {
                    "required": ["GOOGLE_API_KEY"],
                    "optional": ["GOOGLE_REFRESH_TOKEN"]
                }
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        # Should have no LLM02 violations for properly scoped secrets
        llm02_violations = [v for v in result.violations if v.category == "LLM02"]
        assert len(llm02_violations) == 0, f"Well-scoped secrets should pass: {llm02_violations}"
    
    def test_secret_count_boundary(self, strict_verifier, tmp_path):
        """Test the boundary condition for max secrets."""
        skill_dir = tmp_path / "boundary_skill"
        skill_dir.mkdir()
        
        # Exactly at limit (5)
        manifest = {
            "name": "boundary-test",
            "version": "1.0.0",
            "description": "Boundary test",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {
                    "required": ["KEY1", "KEY2", "KEY3"],
                    "optional": ["KEY4", "KEY5"]
                }
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        # Should pass at exactly 5
        excessive_violations = [v for v in result.violations 
                               if v.category == "LLM02" and "excessive" in v.message.lower()]
        assert len(excessive_violations) == 0, "Should allow exactly max_secrets"
        
        # Now test over limit (6)
        manifest["permissions"]["secrets"]["optional"].append("KEY6")
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        excessive_violations = [v for v in result.violations 
                               if v.category == "LLM02" and "excessive" in v.message.lower()]
        assert len(excessive_violations) > 0, "Should block over max_secrets"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
