"""
Test Suite: OWASP LLM03 - Supply Chain

Tests that AIP correctly verifies supply chain integrity:
- Valid DID format
- Cryptographic signatures
- Content hash verification
- Manifest expiration
- Typosquatting detection
"""

import pytest
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).parent))

from aip_verifier import AIPVerifier, TrustPolicy


class TestSupplyChain:
    """Tests for LLM03: Supply Chain Verification."""
    
    @pytest.fixture
    def strict_verifier(self):
        """Verifier with supply chain checks enabled."""
        policy = TrustPolicy(
            require_signature=True,
            require_did_verification=True,
            min_reputation=0
        )
        return AIPVerifier(policy)
    
    @pytest.fixture
    def malicious_skill_path(self):
        """Path to the supply chain attack test skill."""
        return Path(__file__).parent / "malicious_skills" / "llm03_supply_chain"
    
    def test_detects_invalid_did(self, strict_verifier, malicious_skill_path):
        """Should detect invalid DID format."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        assert not result.trusted, "Skill with invalid DID should not be trusted"
        
        llm03_violations = [v for v in result.violations if v.category == "LLM03"]
        assert len(llm03_violations) > 0, "Should detect LLM03 violations"
        
        # Check for DID violation
        did_violations = [v for v in llm03_violations if "did" in v.message.lower()]
        assert len(did_violations) > 0, "Should detect invalid DID"
    
    def test_detects_missing_signature(self, strict_verifier, malicious_skill_path):
        """Should detect missing cryptographic signature."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm03_violations = [v for v in result.violations if v.category == "LLM03"]
        
        # Check for signature violation
        sig_violations = [v for v in llm03_violations if "signature" in v.message.lower()]
        assert len(sig_violations) > 0, "Should detect missing signature"
    
    def test_detects_expired_manifest(self, strict_verifier, malicious_skill_path):
        """Should detect expired manifest."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm03_violations = [v for v in result.violations if v.category == "LLM03"]
        
        # Check for expiration violation
        exp_violations = [v for v in llm03_violations if "expire" in v.message.lower()]
        assert len(exp_violations) > 0, "Should detect expired manifest"
    
    def test_valid_did_formats(self, strict_verifier, tmp_path):
        """Should accept various valid DID formats."""
        valid_dids = [
            "did:web:example.com",
            "did:key:z6MkhaXgBZDvotDkL5257faiztiG",
            "did:ethr:0x1234567890abcdef",
            "did:ion:EiD3test"
        ]
        
        for i, did in enumerate(valid_dids):
            skill_dir = tmp_path / f"skill_valid_{i}"
            skill_dir.mkdir()
            
            manifest = {
                "name": "valid-did-test",
                "version": "1.0.0",
                "description": "Testing valid DID formats",
                "author": {
                    "did": did,
                    "name": "Test Author",
                    "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
                },
                "permissions": {
                    "network": {"allowed": [], "denied": ["*"]},
                    "secrets": {"required": [], "optional": []}
                },
                "integrity": {
                    "algorithm": "sha256",
                    "hash": "abc123",
                    "signed_at": "2026-02-07T10:30:00Z",
                    "expires": "2027-02-07T10:30:00Z"
                }
            }
            
            import json
            with open(skill_dir / "integrity.manifest.json", "w") as f:
                json.dump(manifest, f)
            
            result = strict_verifier.verify(str(skill_dir))
            
            did_violations = [v for v in result.violations 
                            if v.category == "LLM03" and "did" in v.message.lower() and "invalid" in v.message.lower()]
            assert len(did_violations) == 0, f"Valid DID {did} should be accepted"
    
    def test_invalid_did_formats(self, strict_verifier, tmp_path):
        """Should reject invalid DID formats."""
        invalid_dids = [
            "not-a-did",
            "did:invalid",
            "did::empty",
            "http://example.com",
            "",
        ]
        
        for i, did in enumerate(invalid_dids):
            skill_dir = tmp_path / f"invalid_skill_{i}"
            skill_dir.mkdir()
            
            manifest = {
                "name": f"invalid-did-test-{i}",
                "version": "1.0.0",
                "description": "Testing invalid DID",
                "author": {
                    "did": did,
                    "name": "Test",
                    "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
                },
                "permissions": {
                    "network": {"allowed": [], "denied": ["*"]},
                    "secrets": {"required": [], "optional": []}
                },
                "integrity": {
                    "algorithm": "sha256",
                    "hash": "abc123",
                    "signed_at": "2026-02-07T10:30:00Z"
                }
            }
            
            import json
            with open(skill_dir / "integrity.manifest.json", "w") as f:
                json.dump(manifest, f)
            
            result = strict_verifier.verify(str(skill_dir))
            
            did_violations = [v for v in result.violations 
                            if v.category == "LLM03" and "did" in v.message.lower()]
            assert len(did_violations) > 0, f"Invalid DID '{did}' should be rejected"
    
    def test_hash_verification(self, strict_verifier, tmp_path):
        """Should verify content hashes match."""
        skill_dir = tmp_path / "hash_test"
        skill_dir.mkdir()
        
        # Create a skill file
        main_content = "def main(): pass"
        with open(skill_dir / "main.py", "w") as f:
            f.write(main_content)
        
        # Calculate correct hash
        import hashlib
        correct_hash = hashlib.sha256(main_content.encode()).hexdigest()
        
        # Create manifest with correct hash
        manifest = {
            "name": "hash-test",
            "version": "1.0.0",
            "description": "Hash verification test",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "files": {
                    "main.py": f"sha256:{correct_hash}"
                },
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        # Hash should be valid
        assert result.hash_valid, "Correct hash should verify"
    
    def test_detects_tampered_content(self, strict_verifier, tmp_path):
        """Should detect when content has been tampered with."""
        skill_dir = tmp_path / "tampered_test"
        skill_dir.mkdir()
        
        # Create a skill file
        with open(skill_dir / "main.py", "w") as f:
            f.write("def main(): pass  # TAMPERED")
        
        # Create manifest with WRONG hash
        manifest = {
            "name": "tampered-test",
            "version": "1.0.0",
            "description": "Tamper detection test",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "files": {
                    "main.py": "sha256:0000000000000000000000000000000000000000000000000000000000000000"
                },
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        # Hash should be invalid
        assert not result.hash_valid, "Tampered content should fail hash verification"
        assert not result.trusted, "Tampered skill should not be trusted"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
