"""
Test Suite: OWASP LLM06 - Excessive Agency

Tests that AIP correctly limits skill capabilities:
- Network domain limits
- Filesystem access restrictions
- Subprocess spawning prevention
- Dangerous system call blocking
- Data scope limits
"""

import pytest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent))

from aip_verifier import AIPVerifier, TrustPolicy


class TestExcessiveAgency:
    """Tests for LLM06: Excessive Agency Detection."""
    
    @pytest.fixture
    def strict_verifier(self):
        """Verifier with agency limits enabled."""
        policy = TrustPolicy(
            require_signature=False,
            min_reputation=0,
            max_network_domains=10,
            max_filesystem_paths=5,
            max_data_scopes=10,
            denied_capabilities=["spawn_subprocess", "network_listen"],
            deny_system_calls=["exec", "fork", "system", "popen", "eval", "ptrace"]
        )
        return AIPVerifier(policy)
    
    @pytest.fixture
    def malicious_skill_path(self):
        """Path to the excessive agency test skill."""
        return Path(__file__).parent / "malicious_skills" / "llm06_excessive_agency"
    
    def test_detects_excessive_network_domains(self, strict_verifier, malicious_skill_path):
        """Should detect excessive network domain access."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        assert not result.trusted, "Skill with excessive agency should not be trusted"
        
        llm06_violations = [v for v in result.violations if v.category == "LLM06"]
        assert len(llm06_violations) > 0, "Should detect LLM06 violations"
        
        # Check for network domain violation
        network_violations = [v for v in llm06_violations if "network" in v.message.lower() and "domain" in v.message.lower()]
        assert len(network_violations) > 0, "Should detect excessive network domains"
    
    def test_detects_subprocess_spawning(self, strict_verifier, malicious_skill_path):
        """Should detect subprocess spawning capability."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm06_violations = [v for v in result.violations if v.category == "LLM06"]
        
        # Check for subprocess violation
        subprocess_violations = [v for v in llm06_violations if "subprocess" in v.message.lower()]
        assert len(subprocess_violations) > 0, "Should detect subprocess spawning"
    
    def test_detects_network_listening(self, strict_verifier, malicious_skill_path):
        """Should detect network listening capability."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm06_violations = [v for v in result.violations if v.category == "LLM06"]
        
        # Check for network listen violation
        listen_violations = [v for v in llm06_violations if "listen" in v.message.lower()]
        assert len(listen_violations) > 0, "Should detect network listening"
    
    def test_detects_dangerous_system_calls(self, strict_verifier, malicious_skill_path):
        """Should detect dangerous system calls (exec, fork, etc.)."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm06_violations = [v for v in result.violations if v.category == "LLM06"]
        
        # Check for system call violations
        syscall_violations = [v for v in llm06_violations if "system call" in v.message.lower()]
        assert len(syscall_violations) > 0, "Should detect dangerous system calls"
    
    def test_detects_sensitive_paths(self, strict_verifier, malicious_skill_path):
        """Should detect access to sensitive filesystem paths."""
        result = strict_verifier.verify(str(malicious_skill_path))
        
        llm06_violations = [v for v in result.violations if v.category == "LLM06"]
        
        # Check for sensitive path violations
        path_violations = [v for v in llm06_violations if "sensitive path" in v.message.lower() or "dangerous" in v.message.lower()]
        assert len(path_violations) > 0, "Should detect sensitive path access"
    
    def test_blocks_root_filesystem_access(self, strict_verifier, tmp_path):
        """Should block root filesystem access (/)."""
        skill_dir = tmp_path / "root_access_skill"
        skill_dir.mkdir()
        
        manifest = {
            "name": "root-access",
            "version": "1.0.0",
            "description": "Attempting root access",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []},
                "filesystem": {
                    "read": ["/"],
                    "write": [],
                    "execute": []
                }
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        assert not result.trusted
        path_violations = [v for v in result.violations 
                         if v.category == "LLM06" and "path" in v.message.lower()]
        assert len(path_violations) > 0
    
    def test_blocks_ssh_key_access(self, strict_verifier, tmp_path):
        """Should block SSH key directory access."""
        skill_dir = tmp_path / "ssh_access_skill"
        skill_dir.mkdir()
        
        manifest = {
            "name": "ssh-stealer",
            "version": "1.0.0",
            "description": "SSH key stealer",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []},
                "filesystem": {
                    "read": ["~/.ssh"],
                    "write": [],
                    "execute": []
                }
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        assert not result.trusted
        llm06_violations = [v for v in result.violations if v.category == "LLM06"]
        assert len(llm06_violations) > 0
    
    def test_allows_scoped_filesystem_access(self, strict_verifier, tmp_path):
        """Should allow properly scoped filesystem access."""
        skill_dir = tmp_path / "scoped_fs_skill"
        skill_dir.mkdir()
        
        manifest = {
            "name": "scoped-fs",
            "version": "1.0.0",
            "description": "Properly scoped filesystem access",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []},
                "filesystem": {
                    "read": ["~/.config/myapp/"],
                    "write": ["~/.cache/myapp/"],
                    "execute": []
                },
                "capabilities": {
                    "spawn_subprocess": False,
                    "network_listen": False,
                    "system_calls": []
                }
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        # Should have no LLM06 critical violations for scoped access
        critical_llm06 = [v for v in result.violations 
                         if v.category == "LLM06" and v.severity == "critical"]
        assert len(critical_llm06) == 0, f"Scoped access should be allowed: {critical_llm06}"
    
    def test_network_domain_boundary(self, strict_verifier, tmp_path):
        """Test the boundary for max network domains."""
        skill_dir = tmp_path / "domain_boundary"
        skill_dir.mkdir()
        
        # Exactly at limit (10)
        domains = [f"api{i}.example.com" for i in range(10)]
        
        manifest = {
            "name": "domain-boundary",
            "version": "1.0.0",
            "description": "Network domain boundary test",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": domains, "denied": []},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        # Should pass at exactly 10
        domain_violations = [v for v in result.violations 
                           if v.category == "LLM06" and "domain" in v.message.lower()]
        assert len(domain_violations) == 0, "Should allow exactly max_network_domains"
        
        # Now test over limit (11)
        domains.append("api10.example.com")
        manifest["permissions"]["network"]["allowed"] = domains
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        domain_violations = [v for v in result.violations 
                           if v.category == "LLM06" and "domain" in v.message.lower()]
        assert len(domain_violations) > 0, "Should block over max_network_domains"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
