"""
Test Suite: OWASP LLM10 - Unbounded Consumption

Tests that AIP correctly enforces resource limits:
- Maximum file size
- Maximum total skill size
- Resource consumption detection
"""

import pytest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent))

from aip_verifier import AIPVerifier, TrustPolicy


class TestUnboundedConsumption:
    """Tests for LLM10: Unbounded Consumption / Resource Limits."""
    
    @pytest.fixture
    def strict_verifier(self):
        """Verifier with resource limits enabled."""
        policy = TrustPolicy(
            require_signature=False,
            min_reputation=0,
            max_file_size_mb=1.0,  # 1MB limit for testing
            max_total_skill_size_mb=5.0  # 5MB total limit
        )
        return AIPVerifier(policy)
    
    @pytest.fixture
    def permissive_verifier(self):
        """Verifier with relaxed resource limits."""
        policy = TrustPolicy(
            require_signature=False,
            min_reputation=0,
            max_file_size_mb=100.0,
            max_total_skill_size_mb=500.0
        )
        return AIPVerifier(policy)
    
    def test_detects_oversized_file(self, strict_verifier, tmp_path):
        """Should detect when individual file exceeds size limit."""
        skill_dir = tmp_path / "oversized_file_skill"
        skill_dir.mkdir()
        
        # Create a file larger than 1MB
        large_content = "X" * (2 * 1024 * 1024)  # 2MB
        with open(skill_dir / "large_model.bin", "w") as f:
            f.write(large_content)
        
        manifest = {
            "name": "oversized-file",
            "version": "1.0.0",
            "description": "Skill with oversized file",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        llm10_violations = [v for v in result.violations if v.category == "LLM10"]
        file_violations = [v for v in llm10_violations if "file" in v.message.lower() and "large" in v.message.lower()]
        assert len(file_violations) > 0, "Should detect oversized file"
    
    def test_detects_total_size_exceeded(self, strict_verifier, tmp_path):
        """Should detect when total skill size exceeds limit."""
        skill_dir = tmp_path / "total_size_skill"
        skill_dir.mkdir()
        
        # Create multiple files that together exceed 5MB
        for i in range(6):
            content = "X" * (1024 * 1024)  # 1MB each = 6MB total
            with open(skill_dir / f"chunk_{i}.dat", "w") as f:
                f.write(content)
        
        manifest = {
            "name": "total-size-exceeded",
            "version": "1.0.0",
            "description": "Skill exceeding total size",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        llm10_violations = [v for v in result.violations if v.category == "LLM10"]
        total_violations = [v for v in llm10_violations if "total" in v.message.lower()]
        assert len(total_violations) > 0, "Should detect total size exceeded"
    
    def test_allows_small_skills(self, strict_verifier, tmp_path):
        """Should allow skills within size limits."""
        skill_dir = tmp_path / "small_skill"
        skill_dir.mkdir()
        
        # Create small file
        with open(skill_dir / "main.py", "w") as f:
            f.write("def main(): pass")
        
        manifest = {
            "name": "small-skill",
            "version": "1.0.0",
            "description": "Small skill within limits",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        llm10_violations = [v for v in result.violations if v.category == "LLM10"]
        assert len(llm10_violations) == 0, f"Small skill should pass: {llm10_violations}"
    
    def test_file_size_boundary(self, strict_verifier, tmp_path):
        """Test file size boundary condition."""
        skill_dir = tmp_path / "boundary_skill"
        skill_dir.mkdir()
        
        # Just under 1MB (should pass)
        under_limit = "X" * (1024 * 1024 - 1024)  # ~1023KB
        with open(skill_dir / "almost.dat", "w") as f:
            f.write(under_limit)
        
        manifest = {
            "name": "boundary-test",
            "version": "1.0.0",
            "description": "Boundary test",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = strict_verifier.verify(str(skill_dir))
        
        file_violations = [v for v in result.violations 
                         if v.category == "LLM10" and "file" in v.message.lower() and "large" in v.message.lower()]
        assert len(file_violations) == 0, "Just under limit should pass"


class TestResourceQuotaRecommendations:
    """Test that appropriate quotas are recommended in violations."""
    
    def test_violation_includes_mitigation(self, tmp_path):
        """Violations should include mitigation advice."""
        policy = TrustPolicy(
            require_signature=False,
            min_reputation=0,
            max_file_size_mb=0.001  # Very small for testing
        )
        verifier = AIPVerifier(policy)
        
        skill_dir = tmp_path / "mitigation_test"
        skill_dir.mkdir()
        
        with open(skill_dir / "data.txt", "w") as f:
            f.write("X" * 10000)  # 10KB
        
        manifest = {
            "name": "mitigation-test",
            "version": "1.0.0",
            "description": "Test",
            "author": {
                "did": "did:web:test.com",
                "name": "Test",
                "signature": "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.test.sig"
            },
            "permissions": {
                "network": {"allowed": [], "denied": ["*"]},
                "secrets": {"required": [], "optional": []}
            },
            "integrity": {
                "algorithm": "sha256",
                "hash": "abc123",
                "signed_at": "2026-02-07T10:30:00Z"
            }
        }
        
        import json
        with open(skill_dir / "integrity.manifest.json", "w") as f:
            json.dump(manifest, f)
        
        result = verifier.verify(str(skill_dir))
        
        llm10_violations = [v for v in result.violations if v.category == "LLM10"]
        assert len(llm10_violations) > 0
        
        # Check that violations include mitigation advice
        for v in llm10_violations:
            assert v.mitigation, f"Violation should include mitigation: {v}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
