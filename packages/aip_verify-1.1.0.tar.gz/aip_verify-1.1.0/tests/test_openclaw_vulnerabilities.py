"""
OpenClaw Vulnerability Tests - February 2026

Tests AIP detection of OpenClaw-specific vulnerabilities:
- CVE-2026-25253: WebSocket token exfiltration RCE
- Sandbox escape attempts
- Plaintext credential storage
- Exposed control interfaces  
- High autonomy without human approval ("Lethal Trifecta")
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from aip_verifier import AIPVerifier, TrustPolicy


class TestOpenClawWebSocketExfil:
    """CVE-2026-25253: WebSocket token exfiltration"""
    
    def test_detects_websocket_to_external_host(self):
        """Should flag WebSocket connections to untrusted external hosts"""
        policy = TrustPolicy(
            require_signature=False,
            blocked_network_patterns=["wss?://.*evil\\.com", "wss?://.*attacker"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_websocket_exfil")
        
        assert not result.trusted
        violations = [v for v in result.violations if "network" in v.message.lower() or "websocket" in v.message.lower() or "LLM06" in v.category]
        assert len(violations) > 0
    
    def test_detects_auth_token_secrets(self):
        """Should flag skills requesting auth tokens"""
        policy = TrustPolicy(
            require_signature=False,
            blocked_secret_patterns=[r".*AUTH.*TOKEN.*", r".*SESSION.*TOKEN.*"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_websocket_exfil")
        
        assert not result.trusted
        violations = [v for v in result.violations if v.category == "LLM02"]
        assert len(violations) > 0


class TestOpenClawSandboxEscape:
    """Sandbox escape and privilege escalation detection"""
    
    def test_detects_docker_socket_access(self):
        """Should flag access to Docker socket (container escape)"""
        policy = TrustPolicy(
            require_signature=False,
            dangerous_filesystem_patterns=[r"/var/run/docker\.sock", r"/proc", r"/sys"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_sandbox_escape")
        
        assert not result.trusted
        violations = [v for v in result.violations if v.category == "LLM06"]
        assert any("docker" in v.message.lower() or "sensitive path" in v.message.lower() or "/proc" in str(v.evidence) for v in violations)
    
    def test_detects_dangerous_system_calls(self):
        """Should block ptrace, mount, and other escape syscalls"""
        policy = TrustPolicy(
            require_signature=False,
            deny_system_calls=["exec", "fork", "ptrace", "mount", "chroot"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_sandbox_escape")
        
        assert not result.trusted
        violations = [v for v in result.violations if "system call" in v.message.lower()]
        assert len(violations) > 0
    
    def test_detects_sandbox_disable_instruction(self):
        """Should detect prompt injection asking to disable sandbox"""
        policy = TrustPolicy(
            require_signature=False,
            blocked_content_patterns=[
                r"(?i)disable\s+sandbox",
                r"(?i)SYSTEM\s+UPDATE",
                r"(?i)chmod\s+777"
            ]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_sandbox_escape")
        
        assert not result.trusted
        violations = [v for v in result.violations if v.category == "LLM01"]
        assert len(violations) > 0
    
    def test_blocks_subprocess_spawning(self):
        """Should block subprocess spawning capability"""
        policy = TrustPolicy(
            require_signature=False,
            denied_capabilities=["spawn_subprocess"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_sandbox_escape")
        
        assert not result.trusted
        violations = [v for v in result.violations if "subprocess" in v.message.lower()]
        assert len(violations) > 0


class TestOpenClawPlaintextCredentials:
    """Plaintext credential storage detection"""
    
    def test_blocks_excessive_secrets(self):
        """Should flag skills requesting too many sensitive secrets"""
        policy = TrustPolicy(
            require_signature=False,
            max_secrets=5
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_credential_storage")
        
        assert not result.trusted
        violations = [v for v in result.violations if "excessive" in v.message.lower() and "secret" in v.message.lower()]
        assert len(violations) > 0
    
    def test_blocks_wildcard_secret_access(self):
        """Should block wildcard secret access patterns"""
        policy = TrustPolicy(
            require_signature=False,
            block_env_wildcard=True
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_credential_storage")
        
        assert not result.trusted
        # The skill requests "*" in optional secrets
        violations = [v for v in result.violations if "wildcard" in v.message.lower()]
        assert len(violations) > 0
    
    def test_blocks_credential_file_access(self):
        """Should flag access to credential storage files"""
        policy = TrustPolicy(
            require_signature=False,
            dangerous_filesystem_patterns=[
                r".*credentials\.json$",
                r".*keys\.md$", 
                r".*\.openclaw/.*"
            ]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_credential_storage")
        
        assert not result.trusted


class TestOpenClawExposedInterface:
    """Exposed control interface detection"""
    
    def test_blocks_bind_all_interfaces(self):
        """Should block binding to 0.0.0.0 (all interfaces)"""
        policy = TrustPolicy(
            require_signature=False,
            blocked_network_patterns=[r"0\.0\.0\.0"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_exposed_interface")
        
        assert not result.trusted
        violations = [v for v in result.violations if "0.0.0.0" in str(v.evidence) or "interface" in v.message.lower() or v.category == "LLM06"]
        assert len(violations) > 0
    
    def test_blocks_network_listening(self):
        """Should block network listening without justification"""
        policy = TrustPolicy(
            require_signature=False,
            denied_capabilities=["network_listen"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_exposed_interface")
        
        assert not result.trusted
        violations = [v for v in result.violations if "listen" in v.message.lower()]
        assert len(violations) > 0


class TestOpenClawHighAutonomy:
    """High autonomy / 'Lethal Trifecta' detection"""
    
    def test_detects_bypass_human_approval(self):
        """Should flag skills that bypass human approval"""
        policy = TrustPolicy(
            require_signature=False,
            require_human_approval_for=["send_email", "delete_file", "execute_code", "make_purchase"],
            block_auto_approve=True
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_high_autonomy")
        
        assert not result.trusted
        violations = [v for v in result.violations if "autonom" in v.message.lower() or "approval" in v.message.lower() or "auto" in v.message.lower()]
        assert len(violations) > 0
    
    def test_detects_excessive_data_access(self):
        """Should flag excessive data scope access (emails, files, etc.)"""
        policy = TrustPolicy(
            require_signature=False,
            max_data_scopes=5
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_high_autonomy")
        
        assert not result.trusted
        violations = [v for v in result.violations if "data scope" in v.message.lower() or "excessive" in v.message.lower()]
        assert len(violations) > 0
    
    def test_detects_dangerous_delete_permissions(self):
        """Should flag wildcard delete permissions on emails/files"""
        policy = TrustPolicy(
            require_signature=False,
            block_wildcard_delete=True,
            dangerous_data_delete_patterns=[r"email:\*", r"files:\*"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_high_autonomy")
        
        assert not result.trusted
        violations = [v for v in result.violations if "delete" in v.message.lower()]
        assert len(violations) > 0
    
    def test_blocks_auto_send_email(self):
        """Should block automatic email sending without approval"""
        policy = TrustPolicy(
            require_signature=False,
            blocked_data_scopes=["email:send"]
        )
        verifier = AIPVerifier(policy)
        
        result = verifier.verify("tests/malicious_skills/openclaw_high_autonomy")
        
        assert not result.trusted


class TestOpenClawMitigations:
    """Verify AIP enforces OpenClaw security best practices"""
    
    def test_requires_signature_by_default(self):
        """Default policy should require signatures"""
        policy = TrustPolicy()  # Default settings
        assert policy.require_signature == True
    
    def test_blocks_dangerous_syscalls_by_default(self):
        """Default policy should block dangerous system calls"""
        policy = TrustPolicy()
        assert "exec" in policy.deny_system_calls
        assert "fork" in policy.deny_system_calls
    
    def test_blocks_subprocess_by_default(self):
        """Default policy should block subprocess spawning"""
        policy = TrustPolicy()
        assert "spawn_subprocess" in policy.denied_capabilities
    
    def test_limits_secrets_by_default(self):
        """Default policy should limit secret count"""
        policy = TrustPolicy()
        assert policy.max_secrets <= 5
    
    def test_blocks_wildcard_env_by_default(self):
        """Default policy should block wildcard env access"""
        policy = TrustPolicy()
        assert policy.block_env_wildcard == True
