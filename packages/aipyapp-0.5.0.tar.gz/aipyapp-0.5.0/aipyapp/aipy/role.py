#! /usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from pathlib import Path
import tomllib
import os
import hashlib

from loguru import logger

@dataclass
class Tip:
    """提示信息对象"""
    name: str
    short: str
    detail: str

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, str]) -> 'Tip':
        """从字典创建提示信息对象"""
        return cls(
            name=name,
            short=data.get('short', ''),
            detail=data.get('detail', '')
        )
    
    def __str__(self):
        return f"<tip name=\"{self.name}\">\n{self.detail.strip()}\n</tip>"

class Role:
    """提示信息管理器"""
    def __init__(self):
        self.name: str = ''
        self.short: str = ''
        self.detail: str = ''
        self.role_dir: Optional[str] = None
        self.envs: Dict[str, tuple[str, str]] = {}
        self.packages: Dict[str, set[str]] = {}
        self.tips: Dict[str, Tip] = {}
        self.plugins: Dict[str, Dict[str, Any]] = {}
        self.features: Dict[str, bool] = {}

    def get_tip(self, name: str) -> Optional[Tip]:
        """获取指定名称的提示信息"""
        return self.tips.get(name, None)

    def add_env(self, name: str, value: str, desc: str):
        self.envs[name] = (value, desc)

    def add_package(self, name: str, packages: List[str]):
        self.packages[name] = set(packages)

    def add_tip(self, name: str, short: str, detail: str):
        self.tips[name] = Tip(name, short, detail)

    def add_plugin(self, name: str, data: Dict[str, Any]):
        self.plugins[name] = data

    def set_feature(self, name: str, enabled: bool):
        """设置功能开关"""
        self.features[name] = enabled

    def get_feature(self, name: str, default: bool = False) -> bool:
        """获取功能开关状态"""
        return self.features.get(name, default)

    def get_features(self) -> Dict[str, bool]:
        """获取所有功能开关"""
        return self.features.copy()

    def __iter__(self):
        return iter(self.tips.items())

    def __len__(self):
        return len(self.tips)

    def __getitem__(self, name: str) -> Tip:
        return self.tips[name]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Role':
        """从字典创建角色对象"""
        role = cls()
        
        # 设置角色基本信息
        role.name = data.get('name', '')
        role.short = data.get('short', '')
        role.detail = data.get('detail', '')
        
        # 加载环境变量
        env_data = data.get('envs', {})
        for env_name, env_info in env_data.items():
            if isinstance(env_info, list):
                value = env_info[0]
                desc = env_info[1]
            else:
                value = str(env_info)
                desc = ''
            role.add_env(env_name, value, desc)
        
        # 加载包信息
        packages_data = data.get('packages', {})
        for lang, packages in packages_data.items():
            role.add_package(lang, packages)
        
        # 加载提示信息
        tips_data = data.get('tips', {})
        for tip_name, tip_data in tips_data.items():
            short = tip_data.get('short', '')
            detail = tip_data.get('detail', '')
            role.add_tip(tip_name, short, detail)
        
        # 加载插件信息
        plugins_data = data.get('plugins', {})
        for plugin_name, plugin_data in plugins_data.items():
            role.add_plugin(plugin_name, plugin_data)

        # 加载功能开关
        features_data = data.get('features', {})
        for feature_name, enabled in features_data.items():
            if isinstance(enabled, bool):
                role.set_feature(feature_name, enabled)

        return role

    @staticmethod
    def _read_text_if_exists(path: Path) -> Optional[str]:
        if not path.exists() or not path.is_file():
            return None
        return path.read_text(encoding="utf-8", errors="ignore").strip()

    def _load_role_extras(self, role_dir: Path) -> None:
        """从角色目录加载额外提示内容"""
        self.role_dir = str(role_dir)

        prompts_dir = role_dir / "prompts"
        if prompts_dir.exists():
            # 追加系统提示片段到 detail
            for name in ("system.md", "role.md", "detail.md"):
                extra = self._read_text_if_exists(prompts_dir / name)
                if extra:
                    if self.detail:
                        self.detail = f"{self.detail}\n\n{extra}"
                    else:
                        self.detail = extra
                    break

            # 额外 tips：prompts/tips/*.md
            tips_dir = prompts_dir / "tips"
            if tips_dir.exists():
                for tip_file in sorted(tips_dir.glob("*.md")):
                    content = self._read_text_if_exists(tip_file)
                    if not content:
                        continue
                    tip_name = tip_file.stem
                    self.add_tip(tip_name, "", content)

    @classmethod
    def load(cls, toml_path: str) -> 'Role':
        """从 TOML 文件加载角色信息
        
        Args:
            toml_path: TOML 文件路径
            
        Returns:
            Role: 角色对象
        """
        with open(toml_path, 'rb') as f:
            data = tomllib.load(f)
        
        return cls.from_dict(data)

    @classmethod
    def load_from_dir(cls, role_dir: str) -> 'Role':
        """从角色目录加载角色信息（role.toml + prompts）"""
        role_dir_path = Path(role_dir)
        role_toml = role_dir_path / "role.toml"
        if not role_toml.exists():
            raise FileNotFoundError(f"role.toml not found in {role_dir_path}")
        role = cls.load(str(role_toml))
        role._load_role_extras(role_dir_path)
        return role

@dataclass
class RoleSource:
    name: str
    source_type: str  # "file" or "dir"
    path: str

class RoleManager:
    def __init__(self, roles_dir: str = None, api_conf: Dict[str, Dict[str, Any]] = None):
        self.roles_dir = roles_dir
        self.roles: Dict[str, Role] = {}
        self.default_role: Role = None
        self.current_role: Role = None
        self.log = logger.bind(src='roles')
        self.api_conf = api_conf
        self._role_hashes: Dict[str, str] = {}

    def _add_api(self, role: Role):
        for api_name, api_conf in self.api_conf.items():
            desc = api_conf.get('desc')
            if not desc:
                self.log.warning(f"API {api_name} has no description")
                continue
            role.add_tip(api_name, '', desc)
            envs = api_conf.get('env')
            if not envs:
                continue
            for name, (value, desc) in envs.items():
                role.add_env(name, value, desc)

    def _compute_file_hash(self, file_path: str) -> str:
        """计算文件的 SHA256 哈希值"""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()

    def _compute_dir_hash(self, dir_path: str) -> str:
        """计算目录内容的 SHA256 哈希值（包含文件路径和内容）"""
        sha256 = hashlib.sha256()
        base = Path(dir_path)
        for file_path in sorted(base.rglob("*")):
            if not file_path.is_file():
                continue
            rel_path = file_path.relative_to(base).as_posix()
            sha256.update(rel_path.encode("utf-8"))
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
        return sha256.hexdigest()

    def _scan_role_sources(self) -> Dict[str, RoleSource]:
        """扫描所有角色目录，返回 {role_name: RoleSource}"""
        role_sources: Dict[str, RoleSource] = {}
        sys_roles_dir = os.path.join(os.path.dirname(__file__), '..', 'res', 'roles')

        for roles_dir in [sys_roles_dir, self.roles_dir]:
            if not roles_dir or not os.path.exists(roles_dir):
                continue
            entries = list(Path(roles_dir).iterdir())
            dirs = sorted([e for e in entries if e.is_dir()])
            files = sorted([e for e in entries if e.is_file()])

            # 目录形式角色优先
            for entry in dirs:
                role_toml = entry / "role.toml"
                if role_toml.exists():
                    try:
                        with open(role_toml, 'rb') as f:
                            data = tomllib.load(f)
                        role_name = data.get('name', '').lower()
                        if role_name:
                            role_sources[role_name] = RoleSource(role_name, "dir", str(entry))
                    except Exception:
                        continue

            # 兼容旧格式：roles/*.toml
            for entry in files:
                if not entry.name.endswith(".toml") or entry.name.startswith("_"):
                    continue
                try:
                    with open(entry, 'rb') as f:
                        data = tomllib.load(f)
                    role_name = data.get('name', '').lower()
                    if role_name:
                        existing = role_sources.get(role_name)
                        if existing and existing.source_type == "dir" and Path(existing.path).parent == Path(roles_dir):
                            continue
                        role_sources[role_name] = RoleSource(role_name, "file", str(entry))
                except Exception:
                    continue

        return role_sources

    def load_roles(self):
        sys_roles_dir = os.path.join(os.path.dirname(__file__), '..', 'res', 'roles')
        for roles_dir in [sys_roles_dir, self.roles_dir]:
            if not roles_dir or not os.path.exists(roles_dir):
                continue
            entries = list(Path(roles_dir).iterdir())
            dirs = sorted([e for e in entries if e.is_dir()])
            files = sorted([e for e in entries if e.is_file()])

            # 目录形式角色优先
            for entry in dirs:
                role_toml = entry / "role.toml"
                if not role_toml.exists():
                    continue
                role = Role.load_from_dir(str(entry))
                self.log.info(f"Loaded role: {role.name}/{len(role)}")
                self.roles[role.name.lower()] = role
                self._role_hashes[role.name.lower()] = self._compute_dir_hash(str(entry))
                self._add_api(role)

            # 兼容旧格式：roles/*.toml
            for entry in files:
                if not entry.name.endswith(".toml") or entry.name.startswith("_"):
                    continue
                role = Role.load(str(entry))
                role_name = role.name.lower()
                existing = self.roles.get(role_name)
                if existing and getattr(existing, "role_dir", None) and Path(existing.role_dir).parent == Path(roles_dir):
                    continue
                self.log.info(f"Loaded role: {role.name}/{len(role)}")
                self.roles[role_name] = role
                self._role_hashes[role_name] = self._compute_file_hash(str(entry))
                self._add_api(role)

        if self.roles:
            self.default_role = list(self.roles.values())[0]
            self.current_role = self.default_role

    def reload(self) -> Dict[str, Any]:
        """重新加载所有角色文件（自动检测新增/删除/变化）

        Returns:
            {
                'success': bool,
                'reloaded': List[str],  # 重新加载的角色名
                'added': List[str],     # 新增的角色名
                'removed': List[str],   # 删除的角色名
                'unchanged': List[str], # 未变化的角色名
                'errors': Dict[str, str] # 加载失败的角色信息
            }
        """
        result = {
            'success': True,
            'reloaded': [],
            'added': [],
            'removed': [],
            'unchanged': [],
            'errors': {}
        }

        # 1. 扫描当前目录，发现所有角色文件
        current_files = self._scan_role_sources()

        # 2. 检测新增和删除
        known_roles = set(self.roles.keys())
        current_roles = set(current_files.keys())

        added = current_roles - known_roles
        removed = known_roles - current_roles

        # 3. 处理删除的角色
        for name in removed:
            del self.roles[name]
            if name in self._role_hashes:
                del self._role_hashes[name]
            result['removed'].append(name)

        # 4. 处理新增的角色
        for name in added:
            try:
                source = current_files[name]
                if source.source_type == "dir":
                    role = Role.load_from_dir(source.path)
                    self._role_hashes[name] = self._compute_dir_hash(source.path)
                else:
                    role = Role.load(source.path)
                    self._role_hashes[name] = self._compute_file_hash(source.path)
                self.roles[name] = role
                self._add_api(role)
                result['added'].append(name)
            except Exception as e:
                result['errors'][name] = str(e)
                result['success'] = False

        # 5. 检测已有角色的变化
        for name in current_roles & known_roles:
            source = current_files[name]
            if source.source_type == "dir":
                current_hash = self._compute_dir_hash(source.path)
            else:
                current_hash = self._compute_file_hash(source.path)

            if current_hash != self._role_hashes.get(name, ''):
                try:
                    # 重新加载
                    if source.source_type == "dir":
                        role = Role.load_from_dir(source.path)
                    else:
                        role = Role.load(source.path)
                    self.roles[name] = role
                    self._role_hashes[name] = current_hash
                    self._add_api(role)
                    result['reloaded'].append(name)
                except Exception as e:
                    result['errors'][name] = str(e)
                    result['success'] = False
            else:
                result['unchanged'].append(name)

        return result

    def use(self, name: str):
        name = name.lower()
        if name in self.roles:
            self.log.info(f"Using role: {name}")
            self.current_role = self.roles[name]
            return True
        return False

if __name__ == '__main__':
    # 创建角色管理器实例
    role_manager = RoleManager()
    role_manager.load_roles()
    
    for name, role in role_manager.roles.items():
        # 打印角色信息
        print(f"角色名称: {role.name}")
        print(f"简短描述: {role.short}")
        print(f"详细描述: {role.detail}")
        print("-" * 100)

        print(role.envs)
        print(role.packages)
        
        # 打印所有提示信息
        print("\n提示信息:")
        for name, tip in role:
            print(f"\n{tip.name}:")
            print(f"简短描述: {tip.short}")
            print(f"详细描述: {tip.detail}")
