# Airtable changelog

## [0.1.0] - 2026-01-29
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7dbd4946
- SDK version: 0.1.0
