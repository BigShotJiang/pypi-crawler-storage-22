# Airtable changelog

## [0.1.4] - 2026-01-30
- Updated connector definition (YAML version 1.0.2)
- Source commit: b184da3e
- SDK version: 0.1.0

## [0.1.3] - 2026-01-30
- Updated connector definition (YAML version 1.0.2)
- Source commit: 5f65d643
- SDK version: 0.1.0

## [0.1.2] - 2026-01-30
- Updated connector definition (YAML version 1.0.1)
- Source commit: 5b20f488
- SDK version: 0.1.0

## [0.1.1] - 2026-01-30
- Updated connector definition (YAML version 1.0.1)
- Source commit: a3729d85
- SDK version: 0.1.0

## [0.1.0] - 2026-01-29
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7dbd4946
- SDK version: 0.1.0
