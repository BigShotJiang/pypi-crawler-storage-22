# Facebook Marketing changelog

## [0.1.26] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: cddf6b9f
- SDK version: 0.1.0

## [0.1.25] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: 481be654
- SDK version: 0.1.0

## [0.1.24] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: 271d94f6
- SDK version: 0.1.0

## [0.1.23] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: c081aa11
- SDK version: 0.1.0

## [0.1.22] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: 72bd32a3
- SDK version: 0.1.0

## [0.1.21] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: 3e4f6ea0
- SDK version: 0.1.0

## [0.1.20] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: 0c907160
- SDK version: 0.1.0

## [0.1.19] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: aceb0c64
- SDK version: 0.1.0

## [0.1.18] - 2026-02-05
- Updated connector definition (YAML version 1.0.14)
- Source commit: def0e484
- SDK version: 0.1.0

## [0.1.17] - 2026-02-04
- Updated connector definition (YAML version 1.0.14)
- Source commit: 5c699b63
- SDK version: 0.1.0

## [0.1.16] - 2026-02-04
- Updated connector definition (YAML version 1.0.14)
- Source commit: 7aef2bc0
- SDK version: 0.1.0

## [0.1.15] - 2026-02-04
- Updated connector definition (YAML version 1.0.13)
- Source commit: 9d088ae9
- SDK version: 0.1.0

## [0.1.14] - 2026-02-04
- Updated connector definition (YAML version 1.0.12)
- Source commit: f1d25ecb
- SDK version: 0.1.0

## [0.1.13] - 2026-02-04
- Updated connector definition (YAML version 1.0.11)
- Source commit: 30d23e05
- SDK version: 0.1.0

## [0.1.12] - 2026-02-03
- Updated connector definition (YAML version 1.0.11)
- Source commit: 5ef2158e
- SDK version: 0.1.0

## [0.1.11] - 2026-02-03
- Updated connector definition (YAML version 1.0.11)
- Source commit: 5c6dbf88
- SDK version: 0.1.0

## [0.1.10] - 2026-02-03
- Updated connector definition (YAML version 1.0.11)
- Source commit: faf61dad
- SDK version: 0.1.0

## [0.1.9] - 2026-02-03
- Updated connector definition (YAML version 1.0.10)
- Source commit: 888d0538
- SDK version: 0.1.0

## [0.1.8] - 2026-02-03
- Updated connector definition (YAML version 1.0.9)
- Source commit: c007cfdb
- SDK version: 0.1.0

## [0.1.7] - 2026-02-02
- Updated connector definition (YAML version 1.0.8)
- Source commit: 94024675
- SDK version: 0.1.0

## [0.1.6] - 2026-02-02
- Updated connector definition (YAML version 1.0.3)
- Source commit: 9d9866b0
- SDK version: 0.1.0

## [0.1.5] - 2026-01-30
- Updated connector definition (YAML version 1.0.3)
- Source commit: b184da3e
- SDK version: 0.1.0

## [0.1.4] - 2026-01-30
- Updated connector definition (YAML version 1.0.3)
- Source commit: 0c205510
- SDK version: 0.1.0

## [0.1.3] - 2026-01-30
- Updated connector definition (YAML version 1.0.2)
- Source commit: 5f65d643
- SDK version: 0.1.0

## [0.1.2] - 2026-01-30
- Updated connector definition (YAML version 1.0.1)
- Source commit: 5b20f488
- SDK version: 0.1.0

## [0.1.1] - 2026-01-30
- Updated connector definition (YAML version 1.0.1)
- Source commit: a3729d85
- SDK version: 0.1.0

## [0.1.0] - 2026-01-29
- Updated connector definition (YAML version 1.0.1)
- Source commit: e00f35b0
- SDK version: 0.1.0
