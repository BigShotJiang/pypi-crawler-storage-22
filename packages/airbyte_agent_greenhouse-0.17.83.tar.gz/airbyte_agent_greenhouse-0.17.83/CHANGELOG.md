# Greenhouse changelog

## [0.17.83] - 2026-02-05
- Updated connector definition (YAML version 0.1.5)
- Source commit: 72bd32a3
- SDK version: 0.1.0

## [0.17.82] - 2026-02-05
- Updated connector definition (YAML version 0.1.5)
- Source commit: 3e4f6ea0
- SDK version: 0.1.0

## [0.17.81] - 2026-02-05
- Updated connector definition (YAML version 0.1.5)
- Source commit: 0c907160
- SDK version: 0.1.0

## [0.17.80] - 2026-02-05
- Updated connector definition (YAML version 0.1.5)
- Source commit: aceb0c64
- SDK version: 0.1.0

## [0.17.79] - 2026-02-05
- Updated connector definition (YAML version 0.1.5)
- Source commit: def0e484
- SDK version: 0.1.0

## [0.17.78] - 2026-02-04
- Updated connector definition (YAML version 0.1.5)
- Source commit: 5c699b63
- SDK version: 0.1.0

## [0.17.77] - 2026-02-04
- Updated connector definition (YAML version 0.1.5)
- Source commit: 7aef2bc0
- SDK version: 0.1.0

## [0.17.76] - 2026-02-04
- Updated connector definition (YAML version 0.1.4)
- Source commit: 30d23e05
- SDK version: 0.1.0

## [0.17.75] - 2026-02-03
- Updated connector definition (YAML version 0.1.4)
- Source commit: 5ef2158e
- SDK version: 0.1.0

## [0.17.74] - 2026-02-03
- Updated connector definition (YAML version 0.1.4)
- Source commit: 5c6dbf88
- SDK version: 0.1.0

## [0.17.73] - 2026-02-02
- Updated connector definition (YAML version 0.1.4)
- Source commit: 94024675
- SDK version: 0.1.0

## [0.17.72] - 2026-02-02
- Updated connector definition (YAML version 0.1.4)
- Source commit: 9d9866b0
- SDK version: 0.1.0

## [0.17.71] - 2026-01-30
- Updated connector definition (YAML version 0.1.4)
- Source commit: b184da3e
- SDK version: 0.1.0

## [0.17.70] - 2026-01-30
- Updated connector definition (YAML version 0.1.4)
- Source commit: 5b20f488
- SDK version: 0.1.0

## [0.17.69] - 2026-01-30
- Updated connector definition (YAML version 0.1.4)
- Source commit: a3729d85
- SDK version: 0.1.0

## [0.17.68] - 2026-01-29
- Updated connector definition (YAML version 0.1.4)
- Source commit: 43200eed
- SDK version: 0.1.0

## [0.17.67] - 2026-01-29
- Updated connector definition (YAML version 0.1.4)
- Source commit: c718c683
- SDK version: 0.1.0

## [0.17.66] - 2026-01-28
- Updated connector definition (YAML version 0.1.4)
- Source commit: 97007bbd
- SDK version: 0.1.0

## [0.17.65] - 2026-01-28
- Updated connector definition (YAML version 0.1.4)
- Source commit: f6c6fca2
- SDK version: 0.1.0

## [0.17.64] - 2026-01-28
- Updated connector definition (YAML version 0.1.4)
- Source commit: 71f48c10
- SDK version: 0.1.0

## [0.17.63] - 2026-01-27
- Updated connector definition (YAML version 0.1.4)
- Source commit: 0f5e1914
- SDK version: 0.1.0

## [0.17.62] - 2026-01-27
- Updated connector definition (YAML version 0.1.4)
- Source commit: a01f6b16
- SDK version: 0.1.0

## [0.17.61] - 2026-01-27
- Updated connector definition (YAML version 0.1.4)
- Source commit: c9b05509
- SDK version: 0.1.0

## [0.17.60] - 2026-01-27
- Updated connector definition (YAML version 0.1.3)
- Source commit: 4bded58d
- SDK version: 0.1.0

## [0.17.59] - 2026-01-26
- Updated connector definition (YAML version 0.1.3)
- Source commit: 74809153
- SDK version: 0.1.0

## [0.17.58] - 2026-01-26
- Updated connector definition (YAML version 0.1.3)
- Source commit: b73c71e0
- SDK version: 0.1.0

## [0.17.57] - 2026-01-24
- Updated connector definition (YAML version 0.1.3)
- Source commit: 609c1d86
- SDK version: 0.1.0

## [0.17.56] - 2026-01-23
- Updated connector definition (YAML version 0.1.3)
- Source commit: 32c5ef46
- SDK version: 0.1.0

## [0.17.55] - 2026-01-23
- Updated connector definition (YAML version 0.1.2)
- Source commit: 416466da
- SDK version: 0.1.0

## [0.17.54] - 2026-01-23
- Updated connector definition (YAML version 0.1.2)
- Source commit: f17cdd8c
- SDK version: 0.1.0

## [0.17.53] - 2026-01-22
- Updated connector definition (YAML version 0.1.2)
- Source commit: 49e6dfe9
- SDK version: 0.1.0

## [0.17.52] - 2026-01-22
- Updated connector definition (YAML version 0.1.2)
- Source commit: b27328e2
- SDK version: 0.1.0

## [0.17.51] - 2026-01-22
- Updated connector definition (YAML version 0.1.2)
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.17.50] - 2026-01-22
- Updated connector definition (YAML version 0.1.2)
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.17.49] - 2026-01-21
- Updated connector definition (YAML version 0.1.2)
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.17.48] - 2026-01-19
- Updated connector definition (YAML version 0.1.2)
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.17.47] - 2026-01-16
- Updated connector definition (YAML version 0.1.2)
- Source commit: a50c8f71
- SDK version: 0.1.0

## [0.17.46] - 2026-01-16
- Updated connector definition (YAML version 0.1.2)
- Source commit: 49673b7b
- SDK version: 0.1.0

## [0.17.45] - 2026-01-16
- Updated connector definition (YAML version 0.1.2)
- Source commit: ca5acdda
- SDK version: 0.1.0

## [0.17.44] - 2026-01-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: fa9a3b02
- SDK version: 0.1.0

## [0.17.43] - 2026-01-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: 61a2e822
- SDK version: 0.1.0

## [0.17.42] - 2026-01-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: 35211193
- SDK version: 0.1.0

## [0.17.41] - 2026-01-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: 20b3afd9
- SDK version: 0.1.0

## [0.17.40] - 2026-01-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: b7138b41
- SDK version: 0.1.0

## [0.17.39] - 2026-01-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: 10173eb1
- SDK version: 0.1.0

## [0.17.38] - 2026-01-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: a23d9e7a
- SDK version: 0.1.0

## [0.17.37] - 2026-01-14
- Updated connector definition (YAML version 0.1.2)
- Source commit: 7ef09816
- SDK version: 0.1.0

## [0.17.36] - 2026-01-14
- Updated connector definition (YAML version 0.1.2)
- Source commit: e6285db5
- SDK version: 0.1.0

## [0.17.35] - 2026-01-14
- Updated connector definition (YAML version 0.1.2)
- Source commit: 31de238d
- SDK version: 0.1.0

## [0.17.34] - 2026-01-13
- Updated connector definition (YAML version 0.1.2)
- Source commit: e80a226e
- SDK version: 0.1.0

## [0.17.33] - 2026-01-13
- Updated connector definition (YAML version 0.1.2)
- Source commit: 78b1be67
- SDK version: 0.1.0

## [0.17.32] - 2026-01-11
- Updated connector definition (YAML version 0.1.2)
- Source commit: e519b73d
- SDK version: 0.1.0

## [0.17.31] - 2026-01-09
- Updated connector definition (YAML version 0.1.2)
- Source commit: 3c7bfdfd
- SDK version: 0.1.0

## [0.17.30] - 2026-01-09
- Updated connector definition (YAML version 0.1.2)
- Source commit: 3bcb33e8
- SDK version: 0.1.0

## [0.17.29] - 2026-01-09
- Updated connector definition (YAML version 0.1.2)
- Source commit: da9b741b
- SDK version: 0.1.0

## [0.17.28] - 2026-01-07
- Updated connector definition (YAML version 0.1.2)
- Source commit: d023e05f
- SDK version: 0.1.0

## [0.17.27] - 2026-01-06
- Updated connector definition (YAML version 0.1.2)
- Source commit: 0580c727
- SDK version: 0.1.0

## [0.17.26] - 2026-01-06
- Updated connector definition (YAML version 0.1.2)
- Source commit: e0e2f989
- SDK version: 0.1.0

## [0.17.25] - 2026-01-05
- Updated connector definition (YAML version 0.1.2)
- Source commit: 3e274293
- SDK version: 0.1.0

## [0.17.24] - 2025-12-22
- Updated connector definition (YAML version 0.1.2)
- Source commit: 0eb1b1c4
- SDK version: 0.1.0

## [0.17.23] - 2025-12-19
- Updated connector definition (YAML version 0.1.1)
- Source commit: 12f6b994
- SDK version: 0.1.0

## [0.17.22] - 2025-12-19
- Updated connector definition (YAML version 0.1.1)
- Source commit: 5d11bfdf
- SDK version: 0.1.0

## [0.17.21] - 2025-12-19
- Updated connector definition (YAML version 0.1.1)
- Source commit: e996e848
- SDK version: 0.1.0

## [0.17.20] - 2025-12-18
- Updated connector definition (YAML version 0.1.1)
- Source commit: f7c55d3e
- SDK version: 0.1.0

## [0.17.19] - 2025-12-17
- Updated connector definition (YAML version 0.1.1)
- Source commit: af456521
- SDK version: 0.1.0

## [0.17.18] - 2025-12-17
- Updated connector definition (YAML version 0.1.1)
- Source commit: 6a6c981e
- SDK version: 0.1.0

## [0.17.17] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: c4c39c27
- SDK version: 0.1.0

## [0.17.16] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 85f4e6b0
- SDK version: 0.1.0

## [0.17.15] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 0bfa6500
- SDK version: 0.1.0

## [0.17.14] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: ea5a02a3
- SDK version: 0.1.0

## [0.17.13] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.17.12] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.17.11] - 2025-12-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.17.10] - 2025-12-13
- Updated connector definition (YAML version 0.1.1)
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.17.9] - 2025-12-12
- Updated connector definition (YAML version 0.1.1)
- Source commit: 4d366cb5
- SDK version: 0.1.0

## [0.17.8] - 2025-12-12
- Updated connector definition (YAML version 0.1.0)
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.17.7] - 2025-12-12
- Updated connector definition (YAML version 0.1.0)
- Source commit: 9f7f8a98
- SDK version: 0.1.0

## [0.17.6] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 8c06aa10
- SDK version: 0.1.0

## [0.17.5] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.17.4] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.17.3] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2497f71
- SDK version: 0.1.0

## [0.17.2] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 7d738be5
- SDK version: 0.1.0

## [0.17.1] - 2025-12-10
- Updated connector definition (YAML version 0.1.0)
- Source commit: 76636830
- SDK version: 0.1.0

## [0.17.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2ad5029
- SDK version: 0.1.0

## [0.16.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: 139b0b0d
- SDK version: 0.1.0

## [0.15.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: e96bed3d
- SDK version: 0.1.0

## [0.14.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: ed697b90
- SDK version: 0.1.0

## [0.13.0] - 2025-12-05
- Updated connector definition (YAML version 1.0.0)
- Source commit: 20618410
- SDK version: 0.1.0

## [0.12.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: 4a01e446
- SDK version: 0.1.0

## [0.11.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: 5ec76dde
- SDK version: 0.1.0

## [0.10.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: df32a458
- SDK version: 0.1.0

## [0.9.0] - 2025-12-04
- Updated connector definition (YAML version 1.0.0)
- Source commit: a506b369
- SDK version: 0.1.0

## [0.8.0] - 2025-12-03
- Updated connector definition (YAML version 1.0.0)
- Source commit: 92a39ab5
- SDK version: 0.1.0

## [0.7.0] - 2025-12-03
- Updated connector definition (YAML version 1.0.0)
- Source commit: 0ce38253
- SDK version: 0.1.0

## [0.6.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: c8e326d9
- SDK version: 0.1.0

## [0.5.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: ad0b961b
- SDK version: 0.1.0

## [0.4.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 7153780a
- SDK version: 0.1.0

## [0.3.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 01f71cad
- SDK version: 0.1.0

## [0.2.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: 4c17f060
- SDK version: 0.1.0

## [0.1.0] - 2025-12-02
- Updated connector definition (YAML version 1.0.0)
- Source commit: b261c3a2
- SDK version: 0.1.0
