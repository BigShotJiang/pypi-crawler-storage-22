# Changelog

## [0.1.97] - 2026-01-29
- Updated airbyte-agent-mcp package
- Source commit: 43200eed
- SDK version: 0.1.0

## [0.1.96] - 2026-01-29
- Updated airbyte-agent-mcp package
- Source commit: c718c683
- SDK version: 0.1.0

## [0.1.95] - 2026-01-29
- Updated airbyte-agent-mcp package
- Source commit: b907dd5d
- SDK version: 0.1.0

## [0.1.94] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: 97007bbd
- SDK version: 0.1.0

## [0.1.93] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: f6c6fca2
- SDK version: 0.1.0

## [0.1.92] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: 7efee372
- SDK version: 0.1.0

## [0.1.91] - 2026-01-28
- Updated airbyte-agent-mcp package
- Source commit: 71f48c10
- SDK version: 0.1.0

## [0.1.90] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: 0f5e1914
- SDK version: 0.1.0

## [0.1.89] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: a01f6b16
- SDK version: 0.1.0

## [0.1.88] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: 77091939
- SDK version: 0.1.0

## [0.1.87] - 2026-01-27
- Updated airbyte-agent-mcp package
- Source commit: 4bded58d
- SDK version: 0.1.0

## [0.1.86] - 2026-01-26
- Updated airbyte-agent-mcp package
- Source commit: 74809153
- SDK version: 0.1.0

## [0.1.85] - 2026-01-26
- Updated airbyte-agent-mcp package
- Source commit: b73c71e0
- SDK version: 0.1.0

## [0.1.84] - 2026-01-24
- Updated airbyte-agent-mcp package
- Source commit: 609c1d86
- SDK version: 0.1.0

## [0.1.83] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: 99d64eb7
- SDK version: 0.1.0

## [0.1.82] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: b32ea5ab
- SDK version: 0.1.0

## [0.1.81] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: 4285ad48
- SDK version: 0.1.0

## [0.1.80] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: 416466da
- SDK version: 0.1.0

## [0.1.79] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: b69b698f
- SDK version: 0.1.0

## [0.1.78] - 2026-01-23
- Updated airbyte-agent-mcp package
- Source commit: f17cdd8c
- SDK version: 0.1.0

## [0.1.77] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: 49e6dfe9
- SDK version: 0.1.0

## [0.1.76] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: b27328e2
- SDK version: 0.1.0

## [0.1.75] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.1.74] - 2026-01-22
- Updated airbyte-agent-mcp package
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.1.73] - 2026-01-21
- Updated airbyte-agent-mcp package
- Source commit: cf8d5de5
- SDK version: 0.1.0

## [0.1.72] - 2026-01-21
- Updated airbyte-agent-mcp package
- Source commit: 562cfe18
- SDK version: 0.1.0

## [0.1.71] - 2026-01-21
- Updated airbyte-agent-mcp package
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.1.70] - 2026-01-19
- Updated airbyte-agent-mcp package
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.1.69] - 2026-01-17
- Updated airbyte-agent-mcp package
- Source commit: 64c27b4c
- SDK version: 0.1.0

## [0.1.68] - 2026-01-16
- Updated airbyte-agent-mcp package
- Source commit: a50c8f71
- SDK version: 0.1.0

## [0.1.67] - 2026-01-16
- Updated airbyte-agent-mcp package
- Source commit: 49673b7b
- SDK version: 0.1.0

## [0.1.66] - 2026-01-16
- Updated airbyte-agent-mcp package
- Source commit: ca5acdda
- SDK version: 0.1.0

## [0.1.65] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: fa9a3b02
- SDK version: 0.1.0

## [0.1.64] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 61a2e822
- SDK version: 0.1.0

## [0.1.63] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 5d66b084
- SDK version: 0.1.0

## [0.1.62] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 4d03b394
- SDK version: 0.1.0

## [0.1.61] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 35211193
- SDK version: 0.1.0

## [0.1.60] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: a6da90fa
- SDK version: 0.1.0

## [0.1.59] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 20b3afd9
- SDK version: 0.1.0

## [0.1.58] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: b7138b41
- SDK version: 0.1.0

## [0.1.57] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: 10173eb1
- SDK version: 0.1.0

## [0.1.56] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: c10bf9d7
- SDK version: 0.1.0

## [0.1.55] - 2026-01-15
- Updated airbyte-agent-mcp package
- Source commit: a23d9e7a
- SDK version: 0.1.0

## [0.1.54] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: 7ef09816
- SDK version: 0.1.0

## [0.1.53] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: e6285db5
- SDK version: 0.1.0

## [0.1.52] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: 31de238d
- SDK version: 0.1.0

## [0.1.51] - 2026-01-14
- Updated airbyte-agent-mcp package
- Source commit: 6504630b
- SDK version: 0.1.0

## [0.1.50] - 2026-01-13
- Updated airbyte-agent-mcp package
- Source commit: e80a226e
- SDK version: 0.1.0

## [0.1.49] - 2026-01-13
- Updated airbyte-agent-mcp package
- Source commit: 78b1be67
- SDK version: 0.1.0

## [0.1.48] - 2026-01-11
- Updated airbyte-agent-mcp package
- Source commit: e519b73d
- SDK version: 0.1.0

## [0.1.47] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: 3c7bfdfd
- SDK version: 0.1.0

## [0.1.46] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: 3bcb33e8
- SDK version: 0.1.0

## [0.1.45] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: 9fe9d138
- SDK version: 0.1.0

## [0.1.44] - 2026-01-09
- Updated airbyte-agent-mcp package
- Source commit: da9b741b
- SDK version: 0.1.0

## [0.1.43] - 2026-01-07
- Updated airbyte-agent-mcp package
- Source commit: d023e05f
- SDK version: 0.1.0

## [0.1.42] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: 0580c727
- SDK version: 0.1.0

## [0.1.41] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: 42f65575
- SDK version: 0.1.0

## [0.1.40] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: 0deedc22
- SDK version: 0.1.0

## [0.1.39] - 2026-01-06
- Updated airbyte-agent-mcp package
- Source commit: e0e2f989
- SDK version: 0.1.0

## [0.1.38] - 2026-01-05
- Updated airbyte-agent-mcp package
- Source commit: 3e274293
- SDK version: 0.1.0

## [0.1.37] - 2025-12-19
- Updated airbyte-agent-mcp package
- Source commit: 12f6b994
- SDK version: 0.1.0

## [0.1.36] - 2025-12-19
- Updated airbyte-agent-mcp package
- Source commit: 5d11bfdf
- SDK version: 0.1.0

## [0.1.35] - 2025-12-19
- Updated airbyte-agent-mcp package
- Source commit: e996e848
- SDK version: 0.1.0

## [0.1.34] - 2025-12-18
- Updated airbyte-agent-mcp package
- Source commit: f7c55d3e
- SDK version: 0.1.0

## [0.1.33] - 2025-12-17
- Updated airbyte-agent-mcp package
- Source commit: af456521
- SDK version: 0.1.0

## [0.1.32] - 2025-12-17
- Updated airbyte-agent-mcp package
- Source commit: 6a6c981e
- SDK version: 0.1.0

## [0.1.31] - 2025-12-16
- Updated airbyte-agent-mcp package
- Source commit: 9c0af4ae
- SDK version: 0.1.0

## [0.1.30] - 2025-12-16
- Updated airbyte-agent-mcp package
- Source commit: d8fc544e
- SDK version: 0.1.0

## [0.1.29] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: c4c39c27
- SDK version: 0.1.0

## [0.1.28] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 85f4e6b0
- SDK version: 0.1.0

## [0.1.27] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 77ce3325
- SDK version: 0.1.0

## [0.1.26] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 0bfa6500
- SDK version: 0.1.0

## [0.1.25] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: ea5a02a3
- SDK version: 0.1.0

## [0.1.24] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.1.23] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.1.22] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 0e48ca4e
- SDK version: 0.1.0

## [0.1.21] - 2025-12-15
- Updated airbyte-agent-mcp package
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.1.20] - 2025-12-13
- Updated airbyte-agent-mcp package
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.1.19] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.1.18] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 380e7c20
- SDK version: 0.1.0

## [0.1.17] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 1f622906
- SDK version: 0.1.0

## [0.1.16] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 8cd69753
- SDK version: 0.1.0

## [0.1.15] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 9f7f8a98
- SDK version: 0.1.0

## [0.1.14] - 2025-12-12
- Updated airbyte-agent-mcp package
- Source commit: 5cc8eaa0
- SDK version: 0.1.0

## [0.1.13] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: dfe01f50
- SDK version: 0.1.0

## [0.1.12] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: 8c06aa10
- SDK version: 0.1.0

## [0.1.11] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.1.10] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.1.9] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: ec3dcc78
- SDK version: 0.1.0

## [0.1.8] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 334e113b
- SDK version: 0.1.0

## [0.1.7] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 30c77ce6
- SDK version: 0.1.0

## [0.1.6] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 92482e66
- SDK version: 0.1.0

## [0.1.5] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.4] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.3] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.2] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.1] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.0] - 2025-12-09
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0
