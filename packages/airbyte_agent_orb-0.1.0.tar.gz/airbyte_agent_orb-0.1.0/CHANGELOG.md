# Orb changelog

## [0.1.0] - 2026-01-29
- Updated connector definition (YAML version 0.1.1)
- Source commit: 68ca482c
- SDK version: 0.1.0
