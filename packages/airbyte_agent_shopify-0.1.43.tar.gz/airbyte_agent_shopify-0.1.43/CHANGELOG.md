# Shopify changelog

## [0.1.43] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: e4f3b9c8
- SDK version: 0.1.0

## [0.1.42] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: cddf6b9f
- SDK version: 0.1.0

## [0.1.41] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: 481be654
- SDK version: 0.1.0

## [0.1.40] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: 271d94f6
- SDK version: 0.1.0

## [0.1.39] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: c081aa11
- SDK version: 0.1.0

## [0.1.38] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: 72bd32a3
- SDK version: 0.1.0

## [0.1.37] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: 3e4f6ea0
- SDK version: 0.1.0

## [0.1.36] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: 0c907160
- SDK version: 0.1.0

## [0.1.35] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: aceb0c64
- SDK version: 0.1.0

## [0.1.34] - 2026-02-05
- Updated connector definition (YAML version 0.1.6)
- Source commit: def0e484
- SDK version: 0.1.0

## [0.1.33] - 2026-02-04
- Updated connector definition (YAML version 0.1.6)
- Source commit: 5c699b63
- SDK version: 0.1.0

## [0.1.32] - 2026-02-04
- Updated connector definition (YAML version 0.1.6)
- Source commit: 7aef2bc0
- SDK version: 0.1.0

## [0.1.31] - 2026-02-04
- Updated connector definition (YAML version 0.1.5)
- Source commit: 30d23e05
- SDK version: 0.1.0

## [0.1.30] - 2026-02-03
- Updated connector definition (YAML version 0.1.5)
- Source commit: 5ef2158e
- SDK version: 0.1.0

## [0.1.29] - 2026-02-03
- Updated connector definition (YAML version 0.1.5)
- Source commit: 5c6dbf88
- SDK version: 0.1.0

## [0.1.28] - 2026-02-03
- Updated connector definition (YAML version 0.1.5)
- Source commit: 1fc2ac28
- SDK version: 0.1.0

## [0.1.27] - 2026-02-03
- Updated connector definition (YAML version 0.1.4)
- Source commit: f2dbc00e
- SDK version: 0.1.0

## [0.1.26] - 2026-02-02
- Updated connector definition (YAML version 0.1.3)
- Source commit: 94024675
- SDK version: 0.1.0

## [0.1.25] - 2026-02-02
- Updated connector definition (YAML version 0.1.3)
- Source commit: 9d9866b0
- SDK version: 0.1.0

## [0.1.24] - 2026-01-30
- Updated connector definition (YAML version 0.1.3)
- Source commit: b184da3e
- SDK version: 0.1.0

## [0.1.23] - 2026-01-30
- Updated connector definition (YAML version 0.1.3)
- Source commit: 5f65d643
- SDK version: 0.1.0

## [0.1.22] - 2026-01-30
- Updated connector definition (YAML version 0.1.2)
- Source commit: 5b20f488
- SDK version: 0.1.0

## [0.1.21] - 2026-01-30
- Updated connector definition (YAML version 0.1.2)
- Source commit: a3729d85
- SDK version: 0.1.0

## [0.1.20] - 2026-01-29
- Updated connector definition (YAML version 0.1.2)
- Source commit: 43200eed
- SDK version: 0.1.0

## [0.1.19] - 2026-01-29
- Updated connector definition (YAML version 0.1.2)
- Source commit: c718c683
- SDK version: 0.1.0

## [0.1.18] - 2026-01-28
- Updated connector definition (YAML version 0.1.2)
- Source commit: 97007bbd
- SDK version: 0.1.0

## [0.1.17] - 2026-01-28
- Updated connector definition (YAML version 0.1.2)
- Source commit: f6c6fca2
- SDK version: 0.1.0

## [0.1.16] - 2026-01-28
- Updated connector definition (YAML version 0.1.2)
- Source commit: 71f48c10
- SDK version: 0.1.0

## [0.1.15] - 2026-01-27
- Updated connector definition (YAML version 0.1.2)
- Source commit: 0f5e1914
- SDK version: 0.1.0

## [0.1.14] - 2026-01-27
- Updated connector definition (YAML version 0.1.2)
- Source commit: a01f6b16
- SDK version: 0.1.0

## [0.1.13] - 2026-01-27
- Updated connector definition (YAML version 0.1.2)
- Source commit: c9b05509
- SDK version: 0.1.0

## [0.1.12] - 2026-01-27
- Updated connector definition (YAML version 0.1.1)
- Source commit: 4bded58d
- SDK version: 0.1.0

## [0.1.11] - 2026-01-26
- Updated connector definition (YAML version 0.1.1)
- Source commit: 74809153
- SDK version: 0.1.0

## [0.1.10] - 2026-01-26
- Updated connector definition (YAML version 0.1.1)
- Source commit: b73c71e0
- SDK version: 0.1.0

## [0.1.9] - 2026-01-24
- Updated connector definition (YAML version 0.1.1)
- Source commit: 609c1d86
- SDK version: 0.1.0

## [0.1.8] - 2026-01-23
- Updated connector definition (YAML version 0.1.1)
- Source commit: 416466da
- SDK version: 0.1.0

## [0.1.7] - 2026-01-23
- Updated connector definition (YAML version 0.1.1)
- Source commit: f17cdd8c
- SDK version: 0.1.0

## [0.1.6] - 2026-01-22
- Updated connector definition (YAML version 0.1.1)
- Source commit: 49e6dfe9
- SDK version: 0.1.0

## [0.1.5] - 2026-01-22
- Updated connector definition (YAML version 0.1.1)
- Source commit: b27328e2
- SDK version: 0.1.0

## [0.1.4] - 2026-01-22
- Updated connector definition (YAML version 0.1.1)
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.1.3] - 2026-01-22
- Updated connector definition (YAML version 0.1.1)
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.1.2] - 2026-01-21
- Updated connector definition (YAML version 0.1.1)
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.1.1] - 2026-01-19
- Updated connector definition (YAML version 0.1.1)
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.1.0] - 2026-01-17
- Updated connector definition (YAML version 0.1.1)
- Source commit: 7c6c8361
- SDK version: 0.1.0
