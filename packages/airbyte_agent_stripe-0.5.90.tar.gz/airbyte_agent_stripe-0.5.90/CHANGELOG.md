# Stripe changelog

## [0.5.90] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: cddf6b9f
- SDK version: 0.1.0

## [0.5.89] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: 481be654
- SDK version: 0.1.0

## [0.5.88] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: 271d94f6
- SDK version: 0.1.0

## [0.5.87] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: c081aa11
- SDK version: 0.1.0

## [0.5.86] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: 72bd32a3
- SDK version: 0.1.0

## [0.5.85] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: 3e4f6ea0
- SDK version: 0.1.0

## [0.5.84] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: 0c907160
- SDK version: 0.1.0

## [0.5.83] - 2026-02-05
- Updated connector definition (YAML version 0.1.8)
- Source commit: 40df1623
- SDK version: 0.1.0

## [0.5.82] - 2026-02-05
- Updated connector definition (YAML version 0.1.7)
- Source commit: aceb0c64
- SDK version: 0.1.0

## [0.5.81] - 2026-02-05
- Updated connector definition (YAML version 0.1.7)
- Source commit: def0e484
- SDK version: 0.1.0

## [0.5.80] - 2026-02-04
- Updated connector definition (YAML version 0.1.7)
- Source commit: 5c699b63
- SDK version: 0.1.0

## [0.5.79] - 2026-02-04
- Updated connector definition (YAML version 0.1.7)
- Source commit: 7aef2bc0
- SDK version: 0.1.0

## [0.5.78] - 2026-02-04
- Updated connector definition (YAML version 0.1.6)
- Source commit: 30d23e05
- SDK version: 0.1.0

## [0.5.77] - 2026-02-03
- Updated connector definition (YAML version 0.1.6)
- Source commit: 5ef2158e
- SDK version: 0.1.0

## [0.5.76] - 2026-02-03
- Updated connector definition (YAML version 0.1.6)
- Source commit: 5c6dbf88
- SDK version: 0.1.0

## [0.5.75] - 2026-02-02
- Updated connector definition (YAML version 0.1.6)
- Source commit: 94024675
- SDK version: 0.1.0

## [0.5.74] - 2026-02-02
- Updated connector definition (YAML version 0.1.6)
- Source commit: 9d9866b0
- SDK version: 0.1.0

## [0.5.73] - 2026-01-30
- Updated connector definition (YAML version 0.1.6)
- Source commit: b184da3e
- SDK version: 0.1.0

## [0.5.72] - 2026-01-30
- Updated connector definition (YAML version 0.1.6)
- Source commit: 5b20f488
- SDK version: 0.1.0

## [0.5.71] - 2026-01-30
- Updated connector definition (YAML version 0.1.6)
- Source commit: a3729d85
- SDK version: 0.1.0

## [0.5.70] - 2026-01-29
- Updated connector definition (YAML version 0.1.6)
- Source commit: 43200eed
- SDK version: 0.1.0

## [0.5.69] - 2026-01-29
- Updated connector definition (YAML version 0.1.6)
- Source commit: c718c683
- SDK version: 0.1.0

## [0.5.68] - 2026-01-28
- Updated connector definition (YAML version 0.1.6)
- Source commit: 97007bbd
- SDK version: 0.1.0

## [0.5.67] - 2026-01-28
- Updated connector definition (YAML version 0.1.6)
- Source commit: f6c6fca2
- SDK version: 0.1.0

## [0.5.66] - 2026-01-28
- Updated connector definition (YAML version 0.1.6)
- Source commit: 71f48c10
- SDK version: 0.1.0

## [0.5.65] - 2026-01-27
- Updated connector definition (YAML version 0.1.6)
- Source commit: 0f5e1914
- SDK version: 0.1.0

## [0.5.64] - 2026-01-27
- Updated connector definition (YAML version 0.1.6)
- Source commit: a01f6b16
- SDK version: 0.1.0

## [0.5.63] - 2026-01-27
- Updated connector definition (YAML version 0.1.6)
- Source commit: c9b05509
- SDK version: 0.1.0

## [0.5.62] - 2026-01-27
- Updated connector definition (YAML version 0.1.5)
- Source commit: 4bded58d
- SDK version: 0.1.0

## [0.5.61] - 2026-01-26
- Updated connector definition (YAML version 0.1.5)
- Source commit: 74809153
- SDK version: 0.1.0

## [0.5.60] - 2026-01-26
- Updated connector definition (YAML version 0.1.5)
- Source commit: b73c71e0
- SDK version: 0.1.0

## [0.5.59] - 2026-01-24
- Updated connector definition (YAML version 0.1.5)
- Source commit: 609c1d86
- SDK version: 0.1.0

## [0.5.58] - 2026-01-23
- Updated connector definition (YAML version 0.1.5)
- Source commit: 416466da
- SDK version: 0.1.0

## [0.5.57] - 2026-01-23
- Updated connector definition (YAML version 0.1.5)
- Source commit: f17cdd8c
- SDK version: 0.1.0

## [0.5.56] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: 49e6dfe9
- SDK version: 0.1.0

## [0.5.55] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: b27328e2
- SDK version: 0.1.0

## [0.5.54] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.5.53] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.5.52] - 2026-01-21
- Updated connector definition (YAML version 0.1.5)
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.5.51] - 2026-01-19
- Updated connector definition (YAML version 0.1.5)
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.5.50] - 2026-01-16
- Updated connector definition (YAML version 0.1.5)
- Source commit: a50c8f71
- SDK version: 0.1.0

## [0.5.49] - 2026-01-16
- Updated connector definition (YAML version 0.1.5)
- Source commit: 49673b7b
- SDK version: 0.1.0

## [0.5.48] - 2026-01-16
- Updated connector definition (YAML version 0.1.5)
- Source commit: ca5acdda
- SDK version: 0.1.0

## [0.5.47] - 2026-01-15
- Updated connector definition (YAML version 0.1.5)
- Source commit: fa9a3b02
- SDK version: 0.1.0

## [0.5.46] - 2026-01-15
- Updated connector definition (YAML version 0.1.5)
- Source commit: 61a2e822
- SDK version: 0.1.0

## [0.5.45] - 2026-01-15
- Updated connector definition (YAML version 0.1.5)
- Source commit: 35211193
- SDK version: 0.1.0

## [0.5.44] - 2026-01-15
- Updated connector definition (YAML version 0.1.5)
- Source commit: f4a8fbf6
- SDK version: 0.1.0

## [0.5.43] - 2026-01-15
- Updated connector definition (YAML version 0.1.4)
- Source commit: 20b3afd9
- SDK version: 0.1.0

## [0.5.42] - 2026-01-15
- Updated connector definition (YAML version 0.1.4)
- Source commit: b7138b41
- SDK version: 0.1.0

## [0.5.41] - 2026-01-15
- Updated connector definition (YAML version 0.1.4)
- Source commit: 10173eb1
- SDK version: 0.1.0

## [0.5.40] - 2026-01-15
- Updated connector definition (YAML version 0.1.4)
- Source commit: a23d9e7a
- SDK version: 0.1.0

## [0.5.39] - 2026-01-14
- Updated connector definition (YAML version 0.1.4)
- Source commit: 7ef09816
- SDK version: 0.1.0

## [0.5.38] - 2026-01-14
- Updated connector definition (YAML version 0.1.4)
- Source commit: e6285db5
- SDK version: 0.1.0

## [0.5.37] - 2026-01-14
- Updated connector definition (YAML version 0.1.4)
- Source commit: 31de238d
- SDK version: 0.1.0

## [0.5.36] - 2026-01-13
- Updated connector definition (YAML version 0.1.4)
- Source commit: 24bb7379
- SDK version: 0.1.0

## [0.5.35] - 2026-01-13
- Updated connector definition (YAML version 0.1.3)
- Source commit: e80a226e
- SDK version: 0.1.0

## [0.5.34] - 2026-01-13
- Updated connector definition (YAML version 0.1.3)
- Source commit: 78b1be67
- SDK version: 0.1.0

## [0.5.33] - 2026-01-11
- Updated connector definition (YAML version 0.1.3)
- Source commit: e519b73d
- SDK version: 0.1.0

## [0.5.32] - 2026-01-09
- Updated connector definition (YAML version 0.1.3)
- Source commit: 3c7bfdfd
- SDK version: 0.1.0

## [0.5.31] - 2026-01-09
- Updated connector definition (YAML version 0.1.3)
- Source commit: 3bcb33e8
- SDK version: 0.1.0

## [0.5.30] - 2026-01-09
- Updated connector definition (YAML version 0.1.3)
- Source commit: da9b741b
- SDK version: 0.1.0

## [0.5.29] - 2026-01-07
- Updated connector definition (YAML version 0.1.3)
- Source commit: d023e05f
- SDK version: 0.1.0

## [0.5.28] - 2026-01-06
- Updated connector definition (YAML version 0.1.3)
- Source commit: 0580c727
- SDK version: 0.1.0

## [0.5.27] - 2026-01-06
- Updated connector definition (YAML version 0.1.3)
- Source commit: e0e2f989
- SDK version: 0.1.0

## [0.5.26] - 2026-01-05
- Updated connector definition (YAML version 0.1.3)
- Source commit: 3e274293
- SDK version: 0.1.0

## [0.5.25] - 2025-12-22
- Updated connector definition (YAML version 0.1.3)
- Source commit: 0eb1b1c4
- SDK version: 0.1.0

## [0.5.24] - 2025-12-19
- Updated connector definition (YAML version 0.1.2)
- Source commit: 12f6b994
- SDK version: 0.1.0

## [0.5.23] - 2025-12-19
- Updated connector definition (YAML version 0.1.2)
- Source commit: 5d11bfdf
- SDK version: 0.1.0

## [0.5.22] - 2025-12-19
- Updated connector definition (YAML version 0.1.2)
- Source commit: e996e848
- SDK version: 0.1.0

## [0.5.21] - 2025-12-18
- Updated connector definition (YAML version 0.1.2)
- Source commit: f7c55d3e
- SDK version: 0.1.0

## [0.5.20] - 2025-12-17
- Updated connector definition (YAML version 0.1.2)
- Source commit: af456521
- SDK version: 0.1.0

## [0.5.19] - 2025-12-17
- Updated connector definition (YAML version 0.1.2)
- Source commit: 6a6c981e
- SDK version: 0.1.0

## [0.5.18] - 2025-12-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: c4c39c27
- SDK version: 0.1.0

## [0.5.17] - 2025-12-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: 85f4e6b0
- SDK version: 0.1.0

## [0.5.16] - 2025-12-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: 0bfa6500
- SDK version: 0.1.0

## [0.5.15] - 2025-12-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: ea5a02a3
- SDK version: 0.1.0

## [0.5.14] - 2025-12-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: f13dee0a
- SDK version: 0.1.0

## [0.5.13] - 2025-12-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: d79da1e7
- SDK version: 0.1.0

## [0.5.12] - 2025-12-15
- Updated connector definition (YAML version 0.1.2)
- Source commit: 06e7d5c6
- SDK version: 0.1.0

## [0.5.11] - 2025-12-13
- Updated connector definition (YAML version 0.1.2)
- Source commit: 1ab72bd8
- SDK version: 0.1.0

## [0.5.10] - 2025-12-12
- Updated connector definition (YAML version 0.1.2)
- Source commit: c17d44a8
- SDK version: 0.1.0

## [0.5.9] - 2025-12-12
- Updated connector definition (YAML version 0.1.1)
- Source commit: 4d366cb5
- SDK version: 0.1.0

## [0.5.8] - 2025-12-12
- Updated connector definition (YAML version 0.1.0)
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.5.7] - 2025-12-12
- Updated connector definition (YAML version 0.1.0)
- Source commit: 9f7f8a98
- SDK version: 0.1.0

## [0.5.6] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 8c06aa10
- SDK version: 0.1.0

## [0.5.5] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.5.4] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.5.3] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2497f71
- SDK version: 0.1.0

## [0.5.2] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 7d738be5
- SDK version: 0.1.0

## [0.5.1] - 2025-12-10
- Updated connector definition (YAML version 0.1.0)
- Source commit: 76636830
- SDK version: 0.1.0

## [0.5.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2ad5029
- SDK version: 0.1.0

## [0.4.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: 139b0b0d
- SDK version: 0.1.0

## [0.3.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: e96bed3d
- SDK version: 0.1.0

## [0.2.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: ed697b90
- SDK version: 0.1.0

## [0.1.23] - 2025-12-05
- Updated connector definition (YAML version 0.0.1)
- Source commit: 20618410
- SDK version: 0.1.0

## [0.1.22] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: 4a01e446
- SDK version: 0.1.0

## [0.1.21] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5ec76dde
- SDK version: 0.1.0

## [0.1.20] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: df32a458
- SDK version: 0.1.0

## [0.1.19] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: a506b369
- SDK version: 0.1.0

## [0.1.18] - 2025-12-03
- Updated connector definition (YAML version 0.0.1)
- Source commit: 92a39ab5
- SDK version: 0.1.0

## [0.1.17] - 2025-12-03
- Updated connector definition (YAML version 0.0.1)
- Source commit: 0ce38253
- SDK version: 0.1.0

## [0.1.16] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: c8e326d9
- SDK version: 0.1.0

## [0.1.15] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: ad0b961b
- SDK version: 0.1.0

## [0.1.14] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: 7153780a
- SDK version: 0.1.0

## [0.1.13] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: 01f71cad
- SDK version: 0.1.0

## [0.1.12] - 2025-12-02
- Updated connector definition (YAML version 0.0.4)
- Source commit: 236db7f0
- SDK version: 0.1.0

## [0.1.11] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: 4c17f060
- SDK version: 0.1.0

## [0.1.10] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: cd499acd
- SDK version: 0.1.0

## [0.1.9] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: 64df6a87
- SDK version: 0.1.0

## [0.1.8] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: f34b246f
- SDK version: 0.1.0

## [0.1.7] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: b261c3a2
- SDK version: 0.1.0

## [0.1.6] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 702fd446
- SDK version: 0.1.0

## [0.1.5] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: d656a4a2
- SDK version: 0.1.0

## [0.1.4] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.3] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.2] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: c1700e5e
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.1] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.0] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1
