# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""Pydantic models for cloud connector version operations.

This module defines the data models used for connector version management
and pinning operations in Airbyte Cloud.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ConnectorVersionInfo(BaseModel):
    """Information about a cloud connector's version.

    This model represents the current version state of a deployed connector,
    including whether a version override (pin) is active.
    """

    connector_id: str = Field(description="The ID of the deployed connector")
    connector_type: Literal["source", "destination"] = Field(
        description="The type of connector (source or destination)"
    )
    version: str = Field(description="The current version string (e.g., '0.1.0')")
    is_version_pinned: bool = Field(
        description="Whether a version override is active for this connector"
    )

    def __str__(self) -> str:
        """Return a string representation of the version."""
        pinned_suffix = " (pinned)" if self.is_version_pinned else ""
        return (
            f"{self.connector_type} {self.connector_id}: {self.version}{pinned_suffix}"
        )


class VersionOverrideOperationResult(BaseModel):
    """Result of a version override operation (set or clear).

    This model provides detailed information about the outcome of a version
    pinning or unpinning operation.
    """

    success: bool = Field(description="Whether the operation succeeded")
    message: str = Field(description="Human-readable message describing the result")
    connector_id: str = Field(description="The ID of the connector that was modified")
    connector_type: Literal["source", "destination"] = Field(
        description="The type of connector (source or destination)"
    )
    previous_version: str | None = Field(
        default=None,
        description="The version before the operation (None if not available)",
    )
    new_version: str | None = Field(
        default=None,
        description="The version after the operation (None if cleared or failed)",
    )
    was_pinned_before: bool | None = Field(
        default=None,
        description="Whether a pin was active before the operation",
    )
    is_pinned_after: bool | None = Field(
        default=None,
        description="Whether a pin is active after the operation",
    )

    def __str__(self) -> str:
        """Return a string representation of the operation result."""
        if self.success:
            return f"✓ {self.message}"
        return f"✗ {self.message}"


class WorkspaceVersionOverrideResult(BaseModel):
    """Result of a workspace-level version override operation.

    This model provides detailed information about the outcome of a workspace-level
    version pinning or unpinning operation.
    """

    success: bool = Field(description="Whether the operation succeeded")
    message: str = Field(description="Human-readable message describing the result")
    workspace_id: str = Field(description="The workspace ID")
    connector_name: str = Field(
        description="The connector name (e.g., 'source-github')"
    )
    connector_type: Literal["source", "destination"] = Field(
        description="The type of connector (source or destination)"
    )
    version: str | None = Field(
        default=None,
        description="The version that was pinned (None if cleared or failed)",
    )

    def __str__(self) -> str:
        """Return a string representation of the operation result."""
        if self.success:
            return f"✓ {self.message}"
        return f"✗ {self.message}"


class OrganizationVersionOverrideResult(BaseModel):
    """Result of an organization-level version override operation.

    This model provides detailed information about the outcome of an organization-level
    version pinning or unpinning operation.
    """

    success: bool = Field(description="Whether the operation succeeded")
    message: str = Field(description="Human-readable message describing the result")
    organization_id: str = Field(description="The organization ID")
    connector_name: str = Field(
        description="The connector name (e.g., 'source-github')"
    )
    connector_type: Literal["source", "destination"] = Field(
        description="The type of connector (source or destination)"
    )
    version: str | None = Field(
        default=None,
        description="The version that was pinned (None if cleared or failed)",
    )

    def __str__(self) -> str:
        """Return a string representation of the operation result."""
        if self.success:
            return f"✓ {self.message}"
        return f"✗ {self.message}"


class ConnectorRolloutStartResult(BaseModel):
    """Result of a connector rollout start operation.

    This model provides detailed information about the outcome of starting
    a connector rollout workflow.
    """

    success: bool = Field(description="Whether the operation succeeded")
    message: str = Field(description="Human-readable message describing the result")
    docker_repository: str | None = Field(
        default=None,
        description="The docker repository (e.g., 'airbyte/source-github')",
    )
    docker_image_tag: str | None = Field(
        default=None,
        description="The docker image tag (e.g., '1.2.0-rc.2')",
    )
    actor_definition_id: str | None = Field(
        default=None,
        description="The actor definition ID (UUID)",
    )
    rollout_strategy: Literal["manual", "automated", "overridden"] | None = Field(
        default=None,
        description="The rollout strategy used",
    )

    def __str__(self) -> str:
        """Return a string representation of the operation result."""
        if self.success:
            return f"OK {self.message}"
        return f"FAILED {self.message}"


class ConnectorRolloutProgressResult(BaseModel):
    """Result of a connector rollout progress operation.

    This model provides detailed information about the outcome of progressing
    a connector rollout (pinning actors to the RC version).
    """

    success: bool = Field(description="Whether the operation succeeded")
    message: str = Field(description="Human-readable message describing the result")
    rollout_id: str | None = Field(
        default=None,
        description="The rollout ID that was progressed",
    )
    docker_repository: str | None = Field(
        default=None,
        description="The docker repository (e.g., 'airbyte/source-github')",
    )
    docker_image_tag: str | None = Field(
        default=None,
        description="The docker image tag (e.g., '1.2.0-rc.2')",
    )
    target_percentage: int | None = Field(
        default=None,
        description="The target percentage of actors to pin",
    )

    def __str__(self) -> str:
        """Return a string representation of the operation result."""
        if self.success:
            return f"OK {self.message}"
        return f"FAILED {self.message}"


class ConnectorRolloutFinalizeResult(BaseModel):
    """Result of a connector rollout finalization operation.

    This model provides detailed information about the outcome of finalizing
    a connector rollout (promote, rollback, or cancel).
    """

    success: bool = Field(description="Whether the operation succeeded")
    message: str = Field(description="Human-readable message describing the result")
    rollout_id: str | None = Field(
        default=None,
        description="The rollout ID that was finalized",
    )
    docker_repository: str | None = Field(
        default=None,
        description="The docker repository (e.g., 'airbyte/source-github')",
    )
    docker_image_tag: str | None = Field(
        default=None,
        description="The docker image tag (e.g., '1.2.0-rc.2')",
    )
    state: Literal["succeeded", "failed_rolled_back", "canceled"] | None = Field(
        default=None,
        description="The final state of the rollout",
    )

    def __str__(self) -> str:
        """Return a string representation of the operation result."""
        if self.success:
            return f"OK {self.message}"
        return f"FAILED {self.message}"
