# Airbyte Connectors CI

This folder is a collection of systems, tools and scripts that are used to run CI/CD systems
specific to our connectors.

For the list of tools and subfolders, please see [README in `airbyte-ci`](../README.md).
