# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""MCP tools for connector registry operations.

This module will contain tools for interacting with the Airbyte connector registry.
"""

from __future__ import annotations

# Future implementation: Registry tools will be added here
