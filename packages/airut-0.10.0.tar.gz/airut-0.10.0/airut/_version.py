"""Auto-generated at build time — do not edit."""

VERSION = 'v0.10.0'
GIT_SHA_SHORT = 'caf3837'
GIT_SHA_FULL = 'caf3837335ab61cf3f5ec297e5d4f6ce80e63ce7'
