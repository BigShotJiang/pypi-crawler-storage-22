"""Auto-generated at build time — do not edit."""

VERSION = 'v0.8.0'
GIT_SHA_SHORT = 'a661559'
GIT_SHA_FULL = 'a66155980694784399aef5fbb902244bd1c9a570'
