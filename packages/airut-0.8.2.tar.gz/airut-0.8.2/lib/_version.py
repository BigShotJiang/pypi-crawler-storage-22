"""Auto-generated at build time — do not edit."""

VERSION = 'v0.8.2'
GIT_SHA_SHORT = 'cd2378f'
GIT_SHA_FULL = 'cd2378f63560486403de69a57c68852bcea3c012'
