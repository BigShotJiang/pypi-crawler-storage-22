"""Auto-generated at build time — do not edit."""

VERSION = 'v0.8.3'
GIT_SHA_SHORT = 'f77af08'
GIT_SHA_FULL = 'f77af08c05feb951cf6ed22a4e5caa4db017c433'
