"""Auto-generated at build time — do not edit."""

VERSION = 'v0.9.0'
GIT_SHA_SHORT = 'f085001'
GIT_SHA_FULL = 'f08500176af35cb2410ee9d6ad6d66bb7588a3a1'
