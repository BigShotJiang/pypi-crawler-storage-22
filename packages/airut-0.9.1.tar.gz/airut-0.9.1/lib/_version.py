"""Auto-generated at build time — do not edit."""

VERSION = 'v0.9.1'
GIT_SHA_SHORT = 'd063205'
GIT_SHA_FULL = 'd063205f2ecd7498924213892dd520b4706b6a6c'
