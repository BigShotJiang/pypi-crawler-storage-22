"""AITop version information."""

__version__ = "0.13.1"  # Release: documentation and metadata refresh
__author__ = "Alexander Warth"
__copyright__ = f"Copyright (c) 2025 {__author__}"
