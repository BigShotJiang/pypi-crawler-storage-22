"""AITop version information."""

__version__ = "0.15.2"  # Release: AI/ML positioning refresh and header cleanup
__author__ = "Alexander Warth"
__copyright__ = f"Copyright (c) 2025 {__author__}"
