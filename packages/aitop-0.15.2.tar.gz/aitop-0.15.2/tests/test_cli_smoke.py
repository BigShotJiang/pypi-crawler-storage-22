import subprocess
import sys


def _run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "aitop", *args],
        capture_output=True,
        text=True,
        check=False,
    )


def test_cli_help_smoke() -> None:
    result = _run_cli("--help")
    assert result.returncode == 0
    description = "AITop - A high performance system monitor for AI/ML workloads"
    assert description in result.stdout
    assert "--list-themes" in result.stdout


def test_cli_list_themes_smoke() -> None:
    result = _run_cli("--list-themes")
    assert result.returncode == 0
    assert "Available AITop Themes" in result.stdout
    assert "default" in result.stdout
