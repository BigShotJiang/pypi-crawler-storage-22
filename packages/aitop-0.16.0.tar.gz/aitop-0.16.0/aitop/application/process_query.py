#!/usr/bin/env python3
"""Application-level process query services."""

from typing import Any, Dict, List

from ..domain.process_filtering import (
    SUPPORTED_FIELDS,
    QueryTerm,
    _parse_query_terms,
    filter_processes as _filter_processes,
    normalize_query,
    process_matches_query,
)


def filter_processes(
    processes: List[Dict[str, Any]], query: str
) -> List[Dict[str, Any]]:
    """Filter process dictionaries by a user query."""
    return _filter_processes(processes, query)


__all__ = [
    "SUPPORTED_FIELDS",
    "QueryTerm",
    "filter_processes",
    "normalize_query",
    "process_matches_query",
    "_parse_query_terms",
]
