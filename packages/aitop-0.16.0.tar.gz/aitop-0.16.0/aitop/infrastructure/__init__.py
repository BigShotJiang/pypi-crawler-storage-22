"""Infrastructure layer for external systems and side-effectful adapters."""

