#!/usr/bin/env python3
"""File-backed configuration source implementation."""

import json
from pathlib import Path
from typing import Any


class FileConfigSource:
    """Load JSON configuration payloads from disk."""

    def load_json(self, file_path: Path) -> Any:
        """Read and parse a JSON file from the given path."""
        with open(file_path) as file_obj:
            return json.load(file_obj)


__all__ = ["FileConfigSource"]
