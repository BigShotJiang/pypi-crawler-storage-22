"""AITop version information."""

__version__ = "0.16.0"  # Release: CPU telemetry hardening and inventory adapters
__author__ = "Alexander Warth"
__copyright__ = f"Copyright (c) 2025 {__author__}"
