# DevMemory

轻量级 MCP Server，为 AI 编程助手提供跨会话持久记忆能力。

## 特性

- 基于 SQLite + sqlite-vec 的向量语义搜索
- ONNX Runtime 本地 Embedding，无需 API Key
- 记忆自动去重（余弦相似度 > 0.95 时更新）
- 支持项目级和用户级两种作用域
- 7 个 MCP 工具：remember / recall / forget / status / track / digest / auto_save
- 内置 Web 看板（记忆管理、会话状态、问题跟踪）

## 快速开始

### 方式一：pip 安装（推荐）

```bash
# 1. 安装
pip install devmemory

# 2. 进入你的项目目录
cd /path/to/your/project

# 3. 一键配置 MCP（交互式选择 IDE）
devmemory install

# 4. 重启 IDE，完成
```

### 方式二：uvx 运行（无需安装）

```bash
# 1. 进入你的项目目录
cd /path/to/your/project

# 2. 一键配置 MCP（选择 uvx 启动方式）
uvx devmemory install

# 3. 重启 IDE，完成
```

### 方式三：手动配置

在 IDE 的 MCP 配置文件中添加：

```json
{
  "mcpServers": {
    "devmemory": {
      "command": "devmemory",
      "args": ["--project-dir", "/path/to/your/project"]
    }
  }
}
```

各 IDE 配置文件位置：

| IDE | 配置文件 |
|-----|---------|
| Kiro | `.kiro/settings/mcp.json` |
| Cursor | `.cursor/mcp.json` |
| Claude Code | `.mcp.json` |
| Windsurf | `.windsurf/mcp.json` |
| VSCode | `.vscode/mcp.json` |
| Trae | `.trae/mcp.json` |
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) |

## 换项目

每个项目需要独立配置。切换项目时：

```bash
cd /path/to/new/project
devmemory install
```

所有项目的记忆数据存储在 `~/.devmemory/memory.db`，通过 `project_dir` 字段隔离。

## Web 看板

```bash
devmemory web --project-dir /path/to/your/project --port 9080
```

浏览器访问 `http://localhost:9080`，可查看和管理记忆、会话状态、问题跟踪。

## 工具列表

| 工具 | 说明 |
|------|------|
| `remember` | 存入记忆，自动去重 |
| `recall` | 语义搜索记忆 |
| `forget` | 删除记忆 |
| `status` | 读取/更新会话状态 |
| `track` | 问题跟踪（create/update/archive/list） |
| `digest` | 按会话范围提取记忆摘要 |
| `auto_save` | 会话结束时自动保存关键信息 |

## 中国大陆用户

首次运行会自动下载 Embedding 模型（约 200MB）。如果下载慢，设置镜像：

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

或在 MCP 配置中添加 env：

```json
{
  "mcpServers": {
    "devmemory": {
      "command": "devmemory",
      "args": ["--project-dir", "."],
      "env": {
        "HF_ENDPOINT": "https://hf-mirror.com"
      }
    }
  }
}
```

## 依赖

- Python >= 3.10
- sqlite-vec >= 0.1.0
- onnxruntime >= 1.16
- tokenizers >= 0.15
- huggingface-hub >= 0.20
- numpy >= 1.24

## License

MIT
