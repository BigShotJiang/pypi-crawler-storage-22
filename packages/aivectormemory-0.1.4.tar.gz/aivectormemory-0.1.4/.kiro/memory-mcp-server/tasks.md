# 任务文档：DevMemory MCP Server

## 阶段 1：项目骨架与基础设施

- [x] 1.1 创建 `pyproject.toml`（包名 devmemory、依赖、入口点配置）
- [x] 1.2 创建目录结构（devmemory/、tools/、db/、embedding/、web/）
- [x] 1.3 实现 `config.py`（路径常量、默认值、模型名）
- [x] 1.4 实现 `errors.py`（统一错误格式 `{success, error, details}`）
- [x] 1.5 实现 `__main__.py`（命令行参数解析：`--project-dir`、子命令 serve/web）

## 阶段 2：数据层

- [x] 2.1 实现 `db/connection.py`（ConnectionManager：双数据库连接、WAL 模式、sqlite-vec 加载）
- [x] 2.2 实现 `db/schema.py`（建表语句：memories、vec_memories、session_state、issues）
- [x] 2.3 实现 `db/memory_repo.py`（insert、search_by_vector、delete、get_by_session_range）
- [x] 2.4 实现 `db/state_repo.py`（get、upsert 部分更新）
- [x] 2.5 实现 `db/issue_repo.py`（create、update、migrate、archive、list_by_date）
- [x] 2.6 测试数据层：验证建表、CRUD、WAL 模式、sqlite-vec 向量搜索（19 tests passed）

## 阶段 3：Embedding 层

- [x] 3.1 实现 `embedding/engine.py`（EmbeddingEngine：懒加载、模型下载、tokenize → ONNX 推理 → mean pooling → 归一化）
- [x] 3.2 测试 Embedding：验证模型加载、向量维度 384、中文文本编码正确

## 阶段 4：MCP 协议层

- [x] 4.1 实现 `protocol.py`（JSON-RPC 消息解析、响应构建、错误码）
- [x] 4.2 实现 `server.py`（主循环：stdin 读取 → 路由分发 → stdout 响应、session_id 管理）
- [x] 4.3 实现 `initialize` handler（返回 server info + capabilities，递增 session_id）
- [x] 4.4 实现 `tools/list` handler（返回 6 个工具的 JSON Schema）
- [x] 4.5 实现 `tools/call` 路由分发
- [x] 4.6 测试协议层：手动发送 JSON-RPC 消息验证握手和工具列表（4 tests passed）

## 阶段 5：工具实现

- [x] 5.1 实现 `tools/remember.py`（存入记忆 + 去重检查 + Embedding 计算）
- [x] 5.2 实现 `tools/recall.py`（向量搜索 + 双库合并 + 标签过滤）
- [x] 5.3 实现 `tools/forget.py`（删除记忆 + 向量索引）
- [x] 5.4 实现 `tools/status.py`（读取/部分更新会话状态）
- [x] 5.5 实现 `tools/track.py`（create/update/migrate/archive/list 五个 action）
- [x] 5.6 实现 `tools/digest.py`（按 session_id 范围提取记忆）
- [x] 5.7 集成测试：通过 stdio 调用每个工具，验证输入输出（5 tests passed）

## 阶段 6：IDE 集成测试

- [x] 6.1 配置 Kiro MCP（`.kiro/settings/mcp.json`），验证工具列表加载
- [x] 6.2 在 Kiro 中测试 remember → recall 流程
- [x] 6.3 在 Kiro 中测试 status 读写
- [x] 6.4 在 Kiro 中测试 track 全生命周期（create → update → archive）
- [x] 6.5 验证 `pip install -e .` 本地安装 + `devmemory --help` 可用

## 阶段 7：Web 看板

- [x] 7.1 实现 `web/app.py`（HTTP 服务、静态文件托管）
- [x] 7.2 实现 `web/api.py`（REST API 路由：memories/status/issues/stats）
- [x] 7.3 实现 `web/static/index.html`（页面结构：导航、记忆列表、状态、问题、统计）
- [x] 7.4 实现 `web/static/style.css`（样式）
- [x] 7.5 实现 `web/static/app.js`（交互逻辑：搜索、过滤、编辑、删除）
- [x] 7.6 测试 Web 看板：启动服务，验证各页面功能

## 阶段 8：打包发布

- [x] 8.1 完善 `pyproject.toml`（版本号、描述、license、README）
- [x] 8.2 创建 `.gitignore`（包含 `.devmemory/` 建议）
- [x] 8.3 验证 `pip install .` 本地安装
- [x] 8.4 验证 `uv pip install .` 安装
