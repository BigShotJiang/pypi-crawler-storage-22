# 项目规则

> 项目特有规则。全局通用规则（身份、核心原则、消息分类、自测要求等）存储在 devmemory 用户级记忆中，启动时通过 `recall` 自动加载。

---

## 常用命令

```bash
# 运行 MCP Server（stdio 模式，供 AI 助手集成）
.venv/bin/python -m devmemory --project-dir /Users/macos/item/run-memory-mcp-server

# 运行 Web 看板
.venv/bin/python -m devmemory web --project-dir /Users/macos/item/run-memory-mcp-server --port 9080

# 运行测试
.venv/bin/python -m pytest tests/

# 安装依赖（开发模式）
.venv/bin/pip install -e .
```

**环境说明**：
- Python 虚拟环境：`.venv/`
- 数据库位置：`~/.devmemory/memory.db`
- Embedding 模型：`intfloat/multilingual-e5-small`（HuggingFace 镜像：`HF_ENDPOINT=https://hf-mirror.com`）

---

## 启动检查

1. 调用 `recall` 查询与当前任务相关的记忆
2. 调用 `status` 检查会话状态
3. 调用 `track`（action=list）查看未完成的问题
4. 有阻塞 → 等用户反馈，禁止执行任何操作
5. 无阻塞 → 按正常流程执行

---

## 自动记忆规则（devmemory MCP）

以下场景必须主动调用 devmemory 工具，无需用户提醒：

**自动 recall（读取记忆）**：
- 对话开始时，`recall` 当前项目/任务相关的关键词
- 修改代码前，`recall` 相关模块名，检查是否有已知踩坑记录
- 遇到报错时，`recall` 错误关键词，避免重复踩坑

**自动 remember（存储记忆）**：
- 发现技术踩坑（命令失败、框架限制、环境问题）→ 立即 `remember`
- 做出架构决策或重要设计选择 → 立即 `remember`
- 解决了一个非显而易见的问题 → `remember` 问题原因和解决方案
- 标签规范：`["踩坑"]`、`["架构"]`、`["解决方案"]`、`["环境"]`

**自动 status（同步状态）**：
- 开始新任务 → `status` 更新 current_task
- 完成子任务 → `status` 更新 progress
- 遇到阻塞 → `status` 设置 is_blocked + block_reason
- 任务完成 → `status` 清理状态

**自动 track（问题跟踪）**：
- 发现新问题 → `track`（action=create）记录标题
- 问题状态变更 → `track`（action=update）
- 问题解决 → `track`（action=archive）

**自动 digest（记忆整理）**：
- 当 `recall` 返回大量碎片化结果时，调用 `digest` 归纳总结
- 长期未整理（跨多个会话）时，主动 `digest` 清理冗余记忆

**scope 使用规范**：
- `scope=project`：项目相关的踩坑、架构、配置
- `scope=user`：跨项目通用经验（环境配置、工具用法、个人偏好）
- `recall` 不确定时用 `scope=all`

**不要记忆的内容**：
- 临时调试信息、一次性操作
- 用户未确认的猜测性结论
- 已存在于代码注释或 README 中的信息

---

## 代码风格

**简洁优先**：
- 能用三目运算符，不用 if-else
- 能用短路求值，不用条件判断
- 能用解构赋值，不用逐个取值

**避免冗余**：
- 不写无意义的注释
- 不写重复的代码，提取公共函数
- 变量命名清晰，不需要注释解释

---

## 代码修改检查

**修改前**：
- 检查知识库是否有相关规定
- 必须先查看该功能的现有实现
- 涉及数据存储时，必须确认数据流向

**修改后**：
- Python：确认语法正确、类型一致
- 前端（如 web dashboard）：确认标签闭合、样式正确

---

## 任务执行

- 按任务顺序执行，禁止跳过
- 遇到问题自行解决，记录到问题跟踪
- 禁止用"后续迭代"跳过任务
- 一次只修一个问题，修复过程中发现新问题先记录再继续

---

## 完成标准

- 任务只有两种状态：**完成** 或 **未完成**
- 禁止"基本完成"、"差不多"、"大致实现"等模糊表述
- 完成确认流程：逐项检查 → 代码验证 → 功能测试 → 标记完成

---

## 错误处理

1. 记录已尝试的方法
2. 换一种思路解决
3. 仍然失败则询问用户

---

## 内容迁移/拆分

- 禁止凭记忆重写，必须从原文件逐行复制
- 创建索引后必须验证：引用的文件都存在，内容与原文件一致

---

## 上下文优化

- 优先搜索定位，再读取特定行
- 代码修改用编辑工具，不要先读后写整个文件

---

## 自检要求

完成任务前必须自问：
1. 排查是否完整？
2. 数据是否准确？
3. 逻辑是否严谨？
