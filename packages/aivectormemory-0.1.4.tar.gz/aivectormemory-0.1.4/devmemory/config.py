import os
from pathlib import Path

DB_DIR = Path.home() / ".devmemory"
DB_NAME = "memory.db"
MODEL_NAME = "intfloat/multilingual-e5-small"
MODEL_DIMENSION = 384
DEDUP_THRESHOLD = 0.95
USER_SCOPE_DIR = "@user@"
DEFAULT_TOP_K = 5
WEB_DEFAULT_PORT = 9080


def get_db_path() -> Path:
    return DB_DIR / DB_NAME


def get_project_dir(project_dir: str | None = None) -> str:
    return str(Path(project_dir).resolve()) if project_dir else str(Path.cwd().resolve())
