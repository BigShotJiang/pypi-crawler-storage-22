"""检查 aivectormemory 依赖是否能在当前 Python 版本解析"""
import subprocess, sys

deps = [
    "sqlite-vec>=0.1.0",
    "onnxruntime>=1.16",
    "tokenizers>=0.15",
    "huggingface-hub>=0.20",
    "numpy>=1.24",
]

print(f"Python: {sys.version}")
print(f"\n检查依赖解析...")

result = subprocess.run(
    [sys.executable, "-m", "pip", "install", "--dry-run", "--no-deps"] + deps,
    capture_output=True, text=True
)
print("stdout:", result.stdout[-500:] if result.stdout else "(empty)")
print("stderr:", result.stderr[-500:] if result.stderr else "(empty)")
print("returncode:", result.returncode)

# 尝试完整解析（含子依赖）
print("\n完整依赖解析（含子依赖）...")
result2 = subprocess.run(
    [sys.executable, "-m", "pip", "install", "--dry-run"] + deps,
    capture_output=True, text=True
)
print("stdout:", result2.stdout[-1000:] if result2.stdout else "(empty)")
print("stderr:", result2.stderr[-1000:] if result2.stderr else "(empty)")
print("returncode:", result2.returncode)
