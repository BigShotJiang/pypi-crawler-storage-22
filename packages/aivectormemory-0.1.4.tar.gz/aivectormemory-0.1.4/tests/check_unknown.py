import sqlite3, sqlite_vec
from pathlib import Path

db = Path.home() / ".devmemory" / "memory.db"
conn = sqlite3.connect(str(db))
conn.row_factory = sqlite3.Row
conn.enable_load_extension(True)
sqlite_vec.load(conn)
conn.enable_load_extension(False)

# 查找 project_dir 为空字符串的记录
rows = conn.execute("SELECT id, scope, project_dir, substr(content,1,50) as preview, tags FROM memories WHERE project_dir=''").fetchall()
print(f"project_dir='' 的记录数: {len(rows)}")
for r in rows:
    print(f"  id={r['id']} scope={r['scope']} tags={r['tags']} preview={r['preview']}")

# 查找 project_dir='@user@' 的记录
rows2 = conn.execute("SELECT id, scope, project_dir, substr(content,1,50) as preview FROM memories WHERE project_dir='@user@'").fetchall()
print(f"\nproject_dir='@user@' 的记录数: {len(rows2)}")

# 查找所有不同的 project_dir
dirs = conn.execute("SELECT DISTINCT project_dir, COUNT(*) as cnt FROM memories GROUP BY project_dir").fetchall()
print(f"\n所有 project_dir:")
for d in dirs:
    print(f"  '{d['project_dir']}' -> {d['cnt']} 条")

conn.close()
