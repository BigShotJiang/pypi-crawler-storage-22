"""清理模拟脚本写入的测试数据"""
import sqlite3
import sqlite_vec
from pathlib import Path

db_path = Path.home() / ".devmemory" / "memory.db"
conn = sqlite3.connect(str(db_path))
conn.enable_load_extension(True)
sqlite_vec.load(conn)
conn.enable_load_extension(False)

# 找到要删除的 ID
rows = conn.execute("SELECT id FROM memories WHERE content IN ('用户偏好测试2', '决策测试1')").fetchall()
ids = [r[0] for r in rows]
print(f"要删除的 ID: {ids}")

for mid in ids:
    conn.execute("DELETE FROM memories WHERE id=?", (mid,))
    conn.execute("DELETE FROM vec_memories WHERE id=?", (mid,))

conn.commit()

total = conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
print(f"清理后总记忆数: {total}")
conn.close()
