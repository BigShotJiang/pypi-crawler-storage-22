"""清理数据库中 tmp 项目的残留数据"""
import sqlite3
from pathlib import Path

db = Path.home() / ".devmemory" / "memory.db"
conn = sqlite3.connect(str(db))
conn.row_factory = sqlite3.Row

# 查找 tmp 项目
rows = conn.execute(
    "SELECT project_dir, COUNT(*) as cnt FROM memories WHERE project_dir LIKE '%/tmp%' GROUP BY project_dir"
).fetchall()
print("tmp 项目记忆：")
for r in rows:
    print(f"  {r['project_dir']}: {r['cnt']} 条")

issue_rows = conn.execute(
    "SELECT project_dir, COUNT(*) as cnt FROM issues WHERE project_dir LIKE '%/tmp%' GROUP BY project_dir"
).fetchall()
print("tmp 项目问题（issues）：")
for r in issue_rows:
    print(f"  {r['project_dir']}: {r['cnt']} 条")

archive_rows = conn.execute(
    "SELECT project_dir, COUNT(*) as cnt FROM issues_archive WHERE project_dir LIKE '%/tmp%' GROUP BY project_dir"
).fetchall()
print("tmp 项目问题（archive）：")
for r in archive_rows:
    print(f"  {r['project_dir']}: {r['cnt']} 条")

state_rows = conn.execute(
    "SELECT project_dir FROM session_state WHERE project_dir LIKE '%/tmp%'"
).fetchall()
print("tmp 项目状态：")
for r in state_rows:
    print(f"  {r['project_dir']}")

# 删除
d1 = conn.execute("DELETE FROM memories WHERE project_dir LIKE '%/tmp%'").rowcount
d2 = conn.execute("DELETE FROM issues WHERE project_dir LIKE '%/tmp%'").rowcount
d3 = conn.execute("DELETE FROM issues_archive WHERE project_dir LIKE '%/tmp%'").rowcount
d4 = conn.execute("DELETE FROM session_state WHERE project_dir LIKE '%/tmp%'").rowcount
conn.commit()
conn.close()

print(f"\n已清理：memories={d1}, issues={d2}, issues_archive={d3}, session_state={d4}")
