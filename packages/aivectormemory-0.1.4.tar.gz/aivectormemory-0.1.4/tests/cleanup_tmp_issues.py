"""清理 pytest 产生的 tmp 目录 issues 残留"""
import sqlite3
import sqlite_vec
from pathlib import Path

db_path = Path.home() / ".devmemory" / "memory.db"
conn = sqlite3.connect(str(db_path))
conn.enable_load_extension(True)
sqlite_vec.load(conn)
conn.enable_load_extension(False)

cur = conn.execute("DELETE FROM issues WHERE project_dir LIKE '/private/var/folders/%'")
print(f"删除 issues: {cur.rowcount} 条")
cur2 = conn.execute("DELETE FROM issues_archive WHERE project_dir LIKE '/private/var/folders/%'")
print(f"删除 issues_archive: {cur2.rowcount} 条")
conn.commit()

rows = conn.execute("SELECT project_dir, COUNT(*) as cnt FROM issues GROUP BY project_dir").fetchall()
print(f"\n剩余 issues:")
for r in rows:
    print(f"  {r[0] or '(空)'}: {r[1]}")
conn.close()
