---
sidebar_label: ownership_type
title: aixplain.enums.ownership_type
---

#### \_\_author\_\_

Copyright 2023 The aiXplain SDK authors

Licensed under the Apache License, Version 2.0 (the &quot;License&quot;);
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an &quot;AS IS&quot; BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Author: aiXplain team
Date: November 22nd 2023
Description:
    Asset Ownership Type

### OwnershipType Objects

```python
class OwnershipType(Enum)
```

[[view_source]](https://github.com/aixplain/aiXplain/blob/main/aixplain/enums/ownership_type.py#L27)

Enumeration of possible ownership types.

This enum defines the different types of ownership that can be associated with
an asset or resource, including subscribed and owned ownership.

**Attributes**:

- `SUBSCRIBED` _str_ - Subscribed ownership type.
- `OWNED` _str_ - Owned ownership type.

#### \_\_str\_\_

```python
def __str__()
```

[[view_source]](https://github.com/aixplain/aiXplain/blob/main/aixplain/enums/ownership_type.py#L40)

Return the string representation of the ownership type.

**Returns**:

- `str` - The ownership type value as a string.

