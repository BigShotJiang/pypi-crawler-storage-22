"""
AI Gateway integration for AIXtools.

Provides unified access to multiple cloud AI providers through AstraZeneca's AI Gateway
proxy service (portal.ai-gateway.astrazeneca.net).

Supported Models (as of 2026-02-03)
===================================

| Name | ID | Provider | Endpoint |
|------|----|----------|----------|
| Amazon Nova Canvas | amazon.nova-canvas-v1:0 | AWS Bedrock | /bedrock |
| Amazon Nova Lite | us.amazon.nova-lite-v1:0 | AWS Bedrock | /bedrock |
| Amazon Nova Micro | us.amazon.nova-micro-v1:0 | AWS Bedrock | /bedrock |
| Amazon Nova Premier | us.amazon.nova-premier-v1:0 | AWS Bedrock | /bedrock |
| Amazon Nova Pro | us.amazon.nova-pro-v1:0 | AWS Bedrock | /bedrock |
| Claude 3 Haiku | us.anthropic.claude-3-haiku-20240307-v1:0 | AWS Bedrock | /bedrock |
| Claude 3 Opus | us.anthropic.claude-3-opus-20240229-v1:0 | AWS Bedrock | /bedrock |
| Claude 3 Sonnet | us.anthropic.claude-3-sonnet-20240229-v1:0 | AWS Bedrock | /bedrock |
| Claude 3.5 Haiku | us.anthropic.claude-3-5-haiku-20241022-v1:0 | AWS Bedrock | /bedrock |
| Claude 3.5 Sonnet | us.anthropic.claude-3-5-sonnet-20240620-v1:0 | AWS Bedrock | /bedrock |
| Claude 3.5 Sonnet v2 | us.anthropic.claude-3-5-sonnet-20241022-v2:0 | AWS Bedrock | /bedrock |
| Claude 3.7 Sonnet | us.anthropic.claude-3-7-sonnet-20250219-v1:0 | AWS Bedrock | /bedrock |
| Claude Haiku 4.5 | us.anthropic.claude-haiku-4-5-20251001-v1:0 | AWS Bedrock | /bedrock |
| Claude Opus 4 | us.anthropic.claude-opus-4-20250514-v1:0 | AWS Bedrock | /bedrock |
| Claude Opus 4.1 | us.anthropic.claude-opus-4-1-20250805-v1:0 | AWS Bedrock | /bedrock |
| Claude Opus 4.5 | us.anthropic.claude-opus-4-5-20251101-v1:0 | AWS Bedrock | /bedrock |
| Claude Sonnet 4 | us.anthropic.claude-sonnet-4-20250514-v1:0 | AWS Bedrock | /bedrock |
| Claude Sonnet 4.5 | us.anthropic.claude-sonnet-4-5-20250929-v1:0 | AWS Bedrock | /bedrock |
| Command R | cohere.command-r-v1:0 | AWS Bedrock | /bedrock |
| Command R+ | cohere.command-r-plus-v1:0 | AWS Bedrock | /bedrock |
| DeepSeek-R1 | DeepSeek-R1 | Azure OpenAI | /azure-openai |
| Embed 3 English | cohere.embed-english-v3 | AWS Bedrock | /bedrock |
| Embed 3 Multilingual | cohere.embed-multilingual-v3 | AWS Bedrock | /bedrock |
| Gemini 2.0 Flash-Lite | gemini-2.0-flash-lite | Google Vertex AI | /vertex-ai-express |
| Gemini 2.0 Flash-Lite (OpenAI) | google/gemini-2.0-flash-lite | Google Vertex AI | /vertex-ai-openai |
| Gemini 2.5 Flash | gemini-2.5-flash | Google Vertex AI | /vertex-ai-express |
| Gemini 2.5 Flash (OpenAI) | google/gemini-2.5-flash | Google Vertex AI | /vertex-ai-openai |
| Gemini 2.5 Flash-Lite | gemini-2.5-flash-lite | Google Vertex AI | /vertex-ai-express |
| Gemini 2.5 Flash-Lite (OpenAI) | google/gemini-2.5-flash-lite | Google Vertex AI | /vertex-ai-openai |
| Gemini 2.5 Pro | gemini-2.5-pro | Google Vertex AI | /vertex-ai-express |
| Gemini 2.5 Pro (OpenAI) | google/gemini-2.5-pro | Google Vertex AI | /vertex-ai-openai |
| Gemini 3 Flash Preview | gemini-3-flash-preview | Google Vertex AI | /vertex-ai-express |
| Gemini 3 Flash Preview (OpenAI) | google/gemini-3-flash-preview | Google Vertex AI | /vertex-ai-openai |
| Gemini 3 Pro Preview | gemini-3-pro-preview | Google Vertex AI | /vertex-ai-express |
| Gemini 3 Pro Preview (OpenAI) | google/gemini-3-pro-preview | Google Vertex AI | /vertex-ai-openai |
| Gemini Embedding 001 | gemini-embedding-001 | Google Vertex AI | /vertex-ai-express |
| Gemma 3 4B | google.gemma-3-4b-it | AWS Bedrock | /bedrock |
| Gemma 3 12B | google.gemma-3-12b-it | AWS Bedrock | /bedrock |
| Gemma 3 27B | google.gemma-3-27b-it | AWS Bedrock | /bedrock |
| GPT Image 1 | gpt-image-1 | Azure OpenAI | /azure-openai |
| GPT-4.1 | gpt-4.1 | Azure OpenAI | /azure-openai |
| GPT-4.1 Mini | gpt-4.1-mini | Azure OpenAI | /azure-openai |
| GPT-4.1 Nano | gpt-4.1-nano | Azure OpenAI | /azure-openai |
| GPT-4o | gpt-4o | Azure OpenAI | /azure-openai |
| GPT-4o Audio Preview | gpt-4o-audio-preview | Azure OpenAI | /azure-openai |
| GPT-4o Mini | gpt-4o-mini | Azure OpenAI | /azure-openai |
| GPT-4o Mini Audio Preview | gpt-4o-mini-audio-preview | Azure OpenAI | /azure-openai |
| GPT-4o Mini Transcribe | gpt-4o-mini-transcribe | Azure OpenAI | /azure-openai |
| GPT-4o Mini TTS | gpt-4o-mini-tts | Azure OpenAI | /azure-openai |
| GPT-4o Transcribe | gpt-4o-transcribe | Azure OpenAI | /azure-openai |
| GPT-5 | gpt-5 | Azure OpenAI | /azure-openai |
| GPT-5 Chat | gpt-5-chat | Azure OpenAI | /azure-openai |
| GPT-5 Mini | gpt-5-mini | Azure OpenAI | /azure-openai |
| GPT-5 Nano | gpt-5-nano | Azure OpenAI | /azure-openai |
| Grok 3 | grok-3 | Azure OpenAI | /azure-openai |
| Grok 4 | grok-4 | Azure OpenAI | /azure-openai |
| Llama 3 70B Instruct | meta.llama3-70b-instruct-v1:0 | AWS Bedrock | /bedrock |
| Llama 3 8B Instruct | meta.llama3-8b-instruct-v1:0 | AWS Bedrock | /bedrock |
| Llama 3.1 70B Instruct | us.meta.llama3-1-70b-instruct-v1:0 | AWS Bedrock | /bedrock |
| Llama 3.1 8B Instruct | us.meta.llama3-1-8b-instruct-v1:0 | AWS Bedrock | /bedrock |
| Llama 3.2 1B Instruct | us.meta.llama3-2-1b-instruct-v1:0 | AWS Bedrock | /bedrock |
| Llama 3.2 3B Instruct | us.meta.llama3-2-3b-instruct-v1:0 | AWS Bedrock | /bedrock |
| o1 | o1 | Azure OpenAI | /azure-openai |
| o3 | o3 | Azure OpenAI | /azure-openai |
| o3 Mini | o3-mini | Azure OpenAI | /azure-openai |
| o4 Mini | o4-mini | Azure OpenAI | /azure-openai |
| Text Embedding 3 Large | text-embedding-3-large | Azure OpenAI | /azure-openai |
| Text Embedding 3 Small | text-embedding-3-small | Azure OpenAI | /azure-openai |
| Text Embedding Ada 002 | text-embedding-ada-002 | Azure OpenAI | /azure-openai |
| Titan Image Embeddings | amazon.titan-embed-image-v1 | AWS Bedrock | /bedrock |
| Titan Image Generator v2 | amazon.titan-image-generator-v2:0 | AWS Bedrock | /bedrock |
| Titan Text Embeddings | amazon.titan-embed-text-v1 | AWS Bedrock | /bedrock |
| Titan Text Embeddings V2 | amazon.titan-embed-text-v2:0 | AWS Bedrock | /bedrock |

**73 models total** across 3 providers (AWS Bedrock, Azure OpenAI, Google Vertex AI)

Configuration
=============

Set these environment variables:

    MODEL_FAMILY=ai-gateway
    AI_GATEWAY_URL=https://ai-gateway.example.net
    AI_GATEWAY_KEY=your-subscription-key
    AI_GATEWAY_MODEL_NAME=us.anthropic.claude-sonnet-4-5-20250929-v1:0

The backend provider is auto-detected from the model name. Override with AI_GATEWAY_PROVIDER
if auto-detection fails (bedrock | azure | vertex-openai).
"""

import os

import boto3
from botocore.config import Config
from openai import AsyncAzureOpenAI, AsyncOpenAI
from pydantic_ai.models.bedrock import BedrockConverseModel
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.bedrock import BedrockProvider
from pydantic_ai.providers.openai import OpenAIProvider

from aixtools.logging.logging_config import get_logger

logger = get_logger(__name__)


def infer_gateway_provider(model_name: str) -> str:
    """Infer the gateway backend provider from model name patterns.

    Based on models available at portal.ai-gateway.astrazeneca.net/models:
    - Bedrock: anthropic.*, amazon.*, meta.*, cohere.*, google.gemma-* prefixes
    - Azure: gpt-*, o1/o3/o4-*, deepseek-*, grok-*, text-embedding-* models
    - Vertex AI: gemini-*, google/* models
    """
    model_lower = model_name.lower()

    # Bedrock: AWS-hosted models (Anthropic, Amazon, Meta, Cohere, Google Gemma)
    bedrock_prefixes = ("anthropic.", "amazon.", "meta.", "cohere.", "us.", "google.gemma")
    if model_lower.startswith(bedrock_prefixes):
        return "bedrock"

    # Azure: OpenAI models, DeepSeek, Grok, and embeddings
    azure_prefixes = ("gpt-", "o1", "o3", "o4-", "deepseek", "grok-", "text-embedding-")
    if model_lower.startswith(azure_prefixes):
        return "azure"

    # Vertex AI: Google Gemini models (native and OpenAI-compatible)
    if model_lower.startswith(("gemini-", "google/")):
        return "vertex-openai"

    raise ValueError(
        f"Cannot infer AI_GATEWAY_PROVIDER from model '{model_name}'. "
        "Set AI_GATEWAY_PROVIDER explicitly (bedrock | azure | vertex-openai)"
    )


def get_model_gateway_bedrock(gateway_url: str, gateway_key: str, model_name: str):
    """Create Bedrock model via AI Gateway proxy.

    Note: Sets AWS_BEARER_TOKEN_BEDROCK environment variable which is process-global.
    Concurrent calls with different gateway keys may experience race conditions.
    """
    logger.debug("Bedrock gateway_url: %s", gateway_url)
    logger.debug("Bedrock gateway_key set: %s", bool(gateway_key))
    logger.debug("Bedrock model_name: %s", model_name)

    os.environ["AWS_BEARER_TOKEN_BEDROCK"] = gateway_key
    bedrock_client = boto3.client(
        service_name="bedrock-runtime",
        region_name="us-east-1",
        endpoint_url=f"{gateway_url}/bedrock",
        aws_access_key_id="",
        aws_secret_access_key="",
        config=Config(retries={"max_attempts": 0}),
    )
    return BedrockConverseModel(model_name=model_name, provider=BedrockProvider(bedrock_client=bedrock_client))


def get_model_gateway_azure(gateway_url: str, gateway_key: str, model_name: str):
    """Create Azure OpenAI model via AI Gateway proxy."""
    client = AsyncAzureOpenAI(
        azure_endpoint=f"{gateway_url}/azure-openai",
        api_version="2025-01-01-preview",
        api_key=gateway_key,
    )
    return OpenAIChatModel(model_name, provider=OpenAIProvider(openai_client=client))


def get_model_gateway_vertex_openai(gateway_url: str, gateway_key: str, model_name: str):
    """Create Vertex AI model via AI Gateway proxy using OpenAI-compatible endpoint."""
    client = AsyncOpenAI(
        base_url=f"{gateway_url}/vertex-ai-openai/v1",
        api_key=gateway_key,
    )
    return OpenAIChatModel(model_name, provider=OpenAIProvider(openai_client=client))


def get_model_ai_gateway(
    gateway_url=None,
    gateway_key=None,
    gateway_provider=None,
    model_name=None,
):
    """Create model via AI Gateway proxy with auto-detected provider.

    Args:
        gateway_url: AI Gateway base URL (default: AI_GATEWAY_URL env var)
        gateway_key: API subscription key (default: AI_GATEWAY_KEY env var)
        gateway_provider: Override auto-detection (bedrock | azure | vertex-openai)
        model_name: Model ID (default: AI_GATEWAY_MODEL_NAME env var)

    Returns:
        PydanticAI model instance configured for the gateway
    """
    # Read from env at call time (not import time) to allow runtime overrides
    gateway_url = gateway_url or os.environ.get("AI_GATEWAY_URL")
    gateway_key = gateway_key or os.environ.get("AI_GATEWAY_KEY")
    gateway_provider = gateway_provider or os.environ.get("AI_GATEWAY_PROVIDER")
    model_name = model_name or os.environ.get("AI_GATEWAY_MODEL_NAME")

    logger.debug("AI Gateway - URL: %s", gateway_url)
    logger.debug("AI Gateway - Key set: %s", bool(gateway_key))
    logger.debug("AI Gateway - Model: %s, Provider: %s", model_name, gateway_provider or "auto-detect")

    assert gateway_url, "AI_GATEWAY_URL is not set"
    assert gateway_key, "AI_GATEWAY_KEY is not set"
    assert model_name, "AI_GATEWAY_MODEL_NAME is not set"

    # Auto-detect provider if not explicitly set
    if not gateway_provider:
        gateway_provider = infer_gateway_provider(model_name)

    match gateway_provider:
        case "bedrock":
            return get_model_gateway_bedrock(gateway_url, gateway_key, model_name)
        case "azure":
            return get_model_gateway_azure(gateway_url, gateway_key, model_name)
        case "vertex-openai":
            return get_model_gateway_vertex_openai(gateway_url, gateway_key, model_name)
        case _:
            raise ValueError(f"AI_GATEWAY_PROVIDER '{gateway_provider}' not supported")
