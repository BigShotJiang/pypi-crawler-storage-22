# 快速开始

欢迎使用 AKQuant！让我们用最快的速度运行一个最简单的策略。

## 1. 安装

打开终端，运行：

```bash
pip install akquant
```

## 2. 极简示例：买入并持有

复制下面的代码到 `quickstart.py` 并运行。这个策略非常简单：**在第一天买入 100 股，然后一直持有**。

```python
import pandas as pd
from akquant import Strategy, run_backtest

# 1. 策略定义
class BuyAndHold(Strategy):
    def on_bar(self, bar):
        # 如果当前没有持仓，就买入 100 股
        if self.get_position(bar.symbol) == 0:
            print(f"[{bar.timestamp_str}] 买入 {bar.symbol}")
            self.buy(bar.symbol, 100)

# 2. 准备数据 (这里生成一个简单的模拟数据)
dates = pd.date_range("2023-01-01", periods=100)
df = pd.DataFrame({
    "date": dates,
    "open": 10.0, "high": 11.0, "low": 9.0, "close": 10.0, # 假设价格一直横盘
    "volume": 1000,
    "symbol": "DEMO"
})

# 3. 运行回测
print("开始回测...")
result = run_backtest(
    data=df,
    strategy=BuyAndHold,
    cash=10000.0
)

# 4. 查看结果
print(result)
```

运行结果中，你会看到 `total_return` (总收益), `max_drawdown` (最大回撤) 等核心指标。

## 3. 进阶学习

刚才的例子太简单了？想要学习如何编写真正的量化策略（如双均线、MACD 等）？

👉 **请阅读 [手把手教程：编写你的第一个量化策略](tutorial.md)**

该教程将详细讲解：

*   如何获取历史数据 (`get_history`)
*   如何计算技术指标 (MA, RSI)
*   如何止盈止损
