# 示例代码

`akquant` 提供了多个示例脚本，涵盖了从基础回测到 Tick 数据回测的各种场景。您可以在 `examples/` 目录下找到这些文件的完整源码。

## 1. 简单回测 (`simple_backtest.py`)

这是一个最基础的示例，展示了如何：
1.  生成模拟正弦波数据。
2.  定义一个最简单的策略。
3.  运行回测并打印结果。

[查看源码](https://github.com/yourusername/akquant/blob/main/examples/simple_backtest.py)

## 2. AKShare 真实数据回测 (`akshare_backtest.py`)

展示了如何结合 AKShare 库使用真实市场数据进行回测：
*   **DataLoader**: 自动下载并缓存 A 股历史数据。
*   **StrategyConfig**: 配置资金、费率（印花税、佣金）。
*   **SMA 策略**: 经典的双均线策略实现。

[查看源码](https://github.com/yourusername/akquant/blob/main/examples/akshare_backtest.py)

## 3. 完整策略回测 (`full_backtest.py`)

这是一个更接近实战的示例，包含：
*   **双均线策略**: 结合价格突破逻辑。
*   **资金管理**: 动态计算买入数量。
*   **可视化**: 使用 `matplotlib` 绘制价格、均线和权益曲线，并支持中文字体。
*   **交易记录**: 打印详细的买卖操作和手续费。

[查看源码](https://github.com/yourusername/akquant/blob/main/examples/full_backtest.py)

## 4. Tick 数据回测 (`tick_backtest.py`)

展示了 `akquant` 处理高频 Tick 数据的能力：
*   生成模拟的高频 Tick 数据流。
*   定义 `TickStrategy`，在 `on_tick` 回调中处理每一笔行情。
*   实现了一个简单的盘口价差策略。

[查看源码](https://github.com/yourusername/akquant/blob/main/examples/tick_backtest.py)

## 5. 风险控制与配置 (`risk_test.py`)

展示了 `akquant` 强大的风险管理模块：
*   **配置**: 使用 `RiskConfig` 设置最大订单比例、最大持仓比例等。
*   **黑名单**: 设置禁止交易的 `restricted_list`。
*   **验证**: 演示订单因触发风控规则而被拒绝的场景。

[查看源码](https://github.com/yourusername/akquant/blob/main/examples/risk_test.py)

## 6. 性能基准测试 (`benchmark_akquant.py`)

展示了 `akquant` 的极致性能：
*   生成 200,000+ 条 K 线数据。
*   运行 SMA 策略并记录耗时。
*   对比 Backtrader 和 PyBroker 的运行效率。

[查看源码](https://github.com/yourusername/akquant/blob/main/examples/benchmark_akquant.py)

## 7. Zipline 风格在线回测 (`zipline_style_backtest.py`)

展示了如何使用类似 Zipline 的函数式 API (`initialize` + `on_bar`) 进行回测，支持**在线指标计算**：

*   **API**: 使用 `run_backtest` 简化配置。
*   **历史数据**: 通过 `history_depth` 参数自动维护历史数据，并在 `on_bar` 中使用 `ctx.get_history()` 获取 Numpy 数组。
*   **灵活性**: 适合需要动态计算指标或复杂逻辑的场景，无需预先计算向量化指标。

[查看源码](https://github.com/yourusername/akquant/blob/main/examples/zipline_style_backtest.py)
