# 快速开始

本指南将带您快速上手 `akquant`，从简单的手动数据回测到使用 AKShare 真实数据回测。

## 1. 基础示例 (手动数据)

这个示例展示了如何创建一个简单的策略并使用手动构造的数据进行回测。

```python
import akquant
from akquant import Engine, Strategy, DataFeed, Bar, AssetType, Instrument
from datetime import datetime

# 1. 定义策略
class MyStrategy(Strategy):
    def on_bar(self, bar):
        # 简单的双均线逻辑模拟
        # 实际开发中可以使用 akquant.Indicator 或 talib 计算指标
        
        # 获取当前持仓
        position = self.ctx.position.size
        
        # 简单的价格突破逻辑
        if bar.close > 100.0 and position == 0:
            print(f"[{datetime.fromtimestamp(bar.timestamp)}] 价格 {bar.close} > 100, 买入")
            self.buy(quantity=100.0) # 使用默认 symbol
            
        elif bar.close <= 100.0 and position > 0:
            print(f"[{datetime.fromtimestamp(bar.timestamp)}] 价格 {bar.close} <= 100, 卖出")
            self.sell(quantity=float(position))

# 2. 准备环境
engine = Engine()
feed = DataFeed()

# 3. 添加合约 (股票)
engine.add_instrument(Instrument("AAPL", AssetType.Stock, 1.0, 0.01))

# 4. 添加数据
feed.add_bar(Bar(
    timestamp="2023-01-01", 
    open=95.0, high=105.0, low=90.0, close=102.0,
    volume=1000.0, symbol="AAPL"
))
feed.add_bar(Bar(
    timestamp="2023-01-02",
    open=101.0, high=103.0, low=98.0, close=99.0,
    volume=1200.0, symbol="AAPL"
))
engine.add_data(feed)

# 5. 运行回测
print("开始回测...")
result = engine.run(MyStrategy())

# 6. 查看结果
print(f"Total Return: {result.metrics.total_return:.2%}")
```

## 2. 进阶示例 (AKShare 真实数据)

这个示例展示了如何使用便捷函数 `run_backtest` 快速运行基于 AKShare 数据的回测。

```python
import akquant
from akquant.backtest import run_backtest
from akquant import Strategy

# 1. 定义策略
class SmaStrategy(Strategy):
    def on_bar(self, bar):
        # 简单策略：价格高于均价时买入，否则卖出
        # 注意：实际中建议使用 IndicatorSet 进行向量化计算
        if self.ctx.position.size == 0:
            self.buy(symbol=bar.symbol, quantity=100)
        elif bar.close > self.ctx.position.avg_price * 1.1:
            self.sell(symbol=bar.symbol, quantity=100)

# 2. 运行回测
# run_backtest 会自动处理：
# - 数据下载与缓存 (默认 ~/.akquant/cache)
# - 合约信息注册 (默认 A股 T+1)
# - 资金与费率配置
result = run_backtest(
    strategy=SmaStrategy,
    symbol="600000",       # 浦发银行
    start_date="20230101",
    end_date="20230630",
    cash=500_000.0,        # 初始资金
    commission=0.0003,     # 万三佣金
    stamp_tax=0.0005       # 印花税 (A股默认千一，可覆盖)
)

# 3. 查看结果
print(f"Total Return: {result.metrics.total_return:.2%}")
print(f"Sharpe Ratio: {result.metrics.sharpe_ratio:.2f}")
print(f"Max Drawdown: {result.metrics.max_drawdown:.2%}")
```

## 3. 多品种回测 (期货/期权)

`akquant` 支持股票、基金、期货、期权等多种资产类型的回测，并内置了相应的交易规则（如股票买入 100 股限制、期权按张收费等）。

### 期货回测示例

```python
from akquant import AssetType

result = run_backtest(
    strategy=MyFuturesStrategy,
    symbol="IF2306",
    asset_type=AssetType.Futures,
    multiplier=300.0,      # 合约乘数
    margin_ratio=0.12,     # 保证金比率
    commission=0.000023,   # 期货佣金
    # ...
)
```

### 期权回测示例

```python
from akquant import AssetType, OptionType

result = run_backtest(
    strategy=MyOptionStrategy,
    symbol="10005555",
    asset_type=AssetType.Option,
    option_type=OptionType.Call,
    strike_price=3.5,
    option_commission=5.0, # 每张 5 元
    multiplier=10000.0,
    # ...
)
```

## 4. 函数式 API (Zipline 风格)

如果你更喜欢函数式编程，或者需要迁移 Zipline 策略，可以使用 `initialize` 和 `on_bar` 函数：

```python
from akquant.backtest import run_backtest

def initialize(ctx):
    # 初始化全局变量
    ctx.stop_loss = 0.05

def on_bar(ctx, bar):
    if ctx.position.size == 0:
        ctx.buy(symbol=bar.symbol, quantity=100)
    elif bar.close < ctx.position.avg_price * (1 - ctx.stop_loss):
        ctx.sell(symbol=bar.symbol, quantity=100)

run_backtest(
    strategy=on_bar,
    initialize=initialize,
    symbol="600000",
    start_date="20230101",
    end_date="20230630"
)
```

## 下一步

*   查看 [API 参考](api.md) 了解更多细节。
*   浏览 [示例](examples.md) 学习更复杂的策略，包括指标计算和高级订单。
