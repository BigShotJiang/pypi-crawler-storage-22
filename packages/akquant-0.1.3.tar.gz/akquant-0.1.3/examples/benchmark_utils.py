import pandas as pd
import numpy as np
import time


def get_benchmark_data(n=200_000, symbol="BENCHMARK", freq="min", start_date="2020-01-01"):
    """
    Generates dummy market data using Geometric Brownian Motion.
    Ensures positive prices and consistency.
    """
    print(f"Generating {n} rows of dummy data...")
    t0 = time.time()

    dates = pd.date_range(start=start_date, periods=n, freq=freq, tz='UTC')
    # Add 15 hours to simulate market close time (15:00:00 UTC)
    dates = dates + pd.Timedelta(hours=15)

    # Random walk (Geometric Brownian Motion to ensure positive prices)
    # Use symbol hash to ensure different data for different symbols, 
    # but consistent data for the same symbol.
    seed_val = abs(hash(symbol)) % (2**32)
    np.random.seed(seed_val)
    returns = np.random.normal(0, 0.001, n)
    price = 100 * np.exp(np.cumsum(returns))

    df = pd.DataFrame(
        {
            "date": dates,
            "open": price * (1 + np.random.normal(0, 0.0005, n)),
            "high": price * (1 + np.abs(np.random.normal(0, 0.0005, n))),
            "low": price * (1 - np.abs(np.random.normal(0, 0.0005, n))),
            "close": price,
            "volume": np.random.randint(100, 10000, n),
            "symbol": [symbol] * n,
        }
    )

    # Ensure consistency (High >= Open/Close, Low <= Open/Close)
    df["high"] = df[["open", "high", "close"]].max(axis=1)
    df["low"] = df[["open", "low", "close"]].min(axis=1)

    # Add Chinese columns for Akquant compatibility if needed,
    # but Akquant example can rename them.
    # Let's keep standard English columns here.

    print(f"Data generation took {time.time() - t0:.4f}s")
    return df


def print_report(engine_name, duration, total_bars, total_return_pct, total_trades):
    """
    Prints a standardized benchmark report.
    """
    throughput = total_bars / duration if duration > 0 else 0

    print("-" * 50)
    print(f"Backtest Results ({engine_name})")
    print("-" * 50)
    print(f"Data Size     : {total_bars} bars")
    print(f"Execution Time: {duration:.4f} s")
    print(f"Throughput    : {throughput:,.0f} bars/sec")
    print(f"Total Return  : {total_return_pct:.2f}%")
    print(f"Total Trades  : {total_trades}")
    print("-" * 50)
