from .akquant import *
from .utils import load_akshare_bar, prepare_dataframe
from .sizer import Sizer, FixedSize, PercentSizer, AllInSizer
from .strategy import Strategy
from .data import DataLoader
from .log import get_logger, register_logger
from .config import strategy_config
from .indicator import Indicator, IndicatorSet
from .backtest import run_backtest, plot_result

__doc__ = akquant.__doc__
if hasattr(akquant, "__all__"):
    __all__ = akquant.__all__ + [
        "load_akshare_bar",
        "prepare_dataframe",
        "Sizer",
        "FixedSize",
        "PercentSizer",
        "AllInSizer",
        "Strategy",
        "DataLoader",
        "get_logger",
        "register_logger",
        "strategy_config",
        "Indicator",
        "IndicatorSet",
        "run_backtest",
        "plot_result",
    ]
else:
    __all__ = [
        "load_akshare_bar",
        "prepare_dataframe",
        "Sizer",
        "FixedSize",
        "PercentSizer",
        "AllInSizer",
        "Strategy",
        "DataLoader",
        "get_logger",
        "register_logger",
        "strategy_config",
        "Indicator",
        "IndicatorSet",
        "run_backtest",
        "plot_result",
    ]


def create_bar(timestamp, open_px, high_px, low_px, close_px, volume, symbol):
    """创建 Bar 对象的辅助函数"""
    return Bar(timestamp, open_px, high_px, low_px, close_px, volume, symbol)


def _engine_set_timezone_name(self, tz_name: str):
    """
    通过时区名称设置引擎时区

    :param tz_name: 时区名称，例如 "Asia/Shanghai", "UTC", "US/Eastern"
    """
    import datetime

    try:
        import zoneinfo

        tz = zoneinfo.ZoneInfo(tz_name)
    except ImportError:
        import pytz

        tz = pytz.timezone(tz_name)

    # Get offset for current time (approximate is usually fine for constant offset zones,
    # but for DST aware zones, we might want a specific date.
    # For simplicity and standard market hours, we use current date or a fixed date)
    now = datetime.datetime.now(tz)
    offset = int(now.utcoffset().total_seconds())
    self.set_timezone(offset)


# Patch Engine class
Engine.set_timezone_name = _engine_set_timezone_name
