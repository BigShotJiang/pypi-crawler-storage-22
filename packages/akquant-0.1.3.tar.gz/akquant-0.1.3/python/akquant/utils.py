import pandas as pd
from typing import List, Optional
from .akquant import Bar, from_arrays


def load_akshare_bar(df: pd.DataFrame, symbol: Optional[str] = None) -> List[Bar]:
    r"""
    将 AKShare 返回的 DataFrame 转换为 akquant.Bar 列表

    :param df: AKShare 历史行情数据
    :type df: pandas.DataFrame
    :param symbol: 标的代码；未提供时尝试使用 DataFrame 的“股票代码”列
    :type symbol: str, optional
    :return: 转换后的 Bar 对象列表
    :rtype: List[Bar]
    """
    if df.empty:
        return []

    # Check for required columns
    required_map = {
        "日期": "timestamp",
        "开盘": "open",
        "最高": "high",
        "最低": "low",
        "收盘": "close",
        "成交量": "volume",
    }

    # Validate columns
    missing = [col for col in required_map.keys() if col not in df.columns]
    if missing:
        raise ValueError(f"DataFrame 缺少必要列: {missing}")

    # Vectorized Preprocessing

    # 1. Handle Timestamp
    # Convert to datetime with error coercion (invalid dates becomes NaT)
    dt_series = pd.to_datetime(df["日期"], errors="coerce")
    # Fill NaT with 0 (Epoch 0) or handle appropriately
    dt_series = dt_series.fillna(pd.Timestamp(0))
    if dt_series.dt.tz is None:
        dt_series = dt_series.dt.tz_localize("Asia/Shanghai")
    dt_series = dt_series.dt.tz_convert("UTC")
    timestamps = dt_series.astype("int64").tolist()

    # 2. Extract numeric columns
    # Use astype(float) to ensure correct type, fillna(0.0) for safety
    opens = df["开盘"].fillna(0.0).astype(float).tolist()
    highs = df["最高"].fillna(0.0).astype(float).tolist()
    lows = df["最低"].fillna(0.0).astype(float).tolist()
    closes = df["收盘"].fillna(0.0).astype(float).tolist()
    volumes = df["成交量"].fillna(0.0).astype(float).tolist()

    # 3. Handle Symbol
    symbols_list = None
    symbol_val = None

    if symbol:
        symbol_val = symbol
    elif "股票代码" in df.columns:
        # Convert to string
        symbols_list = df["股票代码"].astype(str).tolist()
    else:
        symbol_val = "UNKNOWN"

    # Call Rust extension
    return from_arrays(
        timestamps, opens, highs, lows, closes, volumes, symbol_val, symbols_list
    )


def df_to_arrays(df: pd.DataFrame, symbol: Optional[str] = None):
    r"""
    将 DataFrame 转换为用于 DataFeed.add_arrays 的数组元组
    
    :return: (timestamps, opens, highs, lows, closes, volumes, symbol_val, symbols_list)
    """
    if df.empty:
        return ([], [], [], [], [], [], symbol, None)

    # Check for required columns
    required_map = {
        "日期": "timestamp",
        "开盘": "open",
        "最高": "high",
        "最低": "low",
        "收盘": "close",
        "成交量": "volume",
    }
    
    # ... logic reused ...
    # 为了避免重复代码，我们应该重构 load_akshare_bar
    # 但为了最小化修改风险，我先把逻辑复制过来，或者调用 load_akshare_bar 内部逻辑
    
    # 既然 load_akshare_bar 已经有了逻辑，我们把它提取出来
    
    # 1. Handle Timestamp
    dt_series = pd.to_datetime(df["日期"], errors="coerce")
    dt_series = dt_series.fillna(pd.Timestamp(0))
    if dt_series.dt.tz is None:
        dt_series = dt_series.dt.tz_localize("Asia/Shanghai")
    dt_series = dt_series.dt.tz_convert("UTC")
    timestamps = dt_series.astype("int64").values

    # 2. Extract numeric columns
    opens = df["开盘"].fillna(0.0).astype(float).values
    highs = df["最高"].fillna(0.0).astype(float).values
    lows = df["最低"].fillna(0.0).astype(float).values
    closes = df["收盘"].fillna(0.0).astype(float).values
    volumes = df["成交量"].fillna(0.0).astype(float).values

    # 3. Handle Symbol
    symbols_list = None
    symbol_val = None

    if symbol:
        symbol_val = symbol
    elif "股票代码" in df.columns:
        symbols_list = df["股票代码"].astype(str).tolist() # Strings still need list or object array
    else:
        symbol_val = "UNKNOWN"
        
    return (timestamps, opens, highs, lows, closes, volumes, symbol_val, symbols_list)



def prepare_dataframe(
    df: pd.DataFrame, date_col: Optional[str] = None, tz: str = "Asia/Shanghai"
) -> pd.DataFrame:
    r"""
    自动预处理 DataFrame，处理时区并生成标准时间戳列

    :param df: 输入 DataFrame
    :param date_col: 日期列名 (若为 None 则自动探测)
    :param tz: 默认时区 (若数据为 Naive 时间，则假定为此时区)
    :return: 处理后的 DataFrame (包含 'timestamp' 列)
    """
    df = df.copy()

    # 1. Auto-detect date column
    if date_col is None:
        candidates = ["date", "datetime", "time", "timestamp", "日期", "时间"]
        for c in candidates:
            if c in df.columns:
                date_col = c
                break

    if date_col and date_col in df.columns:
        # 2. Convert to datetime
        dt = pd.to_datetime(df[date_col], errors="coerce")

        # 3. Handle Timezone
        if dt.dt.tz is None:
            dt = dt.dt.tz_localize(tz)

        # 4. Convert to UTC
        dt = dt.dt.tz_convert("UTC")

        # 5. Assign back
        df[date_col] = dt
        df["timestamp"] = dt.astype("int64")
    else:
        # Warn or ignore? For now silent, user might be processing non-time data?
        pass

    return df
