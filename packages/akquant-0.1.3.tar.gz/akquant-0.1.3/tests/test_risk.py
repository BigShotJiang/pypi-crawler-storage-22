from akquant import RiskManager, Portfolio, Order, OrderSide, OrderType, TimeInForce


def create_order(symbol, quantity, price):
    return Order(
        id="test_id",
        symbol=symbol,
        side=OrderSide.Buy,
        order_type=OrderType.Limit,
        quantity=quantity,
        price=price,
        time_in_force=TimeInForce.Day,
    )


def test_risk_manager_initialization():
    """Test initializing RiskManager."""
    rm = RiskManager()
    assert rm.config.active == True
    assert rm.config.restricted_list == []
    assert rm.config.max_order_size is None


def test_risk_restricted_list():
    """Test restricted list check."""
    rm = RiskManager()
    # PyO3 getter returns a copy/clone, so we must modify and set back
    config = rm.config
    config.restricted_list = ["BAD"]
    rm.config = config

    portfolio = Portfolio(100000.0)

    # Blocked
    order_bad = create_order("BAD", 100.0, 10.0)
    msg = rm.check(order_bad, portfolio)
    assert msg is not None
    assert "restricted" in msg

    # Allowed
    order_good = create_order("GOOD", 100.0, 10.0)
    msg = rm.check(order_good, portfolio)
    assert msg is None


def test_risk_max_order_size():
    """Test max order size check."""
    rm = RiskManager()
    config = rm.config
    config.max_order_size = 100.0
    rm.config = config

    portfolio = Portfolio(100000.0)

    # Exceeds
    order_fail = create_order("AAPL", 101.0, 10.0)
    msg = rm.check(order_fail, portfolio)
    assert msg is not None
    assert "quantity" in msg

    # Allowed
    order_ok = create_order("AAPL", 100.0, 10.0)
    msg = rm.check(order_ok, portfolio)
    assert msg is None


def test_risk_max_order_value():
    """Test max order value check."""
    rm = RiskManager()
    config = rm.config
    config.max_order_value = 1000.0
    rm.config = config

    portfolio = Portfolio(100000.0)

    # Exceeds: 100 * 11 = 1100
    order_fail = create_order("AAPL", 100.0, 11.0)
    msg = rm.check(order_fail, portfolio)
    assert msg is not None
    assert "value" in msg

    # Allowed: 100 * 10 = 1000
    order_ok = create_order("AAPL", 100.0, 10.0)
    msg = rm.check(order_ok, portfolio)
    assert msg is None
