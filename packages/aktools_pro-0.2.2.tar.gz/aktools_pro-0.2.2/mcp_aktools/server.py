from fastmcp import FastMCP

mcp = FastMCP(name="aktools-pro", version="0.2.2")
