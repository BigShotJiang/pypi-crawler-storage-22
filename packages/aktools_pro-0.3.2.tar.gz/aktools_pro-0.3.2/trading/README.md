# 📈 策略与交易模块

该模块目前包含策略逻辑及回测基础设施。

## 相关资源
- [AkTools Pro 官方仓库](https://github.com/tchivs/mcp-aktools)
- [欧易模拟盘 API 密钥申请](https://www.okx.com/zh-hans/help/how-can-i-do-spot-trading-with-the-jupyter-notebook)
- [akshare 数据文档](https://akshare.akfamily.xyz/)
