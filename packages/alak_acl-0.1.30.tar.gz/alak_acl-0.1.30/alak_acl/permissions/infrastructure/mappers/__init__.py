"""
Mappers pour la feature Permissions.
"""

from alak_acl.permissions.infrastructure.mappers.permission_mapper import PermissionMapper



__all__ = ["PermissionMapper"]
