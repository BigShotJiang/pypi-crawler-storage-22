"""
Entités du domaine pour la feature Roles.
"""

from alak_acl.roles.domain.entities.role import Role

__all__ = ["Role"]
