"""
Routes d'administration pour l'authentification.
"""

from alak_acl.auth.interface.admin.routes import router

__all__ = ["router"]
