"""
Script de setup pour compatibilité avec pip install -e .
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
