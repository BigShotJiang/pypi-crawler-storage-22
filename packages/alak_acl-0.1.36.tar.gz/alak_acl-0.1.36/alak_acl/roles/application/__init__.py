"""
Couche application de la feature Roles.
"""

from alak_acl.roles.application.interface.role_repository import IRoleRepository


__all__ = ["IRoleRepository"]
