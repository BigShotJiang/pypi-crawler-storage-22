#!/usr/bin/env python3
def main():
    from .main import main as main_core
    main_core()
