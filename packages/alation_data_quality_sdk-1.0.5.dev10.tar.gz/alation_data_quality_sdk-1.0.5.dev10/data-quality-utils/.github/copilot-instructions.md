# Data Quality Utils - AI Coding Agent Instructions

## Project Overview

This is a multi-language data quality utilities repository with client libraries for Go and Python, focusing on data quality notification services (DQNS), query services, and Soda Core integration with Alation.

## Architecture Components

### Client Libraries Structure

- **Go clients**: `client/golang/{cms,dqns}` - gRPC clients for configuration management and data quality notifications
- **Python clients**: `client/python/{dqns,query_service,logger_utils,soda_alation}` - REST/gRPC clients and Soda Core integration
- **Protocol Buffers**: Extensive `.proto` definitions under `protobuf/` for gRPC services (RDBMS, data lineage, service discovery)

### Key Service Boundaries

- **DQNS (Data Quality Notification Service)**: Job state management with REST API (`JobState`: NOT_STARTED → QUEUED → STARTED → FINISHED)
- **Query Service**: gRPC-based database query execution with session management and streaming results
- **Soda Alation Core**: Data quality scanning engine with check execution, metric collection, and Alation integration

## Critical Developer Workflows

### Testing

- **Python**: Uses pytest with `DataSourceFixture` for database integration tests
  - Run: `pytest` in any Python client directory
  - Test data sources controlled by `test_data_source` env var (default: postgres)
  - Schema isolation: Dynamic test schemas with CI/PR naming conventions
  - **Unit tests**: Each Python module has a corresponding `*_test.py` file using `unittest` framework
- **Go**: Uses `github.com/stretchr/testify v1.8.4` for unit testing
  - Run: `go test ./...` in client directories
  - **Unit tests**: Each Go file has a corresponding `*_test.go` file with comprehensive test coverage
- **Key test pattern**: `data_source_fixture.create_test_scan()` → `scan.add_sodacl_yaml_str()` → `scan.execute()` → `scan.assert_all_checks_pass()`

### Building & Publishing

- **Go modules**: Use `ci/shell/publish_go_module.sh` with JFrog Artifactory
- **Python packages**: Standard `setup.py` with version from `changelog.yaml` + `BUILD_NUMBER` env var
- **Dependencies**: Go uses specific protobuf/gRPC versions; Python uses strict gRPC pinning (`grpcio==1.60.1`)
- **CI/CD**: Unified GitHub Actions workflow runs both Go and Python tests with parallel coverage reporting to Coveralls

### Development Environment

- **Database testing**: Requires postgres (or other data sources) for integration tests
- **Schema management**: Automatic test schema creation/cleanup in `DataSourceFixture`
- **Environment variables**: `CONNECTOR_HOST`, `BUILD_NUMBER`, `test_data_source`, GitHub CI vars for schema naming

## Project-Specific Patterns

### Data Quality Checks (Soda Core)

```python
# Standard check pattern in tests
scan.add_sodacl_yaml_str(f"""
  checks for {table_name}:
    - row_count > 0
    - missing_count(id) = 0
    - schema:
        warn:
          when required column missing: [id]
""")
```

### DQNS Client Usage

```python
# Job lifecycle management
client.add_subprocess("extraction")
client.start_subprocess(subprocess_id, "extraction")
client.update_job_state(JobState.FINISHED, JobStatus.SUCCEEDED)
```

### Query Client Pattern

```python
# gRPC session management
client = QueryClient.from_connector_id(connector_id)
session = client.start_session(request)
results = client.query(session_id, sql_query)
client.end_session(session_id)
```

## Integration Points

### External Dependencies

- **Alation**: Direct integration through Soda Core for data catalog updates
- **Kubernetes**: Service discovery pattern `{service}.{namespace}.svc.cluster.local:80`
- **Artifactory**: Go module publishing via JFrog CLI
- **gRPC ecosystem**: Heavy use of protobuf code generation

### Cross-Component Communication

- **Query sessions**: Stateful gRPC connections with session lifecycle
- **Job notifications**: REST API with external subprocess tracking
- **Data source abstraction**: Pluggable data source implementations in Soda Core

## Important File Locations

- Protocol definitions: `client/python/query_service/src/queryservice_client/protobuf/`
- Test fixtures: `client/python/soda_alation/core/tests/helpers/`
- Configuration examples: `client/python/soda_alation/core/tests/data_sources.yml`
- Go modules: `client/golang/{cms,dqns}/go.mod`

## Debugging Tips

- **Failed tests**: Check `data_source_fixture.data_source.logs` for SQL execution details
- **gRPC issues**: Verify protobuf version compatibility across components
- **Schema conflicts**: Tests use dynamic schema names to avoid collisions
- **Version conflicts**: Each Python client has independent dependencies via `setup.py`
