#!/usr/bin/env bash
# Exit on error.
set -o errexit
# Exit on error inside any functions or subshells.
set -o errtrace
# Catch the errors eg. in case mysqldump fails (but gzip succeeds) in `mysqldump |gzip`
set -o pipefail
# Turn on traces, useful while debugging but commented out by default
set -o xtrace

download_artifact(){
  # The artifact's path on Artifactory
  artifact_path=$1
  # The artifact's path on the local filesystem
  filesystem_path=$2
  sudo mkdir -p ${ARTIFACTORY_DIR}
  url="https://${ARTIFACTORY_DOMAIN_NAME}/artifactory/${artifact_path}"
  sudo curl "${url}" -o "${filesystem_path}"
}

configure_jfrog(){
  download_artifact ${JFROG_ARTIFACTORY_REPO} ${JFROG_BIN}
  sudo chmod +x ${JFROG_BIN}
}


main(){
  configure_jfrog

  cd $1
  ${JFROG_BIN} rt gp \
  --url https://${ARTIFACTORY_DOMAIN_NAME}/artifactory \
  --user=${ARTIFACTORY_USERNAME} \
  --password=${ARTIFACTORY_TOKEN} \
  alationgo-local ${RELEASE_VERSION}
}

main "$@"
