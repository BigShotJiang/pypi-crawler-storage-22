package cms

import (
	"context"
	"errors"
	"fmt"

	proto "github.com/alation/data-quality-utils/client/golang/cms/protos"
	log "github.com/alation/go-logging/v2/log"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/metadata"
)

// CorePrefixes contains the default prefixes that contain the configurations used by the Core SDK internally.
var CorePrefixes = []string{"aws", "alation.s3auth"}

// client is an implementation of clients.Client that reads configuration by issuing gRPC
// requests to Configuration Management Service (CMS).
type client struct {
	logger   log.Logger
	tenantID string
	host     string
	prefixes []string
	// gRPClient is an instance of GRPClient.
	gRPClient *grpcClient
}

// NewCMSClient returns an instance of clients.Client.
func NewCMSClient(
	logger log.Logger,
	tenantID string,
	host string,
) (*client, error) {
	gClient, err := newGRPCClient(host)
	if err != nil {
		return nil, err
	}

	return &client{
		logger:    logger,
		tenantID:  tenantID,
		host:      host,
		prefixes:  CorePrefixes,
		gRPClient: gClient,
	}, nil
}

// GetConfiguration fetches the configuration map from CMS.
func (c *client) GetConfiguration(addONPrefix []string) (*Configuration, error) {

	configuration := NewConfiguration()

	grpcMetadata := map[string]string{
		"service.zeus.tenant.id": c.tenantID,
	}
	md := metadata.New(grpcMetadata)
	ctx, cancel := context.WithCancel(context.Background())
	ctx = metadata.NewOutgoingContext(ctx, md)
	defer cancel()
	addONPrefix = append(addONPrefix, c.prefixes...)
	for _, prefix := range addONPrefix {
		err := c.readPrefix(ctx, configuration, prefix)
		if err != nil {
			return nil, err
		}
	}
	// Connection is nil during unit tests and mock tests
	if c.gRPClient.connection != nil {
		closeErr := c.gRPClient.connection.Close()
		if closeErr != nil {
			return nil, errors.New(fmt.Sprintf("%s with error %s", "Failed to close cms client", closeErr.Error()))
		}
	}

	return configuration, nil
}

func (c *client) readPrefix(ctx context.Context, existingConfig *Configuration, prefix string) error {
	c.logger.Debug("Requesting configuration prefix from CMS",
		log.String("URL", c.host),
		log.String("Prefix", prefix),
	)
	serviceRequest := proto.GetConfigurationsByPrefixRequest{
		Prefix: prefix,
	}
	result, err := c.gRPClient.cmsClient.GetConfigurationsByPrefix(ctx, &serviceRequest)
	if err != nil {
		return errors.New(fmt.Sprintf("Failed to fetch prefix = %s from CMS with error %s", prefix, err.Error()))
	}

	existingConfig.MergeIfNotPresent(result.Conf.AsMap())
	return nil
}

// grpcClient encapsulates a gRPC client connection to the given server. This exists so that custom
// low level gRPC client details could be provided to interfacing with CMS.
type grpcClient struct {
	// CmsClient encapsulates the client interface for Configuration Management Service.
	cmsClient proto.ConfigurationServiceClient
	// Connection encapsulates the gRPC connection.
	connection *grpc.ClientConn
}

// NewGRPClient returns an instance of gRPClient struct.
func newGRPCClient(host string) (*grpcClient, error) {
	conn, err := grpc.Dial(host, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, errors.New(fmt.Sprintf("Failed to initialize CMS client with error %s", err.Error()))
	}
	return &grpcClient{
		connection: conn,
		cmsClient:  proto.NewConfigurationServiceClient(conn),
	}, nil
}
