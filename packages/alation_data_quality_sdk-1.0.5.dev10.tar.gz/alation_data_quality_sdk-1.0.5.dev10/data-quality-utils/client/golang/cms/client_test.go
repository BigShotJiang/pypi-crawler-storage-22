package cms

import (
	"context"
	"errors"
	"io"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/structpb"

	log "github.com/alation/go-logging/v2/log"
	proto "github.com/alation/data-quality-utils/client/golang/cms/protos"
)

// Create a simple logger for testing
func createTestLogger() log.Logger {
	return *log.New(io.Discard, log.DebugLevel)
}

// Mock for the ConfigurationServiceClient
type mockConfigurationServiceClient struct {
	mock.Mock
}

func (m *mockConfigurationServiceClient) GetConfigurationsByPrefix(ctx context.Context, request *proto.GetConfigurationsByPrefixRequest, opts ...grpc.CallOption) (*proto.GetConfigurationsResponse, error) {
	args := m.Called(ctx, request)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*proto.GetConfigurationsResponse), args.Error(1)
}

// Mock for grpcClient
type mockGRPCClient struct {
	mock.Mock
	connection *grpc.ClientConn
	cmsClient  proto.ConfigurationServiceClient
}

func (m *mockGRPCClient) setMockClient(client proto.ConfigurationServiceClient) {
	m.cmsClient = client
}

func TestCorePrefixes(t *testing.T) {
	expected := []string{"aws", "alation.s3auth"}
	assert.Equal(t, expected, CorePrefixes)
}

func TestNewGRPCClient_ValidCreation(t *testing.T) {
	// Test that client creation succeeds even with invalid host (gRPC is lazy)
	client, err := newGRPCClient("invalid://host:port")

	// gRPC client creation should succeed (connection is lazy)
	assert.NoError(t, err)
	assert.NotNil(t, client)
	assert.NotNil(t, client.connection)
	assert.NotNil(t, client.cmsClient)

	// Clean up the connection
	if client.connection != nil {
		client.connection.Close()
	}
}

func TestNewCMSClient_Success(t *testing.T) {
	logger := createTestLogger()
	tenantID := "test-tenant"
	host := "localhost:9090"

	// Test successful client creation
	client, err := NewCMSClient(logger, tenantID, host)

	assert.NoError(t, err)
	assert.NotNil(t, client)
	assert.Equal(t, tenantID, client.tenantID)
	assert.Equal(t, host, client.host)
	assert.Equal(t, CorePrefixes, client.prefixes)
	assert.NotNil(t, client.logger)
	assert.NotNil(t, client.gRPClient)

	// Clean up
	if client.gRPClient != nil && client.gRPClient.connection != nil {
		client.gRPClient.connection.Close()
	}
}

func TestNewCMSClient_GRPCClientError(t *testing.T) {
	logger := createTestLogger()
	tenantID := "test-tenant"
	invalidHost := ""  // Empty host should cause error

	// Test client creation failure due to gRPC client error
	client, err := NewCMSClient(logger, tenantID, invalidHost)

	assert.Error(t, err)
	assert.Nil(t, client)
	assert.Contains(t, err.Error(), "Failed to initialize CMS client")
}

func TestClient_GetConfiguration_Success(t *testing.T) {
	// Setup mocks
	mockCMSClient := &mockConfigurationServiceClient{}
	logger := createTestLogger()

	// Create test client with mock gRPC client
	testClient := &client{
		logger:   logger,
		tenantID: "test-tenant",
		host:     "localhost:9090",
		prefixes: []string{"test.prefix"},
		gRPClient: &grpcClient{
			cmsClient:  mockCMSClient,
			connection: nil, // nil connection to avoid close issues in test
		},
	}

	// Setup mock expectations
	expectedResponse := &proto.GetConfigurationsResponse{
		Conf: &structpb.Struct{
			Fields: map[string]*structpb.Value{
				"test.config": {
					Kind: &structpb.Value_StringValue{StringValue: "test-value"},
				},
			},
		},
	}

	mockCMSClient.On("GetConfigurationsByPrefix", mock.Anything, mock.MatchedBy(func(req *proto.GetConfigurationsByPrefixRequest) bool {
		return req.Prefix == "test.prefix"
	})).Return(expectedResponse, nil)

	// Execute
	config, err := testClient.GetConfiguration([]string{})

	// Assert
	assert.NoError(t, err)
	assert.NotNil(t, config)
	mockCMSClient.AssertExpectations(t)
}

func TestClient_GetConfiguration_WithAdditionalPrefixes(t *testing.T) {
	// Setup mocks
	mockCMSClient := &mockConfigurationServiceClient{}
	logger := createTestLogger()

	testClient := &client{
		logger:   logger,
		tenantID: "test-tenant",
		host:     "localhost:9090",
		prefixes: []string{"core.prefix"},
		gRPClient: &grpcClient{
			cmsClient:  mockCMSClient,
			connection: nil,
		},
	}

	// Setup mock expectations for both prefixes
	mockResponse := &proto.GetConfigurationsResponse{
		Conf: &structpb.Struct{Fields: map[string]*structpb.Value{}},
	}

	mockCMSClient.On("GetConfigurationsByPrefix", mock.Anything, mock.MatchedBy(func(req *proto.GetConfigurationsByPrefixRequest) bool {
		return req.Prefix == "additional.prefix"
	})).Return(mockResponse, nil)

	mockCMSClient.On("GetConfigurationsByPrefix", mock.Anything, mock.MatchedBy(func(req *proto.GetConfigurationsByPrefixRequest) bool {
		return req.Prefix == "core.prefix"
	})).Return(mockResponse, nil)

	// Execute
	config, err := testClient.GetConfiguration([]string{"additional.prefix"})

	// Assert
	assert.NoError(t, err)
	assert.NotNil(t, config)
	mockCMSClient.AssertExpectations(t)
}

func TestClient_GetConfiguration_ReadPrefixError(t *testing.T) {
	// Setup mocks
	mockCMSClient := &mockConfigurationServiceClient{}
	logger := createTestLogger()

	testClient := &client{
		logger:   logger,
		tenantID: "test-tenant",
		host:     "localhost:9090",
		prefixes: []string{"error.prefix"},
		gRPClient: &grpcClient{
			cmsClient:  mockCMSClient,
			connection: nil,
		},
	}

	// Setup mock to return error
	expectedError := status.Error(codes.NotFound, "prefix not found")
	mockCMSClient.On("GetConfigurationsByPrefix", mock.Anything, mock.Anything).Return(nil, expectedError)

	// Execute
	config, err := testClient.GetConfiguration([]string{})

	// Assert
	assert.Error(t, err)
	assert.Nil(t, config)
	assert.Contains(t, err.Error(), "Failed to fetch prefix = error.prefix from CMS")
	mockCMSClient.AssertExpectations(t)
}

func TestClient_ReadPrefix_Success(t *testing.T) {
	// Setup mocks
	mockCMSClient := &mockConfigurationServiceClient{}
	logger := createTestLogger()

	testClient := &client{
		logger:   logger,
		tenantID: "test-tenant",
		host:     "localhost:9090",
		gRPClient: &grpcClient{
			cmsClient: mockCMSClient,
		},
	}

	// Create test configuration and response
	existingConfig := NewConfiguration()
	expectedResponse := &proto.GetConfigurationsResponse{
		Conf: &structpb.Struct{
			Fields: map[string]*structpb.Value{
				"test.key": {
					Kind: &structpb.Value_StringValue{StringValue: "test-value"},
				},
			},
		},
	}

	mockCMSClient.On("GetConfigurationsByPrefix", mock.Anything, mock.MatchedBy(func(req *proto.GetConfigurationsByPrefixRequest) bool {
		return req.Prefix == "test.prefix"
	})).Return(expectedResponse, nil)

	// Execute
	err := testClient.readPrefix(context.Background(), existingConfig, "test.prefix")

	// Assert
	assert.NoError(t, err)
	mockCMSClient.AssertExpectations(t)

	// Check that config was merged
	assert.True(t, existingConfig.Exists("test.key"))
	value, err := existingConfig.GetString("test.key")
	assert.NoError(t, err)
	assert.Equal(t, "test-value", value)
}

func TestClient_ReadPrefix_GRPCError(t *testing.T) {
	// Setup mocks
	mockCMSClient := &mockConfigurationServiceClient{}
	logger := createTestLogger()

	testClient := &client{
		logger:   logger,
		tenantID: "test-tenant",
		host:     "localhost:9090",
		gRPClient: &grpcClient{
			cmsClient: mockCMSClient,
		},
	}

	existingConfig := NewConfiguration()
	expectedError := errors.New("gRPC connection failed")

	mockCMSClient.On("GetConfigurationsByPrefix", mock.Anything, mock.Anything).Return(nil, expectedError)

	// Execute
	err := testClient.readPrefix(context.Background(), existingConfig, "test.prefix")

	// Assert
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "Failed to fetch prefix = test.prefix from CMS")
	assert.Contains(t, err.Error(), "gRPC connection failed")
	mockCMSClient.AssertExpectations(t)
}

func TestProtobufTypes(t *testing.T) {
	// Test that we can create the protobuf types
	request := &proto.GetConfigurationsByPrefixRequest{
		Prefix: "test.prefix",
	}
	assert.Equal(t, "test.prefix", request.Prefix)

	response := &proto.GetConfigurationsResponse{
		Conf: &structpb.Struct{},
	}
	assert.NotNil(t, response.Conf)
}

func TestClientStructure(t *testing.T) {
	// Test that we can create a client struct with basic values
	testClient := &client{
		tenantID: "test-tenant",
		host:     "localhost:9090",
		prefixes: CorePrefixes,
	}

	assert.Equal(t, "test-tenant", testClient.tenantID)
	assert.Equal(t, "localhost:9090", testClient.host)
	assert.Equal(t, CorePrefixes, testClient.prefixes)
}

func TestClient_GetConfiguration_WithNilConnection(t *testing.T) {
	// Test that nil connection doesn't cause issues
	mockCMSClient := &mockConfigurationServiceClient{}
	logger := createTestLogger()

	testClient := &client{
		logger:   logger,
		tenantID: "test-tenant",
		host:     "localhost:9090",
		prefixes: []string{"test.prefix"},
		gRPClient: &grpcClient{
			cmsClient:  mockCMSClient,
			connection: nil, // Nil connection should not cause issues
		},
	}

	expectedResponse := &proto.GetConfigurationsResponse{
		Conf: &structpb.Struct{Fields: map[string]*structpb.Value{}},
	}

	mockCMSClient.On("GetConfigurationsByPrefix", mock.Anything, mock.Anything).Return(expectedResponse, nil)

	// Execute - this should succeed since connection is nil
	config, err := testClient.GetConfiguration([]string{})

	// Should succeed with nil connection (no close attempt)
	assert.NoError(t, err)
	assert.NotNil(t, config)

	mockCMSClient.AssertExpectations(t)
}