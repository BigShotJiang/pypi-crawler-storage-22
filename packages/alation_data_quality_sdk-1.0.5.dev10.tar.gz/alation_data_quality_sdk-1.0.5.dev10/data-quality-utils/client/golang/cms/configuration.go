package cms

import (
	"errors"
	"strconv"
)

type Configuration struct {
	configMap map[string]interface{}
}

func NewConfiguration() *Configuration {
	return &Configuration{
		configMap: make(map[string]interface{}),
	}
}

func NewConfigurationFromMap(configMap map[string]interface{}) *Configuration {
	return &Configuration{
		configMap: configMap,
	}
}

func (a *Configuration) MergeIfNotPresent(newConfig map[string]interface{}) {
	if newConfig == nil {
		return
	}
	for key, value := range newConfig {
		if _, ok := a.configMap[key]; !ok {
			a.configMap[key] = value
		}
	}
}

func (a *Configuration) Exists(key string) bool {
	_, exists := a.configMap[key]
	return exists
}

func (a *Configuration) GetInt(key string) (int, error) {
	value, exists := a.configMap[key]
	if !exists {
		return 0, errors.New("key not found")
	}

	switch v := value.(type) {
	case int:
		return v, nil
	case float64:
		return int(v), nil
	case string:
		ret, err := strconv.Atoi(v)
		return ret, err
	default:
		return 0, nil
	}
}

func (a *Configuration) GetIntOrFallback(key string, fallback int) int {
	val, err := a.GetInt(key)
	if err != nil {
		return fallback
	}
	return val
}

func (a *Configuration) GetString(key string) (ret string, err error) {
	if value, ok := a.configMap[key]; !ok {
		return "", errors.New("key not found")
	} else {
		ret, ok = value.(string)
		if !ok {
			return "", errors.New("failed to parse string")
		}
	}
	return ret, nil
}

func (a *Configuration) GetStringOrFallback(key string, fallback string) string {
	val, err := a.GetString(key)
	if err != nil {
		return fallback
	}
	return val
}

func (a *Configuration) GetBool(key string) (ret bool, err error) {
	if value, ok := a.configMap[key]; !ok {
		return false, errors.New("key not found")
	} else {
		ret, ok = value.(bool)
		if !ok {
			return false, errors.New("failed to parse bool")
		}
	}
	return ret, nil
}

func (a *Configuration) GetBoolOrFallback(key string, fallback bool) bool {
	val, err := a.GetBool(key)
	if err != nil {
		return fallback
	}
	return val
}
