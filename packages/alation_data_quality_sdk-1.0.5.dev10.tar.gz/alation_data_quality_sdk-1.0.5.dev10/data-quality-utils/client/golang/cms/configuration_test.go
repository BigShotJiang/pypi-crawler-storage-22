package cms

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewConfiguration(t *testing.T) {
	config := NewConfiguration()
	
	assert.NotNil(t, config)
	assert.NotNil(t, config.configMap)
	assert.Empty(t, config.configMap)
}

func TestNewConfigurationFromMap(t *testing.T) {
	configMap := map[string]interface{}{
		"key1": "value1",
		"key2": 42,
		"key3": true,
	}

	config := NewConfigurationFromMap(configMap)
	
	assert.NotNil(t, config)
	assert.Equal(t, configMap, config.configMap)
}

func TestConfiguration_MergeIfNotPresent(t *testing.T) {
	config := NewConfiguration()
	
	// Test merging with nil
	config.MergeIfNotPresent(nil)
	assert.Empty(t, config.configMap)
	
	// Test merging new keys
	newConfig := map[string]interface{}{
		"key1": "value1",
		"key2": 42,
	}
	config.MergeIfNotPresent(newConfig)
	assert.Equal(t, "value1", config.configMap["key1"])
	assert.Equal(t, 42, config.configMap["key2"])
	
	// Test not overwriting existing keys
	overwriteConfig := map[string]interface{}{
		"key1": "new_value1", // Should not overwrite
		"key3": "value3",     // Should add
	}
	config.MergeIfNotPresent(overwriteConfig)
	assert.Equal(t, "value1", config.configMap["key1"]) // Should remain original
	assert.Equal(t, "value3", config.configMap["key3"]) // Should be added
}

func TestConfiguration_Exists(t *testing.T) {
	config := NewConfigurationFromMap(map[string]interface{}{
		"existing_key": "value",
	})
	
	assert.True(t, config.Exists("existing_key"))
	assert.False(t, config.Exists("non_existing_key"))
}

func TestConfiguration_GetInt(t *testing.T) {
	config := NewConfigurationFromMap(map[string]interface{}{
		"int_value":    42,
		"float_value":  42.0,
		"string_value": "42",
		"invalid_int":  "not_a_number",
		"bool_value":   true,
	})
	
	// Test getting int value
	val, err := config.GetInt("int_value")
	assert.NoError(t, err)
	assert.Equal(t, 42, val)
	
	// Test getting float value (should convert to int)
	val, err = config.GetInt("float_value")
	assert.NoError(t, err)
	assert.Equal(t, 42, val)
	
	// Test getting string value (should parse)
	val, err = config.GetInt("string_value")
	assert.NoError(t, err)
	assert.Equal(t, 42, val)
	
	// Test invalid string
	val, err = config.GetInt("invalid_int")
	assert.Error(t, err)
	
	// Test non-existing key
	val, err = config.GetInt("non_existing")
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "key not found")
	
	// Test default case (non-numeric type)
	val, err = config.GetInt("bool_value")
	assert.NoError(t, err)
	assert.Equal(t, 0, val)
}

func TestConfiguration_GetIntOrFallback(t *testing.T) {
	config := NewConfigurationFromMap(map[string]interface{}{
		"valid_int": 42,
	})
	
	// Test existing key
	val := config.GetIntOrFallback("valid_int", 100)
	assert.Equal(t, 42, val)
	
	// Test non-existing key (should return fallback)
	val = config.GetIntOrFallback("non_existing", 100)
	assert.Equal(t, 100, val)
}

func TestConfiguration_GetString(t *testing.T) {
	config := NewConfigurationFromMap(map[string]interface{}{
		"string_value": "hello",
		"int_value":    42,
	})
	
	// Test getting string value
	val, err := config.GetString("string_value")
	assert.NoError(t, err)
	assert.Equal(t, "hello", val)
	
	// Test non-string value
	val, err = config.GetString("int_value")
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "failed to parse string")
	
	// Test non-existing key
	val, err = config.GetString("non_existing")
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "key not found")
}

func TestConfiguration_GetStringOrFallback(t *testing.T) {
	config := NewConfigurationFromMap(map[string]interface{}{
		"valid_string": "hello",
	})
	
	// Test existing key
	val := config.GetStringOrFallback("valid_string", "fallback")
	assert.Equal(t, "hello", val)
	
	// Test non-existing key (should return fallback)
	val = config.GetStringOrFallback("non_existing", "fallback")
	assert.Equal(t, "fallback", val)
}

func TestConfiguration_GetBool(t *testing.T) {
	config := NewConfigurationFromMap(map[string]interface{}{
		"bool_true":  true,
		"bool_false": false,
		"string_value": "not_a_bool",
	})
	
	// Test getting true bool value
	val, err := config.GetBool("bool_true")
	assert.NoError(t, err)
	assert.True(t, val)
	
	// Test getting false bool value
	val, err = config.GetBool("bool_false")
	assert.NoError(t, err)
	assert.False(t, val)
	
	// Test non-bool value
	val, err = config.GetBool("string_value")
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "failed to parse bool")
	
	// Test non-existing key
	val, err = config.GetBool("non_existing")
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "key not found")
}

func TestConfiguration_GetBoolOrFallback(t *testing.T) {
	config := NewConfigurationFromMap(map[string]interface{}{
		"valid_bool": true,
	})
	
	// Test existing key
	val := config.GetBoolOrFallback("valid_bool", false)
	assert.True(t, val)
	
	// Test non-existing key (should return fallback)
	val = config.GetBoolOrFallback("non_existing", false)
	assert.False(t, val)
}