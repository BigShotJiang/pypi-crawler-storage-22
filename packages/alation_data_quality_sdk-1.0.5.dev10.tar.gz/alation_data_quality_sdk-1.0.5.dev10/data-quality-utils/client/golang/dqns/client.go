package dqns

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"time"
)

type DqNotificationClient struct {
	BaseUrl  string
	TenantId string
	JobId    string
	Client   *http.Client
}

func NewDqNotificationClient(serviceName, serviceNamespace, tenantId, jobId string) *DqNotificationClient {
	baseUrl := fmt.Sprintf("http://%s.%s.svc.cluster.local:80", serviceName, serviceNamespace)
	return &DqNotificationClient{
		BaseUrl:  baseUrl,
		TenantId: tenantId,
		JobId:    jobId,
		Client:   &http.Client{},
	}
}

// ===== Public Methods =====

func (c *DqNotificationClient) GetJob(jobId int) (*GetJobResponse, error) {
	url := c.jobAPIPath()
	data, err := c.sendRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	job, err := c.parseJobResponse(data)
	return &GetJobResponse{Job: job}, err
}

func (c *DqNotificationClient) AddSubProcess(name string) (*UpdateJobResponse, error) {
	req := &ExternalSubprocess{Name: name}
	return c.updateSubProcess("POST", c.subProcessAPIPath(), req)
}

func (c *DqNotificationClient) StartSubProcess(subProcessId int, name string) (*UpdateJobResponse, error) {
	req := &ExternalSubprocess{
		ID:    subProcessId,
		Name:  name,
		State: Started,
	}

	url := fmt.Sprintf("%s?shouldFailJob=%s", c.subProcessAPIPathWithID(subProcessId), "false")
	return c.updateSubProcess("PUT", url, req)
}

func (c *DqNotificationClient) MarkJobCompleteWithoutSubProcess(success bool) (*UpdateJobResponse, error) {
	return c.MarkJobCompleteWithoutSubProcessWithMessage(success, "")
}

func (c *DqNotificationClient) MarkJobCompleteWithoutSubProcessWithMessage(success bool, message string) (*UpdateJobResponse, error) {
	status := Succeeded
	if !success {
		status = Failed
	}

	jobIdInt, _ := c.getJobId(c.JobId)
	req := &Job{
		ID:                jobIdInt,
		Status:            status,
		State:             Finished,
		StateMessage:      message,
		PersistingMessage: []string{message},
	}

	return c.putJob(c.jobAPIPath(), req)
}

func (c *DqNotificationClient) MarkSubProcessAndJobComplete(subProcessId int, name string, success bool) (*UpdateJobResponse, error) {
	return c.MarkSubProcessComplete(subProcessId, name, success, true)
}

func (c *DqNotificationClient) MarkSubProcessComplete(subProcessId int, name string, success, updateJobStatus bool) (*UpdateJobResponse, error) {
	return c.MarkSubProcessCompleteWithMessage(subProcessId, name, success, updateJobStatus, "")
}

func (c *DqNotificationClient) MarkSubProcessAndJobCompleteWithMessage(subProcessId int, name string, success bool, message string) (*UpdateJobResponse, error) {
	return c.MarkSubProcessCompleteWithMessage(subProcessId, name, success, true, message)
}

func (c *DqNotificationClient) MarkSubProcessCompleteWithMessage(subProcessId int, name string, success, updateJobStatus bool, message string) (*UpdateJobResponse, error) {
	status := Succeeded
	if !success {
		status = Failed
	}

	req := &ExternalSubprocess{
		ID:           subProcessId,
		Name:         name,
		Status:       status,
		State:        Finished,
		StateMessage: message,
	}

	if success && updateJobStatus {
		url := fmt.Sprintf("%s?shouldFailJob=%s", c.subProcessAPIPathWithID(subProcessId), "false")
		_, _ = c.updateSubProcess("PUT", url, req)
		return c.MarkJobCompleteWithoutSubProcessWithMessage(success, message)
	} else {
		url := fmt.Sprintf("%s?shouldFailJob=%s", c.subProcessAPIPathWithID(subProcessId), strconv.FormatBool(updateJobStatus))
		return c.updateSubProcess("PUT", url, req)
	}
}

func (c *DqNotificationClient) UpdateJob(req *Job, useSubProcessStatuses bool) (*UpdateJobResponse, error) {
	url := fmt.Sprintf("%s?useSubProcessesForStatus=%s", c.jobAPIPath(), strconv.FormatBool(useSubProcessStatuses))
	return c.putJob(url, req)
}

// ===== Internal Helpers =====

func (c *DqNotificationClient) sendRequest(method, url string, body []byte) ([]byte, error) {
	var lastErr error
	backoff := 1 * time.Second
	maxAttempts := 4 // 1 initial try + 3 retries

	retriableStatusCodes := map[int]bool{
		http.StatusRequestTimeout:     true, // 408
		http.StatusBadGateway:         true, // 502
		http.StatusServiceUnavailable: true, // 503
		http.StatusGatewayTimeout:     true, // 504
	}

	for attempt := 1; attempt <= maxAttempts; attempt++ {
		reqBody := bytes.NewReader(body)
		req, err := http.NewRequest(method, url, reqBody)
		if err != nil {
			return nil, err
		}

		req.Header.Set("Cookie", "service.zeus.tenant.id="+c.TenantId)
		if body != nil {
			req.Header.Set("Content-Type", "application/json")
		}

		resp, err := c.Client.Do(req)
		if err != nil {
			lastErr = err
		} else {
			defer func() {
				if cerr := resp.Body.Close(); cerr != nil {
					fmt.Printf("Warning: failed to close response body: %v\n", cerr)
				}
			}()

			if resp.StatusCode == http.StatusOK {
				return io.ReadAll(resp.Body)
			}

			if retriableStatusCodes[resp.StatusCode] {
				lastErr = fmt.Errorf("API %s returned retriable status: %d", url, resp.StatusCode)
			} else {
				// Non-retriable status
				return nil, fmt.Errorf("API %s returned non-retriable status: %d", url, resp.StatusCode)
			}
		}

		// Sleep before retrying if not the final attempt
		if attempt < maxAttempts {
			time.Sleep(backoff)
			backoff *= 2
		}
	}

	return nil, fmt.Errorf("Request failed after %d attempts: %w", maxAttempts, lastErr)
}

func (c *DqNotificationClient) parseJobResponse(data []byte) (*Job, error) {
	var job Job
	if err := json.Unmarshal(data, &job); err != nil {
		return nil, err
	}
	return &job, nil
}

func (c *DqNotificationClient) getJobId(id string) (int, bool) {
	jobIDInt, err := strconv.Atoi(id)
	if err != nil {
		return 0, false
	}
	return jobIDInt, true
}

func (c *DqNotificationClient) jobAPIPath() string {
	return fmt.Sprintf("%s/api/jobs/%s", c.BaseUrl, c.JobId)
}

func (c *DqNotificationClient) subProcessAPIPath() string {
	return fmt.Sprintf("%s/api/jobs/%s/subprocess", c.BaseUrl, c.JobId)
}

func (c *DqNotificationClient) subProcessAPIPathWithID(id int) string {
	return fmt.Sprintf("%s/api/jobs/%s/subprocess/%d", c.BaseUrl, c.JobId, id)
}

func (c *DqNotificationClient) putJob(url string, req *Job) (*UpdateJobResponse, error) {
	payload, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	data, err := c.sendRequest("PUT", url, payload)
	if err != nil {
		return nil, err
	}
	job, err := c.parseJobResponse(data)
	return &UpdateJobResponse{Job: job}, err
}

func (c *DqNotificationClient) updateSubProcess(requestMethod string, url string, req *ExternalSubprocess) (*UpdateJobResponse, error) {
	payload, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	data, err := c.sendRequest(requestMethod, url, payload)
	if err != nil {
		return nil, err
	}
	job, err := c.parseJobResponse(data)
	return &UpdateJobResponse{Job: job}, err
}

func (c *DqNotificationClient) AddOrUpdateDetailInJob(key, value string) (*UpdateJobResponse, error) {
	req := &Detail{
		Key:  key,
		Text: value,
	}
	url := fmt.Sprintf("%s/%s", c.jobAPIPath(), "detail")

	payload, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	data, err := c.sendRequest("PUT", url, payload)
	if err != nil {
		return nil, err
	}
	job, err := c.parseJobResponse(data)
	return &UpdateJobResponse{Job: job}, err
}
