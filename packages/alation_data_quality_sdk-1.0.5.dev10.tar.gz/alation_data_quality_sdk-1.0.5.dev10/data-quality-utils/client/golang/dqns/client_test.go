package dqns

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewDqNotificationClient(t *testing.T) {
	serviceName := "test-service"
	serviceNamespace := "test-namespace"
	tenantId := "tenant-123"
	jobId := "job-456"

	client := NewDqNotificationClient(serviceName, serviceNamespace, tenantId, jobId)

	assert.NotNil(t, client)
	assert.Equal(t, "http://test-service.test-namespace.svc.cluster.local:80", client.BaseUrl)
	assert.Equal(t, "tenant-123", client.TenantId)
	assert.Equal(t, "job-456", client.JobId)
	assert.NotNil(t, client.Client)
}

func TestDqNotificationClient_jobAPIPath(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl: "http://localhost:8080",
		JobId:   "123",
	}

	path := client.jobAPIPath()
	assert.Equal(t, "http://localhost:8080/api/jobs/123", path)
}

func TestDqNotificationClient_subProcessAPIPath(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl: "http://localhost:8080",
		JobId:   "123",
	}

	path := client.subProcessAPIPath()
	assert.Equal(t, "http://localhost:8080/api/jobs/123/subprocess", path)
}

func TestDqNotificationClient_subProcessAPIPathWithID(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl: "http://localhost:8080",
		JobId:   "123",
	}

	path := client.subProcessAPIPathWithID(456)
	assert.Equal(t, "http://localhost:8080/api/jobs/123/subprocess/456", path)
}

func TestDqNotificationClient_getJobId(t *testing.T) {
	client := &DqNotificationClient{}

	// Test valid job ID
	jobId, ok := client.getJobId("123")
	assert.True(t, ok)
	assert.Equal(t, 123, jobId)

	// Test invalid job ID
	jobId, ok = client.getJobId("invalid")
	assert.False(t, ok)
	assert.Equal(t, 0, jobId)
}

func TestDqNotificationClient_parseJobResponse(t *testing.T) {
	client := &DqNotificationClient{}

	// Test valid JSON
	job := Job{
		ID:     123,
		UUID:   "test-uuid",
		State:  Started,
		Status: Succeeded,
	}
	data, err := json.Marshal(job)
	require.NoError(t, err)

	parsedJob, err := client.parseJobResponse(data)
	assert.NoError(t, err)
	assert.Equal(t, 123, parsedJob.ID)
	assert.Equal(t, "test-uuid", parsedJob.UUID)
	assert.Equal(t, Started, parsedJob.State)
	assert.Equal(t, Succeeded, parsedJob.Status)

	// Test invalid JSON
	_, err = client.parseJobResponse([]byte("invalid json"))
	assert.Error(t, err)
}

func TestDqNotificationClient_GetJob(t *testing.T) {
	// Create a test server
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "GET", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123")
		assert.Equal(t, "tenant-456", r.Header.Get("Cookie")[len("service.zeus.tenant.id="):])

		job := Job{
			ID:     123,
			UUID:   "test-uuid",
			State:  Started,
			Status: Succeeded,
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.GetJob(123)
	assert.NoError(t, err)
	assert.NotNil(t, response)
	assert.Equal(t, 123, response.Job.ID)
	assert.Equal(t, "test-uuid", response.Job.UUID)
}

func TestDqNotificationClient_AddSubProcess(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "POST", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123/subprocess")

		var subprocess ExternalSubprocess
		err := json.NewDecoder(r.Body).Decode(&subprocess)
		assert.NoError(t, err)
		assert.Equal(t, "test-subprocess", subprocess.Name)

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.AddSubProcess("test-subprocess")
	assert.NoError(t, err)
	assert.NotNil(t, response)
	assert.Equal(t, 123, response.Job.ID)
}

func TestDqNotificationClient_StartSubProcess(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "PUT", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123/subprocess/456")
		assert.Contains(t, r.URL.RawQuery, "shouldFailJob=false")

		var subprocess ExternalSubprocess
		err := json.NewDecoder(r.Body).Decode(&subprocess)
		assert.NoError(t, err)
		assert.Equal(t, 456, subprocess.ID)
		assert.Equal(t, "test-subprocess", subprocess.Name)
		assert.Equal(t, Started, subprocess.State)

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.StartSubProcess(456, "test-subprocess")
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_MarkJobCompleteWithoutSubProcess(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "PUT", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123")

		var job Job
		err := json.NewDecoder(r.Body).Decode(&job)
		assert.NoError(t, err)
		assert.Equal(t, 123, job.ID)
		assert.Equal(t, Succeeded, job.Status)
		assert.Equal(t, Finished, job.State)

		job.ID = 123
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.MarkJobCompleteWithoutSubProcess(true)
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_MarkJobCompleteWithoutSubProcessWithMessage(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var job Job
		err := json.NewDecoder(r.Body).Decode(&job)
		assert.NoError(t, err)
		assert.Equal(t, Failed, job.Status)
		assert.Equal(t, "test message", job.StateMessage)
		assert.Equal(t, []string{"test message"}, job.PersistingMessage)

		job.ID = 123
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.MarkJobCompleteWithoutSubProcessWithMessage(false, "test message")
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_AddOrUpdateDetailInJob(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "PUT", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123/detail")

		var detail Detail
		err := json.NewDecoder(r.Body).Decode(&detail)
		assert.NoError(t, err)
		assert.Equal(t, "test-key", detail.Key)
		assert.Equal(t, "test-value", detail.Text)

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.AddOrUpdateDetailInJob("test-key", "test-value")
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_sendRequest_Retry(t *testing.T) {
	attempts := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		attempts++
		if attempts < 3 {
			w.WriteHeader(http.StatusBadGateway) // Retriable error
			return
		}
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("success"))
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{Timeout: 5 * time.Second},
	}

	data, err := client.sendRequest("GET", server.URL+"/test", nil)
	assert.NoError(t, err)
	assert.Equal(t, "success", string(data))
	assert.Equal(t, 3, attempts)
}

func TestDqNotificationClient_sendRequest_NonRetriableError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusBadRequest) // Non-retriable error
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	_, err := client.sendRequest("GET", server.URL+"/test", nil)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "non-retriable status: 400")
}

func TestDqNotificationClient_MarkSubProcessAndJobComplete(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/jobs/123/subprocess/456" {
			// First call to mark subprocess complete
			assert.Equal(t, "PUT", r.Method)
			assert.Contains(t, r.URL.RawQuery, "shouldFailJob=false")
		} else if r.URL.Path == "/api/jobs/123" {
			// Second call to mark job complete
			assert.Equal(t, "PUT", r.Method)
		}

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.MarkSubProcessAndJobComplete(456, "test-subprocess", true)
	assert.NoError(t, err)
	assert.NotNil(t, response)
	assert.Equal(t, 123, response.Job.ID)
}

func TestDqNotificationClient_MarkSubProcessComplete(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "PUT", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123/subprocess/456")
		assert.Contains(t, r.URL.RawQuery, "shouldFailJob=false")

		var subprocess ExternalSubprocess
		err := json.NewDecoder(r.Body).Decode(&subprocess)
		assert.NoError(t, err)
		assert.Equal(t, 456, subprocess.ID)
		assert.Equal(t, "test-subprocess", subprocess.Name)
		assert.Equal(t, Succeeded, subprocess.Status)
		assert.Equal(t, Finished, subprocess.State)

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.MarkSubProcessComplete(456, "test-subprocess", true, false)
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_MarkSubProcessAndJobCompleteWithMessage(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/jobs/123/subprocess/456" {
			var subprocess ExternalSubprocess
			err := json.NewDecoder(r.Body).Decode(&subprocess)
			assert.NoError(t, err)
			assert.Equal(t, Failed, subprocess.Status)
			assert.Equal(t, "error message", subprocess.StateMessage)
		} else if r.URL.Path == "/api/jobs/123" {
			var job Job
			err := json.NewDecoder(r.Body).Decode(&job)
			assert.NoError(t, err)
			assert.Equal(t, Failed, job.Status)
			assert.Equal(t, "error message", job.StateMessage)
		}

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.MarkSubProcessAndJobCompleteWithMessage(456, "test-subprocess", false, "error message")
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_MarkSubProcessCompleteWithMessage_SuccessWithJobUpdate(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/jobs/123/subprocess/456" {
			assert.Contains(t, r.URL.RawQuery, "shouldFailJob=false")
			var subprocess ExternalSubprocess
			err := json.NewDecoder(r.Body).Decode(&subprocess)
			assert.NoError(t, err)
			assert.Equal(t, Succeeded, subprocess.Status)
			assert.Equal(t, "success message", subprocess.StateMessage)
		} else if r.URL.Path == "/api/jobs/123" {
			var job Job
			err := json.NewDecoder(r.Body).Decode(&job)
			assert.NoError(t, err)
			assert.Equal(t, Succeeded, job.Status)
			assert.Equal(t, "success message", job.StateMessage)
		}

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.MarkSubProcessCompleteWithMessage(456, "test-subprocess", true, true, "success message")
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_MarkSubProcessCompleteWithMessage_FailureWithoutJobUpdate(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "PUT", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123/subprocess/456")
		assert.Contains(t, r.URL.RawQuery, "shouldFailJob=false")

		var subprocess ExternalSubprocess
		err := json.NewDecoder(r.Body).Decode(&subprocess)
		assert.NoError(t, err)
		assert.Equal(t, Failed, subprocess.Status)
		assert.Equal(t, "failure message", subprocess.StateMessage)

		job := Job{ID: 123}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(job)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	response, err := client.MarkSubProcessCompleteWithMessage(456, "test-subprocess", false, false, "failure message")
	assert.NoError(t, err)
	assert.NotNil(t, response)
}

func TestDqNotificationClient_UpdateJob(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "PUT", r.Method)
		assert.Contains(t, r.URL.Path, "/api/jobs/123")
		assert.Contains(t, r.URL.RawQuery, "useSubProcessesForStatus=true")

		var job Job
		err := json.NewDecoder(r.Body).Decode(&job)
		assert.NoError(t, err)
		assert.Equal(t, 123, job.ID)
		assert.Equal(t, "test state message", job.StateMessage)

		returnJob := Job{ID: 123, Status: Succeeded}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(returnJob)
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	testJob := &Job{
		ID:           123,
		StateMessage: "test state message",
	}

	response, err := client.UpdateJob(testJob, true)
	assert.NoError(t, err)
	assert.NotNil(t, response)
	assert.Equal(t, Succeeded, response.Job.Status)
}

func TestDqNotificationClient_sendRequest_HttpRequestCreationError(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl:  "invalid-url",
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	// Test with invalid method to force http.NewRequest error
	_, err := client.sendRequest("\n", "invalid-url", nil)
	assert.Error(t, err)
}

func TestDqNotificationClient_sendRequest_HttpClientError(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl:  "http://nonexistent-server-12345.com:9999",
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{Timeout: 1 * time.Millisecond},
	}

	_, err := client.sendRequest("GET", "http://nonexistent-server-12345.com:9999/test", nil)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "Request failed after 4 attempts")
}

func TestDqNotificationClient_sendRequest_MaxRetriesExhausted(t *testing.T) {
	attempts := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		attempts++
		w.WriteHeader(http.StatusBadGateway) // Always return retriable error
	}))
	defer server.Close()

	client := &DqNotificationClient{
		BaseUrl:  server.URL,
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{Timeout: 5 * time.Second},
	}

	_, err := client.sendRequest("GET", server.URL+"/test", nil)
	assert.Error(t, err)
	assert.Equal(t, 4, attempts) // Should try 4 times (1 initial + 3 retries)
	assert.Contains(t, err.Error(), "Request failed after 4 attempts")
}

func TestDqNotificationClient_putJob_JsonMarshalError(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl:  "http://localhost:8080",
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	// Create a job with invalid data that would cause JSON marshal error
	invalidJob := &Job{
		StateMessage: string([]byte{0xff, 0xfe, 0xfd}), // Invalid UTF-8
	}

	_, err := client.putJob("http://localhost:8080/api/jobs/123", invalidJob)
	// This test depends on the JSON marshaling behavior - may or may not error
	// If it doesn't error, that's also valid behavior
	if err != nil {
		assert.Error(t, err)
	}
}

func TestDqNotificationClient_updateSubProcess_JsonMarshalError(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl:  "http://localhost:8080",
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	// Create subprocess with invalid data that would cause JSON marshal error
	invalidSubprocess := &ExternalSubprocess{
		StateMessage: string([]byte{0xff, 0xfe, 0xfd}), // Invalid UTF-8
	}

	_, err := client.updateSubProcess("PUT", "http://localhost:8080/api/test", invalidSubprocess)
	// This test depends on the JSON marshaling behavior - may or may not error
	if err != nil {
		assert.Error(t, err)
	}
}

func TestDqNotificationClient_AddOrUpdateDetailInJob_JsonMarshalError(t *testing.T) {
	client := &DqNotificationClient{
		BaseUrl:  "http://localhost:8080",
		TenantId: "tenant-456",
		JobId:    "123",
		Client:   &http.Client{},
	}

	// Test with problematic key/value that could cause issues
	_, err := client.AddOrUpdateDetailInJob(string([]byte{0xff, 0xfe, 0xfd}), "value")
	// This test depends on the JSON marshaling behavior - may or may not error
	if err != nil {
		assert.Error(t, err)
	}
}