module github.com/alation/data-quality-utils/client/golang/dqns

go 1.23.7

require github.com/stretchr/testify v1.8.4

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

exclude github.com/ugorji/go v1.1.4
