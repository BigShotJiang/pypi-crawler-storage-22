package dqns

type JobState string

const (
	NotStarted JobState = "NOT_STARTED"
	Queued     JobState = "QUEUED"
	Started    JobState = "STARTED"
	Finished   JobState = "FINISHED"
)

// JobStatus is an alias to represent the Job status data type.
type JobStatus string

// Possible values of Job Status
const (
	NA        JobStatus = "NA"
	Succeeded JobStatus = "SUCCEEDED"
	Failed    JobStatus = "FAILED"
	Skipped   JobStatus = "SKIPPED"
)

// NFSeverity is the severity of non-fatal errors
type NFSeverity string

const (
	// P1 means that we might have partial or inconsistent data.
	// Operations like deleting data might need to be skipped.
	P1 NFSeverity = "P1"
	// P2 are warning. It is good to be addressed,
	// but the quality of the data is not affected.
	P2 NFSeverity = "P2"
)

// Job holds info about execution of a job
type Job struct {
	ID                   int                  `json:"id"`
	UUID                 string               `json:"uuid,omitempty"`
	Details              []Detail             `json:"details,omitempty"`
	Errors               []Error              `json:"errors,omitempty"`
	ExternalJobType      string               `json:"external_job_type,omitempty"`
	ExternalServiceAID   int                  `json:"external_service_aid,omitempty"`
	ExternalSubprocesses []ExternalSubprocess `json:"external_subprocesses,omitempty"`
	HasFatalError        bool                 `json:"has_fatal_error,omitempty"`
	HasNonFatalError     bool                 `json:"has_non_fatal_error,omitempty"`
	HasP1Error           bool                 `json:"has_p1_error,omitempty"`
	JobType              string               `json:"job_type,omitempty"`
	NonFatalErrors       []NonFatalError      `json:"non_fatal_errors,omitempty"`
	PersistingMessage    []string             `json:"persisting_message,omitempty"`
	State                JobState             `json:"state,omitempty"`
	StateMessage         string               `json:"state_message,omitempty"`
	Status               JobStatus            `json:"status,omitempty"`
	TSStarted            string               `json:"ts_started,omitempty"`
	TSFinished           string               `json:"ts_finished,omitempty"`
}

// Detail of a job.
type Detail struct {
	ID    int    `json:"id,omitempty"`
	Key   string `json:"key,omitempty"`
	Text  string `json:"text,omitempty"`
	Count int    `json:"count,omitempty"`
}

// NonFatalError generated during a job.
type NonFatalError struct {
	ID           int               `json:"id,omitempty"`
	Category     string            `json:"category,omitempty"`
	Details      map[string]string `json:"details,omitempty"`
	ErrorMessage string            `json:"error_message,omitempty"`
	Hint         string            `json:"hint,omitempty"`
	JobID        int               `json:"job_id,omitempty"`
	Name         string            `json:"name,omitempty"`
	Severity     NFSeverity        `json:"severity,omitempty"`
}

// Error generated during a job
type Error struct {
	ID           int    `json:"id"`
	Category     string `json:"category,omitempty"`
	ErrorCode    string `json:"error_code,omitempty"`
	ErrorMessage string `json:"error_message,omitempty"`
	Fatal        bool   `json:"fatal,omitempty"`
	Hint         string `json:"hint,omitempty"`
	JobID        int    `json:"job_id,omitempty"`
	Name         string `json:"name,omitempty"`
	StackTrace   string `json:"stack_trace,omitempty"`
	Timestamp    string `json:"timestamp,omitempty"`
}

// ExternalSubprocess individual steps executed during a job.
type ExternalSubprocess struct {
	ID     int       `json:"id"`
	JobID  int       `json:"job_id"`
	Name   string    `json:"name,omitempty"`
	Status JobStatus `json:"status,omitempty"`
	State  JobState  `json:"state,omitempty"`
	//This is to add message at job level at the end
	StateMessage string `json:"state_message,omitempty"`
	TSUpdated    string `json:"ts_updated,omitempty"`
	TSFinished   string `json:"ts_finished,omitempty"`
}

// GetJobRequest struct provides ability construct job info request
type GetJobRequest struct {
	Job *Job
}

// GetJobResponse struct holds API response for the GetJob API
type GetJobResponse struct {
	Job *Job
}

// UpdateJobRequest struct used to construct external subprocess API request
type UpdateJobRequest struct {
	Job *Job
}

// UpdateJobResponse struct holds API response for the UpdateJob API
type UpdateJobResponse struct {
	Job *Job
}
