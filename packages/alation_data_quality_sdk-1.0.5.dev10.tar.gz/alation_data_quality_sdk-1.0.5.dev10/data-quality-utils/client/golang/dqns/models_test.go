package dqns

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestJobState_Constants(t *testing.T) {
	assert.Equal(t, "NOT_STARTED", string(NotStarted))
	assert.Equal(t, "QUEUED", string(Queued))
	assert.Equal(t, "STARTED", string(Started))
	assert.Equal(t, "FINISHED", string(Finished))
}

func TestJobStatus_Constants(t *testing.T) {
	assert.Equal(t, "NA", string(NA))
	assert.Equal(t, "SUCCEEDED", string(Succeeded))
	assert.Equal(t, "FAILED", string(Failed))
	assert.Equal(t, "SKIPPED", string(Skipped))
}

func TestNFSeverity_Constants(t *testing.T) {
	assert.Equal(t, "P1", string(P1))
	assert.Equal(t, "P2", string(P2))
}

func TestJob_Struct(t *testing.T) {
	job := Job{
		ID:                 123,
		UUID:               "test-uuid",
		ExternalJobType:    "test-job",
		State:              Started,
		Status:             Succeeded,
		StateMessage:       "Test message",
		PersistingMessage:  []string{"message1", "message2"},
		HasFatalError:      false,
		HasNonFatalError:   true,
		HasP1Error:         false,
	}

	assert.Equal(t, 123, job.ID)
	assert.Equal(t, "test-uuid", job.UUID)
	assert.Equal(t, "test-job", job.ExternalJobType)
	assert.Equal(t, Started, job.State)
	assert.Equal(t, Succeeded, job.Status)
	assert.Equal(t, "Test message", job.StateMessage)
	assert.Equal(t, []string{"message1", "message2"}, job.PersistingMessage)
	assert.False(t, job.HasFatalError)
	assert.True(t, job.HasNonFatalError)
	assert.False(t, job.HasP1Error)
}

func TestDetail_Struct(t *testing.T) {
	detail := Detail{
		ID:    1,
		Key:   "test-key",
		Text:  "test-text",
		Count: 42,
	}

	assert.Equal(t, 1, detail.ID)
	assert.Equal(t, "test-key", detail.Key)
	assert.Equal(t, "test-text", detail.Text)
	assert.Equal(t, 42, detail.Count)
}

func TestNonFatalError_Struct(t *testing.T) {
	details := map[string]string{
		"key1": "value1",
		"key2": "value2",
	}
	
	error := NonFatalError{
		ID:           1,
		Category:     "test-category",
		Details:      details,
		ErrorMessage: "test error",
		Hint:         "test hint",
		JobID:        123,
		Name:         "test-name",
		Severity:     P1,
	}

	assert.Equal(t, 1, error.ID)
	assert.Equal(t, "test-category", error.Category)
	assert.Equal(t, details, error.Details)
	assert.Equal(t, "test error", error.ErrorMessage)
	assert.Equal(t, "test hint", error.Hint)
	assert.Equal(t, 123, error.JobID)
	assert.Equal(t, "test-name", error.Name)
	assert.Equal(t, P1, error.Severity)
}

func TestError_Struct(t *testing.T) {
	error := Error{
		ID:           1,
		Category:     "test-category",
		ErrorCode:    "TEST001",
		ErrorMessage: "test error message",
		Fatal:        true,
		Hint:         "test hint",
		JobID:        123,
		Name:         "test-error",
		StackTrace:   "test stack trace",
		Timestamp:    "2023-10-31T12:00:00Z",
	}

	assert.Equal(t, 1, error.ID)
	assert.Equal(t, "test-category", error.Category)
	assert.Equal(t, "TEST001", error.ErrorCode)
	assert.Equal(t, "test error message", error.ErrorMessage)
	assert.True(t, error.Fatal)
	assert.Equal(t, "test hint", error.Hint)
	assert.Equal(t, 123, error.JobID)
	assert.Equal(t, "test-error", error.Name)
	assert.Equal(t, "test stack trace", error.StackTrace)
	assert.Equal(t, "2023-10-31T12:00:00Z", error.Timestamp)
}

func TestExternalSubprocess_Struct(t *testing.T) {
	subprocess := ExternalSubprocess{
		ID:           1,
		JobID:        123,
		Name:         "test-subprocess",
		Status:       Succeeded,
		State:        Finished,
		StateMessage: "test state message",
		TSUpdated:    "2023-10-31T12:00:00Z",
		TSFinished:   "2023-10-31T12:05:00Z",
	}

	assert.Equal(t, 1, subprocess.ID)
	assert.Equal(t, 123, subprocess.JobID)
	assert.Equal(t, "test-subprocess", subprocess.Name)
	assert.Equal(t, Succeeded, subprocess.Status)
	assert.Equal(t, Finished, subprocess.State)
	assert.Equal(t, "test state message", subprocess.StateMessage)
	assert.Equal(t, "2023-10-31T12:00:00Z", subprocess.TSUpdated)
	assert.Equal(t, "2023-10-31T12:05:00Z", subprocess.TSFinished)
}

func TestGetJobRequest_Struct(t *testing.T) {
	job := &Job{ID: 123}
	request := GetJobRequest{Job: job}
	
	assert.Equal(t, job, request.Job)
	assert.Equal(t, 123, request.Job.ID)
}

func TestGetJobResponse_Struct(t *testing.T) {
	job := &Job{ID: 123}
	response := GetJobResponse{Job: job}
	
	assert.Equal(t, job, response.Job)
	assert.Equal(t, 123, response.Job.ID)
}

func TestUpdateJobRequest_Struct(t *testing.T) {
	job := &Job{ID: 123}
	request := UpdateJobRequest{Job: job}
	
	assert.Equal(t, job, request.Job)
	assert.Equal(t, 123, request.Job.ID)
}

func TestUpdateJobResponse_Struct(t *testing.T) {
	job := &Job{ID: 123}
	response := UpdateJobResponse{Job: job}
	
	assert.Equal(t, job, response.Job)
	assert.Equal(t, 123, response.Job.ID)
}