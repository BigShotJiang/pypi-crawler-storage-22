import os
import yaml
from setuptools import setup, find_packages

def get_version():
    file_dir = os.path.dirname(os.path.abspath(__file__))
    changelog_file = os.path.join(file_dir, "changelog.yaml")
    version = ""
    with open(changelog_file) as f:
        parsed_changelog = yaml.safe_load(f)
        version = parsed_changelog['version']['current-version']
    build_number = os.getenv('BUILD_NUMBER', "0")
    return f"{version}+{build_number}"

setup(
    name='dqns_client',
    version=get_version(),
    include_package_data=True,
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "requests>=2.20.0",
        "PyYAML>=5.1"
    ],
    python_requires=">=3.7",
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent"
    ],
)
