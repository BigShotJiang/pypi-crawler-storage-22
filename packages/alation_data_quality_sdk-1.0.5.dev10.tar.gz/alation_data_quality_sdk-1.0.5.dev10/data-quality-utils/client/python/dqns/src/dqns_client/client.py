import os
import json
import requests
import time
from enum import Enum
from typing import Optional, Dict, List
from dataclasses import dataclass, field, asdict


# ===== Enums =====

class JobState(str, Enum):
    NOT_STARTED = "NOT_STARTED"
    QUEUED = "QUEUED"
    STARTED = "STARTED"
    FINISHED = "FINISHED"

class JobStatus(str, Enum):
    NA = "NA"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"

class NFSeverity(str, Enum):
    P1 = "P1"
    P2 = "P2"


# ===== Models =====

@dataclass
class Detail:
    id: Optional[int] = None
    key: Optional[str] = None
    text: Optional[str] = None
    count: Optional[int] = None

@dataclass
class NonFatalError:
    id: Optional[int] = None
    category: Optional[str] = None
    details: Optional[Dict[str, str]] = None
    error_message: Optional[str] = None
    hint: Optional[str] = None
    job_id: Optional[int] = None
    name: Optional[str] = None
    severity: Optional[NFSeverity] = None

@dataclass
class Error:
    id: int
    category: Optional[str] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    fatal: Optional[bool] = None
    hint: Optional[str] = None
    job_id: Optional[int] = None
    name: Optional[str] = None
    stack_trace: Optional[str] = None
    timestamp: Optional[str] = None

@dataclass
class ExternalSubprocess:
    id: Optional[int] = None
    job_id: Optional[int] = None
    name: Optional[str] = None
    status: Optional[JobStatus] = None
    state: Optional[JobState] = None
    state_message: Optional[str] = None
    ts_updated: Optional[str] = None
    ts_finished: Optional[str] = None

@dataclass
class Job:
    id: int
    uuid: Optional[str] = None
    details: List[Detail] = field(default_factory=list)
    errors: List[Error] = field(default_factory=list)
    external_job_type: Optional[str] = None
    external_service_aid: Optional[int] = None
    external_subprocesses: List[ExternalSubprocess] = field(default_factory=list)
    has_fatal_error: Optional[bool] = None
    has_non_fatal_error: Optional[bool] = None
    has_p1_error: Optional[bool] = None
    job_type: Optional[str] = None
    non_fatal_errors: List[NonFatalError] = field(default_factory=list)
    persisting_message: List[str] = field(default_factory=list)
    state: Optional[JobState] = None
    state_message: Optional[str] = None
    status: Optional[JobStatus] = None
    ts_started: Optional[str] = None
    ts_finished: Optional[str] = None

@dataclass
class GetJobResponse:
    job: Job

@dataclass
class UpdateJobRequest:
    job: Job

@dataclass
class UpdateJobResponse:
    job: Job


# ===== Notification Client =====

class DqNotificationClient:
    def __init__(self, service_name: str, service_namespace: str, tenant_id: str, job_id: str):
        self.base_url = (
            os.environ.get("DQ_NOTIFICATION_HOST")
            or f"http://{service_name}.{service_namespace}.svc.cluster.local:80"
        )
        self.tenant_id = tenant_id
        self.job_id = job_id
        self.session = requests.Session()

    def _get_job_id(self) -> Optional[int]:
        try:
            return int(self.job_id)
        except ValueError:
            return None

    def _send_request(self, method: str, url: str, body: Optional[dict] = None) -> dict:
        RETRIABLE_STATUS_CODES = {408, 502, 503, 504}

        headers = {
            "Cookie": f"service.zeus.tenant.id={self.tenant_id}"
        }
        data = json.dumps(body, default=str) if body else None
        if data:
            headers["Content-Type"] = "application/json"

        backoff = 1  # seconds
        max_attempts = 4

        last_exception = None

        for attempt in range(1, max_attempts + 1):
            try:
                response = self.session.request(method, url, headers=headers, data=data)
                if response.status_code == 200:
                    return response.json()

                if response.status_code in RETRIABLE_STATUS_CODES:
                    last_exception = Exception(
                        f"API {url} returned retriable status: {response.status_code}"
                    )
                else:
                    raise Exception(
                        f"API {url} returned non-retriable status: {response.status_code}"
                    )
            except Exception as e:
                last_exception = e

            if attempt < max_attempts:
                time.sleep(backoff)
                backoff *= 2

        raise Exception(f"Request failed after {max_attempts} attempts: {last_exception}")

    def _parse_job_response(self, data: dict) -> Job:
        # check for both capital and lowercase, just to be safe
        if "job" in data:
            return Job(**data["job"])
        elif "Job" in data:
            return Job(**data["Job"])
        else:
            raise ValueError(f"Unexpected response format: {data}")

    def _job_api_path(self) -> str:
        return f"{self.base_url}/api/jobs/{self.job_id}"

    def _subprocess_api_path(self) -> str:
        return f"{self.base_url}/api/jobs/{self.job_id}/subprocess"

    def _subprocess_api_path_with_id(self, sub_id: int) -> str:
        return f"{self.base_url}/api/jobs/{self.job_id}/subprocess/{sub_id}"

    def _put_job(self, url: str, req: Job) -> UpdateJobResponse:
        body = asdict(req)
        data = self._send_request("PUT", url, body)
        return UpdateJobResponse(job=self._parse_job_response(data))

    def _update_sub_process(self, methodType: str, url: str, subprocess: ExternalSubprocess) -> UpdateJobResponse:
        data = self._send_request(methodType, url, asdict(subprocess))
        return UpdateJobResponse(job=self._parse_job_response(data))

    # ===== Public Methods =====

    def get_job(self, job_id: int) -> GetJobResponse:
        url = self._job_api_path()
        data = self._send_request("GET", url)
        return GetJobResponse(job=self._parse_job_response(data))

    def add_subprocess(self, name: str) -> UpdateJobResponse:
        subprocess = ExternalSubprocess(name=name)
        return self._update_sub_process("POST", self._subprocess_api_path(), subprocess)

    def mark_job_complete_without_subprocess(self, success: bool, message: str = "") -> UpdateJobResponse:
        status = JobStatus.SUCCEEDED if success else JobStatus.FAILED
        job_id = self._get_job_id()
        req = Job(id=job_id, status=status, state=JobState.FINISHED, state_message=message, persisting_message=[message])
        return self._put_job(self._job_api_path(), req)

    def mark_subprocess_and_job_complete(self, sub_process_id: int, name: str, success: bool, message: str = "") -> UpdateJobResponse:
        return self.mark_subprocess_complete(sub_process_id, name, success, True, message)

    def mark_subprocess_complete(self, sub_process_id: int, name: str, success: bool, update_job_status: bool, message: str = "") -> UpdateJobResponse:
        status = JobStatus.SUCCEEDED if success else JobStatus.FAILED
        subprocess = ExternalSubprocess(
            id=sub_process_id,
            name=name,
            status=status,
            state=JobState.FINISHED,
            state_message=message,
        )
        if success and update_job_status:
            url = f"{self._subprocess_api_path_with_id(sub_process_id)}?shouldFailJob='false'"
            self._update_sub_process("PUT", url, subprocess)
            return self.mark_job_complete_without_subprocess(success)
        else:
            url = f"{self._subprocess_api_path_with_id(sub_process_id)}?shouldFailJob={'true' if update_job_status else 'false'}"
            return self._update_sub_process("PUT", url, subprocess)
    
    def start_sub_process(self, sub_process_id: int, name: str) -> UpdateJobResponse:
        subprocess = ExternalSubprocess(
            id=sub_process_id,
            name=name,
            state=JobState.STARTED
        )
        url = f"{self._subprocess_api_path_with_id(sub_process_id)}?shouldFailJob='false'"
        return self._update_sub_process("PUT", url, subprocess)

    def update_job(self, req: Job, use_subprocess_statuses: bool) -> UpdateJobResponse:
        url = f"{self._job_api_path()}?useSubProcessesForStatus={'true' if use_subprocess_statuses else 'false'}"
        return self._put_job(url, req)
