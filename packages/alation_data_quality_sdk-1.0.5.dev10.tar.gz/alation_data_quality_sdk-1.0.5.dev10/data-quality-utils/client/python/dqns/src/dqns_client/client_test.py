import unittest
from unittest.mock import Mock, patch
import json
from .client import (
    DqNotificationClient, JobState, JobStatus, NFSeverity,
    Detail, NonFatalError, Error, ExternalSubprocess, Job,
    GetJobResponse, UpdateJobResponse
)


class TestEnums(unittest.TestCase):
    
    def test_job_state_enum(self):
        self.assertEqual(JobState.NOT_STARTED, "NOT_STARTED")
        self.assertEqual(JobState.QUEUED, "QUEUED")
        self.assertEqual(JobState.STARTED, "STARTED")
        self.assertEqual(JobState.FINISHED, "FINISHED")
    
    def test_job_status_enum(self):
        self.assertEqual(JobStatus.NA, "NA")
        self.assertEqual(JobStatus.SUCCEEDED, "SUCCEEDED")
        self.assertEqual(JobStatus.FAILED, "FAILED")
        self.assertEqual(JobStatus.SKIPPED, "SKIPPED")
    
    def test_nf_severity_enum(self):
        self.assertEqual(NFSeverity.P1, "P1")
        self.assertEqual(NFSeverity.P2, "P2")


class TestDataClasses(unittest.TestCase):
    
    def test_detail_dataclass(self):
        detail = Detail(id=1, key="test_key", text="test_text", count=5)
        self.assertEqual(detail.id, 1)
        self.assertEqual(detail.key, "test_key")
        self.assertEqual(detail.text, "test_text")
        self.assertEqual(detail.count, 5)
    
    def test_non_fatal_error_dataclass(self):
        error = NonFatalError(
            id=1,
            category="test_category",
            details={"key": "value"},
            error_message="test error",
            hint="test hint",
            job_id=123,
            name="test_name",
            severity=NFSeverity.P1
        )
        self.assertEqual(error.id, 1)
        self.assertEqual(error.category, "test_category")
        self.assertEqual(error.details, {"key": "value"})
        self.assertEqual(error.severity, NFSeverity.P1)
    
    def test_error_dataclass(self):
        error = Error(
            id=1,
            category="test_category",
            error_code="TEST001",
            error_message="test error",
            fatal=True,
            hint="test hint",
            job_id=123,
            name="test_error",
            stack_trace="test stack trace",
            timestamp="2023-10-31T12:00:00Z"
        )
        self.assertEqual(error.id, 1)
        self.assertEqual(error.fatal, True)
        self.assertEqual(error.error_code, "TEST001")
    
    def test_external_subprocess_dataclass(self):
        subprocess = ExternalSubprocess(
            id=1,
            job_id=123,
            name="test_subprocess",
            status=JobStatus.SUCCEEDED,
            state=JobState.FINISHED,
            state_message="test message",
            ts_updated="2023-10-31T12:00:00Z",
            ts_finished="2023-10-31T12:05:00Z"
        )
        self.assertEqual(subprocess.id, 1)
        self.assertEqual(subprocess.job_id, 123)
        self.assertEqual(subprocess.status, JobStatus.SUCCEEDED)
    
    def test_job_dataclass(self):
        job = Job(
            id=123,
            uuid="test-uuid",
            state=JobState.STARTED,
            status=JobStatus.SUCCEEDED,
            state_message="test message",
            persisting_message=["msg1", "msg2"],
            has_fatal_error=False,
            has_non_fatal_error=True,
            has_p1_error=False
        )
        self.assertEqual(job.id, 123)
        self.assertEqual(job.uuid, "test-uuid")
        self.assertEqual(job.state, JobState.STARTED)
        self.assertEqual(job.persisting_message, ["msg1", "msg2"])


class TestDqNotificationClient(unittest.TestCase):
    
    def setUp(self):
        self.client = DqNotificationClient(
            service_name="test-service",
            service_namespace="test-namespace",
            tenant_id="tenant-123",
            job_id="456"
        )
    
    def test_init(self):
        self.assertEqual(self.client.tenant_id, "tenant-123")
        self.assertEqual(self.client.job_id, "456")
        self.assertEqual(
            self.client.base_url,
            "http://test-service.test-namespace.svc.cluster.local:80"
        )
    
    def test_get_job_id(self):
        # Test valid job ID
        self.assertEqual(self.client._get_job_id(), 456)
        
        # Test invalid job ID
        invalid_client = DqNotificationClient("test", "test", "test", "invalid")
        self.assertIsNone(invalid_client._get_job_id())
    
    def test_job_api_path(self):
        expected = "http://test-service.test-namespace.svc.cluster.local:80/api/jobs/456"
        self.assertEqual(self.client._job_api_path(), expected)
    
    def test_subprocess_api_path(self):
        expected = "http://test-service.test-namespace.svc.cluster.local:80/api/jobs/456/subprocess"
        self.assertEqual(self.client._subprocess_api_path(), expected)
    
    def test_subprocess_api_path_with_id(self):
        expected = "http://test-service.test-namespace.svc.cluster.local:80/api/jobs/456/subprocess/123"
        self.assertEqual(self.client._subprocess_api_path_with_id(123), expected)
    
    def test_parse_job_response(self):
        # Test with 'job' key
        data = {"job": {"id": 123, "uuid": "test-uuid", "state": "STARTED"}}
        job = self.client._parse_job_response(data)
        self.assertEqual(job.id, 123)
        self.assertEqual(job.uuid, "test-uuid")
        
        # Test with 'Job' key
        data = {"Job": {"id": 456, "uuid": "test-uuid2", "state": "FINISHED"}}
        job = self.client._parse_job_response(data)
        self.assertEqual(job.id, 456)
        
        # Test invalid format
        with self.assertRaises(ValueError):
            self.client._parse_job_response({"invalid": "data"})
    
    @patch('requests.Session.request')
    def test_get_job_success(self, mock_request):
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "job": {
                "id": 123,
                "uuid": "test-uuid",
                "state": "STARTED",
                "status": "SUCCEEDED"
            }
        }
        mock_request.return_value = mock_response
        
        response = self.client.get_job(123)
        
        self.assertIsInstance(response, GetJobResponse)
        self.assertEqual(response.job.id, 123)
        self.assertEqual(response.job.uuid, "test-uuid")
        
        # Verify request was made correctly
        mock_request.assert_called_once()
        _, kwargs = mock_request.call_args
        self.assertIn("tenant-123", kwargs['headers']['Cookie'])
    
    @patch('requests.Session.request')
    def test_send_request_retry_logic(self, mock_request):
        # Mock retriable failures followed by success
        responses = [
            Mock(status_code=502),  # Bad Gateway
            Mock(status_code=503),  # Service Unavailable  
            Mock(status_code=200)   # Success
        ]
        responses[2].json.return_value = {"success": True}
        mock_request.side_effect = responses
        
        result = self.client._send_request("GET", "http://test.com")
        
        self.assertEqual(result, {"success": True})
        self.assertEqual(mock_request.call_count, 3)
    
    @patch('requests.Session.request')
    def test_send_request_non_retriable_error(self, mock_request):
        # Mock non-retriable error
        mock_response = Mock()
        mock_response.status_code = 400  # Bad Request
        mock_request.return_value = mock_response
        
        with self.assertRaises(Exception) as context:
            self.client._send_request("GET", "http://test.com")
        
        self.assertIn("non-retriable status: 400", str(context.exception))
    
    @patch('requests.Session.request')
    def test_add_subprocess_success(self, mock_request):
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "job": {
                "id": 456,
                "state": "STARTED"
            }
        }
        mock_request.return_value = mock_response
        
        response = self.client.add_subprocess("test-subprocess")
        
        self.assertIsInstance(response, UpdateJobResponse)
        self.assertEqual(response.job.id, 456)
        
        # Verify request body
        mock_request.assert_called_once()
        _, kwargs = mock_request.call_args
        request_data = json.loads(kwargs['data'])
        self.assertEqual(request_data['name'], "test-subprocess")
    
    @patch('requests.Session.request')
    def test_start_sub_process_success(self, mock_request):
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "job": {
                "id": 456,
                "state": "STARTED"
            }
        }
        mock_request.return_value = mock_response
        
        response = self.client.start_sub_process(123, "test-subprocess")
        
        self.assertIsInstance(response, UpdateJobResponse)
        
        # Verify request parameters
        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        self.assertIn("shouldFailJob='false'", args[1])
        
        request_data = json.loads(kwargs['data'])
        self.assertEqual(request_data['id'], 123)
        self.assertEqual(request_data['name'], "test-subprocess")
        self.assertEqual(request_data['state'], JobState.STARTED)
    
    @patch('requests.Session.request')
    def test_mark_job_complete_without_subprocess_success(self, mock_request):
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "job": {
                "id": 456,
                "status": "SUCCEEDED",
                "state": "FINISHED"
            }
        }
        mock_request.return_value = mock_response
        
        response = self.client.mark_job_complete_without_subprocess(success=True)
        
        self.assertIsInstance(response, UpdateJobResponse)
        
        # Verify request body
        mock_request.assert_called_once()
        _, kwargs = mock_request.call_args
        request_data = json.loads(kwargs['data'])
        self.assertEqual(request_data['id'], 456)
        self.assertEqual(request_data['status'], JobStatus.SUCCEEDED)
        self.assertEqual(request_data['state'], JobState.FINISHED)
    
    @patch('requests.Session.request')
    def test_mark_job_complete_without_subprocess_failure(self, mock_request):
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "job": {
                "id": 456,
                "status": "FAILED",
                "state": "FINISHED"
            }
        }
        mock_request.return_value = mock_response
        
        response = self.client.mark_job_complete_without_subprocess(success=False, message="Test failure")
        
        # Verify request body contains failed status
        mock_request.assert_called_once()
        _, kwargs = mock_request.call_args
        request_data = json.loads(kwargs['data'])
        self.assertEqual(request_data['status'], JobStatus.FAILED)
        self.assertEqual(request_data['state_message'], "Test failure")
        self.assertEqual(request_data['persisting_message'], ["Test failure"])
    
    @patch('requests.Session.request')
    def test_mark_subprocess_complete(self, mock_request):
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "job": {
                "id": 456,
                "status": "SUCCEEDED"
            }
        }
        mock_request.return_value = mock_response
        
        response = self.client.mark_subprocess_complete(
            sub_process_id=123,
            name="test-subprocess",
            success=True,
            update_job_status=False,
            message="Completed"
        )
        
        self.assertIsInstance(response, UpdateJobResponse)
        
        # Verify request was made to correct endpoint
        mock_request.assert_called_once()
        args, _ = mock_request.call_args
        self.assertIn("/subprocess/123", args[1])
        self.assertIn("shouldFailJob=false", args[1])


if __name__ == '__main__':
    unittest.main()