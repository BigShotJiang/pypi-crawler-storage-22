import logging
import structlog
from structlog import wrap_logger
import sys

# Internal guard to avoid reconfiguring logging multiple times
_logging_configured = False

def _configure_logging_once():
    global _logging_configured
    if _logging_configured:
        return

    logging.basicConfig(
        format="%(message)s",  # structlog handles formatting
        stream=sys.stdout,
        level=logging.INFO
    )

    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.stdlib.add_log_level,
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True
    )

    _logging_configured = True

def get_struct_logger(module_name, **required_default_kwargs):
    _configure_logging_once()
    return wrap_logger(logging.getLogger(module_name), **required_default_kwargs)
