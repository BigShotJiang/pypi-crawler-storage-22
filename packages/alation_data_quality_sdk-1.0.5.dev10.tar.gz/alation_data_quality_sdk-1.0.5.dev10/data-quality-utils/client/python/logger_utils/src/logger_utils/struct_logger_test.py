import unittest
from unittest.mock import patch, Mock
import logging
import structlog
from . import struct_logger
from .struct_logger import get_struct_logger, _configure_logging_once


class TestStructLogger(unittest.TestCase):
    
    def setUp(self):
        # Reset the global configuration flag for each test
        from . import struct_logger
        struct_logger._logging_configured = False

    @patch('logging.basicConfig')
    @patch('structlog.configure')
    def test_configure_logging_once_first_call(self, mock_structlog_configure, mock_basic_config):
        """Test that _configure_logging_once configures logging on first call"""
        _configure_logging_once()
        
        # Verify basic logging configuration
        mock_basic_config.assert_called_once()
        call_kwargs = mock_basic_config.call_args[1]
        self.assertEqual(call_kwargs['format'], "%(message)s")
        self.assertEqual(call_kwargs['level'], logging.INFO)
        
        # Verify structlog configuration
        mock_structlog_configure.assert_called_once()
        configure_kwargs = mock_structlog_configure.call_args[1]
        
        # Check that all expected keys are present
        expected_keys = ['processors', 'context_class', 'logger_factory', 'wrapper_class', 'cache_logger_on_first_use']
        for key in expected_keys:
            self.assertIn(key, configure_kwargs)
        
        # Check specific values
        self.assertEqual(configure_kwargs['context_class'], dict)
        self.assertTrue(configure_kwargs['cache_logger_on_first_use'])
        
        # Check that processors list has expected length and types
        processors = configure_kwargs['processors']
        self.assertEqual(len(processors), 4)
    
    @patch('logging.basicConfig')
    @patch('structlog.configure')
    def test_configure_logging_once_subsequent_calls(self, mock_structlog_configure, mock_basic_config):
        """Test that _configure_logging_once doesn't configure on subsequent calls"""
        # Call twice
        _configure_logging_once()
        _configure_logging_once()
        
        # Should only be called once
        mock_basic_config.assert_called_once()
        mock_structlog_configure.assert_called_once()
    
    def test_processors_configuration(self):
        """Test that structlog processors are configured correctly"""
        with patch('logging.basicConfig'), \
             patch('structlog.configure') as mock_configure:
            
            _configure_logging_once()
            
            # Get the processors that were configured
            configure_kwargs = mock_configure.call_args[1]
            processors = configure_kwargs['processors']
            
            # Check that we have the expected number of processors
            self.assertEqual(len(processors), 4)
            
            # Verify processor types (this is a basic check since the actual processor
            # instances are created by structlog)
            self.assertTrue(callable(processors[0]))  # TimeStamper
            self.assertTrue(callable(processors[1]))  # add_log_level
            self.assertTrue(callable(processors[2]))  # format_exc_info
            self.assertTrue(callable(processors[3]))  # JSONRenderer
    
    def test_logger_factory_configuration(self):
        """Test that logger factory is configured correctly"""
        with patch('logging.basicConfig'), \
             patch('structlog.configure') as mock_configure:
            
            _configure_logging_once()
            
            configure_kwargs = mock_configure.call_args[1]
            logger_factory = configure_kwargs['logger_factory']
            
            # Verify it's a LoggerFactory instance
            self.assertIsInstance(logger_factory, structlog.stdlib.LoggerFactory)
    
    def test_wrapper_class_configuration(self):
        """Test that wrapper class is configured correctly"""
        with patch('logging.basicConfig'), \
             patch('structlog.configure') as mock_configure:
            
            _configure_logging_once()
            
            configure_kwargs = mock_configure.call_args[1]
            wrapper_class = configure_kwargs['wrapper_class']
            
            # Verify it's the correct wrapper class
            self.assertEqual(wrapper_class, structlog.stdlib.BoundLogger)


if __name__ == '__main__':
    unittest.main()