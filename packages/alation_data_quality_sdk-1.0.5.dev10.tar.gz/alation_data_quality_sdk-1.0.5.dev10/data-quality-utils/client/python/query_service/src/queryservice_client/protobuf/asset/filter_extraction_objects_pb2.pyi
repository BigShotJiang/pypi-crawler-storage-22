from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Filter(_message.Message):
    __slots__ = ("external_id", "path", "additionalInfo")
    class AdditionalInfoEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    ADDITIONALINFO_FIELD_NUMBER: _ClassVar[int]
    external_id: str
    path: Path
    additionalInfo: _containers.ScalarMap[str, str]
    def __init__(self, external_id: _Optional[str] = ..., path: _Optional[_Union[Path, _Mapping]] = ..., additionalInfo: _Optional[_Mapping[str, str]] = ...) -> None: ...

class Path(_message.Message):
    __slots__ = ("path", "delimiter")
    PATH_FIELD_NUMBER: _ClassVar[int]
    DELIMITER_FIELD_NUMBER: _ClassVar[int]
    path: _containers.RepeatedScalarFieldContainer[str]
    delimiter: str
    def __init__(self, path: _Optional[_Iterable[str]] = ..., delimiter: _Optional[str] = ...) -> None: ...
