from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from asset import filter_extraction_objects_pb2 as _filter_extraction_objects_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FilterExtractionRequest(_message.Message):
    __slots__ = ("configuration",)
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ...) -> None: ...

class FilterExtractionResponse(_message.Message):
    __slots__ = ("filter",)
    FILTER_FIELD_NUMBER: _ClassVar[int]
    filter: _filter_extraction_objects_pb2.Filter
    def __init__(self, filter: _Optional[_Union[_filter_extraction_objects_pb2.Filter, _Mapping]] = ...) -> None: ...
