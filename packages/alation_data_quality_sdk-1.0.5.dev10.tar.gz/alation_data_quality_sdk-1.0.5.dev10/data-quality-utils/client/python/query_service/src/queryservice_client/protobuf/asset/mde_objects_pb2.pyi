from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DQStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GOOD: _ClassVar[DQStatus]
    WARNING: _ClassVar[DQStatus]
    ALERT: _ClassVar[DQStatus]
GOOD: DQStatus
WARNING: DQStatus
ALERT: DQStatus

class Asset(_message.Message):
    __slots__ = ("eid", "parent_eid", "properties")
    EID_FIELD_NUMBER: _ClassVar[int]
    PARENT_EID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    eid: ExternalID
    parent_eid: ExternalID
    properties: _containers.RepeatedCompositeFieldContainer[Property]
    def __init__(self, eid: _Optional[_Union[ExternalID, _Mapping]] = ..., parent_eid: _Optional[_Union[ExternalID, _Mapping]] = ..., properties: _Optional[_Iterable[_Union[Property, _Mapping]]] = ...) -> None: ...

class ExternalID(_message.Message):
    __slots__ = ("atype_id", "atype_name", "eid")
    ATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    ATYPE_NAME_FIELD_NUMBER: _ClassVar[int]
    EID_FIELD_NUMBER: _ClassVar[int]
    atype_id: str
    atype_name: str
    eid: str
    def __init__(self, atype_id: _Optional[str] = ..., atype_name: _Optional[str] = ..., eid: _Optional[str] = ...) -> None: ...

class RelationMetadata(_message.Message):
    __slots__ = ("name", "role")
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    name: str
    role: str
    def __init__(self, name: _Optional[str] = ..., role: _Optional[str] = ...) -> None: ...

class Property(_message.Message):
    __slots__ = ("name", "relationMetadata", "string_v", "list_v", "int32_v", "int64_v", "bool_v", "asset_v", "assets_v")
    NAME_FIELD_NUMBER: _ClassVar[int]
    RELATIONMETADATA_FIELD_NUMBER: _ClassVar[int]
    STRING_V_FIELD_NUMBER: _ClassVar[int]
    LIST_V_FIELD_NUMBER: _ClassVar[int]
    INT32_V_FIELD_NUMBER: _ClassVar[int]
    INT64_V_FIELD_NUMBER: _ClassVar[int]
    BOOL_V_FIELD_NUMBER: _ClassVar[int]
    ASSET_V_FIELD_NUMBER: _ClassVar[int]
    ASSETS_V_FIELD_NUMBER: _ClassVar[int]
    name: str
    relationMetadata: RelationMetadata
    string_v: str
    list_v: _struct_pb2.ListValue
    int32_v: int
    int64_v: int
    bool_v: bool
    asset_v: Asset
    assets_v: Assets
    def __init__(self, name: _Optional[str] = ..., relationMetadata: _Optional[_Union[RelationMetadata, _Mapping]] = ..., string_v: _Optional[str] = ..., list_v: _Optional[_Union[_struct_pb2.ListValue, _Mapping]] = ..., int32_v: _Optional[int] = ..., int64_v: _Optional[int] = ..., bool_v: bool = ..., asset_v: _Optional[_Union[Asset, _Mapping]] = ..., assets_v: _Optional[_Union[Assets, _Mapping]] = ...) -> None: ...

class Assets(_message.Message):
    __slots__ = ("assets",)
    ASSETS_FIELD_NUMBER: _ClassVar[int]
    assets: _containers.RepeatedCompositeFieldContainer[Asset]
    def __init__(self, assets: _Optional[_Iterable[_Union[Asset, _Mapping]]] = ...) -> None: ...

class DQRuleAndValue(_message.Message):
    __slots__ = ("externalID", "name", "type", "description", "asset", "status", "string_v", "int32_v", "bool_v", "url", "lastUpdatedAt")
    EXTERNALID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ASSET_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STRING_V_FIELD_NUMBER: _ClassVar[int]
    INT32_V_FIELD_NUMBER: _ClassVar[int]
    BOOL_V_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    LASTUPDATEDAT_FIELD_NUMBER: _ClassVar[int]
    externalID: str
    name: str
    type: str
    description: str
    asset: Asset
    status: DQStatus
    string_v: str
    int32_v: int
    bool_v: bool
    url: str
    lastUpdatedAt: str
    def __init__(self, externalID: _Optional[str] = ..., name: _Optional[str] = ..., type: _Optional[str] = ..., description: _Optional[str] = ..., asset: _Optional[_Union[Asset, _Mapping]] = ..., status: _Optional[_Union[DQStatus, str]] = ..., string_v: _Optional[str] = ..., int32_v: _Optional[int] = ..., bool_v: bool = ..., url: _Optional[str] = ..., lastUpdatedAt: _Optional[str] = ...) -> None: ...
