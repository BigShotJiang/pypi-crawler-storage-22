from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import job_error_pb2 as _job_error_pb2
from asset import mde_objects_pb2 as _mde_objects_pb2
from asset import filter_extraction_pb2 as _filter_extraction_pb2
from queryservice_client.protobuf.common import extraction_objects_pb2 as _extraction_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MetadataExtractionRequest(_message.Message):
    __slots__ = ("configuration", "filter", "isInclusionFilter")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    ISINCLUSIONFILTER_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    filter: _containers.RepeatedCompositeFieldContainer[_filter_extraction_pb2.FilterExtractionResponse]
    isInclusionFilter: bool
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., filter: _Optional[_Iterable[_Union[_filter_extraction_pb2.FilterExtractionResponse, _Mapping]]] = ..., isInclusionFilter: bool = ...) -> None: ...

class MetadataExtractionResponse(_message.Message):
    __slots__ = ("asset", "error", "extractionProgress", "dqRuleAndValue")
    ASSET_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    EXTRACTIONPROGRESS_FIELD_NUMBER: _ClassVar[int]
    DQRULEANDVALUE_FIELD_NUMBER: _ClassVar[int]
    asset: _mde_objects_pb2.Asset
    error: _job_error_pb2.Error
    extractionProgress: _extraction_objects_pb2.ExtractionProgress
    dqRuleAndValue: _mde_objects_pb2.DQRuleAndValue
    def __init__(self, asset: _Optional[_Union[_mde_objects_pb2.Asset, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ..., extractionProgress: _Optional[_Union[_extraction_objects_pb2.ExtractionProgress, _Mapping]] = ..., dqRuleAndValue: _Optional[_Union[_mde_objects_pb2.DQRuleAndValue, _Mapping]] = ...) -> None: ...
