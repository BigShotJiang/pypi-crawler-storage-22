from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from bi import mde_objects_pb2 as _mde_objects_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PropagateCertificationRequest(_message.Message):
    __slots__ = ("configuration", "biObject", "note", "certify")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    BIOBJECT_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    CERTIFY_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    biObject: _mde_objects_pb2.GBMBIObject
    note: str
    certify: bool
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., biObject: _Optional[_Union[_mde_objects_pb2.GBMBIObject, _Mapping]] = ..., note: _Optional[str] = ..., certify: bool = ...) -> None: ...
