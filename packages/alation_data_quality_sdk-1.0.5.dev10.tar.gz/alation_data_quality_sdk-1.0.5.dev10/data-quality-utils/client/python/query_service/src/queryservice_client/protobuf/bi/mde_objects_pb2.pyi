from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GBMBIObject(_message.Message):
    __slots__ = ("id", "name", "biObjectType", "description", "createdAt", "lastUpdated", "source_url", "biCompositeKey")
    class BiCompositeKeyEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BIOBJECTTYPE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CREATEDAT_FIELD_NUMBER: _ClassVar[int]
    LASTUPDATED_FIELD_NUMBER: _ClassVar[int]
    SOURCE_URL_FIELD_NUMBER: _ClassVar[int]
    BICOMPOSITEKEY_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    biObjectType: str
    description: str
    createdAt: str
    lastUpdated: str
    source_url: str
    biCompositeKey: _containers.ScalarMap[str, str]
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., biObjectType: _Optional[str] = ..., description: _Optional[str] = ..., createdAt: _Optional[str] = ..., lastUpdated: _Optional[str] = ..., source_url: _Optional[str] = ..., biCompositeKey: _Optional[_Mapping[str, str]] = ...) -> None: ...

class GBMBIUser(_message.Message):
    __slots__ = ("biObject", "username")
    BIOBJECT_FIELD_NUMBER: _ClassVar[int]
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    biObject: GBMBIObject
    username: str
    def __init__(self, biObject: _Optional[_Union[GBMBIObject, _Mapping]] = ..., username: _Optional[str] = ...) -> None: ...

class GBMBIFolder(_message.Message):
    __slots__ = ("biObject", "owner", "numReports", "numReportAccesses", "parentFolderId", "isExtractable")
    BIOBJECT_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    NUMREPORTS_FIELD_NUMBER: _ClassVar[int]
    NUMREPORTACCESSES_FIELD_NUMBER: _ClassVar[int]
    PARENTFOLDERID_FIELD_NUMBER: _ClassVar[int]
    ISEXTRACTABLE_FIELD_NUMBER: _ClassVar[int]
    biObject: GBMBIObject
    owner: str
    numReports: int
    numReportAccesses: int
    parentFolderId: str
    isExtractable: bool
    def __init__(self, biObject: _Optional[_Union[GBMBIObject, _Mapping]] = ..., owner: _Optional[str] = ..., numReports: _Optional[int] = ..., numReportAccesses: _Optional[int] = ..., parentFolderId: _Optional[str] = ..., isExtractable: bool = ...) -> None: ...

class GBMBIReport(_message.Message):
    __slots__ = ("biObject", "owner", "numAccesses", "parentFolderId", "parentReportIds", "datasourceIds", "type")
    class Type(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        SIMPLE: _ClassVar[GBMBIReport.Type]
        DASHBOARD: _ClassVar[GBMBIReport.Type]
    SIMPLE: GBMBIReport.Type
    DASHBOARD: GBMBIReport.Type
    BIOBJECT_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    NUMACCESSES_FIELD_NUMBER: _ClassVar[int]
    PARENTFOLDERID_FIELD_NUMBER: _ClassVar[int]
    PARENTREPORTIDS_FIELD_NUMBER: _ClassVar[int]
    DATASOURCEIDS_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    biObject: GBMBIObject
    owner: str
    numAccesses: int
    parentFolderId: str
    parentReportIds: _containers.RepeatedScalarFieldContainer[str]
    datasourceIds: _containers.RepeatedScalarFieldContainer[str]
    type: GBMBIReport.Type
    def __init__(self, biObject: _Optional[_Union[GBMBIObject, _Mapping]] = ..., owner: _Optional[str] = ..., numAccesses: _Optional[int] = ..., parentFolderId: _Optional[str] = ..., parentReportIds: _Optional[_Iterable[str]] = ..., datasourceIds: _Optional[_Iterable[str]] = ..., type: _Optional[_Union[GBMBIReport.Type, str]] = ...) -> None: ...

class GBMBIDatasource(_message.Message):
    __slots__ = ("biObject", "owner", "parentFolderId", "connectionIds", "linkedDatasourceIds")
    BIOBJECT_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    PARENTFOLDERID_FIELD_NUMBER: _ClassVar[int]
    CONNECTIONIDS_FIELD_NUMBER: _ClassVar[int]
    LINKEDDATASOURCEIDS_FIELD_NUMBER: _ClassVar[int]
    biObject: GBMBIObject
    owner: str
    parentFolderId: str
    connectionIds: _containers.RepeatedScalarFieldContainer[str]
    linkedDatasourceIds: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, biObject: _Optional[_Union[GBMBIObject, _Mapping]] = ..., owner: _Optional[str] = ..., parentFolderId: _Optional[str] = ..., connectionIds: _Optional[_Iterable[str]] = ..., linkedDatasourceIds: _Optional[_Iterable[str]] = ...) -> None: ...

class GBMBIConnection(_message.Message):
    __slots__ = ("biObject", "parentFolderId", "connectionType", "displayConnectionType", "databaseType", "host", "port", "dbSchema", "dbTable", "sql", "dataFiles")
    class Type(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        FILES: _ClassVar[GBMBIConnection.Type]
        TABLE: _ClassVar[GBMBIConnection.Type]
        SQL_QUERY: _ClassVar[GBMBIConnection.Type]
        OTHER: _ClassVar[GBMBIConnection.Type]
    FILES: GBMBIConnection.Type
    TABLE: GBMBIConnection.Type
    SQL_QUERY: GBMBIConnection.Type
    OTHER: GBMBIConnection.Type
    BIOBJECT_FIELD_NUMBER: _ClassVar[int]
    PARENTFOLDERID_FIELD_NUMBER: _ClassVar[int]
    CONNECTIONTYPE_FIELD_NUMBER: _ClassVar[int]
    DISPLAYCONNECTIONTYPE_FIELD_NUMBER: _ClassVar[int]
    DATABASETYPE_FIELD_NUMBER: _ClassVar[int]
    HOST_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    DBSCHEMA_FIELD_NUMBER: _ClassVar[int]
    DBTABLE_FIELD_NUMBER: _ClassVar[int]
    SQL_FIELD_NUMBER: _ClassVar[int]
    DATAFILES_FIELD_NUMBER: _ClassVar[int]
    biObject: GBMBIObject
    parentFolderId: str
    connectionType: GBMBIConnection.Type
    displayConnectionType: str
    databaseType: str
    host: str
    port: str
    dbSchema: str
    dbTable: str
    sql: str
    dataFiles: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, biObject: _Optional[_Union[GBMBIObject, _Mapping]] = ..., parentFolderId: _Optional[str] = ..., connectionType: _Optional[_Union[GBMBIConnection.Type, str]] = ..., displayConnectionType: _Optional[str] = ..., databaseType: _Optional[str] = ..., host: _Optional[str] = ..., port: _Optional[str] = ..., dbSchema: _Optional[str] = ..., dbTable: _Optional[str] = ..., sql: _Optional[str] = ..., dataFiles: _Optional[_Iterable[str]] = ...) -> None: ...

class GBMBIColumnBase(_message.Message):
    __slots__ = ("biObject", "dataType", "role", "expression", "values")
    BIOBJECT_FIELD_NUMBER: _ClassVar[int]
    DATATYPE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    EXPRESSION_FIELD_NUMBER: _ClassVar[int]
    VALUES_FIELD_NUMBER: _ClassVar[int]
    biObject: GBMBIObject
    dataType: str
    role: str
    expression: str
    values: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, biObject: _Optional[_Union[GBMBIObject, _Mapping]] = ..., dataType: _Optional[str] = ..., role: _Optional[str] = ..., expression: _Optional[str] = ..., values: _Optional[_Iterable[str]] = ...) -> None: ...

class GBMBIReportColumn(_message.Message):
    __slots__ = ("biColumnBase", "reportId", "datasourceColumnIds", "parentReportColumnIds")
    BICOLUMNBASE_FIELD_NUMBER: _ClassVar[int]
    REPORTID_FIELD_NUMBER: _ClassVar[int]
    DATASOURCECOLUMNIDS_FIELD_NUMBER: _ClassVar[int]
    PARENTREPORTCOLUMNIDS_FIELD_NUMBER: _ClassVar[int]
    biColumnBase: GBMBIColumnBase
    reportId: str
    datasourceColumnIds: _containers.RepeatedScalarFieldContainer[str]
    parentReportColumnIds: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, biColumnBase: _Optional[_Union[GBMBIColumnBase, _Mapping]] = ..., reportId: _Optional[str] = ..., datasourceColumnIds: _Optional[_Iterable[str]] = ..., parentReportColumnIds: _Optional[_Iterable[str]] = ...) -> None: ...

class GBMBIDatasourceColumn(_message.Message):
    __slots__ = ("biColumnBase", "datasourceId", "parentDatasourceColumnIds", "parentConnectionColumnIds")
    BICOLUMNBASE_FIELD_NUMBER: _ClassVar[int]
    DATASOURCEID_FIELD_NUMBER: _ClassVar[int]
    PARENTDATASOURCECOLUMNIDS_FIELD_NUMBER: _ClassVar[int]
    PARENTCONNECTIONCOLUMNIDS_FIELD_NUMBER: _ClassVar[int]
    biColumnBase: GBMBIColumnBase
    datasourceId: str
    parentDatasourceColumnIds: _containers.RepeatedScalarFieldContainer[str]
    parentConnectionColumnIds: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, biColumnBase: _Optional[_Union[GBMBIColumnBase, _Mapping]] = ..., datasourceId: _Optional[str] = ..., parentDatasourceColumnIds: _Optional[_Iterable[str]] = ..., parentConnectionColumnIds: _Optional[_Iterable[str]] = ...) -> None: ...

class GBMBIConnectionColumn(_message.Message):
    __slots__ = ("biColumnBase", "connectionId")
    BICOLUMNBASE_FIELD_NUMBER: _ClassVar[int]
    CONNECTIONID_FIELD_NUMBER: _ClassVar[int]
    biColumnBase: GBMBIColumnBase
    connectionId: str
    def __init__(self, biColumnBase: _Optional[_Union[GBMBIColumnBase, _Mapping]] = ..., connectionId: _Optional[str] = ...) -> None: ...

class GBMBIPermission(_message.Message):
    __slots__ = ("userExternalId", "objectOType", "objectExternalId", "id")
    USEREXTERNALID_FIELD_NUMBER: _ClassVar[int]
    OBJECTOTYPE_FIELD_NUMBER: _ClassVar[int]
    OBJECTEXTERNALID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    userExternalId: str
    objectOType: str
    objectExternalId: str
    id: str
    def __init__(self, userExternalId: _Optional[str] = ..., objectOType: _Optional[str] = ..., objectExternalId: _Optional[str] = ..., id: _Optional[str] = ...) -> None: ...

class GBMBIImage(_message.Message):
    __slots__ = ("imageName", "imageData", "errorMessage", "hasMore")
    IMAGENAME_FIELD_NUMBER: _ClassVar[int]
    IMAGEDATA_FIELD_NUMBER: _ClassVar[int]
    ERRORMESSAGE_FIELD_NUMBER: _ClassVar[int]
    HASMORE_FIELD_NUMBER: _ClassVar[int]
    imageName: str
    imageData: bytes
    errorMessage: str
    hasMore: bool
    def __init__(self, imageName: _Optional[str] = ..., imageData: _Optional[bytes] = ..., errorMessage: _Optional[str] = ..., hasMore: bool = ...) -> None: ...

class AlationUser(_message.Message):
    __slots__ = ("username",)
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    username: str
    def __init__(self, username: _Optional[str] = ...) -> None: ...
