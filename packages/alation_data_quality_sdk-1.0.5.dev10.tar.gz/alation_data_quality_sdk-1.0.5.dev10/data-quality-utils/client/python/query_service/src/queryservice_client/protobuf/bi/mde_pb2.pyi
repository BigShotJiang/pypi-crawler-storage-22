from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import job_error_pb2 as _job_error_pb2
from bi import mde_objects_pb2 as _mde_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ListFileSystemRequest(_message.Message):
    __slots__ = ("configuration", "users")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    users: _containers.RepeatedCompositeFieldContainer[_mde_objects_pb2.AlationUser]
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., users: _Optional[_Iterable[_Union[_mde_objects_pb2.AlationUser, _Mapping]]] = ...) -> None: ...

class RunFullExtractionRequest(_message.Message):
    __slots__ = ("configuration", "folders", "isIncludeFilter", "users")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    FOLDERS_FIELD_NUMBER: _ClassVar[int]
    ISINCLUDEFILTER_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    folders: _containers.RepeatedCompositeFieldContainer[_mde_objects_pb2.GBMBIFolder]
    isIncludeFilter: bool
    users: _containers.RepeatedCompositeFieldContainer[_mde_objects_pb2.AlationUser]
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., folders: _Optional[_Iterable[_Union[_mde_objects_pb2.GBMBIFolder, _Mapping]]] = ..., isIncludeFilter: bool = ..., users: _Optional[_Iterable[_Union[_mde_objects_pb2.AlationUser, _Mapping]]] = ...) -> None: ...

class BIObjectResponse(_message.Message):
    __slots__ = ("biUser", "biFolder", "biReport", "biDataSource", "biConnection", "biReportColumn", "biDatasourceColumn", "biConnectionColumn", "biPermission", "biImage", "error")
    BIUSER_FIELD_NUMBER: _ClassVar[int]
    BIFOLDER_FIELD_NUMBER: _ClassVar[int]
    BIREPORT_FIELD_NUMBER: _ClassVar[int]
    BIDATASOURCE_FIELD_NUMBER: _ClassVar[int]
    BICONNECTION_FIELD_NUMBER: _ClassVar[int]
    BIREPORTCOLUMN_FIELD_NUMBER: _ClassVar[int]
    BIDATASOURCECOLUMN_FIELD_NUMBER: _ClassVar[int]
    BICONNECTIONCOLUMN_FIELD_NUMBER: _ClassVar[int]
    BIPERMISSION_FIELD_NUMBER: _ClassVar[int]
    BIIMAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    biUser: _mde_objects_pb2.GBMBIUser
    biFolder: _mde_objects_pb2.GBMBIFolder
    biReport: _mde_objects_pb2.GBMBIReport
    biDataSource: _mde_objects_pb2.GBMBIDatasource
    biConnection: _mde_objects_pb2.GBMBIConnection
    biReportColumn: _mde_objects_pb2.GBMBIReportColumn
    biDatasourceColumn: _mde_objects_pb2.GBMBIDatasourceColumn
    biConnectionColumn: _mde_objects_pb2.GBMBIConnectionColumn
    biPermission: _mde_objects_pb2.GBMBIPermission
    biImage: _mde_objects_pb2.GBMBIImage
    error: _job_error_pb2.Error
    def __init__(self, biUser: _Optional[_Union[_mde_objects_pb2.GBMBIUser, _Mapping]] = ..., biFolder: _Optional[_Union[_mde_objects_pb2.GBMBIFolder, _Mapping]] = ..., biReport: _Optional[_Union[_mde_objects_pb2.GBMBIReport, _Mapping]] = ..., biDataSource: _Optional[_Union[_mde_objects_pb2.GBMBIDatasource, _Mapping]] = ..., biConnection: _Optional[_Union[_mde_objects_pb2.GBMBIConnection, _Mapping]] = ..., biReportColumn: _Optional[_Union[_mde_objects_pb2.GBMBIReportColumn, _Mapping]] = ..., biDatasourceColumn: _Optional[_Union[_mde_objects_pb2.GBMBIDatasourceColumn, _Mapping]] = ..., biConnectionColumn: _Optional[_Union[_mde_objects_pb2.GBMBIConnectionColumn, _Mapping]] = ..., biPermission: _Optional[_Union[_mde_objects_pb2.GBMBIPermission, _Mapping]] = ..., biImage: _Optional[_Union[_mde_objects_pb2.GBMBIImage, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ...) -> None: ...
