from queryservice_client.protobuf.rdbms import mde_objects_pb2 as _mde_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CustomFieldType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PICKER: _ClassVar[CustomFieldType]
PICKER: CustomFieldType

class CustomFieldId(_message.Message):
    __slots__ = ("parts",)
    PARTS_FIELD_NUMBER: _ClassVar[int]
    parts: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, parts: _Optional[_Iterable[str]] = ...) -> None: ...

class CustomFieldApiId(_message.Message):
    __slots__ = ("key",)
    class KeyEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    KEY_FIELD_NUMBER: _ClassVar[int]
    key: _containers.ScalarMap[str, str]
    def __init__(self, key: _Optional[_Mapping[str, str]] = ...) -> None: ...

class CustomField(_message.Message):
    __slots__ = ("id", "apiId", "name", "fullyQualifiedName", "customFieldType", "allowedPickerValues")
    ID_FIELD_NUMBER: _ClassVar[int]
    APIID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    FULLYQUALIFIEDNAME_FIELD_NUMBER: _ClassVar[int]
    CUSTOMFIELDTYPE_FIELD_NUMBER: _ClassVar[int]
    ALLOWEDPICKERVALUES_FIELD_NUMBER: _ClassVar[int]
    id: CustomFieldId
    apiId: CustomFieldApiId
    name: str
    fullyQualifiedName: str
    customFieldType: CustomFieldType
    allowedPickerValues: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, id: _Optional[_Union[CustomFieldId, _Mapping]] = ..., apiId: _Optional[_Union[CustomFieldApiId, _Mapping]] = ..., name: _Optional[str] = ..., fullyQualifiedName: _Optional[str] = ..., customFieldType: _Optional[_Union[CustomFieldType, str]] = ..., allowedPickerValues: _Optional[_Iterable[str]] = ...) -> None: ...

class CustomFieldPickerValue(_message.Message):
    __slots__ = ("customFieldId", "value")
    CUSTOMFIELDID_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    customFieldId: CustomFieldId
    value: str
    def __init__(self, customFieldId: _Optional[_Union[CustomFieldId, _Mapping]] = ..., value: _Optional[str] = ...) -> None: ...

class CustomFieldLink(_message.Message):
    __slots__ = ("schemaId", "tableId", "columnId", "pickerValue")
    SCHEMAID_FIELD_NUMBER: _ClassVar[int]
    TABLEID_FIELD_NUMBER: _ClassVar[int]
    COLUMNID_FIELD_NUMBER: _ClassVar[int]
    PICKERVALUE_FIELD_NUMBER: _ClassVar[int]
    schemaId: _mde_objects_pb2.SchemaId
    tableId: _mde_objects_pb2.TableId
    columnId: _mde_objects_pb2.ColumnId
    pickerValue: CustomFieldPickerValue
    def __init__(self, schemaId: _Optional[_Union[_mde_objects_pb2.SchemaId, _Mapping]] = ..., tableId: _Optional[_Union[_mde_objects_pb2.TableId, _Mapping]] = ..., columnId: _Optional[_Union[_mde_objects_pb2.ColumnId, _Mapping]] = ..., pickerValue: _Optional[_Union[CustomFieldPickerValue, _Mapping]] = ...) -> None: ...

class CustomFieldSyncValue(_message.Message):
    __slots__ = ("vString",)
    VSTRING_FIELD_NUMBER: _ClassVar[int]
    vString: str
    def __init__(self, vString: _Optional[str] = ...) -> None: ...

class CustomFieldValueUpdate(_message.Message):
    __slots__ = ("schemaApiId", "tableApiId", "columnApiId", "customFieldApiId", "customFieldType", "newValue")
    SCHEMAAPIID_FIELD_NUMBER: _ClassVar[int]
    TABLEAPIID_FIELD_NUMBER: _ClassVar[int]
    COLUMNAPIID_FIELD_NUMBER: _ClassVar[int]
    CUSTOMFIELDAPIID_FIELD_NUMBER: _ClassVar[int]
    CUSTOMFIELDTYPE_FIELD_NUMBER: _ClassVar[int]
    NEWVALUE_FIELD_NUMBER: _ClassVar[int]
    schemaApiId: _mde_objects_pb2.SchemaApiId
    tableApiId: _mde_objects_pb2.TableApiId
    columnApiId: _mde_objects_pb2.ColumnApiId
    customFieldApiId: CustomFieldApiId
    customFieldType: CustomFieldType
    newValue: CustomFieldSyncValue
    def __init__(self, schemaApiId: _Optional[_Union[_mde_objects_pb2.SchemaApiId, _Mapping]] = ..., tableApiId: _Optional[_Union[_mde_objects_pb2.TableApiId, _Mapping]] = ..., columnApiId: _Optional[_Union[_mde_objects_pb2.ColumnApiId, _Mapping]] = ..., customFieldApiId: _Optional[_Union[CustomFieldApiId, _Mapping]] = ..., customFieldType: _Optional[_Union[CustomFieldType, str]] = ..., newValue: _Optional[_Union[CustomFieldSyncValue, _Mapping]] = ...) -> None: ...
