from cf import cf_objects_pb2 as _cf_objects_pb2
from queryservice_client.protobuf.rdbms import mde_pb2 as _mde_pb2
from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CustomFieldExtractionRequest(_message.Message):
    __slots__ = ("configuration", "filter", "is_include_filter")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    IS_INCLUDE_FILTER_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    filter: _containers.RepeatedCompositeFieldContainer[_mde_pb2.FilterExtractionResponse]
    is_include_filter: bool
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., filter: _Optional[_Iterable[_Union[_mde_pb2.FilterExtractionResponse, _Mapping]]] = ..., is_include_filter: bool = ...) -> None: ...

class CustomFieldExtractionResponse(_message.Message):
    __slots__ = ("field", "link")
    FIELD_FIELD_NUMBER: _ClassVar[int]
    LINK_FIELD_NUMBER: _ClassVar[int]
    field: _cf_objects_pb2.CustomField
    link: _cf_objects_pb2.CustomFieldLink
    def __init__(self, field: _Optional[_Union[_cf_objects_pb2.CustomField, _Mapping]] = ..., link: _Optional[_Union[_cf_objects_pb2.CustomFieldLink, _Mapping]] = ...) -> None: ...
