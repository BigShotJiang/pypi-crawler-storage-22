from cf import cf_objects_pb2 as _cf_objects_pb2
from queryservice_client.protobuf.common import auth_pb2 as _auth_pb2
from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import error_pb2 as _error_pb2
from queryservice_client.protobuf.rdbms import mde_objects_pb2 as _mde_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CustomFieldSyncResponse(_message.Message):
    __slots__ = ("schemaId", "tableId", "columnId", "error")
    SCHEMAID_FIELD_NUMBER: _ClassVar[int]
    TABLEID_FIELD_NUMBER: _ClassVar[int]
    COLUMNID_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    schemaId: _mde_objects_pb2.SchemaId
    tableId: _mde_objects_pb2.TableId
    columnId: _mde_objects_pb2.ColumnId
    error: _error_pb2.Error
    def __init__(self, schemaId: _Optional[_Union[_mde_objects_pb2.SchemaId, _Mapping]] = ..., tableId: _Optional[_Union[_mde_objects_pb2.TableId, _Mapping]] = ..., columnId: _Optional[_Union[_mde_objects_pb2.ColumnId, _Mapping]] = ..., error: _Optional[_Union[_error_pb2.Error, _Mapping]] = ...) -> None: ...

class CustomFieldSyncRequest(_message.Message):
    __slots__ = ("configuration", "auth", "customFieldValueUpdates")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    CUSTOMFIELDVALUEUPDATES_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    auth: _auth_pb2.Auth
    customFieldValueUpdates: _containers.RepeatedCompositeFieldContainer[_cf_objects_pb2.CustomFieldValueUpdate]
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., auth: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ..., customFieldValueUpdates: _Optional[_Iterable[_Union[_cf_objects_pb2.CustomFieldValueUpdate, _Mapping]]] = ...) -> None: ...
