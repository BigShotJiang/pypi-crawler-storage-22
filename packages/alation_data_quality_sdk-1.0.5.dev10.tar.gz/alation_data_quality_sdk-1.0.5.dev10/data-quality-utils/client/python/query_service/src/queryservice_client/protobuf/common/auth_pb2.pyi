from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Auth(_message.Message):
    __slots__ = ("none", "simple", "oauth", "oauthRefresh", "awsBasic", "awsSession", "azureBasic", "refreshToken")
    NONE_FIELD_NUMBER: _ClassVar[int]
    SIMPLE_FIELD_NUMBER: _ClassVar[int]
    OAUTH_FIELD_NUMBER: _ClassVar[int]
    OAUTHREFRESH_FIELD_NUMBER: _ClassVar[int]
    AWSBASIC_FIELD_NUMBER: _ClassVar[int]
    AWSSESSION_FIELD_NUMBER: _ClassVar[int]
    AZUREBASIC_FIELD_NUMBER: _ClassVar[int]
    REFRESHTOKEN_FIELD_NUMBER: _ClassVar[int]
    none: _empty_pb2.Empty
    simple: Simple
    oauth: OAuth
    oauthRefresh: OAuthRefresh
    awsBasic: AwsBasic
    awsSession: AwsSession
    azureBasic: AzureBasic
    refreshToken: CAGRequest
    def __init__(self, none: _Optional[_Union[_empty_pb2.Empty, _Mapping]] = ..., simple: _Optional[_Union[Simple, _Mapping]] = ..., oauth: _Optional[_Union[OAuth, _Mapping]] = ..., oauthRefresh: _Optional[_Union[OAuthRefresh, _Mapping]] = ..., awsBasic: _Optional[_Union[AwsBasic, _Mapping]] = ..., awsSession: _Optional[_Union[AwsSession, _Mapping]] = ..., azureBasic: _Optional[_Union[AzureBasic, _Mapping]] = ..., refreshToken: _Optional[_Union[CAGRequest, _Mapping]] = ...) -> None: ...

class Simple(_message.Message):
    __slots__ = ("username", "password")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    username: str
    password: str
    def __init__(self, username: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class OAuth(_message.Message):
    __slots__ = ("accessToken", "expiresIn", "expiry", "uri")
    ACCESSTOKEN_FIELD_NUMBER: _ClassVar[int]
    EXPIRESIN_FIELD_NUMBER: _ClassVar[int]
    EXPIRY_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    accessToken: str
    expiresIn: int
    expiry: int
    uri: str
    def __init__(self, accessToken: _Optional[str] = ..., expiresIn: _Optional[int] = ..., expiry: _Optional[int] = ..., uri: _Optional[str] = ...) -> None: ...

class OAuthRefresh(_message.Message):
    __slots__ = ("refreshToken", "clientId", "clientSecret")
    REFRESHTOKEN_FIELD_NUMBER: _ClassVar[int]
    CLIENTID_FIELD_NUMBER: _ClassVar[int]
    CLIENTSECRET_FIELD_NUMBER: _ClassVar[int]
    refreshToken: str
    clientId: str
    clientSecret: str
    def __init__(self, refreshToken: _Optional[str] = ..., clientId: _Optional[str] = ..., clientSecret: _Optional[str] = ...) -> None: ...

class AwsBasic(_message.Message):
    __slots__ = ("accessKey", "secretKey")
    ACCESSKEY_FIELD_NUMBER: _ClassVar[int]
    SECRETKEY_FIELD_NUMBER: _ClassVar[int]
    accessKey: str
    secretKey: str
    def __init__(self, accessKey: _Optional[str] = ..., secretKey: _Optional[str] = ...) -> None: ...

class AwsSession(_message.Message):
    __slots__ = ("accessKey", "secretKey", "sessionToken", "dbUserName", "expiry")
    ACCESSKEY_FIELD_NUMBER: _ClassVar[int]
    SECRETKEY_FIELD_NUMBER: _ClassVar[int]
    SESSIONTOKEN_FIELD_NUMBER: _ClassVar[int]
    DBUSERNAME_FIELD_NUMBER: _ClassVar[int]
    EXPIRY_FIELD_NUMBER: _ClassVar[int]
    accessKey: str
    secretKey: str
    sessionToken: str
    dbUserName: str
    expiry: int
    def __init__(self, accessKey: _Optional[str] = ..., secretKey: _Optional[str] = ..., sessionToken: _Optional[str] = ..., dbUserName: _Optional[str] = ..., expiry: _Optional[int] = ...) -> None: ...

class AzureBasic(_message.Message):
    __slots__ = ("isSAS", "accessKey")
    ISSAS_FIELD_NUMBER: _ClassVar[int]
    ACCESSKEY_FIELD_NUMBER: _ClassVar[int]
    isSAS: bool
    accessKey: str
    def __init__(self, isSAS: bool = ..., accessKey: _Optional[str] = ...) -> None: ...

class CAGRequest(_message.Message):
    __slots__ = ("hostname", "token", "eagerInitialize")
    HOSTNAME_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    EAGERINITIALIZE_FIELD_NUMBER: _ClassVar[int]
    hostname: str
    token: str
    eagerInitialize: bool
    def __init__(self, hostname: _Optional[str] = ..., token: _Optional[str] = ..., eagerInitialize: bool = ...) -> None: ...
