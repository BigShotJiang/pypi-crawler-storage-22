from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class CAGRequest(_message.Message):
    __slots__ = ("token",)
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    token: str
    def __init__(self, token: _Optional[str] = ...) -> None: ...

class CAGResponse(_message.Message):
    __slots__ = ("success", "code", "message", "protoName", "protoObj")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    PROTONAME_FIELD_NUMBER: _ClassVar[int]
    PROTOOBJ_FIELD_NUMBER: _ClassVar[int]
    success: bool
    code: str
    message: str
    protoName: str
    protoObj: bytes
    def __init__(self, success: bool = ..., code: _Optional[str] = ..., message: _Optional[str] = ..., protoName: _Optional[str] = ..., protoObj: _Optional[bytes] = ...) -> None: ...
