from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CheckStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SUCCESS: _ClassVar[CheckStatus]
    FAILURE: _ClassVar[CheckStatus]
    SKIPPED: _ClassVar[CheckStatus]
    WARNING: _ClassVar[CheckStatus]
SUCCESS: CheckStatus
FAILURE: CheckStatus
SKIPPED: CheckStatus
WARNING: CheckStatus

class CheckRequest(_message.Message):
    __slots__ = ("configuration", "check_name", "check_ids")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    CHECK_NAME_FIELD_NUMBER: _ClassVar[int]
    CHECK_IDS_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    check_name: str
    check_ids: _containers.RepeatedCompositeFieldContainer[CheckID]
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., check_name: _Optional[str] = ..., check_ids: _Optional[_Iterable[_Union[CheckID, _Mapping]]] = ...) -> None: ...

class CheckID(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class CheckResult(_message.Message):
    __slots__ = ("id", "result", "error", "message")
    ID_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    id: str
    result: CheckStatus
    error: CheckError
    message: CheckMessage
    def __init__(self, id: _Optional[str] = ..., result: _Optional[_Union[CheckStatus, str]] = ..., error: _Optional[_Union[CheckError, _Mapping]] = ..., message: _Optional[_Union[CheckMessage, _Mapping]] = ...) -> None: ...

class CheckError(_message.Message):
    __slots__ = ("error_code", "error_text", "action")
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ERROR_TEXT_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    error_code: str
    error_text: str
    action: str
    def __init__(self, error_code: _Optional[str] = ..., error_text: _Optional[str] = ..., action: _Optional[str] = ...) -> None: ...

class CheckMessage(_message.Message):
    __slots__ = ("text", "action")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    text: str
    action: str
    def __init__(self, text: _Optional[str] = ..., action: _Optional[str] = ...) -> None: ...
