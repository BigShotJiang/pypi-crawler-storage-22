from queryservice_client.protobuf.common import auth_pb2 as _auth_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ArrayOfTextParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, key: _Optional[str] = ..., value: _Optional[_Iterable[str]] = ...) -> None: ...

class BooleanParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: bool
    def __init__(self, key: _Optional[str] = ..., value: bool = ...) -> None: ...

class DictionaryParam(_message.Message):
    __slots__ = ("key", "value")
    class ValueEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: _containers.ScalarMap[str, str]
    def __init__(self, key: _Optional[str] = ..., value: _Optional[_Mapping[str, str]] = ...) -> None: ...

class EncryptedBinaryParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: bytes
    def __init__(self, key: _Optional[str] = ..., value: _Optional[bytes] = ...) -> None: ...

class EncryptedTextParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class FloatParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: float
    def __init__(self, key: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...

class IntegerParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: int
    def __init__(self, key: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...

class RadioParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class SelectParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class TextParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class TextAreaParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class AuthParam(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: _auth_pb2.Auth
    def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ...) -> None: ...

class ProtobufParameter(_message.Message):
    __slots__ = ("arrayOfText", "boolean", "dictionary", "encryptedBinary", "encryptedText", "float", "integer", "text", "textArea", "radio", "select", "auth")
    ARRAYOFTEXT_FIELD_NUMBER: _ClassVar[int]
    BOOLEAN_FIELD_NUMBER: _ClassVar[int]
    DICTIONARY_FIELD_NUMBER: _ClassVar[int]
    ENCRYPTEDBINARY_FIELD_NUMBER: _ClassVar[int]
    ENCRYPTEDTEXT_FIELD_NUMBER: _ClassVar[int]
    FLOAT_FIELD_NUMBER: _ClassVar[int]
    INTEGER_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    TEXTAREA_FIELD_NUMBER: _ClassVar[int]
    RADIO_FIELD_NUMBER: _ClassVar[int]
    SELECT_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    arrayOfText: ArrayOfTextParam
    boolean: BooleanParam
    dictionary: DictionaryParam
    encryptedBinary: EncryptedBinaryParam
    encryptedText: EncryptedTextParam
    float: FloatParam
    integer: IntegerParam
    text: TextParam
    textArea: TextAreaParam
    radio: RadioParam
    select: SelectParam
    auth: AuthParam
    def __init__(self, arrayOfText: _Optional[_Union[ArrayOfTextParam, _Mapping]] = ..., boolean: _Optional[_Union[BooleanParam, _Mapping]] = ..., dictionary: _Optional[_Union[DictionaryParam, _Mapping]] = ..., encryptedBinary: _Optional[_Union[EncryptedBinaryParam, _Mapping]] = ..., encryptedText: _Optional[_Union[EncryptedTextParam, _Mapping]] = ..., float: _Optional[_Union[FloatParam, _Mapping]] = ..., integer: _Optional[_Union[IntegerParam, _Mapping]] = ..., text: _Optional[_Union[TextParam, _Mapping]] = ..., textArea: _Optional[_Union[TextAreaParam, _Mapping]] = ..., radio: _Optional[_Union[RadioParam, _Mapping]] = ..., select: _Optional[_Union[SelectParam, _Mapping]] = ..., auth: _Optional[_Union[AuthParam, _Mapping]] = ...) -> None: ...

class ProtobufConfiguration(_message.Message):
    __slots__ = ("parameters", "interpolatedParameters")
    class ParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: ProtobufParameter
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[ProtobufParameter, _Mapping]] = ...) -> None: ...
    class InterpolatedParametersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _auth_pb2.CAGRequest
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_auth_pb2.CAGRequest, _Mapping]] = ...) -> None: ...
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    INTERPOLATEDPARAMETERS_FIELD_NUMBER: _ClassVar[int]
    parameters: _containers.MessageMap[str, ProtobufParameter]
    interpolatedParameters: _containers.MessageMap[str, _auth_pb2.CAGRequest]
    def __init__(self, parameters: _Optional[_Mapping[str, ProtobufParameter]] = ..., interpolatedParameters: _Optional[_Mapping[str, _auth_pb2.CAGRequest]] = ...) -> None: ...
