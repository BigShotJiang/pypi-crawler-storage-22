from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SourceType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    None: _ClassVar[SourceType]
    RDBMS: _ClassVar[SourceType]
    BI: _ClassVar[SourceType]
    FS: _ClassVar[SourceType]
None: SourceType
RDBMS: SourceType
BI: SourceType
FS: SourceType

class ConnectionInfo(_message.Message):
    __slots__ = ("uri", "host", "port")
    URI_FIELD_NUMBER: _ClassVar[int]
    HOST_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    uri: str
    host: str
    port: int
    def __init__(self, uri: _Optional[str] = ..., host: _Optional[str] = ..., port: _Optional[int] = ...) -> None: ...

class Self(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DataSource(_message.Message):
    __slots__ = ("type", "self", "id", "connection")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    SELF_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_FIELD_NUMBER: _ClassVar[int]
    type: SourceType
    self: Self
    id: int
    connection: ConnectionInfo
    def __init__(self, type: _Optional[_Union[SourceType, str]] = ..., self: _Optional[_Union[Self, _Mapping]] = ..., id: _Optional[int] = ..., connection: _Optional[_Union[ConnectionInfo, _Mapping]] = ...) -> None: ...
