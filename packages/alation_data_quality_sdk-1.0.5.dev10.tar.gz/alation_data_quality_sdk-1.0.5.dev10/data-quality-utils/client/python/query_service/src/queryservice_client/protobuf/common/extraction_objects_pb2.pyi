from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Bookmark(_message.Message):
    __slots__ = ("checkpoints",)
    class CheckpointsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    CHECKPOINTS_FIELD_NUMBER: _ClassVar[int]
    checkpoints: _containers.ScalarMap[str, str]
    def __init__(self, checkpoints: _Optional[_Mapping[str, str]] = ...) -> None: ...

class ExtractionProgressDetailGroup(_message.Message):
    __slots__ = ("message", "key", "details")
    class DetailsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    message: str
    key: str
    details: _containers.ScalarMap[str, str]
    def __init__(self, message: _Optional[str] = ..., key: _Optional[str] = ..., details: _Optional[_Mapping[str, str]] = ...) -> None: ...

class ExtractionProgressDetail(_message.Message):
    __slots__ = ("message", "key")
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    message: str
    key: str
    def __init__(self, message: _Optional[str] = ..., key: _Optional[str] = ...) -> None: ...

class ExtractionProgress(_message.Message):
    __slots__ = ("message", "extraction_message", "progress_details")
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    EXTRACTION_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_DETAILS_FIELD_NUMBER: _ClassVar[int]
    message: str
    extraction_message: ExtractionProgressDetail
    progress_details: ExtractionProgressDetailGroup
    def __init__(self, message: _Optional[str] = ..., extraction_message: _Optional[_Union[ExtractionProgressDetail, _Mapping]] = ..., progress_details: _Optional[_Union[ExtractionProgressDetailGroup, _Mapping]] = ...) -> None: ...

class KeyedBookmark(_message.Message):
    __slots__ = ("key", "value")
    class ValueEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: _containers.ScalarMap[str, str]
    def __init__(self, key: _Optional[str] = ..., value: _Optional[_Mapping[str, str]] = ...) -> None: ...
