from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ErrorSeverity(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    P0: _ClassVar[ErrorSeverity]
    P1: _ClassVar[ErrorSeverity]
    P2: _ClassVar[ErrorSeverity]
P0: ErrorSeverity
P1: ErrorSeverity
P2: ErrorSeverity

class ContextEntry(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class Error(_message.Message):
    __slots__ = ("message", "name", "category", "action", "context", "severity")
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    message: str
    name: str
    category: str
    action: str
    context: _containers.RepeatedCompositeFieldContainer[ContextEntry]
    severity: ErrorSeverity
    def __init__(self, message: _Optional[str] = ..., name: _Optional[str] = ..., category: _Optional[str] = ..., action: _Optional[str] = ..., context: _Optional[_Iterable[_Union[ContextEntry, _Mapping]]] = ..., severity: _Optional[_Union[ErrorSeverity, str]] = ...) -> None: ...
