from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from dl import dl_objects_pb2 as _dl_objects_pb2
from queryservice_client.protobuf.common import job_error_pb2 as _job_error_pb2
from queryservice_client.protobuf.common import extraction_objects_pb2 as _extraction_objects_pb2
from asset import filter_extraction_pb2 as _filter_extraction_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LineageExtractionRequest(_message.Message):
    __slots__ = ("configuration", "hasAllLineage", "projectDetail", "bookmark", "filter", "isInclusionFilter")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    HASALLLINEAGE_FIELD_NUMBER: _ClassVar[int]
    PROJECTDETAIL_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    ISINCLUSIONFILTER_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    hasAllLineage: bool
    projectDetail: _containers.RepeatedCompositeFieldContainer[ProjectDetail]
    bookmark: _containers.RepeatedCompositeFieldContainer[_extraction_objects_pb2.KeyedBookmark]
    filter: _containers.RepeatedCompositeFieldContainer[_filter_extraction_pb2.FilterExtractionResponse]
    isInclusionFilter: bool
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., hasAllLineage: bool = ..., projectDetail: _Optional[_Iterable[_Union[ProjectDetail, _Mapping]]] = ..., bookmark: _Optional[_Iterable[_Union[_extraction_objects_pb2.KeyedBookmark, _Mapping]]] = ..., filter: _Optional[_Iterable[_Union[_filter_extraction_pb2.FilterExtractionResponse, _Mapping]]] = ..., isInclusionFilter: bool = ...) -> None: ...

class ProjectDetail(_message.Message):
    __slots__ = ("name", "externalId", "databaseType", "additionalInfo", "datasourceConfiguration", "primaryConnectorInfo")
    class AdditionalInfoEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    class DatasourceConfigurationEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    NAME_FIELD_NUMBER: _ClassVar[int]
    EXTERNALID_FIELD_NUMBER: _ClassVar[int]
    DATABASETYPE_FIELD_NUMBER: _ClassVar[int]
    ADDITIONALINFO_FIELD_NUMBER: _ClassVar[int]
    DATASOURCECONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    PRIMARYCONNECTORINFO_FIELD_NUMBER: _ClassVar[int]
    name: str
    externalId: str
    databaseType: str
    additionalInfo: _containers.ScalarMap[str, str]
    datasourceConfiguration: _containers.ScalarMap[str, str]
    primaryConnectorInfo: PrimaryConnectorInfo
    def __init__(self, name: _Optional[str] = ..., externalId: _Optional[str] = ..., databaseType: _Optional[str] = ..., additionalInfo: _Optional[_Mapping[str, str]] = ..., datasourceConfiguration: _Optional[_Mapping[str, str]] = ..., primaryConnectorInfo: _Optional[_Union[PrimaryConnectorInfo, _Mapping]] = ...) -> None: ...

class PrimaryConnectorInfo(_message.Message):
    __slots__ = ("host", "port")
    HOST_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    host: str
    port: int
    def __init__(self, host: _Optional[str] = ..., port: _Optional[int] = ...) -> None: ...

class LineageExtractionResponse(_message.Message):
    __slots__ = ("lineagePath", "bookmark", "error", "extractionProgress")
    LINEAGEPATH_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    EXTRACTIONPROGRESS_FIELD_NUMBER: _ClassVar[int]
    lineagePath: _dl_objects_pb2.LineagePath
    bookmark: _extraction_objects_pb2.KeyedBookmark
    error: _job_error_pb2.Error
    extractionProgress: _extraction_objects_pb2.ExtractionProgress
    def __init__(self, lineagePath: _Optional[_Union[_dl_objects_pb2.LineagePath, _Mapping]] = ..., bookmark: _Optional[_Union[_extraction_objects_pb2.KeyedBookmark, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ..., extractionProgress: _Optional[_Union[_extraction_objects_pb2.ExtractionProgress, _Mapping]] = ...) -> None: ...
