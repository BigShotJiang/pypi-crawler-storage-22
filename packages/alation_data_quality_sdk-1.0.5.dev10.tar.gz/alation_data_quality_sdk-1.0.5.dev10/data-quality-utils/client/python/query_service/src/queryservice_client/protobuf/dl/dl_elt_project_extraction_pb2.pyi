from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import extraction_objects_pb2 as _extraction_objects_pb2
from queryservice_client.protobuf.common import job_error_pb2 as _job_error_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ProjectExtractionRequest(_message.Message):
    __slots__ = ("configuration",)
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ...) -> None: ...

class ProjectExtractionResponse(_message.Message):
    __slots__ = ("Project", "extractionProgress", "error")
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    EXTRACTIONPROGRESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    Project: Project
    extractionProgress: _extraction_objects_pb2.ExtractionProgress
    error: _job_error_pb2.Error
    def __init__(self, Project: _Optional[_Union[Project, _Mapping]] = ..., extractionProgress: _Optional[_Union[_extraction_objects_pb2.ExtractionProgress, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ...) -> None: ...

class Project(_message.Message):
    __slots__ = ("externalId", "name", "databaseType", "lineageInfo", "hostInfo", "additionalInfo")
    class AdditionalInfoEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    EXTERNALID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATABASETYPE_FIELD_NUMBER: _ClassVar[int]
    LINEAGEINFO_FIELD_NUMBER: _ClassVar[int]
    HOSTINFO_FIELD_NUMBER: _ClassVar[int]
    ADDITIONALINFO_FIELD_NUMBER: _ClassVar[int]
    externalId: str
    name: str
    databaseType: str
    lineageInfo: LineageInfo
    hostInfo: HostInfo
    additionalInfo: _containers.ScalarMap[str, str]
    def __init__(self, externalId: _Optional[str] = ..., name: _Optional[str] = ..., databaseType: _Optional[str] = ..., lineageInfo: _Optional[_Union[LineageInfo, _Mapping]] = ..., hostInfo: _Optional[_Union[HostInfo, _Mapping]] = ..., additionalInfo: _Optional[_Mapping[str, str]] = ...) -> None: ...

class LineageInfo(_message.Message):
    __slots__ = ("primaryConnectorName", "hasAllLineage", "hasLineage")
    PRIMARYCONNECTORNAME_FIELD_NUMBER: _ClassVar[int]
    HASALLLINEAGE_FIELD_NUMBER: _ClassVar[int]
    HASLINEAGE_FIELD_NUMBER: _ClassVar[int]
    primaryConnectorName: str
    hasAllLineage: bool
    hasLineage: bool
    def __init__(self, primaryConnectorName: _Optional[str] = ..., hasAllLineage: bool = ..., hasLineage: bool = ...) -> None: ...

class HostInfo(_message.Message):
    __slots__ = ("host", "port")
    HOST_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    host: str
    port: int
    def __init__(self, host: _Optional[str] = ..., port: _Optional[int] = ...) -> None: ...
