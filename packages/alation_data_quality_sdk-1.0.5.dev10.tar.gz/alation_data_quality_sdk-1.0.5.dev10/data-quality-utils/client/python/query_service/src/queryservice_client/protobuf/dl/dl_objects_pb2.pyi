from queryservice_client.protobuf.rdbms import mde_objects_pb2 as _mde_objects_pb2
from queryservice_client.protobuf.common import datasource_pb2 as _datasource_pb2
from asset import filter_extraction_objects_pb2 as _filter_extraction_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ModelType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TABLE: _ClassVar[ModelType]
    VIEW: _ClassVar[ModelType]
    INCREMENTAL: _ClassVar[ModelType]
    EPHEMERAL: _ClassVar[ModelType]
TABLE: ModelType
VIEW: ModelType
INCREMENTAL: ModelType
EPHEMERAL: ModelType

class Dataflow(_message.Message):
    __slots__ = ("content", "facets")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    FACETS_FIELD_NUMBER: _ClassVar[int]
    content: str
    facets: DataflowFacets
    def __init__(self, content: _Optional[str] = ..., facets: _Optional[_Union[DataflowFacets, _Mapping]] = ...) -> None: ...

class NativeObject(_message.Message):
    __slots__ = ("data_source", "schema_id", "table_id", "column_id", "path_id", "facets")
    DATA_SOURCE_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_ID_FIELD_NUMBER: _ClassVar[int]
    TABLE_ID_FIELD_NUMBER: _ClassVar[int]
    COLUMN_ID_FIELD_NUMBER: _ClassVar[int]
    PATH_ID_FIELD_NUMBER: _ClassVar[int]
    FACETS_FIELD_NUMBER: _ClassVar[int]
    data_source: _datasource_pb2.DataSource
    schema_id: _mde_objects_pb2.SchemaId
    table_id: _mde_objects_pb2.TableId
    column_id: _mde_objects_pb2.ColumnId
    path_id: PathId
    facets: DatasourceFacets
    def __init__(self, data_source: _Optional[_Union[_datasource_pb2.DataSource, _Mapping]] = ..., schema_id: _Optional[_Union[_mde_objects_pb2.SchemaId, _Mapping]] = ..., table_id: _Optional[_Union[_mde_objects_pb2.TableId, _Mapping]] = ..., column_id: _Optional[_Union[_mde_objects_pb2.ColumnId, _Mapping]] = ..., path_id: _Optional[_Union[PathId, _Mapping]] = ..., facets: _Optional[_Union[DatasourceFacets, _Mapping]] = ...) -> None: ...

class LineageObject(_message.Message):
    __slots__ = ("native_object",)
    NATIVE_OBJECT_FIELD_NUMBER: _ClassVar[int]
    native_object: NativeObject
    def __init__(self, native_object: _Optional[_Union[NativeObject, _Mapping]] = ...) -> None: ...

class LineagePath(_message.Message):
    __slots__ = ("sources", "dataflow", "target", "fullyQualifiedPath")
    SOURCES_FIELD_NUMBER: _ClassVar[int]
    DATAFLOW_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    FULLYQUALIFIEDPATH_FIELD_NUMBER: _ClassVar[int]
    sources: _containers.RepeatedCompositeFieldContainer[LineageObject]
    dataflow: Dataflow
    target: LineageObject
    fullyQualifiedPath: PathId
    def __init__(self, sources: _Optional[_Iterable[_Union[LineageObject, _Mapping]]] = ..., dataflow: _Optional[_Union[Dataflow, _Mapping]] = ..., target: _Optional[_Union[LineageObject, _Mapping]] = ..., fullyQualifiedPath: _Optional[_Union[PathId, _Mapping]] = ...) -> None: ...

class ModelTypeFacet(_message.Message):
    __slots__ = ("modelType",)
    MODELTYPE_FIELD_NUMBER: _ClassVar[int]
    modelType: ModelType
    def __init__(self, modelType: _Optional[_Union[ModelType, str]] = ...) -> None: ...

class DatasourceFacets(_message.Message):
    __slots__ = ("modelTypeFacet", "modelFacet")
    MODELTYPEFACET_FIELD_NUMBER: _ClassVar[int]
    MODELFACET_FIELD_NUMBER: _ClassVar[int]
    modelTypeFacet: ModelTypeFacet
    modelFacet: ModelFacet
    def __init__(self, modelTypeFacet: _Optional[_Union[ModelTypeFacet, _Mapping]] = ..., modelFacet: _Optional[_Union[ModelFacet, _Mapping]] = ...) -> None: ...

class PathId(_message.Message):
    __slots__ = ("external_id", "path")
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    external_id: str
    path: _filter_extraction_objects_pb2.Path
    def __init__(self, external_id: _Optional[str] = ..., path: _Optional[_Union[_filter_extraction_objects_pb2.Path, _Mapping]] = ...) -> None: ...

class ModelFacet(_message.Message):
    __slots__ = ("externalId", "columnNames")
    EXTERNALID_FIELD_NUMBER: _ClassVar[int]
    COLUMNNAMES_FIELD_NUMBER: _ClassVar[int]
    externalId: str
    columnNames: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, externalId: _Optional[str] = ..., columnNames: _Optional[_Iterable[str]] = ...) -> None: ...

class CodeFacet(_message.Message):
    __slots__ = ("code",)
    CODE_FIELD_NUMBER: _ClassVar[int]
    code: str
    def __init__(self, code: _Optional[str] = ...) -> None: ...

class ExternalURLFacet(_message.Message):
    __slots__ = ("externalUrl",)
    EXTERNALURL_FIELD_NUMBER: _ClassVar[int]
    externalUrl: str
    def __init__(self, externalUrl: _Optional[str] = ...) -> None: ...

class DataFlowGroupFacet(_message.Message):
    __slots__ = ("groupName",)
    GROUPNAME_FIELD_NUMBER: _ClassVar[int]
    groupName: str
    def __init__(self, groupName: _Optional[str] = ...) -> None: ...

class DataflowFacets(_message.Message):
    __slots__ = ("codeFacet", "dataflowGroupFacet", "externalURLFacet", "dbType")
    CODEFACET_FIELD_NUMBER: _ClassVar[int]
    DATAFLOWGROUPFACET_FIELD_NUMBER: _ClassVar[int]
    EXTERNALURLFACET_FIELD_NUMBER: _ClassVar[int]
    DBTYPE_FIELD_NUMBER: _ClassVar[int]
    codeFacet: CodeFacet
    dataflowGroupFacet: DataFlowGroupFacet
    externalURLFacet: ExternalURLFacet
    dbType: str
    def __init__(self, codeFacet: _Optional[_Union[CodeFacet, _Mapping]] = ..., dataflowGroupFacet: _Optional[_Union[DataFlowGroupFacet, _Mapping]] = ..., externalURLFacet: _Optional[_Union[ExternalURLFacet, _Mapping]] = ..., dbType: _Optional[str] = ...) -> None: ...
