from dl import dl_objects_pb2 as _dl_objects_pb2
from queryservice_client.protobuf.rdbms import mde_pb2 as _mde_pb2
from queryservice_client.protobuf.rdbms import mde_objects_pb2 as _mde_objects_pb2
from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import extraction_objects_pb2 as _extraction_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LineageExtractionRequest(_message.Message):
    __slots__ = ("configuration", "schemaIds", "is_include_filter", "bookmark")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    SCHEMAIDS_FIELD_NUMBER: _ClassVar[int]
    IS_INCLUDE_FILTER_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    schemaIds: _containers.RepeatedCompositeFieldContainer[_mde_objects_pb2.SchemaId]
    is_include_filter: bool
    bookmark: _extraction_objects_pb2.Bookmark
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., schemaIds: _Optional[_Iterable[_Union[_mde_objects_pb2.SchemaId, _Mapping]]] = ..., is_include_filter: bool = ..., bookmark: _Optional[_Union[_extraction_objects_pb2.Bookmark, _Mapping]] = ...) -> None: ...

class LineageExtractionResponse(_message.Message):
    __slots__ = ("lineagePath", "bookmark")
    LINEAGEPATH_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    lineagePath: _dl_objects_pb2.LineagePath
    bookmark: _extraction_objects_pb2.Bookmark
    def __init__(self, lineagePath: _Optional[_Union[_dl_objects_pb2.LineagePath, _Mapping]] = ..., bookmark: _Optional[_Union[_extraction_objects_pb2.Bookmark, _Mapping]] = ...) -> None: ...
