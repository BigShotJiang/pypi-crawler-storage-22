from google.protobuf import empty_pb2 as _empty_pb2
from queryservice_client.protobuf.common import verify_pb2 as _verify_pb2
from fs import mde_pb2 as _mde_pb2
from fs import fs_profiling_pb2 as _fs_profiling_pb2
from fs import volume_check_pb2 as _volume_check_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
