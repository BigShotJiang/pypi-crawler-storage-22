from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import auth_pb2 as _auth_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FileProfilingRequest(_message.Message):
    __slots__ = ("configuration", "profileRequests", "auth")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    PROFILEREQUESTS_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    profileRequests: _containers.RepeatedCompositeFieldContainer[ProfileRequest]
    auth: _auth_pb2.Auth
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., profileRequests: _Optional[_Iterable[_Union[ProfileRequest, _Mapping]]] = ..., auth: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ...) -> None: ...

class ProfileRequest(_message.Message):
    __slots__ = ("id", "path", "columns", "timeout", "populationSize", "sampleSize", "sensitiveColumns", "isDirectory")
    ID_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    POPULATIONSIZE_FIELD_NUMBER: _ClassVar[int]
    SAMPLESIZE_FIELD_NUMBER: _ClassVar[int]
    SENSITIVECOLUMNS_FIELD_NUMBER: _ClassVar[int]
    ISDIRECTORY_FIELD_NUMBER: _ClassVar[int]
    id: str
    path: _containers.RepeatedScalarFieldContainer[str]
    columns: _containers.RepeatedCompositeFieldContainer[Column]
    timeout: int
    populationSize: int
    sampleSize: int
    sensitiveColumns: _containers.RepeatedCompositeFieldContainer[Column]
    isDirectory: bool
    def __init__(self, id: _Optional[str] = ..., path: _Optional[_Iterable[str]] = ..., columns: _Optional[_Iterable[_Union[Column, _Mapping]]] = ..., timeout: _Optional[int] = ..., populationSize: _Optional[int] = ..., sampleSize: _Optional[int] = ..., sensitiveColumns: _Optional[_Iterable[_Union[Column, _Mapping]]] = ..., isDirectory: bool = ...) -> None: ...

class Column(_message.Message):
    __slots__ = ("id", "name")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    id: int
    name: str
    def __init__(self, id: _Optional[int] = ..., name: _Optional[str] = ...) -> None: ...

class FileProfilingResponse(_message.Message):
    __slots__ = ("id", "rowSamples", "numberOfRowsSampled", "secondsTaken", "hasMore")
    ID_FIELD_NUMBER: _ClassVar[int]
    ROWSAMPLES_FIELD_NUMBER: _ClassVar[int]
    NUMBEROFROWSSAMPLED_FIELD_NUMBER: _ClassVar[int]
    SECONDSTAKEN_FIELD_NUMBER: _ClassVar[int]
    HASMORE_FIELD_NUMBER: _ClassVar[int]
    id: str
    rowSamples: _containers.RepeatedCompositeFieldContainer[Row]
    numberOfRowsSampled: int
    secondsTaken: int
    hasMore: bool
    def __init__(self, id: _Optional[str] = ..., rowSamples: _Optional[_Iterable[_Union[Row, _Mapping]]] = ..., numberOfRowsSampled: _Optional[int] = ..., secondsTaken: _Optional[int] = ..., hasMore: bool = ...) -> None: ...

class Row(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, values: _Optional[_Iterable[str]] = ...) -> None: ...
