from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Otype(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FILE: _ClassVar[Otype]
    BOOKMARK: _ClassVar[Otype]
    COLUMN: _ClassVar[Otype]
FILE: Otype
BOOKMARK: Otype
COLUMN: Otype

class Path(_message.Message):
    __slots__ = ("filePath",)
    FILEPATH_FIELD_NUMBER: _ClassVar[int]
    filePath: str
    def __init__(self, filePath: _Optional[str] = ...) -> None: ...

class ExtractionProgress(_message.Message):
    __slots__ = ("message", "completedOtype")
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    COMPLETEDOTYPE_FIELD_NUMBER: _ClassVar[int]
    message: str
    completedOtype: Otype
    def __init__(self, message: _Optional[str] = ..., completedOtype: _Optional[_Union[Otype, str]] = ...) -> None: ...

class Filter(_message.Message):
    __slots__ = ("path",)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: _containers.RepeatedCompositeFieldContainer[Path]
    def __init__(self, path: _Optional[_Iterable[_Union[Path, _Mapping]]] = ...) -> None: ...

class File(_message.Message):
    __slots__ = ("rootPath", "path", "type", "pathDelimiter", "isDirectory", "isDeleted", "owner", "sizeInBytes", "createTime", "lastModifiedTimestamp", "lastAccessedTimestamp", "group", "permission")
    ROOTPATH_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    PATHDELIMITER_FIELD_NUMBER: _ClassVar[int]
    ISDIRECTORY_FIELD_NUMBER: _ClassVar[int]
    ISDELETED_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    SIZEINBYTES_FIELD_NUMBER: _ClassVar[int]
    CREATETIME_FIELD_NUMBER: _ClassVar[int]
    LASTMODIFIEDTIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    LASTACCESSEDTIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    PERMISSION_FIELD_NUMBER: _ClassVar[int]
    rootPath: str
    path: _containers.RepeatedScalarFieldContainer[str]
    type: str
    pathDelimiter: str
    isDirectory: bool
    isDeleted: bool
    owner: str
    sizeInBytes: int
    createTime: _timestamp_pb2.Timestamp
    lastModifiedTimestamp: _timestamp_pb2.Timestamp
    lastAccessedTimestamp: _timestamp_pb2.Timestamp
    group: str
    permission: str
    def __init__(self, rootPath: _Optional[str] = ..., path: _Optional[_Iterable[str]] = ..., type: _Optional[str] = ..., pathDelimiter: _Optional[str] = ..., isDirectory: bool = ..., isDeleted: bool = ..., owner: _Optional[str] = ..., sizeInBytes: _Optional[int] = ..., createTime: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., lastModifiedTimestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., lastAccessedTimestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., group: _Optional[str] = ..., permission: _Optional[str] = ...) -> None: ...

class Bookmark(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: _struct_pb2.Struct
    def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class ColumnId(_message.Message):
    __slots__ = ("path", "name", "isDirectory")
    PATH_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ISDIRECTORY_FIELD_NUMBER: _ClassVar[int]
    path: _containers.RepeatedScalarFieldContainer[str]
    name: str
    isDirectory: bool
    def __init__(self, path: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., isDirectory: bool = ...) -> None: ...

class ColumnType(_message.Message):
    __slots__ = ("name", "remarks", "normalized")
    class NormalizedType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        OTHER: _ClassVar[ColumnType.NormalizedType]
        BOOL: _ClassVar[ColumnType.NormalizedType]
        DATE: _ClassVar[ColumnType.NormalizedType]
        INT: _ClassVar[ColumnType.NormalizedType]
        FLOAT: _ClassVar[ColumnType.NormalizedType]
        STRING: _ClassVar[ColumnType.NormalizedType]
        TIME: _ClassVar[ColumnType.NormalizedType]
        TIMESTAMP: _ClassVar[ColumnType.NormalizedType]
    OTHER: ColumnType.NormalizedType
    BOOL: ColumnType.NormalizedType
    DATE: ColumnType.NormalizedType
    INT: ColumnType.NormalizedType
    FLOAT: ColumnType.NormalizedType
    STRING: ColumnType.NormalizedType
    TIME: ColumnType.NormalizedType
    TIMESTAMP: ColumnType.NormalizedType
    NAME_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    NORMALIZED_FIELD_NUMBER: _ClassVar[int]
    name: str
    remarks: str
    normalized: ColumnType.NormalizedType
    def __init__(self, name: _Optional[str] = ..., remarks: _Optional[str] = ..., normalized: _Optional[_Union[ColumnType.NormalizedType, str]] = ...) -> None: ...

class Column(_message.Message):
    __slots__ = ("id", "type", "position", "isNullable")
    ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    ISNULLABLE_FIELD_NUMBER: _ClassVar[int]
    id: ColumnId
    type: ColumnType
    position: int
    isNullable: bool
    def __init__(self, id: _Optional[_Union[ColumnId, _Mapping]] = ..., type: _Optional[_Union[ColumnType, _Mapping]] = ..., position: _Optional[int] = ..., isNullable: bool = ...) -> None: ...
