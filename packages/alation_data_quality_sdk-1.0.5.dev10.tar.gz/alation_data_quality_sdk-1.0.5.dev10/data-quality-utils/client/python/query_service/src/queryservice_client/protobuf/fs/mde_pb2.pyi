from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from fs import mde_objects_pb2 as _mde_objects_pb2
from queryservice_client.protobuf.common import job_error_pb2 as _job_error_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FilterExtractionRequest(_message.Message):
    __slots__ = ("configuration",)
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ...) -> None: ...

class FilterExtractionResponse(_message.Message):
    __slots__ = ("path",)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: _mde_objects_pb2.Path
    def __init__(self, path: _Optional[_Union[_mde_objects_pb2.Path, _Mapping]] = ...) -> None: ...

class MetadataExtractionRequest(_message.Message):
    __slots__ = ("configuration", "bookmark", "filter", "is_include_filter")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    IS_INCLUDE_FILTER_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    bookmark: _containers.RepeatedCompositeFieldContainer[_mde_objects_pb2.Bookmark]
    filter: _mde_objects_pb2.Filter
    is_include_filter: bool
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., bookmark: _Optional[_Iterable[_Union[_mde_objects_pb2.Bookmark, _Mapping]]] = ..., filter: _Optional[_Union[_mde_objects_pb2.Filter, _Mapping]] = ..., is_include_filter: bool = ...) -> None: ...

class MetadataExtractionResponse(_message.Message):
    __slots__ = ("file", "bookmark", "extractionProgress", "error")
    FILE_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    EXTRACTIONPROGRESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    file: _mde_objects_pb2.File
    bookmark: _mde_objects_pb2.Bookmark
    extractionProgress: _mde_objects_pb2.ExtractionProgress
    error: _job_error_pb2.Error
    def __init__(self, file: _Optional[_Union[_mde_objects_pb2.File, _Mapping]] = ..., bookmark: _Optional[_Union[_mde_objects_pb2.Bookmark, _Mapping]] = ..., extractionProgress: _Optional[_Union[_mde_objects_pb2.ExtractionProgress, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ...) -> None: ...

class ColumnExtractionResponse(_message.Message):
    __slots__ = ("column", "bookmark", "extractionProgress", "error")
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    EXTRACTIONPROGRESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    column: _mde_objects_pb2.Column
    bookmark: _mde_objects_pb2.Bookmark
    extractionProgress: _mde_objects_pb2.ExtractionProgress
    error: _job_error_pb2.Error
    def __init__(self, column: _Optional[_Union[_mde_objects_pb2.Column, _Mapping]] = ..., bookmark: _Optional[_Union[_mde_objects_pb2.Bookmark, _Mapping]] = ..., extractionProgress: _Optional[_Union[_mde_objects_pb2.ExtractionProgress, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ...) -> None: ...
