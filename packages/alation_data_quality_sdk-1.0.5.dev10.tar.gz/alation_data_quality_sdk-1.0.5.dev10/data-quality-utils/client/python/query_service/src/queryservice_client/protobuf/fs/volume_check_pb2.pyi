from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import job_error_pb2 as _job_error_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class VolumeCheckRequest(_message.Message):
    __slots__ = ("configuration", "rootInfo", "is_include_filter")
    class RootInfoEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: RootInfo
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[RootInfo, _Mapping]] = ...) -> None: ...
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    ROOTINFO_FIELD_NUMBER: _ClassVar[int]
    IS_INCLUDE_FILTER_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    rootInfo: _containers.MessageMap[str, RootInfo]
    is_include_filter: bool
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., rootInfo: _Optional[_Mapping[str, RootInfo]] = ..., is_include_filter: bool = ...) -> None: ...

class RootInfo(_message.Message):
    __slots__ = ("tsSnapshot", "currentVolume")
    TSSNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    CURRENTVOLUME_FIELD_NUMBER: _ClassVar[int]
    tsSnapshot: int
    currentVolume: int
    def __init__(self, tsSnapshot: _Optional[int] = ..., currentVolume: _Optional[int] = ...) -> None: ...

class VolumeCheckResponse(_message.Message):
    __slots__ = ("item", "error")
    ITEM_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    item: ResponseItem
    error: _job_error_pb2.Error
    def __init__(self, item: _Optional[_Union[ResponseItem, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ...) -> None: ...

class ResponseItem(_message.Message):
    __slots__ = ("rootName", "volume", "tsSnapshot")
    ROOTNAME_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    TSSNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    rootName: str
    volume: Volume
    tsSnapshot: int
    def __init__(self, rootName: _Optional[str] = ..., volume: _Optional[_Union[Volume, _Mapping]] = ..., tsSnapshot: _Optional[int] = ...) -> None: ...

class Volume(_message.Message):
    __slots__ = ("fileCount", "directoryCount")
    FILECOUNT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORYCOUNT_FIELD_NUMBER: _ClassVar[int]
    fileCount: int
    directoryCount: int
    def __init__(self, fileCount: _Optional[int] = ..., directoryCount: _Optional[int] = ...) -> None: ...
