from queryservice_client.protobuf.rdbms import mde_objects_pb2 as _mde_objects_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PolicyId(_message.Message):
    __slots__ = ("parts",)
    PARTS_FIELD_NUMBER: _ClassVar[int]
    parts: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, parts: _Optional[_Iterable[str]] = ...) -> None: ...

class PolicyApiId(_message.Message):
    __slots__ = ("key",)
    class KeyEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    KEY_FIELD_NUMBER: _ClassVar[int]
    key: _containers.ScalarMap[str, str]
    def __init__(self, key: _Optional[_Mapping[str, str]] = ...) -> None: ...

class SQLDefinition(_message.Message):
    __slots__ = ("sql", "arguments")
    SQL_FIELD_NUMBER: _ClassVar[int]
    ARGUMENTS_FIELD_NUMBER: _ClassVar[int]
    sql: str
    arguments: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, sql: _Optional[str] = ..., arguments: _Optional[_Iterable[str]] = ...) -> None: ...

class Policy(_message.Message):
    __slots__ = ("id", "apiId", "name", "policyType", "owner", "tsCreated", "sqlDefinition")
    class PolicyType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        DATA_MASK: _ClassVar[Policy.PolicyType]
        ROW_ACCESS: _ClassVar[Policy.PolicyType]
    DATA_MASK: Policy.PolicyType
    ROW_ACCESS: Policy.PolicyType
    ID_FIELD_NUMBER: _ClassVar[int]
    APIID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    POLICYTYPE_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    TSCREATED_FIELD_NUMBER: _ClassVar[int]
    SQLDEFINITION_FIELD_NUMBER: _ClassVar[int]
    id: PolicyId
    apiId: PolicyApiId
    name: str
    policyType: Policy.PolicyType
    owner: str
    tsCreated: _timestamp_pb2.Timestamp
    sqlDefinition: SQLDefinition
    def __init__(self, id: _Optional[_Union[PolicyId, _Mapping]] = ..., apiId: _Optional[_Union[PolicyApiId, _Mapping]] = ..., name: _Optional[str] = ..., policyType: _Optional[_Union[Policy.PolicyType, str]] = ..., owner: _Optional[str] = ..., tsCreated: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., sqlDefinition: _Optional[_Union[SQLDefinition, _Mapping]] = ...) -> None: ...

class TableLink(_message.Message):
    __slots__ = ("pid", "tableId")
    PID_FIELD_NUMBER: _ClassVar[int]
    TABLEID_FIELD_NUMBER: _ClassVar[int]
    pid: PolicyId
    tableId: _mde_objects_pb2.TableId
    def __init__(self, pid: _Optional[_Union[PolicyId, _Mapping]] = ..., tableId: _Optional[_Union[_mde_objects_pb2.TableId, _Mapping]] = ...) -> None: ...

class ColumnLink(_message.Message):
    __slots__ = ("pid", "columnId")
    PID_FIELD_NUMBER: _ClassVar[int]
    COLUMNID_FIELD_NUMBER: _ClassVar[int]
    pid: PolicyId
    columnId: _mde_objects_pb2.ColumnId
    def __init__(self, pid: _Optional[_Union[PolicyId, _Mapping]] = ..., columnId: _Optional[_Union[_mde_objects_pb2.ColumnId, _Mapping]] = ...) -> None: ...

class PolicyObjectApiId(_message.Message):
    __slots__ = ("tableApiId", "columnApiId")
    TABLEAPIID_FIELD_NUMBER: _ClassVar[int]
    COLUMNAPIID_FIELD_NUMBER: _ClassVar[int]
    tableApiId: _mde_objects_pb2.TableApiId
    columnApiId: _mde_objects_pb2.ColumnApiId
    def __init__(self, tableApiId: _Optional[_Union[_mde_objects_pb2.TableApiId, _Mapping]] = ..., columnApiId: _Optional[_Union[_mde_objects_pb2.ColumnApiId, _Mapping]] = ...) -> None: ...

class PolicyArgument(_message.Message):
    __slots__ = ("argument", "columnId")
    ARGUMENT_FIELD_NUMBER: _ClassVar[int]
    COLUMNID_FIELD_NUMBER: _ClassVar[int]
    argument: str
    columnId: _mde_objects_pb2.ColumnId
    def __init__(self, argument: _Optional[str] = ..., columnId: _Optional[_Union[_mde_objects_pb2.ColumnId, _Mapping]] = ...) -> None: ...

class PolicyObjectSyncValue(_message.Message):
    __slots__ = ("policyObjectApiId", "policyArguments")
    POLICYOBJECTAPIID_FIELD_NUMBER: _ClassVar[int]
    POLICYARGUMENTS_FIELD_NUMBER: _ClassVar[int]
    policyObjectApiId: PolicyObjectApiId
    policyArguments: _containers.RepeatedCompositeFieldContainer[PolicyArgument]
    def __init__(self, policyObjectApiId: _Optional[_Union[PolicyObjectApiId, _Mapping]] = ..., policyArguments: _Optional[_Iterable[_Union[PolicyArgument, _Mapping]]] = ...) -> None: ...
