from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from policy import policy_objects_pb2 as _policy_objects_pb2
from queryservice_client.protobuf.rdbms import mde_pb2 as _mde_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PolicyExtractionRequest(_message.Message):
    __slots__ = ("configuration", "filter", "is_include_filter")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    IS_INCLUDE_FILTER_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    filter: _containers.RepeatedCompositeFieldContainer[_mde_pb2.FilterExtractionResponse]
    is_include_filter: bool
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., filter: _Optional[_Iterable[_Union[_mde_pb2.FilterExtractionResponse, _Mapping]]] = ..., is_include_filter: bool = ...) -> None: ...

class PolicyExtractionResponse(_message.Message):
    __slots__ = ("policy", "tableLink", "columnLink")
    POLICY_FIELD_NUMBER: _ClassVar[int]
    TABLELINK_FIELD_NUMBER: _ClassVar[int]
    COLUMNLINK_FIELD_NUMBER: _ClassVar[int]
    policy: _policy_objects_pb2.Policy
    tableLink: _policy_objects_pb2.TableLink
    columnLink: _policy_objects_pb2.ColumnLink
    def __init__(self, policy: _Optional[_Union[_policy_objects_pb2.Policy, _Mapping]] = ..., tableLink: _Optional[_Union[_policy_objects_pb2.TableLink, _Mapping]] = ..., columnLink: _Optional[_Union[_policy_objects_pb2.ColumnLink, _Mapping]] = ...) -> None: ...
