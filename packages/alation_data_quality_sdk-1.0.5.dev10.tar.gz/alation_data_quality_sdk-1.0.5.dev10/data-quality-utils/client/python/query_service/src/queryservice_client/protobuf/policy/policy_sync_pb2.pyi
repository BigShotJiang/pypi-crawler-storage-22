from policy import policy_objects_pb2 as _policy_objects_pb2
from queryservice_client.protobuf.common import auth_pb2 as _auth_pb2
from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import error_pb2 as _error_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PolicySyncResponse(_message.Message):
    __slots__ = ("tableLink", "columnLink", "error")
    TABLELINK_FIELD_NUMBER: _ClassVar[int]
    COLUMNLINK_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    tableLink: _policy_objects_pb2.TableLink
    columnLink: _policy_objects_pb2.ColumnLink
    error: _error_pb2.Error
    def __init__(self, tableLink: _Optional[_Union[_policy_objects_pb2.TableLink, _Mapping]] = ..., columnLink: _Optional[_Union[_policy_objects_pb2.ColumnLink, _Mapping]] = ..., error: _Optional[_Union[_error_pb2.Error, _Mapping]] = ...) -> None: ...

class PolicySyncRequest(_message.Message):
    __slots__ = ("configuration", "auth", "policyApiId", "policyObjectSyncValues")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    POLICYAPIID_FIELD_NUMBER: _ClassVar[int]
    POLICYOBJECTSYNCVALUES_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    auth: _auth_pb2.Auth
    policyApiId: _policy_objects_pb2.PolicyApiId
    policyObjectSyncValues: _containers.RepeatedCompositeFieldContainer[_policy_objects_pb2.PolicyObjectSyncValue]
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., auth: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ..., policyApiId: _Optional[_Union[_policy_objects_pb2.PolicyApiId, _Mapping]] = ..., policyObjectSyncValues: _Optional[_Iterable[_Union[_policy_objects_pb2.PolicyObjectSyncValue, _Mapping]]] = ...) -> None: ...
