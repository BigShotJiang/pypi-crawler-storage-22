from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Otype(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DATABASE_CATALOG: _ClassVar[Otype]
    SCHEMA: _ClassVar[Otype]
    TABLE: _ClassVar[Otype]
    COLUMN: _ClassVar[Otype]
    FUNCTION: _ClassVar[Otype]
DATABASE_CATALOG: Otype
SCHEMA: Otype
TABLE: Otype
COLUMN: Otype
FUNCTION: Otype

class Name(_message.Message):
    __slots__ = ("original", "normalized")
    ORIGINAL_FIELD_NUMBER: _ClassVar[int]
    NORMALIZED_FIELD_NUMBER: _ClassVar[int]
    original: str
    normalized: str
    def __init__(self, original: _Optional[str] = ..., normalized: _Optional[str] = ...) -> None: ...

class DatabaseCatalogId(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: Name
    def __init__(self, name: _Optional[_Union[Name, _Mapping]] = ...) -> None: ...

class SchemaId(_message.Message):
    __slots__ = ("databaseCatalog", "name")
    DATABASECATALOG_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    databaseCatalog: Name
    name: Name
    def __init__(self, databaseCatalog: _Optional[_Union[Name, _Mapping]] = ..., name: _Optional[_Union[Name, _Mapping]] = ...) -> None: ...

class TableId(_message.Message):
    __slots__ = ("databaseCatalog", "schema", "name")
    DATABASECATALOG_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    databaseCatalog: Name
    schema: Name
    name: Name
    def __init__(self, databaseCatalog: _Optional[_Union[Name, _Mapping]] = ..., schema: _Optional[_Union[Name, _Mapping]] = ..., name: _Optional[_Union[Name, _Mapping]] = ...) -> None: ...

class ColumnId(_message.Message):
    __slots__ = ("databaseCatalog", "schema", "table", "name")
    DATABASECATALOG_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    TABLE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    databaseCatalog: Name
    schema: Name
    table: Name
    name: Name
    def __init__(self, databaseCatalog: _Optional[_Union[Name, _Mapping]] = ..., schema: _Optional[_Union[Name, _Mapping]] = ..., table: _Optional[_Union[Name, _Mapping]] = ..., name: _Optional[_Union[Name, _Mapping]] = ...) -> None: ...

class FunctionId(_message.Message):
    __slots__ = ("databaseCatalog", "schema", "name")
    DATABASECATALOG_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    databaseCatalog: Name
    schema: Name
    name: Name
    def __init__(self, databaseCatalog: _Optional[_Union[Name, _Mapping]] = ..., schema: _Optional[_Union[Name, _Mapping]] = ..., name: _Optional[_Union[Name, _Mapping]] = ...) -> None: ...

class DatabaseCatalog(_message.Message):
    __slots__ = ("id", "sourceComment")
    ID_FIELD_NUMBER: _ClassVar[int]
    SOURCECOMMENT_FIELD_NUMBER: _ClassVar[int]
    id: DatabaseCatalogId
    sourceComment: str
    def __init__(self, id: _Optional[_Union[DatabaseCatalogId, _Mapping]] = ..., sourceComment: _Optional[str] = ...) -> None: ...

class Schema(_message.Message):
    __slots__ = ("id", "sourceComment", "isDeleted")
    ID_FIELD_NUMBER: _ClassVar[int]
    SOURCECOMMENT_FIELD_NUMBER: _ClassVar[int]
    ISDELETED_FIELD_NUMBER: _ClassVar[int]
    id: SchemaId
    sourceComment: str
    isDeleted: bool
    def __init__(self, id: _Optional[_Union[SchemaId, _Mapping]] = ..., sourceComment: _Optional[str] = ..., isDeleted: bool = ...) -> None: ...

class TableType(_message.Message):
    __slots__ = ("name", "normalized")
    class NormalizedType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        TABLE: _ClassVar[TableType.NormalizedType]
        VIEW: _ClassVar[TableType.NormalizedType]
        SYNONYM: _ClassVar[TableType.NormalizedType]
    TABLE: TableType.NormalizedType
    VIEW: TableType.NormalizedType
    SYNONYM: TableType.NormalizedType
    NAME_FIELD_NUMBER: _ClassVar[int]
    NORMALIZED_FIELD_NUMBER: _ClassVar[int]
    name: str
    normalized: TableType.NormalizedType
    def __init__(self, name: _Optional[str] = ..., normalized: _Optional[_Union[TableType.NormalizedType, str]] = ...) -> None: ...

class Partition(_message.Message):
    __slots__ = ("definition", "columns")
    DEFINITION_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    definition: str
    columns: _containers.RepeatedCompositeFieldContainer[ColumnId]
    def __init__(self, definition: _Optional[str] = ..., columns: _Optional[_Iterable[_Union[ColumnId, _Mapping]]] = ...) -> None: ...

class FileSystemPath(_message.Message):
    __slots__ = ("segments",)
    SEGMENTS_FIELD_NUMBER: _ClassVar[int]
    segments: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, segments: _Optional[_Iterable[str]] = ...) -> None: ...

class DataLocation(_message.Message):
    __slots__ = ("original", "scheme", "hostport", "path")
    ORIGINAL_FIELD_NUMBER: _ClassVar[int]
    SCHEME_FIELD_NUMBER: _ClassVar[int]
    HOSTPORT_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    original: str
    scheme: str
    hostport: str
    path: FileSystemPath
    def __init__(self, original: _Optional[str] = ..., scheme: _Optional[str] = ..., hostport: _Optional[str] = ..., path: _Optional[_Union[FileSystemPath, _Mapping]] = ...) -> None: ...

class Table(_message.Message):
    __slots__ = ("id", "sourceComment", "type", "ddl", "partition", "baseTable", "owner", "dataLocation", "additionalProperties", "isDeleted")
    class AdditionalPropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    SOURCECOMMENT_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    DDL_FIELD_NUMBER: _ClassVar[int]
    PARTITION_FIELD_NUMBER: _ClassVar[int]
    BASETABLE_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    DATALOCATION_FIELD_NUMBER: _ClassVar[int]
    ADDITIONALPROPERTIES_FIELD_NUMBER: _ClassVar[int]
    ISDELETED_FIELD_NUMBER: _ClassVar[int]
    id: TableId
    sourceComment: str
    type: TableType
    ddl: str
    partition: Partition
    baseTable: TableId
    owner: str
    dataLocation: DataLocation
    additionalProperties: _containers.ScalarMap[str, str]
    isDeleted: bool
    def __init__(self, id: _Optional[_Union[TableId, _Mapping]] = ..., sourceComment: _Optional[str] = ..., type: _Optional[_Union[TableType, _Mapping]] = ..., ddl: _Optional[str] = ..., partition: _Optional[_Union[Partition, _Mapping]] = ..., baseTable: _Optional[_Union[TableId, _Mapping]] = ..., owner: _Optional[str] = ..., dataLocation: _Optional[_Union[DataLocation, _Mapping]] = ..., additionalProperties: _Optional[_Mapping[str, str]] = ..., isDeleted: bool = ...) -> None: ...

class ColumnType(_message.Message):
    __slots__ = ("name", "definition", "normalized")
    class NormalizedType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        OTHER: _ClassVar[ColumnType.NormalizedType]
        BOOL: _ClassVar[ColumnType.NormalizedType]
        DATE: _ClassVar[ColumnType.NormalizedType]
        INT: _ClassVar[ColumnType.NormalizedType]
        FLOAT: _ClassVar[ColumnType.NormalizedType]
        STRING: _ClassVar[ColumnType.NormalizedType]
        TIME: _ClassVar[ColumnType.NormalizedType]
        TIMESTAMP: _ClassVar[ColumnType.NormalizedType]
    OTHER: ColumnType.NormalizedType
    BOOL: ColumnType.NormalizedType
    DATE: ColumnType.NormalizedType
    INT: ColumnType.NormalizedType
    FLOAT: ColumnType.NormalizedType
    STRING: ColumnType.NormalizedType
    TIME: ColumnType.NormalizedType
    TIMESTAMP: ColumnType.NormalizedType
    NAME_FIELD_NUMBER: _ClassVar[int]
    DEFINITION_FIELD_NUMBER: _ClassVar[int]
    NORMALIZED_FIELD_NUMBER: _ClassVar[int]
    name: str
    definition: str
    normalized: ColumnType.NormalizedType
    def __init__(self, name: _Optional[str] = ..., definition: _Optional[str] = ..., normalized: _Optional[_Union[ColumnType.NormalizedType, str]] = ...) -> None: ...

class TableIndexingInfo(_message.Message):
    __slots__ = ("isPrimaryKey", "isForeignKey", "referencedColumnId", "isOtherIndex")
    ISPRIMARYKEY_FIELD_NUMBER: _ClassVar[int]
    ISFOREIGNKEY_FIELD_NUMBER: _ClassVar[int]
    REFERENCEDCOLUMNID_FIELD_NUMBER: _ClassVar[int]
    ISOTHERINDEX_FIELD_NUMBER: _ClassVar[int]
    isPrimaryKey: bool
    isForeignKey: bool
    referencedColumnId: ColumnId
    isOtherIndex: bool
    def __init__(self, isPrimaryKey: bool = ..., isForeignKey: bool = ..., referencedColumnId: _Optional[_Union[ColumnId, _Mapping]] = ..., isOtherIndex: bool = ...) -> None: ...

class Column(_message.Message):
    __slots__ = ("id", "sourceComment", "type", "position", "isNullable", "indexInfo", "isDeleted")
    ID_FIELD_NUMBER: _ClassVar[int]
    SOURCECOMMENT_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    ISNULLABLE_FIELD_NUMBER: _ClassVar[int]
    INDEXINFO_FIELD_NUMBER: _ClassVar[int]
    ISDELETED_FIELD_NUMBER: _ClassVar[int]
    id: ColumnId
    sourceComment: str
    type: ColumnType
    position: int
    isNullable: bool
    indexInfo: TableIndexingInfo
    isDeleted: bool
    def __init__(self, id: _Optional[_Union[ColumnId, _Mapping]] = ..., sourceComment: _Optional[str] = ..., type: _Optional[_Union[ColumnType, _Mapping]] = ..., position: _Optional[int] = ..., isNullable: bool = ..., indexInfo: _Optional[_Union[TableIndexingInfo, _Mapping]] = ..., isDeleted: bool = ...) -> None: ...

class Function(_message.Message):
    __slots__ = ("id", "sourceComment", "signatures", "isDeleted")
    ID_FIELD_NUMBER: _ClassVar[int]
    SOURCECOMMENT_FIELD_NUMBER: _ClassVar[int]
    SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    ISDELETED_FIELD_NUMBER: _ClassVar[int]
    id: FunctionId
    sourceComment: str
    signatures: _containers.RepeatedScalarFieldContainer[str]
    isDeleted: bool
    def __init__(self, id: _Optional[_Union[FunctionId, _Mapping]] = ..., sourceComment: _Optional[str] = ..., signatures: _Optional[_Iterable[str]] = ..., isDeleted: bool = ...) -> None: ...

class SchemaApiId(_message.Message):
    __slots__ = ("schemaId",)
    SCHEMAID_FIELD_NUMBER: _ClassVar[int]
    schemaId: SchemaId
    def __init__(self, schemaId: _Optional[_Union[SchemaId, _Mapping]] = ...) -> None: ...

class TableApiId(_message.Message):
    __slots__ = ("tableId", "tableType")
    TABLEID_FIELD_NUMBER: _ClassVar[int]
    TABLETYPE_FIELD_NUMBER: _ClassVar[int]
    tableId: TableId
    tableType: TableType
    def __init__(self, tableId: _Optional[_Union[TableId, _Mapping]] = ..., tableType: _Optional[_Union[TableType, _Mapping]] = ...) -> None: ...

class ColumnApiId(_message.Message):
    __slots__ = ("columnId", "tableType")
    COLUMNID_FIELD_NUMBER: _ClassVar[int]
    TABLETYPE_FIELD_NUMBER: _ClassVar[int]
    columnId: ColumnId
    tableType: TableType
    def __init__(self, columnId: _Optional[_Union[ColumnId, _Mapping]] = ..., tableType: _Optional[_Union[TableType, _Mapping]] = ...) -> None: ...
