from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import extraction_objects_pb2 as _extraction_objects_pb2
from queryservice_client.protobuf.common import job_error_pb2 as _job_error_pb2
from queryservice_client.protobuf.rdbms import mde_objects_pb2 as _mde_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FilterExtractionRequest(_message.Message):
    __slots__ = ("configuration",)
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ...) -> None: ...

class FilterExtractionResponse(_message.Message):
    __slots__ = ("databaseCatalogId", "schemaId", "tableId", "error")
    DATABASECATALOGID_FIELD_NUMBER: _ClassVar[int]
    SCHEMAID_FIELD_NUMBER: _ClassVar[int]
    TABLEID_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    databaseCatalogId: _mde_objects_pb2.DatabaseCatalogId
    schemaId: _mde_objects_pb2.SchemaId
    tableId: _mde_objects_pb2.TableId
    error: _job_error_pb2.Error
    def __init__(self, databaseCatalogId: _Optional[_Union[_mde_objects_pb2.DatabaseCatalogId, _Mapping]] = ..., schemaId: _Optional[_Union[_mde_objects_pb2.SchemaId, _Mapping]] = ..., tableId: _Optional[_Union[_mde_objects_pb2.TableId, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ...) -> None: ...

class MetadataExtractionRequest(_message.Message):
    __slots__ = ("configuration", "filter", "is_include_filter", "bookmark")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    IS_INCLUDE_FILTER_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    filter: _containers.RepeatedCompositeFieldContainer[FilterExtractionResponse]
    is_include_filter: bool
    bookmark: _extraction_objects_pb2.Bookmark
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., filter: _Optional[_Iterable[_Union[FilterExtractionResponse, _Mapping]]] = ..., is_include_filter: bool = ..., bookmark: _Optional[_Union[_extraction_objects_pb2.Bookmark, _Mapping]] = ...) -> None: ...

class ExtractionProgress(_message.Message):
    __slots__ = ("message", "completedOtype")
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    COMPLETEDOTYPE_FIELD_NUMBER: _ClassVar[int]
    message: str
    completedOtype: _mde_objects_pb2.Otype
    def __init__(self, message: _Optional[str] = ..., completedOtype: _Optional[_Union[_mde_objects_pb2.Otype, str]] = ...) -> None: ...

class MetadataExtractionResponse(_message.Message):
    __slots__ = ("databaseCatalog", "schema", "table", "column", "function", "extractionProgress", "error", "bookmark")
    DATABASECATALOG_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    TABLE_FIELD_NUMBER: _ClassVar[int]
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    FUNCTION_FIELD_NUMBER: _ClassVar[int]
    EXTRACTIONPROGRESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    BOOKMARK_FIELD_NUMBER: _ClassVar[int]
    databaseCatalog: _mde_objects_pb2.DatabaseCatalog
    schema: _mde_objects_pb2.Schema
    table: _mde_objects_pb2.Table
    column: _mde_objects_pb2.Column
    function: _mde_objects_pb2.Function
    extractionProgress: ExtractionProgress
    error: _job_error_pb2.Error
    bookmark: _extraction_objects_pb2.Bookmark
    def __init__(self, databaseCatalog: _Optional[_Union[_mde_objects_pb2.DatabaseCatalog, _Mapping]] = ..., schema: _Optional[_Union[_mde_objects_pb2.Schema, _Mapping]] = ..., table: _Optional[_Union[_mde_objects_pb2.Table, _Mapping]] = ..., column: _Optional[_Union[_mde_objects_pb2.Column, _Mapping]] = ..., function: _Optional[_Union[_mde_objects_pb2.Function, _Mapping]] = ..., extractionProgress: _Optional[_Union[ExtractionProgress, _Mapping]] = ..., error: _Optional[_Union[_job_error_pb2.Error, _Mapping]] = ..., bookmark: _Optional[_Union[_extraction_objects_pb2.Bookmark, _Mapping]] = ...) -> None: ...

class TableExtractionRequest(_message.Message):
    __slots__ = ("configuration", "tableId", "tableType")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    TABLEID_FIELD_NUMBER: _ClassVar[int]
    TABLETYPE_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    tableId: _mde_objects_pb2.TableId
    tableType: _mde_objects_pb2.TableType
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., tableId: _Optional[_Union[_mde_objects_pb2.TableId, _Mapping]] = ..., tableType: _Optional[_Union[_mde_objects_pb2.TableType, _Mapping]] = ...) -> None: ...

class TableExtractionResponse(_message.Message):
    __slots__ = ("table", "column")
    TABLE_FIELD_NUMBER: _ClassVar[int]
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    table: _mde_objects_pb2.Table
    column: _mde_objects_pb2.Column
    def __init__(self, table: _Optional[_Union[_mde_objects_pb2.Table, _Mapping]] = ..., column: _Optional[_Union[_mde_objects_pb2.Column, _Mapping]] = ...) -> None: ...
