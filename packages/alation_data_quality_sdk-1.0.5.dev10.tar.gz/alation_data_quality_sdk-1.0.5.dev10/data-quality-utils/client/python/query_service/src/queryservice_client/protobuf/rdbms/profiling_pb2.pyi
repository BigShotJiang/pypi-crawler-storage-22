from queryservice_client.protobuf.common import auth_pb2 as _auth_pb2
from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.rdbms import mde_objects_pb2 as _mde_objects_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TableProfilingRequest(_message.Message):
    __slots__ = ("configuration", "tableRequests", "auth", "jdbcUri")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    TABLEREQUESTS_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    JDBCURI_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    tableRequests: _containers.RepeatedCompositeFieldContainer[TableRequest]
    auth: _auth_pb2.Auth
    jdbcUri: str
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., tableRequests: _Optional[_Iterable[_Union[TableRequest, _Mapping]]] = ..., auth: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ..., jdbcUri: _Optional[str] = ...) -> None: ...

class TableRequest(_message.Message):
    __slots__ = ("id", "name", "schema", "populationSize", "sampleSize", "sensitiveColumns", "columns", "timeout", "schema_name", "catalog_name")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    POPULATIONSIZE_FIELD_NUMBER: _ClassVar[int]
    SAMPLESIZE_FIELD_NUMBER: _ClassVar[int]
    SENSITIVECOLUMNS_FIELD_NUMBER: _ClassVar[int]
    COLUMNS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_NAME_FIELD_NUMBER: _ClassVar[int]
    CATALOG_NAME_FIELD_NUMBER: _ClassVar[int]
    id: int
    name: str
    schema: str
    populationSize: int
    sampleSize: int
    sensitiveColumns: _containers.RepeatedCompositeFieldContainer[Column]
    columns: _containers.RepeatedCompositeFieldContainer[Column]
    timeout: int
    schema_name: str
    catalog_name: str
    def __init__(self, id: _Optional[int] = ..., name: _Optional[str] = ..., schema: _Optional[str] = ..., populationSize: _Optional[int] = ..., sampleSize: _Optional[int] = ..., sensitiveColumns: _Optional[_Iterable[_Union[Column, _Mapping]]] = ..., columns: _Optional[_Iterable[_Union[Column, _Mapping]]] = ..., timeout: _Optional[int] = ..., schema_name: _Optional[str] = ..., catalog_name: _Optional[str] = ...) -> None: ...

class Column(_message.Message):
    __slots__ = ("name", "id", "columnType")
    NAME_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    COLUMNTYPE_FIELD_NUMBER: _ClassVar[int]
    name: str
    id: int
    columnType: _mde_objects_pb2.ColumnType
    def __init__(self, name: _Optional[str] = ..., id: _Optional[int] = ..., columnType: _Optional[_Union[_mde_objects_pb2.ColumnType, _Mapping]] = ...) -> None: ...

class TableProfilingResponse(_message.Message):
    __slots__ = ("id", "rowSamples", "numberOfRowsSampled", "secondsTaken", "hasMore", "columnSummaries")
    ID_FIELD_NUMBER: _ClassVar[int]
    ROWSAMPLES_FIELD_NUMBER: _ClassVar[int]
    NUMBEROFROWSSAMPLED_FIELD_NUMBER: _ClassVar[int]
    SECONDSTAKEN_FIELD_NUMBER: _ClassVar[int]
    HASMORE_FIELD_NUMBER: _ClassVar[int]
    COLUMNSUMMARIES_FIELD_NUMBER: _ClassVar[int]
    id: int
    rowSamples: _containers.RepeatedCompositeFieldContainer[Row]
    numberOfRowsSampled: int
    secondsTaken: int
    hasMore: bool
    columnSummaries: _containers.RepeatedCompositeFieldContainer[ColumnSummary]
    def __init__(self, id: _Optional[int] = ..., rowSamples: _Optional[_Iterable[_Union[Row, _Mapping]]] = ..., numberOfRowsSampled: _Optional[int] = ..., secondsTaken: _Optional[int] = ..., hasMore: bool = ..., columnSummaries: _Optional[_Iterable[_Union[ColumnSummary, _Mapping]]] = ...) -> None: ...

class Row(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, values: _Optional[_Iterable[str]] = ...) -> None: ...

class ColumnSummary(_message.Message):
    __slots__ = ("distribution", "numberOfNulls", "numberOfUniqueValues", "numberOfAllValues", "column")
    DISTRIBUTION_FIELD_NUMBER: _ClassVar[int]
    NUMBEROFNULLS_FIELD_NUMBER: _ClassVar[int]
    NUMBEROFUNIQUEVALUES_FIELD_NUMBER: _ClassVar[int]
    NUMBEROFALLVALUES_FIELD_NUMBER: _ClassVar[int]
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    distribution: _containers.RepeatedCompositeFieldContainer[ColumnDistribution]
    numberOfNulls: int
    numberOfUniqueValues: int
    numberOfAllValues: int
    column: Column
    def __init__(self, distribution: _Optional[_Iterable[_Union[ColumnDistribution, _Mapping]]] = ..., numberOfNulls: _Optional[int] = ..., numberOfUniqueValues: _Optional[int] = ..., numberOfAllValues: _Optional[int] = ..., column: _Optional[_Union[Column, _Mapping]] = ...) -> None: ...

class ColumnDistribution(_message.Message):
    __slots__ = ("value", "count")
    VALUE_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    value: str
    count: int
    def __init__(self, value: _Optional[str] = ..., count: _Optional[int] = ...) -> None: ...

class CustomTableProfilingRequest(_message.Message):
    __slots__ = ("configuration", "tableRequests", "auth", "jdbcUri")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    TABLEREQUESTS_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    JDBCURI_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    tableRequests: _containers.RepeatedCompositeFieldContainer[CustomTableRequest]
    auth: _auth_pb2.Auth
    jdbcUri: str
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., tableRequests: _Optional[_Iterable[_Union[CustomTableRequest, _Mapping]]] = ..., auth: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ..., jdbcUri: _Optional[str] = ...) -> None: ...

class CustomTableRequest(_message.Message):
    __slots__ = ("request", "override")
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    OVERRIDE_FIELD_NUMBER: _ClassVar[int]
    request: TableRequest
    override: str
    def __init__(self, request: _Optional[_Union[TableRequest, _Mapping]] = ..., override: _Optional[str] = ...) -> None: ...

class CustomTableProfilingResponse(_message.Message):
    __slots__ = ("response", "schema")
    RESPONSE_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    response: TableProfilingResponse
    schema: _containers.RepeatedCompositeFieldContainer[Column]
    def __init__(self, response: _Optional[_Union[TableProfilingResponse, _Mapping]] = ..., schema: _Optional[_Iterable[_Union[Column, _Mapping]]] = ...) -> None: ...

class ColumnProfilingRequest(_message.Message):
    __slots__ = ("configuration", "request", "auth", "jdbcUri")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    JDBCURI_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    request: ColumnRequest
    auth: _auth_pb2.Auth
    jdbcUri: str
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., request: _Optional[_Union[ColumnRequest, _Mapping]] = ..., auth: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ..., jdbcUri: _Optional[str] = ...) -> None: ...

class ColumnRequest(_message.Message):
    __slots__ = ("schema", "table", "column", "sampleSize", "timeout", "type", "schema_name", "catalog_name")
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    TABLE_FIELD_NUMBER: _ClassVar[int]
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    SAMPLESIZE_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_NAME_FIELD_NUMBER: _ClassVar[int]
    CATALOG_NAME_FIELD_NUMBER: _ClassVar[int]
    schema: str
    table: str
    column: str
    sampleSize: int
    timeout: int
    type: _mde_objects_pb2.ColumnType.NormalizedType
    schema_name: str
    catalog_name: str
    def __init__(self, schema: _Optional[str] = ..., table: _Optional[str] = ..., column: _Optional[str] = ..., sampleSize: _Optional[int] = ..., timeout: _Optional[int] = ..., type: _Optional[_Union[_mde_objects_pb2.ColumnType.NormalizedType, str]] = ..., schema_name: _Optional[str] = ..., catalog_name: _Optional[str] = ...) -> None: ...

class ColumnProfilingResponse(_message.Message):
    __slots__ = ("distribution", "final")
    DISTRIBUTION_FIELD_NUMBER: _ClassVar[int]
    FINAL_FIELD_NUMBER: _ClassVar[int]
    distribution: ColumnDistribution
    final: ColumnProfilingFinalResponse
    def __init__(self, distribution: _Optional[_Union[ColumnDistribution, _Mapping]] = ..., final: _Optional[_Union[ColumnProfilingFinalResponse, _Mapping]] = ...) -> None: ...

class ColumnProfilingFinalResponse(_message.Message):
    __slots__ = ("statistics", "hasMore", "secondsTaken")
    STATISTICS_FIELD_NUMBER: _ClassVar[int]
    HASMORE_FIELD_NUMBER: _ClassVar[int]
    SECONDSTAKEN_FIELD_NUMBER: _ClassVar[int]
    statistics: _containers.RepeatedCompositeFieldContainer[Statistic]
    hasMore: bool
    secondsTaken: int
    def __init__(self, statistics: _Optional[_Iterable[_Union[Statistic, _Mapping]]] = ..., hasMore: bool = ..., secondsTaken: _Optional[int] = ...) -> None: ...

class Statistic(_message.Message):
    __slots__ = ("name", "value")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: str
    def __init__(self, name: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class CustomColumnProfilingRequest(_message.Message):
    __slots__ = ("configuration", "request", "override", "auth", "jdbcUri")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    OVERRIDE_FIELD_NUMBER: _ClassVar[int]
    AUTH_FIELD_NUMBER: _ClassVar[int]
    JDBCURI_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    request: ColumnRequest
    override: ColumnStatisticsOverride
    auth: _auth_pb2.Auth
    jdbcUri: str
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., request: _Optional[_Union[ColumnRequest, _Mapping]] = ..., override: _Optional[_Union[ColumnStatisticsOverride, _Mapping]] = ..., auth: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ..., jdbcUri: _Optional[str] = ...) -> None: ...

class ColumnStatisticsOverride(_message.Message):
    __slots__ = ("literal", "templated")
    LITERAL_FIELD_NUMBER: _ClassVar[int]
    TEMPLATED_FIELD_NUMBER: _ClassVar[int]
    literal: str
    templated: TemplatedColumnStatisticsOverride
    def __init__(self, literal: _Optional[str] = ..., templated: _Optional[_Union[TemplatedColumnStatisticsOverride, _Mapping]] = ...) -> None: ...

class TemplatedColumnStatisticsOverride(_message.Message):
    __slots__ = ("numericTemplate", "nonNumericTemplate", "columnPlaceholder", "tablePlaceholder", "limitPlaceholder")
    NUMERICTEMPLATE_FIELD_NUMBER: _ClassVar[int]
    NONNUMERICTEMPLATE_FIELD_NUMBER: _ClassVar[int]
    COLUMNPLACEHOLDER_FIELD_NUMBER: _ClassVar[int]
    TABLEPLACEHOLDER_FIELD_NUMBER: _ClassVar[int]
    LIMITPLACEHOLDER_FIELD_NUMBER: _ClassVar[int]
    numericTemplate: str
    nonNumericTemplate: str
    columnPlaceholder: str
    tablePlaceholder: str
    limitPlaceholder: str
    def __init__(self, numericTemplate: _Optional[str] = ..., nonNumericTemplate: _Optional[str] = ..., columnPlaceholder: _Optional[str] = ..., tablePlaceholder: _Optional[str] = ..., limitPlaceholder: _Optional[str] = ...) -> None: ...
