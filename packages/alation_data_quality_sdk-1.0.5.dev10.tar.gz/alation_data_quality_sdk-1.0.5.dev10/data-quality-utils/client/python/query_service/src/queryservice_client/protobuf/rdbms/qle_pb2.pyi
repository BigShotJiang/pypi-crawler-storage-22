from google.protobuf import timestamp_pb2 as _timestamp_pb2
from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Request(_message.Message):
    __slots__ = ("configuration", "runConfiguration")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    RUNCONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    runConfiguration: RunConfiguration
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., runConfiguration: _Optional[_Union[RunConfiguration, _Mapping]] = ...) -> None: ...

class RunConfiguration(_message.Message):
    __slots__ = ("limit", "startTime", "endTime")
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    ENDTIME_FIELD_NUMBER: _ClassVar[int]
    limit: int
    startTime: _timestamp_pb2.Timestamp
    endTime: _timestamp_pb2.Timestamp
    def __init__(self, limit: _Optional[int] = ..., startTime: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., endTime: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Response(_message.Message):
    __slots__ = ("statement", "result", "isResult")
    STATEMENT_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    ISRESULT_FIELD_NUMBER: _ClassVar[int]
    statement: QueryStatement
    result: FinalResult
    isResult: bool
    def __init__(self, statement: _Optional[_Union[QueryStatement, _Mapping]] = ..., result: _Optional[_Union[FinalResult, _Mapping]] = ..., isResult: bool = ...) -> None: ...

class FinalResult(_message.Message):
    __slots__ = ("statementCount", "accounts", "warnings")
    class AccountsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: int
        def __init__(self, key: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...
    STATEMENTCOUNT_FIELD_NUMBER: _ClassVar[int]
    ACCOUNTS_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    statementCount: int
    accounts: _containers.ScalarMap[str, int]
    warnings: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, statementCount: _Optional[int] = ..., accounts: _Optional[_Mapping[str, int]] = ..., warnings: _Optional[_Iterable[str]] = ...) -> None: ...

class QueryStatement(_message.Message):
    __slots__ = ("userName", "text", "defaultDatabases", "sessionId", "sessionStartTime", "startTime", "cancelled", "secondsTaken", "destinationTable")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    DEFAULTDATABASES_FIELD_NUMBER: _ClassVar[int]
    SESSIONID_FIELD_NUMBER: _ClassVar[int]
    SESSIONSTARTTIME_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    CANCELLED_FIELD_NUMBER: _ClassVar[int]
    SECONDSTAKEN_FIELD_NUMBER: _ClassVar[int]
    DESTINATIONTABLE_FIELD_NUMBER: _ClassVar[int]
    userName: str
    text: str
    defaultDatabases: str
    sessionId: str
    sessionStartTime: _timestamp_pb2.Timestamp
    startTime: _timestamp_pb2.Timestamp
    cancelled: bool
    secondsTaken: float
    destinationTable: str
    def __init__(self, userName: _Optional[str] = ..., text: _Optional[str] = ..., defaultDatabases: _Optional[str] = ..., sessionId: _Optional[str] = ..., sessionStartTime: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., startTime: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., cancelled: bool = ..., secondsTaken: _Optional[float] = ..., destinationTable: _Optional[str] = ...) -> None: ...
