from queryservice_client.protobuf.common import configuration_pb2 as _configuration_pb2
from queryservice_client.protobuf.common import auth_pb2 as _auth_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DataType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NULL: _ClassVar[DataType]
    DOUBLE: _ClassVar[DataType]
    FLOAT: _ClassVar[DataType]
    INT32: _ClassVar[DataType]
    INT64: _ClassVar[DataType]
    UINT32: _ClassVar[DataType]
    UINT64: _ClassVar[DataType]
    BOOL: _ClassVar[DataType]
    STRING: _ClassVar[DataType]
    BYTES: _ClassVar[DataType]
    DATE: _ClassVar[DataType]
    ARRAY: _ClassVar[DataType]
    STRUCT: _ClassVar[DataType]
    BIGINT: _ClassVar[DataType]
    BIGDECIMAL: _ClassVar[DataType]

class Endianness(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BIG: _ClassVar[Endianness]
    LITTLE: _ClassVar[Endianness]
NULL: DataType
DOUBLE: DataType
FLOAT: DataType
INT32: DataType
INT64: DataType
UINT32: DataType
UINT64: DataType
BOOL: DataType
STRING: DataType
BYTES: DataType
DATE: DataType
ARRAY: DataType
STRUCT: DataType
BIGINT: DataType
BIGDECIMAL: DataType
BIG: Endianness
LITTLE: Endianness

class StartSessionRequest(_message.Message):
    __slots__ = ("configuration", "authentication")
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    AUTHENTICATION_FIELD_NUMBER: _ClassVar[int]
    configuration: _configuration_pb2.ProtobufConfiguration
    authentication: _auth_pb2.Auth
    def __init__(self, configuration: _Optional[_Union[_configuration_pb2.ProtobufConfiguration, _Mapping]] = ..., authentication: _Optional[_Union[_auth_pb2.Auth, _Mapping]] = ...) -> None: ...

class StartSessionResponse(_message.Message):
    __slots__ = ("sessionId", "supportsCancellation")
    SESSIONID_FIELD_NUMBER: _ClassVar[int]
    SUPPORTSCANCELLATION_FIELD_NUMBER: _ClassVar[int]
    sessionId: int
    supportsCancellation: bool
    def __init__(self, sessionId: _Optional[int] = ..., supportsCancellation: bool = ...) -> None: ...

class EndSessionRequest(_message.Message):
    __slots__ = ("sessionId",)
    SESSIONID_FIELD_NUMBER: _ClassVar[int]
    sessionId: int
    def __init__(self, sessionId: _Optional[int] = ...) -> None: ...

class CancelQueryRequest(_message.Message):
    __slots__ = ("sessionId",)
    SESSIONID_FIELD_NUMBER: _ClassVar[int]
    sessionId: int
    def __init__(self, sessionId: _Optional[int] = ...) -> None: ...

class CancelQueryResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QueryRequest(_message.Message):
    __slots__ = ("sessionId", "query", "limit", "timeout")
    SESSIONID_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    sessionId: int
    query: str
    limit: int
    timeout: int
    def __init__(self, sessionId: _Optional[int] = ..., query: _Optional[str] = ..., limit: _Optional[int] = ..., timeout: _Optional[int] = ...) -> None: ...

class QueryResponse(_message.Message):
    __slots__ = ("restart", "cancelled", "queryResult")
    RESTART_FIELD_NUMBER: _ClassVar[int]
    CANCELLED_FIELD_NUMBER: _ClassVar[int]
    QUERYRESULT_FIELD_NUMBER: _ClassVar[int]
    restart: bool
    cancelled: bool
    queryResult: QueryResult
    def __init__(self, restart: bool = ..., cancelled: bool = ..., queryResult: _Optional[_Union[QueryResult, _Mapping]] = ...) -> None: ...

class QueryResult(_message.Message):
    __slots__ = ("objects",)
    OBJECTS_FIELD_NUMBER: _ClassVar[int]
    objects: _containers.RepeatedCompositeFieldContainer[QueryResultObject]
    def __init__(self, objects: _Optional[_Iterable[_Union[QueryResultObject, _Mapping]]] = ...) -> None: ...

class QueryResultObject(_message.Message):
    __slots__ = ("data", "beginResultSet", "endOfResultSet", "endOfMetadata", "endOfRow")
    DATA_FIELD_NUMBER: _ClassVar[int]
    BEGINRESULTSET_FIELD_NUMBER: _ClassVar[int]
    ENDOFRESULTSET_FIELD_NUMBER: _ClassVar[int]
    ENDOFMETADATA_FIELD_NUMBER: _ClassVar[int]
    ENDOFROW_FIELD_NUMBER: _ClassVar[int]
    data: StreamData
    beginResultSet: StreamDelimiter
    endOfResultSet: StreamDelimiter
    endOfMetadata: StreamDelimiter
    endOfRow: StreamDelimiter
    def __init__(self, data: _Optional[_Union[StreamData, _Mapping]] = ..., beginResultSet: _Optional[_Union[StreamDelimiter, _Mapping]] = ..., endOfResultSet: _Optional[_Union[StreamDelimiter, _Mapping]] = ..., endOfMetadata: _Optional[_Union[StreamDelimiter, _Mapping]] = ..., endOfRow: _Optional[_Union[StreamDelimiter, _Mapping]] = ...) -> None: ...

class StreamData(_message.Message):
    __slots__ = ("metadata", "rowData")
    METADATA_FIELD_NUMBER: _ClassVar[int]
    ROWDATA_FIELD_NUMBER: _ClassVar[int]
    metadata: Metadata
    rowData: RowData
    def __init__(self, metadata: _Optional[_Union[Metadata, _Mapping]] = ..., rowData: _Optional[_Union[RowData, _Mapping]] = ...) -> None: ...

class Metadata(_message.Message):
    __slots__ = ("projection", "updateCount")
    PROJECTION_FIELD_NUMBER: _ClassVar[int]
    UPDATECOUNT_FIELD_NUMBER: _ClassVar[int]
    projection: Projection
    updateCount: int
    def __init__(self, projection: _Optional[_Union[Projection, _Mapping]] = ..., updateCount: _Optional[int] = ...) -> None: ...

class Projection(_message.Message):
    __slots__ = ("name", "ordinality", "type", "dtype", "label")
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDINALITY_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    DTYPE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    name: str
    ordinality: int
    type: str
    dtype: DataType
    label: str
    def __init__(self, name: _Optional[str] = ..., ordinality: _Optional[int] = ..., type: _Optional[str] = ..., dtype: _Optional[_Union[DataType, str]] = ..., label: _Optional[str] = ...) -> None: ...

class RowData(_message.Message):
    __slots__ = ("null", "double", "float", "int32", "int64", "uint32", "uint64", "bool", "string", "bytes", "date", "array", "struct", "bigInt", "bigDecimal")
    NULL_FIELD_NUMBER: _ClassVar[int]
    DOUBLE_FIELD_NUMBER: _ClassVar[int]
    FLOAT_FIELD_NUMBER: _ClassVar[int]
    INT32_FIELD_NUMBER: _ClassVar[int]
    INT64_FIELD_NUMBER: _ClassVar[int]
    UINT32_FIELD_NUMBER: _ClassVar[int]
    UINT64_FIELD_NUMBER: _ClassVar[int]
    BOOL_FIELD_NUMBER: _ClassVar[int]
    STRING_FIELD_NUMBER: _ClassVar[int]
    BYTES_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    ARRAY_FIELD_NUMBER: _ClassVar[int]
    STRUCT_FIELD_NUMBER: _ClassVar[int]
    BIGINT_FIELD_NUMBER: _ClassVar[int]
    BIGDECIMAL_FIELD_NUMBER: _ClassVar[int]
    null: Null
    double: float
    float: float
    int32: int
    int64: int
    uint32: int
    uint64: int
    bool: bool
    string: str
    bytes: bytes
    date: Date
    array: Array
    struct: Struct
    bigInt: BigInt
    bigDecimal: BigDecimal
    def __init__(self, null: _Optional[_Union[Null, _Mapping]] = ..., double: _Optional[float] = ..., float: _Optional[float] = ..., int32: _Optional[int] = ..., int64: _Optional[int] = ..., uint32: _Optional[int] = ..., uint64: _Optional[int] = ..., bool: bool = ..., string: _Optional[str] = ..., bytes: _Optional[bytes] = ..., date: _Optional[_Union[Date, _Mapping]] = ..., array: _Optional[_Union[Array, _Mapping]] = ..., struct: _Optional[_Union[Struct, _Mapping]] = ..., bigInt: _Optional[_Union[BigInt, _Mapping]] = ..., bigDecimal: _Optional[_Union[BigDecimal, _Mapping]] = ...) -> None: ...

class Struct(_message.Message):
    __slots__ = ("members",)
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    members: _containers.RepeatedCompositeFieldContainer[RowData]
    def __init__(self, members: _Optional[_Iterable[_Union[RowData, _Mapping]]] = ...) -> None: ...

class Array(_message.Message):
    __slots__ = ("array",)
    ARRAY_FIELD_NUMBER: _ClassVar[int]
    array: _containers.RepeatedCompositeFieldContainer[RowData]
    def __init__(self, array: _Optional[_Iterable[_Union[RowData, _Mapping]]] = ...) -> None: ...

class Null(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class Date(_message.Message):
    __slots__ = ("timestamp", "timezoneOffsetMinutes")
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    TIMEZONEOFFSETMINUTES_FIELD_NUMBER: _ClassVar[int]
    timestamp: _timestamp_pb2.Timestamp
    timezoneOffsetMinutes: int
    def __init__(self, timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., timezoneOffsetMinutes: _Optional[int] = ...) -> None: ...

class StreamDelimiter(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class BigInt(_message.Message):
    __slots__ = ("value", "endianness")
    VALUE_FIELD_NUMBER: _ClassVar[int]
    ENDIANNESS_FIELD_NUMBER: _ClassVar[int]
    value: bytes
    endianness: Endianness
    def __init__(self, value: _Optional[bytes] = ..., endianness: _Optional[_Union[Endianness, str]] = ...) -> None: ...

class BigDecimal(_message.Message):
    __slots__ = ("scale", "unscaledValue")
    SCALE_FIELD_NUMBER: _ClassVar[int]
    UNSCALEDVALUE_FIELD_NUMBER: _ClassVar[int]
    scale: int
    unscaledValue: BigInt
    def __init__(self, scale: _Optional[int] = ..., unscaledValue: _Optional[_Union[BigInt, _Mapping]] = ...) -> None: ...
