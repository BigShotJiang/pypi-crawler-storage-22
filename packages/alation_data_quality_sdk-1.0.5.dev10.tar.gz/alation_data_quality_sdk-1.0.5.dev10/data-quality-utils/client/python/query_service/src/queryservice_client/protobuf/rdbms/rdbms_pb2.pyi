from google.protobuf import empty_pb2 as _empty_pb2
from queryservice_client.protobuf.common import verify_pb2 as _verify_pb2
from queryservice_client.protobuf.rdbms import mde_pb2 as _mde_pb2
from queryservice_client.protobuf.rdbms import profiling_pb2 as _profiling_pb2
from queryservice_client.protobuf.rdbms import qle_pb2 as _qle_pb2
from queryservice_client.protobuf.rdbms import query_pb2 as _query_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
