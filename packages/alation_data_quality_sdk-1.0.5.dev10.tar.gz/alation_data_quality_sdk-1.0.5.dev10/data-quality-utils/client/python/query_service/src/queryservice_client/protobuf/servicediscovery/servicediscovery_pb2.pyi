from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Agent(_message.Message):
    __slots__ = ("uuid",)
    UUID_FIELD_NUMBER: _ClassVar[int]
    uuid: str
    def __init__(self, uuid: _Optional[str] = ...) -> None: ...

class ProxyList(_message.Message):
    __slots__ = ("proxies",)
    PROXIES_FIELD_NUMBER: _ClassVar[int]
    proxies: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, proxies: _Optional[_Iterable[str]] = ...) -> None: ...
