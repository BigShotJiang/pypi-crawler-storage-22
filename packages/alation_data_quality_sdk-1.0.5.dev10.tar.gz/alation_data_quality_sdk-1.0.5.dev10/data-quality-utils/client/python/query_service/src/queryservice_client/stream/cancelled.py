class Cancelled(Exception):
    pass