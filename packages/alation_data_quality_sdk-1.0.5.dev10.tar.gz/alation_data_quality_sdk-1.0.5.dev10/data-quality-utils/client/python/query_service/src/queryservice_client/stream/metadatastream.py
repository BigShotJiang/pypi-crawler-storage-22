from queryservice_client.protobuf.rdbms.query_pb2 import QueryResultObject

from queryservice_client.stream.peekable import Peekable
from queryservice_client.stream.delimitedstream import DelimitedStream

class MetadataStream(Peekable):

    @staticmethod
    def check(obj: QueryResultObject):
        return obj.HasField("endOfMetadata")

    def __init__(self, stream):
        self.stream = DelimitedStream(stream, MetadataStream.check)

    def has_next(self):
        return self.stream.has_next()

    def __next__(self):
        return next(self.stream).data.metadata

    def peek(self):
        return self.stream.peek().data.metadata

    def __iter__(self):
        return self