class Reconnect(Exception):
    pass