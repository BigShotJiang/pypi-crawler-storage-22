#!/usr/bin/env python

import os
from setuptools import find_namespace_packages, setup

package_name = "soda-core"
# Managed by tbump - do not change manually
package_version = "3.4.4"
description = "Soda Core"

def get_version():
    build_number = os.getenv('BUILD_NUMBER', "0")
    return f"{package_version}+{build_number}"

requires = [
    "markupsafe>=2.0.1,<=2.1.2",
    "Jinja2>=2.11,<4.0",
    "click~=8.0",
    "ruamel.yaml>=0.17.0,<0.18.0",
    "requests~=2.30",
    "antlr4-python3-runtime~=4.11.1",
    "sqlparse>=0.5.0,<0.6.0",
    "inflect~=7.0",
    "pydantic>=2.0.0,<3.0.0",
    "alation_queryservice_client>=0.1.0",
    "alation_logger_utils>=0.1.0",
    "structlog>=24.4.0",
]


setup(
    name=package_name,
    version=get_version(),
    author="Soda Data N.V.",
    author_email="info@soda.io",
    description="Soda Core library & CLI",
    long_description_content_type="text/markdown",
    packages=find_namespace_packages(include=["soda*"]),
    install_requires=requires,
    entry_points={"console_scripts": ["soda=soda.cli.cli:main"]},
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    python_requires=">=3.7",
)
