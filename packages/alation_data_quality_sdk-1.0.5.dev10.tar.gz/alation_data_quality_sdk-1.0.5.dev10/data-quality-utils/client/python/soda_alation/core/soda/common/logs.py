from __future__ import annotations

import logging
import structlog
import sys
from logging import Logger
from typing import Optional

from soda.common.log import Log, LogLevel
from soda.sodacl.location import Location


def configure_logging():
    sys.stderr = sys.stdout
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("botocore").setLevel(logging.WARNING)
    logging.getLogger("pyathena").setLevel(logging.WARNING)
    logging.getLogger("faker").setLevel(logging.ERROR)
    logging.getLogger("snowflake").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)
    logging.getLogger("pyspark").setLevel(logging.ERROR)
    logging.getLogger("pyhive").setLevel(logging.ERROR)
    logging.getLogger("py4j").setLevel(logging.INFO)
    logging.getLogger("segment").setLevel(logging.WARNING)
    logging.basicConfig(
        level=logging.DEBUG,
        force=True,  # Override any previously set handlers.
        # https://docs.python.org/3/library/logging.html#logrecord-attributes
        # %(name)s
        format="%(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


class Logs:
    __instance = None

    def __new__(cls, logger: Optional[structlog.BoundLogger] = None):
        if cls.__instance is None:
            cls.__instance = super().__new__(cls)
            cls.__instance._initialize(logger)
        return cls.__instance

    def _initialize(self, logger: Optional[structlog.BoundLogger] = None):
        self.logs: list[Log] = []  # Soda-compatible log storage
        self.logs_buffer: list[Log] = []
        self.verbose: bool = False
        self.logger: structlog.BoundLogger = logger or structlog.get_logger()

    def reset(self):
        """Reset the singleton instance (for testability)."""
        Logs.__instance = None
        return Logs()

    def set_logger(self, logger: structlog.BoundLogger):
        """Assign or override the logger instance."""
        self.logger = logger

    def bind_context(self, **kwargs):
        """Bind structured context (e.g. tenant_id, job_id)."""
        self.logger = self.logger.bind(**kwargs)

    def copy_context_from_logger(self, source_logger: structlog.BoundLogger):
        """Copies and binds context from an existing BoundLogger."""
        context = getattr(source_logger, "_context", {})
        self.logger = self.logger.bind(**context)

    def _record_and_log(
        self,
        level: LogLevel,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
        **extra,
    ):
        log = Log(
            level=level,
            message=message,
            location=location,
            doc=doc,
            exception=exception
        )
        self.logs.append(log)

        # Emit via structlog
        log_method = {
            LogLevel.ERROR: self.logger.error,
            LogLevel.WARNING: self.logger.warning,
            LogLevel.INFO: self.logger.info,
            LogLevel.DEBUG: self.logger.debug,
        }[level]

        log_method(
            message,
            location=str(location) if location else None,
            doc=doc,
            exception=str(exception) if exception else None,
            **extra
        )

    def error(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
        **extra
    ):
        self._record_and_log(LogLevel.ERROR, message, location, doc, exception, **extra)

    def warning(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
        **extra
    ):
        self._record_and_log(LogLevel.WARNING, message, location, doc, exception, **extra)

    def info(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
        **extra
    ):
        self._record_and_log(LogLevel.INFO, message, location, doc, exception, **extra)

    def debug(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
        **extra
    ):
        if self.verbose:
            self._record_and_log(LogLevel.DEBUG, message, location, doc, exception, **extra)

    def log_into_buffer(self, level, message, location, doc, exception):
        log = Log(
            level=level,
            message=message,
            location=location,
            doc=doc,
            exception=exception,
        )
        self.logs_buffer.append(log)

    def flush_buffer(self):
        for log in self.logs_buffer:
            self._record_and_log(
                level=log.level,
                message=log.message,
                location=log.location,
                doc=log.doc,
                exception=log.exception
            )
            self.logs.append(log)
        self.logs_buffer = []

    def error_into_buffer(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
    ):
        self.log_into_buffer(LogLevel.ERROR, message, location, doc, exception)

    def warning_into_buffer(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
    ):
        self.log_into_buffer(LogLevel.WARNING, message, location, doc, exception)

    def info_into_buffer(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
    ):
        self.log_into_buffer(LogLevel.INFO, message, location, doc, exception)

    def debug_into_buffer(
        self,
        message: str,
        location: Optional[Location] = None,
        doc: Optional[str] = None,
        exception: Optional[BaseException] = None,
    ):
        if self.verbose:
            self.log_into_buffer(LogLevel.DEBUG, message, location, doc, exception)

    def log_message_present(self, message: str, full_match: bool = False) -> bool:
        for log in self.logs:
            if full_match and log.message == message:
                return True
            elif not full_match and message in log.message:
                return True
        return False

