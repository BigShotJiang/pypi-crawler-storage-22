# --- Alation Change ---
# These utilities are a port of parsing Fully qualified
# names for schema, table and columns.

def parse_qualified_name(name):
	"""Parse qualified names. SQLServer can have 3 or 4 levels.
	Ex.
	>>> parse_qualified_name('schema.table')
	('schema', 'table')
	>>> parse_qualified_name('table')
	(None, 'table')
	"""
	schema_name = None
	table_name = None
	parts = universal_identifier_split(name)
	parts = [part.strip() for part in parts]
	if len(parts) == 1:
		table_name = parts[0]
	elif len(parts) == 2:
		schema_name, table_name = parts
	elif len(parts) >= 3:
		table_name = parts[-1]
		schema_name = ".".join(parts[:-1])
	return schema_name, table_name

def universal_identifier_split(text):
	"""
	Split database identifier names. Handles quoting with double quotes or with brackets.
	Handles escaping with '\' or with an extra quote character.
	"""
	UNQUOTED = 0
	IN_QUOTES = 1
	QUOTE_IN_QUOTES = 2
	ESCAPE_IN_QUOTES = 3

	if not isinstance(text, str):
		text = text.decode('utf-8', 'ignore')
	parts = []
	result = ''
	state = UNQUOTED
	current_quote_char = '"'
	for char in text:
		if char in ('.', ':'):
			if state == UNQUOTED:
				parts.append(result)
				result = ''
				continue
			if state in (IN_QUOTES, ESCAPE_IN_QUOTES):
				result += char
				state = IN_QUOTES
				continue
			if state == QUOTE_IN_QUOTES:
				state = UNQUOTED
				parts.append(result)
				result = ''
				continue
		if char in ('"', '[', ']'):
			if state == UNQUOTED:
				state = IN_QUOTES
				current_quote_char = char
				continue
			if state == IN_QUOTES:
				if ((current_quote_char == '[' and char == ']') or
						(current_quote_char == '"' and char == '"')):
					state = QUOTE_IN_QUOTES
					continue
				result += char
				continue
			if state == QUOTE_IN_QUOTES:
				if ((current_quote_char == '[' and char == ']') or
						(current_quote_char == '"' and char == '"')):
					state = IN_QUOTES
					result += char
				state = IN_QUOTES
				continue
			if state == ESCAPE_IN_QUOTES:
				result += char
				state = IN_QUOTES
				continue
		if char == '\\':
			if state == IN_QUOTES:
				state = ESCAPE_IN_QUOTES
				continue
			if state == QUOTE_IN_QUOTES:
				state = UNQUOTED
				result += char
				continue
			state = UNQUOTED
			result += char
			continue
		if state == ESCAPE_IN_QUOTES:
			state = IN_QUOTES
		if state == QUOTE_IN_QUOTES:
			state = IN_QUOTES
		result += char
	parts.append(result)
	return parts

