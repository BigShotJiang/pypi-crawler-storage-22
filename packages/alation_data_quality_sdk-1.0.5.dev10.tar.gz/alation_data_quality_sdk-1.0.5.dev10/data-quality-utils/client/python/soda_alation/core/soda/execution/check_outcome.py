from enum import Enum


class CheckOutcome(Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    ERROR = "error"

    def __str__(self):
        return self.name
