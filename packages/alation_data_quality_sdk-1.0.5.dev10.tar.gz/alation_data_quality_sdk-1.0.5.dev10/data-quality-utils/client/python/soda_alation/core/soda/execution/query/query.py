from __future__ import annotations

import time
from datetime import datetime, timedelta

from soda.common.exception_helper import get_exception_stacktrace
from soda.common.memory_safe_cursor_fetcher import MemorySafeCursorFetcher
from soda.common.query_helper import parse_columns_from_query
from soda.common.string_helper import strip_quotes
from soda.common.undefined_instance import undefined
from soda.sampler.db_sample import DbSample
from soda.sampler.sample_context import SampleContext
from soda.sampler.sampler import Sampler
from queryservice_client.queryclient import run_query

from typing import Union
import json

class Query:
    _counter = 0

    @classmethod
    def generate_id(cls):
        cls._counter += 1
        return cls._counter

    def __init__(
        self,
        data_source_scan: DataSourceScan,
        table: Table = None,
        partition: Partition = None,
        column: Column = None,
        unqualified_query_name: str = None,
        sql: str | None = None,
        sample_name: str = "failed_rows",
        location: Location | None = None,
        samples_limit: int | None = None,
    ):
        self.logs = data_source_scan.scan._logs
        self.data_source_scan = data_source_scan
        self.query_name: str = Query.build_query_name(
            data_source_scan, table, partition, column, unqualified_query_name
        )
        self.sample_name = sample_name
        self.table: Table | None = table
        self.partition: Partition | None = partition
        self.column: Column | None = column
        self.location: Location | None = location
        self.samples_limit: int | None = samples_limit

        # The SQL query that is used _fetchone or _fetchall or _store
        # This field can also be initialized in the execute method before any of _fetchone,
        # _fetchall or _store are called
        self.sql: str = data_source_scan.scan.jinja_resolve(sql)

        self.passing_sql: str | None = None
        self.failing_sql: str | None = None

        self.failing_rows_sql_aggregated: str | None = None

        # Following fields are initialized in execute method
        self.description: tuple | None = None
        self.row: tuple | None = None
        self.rows: list[tuple] | None = None
        self.row_count: int | None = None
        self.sample_ref: SampleRef | None = None
        self.exception: BaseException | None = None
        self.duration: timedelta | None = None
        self.query_execution_column = None
        self.sample_query_execution_column = None
        self.sample_description: tuple | None = None


    def set_logger(self, logger: any):
        """
        Sets the logger to be used by the query.
        """
        self.logger = logger

    def get_cloud_dicts(self) -> list(dict(str, any)):
        dicts = [self.get_dict()]

        if self.failing_sql:
            dicts.append(self.get_dict("failing_sql", self.failing_sql))

        if self.passing_sql:
            dicts.append(self.get_dict("passing_sql", self.passing_sql))

        if self.failing_rows_sql_aggregated:
            dicts.append(self.get_dict("failing_rows_sql_aggregated", self.failing_rows_sql_aggregated))

        return dicts

    def get_dict(self, name_suffix: str | None = None, sql: str | None = None) -> dict:
        from soda.execution.column import Column
        from soda.execution.partition import Partition

        name = self.query_name

        if name_suffix:
            name += f".{name_suffix}"
        return {
            "name": name,
            "dataSource": self.data_source_scan.data_source.data_source_name,
            "table": strip_quotes(Partition.get_table_name(self.partition)),
            "partition": Partition.get_partition_name(self.partition),
            "column": Column.get_partition_name(self.column),
            "sql": sql or self.sql,
            "exception": None if name_suffix or sql else get_exception_stacktrace(self.exception),
            "duration": None if name_suffix or sql else self.duration,
        }
    
    def get_sql(self) -> str:
        """
        Returns the SQL query string.
        If the SQL is not set, it raises an exception.
        """
        if self.sql is None:
            ""
        return self.sql
    
    def get_duration(self) -> Union[timedelta, None]:
        """
        Returns the duration of the query execution.
        If the duration is not set, it returns None.
        """
        return self.duration

    @staticmethod
    def build_query_name(data_source_scan, table, partition, column, unqualified_query_name):
        full_query_pieces = [str(Query.generate_id()), data_source_scan.data_source.data_source_name]
        if partition is not None and partition.partition_name is not None:
            full_query_pieces.append(f"{partition.table.table_name}[{partition.partition_name}]")
        elif partition is not None and partition.partition_name is None:
            full_query_pieces.append(f"{partition.table.table_name}")
        elif table is not None:
            full_query_pieces.append(f"{table.table_name}")
        if column is not None:
            full_query_pieces.append(f"{column.column_name}")
        full_query_pieces.append(unqualified_query_name)
        return ".".join(full_query_pieces)

    def execute(self):
        """
        Execute method implementations should
          - invoke either self.fetchone, self.fetchall or self.store
          - update the metrics with value and optionally other diagnostic information
        If queries are not intended to return any data, use the QueryWithoutResults class.
        """
        # TODO: some of the subclasses couple setting metric with storing the sample - refactor that.
        try:
            self.fetchall()
        except Exception as e:
            if hasattr(self, "metric") and self.metric:
                message = self.get_exception_message(e, self.logger)
                self.metric.set_error_message(message)
            return

    def _cursor_execute_exception_handler(self, e):
        data_source = self.data_source_scan.data_source
        self.exception = e
        self.logs.error(
            message=f"Query execution error in {self.query_name}: {e}\n{self.sql}",
            exception=e,
            location=self.location,
        )
        data_source.query_failed(e)

    def _execute_cursor(self, execute=True):
        """
        Execute the SQL query and yield the cursor for further processing.
        """
        self.__append_to_scan()
        start = datetime.now()
        data_source = self.data_source_scan.data_source
        try:
            cursor = data_source.connection.cursor()
            try:
                self.logs.debug(f"Query {self.query_name}:\n{self.sql}")
                if execute:
                    cursor.execute(self.sql)
                self.description = cursor.description
                yield cursor
            finally:
                # Some DB implementations, like MYSQL, require the cursor's results to be
                # read before closing. This is not always the case so we want to make sure
                # results are reset when possible.
                if hasattr(cursor, "reset"):
                    cursor.reset()
                cursor.close()
        except BaseException as e:
            self._cursor_execute_exception_handler(e)
        finally:
            self.duration = datetime.now() - start

    def fetchone(self):
        """
        DataSource query execution exceptions will be caught and result in the
        self.exception being populated.
        """
        # Check if OCF configuration is available for custom query service client
        connector_metadata = getattr(self.data_source_scan.scan, '_ocf_configuration', None)

        if connector_metadata:
            # Use custom query service client (existing flow)
            start_time = time.time()
            self.query_execution_column, self.row_list = run_query(connector_metadata, self.sql, self.logger)
            end_time = time.time()

            elapsed_seconds = end_time - start_time
            self.duration = timedelta(seconds=elapsed_seconds)

            # Check for None and empty list for getting first row
            self.row = self.row_list[0] if self.row_list else None

            self._create_description()
            self.row_count = 1 if self.row is not None or self.rows != [] else 0
        else:
            # Use standard Soda direct database connection
            # Ensure connection is established
            data_source = self.data_source_scan.data_source

            if not hasattr(data_source, 'connection') or data_source.connection is None:
                # Fix credentials: use the ones from the 'connection' block instead of top-level mock values
                if 'connection' in data_source.data_source_properties:
                    conn_props = data_source.data_source_properties['connection']
                    # Override the top-level properties with correct ones from connection block
                    for key, value in conn_props.items():
                        data_source.data_source_properties[key] = value

                    # Also set username if it exists
                    if 'user' in conn_props:
                        data_source.data_source_properties['username'] = conn_props['user']

                    # Set credentials directly on the data_source object
                    if 'password' in conn_props:
                        data_source.password = conn_props['password']
                    if 'user' in conn_props:
                        data_source.user = conn_props['user']
                        data_source.username = conn_props['user']

                data_source.connect()

            for cursor in self._execute_cursor():
                self.row = cursor.fetchone()
                self.row_count = 1 if self.row is not None else 0

    def fetchall(self):
        """
        DataSource query execution exceptions will be caught and result in the
        self.exception being populated.
        """
        # Check if OCF configuration is available for custom query service client
        connector_metadata = getattr(self.data_source_scan.scan, '_ocf_configuration', None)

        if connector_metadata:
            # Use custom query service client (existing flow)
            start_time = time.time()
            self.query_execution_column, self.rows = run_query(connector_metadata, self.sql, self.logger)
            end_time = time.time()

            elapsed_seconds = end_time - start_time
            self.duration = timedelta(seconds=elapsed_seconds)

            self._create_description()
            self.row_count = len(self.rows) if self.rows is not None or self.rows != [] else 0
        else:
            # Use standard Soda direct database connection
            # Ensure connection is established
            data_source = self.data_source_scan.data_source

            if not hasattr(data_source, 'connection') or data_source.connection is None:
                # Fix credentials: use the ones from the 'connection' block instead of top-level mock values
                if 'connection' in data_source.data_source_properties:
                    conn_props = data_source.data_source_properties['connection']
                    # Override the top-level properties with correct ones from connection block
                    for key, value in conn_props.items():
                        data_source.data_source_properties[key] = value

                    # Also set username if it exists
                    if 'user' in conn_props:
                        data_source.data_source_properties['username'] = conn_props['user']

                    # Set credentials directly on the data_source object
                    if 'password' in conn_props:
                        data_source.password = conn_props['password']
                    if 'user' in conn_props:
                        data_source.user = conn_props['user']
                        data_source.username = conn_props['user']

                data_source.connect()

            for cursor in self._execute_cursor():
                safe_fetcher = MemorySafeCursorFetcher(cursor)
                self.rows = safe_fetcher.get_rows()
                self.row_count = safe_fetcher.get_row_count()

    def _create_description(self):
        description_list = []
        if hasattr(self, 'query_execution_column') and self.query_execution_column:
            for column in self.query_execution_column:
                column_description = (column, None, None, None, None, None, None)
                description_list.append(column_description)
        self.description = tuple(description_list)  

    def _create_sample_description(self):
        description_list = []
        if hasattr(self, 'sample_query_execution_column') and self.sample_query_execution_column: 
            for column in self.sample_query_execution_column:
                column_description = (column, None, None, None, None, None, None)
                description_list.append(column_description)   
        self.sample_description = tuple(description_list)  

    def store(self):
        """
        Used for setting the metric value.
        """

        # A bit of a hacky workaround for queries that also set the metric in one go.
        # TODO: revisit after decoupling getting metric values and storing samples. This can be dangerous, it sets the metric value
        # only when metric value is not set, but this could cause weird regressions.
        set_metric = False
        if hasattr(self, "metric") and self.metric and self.metric.value == undefined:
            set_metric = True

        if set_metric:
            self.metric.set_value(self.row_count if self.row_count else 0)

        if hasattr(self, "metric") and self.metric:
            self.metric.set_sample_failed_rows_query(self.sql)    

        '''
        sampler: Sampler = self.data_source_scan.scan._configuration.sampler
        allow_samples = True
        offending_columns = []

        check_name = next(iter(self.metric.checks)).name if hasattr(self, "metric") else None
        self.logs.debug(f"Check name: {check_name}: \nQuery: {self.sql}")

        if self.partition and self.partition.table:
            query_columns = parse_columns_from_query(self.sql)

            if query_columns:
                self.logs.debug(f"Partition enabled Query {self.query_name} columns: {query_columns}")
            for column in query_columns:
                if self.data_source_scan.data_source.is_column_excluded(self.partition.table.table_name, column):
                    allow_samples = False
                    offending_columns.append(column)
            if offending_columns:
                self.logs.info(
                    f"Query {self.query_name} is excluded from sample collection due to offending columns: {offending_columns}"
                )
                return

            # A bit of a hacky workaround for queries that also set the metric in one go.
            # TODO: revisit after decoupling getting metric values and storing samples. This can be dangerous, it sets the metric value
            # only when metric value is not set, but this could cause weird regressions.
        set_metric = False
        if hasattr(self, "metric") and self.metric and self.metric.value == undefined:
            set_metric = True

        self.logs.debug(f"Query {self.query_name} will {'set metric and ' if set_metric else ''}store samples: {allow_samples}")
        try:
            if set_metric or allow_samples:
                check_name = next(iter(self.metric.checks)).name if hasattr(self, "metric") else None
                self.logs.debug(f"Executing query {self.query_name} for sample collection, for check {check_name}: \n{self.sql}")
                connector_metadata = self.data_source_scan.scan._ocf_configuration
                start_time = time.time()
                self.sample_query_execution_column, sample_row_list = run_query(connector_metadata, self.sql, self.logger)
                end_time = time.time()

                elapsed_seconds = end_time - start_time
                self.duration = timedelta(seconds=elapsed_seconds)
                self._create_sample_description()
                db_sample = DbSample(sample_row_list, self.sample_description, self.data_source_scan.data_source, self.samples_limit)

            if set_metric:
                self.metric.set_value(db_sample.get_rows_count())

            if allow_samples:
                # TODO Hacky way to get the check name, check name isn't there when dataset samples are taken
                check_name = next(iter(self.metric.checks)).name if hasattr(self, "metric") else None
                sample_context = SampleContext(
                    sample=db_sample,
                    sample_name=self.sample_name,
                    query=self.sql,
                    data_source=self.data_source_scan.data_source,
                    partition=self.partition,
                    column=self.column,
                    scan=self.data_source_scan.scan,
                    logs=self.data_source_scan.scan._logs,
                    samples_limit=self.samples_limit,
                    passing_sql=self.passing_sql,
                    check_name=check_name,
                )

                self.sample_ref = sampler.store_sample(sample_context)
            else:
                self.logs.info(
                    f"Skipping samples from query '{self.query_name}'. Excluded column(s) present: {offending_columns}."
                )
        except BaseException as e:
            self._cursor_execute_exception_handler(e)
        '''

    def __append_to_scan(self):
        scan = self.data_source_scan.scan
        self.index = len(scan._queries)
        scan._queries.append(self)


    @staticmethod
    def get_exception_message(e: Exception, logger: any) -> str:
        message = f"{e}"
        # Try extracting gRPC error message if available
        try:
            if hasattr(e, "details"):
                details = e.details()
                logger.debug(f"Raw gRPC details: {details}")
                try:
                    parsed = json.loads(details)
                    message = parsed.get("message")
                    if message:
                        logger.debug(f"Parsed error message: {message}")
                    else:
                        logger.warn("'message' field not found in parsed details.")
                except json.JSONDecodeError:
                    logger.warn("Could not parse details as JSON.")
        except Exception as nested:
            pass
        return message
