from __future__ import annotations

from soda.execution.metric.metric import Metric
from soda.execution.query.query import Query


class UserDefinedNumericQuery(Query):
    def __init__(
        self,
        data_source_scan: DataSourceScan,
        check_name: str,
        sql: str,
        metric: Metric,
    ):
        super().__init__(
            data_source_scan=data_source_scan, unqualified_query_name=f"user_defined_query[{check_name}]", sql=sql
        )
        self.metric = metric

    def execute(self):
        try:
            self.fetchone()
        except Exception as e:
            # Generic/query execution failures in fetching
            message = self.get_exception_message(e, self.logger)
            self.metric.set_error_message(message)
            return

        if self.row is None:
            return

        # Loop over returned columns and convert to float
        for index, val in enumerate(self.row):
            if val is None:
                continue
            try:
                metric_value = float(val)
            except (TypeError, ValueError) as e:
                # Building a clear, actionable error for metric
                col_name = (
                    self.description[index][0]
                    if self.description and len(self.description) > index
                    else f"col_{index}"
                )
                custom = f"""Projection list in query returned a non-numeric value.
                            Column: {col_name}
                            Value: {val!r}
                            The metric only accepts numeric results.

                            Suggestion: Use a numeric aggregate function (e.g., SUM/AVG/COUNT) or CAST(... AS DOUBLE/NUMERIC) in the projection list."""
                self.metric.set_error_message(custom)

                # Log full stacktrace so that it can be used for error reporting
                self.logger.exception(
                    "Conversion to float failed for column=%s value=%r", col_name, val
                )
                return

            # Only set the metric if conversion succeeded
            self.metric.set_value(metric_value)

        # Optionally run the sample query only if no errors occurred
        sample_query = self.metric.create_failed_rows_sample_query()
        if sample_query:
            self.metric.queries.append(sample_query)
            sample_query.execute()
