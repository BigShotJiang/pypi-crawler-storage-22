
from soda.sampler.sample_context import SampleContext
from soda.sampler.sampler import Sampler

class AlationSampler(Sampler):
    def store_sample(self, sample_context: SampleContext):
        # Retrieve the rows from the sample for a check
        rows = sample_context.sample.get_rows()
        # Check SampleContext for more details that you can extract
        # This example simply prints the failed row samples
        print("Starting Alation sample storage...")
        print(sample_context.query)
        print(sample_context.sample.get_schema())
        print(rows)
        print("Alation sample storage completed.")