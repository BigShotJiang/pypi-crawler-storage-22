from typing import Tuple

from soda.common.memory_safe_cursor_fetcher import MemorySafeCursorFetcher
from soda.sampler.sample import Sample
from soda.sampler.sample_schema import SampleColumn, SampleSchema


class DbSample(Sample):
    def __init__(self, row_list, query_description, data_source, limit=None):
        self.row_list = row_list
        self.query_description = query_description
        self.data_source = data_source
        self.rows = None
        self._limit = limit

    def get_rows(self) -> Tuple[Tuple]:
        return self.row_list

    def get_rows_count(self) -> int:
        return len(self.row_list)

    def get_schema(self) -> SampleSchema:
        return self._convert_python_db_schema_to_sample_schema(self.query_description)

    def _convert_python_db_schema_to_sample_schema(self, dbapi_description) -> SampleSchema:
        columns = SampleColumn.create_sample_columns(dbapi_description, self.data_source)
        return SampleSchema(columns=columns)
