from __future__ import annotations

import logging
import os
from typing import Any

import pytest
import requests
from dotenv import load_dotenv
from helpers.data_source_fixture import DataSourceFixture
from helpers.mock_file_system import MockFileSystem
from helpers.mock_http_request import MockHttpRequest
from pytest import MonkeyPatch
from soda.common.file_system import FileSystemSingleton
from soda.common.logs import Logs, configure_logging

logger = logging.getLogger(__name__)

# Load local env file so that test data sources can be set up.
project_root_dir = __file__[: -len("soda/core/tests/helpers/fixtures.py")]
load_dotenv(f"{project_root_dir}/.env", override=True)

# In global scope because it is used in pytest annotations, it would not work as a fixture.
test_data_source = os.getenv("test_data_source", "postgres")

logs = Logs()


def pytest_sessionstart(session: Any) -> None:
    configure_logging()


def pytest_runtest_logstart(nodeid: str, location: tuple[str, int | None, str]) -> None:
    """
    Prints the test function name and the location in a format that PyCharm recognizes and turns into a link in the console
    """
    logging.debug(f'### "soda/core/tests/{location[0]}:{(location[1]+1)}" {location[2]}')


@pytest.fixture(scope="session")
def data_source_fixture():
    data_source_fixture = DataSourceFixture._create()
    data_source_fixture._test_session_starts()
    yield data_source_fixture
    data_source_fixture._test_session_ends()


@pytest.fixture
def mock_file_system():
    """
    Fixture that swaps the file_system() with an in-memory, mock version
    Usage:

    def test_mytest_with_mock_file_system(mock_file_system):
        mock_file_system.files = {
          '~/.soda/configuration.yml': '...content of the file...',
          '/project/mytable.soql.yml': '...content of the file...'
        }

        # Now file system will use the given the in memory string files above instead of using the real file system
        file_system().exists('~/.soda/configuration.yml') -> True
    """
    original_file_system = FileSystemSingleton.INSTANCE
    FileSystemSingleton.INSTANCE = MockFileSystem()
    yield FileSystemSingleton.INSTANCE
    FileSystemSingleton.INSTANCE = original_file_system


@pytest.fixture
def mock_http_post_request(monkeypatch: MonkeyPatch):
    mock_http_request: MockHttpRequest = MockHttpRequest._create()
    monkeypatch.setattr(requests, "post", mock_http_request.mock_post)
    yield mock_http_request


@pytest.fixture(autouse=True)
def clean_logs_before_tests():
    logs.reset()
    yield


@pytest.fixture(scope="function")
def environ():
    original_environ = os.environ.copy()
    yield os.environ
    os.environ.clear()
    os.environ.update(original_environ)


def format_query_one_line(query: str) -> str:
    """@TODO: implement"""
    return query
