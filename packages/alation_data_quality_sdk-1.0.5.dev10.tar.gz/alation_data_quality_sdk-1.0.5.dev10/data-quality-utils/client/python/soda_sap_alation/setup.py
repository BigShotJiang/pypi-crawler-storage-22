#!/usr/bin/env python
import os
from setuptools import find_namespace_packages, setup

package_name = "soda-core-sap-hana"
package_version = "3.4.4"
description = "Soda Core SAP HANA Package"

def get_version():
    build_number = os.getenv('BUILD_NUMBER', "0")
    return f"{package_version}+{build_number}"

requires = [f"soda-core=={package_version}"]
# TODO Fix the params
setup(
    name=package_name,
    version=get_version(),
    install_requires=requires,
    packages=find_namespace_packages(include=["soda*"]),
)