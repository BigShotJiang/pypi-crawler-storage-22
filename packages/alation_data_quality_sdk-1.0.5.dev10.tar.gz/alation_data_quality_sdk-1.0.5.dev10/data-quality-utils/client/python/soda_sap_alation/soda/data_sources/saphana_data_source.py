
from __future__ import annotations

import logging

from soda.execution.data_source import DataSource
from soda.execution.data_type import DataType
# from soda.contracts.impl.contract_data_source import FileClContractDataSource
# from soda.contracts.impl.sql_dialect import SqlDialect
# from soda.contracts.impl.yaml_helper import YamlFile

logger = logging.getLogger(__name__)


class SaphanaDataSource(DataSource):
    TYPE = "saphana"

    SCHEMA_CHECK_TYPES_MAPPING: dict = {
        "VARCHAR": ["varchar", "nvarchar", "alphanum", "shorttext"],
        "INTEGER": ["tinyint", "smallint", "integer", "bigint"],
        "DECIMAL": ["decimal", "numeric"],
        "FLOAT": ["float", "real", "double"],
        "DATE": ["date"],
        "TIME": ["time"],
        "TIMESTAMP": ["timestamp", "seconddate"],
        "BOOLEAN": ["boolean"],
    }

    SQL_TYPE_FOR_CREATE_TABLE_MAP: dict = {
        DataType.TEXT: "VARCHAR(255)",
        DataType.INTEGER: "INTEGER",
        DataType.DECIMAL: "DECIMAL(18,2)",
        DataType.DATE: "DATE",
        DataType.TIME: "TIME",
        DataType.TIMESTAMP: "TIMESTAMP",
        DataType.TIMESTAMP_TZ: "TIMESTAMP",
        DataType.BOOLEAN: "BOOLEAN",
    }

    # Supported data types as returned by the given data source when retrieving dataset schema. Used in schema checks.
    SQL_TYPE_FOR_SCHEMA_CHECK_MAP = SQL_TYPE_FOR_CREATE_TABLE_MAP

    NUMERIC_TYPES_FOR_PROFILING = [
        "FLOAT", "DECIMAL", "NUMERIC", "INTEGER", "BIGINT", "SMALLINT", "TINYINT", "REAL", "DOUBLE"
    ]
    TEXT_TYPES_FOR_PROFILING = [
        "VARCHAR", "NVARCHAR", "ALPHANUM", "TEXT", "CLOB", "NCLOB", "SHORTTEXT"
    ]

    def __init__(self, logs, data_source_name, data_source_properties):
        super().__init__(logs, data_source_name, data_source_properties)
        self.host = data_source_properties.get("host")
        self.port = data_source_properties.get("port")
        self.user = data_source_properties.get("username")
        self.password = data_source_properties.get("password")
        self.database = data_source_properties.get("database")
        # schema is managed by base class; ensure prefix recalculation
        self.table_prefix = self._create_table_prefix()

    def connect(self):
        """Initialize a PEP 249 connection using SAP HANA DB-API (hdbcli)."""
        try:
            from hdbcli import dbapi  # type: ignore

            # Empty password should be treated as None
            password = self.password if self.password else None

            # HANA DB-API uses address/port/user/password, optional databaseName for tenant DB
            self.logs.debug(
                f'SAP HANA connection properties: host="{self.host}", port="{self.port}", database="{self.database}", user="{self.user}"'
            )

            kwargs = {
                "address": self.host,
                "port": int(self.port) if self.port else None,
                "user": self.user,
                "password": password,
            }
            if self.database:
                kwargs["databaseName"] = self.database

            self.connection = dbapi.connect(**kwargs)
            return self.connection
        except Exception as e:
            # Let Soda handle and log the failure
            self.logs.error(f"Failed to connect to SAP HANA: {e}")
            raise

    def sql_test_connection(self) -> str:
        return "SELECT 1 FROM DUMMY"

    # def escape_regex(self, value: str):
    #     return value.replace("\\", "\\\\")

    def regex_replace_flags(self) -> str:
        return ""

    def expr_regexp_like(self, expr: str, pattern: str):
        return f"{expr} LIKE_REGEXPR '{pattern}'"
    
    def expr_count_conditional(self, condition: str) -> str:
        """
        Override to ensure COUNT only counts conditionally matched rows,
        and avoids SAP HANA syntax errors for CASE without ELSE.
        """
        return f"COUNT(CASE WHEN {condition} THEN 1 ELSE NULL END)"

    def cast_text_to_number(self, column_name, validity_format: str):
        return f"CAST({column_name} AS DECIMAL(18,2))"

    def get_metric_sql_aggregation_expression(self, metric_name: str, metric_args: list[object] | None, expr: str):
        if metric_name in ["stddev", "stddev_pop", "stddev_samp", "variance", "var_pop", "var_samp"]:
            return f"{metric_name.upper()}({expr})"
        if metric_name in ["percentile", "percentile_disc"]:
            # SAP HANA does not support percentile_disc directly
            raise NotImplementedError("Percentile functions are not supported in SAP HANA dialect.")
        return super().get_metric_sql_aggregation_expression(metric_name, metric_args, expr)

    def sql_get_table_names_with_count(self, include_tables=None, exclude_tables=None):
        where_clauses = ["SCHEMA_NAME != 'SYS'"]

        # apply schema filter if provided
        if getattr(self, "schema", None):
            where_clauses.append(
                f"SCHEMA_NAME = '{self.default_casify_system_name(self.schema)}'"
            )

        # includes/excludes using helper
        table_filter = self.sql_table_include_exclude_filter(
            "TABLE_NAME", "SCHEMA_NAME", include_tables or [], exclude_tables or []
        )
        if table_filter:
            where_clauses.append(table_filter)

        where_sql = " AND ".join(where_clauses)
        return (
            "SELECT TABLE_NAME, RECORD_COUNT\n"
            "FROM M_TABLES\n"
            f"WHERE {where_sql}"
        )

    def quote_table(self, table_name: str) -> str:
        return f'"{table_name}"'

    def quote_column(self, column_name: str) -> str:
        return f'"{column_name}"'

    def default_casify_sql_function(self) -> str:
        return "upper"

    def default_casify_system_name(self, identifier: str) -> str:
        return identifier.upper()

    def default_casify_table_name(self, identifier: str) -> str:
        return identifier.upper()

    def default_casify_column_name(self, identifier: str) -> str:
        return identifier.upper()

    def default_casify_type_name(self, identifier: str) -> str:
        return identifier.upper()

    def safe_connection_data(self):
        return [self.type, self.host, self.database]

    # Metadata column mapping overrides (INFORMATION_SCHEMA in HANA uses uppercase names)
    @staticmethod
    def column_metadata_columns() -> list:
        return ["COLUMN_NAME", "DATA_TYPE_NAME", "IS_NULLABLE"]

    @staticmethod
    def column_metadata_table_name() -> str:
        return "TABLE_NAME"

    @staticmethod
    def column_metadata_schema_name() -> str:
        return "TABLE_SCHEMA"

    @staticmethod
    def column_metadata_column_name() -> str:
        return "COLUMN_NAME"

    @staticmethod
    def column_metadata_datatype_name() -> str:
        return "DATA_TYPE_NAME"

    def use_database_in_filter(self) -> bool:
        # HANA typically doesn't use TABLE_CATALOG for filtering
        return False

    def sql_information_schema_tables(self) -> str:
        return "INFORMATION_SCHEMA.TABLES"

    def sql_information_schema_columns(self) -> str:
        return "INFORMATION_SCHEMA.COLUMNS"

    def _create_table_prefix(self):
        # Quote schema to preserve case and special characters
        if self.schema:
            return f'"{self.schema}"'
        return None

    def sql_analyze_table(self, table: str) -> str:
        # Update statistics to keep metadata like RECORD_COUNT current
        return f"UPDATE STATISTICS {table}"
    
# class SapHanaSqlDialect(SqlDialect):
#     def _get_create_table_sql_type_dict(self):
#         return SapHanaDataSource.SQL_TYPE_FOR_CREATE_TABLE_MAP

#     def _get_schema_check_sql_type_dict(self):
#         return SapHanaDataSource.SQL_TYPE_FOR_SCHEMA_CHECK_MAP

#     def stmt_drop_schema_if_exists(self, database_name: str, schema_name: str) -> str:
#         return f"DROP SCHEMA \"{schema_name}\" CASCADE"

#     def stmt_create_schema_if_not_exists(self, database_name: str, schema_name: str) -> str:
#         return f"CREATE SCHEMA IF NOT EXISTS \"{schema_name}\""

#     def escape_regex(self, value: str):
#         return value.replace("\\", "\\\\")

#     def regex_replace_flags(self) -> str:
#         return ""

#     def expr_regexp_like(self, expr: str, pattern: str):
#         return f"{expr} LIKE_REGEXPR '{pattern}'"

#     def cast_text_to_number(self, column_name, validity_format: str):
#         return f"CAST({column_name} AS DECIMAL(18,2))"

#     def sql_get_table_names_with_count(self, include_tables=None, exclude_tables=None):
#         return """
#             SELECT TABLE_NAME, RECORD_COUNT
#             FROM M_TABLES
#             WHERE SCHEMA_NAME != 'SYS'
#         """

#     def default_casify(self, identifier: str) -> str:
#         return identifier.upper()


# class SapHanaContractDataSource(FileClContractDataSource):
#     def __init__(self, data_source_yaml_file: YamlFile):
#         super().__init__(data_source_yaml_file)

#     def _create_sql_dialect(self) -> SqlDialect:
#         return SapHanaSqlDialect()

#     def _create_connection(self, connection_yaml_dict: dict):
#         self._log_connection_properties_excl_pwd("sap_hana", connection_yaml_dict)
#         return
