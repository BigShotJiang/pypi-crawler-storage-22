# AlayaFlow

A desktop platform for executing LangGraph workflows with multiple executors.

## 简介

AlayaFlow 是一个桌面平台，用于执行 LangGraph 工作流。


## 安装

### 从 PyPI 安装（推荐）

```bash
pip install alayaflow
```

### 从源码安装

```bash
git clone git@github.com:AlayaDB-AI/AlayaFlow.git
cd alayaflow
pip install -e .
```

## 系统要求

- Python >= 3.10
- uv (Rust-based Python package installer)

## 使用示例

```python
from alayaflow.workflow import WorkflowManager, WorkflowLoader

# 创建工作流管理器
manager = WorkflowManager()

# 加载工作流
manager.load_workflow(workflow_id="my-workflow", version="1.0.0")

# 执行工作流...
```

## 配置

项目支持通过 `.env` 文件进行配置。主要配置项包括：

- `dev_mode`: 开发模式（dev/dev-uneditable/prod）
- `alayahub_url`: AlayaHub API 地址
- `langfuse_enabled`: 是否启用 Langfuse 追踪
- 各种存储路径配置

## 开发

### 安装开发依赖

```bash
pip install -e ".[dev]"
```

### 运行测试

```bash
pytest
```

## 许可证

本项目采用 MIT License。详情请参阅 [LICENSE](LICENSE) 文件。

## 贡献

欢迎提交 Issue 和 Pull Request！

## 相关链接

- [LangGraph](https://github.com/langchain-ai/langgraph)
- [uv](https://github.com/astral-sh/uv)
