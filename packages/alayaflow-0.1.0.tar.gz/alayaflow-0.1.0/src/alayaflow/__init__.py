"""AlayaFlow - A desktop platform for executing LangGraph workflows with multiple executors."""


__version__ = "0.1.0"

