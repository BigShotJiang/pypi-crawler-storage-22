from abc import ABC, abstractmethod
from typing import Dict, List, Any

class BaseAlayaMemClient(ABC):
    @abstractmethod
    def init_session(self, user_id: str, session_id: str) -> Dict:
        pass

    @abstractmethod
    def vdb_query(self, messages: List[Any], limit: int) -> Dict:
        pass

    @abstractmethod
    def add_session_messages(self, user_id: str, session_id: str, messages: List[Any]) -> None:
        pass

    @abstractmethod
    def query(self, user_id: str, session_id: str, message: Any) -> Dict:
        pass