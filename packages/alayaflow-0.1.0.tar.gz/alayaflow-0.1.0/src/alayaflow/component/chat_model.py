import requests

from langchain_openai import ChatOpenAI

from alayaflow.common.config import settings

def mk_chat_model_deepseek():
    return ChatOpenAI(
        model="deepseek-chat",
        api_key="sk-4fe7cd96f5e948c79168025372e2327c",
        base_url="https://api.deepseek.com/v1",
    )

def mk_chat_model_jet(base_url: str, model_name: str):
    return ChatOpenAI(
        model=model_name,
        api_key="EMPTY",
        base_url=base_url,
    )

