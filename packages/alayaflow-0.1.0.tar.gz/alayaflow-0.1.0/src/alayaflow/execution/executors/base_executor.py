from abc import ABC, abstractmethod
from typing import Generator, Dict


class BaseExecutor(ABC):
    @abstractmethod
    def execute_stream(self, workflow_id: str, version: str, input_data: dict, config: dict) -> Generator[Dict, None, None]:
        pass

