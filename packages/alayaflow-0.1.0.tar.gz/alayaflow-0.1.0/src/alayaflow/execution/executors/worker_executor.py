from typing import Generator, Dict

from alayaflow.execution.executors.base_executor import BaseExecutor
from alayaflow.workflow.workflow_manager import WorkflowManager

class WorkerExecutor(BaseExecutor):
    def __init__(self, workflow_manager: WorkflowManager):
        self.workflow_manager = workflow_manager
    
    def execute_stream(self, workflow_id: str, version: str, input_data: dict, user_config: dict) -> Generator[Dict, None, None]:
        raise NotImplementedError("worker executor not supported yet")

