from abc import ABC
from typing import Dict, Generator

from alayaflow.workflow.workflow_info import WorkflowInfo

class BaseRunnableWorkflow(ABC):
    def __init__(self, info: WorkflowInfo) -> None:
        self._info = info

    @property
    def info(self) -> WorkflowInfo:
        return self._info

    def invoke(self, input_data: dict, user_config: dict) -> dict:
        raise NotImplementedError("invoke method must be implemented in derived classes")
    
    def astream_events(self, input_data: dict, user_config: dict) -> Generator[Dict, None, None]:
        raise NotImplementedError("invoke method must be implemented in derived classes")

