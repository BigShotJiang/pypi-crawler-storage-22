


# ============= alayamem test ===================
TEST_USER_ID = "user_1"
TEST_MESSAGES = [{"role": "user", "content": "唐博是谁"}]
TEST_LIMTT = 3
TEST_COLLECTION_NAME = "file_watcher_collection"

