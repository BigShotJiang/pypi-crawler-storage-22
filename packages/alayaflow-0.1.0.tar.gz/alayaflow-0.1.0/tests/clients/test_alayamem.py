import pytest
from alayaflow.component.memory import (
    query_vdb_message,
    init_memory,
    query_message,
    add_message
)
from .conftest import TEST_USER_ID, TEST_MESSAGES, TEST_LIMTT, TEST_COLLECTION_NAME

# Disable all mem test for now

# def test_query_vdb_message():
#     result = query_vdb_message(TEST_MESSAGES, TEST_LIMTT, TEST_COLLECTION_NAME)

#     assert result is not None
#     assert "vdb_results" in result
#     assert "vdb_response" in result
#     vdb_response = result["vdb_response"]
#     assert "documents" in vdb_response
#     assert "metadatas" in vdb_response
#     assert "distances" in vdb_response
#     assert vdb_response["documents"]
#     assert len(vdb_response["documents"]) > 0
#     assert len(vdb_response["documents"][0]) > 0


# def test_init_memory():
#     result = init_memory(TEST_USER_ID)

#     assert result is not None
#     assert result["status"] == "success"
#     assert TEST_USER_ID in result["message"]

# def test_add_message():
#     # 先初始化内存
#     init_memory(TEST_USER_ID)

#     result = add_message(TEST_USER_ID, TEST_MESSAGES)
#     # todo 


# def test_query_message():
#     init_memory(TEST_USER_ID)
#     # result = add_message(TEST_USER_ID, TEST_MESSAGES)
#     query_result = query_message(TEST_USER_ID, TEST_MESSAGES)
#     # todo 
#     print("query_result",query_result)
#     assert query_result is not None
#     assert "answer" in query_result
#     assert "tokens_used" in query_result
#     assert "retrieval_info" in query_result
#     assert query_result["retrieval_info"]





