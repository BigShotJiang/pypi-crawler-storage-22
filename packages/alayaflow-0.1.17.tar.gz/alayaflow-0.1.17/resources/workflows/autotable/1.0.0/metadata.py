from pathlib import Path

from alayaflow.workflow import WorkflowInfo

def get_metadata():
    meta = {
        "id": "autotable",
        "name": "Auto Table Filler",
        "description": "基于知识库的智能表格自动填写工作流",
        "version": "1.0.0",
        "tags": ["extraction", "table", "rag"],
        "entry_file": "workflow.py",
        "entry_point": "create_graph",
        "wf_dir": Path(__file__).parent
    }
    return WorkflowInfo(**meta)

