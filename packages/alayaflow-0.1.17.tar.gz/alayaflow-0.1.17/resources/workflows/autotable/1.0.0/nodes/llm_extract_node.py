import json
from threading import Semaphore

from langgraph.runtime import Runtime

from alayaflow.component.llm_node import LLMComponent, ResponseFormat

from ..schemas import TaskState, WorkflowContext
from ..utils import make_patch

# 全局信号量：控制 LLM 字段提取并发数
EXTRACT_LLM_SEMAPHORE = Semaphore(10)


def create_generate_node():
    def _build_system_prompt(keys: list[str]) -> str:
        # 这里只用于“提醒模型只输出这些key”，不用于构造复杂结构
        keys_str = ", ".join(keys)

        return f"""
            你是一个严谨的“表格字段抽取器”（table patch extractor）。
            你的任务：仅基于【用户记忆】与【知识库片段】抽取字段值；禁止猜测、补全或编造。

            # 字段格式说明
            输入字段列表采用特定格式：
            1. **【字段路径 Path】**
            - 类型：list[str]
            - 含义：表示字段在原始表格/表单结构中的层级位置。

            - 结构说明：
            - path[0] 表示最外层区块/章节标题（例如：表单中的一级栏目）
            - path[1] 表示其下的子区块/子表格
            - path[2] 表示更内层的子表格或字段分组
            - 数组的顺序表示从外到内的层级关系

            - 重要说明：
                Path 仅用于定位字段所在的结构位置；
                Path 本身不是需要填写的字段；
                不得在输出 JSON 中包含 Path。

            2. **【字段列表 Keys】**
            - 类型：list[str]
              例如：["姓名", "电话", "性别"]
            - 含义：
              字段列表定义了“当前字段路径（Path）下需要填写的字段集合”。
            - 重要说明：
              - 所有字段都属于当前 Path 所定位的结构层级。
              - 不存在嵌套字段结构。
              - 输出必须为扁平 JSON 对象（key → string）。

            ## 规则
            1. 字段名可能略有不同，智能匹配（"姓名"可能对应"姓 名"）
            2. 优先匹配完全相同的字段；匹配不到时，类似含义的字段可以匹配（例如"手机号"和"办公号码"），但不要匹配到不相关的字段。
            3. **关键 - 表格单元格理解（非常重要！）**：
            - 知识库每行用 " | " 分隔单元格
            - `<空>` 表示空单元格
            - **智能匹配规则**：
                * 字段名后面不一定是值！需要根据语义判断
                * 如果字段名后面是 `<空>`，该字段值为 ""
                * 如果字段名后面有其他字段名，继续找下一个非字段名的单元格
                * 示例：
                - "其它社会团体任职情况 | <空> | 组织名称及担任职务 | 内容"
                    → "其它社会团体任职情况" 后面是 `<空>` → ""
                    → "组织名称及担任职务" 后面是 "内容" → "内容"
                - "字段A | 字段B | 值" → "字段A" 后面是字段名 "字段B"，继续找 → "字段B" 后面是值 → "字段A"="", "字段B"="值"
            - **占位符识别**：如果单元格内容是模板占位符（如"签字： 年 月 日"、"组长签字： 年 月 日"、"学院盖章： 年 月 日"），应返回 ""
            - **空值判断**：
                * 字段后是 `<空>` → 返回 ""
                * 字段后是占位符/模板文本 → 返回 ""
                * 字段在知识库中找不到 → 返回 ""
            4. **长文本字段格式化（重要！）**：
            - 对于包含多个条目或时间序列的长文本字段（如"主要学习工作经历"、"学术成果及其他科技工作成绩"等），应使用格式化的列表形式返回
            - **推荐格式**：使用序号列表，每个条目一行，例如：
                * "1. 2008.09-2012.07 就读于四川省成都市四川大学\n2. 2012.09-2013.06 就读于安徽省合肥市中国科技大学\n3. ..."
            - 如果知识库中已经分行，优先保持原有分行格式
            - 如果是一段连续文本但包含多个时间节点或条目，应按条目拆分并以序号列表返回
            - 确保每个条目清晰独立，便于阅读
            5.多字段条目对齐规则（非常重要！）:
            - 当本次任务的多个字段来源于同一组条目且可能包含多个条目（例如科研项目表、工作经历表、论文列表等），应使用格式化的列表形式返回：
            - 推荐格式：使用序号列表，每个条目一行，例如有"起止年月"和"项目名称"两个字段，且这两个字段对应的条目有多个时，例如：
                起止年月: 1. 2025.01-2027.12\n2. 2025.01-2025.12
                项目名称: 1. 数据库系统\n2. 大规模训练与推理过程可视分析研究
            - 对齐要求：
                所有属于同一组条目的字段，条目数量必须一致；
                各字段的序号集合必须完全一致（例如都为 1~5）；
                同一序号下的内容必须来自同一条记录，不得错配；
                如果某条记录某字段缺失：保留该序号输出为空行形式：k. （仅序号，无内容）；
                不允许因为某字段缺失而减少该字段的条目数量。
            """.strip()
    
    def _build_user_prompt(
        memory_json: str,
        content_text: str,
        path: list[str],
        keys: list[str],
        ) -> str:
        path_str = " / ".join(path) if path else "<root>"
        keys_repr = ", ".join(keys)

        json_skeleton = "{\n" + ",\n".join([f'  "{k}": ""' for k in keys]) + "\n}"
        return f"""
            【字段路径 Path】（仅用于语义定位，不要输出）：
            {path_str}

            【字段列表 Keys】（只允许输出这些字段，不多不少）：
            {keys_repr}

            【用户记忆】（仅可据此抽取，不得推测）
            {memory_json}

            【知识库片段】（仅可据此抽取，不得推测）
            {content_text}

            【JSON 输出模板】（必须严格遵循 key 集合）
            {json_skeleton}
            """.strip()


    def _non_empty_kv(extracted: dict[str, str]) -> dict[str, str]:
        return {k: v for k, v in extracted.items() if isinstance(v, str) and v.strip()}
    
    def generate_node(state: TaskState, runtime: Runtime[WorkflowContext]):
        task = state["task"]
        path = task.path
        keys = list(task.keys)

        memory_json = state.get("memory_json", "")
        docs = state.get("docs", [])
        task_id = f"{'/'.join(path) or '<root>'}:{','.join(keys)}"
        default_kv = {k: "" for k in keys}
        default_patch = make_patch(path, default_kv)
        if not memory_json and not docs:
            return {
                "final_result": default_patch,
                "context_by_task": {task_id: []},
            }
        formatted_context = "\n\n".join(
            [f"片段 {i+1}:\n{doc}" for i, doc in enumerate(docs)]
        )
        try:
            with EXTRACT_LLM_SEMAPHORE:
                system_prompt = _build_system_prompt(keys)
                user_prompt = _build_user_prompt(memory_json, formatted_context, path, keys)

                llm = LLMComponent(
                    model_id=runtime.context.extract_model_id,
                    system_prompt=system_prompt,
                    prompt=user_prompt,
                    response_format=ResponseFormat.JSON,
                    temperature=0.6,
                )

                msg = llm()
                obj = json.loads(msg.content)

                extracted = {}
                for k in keys:
                    v = obj.get(k, "")
                    extracted[k] = (str(v).strip() if v is not None else "")
                patch = make_patch(path, extracted)
                mem_kv = _non_empty_kv(extracted)
                mem_patch = make_patch(path, mem_kv) if mem_kv else {}
                return {
                    "final_result": patch,
                    "memory_patch": mem_patch,
                    "context_by_task": {task_id: docs},
                }

        except Exception as e:
            return {
                "final_result": default_patch,
                "memory_patch": {}, 
                "context_by_task": {task_id: docs},
                "errors": {task_id: f"LLM Error: {type(e).__name__}: {e}"},
            }

    return generate_node
