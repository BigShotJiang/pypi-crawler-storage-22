from pathlib import Path
import json

from alayaflow.workflow import WorkflowInfo
from alayaflow.utils.logger import AlayaFlowLogger

logger = AlayaFlowLogger()

def get_metadata():
    try:
        wf_dir = Path(__file__).parent
        meta_path = wf_dir / "metadata.json"
        meta = json.loads(meta_path.read_text())
        meta.update({"wf_dir": wf_dir})
        return WorkflowInfo(**meta)
    except Exception as e:
        logger.error(f"Error loading metadata: {e}")
        raise RuntimeError(f"Error loading metadata: {e}")
