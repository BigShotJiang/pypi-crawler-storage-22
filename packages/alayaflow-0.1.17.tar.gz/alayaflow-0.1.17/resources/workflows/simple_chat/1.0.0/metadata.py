from pathlib import Path

from alayaflow.workflow import WorkflowInfo

def get_metadata():
    meta = {
        "id": "simple_chat",
        "name": "Simple Chatbot",
        "description": "一个简单的 LLM 对话工作流示例",
        "version": "1.0.0",
        "tags": ["chat", "basic"],
        "entry_file": "workflow.py",
        "entry_point": "create_graph",
        "wf_dir": Path(__file__).parent
    }
    return WorkflowInfo(**meta)
