#!/bin/bash
rm -rf dist/                  
rm -rf build/
rm *.egg-info

python -m build

twine check dist/*
twine upload dist/*