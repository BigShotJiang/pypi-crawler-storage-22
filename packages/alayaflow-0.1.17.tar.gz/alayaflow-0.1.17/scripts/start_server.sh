#!/bin/bash

PROJ_ROOT=$(dirname $(dirname $(realpath $0)))

cd $PROJ_ROOT
uv run uvicorn server.app:app --reload --host 0.0.0.0 --port 12000
