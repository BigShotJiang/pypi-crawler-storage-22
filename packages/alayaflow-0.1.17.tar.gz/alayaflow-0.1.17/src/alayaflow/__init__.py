"""AlayaFlow - A workflow engen for management and execution."""

from importlib.metadata import version

from .api import Flow

__all__ = [
    "Flow",
]

__version__ = version("alayaflow")


