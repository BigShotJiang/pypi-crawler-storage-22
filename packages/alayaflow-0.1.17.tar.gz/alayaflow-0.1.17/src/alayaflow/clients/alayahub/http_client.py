import requests

from alayaflow.utils.logger import AlayaFlowLogger

logger = AlayaFlowLogger()

class HttpAlayaHubClient:
    def __init__(self, base_url: str, download_url: str):
        """Initialize the HTTP client with base URL"""
        self.base_url = base_url.rstrip('/')
        self.download_url = download_url.rstrip('/')

    def download_workflow(self, workflow_id: str, version: str, output_path: str):
        """Download a workflow from the hub"""
        download_url = f"{self.download_url}/workflows/{workflow_id}/{version}/download/workflows.zip"

        logger.info(f"Downloading workflow {workflow_id} version {version} from {download_url} to {output_path}")

        response = requests.get(download_url, stream=True, timeout=30)
        response.raise_for_status()
        
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
