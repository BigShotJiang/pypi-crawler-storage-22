from abc import ABC, abstractmethod
from typing import Dict, List, Any

from alayaflow.clients.alayamem.types import (
    HybridQueryResponse,
    GetProfileResponse,
    UpdateProfileResponse,
)

class BaseAlayaMemClient(ABC):


    @abstractmethod
    def query_file(self, user_id: str, message: Any, limit: int = 10, use_query_params: bool = False) -> Dict:
        """ 查询文件内容 - POST 请求 """
        pass

    @abstractmethod
    def commit_turn(self, session_id: str, user_text: str, assistant_text: str,
                    user_id: str = None, window_size: int = 10) -> Dict:
        """ 提交多轮对话记录 - POST 请求 """
        pass

    @abstractmethod
    def turns(self, session_id: str, user_id: str = None, limit: int = 10) -> List:
        """ 查询对话历史记录 - GET 请求 """
        pass

    @abstractmethod
    def summary(self, session_id: str, user_id: str = None) -> Dict:
        """ 查询会话摘要 - GET 请求 """
        pass

    @abstractmethod
    def profile(self, user_id: str) -> Dict:
        """ 查询用户画像 - GET 请求 """
        pass

    @abstractmethod
    def hybrid_query(self, query: str, user_id: str, limit: int = 10) -> HybridQueryResponse:
        """
        混合检索 - POST 请求
        
        Returns:
            HybridQueryResponse: 包含检索结果的字典，结构见 types.HybridQueryResponse
        """
        pass

    @abstractmethod
    def get_profile(self, user_id: str, profile_id: str) -> GetProfileResponse:
        """
        获取用户画像 - GET 请求
        
        Returns:
            GetProfileResponse: 包含画像数据的字典，结构见 types.GetProfileResponse
        """
        pass

    @abstractmethod
    def update_profile(self, user_id: str, profile_id: str, content: Dict[str, Any]) -> UpdateProfileResponse:
        """
        更新用户画像 - PUT 请求
        
        Returns:
            UpdateProfileResponse: 包含更新结果的字典，结构见 types.UpdateProfileResponse
        """
        pass