"""AlayaMem 客户端类型定义"""
from typing import List, Any, Dict, TypedDict, Optional


class HybridQueryResults(TypedDict):
    """混合检索结果数据结构"""
    ids: List[List[str]]  
    documents: List[List[str]]
    metadatas: List[List[Dict[str, Any]]]
    distances: List[List[float]]


class HybridQueryResponse(TypedDict):
    """混合检索API返回格式"""
    msg: str
    results: HybridQueryResults
    query: str
    user_id: str
    count: int


class ProfileData(TypedDict, total=False):
    """用户画像数据"""
    profile_id: str
    user_id: str
    name: str
    type: Optional[str]
    created_at: float
    updated_at: float
    content: Dict[str, Any]


class GetProfileResponse(TypedDict):
    """获取用户画像API返回格式"""
    code: int
    msg: str
    data: ProfileData


class UpdateProfileResponse(TypedDict):
    """更新用户画像API返回格式"""
    code: int
    msg: str
    data: ProfileData

