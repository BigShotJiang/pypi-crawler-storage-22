import os

from langchain_openai import ChatOpenAI


def mk_chat_model_deepseek():
    return ChatOpenAI(
        model="deepseek-chat",
        api_key=os.getenv("DEEPSEEK_API_KEY"),
        base_url="https://api.deepseek.com/v1",
    )

def mk_chat_model_jet(base_url: str, model_name: str):
    return ChatOpenAI(
        model=model_name,
        api_key="EMPTY",
        base_url=base_url,
    )

