from alayaflow.clients.alayamem.http_client import HttpAlayaMemClient


def query_file(alayamem_url: str, user_id: str, message):
    mem_client = HttpAlayaMemClient(alayamem_url)
    try:
        return mem_client.query_file(user_id, message)
    except Exception as e:
        print(f"[Query File] Error: {e}")
        return {"error": str(e)}


def commit_turn(alayamem_url: str, session_id: str, user_text: str,
                assistant_text: str, user_id: str = None, window_size: int = 3):
    """ 提交多轮对话记录 """
    mem_client = HttpAlayaMemClient(alayamem_url)
    try:
        return mem_client.commit_turn(session_id, user_text, assistant_text,
                                     user_id, window_size)
    except Exception as e:
        print(f"[Commit Turn] Error: {e}")
        return {"error": str(e)}


def turns(alayamem_url: str, session_id: str, user_id: str = None, limit: int = 10):
    """ 查询对话历史记录 """
    mem_client = HttpAlayaMemClient(alayamem_url)
    try:
        return mem_client.turns(session_id, user_id, limit)
    except Exception as e:
        print(f"[Turns] Error: {e}")
        return {"error": str(e)}


def summary(alayamem_url: str, session_id: str, user_id: str = None):
    """ 查询会话摘要 """
    mem_client = HttpAlayaMemClient(alayamem_url)
    try:
        return mem_client.summary(session_id, user_id)
    except Exception as e:
        print(f"[Summary] Error: {e}")
        return {"error": str(e)}



def profile(alayamem_url: str, user_id: str):
    mem_client = HttpAlayaMemClient(alayamem_url)
    try:
        return mem_client.profile(user_id)
    except Exception as e:
        print(f"[Profile] Error: {e}")
        return {"error": str(e)}
