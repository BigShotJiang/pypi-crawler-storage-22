from typing import Optional
from pydantic import BaseModel, Field, ConfigDict, SecretStr


class GenerationConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="采样温度")
    max_tokens: Optional[int] = Field(default=None, description="最大生成 Token 数")
    top_p: float = Field(default=1.0, description="核采样阈值")
    frequency_penalty: float = Field(default=0.0, ge=-2.0, le=2.0)
    presence_penalty: float = Field(default=0.0, ge=-2.0, le=2.0)
    
    extra_kwargs: dict = Field(default_factory=dict, description="其他参数")


class ModelProfile(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    # Local used fields
    name: str = Field(..., description="模型名称")
    model_id: str = Field(..., description="系统内部使用的唯一 ID")
    model_type: str = Field(default="OpenAI", description="模型类型工厂标识")
    provider_name: str = Field(default="Unknown", description="提供商名称")

    # Connection Credentials
    model_name: str = Field(..., description="厂商的模型名称")
    base_url: str = Field(..., description="API Base URL")
    api_key: SecretStr = Field(default=SecretStr(""), description="API Key")

    # Default Generation Config
    default_config: GenerationConfig = Field(default_factory=GenerationConfig)

