from abc import ABC, abstractmethod
from typing import Generator, Dict, AsyncGenerator


class BaseExecutor(ABC):
    @abstractmethod
    def execute_stream(self, workflow_id: str, version: str, inputs: dict, context: dict, metadata: dict = None) -> Generator[Dict, None, None]:
        pass

    @abstractmethod
    async def execute_stream_async(self, workflow_id: str, version: str, inputs: dict, context: dict, metadata: dict = None) -> AsyncGenerator[Dict, None]:
        pass

