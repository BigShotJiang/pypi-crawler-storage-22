from typing import Generator, Dict, AsyncGenerator

from alayaflow.execution.executors.base_executor import BaseExecutor
from alayaflow.workflow.workflow_manager import WorkflowManager

class WorkerExecutor(BaseExecutor):
    def __init__(self, workflow_manager: WorkflowManager):
        self.workflow_manager = workflow_manager
    
    def execute_stream(self, workflow_id: str, version: str, inputs: dict, context: dict, metadata: dict = None) -> Generator[Dict, None, None]:
        raise NotImplementedError("worker executor not supported yet")

    def execute_stream_async(self, workflow_id: str, version: str, inputs: dict, context: dict, metadata: dict = None) -> AsyncGenerator[Dict, None]:
        raise NotImplementedError("worker executor not supported yet")