import queue, threading, asyncio

def iter_sync(async_gen):
    """将 AsyncGenerator 转为 Sync Generator"""
    q = queue.Queue(maxsize=1)
    SENTINEL = object()

    def _run():
        try:
            async def _drive():
                async for item in async_gen: q.put(item)
            asyncio.run(_drive())
        except Exception as e: q.put(e)
        finally: q.put(SENTINEL)

    threading.Thread(target=_run, daemon=True).start()

    for item in iter(q.get, SENTINEL):
        if isinstance(item, Exception): raise item
        yield item