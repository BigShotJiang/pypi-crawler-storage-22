from abc import ABC
from typing import Dict, Any, AsyncGenerator

from langgraph.graph.state import RunnableConfig

from alayaflow.workflow.workflow_info import WorkflowInfo

class BaseRunnableWorkflow(ABC):
    def __init__(self, info: WorkflowInfo) -> None:
        self._info = info

    @property
    def info(self) -> WorkflowInfo:
        return self._info

    def invoke(self, inputs: dict, context: dict, config: RunnableConfig) -> dict:
        raise NotImplementedError("invoke method must be implemented in derived classes")

    async def stream_events_async(self, inputs: dict, context: dict, config: RunnableConfig) -> AsyncGenerator[Dict[str, Any], None]:
        raise NotImplementedError("stream_events_async method must be implemented in derived classes")

