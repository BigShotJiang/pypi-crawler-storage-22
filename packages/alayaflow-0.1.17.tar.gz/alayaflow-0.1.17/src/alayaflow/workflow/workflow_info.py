from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, NamedTuple


class WorkflowKey(NamedTuple):
    id: str
    version: str


@dataclass
class WorkflowInfo:
    """工作流元信息"""
    id: str
    name: str
    description: str
    version: str
    tags: List[str]
    entry_file: str
    entry_point: str
    wf_dir: Optional[Path] = None

    @property
    def key(self) -> WorkflowKey:
        return WorkflowKey(self.id, self.version)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "tags": self.tags,
            "entry_file": self.entry_file,
            "entry_point": self.entry_point,
            "wf_dir": str(self.wf_dir),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "WorkflowInfo":
        return cls(
            id=data["id"],
            name=data["name"],
            description=data["description"],
            version=data["version"],
            tags=data["tags"],
            entry_file=data["entry_file"],
            entry_point=data["entry_point"],
            wf_dir=Path(data.get("wf_dir", "")) if data.get("wf_dir") else None,
        )
