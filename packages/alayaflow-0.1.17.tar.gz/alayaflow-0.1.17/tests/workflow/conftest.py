""" workflow 测试配置文件"""
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.parent
TEST_WORKFLOW_ID = "simple_chat"
TEST_WORKFLOW_VERSION = "1.0.0"
EXPECTED_WORKFLOW_ID = "simple_chat"
EXPECTED_WORKFLOW_NAME = "Simple Chatbot"
EXPECTED_WORKFLOW_VERSION = "1.0.0"
EXPECTED_ENTRY_POINT = "create_graph"

# 新的目录结构：workflows_dir / workflow_id / version
WORKFLOWS_DIR = PROJECT_ROOT / "resources" / "workflows"
WORKFLOW_DIR = WORKFLOWS_DIR / TEST_WORKFLOW_ID / TEST_WORKFLOW_VERSION
