import pytest
from alayaflow.workflow.runnable import StateGraphRunnableWorkflow
from alayaflow.workflow.workflow_loader import WorkflowLoader
from alayaflow.workflow.workflow_info import WorkflowInfo

from .conftest import (
    WORKFLOWS_DIR,
    EXPECTED_WORKFLOW_ID,
    EXPECTED_WORKFLOW_NAME,
    EXPECTED_WORKFLOW_VERSION,
    EXPECTED_ENTRY_POINT,
)


# ============  workflow : python_import/1.0.0 ============
def test_load_info():
    """测试加载工作流元信息"""
    workflow_dir = WORKFLOWS_DIR / EXPECTED_WORKFLOW_ID / EXPECTED_WORKFLOW_VERSION
    loader = WorkflowLoader(str(workflow_dir), EXPECTED_WORKFLOW_ID, EXPECTED_WORKFLOW_VERSION)
    wf_info = loader.load_info()
    
    assert isinstance(wf_info, WorkflowInfo)
    assert wf_info.id == EXPECTED_WORKFLOW_ID
    assert wf_info.name == EXPECTED_WORKFLOW_NAME
    assert wf_info.version == EXPECTED_WORKFLOW_VERSION


def test_load_workflow():
    """测试完整加载工作流"""
    workflow_dir = WORKFLOWS_DIR / EXPECTED_WORKFLOW_ID / EXPECTED_WORKFLOW_VERSION
    loader = WorkflowLoader(str(workflow_dir), EXPECTED_WORKFLOW_ID, EXPECTED_WORKFLOW_VERSION)
    result = loader.load_workflow({
        "alayamem_url": "http://xxxxx",
    })

    assert isinstance(result, StateGraphRunnableWorkflow)
    assert result.info is not None
    assert result.info.id == EXPECTED_WORKFLOW_ID
    assert result.info.version == EXPECTED_WORKFLOW_VERSION
    assert result._graph is not None
