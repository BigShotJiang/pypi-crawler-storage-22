::: albert.collections.links.LinksCollection
