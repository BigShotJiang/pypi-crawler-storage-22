::: albert.resources.synthesis
