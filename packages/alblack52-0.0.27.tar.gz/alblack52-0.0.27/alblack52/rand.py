import random

grades = []
for _ in range(3):
    grade = random.randint(1, 3)
    grades.append(grade)

print(grades)  # Пример: [3, 5, 4]

