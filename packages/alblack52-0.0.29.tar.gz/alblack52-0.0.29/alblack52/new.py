import requests

# ---------------- Настройки ----------------
PROXY_BASE_URL = "https://550b9c80eba1.ngrok-free.app"
PROXY_SECRET = "dns"

MODEL = "deepseek-ai/DeepSeek-V3.2"

SYSTEM_PROMPT = '''
Ты — эксперт в теории вероятностей. Тебе нужно написать как можно более правильный ответ на задания. От твоего ответа зависит, сдам ли я очень важный экзамен.
Ответом на мой запрос должен быть только код, без пояснений и комментариев.
Решай задачи аналитическим решением, при этом используя только стандартные библиотеки и чтобы код был максимально коротким, но не в ущерб точности, всё только на языке программирования Python.
'''


# ------------------------------------------

def start():
    """
    Запускает полноценный интерактивный чат с моделью.
    Вводишь запросы через input(), exit для выхода.
    """
    conversation_history = [{"role": "system", "content": SYSTEM_PROMPT}]

    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("Выход из чата.")
            break

        conversation_history.append({"role": "user", "content": user_input})

        # Отправка запроса через прокси
        url = f"{PROXY_BASE_URL}/api/proxy"
        headers = {"X-Proxy-Secret": PROXY_SECRET, "Content-Type": "application/json"}
        data = {"messages": conversation_history, "model": MODEL}

        try:
            resp = requests.post(url, headers=headers, json=data, timeout=200)
            if resp.status_code == 200:
                j = resp.json()
                answer = j.get("text") or j.get("upstream")
            else:
                answer = f"Ошибка прокси {resp.status_code}: {resp.text}"
        except Exception as e:
            answer = f"Ошибка при отправке запроса: {e}"

        conversation_history.append({"role": "assistant", "content": answer})
        print("Ян Маковейчук: " + answer)
