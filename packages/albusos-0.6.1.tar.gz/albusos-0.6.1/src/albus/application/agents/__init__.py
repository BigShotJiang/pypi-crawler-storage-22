"""Agent application services."""

from albus.application.agents.service import AgentService

__all__ = [
    "AgentService",
]
