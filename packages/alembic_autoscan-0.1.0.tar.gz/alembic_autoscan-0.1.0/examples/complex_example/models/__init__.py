"""
Models package initialization.
"""

# Traditionally, you would import all models here for Alembic
# But with alembic-autoscan, this is no longer necessary!

from .user import User
from .post import Post
from .article import Article