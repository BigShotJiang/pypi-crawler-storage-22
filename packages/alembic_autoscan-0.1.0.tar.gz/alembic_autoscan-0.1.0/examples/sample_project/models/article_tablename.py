class ArticleTablename:
    __tablename__ = "articles_tablename"