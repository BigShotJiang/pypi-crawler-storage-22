# Changelog

## 0.7.11

- Fixed: MCP `rg_search` now accepts `paths` as string or list; previously a
  string caused a Pydantic validation error.

## 0.7.10

- Fixed: Removed unsupported `color` kwarg from `ArgumentParser` that crashed
  on Python < 3.14 (and in Docker containers using older Python).

## 0.7.9

- Improved: Increased sub-query timeout defaults
  (CLI: 120 s -> 300 s, API: 60 s -> 120 s).

## 0.7.8

- Docs: Clarified CLI aliases (`aleph run` / `aleph-rlm run`) and updated MCP
  manual config args.

## 0.7.7

- Added: `aleph-rlm configure` wizard for MCP client configs (workspace scope,
  sub-query backend, Docker).
- Added: `aleph run|shell|serve` and `aleph-rlm run|shell|serve` as official
  CLI entry points; `alef` is now deprecated.
- Added: Optional Dockerfile and install flow for containerized MCP server.
- Fixed: Headless argparse colorization crash when stdout/stderr are closed.
- Improved: Cached text context analysis to avoid repeat scans.

## 0.7.6

- Removed: CoCap module and related REPL helpers.

## 0.7.5

- Added: CLI provider tests for message formatting and error handling.
- Added: Swarm coordination/progress/context-id test coverage.
- Added: `ctx_append`/`ctx_set` sandbox helper tests.
- Fixed: Swarm timestamps now use timezone-safe UTC generation.
- Fixed: `__version__` now matches the package release version.

## 0.7.4

- Added: `alef` CLI command for running full RLM loop without MCP server.
- Added: CLI provider (`--provider cli`) for API-key-free operation via
  `claude`, `codex`, or `gemini` CLIs.
- Added: Entry point `alef run "prompt" --provider cli --model claude` with
  context file/stdin support.
- Fixed: Code blocks before FINAL directives are now executed properly
  (parser priority fix).
- Fixed: Trajectory JSON serialization for `ActionType` enum.
- Fixed: Type annotations for mypy compliance.

## 0.7.3

- Added: CLI recursion tracking and depth controls for `sub_aleph`.
- Improved: Session management for nested recursion contexts.

## 0.7.2

- Added: `sub_aleph` nested recursion tool for RLM-style recursive reasoning
  with depth control.
- Added: MCP and REPL exposure for `sub_aleph` with configurable `max_depth`,
  `max_iterations`, and `max_sub_queries`.
- Added: `ALEPH_MAX_DEPTH` environment variable for limiting recursion depth.
- Added: Double recursion test (`tests/test_double_recursion.py`) for
  deterministic verification.
- Updated: Docs for `sub_aleph` usage patterns and depth configuration.

## 0.7.1

- Enhanced: System prompt with RLM paper examples
  (arXiv:2512.24601 Appendix D patterns).
- Added: Sub-query batching efficiency guidance (~100-200 K chars per call,
  avoid 1000s of small calls).
- Added: New /aleph skill examples -- iterative document analysis,
  regex-targeted sub-queries, answer verification pattern.
- Improved: Documentation alignment with RLM paper's best practices.

## 0.7.0

- Added: CLI flags for sub-query configuration (`--sub-query-backend`,
  `--sub-query-timeout`, `--sub-query-share-session`).
- Added: Runtime `configure` MCP tool and REPL helpers (`set_backend`,
  `get_config`) for sub-query config.
- Added: `ALEPH_SUB_QUERY_TIMEOUT` environment variable to align CLI/API
  sub-query timeouts.
- Fixed: Validation retry behavior respects per-call settings over env defaults.
- Improved: Sub-query error messages now include allowed backend choices.

## 0.6.0

- Fixed: Workspace root auto-detection to honor `ALEPH_WORKSPACE_ROOT` and
  prefer invocation directories (`PWD`/`INIT_CWD`) before falling back to
  `os.getcwd()`.

## 0.5.9

- Fixed: `sub_query` to auto-inject session context when `context_slice` is
  omitted.
- Added: Shared session support for CLI sub-agents (codex/gemini/claude) via
  streamable HTTP.
- Changed: Deprioritized `claude` CLI backend (hangs in MCP/sandbox contexts);
  new order: api -> codex -> gemini -> claude.
- Fixed: stdin handling in CLI backends to prevent subprocess from stealing
  MCP stdio.

## 0.5.8

- Added: Smart loaders for PDF/DOCX/HTML and compressed logs (.gz/.bz2/.xz)
  in `load_file`.
- Added: Fast repo-wide search via `rg_search` and lightweight
  `semantic_search` + `embed_text` helpers.
- Added: Task tracking per context and automatic memory pack save/load.
- Improved: Provenance defaults (peek records evidence) and extended default
  timeouts.

## 0.5.7

- Changed: Codex CLI sub-queries now use `codex exec --full-auto`, with stdin
  support for long prompts.
- Added: Auto-reconnect for remote MCP servers and a configurable default
  timeout (`ALEPH_REMOTE_TOOL_TIMEOUT`).

## 0.5.6

- Removed: Deprecated recipe workflow and aider backend references.
- Added: Gemini CLI sub-query backend and updated backend priority docs.
- Improved: Sub-query system prompt for structured output.
- Added: Full Power Mode docs and made installer defaults max power.
- Added: `--max-write-bytes` and aligned file size limits across docs.
- Clarified: Action-tool file size caps and workspace mode usage.
