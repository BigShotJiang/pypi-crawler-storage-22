# Module to read/write Modbus message over TCP to Alfen Eve (Single Pro-Line) car charger
# This code has been created by heavily making use of the code for SolarEdge inverter
# created by nmakel/solaredge_modbus on GitHub.com
# Basically I have adapted that code to reflect the situation for the Alfen CarCharger instead of the SolarEdge Inverter
# and limited myself to the Modbus TCP implementation only

import enum
import time
import syslog

from pymodbus.client import ModbusTcpClient

MAX_RETRIES = 3
RETRY_DELAY = 1

class registerType(enum.Enum):
    INPUT = 1
    HOLDING = 2

class registerDataType(enum.Enum):
    UINT16 = 1
    UINT32 = 2
    UINT64 = 3
    INT16 = 4
    SCALE = 4
    ACC32 = 5
    FLOAT32 = 6
    SEFLOAT = 7
    FLOAT64 = 8
    STRING = 9

METER_TYPE_MAP = {
    "0": "RTU",
    "1": "TCP/IP",
    "2": "UDP",
    "3": "P1",
    "4": "Other"
}

METER_STATE_MAP = {
    "1": "Initialised",
    "2": "Updated",
    "3": "Initialised & Updated",
    "4": "Warning",
    "5": "Warning & Initialised",
    "6": "Warning & Updated",
    "7": "Warning, Initialised & Updated",
    "8": "Error",
    "9": "Error & Initialised",
    "10": "Error & Updated",
    "11": "Error, Initialised & Updated",
    "12": "Error & Warning",
    "13": "Error, Warning & Initialised",
    "14": "Error, Warning & Updated",
    "15": "Error, Warning, Initialised & Updated"
}

AVAILABILITY_MAP = {
    "0": "Inoperable",
    "1": "Operable"
}

MODE_3_STATE_MAP = {
    "A": "NotConnected",
    "B1": "Connected",
    "B2": "Connected",
    "C1": "Connected",
    "C2": "Charging",
    "D1": "Connected",
    "D2": "Charging",
    "E": "NotConnected",
    "F": "Error"
}

SETPOINT_MAP = {
    "0": "No",
    "1": "Yes"
}

MODBUS_SLAVE_MAX_CURRENT_ENABLE_MAP = {
    "0": "Disabled",
    "1": "Enabled"
}

class AlfenEve:

    model = "Alfen Eve"
    word_order = "big" # In the past: Endian.BIG

    def __init__(
        self, host=False, port=False,
        timeout=RETRY_DELAY, retries=MAX_RETRIES,
        parent=False
    ):

        if parent:
            self.client = parent.client
            self.timeout = parent.timeout
            self.retries = parent.retries

            self.host = parent.host
            self.port = parent.port
        else:
            self.host = host
            self.port = port

            self.timeout = timeout
            self.retries = retries

            self.client = ModbusTcpClient(
                host=self.host,
                port=self.port,
                timeout=self.timeout
            )

    def __repr__(self):
        return f"{self.model}({self.host}:{self.port}: timeout={self.timeout}, retries={self.retries})"

    def _read_input_registers(self, slave, address, length):
        raise NotImplementedError("INPUT registers are not used/implemented for Alfen Eve")

    def _read_holding_registers(self, slave, address, length):
        for _ in range(self.retries):
            try:
                if not self.connected():
                    self.connect()
                    time.sleep(0.1)
                    continue

                rr = self.client.read_holding_registers(address, count=length, device_id=slave)

                if rr is None or rr.isError():
                    time.sleep(self.timeout)
                    continue
                if not hasattr(rr, "registers") or len(rr.registers) != length:
                    time.sleep(self.timeout)
                    continue

                return rr.registers

            except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError) as e:
                # Socket got closed by peer/NAT; force reconnect next iteration
                try:
                    self.client.close()
                except Exception:
                    pass
                time.sleep(self.timeout)
                continue

        return None

    def _write_holding_register(self, slave, address, value):
        for _ in range(self.retries):
            try:
                if not self.connected():
                    self.connect()
                    time.sleep(0.1)

                resp = self.client.write_registers(address=address, values=value, device_id=slave)
                if resp is None or resp.isError():
                    time.sleep(self.timeout)
                    continue
                return resp

            except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
                try:
                    self.client.close()
                except Exception:
                    pass
                time.sleep(self.timeout)
                continue

        return None

    def _dtype_to_client_datatype(self, dtype):
        DT = ModbusTcpClient.DATATYPE
        return {
            registerDataType.UINT16: DT.UINT16,
            registerDataType.UINT32: DT.UINT32,
            registerDataType.UINT64: DT.UINT64,
            registerDataType.INT16: DT.INT16,
            registerDataType.ACC32: DT.UINT32,
            registerDataType.FLOAT32: DT.FLOAT32,
            registerDataType.SEFLOAT: DT.FLOAT32,
            registerDataType.FLOAT64: DT.FLOAT64,
            registerDataType.STRING: DT.STRING,
        }[dtype]

    def _encode_value(self, data, dtype):
        dt = self._dtype_to_client_datatype(dtype)
        return self.client.convert_to_registers(
            data,
            data_type=dt,
            word_order=self.word_order,
            string_encoding="utf-8",
        )

    def _decode_value(self, registers, dtype, vtype):
        if registers is None:
            raise AttributeError("No registers")

        dt = self._dtype_to_client_datatype(dtype)
        decoded = self.client.convert_from_registers(
            registers,
            data_type=dt,
            word_order=self.word_order,
            string_encoding="utf-8",
        )

        if dtype == registerDataType.STRING and isinstance(decoded, str):
            decoded = decoded.replace("\x00", "").rstrip()

        return vtype(decoded)

    def _read(self, value):
        slave, address, length, rtype, dtype, vtype, label, fmt, batch = value

        if rtype == registerType.INPUT:
            regs = self._read_input_registers(slave, address, length)  # -> list[int] | None
        elif rtype == registerType.HOLDING:
            regs = self._read_holding_registers(slave, address, length)  # -> list[int] | None
        else:
            raise NotImplementedError(rtype)

        if not regs:
            return False

        # regs is a list[int]; _decode_value will use convert_from_registers
        return self._decode_value(regs, dtype, vtype)

    def _read_all(self, values, rtype):
        """
        New-pymodbus friendly version:
        - does ONE contiguous Modbus read for the whole batch
        - works with _read_*_registers returning a list[int] (raw registers)
        - decodes each field by slicing the raw register list (no skip_bytes / BinaryPayloadDecoder)
        """
        # Determine contiguous range [addr_min, addr_max)
        addr_min = None
        addr_max = None
        v_slave = None

        for _k, v in values.items():
            v_slave = v[0]
            v_addr = v[1]
            v_len = v[2]

            if addr_min is None or v_addr < addr_min:
                addr_min = v_addr
            end = v_addr + v_len
            if addr_max is None or end > addr_max:
                addr_max = end

        if addr_min is None or addr_max is None:
            return {}

        base_addr = addr_min
        total_count = addr_max - addr_min  # number of registers to read

        # Read one contiguous block (raw list[int])
        if rtype == registerType.INPUT:
            raw = self._read_input_registers(v_slave, base_addr, total_count)  # must return list[int] | None
        elif rtype == registerType.HOLDING:
            raw = self._read_holding_registers(v_slave, base_addr, total_count)  # must return list[int] | None
        else:
            raise NotImplementedError(rtype)

        if not raw:
            return {}

        # Decode each entry by slicing its register window out of the raw list
        results = {}
        for k, v in sorted(values.items(), key=lambda kv: kv[1][1]): # sort by address
            slave, address, count, _rtype, dtype, vtype, label, fmt, batch = v

            # If you ever mix slaves in one batch, that's a logic error (old code also effectively assumed 1 slave)
            if slave != v_slave:
                raise ValueError(f"Mixed device IDs in one batch: {v_slave} vs {slave} for {k}")

            start = address - base_addr
            end = start + count
            if start < 0 or end > len(raw):
                continue
            regs = raw[start:end]

            if len(regs) != count:
                # defensive: contiguous read didn't include expected slice
                continue

            results[k] = self._decode_value(regs, dtype, vtype)

        return results

    def _write(self, value, data):
        slave, address, length, rtype, dtype, vtype, label, fmt, batch = value

        if rtype != registerType.HOLDING:
            raise NotImplementedError(rtype)

        regs = self._encode_value(data, dtype)  # -> list[int]
        resp = self._write_holding_register(slave, address, regs)  # uses device_id=slave internally

        # Optional but recommended: pymodbus can return an error response without raising
        if resp is None or (hasattr(resp, "isError") and resp.isError()):
            return False

        return True

    def connect(self):
        return self.client.connect()

    def disconnect(self):
        self.client.close()

    def connected(self):
        return self.client.is_socket_open()

    def read(self, key):
        if key not in self.registers:
            raise KeyError(key)

        return {key: self._read(self.registers[key])}

    def write(self, key, data):
        if key not in self.registers:
            raise KeyError(key)

        return self._write(self.registers[key], data)

    def read_all(self, rtype=registerType.HOLDING):
        registers = {k: v for k, v in self.registers.items() if (v[3] == rtype)}
        results = {}

        batches = sorted({v[8] for v in registers.values()})
        for batch in batches:
            register_batch = {k: v for k, v in registers.items() if v[8] == batch}
            results.update(self._read_all(register_batch, rtype))

        return results


class CarCharger(AlfenEve):

    def __init__(self, *args, **kwargs):
        self.model = "Car Charger"

        super().__init__(*args, **kwargs)

        self.registers = {
            # name, address, length, register, type, target type, description, unit, batch
            "c_name": (0xc8, 0x64, 17, registerType.HOLDING, registerDataType.STRING, str, "ALF_1000", "", 1),
            "c_manufacturer": (0xc8, 0x75, 5, registerType.HOLDING, registerDataType.STRING, str, "Alfen NV", "", 1),
            "c_modbus_table_version": (0xc8, 0x7a, 1, registerType.HOLDING, registerDataType.INT16, int, "1", "", 1),
            "c_firmware_version": (0xc8, 0x7b, 17, registerType.HOLDING, registerDataType.STRING, str, "3.4.0-2990", "", 1),
            "c_platform_type": (0xc8, 0x8c, 17, registerType.HOLDING, registerDataType.STRING, str, "NG910", "", 1),
            "c_station_serial_number": (0xc8, 0x9d, 11, registerType.HOLDING, registerDataType.STRING, str, "00000R000", "", 1),
            "c_date_year": (0xc8, 0xa8, 1, registerType.HOLDING, registerDataType.INT16, int, "2019", "1yr", 1),
            "c_date_month": (0xc8, 0xa9, 1, registerType.HOLDING, registerDataType.INT16, int, "03", "1mon", 1),
            "c_date_day": (0xc8, 0xaa, 1, registerType.HOLDING, registerDataType.INT16, int, "11", "1d", 1),
            "c_time_hour": (0xc8, 0xab, 1, registerType.HOLDING, registerDataType.INT16, int, "12", "1hr", 1),
            "c_time_minute": (0xc8, 0xac, 1, registerType.HOLDING, registerDataType.INT16, int, "01", "1min", 1),
            "c_time_second": (0xc8, 0xad, 1, registerType.HOLDING, registerDataType.INT16, int, "04", "1s", 1),
            "c_uptime": (0xc8, 0xae, 4, registerType.HOLDING, registerDataType.UINT64, int, "100", "0.001s", 1),
            "c_time_zone": (0xc8, 0xb2, 1, registerType.HOLDING, registerDataType.INT16, int, "Time zone offset to UTC in minutes", "1min", 1),

            "station_active_max_current": (0xc8, 0x44c, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "The Actual Max Current", "A", 2),
            "temperature": (0xc8, 0x44e, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Board Temperature", "degrees Celsius", 2),
            "ocpp_state": (0xc8, 0x450, 1, registerType.HOLDING, registerDataType.UINT16, int, "Back Office Connected", "", 2),
            "nr_of_sockets": (0xc8, 0x451, 1, registerType.HOLDING, registerDataType.UINT16, int, "Number of Sockets", "", 2),

            "meter_state": (0x1, 0x12c, 1, registerType.HOLDING, registerDataType.UINT16, int, "Bitmask with state", "", 3),
            "meter_last_value_timestamp": (0x1, 0x12d, 4, registerType.HOLDING, registerDataType.UINT64, int, "Milliseconds since last received measurement", "0.001s", 3),
            "meter_type": (0x1, 0x131, 1, registerType.HOLDING, registerDataType.UINT16, int, "0:RTU, 1:TCP/IP, 2:UDP, 3:P1, 4:other", "", 3),

            "voltage_phase_L1N": (0x1, 0x132, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Voltage Phase L1N", "V", 4),
            "voltage_phase_L2N": (
            0x1, 0x134, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Voltage Phase L2N", "V", 4),
            "voltage_phase_L3N": (
            0x1, 0x136, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Voltage Phase L3N", "V", 4),
            "voltage_phase_L1L2": (
            0x1, 0x138, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Voltage Phase L1L2", "V", 4),
            "voltage_phase_L2L3": (
                0x1, 0x13a, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Voltage Phase L2L3", "V", 4),
            "voltage_phase_L3L1": (
                0x1, 0x13c, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Voltage Phase L3L1", "V", 4),
            "current_N": (
                0x1, 0x13e, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Current through N", "A", 4),
            "current_phase_L1": (
                0x1, 0x140, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Current Phase L1", "A", 4),
            "current_phase_L2": (
                0x1, 0x142, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Current Phase L2", "A", 4),
            "current_phase_L3": (
                0x1, 0x144, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Current Phase L3", "A", 4),
            "current_sum": (
                0x1, 0x146, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Current Sum", "A", 4),

            "power_factor_phase_L1": (
                0x1, 0x148, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Power Factor Phase L1", "", 5),
            "power_factor_phase_L2": (
                0x1, 0x14a, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Power Factor Phase L2", "", 5),
            "power_factor_phase_L3": (
                0x1, 0x14c, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Power Factor Phase L3", "", 5),
            "power_factor_sum": (
                0x1, 0x14e, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Power Factor Sum", "", 5),
            "frequency": (
                0x1, 0x150, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Frequency", "Hz", 5),

            "real_power_phase_L1": (
                0x1, 0x152, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Real Power Phase L1", "W", 5),
            "real_power_phase_L2": (
                0x1, 0x154, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Real Power Phase L2", "W", 5),
            "real_power_phase_L3": (
                0x1, 0x156, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Real Power Phase L3", "W", 5),
            "real_power_sum": (
                0x1, 0x158, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Real Power Sum", "W", 5),

            "apparent_power_phase_L1": (
                0x1, 0x15a, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Apparent Power Phase L1", "VA", 5),
            "apparent_power_phase_L2": (
                0x1, 0x15c, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Apparent Power Phase L2", "VA", 5),
            "apparent_power_phase_L3": (
                0x1, 0x15e, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Apparent Power Phase L3", "VA", 5),
            "apparent_power_sum": (
                0x1, 0x160, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Apparent Power Sum", "VA", 5),

            "reactive_power_phase_L1": (
                0x1, 0x162, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Reactive Power Phase L1", "VAr", 5),
            "reactive_power_phase_L2": (
                0x1, 0x164, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Reactive Power Phase L2", "VAr", 5),
            "reactive_power_phase_L3": (
                0x1, 0x166, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Reactive Power Phase L3", "VAr", 5),
            "reactive_power_sum": (
                0x1, 0x168, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Reactive Power Sum", "VAr", 5),

            "real_energy_delivered_phase_L1": (
                0x1, 0x16a, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Delivered Phase L1", "Wh", 6),
            "real_energy_delivered_phase_L2": (
                0x1, 0x16e, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Delivered Phase L2", "Wh", 6),
            "real_energy_delivered_phase_L3": (
                0x1, 0x172, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Delivered Phase L3", "Wh", 6),
            "real_energy_delivered_sum": (
                0x1, 0x176, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Delivered Sum", "Wh", 6),

            "real_energy_consumed_phase_L1": (
                0x1, 0x17a, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Consumed Phase L1", "Wh", 6),
            "real_energy_consumed_phase_L2": (
                0x1, 0x17e, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Consumed Phase L2", "Wh", 6),
            "real_energy_consumed_phase_L3": (
                0x1, 0x182, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Consumed Phase L3", "Wh", 6),
            "real_energy_consumed_sum": (
                0x1, 0x186, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Real Energy Consumed Sum", "Wh", 6),

            "apparent_energy_phase_L1": (
                0x1, 0x18a, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Apparent Energy Phase L1", "VAh", 6),
            "apparent_energy_phase_L2": (
                0x1, 0x18e, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Apparent Energy Phase L2", "VAh", 6),
            "apparent_energy_phase_L3": (
                0x1, 0x192, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Apparent Energy Phase L3", "VAh", 6),
            "apparent_energy_sum": (
                0x1, 0x196, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Apparent Energy Sum", "VAh", 6),

            "reactive_energy_phase_L1": (
                0x1, 0x19a, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Reactive Energy Phase L1", "VArh", 6),
            "reactive_energy_phase_L2": (
                0x1, 0x19e, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Reactive Energy Phase L2", "VArh", 6),
            "reactive_energy_phase_L3": (
                0x1, 0x1a2, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Reactive Energy Phase L3", "VArh", 6),
            "reactive_energy_sum": (
                0x1, 0x1a6, 4, registerType.HOLDING, registerDataType.FLOAT64, float, "Reactive Energy Sum", "VArh", 6),

            "availability": (
                0x1, 0x4b0, 1, registerType.HOLDING, registerDataType.UINT16, int, "1: Operative; 0: Inoperative", "",
                7),
            "mode_3_state": (0x1, 0x4b1, 5, registerType.HOLDING, registerDataType.STRING, str, "61851 states",
                             "", 7),
            "actual_applied_max_current": (
                0x1, 0x4b6, 2, registerType.HOLDING, registerDataType.FLOAT32, float,
                "Actual Applied Max Current for Socket", "A", 7),
            "modbus_slave_max_current_valid_time": (
                0x1, 0x4b8, 2, registerType.HOLDING, registerDataType.UINT32, int,
                "Remaining time before fallback to safe current", "1s", 7),
            "modbus_slave_max_current": (
                0x1, 0x4ba, 2, registerType.HOLDING, registerDataType.FLOAT32, float,
                "Modbus Slave Max Current", "A", 7),
            "active_load_balancing_safe_current": (
                0x1, 0x4bc, 2, registerType.HOLDING, registerDataType.FLOAT32, float,
                "Active Load Balancing Safe Current", "A", 7),
            "modbus_slave_received_setpoint_accounted_for": (
                0x1, 0x4be, 1, registerType.HOLDING, registerDataType.UINT16, int,
                "Modbus Slave Received Setpoint Accounted For", "", 7),
            "charge_using_1_or_3_phases": (
                0x1, 0x4bf, 1, registerType.HOLDING, registerDataType.UINT16, int,
                "Phases used for charging", "phases", 7),

            "scn_name": (0xc8, 0x578, 4, registerType.HOLDING, registerDataType.STRING, str, "", "", 8),
            "scn_sockets": (0xc8, 0x57c, 1, registerType.HOLDING, registerDataType.UINT16, int, "", "1A", 8),
            "scn_total_consumption_phase_l1": (0xc8, 0x57d, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 8),
            "scn_total_consumption_phase_l2": (0xc8, 0x57f, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 8),
            "scn_total_consumption_phase_l3": (0xc8, 0x581, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 8),
            "scn_actual_max_current_phase_l1": (0xc8, 0x583, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 8),
            "scn_actual_max_current_phase_l2": (0xc8, 0x585, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 8),
            "scn_actual_max_current_phase_l3": (0xc8, 0x587, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 8),
            "scn_max_current_phase_l1": (0xc8, 0x589, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 9),
            "scn_max_current_phase_l2": (0xc8, 0x58b, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 9),
            "scn_max_current_phase_l3": (0xc8, 0x58d, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "", "1A", 9),
            "remaining_valid_time_max_current_phase_l1": (0xc8, 0x58f, 2, registerType.HOLDING, registerDataType.UINT32, int, "Max current valid time", "1s", 9),
            "remaining_valid_time_max_current_phase_l2": (0xc8, 0x591, 2, registerType.HOLDING, registerDataType.UINT32, int, "Max current valid time", "1s", 9),
            "remaining_valid_time_max_current_phase_l3": (0xc8, 0x593, 2, registerType.HOLDING, registerDataType.UINT32, int, "Max current valid time", "1s", 9),
            "scn_safe_current": (0xc8, 0x595, 2, registerType.HOLDING, registerDataType.FLOAT32, float, "Configured SCN safe current", "1A", 9),
            "scn_modbus_slave_max_current_enable": (0xc8, 0x597, 1, registerType.HOLDING, registerDataType.UINT16, int, "1: Enabled; 0: Disabled", "1A",
            9)

        }

    def read_with_retry(self, key, *, manage_connection: bool = True):
        for attempt in range(1, self.retries + 1):
            try:
                if manage_connection:
                    self.connect()
                return self.read(key)
            except Exception as e:
                if attempt < self.retries:
                    time.sleep(self.timeout)
                else:
                    syslog.syslog(f"Failed to read {key} after {self.retries} attempts: {e}")
                    raise
            finally:
                if manage_connection:
                    self.disconnect()

    def read_batch(self, batch: int, rtype=registerType.HOLDING):
        """
        Read all registers for a given batch in one contiguous Modbus read.
        Returns a dict of {register_name: decoded_value}.
        """
        regs = {k: v for k, v in self.registers.items() if (v[3] == rtype and v[8] == batch)}
        if not regs:
            return {}
        return self._read_all(regs, rtype)

    def read_batches(self, batches, rtype=registerType.HOLDING):
        out = {}
        for b in batches:
            out.update(self.read_batch(b, rtype=rtype))
        return out

    def write_with_retry(self, key: str, value: int, *, manage_connection: bool = True) -> bool:
        """Write a value to the car_charger with retries."""
        for attempt in range(1, self.retries + 1):
            try:
                if manage_connection:
                    self.connect()

                resp_ok = self.write(key, value)

                # IMPORTANT: pymodbus can “fail” without raising
                # if resp is None or (hasattr(resp, "isError") and resp.isError()):
                #     raise RuntimeError(f"Modbus write failed for {key}={value}: {resp}")
                if not resp_ok:
                    raise RuntimeError(f"Modbus write failed for {key}={value}")
                return True

            except Exception as e:
                if attempt < self.retries:
                    time.sleep(self.timeout)
                else:
                    syslog.syslog(f"Failed to write {key} after {self.retries} attempts: {e}")
                    return False
            finally:
                if manage_connection:
                    self.disconnect()

    def get_setpoint_current(self, *, manage_connection: bool = True) -> float:
        """
        The last written Modbus setpoint (what we *asked* the charger to do).
        """
        data = self.read_with_retry("modbus_slave_max_current", manage_connection = manage_connection)
        return float(data["modbus_slave_max_current"])

    def get_applied_current(self, *, manage_connection: bool = True) -> float:
        """
        The *actually enforced* current limit on the socket.
        """
        data = self.read_with_retry("actual_applied_max_current", manage_connection = manage_connection)
        return float(data["actual_applied_max_current"])

    def get_fallback_safe_current_time(self, *, manage_connection: bool = True) -> int:
        """
        The remaining time before the charger will switch back to safe current
        """
        data = self.read_with_retry("modbus_slave_max_current_valid_time", manage_connection = manage_connection)
        return int(data["modbus_slave_max_current_valid_time"])

    def get_accounted_for(self, *, manage_connection: bool = True) -> int:
        """
        See if our settings have been processed/accepted
        """
        data = self.read_with_retry("modbus_slave_received_setpoint_accounted_for", manage_connection = manage_connection)
        return int(data["modbus_slave_received_setpoint_accounted_for"])

    def get_status(self, *, manage_connection: bool = True) -> str:
        mode_3_state = self.read_with_retry("mode_3_state", manage_connection=manage_connection)
        raw = (mode_3_state or {}).get("mode_3_state")
        #status = MODE_3_STATE_MAP.get(str(raw).strip() if raw else "?", "Unknown")
        return raw

    def get_phases(self, *, manage_connection: bool = True) -> int:
        phases = self.read_with_retry('charge_using_1_or_3_phases', manage_connection=manage_connection)['charge_using_1_or_3_phases']
        return phases

    def get_current(self, *, manage_connection: bool = True) -> float:
        current = self.read_with_retry('modbus_slave_max_current', manage_connection=manage_connection)['modbus_slave_max_current']
        return current

    def get_power(self, *, manage_connection: bool = True) -> float:
        power = self.read_with_retry('real_power_sum', manage_connection=manage_connection)['real_power_sum']
        return power

    def pause_charging(self, *, manage_connection: bool = True) -> None:
        PAUSE_CURRENT = 0.0
        syslog.syslog("Stop Charging...")
        value = self.read_with_retry('modbus_slave_max_current', manage_connection=manage_connection)
        current = value['modbus_slave_max_current']
        syslog.syslog(f"Current usage in A: {current}")
        if current > 5.5:
            syslog.syslog("Pausing...")
            self.set_current(PAUSE_CURRENT, manage_connection=manage_connection)
            syslog.syslog("Paused...")
        else:
            syslog.syslog("Already paused charging...")

    def switch_phase(self, phases, *, manage_connection: bool = True) -> bool:
        if (phases == 1 or phases == 3):
            current_phases = self.get_phases(manage_connection=manage_connection)

            if current_phases == phases:
                syslog.syslog(f"No need to switch, already at {phases} phase...")
                return True
            else:
                try:
                    status = self.get_status(manage_connection=manage_connection)
                    if status in {"C2", "D2"}:  # Charging, so set current on 0.0 A
                        ok = self.set_current(0.0, manage_connection=False)
                        if not ok:
                            syslog.syslog("No confirmation charging has stopped, so not switching phases")
                            return False
                    syslog.syslog(f"Switch to {phases} phase(s)...")
                    syslog.syslog(f"Current phase(s): {current_phases}")
                    time.sleep(1.5) # To allow settling of current on 0.0 before switching phases
                    self.write_with_retry('charge_using_1_or_3_phases', phases, manage_connection=manage_connection)
                    return True
                except Exception as e:
                    syslog.syslog(e)
                finally:
                    current_phases = self.get_phases(manage_connection=manage_connection)
                    syslog.syslog(f"Current phase(s): {current_phases}")
                return True
        else:
            syslog.syslog(f"Invalid # of phases: {phases}...")
            return False

    def set_current(self, current, *, manage_connection: bool = True, verify: bool = True, abs_tol: float =0.3, timeout_s: float = 6.0, settle_s: float = 1.2) -> bool:
        """
        Write the requested current. If verify=True, wait until either:
          - actual_applied_max_current ~= requested (within abs_tol).
        Returns True on success, False on timeout.
        Performs a single retry write if verification initially fails.
        """
        requested = float(current)
        self.write_with_retry('modbus_slave_max_current', requested, manage_connection=manage_connection)
        if not verify:
            return True

        def _wait_ok(deadline: float) -> bool:
            # brief settle before polling
            time.sleep(settle_s)
            while time.time() < deadline:
                try:
                    applied = self.get_applied_current(manage_connection=manage_connection)
                    if abs(applied - requested) < abs_tol:
                        return True
                except Exception:
                    pass
                time.sleep(1)
            return False

        #try once
        if _wait_ok(time.time() + timeout_s):
            return True
        # single retry write + wait again
        self.write_with_retry("modbus_slave_max_current", requested, manage_connection=manage_connection)
        return _wait_ok(time.time() + timeout_s)

    def set_current_and_confirm(self, current, retries=3, first_sleep=0.8, tol=0.3):
        for i in range (retries):
            self.set_current(current,manage_connection=False,abs_tol=tol)
            time.sleep(first_sleep * (1.6 ** i))
            applied = self.get_applied_current(manage_connection=False)
            if abs(applied - current) <= tol:
                return True
        syslog.syslog(f"Current command pending: requested={current}, readback={applied}")
        return False

    def set_charge_profile(self, phases, current, *, manage_connection: bool = True):
        status = self.get_status(manage_connection=manage_connection)
        if status in {"B1", "B2", "C1", "C2", "D1", "D2"}: # Charging or Connected
            current_phases = int(self.get_phases(manage_connection=manage_connection))
            momentary_current = self.get_current(manage_connection=manage_connection)
            syslog.syslog(f"Currently Charge Profile is: Phase(s): {current_phases}; Current: {momentary_current} A.")
            syslog.syslog(f"Current Phase(s): {current_phases} versus Requested Phase(s): {phases}")
            if current_phases != phases:
                if status in {"C2", "D2"}: # Charging, so set current on 0.0 A
                    #self.pause_charging(manage_connection=manage_connection)
                    ok = self.set_current_and_confirm(0.0)
                    #time.sleep(1)
                if ok:
                    self.switch_phase(phases, manage_connection=manage_connection)
                else:
                    syslog.syslog("Not able to switch phase as no feedback that current is on 0.0 A. Continue with setting current...")

            self.set_current(current, verify=False, manage_connection=manage_connection)
            time.sleep(1)
            phases = self.get_phases(manage_connection=manage_connection)
            current = self.get_current(manage_connection=manage_connection)
            syslog.syslog(f"Charge Profile Set: Phase(s): {phases}; Current: {current} A.")
        else:
            syslog.syslog(f"Car is not connected: {status}, so no changes in charge profile applied.")