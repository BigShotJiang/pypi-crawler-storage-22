# algo-backend-framework-python

# 功能概述
- 配置
- 错误码、异常、参数检验报错转换
- 标准响应体、x-request-id
- 日志框架支持：loguru、nb_log
- 多进程prometheus指标
- otel

## 分支规范
- master分支: 归档分支
- release/release-×.×.×: 发布分支，×.×.×为版本号；修改[pyproject.toml](pyproject.toml)中的version构建并发布包
- dev分支: 开发分支；合并至release分支时，需要提mr，mr需要填写版本号和功能描述；需要充分自测和review之后才能合并至release
- feat/feat-×××××: 功能分支；合并至dev时需要mr，mr需要填写功能名称和功能描述；新功能或较大重构需要建feat分支，较小的改动不必开feat分支

## 本地调试

本地开发需要打包验证，则先构建包（但不要发布），然后在本地目录离线安装
```shell
# 构建包
uv build
# 拷贝wheel包到本地测试目录下执行以下命令
uv add algo_backend_framework-*.*.*-py3-none-any.whl
# 调试时发现包有问题，只需要remove后重新打包，并重新add
uv remove algo-backend-framework
```

## 开发约定
- 代码提交前进行sonar扫描和语法检查，并进行代码格式化
    ```
    uv run ruff format algo_backend/×××××
    ```
- 子模块__init__.py文件需要声明包内暴露模块，不建议用户通过包内文件名导入，以减少后期微调重构引起的不兼容
- 跨模块导入一律使用`from algo_backend.× import 模块名`的全限定包名，同级目录下导入从使用`from . import `


## 发布
- 在release分支进行构建和推送
```shell
uv build
# 推送ctcdn nexus
uv publish --index ctcdn-pypi-upload
# 推送pypi
uv publish
```