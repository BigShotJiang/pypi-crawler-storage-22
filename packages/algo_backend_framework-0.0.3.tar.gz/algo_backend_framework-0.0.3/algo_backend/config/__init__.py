from dotenv import load_dotenv

load_dotenv(".env")

from .basic_config import ErrorCodeConfig, ServiceConfig
from .loguru_config import LoguruConfig

__all__ = ["LoguruConfig", "ServiceConfig", "ErrorCodeConfig"]
