import os

from algo_backend.utils import OsAttrMeta


class ErrorCodeConfig:
    SERVICE_PREFIX: int = os.getenv("ERROR_CODE_SERVICE_PREFIX", "0")


class ServiceConfig(metaclass=OsAttrMeta):
    HTTP_PORT: int = 8100
    TIMEOUT_KEEP_ALIVE: int = 1000
    PROCESS_NUM: int = 1
