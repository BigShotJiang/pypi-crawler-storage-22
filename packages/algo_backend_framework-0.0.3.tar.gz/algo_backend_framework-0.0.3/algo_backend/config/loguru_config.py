from typing import List

from algo_backend.utils import OsAttrMeta


class LoguruConfig(metaclass=OsAttrMeta):
    LOGGER_PATH: str = "/logger"
    LOG_RETENTION_DAY: int = 60
    DISABLE_LOG_PKG: str = ""
    LOG_ADD_CONTAINED_ID: bool = False
    SAVE_INFO_LEVEL: bool = False
    SAVE_DEBUG_LOG: bool = True

    @classmethod
    def get_disable_log_pkg(cls) -> List[str]:
        if cls.DISABLE_LOG_PKG:
            return cls.DISABLE_LOG_PKG.split(",")
        else:
            return []
