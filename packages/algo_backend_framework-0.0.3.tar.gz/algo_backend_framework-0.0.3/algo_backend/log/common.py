class BasicLogStarter:
    """
    日志启动器，初始化日志格式和落盘等
    """

    def __init__(self, service_name: str):
        """
        :param service_name: 服务名
        """
        self.service_name = service_name

    def setup_log(self):
        """
        执行一些日志设置
        """
        pass
