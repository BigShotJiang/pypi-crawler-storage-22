from abc import ABC, abstractmethod


class AbstractMetricCollector(ABC):
    """指标收集器抽象基类"""

    def __init__(self, interval_sec: int = None):
        self.collect_interval = interval_sec or 30  # 收集间隔，秒

    @abstractmethod
    async def collect(self):
        """收集指标数据"""
        pass

    def set_interval(self, interval_sec: int):
        """设置收集间隔"""
        self.collect_interval = interval_sec
