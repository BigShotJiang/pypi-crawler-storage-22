from typing import Optional, List

from algo_backend.metrics import RequestTimeCostMiddleware
from starlette.middleware import Middleware


def http_request_time_cost_middleware(
    buckets: Optional[List[float]] = None, ignore_paths: Optional[List[str]] = None
):
    return Middleware(
        RequestTimeCostMiddleware, buckets=buckets, ignore_paths=ignore_paths
    )
