from .vo import AbstractRespVo, BaseRespVo

__all__ = ["BaseRespVo", "AbstractRespVo"]
