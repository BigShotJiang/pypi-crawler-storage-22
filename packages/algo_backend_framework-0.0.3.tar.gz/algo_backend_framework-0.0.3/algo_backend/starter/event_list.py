import asyncio
from typing import Any, Callable, Coroutine, List, Optional, Union


class EventList:
    def __init__(self):
        """
        普通函数和协程函数列表
        """
        self.__events: List[
            Union[Callable, Callable[[], Coroutine[Any, Any, None]]]
        ] = []

    def add(
        self,
        event: Optional[
            Union[Callable, Callable[[], Coroutine[Any, Any, None]]]
        ] = None,
    ):
        """添加事件到列表"""
        if event:
            self.__events.append(event)
            return self

    async def execute(self):
        """执行所有事件"""

        for event in self.__events:
            if asyncio.iscoroutinefunction(event):
                await event()
            else:
                event()
