import uuid

from fastapi import Header


def gen_random_request_id():
    return str(uuid.uuid4())


async def get_request_id(
    x_request_id: str = Header(gen_random_request_id(), alias="x-request-id"),
):
    """
    使用示例

    @app.post("/example/help")
    async def run(body: Body, reqid=Depends(get_request_id)):
        ...

    如果请求头中没有x-request-id，则会触发validate_interceptor的检验
    """
    return x_request_id
