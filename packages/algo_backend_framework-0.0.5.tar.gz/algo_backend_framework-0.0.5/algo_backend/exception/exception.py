from typing import Optional, TypeVar

from .status_code import (
    BasicApiId,
    BasicApiInnerErrorCode,
    BasicStatusCode,
    CommonStatusCode,
    add_service_prefix,
)


class BasicException(Exception):
    """
    基础异常类
    """

    def __init__(self, code: int, msg: str):
        super().__init__(msg)
        self.code = code
        self.msg = msg


# 定义泛型变量 T，限定为 BasicStatusCode 的子类
T = TypeVar("T", bound=BasicStatusCode)


class BasicCommonException(BasicException):
    def __init__(self, status_code: T, **kwargs):
        super().__init__(code=status_code.code, msg=status_code.msg.format(**kwargs))


# 定义泛型变量 ET，限定为 BasicApiInnerErrorCode 的子类
ET = TypeVar("ET", bound=BasicApiInnerErrorCode)


class BasicApiInnerException(BasicException):
    """
    接口内部异常类的基类
    """

    def __init__(self, status_code: ET, **kwargs):
        super().__init__(code=status_code.code, msg=status_code.msg.format(**kwargs))

    def standardize(self, api_id: BasicApiId) -> "BasicApiInnerException":
        """
        生8位错误码
        :param api_id:
        :return:
        """
        self.code = BasicApiInnerErrorCode.gen_standard_code(
            api_id=api_id, inner_error_code=self.code
        )
        # 增加两位应用码
        self.code = add_service_prefix(self.code)
        return self


def transfer_exception(
    e: Exception,
    api_name: Optional[str] = None,
    request_id: Optional[str] = None,
    api_id: Optional[BasicApiId] = None,
) -> BasicException:
    _params = dict(api_name=api_name, request_id=request_id)
    if isinstance(e, BasicCommonException):
        return e
    elif isinstance(e, BasicApiInnerException):
        return e.standardize(api_id=api_id)
    else:
        return BasicCommonException(CommonStatusCode.UNKNOWN_ERROR, msg=str(e))
