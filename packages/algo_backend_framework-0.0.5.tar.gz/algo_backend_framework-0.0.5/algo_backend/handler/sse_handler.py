import logging
import time
import traceback
from functools import wraps
from typing import AsyncIterable, Callable, TypeVar

from pydantic import BaseModel

from algo_backend.exception import (
    BasicApiId,
    BasicException,
    DefaultApiErrorCode,
    transfer_exception,
)
from algo_backend.metrics import PrometheusTimeCostMetricSetting
from algo_backend.schema import SseVoGenerator

logger = logging.getLogger(__name__)


D = TypeVar("D", bound=BaseModel)


def sse_timing_and_exception_handler(
    transfer_obj_cls=type(SseVoGenerator),
    *,
    api_id: BasicApiId = DefaultApiErrorCode.DEFAULT_ERROR,
    api_name: str = ""
):
    def decorator(
        func: Callable[..., AsyncIterable[D]],
    ) -> Callable[..., AsyncIterable[D]]:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            request_id = kwargs.get("request_id", None) or kwargs.get("reqid", None)
            _name = func.__name__ or api_name

            transfer_obj: SseVoGenerator = transfer_obj_cls(request_id=request_id)
            # 提供额外参数，方便丰富上下文
            transfer_obj.extract_info(*args, **kwargs)

            start_time = time.perf_counter()
            # 执行原函数
            logger.info(f"ReqId: {request_id} | Function: {_name} | Start")

            try:
                start_event = transfer_obj.start()
                if start_event:
                    yield start_event

                async for item in func(*args, **kwargs):
                    yield transfer_obj.generate(item)

                elapsed_time = time.perf_counter() - start_time

                logger.info(
                    f"ReqId: {request_id} | Function: {_name} | COST:{elapsed_time:.4f}s"
                )
                PrometheusTimeCostMetricSetting.api_metrics_instance().add(
                    _name, elapsed_time
                )

                end_event = transfer_obj.done()
                if end_event:
                    yield end_event

            except Exception as e:
                # 计算耗时
                elapsed_time = time.perf_counter() - start_time
                PrometheusTimeCostMetricSetting.api_metrics_instance().add_error(_name)
                # 记录异常信息和完整堆栈
                logger.error(
                    f"ReqId: {request_id} | Function: {_name} | COST:{elapsed_time:.4f}s | Exception: {str(e)}\n"
                    f"Traceback:\n{traceback.format_exc()}"
                )

                basic_exception: BasicException = transfer_exception(
                    e, api_name=_name, api_id=api_id, request_id=request_id
                )
                yield transfer_obj.error(basic_exception)

        return wrapper

    return decorator
