from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware

default_cors_middleware = Middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
