from abc import ABC, abstractmethod
from typing import TypeVar, Optional

from pydantic import BaseModel

from algo_backend.exception import BasicException


T = TypeVar("T", bound=BaseModel)


class SseVoGenerator(ABC):
    def __init__(self, request_id: str=None):
        self.request_id = request_id

    @abstractmethod
    def extract_info(self, *args, **kwargs):
        """额外获取信息"""
        ...

    @abstractmethod
    def start(self) -> Optional[T]:
        """
        返回None时，sse_timing_and_exception_handler会忽略这一步
        """
        ...

    @abstractmethod
    def generate(self, content: BaseModel) -> T: ...

    @abstractmethod
    def done(self) -> T:
        """
        返回None时，sse_timing_and_exception_handler会忽略这一步
        """
        ...

    @abstractmethod
    def error(self, exception: BasicException) -> T:
        ...