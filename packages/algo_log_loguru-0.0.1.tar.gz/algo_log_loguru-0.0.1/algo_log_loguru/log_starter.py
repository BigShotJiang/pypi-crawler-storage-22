import os
import socket

from .loguru_config import LoguruConfig
from algo_backend.log import BasicLogStarter
from algo_backend.starter import DefaultAlgoServiceStarter
from loguru import logger

from .log_clean import LoguruCleaner
from .log_setup import LoguruSetup


class LoguruStarter(BasicLogStarter):
    """
    容器内日志目录默认是：/logger/服务名
    """

    def __init__(self, service_name: str):
        super().__init__(service_name)
        self.log_config = LoguruConfig()

    @property
    def service_log_dir(self):
        return os.path.join(self.log_config.LOGGER_PATH, self.service_name)

    def setup_log(self):
        """
        日志设置
        """

        LoguruSetup.rotate_daily(
            log_dir=self.service_log_dir,
            service_name=self.add_container_id(service_name=self.service_name),
            add_pid_suffix=True,
            save_info=self.log_config.SAVE_INFO_LOG,
            save_debug=self.log_config.SAVE_DEBUG_LOG,
            save_log=self.log_config.SAVE_LOG,
            disable_log_pkg=self.log_config.get_disable_log_pkg(),
        )

        for pkg in self.log_config.get_disable_log_pkg():
            # 忽略一些包的日志
            logger.debug(f"ignore log: {pkg}")
            logger.disable(pkg)

    def run_log_cleaner(self):
        """
        启动定时任务清理日志
        """
        LoguruCleaner.schedule_run(
            log_dir=self.service_log_dir,
            retention_day=self.log_config.LOG_RETENTION_DAY,
        )

    def add_container_id(self, service_name: str):
        if not self.log_config.LOG_ADD_CONTAINED_ID:
            logger.info("日志名不增加containerId")
            return service_name

        try:
            socket_hostname = f"-{socket.gethostname()}"
        except:
            socket_hostname = ""
        if service_name in socket_hostname:
            return service_name
        else:
            return f"{service_name}{socket_hostname}"

    def service_generator_hook(self, service_generate: DefaultAlgoServiceStarter):
        """
        钩子函数
        """
        service_generate.insert_event(self.setup_log)
        service_generate.append_event(self.run_log_cleaner)
