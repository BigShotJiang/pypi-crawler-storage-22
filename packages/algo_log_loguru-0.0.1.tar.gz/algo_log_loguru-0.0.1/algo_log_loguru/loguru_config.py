from typing import List

from algo_backend.config import CommonLogConfig


class LoguruConfig(CommonLogConfig):
    DISABLE_LOG_PKG: str = ""
    LOG_ADD_CONTAINED_ID: bool = False
    SAVE_INFO_LOG: bool = False
    SAVE_DEBUG_LOG: bool = True

    def get_disable_log_pkg(self) -> List[str]:
        if self.DISABLE_LOG_PKG:
            return self.DISABLE_LOG_PKG.split(",")
        else:
            return []
