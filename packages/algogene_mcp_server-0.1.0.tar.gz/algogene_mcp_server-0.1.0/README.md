# ALGOGENE MCP Server

## Introduction

The `algogene_mcp_server` provides a Python-based interface for accessing the ALGOGENE API, enabling users to conduct strategy backtest, real-time data analytics, and manage trading activities.

## Installation

1. **Clone the Repository:**

```
git clone https://github.com/yourusername/algogene_mcp_server.git
cd algogene_mcp_server
```

2. **Set Up Your Environment:**
Ensure you have Python 3.11 or later installed.


3. **Install Dependencies:**
```
pip install requests mcp-server
```

4. **Update Configuration:**
Modify the configuration file located at `/config/__init__.py`.

```python
BASE_URL = "https://algogene.com/rest"

ALGOGENE_USER = "YOUR_ALGOGENE_USER_ID"
ALGOGENE_API_KEY = "YOUR_ALGOGENE_API_KEY"
```



## Running the Server
1. Start the Server:

```
python main.py
```

You can customize options using command-line arguments:

```bash
python main.py --transport streamable-http --port 8080 --host 0.0.0.0
```

2. Connect and Execute Commands:

- The server runs in STDIO mode by default. You can connect to it via your MCP client and run commands based on available tools.


## Tools Overview
1. Contract Specification:
- get_instruments: Get all available instruments available on ALGOGENE
- get_instrument_meta: Get contract specification of a financial instrument
- search_instrument: Search related financial instruments based on matched keywords of symbol or description
- list_econs_series: List out all available economic time series
- search_econs_series: Search related economic time series based on matched keywords of titles, geo and freq
- get_econs_series_meta: Get meta data or specification of an economic time series

2. Real-time Data:
- get_realtime_prices: Get current price for trading symbol(s)
- get_realtime_price_24hrchange: Get the recent 24 hours market price change
- get_realtime_exchange_rate: Get current exchange rate between 2 currencies
- get_realtime_news: Get latest news for a specified language/source/categroy
- get_realtime_weather: Get latest weather info for a specified region
- get_realtime_econs_calendar: Get the upcoming economic calendar info such as holiday, statistics release, president speech, etc
- get_realtime_econs_stat: Get the most recent released economic statistics

3. Historical Data:
- get_history_price: Get historical market price
- get_history_news: Get historical news
- get_history_weather: Get historical weather
- get_history_corp_announcement: Get company's corporate announcement history
- get_history_econs_calendar: Get economic calendar history, such as holiday, statistics release, president speech, etc
- get_history_econs_stat: Get historical released economic statistics
- strategy_market_perf: Get performance statistics for a market index 

4. Trading Account Current Status:
- get_session: Get session token that will be used to access account and order related resources
- list_accounts: List out all your trading accounts with latest balance on ALGOGENE.
- get_positions: Get outstanding positions of a trading account
- get_balance: Get current balance of a trading account
- get_opened_trades: Get opened trades of a trading account
- get_pending_trades: Get pending trades (or limit orders) of a trading account
- set_account_config: Trading connection setup with your personal broker/exchange account on ALGOGENE.

5. Trading Account History: 
- strategy_trade: Get transaction history of a trading account
- strategy_bal: Get daily history of account balance of a trading account
- strategy_pos: Get daily history of position of a trading account
- strategy_pl: Get daily history of cumulative profit/loss of a trading account
- strategy_cashflow: Get history of cash flow (eg. deposit, withdrawal, dividend payment, etc) of a trading account
- strategy_stats: Get performance statistics history and trading setting of a trading account

6. Order Placecment and Management: 
- open_order: Place an order on a trading account
- query_order: Query an order's details of a trading account
- update_pending_order: Update trading parameters of a pending order
- update_opened_order: Update trading parameters of an outstanding/opened order
- cancel_orders: cancel a list of unfilled limit/stop orders
- close_orders: close a list of outstanding orders

7. Other Trading Apps: 
- app_predict_sentiment: Give a sentiment score for a given text (eg. news, blog posts, financial reports)


