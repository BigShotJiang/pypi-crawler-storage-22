from typing import TypeVar, MutableSequence

T =  TypeVar("T")

# We use mutable sequence because we need to modify the list in place
def quick_sort(sequence: MutableSequence[T]):
    """
    In-place Quick Sort implementation using divide-and-conquer.

    This function sorts the given sequence in place.

    Average Time Complexity: O(n log n)
    Worst Case Time Complexity: O(n^2)
    Space Complexity: O(log n) due to recursion
    """

    if len(sequence) <= 1:
        return

    _quick_sort(sequence, 0, len(sequence) - 1)


def _partition(sequence,low,high)-> int:
    """
    Partition the sequence using the Lomuto partition scheme.

    This function selects the last element as the pivot and rearranges
    the sequence in place so that:
    - all elements less than or equal to the pivot are placed to its left
    - all elements greater than the pivot are placed to its right

    The pivot is moved to its final correct position, and its index
    is returned.

    :param sequence: Mutable sequence to be partitioned
    :param low: Starting index of the subarray
    :param high: Ending index of the subarray (pivot index)
    :return: Final index position of the pivot
    """

    pivot = sequence[high]

    # at the start, no elements <= pivot.
    i = low - 1

    #  we need to arrange the sub array into these segments: [≤ pivot  |  > pivot  | pivot]
    for j in range(low,high): # up to high - 1
        if sequence[j] <= pivot:
            i += 1
            sequence[i],sequence[j] = sequence[j],sequence[i]

    # place pivot in its final position
    sequence[i+1],sequence[high] = sequence[high], sequence[i+1]

    return i + 1


def _quick_sort(sequence,low,high):
    """
    Recursively sort a subarray of the sequence in place using Quick Sort.

    This helper function sorts the elements in the index range
    sequence[low : high + 1] using the divide-and-conquer approach.
    It assumes that the partitioning logic correctly places the pivot
    in its final position and recursively sorts the left and right
    subarrays around the pivot.

    Base case:
    - If low >= high, the subarray has zero or one element and is already sorted.

    :param sequence: Mutable sequence to be sorted in place
    :param low: Starting index of the subarray
    :param high: Ending index of the subarray
    :return: None
    """

    # If the subarray has 0 or 1 element
    # That means it is already sorted
    # This happens when:low >= high

    if low >= high:
        return # No return: because we do this in place

    p = _partition(sequence,low,high)

    _quick_sort(sequence,low,p-1)
    _quick_sort(sequence,p+1,high)

