# algokit-py

A lightweight Python algorithms library with clean, well-documented, and tested implementations.
Designed for learning, interviews, and real-world algorithm reasoning.

## Features

### Search Algorithms
- Linear Search
- Binary Search (iterative, invariant-based)

### Sorting Algorithms
- Bubble Sort (in-place, stable, O(n²))
- Insertion Sort (in-place, stable, O(n²))
- Merge Sort (stable, divide-and-conquer, O(n log n), extra space)
- Quick Sort (in-place, average O(n log n), not stable)

## Usage

### Install

```python
pip install algokit-py
```

### Search
```python
from algokit_py.search import linear_search, binary_search

print(linear_search([1, 2, 3], 2))
print(binary_search([1, 2, 3], 2))
```

### Sorting
```python
from algokit_py.sort import bubble_sort, insertion_sort, merge_sort, quick_sort

# Bubble Sort (in-place)
data = [3, 1, 2]
bubble_sort(data)
print(data)  # [1, 2, 3]

# Insertion Sort (in-place)
data = [3, 1, 2]
insertion_sort(data)
print(data)  # [1, 2, 3]

# Merge Sort (returns new list)
print(merge_sort([3, 1, 2]))  # [1, 2, 3]

# Quick Sort (in-place)
data = [3, 1, 2]
quick_sort(data)
print(data)  # [1, 2, 3]
```
