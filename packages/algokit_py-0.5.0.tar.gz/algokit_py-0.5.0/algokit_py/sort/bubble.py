from typing import MutableSequence, TypeVar

T = TypeVar('T')

# NOTE:
# This is the basic bubble sort implementation.
# An early-exit optimization using a `swapped` flag
# can reduce the best-case time complexity to O(n).
# This optimization will be added in a future version.

def bubble_sort(sequence: MutableSequence[T]) -> None:
    """
    In-place Bubble Sort implementation.

    This function sorts the given mutable sequence in place by repeatedly
    swapping adjacent elements if they are in the wrong order. After each
    outer pass, the largest remaining element is guaranteed to be placed
    at its final correct position.

    Bubble sort is a stable sorting algorithm.

    Worst Case Time Complexity: O(n^2)
    Average Case Time Complexity: O(n^2)
    Best Case Time Complexity: O(n) (when the sequence is already sorted, with optimization)
    Space Complexity: O(1)

    :param sequence: Mutable sequence to be sorted in place
    :return: None
    """
    length = len(sequence)
    for i in range(length):
        for j in range(length - 1 - i):
            if sequence[j] > sequence[j + 1]:
                sequence[j], sequence[j + 1] = sequence[j + 1], sequence[j]
