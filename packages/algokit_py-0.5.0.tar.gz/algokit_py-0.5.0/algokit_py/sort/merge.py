from typing import Sequence, TypeVar

T = TypeVar('T')

def merge_sort(sequence: Sequence[T]) -> list[T]:
    """
    Merge sort implementation.

    Base case:
    - Sequences of length 0 or 1 are already sorted.

    Worst Case Time Complexity: O(n log n)
    Space Complexity: O(n)
    """
    if len(sequence) <= 1:
        return list(sequence)

    middle = len(sequence) // 2
    left = sequence[:middle]
    right = sequence[middle:]

    sorted_left = merge_sort(left)
    sorted_right = merge_sort(right)

    merged = []
    i = j = 0

    while i < len(sorted_left) and j < len(sorted_right):
        if sorted_left[i] <= sorted_right[j]:
            merged.append(sorted_left[i])
            i += 1
        else:
            merged.append(sorted_right[j])
            j += 1

    merged.extend(sorted_left[i:])
    merged.extend(sorted_right[j:])

    return merged




