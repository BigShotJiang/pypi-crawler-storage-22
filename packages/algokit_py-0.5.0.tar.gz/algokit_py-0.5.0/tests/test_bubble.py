from algokit_py.sort import bubble_sort


def test_bubble_sort_basic():
    data = [3, 1, 2]
    bubble_sort(data)
    assert data == [1, 2, 3]


def test_bubble_sort_already_sorted():
    data = [1, 2, 3, 4]
    bubble_sort(data)
    assert data == [1, 2, 3, 4]


def test_bubble_sort_reverse():
    data = [4, 3, 2, 1]
    bubble_sort(data)
    assert data == [1, 2, 3, 4]


def test_bubble_sort_duplicates():
    data = [3, 1, 2, 1]
    bubble_sort(data)
    assert data == [1, 1, 2, 3]


def test_bubble_sort_single_element():
    data = [5]
    bubble_sort(data)
    assert data == [5]


def test_bubble_sort_empty():
    data = []
    bubble_sort(data)
    assert data == []
