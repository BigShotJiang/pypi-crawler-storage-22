from algokit_py.sort import quick_sort


def test_quick_sort_basic():
    data = [3, 1, 2]
    quick_sort(data)
    assert data == [1, 2, 3]


def test_quick_sort_already_sorted():
    data = [1, 2, 3, 4]
    quick_sort(data)
    assert data == [1, 2, 3, 4]


def test_quick_sort_reverse():
    data = [4, 3, 2, 1]
    quick_sort(data)
    assert data == [1, 2, 3, 4]


def test_quick_sort_duplicates():
    data = [3, 1, 2, 1]
    quick_sort(data)
    assert data == [1, 1, 2, 3]


def test_quick_sort_single_element():
    data = [5]
    quick_sort(data)
    assert data == [5]


def test_quick_sort_empty():
    data = []
    quick_sort(data)
    assert data == []
