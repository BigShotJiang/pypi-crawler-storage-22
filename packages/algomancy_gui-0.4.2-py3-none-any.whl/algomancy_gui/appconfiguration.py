import platform
from typing import Any, Dict, List, Type
import os

from algomancy_content import LibraryManager as library
from algomancy_data import Schema, BASE_DATA_BOUND, DataSource
from algomancy_content.pages.page import (
    BaseHomePage,
    BaseScenarioPage,
    BaseComparePage,
    BaseOverviewPage,
    BaseDataPage,
)
from algomancy_gui.stylingconfigurator import StylingConfigurator
from algomancy_scenario import ALGORITHM, BASE_KPI
from algomancy_scenario.core_configuration import CoreConfiguration


class AppConfiguration(CoreConfiguration):
    """
    Central configuration object for the Algomancy dashboard.

    This class extends `CoreConfiguration` with GUI-specific settings such as
    page definitions, styling, and server parameters. It is the primary
    configuration object used when launching the Dash-based dashboard.

    Construct with your configuration choices; validation runs automatically
    on creation. Use the `as_dict()` method to obtain the dictionary format
    expected by `DashLauncher.build()` and `SettingsManager`.

    Args:
        use_sessions (bool): Enable multi-session support. Defaults to False.
        assets_path (str): Path to static assets directory (CSS, JS, images).
            Defaults to "assets".
        data_path (str): Path to data storage directory. Defaults to "data".
        has_persistent_state (bool): Enable disk persistence for data and scenarios.
            Defaults to False.
        save_type (str | None): Persistence format ("json" or None). Defaults to "json".
        data_object_type (type[BASE_DATA_BOUND] | None): Data container class type.
            Defaults to DataSource.
        etl_factory (Any | None): ETL factory instance for data transformations.
            Defaults to None.
        kpi_templates (Dict[str, Type[BASE_KPI]] | None): Mapping of KPI template names
            to classes. Defaults to None.
        algo_templates (Dict[str, Type[ALGORITHM]] | None): Mapping of algorithm template
            names to classes. Defaults to None.
        input_configs (List[InputFileConfiguration] | None): Input file configurations.
            Defaults to None.
        autocreate (bool | None): Create default scenario on startup. Defaults to False.
        default_algo (str | None): Default algorithm name to use. Defaults to None.
        default_algo_params_values (Dict[str, Any] | None): Default algorithm parameters.
            Defaults to None.
        autorun (bool | None): Run algorithm automatically on startup. Defaults to False.
        home_page (BaseHomePage | str): Home page implementation or "standard".
            Defaults to "standard".
        data_page (BaseDataPage | str): Data page implementation or "placeholder".
            Defaults to "placeholder".
        scenario_page (BaseScenarioPage | str): Scenario page implementation or "placeholder".
            Defaults to "placeholder".
        compare_page (BaseComparePage | str): Compare page implementation or "placeholder".
            Defaults to "placeholder".
        overview_page (BaseOverviewPage | str): Overview page implementation or "standard".
            Defaults to "standard".
        styling_config (Any | None): Custom styling configuration dictionary.
            Defaults to StylingConfigurator.get_cqm_config().
        use_cqm_loader (bool): Enable specialized CQM data loader. Defaults to False.
        title (str): Dashboard title displayed in browser. Defaults to "Algomancy Dashboard".
        host (str | None): Server host address. Defaults to "127.0.0.1" (Windows)
            or "0.0.0.1" (Linux).
        port (int | None): Server port number (1-65535). Defaults to 8050.
        compare_default_open (List[str] | None): Compare page sections to expand by default
            (e.g., ["side-by-side", "kpis"]). Defaults to [].
        compare_ordered_list_components (List[str] | None): Order of compare page sections.
            Defaults to [].
        use_data_page_spinner (bool): Show loading spinner on Data page. Defaults to True.
        use_scenario_page_spinner (bool): Show loading spinner on Scenario page.
            Defaults to True.
        use_compare_page_spinner (bool): Show loading spinner on Compare page.
            Defaults to True.
        allow_parameter_upload_from_file (bool): Allow parameter file uploads.
            Defaults to False.
        use_authentication (bool): Enable dashboard authentication. Defaults to False.

    Attributes:
        assets_path (str): Path to the dashboard's assets directory.
        home_page (BaseHomePage | str): Home page configuration.
        data_page (BaseDataPage | str): Data Management page configuration.
        scenario_page (BaseScenarioPage | str): Scenario configuration page.
        compare_page (BaseComparePage | str): Result Comparison page configuration.
        overview_page (BaseOverviewPage | str): Overview/Analytics page configuration.
        styling_config (Any): Dictionary containing styling and layout preferences.
        use_cqm_loader (bool): Whether to use the specialized CQM data loader.
        host (str): Network host address for the Dash server.
        port (int): Port number for the Dash server.
        compare_default_open (List[str]): List of compare page sections open by default.
        compare_ordered_list_components (List[str]): Ordering of compare page components.
        show_loading_on_datapage (bool): Whether to show loading spinner on Data page.
        show_loading_on_scenariopage (bool): Whether to show loading spinner on Scenario page.
        show_loading_on_comparepage (bool): Whether to show loading spinner on Compare page.
        allow_parameter_upload_from_file (bool): Allow algorithm parameter file uploads.
        use_authentication (bool): Whether dashboard authentication is enabled.

    Example:
        Create a basic dashboard configuration:

        >>> from algomancy_gui import AppConfiguration
        >>> config = AppConfiguration(
        ...     title="My Custom Dashboard",
        ...     port=9000,
        ...     use_sessions=True,
        ...     assets_path="custom_assets",
        ... )
        >>> config.port
        9000
        >>> config_dict = config.as_dict()
    """

    def __init__(
        self,
        # === session manager configuration ===
        use_sessions: bool = False,
        # === path specifications ===
        assets_path: str = "assets",  # gui
        data_path: str = "data",
        # === data manager configuration ===
        has_persistent_state: bool = False,
        save_type: str | None = "json",
        data_object_type: type[BASE_DATA_BOUND] | None = DataSource,
        # === scenario manager configuration ===
        etl_factory: Any | None = None,
        kpi_templates: Dict[str, Type[BASE_KPI]] | None = None,
        algo_templates: Dict[str, Type[ALGORITHM]] | None = None,
        schemas: List[Schema] | None = None,
        # === auto start/create features ===
        autocreate: bool | None = False,
        default_algo: str | None = None,
        default_algo_params_values: Dict[str, Any] | None = None,
        autorun: bool | None = False,
        # === content functions ===
        home_page: BaseHomePage | str = "standard",  # gui
        data_page: BaseDataPage | str = "placeholder",  # gui
        scenario_page: BaseScenarioPage | str = "placeholder",  # gui
        compare_page: BaseComparePage | str = "placeholder",  # gui
        overview_page: BaseOverviewPage | str = "standard",  # gui
        # === styling configuration ===
        styling_config: Any | None = StylingConfigurator.get_cqm_config(),  # gui
        use_cqm_loader: bool = False,  # gui
        # === misc dashboard configurations ===
        title: str = "Algomancy Dashboard",
        host: str | None = None,  # gui/api
        port: int | None = None,  # gui/api
        # === page configurations ===
        compare_default_open: List[str] | None = None,  # gui
        compare_ordered_list_components: List[str] | None = None,  # gui
        use_data_page_spinner: bool = True,  # gui
        use_scenario_page_spinner: bool = True,  # gui
        use_compare_page_spinner: bool = True,  # gui
        allow_parameter_upload_from_file: bool = False,  # gui
        # === authentication ===
        use_authentication: bool = False,  # gui
    ):
        """
        Initializes the AppConfiguration.

        Args:
            use_sessions: Enable multi-session support. Inherited from CoreConfiguration.
            assets_path: Path to static assets. Defaults to "assets".
            data_path: Path to data storage. Inherited from CoreConfiguration.
            has_persistent_state: Enable disk persistence. Inherited from CoreConfiguration.
            save_type: Persistence format. Inherited from CoreConfiguration.
            data_object_type: Data container class. Inherited from CoreConfiguration.
            etl_factory: ETL factory instance. Inherited from CoreConfiguration.
            kpi_templates: Mapping of KPI templates. Inherited from CoreConfiguration.
            algo_templates: Mapping of algorithm templates. Inherited from CoreConfiguration.
            input_configs: Input file configurations. Inherited from CoreConfiguration.
            autocreate: Create default scenario on start. Inherited from CoreConfiguration.
            default_algo: Default algorithm name. Inherited from CoreConfiguration.
            default_algo_params_values: Default algorithm parameters. Inherited from CoreConfiguration.
            autorun: Run algorithm on startup. Inherited from CoreConfiguration.
            home_page: Home page implementation or "standard". Defaults to "standard".
            data_page: Data page implementation or "placeholder". Defaults to "placeholder".
            scenario_page: Scenario page implementation or "placeholder". Defaults to "placeholder".
            compare_page: Compare page implementation or "placeholder". Defaults to "placeholder".
            overview_page: Overview page implementation or "standard". Defaults to "standard".
            styling_config: Custom styling configuration. Defaults to CQM styling.
            use_cqm_loader: Enable CQM data loader. Defaults to False.
            title: Dashboard title. Defaults to "Algomancy Dashboard".
            host: Server host address. Defaults to 127.0.0.1 (Win) or 0.0.0.1 (Linux).
            port: Server port. Defaults to 8050.
            compare_default_open: Sections to expand on compare page. Defaults to [].
            compare_ordered_list_components: Order of compare page sections. Defaults to [].
            use_data_page_spinner: Show spinner on Data page. Defaults to True.
            use_scenario_page_spinner: Show spinner on Scenario page. Defaults to True.
            use_compare_page_spinner: Show spinner on Compare page. Defaults to True.
            allow_parameter_upload_from_file: Allow parameter file uploads. Defaults to False.
            use_authentication: Enable dashboard authentication. Defaults to False.
        """
        # initialize core part
        super().__init__(
            use_sessions=use_sessions,
            data_path=data_path,
            has_persistent_state=has_persistent_state,
            save_type=save_type,
            data_object_type=data_object_type,
            etl_factory=etl_factory,
            kpi_templates=kpi_templates,
            algo_templates=algo_templates,
            schemas=schemas,
            autocreate=autocreate,
            default_algo=default_algo,
            default_algo_params_values=default_algo_params_values,
            autorun=autorun,
            title=title,
        )

        # paths (GUI)
        self.assets_path = assets_path

        # content + callbacks
        self.home_page = home_page
        self.data_page = data_page
        self.scenario_page = scenario_page
        self.compare_page = compare_page
        self.overview_page = overview_page

        # styling + misc
        self.styling_config = styling_config
        self.use_cqm_loader = use_cqm_loader
        self.host = host or self._get_default_host()
        self.port = port or 8050

        # settings pages
        self.compare_default_open = compare_default_open or []
        self.compare_ordered_list_components = compare_ordered_list_components or []
        self.show_loading_on_datapage = use_data_page_spinner
        self.show_loading_on_scenariopage = use_scenario_page_spinner
        self.show_loading_on_comparepage = use_compare_page_spinner
        self.allow_parameter_upload_from_file = allow_parameter_upload_from_file

        # auth
        self.use_authentication = use_authentication

        # validate GUI-specific pieces immediately (core validated in super())
        self._validate_gui()

    # public API
    def as_dict(self) -> Dict[str, Any]:
        """
        Serializes the configuration to a dictionary.

        Converts all configuration attributes into a dictionary representation
        suitable for JSON serialization, storage, or passing to other
        components like `DashLauncher.build()` or `SettingsManager`. This
        method is the inverse of `from_dict()`.

        Returns:
            A dictionary containing all configuration parameters as key-value
            pairs. Keys match the parameter names from `__init__`, with the
            exception of `allow_parameter_upload_from_file` which is mapped
            to `allow_param_upload_by_file` for backward compatibility.

        Example:
            >>> config = AppConfiguration(
            ...     title="My Dashboard",
            ...     port=9000,
            ...     use_sessions=True,
            ... )
            >>> config_dict = config.as_dict()
            >>> config_dict["port"]
            9000
            >>> config_dict["title"]
            'My Dashboard'
        """

        return {
            # === session manager configuration ===
            "use_sessions": self.use_sessions,
            # === path specifications ===
            "assets_path": self.assets_path,
            "data_path": self.data_path,
            # === data manager configuration ===
            "has_persistent_state": self.has_persistent_state,
            "save_type": self.save_type,
            "data_object_type": self.data_object_type,
            # === scenario manager configuration ===
            "etl_factory": self.etl_factory,
            "kpi_templates": self.kpi_templates,
            "algo_templates": self.algo_templates,
            "schemas": self.schemas,
            "autocreate": self.autocreate,
            "default_algo": self.default_algo,
            "default_algo_params_values": self.default_algo_params_values,
            "autorun": self.autorun,
            # === content functions ===
            "home_page": self.home_page,
            "data_page": self.data_page,
            "scenario_page": self.scenario_page,
            "compare_page": self.compare_page,
            "overview_page": self.overview_page,
            # === styling configuration ===
            "styling_config": self.styling_config,
            "use_cqm_loader": self.use_cqm_loader,
            # === misc dashboard configurations ===
            "title": self.title,
            "host": self.host,
            "port": self.port,
            # === page configurations ===
            "compare_default_open": self.compare_default_open,
            "compare_ordered_list_components": self.compare_ordered_list_components,
            "show_loading_on_datapage": self.show_loading_on_datapage,
            "show_loading_on_scenariopage": self.show_loading_on_scenariopage,
            "show_loading_on_comparepage": self.show_loading_on_comparepage,
            "allow_param_upload_by_file": self.allow_parameter_upload_from_file,
            # === authentication ===
            "use_authentication": self.use_authentication,
        }

    # validation helpers (GUI layer)
    def _validate_gui(self) -> None:
        self._validate_paths_gui()
        self._validate_values_gui()
        self._validate_pages()
        self._validate_page_configurations()

    def _validate_pages(self):
        # fetch pages that were passed as str
        home, data, scenario, compare, overview = library.get_pages(self.as_dict())

        # check home page attributes
        assert hasattr(home, "create_content")
        assert hasattr(home, "register_callbacks"), (
            "home_page.register_callbacks must be a function"
        )

        # check data page attributes
        assert hasattr(data, "create_content"), (
            "data_page.create_content must be a function"
        )
        assert hasattr(data, "register_callbacks"), (
            "data_page.register_callbacks must be a function"
        )

        # check scenario page attributes
        assert hasattr(scenario, "create_content"), (
            "scenario_page.create_content must be a function"
        )
        assert hasattr(scenario, "register_callbacks"), (
            "scenario_page.register_callbacks must be a function"
        )

        # check compare page attributes
        assert hasattr(compare, "create_side_by_side_content"), (
            "compare_page.create_side_by_side_content must be a function"
        )
        assert hasattr(compare, "create_compare_section"), (
            "compare_page.create_compare_section must be a function"
        )
        assert hasattr(compare, "create_details_section"), (
            "compare_page.create_details_section must be a function"
        )
        assert hasattr(compare, "register_callbacks"), (
            "compare_page.register_callbacks must be a function"
        )

        # check overview page attributes
        assert hasattr(overview, "create_content"), (
            "overview_page.create_content must be a function"
        )
        assert hasattr(overview, "register_callbacks"), (
            "scenario_page.register_callbacks must be a function"
        )

    def _validate_page_configurations(self) -> None:
        # basic type checks for collections
        if not isinstance(self.compare_default_open, list):
            raise ValueError("compare_default_open must be a list of strings")
        if not isinstance(self.compare_ordered_list_components, list):
            raise ValueError(
                "compare_ordered_list_components must be a list of strings"
            )

        # ensure all strings are valid
        admissible_values = ["side-by-side", "kpis", "compare", "details"]
        for component in self.compare_default_open:
            if not isinstance(component, str):
                raise ValueError(
                    f"compare_default_open must be a list of strings, but contains {component}"
                )
            if component not in admissible_values:
                raise ValueError(
                    f"compare_default_open contains invalid component: {component}"
                )

        for component in self.compare_ordered_list_components:
            if not isinstance(component, str):
                raise ValueError(
                    f"compare_ordered_list_components must be a list of strings, but contains {component}"
                )
            if component not in admissible_values:
                raise ValueError(
                    f"compare_ordered_list_components contains invalid component: {component}"
                )

        # ensure all strings are unique
        if len(self.compare_default_open) != len(set(self.compare_default_open)):
            raise ValueError("compare_default_open contains duplicate values")
        if len(self.compare_ordered_list_components) != len(
            set(self.compare_ordered_list_components)
        ):
            raise ValueError(
                "compare_ordered_list_components contains duplicate values"
            )

    def _validate_paths_gui(self) -> None:
        if self.assets_path is None or self.assets_path == "":
            raise ValueError("assets_path must be provided")
        if not os.path.isdir(self.assets_path):
            raise ValueError(
                f"assets_path does not exist or is not a directory: {self.assets_path}"
            )

    def _validate_values_gui(self) -> None:
        # booleans allowed to be False, but must not be None if specified
        if self.use_authentication is None:
            raise ValueError(
                "Boolean configuration 'use_authentication' must be set to True or False, not None"
            )

        # host and port (host may be filled elsewhere; allow None)
        if self.port is not None:
            if not isinstance(self.port, int) or not (1 <= self.port <= 65535):
                raise ValueError("port must be an integer between 1 and 65535")

    @staticmethod
    def _get_default_host() -> str:
        if platform.system() == "Windows":
            host = "127.0.0.1"  # default host for windows
        else:
            host = "0.0.0.1"  # default host for linux
        return host

    @classmethod
    def from_dict(cls, config: Dict[str, Any]) -> "AppConfiguration":
        """
        Creates an AppConfiguration instance from a dictionary.

        This factory method reconstructs an AppConfiguration object from a
        dictionary representation, typically one created by `as_dict()`. It
        is useful for deserializing configurations from JSON files or other
        storage formats.

        Args:
            config: Dictionary containing configuration parameters. Keys should
                match the parameter names of the `__init__` method. Any missing
                keys will use their default values from `__init__`.

        Returns:
            A new AppConfiguration instance initialized with the provided
            configuration values.

        Example:
            >>> config_dict = {
            ...     "title": "My Dashboard",
            ...     "port": 9000,
            ...     "use_sessions": True,
            ... }
            >>> app_config = AppConfiguration.from_dict(config_dict)
            >>> app_config.port
            9000
        """
        return cls(**config)
