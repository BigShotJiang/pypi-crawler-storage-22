2026-01-23 Version: 1.8.1
- Update API IssueCouponForCustomer: add request parameters ApplicationReason.
- Update API ListCouponUsage: add request parameters T2PartnerUid.


2026-01-23 Version: 1.8.1
- Update API IssueCouponForCustomer: add request parameters ApplicationReason.
- Update API ListCouponUsage: add request parameters T2PartnerUid.


2025-11-27 Version: 1.8.0
- Support API GetPurchaseControlRecord.
- Support API GetShutdownPolicyRecord.
- Update API ListExportTasks: add request parameters Id.


2025-11-05 Version: 1.7.0
- Support API ExportReversedDeductionHistory.
- Support API GetCommissionableProducts.
- Support API ListExportTasks.
- Support API QueryReversedDeductionHistory.


2025-02-20 Version: 1.6.1
- Update API IssueCouponForCustomer: add param IsUseBenefit.


2024-11-29 Version: 1.6.0
- Support API CancelCoupon.
- Support API CouponApprovalStatusList.
- Support API DeleteCouponTemplate.
- Support API GetCouponTemplateDetail.


2024-11-05 Version: 1.5.1
- Update API CreateCouponTemplate: update param CouponDescription.
- Update API CreateCouponTemplate: update param ReasonForApplication.
- Update API CreateCouponTemplate: update param TemplateName.
- Update API GetAccountInfo: update response param.


2024-09-04 Version: 1.5.0
- Support API CreateCouponTemplate.
- Support API GetCoupondeductProductCode.
- Support API GetCustomerOrders.
- Support API IssueCouponForCustomer.


2024-04-18 Version: 1.4.0
- Support API CustomerQuotaRecordList.
- Support API ExportCustomerQuotaRecord.
- Support API ListCouponUsage.
- Support API QuotaListExportPaged.
- Update API GetAccountInfo: update response param.
- Update API InviteSubAccount: update param AccountInfoList.
- Update API SetAccountInfo: add param CustomerBd.
- Update API SubscriptionBill: update response param.


2024-03-08 Version: 1.3.0
- Support API CustomerQuotaRecordList.
- Support API ExportCustomerQuotaRecord.
- Support API ListCouponUsage.
- Support API QuotaListExportPaged.


2024-02-27 Version: 1.2.0
- Support API CustomerQuotaRecordList.
- Support API ExportCustomerQuotaRecord.
- Support API ListCouponUsage.
- Support API QuotaListExportPaged.


2024-02-27 Version: 1.1.0
- Support API CustomerQuotaRecordList.
- Support API ExportCustomerQuotaRecord.
- Support API QuotaListExportPaged.


2023-12-22 Version: 1.0.1
- Generated python 2022-12-16 for Agency.

2023-10-13 Version: 1.0.0
- Generated python 2022-12-16 for Agency.

