2026-01-22 Version: 2.8.0
- Support API UpdateIndex.


2026-01-16 Version: 2.7.2
- Update API CreateIndex: add request parameters database.
- Update API CreateIndex: add request parameters datasourceCode.
- Update API CreateIndex: add request parameters table.


2026-01-15 Version: 2.7.1
- Update API DescribeFile: add response parameters Body.Data.ParseResultDownloadUrl.


2026-01-14 Version: 2.7.0
- Support API GetIndexMonitor.


2025-12-03 Version: 2.6.2
- Update API CreateIndex: add request parameters pipelineCommercialCu.
- Update API CreateIndex: add request parameters pipelineCommercialType.
- Update API CreateIndex: add request parameters pipelineRetrieveRateLimitStrategy.


2025-11-19 Version: 2.6.1
- Generated python 2023-12-29 for bailian.

2025-11-04 Version: 2.6.0
- Support API ApplyTempStorageLease.


2025-09-20 Version: 2.5.0
- Support API ChangeParseSetting.
- Support API GetAvailableParserTypes.
- Support API GetParseSettings.
- Support API HighCodeDeploy.


2025-09-10 Version: 2.4.1
- Update API AddFilesFromAuthorizedOss: add request parameters OverWriteFileByOssKey.
- Update API CreateAndPulishAgent: add request parameters applicationConfig.parameters.enable_thinking.
- Update API UpdateAndPublishAgent: add request parameters applicationConfig.parameters.enable_thinking.
- Update API UpdateAndPublishAgentSelective: add request parameters applicationConfig.parameters.enable_thinking.


2025-08-12 Version: 2.4.0
- Support API GetAlipayTransferStatus.
- Support API GetAlipayUrl.


2025-08-07 Version: 2.3.0
- Support API DeleteChunk.


2025-08-04 Version: 2.2.0
- Support API ListIndexFileDetails.
- Support API UpdateChunk.


2025-07-30 Version: 2.1.1
- Update API CreateIndex: add request parameters CreateIndexType.
- Update API CreateIndex: add request parameters EnableRewrite.
- Update API CreateIndex: add request parameters TableIds.
- Update API ListIndices: add response parameters Body.Data.Indices.$.ConfgModel.
- Update API ListIndices: add response parameters Body.Data.Indices.$.EnableRewrite.
- Update API SubmitIndexAddDocumentsJob: add request parameters EnableHeaders.


2025-07-17 Version: 2.1.0
- Support API AddFilesFromAuthorizedOss.


2025-06-04 Version: 2.0.8
- Update API ListIndexDocuments: add request parameters EnableNameLike.


2025-05-23 Version: 2.0.7
- Update API ListCategory: add request parameters CategoryName.


2025-05-08 Version: 2.0.6
- Update API AddFile: add request parameters OriginalFileUrl.


2025-04-27 Version: 2.0.5
- Update API SubmitIndexAddDocumentsJob: add request parameters ChunkMode.
- Update API SubmitIndexAddDocumentsJob: add request parameters ChunkSize.
- Update API SubmitIndexAddDocumentsJob: add request parameters OverlapSize.
- Update API SubmitIndexAddDocumentsJob: add request parameters Separator.


2025-04-21 Version: 2.0.4
- Update API CreateIndex: add request parameters chunkMode.


2025-04-10 Version: 2.0.3
- Update API Retrieve: add request parameters QueryHistory.


2025-04-07 Version: 2.0.2
- Update API ApplyFileUploadLease: add request parameters UseInternalEndpoint.


2025-04-07 Version: 2.0.2
- Update API ApplyFileUploadLease: add request parameters UseInternalEndpoint.


2025-03-25 Version: 2.0.1
- Update API GetIndexJobStatus: update response param.
- Update API ListFile: update response param.
- Update API ListIndexDocuments: update response param.
- Update API ListIndices: update response param.
- Update API Retrieve: update param SaveRetrieverHistory.


2025-01-16 Version: 2.0.0
- Update API UpdateAndPublishAgentSelective: update param applicationConfig.


2025-01-03 Version: 1.11.2
- Update API AddFile: add param CategoryType.
- Update API ApplyFileUploadLease: add param CategoryType.
- Update API CreateIndex: add param enableHeaders.
- Update API DescribeFile: update response param.


2024-12-26 Version: 1.11.1
- Generated python 2023-12-29 for bailian.

2024-12-23 Version: 1.11.0
- Support API UpdateAndPublishAgentSelective.
- Update API CreateAndPulishAgent: add param sampleLibrary.
- Update API CreateAndPulishAgent: update param applicationConfig.
- Update API UpdateAndPublishAgent: add param sampleLibrary.
- Update API UpdateAndPublishAgent: update param applicationConfig.


2024-12-12 Version: 1.10.2
- Update API ListChunks: update param body.


2024-11-07 Version: 1.10.1
- Update API CreateIndex: add param metaExtractColumns.


2024-11-04 Version: 1.10.0
- Support API UpdateFileTag.


2024-10-16 Version: 1.9.0
- Support API CreatePromptTemplate.
- Support API DeletePromptTemplate.
- Support API GetPromptTemplate.
- Support API ListPromptTemplates.
- Support API UpdatePromptTemplate.
- Update API ListChunks: update param body.
- Update API ListFile: add param FileName.


2024-09-19 Version: 1.8.4
- Update API AddFile: add param Tags.
- Update API DescribeFile: update response param.
- Update API ListFile: update response param.


2024-09-17 Version: 1.8.3
- Update API CreateIndex: add param DataSource.
- Update API Retrieve: add param Images.


2024-09-06 Version: 1.8.2
- Update API GetIndexJobStatus: add param PageNumber.
- Update API GetIndexJobStatus: add param pageSize.
- Update API Retrieve: update param SearchFilters.


2024-08-29 Version: 1.8.1
- Generated python 2023-12-29 for bailian.

2024-08-21 Version: 1.8.0
- Support API CreateMemory.
- Support API CreateMemoryNode.
- Support API DeleteMemory.
- Support API DeleteMemoryNode.
- Support API GetMemory.
- Support API GetMemoryNode.
- Support API ListMemories.
- Support API ListMemoryNodes.
- Support API UpdateMemory.
- Support API UpdateMemoryNode.
- Update API ApplyFileUploadLease: update param Md5.
- Update API ListFile: update param MaxResults.


2024-08-02 Version: 1.7.0
- Support API ListFile.


2024-07-31 Version: 1.6.0
- Support API CreateAndPulishAgent.
- Support API DeleteAgent.
- Support API GetPublishedAgent.
- Support API ListPublishedAgent.
- Support API UpdateAndPublishAgent.


2024-07-30 Version: 1.5.0
- Support API AddCategory.
- Support API DeleteCategory.
- Support API ListCategory.


2024-07-23 Version: 1.4.1
- Update API Retrieve: add param SearchFilters.
- Update API Retrieve: update param RerankTopN.


2024-07-20 Version: 1.4.0
- Support API DeleteFile.


2024-07-16 Version: 1.3.0
- Support API DeleteIndex.
- Support API DeleteIndexDocument.
- Support API ListChunks.
- Support API ListIndexDocuments.
- Support API ListIndices.


2024-07-09 Version: 1.2.0
- Support API SubmitIndexAddDocumentsJob.


2024-07-09 Version: 1.2.0
- Support API SubmitIndexAddDocumentsJob.


2024-07-04 Version: 1.1.0
- Support API CreateIndex.
- Support API GetIndexJobStatus.
- Support API Retrieve.
- Support API SubmitIndexJob.


2024-07-02 Version: 1.0.0
- Generated python 2023-12-29 for bailian.

