2025-09-24 Version: 5.1.0
- Support API PayOrder.
- Update API ApplyInvoice: add request parameters emails.
- Update API CreateSavingsPlansInstance: add request parameters AutoPay.


2025-01-15 Version: 5.0.0
- Update API DescribeInstanceAmortizedCostByAmortizationPeriod: update response param.
- Update API DescribeInstanceAmortizedCostByConsumePeriod: update response param.
- Update API DescribeInstanceBill: update response param.
- Update API DescribeProductAmortizedCostByAmortizationPeriod: update response param.
- Update API DescribeProductAmortizedCostByConsumePeriod: update response param.
- Update API DescribeSplitItemBill: update response param.


2025-01-08 Version: 4.1.0
- Support API SetSavingPlanUserDeductRule.
- Update API DescribeInstanceBill: update response param.
- Update API DescribeSplitItemBill: update response param.


2024-12-03 Version: 4.0.3
- Update API CreateInstance: add param PricingCycle.


2024-08-20 Version: 4.0.2
- Update API QuerySavingsPlansDiscount: add param SpnCommodityCode.
- Update API QuerySavingsPlansInstance: add param CommodityCode.


2024-07-10 Version: 4.0.1
- Update API GetOrderDetail: update response param.


2024-06-28 Version: 4.0.0
- Delete API EnableBillGeneration.
- Update API CreateResourcePackage: update response param.
- Update API DescribeResourcePackageProduct: update response param.
- Update API DescribeSplitItemBill: add param PipCode.
- Update API QueryCostUnitResource: update response param.
- Update API SubscribeBillToOSS: add param UsingSsl.
- Update API SubscribeBillToOSS: update response param.


2024-03-29 Version: 3.0.2
- Generated python 2017-12-14 for BssOpenApi.

2024-03-14 Version: 3.0.1
- Update API GetOrderDetail: update response param.


2024-03-13 Version: 3.0.0
- Delete API SaveUserCredit.
- Delete API SetCreditLabelAction.
- Update API DescribeInstanceBill: add param PipCode.
- Update API QueryAccountBalance: update response param.
- Update API QuerySavingsPlansDeductLog: update response param.
- Update API SetRenewal: update param ProductCode.


2023-11-21 Version: 2.2.2
- Generated python 2017-12-14 for BssOpenApi.

2023-10-19 Version: 2.2.1
- Generated python 2017-12-14 for BssOpenApi.

2023-09-06 Version: 2.2.0
- Generated python 2017-12-14 for BssOpenApi.

2023-09-04 Version: 2.1.0
- Generated python 2017-12-14 for BssOpenApi.

2023-05-19 Version: 2.0.10
- DescribeInstanceAmortizedCostByAmortizationPeriodDate

2023-03-07 Version: 2.0.9
- QuerySavingsPlansInstance api add status query param. 


2023-02-13 Version: 2.0.8
- SubscribeBillToOSS add param: RowLimitPerFile. 

2023-02-07 Version: 2.0.7
- Add other language.

2022-06-28 Version: 2.0.6
- Update QuerySavingsPlansDeductLog add field OwnerId.

2022-05-19 Version: 2.0.5
- Update SubscribeBillToOSS and QueryBillToOSSSubscription to support BucketPath.

2022-04-24 Version: 2.0.4
- Bill api add query conditions and return data field.

2021-11-23 Version: 2.0.3
- Add Create Savingplan Instance API.

2021-11-23 Version: 2.0.1
- Add Create Savingplan Instance API.

2021-08-12 Version: 1.0.8
- Generated python 2017-12-14 for BssOpenApi.

2021-06-25 Version: 1.0.7
- AMP Version Change.

2021-06-15 Version: 1.0.6
- AMP Version Change.

2021-04-28 Version: 1.0.5
- AMP Version Change.

2021-03-26 Version: 1.0.4
- AMP Version Change.

2021-03-23 Version: 1.0.3
- Generated python 2017-12-14 for BssOpenApi.

2021-03-19 Version: 1.0.2
- AMP Version Change.

2021-03-04 Version: 1.0.1
- AMP Version Change.

2021-02-04 Version: 0.1.3
- Add FinancialRelationApi to support for multie enterprise financial account query.

2021-01-27 Version: 1.0.0
- Generated python 2017-12-14 for BssOpenApi.

2021-01-19 Version: 0.1.2
- Generated python 2017-12-14 for BssOpenApi.

2020-09-24 Version: 0.1.1
- Supported query account transactions.

