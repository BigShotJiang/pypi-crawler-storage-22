# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class CreateDetectionRuleResponseBody(DaraModel):
    def __init__(
        self,
        detection_rule_id: str = None,
        request_id: str = None,
    ):
        self.detection_rule_id = detection_rule_id
        self.request_id = request_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.detection_rule_id is not None:
            result['DetectionRuleId'] = self.detection_rule_id

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('DetectionRuleId') is not None:
            self.detection_rule_id = m.get('DetectionRuleId')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

