# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class CreateIPv6TranslatorEntryResponseBody(DaraModel):
    def __init__(
        self,
        ipv_6translator_entry_id: str = None,
        request_id: str = None,
    ):
        # The ID of the IPv6 Translation Service instance.
        self.ipv_6translator_entry_id = ipv_6translator_entry_id
        # The request ID.
        self.request_id = request_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.ipv_6translator_entry_id is not None:
            result['Ipv6TranslatorEntryId'] = self.ipv_6translator_entry_id

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Ipv6TranslatorEntryId') is not None:
            self.ipv_6translator_entry_id = m.get('Ipv6TranslatorEntryId')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

