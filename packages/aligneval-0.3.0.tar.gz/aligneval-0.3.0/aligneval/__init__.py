"""
AlignEval - Production-ready LLM and RAG evaluation framework.

AlignEval uses GPT-4o/GPT-4.1 as a judge to assess LLM and RAG system quality
across multiple dimensions including accuracy, helpfulness, relevance, clarity,
safety, and RAG-specific metrics like faithfulness and groundedness.
"""

__version__ = "0.1.0"
__author__ = "AlignEval Team"

# Core imports
from aligneval.core.test_case import LLMTestCase
from aligneval.core.dataset import EvaluationDataset
from aligneval.core.config import Settings, get_settings

# Evaluator imports
from aligneval.evaluator.evaluator import AlignEvaluator, EvaluationResult
from aligneval.evaluator.rag_evaluator import RAGEvaluator, RAGEvaluationResult, RAGDiagnostics

# Metric imports
from aligneval.metrics.base import BaseMetric, MetricResult

# Monitor imports (live dashboard)
from aligneval.monitor import monitor, Monitor

__all__ = [
    # Core
    "LLMTestCase",
    "EvaluationDataset",
    "Settings",
    "get_settings",
    # Evaluators
    "AlignEvaluator",
    "EvaluationResult",
    "RAGEvaluator",
    "RAGEvaluationResult",
    "RAGDiagnostics",
    # Metrics
    "BaseMetric",
    "MetricResult",
    # Monitor
    "monitor",
    "Monitor",
]
