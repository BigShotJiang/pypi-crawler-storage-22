"""AlignEval autonomous agent for end-to-end evaluation workflows."""

import logging
from datetime import datetime
from typing import Dict, Any
from langgraph.graph import StateGraph, END

from aligneval.agent.state import AgentState
from aligneval.agent.tools import (
    select_metrics_tool,
    evaluate_tool,
    generate_report_tool,
    analyze_results_tool
)
from aligneval.core.test_case import LLMTestCase

logger = logging.getLogger(__name__)


def create_agent() -> StateGraph:
    """Create AlignEval autonomous agent using LangGraph.
    
    This function creates a LangGraph StateGraph that implements an autonomous
    evaluation workflow. The agent:
    1. Selects appropriate metrics based on test case characteristics
    2. Executes evaluation with selected metrics
    3. Generates an HTML report
    4. Analyzes results and provides recommendations
    
    The agent uses a simple rule-based approach to determine the next action
    based on the current state.
    
    Returns:
        StateGraph: Compiled LangGraph workflow
        
    Example:
        >>> agent_graph = create_agent()
        >>> initial_state = AgentState(
        ...     messages=[],
        ...     test_case=my_test_case,
        ...     evaluation_results=None,
        ...     selected_metrics=[],
        ...     report_path=None,
        ...     next_action=""
        ... )
        >>> final_state = await agent_graph.ainvoke(initial_state)
    """
    logger.info("Creating AlignEval autonomous agent")
    
    workflow = StateGraph(AgentState)
    
    # Node: Agent reasoning - decides next action based on state
    def agent_node(state: AgentState) -> AgentState:
        """Agent decides next action based on current state.
        
        This node implements simple rule-based logic to determine what the agent
        should do next in the evaluation workflow.
        
        Args:
            state: Current agent state
            
        Returns:
            Updated state with next_action set
        """
        logger.debug("Agent node: determining next action")
        
        # Determine next action based on what's been completed
        if not state.get("selected_metrics"):
            state["next_action"] = "select_metrics"
            logger.debug("Next action: select_metrics")
        elif not state.get("evaluation_results"):
            state["next_action"] = "evaluate"
            logger.debug("Next action: evaluate")
        elif not state.get("report_path"):
            state["next_action"] = "generate_report"
            logger.debug("Next action: generate_report")
        else:
            state["next_action"] = "analyze"
            logger.debug("Next action: analyze")
        
        return state
    
    # Node: Execute tool - performs the action determined by agent_node
    def tool_node(state: AgentState) -> AgentState:
        """Execute the selected tool based on next_action.
        
        This node executes the appropriate tool function and updates the state
        with the results. It also adds messages to track the workflow progress.
        
        Args:
            state: Current agent state with next_action set
            
        Returns:
            Updated state with tool execution results
        """
        action = state["next_action"]
        logger.info(f"Tool node: executing action '{action}'")
        
        if action == "select_metrics":
            # Select appropriate metrics for the test case
            metrics = select_metrics_tool(state["test_case"])
            state["selected_metrics"] = metrics
            state["messages"].append({
                "role": "assistant",
                "content": f"Selected metrics: {', '.join(metrics)}"
            })
            logger.info(f"Selected {len(metrics)} metrics")
        
        elif action == "evaluate":
            # Execute evaluation with selected metrics
            results = evaluate_tool(state["test_case"], state["selected_metrics"])
            state["evaluation_results"] = results
            state["messages"].append({
                "role": "assistant",
                "content": f"Evaluation complete. Overall score: {results.overall_score:.2f}"
            })
            logger.info(f"Evaluation complete with score: {results.overall_score:.2f}")
        
        elif action == "generate_report":
            # Generate HTML report
            report_path = f"/tmp/aligneval_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
            generate_report_tool(state["evaluation_results"], report_path)
            state["report_path"] = report_path
            state["messages"].append({
                "role": "assistant",
                "content": f"Report generated: {report_path}"
            })
            logger.info(f"Report generated at: {report_path}")
        
        elif action == "analyze":
            # Analyze results and provide recommendations
            analysis = analyze_results_tool(state["evaluation_results"])
            
            # Format analysis message
            analysis_msg = f"""Analysis complete:
- Overall Score: {analysis['overall_score']:.2f}
- Status: {'PASSED' if analysis['passed'] else 'FAILED'}
- Weak Metrics: {', '.join(analysis['weak_metrics']) if analysis['weak_metrics'] else 'None'}

Recommendations:
"""
            for i, rec in enumerate(analysis['recommendations'], 1):
                analysis_msg += f"{i}. {rec}\n"
            
            state["messages"].append({
                "role": "assistant",
                "content": analysis_msg
            })
            state["next_action"] = "done"
            logger.info("Analysis complete, workflow finished")
        
        return state
    
    # Add nodes to workflow
    workflow.add_node("agent", agent_node)
    workflow.add_node("tools", tool_node)
    
    # Set entry point
    workflow.set_entry_point("agent")
    
    # Conditional routing: continue to tools or end
    def should_continue(state: AgentState) -> str:
        """Decide whether to continue workflow or end.
        
        Args:
            state: Current agent state
            
        Returns:
            "end" if workflow is complete, "tools" to continue
        """
        if state["next_action"] == "done":
            logger.debug("Workflow complete, ending")
            return "end"
        else:
            logger.debug("Continuing to tools node")
            return "tools"
    
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "tools": "tools",
            "end": END
        }
    )
    
    # After executing tools, go back to agent for next decision
    workflow.add_edge("tools", "agent")
    
    logger.info("Agent workflow compiled successfully")
    return workflow.compile()


class AlignEvalAgent:
    """Autonomous agent for end-to-end evaluation workflows.
    
    This class provides a high-level interface to the LangGraph-based autonomous
    agent. It handles the complete evaluation workflow from metric selection through
    analysis and reporting.
    
    The agent automatically:
    - Selects appropriate metrics based on test case characteristics
    - Executes evaluation with selected metrics
    - Generates HTML reports
    - Analyzes results and provides actionable recommendations
    
    Attributes:
        graph: Compiled LangGraph workflow
        
    Example:
        >>> agent = AlignEvalAgent()
        >>> test_case = LLMTestCase(
        ...     input="What is machine learning?",
        ...     actual_output="Machine learning is a subset of AI...",
        ...     retrieval_context=["ML is a field of AI..."]
        ... )
        >>> result = await agent.evaluate(test_case)
        >>> print(result["results"].overall_score)
        0.85
        >>> print(result["report_path"])
        /tmp/aligneval_report_20250115_143022.html
    """
    
    def __init__(self):
        """Initialize the AlignEval agent by compiling the workflow graph."""
        logger.info("Initializing AlignEvalAgent")
        self.graph = create_agent()
        logger.info("AlignEvalAgent initialized successfully")
    
    async def evaluate(self, test_case: LLMTestCase) -> Dict[str, Any]:
        """Run autonomous evaluation workflow on a test case.
        
        This method executes the complete evaluation workflow asynchronously,
        including metric selection, evaluation, report generation, and analysis.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            Dict containing:
                - messages: List of workflow messages
                - results: EvaluationResult with all metric scores
                - report_path: Path to generated HTML report
                
        Example:
            >>> agent = AlignEvalAgent()
            >>> test_case = LLMTestCase(
            ...     input="Explain quantum computing",
            ...     actual_output="Quantum computing uses quantum mechanics..."
            ... )
            >>> result = await agent.evaluate(test_case)
            >>> for msg in result["messages"]:
            ...     print(f"{msg['role']}: {msg['content']}")
        """
        logger.info("Starting autonomous evaluation workflow")
        
        # Initialize state
        initial_state = AgentState(
            messages=[],
            test_case=test_case,
            evaluation_results=None,
            selected_metrics=[],
            report_path=None,
            next_action=""
        )
        
        # Execute workflow
        final_state = await self.graph.ainvoke(initial_state)
        
        logger.info("Autonomous evaluation workflow complete")
        
        return {
            "messages": final_state["messages"],
            "results": final_state["evaluation_results"],
            "report_path": final_state["report_path"]
        }
