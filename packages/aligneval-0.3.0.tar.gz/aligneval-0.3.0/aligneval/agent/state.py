"""State definition for AlignEval autonomous agent."""

from typing import TypedDict, List, Dict, Optional
from aligneval.core.test_case import LLMTestCase
from aligneval.evaluator.evaluator import EvaluationResult


class AgentState(TypedDict):
    """State for AlignEval autonomous agent workflow.
    
    This TypedDict defines the state that flows through the LangGraph agent nodes.
    The agent uses this state to track the evaluation workflow from metric selection
    through evaluation, report generation, and analysis.
    
    Attributes:
        messages: Conversation history between agent and user
        test_case: The test case being evaluated
        evaluation_results: Results from evaluation (populated after evaluation)
        selected_metrics: Names of metrics selected for evaluation
        report_path: Path to generated report (populated after report generation)
        next_action: The next action the agent should take
    """
    
    messages: List[Dict[str, str]]
    test_case: Optional[LLMTestCase]
    evaluation_results: Optional[EvaluationResult]
    selected_metrics: List[str]
    report_path: Optional[str]
    next_action: str
