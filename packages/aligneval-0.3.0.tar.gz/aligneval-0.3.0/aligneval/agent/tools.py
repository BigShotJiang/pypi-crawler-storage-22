"""Tools for AlignEval autonomous agent."""

import logging
from typing import List, Dict, Any
from aligneval.core.test_case import LLMTestCase
from aligneval.evaluator.evaluator import AlignEvaluator, EvaluationResult
from aligneval.metrics import get_metric_by_name
from aligneval.report.generator import ReportGenerator

logger = logging.getLogger(__name__)


def select_metrics_tool(test_case: LLMTestCase) -> List[str]:
    """Automatically select appropriate metrics based on test case characteristics.
    
    This tool analyzes the test case to determine which metrics are most relevant:
    - Always includes core general metrics (Accuracy, Helpfulness, Relevance, Clarity)
    - Adds RAG-specific metrics if retrieval_context is present
    - Adds Safety metric if the input mentions safety-related keywords
    
    Args:
        test_case: The test case to analyze
        
    Returns:
        List of metric names to use for evaluation
        
    Example:
        >>> test_case = LLMTestCase(
        ...     input="What is AI?",
        ...     actual_output="AI is artificial intelligence.",
        ...     retrieval_context=["AI stands for artificial intelligence..."]
        ... )
        >>> metrics = select_metrics_tool(test_case)
        >>> print(metrics)
        ['Accuracy', 'Helpfulness', 'Relevance', 'Clarity', 'Faithfulness', 'Context Precision', 'Answer Relevancy']
    """
    logger.info("Selecting appropriate metrics for test case")
    
    # Start with core general metrics
    metrics = ["Accuracy", "Helpfulness", "Relevance", "Clarity"]
    
    # Add RAG metrics if retrieval context is present
    if test_case.retrieval_context:
        logger.info("Retrieval context detected, adding RAG metrics")
        metrics.extend([
            "Faithfulness",
            "Context Precision",
            "Answer Relevancy"
        ])
    
    # Add Safety metric if safety-related keywords are in the input
    safety_keywords = ["safe", "harm", "danger", "toxic", "offensive", "inappropriate"]
    if any(keyword in test_case.input.lower() for keyword in safety_keywords):
        logger.info("Safety-related keywords detected, adding Safety metric")
        metrics.append("Safety")
    
    logger.info(f"Selected {len(metrics)} metrics: {metrics}")
    return metrics


def evaluate_tool(test_case: LLMTestCase, metric_names: List[str]) -> EvaluationResult:
    """Execute evaluation with selected metrics.
    
    This tool creates an AlignEvaluator with the specified metrics and evaluates
    the test case, returning comprehensive results.
    
    Args:
        test_case: The test case to evaluate
        metric_names: List of metric names to use for evaluation
        
    Returns:
        EvaluationResult: Complete evaluation results with all metric scores
        
    Raises:
        ValueError: If any metric name is not found in the registry
        
    Example:
        >>> test_case = LLMTestCase(
        ...     input="What is 2+2?",
        ...     actual_output="2+2 equals 4."
        ... )
        >>> result = evaluate_tool(test_case, ["Accuracy", "Clarity"])
        >>> print(result.overall_score)
        0.85
    """
    logger.info(f"Evaluating test case with metrics: {metric_names}")
    
    # Get metric instances from registry
    metrics = []
    for name in metric_names:
        metric = get_metric_by_name(name)
        if metric is None:
            error_msg = f"Metric '{name}' not found in registry"
            logger.error(error_msg)
            raise ValueError(error_msg)
        metrics.append(metric)
    
    # Create evaluator and run evaluation
    evaluator = AlignEvaluator(metrics)
    result = evaluator.evaluate(test_case)
    
    logger.info(f"Evaluation complete. Overall score: {result.overall_score:.3f}")
    return result


def generate_report_tool(results: EvaluationResult, output_path: str) -> str:
    """Generate HTML report from evaluation results.
    
    This tool creates a formatted HTML report containing evaluation results,
    metric breakdowns, and visualizations.
    
    Args:
        results: The evaluation results to include in the report
        output_path: Path where the HTML report should be saved
        
    Returns:
        str: The path to the generated report
        
    Example:
        >>> result = evaluate_tool(test_case, ["Accuracy"])
        >>> report_path = generate_report_tool(result, "/tmp/report.html")
        >>> print(f"Report saved to: {report_path}")
        Report saved to: /tmp/report.html
    """
    logger.info(f"Generating HTML report at: {output_path}")
    
    generator = ReportGenerator()
    generator.generate_html([results], output_path)
    
    logger.info(f"Report generated successfully: {output_path}")
    return output_path


def analyze_results_tool(results: EvaluationResult) -> Dict[str, Any]:
    """Analyze evaluation results and provide actionable recommendations.
    
    This tool examines the evaluation results to identify weak metrics (scores < 0.6)
    and generates specific, actionable recommendations for improvement.
    
    Args:
        results: The evaluation results to analyze
        
    Returns:
        Dict containing:
            - overall_score: The overall evaluation score
            - passed: Whether the evaluation passed (all scores > 0.6)
            - weak_metrics: List of metrics with scores below 0.6
            - recommendations: List of actionable improvement suggestions
            
    Example:
        >>> result = evaluate_tool(test_case, ["Accuracy", "Relevance"])
        >>> analysis = analyze_results_tool(result)
        >>> print(analysis["recommendations"])
        ['Improve factual accuracy: Verify facts against reliable sources']
    """
    logger.info("Analyzing evaluation results")
    
    analysis = {
        "overall_score": results.overall_score,
        "passed": results.passed,
        "weak_metrics": [],
        "recommendations": []
    }
    
    # Identify weak metrics and generate recommendations
    for metric_result in results.metric_results:
        if metric_result.error:
            logger.warning(f"Metric {metric_result.metric_name} had an error: {metric_result.error}")
            continue
            
        if metric_result.normalized_score < 0.6:
            analysis["weak_metrics"].append(metric_result.metric_name)
            
            # Generate specific recommendations based on metric
            if metric_result.metric_name == "Accuracy":
                analysis["recommendations"].append(
                    "Improve factual accuracy: Verify facts against reliable sources and ensure all claims are correct"
                )
            elif metric_result.metric_name == "Helpfulness":
                analysis["recommendations"].append(
                    "Improve helpfulness: Provide more actionable information and directly address the user's needs"
                )
            elif metric_result.metric_name == "Relevance":
                analysis["recommendations"].append(
                    "Improve relevance: Ensure response directly addresses the query without unnecessary tangents"
                )
            elif metric_result.metric_name == "Clarity":
                analysis["recommendations"].append(
                    "Improve clarity: Use simpler language, better structure, and clearer explanations"
                )
            elif metric_result.metric_name == "Safety":
                analysis["recommendations"].append(
                    "Improve safety: Remove any potentially harmful, toxic, or inappropriate content"
                )
            elif metric_result.metric_name == "Faithfulness":
                analysis["recommendations"].append(
                    "Improve faithfulness: Ensure all claims in the response are supported by the retrieval context"
                )
            elif metric_result.metric_name == "Context Precision":
                analysis["recommendations"].append(
                    "Improve context precision: Refine retrieval to return more relevant context documents"
                )
            elif metric_result.metric_name == "Context Recall":
                analysis["recommendations"].append(
                    "Improve context recall: Ensure retrieval captures all necessary information to answer the query"
                )
            elif metric_result.metric_name == "Answer Relevancy":
                analysis["recommendations"].append(
                    "Improve answer relevancy: Ensure the response directly addresses the specific question asked"
                )
            elif metric_result.metric_name == "Groundedness":
                analysis["recommendations"].append(
                    "Improve groundedness: Ensure factual consistency with the provided context"
                )
    
    if not analysis["weak_metrics"]:
        analysis["recommendations"].append(
            "Excellent performance! All metrics scored above 0.6. Continue maintaining this quality."
        )
    
    logger.info(f"Analysis complete. Found {len(analysis['weak_metrics'])} weak metrics")
    return analysis
