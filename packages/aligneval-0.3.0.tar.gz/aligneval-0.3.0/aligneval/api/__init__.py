"""FastAPI REST API for AlignEval."""

from aligneval.api.main import app

__all__ = ["app"]
