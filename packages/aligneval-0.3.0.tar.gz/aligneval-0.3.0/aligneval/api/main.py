"""FastAPI application for AlignEval REST API."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from aligneval.api.routes import router

# Create FastAPI app with metadata
app = FastAPI(
    title="AlignEval API",
    description="REST API for evaluating LLM and RAG systems using GPT-4 as a judge",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify allowed origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router, prefix="/api/v1")


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "AlignEval API",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/api/v1/health"
    }


@app.get("/api/v1/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy"}
