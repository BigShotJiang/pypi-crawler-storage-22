"""API routes for AlignEval REST API."""

import logging
from typing import List
from datetime import datetime

from fastapi import APIRouter, HTTPException, status

from aligneval.api.schemas import (
    EvaluateRequest,
    EvaluateResponse,
    BatchEvaluateRequest,
    BatchEvaluateResponse,
    MetricsListResponse,
    MetricInfo,
    ErrorResponse,
)
from aligneval.evaluator.evaluator import AlignEvaluator
from aligneval.metrics import get_all_metrics, get_metric_by_name
from aligneval.metrics.base import BaseMetric

logger = logging.getLogger(__name__)

# Create API router
router = APIRouter()


def _get_metrics_from_names(metric_names: List[str]) -> List[BaseMetric]:
    """Get metric instances from a list of metric names.
    
    Args:
        metric_names: List of metric names to retrieve
        
    Returns:
        List of BaseMetric instances
        
    Raises:
        HTTPException: If any metric name is not found
    """
    if not metric_names:
        return get_all_metrics()
    
    metrics = []
    for name in metric_names:
        metric = get_metric_by_name(name)
        if metric is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Metric '{name}' not found"
            )
        metrics.append(metric)
    
    return metrics


@router.post(
    "/evaluate",
    response_model=EvaluateResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request"},
        500: {"model": ErrorResponse, "description": "Evaluation failed"},
    },
    summary="Evaluate a single test case",
    description="Evaluate a single test case using specified metrics or all available metrics",
)
async def evaluate_single(request: EvaluateRequest) -> EvaluateResponse:
    """Evaluate a single test case.
    
    Args:
        request: Evaluation request containing test case and optional metric names
        
    Returns:
        EvaluateResponse: Evaluation results
        
    Raises:
        HTTPException: If evaluation fails or metrics are invalid
    """
    try:
        logger.info(f"Received evaluation request with {len(request.metrics)} metrics")
        
        # Get metrics
        metrics = _get_metrics_from_names(request.metrics)
        
        # Create evaluator and evaluate
        evaluator = AlignEvaluator(metrics=metrics)
        result = await evaluator.evaluate_async(request.test_case)
        
        # Convert to response schema
        return EvaluateResponse(
            test_case=result.test_case,
            metric_results=result.metric_results,
            overall_score=result.overall_score,
            timestamp=result.timestamp,
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Evaluation failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Evaluation failed: {str(e)}"
        )


@router.post(
    "/evaluate/batch",
    response_model=BatchEvaluateResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request"},
        500: {"model": ErrorResponse, "description": "Batch evaluation failed"},
    },
    summary="Evaluate multiple test cases",
    description="Evaluate multiple test cases in batch using specified metrics or all available metrics",
)
async def evaluate_batch(request: BatchEvaluateRequest) -> BatchEvaluateResponse:
    """Evaluate multiple test cases in batch.
    
    Args:
        request: Batch evaluation request containing test cases and optional metric names
        
    Returns:
        BatchEvaluateResponse: Batch evaluation results with statistics
        
    Raises:
        HTTPException: If batch evaluation fails or metrics are invalid
    """
    try:
        logger.info(
            f"Received batch evaluation request with {len(request.test_cases)} test cases "
            f"and {len(request.metrics)} metrics"
        )
        
        if not request.test_cases:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="test_cases list cannot be empty"
            )
        
        # Get metrics
        metrics = _get_metrics_from_names(request.metrics)
        
        # Create evaluator
        evaluator = AlignEvaluator(metrics=metrics)
        
        # Evaluate all test cases asynchronously
        from aligneval.core.dataset import EvaluationDataset
        dataset = EvaluationDataset(test_cases=request.test_cases)
        
        results = await evaluator.evaluate_dataset_async(
            dataset=dataset,
            max_concurrent=request.max_concurrent
        )
        
        # Convert to response schema
        responses = [
            EvaluateResponse(
                test_case=result.test_case,
                metric_results=result.metric_results,
                overall_score=result.overall_score,
                timestamp=result.timestamp,
            )
            for result in results
        ]
        
        # Calculate statistics
        error_count = sum(
            1 for result in results
            if any(mr.error for mr in result.metric_results)
        )
        success_count = len(results) - error_count
        
        return BatchEvaluateResponse(
            results=responses,
            total_count=len(results),
            success_count=success_count,
            error_count=error_count,
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Batch evaluation failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Batch evaluation failed: {str(e)}"
        )


@router.get(
    "/metrics",
    response_model=MetricsListResponse,
    status_code=status.HTTP_200_OK,
    summary="List available metrics",
    description="Get a list of all available evaluation metrics",
)
async def list_metrics() -> MetricsListResponse:
    """List all available evaluation metrics.
    
    Returns:
        MetricsListResponse: List of available metrics with their descriptions
    """
    try:
        logger.info("Listing available metrics")
        
        all_metrics = get_all_metrics()
        
        metric_infos = [
            MetricInfo(name=metric.name, description=metric.description)
            for metric in all_metrics
        ]
        
        return MetricsListResponse(
            metrics=metric_infos,
            count=len(metric_infos)
        )
        
    except Exception as e:
        logger.error(f"Failed to list metrics: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list metrics: {str(e)}"
        )
