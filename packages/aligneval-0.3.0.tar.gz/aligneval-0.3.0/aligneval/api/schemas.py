"""Pydantic schemas for FastAPI REST API."""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

from aligneval.core.test_case import LLMTestCase
from aligneval.metrics.base import MetricResult


class EvaluateRequest(BaseModel):
    """Request schema for single test case evaluation.
    
    Attributes:
        test_case: The test case to evaluate
        metrics: List of metric names to use (if empty, uses all available metrics)
    """
    
    test_case: LLMTestCase = Field(..., description="The test case to evaluate")
    metrics: List[str] = Field(
        default_factory=list,
        description="List of metric names to use (empty = all metrics)"
    )


class EvaluateResponse(BaseModel):
    """Response schema for single test case evaluation.
    
    Attributes:
        test_case: The evaluated test case
        metric_results: Results from each metric
        overall_score: Average of all normalized scores
        timestamp: ISO format timestamp of evaluation
    """
    
    test_case: LLMTestCase = Field(..., description="The evaluated test case")
    metric_results: List[MetricResult] = Field(..., description="Results from each metric")
    overall_score: float = Field(..., description="Average of all normalized scores")
    timestamp: str = Field(..., description="ISO format timestamp of evaluation")


class BatchEvaluateRequest(BaseModel):
    """Request schema for batch evaluation.
    
    Attributes:
        test_cases: List of test cases to evaluate
        metrics: List of metric names to use (if empty, uses all available metrics)
        max_concurrent: Maximum number of concurrent evaluations (optional)
    """
    
    test_cases: List[LLMTestCase] = Field(..., description="List of test cases to evaluate")
    metrics: List[str] = Field(
        default_factory=list,
        description="List of metric names to use (empty = all metrics)"
    )
    max_concurrent: Optional[int] = Field(
        None,
        description="Maximum number of concurrent evaluations"
    )


class BatchEvaluateResponse(BaseModel):
    """Response schema for batch evaluation.
    
    Attributes:
        results: List of evaluation results
        total_count: Total number of test cases evaluated
        success_count: Number of successful evaluations
        error_count: Number of failed evaluations
    """
    
    results: List[EvaluateResponse] = Field(..., description="List of evaluation results")
    total_count: int = Field(..., description="Total number of test cases")
    success_count: int = Field(..., description="Number of successful evaluations")
    error_count: int = Field(..., description="Number of failed evaluations")


class MetricInfo(BaseModel):
    """Information about an available metric.
    
    Attributes:
        name: The metric name
        description: Description of what the metric evaluates
    """
    
    name: str = Field(..., description="The metric name")
    description: str = Field(..., description="Description of what the metric evaluates")


class MetricsListResponse(BaseModel):
    """Response schema for listing available metrics.
    
    Attributes:
        metrics: List of available metrics
        count: Total number of available metrics
    """
    
    metrics: List[MetricInfo] = Field(..., description="List of available metrics")
    count: int = Field(..., description="Total number of available metrics")


class ErrorResponse(BaseModel):
    """Error response schema.
    
    Attributes:
        error: Error message
        detail: Additional error details (optional)
    """
    
    error: str = Field(..., description="Error message")
    detail: Optional[Dict[str, Any]] = Field(None, description="Additional error details")
