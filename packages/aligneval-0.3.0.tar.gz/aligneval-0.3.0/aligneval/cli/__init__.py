"""Command-line interface for AlignEval."""

from aligneval.cli.commands import cli

__all__ = ["cli"]
