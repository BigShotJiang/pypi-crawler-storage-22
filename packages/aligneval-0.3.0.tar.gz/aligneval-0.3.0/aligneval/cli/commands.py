"""Command-line interface for AlignEval using Click and Rich."""

import json
import click
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.progress import track

from aligneval.core.test_case import LLMTestCase
from aligneval.core.dataset import EvaluationDataset
from aligneval.evaluator.evaluator import AlignEvaluator, EvaluationResult
from aligneval.metrics import get_metric_by_name, get_all_metrics
from aligneval.generator.synthetic import SyntheticDataGenerator
from aligneval.report.generator import ReportGenerator

console = Console()


@click.group()
def cli():
    """AlignEval - LLM and RAG Evaluation Framework
    
    A production-ready evaluation framework for LLM and RAG systems using
    GPT-4o/GPT-4.1 as a judge.
    """
    pass


@cli.command()
@click.option('--input', required=True, help='Input query or prompt')
@click.option('--output', required=True, help='Actual output to evaluate')
@click.option('--expected', help='Expected output (optional)')
@click.option('--context', multiple=True, help='Retrieval context for RAG (can be specified multiple times)')
@click.option('--metrics', default='Accuracy,Relevance', help='Comma-separated metric names')
def evaluate(input, output, expected, context, metrics):
    """Evaluate a single LLM response.
    
    Example:
        aligneval evaluate --input "What is the capital of France?" --output "Paris" --metrics Accuracy,Relevance
    """
    try:
        # Create test case
        test_case = LLMTestCase(
            input=input,
            actual_output=output,
            expected_output=expected if expected else None,
            retrieval_context=list(context) if context else None
        )
        
        # Parse and validate metrics
        metric_names = [m.strip() for m in metrics.split(',')]
        metric_list = []
        for name in metric_names:
            metric = get_metric_by_name(name)
            if metric is None:
                console.print(f"[bold red]Error:[/bold red] Unknown metric '{name}'")
                console.print(f"Available metrics: {', '.join(m.name for m in get_all_metrics())}")
                raise click.Abort()
            metric_list.append(metric)
        
        # Create evaluator and evaluate
        evaluator = AlignEvaluator(metric_list)
        
        with console.status("[bold green]Evaluating..."):
            result = evaluator.evaluate(test_case)
        
        # Display results in a table
        table = Table(title="Evaluation Results", show_header=True, header_style="bold cyan")
        table.add_column("Metric", style="cyan", width=20)
        table.add_column("Score", style="magenta", width=10)
        table.add_column("Reasoning", style="white")
        
        for mr in result.metric_results:
            if mr.error:
                table.add_row(
                    mr.metric_name,
                    "[red]ERROR[/red]",
                    f"[red]{mr.error}[/red]"
                )
            else:
                score_color = "green" if mr.normalized_score > 0.6 else "yellow" if mr.normalized_score > 0.4 else "red"
                table.add_row(
                    mr.metric_name,
                    f"[{score_color}]{mr.normalized_score:.2f}[/{score_color}]",
                    mr.reasoning[:100] + "..." if len(mr.reasoning) > 100 else mr.reasoning
                )
        
        console.print(table)
        console.print(f"\n[bold]Overall Score:[/bold] {result.overall_score:.2f}")
        
        if result.passed:
            console.print("[bold green]✓ PASSED[/bold green]")
        else:
            console.print("[bold red]✗ FAILED[/bold red]")
    
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        raise click.Abort()


@cli.command()
@click.argument('dataset_file', type=click.Path(exists=True))
@click.option('--metrics', default='Accuracy,Relevance', help='Comma-separated metric names')
@click.option('--output', default='results.json', help='Output file for results')
def batch(dataset_file, metrics, output):
    """Evaluate a batch of test cases from a JSON file.
    
    The dataset file should be a JSON file containing an EvaluationDataset.
    
    Example:
        aligneval batch dataset.json --metrics Accuracy,Helpfulness --output results.json
    """
    try:
        # Load dataset
        console.print(f"[bold]Loading dataset from:[/bold] {dataset_file}")
        with open(dataset_file, 'r') as f:
            dataset_json = f.read()
        dataset = EvaluationDataset.from_json(dataset_json)
        console.print(f"[bold green]✓[/bold green] Loaded {len(dataset)} test cases")
        
        # Parse and validate metrics
        metric_names = [m.strip() for m in metrics.split(',')]
        metric_list = []
        for name in metric_names:
            metric = get_metric_by_name(name)
            if metric is None:
                console.print(f"[bold red]Error:[/bold red] Unknown metric '{name}'")
                console.print(f"Available metrics: {', '.join(m.name for m in get_all_metrics())}")
                raise click.Abort()
            metric_list.append(metric)
        
        # Create evaluator
        evaluator = AlignEvaluator(metric_list)
        
        # Evaluate with progress bar (using the evaluator's built-in progress)
        console.print(f"\n[bold]Evaluating with metrics:[/bold] {', '.join(m.name for m in metric_list)}")
        results = evaluator.evaluate_dataset(dataset)
        
        # Save results
        results_data = [r.model_dump() for r in results]
        with open(output, 'w') as f:
            json.dump(results_data, f, indent=2)
        
        # Display summary
        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed
        avg_score = sum(r.overall_score for r in results) / len(results) if results else 0.0
        
        console.print(f"\n[bold]Summary:[/bold]")
        summary_table = Table(show_header=False, box=None)
        summary_table.add_column("Label", style="bold")
        summary_table.add_column("Value")
        summary_table.add_row("Total Cases", str(len(results)))
        summary_table.add_row("Passed", f"[green]{passed}[/green] ({passed/len(results)*100:.1f}%)")
        summary_table.add_row("Failed", f"[red]{failed}[/red] ({failed/len(results)*100:.1f}%)")
        summary_table.add_row("Average Score", f"{avg_score:.2f}")
        console.print(summary_table)
        
        console.print(f"\n[bold green]✓[/bold green] Results saved to: {output}")
    
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        raise click.Abort()


@cli.command()
@click.option('--domain', help='Domain description (e.g., "customer support chatbot")')
@click.option('--text', help='Text content to generate test cases from')
@click.option('--file', type=click.Path(exists=True), help='File to generate from (PDF, TXT, MD)')
@click.option('--num-cases', default=10, help='Number of test cases to generate')
@click.option('--output', default='synthetic_dataset.json', help='Output file path')
@click.option('--rag', is_flag=True, help='Include RAG context in generated test cases')
def generate(domain, text, file, num_cases, output, rag):
    """Generate synthetic test cases.
    
    You must provide one of: --domain, --text, or --file
    
    Examples:
        aligneval generate --domain "customer support chatbot" --num-cases 10
        aligneval generate --file docs.pdf --num-cases 5
        aligneval generate --text "Paris is the capital of France" --num-cases 3
    """
    try:
        # Validate that exactly one source is provided
        sources = [domain, text, file]
        if sum(s is not None for s in sources) != 1:
            console.print("[bold red]Error:[/bold red] Provide exactly one of: --domain, --text, or --file")
            raise click.Abort()
        
        generator = SyntheticDataGenerator()
        
        with console.status("[bold green]Generating test cases..."):
            if domain:
                dataset = generator.generate_from_domain(domain, num_cases, rag)
            elif text:
                dataset = generator.generate_from_text(text, num_cases)
            elif file:
                dataset = generator.generate_from_file(file, num_cases)
        
        # Save dataset
        dataset_json = dataset.to_json()
        with open(output, 'w') as f:
            f.write(dataset_json)
        
        console.print(f"[bold green]✓[/bold green] Generated {len(dataset)} test cases")
        console.print(f"[bold]Saved to:[/bold] {output}")
        
        # Display sample
        if len(dataset) > 0:
            console.print("\n[bold]Sample test case:[/bold]")
            sample = dataset.test_cases[0]
            sample_table = Table(show_header=False, box=None)
            sample_table.add_column("Field", style="bold cyan")
            sample_table.add_column("Value")
            sample_table.add_row("Input", sample.input[:100] + "..." if len(sample.input) > 100 else sample.input)
            sample_table.add_row("Expected", sample.expected_output[:100] + "..." if sample.expected_output and len(sample.expected_output) > 100 else sample.expected_output or "N/A")
            if sample.retrieval_context:
                sample_table.add_row("Context", f"{len(sample.retrieval_context)} items")
            console.print(sample_table)
    
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        raise click.Abort()


@cli.command()
@click.argument('results_file', type=click.Path(exists=True))
@click.option('--format', type=click.Choice(['html', 'json']), default='html', help='Report format')
@click.option('--output', help='Output file path (default: report.html or report.json)')
def report(results_file, format, output):
    """Generate a report from evaluation results.
    
    The results file should be a JSON file containing evaluation results
    (typically generated by the 'batch' command).
    
    Examples:
        aligneval report results.json --format html
        aligneval report results.json --format json --output my_report.json
    """
    try:
        # Load results
        console.print(f"[bold]Loading results from:[/bold] {results_file}")
        with open(results_file, 'r') as f:
            results_data = json.load(f)
        
        # Parse results
        results = [EvaluationResult.model_validate(r) for r in results_data]
        console.print(f"[bold green]✓[/bold green] Loaded {len(results)} evaluation results")
        
        # Generate report
        generator = ReportGenerator()
        
        # Determine output path
        if not output:
            output = f"report.{format}"
        
        with console.status(f"[bold green]Generating {format.upper()} report..."):
            if format == 'html':
                generator.generate_html(results, output)
            else:
                generator.generate_json(results, output)
        
        console.print(f"[bold green]✓[/bold green] Report generated: {output}")
        
        # Display summary
        passed = sum(1 for r in results if r.passed)
        avg_score = sum(r.overall_score for r in results) / len(results) if results else 0.0
        
        console.print(f"\n[bold]Report Summary:[/bold]")
        summary_table = Table(show_header=False, box=None)
        summary_table.add_column("Label", style="bold")
        summary_table.add_column("Value")
        summary_table.add_row("Total Cases", str(len(results)))
        summary_table.add_row("Passed", f"[green]{passed}[/green] ({passed/len(results)*100:.1f}%)")
        summary_table.add_row("Average Score", f"{avg_score:.2f}")
        summary_table.add_row("Format", format.upper())
        console.print(summary_table)
    
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        raise click.Abort()


if __name__ == '__main__':
    cli()
