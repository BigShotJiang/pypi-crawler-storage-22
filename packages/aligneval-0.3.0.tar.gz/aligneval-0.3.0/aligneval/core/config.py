"""Configuration management for AlignEval using Pydantic settings."""

import logging
import sys
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    AlignEval configuration loaded from environment variables.
    
    All settings are prefixed with ALIGNEVAL_ in environment variables.
    Example: ALIGNEVAL_OPENAI_API_KEY, ALIGNEVAL_JUDGE_MODEL, etc.
    """
    
    model_config = SettingsConfigDict(
        env_prefix="ALIGNEVAL_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )
    
    # OpenAI Configuration
    openai_api_key: str = Field(
        ...,
        description="OpenAI API key for accessing GPT-4o/GPT-4.1",
    )
    
    # Judge Model Configuration
    judge_model: Literal["gpt-4o", "gpt-4.1"] = Field(
        default="gpt-4o",
        description="Judge model to use for evaluation",
    )
    
    # Model Parameters
    temperature: float = Field(
        default=0.0,
        ge=0.0,
        le=2.0,
        description="Temperature for judge LLM (0.0 = deterministic, 2.0 = creative)",
    )
    
    max_tokens: int = Field(
        default=1000,
        gt=0,
        description="Maximum tokens for judge LLM responses",
    )
    
    timeout: int = Field(
        default=60,
        gt=0,
        description="Timeout for API calls in seconds",
    )
    
    # Retry Configuration
    max_retries: int = Field(
        default=3,
        ge=0,
        description="Maximum number of retry attempts for failed API calls",
    )
    
    retry_delay: float = Field(
        default=1.0,
        gt=0.0,
        description="Initial retry delay in seconds (uses exponential backoff)",
    )
    
    # Async Configuration
    max_concurrent_requests: int = Field(
        default=10,
        gt=0,
        description="Maximum number of concurrent API requests for batch evaluation",
    )
    
    # Position Bias Mitigation
    enable_position_bias_mitigation: bool = Field(
        default=True,
        description="Enable randomization of output ordering to reduce position bias",
    )
    
    # Logging Configuration
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="INFO",
        description="Logging level for AlignEval",
    )
    
    log_file: str | None = Field(
        default=None,
        description="Path to log file (if None, logs only to console)",
    )
    
    log_format: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Format string for log messages",
    )
    
    @field_validator("openai_api_key")
    @classmethod
    def validate_api_key(cls, v: str) -> str:
        """Validate that API key is not empty or placeholder."""
        if not v or v.strip() == "":
            raise ValueError("OpenAI API key cannot be empty")
        if "your-openai-api-key-here" in v.lower():
            raise ValueError("Please set a valid OpenAI API key")
        return v.strip()
    
    @field_validator("temperature")
    @classmethod
    def validate_temperature(cls, v: float) -> float:
        """Validate temperature is within valid range."""
        if not 0.0 <= v <= 2.0:
            raise ValueError("Temperature must be between 0.0 and 2.0")
        return v


# Global settings instance
_settings: Settings | None = None


def configure_logging(settings: Settings) -> None:
    """
    Configure logging based on settings.
    
    Sets up both console and file handlers (if log_file is specified).
    
    Args:
        settings: Settings instance with logging configuration
    """
    # Get the root logger for aligneval
    logger = logging.getLogger("aligneval")
    logger.setLevel(getattr(logging, settings.log_level))
    
    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()
    
    # Create formatter
    formatter = logging.Formatter(settings.log_format)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, settings.log_level))
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler (if log_file is specified)
    if settings.log_file:
        log_path = Path(settings.log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(getattr(logging, settings.log_level))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        logger.info(f"Logging to file: {log_path}")
    
    logger.info(f"Logging configured with level: {settings.log_level}")


def get_settings() -> Settings:
    """
    Get the global settings instance.
    
    Creates a new instance on first call, then returns cached instance.
    Configures logging on first initialization.
    Useful for dependency injection and testing.
    
    Returns:
        Settings: The global settings instance
    """
    global _settings
    if _settings is None:
        _settings = Settings()
        configure_logging(_settings)
    return _settings


def reset_settings() -> None:
    """
    Reset the global settings instance.
    
    Useful for testing to ensure clean state between tests.
    """
    global _settings
    _settings = None
