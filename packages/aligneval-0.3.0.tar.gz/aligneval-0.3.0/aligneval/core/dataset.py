"""Core data model for evaluation datasets."""

from typing import List, Iterator, Dict, Any
from pydantic import BaseModel, Field, ConfigDict
from aligneval.core.test_case import LLMTestCase


class EvaluationDataset(BaseModel):
    """A collection of test cases for batch evaluation.
    
    This model represents a dataset containing multiple LLMTestCase instances
    for batch evaluation workflows. It provides collection management methods
    and JSON serialization/deserialization.
    
    Attributes:
        name: A descriptive name for the dataset
        test_cases: List of LLMTestCase instances
        metadata: Additional metadata for the dataset
    """
    
    name: str = Field(..., description="A descriptive name for the dataset")
    test_cases: List[LLMTestCase] = Field(
        default_factory=list,
        description="List of test cases in the dataset"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata for the dataset"
    )
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "name": "customer_support_tests",
                "test_cases": [
                    {
                        "input": "How do I reset my password?",
                        "actual_output": "You can reset your password by clicking the 'Forgot Password' link.",
                        "expected_output": "Click 'Forgot Password' on the login page."
                    }
                ],
                "metadata": {"version": "1.0", "created_by": "test_team"}
            }
        }
    )
    
    def add_test_case(self, test_case: LLMTestCase) -> None:
        """Add a test case to the dataset.
        
        Args:
            test_case: The LLMTestCase to add
        """
        self.test_cases.append(test_case)
    
    def remove_test_case(self, index: int) -> LLMTestCase:
        """Remove and return a test case at the specified index.
        
        Args:
            index: The index of the test case to remove
            
        Returns:
            The removed LLMTestCase
            
        Raises:
            IndexError: If index is out of range
        """
        return self.test_cases.pop(index)
    
    def __len__(self) -> int:
        """Return the number of test cases in the dataset.
        
        Returns:
            The number of test cases
        """
        return len(self.test_cases)
    
    def __iter__(self) -> Iterator[LLMTestCase]:
        """Iterate over test cases in the dataset.
        
        Returns:
            An iterator over LLMTestCase instances
        """
        return iter(self.test_cases)
    
    @classmethod
    def from_json(cls, json_str: str) -> "EvaluationDataset":
        """Create an EvaluationDataset from a JSON string.
        
        Args:
            json_str: JSON string representation of the dataset
            
        Returns:
            An EvaluationDataset instance
        """
        return cls.model_validate_json(json_str)
    
    def to_json(self) -> str:
        """Convert the dataset to a JSON string.
        
        Returns:
            JSON string representation of the dataset
        """
        return self.model_dump_json()
