"""Core data model for LLM test cases."""

from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, Dict, Any, List


class LLMTestCase(BaseModel):
    """A single test case for LLM evaluation.
    
    This model represents a single evaluation instance containing the input prompt,
    actual LLM output, optional expected output, optional retrieval context for RAG
    systems, and additional metadata.
    
    Attributes:
        input: The input prompt or query sent to the LLM
        actual_output: The actual LLM response to evaluate
        expected_output: The expected/ideal response (optional)
        retrieval_context: Retrieved context for RAG systems (optional)
        additional_metadata: Extra metadata for extensibility
    """
    
    input: str = Field(..., description="The input prompt or query")
    actual_output: str = Field(..., description="The actual LLM response to evaluate")
    expected_output: Optional[str] = Field(None, description="The expected/ideal response")
    retrieval_context: Optional[List[str]] = Field(
        None, 
        description="Retrieved context for RAG systems"
    )
    additional_metadata: Dict[str, Any] = Field(
        default_factory=dict, 
        description="Extra metadata"
    )
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "input": "What is the capital of France?",
                "actual_output": "The capital of France is Paris.",
                "expected_output": "Paris",
                "retrieval_context": ["Paris is the capital and largest city of France."],
                "additional_metadata": {"model": "gpt-4", "timestamp": "2025-01-15"}
            }
        }
    )
