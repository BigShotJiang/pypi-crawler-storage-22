"""Main evaluator for general LLM metrics."""

import asyncio
import logging
from datetime import datetime
from typing import List

from pydantic import BaseModel, Field
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from aligneval.core.test_case import LLMTestCase
from aligneval.core.dataset import EvaluationDataset
from aligneval.core.config import get_settings
from aligneval.metrics.base import BaseMetric, MetricResult

logger = logging.getLogger(__name__)


class EvaluationResult(BaseModel):
    """Result of evaluating a test case.
    
    This model represents the complete evaluation result for a single test case,
    including all metric results, an overall score, and metadata.
    
    Attributes:
        test_case: The test case that was evaluated
        metric_results: List of results from each metric
        overall_score: Average of all normalized scores
        timestamp: ISO format timestamp of when evaluation completed
    """
    
    test_case: LLMTestCase = Field(..., description="The test case that was evaluated")
    metric_results: List[MetricResult] = Field(..., description="Results from each metric")
    overall_score: float = Field(..., description="Average of all normalized scores")
    timestamp: str = Field(..., description="ISO format timestamp of evaluation")
    
    @property
    def passed(self) -> bool:
        """Check if evaluation passed (all scores > 0.6).
        
        Returns:
            bool: True if all non-error metric scores are above 0.6
        """
        return all(
            r.normalized_score > 0.6 
            for r in self.metric_results 
            if not r.error
        )


class AlignEvaluator:
    """Main evaluator for general LLM metrics.
    
    This evaluator executes multiple metrics on test cases and aggregates the results.
    It supports both synchronous and asynchronous evaluation, as well as batch
    processing of datasets with progress tracking.
    
    Attributes:
        metrics: List of metrics to evaluate
    """
    
    def __init__(self, metrics: List[BaseMetric]):
        """Initialize the evaluator with a list of metrics.
        
        Args:
            metrics: List of BaseMetric instances to use for evaluation
        """
        self.metrics = metrics
        logger.info(f"Initialized AlignEvaluator with {len(metrics)} metrics: {[m.name for m in metrics]}")
    
    def evaluate(self, test_case: LLMTestCase) -> EvaluationResult:
        """Evaluate a single test case synchronously.
        
        Executes all configured metrics on the test case and aggregates the results
        into a single EvaluationResult.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            EvaluationResult: Aggregated results from all metrics
        """
        logger.info(f"Evaluating test case with {len(self.metrics)} metrics")
        metric_results = []
        
        for metric in self.metrics:
            try:
                result = metric.evaluate(test_case)
                metric_results.append(result)
            except Exception as e:
                logger.error(f"Error evaluating metric {metric.name}: {e}", exc_info=True)
                raise
        
        overall_score = self._calculate_overall_score(metric_results)
        logger.info(f"Evaluation complete. Overall score: {overall_score:.3f}")
        
        return EvaluationResult(
            test_case=test_case,
            metric_results=metric_results,
            overall_score=overall_score,
            timestamp=datetime.now().isoformat()
        )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> EvaluationResult:
        """Evaluate a single test case asynchronously.
        
        Executes all configured metrics concurrently on the test case and aggregates
        the results into a single EvaluationResult.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            EvaluationResult: Aggregated results from all metrics
        """
        tasks = [metric.evaluate_async(test_case) for metric in self.metrics]
        metric_results = await asyncio.gather(*tasks)
        
        overall_score = self._calculate_overall_score(list(metric_results))
        
        return EvaluationResult(
            test_case=test_case,
            metric_results=list(metric_results),
            overall_score=overall_score,
            timestamp=datetime.now().isoformat()
        )
    
    def evaluate_dataset(self, dataset: EvaluationDataset) -> List[EvaluationResult]:
        """Evaluate a dataset synchronously with progress bar.
        
        Processes all test cases in the dataset sequentially, displaying a Rich
        progress bar. Errors in individual test cases are handled gracefully and
        don't stop the batch evaluation.
        
        Args:
            dataset: The dataset to evaluate
            
        Returns:
            List[EvaluationResult]: Results for all test cases
        """
        logger.info(f"Starting batch evaluation of {len(dataset)} test cases")
        results = []
        errors = 0
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        ) as progress:
            task = progress.add_task(
                f"Evaluating {len(dataset)} test cases...",
                total=len(dataset)
            )
            
            for idx, test_case in enumerate(dataset):
                try:
                    logger.debug(f"Evaluating test case {idx + 1}/{len(dataset)}")
                    result = self.evaluate(test_case)
                    results.append(result)
                except Exception as e:
                    # Log error but continue with other test cases
                    errors += 1
                    logger.error(f"Error evaluating test case {idx + 1}: {e}", exc_info=True)
                    print(f"Error evaluating test case: {e}")
                    # Create an error result
                    error_result = EvaluationResult(
                        test_case=test_case,
                        metric_results=[
                            MetricResult(
                                metric_name="Error",
                                raw_score=1,
                                normalized_score=0.0,
                                reasoning="",
                                error=str(e)
                            )
                        ],
                        overall_score=0.0,
                        timestamp=datetime.now().isoformat()
                    )
                    results.append(error_result)
                finally:
                    progress.update(task, advance=1)
        
        logger.info(f"Batch evaluation complete. {len(results)} results, {errors} errors")
        return results
    
    async def evaluate_dataset_async(
        self,
        dataset: EvaluationDataset,
        max_concurrent: int = None
    ) -> List[EvaluationResult]:
        """Evaluate a dataset asynchronously with concurrency control.
        
        Processes test cases concurrently with a configurable concurrency limit.
        This provides better performance for large datasets while respecting API
        rate limits.
        
        Args:
            dataset: The dataset to evaluate
            max_concurrent: Maximum number of concurrent evaluations (defaults to
                          settings.max_concurrent_requests)
            
        Returns:
            List[EvaluationResult]: Results for all test cases
        """
        settings = get_settings()
        if max_concurrent is None:
            max_concurrent = settings.max_concurrent_requests
        
        logger.info(f"Starting async batch evaluation of {len(dataset)} test cases with max_concurrent={max_concurrent}")
        
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def evaluate_with_semaphore(test_case: LLMTestCase) -> EvaluationResult:
            """Evaluate a test case with semaphore-based concurrency control."""
            async with semaphore:
                try:
                    return await self.evaluate_async(test_case)
                except Exception as e:
                    logger.error(f"Error in async evaluation: {e}", exc_info=True)
                    # Return error result instead of raising
                    return EvaluationResult(
                        test_case=test_case,
                        metric_results=[
                            MetricResult(
                                metric_name="Error",
                                raw_score=1,
                                normalized_score=0.0,
                                reasoning="",
                                error=str(e)
                            )
                        ],
                        overall_score=0.0,
                        timestamp=datetime.now().isoformat()
                    )
        
        tasks = [evaluate_with_semaphore(tc) for tc in dataset]
        results = await asyncio.gather(*tasks)
        
        errors = sum(1 for r in results if any(mr.error for mr in r.metric_results))
        logger.info(f"Async batch evaluation complete. {len(results)} results, {errors} errors")
        
        return list(results)
    
    def _calculate_overall_score(self, metric_results: List[MetricResult]) -> float:
        """Calculate overall score as average of normalized scores.
        
        Only includes scores from metrics that didn't error. If all metrics errored,
        returns 0.0.
        
        Args:
            metric_results: List of metric results
            
        Returns:
            float: Average normalized score, or 0.0 if no valid scores
        """
        valid_scores = [r.normalized_score for r in metric_results if not r.error]
        return sum(valid_scores) / len(valid_scores) if valid_scores else 0.0
