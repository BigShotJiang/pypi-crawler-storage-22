"""LangGraph-based evaluation pipeline for structured evaluation workflows."""

import asyncio
import logging
from datetime import datetime
from typing import TypedDict, List, Optional

from langgraph.graph import StateGraph, END

from aligneval.core.test_case import LLMTestCase
from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.evaluator.evaluator import EvaluationResult

logger = logging.getLogger(__name__)


class PipelineState(TypedDict):
    """State for evaluation pipeline.
    
    This TypedDict defines the state that flows through the LangGraph evaluation
    pipeline. Each node in the pipeline can read from and write to this state.
    
    Attributes:
        test_case: The test case being evaluated
        metrics: List of metrics to execute
        metric_results: Results from executed metrics
        overall_score: Calculated overall score
        error: Error message if validation or execution fails
    """
    
    test_case: LLMTestCase
    metrics: List[BaseMetric]
    metric_results: List[MetricResult]
    overall_score: float
    error: Optional[str]


def create_evaluation_pipeline() -> StateGraph:
    """Create LangGraph evaluation pipeline.
    
    This function creates a LangGraph StateGraph that orchestrates the evaluation
    workflow with the following nodes:
    1. validate_input: Validates that the test case has required fields
    2. execute_metrics: Executes all metrics asynchronously
    3. calculate_score: Calculates the overall score from metric results
    
    The pipeline includes conditional routing based on validation results.
    
    Returns:
        StateGraph: Compiled LangGraph evaluation pipeline
    """
    
    workflow = StateGraph(PipelineState)
    
    # Node: Validate input
    def validate_input(state: PipelineState) -> PipelineState:
        """Validate test case has required fields.
        
        Checks if RAG metrics require retrieval_context and validates that it's present.
        
        Args:
            state: Current pipeline state
            
        Returns:
            PipelineState: Updated state with error field set if validation fails
        """
        logger.debug("Pipeline: Validating input")
        test_case = state["test_case"]
        metrics = state["metrics"]
        
        # Check if RAG metrics require context
        rag_metrics = {
            "Faithfulness", "Answer Relevancy", "Context Precision",
            "Context Recall", "Groundedness"
        }
        requires_context = any(m.name in rag_metrics for m in metrics)
        
        if requires_context and not test_case.retrieval_context:
            error_msg = "RAG metrics require retrieval_context"
            logger.error(f"Pipeline validation failed: {error_msg}")
            state["error"] = error_msg
            return state
        
        logger.debug("Pipeline: Validation passed")
        state["error"] = None
        return state
    
    # Node: Execute metrics
    async def execute_metrics(state: PipelineState) -> PipelineState:
        """Execute all metrics asynchronously.
        
        Runs all metrics concurrently and handles exceptions gracefully by creating
        error results for failed metrics.
        
        Args:
            state: Current pipeline state
            
        Returns:
            PipelineState: Updated state with metric_results populated
        """
        if state.get("error"):
            logger.debug("Pipeline: Skipping metric execution due to validation error")
            return state
        
        logger.info(f"Pipeline: Executing {len(state['metrics'])} metrics")
        test_case = state["test_case"]
        metrics = state["metrics"]
        
        # Execute all metrics concurrently
        tasks = [metric.evaluate_async(test_case) for metric in metrics]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results and handle exceptions
        metric_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                # Create error result for failed metric
                logger.error(f"Pipeline: Metric {metrics[i].name} failed: {result}")
                metric_results.append(MetricResult(
                    metric_name=metrics[i].name,
                    raw_score=1,
                    normalized_score=0.0,
                    reasoning="",
                    error=str(result)
                ))
            else:
                metric_results.append(result)
        
        state["metric_results"] = metric_results
        logger.info(f"Pipeline: Executed {len(metric_results)} metrics")
        return state
    
    # Node: Calculate overall score
    def calculate_score(state: PipelineState) -> PipelineState:
        """Calculate overall score from metric results.
        
        Computes the average of all valid normalized scores. If there's a validation
        error, sets the overall score to 0.0.
        
        Args:
            state: Current pipeline state
            
        Returns:
            PipelineState: Updated state with overall_score calculated
        """
        if state.get("error"):
            logger.debug("Pipeline: Setting overall score to 0.0 due to error")
            state["overall_score"] = 0.0
            return state
        
        metric_results = state["metric_results"]
        valid_scores = [r.normalized_score for r in metric_results if not r.error]
        overall_score = sum(valid_scores) / len(valid_scores) if valid_scores else 0.0
        
        state["overall_score"] = overall_score
        logger.info(f"Pipeline: Calculated overall score: {overall_score:.3f}")
        return state
    
    # Add nodes to workflow
    workflow.add_node("validate", validate_input)
    workflow.add_node("execute", execute_metrics)
    workflow.add_node("calculate", calculate_score)
    
    # Set entry point
    workflow.set_entry_point("validate")
    
    # Conditional routing based on validation
    def should_continue(state: PipelineState) -> str:
        """Conditional routing based on validation.
        
        If validation fails, skip to calculate node (which will set score to 0.0).
        Otherwise, proceed to execute metrics.
        
        Args:
            state: Current pipeline state
            
        Returns:
            str: Next node to execute ("execute" or "calculate")
        """
        if state.get("error"):
            logger.debug("Pipeline: Routing to calculate due to validation error")
            return "calculate"
        else:
            logger.debug("Pipeline: Routing to execute")
            return "execute"
    
    # Add conditional edges
    workflow.add_conditional_edges(
        "validate",
        should_continue,
        {
            "execute": "execute",
            "calculate": "calculate"
        }
    )
    
    # Add regular edges
    workflow.add_edge("execute", "calculate")
    workflow.add_edge("calculate", END)
    
    logger.debug("Pipeline: Workflow compiled")
    return workflow.compile()


class EvaluationPipeline:
    """Wrapper for LangGraph evaluation pipeline.
    
    This class provides a high-level interface to the LangGraph evaluation pipeline,
    making it easy to execute evaluations with automatic state management and
    result conversion.
    
    Attributes:
        graph: Compiled LangGraph StateGraph
    """
    
    def __init__(self):
        """Initialize the evaluation pipeline by compiling the graph."""
        logger.info("Initializing EvaluationPipeline")
        self.graph = create_evaluation_pipeline()
    
    async def evaluate(
        self,
        test_case: LLMTestCase,
        metrics: List[BaseMetric]
    ) -> EvaluationResult:
        """Execute pipeline evaluation.
        
        Runs the complete evaluation pipeline on a test case with the specified
        metrics, handling state management and converting the final state to an
        EvaluationResult.
        
        Args:
            test_case: The test case to evaluate
            metrics: List of metrics to execute
            
        Returns:
            EvaluationResult: Aggregated evaluation result
        """
        logger.info(f"Pipeline: Starting evaluation with {len(metrics)} metrics")
        
        # Create initial state
        initial_state: PipelineState = {
            "test_case": test_case,
            "metrics": metrics,
            "metric_results": [],
            "overall_score": 0.0,
            "error": None
        }
        
        # Execute pipeline
        final_state = await self.graph.ainvoke(initial_state)
        
        # Convert to EvaluationResult
        result = EvaluationResult(
            test_case=test_case,
            metric_results=final_state["metric_results"],
            overall_score=final_state["overall_score"],
            timestamp=datetime.now().isoformat()
        )
        
        logger.info(f"Pipeline: Evaluation complete. Overall score: {result.overall_score:.3f}")
        return result
