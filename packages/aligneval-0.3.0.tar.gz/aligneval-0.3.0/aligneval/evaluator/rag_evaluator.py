"""Specialized evaluator for RAG systems with diagnostic insights."""

import asyncio
import logging
from datetime import datetime
from typing import List

from pydantic import BaseModel, Field

from aligneval.core.test_case import LLMTestCase
from aligneval.core.dataset import EvaluationDataset
from aligneval.core.config import get_settings
from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.evaluator.evaluator import EvaluationResult

logger = logging.getLogger(__name__)


class RAGDiagnostics(BaseModel):
    """Diagnostic insights for RAG evaluation.
    
    This model provides detailed analysis of RAG system performance by separating
    retrieval quality from generation quality, identifying bottlenecks, and
    providing actionable recommendations.
    
    Attributes:
        retrieval_score: Average score of retrieval metrics (Context Precision, Context Recall)
        generation_score: Average score of generation metrics (Faithfulness, Answer Relevancy, Groundedness)
        bottleneck: Identifies whether "retrieval" or "generation" is the weaker component
        recommendations: List of actionable recommendations for improvement
    """
    
    retrieval_score: float = Field(..., description="Average of Context Precision + Context Recall")
    generation_score: float = Field(..., description="Average of Faithfulness + Answer Relevancy + Groundedness")
    bottleneck: str = Field(..., description="Either 'retrieval' or 'generation'")
    recommendations: List[str] = Field(default_factory=list, description="Actionable improvement recommendations")


class RAGEvaluationResult(EvaluationResult):
    """Extended evaluation result with RAG-specific diagnostics.
    
    This model extends the base EvaluationResult with RAG-specific diagnostic
    information that helps identify whether retrieval or generation is the
    bottleneck in the RAG pipeline.
    
    Attributes:
        diagnostics: RAG-specific diagnostic insights
    """
    
    diagnostics: RAGDiagnostics = Field(..., description="RAG-specific diagnostic insights")


class RAGEvaluator:
    """Specialized evaluator for RAG systems.
    
    This evaluator is designed specifically for Retrieval-Augmented Generation systems.
    It validates that retrieval context is present, executes RAG-specific metrics,
    and provides diagnostic insights that separate retrieval quality from generation
    quality to help identify bottlenecks.
    
    Attributes:
        metrics: List of metrics to evaluate (must include at least one RAG metric)
    """
    
    def __init__(self, metrics: List[BaseMetric]):
        """Initialize the RAG evaluator with a list of metrics.
        
        Args:
            metrics: List of BaseMetric instances to use for evaluation
            
        Raises:
            ValueError: If no RAG-specific metrics are included
        """
        self.metrics = metrics
        self._validate_rag_metrics()
        logger.info(f"Initialized RAGEvaluator with {len(metrics)} metrics: {[m.name for m in metrics]}")
    
    def _validate_rag_metrics(self) -> None:
        """Ensure at least one RAG metric is included.
        
        Raises:
            ValueError: If no RAG-specific metrics are found
        """
        rag_metric_names = {
            "Faithfulness", "Answer Relevancy", "Context Precision",
            "Context Recall", "Groundedness"
        }
        has_rag_metric = any(m.name in rag_metric_names for m in self.metrics)
        if not has_rag_metric:
            raise ValueError("RAGEvaluator requires at least one RAG-specific metric")
    
    def evaluate(self, test_case: LLMTestCase) -> RAGEvaluationResult:
        """Evaluate a RAG test case with diagnostics.
        
        Executes all configured metrics on the test case and generates diagnostic
        insights that separate retrieval performance from generation performance.
        
        Args:
            test_case: The test case to evaluate (must have retrieval_context)
            
        Returns:
            RAGEvaluationResult: Aggregated results with RAG diagnostics
            
        Raises:
            ValueError: If test_case does not have retrieval_context
        """
        if not test_case.retrieval_context:
            logger.error("RAG evaluation attempted without retrieval_context")
            raise ValueError("RAG evaluation requires retrieval_context")
        
        logger.info(f"Evaluating RAG test case with {len(self.metrics)} metrics")
        
        metric_results = []
        for metric in self.metrics:
            try:
                result = metric.evaluate(test_case)
                metric_results.append(result)
            except Exception as e:
                logger.error(f"Error evaluating RAG metric {metric.name}: {e}", exc_info=True)
                raise
        
        overall_score = self._calculate_overall_score(metric_results)
        diagnostics = self._generate_diagnostics(metric_results)
        
        logger.info(f"RAG evaluation complete. Overall: {overall_score:.3f}, "
                   f"Retrieval: {diagnostics.retrieval_score:.3f}, "
                   f"Generation: {diagnostics.generation_score:.3f}, "
                   f"Bottleneck: {diagnostics.bottleneck}")
        
        return RAGEvaluationResult(
            test_case=test_case,
            metric_results=metric_results,
            overall_score=overall_score,
            timestamp=datetime.now().isoformat(),
            diagnostics=diagnostics
        )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> RAGEvaluationResult:
        """Async RAG evaluation with diagnostics.
        
        Executes all configured metrics concurrently on the test case and generates
        diagnostic insights that separate retrieval performance from generation performance.
        
        Args:
            test_case: The test case to evaluate (must have retrieval_context)
            
        Returns:
            RAGEvaluationResult: Aggregated results with RAG diagnostics
            
        Raises:
            ValueError: If test_case does not have retrieval_context
        """
        if not test_case.retrieval_context:
            raise ValueError("RAG evaluation requires retrieval_context")
        
        tasks = [metric.evaluate_async(test_case) for metric in self.metrics]
        metric_results = await asyncio.gather(*tasks)
        
        overall_score = self._calculate_overall_score(list(metric_results))
        diagnostics = self._generate_diagnostics(list(metric_results))
        
        return RAGEvaluationResult(
            test_case=test_case,
            metric_results=list(metric_results),
            overall_score=overall_score,
            timestamp=datetime.now().isoformat(),
            diagnostics=diagnostics
        )
    
    def _generate_diagnostics(self, metric_results: List[MetricResult]) -> RAGDiagnostics:
        """Generate diagnostic insights from metric results.
        
        Analyzes metric results to separate retrieval quality from generation quality,
        identifies the bottleneck, and provides actionable recommendations.
        
        Args:
            metric_results: List of metric results from evaluation
            
        Returns:
            RAGDiagnostics: Diagnostic insights with scores, bottleneck, and recommendations
        """
        retrieval_metrics = ["Context Precision", "Context Recall"]
        generation_metrics = ["Faithfulness", "Answer Relevancy", "Groundedness"]
        
        # Calculate retrieval score
        retrieval_scores = [
            r.normalized_score for r in metric_results
            if r.metric_name in retrieval_metrics and not r.error
        ]
        retrieval_score = sum(retrieval_scores) / len(retrieval_scores) if retrieval_scores else 0.0
        
        # Calculate generation score
        generation_scores = [
            r.normalized_score for r in metric_results
            if r.metric_name in generation_metrics and not r.error
        ]
        generation_score = sum(generation_scores) / len(generation_scores) if generation_scores else 0.0
        
        # Identify bottleneck
        bottleneck = "retrieval" if retrieval_score < generation_score else "generation"
        
        # Generate recommendations
        recommendations = []
        if retrieval_score < 0.6:
            recommendations.append("Improve retrieval: Consider better embedding models or retrieval strategies")
        if generation_score < 0.6:
            recommendations.append("Improve generation: Consider better prompts or more capable LLM")
        if retrieval_score < 0.4:
            recommendations.append("Critical: Retrieval is failing to find relevant context")
        if generation_score < 0.4:
            recommendations.append("Critical: Generation is not using context effectively")
        
        return RAGDiagnostics(
            retrieval_score=retrieval_score,
            generation_score=generation_score,
            bottleneck=bottleneck,
            recommendations=recommendations
        )
    
    def _calculate_overall_score(self, metric_results: List[MetricResult]) -> float:
        """Calculate overall score as average of normalized scores.
        
        Only includes scores from metrics that didn't error. If all metrics errored,
        returns 0.0.
        
        Args:
            metric_results: List of metric results
            
        Returns:
            float: Average normalized score, or 0.0 if no valid scores
        """
        valid_scores = [r.normalized_score for r in metric_results if not r.error]
        return sum(valid_scores) / len(valid_scores) if valid_scores else 0.0
