"""Synthetic test case generation."""

from aligneval.generator.synthetic import SyntheticDataGenerator

__all__ = ["SyntheticDataGenerator"]
