"""Synthetic test case generation using GPT-4o/GPT-4.1."""

import json
import logging
from typing import Optional

from openai import OpenAI

from aligneval.core.config import get_settings
from aligneval.core.dataset import EvaluationDataset
from aligneval.core.test_case import LLMTestCase

logger = logging.getLogger(__name__)


class SyntheticDataGenerator:
    """Generate synthetic test cases for evaluation.
    
    This class uses GPT-4o/GPT-4.1 to automatically generate realistic test cases
    for evaluation. It supports generation from domain descriptions, text documents,
    and file uploads (PDF, TXT, MD).
    
    Attributes:
        client: OpenAI client for API calls
        settings: AlignEval settings instance
    """
    
    def __init__(self):
        """Initialize the synthetic data generator with OpenAI client."""
        self.settings = get_settings()
        self.client = OpenAI(api_key=self.settings.openai_api_key)
        logger.info("SyntheticDataGenerator initialized")
    
    def generate_from_domain(
        self,
        domain: str,
        num_cases: int = 10,
        include_rag: bool = False
    ) -> EvaluationDataset:
        """Generate test cases from a domain description.
        
        Creates realistic test cases for a specific domain (e.g., "customer support chatbot",
        "medical Q&A system"). The generator creates diverse input queries and expected outputs.
        
        Args:
            domain: Description of the domain (e.g., "customer support chatbot")
            num_cases: Number of test cases to generate (default: 10)
            include_rag: Whether to include retrieval_context for RAG evaluation (default: False)
            
        Returns:
            EvaluationDataset containing the generated test cases
            
        Example:
            >>> generator = SyntheticDataGenerator()
            >>> dataset = generator.generate_from_domain("customer support chatbot", num_cases=5)
            >>> print(len(dataset))
            5
        """
        logger.info(f"Generating {num_cases} test cases for domain: {domain}")
        
        prompt = f"""Generate {num_cases} realistic test cases for evaluating a {domain} system.

For each test case, provide:
1. input: A realistic user query
2. expected_output: An ideal response
"""
        if include_rag:
            prompt += "3. retrieval_context: Relevant context documents (2-3 sentences each, provide as array)\n"
        
        prompt += """
Return as JSON with this exact structure:
{
  "test_cases": [
    {
      "input": "...",
      "expected_output": "...",
"""
        if include_rag:
            prompt += '      "retrieval_context": ["...", "..."]\n'
        
        prompt += """    }
  ]
}

Make the test cases diverse and realistic."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.settings.judge_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                response_format={"type": "json_object"}
            )
            
            data = json.loads(response.choices[0].message.content)
            test_cases = []
            
            for case_data in data.get("test_cases", []):
                # Create test case with actual_output same as expected_output initially
                test_case = LLMTestCase(
                    input=case_data["input"],
                    actual_output=case_data.get("expected_output", ""),
                    expected_output=case_data.get("expected_output"),
                    retrieval_context=case_data.get("retrieval_context") if include_rag else None
                )
                test_cases.append(test_case)
            
            logger.info(f"Successfully generated {len(test_cases)} test cases")
            
            return EvaluationDataset(
                name=f"{domain}_synthetic",
                test_cases=test_cases,
                metadata={
                    "domain": domain,
                    "num_cases_requested": num_cases,
                    "include_rag": include_rag,
                    "generator": "SyntheticDataGenerator"
                }
            )
            
        except Exception as e:
            logger.error(f"Error generating test cases from domain: {e}", exc_info=True)
            raise
    
    def generate_from_text(
        self,
        text: str,
        num_cases: int = 10
    ) -> EvaluationDataset:
        """Generate test cases from a text document.
        
        Creates question-answer pairs based on the provided text content. Useful for
        creating evaluation datasets from documentation, articles, or knowledge bases.
        
        Args:
            text: The text content to generate test cases from
            num_cases: Number of test cases to generate (default: 10)
            
        Returns:
            EvaluationDataset containing the generated test cases
            
        Example:
            >>> generator = SyntheticDataGenerator()
            >>> text = "Paris is the capital of France. It has a population of 2.2 million."
            >>> dataset = generator.generate_from_text(text, num_cases=3)
        """
        logger.info(f"Generating {num_cases} test cases from text ({len(text)} chars)")
        
        # Truncate text for token limits (approximately 2000 chars = ~500 tokens)
        truncated_text = text[:2000]
        if len(text) > 2000:
            logger.warning(f"Text truncated from {len(text)} to 2000 chars for token limits")
        
        prompt = f"""Given this text, generate {num_cases} question-answer pairs for evaluation:

Text:
{truncated_text}

Generate diverse questions that test understanding of this content.
For each test case, provide:
1. input: A question about the text
2. expected_output: The correct answer based on the text
3. retrieval_context: Relevant excerpts from the text (as array)

Return as JSON with this exact structure:
{{
  "test_cases": [
    {{
      "input": "...",
      "expected_output": "...",
      "retrieval_context": ["...", "..."]
    }}
  ]
}}"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.settings.judge_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                response_format={"type": "json_object"}
            )
            
            data = json.loads(response.choices[0].message.content)
            test_cases = []
            
            for case_data in data.get("test_cases", []):
                test_case = LLMTestCase(
                    input=case_data["input"],
                    actual_output=case_data.get("expected_output", ""),
                    expected_output=case_data.get("expected_output"),
                    retrieval_context=case_data.get("retrieval_context")
                )
                test_cases.append(test_case)
            
            logger.info(f"Successfully generated {len(test_cases)} test cases from text")
            
            return EvaluationDataset(
                name="text_based_synthetic",
                test_cases=test_cases,
                metadata={
                    "source": "text",
                    "text_length": len(text),
                    "num_cases_requested": num_cases,
                    "generator": "SyntheticDataGenerator"
                }
            )
            
        except Exception as e:
            logger.error(f"Error generating test cases from text: {e}", exc_info=True)
            raise
    
    def generate_from_file(
        self,
        file_path: str,
        num_cases: int = 10
    ) -> EvaluationDataset:
        """Generate test cases from a file (PDF, TXT, MD).
        
        Reads the file content and generates test cases based on it. Supports
        PDF, TXT, and MD file formats.
        
        Args:
            file_path: Path to the file (PDF, TXT, or MD)
            num_cases: Number of test cases to generate (default: 10)
            
        Returns:
            EvaluationDataset containing the generated test cases
            
        Raises:
            ValueError: If file format is not supported
            FileNotFoundError: If file does not exist
            
        Example:
            >>> generator = SyntheticDataGenerator()
            >>> dataset = generator.generate_from_file("docs/manual.pdf", num_cases=5)
        """
        logger.info(f"Generating {num_cases} test cases from file: {file_path}")
        
        # Extract text based on file type
        if file_path.endswith('.pdf'):
            text = self._extract_pdf_text(file_path)
        elif file_path.endswith(('.txt', '.md')):
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
        else:
            raise ValueError(f"Unsupported file format. Supported: PDF, TXT, MD")
        
        # Generate test cases from the extracted text
        dataset = self.generate_from_text(text, num_cases)
        
        # Update metadata with file information
        dataset.name = f"file_based_synthetic"
        dataset.metadata.update({
            "source": "file",
            "file_path": file_path
        })
        
        logger.info(f"Successfully generated {len(dataset)} test cases from file")
        return dataset
    
    def _extract_pdf_text(self, pdf_path: str) -> str:
        """Extract text from a PDF file.
        
        Uses PyPDF2 to extract text from all pages of a PDF document.
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            Extracted text content
            
        Raises:
            ImportError: If PyPDF2 is not installed
            FileNotFoundError: If PDF file does not exist
        """
        try:
            import PyPDF2
        except ImportError:
            raise ImportError(
                "PyPDF2 is required for PDF support. "
                "Install it with: pip install PyPDF2"
            )
        
        logger.info(f"Extracting text from PDF: {pdf_path}")
        
        try:
            with open(pdf_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                text = ""
                for page_num, page in enumerate(reader.pages):
                    page_text = page.extract_text()
                    text += page_text
                    logger.debug(f"Extracted {len(page_text)} chars from page {page_num + 1}")
                
                logger.info(f"Extracted total {len(text)} chars from {len(reader.pages)} pages")
                return text
                
        except FileNotFoundError:
            logger.error(f"PDF file not found: {pdf_path}")
            raise
        except Exception as e:
            logger.error(f"Error extracting PDF text: {e}", exc_info=True)
            raise
