"""LangChain integration adapter for AlignEval.

This module provides an adapter for evaluating LangChain chains and RAG systems
using AlignEval metrics. It handles the conversion of LangChain outputs to
LLMTestCase instances and supports both general chains and RAG chains with retrievers.
"""

import logging
from typing import Any, Dict, Optional

from aligneval.core.test_case import LLMTestCase
from aligneval.evaluator.evaluator import AlignEvaluator, EvaluationResult
from aligneval.evaluator.rag_evaluator import RAGEvaluator, RAGEvaluationResult

logger = logging.getLogger(__name__)


class LangChainAdapter:
    """Adapter for evaluating LangChain chains and agents.
    
    This adapter integrates AlignEval with LangChain, allowing you to evaluate
    LangChain chains and RAG systems using AlignEval's comprehensive metrics.
    
    Attributes:
        evaluator: The AlignEvaluator instance used for general chain evaluation
    
    Example:
        >>> from aligneval.integrations.langchain_adapter import LangChainAdapter
        >>> from aligneval.evaluator import AlignEvaluator
        >>> from aligneval.metrics import AccuracyMetric, RelevanceMetric
        >>> 
        >>> evaluator = AlignEvaluator([AccuracyMetric(), RelevanceMetric()])
        >>> adapter = LangChainAdapter(evaluator)
        >>> 
        >>> # Evaluate a LangChain chain
        >>> result = adapter.evaluate_chain(
        ...     chain=my_chain,
        ...     input_data={"query": "What is AI?"},
        ...     expected_output="Artificial Intelligence"
        ... )
    """
    
    def __init__(self, evaluator: AlignEvaluator):
        """Initialize the LangChain adapter.
        
        Args:
            evaluator: AlignEvaluator instance with configured metrics
        """
        self.evaluator = evaluator
        logger.info("LangChainAdapter initialized")
    
    def evaluate_chain(
        self,
        chain: Any,
        input_data: Dict[str, Any],
        expected_output: Optional[str] = None
    ) -> EvaluationResult:
        """Evaluate a LangChain chain.
        
        This method executes a LangChain chain with the provided input data,
        extracts the output, and evaluates it using the configured metrics.
        
        Args:
            chain: LangChain chain instance (e.g., LLMChain, SequentialChain)
            input_data: Input data dictionary to pass to the chain
            expected_output: Optional expected output for comparison
        
        Returns:
            EvaluationResult containing metric scores and analysis
        
        Raises:
            ValueError: If chain execution fails or output cannot be extracted
        
        Example:
            >>> result = adapter.evaluate_chain(
            ...     chain=my_llm_chain,
            ...     input_data={"question": "What is 2+2?"},
            ...     expected_output="4"
            ... )
            >>> print(f"Overall score: {result.overall_score}")
        """
        try:
            logger.info(f"Evaluating LangChain chain with input: {input_data}")
            
            # Execute chain
            output = chain.invoke(input_data)
            logger.debug(f"Chain output: {output}")
            
            # Extract output (handle different chain types)
            if isinstance(output, dict):
                # Try common output keys
                actual_output = (
                    output.get("output") or 
                    output.get("text") or 
                    output.get("answer") or 
                    str(output)
                )
            else:
                actual_output = str(output)
            
            # Create test case
            test_case = LLMTestCase(
                input=str(input_data),
                actual_output=actual_output,
                expected_output=expected_output
            )
            
            logger.info("Evaluating test case with AlignEvaluator")
            return self.evaluator.evaluate(test_case)
        
        except Exception as e:
            logger.error(f"Failed to evaluate LangChain chain: {e}", exc_info=True)
            raise ValueError(
                f"Failed to evaluate LangChain chain: {str(e)}\n"
                f"Ensure chain returns a dict with 'output', 'text', or 'answer' key, "
                f"or a string value"
            )
    
    def evaluate_rag_chain(
        self,
        chain: Any,
        retriever: Any,
        query: str,
        expected_output: Optional[str] = None
    ) -> RAGEvaluationResult:
        """Evaluate a RAG chain with retriever.
        
        This method evaluates a complete RAG pipeline by:
        1. Using the retriever to fetch relevant documents
        2. Executing the chain with the query and retrieved context
        3. Evaluating both retrieval quality and generation quality
        
        Args:
            chain: LangChain chain instance for generation
            retriever: LangChain retriever instance (BaseRetriever)
            query: Input query string
            expected_output: Optional expected output for comparison
        
        Returns:
            RAGEvaluationResult with diagnostics separating retrieval and generation scores
        
        Raises:
            ValueError: If retrieval or chain execution fails
        
        Example:
            >>> from aligneval.metrics import FaithfulnessMetric, ContextPrecisionMetric
            >>> 
            >>> rag_evaluator = RAGEvaluator([
            ...     FaithfulnessMetric(),
            ...     ContextPrecisionMetric()
            ... ])
            >>> adapter = LangChainAdapter(rag_evaluator)
            >>> 
            >>> result = adapter.evaluate_rag_chain(
            ...     chain=my_rag_chain,
            ...     retriever=my_retriever,
            ...     query="What is quantum computing?",
            ...     expected_output="Quantum computing uses qubits..."
            ... )
            >>> print(f"Retrieval score: {result.diagnostics.retrieval_score}")
            >>> print(f"Generation score: {result.diagnostics.generation_score}")
        """
        try:
            logger.info(f"Evaluating RAG chain with query: {query}")
            
            # Retrieve context
            docs = retriever.get_relevant_documents(query)
            context = [doc.page_content for doc in docs]
            logger.debug(f"Retrieved {len(context)} documents")
            
            # Execute chain with context
            chain_input = {"query": query, "context": context}
            output = chain.invoke(chain_input)
            
            # Extract output
            if isinstance(output, dict):
                actual_output = (
                    output.get("output") or 
                    output.get("text") or 
                    output.get("answer") or 
                    str(output)
                )
            else:
                actual_output = str(output)
            
            # Create test case with retrieval context
            test_case = LLMTestCase(
                input=query,
                actual_output=actual_output,
                expected_output=expected_output,
                retrieval_context=context
            )
            
            # Use RAGEvaluator for evaluation
            # Import here to avoid circular dependency
            from aligneval.metrics import FaithfulnessMetric, ContextPrecisionMetric
            
            # Create RAGEvaluator if the current evaluator is not a RAGEvaluator
            if isinstance(self.evaluator, RAGEvaluator):
                rag_evaluator = self.evaluator
            else:
                logger.info("Creating RAGEvaluator with default RAG metrics")
                rag_evaluator = RAGEvaluator([
                    FaithfulnessMetric(),
                    ContextPrecisionMetric()
                ])
            
            logger.info("Evaluating RAG test case")
            return rag_evaluator.evaluate(test_case)
        
        except Exception as e:
            logger.error(f"Failed to evaluate RAG chain: {e}", exc_info=True)
            raise ValueError(
                f"Failed to evaluate RAG chain: {str(e)}\n"
                f"Ensure retriever implements get_relevant_documents() and "
                f"chain accepts 'query' and 'context' inputs"
            )
