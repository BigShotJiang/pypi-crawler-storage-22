"""LangGraph integration adapter for AlignEval.

This module provides an adapter for evaluating LangGraph workflows using AlignEval
metrics. It handles the conversion of LangGraph state to LLMTestCase instances and
tracks state transitions throughout the workflow execution.
"""

import logging
from typing import Any, Dict, List, Optional

from aligneval.core.test_case import LLMTestCase
from aligneval.evaluator.evaluator import AlignEvaluator, EvaluationResult

logger = logging.getLogger(__name__)


class LangGraphAdapter:
    """Adapter for evaluating LangGraph workflows.
    
    This adapter integrates AlignEval with LangGraph, allowing you to evaluate
    LangGraph workflows and track state transitions throughout execution.
    
    Attributes:
        evaluator: The AlignEvaluator instance used for workflow evaluation
    
    Example:
        >>> from aligneval.integrations.langgraph_adapter import LangGraphAdapter
        >>> from aligneval.evaluator import AlignEvaluator
        >>> from aligneval.metrics import AccuracyMetric, RelevanceMetric
        >>> 
        >>> evaluator = AlignEvaluator([AccuracyMetric(), RelevanceMetric()])
        >>> adapter = LangGraphAdapter(evaluator)
        >>> 
        >>> # Evaluate a LangGraph workflow
        >>> result = adapter.evaluate_workflow(
        ...     graph=my_compiled_graph,
        ...     initial_state={"input": "What is AI?"},
        ...     expected_output="Artificial Intelligence"
        ... )
    """
    
    def __init__(self, evaluator: AlignEvaluator):
        """Initialize the LangGraph adapter.
        
        Args:
            evaluator: AlignEvaluator instance with configured metrics
        """
        self.evaluator = evaluator
        logger.info("LangGraphAdapter initialized")
    
    def evaluate_workflow(
        self,
        graph: Any,
        initial_state: Dict[str, Any],
        expected_output: Optional[str] = None
    ) -> EvaluationResult:
        """Evaluate a LangGraph workflow.
        
        This method executes a LangGraph workflow with the provided initial state,
        extracts the final output, tracks state transitions, and evaluates the
        result using the configured metrics.
        
        Args:
            graph: Compiled LangGraph StateGraph instance
            initial_state: Initial state dictionary to start the workflow
            expected_output: Optional expected output for comparison
        
        Returns:
            EvaluationResult containing metric scores and analysis, with state
            transitions included in additional_metadata
        
        Raises:
            ValueError: If workflow execution fails or output cannot be extracted
        
        Example:
            >>> from langgraph.graph import StateGraph
            >>> 
            >>> # Create and compile a graph
            >>> workflow = StateGraph(MyState)
            >>> # ... add nodes and edges ...
            >>> compiled_graph = workflow.compile()
            >>> 
            >>> # Evaluate the workflow
            >>> result = adapter.evaluate_workflow(
            ...     graph=compiled_graph,
            ...     initial_state={"input": "Explain quantum computing"},
            ...     expected_output="Quantum computing uses qubits..."
            ... )
            >>> print(f"Overall score: {result.overall_score}")
            >>> print(f"State transitions: {result.test_case.additional_metadata['state_transitions']}")
        """
        try:
            logger.info(f"Evaluating LangGraph workflow with initial state: {initial_state}")
            
            # Execute workflow
            final_state = graph.invoke(initial_state)
            logger.debug(f"Final state: {final_state}")
            
            # Extract input and output from state
            # Try multiple common keys for input
            input_text = str(
                initial_state.get("input") or 
                initial_state.get("query") or 
                initial_state.get("question") or 
                initial_state
            )
            
            # Try multiple common keys for output
            if isinstance(final_state, dict):
                output_text = str(
                    final_state.get("output") or 
                    final_state.get("response") or 
                    final_state.get("answer") or 
                    final_state.get("result") or 
                    final_state
                )
            else:
                output_text = str(final_state)
            
            # Extract state transitions
            transitions = self._extract_transitions(final_state)
            
            # Create test case with state transitions in metadata
            test_case = LLMTestCase(
                input=input_text,
                actual_output=output_text,
                expected_output=expected_output,
                additional_metadata={
                    "state_transitions": transitions,
                    "initial_state": initial_state,
                    "final_state": final_state if isinstance(final_state, dict) else str(final_state)
                }
            )
            
            logger.info("Evaluating test case with AlignEvaluator")
            return self.evaluator.evaluate(test_case)
        
        except Exception as e:
            logger.error(f"Failed to evaluate LangGraph workflow: {e}", exc_info=True)
            raise ValueError(
                f"Failed to evaluate LangGraph workflow: {str(e)}\n"
                f"Ensure graph is compiled and initial_state contains required fields. "
                f"Expected state to have 'input'/'query'/'question' and final state to have "
                f"'output'/'response'/'answer'/'result' keys"
            )
    
    def _extract_transitions(self, state: Dict[str, Any]) -> List[str]:
        """Extract state transitions from final state.
        
        This method attempts to extract state transition information from the
        final state. LangGraph may store transition history in various ways
        depending on the implementation.
        
        Args:
            state: Final state dictionary from workflow execution
        
        Returns:
            List of state transition descriptions, or empty list if not available
        
        Note:
            The implementation looks for common patterns where state transitions
            might be stored. If your workflow uses a different pattern, you may
            need to customize this method or store transitions explicitly in
            your state.
        """
        if not isinstance(state, dict):
            logger.debug("State is not a dictionary, cannot extract transitions")
            return []
        
        # Try common keys where transitions might be stored
        transitions = (
            state.get("_transitions") or 
            state.get("transitions") or 
            state.get("history") or 
            state.get("steps") or 
            []
        )
        
        # Convert to list of strings if needed
        if isinstance(transitions, list):
            result = [str(t) for t in transitions]
            logger.debug(f"Extracted {len(result)} state transitions")
            return result
        
        logger.debug("No state transitions found in final state")
        return []
