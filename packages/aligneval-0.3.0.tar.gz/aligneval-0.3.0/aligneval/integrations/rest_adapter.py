"""REST API integration adapter for AlignEval.

This module provides an adapter for evaluating external REST APIs using AlignEval
metrics. It handles HTTP requests, response parsing, and error handling for
seamless integration with any HTTP-based LLM service.
"""

import logging
from typing import Any, Dict, Optional

import httpx

from aligneval.core.test_case import LLMTestCase
from aligneval.evaluator.evaluator import AlignEvaluator, EvaluationResult

logger = logging.getLogger(__name__)


class RESTAdapter:
    """Adapter for evaluating external REST APIs.
    
    This adapter integrates AlignEval with external HTTP-based LLM services,
    allowing you to evaluate any REST API endpoint that returns text responses.
    
    Attributes:
        evaluator: The AlignEvaluator instance used for evaluation
        base_url: Base URL for the external API
        headers: HTTP headers to include in requests
        client: Async HTTP client for making requests
    
    Example:
        >>> from aligneval.integrations.rest_adapter import RESTAdapter
        >>> from aligneval.evaluator import AlignEvaluator
        >>> from aligneval.metrics import AccuracyMetric, RelevanceMetric
        >>> 
        >>> evaluator = AlignEvaluator([AccuracyMetric(), RelevanceMetric()])
        >>> adapter = RESTAdapter(
        ...     evaluator=evaluator,
        ...     base_url="https://api.example.com",
        ...     headers={"Authorization": "Bearer token123"}
        ... )
        >>> 
        >>> # Evaluate an API endpoint
        >>> import asyncio
        >>> result = asyncio.run(adapter.evaluate_endpoint(
        ...     endpoint="v1/chat/completions",
        ...     input_data={"prompt": "What is AI?"},
        ...     expected_output="Artificial Intelligence"
        ... ))
    """
    
    def __init__(
        self,
        evaluator: AlignEvaluator,
        base_url: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0
    ):
        """Initialize the REST adapter.
        
        Args:
            evaluator: AlignEvaluator instance with configured metrics
            base_url: Base URL for the external API (e.g., "https://api.example.com")
            headers: Optional HTTP headers to include in all requests
            timeout: Request timeout in seconds (default: 30.0)
        """
        self.evaluator = evaluator
        self.base_url = base_url.rstrip('/')  # Remove trailing slash
        self.headers = headers or {}
        self.timeout = timeout
        self.client = httpx.AsyncClient(timeout=timeout)
        logger.info(f"RESTAdapter initialized with base_url: {base_url}")
    
    async def evaluate_endpoint(
        self,
        endpoint: str,
        input_data: Dict[str, Any],
        expected_output: Optional[str] = None,
        method: str = "POST"
    ) -> EvaluationResult:
        """Evaluate an external API endpoint.
        
        This method calls an external REST API endpoint, extracts the response,
        and evaluates it using the configured metrics. It handles HTTP errors
        gracefully and includes error information in the evaluation result.
        
        Args:
            endpoint: API endpoint path (e.g., "v1/chat/completions")
            input_data: Input data dictionary to send to the API
            expected_output: Optional expected output for comparison
            method: HTTP method to use ("POST" or "GET", default: "POST")
        
        Returns:
            EvaluationResult containing metric scores and analysis
        
        Raises:
            ValueError: If method is not supported
        
        Example:
            >>> # POST request
            >>> result = await adapter.evaluate_endpoint(
            ...     endpoint="v1/generate",
            ...     input_data={"prompt": "Explain quantum computing", "max_tokens": 100},
            ...     expected_output="Quantum computing uses qubits...",
            ...     method="POST"
            ... )
            >>> 
            >>> # GET request
            >>> result = await adapter.evaluate_endpoint(
            ...     endpoint="v1/query",
            ...     input_data={"q": "What is AI?"},
            ...     method="GET"
            ... )
        
        Note:
            HTTP errors (4xx, 5xx) are handled gracefully. The error message
            is used as the actual_output and included in the evaluation result,
            allowing you to see how the evaluator scores error responses.
        """
        # Validate method
        if method.upper() not in ["POST", "GET"]:
            raise ValueError(f"Unsupported HTTP method: {method}. Use 'POST' or 'GET'")
        
        # Construct full URL
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        logger.info(f"Evaluating {method} {url}")
        
        try:
            # Call external API
            if method.upper() == "POST":
                response = await self.client.post(
                    url,
                    json=input_data,
                    headers=self.headers
                )
            else:  # GET
                response = await self.client.get(
                    url,
                    params=input_data,
                    headers=self.headers
                )
            
            # Raise for HTTP errors (4xx, 5xx)
            response.raise_for_status()
            
            # Parse response
            try:
                output_data = response.json()
                actual_output = self._extract_output(output_data)
            except Exception as e:
                # If JSON parsing fails, use text response
                logger.warning(f"Failed to parse JSON response: {e}, using text response")
                actual_output = response.text
            
            logger.debug(f"Extracted output: {actual_output[:100]}...")
            
            # Create test case
            test_case = LLMTestCase(
                input=str(input_data),
                actual_output=actual_output,
                expected_output=expected_output,
                additional_metadata={
                    "endpoint": endpoint,
                    "method": method,
                    "status_code": response.status_code,
                    "response_time_ms": response.elapsed.total_seconds() * 1000
                }
            )
            
            logger.info("Evaluating test case with AlignEvaluator")
            return await self.evaluator.evaluate_async(test_case)
        
        except httpx.HTTPStatusError as e:
            # HTTP error (4xx, 5xx)
            logger.warning(f"HTTP error {e.response.status_code}: {e}")
            
            # Create test case with error as output
            test_case = LLMTestCase(
                input=str(input_data),
                actual_output=f"HTTP {e.response.status_code} Error: {e.response.text}",
                expected_output=expected_output,
                additional_metadata={
                    "endpoint": endpoint,
                    "method": method,
                    "status_code": e.response.status_code,
                    "error": str(e)
                }
            )
            
            # Evaluate the error response
            result = await self.evaluator.evaluate_async(test_case)
            
            # Add error information to result
            # Note: We can't modify the result directly as it's a Pydantic model,
            # but the error is already captured in the test_case metadata
            logger.info(f"Evaluated error response with score: {result.overall_score}")
            return result
        
        except httpx.RequestError as e:
            # Network error (connection failed, timeout, etc.)
            logger.error(f"Request error: {e}", exc_info=True)
            
            # Create test case with error as output
            test_case = LLMTestCase(
                input=str(input_data),
                actual_output=f"Request Error: {str(e)}",
                expected_output=expected_output,
                additional_metadata={
                    "endpoint": endpoint,
                    "method": method,
                    "error": str(e),
                    "error_type": type(e).__name__
                }
            )
            
            # Evaluate the error response
            result = await self.evaluator.evaluate_async(test_case)
            logger.info(f"Evaluated network error with score: {result.overall_score}")
            return result
        
        except Exception as e:
            # Unexpected error
            logger.error(f"Unexpected error evaluating endpoint: {e}", exc_info=True)
            raise ValueError(
                f"Failed to evaluate REST endpoint: {str(e)}\n"
                f"URL: {url}\n"
                f"Method: {method}"
            )
    
    def _extract_output(self, response_data: Dict[str, Any]) -> str:
        """Extract output from API response.
        
        This method attempts to extract the text output from an API response
        by trying common response key patterns. If no standard key is found,
        it returns the full response as a string.
        
        Args:
            response_data: Parsed JSON response from the API
        
        Returns:
            Extracted output text
        
        Note:
            The method tries the following keys in order:
            - output
            - response
            - text
            - result
            - answer
            - content
            - message
            
            If none are found, it returns the full response as a string.
        """
        # Try common response keys
        common_keys = [
            'output', 'response', 'text', 'result', 
            'answer', 'content', 'message'
        ]
        
        for key in common_keys:
            if key in response_data:
                value = response_data[key]
                logger.debug(f"Extracted output from key '{key}'")
                
                # Handle nested structures (e.g., {"message": {"content": "..."}})
                if isinstance(value, dict):
                    # Try to extract from nested structure
                    for nested_key in common_keys:
                        if nested_key in value:
                            return str(value[nested_key])
                    # If no nested key found, stringify the dict
                    return str(value)
                
                return str(value)
        
        # Fallback to full response
        logger.debug("No standard output key found, using full response")
        return str(response_data)
    
    async def close(self):
        """Close the HTTP client.
        
        This method should be called when you're done using the adapter to
        properly close the HTTP client and release resources.
        
        Example:
            >>> adapter = RESTAdapter(evaluator, "https://api.example.com")
            >>> try:
            ...     result = await adapter.evaluate_endpoint(...)
            ... finally:
            ...     await adapter.close()
        """
        await self.client.aclose()
        logger.info("RESTAdapter HTTP client closed")
    
    async def __aenter__(self):
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
