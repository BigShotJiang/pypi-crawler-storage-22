"""Evaluation metrics for LLM and RAG systems."""

from typing import Optional, List
from aligneval.metrics.base import MetricResult, BaseMetric
from aligneval.metrics.accuracy import AccuracyMetric
from aligneval.metrics.helpfulness import HelpfulnessMetric
from aligneval.metrics.relevance import RelevanceMetric
from aligneval.metrics.clarity import ClarityMetric
from aligneval.metrics.safety import SafetyMetric
from aligneval.metrics.faithfulness import FaithfulnessMetric
from aligneval.metrics.answer_relevancy import AnswerRelevancyMetric
from aligneval.metrics.context_precision import ContextPrecisionMetric
from aligneval.metrics.context_recall import ContextRecallMetric
from aligneval.metrics.groundedness import GroundednessMetric

# Lazy-loaded registry cache
_metrics_cache: Optional[List[BaseMetric]] = None


def _get_all_metrics() -> List[BaseMetric]:
    """Get all available metrics (lazy-loaded).
    
    Returns:
        List of all metric instances
    """
    global _metrics_cache
    
    if _metrics_cache is None:
        _metrics_cache = [
            AccuracyMetric(),
            HelpfulnessMetric(),
            RelevanceMetric(),
            ClarityMetric(),
            SafetyMetric(),
            FaithfulnessMetric(),
            AnswerRelevancyMetric(),
            ContextPrecisionMetric(),
            ContextRecallMetric(),
            GroundednessMetric(),
        ]
    
    return _metrics_cache


# Registry of all available metrics (lazy-loaded property)
@property
def ALL_METRICS() -> List[BaseMetric]:
    """Registry of all available metrics."""
    return _get_all_metrics()


# For direct access without property decorator
def get_all_metrics() -> List[BaseMetric]:
    """Get all available metrics.
    
    Returns:
        List of all metric instances
        
    Example:
        >>> metrics = get_all_metrics()
        >>> print(len(metrics))  # 10
    """
    return _get_all_metrics()


def get_metric_by_name(name: str) -> Optional[BaseMetric]:
    """Get a metric instance by name.
    
    Args:
        name: The name of the metric to retrieve (case-insensitive)
        
    Returns:
        The metric instance if found, None otherwise
        
    Example:
        >>> accuracy = get_metric_by_name("Accuracy")
        >>> faithfulness = get_metric_by_name("faithfulness")
    """
    for metric in _get_all_metrics():
        if metric.name.lower() == name.lower():
            return metric
    return None


__all__ = [
    "MetricResult",
    "BaseMetric",
    "AccuracyMetric",
    "HelpfulnessMetric",
    "RelevanceMetric",
    "ClarityMetric",
    "SafetyMetric",
    "FaithfulnessMetric",
    "AnswerRelevancyMetric",
    "ContextPrecisionMetric",
    "ContextRecallMetric",
    "GroundednessMetric",
    "get_all_metrics",
    "get_metric_by_name",
]
