"""Accuracy metric for evaluating factual correctness of LLM responses."""

from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.core.test_case import LLMTestCase


class AccuracyMetric(BaseMetric):
    """Evaluates factual correctness of the response.
    
    This metric assesses whether the LLM's response is factually accurate by comparing
    it against the input query and optional expected output. The judge LLM uses
    Chain-of-Thought reasoning to analyze factual claims and determine accuracy.
    
    Scoring scale:
    - 1: Completely inaccurate, contains major factual errors
    - 2: Mostly inaccurate, contains several factual errors
    - 3: Partially accurate, contains some factual errors
    - 4: Mostly accurate, minor factual issues
    - 5: Completely accurate, no factual errors
    """
    
    def __init__(self):
        """Initialize the Accuracy metric."""
        super().__init__(
            name="Accuracy",
            description="Evaluates whether the response is factually correct"
        )
    
    def _build_prompt(self, test_case: LLMTestCase) -> str:
        """Build the evaluation prompt for the judge LLM.
        
        The prompt includes the input query, actual response, and optionally the
        expected response. It instructs the judge to use Chain-of-Thought reasoning
        to evaluate factual accuracy on a 1-5 scale.
        
        Args:
            test_case: The test case containing input, actual_output, and optional expected_output
            
        Returns:
            str: The formatted prompt for the judge LLM
        """
        prompt = f"""You are an expert evaluator assessing the factual accuracy of an LLM response.

Input Query: {test_case.input}
Actual Response: {test_case.actual_output}
"""
        
        # Include expected output if available
        if test_case.expected_output:
            prompt += f"Expected Response: {test_case.expected_output}\n"
        
        prompt += """
Evaluate the factual accuracy of the actual response on a scale of 1-5:
1 = Completely inaccurate, contains major factual errors
2 = Mostly inaccurate, contains several factual errors
3 = Partially accurate, contains some factual errors
4 = Mostly accurate, minor factual issues
5 = Completely accurate, no factual errors

Think step-by-step about the factual claims in the response and whether they are correct.

Return your evaluation as JSON:
{
    "reasoning": "Your step-by-step analysis",
    "score": <1-5>
}"""
        
        return prompt
    
    def evaluate(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case synchronously.
        
        This method builds the evaluation prompt, calls the judge LLM, and returns
        a MetricResult with the score and reasoning. If an error occurs, it returns
        a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = self._call_judge_llm(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case asynchronously.
        
        This method builds the evaluation prompt, calls the judge LLM asynchronously,
        and returns a MetricResult with the score and reasoning. If an error occurs,
        it returns a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = await self._call_judge_llm_async(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
