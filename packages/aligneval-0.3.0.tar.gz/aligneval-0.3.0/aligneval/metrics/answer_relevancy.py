"""Answer Relevancy metric for evaluating RAG response relevance to query."""

from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.core.test_case import LLMTestCase


class AnswerRelevancyMetric(BaseMetric):
    """Evaluates whether the response addresses the input query.
    
    This metric assesses whether the LLM's response is relevant to and directly
    addresses the user's query. It focuses on whether the response answers what
    was asked, regardless of whether it uses the retrieval context.
    
    Scoring scale:
    - 1: Completely irrelevant, does not address the query at all
    - 2: Mostly irrelevant, addresses query tangentially
    - 3: Partially relevant, addresses some aspects of the query
    - 4: Mostly relevant, addresses the query with minor gaps
    - 5: Completely relevant, directly and fully addresses the query
    """
    
    def __init__(self):
        """Initialize the Answer Relevancy metric."""
        super().__init__(
            name="Answer Relevancy",
            description="Evaluates whether the response addresses the input query"
        )
    
    def _build_prompt(self, test_case: LLMTestCase) -> str:
        """Build the evaluation prompt for the judge LLM.
        
        The prompt includes the input query, retrieved context, and generated response.
        It instructs the judge to use Chain-of-Thought reasoning to evaluate answer
        relevancy on a 1-5 scale.
        
        Args:
            test_case: The test case containing input, actual_output, and retrieval_context
            
        Returns:
            str: The formatted prompt for the judge LLM
            
        Raises:
            ValueError: If retrieval_context is missing
        """
        if not test_case.retrieval_context:
            raise ValueError("Answer Relevancy metric requires retrieval_context")
        
        context_str = "\n".join(test_case.retrieval_context)
        
        prompt = f"""You are an expert evaluator assessing the relevancy of a RAG system response.

Input Query: {test_case.input}
Retrieved Context:
{context_str}

Generated Response: {test_case.actual_output}

Evaluate how relevant the response is to the input query on a scale of 1-5:
1 = Completely irrelevant, does not address the query at all
2 = Mostly irrelevant, addresses query tangentially
3 = Partially relevant, addresses some aspects of the query
4 = Mostly relevant, addresses the query with minor gaps
5 = Completely relevant, directly and fully addresses the query

Think step-by-step:
1. Identify what the user is asking for in the query
2. Check if the response addresses those needs
3. Assess the overall relevancy

Return your evaluation as JSON:
{{
    "reasoning": "Your step-by-step analysis",
    "score": <1-5>
}}"""
        
        return prompt
    
    def evaluate(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case synchronously.
        
        This method builds the evaluation prompt, calls the judge LLM, and returns
        a MetricResult with the score and reasoning. If an error occurs, it returns
        a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = self._call_judge_llm(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case asynchronously.
        
        This method builds the evaluation prompt, calls the judge LLM asynchronously,
        and returns a MetricResult with the score and reasoning. If an error occurs,
        it returns a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = await self._call_judge_llm_async(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
