"""Base metric architecture for AlignEval."""

from typing import Dict, Any, Optional
from pydantic import BaseModel, Field, field_validator


class MetricResult(BaseModel):
    """Result of a metric evaluation.
    
    This model represents the outcome of evaluating a test case against a specific metric.
    It includes both raw scores (1-5) and normalized scores (0.0-1.0), along with reasoning
    and optional metadata.
    """
    
    metric_name: str = Field(..., description="Name of the metric that produced this result")
    raw_score: int = Field(..., ge=1, le=5, description="Score from 1-5")
    normalized_score: float = Field(..., ge=0.0, le=1.0, description="Score from 0.0-1.0")
    reasoning: str = Field(..., description="Chain-of-thought reasoning from the judge LLM")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    error: Optional[str] = Field(None, description="Error message if evaluation failed")
    
    @field_validator('raw_score')
    @classmethod
    def validate_raw_score(cls, v: int) -> int:
        """Validate that raw_score is in the range 1-5."""
        if not 1 <= v <= 5:
            raise ValueError(f"raw_score must be between 1 and 5, got {v}")
        return v
    
    @field_validator('normalized_score')
    @classmethod
    def validate_normalized_score(cls, v: float) -> float:
        """Validate that normalized_score is in the range 0.0-1.0."""
        if not 0.0 <= v <= 1.0:
            raise ValueError(f"normalized_score must be between 0.0 and 1.0, got {v}")
        return v
    
    @classmethod
    def from_raw_score(
        cls,
        metric_name: str,
        raw_score: int,
        reasoning: str,
        metadata: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
        **kwargs
    ) -> "MetricResult":
        """Create a MetricResult from a raw score, auto-calculating normalized score.
        
        The normalization formula is: (raw_score - 1) / 4.0
        This maps the 1-5 scale to 0.0-1.0:
        - 1 -> 0.0
        - 2 -> 0.25
        - 3 -> 0.5
        - 4 -> 0.75
        - 5 -> 1.0
        
        Args:
            metric_name: Name of the metric
            raw_score: Integer score from 1-5
            reasoning: Chain-of-thought reasoning from the judge
            metadata: Optional additional metadata
            error: Optional error message
            **kwargs: Additional fields to pass to the constructor
            
        Returns:
            MetricResult instance with calculated normalized_score
        """
        normalized_score = (raw_score - 1) / 4.0
        
        return cls(
            metric_name=metric_name,
            raw_score=raw_score,
            normalized_score=normalized_score,
            reasoning=reasoning,
            metadata=metadata or {},
            error=error,
            **kwargs
        )


from abc import ABC, abstractmethod
import json
import logging
import time
import asyncio
import random
from typing import List, Tuple
from openai import OpenAI, AsyncOpenAI

from aligneval.core.test_case import LLMTestCase
from aligneval.core.config import get_settings

logger = logging.getLogger(__name__)


class BaseMetric(ABC):
    """Abstract base class for all evaluation metrics.
    
    This class defines the interface that all metrics must implement. It provides
    common functionality for calling the judge LLM with retry logic and exponential
    backoff, while requiring subclasses to implement metric-specific prompt building
    and evaluation logic.
    
    Attributes:
        name: The name of the metric
        description: A description of what the metric evaluates
        client: Synchronous OpenAI client for API calls
    """
    
    def __init__(self, name: str, description: str):
        """Initialize the metric with a name and description.
        
        Args:
            name: The name of the metric (e.g., "Accuracy", "Faithfulness")
            description: A description of what the metric evaluates
        """
        self.name = name
        self.description = description
        self.client = self._initialize_client()
    
    def _initialize_client(self) -> OpenAI:
        """Initialize the OpenAI client for synchronous API calls.
        
        Returns:
            OpenAI: Configured OpenAI client instance
        """
        settings = get_settings()
        return OpenAI(api_key=settings.openai_api_key)
    def _randomize_outputs(self, outputs: List[str]) -> Tuple[List[str], List[int]]:
        """Randomize the order of multiple candidate outputs for position bias mitigation.

        This method shuffles the order of outputs to prevent position bias in the judge LLM's
        evaluation. It returns both the shuffled outputs and a mapping to restore the original
        order.

        Args:
            outputs: List of candidate outputs to randomize

        Returns:
            Tuple containing:
                - List of shuffled outputs
                - List of original indices (mapping from shuffled position to original position)
        """
        settings = get_settings()

        # If position bias mitigation is disabled, return outputs unchanged
        if not settings.enable_position_bias_mitigation:
            return outputs, list(range(len(outputs)))

        # Create list of (output, original_index) pairs
        indexed_outputs = list(enumerate(outputs))

        # Shuffle the pairs
        random.shuffle(indexed_outputs)

        # Separate shuffled outputs and their original indices
        shuffled_outputs = [output for _, output in indexed_outputs]
        original_indices = [idx for idx, _ in indexed_outputs]

        logger.debug(f"Randomized {len(outputs)} outputs for position bias mitigation")
        logger.debug(f"Original indices mapping: {original_indices}")

        return shuffled_outputs, original_indices

    def _map_scores_to_original_positions(
        self,
        scores: List[int],
        original_indices: List[int]
    ) -> List[int]:
        """Map scores from randomized positions back to original positions.

        After evaluating randomized outputs, this method maps the scores back to
        correspond with the original output order.

        Args:
            scores: List of scores in randomized order
            original_indices: Mapping from shuffled position to original position

        Returns:
            List of scores in original order
        """
        # Create a list to hold scores in original order
        original_scores = [0] * len(scores)

        # Map each score back to its original position
        for shuffled_pos, original_pos in enumerate(original_indices):
            original_scores[original_pos] = scores[shuffled_pos]

        logger.debug(f"Mapped scores back to original positions")

        return original_scores

    def _add_position_bias_note(self, reasoning: str, was_randomized: bool) -> str:
        """Add a note about position bias mitigation to the reasoning.

        This documents whether position bias mitigation was applied during evaluation.

        Args:
            reasoning: Original reasoning from the judge LLM
            was_randomized: Whether outputs were randomized

        Returns:
            Updated reasoning with position bias mitigation note
        """
        settings = get_settings()

        if not settings.enable_position_bias_mitigation:
            note = "\n\n[Position Bias Mitigation: Disabled]"
        elif was_randomized:
            note = "\n\n[Position Bias Mitigation: Outputs were randomized to prevent position bias. Scores have been mapped back to original positions.]"
        else:
            note = "\n\n[Position Bias Mitigation: Enabled, but only one output was evaluated.]"

        return reasoning + note
    
    @abstractmethod
    def _build_prompt(self, test_case: LLMTestCase) -> str:
        """Build the evaluation prompt for the judge LLM.
        
        This method must be implemented by subclasses to create metric-specific
        prompts that instruct the judge LLM on how to evaluate the test case.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            str: The formatted prompt for the judge LLM
        """
        pass
    
    @abstractmethod
    def evaluate(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case synchronously.
        
        This method must be implemented by subclasses to perform the actual
        evaluation logic, typically by building a prompt and calling the judge LLM.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores and reasoning
        """
        pass
    
    @abstractmethod
    async def evaluate_async(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case asynchronously.
        
        This method must be implemented by subclasses to perform asynchronous
        evaluation, enabling concurrent processing of multiple test cases.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores and reasoning
        """
        pass
    
    def _call_judge_llm(self, prompt: str) -> Dict[str, Any]:
        """Call the judge LLM with retry logic and exponential backoff.
        
        This method handles API calls to the judge LLM with automatic retry logic.
        If a call fails, it will retry up to max_retries times with exponential
        backoff between attempts.
        
        Args:
            prompt: The prompt to send to the judge LLM
            
        Returns:
            Dict[str, Any]: Parsed JSON response from the judge LLM
            
        Raises:
            Exception: If all retry attempts fail, the last exception is raised
        """
        settings = get_settings()
        
        logger.debug(f"Calling judge LLM for metric: {self.name}")
        
        for attempt in range(settings.max_retries):
            try:
                logger.debug(f"Attempt {attempt + 1}/{settings.max_retries} for {self.name}")
                
                response = self.client.chat.completions.create(
                    model=settings.judge_model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=settings.temperature,
                    max_tokens=settings.max_tokens,
                    timeout=settings.timeout,
                    response_format={"type": "json_object"}
                )
                
                # Parse and return the JSON response
                content = response.choices[0].message.content
                if content is None:
                    raise ValueError("Judge LLM returned empty response")
                
                result = json.loads(content)
                logger.info(f"Successfully evaluated {self.name} metric")
                return result
                
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse JSON response for {self.name}: {e}")
                if attempt == settings.max_retries - 1:
                    raise
                
            except Exception as e:
                logger.warning(f"API call failed for {self.name} (attempt {attempt + 1}): {e}")
                # If this is the last attempt, raise the exception
                if attempt == settings.max_retries - 1:
                    logger.error(f"All retry attempts failed for {self.name}")
                    raise
                
                # Otherwise, wait with exponential backoff and retry
                delay = settings.retry_delay * (2 ** attempt)
                logger.debug(f"Retrying in {delay}s...")
                time.sleep(delay)
    
    async def _call_judge_llm_async(self, prompt: str) -> Dict[str, Any]:
        """Call the judge LLM asynchronously with retry logic and exponential backoff.
        
        This method handles async API calls to the judge LLM with automatic retry logic.
        If a call fails, it will retry up to max_retries times with exponential
        backoff between attempts.
        
        Args:
            prompt: The prompt to send to the judge LLM
            
        Returns:
            Dict[str, Any]: Parsed JSON response from the judge LLM
            
        Raises:
            Exception: If all retry attempts fail, the last exception is raised
        """
        settings = get_settings()
        async_client = AsyncOpenAI(api_key=settings.openai_api_key)
        
        logger.debug(f"Calling judge LLM async for metric: {self.name}")
        
        for attempt in range(settings.max_retries):
            try:
                logger.debug(f"Async attempt {attempt + 1}/{settings.max_retries} for {self.name}")
                
                response = await async_client.chat.completions.create(
                    model=settings.judge_model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=settings.temperature,
                    max_tokens=settings.max_tokens,
                    timeout=settings.timeout,
                    response_format={"type": "json_object"}
                )
                
                # Parse and return the JSON response
                content = response.choices[0].message.content
                if content is None:
                    raise ValueError("Judge LLM returned empty response")
                
                result = json.loads(content)
                logger.info(f"Successfully evaluated {self.name} metric (async)")
                return result
                
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse JSON response for {self.name} (async): {e}")
                if attempt == settings.max_retries - 1:
                    raise
                    
            except Exception as e:
                logger.warning(f"Async API call failed for {self.name} (attempt {attempt + 1}): {e}")
                # If this is the last attempt, raise the exception
                if attempt == settings.max_retries - 1:
                    logger.error(f"All async retry attempts failed for {self.name}")
                    raise
                
                # Otherwise, wait with exponential backoff and retry
                delay = settings.retry_delay * (2 ** attempt)
                logger.debug(f"Retrying in {delay}s...")
                await asyncio.sleep(delay)
