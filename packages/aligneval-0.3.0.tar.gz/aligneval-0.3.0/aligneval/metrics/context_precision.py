"""Context Precision metric for evaluating RAG retrieval relevance."""

from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.core.test_case import LLMTestCase


class ContextPrecisionMetric(BaseMetric):
    """Evaluates whether the retrieved context is relevant to the query.
    
    This metric assesses the precision of the retrieval component by checking
    if the retrieved context contains relevant information for answering the query.
    High precision means the retriever is not returning irrelevant documents.
    
    Scoring scale:
    - 1: Completely irrelevant context, no useful information
    - 2: Mostly irrelevant context, minimal useful information
    - 3: Partially relevant context, some useful information
    - 4: Mostly relevant context, minor irrelevant details
    - 5: Completely relevant context, all information is useful
    """
    
    def __init__(self):
        """Initialize the Context Precision metric."""
        super().__init__(
            name="Context Precision",
            description="Evaluates whether the retrieved context is relevant to the query"
        )
    
    def _build_prompt(self, test_case: LLMTestCase) -> str:
        """Build the evaluation prompt for the judge LLM.
        
        The prompt includes the input query and retrieved context. It instructs
        the judge to use Chain-of-Thought reasoning to evaluate context precision
        on a 1-5 scale.
        
        Args:
            test_case: The test case containing input and retrieval_context
            
        Returns:
            str: The formatted prompt for the judge LLM
            
        Raises:
            ValueError: If retrieval_context is missing
        """
        if not test_case.retrieval_context:
            raise ValueError("Context Precision metric requires retrieval_context")
        
        context_str = "\n".join(test_case.retrieval_context)
        
        prompt = f"""You are an expert evaluator assessing the precision of a RAG system's retrieval.

Input Query: {test_case.input}
Retrieved Context:
{context_str}

Evaluate how relevant the retrieved context is to the query on a scale of 1-5:
1 = Completely irrelevant context, no useful information
2 = Mostly irrelevant context, minimal useful information
3 = Partially relevant context, some useful information
4 = Mostly relevant context, minor irrelevant details
5 = Completely relevant context, all information is useful

Think step-by-step:
1. Identify what information is needed to answer the query
2. Check if the retrieved context contains that information
3. Assess how much of the context is relevant vs irrelevant

Return your evaluation as JSON:
{{
    "reasoning": "Your step-by-step analysis",
    "score": <1-5>
}}"""
        
        return prompt
    
    def evaluate(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case synchronously.
        
        This method builds the evaluation prompt, calls the judge LLM, and returns
        a MetricResult with the score and reasoning. If an error occurs, it returns
        a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = self._call_judge_llm(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case asynchronously.
        
        This method builds the evaluation prompt, calls the judge LLM asynchronously,
        and returns a MetricResult with the score and reasoning. If an error occurs,
        it returns a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = await self._call_judge_llm_async(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
