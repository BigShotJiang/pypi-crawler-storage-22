"""Context Recall metric for evaluating RAG retrieval completeness."""

from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.core.test_case import LLMTestCase


class ContextRecallMetric(BaseMetric):
    """Evaluates whether the retrieved context contains all necessary information.
    
    This metric assesses the recall of the retrieval component by checking if the
    retrieved context contains all the information needed to answer the query.
    High recall means the retriever is not missing important documents.
    
    Scoring scale:
    - 1: Missing all necessary information
    - 2: Missing most necessary information
    - 3: Missing some necessary information
    - 4: Contains most necessary information, minor gaps
    - 5: Contains all necessary information
    """
    
    def __init__(self):
        """Initialize the Context Recall metric."""
        super().__init__(
            name="Context Recall",
            description="Evaluates whether the retrieved context contains all necessary information"
        )
    
    def _build_prompt(self, test_case: LLMTestCase) -> str:
        """Build the evaluation prompt for the judge LLM.
        
        The prompt includes the input query, retrieved context, and optionally the
        expected output. It instructs the judge to use Chain-of-Thought reasoning
        to evaluate context recall on a 1-5 scale.
        
        Args:
            test_case: The test case containing input, retrieval_context, and optional expected_output
            
        Returns:
            str: The formatted prompt for the judge LLM
            
        Raises:
            ValueError: If retrieval_context is missing
        """
        if not test_case.retrieval_context:
            raise ValueError("Context Recall metric requires retrieval_context")
        
        context_str = "\n".join(test_case.retrieval_context)
        
        prompt = f"""You are an expert evaluator assessing the recall of a RAG system's retrieval.

Input Query: {test_case.input}
Retrieved Context:
{context_str}
"""
        
        # Include expected output if available for better evaluation
        if test_case.expected_output:
            prompt += f"Expected Answer: {test_case.expected_output}\n"
        
        prompt += """
Evaluate whether the retrieved context contains all necessary information to answer the query on a scale of 1-5:
1 = Missing all necessary information
2 = Missing most necessary information
3 = Missing some necessary information
4 = Contains most necessary information, minor gaps
5 = Contains all necessary information

Think step-by-step:
1. Identify what information is needed to fully answer the query
2. Check if the retrieved context contains each piece of information
3. Assess the completeness of the context

Return your evaluation as JSON:
{{
    "reasoning": "Your step-by-step analysis",
    "score": <1-5>
}}"""
        
        return prompt
    
    def evaluate(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case synchronously.
        
        This method builds the evaluation prompt, calls the judge LLM, and returns
        a MetricResult with the score and reasoning. If an error occurs, it returns
        a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = self._call_judge_llm(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case asynchronously.
        
        This method builds the evaluation prompt, calls the judge LLM asynchronously,
        and returns a MetricResult with the score and reasoning. If an error occurs,
        it returns a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = await self._call_judge_llm_async(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
