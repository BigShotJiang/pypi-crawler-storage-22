"""Faithfulness metric for evaluating RAG response grounding in retrieval context."""

from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.core.test_case import LLMTestCase


class FaithfulnessMetric(BaseMetric):
    """Evaluates whether the response is grounded in the retrieval context.
    
    This metric assesses whether the LLM's response is faithful to the retrieved context
    by checking if all factual claims in the response are supported by the context.
    This is a critical RAG metric for detecting hallucinations.
    
    Scoring scale:
    - 1: Completely unfaithful, contradicts or ignores context
    - 2: Mostly unfaithful, significant unsupported claims
    - 3: Partially faithful, some unsupported claims
    - 4: Mostly faithful, minor unsupported details
    - 5: Completely faithful, all claims supported by context
    """
    
    def __init__(self):
        """Initialize the Faithfulness metric."""
        super().__init__(
            name="Faithfulness",
            description="Evaluates whether the response is faithful to the retrieval context"
        )
    
    def _build_prompt(self, test_case: LLMTestCase) -> str:
        """Build the evaluation prompt for the judge LLM.
        
        The prompt includes the input query, retrieved context, and generated response.
        It instructs the judge to use Chain-of-Thought reasoning to evaluate faithfulness
        on a 1-5 scale.
        
        Args:
            test_case: The test case containing input, actual_output, and retrieval_context
            
        Returns:
            str: The formatted prompt for the judge LLM
            
        Raises:
            ValueError: If retrieval_context is missing
        """
        if not test_case.retrieval_context:
            raise ValueError("Faithfulness metric requires retrieval_context")
        
        context_str = "\n".join(test_case.retrieval_context)
        
        prompt = f"""You are an expert evaluator assessing the faithfulness of a RAG system response.

Input Query: {test_case.input}
Retrieved Context:
{context_str}

Generated Response: {test_case.actual_output}

Evaluate how faithful the response is to the retrieved context on a scale of 1-5:
1 = Completely unfaithful, contradicts or ignores context
2 = Mostly unfaithful, significant unsupported claims
3 = Partially faithful, some unsupported claims
4 = Mostly faithful, minor unsupported details
5 = Completely faithful, all claims supported by context

Think step-by-step:
1. Identify all factual claims in the response
2. Check if each claim is supported by the context
3. Assess the overall faithfulness

Return your evaluation as JSON:
{{
    "reasoning": "Your step-by-step analysis",
    "score": <1-5>
}}"""
        
        return prompt
    
    def evaluate(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case synchronously.
        
        This method builds the evaluation prompt, calls the judge LLM, and returns
        a MetricResult with the score and reasoning. If an error occurs, it returns
        a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = self._call_judge_llm(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case asynchronously.
        
        This method builds the evaluation prompt, calls the judge LLM asynchronously,
        and returns a MetricResult with the score and reasoning. If an error occurs,
        it returns a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = await self._call_judge_llm_async(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
