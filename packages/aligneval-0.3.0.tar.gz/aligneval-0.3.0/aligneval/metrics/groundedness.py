"""Groundedness metric for evaluating RAG factual consistency."""

from aligneval.metrics.base import BaseMetric, MetricResult
from aligneval.core.test_case import LLMTestCase


class GroundednessMetric(BaseMetric):
    """Evaluates factual consistency with the retrieval context.
    
    This metric assesses whether the response is factually consistent with the
    retrieved context. Similar to faithfulness, but focuses specifically on
    factual consistency rather than general grounding. This helps detect when
    the model adds facts not present in the context.
    
    Scoring scale:
    - 1: Completely inconsistent, contradicts context facts
    - 2: Mostly inconsistent, significant factual deviations
    - 3: Partially consistent, some factual deviations
    - 4: Mostly consistent, minor factual deviations
    - 5: Completely consistent, all facts align with context
    """
    
    def __init__(self):
        """Initialize the Groundedness metric."""
        super().__init__(
            name="Groundedness",
            description="Evaluates factual consistency with the retrieval context"
        )
    
    def _build_prompt(self, test_case: LLMTestCase) -> str:
        """Build the evaluation prompt for the judge LLM.
        
        The prompt includes the input query, retrieved context, and generated response.
        It instructs the judge to use Chain-of-Thought reasoning to evaluate groundedness
        on a 1-5 scale.
        
        Args:
            test_case: The test case containing input, actual_output, and retrieval_context
            
        Returns:
            str: The formatted prompt for the judge LLM
            
        Raises:
            ValueError: If retrieval_context is missing
        """
        if not test_case.retrieval_context:
            raise ValueError("Groundedness metric requires retrieval_context")
        
        context_str = "\n".join(test_case.retrieval_context)
        
        prompt = f"""You are an expert evaluator assessing the groundedness of a RAG system response.

Input Query: {test_case.input}
Retrieved Context:
{context_str}

Generated Response: {test_case.actual_output}

Evaluate how grounded the response is in the retrieved context on a scale of 1-5:
1 = Completely inconsistent, contradicts context facts
2 = Mostly inconsistent, significant factual deviations
3 = Partially consistent, some factual deviations
4 = Mostly consistent, minor factual deviations
5 = Completely consistent, all facts align with context

Think step-by-step:
1. Identify all factual statements in the response
2. Check if each fact is consistent with the context
3. Look for contradictions or unsupported facts
4. Assess the overall groundedness

Return your evaluation as JSON:
{{
    "reasoning": "Your step-by-step analysis",
    "score": <1-5>
}}"""
        
        return prompt
    
    def evaluate(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case synchronously.
        
        This method builds the evaluation prompt, calls the judge LLM, and returns
        a MetricResult with the score and reasoning. If an error occurs, it returns
        a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = self._call_judge_llm(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
    
    async def evaluate_async(self, test_case: LLMTestCase) -> MetricResult:
        """Evaluate a test case asynchronously.
        
        This method builds the evaluation prompt, calls the judge LLM asynchronously,
        and returns a MetricResult with the score and reasoning. If an error occurs,
        it returns a MetricResult with error information.
        
        Args:
            test_case: The test case to evaluate
            
        Returns:
            MetricResult: The evaluation result with scores, reasoning, and optional error
        """
        try:
            prompt = self._build_prompt(test_case)
            result = await self._call_judge_llm_async(prompt)
            
            return MetricResult.from_raw_score(
                metric_name=self.name,
                raw_score=result["score"],
                reasoning=result["reasoning"]
            )
        except Exception as e:
            # Return error result with minimum score
            return MetricResult(
                metric_name=self.name,
                raw_score=1,
                normalized_score=0.0,
                reasoning="",
                error=str(e)
            )
