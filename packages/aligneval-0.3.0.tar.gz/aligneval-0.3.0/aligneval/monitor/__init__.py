"""AlignEval Monitor - Live dashboard for chatbot evaluation.

This module provides a simple decorator-based interface for monitoring
chatbot responses in real-time with a live dashboard.

Example:
    from aligneval import monitor
    
    @monitor(metrics=["Accuracy", "Helpfulness"])
    def my_chatbot(user_input: str) -> str:
        return generate_response(user_input)
    
    # Dashboard automatically opens at http://localhost:5000
"""

from aligneval.monitor.decorator import monitor, Monitor

__all__ = ["monitor", "Monitor"]
