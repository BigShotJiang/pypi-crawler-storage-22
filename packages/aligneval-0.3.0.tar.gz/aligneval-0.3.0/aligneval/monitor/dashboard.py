"""Flask dashboard for live monitoring."""
import logging
import threading
import time
from pathlib import Path

from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO

logger = logging.getLogger(__name__)


class DashboardServer:
    """Flask server for live dashboard."""
    
    def __init__(self, tracker, port: int = 5000):
        """Initialize dashboard server.
        
        Args:
            tracker: EvaluationTracker instance
            port: Port to run server on
        """
        self.tracker = tracker
        self.port = port
        self.running = False
        
        # Create Flask app
        template_dir = Path(__file__).parent / 'templates'
        self.app = Flask(__name__, template_folder=str(template_dir))
        self.app.config['SECRET_KEY'] = 'aligneval-secret-key'
        
        # Initialize SocketIO
        self.socketio = SocketIO(
            self.app,
            cors_allowed_origins="*",
            async_mode='threading'
        )
        
        # Setup routes
        self._setup_routes()
        
        # Start broadcast thread
        self.broadcast_thread = None
        
        logger.info(f"Dashboard server initialized on port {port}")
    
    def _setup_routes(self):
        """Setup Flask routes."""
        
        @self.app.route('/')
        def index():
            """Render dashboard page."""
            return render_template('dashboard.html')
        
        @self.app.route('/api/stats')
        def stats():
            """Get overall statistics."""
            return jsonify(self.tracker.get_stats())
        
        @self.app.route('/api/recent')
        def recent():
            """Get recent evaluations."""
            limit = 10
            return jsonify(self.tracker.get_recent_results(limit=limit))
        
        @self.app.route('/api/health')
        def health():
            """Health check endpoint."""
            return jsonify({'status': 'healthy'})
    
    def _broadcast_updates(self):
        """Broadcast updates to connected clients via WebSocket."""
        while self.running:
            try:
                stats = self.tracker.get_stats()
                recent = self.tracker.get_recent_results(limit=5)
                
                self.socketio.emit('update', {
                    'stats': stats,
                    'recent': recent
                })
                
                logger.debug("Broadcasted update to clients")
                
            except Exception as e:
                logger.error(f"Broadcast error: {e}", exc_info=True)
            
            time.sleep(2)  # Update every 2 seconds
    
    def run(self):
        """Run the dashboard server."""
        self.running = True
        
        # Start broadcast thread
        self.broadcast_thread = threading.Thread(
            target=self._broadcast_updates,
            daemon=True
        )
        self.broadcast_thread.start()
        
        logger.info(f"Starting dashboard server on http://0.0.0.0:{self.port}")
        
        # Run Flask app
        self.socketio.run(
            self.app,
            host='0.0.0.0',
            port=self.port,
            debug=False,
            use_reloader=False,
            log_output=False
        )
    
    def stop(self):
        """Stop the dashboard server."""
        self.running = False
        logger.info("Dashboard server stopped")
