"""Decorator for monitoring chatbot functions."""

import functools
import time
import threading
import webbrowser
from typing import Callable, List, Optional, Any
import logging

from aligneval.monitor.tracker import EvaluationTracker
from aligneval.monitor.dashboard import DashboardServer

logger = logging.getLogger(__name__)


class Monitor:
    """Monitor class for tracking chatbot evaluations with live dashboard.
    
    Example:
        monitor = Monitor(metrics=["Accuracy", "Helpfulness"])
        monitor.start_dashboard()
        
        result = monitor.track(my_chatbot, "What is AI?")
    """
    
    def __init__(
        self,
        metrics: Optional[List[str]] = None,
        dashboard_port: int = 5000,
        auto_open: bool = True,
        store_history: bool = True
    ):
        """Initialize monitor.
        
        Args:
            metrics: List of metric names to evaluate
            dashboard_port: Port for dashboard server
            auto_open: Automatically open dashboard in browser
            store_history: Store evaluation history in database
        """
        self.metrics = metrics or ["Accuracy", "Helpfulness"]
        self.dashboard_port = dashboard_port
        self.auto_open = auto_open
        self.store_history = store_history
        
        # Initialize tracker
        self.tracker = EvaluationTracker(
            metrics=self.metrics,
            store_history=self.store_history
        )
        
        # Dashboard server
        self.dashboard = None
        self.dashboard_thread = None
        
        logger.info(f"Monitor initialized with metrics: {self.metrics}")
    
    def start_dashboard(self):
        """Start the dashboard server in background thread."""
        if self.dashboard is not None:
            logger.warning("Dashboard already running")
            return
        
        self.dashboard = DashboardServer(
            tracker=self.tracker,
            port=self.dashboard_port
        )
        
        # Start in background thread
        self.dashboard_thread = threading.Thread(
            target=self.dashboard.run,
            daemon=True
        )
        self.dashboard_thread.start()
        
        # Wait a moment for server to start
        time.sleep(1)
        
        dashboard_url = f"http://localhost:{self.dashboard_port}"
        logger.info(f"Dashboard started at {dashboard_url}")
        
        # Auto-open browser
        if self.auto_open:
            try:
                webbrowser.open(dashboard_url)
                logger.info("Opened dashboard in browser")
            except Exception as e:
                logger.warning(f"Could not open browser: {e}")
    
    def stop_dashboard(self):
        """Stop the dashboard server."""
        if self.dashboard:
            self.dashboard.stop()
            self.dashboard = None
            logger.info("Dashboard stopped")
    
    def track(self, func: Callable, *args, **kwargs) -> Any:
        """Track a function call and evaluate the result.
        
        Args:
            func: Function to track
            *args: Positional arguments for function
            **kwargs: Keyword arguments for function
            
        Returns:
            Result from function
        """
        # Extract input (assume first arg is user input)
        user_input = args[0] if args else kwargs.get('input', '')
        
        # Call function
        start_time = time.time()
        result = func(*args, **kwargs)
        execution_time = time.time() - start_time
        
        # Track evaluation (async in background)
        self.tracker.track_evaluation(
            input_text=str(user_input),
            output_text=str(result),
            execution_time=execution_time
        )
        
        return result
    
    def __enter__(self):
        """Context manager entry."""
        self.start_dashboard()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop_dashboard()


def monitor(
    metrics: Optional[List[str]] = None,
    dashboard_port: int = 5000,
    auto_open: bool = True,
    store_history: bool = True
):
    """Decorator for monitoring chatbot functions with live dashboard.
    
    Args:
        metrics: List of metric names to evaluate
        dashboard_port: Port for dashboard server
        auto_open: Automatically open dashboard in browser
        store_history: Store evaluation history in database
    
    Example:
        @monitor(metrics=["Accuracy", "Helpfulness"])
        def my_chatbot(user_input: str) -> str:
            return generate_response(user_input)
    """
    # Create monitor instance
    mon = Monitor(
        metrics=metrics,
        dashboard_port=dashboard_port,
        auto_open=auto_open,
        store_history=store_history
    )
    
    # Start dashboard
    mon.start_dashboard()
    
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return mon.track(func, *args, **kwargs)
        
        # Attach monitor instance to function
        wrapper._monitor = mon
        
        return wrapper
    
    return decorator
