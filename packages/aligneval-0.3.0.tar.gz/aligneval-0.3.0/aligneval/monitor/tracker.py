"""Track evaluations in background."""
import threading
import queue
import time
import logging
from typing import List, Dict, Any
from datetime import datetime

from aligneval.evaluator.evaluator import AlignEvaluator
from aligneval.core.test_case import LLMTestCase
from aligneval.metrics import get_metric_by_name

logger = logging.getLogger(__name__)


class EvaluationTracker:
    """Track chatbot evaluations in background thread."""
    
    def __init__(self, metrics: List[str], store_history: bool = True):
        """Initialize tracker.
        
        Args:
            metrics: List of metric names to evaluate
            store_history: Whether to store evaluation history
        """
        self.metric_names = metrics
        self.store_history = store_history
        
        # Initialize evaluator
        metric_instances = [get_metric_by_name(m) for m in metrics]
        self.evaluator = AlignEvaluator(metric_instances)
        
        # Queue for async evaluation
        self.queue = queue.Queue()
        
        # Store results
        self.results: List[Dict[str, Any]] = []
        self.lock = threading.Lock()
        
        # Start background worker
        self.running = True
        self.worker = threading.Thread(target=self._process_queue, daemon=True)
        self.worker.start()
        
        logger.info(f"EvaluationTracker started with metrics: {metrics}")
    
    def track_evaluation(
        self,
        input_text: str,
        output_text: str,
        execution_time: float
    ):
        """Add evaluation to queue for async processing.
        
        Args:
            input_text: User input
            output_text: Chatbot output
            execution_time: Time taken to generate response
        """
        self.queue.put({
            'input': input_text,
            'output': output_text,
            'execution_time': execution_time,
            'timestamp': datetime.now().isoformat()
        })
        logger.debug(f"Queued evaluation for: {input_text[:50]}...")
    
    def _process_queue(self):
        """Process evaluations in background thread."""
        while self.running:
            try:
                item = self.queue.get(timeout=1)
                
                # Evaluate
                test_case = LLMTestCase(
                    input=item['input'],
                    actual_output=item['output']
                )
                
                result = self.evaluator.evaluate(test_case)
                
                # Store result
                result_data = {
                    'timestamp': item['timestamp'],
                    'input': item['input'],
                    'output': item['output'],
                    'execution_time': item['execution_time'],
                    'overall_score': result.overall_score,
                    'passed': result.passed,
                    'metrics': [
                        {
                            'name': mr.metric_name,
                            'score': mr.normalized_score,
                            'raw_score': mr.raw_score
                        }
                        for mr in result.metric_results
                    ]
                }
                
                with self.lock:
                    self.results.append(result_data)
                    
                    # Keep only last 100 results
                    if len(self.results) > 100:
                        self.results = self.results[-100:]
                
                logger.info(f"Evaluated: score={result.overall_score:.2f}")
                
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error evaluating: {e}", exc_info=True)
            finally:
                try:
                    self.queue.task_done()
                except ValueError:
                    pass
    
    def get_recent_results(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent evaluation results.
        
        Args:
            limit: Maximum number of results to return
            
        Returns:
            List of recent evaluation results
        """
        with self.lock:
            return self.results[-limit:]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get overall statistics.
        
        Returns:
            Dictionary with statistics
        """
        with self.lock:
            if not self.results:
                return {
                    'total': 0,
                    'avg_score': 0.0,
                    'pass_rate': 0.0,
                    'pending': self.queue.qsize()
                }
            
            scores = [r['overall_score'] for r in self.results]
            passed = sum(1 for r in self.results if r['passed'])
            
            return {
                'total': len(self.results),
                'avg_score': sum(scores) / len(scores),
                'pass_rate': passed / len(self.results),
                'pending': self.queue.qsize()
            }
    
    def stop(self):
        """Stop the background worker."""
        self.running = False
        logger.info("EvaluationTracker stopped")
