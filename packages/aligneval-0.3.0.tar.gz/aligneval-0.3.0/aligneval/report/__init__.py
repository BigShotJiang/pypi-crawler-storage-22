"""Report generation for evaluation results."""

from aligneval.report.generator import ReportGenerator

__all__ = ["ReportGenerator"]
