"""Report generation for evaluation results."""

from jinja2 import Environment, FileSystemLoader
import json
from pathlib import Path
from typing import List, Dict
from datetime import datetime

from aligneval.evaluator.evaluator import EvaluationResult


class ReportGenerator:
    """Generate HTML and JSON reports from evaluation results.
    
    This class provides methods to generate formatted reports from evaluation
    results, supporting both HTML (for human viewing) and JSON (for programmatic
    analysis) formats.
    
    Attributes:
        env: Jinja2 environment for template rendering
    """
    
    def __init__(self):
        """Initialize the report generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(loader=FileSystemLoader(str(template_dir)))
    
    def generate_html(
        self,
        results: List[EvaluationResult],
        output_path: str
    ) -> None:
        """Generate HTML report using Jinja2 template.
        
        Creates a formatted HTML report with summary statistics, metric averages,
        and detailed results for each test case.
        
        Args:
            results: List of evaluation results to include in report
            output_path: Path where HTML file should be saved
        """
        template = self.env.get_template("report.html")
        
        # Calculate summary statistics
        summary = {
            "total_cases": len(results),
            "passed_cases": sum(1 for r in results if r.passed),
            "average_score": sum(r.overall_score for r in results) / len(results) if results else 0.0,
            "metric_averages": self._calculate_metric_averages(results)
        }
        
        html_content = template.render(
            results=results,
            summary=summary,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        
        with open(output_path, 'w') as f:
            f.write(html_content)
    
    def generate_json(
        self,
        results: List[EvaluationResult],
        output_path: str
    ) -> None:
        """Generate JSON report for programmatic analysis.
        
        Creates a structured JSON report containing summary statistics and
        detailed results that can be easily parsed by other tools.
        
        Args:
            results: List of evaluation results to include in report
            output_path: Path where JSON file should be saved
        """
        report_data = {
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "total_cases": len(results),
                "passed_cases": sum(1 for r in results if r.passed),
                "average_score": sum(r.overall_score for r in results) / len(results) if results else 0.0,
                "metric_averages": self._calculate_metric_averages(results)
            },
            "results": [r.model_dump() for r in results]
        }
        
        with open(output_path, 'w') as f:
            json.dump(report_data, f, indent=2)
    
    def _calculate_metric_averages(
        self,
        results: List[EvaluationResult]
    ) -> Dict[str, float]:
        """Calculate average scores per metric across all results.
        
        Aggregates scores for each metric type across all evaluation results,
        computing the mean score for each metric.
        
        Args:
            results: List of evaluation results to analyze
            
        Returns:
            Dictionary mapping metric names to their average normalized scores
        """
        metric_scores: Dict[str, List[float]] = {}
        
        for result in results:
            for metric_result in result.metric_results:
                if metric_result.error:
                    continue
                
                if metric_result.metric_name not in metric_scores:
                    metric_scores[metric_result.metric_name] = []
                
                metric_scores[metric_result.metric_name].append(
                    metric_result.normalized_score
                )
        
        return {
            name: sum(scores) / len(scores)
            for name, scores in metric_scores.items()
        }
