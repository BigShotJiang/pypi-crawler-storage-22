"""Logout confirmation modal for the dashboard."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Static

from ..branding import BRANDING


class LogoutConfirmScreen(ModalScreen):
    """Modal that warns the user before logging out and exiting Aline."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=False),
        Binding("enter", "confirm", "Confirm", show=False),
    ]

    DEFAULT_CSS = """
    LogoutConfirmScreen {
        align: center middle;
    }

    LogoutConfirmScreen #logout-root {
        width: 100%;
        max-width: 60;
        height: auto;
        max-height: 80%;
        padding: 1 2;
        background: $background;
        border: solid $warning;
    }

    LogoutConfirmScreen #logout-title {
        height: auto;
        margin-bottom: 1;
    }

    LogoutConfirmScreen #logout-body {
        height: auto;
    }

    LogoutConfirmScreen #logout-body Static {
        height: auto;
        margin-bottom: 1;
    }

    LogoutConfirmScreen #logout-actions {
        height: auto;
        margin-top: 1;
        align: right middle;
    }

    LogoutConfirmScreen #logout-actions Button {
        width: auto;
        min-width: 0;
        margin-left: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Container(id="logout-root"):
            yield Static("[bold]Logout[/bold]", id="logout-title")
            with Vertical(id="logout-body"):
                yield Static(
                    f"Logging out will close {BRANDING.dashboard_label}.\n\n"
                    "Your tmux sessions will [bold]not[/bold] be affected — "
                    "all running processes inside tmux will continue as normal."
                )
            with Horizontal(id="logout-actions"):
                yield Button("Cancel", id="cancel")
                yield Button("Logout & Exit", id="confirm", variant="warning")

    def on_mount(self) -> None:
        self.query_one("#confirm", Button).focus()

    def action_close(self) -> None:
        self.dismiss(False)

    def action_confirm(self) -> None:
        self.dismiss(True)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel":
            self.dismiss(False)
            return
        if event.button.id == "confirm":
            self.dismiss(True)
            return
