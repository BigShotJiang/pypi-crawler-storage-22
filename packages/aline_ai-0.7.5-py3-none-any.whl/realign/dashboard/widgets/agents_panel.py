"""Agents Panel Widget - Lists agent profiles with their terminals."""

from __future__ import annotations

import asyncio
import json as _json
import re
import shlex
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from textual import events
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Button, Rule, Static
from textual.message import Message
from textual.worker import Worker, WorkerState
from rich.text import Text

from .. import tmux_manager
from ...logging_config import setup_logger
from ..clipboard import copy_text

logger = setup_logger("realign.dashboard.widgets.agents_panel", "dashboard.log")


@dataclass(frozen=True)
class _ProcessSnapshot:
    created_at_monotonic: float
    tty_key: str
    children: dict[int, list[int]]
    comms: dict[int, str]


class TruncButton(Button):
    """Button that truncates its label with '...' based on actual widget width."""

    def __init__(self, full_text: str, **kwargs) -> None:
        super().__init__(full_text, **kwargs)
        self._full_text = full_text

    def render(self) -> Text:
        width = self.size.width
        gutter = self.styles.gutter
        avail = width - gutter.width
        text = self._full_text
        if avail > 3 and len(text) > avail:
            return Text(text[: avail - 3] + "...")
        return Text(text)

class SpinnerPrefixButton(Button):
    """Button label with an animated spinner prefix, truncated to widget width."""

    _FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")

    def __init__(self, *, prefix: str, label: str, **kwargs) -> None:
        self._prefix = prefix
        self._label = label
        super().__init__(f"{prefix}{label}", **kwargs)

    def render(self) -> Text:
        width = self.size.width
        gutter = self.styles.gutter
        avail = width - gutter.width

        idx = int(time.monotonic() * 8) % len(self._FRAMES)
        spinner = self._FRAMES[idx]
        text = f"{self._prefix}{spinner} {self._label}"

        if avail > 3 and len(text) > avail:
            return Text(text[: avail - 3] + "...")
        return Text(text)


class AgentNameButton(Button):
    """Button that emits a message on double-click."""

    class DoubleClicked(Message, bubble=True):
        def __init__(self, button: "AgentNameButton", agent_id: str) -> None:
            super().__init__()
            self.button = button
            self.agent_id = agent_id

    async def _on_click(self, event: events.Click) -> None:
        await super()._on_click(event)
        if event.chain >= 2:
            self.post_message(self.DoubleClicked(self, self.name or ""))


class _TerminalRowWidget(Horizontal):
    def __init__(
        self,
        *,
        terminal_id: str,
        term_safe_id: str,
        prefix: str,
        title: str,
        running_agent: str | None,
        pane_current_command: str | None,
        is_active: bool,
    ) -> None:
        super().__init__(classes="terminal-row")

        switch_classes = "terminal-switch active-terminal" if is_active else "terminal-switch"

        pane_cmd = (pane_current_command or "").strip().lower()
        title_is_relevant = bool(title) and (
            bool(running_agent) or pane_cmd in {"claude", "codex", "opencode"}
        )

        if title_is_relevant:
            label = f"{prefix}{title}"
            switch_btn: Button = TruncButton(
                label,
                id=f"switch-{term_safe_id}",
                name=terminal_id,
                classes=switch_classes,
            )
            switch_btn.tooltip = title
        elif running_agent:
            provider = (running_agent or "").strip().lower()
            provider_label = (running_agent or "").strip().capitalize()
            if provider in {"codex", "claude"}:
                switch_btn = SpinnerPrefixButton(
                    prefix=prefix,
                    label=provider_label,
                    id=f"switch-{term_safe_id}",
                    name=terminal_id,
                    classes=f"{switch_classes} spinner",
                )
            else:
                switch_btn = TruncButton(
                    f"{prefix}{provider_label}",
                    id=f"switch-{term_safe_id}",
                    name=terminal_id,
                    classes=switch_classes,
                )
        else:
            display = (pane_current_command or "").strip() or "Terminal"
            switch_btn = TruncButton(
                f"{prefix}{display}",
                id=f"switch-{term_safe_id}",
                name=terminal_id,
                classes=switch_classes,
            )

        self._switch_btn = switch_btn
        self._close_btn = Button(
            "✕",
            id=f"close-{term_safe_id}",
            name=terminal_id,
            variant="error",
            classes="terminal-close",
        )

    def compose(self) -> ComposeResult:
        yield self._switch_btn
        yield self._close_btn


class _TerminalConnectorWidget(Horizontal):
    def __init__(self) -> None:
        super().__init__(classes="terminal-row")

    def compose(self) -> ComposeResult:
        yield Button("│", classes="terminal-switch")


class _AgentBlockWidget(Container):
    def __init__(self, *, agent: dict, active_terminal_id: str | None) -> None:
        super().__init__(classes="agent-block")
        self._agent = agent
        self._active_terminal_id = active_terminal_id

    def compose(self) -> ComposeResult:
        agent = self._agent
        safe_id = AgentsPanel._safe_id(agent["id"])

        rule = Rule(line_style="solid")
        rule.styles.color = "black"
        yield rule

        with Horizontal(classes="agent-row"):
            name_label = Text(f"▸ {agent['name']}", style="bold")
            agent_btn = AgentNameButton(
                name_label,
                id=f"agent-{safe_id}",
                name=agent["id"],
                classes="agent-name",
            )
            if agent.get("description"):
                agent_btn.tooltip = agent["description"]
            yield agent_btn

            if agent.get("share_url"):
                yield Button(
                    "Sync",
                    id=f"sync-{safe_id}",
                    name=agent["id"],
                    classes="agent-share",
                )
                yield Button(
                    "Link",
                    id=f"link-{safe_id}",
                    name=agent["id"],
                    classes="agent-share",
                )
            else:
                yield Button(
                    "Share",
                    id=f"share-{safe_id}",
                    name=agent["id"],
                    classes="agent-share",
                )

            yield Button(
                "+",
                id=f"create-term-{safe_id}",
                name=agent["id"],
                classes="agent-create",
            )
            yield Button(
                "✕",
                id=f"delete-{safe_id}",
                name=agent["id"],
                variant="error",
                classes="agent-delete",
            )

        terminals = agent.get("terminals") or []
        if not terminals:
            return

        with Vertical(classes="terminal-list"):
            for term_idx, term in enumerate(terminals):
                is_last_term = term_idx == len(terminals) - 1
                prefix = "└ " if is_last_term else "├ "

                terminal_id = term["terminal_id"]
                term_safe_id = AgentsPanel._safe_id(terminal_id)
                is_active = terminal_id == self._active_terminal_id

                yield _TerminalRowWidget(
                    terminal_id=terminal_id,
                    term_safe_id=term_safe_id,
                    prefix=prefix,
                    title=term.get("title", "") or "",
                    running_agent=term.get("running_agent"),
                    pane_current_command=term.get("pane_current_command"),
                    is_active=is_active,
                )
                if not is_last_term:
                    yield _TerminalConnectorWidget()


class AgentsPanel(Container, can_focus=True):
    """Panel displaying agent profiles with their associated terminals."""

    REFRESH_INTERVAL_SECONDS = 2.0
    SPINNER_INTERVAL_SECONDS = 0.15

    DEFAULT_CSS = """
    AgentsPanel {
        height: 100%;
        padding: 0 1;
        overflow: hidden;
    }

    AgentsPanel:focus {
        border: none;
    }

    AgentsPanel .summary {
        height: auto;
        margin: 0;
        padding: 0;
        background: transparent;
        border: none;
        align: right middle;
    }

    AgentsPanel Button {
        min-width: 0;
        padding: 0 1;
        background: transparent;
        border: none;
    }

    AgentsPanel Button:hover {
        background: $surface-lighten-1;
    }

    AgentsPanel .summary Button {
        width: auto;
        margin-right: 1;
    }

    AgentsPanel .list {
        height: 1fr;
        padding: 0;
        overflow-y: auto;
        border: none;
        background: transparent;
    }

    AgentsPanel Rule {
        margin: 0;
    }

    AgentsPanel .agent-row {
        height: 2;
        margin: 0;
    }

    AgentsPanel .agent-block {
        height: auto;
    }

    AgentsPanel .agent-row Button.agent-name {
        width: 1fr;
        height: 1;
        margin: 0;
        padding: 0 1;
        text-align: left;
        content-align: left middle;
    }

    AgentsPanel .agent-row Button.agent-create {
        width: 3;
        min-width: 3;
        height: 1;
        margin-left: 0;
        padding: 0;
        content-align: center middle;
    }

    AgentsPanel .agent-row Button.agent-delete {
        width: 3;
        min-width: 3;
        height: 1;
        margin-left: 0;
        padding: 0;
        content-align: center middle;
    }

    AgentsPanel .agent-row Button.agent-share {
        width: auto;
        min-width: 6;
        height: 1;
        margin-left: 0;
        padding: 0 1;
        content-align: center middle;
    }

    AgentsPanel .terminal-list {
        margin: 0 0 1 2;
        padding: 0;
        height: auto;
        background: transparent;
        border: none;
    }

    AgentsPanel .terminal-row {
        height: 1;
        margin: 0;
    }

    AgentsPanel .terminal-row Button.terminal-switch {
        width: 1fr;
        height: 1;
        margin: 0;
        padding: 0 1;
        text-align: left;
        content-align: left middle;
        text-opacity: 60%;
    }

    AgentsPanel .terminal-row Button.terminal-switch:hover {
        text-opacity: 100%;
    }

    AgentsPanel .terminal-row Button.active-terminal {
        text-opacity: 100%;
        text-style: bold;
    }

    AgentsPanel .terminal-row Button.terminal-close {
        width: 3;
        min-width: 3;
        height: 1;
        margin: 0;
        padding: 0;
        content-align: center middle;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._refresh_lock = asyncio.Lock()
        self._agents: list[dict] = []
        self._active_terminal_id: str | None = None
        self._rendered_fingerprint: str = ""
        self._switch_worker: Optional[Worker] = None
        self._switch_seq: int = 0
        self._refresh_worker: Optional[Worker] = None
        self._render_worker: Optional[Worker] = None
        self._pending_render: bool = False
        self._pending_render_reason: str | None = None
        self._share_worker: Optional[Worker] = None
        self._sync_worker: Optional[Worker] = None
        self._share_agent_id: Optional[str] = None
        self._sync_agent_id: Optional[str] = None
        self._refresh_timer = None
        self._spinner_timer = None
        self._last_refresh_error_at: float | None = None
        self._last_render_started_at: float | None = None
        self._last_render_completed_at: float | None = None
        self._process_snapshot: _ProcessSnapshot | None = None

    def compose(self) -> ComposeResult:
        with Horizontal(classes="summary"):
            yield Button("Add Agent", id="create-agent", variant="primary")
        with Vertical(id="agents-list", classes="list"):
            yield Static("No agents yet. Click 'Add Agent' to add one.")

    def on_mount(self) -> None:
        btn = self.query_one("#create-agent", Button)
        btn.styles.border = ("round", "black")
        btn.styles.text_align = "center"
        btn.styles.content_align = ("center", "middle")

    def on_show(self) -> None:
        if self._refresh_timer is None:
            # Refresh frequently, but avoid hammering SQLite/tmux (can cause transient empty UI).
            self._refresh_timer = self.set_interval(
                self.REFRESH_INTERVAL_SECONDS, self._on_refresh_timer
            )
        else:
            try:
                self._refresh_timer.resume()
            except Exception:
                pass

        if self._spinner_timer is None:
            self._spinner_timer = self.set_interval(
                self.SPINNER_INTERVAL_SECONDS, self._on_spinner_timer
            )
        else:
            try:
                self._spinner_timer.resume()
            except Exception:
                pass
        self.refresh_data()

    def on_hide(self) -> None:
        if self._refresh_timer is not None:
            try:
                self._refresh_timer.pause()
            except Exception:
                pass
        if self._spinner_timer is not None:
            try:
                self._spinner_timer.pause()
            except Exception:
                pass

    def _on_refresh_timer(self) -> None:
        self.refresh_data()

    def _on_spinner_timer(self) -> None:
        if not self.display:
            return
        try:
            for btn in self.query("Button.spinner"):
                btn.refresh()
        except Exception:
            pass

    def refresh_data(self) -> None:
        if not self.display:
            return
        if self._refresh_worker is not None and self._refresh_worker.state in (
            WorkerState.PENDING,
            WorkerState.RUNNING,
        ):
            return
        self._refresh_worker = self.run_worker(
            self._collect_agents, thread=True, exit_on_error=False
        )

    def diagnostics_state(self) -> dict[str, object]:
        """Small, safe snapshot for watchdog logging (never raises)."""
        state: dict[str, object] = {}
        try:
            state["agents_count"] = int(len(self._agents))
            state["rendered_fingerprint_len"] = int(len(self._rendered_fingerprint))
            state["refresh_worker_state"] = str(
                getattr(getattr(self, "_refresh_worker", None), "state", None)
            )
            state["render_worker_state"] = str(
                getattr(getattr(self, "_render_worker", None), "state", None)
            )
            state["pending_render"] = bool(self._pending_render)
            state["last_refresh_error_at"] = self._last_refresh_error_at
            state["last_render_started_at"] = self._last_render_started_at
            state["last_render_completed_at"] = self._last_render_completed_at
        except Exception:
            pass
        try:
            container = self.query_one("#agents-list", Vertical)
            state["agents_list_children"] = int(len(getattr(container, "children", []) or []))
        except Exception:
            pass
        return state

    def _ui_blank(self) -> bool:
        try:
            container = self.query_one("#agents-list", Vertical)
            return len(container.children) == 0
        except Exception:
            return False

    def _schedule_render(self, *, reason: str) -> None:
        if not self.display:
            return

        if self._render_worker is not None and self._render_worker.state in (
            WorkerState.PENDING,
            WorkerState.RUNNING,
        ):
            self._pending_render = True
            self._pending_render_reason = reason
            return

        self._pending_render = False
        self._pending_render_reason = None
        self._last_render_started_at = time.monotonic()
        self._render_worker = self.run_worker(
            self._render_agents(), group="agents-render", exit_on_error=False
        )

    def force_render(self, *, reason: str) -> None:
        """Force a re-render even if the collected data didn't change."""
        # Reset fingerprint so the next refresh doesn't treat the UI as "up to date".
        self._rendered_fingerprint = ""
        if self._agents:
            self._schedule_render(reason=reason)

    @staticmethod
    def _detect_running_agent(
        pane_pid: int | None, snapshot: _ProcessSnapshot | None
    ) -> str | None:
        """Detect whether a known agent process exists under a tmux pane PID.

        Uses a cached process snapshot built once per refresh to avoid spawning `ps`
        repeatedly for every terminal row.
        """
        if not pane_pid or snapshot is None:
            return None

        children = snapshot.children
        comms = snapshot.comms
        stack = [pane_pid]
        seen: set[int] = set()
        while stack:
            p = stack.pop()
            if p in seen:
                continue
            seen.add(p)
            comm = (comms.get(p) or "").lower()
            for kw in ("claude", "codex", "opencode"):
                if kw in comm:
                    return kw
            stack.extend(children.get(p, []))
        return None

    @staticmethod
    def _normalize_tty(tty: str) -> str:
        s = (tty or "").strip()
        if not s:
            return ""
        if s.startswith("/dev/"):
            s = s[len("/dev/") :]
        return s.strip()

    def _get_process_snapshot(self, *, pane_ttys: set[str]) -> _ProcessSnapshot | None:
        """Return a cached process snapshot scoped to the given TTY set.

        TTL is aligned with the panel refresh interval so the snapshot is at most one refresh stale.
        """
        ttys = sorted(
            {self._normalize_tty(t) for t in (pane_ttys or set()) if self._normalize_tty(t)}
        )
        if not ttys:
            return None
        tty_key = ",".join(ttys)

        now = time.monotonic()
        cached = self._process_snapshot
        if (
            cached
            and cached.tty_key == tty_key
            and (now - cached.created_at_monotonic) < float(self.REFRESH_INTERVAL_SECONDS)
        ):
            return cached

        try:
            import subprocess

            # Prefer TTY-limited `ps` to keep output small. BSD ps supports comma-separated TTY list.
            result = subprocess.run(
                ["ps", "-o", "pid=,ppid=,comm=", "-t", tty_key],
                capture_output=True,
                text=True,
                timeout=2,
            )
            stdout = result.stdout or ""
            if result.returncode != 0 or not stdout.strip():
                # Fallback: some environments may not accept `-t` list; fall back to a single
                # snapshot of all processes and filter by TTY.
                result = subprocess.run(
                    ["ps", "-axo", "pid=,ppid=,tty=,comm="],
                    capture_output=True,
                    text=True,
                    timeout=2,
                )
                stdout = result.stdout or ""

                allowed = set(ttys)
                filtered_lines: list[str] = []
                for line in stdout.splitlines():
                    parts = line.split(None, 3)
                    if len(parts) < 4:
                        continue
                    tty = self._normalize_tty(parts[2])
                    if tty and tty in allowed:
                        filtered_lines.append(f"{parts[0]} {parts[1]} {parts[3]}")
                stdout = "\n".join(filtered_lines)

            children: dict[int, list[int]] = {}
            comms: dict[int, str] = {}
            for line in stdout.splitlines():
                parts = line.split(None, 2)
                if len(parts) < 3:
                    continue
                try:
                    pid, ppid = int(parts[0]), int(parts[1])
                except ValueError:
                    continue
                children.setdefault(ppid, []).append(pid)
                comms[pid] = parts[2]

            snap = _ProcessSnapshot(
                created_at_monotonic=now, tty_key=tty_key, children=children, comms=comms
            )
            self._process_snapshot = snap
            return snap
        except Exception:
            return None

    def _collect_agents(self) -> dict:
        """Collect agent info with their terminals."""
        agents: list[dict] = []

        from ...db import get_database

        # Dashboard should prefer correctness/stability over ultra-low lock timeouts.
        db = get_database(read_only=True, connect_timeout_seconds=2.0)

        # Critical: if this fails, let it surface as a worker ERROR so we can keep
        # the last rendered UI instead of flashing an empty agent list.
        agent_infos = db.list_agent_info()

        # Best-effort: missing pieces should degrade gracefully (names still render).
        try:
            active_terminals = db.list_agents(status="active", limit=1000)
        except Exception as e:
            logger.debug(f"Failed to list active terminals: {e}")
            active_terminals = []

        try:
            latest_links = db.list_latest_window_links(limit=2000)
        except Exception:
            latest_links = []
        link_by_terminal = {
            l.terminal_id: l for l in latest_links if getattr(l, "terminal_id", None)
        }

        tmux_windows_ok = True
        try:
            tmux_windows = tmux_manager.list_inner_windows()
        except Exception as e:
            logger.debug(f"Failed to list tmux windows: {e}")
            tmux_windows_ok = False
            tmux_windows = []
        terminal_to_window = {
            w.terminal_id: w for w in tmux_windows if getattr(w, "terminal_id", None)
        }

        # If we are running inside the managed tmux dashboard environment, only show terminals
        # that still exist in the inner tmux server. This prevents stale buttons when a user
        # exits a shell directly (tmux window disappears but DB record may still be "active").
        try:
            if tmux_manager.managed_env_enabled() and tmux_windows_ok:
                present = {tid for tid in terminal_to_window.keys() if tid}
                if present:
                    active_terminals = [t for t in active_terminals if getattr(t, "id", None) in present]
                else:
                    # Inner session exists but no tracked terminals are present.
                    active_terminals = []
        except Exception:
            pass

        pane_ttys: set[str] = set()
        for w in tmux_windows:
            if getattr(w, "pane_pid", None) and getattr(w, "pane_tty", None):
                pane_ttys.add(str(w.pane_tty))
        ps_snapshot = self._get_process_snapshot(pane_ttys=pane_ttys) if pane_ttys else None

        # Detect currently active terminal
        active_window = next((w for w in tmux_windows if w.active), None)
        active_terminal_id = active_window.terminal_id if active_window else None

        # Collect all session_ids for title lookup
        session_ids: list[str] = []
        for t in active_terminals:
            link = link_by_terminal.get(t.id)
            if link and getattr(link, "session_id", None):
                session_ids.append(link.session_id)
                continue
            window = terminal_to_window.get(t.id)
            if window and getattr(window, "session_id", None):
                session_ids.append(window.session_id)
                continue
            # Fallback: agent record (works even when WindowLink isn't available yet / at all).
            agent_session_id = getattr(t, "session_id", None)
            if agent_session_id:
                session_ids.append(agent_session_id)

        titles: dict[str, str] = {}
        session_agent_id: dict[str, str] = {}
        try:
            uniq_session_ids = sorted({sid for sid in session_ids if sid})
            if uniq_session_ids:
                sessions = db.get_sessions_by_ids(uniq_session_ids)
                for s in sessions:
                    sid = getattr(s, "id", None)
                    if not sid:
                        continue
                    title = (getattr(s, "session_title", "") or "").strip()
                    if title:
                        titles[sid] = title
                    agent_id = getattr(s, "agent_id", None)
                    if agent_id:
                        session_agent_id[sid] = agent_id
        except Exception:
            titles = {}
            session_agent_id = {}

        # Map agent_info.id -> list of terminals
        agent_to_terminals: dict[str, list[dict]] = {}
        for t in active_terminals:
            # Find which agent_info this terminal belongs to
            agent_info_id = None

            link = link_by_terminal.get(t.id)

            # Method 1: Check source field for "agent:{agent_info_id}" format
            source = t.source or ""
            if source.startswith("agent:"):
                agent_info_id = source[6:]

            # Method 2: WindowLink agent_id
            if not agent_info_id and link and getattr(link, "agent_id", None):
                agent_info_id = link.agent_id

            # Method 3: Fallback - check tmux window's session.agent_id
            if not agent_info_id:
                window = terminal_to_window.get(t.id)
                if window and getattr(window, "session_id", None):
                    agent_info_id = session_agent_id.get(window.session_id) or None

            if agent_info_id:
                agent_to_terminals.setdefault(agent_info_id, [])

                # Get session_id from windowlink (preferred) or tmux window
                window = terminal_to_window.get(t.id)
                session_id = (
                    link.session_id
                    if link and getattr(link, "session_id", None)
                    else (
                        window.session_id
                        if window and getattr(window, "session_id", None)
                        else getattr(t, "session_id", None)
                    )
                )
                title = titles.get(session_id, "") if session_id else ""

                pane_cmd = window.pane_current_command if window else None
                provider = (
                    link.provider
                    if link and getattr(link, "provider", None)
                    else (t.provider or "")
                )
                pane_pid = window.pane_pid if window else None
                running_agent = self._detect_running_agent(pane_pid, ps_snapshot)

                entry = {
                    "terminal_id": t.id,
                    "window_id": window.window_id if window else None,
                    "session_id": session_id,
                    "provider": provider,
                    "session_type": t.session_type or "",
                    "title": title,
                    "cwd": t.cwd or "",
                    "running_agent": running_agent,
                    "pane_current_command": pane_cmd,
                }
                agent_to_terminals[agent_info_id].append(entry)

        for info in agent_infos:
            terminals = agent_to_terminals.get(info.id, [])
            agents.append(
                {
                    "id": info.id,
                    "name": info.name,
                    "description": info.description or "",
                    "terminals": terminals,
                    "share_url": getattr(info, "share_url", None),
                    "last_synced_at": getattr(info, "last_synced_at", None),
                }
            )

        return {"agents": agents, "active_terminal_id": active_terminal_id}

    @staticmethod
    def _fingerprint(agents: list[dict]) -> str:
        """Fast serialisation used only for change detection."""
        try:
            return _json.dumps(agents, sort_keys=True, default=str)
        except Exception:
            return ""

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        # Handle switch worker
        if self._switch_worker is not None and event.worker is self._switch_worker:
            if event.state == WorkerState.SUCCESS:
                result = self._switch_worker.result or {}
                if isinstance(result, dict):
                    seq = int(result.get("seq", 0) or 0)
                    if seq != self._switch_seq:
                        return
                    terminal_id = str(result.get("terminal_id", "") or "").strip() or None
                    ok = bool(result.get("ok", False))
                    if ok and terminal_id:
                        self._active_terminal_id = terminal_id
                        self._update_active_terminal_ui(terminal_id)
                        # Prevent the next refresh from forcing a full re-render just due to
                        # active-terminal changes.
                        self._rendered_fingerprint = (
                            self._fingerprint(self._agents) + f"|active:{self._active_terminal_id}"
                        )
                    else:
                        msg = str(result.get("error", "") or "Failed to switch").strip()
                        self.app.notify(msg, title="Agent", severity="error")
                        self.refresh_data()
            elif event.state == WorkerState.ERROR:
                err = self._switch_worker.error
                msg = "Failed to switch"
                if isinstance(err, BaseException):
                    msg = f"Failed to switch: {err}"
                elif err:
                    msg = f"Failed to switch: {err}"
                self.app.notify(msg, title="Agent", severity="error")
                self.refresh_data()

            if event.state in {WorkerState.SUCCESS, WorkerState.ERROR, WorkerState.CANCELLED}:
                self._switch_worker = None
            return

        # Handle refresh worker
        if self._refresh_worker is not None and event.worker is self._refresh_worker:
            if event.state == WorkerState.ERROR:
                # Keep the last successfully-rendered list on refresh errors to avoid
                # flashing an empty Agents tab during transient tmux/SQLite hiccups.
                self._last_refresh_error_at = time.monotonic()
                err = self._refresh_worker.error
                if isinstance(err, BaseException):
                    logger.warning(
                        "Agents refresh failed",
                        exc_info=(type(err), err, err.__traceback__),
                    )
                else:
                    logger.warning(f"Agents refresh failed: {err}")
                return
            elif event.state == WorkerState.SUCCESS:
                prev_agents = self._agents
                prev_active = self._active_terminal_id
                payload = self._refresh_worker.result or {}
                if isinstance(payload, dict) and "agents" in payload:
                    self._agents = payload.get("agents") or []
                    self._active_terminal_id = payload.get("active_terminal_id") or None
                else:
                    self._agents = payload or []
                self._last_refresh_error_at = None
            else:
                return

            # Fast path: only the active terminal changed; update button classes in-place
            # to avoid full re-render flicker / input lag.
            try:
                prev_agents_fp = self._fingerprint(prev_agents)
                new_agents_fp = self._fingerprint(self._agents)
                if (
                    prev_agents_fp == new_agents_fp
                    and prev_active != self._active_terminal_id
                    and not self._ui_blank()
                ):
                    self._update_active_terminal_ui(self._active_terminal_id)
                    self._rendered_fingerprint = new_agents_fp + f"|active:{self._active_terminal_id}"
                    return
            except Exception:
                new_agents_fp = self._fingerprint(self._agents)

            fp = new_agents_fp + f"|active:{self._active_terminal_id}"
            # Important: the UI can become blank due to cancellation or transient Textual issues.
            # If data didn't change but the widget tree is empty, force a re-render.
            should_render = (fp != self._rendered_fingerprint) or (
                self._agents and self._ui_blank()
            )
            if not should_render:
                return  # nothing changed – skip re-render to avoid flicker
            self._rendered_fingerprint = fp
            self._schedule_render(reason="refresh")
            return

        # Handle render worker
        if self._render_worker is not None and event.worker is self._render_worker:
            if event.state == WorkerState.ERROR:
                err = self._render_worker.error
                if isinstance(err, BaseException):
                    logger.warning(
                        "Agents render failed",
                        exc_info=(type(err), err, err.__traceback__),
                    )
                else:
                    logger.warning(f"Agents render failed: {err}")
                # Force next refresh to re-render even if data is unchanged.
                self._rendered_fingerprint = ""
            elif event.state == WorkerState.SUCCESS:
                self._last_render_completed_at = time.monotonic()
            elif event.state == WorkerState.CANCELLED:
                self._rendered_fingerprint = ""

            if event.state in {WorkerState.SUCCESS, WorkerState.ERROR, WorkerState.CANCELLED}:
                self._last_render_completed_at = time.monotonic()
                self._render_worker = None
                if self._pending_render:
                    reason = self._pending_render_reason or "pending"
                    self._schedule_render(reason=reason)
            return

        # Handle share worker
        if self._share_worker is not None and event.worker is self._share_worker:
            self._handle_share_worker_state_changed(event)

        # Handle sync worker
        if self._sync_worker is not None and event.worker is self._sync_worker:
            self._handle_sync_worker_state_changed(event)

    async def _render_agents(self) -> None:
        async with self._refresh_lock:
            try:
                container = self.query_one("#agents-list", Vertical)
                with self.app.batch_update():
                    await container.remove_children()

                    if not self._agents:
                        await container.mount(
                            Static("No agents yet. Click 'Add Agent' to add one.")
                        )
                        return

                    blocks = [
                        _AgentBlockWidget(agent=agent, active_terminal_id=self._active_terminal_id)
                        for agent in self._agents
                    ]
                    await container.mount_all(blocks)
            except Exception:
                logger.exception("Failed to render agents list")
                try:
                    container = self.query_one("#agents-list", Vertical)
                    await container.remove_children()
                    await container.mount(
                        Static("Agents UI error (see ~/.aline/.logs/dashboard.log)")
                    )
                except Exception:
                    pass
                return
            except asyncio.CancelledError:
                # Best-effort: avoid leaving the UI in a permanently blank state.
                logger.warning("Agents render cancelled")
                self._rendered_fingerprint = ""
                return

    @staticmethod
    def _short_id(val: str | None) -> str:
        if not val:
            return ""
        if len(val) > 20:
            return val[:8] + "..." + val[-8:]
        return val

    def _fetch_session_titles(self, session_ids: list[str]) -> dict[str, str]:
        """Fetch session titles from database (same method as Terminal panel)."""
        if not session_ids:
            return {}
        try:
            from ...db import get_database

            db = get_database(read_only=True)
            sessions = db.get_sessions_by_ids(session_ids)
            titles: dict[str, str] = {}
            for s in sessions:
                title = (s.session_title or "").strip()
                if title:
                    titles[s.id] = title
            return titles
        except Exception:
            return {}

    @staticmethod
    def _safe_id(raw: str) -> str:
        safe = re.sub(r"[^A-Za-z0-9_-]+", "-", raw).strip("-_")
        if not safe:
            return "a"
        if safe[0].isdigit():
            return f"a-{safe}"
        return safe

    def _find_window(self, terminal_id: str) -> str | None:
        if not terminal_id:
            return None
        try:
            for w in tmux_manager.list_inner_windows():
                if w.terminal_id == terminal_id:
                    return w.window_id
        except Exception:
            pass
        return None

    def _update_active_terminal_ui(self, terminal_id: str | None) -> None:
        """Update just the active-terminal button classes (no full re-render)."""
        try:
            for btn in self.query("Button.terminal-switch"):
                btn_id = btn.id or ""
                if not btn_id.startswith("switch-"):
                    continue
                is_active = bool(terminal_id and (btn.name == terminal_id))
                if is_active:
                    btn.add_class("active-terminal")
                else:
                    btn.remove_class("active-terminal")
        except Exception:
            return

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""

        if btn_id == "create-agent":
            await self._create_agent()
            return

        if btn_id.startswith("agent-"):
            # Click on agent name - could expand/collapse or do nothing
            return

        if btn_id.startswith("create-term-"):
            agent_id = event.button.name or ""
            await self._create_terminal_for_agent(agent_id)
            return

        if btn_id.startswith("delete-"):
            agent_id = event.button.name or ""
            await self._delete_agent(agent_id)
            return

        if btn_id.startswith("share-"):
            agent_id = event.button.name or ""
            await self._share_agent(agent_id)
            return

        if btn_id.startswith("sync-"):
            agent_id = event.button.name or ""
            await self._sync_agent(agent_id)
            return

        if btn_id.startswith("link-"):
            agent_id = event.button.name or ""
            await self._copy_share_link(agent_id)
            return

        if btn_id.startswith("switch-"):
            terminal_id = event.button.name or ""
            self._request_switch_to_terminal(terminal_id)
            return

        if btn_id.startswith("close-"):
            terminal_id = event.button.name or ""
            await self._close_terminal(terminal_id)
            return

    async def on_agent_name_button_double_clicked(
        self, event: AgentNameButton.DoubleClicked
    ) -> None:
        agent_id = event.agent_id
        if not agent_id:
            return

        from ..screens import AgentDetailScreen

        self.app.push_screen(AgentDetailScreen(agent_id))

    async def _create_agent(self) -> None:
        try:
            from ..screens import CreateAgentInfoScreen

            self.app.push_screen(CreateAgentInfoScreen(), self._on_create_result)
        except ImportError:
            try:
                from ...agent_names import generate_agent_name
                from ...db import get_database
                import uuid

                db = get_database(read_only=False)
                agent_id = str(uuid.uuid4())
                name = generate_agent_name()
                db.get_or_create_agent_info(agent_id, name=name)
                self.app.notify(f"Created: {name}", title="Agent")
                self.refresh_data()
            except Exception as e:
                self.app.notify(f"Failed: {e}", title="Agent", severity="error")

    def _on_create_result(self, result: dict | None) -> None:
        if result:
            if result.get("imported"):
                n = result.get("sessions_imported", 0)
                self.app.notify(f"Imported: {result.get('name')} ({n} sessions)", title="Agent")
            else:
                self.app.notify(f"Created: {result.get('name')}", title="Agent")
        self.refresh_data()

    async def _create_terminal_for_agent(self, agent_id: str) -> None:
        """Create a new terminal under the specified agent."""
        if not agent_id:
            return

        # Get agent info
        agent = next((a for a in self._agents if a["id"] == agent_id), None)
        if not agent:
            self.app.notify("Agent not found", title="Agent", severity="error")
            return

        # Show create terminal screen with agent context
        try:
            from ..screens import CreateAgentScreen

            self.app.push_screen(
                CreateAgentScreen(),
                lambda result: self._on_create_terminal_result(result, agent_id),
            )
        except ImportError as e:
            self.app.notify(f"Failed: {e}", title="Agent", severity="error")

    def _on_create_terminal_result(
        self, result: tuple[str, str, bool, bool] | None, agent_id: str
    ) -> None:
        """Handle result from CreateAgentScreen."""
        if result is None:
            return

        agent_type, workspace, skip_permissions, no_track = result

        # Create the terminal with agent association
        self.run_worker(
            self._do_create_terminal(agent_type, workspace, skip_permissions, no_track, agent_id),
            group="terminal-create",
            exclusive=True,
            exit_on_error=False,
        )

    async def _do_create_terminal(
        self,
        agent_type: str,
        workspace: str,
        skip_permissions: bool,
        no_track: bool,
        agent_id: str,
    ) -> None:
        """Actually create the terminal with agent association."""
        if agent_type == "claude":
            await self._create_claude_terminal(workspace, skip_permissions, no_track, agent_id)
        elif agent_type == "codex":
            await self._create_codex_terminal(workspace, no_track, agent_id)
        elif agent_type == "opencode":
            await self._create_opencode_terminal(workspace, agent_id)
        elif agent_type == "zsh":
            await self._create_zsh_terminal(workspace, agent_id)

        self.refresh_data()

    async def _create_claude_terminal(
        self, workspace: str, skip_permissions: bool, no_track: bool, agent_id: str
    ) -> None:
        """Create a Claude terminal associated with an agent."""
        terminal_id = tmux_manager.new_terminal_id()
        context_id = tmux_manager.new_context_id("cc")
        logger.info(
            "Create terminal requested: provider=claude terminal_id=%s agent_id=%s workspace=%s "
            "no_track=%s skip_permissions=%s context_id=%s",
            terminal_id,
            agent_id,
            workspace,
            no_track,
            skip_permissions,
            context_id,
        )

        # Prepare CODEX_HOME so user can run codex in this terminal
        try:
            from ...codex_home import prepare_codex_home

            codex_home = prepare_codex_home(terminal_id)
        except Exception:
            codex_home = None

        env = {
            tmux_manager.ENV_TERMINAL_ID: terminal_id,
            tmux_manager.ENV_TERMINAL_PROVIDER: "claude",
            tmux_manager.ENV_INNER_SOCKET: tmux_manager.INNER_SOCKET,
            tmux_manager.ENV_INNER_SESSION: tmux_manager.INNER_SESSION,
            tmux_manager.ENV_CONTEXT_ID: context_id,
            "ALINE_AGENT_ID": agent_id,  # Pass agent_id to hooks
        }
        if codex_home:
            env["CODEX_HOME"] = str(codex_home)
        if no_track:
            env["ALINE_NO_TRACK"] = "1"

        # Install hooks
        self._install_claude_hooks(workspace)

        claude_cmd = "claude"
        if skip_permissions:
            claude_cmd = "claude --dangerously-skip-permissions"

        command = self._command_in_directory(
            tmux_manager.zsh_run_and_keep_open(claude_cmd), workspace
        )

        created = tmux_manager.create_inner_window(
            "cc",
            tmux_manager.shell_command_with_env(command, env),
            terminal_id=terminal_id,
            provider="claude",
            context_id=context_id,
            no_track=no_track,
        )

        if created:
            logger.info(
                "Create terminal success: provider=claude terminal_id=%s window_id=%s",
                terminal_id,
                created.window_id,
            )
            if not tmux_manager.focus_right_pane():
                logger.warning("Create terminal: focus_right_pane failed (provider=claude)")
            # Store agent association in database with agent_info_id in source
            try:
                from ...db import get_database

                db = get_database(read_only=False)
                db.get_or_create_agent(
                    terminal_id,
                    provider="claude",
                    session_type="claude",
                    context_id=context_id,
                    cwd=workspace,
                    project_dir=workspace,
                    source=f"agent:{agent_id}",  # Store agent_info_id in source
                )
            except Exception:
                pass
        else:
            logger.warning("Create terminal failed: provider=claude terminal_id=%s", terminal_id)
            self.app.notify("Failed to create terminal", title="Agent", severity="error")

    async def _create_codex_terminal(self, workspace: str, no_track: bool, agent_id: str) -> None:
        """Create a Codex terminal associated with an agent."""
        try:
            from ...db import get_database
            from datetime import datetime, timedelta

            db = get_database(read_only=True)
            cutoff = datetime.now() - timedelta(seconds=10)
            for agent in db.list_agents(status="active", limit=1000):
                if agent.provider != "codex":
                    continue
                if (agent.source or "") != f"agent:{agent_id}":
                    continue
                if agent.created_at >= cutoff and not agent.session_id:
                    self.app.notify(
                        "Please wait a few seconds before opening another Codex terminal for this agent.",
                        title="Agent",
                        severity="warning",
                    )
                    return
        except Exception:
            pass

        terminal_id = tmux_manager.new_terminal_id()
        context_id = tmux_manager.new_context_id("cx")
        logger.info(
            "Create terminal requested: provider=codex terminal_id=%s agent_id=%s workspace=%s "
            "no_track=%s context_id=%s",
            terminal_id,
            agent_id,
            workspace,
            no_track,
            context_id,
        )

        try:
            from ...codex_home import prepare_codex_home

            codex_home = prepare_codex_home(terminal_id, agent_id=agent_id)
        except Exception:
            codex_home = None

        env = {
            tmux_manager.ENV_TERMINAL_ID: terminal_id,
            tmux_manager.ENV_TERMINAL_PROVIDER: "codex",
            tmux_manager.ENV_INNER_SOCKET: tmux_manager.INNER_SOCKET,
            tmux_manager.ENV_INNER_SESSION: tmux_manager.INNER_SESSION,
            tmux_manager.ENV_CONTEXT_ID: context_id,
            "ALINE_AGENT_ID": agent_id,
        }
        if codex_home:
            env["CODEX_HOME"] = str(codex_home)
        if no_track:
            env["ALINE_NO_TRACK"] = "1"

        # Store agent in database with agent_info_id in source
        try:
            from ...db import get_database

            db = get_database(read_only=False)
            db.get_or_create_agent(
                terminal_id,
                provider="codex",
                session_type="codex",
                context_id=context_id,
                cwd=workspace,
                project_dir=workspace,
                source=f"agent:{agent_id}",  # Store agent_info_id in source
            )
        except Exception:
            pass

        command = self._command_in_directory(tmux_manager.zsh_run_and_keep_open("codex"), workspace)

        created = tmux_manager.create_inner_window(
            "codex",
            tmux_manager.shell_command_with_env(command, env),
            terminal_id=terminal_id,
            provider="codex",
            context_id=context_id,
            no_track=no_track,
        )

        if created:
            logger.info(
                "Create terminal success: provider=codex terminal_id=%s window_id=%s",
                terminal_id,
                created.window_id,
            )
            if not tmux_manager.focus_right_pane():
                logger.warning("Create terminal: focus_right_pane failed (provider=codex)")
        else:
            logger.warning("Create terminal failed: provider=codex terminal_id=%s", terminal_id)
            self.app.notify("Failed to create terminal", title="Agent", severity="error")

    async def _create_opencode_terminal(self, workspace: str, agent_id: str) -> None:
        """Create an Opencode terminal associated with an agent."""
        terminal_id = tmux_manager.new_terminal_id()
        context_id = tmux_manager.new_context_id("oc")
        logger.info(
            "Create terminal requested: provider=opencode terminal_id=%s agent_id=%s workspace=%s "
            "context_id=%s",
            terminal_id,
            agent_id,
            workspace,
            context_id,
        )

        # Prepare CODEX_HOME so user can run codex in this terminal
        try:
            from ...codex_home import prepare_codex_home

            codex_home = prepare_codex_home(terminal_id, agent_id=agent_id)
        except Exception:
            codex_home = None

        env = {
            tmux_manager.ENV_TERMINAL_ID: terminal_id,
            tmux_manager.ENV_TERMINAL_PROVIDER: "opencode",
            tmux_manager.ENV_INNER_SOCKET: tmux_manager.INNER_SOCKET,
            tmux_manager.ENV_INNER_SESSION: tmux_manager.INNER_SESSION,
            tmux_manager.ENV_CONTEXT_ID: context_id,
            "ALINE_AGENT_ID": agent_id,
        }
        if codex_home:
            env["CODEX_HOME"] = str(codex_home)

        # Install Claude hooks in case user runs claude manually
        self._install_claude_hooks(workspace)

        command = self._command_in_directory(
            tmux_manager.zsh_run_and_keep_open("opencode"), workspace
        )

        created = tmux_manager.create_inner_window(
            "opencode",
            tmux_manager.shell_command_with_env(command, env),
            terminal_id=terminal_id,
            provider="opencode",
            context_id=context_id,
        )

        if created:
            logger.info(
                "Create terminal success: provider=opencode terminal_id=%s window_id=%s",
                terminal_id,
                created.window_id,
            )
            if not tmux_manager.focus_right_pane():
                logger.warning("Create terminal: focus_right_pane failed (provider=opencode)")
            # Store agent association in database
            try:
                from ...db import get_database

                db = get_database(read_only=False)
                db.get_or_create_agent(
                    terminal_id,
                    provider="opencode",
                    session_type="opencode",
                    context_id=context_id,
                    cwd=workspace,
                    project_dir=workspace,
                    source=f"agent:{agent_id}",
                )
            except Exception:
                pass
        else:
            logger.warning("Create terminal failed: provider=opencode terminal_id=%s", terminal_id)
            self.app.notify("Failed to create terminal", title="Agent", severity="error")

    async def _create_zsh_terminal(self, workspace: str, agent_id: str) -> None:
        """Create a zsh terminal associated with an agent."""
        terminal_id = tmux_manager.new_terminal_id()
        context_id = tmux_manager.new_context_id("zsh")
        logger.info(
            "Create terminal requested: provider=zsh terminal_id=%s agent_id=%s workspace=%s context_id=%s",
            terminal_id,
            agent_id,
            workspace,
            context_id,
        )

        # Prepare CODEX_HOME so user can run codex in this terminal
        try:
            from ...codex_home import prepare_codex_home

            codex_home = prepare_codex_home(terminal_id, agent_id=agent_id)
        except Exception:
            codex_home = None

        env = {
            tmux_manager.ENV_TERMINAL_ID: terminal_id,
            tmux_manager.ENV_TERMINAL_PROVIDER: "zsh",
            tmux_manager.ENV_INNER_SOCKET: tmux_manager.INNER_SOCKET,
            tmux_manager.ENV_INNER_SESSION: tmux_manager.INNER_SESSION,
            tmux_manager.ENV_CONTEXT_ID: context_id,
            "ALINE_AGENT_ID": agent_id,
        }
        if codex_home:
            env["CODEX_HOME"] = str(codex_home)

        # Install Claude hooks in case user runs claude manually
        self._install_claude_hooks(workspace)

        command = self._command_in_directory("zsh", workspace)

        created = tmux_manager.create_inner_window(
            "zsh",
            tmux_manager.shell_command_with_env(command, env),
            terminal_id=terminal_id,
            provider="zsh",
            context_id=context_id,
        )

        if created:
            logger.info(
                "Create terminal success: provider=zsh terminal_id=%s window_id=%s",
                terminal_id,
                created.window_id,
            )
            if not tmux_manager.focus_right_pane():
                logger.warning("Create terminal: focus_right_pane failed (provider=zsh)")
            # Store agent association in database
            try:
                from ...db import get_database

                db = get_database(read_only=False)
                db.get_or_create_agent(
                    terminal_id,
                    provider="zsh",
                    session_type="zsh",
                    context_id=context_id,
                    cwd=workspace,
                    project_dir=workspace,
                    source=f"agent:{agent_id}",
                )
            except Exception:
                pass
        else:
            logger.warning("Create terminal failed: provider=zsh terminal_id=%s", terminal_id)
            self.app.notify("Failed to create terminal", title="Agent", severity="error")

    def _install_claude_hooks(self, workspace: str) -> None:
        """Install Claude hooks for a workspace."""
        try:
            from ...claude_hooks.stop_hook_installer import (
                ensure_stop_hook_installed,
                get_settings_path as get_stop_settings_path,
                install_stop_hook,
            )
            from ...claude_hooks.user_prompt_submit_hook_installer import (
                ensure_user_prompt_submit_hook_installed,
                get_settings_path as get_submit_settings_path,
                install_user_prompt_submit_hook,
            )
            from ...claude_hooks.permission_request_hook_installer import (
                ensure_permission_request_hook_installed,
                get_settings_path as get_permission_settings_path,
                install_permission_request_hook,
            )

            ensure_stop_hook_installed(quiet=True)
            ensure_user_prompt_submit_hook_installed(quiet=True)
            ensure_permission_request_hook_installed(quiet=True)

            project_root = Path(workspace)
            install_stop_hook(get_stop_settings_path(project_root), quiet=True)
            install_user_prompt_submit_hook(get_submit_settings_path(project_root), quiet=True)
            install_permission_request_hook(get_permission_settings_path(project_root), quiet=True)
        except Exception:
            pass

    @staticmethod
    def _command_in_directory(command: str, directory: str) -> str:
        return f"cd {shlex.quote(directory)} && {command}"

    async def _delete_agent(self, agent_id: str) -> None:
        if not agent_id:
            return
        try:
            from ...db import get_database

            db = get_database(read_only=False)
            info = db.get_agent_info(agent_id)
            name = info.name if info else "Unknown"

            record = db.update_agent_info(agent_id, visibility="invisible")
            if record:
                self.app.notify(f"Hidden: {name}", title="Agent")
            self.refresh_data()
        except Exception as e:
            self.app.notify(f"Failed: {e}", title="Agent", severity="error")

    def _request_switch_to_terminal(self, terminal_id: str) -> None:
        """Switch terminals without blocking the UI thread."""
        terminal_id = (terminal_id or "").strip()
        if not terminal_id:
            return

        self._active_terminal_id = terminal_id
        self._update_active_terminal_ui(terminal_id)
        self._rendered_fingerprint = (
            self._fingerprint(self._agents) + f"|active:{self._active_terminal_id}"
        )

        self._switch_seq += 1
        seq = self._switch_seq

        if self._switch_worker is not None and self._switch_worker.state in (
            WorkerState.PENDING,
            WorkerState.RUNNING,
        ):
            try:
                self._switch_worker.cancel()
            except Exception:
                pass

        agents_snapshot = self._agents

        def work() -> dict:
            # Prefer cached window_id to avoid a blocking tmux scan on every click.
            window_id = None
            try:
                for agent in agents_snapshot:
                    for term in agent.get("terminals") or []:
                        if term.get("terminal_id") == terminal_id:
                            window_id = (term.get("window_id") or "").strip() or None
                            break
                    if window_id:
                        break
            except Exception:
                window_id = None

            if not window_id:
                # Fall back to querying tmux (best-effort).
                window_id = self._find_window(terminal_id)

            if not window_id:
                # If the terminal was closed from within the shell (e.g. `exit`), the DB record can
                # remain "active" briefly. Trigger a refresh so the stale button disappears.
                try:
                    from ...db import get_database

                    db = get_database(read_only=False)
                    db.update_agent(terminal_id, status="inactive")
                except Exception:
                    pass
                return {
                    "seq": seq,
                    "terminal_id": terminal_id,
                    "ok": False,
                    "error": "Window not found",
                }

            if not tmux_manager.select_inner_window(window_id):
                return {
                    "seq": seq,
                    "terminal_id": terminal_id,
                    "window_id": window_id,
                    "ok": False,
                    "error": "Failed to switch",
                }

            # Prefer showing the terminal after switching (best-effort).
            if not tmux_manager.focus_right_pane():
                logger.warning(
                    "Switch terminal: focus_right_pane failed (terminal_id=%s window_id=%s)",
                    terminal_id,
                    window_id,
                )
            tmux_manager.clear_attention(window_id)
            return {"seq": seq, "terminal_id": terminal_id, "window_id": window_id, "ok": True}

        self._switch_worker = self.run_worker(work, thread=True, exit_on_error=False)

    async def _close_terminal(self, terminal_id: str) -> None:
        if not terminal_id:
            return

        # Try to close the tmux window if it exists
        window_id = self._find_window(terminal_id)
        if window_id:
            tmux_manager.kill_inner_window(window_id)

        # Also update the agent status in the database to mark it as inactive
        try:
            from ...db import get_database

            db = get_database(read_only=False)
            db.update_agent(terminal_id, status="inactive")
        except Exception as e:
            logger.debug(f"Failed to update agent status: {e}")

        self.refresh_data()

    async def _share_agent(self, agent_id: str) -> None:
        """Share all sessions for an agent."""
        if not agent_id:
            return

        # Check if share is already in progress
        if self._share_worker is not None and self._share_worker.state in (
            WorkerState.PENDING,
            WorkerState.RUNNING,
        ):
            return

        # Check if agent has sessions
        try:
            from ...db import get_database

            db = get_database(read_only=True)
            sessions = db.get_sessions_by_agent_id(agent_id)
            if not sessions:
                self.app.notify("Agent has no sessions to share", title="Share", severity="warning")
                return
        except Exception as e:
            self.app.notify(f"Failed to check sessions: {e}", title="Share", severity="error")
            return

        # Store agent_id for the worker callback
        self._share_agent_id = agent_id

        # Create progress callback that posts notifications from worker thread
        app = self.app  # Capture reference for closure

        def progress_callback(message: str) -> None:
            """Send progress notification from worker thread."""
            try:
                app.call_from_thread(app.notify, message, title="Share", timeout=3)
            except Exception:
                pass  # Ignore errors if app is closing

        def work() -> dict:
            import contextlib
            import io
            import json as json_module
            import re

            stdout = io.StringIO()
            stderr = io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                from ...commands import export_shares

                exit_code = export_shares.export_agent_shares_command(
                    agent_id=agent_id,
                    password=None,
                    json_output=True,
                    compact=True,
                    progress_callback=progress_callback,
                )

            output = stdout.getvalue().strip()
            error_text = stderr.getvalue().strip()
            result: dict = {
                "exit_code": exit_code,
                "output": output,
                "stderr": error_text,
            }

            if output:
                try:
                    result["json"] = json_module.loads(output)
                except Exception:
                    result["json"] = None
                    try:
                        from ...llm_client import extract_json

                        result["json"] = extract_json(output)
                    except Exception:
                        result["json"] = None
                        try:
                            match = re.search(r"\{.*\}", output, re.DOTALL)
                            if match:
                                result["json"] = json_module.loads(match.group(0), strict=False)
                        except Exception:
                            result["json"] = None

            if not result.get("json") and output:
                match = re.search(r"https?://[^\s\"']+/share/[^\s\"']+", output)
                if match:
                    result["share_link_guess"] = match.group(0)
            else:
                result["json"] = None

            return result

        self.app.notify("Starting share...", title="Share", timeout=2)
        self._share_worker = self.run_worker(work, thread=True, exit_on_error=False)

    def _handle_share_worker_state_changed(self, event: Worker.StateChanged) -> None:
        """Handle share worker state changes."""
        from ..clipboard import copy_text

        if event.state == WorkerState.ERROR:
            err = self._share_worker.error if self._share_worker else "Unknown error"
            self.app.notify(f"Share failed: {err}", title="Share", severity="error")
            return

        if event.state != WorkerState.SUCCESS:
            return

        result = self._share_worker.result if self._share_worker else {}
        raw_exit_code = result.get("exit_code", None)
        exit_code = 1 if raw_exit_code is None else int(raw_exit_code)
        payload = result.get("json") or {}
        share_link = payload.get("share_link") or payload.get("share_url")
        if not share_link:
            share_link = result.get("share_link_guess")
        slack_message = payload.get("slack_message") if isinstance(payload, dict) else None
        if not slack_message:
            try:
                from ...db import get_database

                db = get_database()
                agent_info = (
                    db.get_agent_info(self._share_agent_id) if self._share_agent_id else None
                )
                agent_name = agent_info.name if agent_info and agent_info.name else "agent"
                slack_message = f"Sharing {agent_name} sessions from Aline."
            except Exception:
                slack_message = "Sharing sessions from Aline."

        if exit_code == 0 and share_link:
            if slack_message:
                text_to_copy = str(slack_message) + "\n\n" + str(share_link)
            else:
                text_to_copy = str(share_link)

            copied = copy_text(self.app, text_to_copy)

            suffix = " (copied)" if copied else ""
            self.app.notify(f"Share link: {share_link}{suffix}", title="Share", timeout=6)
        elif exit_code == 0:
            self.app.notify("Share completed", title="Share", timeout=3)
        else:
            extra = result.get("stderr") or ""
            suffix = f": {extra}" if extra else ""
            self.app.notify(f"Share failed (exit {exit_code}){suffix}", title="Share", timeout=6)

    async def _sync_agent(self, agent_id: str) -> None:
        """Sync all sessions for an agent with remote share."""
        if not agent_id:
            return

        # Check if sync is already in progress
        if self._sync_worker is not None and self._sync_worker.state in (
            WorkerState.PENDING,
            WorkerState.RUNNING,
        ):
            return

        self._sync_agent_id = agent_id

        app = self.app

        def progress_callback(message: str) -> None:
            try:
                app.call_from_thread(app.notify, message, title="Sync", timeout=3)
            except Exception:
                pass

        def work() -> dict:
            from ...commands.sync_agent import sync_agent_command

            return sync_agent_command(
                agent_id=agent_id,
                progress_callback=progress_callback,
            )

        self.app.notify("Starting sync...", title="Sync", timeout=2)
        self._sync_worker = self.run_worker(work, thread=True, exit_on_error=False)

    def _handle_sync_worker_state_changed(self, event: Worker.StateChanged) -> None:
        """Handle sync worker state changes."""
        if event.state == WorkerState.ERROR:
            err = self._sync_worker.error if self._sync_worker else "Unknown error"
            self.app.notify(f"Sync failed: {err}", title="Sync", severity="error")
            return

        if event.state != WorkerState.SUCCESS:
            return

        result = self._sync_worker.result if self._sync_worker else {}

        if result.get("success"):
            pulled = result.get("sessions_pulled", 0)
            pushed = result.get("sessions_pushed", 0)

            # Copy share URL to clipboard
            agent_id = self._sync_agent_id
            share_url = None
            if agent_id:
                agent = next((a for a in self._agents if a["id"] == agent_id), None)
                if agent:
                    share_url = agent.get("share_url")

            if share_url:
                copied = copy_text(self.app, share_url)
                suffix = " (link copied)" if copied else ""
            else:
                suffix = ""

            self.app.notify(
                f"Synced: pulled {pulled}, pushed {pushed} session(s){suffix}",
                title="Sync",
                timeout=6,
            )
            self.refresh_data()
        else:
            error = result.get("error", "Unknown error")
            self.app.notify(f"Sync failed: {error}", title="Sync", severity="error")

    async def _copy_share_link(self, agent_id: str) -> None:
        """Copy the share link for an agent to clipboard."""
        if not agent_id:
            return

        agent = next((a for a in self._agents if a["id"] == agent_id), None)
        if not agent:
            self.app.notify("Agent not found", title="Link", severity="error")
            return

        share_url = agent.get("share_url")
        if not share_url:
            self.app.notify("No share link available", title="Link", severity="warning")
            return

        copied = copy_text(self.app, share_url)
        if copied:
            self.app.notify("Share link copied to clipboard", title="Link", timeout=3)
        else:
            self.app.notify(f"Failed to copy. Link: {share_url}", title="Link", severity="warning")
