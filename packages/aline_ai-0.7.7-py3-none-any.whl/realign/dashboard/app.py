"""Aline Dashboard - Main Application."""

import asyncio
import os
import time
import traceback

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal
from textual.worker import Worker, WorkerState
from textual.widgets import Footer, TabbedContent, TabPane

from ..logging_config import setup_logger
from .diagnostics import DashboardDiagnostics
from .widgets import (
    AlineHeader,
    ConfigPanel,
    AgentsPanel,
    RightStatusBar,
    WatcherPanel,
    WorkerPanel,
)
from .state import get_dashboard_state_value

# Environment variable to control terminal mode
ENV_TERMINAL_MODE = "ALINE_TERMINAL_MODE"

# Set up dashboard logger - logs to ~/.aline/.logs/dashboard.log
logger = setup_logger("realign.dashboard", "dashboard.log")


def _monotonic() -> float:
    """Small wrapper so tests can patch without affecting global time.monotonic()."""
    return time.monotonic()


class AlineDashboard(App):
    """Aline Interactive Dashboard - TUI for monitoring and managing Aline."""

    CSS_PATH = "styles/dashboard.tcss"
    TITLE = "Aline Dashboard"
    ENABLE_COMMAND_PALETTE = False

    BINDINGS = [
        Binding("r", "refresh", "Refresh", show=False),
        Binding("?", "help", "Help"),
        Binding("tab", "next_tab", "Next Tab", priority=True, show=False),
        Binding("shift+tab", "prev_tab", "Prev Tab", priority=True, show=False),
        Binding("ctrl+d", "dump_diagnostics", "Dump Diagnostics", show=False),
        Binding("ctrl+c", "quit_confirm", "Quit", priority=True),
    ]

    _quit_confirm_window_s: float = 1.2

    def __init__(self, use_native_terminal: bool | None = None, *, dev: bool = False):
        """Initialize the dashboard.

        Args:
            use_native_terminal: If True, use native terminal backend (iTerm2/Kitty).
                                 If False, use tmux.
                                 If None (default), auto-detect from ALINE_TERMINAL_MODE env var.
            dev: If True, enable developer mode (shows Watcher and Worker tabs).
        """
        super().__init__()
        self.use_native_terminal = use_native_terminal
        self.dev = bool(dev)
        self._native_terminal_mode = self._detect_native_mode()
        self._local_api_server = None
        self._diagnostics = DashboardDiagnostics.start()
        self._tmux_width_timer = None
        self._diagnostics.install_global_exception_hooks()
        self._watchdog_timer = None
        self._apply_saved_theme()
        self._diagnostics.event(
            "dashboard_init",
            native_terminal=bool(self._native_terminal_mode),
        )
        logger.info(f"AlineDashboard initialized (native_terminal={self._native_terminal_mode})")

    def _detect_native_mode(self) -> bool:
        """Detect if native terminal mode should be used."""
        if self.use_native_terminal is not None:
            return self.use_native_terminal

        mode = os.environ.get(ENV_TERMINAL_MODE, "").strip().lower()
        return mode in {"native", "iterm2", "iterm", "kitty"}

    def compose(self) -> ComposeResult:
        """Compose the dashboard layout."""
        logger.debug("compose() started")
        try:
            yield AlineHeader()
            with TabbedContent(initial="agents"):
                with TabPane("Agents", id="agents"):
                    yield AgentsPanel()
                with TabPane("Config", id="config"):
                    yield ConfigPanel()
                if self.dev:
                    with TabPane("Watcher", id="watcher"):
                        yield WatcherPanel()
                    with TabPane("Worker", id="worker"):
                        yield WorkerPanel()
            with Horizontal(id="dashboard-footer-row"):
                yield Footer()
                yield RightStatusBar(id="status-bar", width=35)
            logger.debug("compose() completed successfully")
        except Exception as e:
            logger.error(f"compose() failed: {e}\n{traceback.format_exc()}")
            raise

    def set_status_bar(
        self,
        text: str,
        *,
        spinning: bool = True,
        variant: str = "active",
        clear_after_s: float | None = None,
    ) -> None:
        try:
            bar = self.query_one("#status-bar", RightStatusBar)
        except Exception:
            return
        bar.set_status(
            text,
            spinning=spinning,
            variant=variant,
            clear_after_s=clear_after_s,
        )

    def clear_status_bar(self) -> None:
        self.set_status_bar("", spinning=False)

    def _tab_ids(self) -> list[str]:
        tabs = ["agents", "config"]
        if self.dev:
            tabs.extend(["watcher", "worker"])
        return tabs

    def on_mount(self) -> None:
        """Apply dashboard theme based on saved preference."""
        logger.info("on_mount() started")
        try:
            self._quit_confirm_deadline: float | None = None
            try:
                loop = asyncio.get_running_loop()
                self._diagnostics.install_asyncio_exception_handler(loop)
            except Exception:
                pass

            # Start local API server for one-click browser import
            self._start_local_api_server()

            # Set up side-by-side layout for native terminal mode
            if self._native_terminal_mode:
                self._setup_native_terminal_layout()

            # Watchdog: capture snapshots for intermittent blank/stuck UI issues.
            if self._watchdog_timer is None:
                self._watchdog_timer = self.set_interval(5.0, self._watchdog_check)

            logger.info("on_mount() completed successfully")
        except Exception as e:
            logger.error(f"on_mount() failed: {e}\n{traceback.format_exc()}")
            raise

    def on_resize(self) -> None:
        """Keep the tmux outer layout stable when the terminal is resized."""
        if self._native_terminal_mode:
            return

        # Debounce: terminal resize can generate many events; keep the UI responsive.
        try:
            if self._tmux_width_timer is not None:
                try:
                    self._tmux_width_timer.stop()
                except Exception:
                    pass
            self._tmux_width_timer = self.set_timer(0.05, self._enforce_tmux_dashboard_width)
        except Exception:
            return

    def _enforce_tmux_dashboard_width(self) -> None:
        try:
            from . import tmux_manager

            tmux_manager.enforce_outer_dashboard_pane_width()
        except Exception:
            return

    def on_unmount(self) -> None:
        try:
            self._diagnostics.event("dashboard_unmount")
        except Exception:
            pass

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        if event.state != WorkerState.ERROR:
            return
        try:
            worker = event.worker
            err = getattr(worker, "error", None)
            if isinstance(err, BaseException):
                self._diagnostics.exception(
                    "worker_error",
                    err,
                    worker_name=str(getattr(worker, "name", "") or ""),
                    worker_group=str(getattr(worker, "group", "") or ""),
                    worker_state=str(event.state),
                )
            else:
                self._diagnostics.event(
                    "worker_error",
                    error=str(err),
                    worker_name=str(getattr(worker, "name", "") or ""),
                    worker_group=str(getattr(worker, "group", "") or ""),
                    worker_state=str(event.state),
                )
        except Exception:
            return

    def _watchdog_check(self) -> None:
        """Lightweight watchdog to detect UI blanking and missing panes."""
        try:
            panel = self.query_one(AgentsPanel)
            state = panel.diagnostics_state()
            agents_count = int(state.get("agents_count", 0) or 0)
            children = int(state.get("agents_list_children", 1) or 0)
            if agents_count > 0 and children == 0:
                self._diagnostics.snapshot(reason="agents_panel_blank", app=self, agents_panel=state)
                panel.force_render(reason="watchdog_blank")
        except Exception:
            pass

        # Only relevant for tmux mode.
        if self._native_terminal_mode:
            return
        try:
            from . import tmux_manager

            panes = tmux_manager.list_outer_panes(timeout_s=0.2)
            if panes and len(panes) < 2:
                try:
                    tmux_state = tmux_manager.collect_tmux_debug_state()
                except Exception:
                    tmux_state = {}
                self._diagnostics.snapshot(
                    reason="tmux_outer_missing_right_pane",
                    app=self,
                    tmux_state=tmux_state,
                )
                try:
                    tmux_manager.ensure_right_pane_ready()
                except Exception:
                    pass
            else:
                pane1_cmd = ""
                for ln in panes:
                    parts = ln.split("\t")
                    if parts and parts[0] == "1":
                        pane1_cmd = parts[2] if len(parts) > 2 else ""
                        break
                if pane1_cmd and pane1_cmd != "tmux":
                    try:
                        tmux_state = tmux_manager.collect_tmux_debug_state()
                    except Exception:
                        tmux_state = {}
                    self._diagnostics.snapshot(
                        reason="tmux_right_pane_not_attached",
                        app=self,
                        pane1_current_command=pane1_cmd,
                        tmux_state=tmux_state,
                    )
                    try:
                        tmux_manager.ensure_right_pane_ready()
                    except Exception:
                        pass
        except Exception:
            pass

    def _start_local_api_server(self) -> None:
        """Start the local HTTP API server for browser-based agent import."""
        try:
            from ..config import ReAlignConfig
            from .local_api import LocalAPIServer

            config = ReAlignConfig.load()
            self._local_api_server = LocalAPIServer(port=config.local_api_port)
            self._local_api_server.start()
        except Exception as e:
            logger.warning(f"Could not start local API server: {e}")

    def _apply_saved_theme(self) -> None:
        theme_choice = str(get_dashboard_state_value("theme", "dark")).strip().lower()
        if theme_choice == "light":
            self.theme = "textual-light"
        else:
            self.theme = "textual-dark"

    def _setup_native_terminal_layout(self) -> None:
        """Set up side-by-side layout for Dashboard and native terminal."""
        # Skip if using iTerm2 split pane mode (already set up by CLI)
        if os.environ.get("ALINE_ITERM2_RIGHT_PANE"):
            logger.info("Using iTerm2 split pane mode, skipping window layout")
            return

        try:
            from .layout import setup_side_by_side_layout

            # Determine the target terminal app
            mode = os.environ.get(ENV_TERMINAL_MODE, "").strip().lower()
            if mode == "kitty":
                terminal_app = "Kitty"
            else:
                terminal_app = "iTerm2"

            # Set up side-by-side layout (Dashboard on left, terminal on right)
            success = setup_side_by_side_layout(
                terminal_app=terminal_app,
                dashboard_on_left=True,
                dashboard_width_percent=40,  # Dashboard takes 40%, terminal takes 60%
            )

            if success:
                logger.info(f"Set up side-by-side layout with {terminal_app}")
            else:
                logger.warning("Failed to set up side-by-side layout")
        except Exception as e:
            logger.warning(f"Could not set up native terminal layout: {e}")

    def action_next_tab(self) -> None:
        """Switch to next tab."""
        tabbed_content = self.query_one(TabbedContent)
        tabs = self._tab_ids()
        current = tabbed_content.active
        if current in tabs:
            idx = tabs.index(current)
            next_idx = (idx + 1) % len(tabs)
            tabbed_content.active = tabs[next_idx]

    def action_prev_tab(self) -> None:
        """Switch to previous tab."""
        tabbed_content = self.query_one(TabbedContent)
        tabs = self._tab_ids()
        current = tabbed_content.active
        if current in tabs:
            idx = tabs.index(current)
            prev_idx = (idx - 1) % len(tabs)
            tabbed_content.active = tabs[prev_idx]

    async def action_refresh(self) -> None:
        """Refresh the current tab."""
        try:
            self._diagnostics.event("action_refresh")
        except Exception:
            pass
        tabbed_content = self.query_one(TabbedContent)
        active_tab_id = tabbed_content.active

        if active_tab_id == "agents":
            self.query_one(AgentsPanel).refresh_data()
        elif active_tab_id == "config":
            self.query_one(ConfigPanel).refresh_data()
        elif active_tab_id == "watcher" and self.dev:
            self.query_one(WatcherPanel).refresh_data()
        elif active_tab_id == "worker" and self.dev:
            self.query_one(WorkerPanel).refresh_data()

    def action_help(self) -> None:
        """Show help information."""
        from .screens import HelpScreen

        self.push_screen(HelpScreen())

    def action_dump_diagnostics(self) -> None:
        try:
            self._diagnostics.snapshot(reason="manual_dump", app=self)
            path = self._diagnostics.path
            if path:
                self.notify(f"Diagnostics written: {path}", title="Diagnostics", timeout=4)
            else:
                self.notify("Diagnostics written to stderr (no log dir)", title="Diagnostics", timeout=4)
        except Exception as e:
            self.notify(f"Diagnostics failed: {e}", title="Diagnostics", severity="error", timeout=4)

    def action_quit_confirm(self) -> None:
        """Quit only when Ctrl+C is pressed twice quickly."""
        now = _monotonic()
        deadline = self._quit_confirm_deadline
        if deadline is not None and now <= deadline:
            self.exit()
            return

        self._quit_confirm_deadline = now + self._quit_confirm_window_s
        self.notify("Press Ctrl+C again to quit", title="Quit", timeout=2)


def run_dashboard(use_native_terminal: bool | None = None) -> None:
    """Run the Aline Dashboard.

    Args:
        use_native_terminal: If True, use native terminal backend (iTerm2/Kitty).
                             If False, use tmux.
                             If None (default), auto-detect from ALINE_TERMINAL_MODE env var.
    """
    logger.info("Starting Aline Dashboard")
    try:
        app = AlineDashboard(use_native_terminal=use_native_terminal)
        app.run()
        logger.info("Aline Dashboard exited normally")
    except Exception as e:
        logger.error(f"Dashboard crashed: {e}\n{traceback.format_exc()}")
        raise


if __name__ == "__main__":
    run_dashboard()
