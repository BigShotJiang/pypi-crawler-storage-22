"""Event maintenance utilities."""
