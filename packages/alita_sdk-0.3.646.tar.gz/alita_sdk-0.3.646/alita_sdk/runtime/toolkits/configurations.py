from alita_sdk.configurations import get_configurations as alita_configurations

def get_configurations():
    return alita_configurations()
