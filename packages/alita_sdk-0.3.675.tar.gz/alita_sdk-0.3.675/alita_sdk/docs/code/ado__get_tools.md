# ado - get_tools

**Toolkit**: `ado`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsReposToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
