# ado_repos - list_open_pull_requests

**Toolkit**: `ado_repos`
**Method**: `list_open_pull_requests`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def list_open_pull_requests(self) -> str:
        """
        Fetches all open pull requests from the Azure DevOps repository.

        Returns:
            str: A plaintext report containing the number of PRs
            and each PR's title and ID.
        """
        try:
            pull_requests = self._client.get_pull_requests(
                repository_id=self.repository_id,
                search_criteria=GitPullRequestSearchCriteria(
                    repository_id=self.repository_id, status="active"
                ),
                project=self.project,
            )
        except Exception as e:
            msg = f"Error during attempt to get active pull request: {str(e)}"
            logger.error(msg)
            return ToolException(msg)

        if pull_requests:
            parsed_prs = self.parse_pull_requests(pull_requests)
            parsed_prs_str = (
                    "Found "
                    + str(len(parsed_prs))
                    + " open pull requests:\n"
                    + str(parsed_prs)
            )
            return parsed_prs_str
        else:
            return "No open pull requests available"
```

## Helper Methods

```python
Helper: parse_pull_requests
    def parse_pull_requests(
            self, pull_requests: Union[GitPullRequest, List[GitPullRequest]]
    ) -> List[dict]:
        """
        Extracts title and number from each Pull Request and puts them in a dictionary
        Parameters:
            issues(List[GitPullRequest]): A list of ADO Repos  GitPullRequest objects
        Returns:
            List[dict]: A dictionary of Pull Request titles and numbers
        """
        if not isinstance(pull_requests, list):
            pull_requests = [pull_requests]

        parsed = []
        try:
            for pull_request in pull_requests:
                comment_threads: List[GitPullRequestCommentThread] = (
                    self._client.get_threads(
                        repository_id=self.repository_id,
                        pull_request_id=pull_request.pull_request_id,
                        project=self.project,
                    )
                )

                commits: List[GitCommitRef] = self._client.get_pull_request_commits(
                    repository_id=self.repository_id,
                    project=self.project,
                    pull_request_id=pull_request.pull_request_id,
                )

                commit_details = [
                    {"commit_id": commit.commit_id, "comment": commit.comment}
                    for commit in commits
                ]

                parsed.append(
                    {
                        "title": pull_request.title,
                        "pull_request_id": pull_request.pull_request_id,
                        "commits": commit_details,
                        "comments": self.parse_pull_request_comments(comment_threads),
                        "source_branch": pull_request.source_ref_name,
                        "target_branch": pull_request.target_ref_name,
                    }
                )
        except Exception as e:
            msg = f"Failed to parse pull requests. Error: {str(e)}"
            logger.error(msg)
            return ToolException(msg)

        return parsed
```
