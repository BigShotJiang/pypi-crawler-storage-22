# carrier - extract_application_name

**Toolkit**: `carrier`
**Method**: `extract_application_name`
**Source File**: `lighthouse_excel_reporter.py`

---

## Method Implementation

```python
def extract_application_name(url):
    parsed_url = urlparse(url)
    hostname_parts = parsed_url.hostname.split('.') if parsed_url.hostname else []
    application_name = hostname_parts[0] if len(hostname_parts) > 1 else '3rd-party'
    return application_name
```
