# custom_open_api - invoke_rest_api_by_spec

**Toolkit**: `custom_open_api`
**Method**: `invoke_rest_api_by_spec`
**Source File**: `api_wrapper.py`
**Class**: `OpenApiWrapper`

---

## Method Implementation

```python
    def invoke_rest_api_by_spec(self, method: str, url: str, headers: str = "", fields: str = "", body: str = "") -> str:
        """
        Use this tool to invoke external API according to OpenAPI specification.
        If you do not have specification, retrieve it first by using another tool.
        All provided arguments must be in STRING format.
        You must provide the following required args: method: String, url: String.
        Other args are optional: fields: String, body: String.
        IMPORTANT: "fields" MUST be String text, example "fields": "{'param1': 'value'}"
        """
        encoded_data = body.encode('utf-8') if body else None
        headers_param = parse_to_dict(headers) if headers else {}
        fields_param = parse_to_dict(fields) if fields else None

        if self.api_key:
            headers_param['Authorization'] = "Bearer " + self.api_key

        response = self._client.request(method=method, url=url, fields=fields_param, headers=headers_param,
                                        body=encoded_data)
        return response.data.decode('utf-8')
```

## Helper Methods

```python
Helper: parse_to_dict
def parse_to_dict(input_string):
    try:
        # Try parsing it directly first, in case the string is already in correct JSON format
        parsed_dict = json.loads(input_string)
    except json.JSONDecodeError:
        # If that fails, replace single quotes with double quotes
        # and escape existing double quotes
        try:
            # This will convert single quotes to double quotes and escape existing double quotes
            adjusted_string = input_string.replace('\'', '\"').replace('\"', '\\\"')
            # If the above line replaces already correct double quotes, we correct them back
            adjusted_string = adjusted_string.replace('\\\"{', '\"{').replace('}\\\"', '}\"')
            # Now try to parse the adjusted string
            parsed_dict = json.loads(adjusted_string)
        except json.JSONDecodeError as e:
            # Handle any JSON errors
            print("JSON decode error:", e)
            return None
    return parsed_dict
```
