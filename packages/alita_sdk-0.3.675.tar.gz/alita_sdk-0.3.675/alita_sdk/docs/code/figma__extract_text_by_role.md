# figma - extract_text_by_role

**Toolkit**: `figma`
**Method**: `extract_text_by_role`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def extract_text_by_role(
    node: Dict,
    depth: int = 0,
    max_depth: int = 10,
    parent_context: str = ''
) -> Dict[str, List[str]]:
    """
    Recursively extract text content categorized by likely role.

    Improved categorization:
    - Uses font size, weight, and style for heading detection
    - Considers parent container names for context
    - Deduplicates and cleans text
    - Filters out placeholder/system text

    Returns:
        {
            'headings': [...],  # Large/bold text, titles
            'labels': [...],    # Form labels, field names, small descriptive text
            'buttons': [...],   # Text inside interactive elements
            'body': [...],      # Regular body/paragraph text
            'errors': [...],    # Error messages (red text, error containers)
            'placeholders': [...],  # Placeholder/hint text (gray, placeholder in name)
        }
    """
    if depth > max_depth:
        return {'headings': [], 'labels': [], 'buttons': [], 'body': [], 'errors': [], 'placeholders': []}

    result = {'headings': [], 'labels': [], 'buttons': [], 'body': [], 'errors': [], 'placeholders': []}

    node_type = node.get('type', '').upper()
    node_name = node.get('name', '').lower()

    # Build context path for children
    current_context = f"{parent_context}/{node_name}" if parent_context else node_name

    if node_type == 'TEXT':
        text = node.get('characters', '').strip()
        if not text:
            return result

        # Skip very short text that's likely icons or separators
        if len(text) <= 1 and text not in ['?', '!']:
            return result

        # Skip obvious system/template text
        skip_patterns = ['lorem ipsum', 'placeholder', '{{', '}}', 'xxx', '000']
        if any(p in text.lower() for p in skip_patterns):
            return result

        # Get text style info
        style = node.get('style', {})
        font_size = style.get('fontSize', 14)
        font_weight = style.get('fontWeight', 400)
        text_decoration = style.get('textDecoration', '')

        # Check fills for color-based categorization
        fills = node.get('fills', [])
        is_red = any(
            f.get('type') == 'SOLID' and
            f.get('color', {}).get('r', 0) > 0.7 and
            f.get('color', {}).get('g', 0) < 0.3 and
            f.get('color', {}).get('b', 0) < 0.3
            for f in fills if isinstance(f, dict)
        )
        is_gray = any(
            f.get('type') == 'SOLID' and
            abs(f.get('color', {}).get('r', 0) - f.get('color', {}).get('g', 0)) < 0.1 and
            f.get('color', {}).get('r', 0) > 0.4 and
            f.get('color', {}).get('r', 0) < 0.7
            for f in fills if isinstance(f, dict)
        )

        # Categorize based on multiple signals
        # Priority: error > placeholder > heading > label > body

        # Error detection
        if is_red or 'error' in node_name or 'error' in current_context:
            result['errors'].append(text)
        # Placeholder detection
        elif is_gray or 'placeholder' in node_name or 'hint' in node_name:
            result['placeholders'].append(text)
        # Heading detection (large, bold, or semantically marked)
        elif (font_size >= 18 or
              font_weight >= 600 or
              any(h in node_name for h in ['heading', 'title', 'header', 'h1', 'h2', 'h3'])):
            result['headings'].append(text)
        # Label detection (small text, form context, specific naming)
        elif (font_size <= 12 or
              'label' in node_name or
              'caption' in node_name or
              any(ctx in current_context for ctx in ['form', 'input', 'field'])):
            result['labels'].append(text)
        # Everything else is body text
        else:
            result['body'].append(text)

    # Check if this is an interactive element
    is_button = (
        node_type in ['INSTANCE', 'COMPONENT', 'FRAME'] and
        any(kw in node_name for kw in ['button', 'btn', 'cta', 'action', 'link', 'tab', 'chip'])
    )
    is_input = (
        node_type in ['INSTANCE', 'COMPONENT', 'FRAME'] and
        any(kw in node_name for kw in ['input', 'textfield', 'textarea', 'dropdown', 'select'])
    )

    # Recurse into children
    for child in node.get('children', []):
        child_result = extract_text_by_role(child, depth + 1, max_depth, current_context)

        if is_button:
            # All text inside buttons goes to buttons category
            for texts in child_result.values():
                result['buttons'].extend(texts)
        elif is_input:
            # Input text goes to placeholders if gray, otherwise labels
            result['placeholders'].extend(child_result.get('placeholders', []))
            # Other text becomes labels (field values shown)
            for key in ['headings', 'labels', 'body']:
                result['labels'].extend(child_result.get(key, []))
            result['errors'].extend(child_result.get('errors', []))
        else:
            for key in result:
                result[key].extend(child_result.get(key, []))

    return result
```
