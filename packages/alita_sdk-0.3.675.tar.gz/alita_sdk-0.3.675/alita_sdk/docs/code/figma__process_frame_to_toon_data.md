# figma - process_frame_to_toon_data

**Toolkit**: `figma`
**Method**: `process_frame_to_toon_data`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def process_frame_to_toon_data(frame_node: Dict) -> Dict:
    """
    Process a Figma frame node into TOON-ready data structure.

    Returns structured data that can be serialized to TOON format.
    """
    name = frame_node.get('name', 'Untitled')

    # Extract position and size
    bounds = frame_node.get('absoluteBoundingBox', {})
    position = {'x': bounds.get('x', 0), 'y': bounds.get('y', 0)}
    size = {'w': bounds.get('width', 0), 'h': bounds.get('height', 0)}

    # Extract text by role
    text_data = extract_text_by_role(frame_node)

    # Extract components
    components = extract_components(frame_node)

    # Extract input fields
    inputs = extract_inputs(frame_node)
    # Dedupe inputs by name
    seen_inputs = set()
    unique_inputs = []
    for inp in inputs:
        if inp['name'] not in seen_inputs:
            seen_inputs.add(inp['name'])
            unique_inputs.append(inp)

    # Build frame data with deduplication
    frame_data = {
        'id': frame_node.get('id', ''),
        'name': name,
        'position': position,
        'size': size,
        # Deduplicate and limit text fields
        'headings': dedupe_and_clean_text(text_data['headings'], max_items=5),
        'labels': dedupe_and_clean_text(text_data['labels'], max_items=15),
        'buttons': dedupe_and_clean_text(text_data['buttons'], max_items=10),
        'inputs': unique_inputs[:10],  # Limit to 10 inputs
        'body': dedupe_and_clean_text(text_data['body'], max_items=10),
        'errors': dedupe_and_clean_text(text_data['errors'], max_items=5),
        'placeholders': dedupe_and_clean_text(text_data.get('placeholders', []), max_items=5),
        'components': list(dict.fromkeys(components))[:15],  # Dedupe components too
    }

    # Infer type and state
    frame_data['type'] = infer_screen_type(frame_data)
    frame_data['state'] = infer_state_from_name(name)

    # Check if variant
    base_name = extract_base_name(name)
    if base_name != name:
        frame_data['variant_of'] = base_name

    return frame_data
```

## Helper Methods

```python
Helper: infer_state_from_name
def infer_state_from_name(name: str) -> str:
    """
    Infer screen state from name.

    Returns: default, error, success, loading, empty, or the detected state
    """
    name_lower = name.lower()

    state_keywords = {
        'error': ['error', 'fail', 'invalid', 'wrong'],
        'success': ['success', 'complete', 'done', 'confirmed'],
        'loading': ['loading', 'progress', 'spinner', 'wait'],
        'empty': ['empty', 'no data', 'no results', 'blank'],
        'disabled': ['disabled', 'inactive', 'locked'],
    }

    for state, keywords in state_keywords.items():
        if any(kw in name_lower for kw in keywords):
            return state

    return 'default'
```

```python
Helper: infer_screen_type
def infer_screen_type(frame_data: Dict) -> str:
    """
    Infer screen type from content.

    Returns: form, list, detail, dashboard, modal, menu, settings, chat, etc.
    """
    name_lower = frame_data.get('name', '').lower()
    components = frame_data.get('components', [])
    buttons = frame_data.get('buttons', [])
    labels = frame_data.get('labels', [])

    components_lower = [c.lower() for c in components]
    buttons_lower = [b.lower() for b in buttons]

    # Check name hints
    type_hints = {
        'form': ['login', 'signup', 'register', 'checkout', 'payment', 'form', 'input'],
        'list': ['list', 'feed', 'timeline', 'results', 'search results'],
        'detail': ['detail', 'profile', 'item', 'product', 'article'],
        'dashboard': ['dashboard', 'home', 'overview', 'summary'],
        'modal': ['modal', 'dialog', 'popup', 'overlay', 'alert'],
        'menu': ['menu', 'navigation', 'sidebar', 'drawer'],
        'settings': ['settings', 'preferences', 'config', 'options'],
        'chat': ['chat', 'message', 'conversation', 'inbox'],
        'onboarding': ['onboarding', 'welcome', 'intro', 'tutorial'],
    }

    for screen_type, keywords in type_hints.items():
        if any(kw in name_lower for kw in keywords):
            return screen_type

    # Check components
    if any('input' in c or 'textfield' in c or 'form' in c for c in components_lower):
        return 'form'
    if any('card' in c or 'listitem' in c for c in components_lower):
        return 'list'
    if any('modal' in c or 'dialog' in c for c in components_lower):
        return 'modal'

    # Check buttons for form indicators
    form_buttons = ['submit', 'save', 'sign in', 'log in', 'register', 'next', 'continue']
    if any(any(fb in b for fb in form_buttons) for b in buttons_lower):
        return 'form'

    return 'screen'  # Generic fallback
```
