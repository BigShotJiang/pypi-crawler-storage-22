# figma - serialize_file

**Toolkit**: `figma`
**Method**: `serialize_file`
**Source File**: `toon_tools.py`
**Class**: `TOONSerializer`

---

## Method Implementation

```python
    def serialize_file(self, file_data: Dict) -> str:
        """
        Serialize entire file structure to TOON format.

        Expected input:
        {
            'name': 'File Name',
            'key': 'abc123',
            'pages': [...]
        }
        """
        lines = []

        # File header
        name = file_data.get('name', 'Untitled')
        key = file_data.get('key', '')
        lines.append(f"FILE: {name} [key:{key}]")

        # Pages
        for page in file_data.get('pages', []):
            lines.extend(self.serialize_page(page, level=1))

        # Global flow analysis
        all_frames = []
        for page in file_data.get('pages', []):
            all_frames.extend(page.get('frames', []))

        flow_lines = self.serialize_flows(all_frames, level=1)
        if flow_lines:
            lines.append(f"{self._i(1)}FLOWS:")
            lines.extend(flow_lines)

        return '\n'.join(lines)
```

## Helper Methods

```python
Helper: serialize_flows
    def serialize_flows(self, frames: List[Dict], level: int = 0) -> List[str]:
        """Generate flow analysis section with semantic insights."""
        lines = []

        # Entry/exit points
        points = infer_entry_exit_points(frames)
        if points['entry']:
            lines.append(f"{self._i(level + 1)}entry_points: {', '.join(points['entry'])}")
        if points['exit']:
            lines.append(f"{self._i(level + 1)}exit_points: {', '.join(points['exit'])}")

        # Detect user journeys (grouped by purpose)
        journeys = detect_user_journeys(frames)
        for journey_name, journey_frames in journeys.items():
            if journey_frames:
                # Format: journey_name: Frame1 > Frame2 or Frame1 (×3) if repeated
                frame_names = [f['name'] for f in journey_frames[:10]]  # Limit to 10
                journey_str = _dedupe_frame_sequence(frame_names)
                lines.append(f"{self._i(level + 1)}{journey_name}: {journey_str}")

        # Detect sequences (numbered frames suggesting flow order)
        sequences = detect_sequences(frames)
        for seq in sequences:
            # Use dedupe to handle repeated names
            seq_str = _dedupe_frame_sequence(list(seq))
            # Skip if already covered by a journey (check deduped version)
            if not any(seq_str in line for line in lines):
                lines.append(f"{self._i(level + 1)}sequence: {seq_str}")

        # Detect variants (frames that are states of the same screen)
        variants = group_variants(frames)
        for base, variant_list in variants.items():
            if len(variant_list) > 1:
                # Format: base (N variants: state1, state2, state3)
                states = [v.get('state', 'default') for v in variant_list]
                unique_states = list(dict.fromkeys(states))  # Preserve order, dedupe
                count = len(variant_list)
                states_str = ', '.join(unique_states[:5])  # Limit to 5 states
                lines.append(f"{self._i(level + 1)}variants: {base} ({count} variants: {states_str})")

        # Extract CTA destinations with context awareness
        cta_by_category = {}  # Group CTAs by destination category
        for frame in frames:
            frame_name = frame.get('name', '')
            for btn in frame.get('buttons', []):
                btn_text = btn if isinstance(btn, str) else btn.get('text', '')
                if btn_text:
                    dest = infer_cta_destination(btn_text, frame_context=frame_name)
                    if dest:  # None means filtered out (icons, etc.)
                        # Group by destination category for cleaner output
                        if dest not in cta_by_category:
                            cta_by_category[dest] = set()
                        cta_by_category[dest].add(btn_text)

        # Format CTAs grouped by action type
        if cta_by_category:
            # Primary actions first
            priority_order = ['authenticate', 'register', 'submit_form', 'save', 'pay',
                            'navigate_next', 'create', 'view_detail']
            sorted_categories = sorted(cta_by_category.keys(),
                key=lambda x: priority_order.index(x) if x in priority_order else 100)

            cta_strs = []
            for cat in sorted_categories[:8]:  # Limit to 8 categories
                buttons = list(cta_by_category[cat])[:3]  # Max 3 buttons per category
                if cat.startswith('do:'):
                    # Custom action - show as-is
                    cta_strs.append(f'"{buttons[0]}"')
                else:
                    # Known category
                    cta_strs.append(f'{", ".join(buttons)} > {cat}')
            lines.append(f"{self._i(level + 1)}actions: {' | '.join(cta_strs)}")

        return lines
```

```python
Helper: serialize_page
    def serialize_page(self, page_data: Dict, level: int = 0, dedupe_variants: bool = True) -> List[str]:
        """
        Serialize a single page.

        Args:
            page_data: Page data dict
            level: Indentation level
            dedupe_variants: If True, group variants and show only deltas (default True)
        """
        lines = []

        name = page_data.get('name', 'Untitled Page')
        page_id = page_data.get('id', '')
        id_str = f" #{page_id}" if page_id else ''
        lines.append(f"{self._i(level)}PAGE: {name}{id_str}")

        frames = page_data.get('frames', [])

        if dedupe_variants and len(frames) > 1:
            # Get variant groups with deltas
            variant_groups = get_variant_groups_with_deltas(frames)

            # Track which frames are in variant groups (to avoid double-output)
            variant_frame_ids = set()
            for group in variant_groups:
                variant_frame_ids.add(group['base_frame'].get('id', ''))
                for v in group['variants']:
                    variant_frame_ids.add(v.get('id', ''))

            # Output non-variant frames normally
            for frame in frames:
                if frame.get('id', '') not in variant_frame_ids:
                    lines.extend(self.serialize_frame(frame, level + 1))

            # Output variant groups with deduplication
            for group in variant_groups:
                lines.extend(self.serialize_variant_group(group, level + 1))
        else:
            # No deduplication - output all frames
            for frame in frames:
                lines.extend(self.serialize_frame(frame, level + 1))

        return lines
```
