# figma - serialize_file_with_llm_explanations

**Toolkit**: `figma`
**Method**: `serialize_file_with_llm_explanations`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def serialize_file_with_llm_explanations(
    file_data: Dict,
    llm: Any,
    frame_images: Optional[Dict[str, str]] = None,
    max_frames_to_analyze: int = 50,
    status_callback: Optional[Callable[[str], None]] = None,
    parallel_workers: int = 5,
    include_design_insights: bool = True,
) -> str:
    """
    Serialize file with LLM explanations merged inline with each FRAME.

    Supports vision-based analysis when frame_images dict is provided.
    Uses parallel LLM processing for faster analysis.
    Output uses visual insights instead of element mappings.

    Args:
        file_data: Processed file data dict
        llm: LangChain LLM instance
        frame_images: Optional dict mapping frame_id -> image_url for vision analysis
        max_frames_to_analyze: Maximum frames to analyze with LLM (default 50)
        status_callback: Optional callback function for progress updates
        parallel_workers: Number of parallel LLM workers (default 5)
        include_design_insights: Whether to include DESIGN INSIGHTS section (default True)

    Output format:
    FILE: Name [key:xxx]
      PAGE: Page Name #id
        FRAME: Frame Name [pos] type/state #id
          Purpose: Authentication screen for returning users
          Goal: Sign into account | Action: "Sign In"
          Visual: [focus] title and form | [layout] form-stack | [state] default
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    def _log_status(msg: str):
        """Log status via callback if provided."""
        logging.info(msg)
        if status_callback:
            try:
                status_callback(msg)
            except Exception:
                pass  # Don't let callback failures break processing

    lines = []
    serializer = TOONSerializer()
    frame_images = frame_images or {}

    # File header
    name = file_data.get('name', 'Untitled')
    key = file_data.get('key', '')
    lines.append(f"FILE: {name} [key:{key}]")

    # Collect all frames first for parallel processing
    all_frames = []
    frame_to_page = {}  # Map frame_id to page info for later

    for page in file_data.get('pages', []):
        for frame in page.get('frames', []):
            all_frames.append(frame)
            frame_to_page[frame.get('id', '')] = {
                'page_name': page.get('name', 'Untitled Page'),
                'page_id': page.get('id', ''),
            }

    total_frames = len(all_frames)
    frames_to_analyze = all_frames[:max_frames_to_analyze]
    _log_status(f"Starting LLM analysis for {len(frames_to_analyze)} of {total_frames} frames...")

    # Parallel LLM analysis
    frame_explanations = {}  # frame_id -> explanation

    def _analyze_single_frame(frame: Dict) -> Tuple[str, Optional[Any]]:
        """Worker function to analyze a single frame."""
        frame_id = frame.get('id', '')
        image_url = frame_images.get(frame_id)
        try:
            explanation = analyze_frame_with_llm(
                frame, llm, serializer, image_url=image_url
            )
            return frame_id, explanation
        except Exception as e:
            logging.warning(f"LLM analysis failed for frame {frame.get('name')}: {e}")
            return frame_id, None

    # Use parallel processing for LLM calls
    if frames_to_analyze:
        workers = min(parallel_workers, len(frames_to_analyze))
        _log_status(f"Analyzing frames with {workers} parallel LLM workers...")
        completed = 0

        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_frame = {
                executor.submit(_analyze_single_frame, frame): frame
                for frame in frames_to_analyze
            }

            for future in as_completed(future_to_frame):
                frame = future_to_frame[future]
                frame_name = frame.get('name', 'Untitled')
                try:
                    frame_id, explanation = future.result()
                    if explanation:
                        frame_explanations[frame_id] = explanation
                        _log_status(f"Analyzed {completed + 1}/{len(frames_to_analyze)}: {frame_name} ✓")
                    else:
                        _log_status(f"Analyzed {completed + 1}/{len(frames_to_analyze)}: {frame_name} (no result)")
                    completed += 1
                except Exception as e:
                    completed += 1
                    logging.warning(f"Frame analysis failed for {frame_name}: {e}")
                    _log_status(f"Analyzed {completed}/{len(frames_to_analyze)}: {frame_name} (error: {type(e).__name__})")

    # Summary of LLM analysis results
    success_count = len(frame_explanations)
    _log_status(f"Frame analysis complete: {success_count}/{len(frames_to_analyze)} frames analyzed successfully")

    # Now generate output with pre-computed explanations
    for page in file_data.get('pages', []):
        page_name = page.get('name', 'Untitled Page')
        page_id = page.get('id', '')
        lines.append(f"  PAGE: {page_name} #{page_id}")

        for frame in page.get('frames', []):
            frame_name = frame.get('name', 'Untitled')
            frame_id = frame.get('id', '')
            frame_type = frame.get('type', 'screen')
            frame_state = frame.get('state', 'default')

            # Compact frame header
            pos = frame.get('position', {})
            size = frame.get('size', {})
            pos_str = f"[{int(pos.get('x', 0))},{int(pos.get('y', 0))} {int(size.get('w', 0))}x{int(size.get('h', 0))}]"
            lines.append(f"    FRAME: {frame_name} {pos_str} {frame_type}/{frame_state} #{frame_id}")

            # Get frame content
            headings = frame.get('headings', [])
            buttons = frame.get('buttons', []).copy()  # Copy to allow modification
            inputs = frame.get('inputs', [])
            primary_action = None  # Track LLM-identified action

            # LLM analysis from pre-computed results
            explanation = frame_explanations.get(frame_id)
            if explanation:
                lines.append(f"      Purpose: {explanation.purpose}")
                goal_action = f"Goal: {explanation.user_goal}"
                if explanation.primary_action:
                    primary_action = explanation.primary_action
                    goal_action += f" | Action: \"{primary_action}\""
                lines.append(f"      {goal_action}")

                # Visual insights
                visual_parts = []
                if explanation.visual_focus:
                    visual_parts.append(f"[focus] {explanation.visual_focus}")
                if explanation.layout_pattern:
                    visual_parts.append(f"[layout] {explanation.layout_pattern}")
                if explanation.visual_state and explanation.visual_state != 'default':
                    visual_parts.append(f"[state] {explanation.visual_state}")
                if visual_parts:
                    lines.append(f"      Visual: {' | '.join(visual_parts)}")

            # Ensure primary_action from LLM appears in buttons (button completeness)
            if primary_action:
                # Check if action is already in buttons (case-insensitive)
                buttons_lower = [b.lower() for b in buttons]
                action_lower = primary_action.lower()
                if not any(action_lower in b or b in action_lower for b in buttons_lower):
                    # Add the LLM-identified action to buttons list
                    buttons.insert(0, f"[LLM] {primary_action}")

            # Use LLM-extracted inputs if available (preferred), else fall back to heuristic
            llm_inputs = []
            if explanation and hasattr(explanation, 'inputs') and explanation.inputs:
                llm_inputs = explanation.inputs

            # Extracted content (Headings, Buttons, Inputs)
            if headings:
                lines.append(f"      Headings: {' | '.join(headings[:3])}")
            if buttons:
                # Show buttons with inferred actions
                btn_strs = []
                for btn in buttons[:6]:  # Increased limit to accommodate added LLM action
                    dest = infer_cta_destination(btn, frame_context=frame_name)
                    btn_strs.append(f"{btn} > {dest}" if dest else btn)
                lines.append(f"      Buttons: {' | '.join(btn_strs)}")

            # Prefer LLM-extracted inputs over heuristic extraction (standardized format)
            if llm_inputs:
                # Convert LLM ExtractedInput objects to dicts for standardized formatting
                llm_inputs_dicts = [
                    {
                        'name': inp.label,
                        'type': inp.input_type,
                        'required': inp.required,
                        'value': inp.current_value,
                        'options': inp.options,
                    }
                    for inp in llm_inputs
                ]
                inputs_str = format_inputs_list(llm_inputs_dicts)
                if inputs_str:
                    lines.append(f"      Inputs: {inputs_str}")
            elif inputs:
                # Fallback to heuristic-extracted inputs (standardized format)
                inputs_str = format_inputs_list(inputs)
                if inputs_str:
                    lines.append(f"      Inputs: {inputs_str}")

        lines.append("")  # Blank line after page

    _log_status("Analyzing flows and variants (parallel)...")

    # Run LLM flow analysis and design insights in parallel
    flow_analysis_result = None
    design_analysis_result = None
    flow_error = None
    design_error = None

    def _analyze_flows():
        """Worker for flow analysis."""
        nonlocal flow_analysis_result, flow_error
        try:
            flow_analysis_result = analyze_flows_with_llm(all_frames, llm)
        except Exception as e:
            flow_error = e

    def _analyze_design():
        """Worker for design insights."""
        nonlocal design_analysis_result, design_error
        try:
            design_analysis_result = analyze_file_with_llm(file_data, llm)
        except Exception as e:
            design_error = e

    # Run flow analysis and optionally design insights in parallel
    if all_frames:
        parallel_tasks = [_analyze_flows]
        if include_design_insights:
            parallel_tasks.append(_analyze_design)

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(task) for task in parallel_tasks]
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    logging.warning(f"Parallel analysis task failed: {e}")

    # Add FLOWS section
    if all_frames:
        lines.append("FLOWS:")
        if flow_analysis_result:
            flow_lines = serialize_flow_analysis(flow_analysis_result, level=0)
            lines.extend(flow_lines)
        elif flow_error:
            logging.warning(f"LLM flow analysis failed, using heuristics: {flow_error}")
            flow_lines = serializer.serialize_flows(all_frames, level=0)
            lines.extend(flow_lines)
        else:
            # Fallback to heuristic flows if LLM returned nothing
            flow_lines = serializer.serialize_flows(all_frames, level=0)
            lines.extend(flow_lines)

    # Explicit VARIANTS section with frame differences (fast heuristic, no parallelization needed)
    if all_frames:
        variants = group_variants(all_frames)
        if variants:
            lines.append("")
            lines.append("VARIANTS:")
            for base, variant_list in variants.items():
                if len(variant_list) > 1:
                    # Group by states
                    states_by_id = {}
                    for v in variant_list:
                        state = v.get('state', 'default')
                        frame_id = v.get('id', '')[:6]  # Short ID
                        states_by_id[f"#{frame_id}"] = state

                    # Detect potential duplicates (same state, similar content)
                    state_groups = {}
                    for v in variant_list:
                        state = v.get('state', 'default')
                        if state not in state_groups:
                            state_groups[state] = []
                        state_groups[state].append(v)

                    # Build variant line
                    lines.append(f"  {base} ({len(variant_list)} frames):")

                    # List variants by state
                    for state, variants_in_state in state_groups.items():
                        ids = [f"#{v.get('id', '')[:6]}" for v in variants_in_state]
                        if len(variants_in_state) > 1:
                            # Potential duplicates or responsive variants
                            lines.append(f"    {state}: {', '.join(ids)} - potential duplicates or responsive")
                        else:
                            # Unique state
                            frame = variants_in_state[0].get('frame', {})
                            # Try to identify distinguishing feature
                            distinguisher = ""
                            if frame.get('headings'):
                                distinguisher = f" - \"{frame['headings'][0][:30]}...\""
                            elif frame.get('inputs'):
                                inp = frame['inputs'][0]
                                distinguisher = f" - {inp.get('type', 'text')} labeled \"{inp.get('name', '')[:20]}\""
                            lines.append(f"    {state}: {ids[0]}{distinguisher}")

    # Add DESIGN INSIGHTS section (if enabled and analysis succeeded)
    if include_design_insights:
        if design_analysis_result:
            _log_status("Adding design insights...")
            lines.append("")
            lines.append("DESIGN INSIGHTS:")
            lines.append(f"  Type: {design_analysis_result.design_type} | Target: {design_analysis_result.target_user}")
            lines.append(f"  Purpose: {design_analysis_result.overall_purpose}")
            if design_analysis_result.design_patterns:
                lines.append(f"  Patterns: {', '.join(design_analysis_result.design_patterns[:5])}")
            if design_analysis_result.gaps_or_concerns:
                lines.append(f"  Gaps: {'; '.join(design_analysis_result.gaps_or_concerns[:3])}")
        elif design_error:
            logging.warning(f"File-level LLM analysis failed: {design_error}")

    return '\n'.join(lines)
```

## Helper Methods

```python
Helper: infer_cta_destination
def infer_cta_destination(cta_text: str, frame_context: str = '') -> str:
    """
    Infer likely destination/action from CTA/button text with context awareness.

    Args:
        cta_text: The button/CTA text
        frame_context: Optional frame name for additional context

    Returns semantic action category or descriptive action based on text.
    """
    cta_lower = cta_text.lower().strip()
    context_lower = frame_context.lower() if frame_context else ''

    # Skip very short or icon-only buttons
    if len(cta_lower) < 2 or cta_lower in ['x', '+', '-', '...', '→', '←']:
        return None  # Will be filtered out

    # Semantic destination mapping with expanded keywords
    destinations = {
        'authenticate': ['sign in', 'log in', 'login', 'authenticate', 'sign-in', 'log-in'],
        'register': ['sign up', 'register', 'create account', 'join', 'get started', 'sign-up'],
        'navigate_next': ['next', 'continue', 'proceed', 'forward', 'go', 'start'],
        'navigate_back': ['back', 'previous', 'return', 'go back'],
        'cancel': ['cancel', 'nevermind', 'not now', 'maybe later', 'skip'],
        'submit_form': ['submit', 'send', 'apply', 'confirm', 'done', 'complete', 'finish', 'ok', 'okay'],
        'save': ['save', 'save changes', 'update', 'keep'],
        'view_detail': ['view', 'details', 'more', 'see more', 'read more', 'open', 'expand', 'show'],
        'search': ['search', 'find', 'look up', 'filter'],
        'settings': ['settings', 'preferences', 'options', 'configure', 'customize'],
        'help': ['help', 'support', 'faq', 'contact', 'learn more', 'how to', 'guide'],
        'share': ['share', 'invite', 'send to', 'export', 'copy link'],
        'delete': ['delete', 'remove', 'clear', 'trash', 'discard'],
        'edit': ['edit', 'modify', 'change', 'rename'],
        'create': ['add', 'create', 'new', 'plus', 'insert'],
        'close': ['close', 'dismiss', 'exit', 'hide'],
        'reset': ['reset', 'forgot password', 'recover', 'restore'],
        'download': ['download', 'export', 'get', 'install'],
        'upload': ['upload', 'import', 'attach', 'choose file'],
        'refresh': ['refresh', 'reload', 'retry', 'try again'],
        'select': ['select', 'choose', 'pick'],
        'toggle': ['enable', 'disable', 'turn on', 'turn off', 'switch'],
        'connect': ['connect', 'link', 'integrate', 'sync'],
        'pay': ['pay', 'checkout', 'purchase', 'buy', 'order', 'subscribe'],
        'upgrade': ['upgrade', 'premium', 'pro', 'unlock'],
    }

    # Try to match known categories
    for dest, keywords in destinations.items():
        if any(kw in cta_lower for kw in keywords):
            return dest

    # Context-aware inference from frame name
    if context_lower:
        if any(ctx in context_lower for ctx in ['login', 'auth', 'sign']):
            if any(w in cta_lower for w in ['submit', 'go', 'enter']):
                return 'authenticate'
        if any(ctx in context_lower for ctx in ['modal', 'dialog', 'popup']):
            return 'dismiss_modal'
        if any(ctx in context_lower for ctx in ['form', 'input', 'settings']):
            return 'submit_form'
        if any(ctx in context_lower for ctx in ['checkout', 'payment', 'cart']):
            return 'pay'

    # Return cleaned button text as action (more informative than generic 'action')
    # Clean up the text for display
    clean_text = cta_text.strip()
    if len(clean_text) <= 20:
        return f"do:{clean_text}"  # Short enough to show as-is
    return f"do:{clean_text[:17]}..."  # Truncate long text
```

```python
Helper: analyze_frame_with_llm
def analyze_frame_with_llm(
    frame_data: Dict,
    llm: Any,
    toon_serializer: Optional['TOONSerializer'] = None,
    image_url: Optional[str] = None,
) -> Optional[ScreenExplanation]:
    """
    Analyze a single frame using LLM with structured output.

    Supports vision-based analysis when image_url is provided (for multimodal LLMs).
    Falls back to text-based analysis using TOON data otherwise.

    Args:
        frame_data: Processed frame data dict
        llm: LangChain LLM instance with structured output support
        toon_serializer: Optional serializer for formatting
        image_url: Optional URL to frame image for vision-based analysis

    Returns:
        ScreenExplanation model or None if analysis fails
    """
    if not llm:
        return None

    frame_name = frame_data.get('name', 'Unknown')
    frame_id = frame_data.get('id', '')

    # Try vision-based analysis first if image available
    if image_url:
        try:
            from langchain_core.messages import HumanMessage

            structured_llm = llm.with_structured_output(ScreenExplanation)
            prompt_text = SCREEN_VISION_PROMPT.format(
                frame_name=frame_name,
                frame_id=frame_id,
            )

            # Create message with image content
            message = HumanMessage(
                content=[
                    {"type": "text", "text": prompt_text},
                    {"type": "image_url", "image_url": {"url": image_url}},
                ]
            )
            result = structured_llm.invoke([message])
            if result:
                return result
        except Exception as e:
            # Vision analysis failed - fall back to text-based
            logging.warning(f"Vision analysis failed for {frame_name}, falling back to text: {type(e).__name__}: {e}")

    # Text-based analysis (fallback or primary if no image)
    try:
        if toon_serializer is None:
            toon_serializer = TOONSerializer()

        toon_lines = toon_serializer.serialize_frame(frame_data, level=0)
        toon_data = '\n'.join(toon_lines)

        prompt = SCREEN_TEXT_PROMPT.format(
            frame_name=frame_name,
            frame_id=frame_id,
            toon_data=toon_data,
        )

        structured_llm = llm.with_structured_output(ScreenExplanation)
        result = structured_llm.invoke(prompt)
        return result

    except Exception as e:
        logging.warning(f"LLM frame analysis failed for {frame_name}: {type(e).__name__}: {e}")
        return None
```
