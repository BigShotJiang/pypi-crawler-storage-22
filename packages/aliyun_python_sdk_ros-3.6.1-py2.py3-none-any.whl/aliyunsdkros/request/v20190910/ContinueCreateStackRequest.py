# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkros.endpoint import endpoint_data

class ContinueCreateStackRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'ROS', '2019-09-10', 'ContinueCreateStack','ros')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_Mode(self): # String
		return self.get_query_params().get('Mode')

	def set_Mode(self, Mode):  # String
		self.add_query_param('Mode', Mode)
	def get_TemplateVersion(self): # String
		return self.get_query_params().get('TemplateVersion')

	def set_TemplateVersion(self, TemplateVersion):  # String
		self.add_query_param('TemplateVersion', TemplateVersion)
	def get_DryRun(self): # Boolean
		return self.get_query_params().get('DryRun')

	def set_DryRun(self, DryRun):  # Boolean
		self.add_query_param('DryRun', DryRun)
	def get_RecreatingOptionss(self): # RepeatList
		return self.get_query_params().get('RecreatingOptions')

	def set_RecreatingOptionss(self, RecreatingOptions):  # RepeatList
		for depth1 in range(len(RecreatingOptions)):
			self.add_query_param('RecreatingOptions.' + str(depth1 + 1), RecreatingOptions[depth1])
	def get_TemplateId(self): # String
		return self.get_query_params().get('TemplateId')

	def set_TemplateId(self, TemplateId):  # String
		self.add_query_param('TemplateId', TemplateId)
	def get_Parameterss(self): # RepeatList
		return self.get_query_params().get('Parameters')

	def set_Parameterss(self, Parameters):  # RepeatList
		for depth1 in range(len(Parameters)):
			if Parameters[depth1].get('ParameterValue') is not None:
				self.add_query_param('Parameters.' + str(depth1 + 1) + '.ParameterValue', Parameters[depth1].get('ParameterValue'))
			if Parameters[depth1].get('ParameterKey') is not None:
				self.add_query_param('Parameters.' + str(depth1 + 1) + '.ParameterKey', Parameters[depth1].get('ParameterKey'))
	def get_RecreatingResourcess(self): # RepeatList
		return self.get_query_params().get('RecreatingResources')

	def set_RecreatingResourcess(self, RecreatingResources):  # RepeatList
		for depth1 in range(len(RecreatingResources)):
			self.add_query_param('RecreatingResources.' + str(depth1 + 1), RecreatingResources[depth1])
	def get_TemplateBody(self): # String
		return self.get_query_params().get('TemplateBody')

	def set_TemplateBody(self, TemplateBody):  # String
		self.add_query_param('TemplateBody', TemplateBody)
	def get_StackId(self): # String
		return self.get_query_params().get('StackId')

	def set_StackId(self, StackId):  # String
		self.add_query_param('StackId', StackId)
	def get_Parallelism(self): # Long
		return self.get_query_params().get('Parallelism')

	def set_Parallelism(self, Parallelism):  # Long
		self.add_query_param('Parallelism', Parallelism)
	def get_TemplateURL(self): # String
		return self.get_query_params().get('TemplateURL')

	def set_TemplateURL(self, TemplateURL):  # String
		self.add_query_param('TemplateURL', TemplateURL)
	def get_RamRoleName(self): # String
		return self.get_query_params().get('RamRoleName')

	def set_RamRoleName(self, RamRoleName):  # String
		self.add_query_param('RamRoleName', RamRoleName)
