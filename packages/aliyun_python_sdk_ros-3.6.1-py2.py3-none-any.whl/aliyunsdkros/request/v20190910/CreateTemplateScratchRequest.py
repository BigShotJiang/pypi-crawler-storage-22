# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkros.endpoint import endpoint_data
import json

class CreateTemplateScratchRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'ROS', '2019-09-10', 'CreateTemplateScratch','ros')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_ResourceGroupId(self): # String
		return self.get_query_params().get('ResourceGroupId')

	def set_ResourceGroupId(self, ResourceGroupId):  # String
		self.add_query_param('ResourceGroupId', ResourceGroupId)
	def get_SourceResources(self): # Array
		return self.get_query_params().get('SourceResources')

	def set_SourceResources(self, SourceResources):  # Array
		self.add_query_param("SourceResources", json.dumps(SourceResources))
	def get_Tagss(self): # RepeatList
		return self.get_query_params().get('Tags')

	def set_Tagss(self, Tags):  # RepeatList
		for depth1 in range(len(Tags)):
			if Tags[depth1].get('Value') is not None:
				self.add_query_param('Tags.' + str(depth1 + 1) + '.Value', Tags[depth1].get('Value'))
			if Tags[depth1].get('Key') is not None:
				self.add_query_param('Tags.' + str(depth1 + 1) + '.Key', Tags[depth1].get('Key'))
	def get_ExecutionMode(self): # String
		return self.get_query_params().get('ExecutionMode')

	def set_ExecutionMode(self, ExecutionMode):  # String
		self.add_query_param('ExecutionMode', ExecutionMode)
	def get_PreferenceParameters(self): # Array
		return self.get_query_params().get('PreferenceParameters')

	def set_PreferenceParameters(self, PreferenceParameters):  # Array
		self.add_query_param("PreferenceParameters", json.dumps(PreferenceParameters))
	def get_ClientToken(self): # String
		return self.get_query_params().get('ClientToken')

	def set_ClientToken(self, ClientToken):  # String
		self.add_query_param('ClientToken', ClientToken)
	def get_Description(self): # String
		return self.get_query_params().get('Description')

	def set_Description(self, Description):  # String
		self.add_query_param('Description', Description)
	def get_SourceTag(self): # Struct
		return self.get_query_params().get('SourceTag')

	def set_SourceTag(self, SourceTag):  # Struct
		self.add_query_param("SourceTag", json.dumps(SourceTag))
	def get_LogicalIdStrategy(self): # String
		return self.get_query_params().get('LogicalIdStrategy')

	def set_LogicalIdStrategy(self, LogicalIdStrategy):  # String
		self.add_query_param('LogicalIdStrategy', LogicalIdStrategy)
	def get_SourceResourceGroup(self): # Struct
		return self.get_query_params().get('SourceResourceGroup')

	def set_SourceResourceGroup(self, SourceResourceGroup):  # Struct
		self.add_query_param("SourceResourceGroup", json.dumps(SourceResourceGroup))
	def get_TemplateScratchType(self): # String
		return self.get_query_params().get('TemplateScratchType')

	def set_TemplateScratchType(self, TemplateScratchType):  # String
		self.add_query_param('TemplateScratchType', TemplateScratchType)
