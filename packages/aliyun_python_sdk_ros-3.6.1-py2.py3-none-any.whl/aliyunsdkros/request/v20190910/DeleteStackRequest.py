# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkros.endpoint import endpoint_data

class DeleteStackRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'ROS', '2019-09-10', 'DeleteStack','ros')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_DeleteOptionss(self): # RepeatList
		return self.get_query_params().get('DeleteOptions')

	def set_DeleteOptionss(self, DeleteOptions):  # RepeatList
		for depth1 in range(len(DeleteOptions)):
			self.add_query_param('DeleteOptions.' + str(depth1 + 1), DeleteOptions[depth1])
	def get_RetainAllResources(self): # Boolean
		return self.get_query_params().get('RetainAllResources')

	def set_RetainAllResources(self, RetainAllResources):  # Boolean
		self.add_query_param('RetainAllResources', RetainAllResources)
	def get_StackId(self): # String
		return self.get_query_params().get('StackId')

	def set_StackId(self, StackId):  # String
		self.add_query_param('StackId', StackId)
	def get_Parallelism(self): # Long
		return self.get_query_params().get('Parallelism')

	def set_Parallelism(self, Parallelism):  # Long
		self.add_query_param('Parallelism', Parallelism)
	def get_RetainResourcess(self): # RepeatList
		return self.get_query_params().get('RetainResources')

	def set_RetainResourcess(self, RetainResources):  # RepeatList
		for depth1 in range(len(RetainResources)):
			self.add_query_param('RetainResources.' + str(depth1 + 1), RetainResources[depth1])
	def get_RamRoleName(self): # String
		return self.get_query_params().get('RamRoleName')

	def set_RamRoleName(self, RamRoleName):  # String
		self.add_query_param('RamRoleName', RamRoleName)
