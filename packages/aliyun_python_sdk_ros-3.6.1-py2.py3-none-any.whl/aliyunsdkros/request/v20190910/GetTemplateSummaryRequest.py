# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkros.endpoint import endpoint_data

class GetTemplateSummaryRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'ROS', '2019-09-10', 'GetTemplateSummary','ros')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_ClientToken(self): # String
		return self.get_query_params().get('ClientToken')

	def set_ClientToken(self, ClientToken):  # String
		self.add_query_param('ClientToken', ClientToken)
	def get_TemplateBody(self): # String
		return self.get_query_params().get('TemplateBody')

	def set_TemplateBody(self, TemplateBody):  # String
		self.add_query_param('TemplateBody', TemplateBody)
	def get_StackId(self): # String
		return self.get_query_params().get('StackId')

	def set_StackId(self, StackId):  # String
		self.add_query_param('StackId', StackId)
	def get_TemplateURL(self): # String
		return self.get_query_params().get('TemplateURL')

	def set_TemplateURL(self, TemplateURL):  # String
		self.add_query_param('TemplateURL', TemplateURL)
	def get_TemplateVersion(self): # String
		return self.get_query_params().get('TemplateVersion')

	def set_TemplateVersion(self, TemplateVersion):  # String
		self.add_query_param('TemplateVersion', TemplateVersion)
	def get_StackGroupName(self): # String
		return self.get_query_params().get('StackGroupName')

	def set_StackGroupName(self, StackGroupName):  # String
		self.add_query_param('StackGroupName', StackGroupName)
	def get_TemplateId(self): # String
		return self.get_query_params().get('TemplateId')

	def set_TemplateId(self, TemplateId):  # String
		self.add_query_param('TemplateId', TemplateId)
	def get_ChangeSetId(self): # String
		return self.get_query_params().get('ChangeSetId')

	def set_ChangeSetId(self, ChangeSetId):  # String
		self.add_query_param('ChangeSetId', ChangeSetId)
	def get_Parameterss(self): # RepeatList
		return self.get_query_params().get('Parameters')

	def set_Parameterss(self, Parameters):  # RepeatList
		for depth1 in range(len(Parameters)):
			if Parameters[depth1].get('ParameterValue') is not None:
				self.add_query_param('Parameters.' + str(depth1 + 1) + '.ParameterValue', Parameters[depth1].get('ParameterValue'))
			if Parameters[depth1].get('ParameterKey') is not None:
				self.add_query_param('Parameters.' + str(depth1 + 1) + '.ParameterKey', Parameters[depth1].get('ParameterKey'))
