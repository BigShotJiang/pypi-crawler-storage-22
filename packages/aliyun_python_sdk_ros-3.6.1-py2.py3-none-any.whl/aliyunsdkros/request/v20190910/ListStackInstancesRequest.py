# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkros.endpoint import endpoint_data

class ListStackInstancesRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'ROS', '2019-09-10', 'ListStackInstances','ros')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_PageNumber(self): # Long
		return self.get_query_params().get('PageNumber')

	def set_PageNumber(self, PageNumber):  # Long
		self.add_query_param('PageNumber', PageNumber)
	def get_StackGroupName(self): # String
		return self.get_query_params().get('StackGroupName')

	def set_StackGroupName(self, StackGroupName):  # String
		self.add_query_param('StackGroupName', StackGroupName)
	def get_PageSize(self): # Long
		return self.get_query_params().get('PageSize')

	def set_PageSize(self, PageSize):  # Long
		self.add_query_param('PageSize', PageSize)
	def get_StackInstanceRegionId(self): # String
		return self.get_query_params().get('StackInstanceRegionId')

	def set_StackInstanceRegionId(self, StackInstanceRegionId):  # String
		self.add_query_param('StackInstanceRegionId', StackInstanceRegionId)
	def get_StackInstanceAccountId(self): # String
		return self.get_query_params().get('StackInstanceAccountId')

	def set_StackInstanceAccountId(self, StackInstanceAccountId):  # String
		self.add_query_param('StackInstanceAccountId', StackInstanceAccountId)
