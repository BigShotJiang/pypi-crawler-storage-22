# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkros.endpoint import endpoint_data

class ListStacksRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'ROS', '2019-09-10', 'ListStacks','ros')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_StartTime(self): # String
		return self.get_query_params().get('StartTime')

	def set_StartTime(self, StartTime):  # String
		self.add_query_param('StartTime', StartTime)
	def get_ResourceGroupId(self): # String
		return self.get_query_params().get('ResourceGroupId')

	def set_ResourceGroupId(self, ResourceGroupId):  # String
		self.add_query_param('ResourceGroupId', ResourceGroupId)
	def get_StackIdss(self): # RepeatList
		return self.get_query_params().get('StackIds')

	def set_StackIdss(self, StackIds):  # RepeatList
		for depth1 in range(len(StackIds)):
			self.add_query_param('StackIds.' + str(depth1 + 1), StackIds[depth1])
	def get_StackNames(self): # RepeatList
		return self.get_query_params().get('StackName')

	def set_StackNames(self, StackName):  # RepeatList
		for depth1 in range(len(StackName)):
			self.add_query_param('StackName.' + str(depth1 + 1), StackName[depth1])
	def get_Tags(self): # RepeatList
		return self.get_query_params().get('Tag')

	def set_Tags(self, Tag):  # RepeatList
		for depth1 in range(len(Tag)):
			if Tag[depth1].get('Value') is not None:
				self.add_query_param('Tag.' + str(depth1 + 1) + '.Value', Tag[depth1].get('Value'))
			if Tag[depth1].get('Key') is not None:
				self.add_query_param('Tag.' + str(depth1 + 1) + '.Key', Tag[depth1].get('Key'))
	def get_Statuss(self): # RepeatList
		return self.get_query_params().get('Status')

	def set_Statuss(self, Status):  # RepeatList
		for depth1 in range(len(Status)):
			self.add_query_param('Status.' + str(depth1 + 1), Status[depth1])
	def get_ShowNestedStack(self): # Boolean
		return self.get_query_params().get('ShowNestedStack')

	def set_ShowNestedStack(self, ShowNestedStack):  # Boolean
		self.add_query_param('ShowNestedStack', ShowNestedStack)
	def get_StackId(self): # String
		return self.get_query_params().get('StackId')

	def set_StackId(self, StackId):  # String
		self.add_query_param('StackId', StackId)
	def get_PageNumber(self): # Long
		return self.get_query_params().get('PageNumber')

	def set_PageNumber(self, PageNumber):  # Long
		self.add_query_param('PageNumber', PageNumber)
	def get_PageSize(self): # Long
		return self.get_query_params().get('PageSize')

	def set_PageSize(self, PageSize):  # Long
		self.add_query_param('PageSize', PageSize)
	def get_EndTime(self): # String
		return self.get_query_params().get('EndTime')

	def set_EndTime(self, EndTime):  # String
		self.add_query_param('EndTime', EndTime)
	def get_ParentStackId(self): # String
		return self.get_query_params().get('ParentStackId')

	def set_ParentStackId(self, ParentStackId):  # String
		self.add_query_param('ParentStackId', ParentStackId)
