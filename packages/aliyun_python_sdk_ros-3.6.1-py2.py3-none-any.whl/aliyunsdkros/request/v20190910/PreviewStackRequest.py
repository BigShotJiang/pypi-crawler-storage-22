# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
from aliyunsdkros.endpoint import endpoint_data

class PreviewStackRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'ROS', '2019-09-10', 'PreviewStack','ros')
		self.set_method('POST')

		if hasattr(self, "endpoint_map"):
			setattr(self, "endpoint_map", endpoint_data.getEndpointMap())
		if hasattr(self, "endpoint_regional"):
			setattr(self, "endpoint_regional", endpoint_data.getEndpointRegional())

	def get_TimeoutInMinutes(self): # Long
		return self.get_query_params().get('TimeoutInMinutes')

	def set_TimeoutInMinutes(self, TimeoutInMinutes):  # Long
		self.add_query_param('TimeoutInMinutes', TimeoutInMinutes)
	def get_TemplateVersion(self): # String
		return self.get_query_params().get('TemplateVersion')

	def set_TemplateVersion(self, TemplateVersion):  # String
		self.add_query_param('TemplateVersion', TemplateVersion)
	def get_StackName(self): # String
		return self.get_query_params().get('StackName')

	def set_StackName(self, StackName):  # String
		self.add_query_param('StackName', StackName)
	def get_DisableRollback(self): # Boolean
		return self.get_query_params().get('DisableRollback')

	def set_DisableRollback(self, DisableRollback):  # Boolean
		self.add_query_param('DisableRollback', DisableRollback)
	def get_TemplateId(self): # String
		return self.get_query_params().get('TemplateId')

	def set_TemplateId(self, TemplateId):  # String
		self.add_query_param('TemplateId', TemplateId)
	def get_Parameterss(self): # RepeatList
		return self.get_query_params().get('Parameters')

	def set_Parameterss(self, Parameters):  # RepeatList
		for depth1 in range(len(Parameters)):
			if Parameters[depth1].get('ParameterValue') is not None:
				self.add_query_param('Parameters.' + str(depth1 + 1) + '.ParameterValue', Parameters[depth1].get('ParameterValue'))
			if Parameters[depth1].get('ParameterKey') is not None:
				self.add_query_param('Parameters.' + str(depth1 + 1) + '.ParameterKey', Parameters[depth1].get('ParameterKey'))
	def get_TemplateScratchId(self): # String
		return self.get_query_params().get('TemplateScratchId')

	def set_TemplateScratchId(self, TemplateScratchId):  # String
		self.add_query_param('TemplateScratchId', TemplateScratchId)
	def get_ClientToken(self): # String
		return self.get_query_params().get('ClientToken')

	def set_ClientToken(self, ClientToken):  # String
		self.add_query_param('ClientToken', ClientToken)
	def get_TemplateBody(self): # String
		return self.get_body_params().get('TemplateBody')

	def set_TemplateBody(self, TemplateBody):  # String
		self.add_body_params('TemplateBody', TemplateBody)
	def get_EnablePreConfig(self): # Boolean
		return self.get_query_params().get('EnablePreConfig')

	def set_EnablePreConfig(self, EnablePreConfig):  # Boolean
		self.add_query_param('EnablePreConfig', EnablePreConfig)
	def get_Parallelism(self): # Long
		return self.get_query_params().get('Parallelism')

	def set_Parallelism(self, Parallelism):  # Long
		self.add_query_param('Parallelism', Parallelism)
	def get_StackId(self): # String
		return self.get_query_params().get('StackId')

	def set_StackId(self, StackId):  # String
		self.add_query_param('StackId', StackId)
	def get_TemplateScratchRegionId(self): # String
		return self.get_query_params().get('TemplateScratchRegionId')

	def set_TemplateScratchRegionId(self, TemplateScratchRegionId):  # String
		self.add_query_param('TemplateScratchRegionId', TemplateScratchRegionId)
	def get_TemplateURL(self): # String
		return self.get_query_params().get('TemplateURL')

	def set_TemplateURL(self, TemplateURL):  # String
		self.add_query_param('TemplateURL', TemplateURL)
	def get_TaintResourcess(self): # RepeatList
		return self.get_query_params().get('TaintResources')

	def set_TaintResourcess(self, TaintResources):  # RepeatList
		for depth1 in range(len(TaintResources)):
			self.add_query_param('TaintResources.' + str(depth1 + 1), TaintResources[depth1])
	def get_StackPolicyBody(self): # String
		return self.get_query_params().get('StackPolicyBody')

	def set_StackPolicyBody(self, StackPolicyBody):  # String
		self.add_query_param('StackPolicyBody', StackPolicyBody)
	def get_UsePreviousParameters(self): # Boolean
		return self.get_query_params().get('UsePreviousParameters')

	def set_UsePreviousParameters(self, UsePreviousParameters):  # Boolean
		self.add_query_param('UsePreviousParameters', UsePreviousParameters)
	def get_StackPolicyURL(self): # String
		return self.get_query_params().get('StackPolicyURL')

	def set_StackPolicyURL(self, StackPolicyURL):  # String
		self.add_query_param('StackPolicyURL', StackPolicyURL)
