# akhan-broadcast-server
A python package for the BroadcastServer simple CLI app

## Requirements 
- Python v3.10+ (tested on v3.12)
- Pip

## Install 
Install the package from PyPi.

Recommended: Create and use a python [virtual environment](https://docs.python.org/3/library/venv.html) running `pip install akhan-broadcast-server` or install with pipx `pipx install akhan-broadcast-server`.

## Usage
TBD