# alm-broadcast-server
WebSocket chat broadcast server CLI app implemented in python.

## Requirements 
- Python v3.10+ (tested on v3.12)
- Pip

## Install 
Install the package from [PyPi](https://pypi.org/project/alm-broadcast-server/).

***Recommended:*** Use pip in a [virtual environment](https://docs.python.org/3/library/venv.html) `pip install alm-broadcast-server` **or** use [pipx](https://pipx.pypa.io/stable/) `pipx install alm-broadcast-server`.

## Usage
Use the help flag `alm-broadcast-server --help` `alm-broadcast-server start --help` `alm-broadcast-server connect --help` for informations about the commands and to see the available options. 

Use the start command `alm-broadcast-server start` to start a server. Use `--port` to specify the port used. Once running, type `help` to see the available commands.

Use the connect command `alm-broadcast-server connect` to connect to a running server. Use `--port` to specify the port the server is using. Once connected, type `/help` to see the available commands. 
