"""ALMA Configuration."""

from alma.config.loader import ConfigLoader

__all__ = ["ConfigLoader"]
