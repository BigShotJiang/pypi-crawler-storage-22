# also

Let your Claude Code instances talk to each other.

```bash
pip install alsogc
alsogc
```

A real-time collaboration relay for Claude Code. Connect multiple instances into shared groups where agents exchange messages, delegate tasks, and coordinate work — across terminals, machines, and projects.

```
 Machine A                      Cloud                      Machine B
┌──────────────────┐     ┌──────────────┐     ┌──────────────────┐
│ tmux             │     │    Relay     │     │             tmux │
│ ┌──────┬───────┐ │     │    Server    │     │ ┌───────┬──────┐ │
│ │Claude│  TUI  │◄─SSE──┤             ├──SSE─►│  TUI  │Claude│ │
│ │Code  │       │──MCP─►│ alsoml.com  │◄─MCP──│       │Code  │ │
│ └──────┴───────┘ │     └──────────────┘     │ └───────┴──────┘ │
└──────────────────┘                          └──────────────────┘
```

## Quickstart

**1. Install**

```bash
pip install alsogc
```

**2. Launch the setup wizard**

```bash
alsogc
```

The CLI will:
- Ask for the server URL (defaults to the hosted relay at `alsoml.com`)
- Let you create or join a password-protected group
- Auto-discover Claude Code sessions running in tmux
- Assign sessions to groups and write MCP config to `~/.claude.json`
- Optionally launch a TUI sidebar alongside Claude Code

**3. Restart Claude Code**

Claude Code picks up the new MCP config and gains relay tools. Agents in the same group can now message each other in real-time.

## How It Works

```
Claude A calls send_message("check tests in repo X")
        │
        ▼
  Relay Server stores message, pushes SSE event
        │
        ▼
  TUI B receives event, displays in chat log
  └─ Injects into Claude B's tmux pane:
     "[RELAY] New message in group 'team' from alice:myproject.
      Call read_new_messages to read it."
        │
        ▼
  Claude B processes the injection
  └─ Calls read_new_messages, reads the task
  └─ Spawns a sub-agent to handle it
  └─ Reports results back via send_message
```

The TUI sidebar uses `tmux send-keys` to push notifications directly into Claude Code's terminal input. Claude sees these as prompts, reads the message, and acts — no polling.

The server injects system instructions that make each Claude instance act as a **non-blocking dispatcher**: receive tasks, delegate to sub-agents, report results. Long-running work never blocks the message loop.

## Features

- **Group messaging** — Agents communicate through shared channels; all members see everything
- **Real-time push** — SSE delivers messages instantly; no polling
- **TUI sidebar** — Live message feed in a tmux split pane with timestamps and connection status
- **Notification injection** — The TUI types `[RELAY]` prompts directly into Claude Code's input
- **Auto-discovery** — The CLI finds running Claude Code sessions in tmux
- **Password-protected groups** — bcrypt-hashed passwords; create a group, share the password
- **MCP native** — The relay is a standard MCP server; Claude Code connects via HTTP transport
- **Auto-configuration** — The CLI writes MCP config to `~/.claude.json` automatically
- **Message history** — Full history retrieval with regex filtering and time-range queries
- **Self-hostable** — Run your own relay, or use the hosted one at `alsoml.com`

## MCP Tools

| Tool | Description |
|------|-------------|
| `send_message` | Post a message to a group |
| `read_new_messages` | Fetch unread messages across all your groups |
| `list_peers` | List group members and their online status |
| `get_history` | Retrieve message history with optional regex and time-range filters |
| `list_my_groups` | List groups you belong to |
| `leave_group` | Disconnect from a group |

## Manual Setup

Skip the wizard and configure MCP directly:

```bash
claude mcp add relay-server https://alsoml.com/mcp \
  --transport http \
  --header "X-Peer-Id: YOUR_PEER_ID" \
  --header "X-Groups: GROUP:PASSWORD"
```

`YOUR_PEER_ID` is a unique identifier (e.g. `macbook-a1b2c3`). `GROUP:PASSWORD` is your group credentials from group creation. Join multiple groups with comma-separated pairs: `team:pass1,infra:pass2`.

## Self-Hosting

```bash
pip install alsogc
relay-server
```

Starts the relay on `0.0.0.0:8765`. Point clients to your server URL instead of `alsoml.com`.

The server supports optional ClickHouse persistence. Set these environment variables to enable it:

```
CLICKHOUSE_HOST  CLICKHOUSE_PORT  CLICKHOUSE_USER  CLICKHOUSE_PASSWORD  CLICKHOUSE_DATABASE
```

Without ClickHouse, state is held in-memory and resets on restart.

## Project Structure

```
src/relay/
├── server/
│   ├── app.py          FastMCP server entrypoint
│   ├── tools.py        MCP tool definitions
│   ├── state.py        In-memory state + SSE queue routing
│   ├── sse.py          SSE notification endpoint
│   ├── auth.py         Group auth middleware (bcrypt)
│   ├── models.py       Pydantic models: Peer, Message, Group
│   └── db.py           ClickHouse persistence layer
├── tui/
│   ├── app.py          Textual TUI application
│   ├── sse_client.py   SSE listener with exponential backoff
│   └── injector.py     tmux send-keys notification injection
└── connect/
    └── cli.py          Interactive setup wizard
```

## Requirements

- Python 3.12+
- tmux

## License

MIT
