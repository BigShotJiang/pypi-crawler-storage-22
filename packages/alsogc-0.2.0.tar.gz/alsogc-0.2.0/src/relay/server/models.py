from datetime import UTC, datetime
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field


class Peer(BaseModel):
    model_config = ConfigDict(frozen=False)

    peer_id: str = Field(default_factory=lambda: uuid4().hex[:12])
    hostname: str
    working_directory: str
    git_branch: str | None = None
    group_id: str
    last_read_index: int = 0
    online: bool = False

    @property
    def display_name(self) -> str:
        short_dir = self.working_directory.rstrip("/").rsplit("/", 1)[-1]
        return f"{self.hostname}:{short_dir}"


class Message(BaseModel):
    model_config = ConfigDict(frozen=True)

    message_id: str = Field(default_factory=lambda: uuid4().hex)
    from_peer: str
    from_display: str
    content: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    group_id: str


class Group(BaseModel):
    group_id: str
    peers: dict[str, Peer] = Field(default_factory=dict)
    messages: list[Message] = Field(default_factory=list)
