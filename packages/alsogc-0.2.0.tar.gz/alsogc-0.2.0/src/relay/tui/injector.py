from __future__ import annotations

import asyncio


class TmuxInjector:
    def __init__(self, target_pane: str) -> None:
        self.target_pane = target_pane

    async def inject(self, text: str) -> bool:
        type_proc = await asyncio.create_subprocess_exec(
            "tmux", "send-keys", "-t", self.target_pane, "-l", text,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        if await type_proc.wait() != 0:
            return False
        submit_proc = await asyncio.create_subprocess_exec(
            "tmux", "send-keys", "-t", self.target_pane, "Enter",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        return await submit_proc.wait() == 0

    async def inject_notification(
        self,
        from_display: str,
        group_id: str,
    ) -> bool:
        text = (
            f"[RELAY] New message in group '{group_id}' from {from_display}. "
            f"Call the read_new_messages tool to read it."
        )
        return await self.inject(text)
