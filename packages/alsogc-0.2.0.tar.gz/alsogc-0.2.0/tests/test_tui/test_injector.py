from unittest.mock import AsyncMock, call, patch

import pytest

from relay.tui.injector import TmuxInjector


class TestTmuxInjector:
    def test_init_stores_target_pane(self):
        injector = TmuxInjector("%42")
        assert injector.target_pane == "%42"

    @pytest.mark.asyncio
    async def test_inject_sends_literal_text_then_enter(self):
        injector = TmuxInjector("%1")
        mock_proc = AsyncMock()
        mock_proc.wait = AsyncMock(return_value=0)
        with patch("relay.tui.injector.asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            result = await injector.inject("hello world")
            assert result is True
            assert mock_exec.call_count == 2
            type_args = mock_exec.call_args_list[0][0]
            assert type_args == ("tmux", "send-keys", "-t", "%1", "-l", "hello world")
            enter_args = mock_exec.call_args_list[1][0]
            assert enter_args == ("tmux", "send-keys", "-t", "%1", "Enter")

    @pytest.mark.asyncio
    async def test_inject_returns_false_on_type_failure(self):
        injector = TmuxInjector("%1")
        mock_proc = AsyncMock()
        mock_proc.wait = AsyncMock(return_value=1)
        with patch("relay.tui.injector.asyncio.create_subprocess_exec", return_value=mock_proc):
            result = await injector.inject("hello")
            assert result is False

    @pytest.mark.asyncio
    async def test_inject_returns_false_on_enter_failure(self):
        injector = TmuxInjector("%1")
        type_proc = AsyncMock()
        type_proc.wait = AsyncMock(return_value=0)
        enter_proc = AsyncMock()
        enter_proc.wait = AsyncMock(return_value=1)
        with patch("relay.tui.injector.asyncio.create_subprocess_exec", side_effect=[type_proc, enter_proc]):
            result = await injector.inject("hello")
            assert result is False

    @pytest.mark.asyncio
    async def test_inject_notification_formats_message(self):
        injector = TmuxInjector("%1")
        mock_proc = AsyncMock()
        mock_proc.wait = AsyncMock(return_value=0)
        with patch("relay.tui.injector.asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            result = await injector.inject_notification("alice:proj", "team1")
            assert result is True
            type_args = mock_exec.call_args_list[0][0]
            text = type_args[5]
            assert "RELAY" in text
            assert "team1" in text
            assert "alice:proj" in text
            assert "read_new_messages" in text

    @pytest.mark.asyncio
    async def test_inject_notification_default_format(self):
        injector = TmuxInjector("%1")
        mock_proc = AsyncMock()
        mock_proc.wait = AsyncMock(return_value=0)
        with patch("relay.tui.injector.asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            await injector.inject_notification("bob:work", "g1")
            type_args = mock_exec.call_args_list[0][0]
            text = type_args[5]
            assert "group 'g1'" in text
            assert "bob:work" in text
