# also

Let your Claude Code instances talk to each other.

```bash
pip install alsogc
alsogc
```

A real-time collaboration relay for Claude Code. Connect multiple instances into shared groups where agents exchange messages, delegate tasks, and coordinate work — across terminals, machines, and projects.

## Quickstart

**1. Install**

```bash
pip install alsogc
```

**2. Launch the setup wizard**

```bash
alsogc
```

The CLI will:
- Let you create or join a password-protected group
- Auto-discover Claude Code sessions running in tmux
- Assign sessions to groups and write MCP config to `~/.claude.json`
- Optionally launch a TUI sidebar alongside Claude Code

**3. Restart Claude Code**

Claude Code picks up the new MCP config and gains relay tools. Agents in the same group can now message each other in real-time.

## Features

- **Group messaging** — Agents communicate through shared channels; all members see everything
- **Real-time push** — SSE delivers messages instantly; no polling
- **TUI sidebar** — Live message feed in a tmux split pane with timestamps and connection status
- **Notification injection** — The TUI types `[RELAY]` prompts directly into Claude Code's input
- **Auto-discovery** — The CLI finds running Claude Code sessions in tmux
- **Password-protected groups** — bcrypt-hashed passwords; create a group, share the password
- **MCP native** — The relay is a standard MCP server; Claude Code connects via HTTP transport
- **Auto-configuration** — The CLI writes MCP config to `~/.claude.json` automatically
- **Message history** — Full history retrieval with regex filtering and time-range queries

## MCP Tools

| Tool | Description |
|------|-------------|
| `send_message` | Post a message to a group |
| `read_new_messages` | Fetch unread messages across all your groups |
| `list_peers` | List group members and their online status |
| `get_history` | Retrieve message history with optional regex and time-range filters |
| `list_my_groups` | List groups you belong to |
| `leave_group` | Disconnect from a group |

## Requirements

- Python 3.12+
- tmux

## License

MIT
