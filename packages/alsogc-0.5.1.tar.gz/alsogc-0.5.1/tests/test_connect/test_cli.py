from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

from relay.connect.cli import (
    _build_groups_header,
    _build_mcp_entry,
    _load_state,
    _remove_mcp_config,
    _save_state,
    _sync_mcp_config,
)


@pytest.fixture
def tmp_state_dir(tmp_path: Path) -> Path:
    return tmp_path / ".alsogc"


@pytest.fixture
def tmp_state_file(tmp_state_dir: Path) -> Path:
    return tmp_state_dir / "state.json"


@pytest.fixture
def tmp_claude_config(tmp_path: Path) -> Path:
    return tmp_path / ".claude.json"


@pytest.fixture(autouse=True)
def _patch_paths(
    tmp_state_dir: Path,
    tmp_state_file: Path,
    tmp_claude_config: Path,
) -> Any:
    with (
        patch("relay.connect.cli.STATE_DIR", tmp_state_dir),
        patch("relay.connect.cli.STATE_FILE", tmp_state_file),
        patch("relay.connect.cli.CLAUDE_CONFIG_PATH", tmp_claude_config),
    ):
        yield


def _make_state(groups: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "server_url": "https://alsoml.com",
        "peer_id": "test-host-abc123",
        "groups": groups or {},
        "children": {},
    }


class TestLoadState:
    def test_creates_state_dir_on_first_load(self, tmp_state_dir: Path):
        assert not tmp_state_dir.exists()
        _load_state()
        assert tmp_state_dir.exists()

    def test_creates_state_file_on_first_load(self, tmp_state_file: Path):
        assert not tmp_state_file.exists()
        _load_state()
        assert tmp_state_file.exists()

    def test_fresh_state_has_required_keys(self):
        state = _load_state()
        assert "server_url" in state
        assert "peer_id" in state
        assert "groups" in state
        assert "children" in state
        assert state["groups"] == {}

    def test_loads_existing_state(self, tmp_state_dir: Path, tmp_state_file: Path):
        tmp_state_dir.mkdir(parents=True, exist_ok=True)
        existing = _make_state({"mygroup": {"password": "secret"}})
        tmp_state_file.write_text(json.dumps(existing))
        state = _load_state()
        assert state["groups"] == {"mygroup": {"password": "secret"}}

    def test_backfills_missing_keys(self, tmp_state_dir: Path, tmp_state_file: Path):
        tmp_state_dir.mkdir(parents=True, exist_ok=True)
        tmp_state_file.write_text(json.dumps({"groups": {"g1": {"password": "pw"}}}))
        state = _load_state()
        assert "server_url" in state
        assert "peer_id" in state
        assert "children" in state
        assert state["groups"] == {"g1": {"password": "pw"}}


class TestSaveState:
    def test_creates_directory_and_file(self, tmp_state_dir: Path, tmp_state_file: Path):
        assert not tmp_state_dir.exists()
        state = _make_state()
        _save_state(state)
        assert tmp_state_file.exists()
        loaded = json.loads(tmp_state_file.read_text())
        assert loaded["peer_id"] == "test-host-abc123"

    def test_overwrites_existing_state(self, tmp_state_dir: Path, tmp_state_file: Path):
        state = _make_state()
        _save_state(state)
        state["groups"]["g1"] = {"password": "pw1"}
        _save_state(state)
        loaded = json.loads(tmp_state_file.read_text())
        assert "g1" in loaded["groups"]


class TestBuildGroupsHeader:
    def test_single_group(self):
        state = _make_state({"team1": {"password": "abc"}})
        header = _build_groups_header(state, ["team1"])
        assert header == "team1:abc"

    def test_multiple_groups(self):
        state = _make_state({"g1": {"password": "p1"}, "g2": {"password": "p2"}})
        header = _build_groups_header(state, ["g1", "g2"])
        assert "g1:p1" in header
        assert "g2:p2" in header

    def test_empty_groups(self):
        state = _make_state()
        header = _build_groups_header(state, [])
        assert header == ""

    def test_missing_password_skipped(self):
        state = _make_state({"g1": {}})
        header = _build_groups_header(state, ["g1"])
        assert header == ""


class TestBuildMcpEntry:
    def test_entry_structure(self):
        state = _make_state({"team1": {"password": "pw1"}})
        entry = _build_mcp_entry(state)
        assert entry["type"] == "http"
        assert entry["url"] == "https://alsoml.com/mcp"
        assert "X-Peer-Id" in entry["headers"]
        assert "X-Groups" in entry["headers"]
        assert "X-Hostname" in entry["headers"]
        assert "X-Working-Directory" in entry["headers"]

    def test_groups_header_matches(self):
        state = _make_state({"team1": {"password": "pw1"}})
        entry = _build_mcp_entry(state)
        assert entry["headers"]["X-Groups"] == "team1:pw1"

    def test_peer_id_matches(self):
        state = _make_state({"team1": {"password": "pw1"}})
        entry = _build_mcp_entry(state)
        assert entry["headers"]["X-Peer-Id"] == "test-host-abc123"


class TestSyncMcpConfig:
    def test_writes_mcp_servers_to_new_file(self, tmp_claude_config: Path):
        state = _make_state({"team1": {"password": "pw1"}})
        result = _sync_mcp_config(state)
        assert result is True
        config = json.loads(tmp_claude_config.read_text())
        assert "mcpServers" in config
        assert "also-mcp" in config["mcpServers"]
        assert config["mcpServers"]["also-mcp"]["type"] == "http"

    def test_preserves_existing_config(self, tmp_claude_config: Path):
        existing = {"numStartups": 42, "installMethod": "native"}
        tmp_claude_config.write_text(json.dumps(existing))
        state = _make_state({"team1": {"password": "pw1"}})
        _sync_mcp_config(state)
        config = json.loads(tmp_claude_config.read_text())
        assert config["numStartups"] == 42
        assert config["installMethod"] == "native"
        assert "mcpServers" in config

    def test_preserves_existing_mcp_servers(self, tmp_claude_config: Path):
        existing = {
            "mcpServers": {
                "other-server": {"type": "stdio", "command": "foo"}
            }
        }
        tmp_claude_config.write_text(json.dumps(existing))
        state = _make_state({"team1": {"password": "pw1"}})
        _sync_mcp_config(state)
        config = json.loads(tmp_claude_config.read_text())
        assert "other-server" in config["mcpServers"]
        assert "also-mcp" in config["mcpServers"]

    def test_updates_existing_also_mcp_entry(self, tmp_claude_config: Path):
        existing = {
            "mcpServers": {
                "also-mcp": {"type": "http", "url": "https://old.com/mcp", "headers": {}}
            }
        }
        tmp_claude_config.write_text(json.dumps(existing))
        state = _make_state({"newgroup": {"password": "newpw"}})
        _sync_mcp_config(state)
        config = json.loads(tmp_claude_config.read_text())
        assert config["mcpServers"]["also-mcp"]["url"] == "https://alsoml.com/mcp"
        assert "newgroup:newpw" in config["mcpServers"]["also-mcp"]["headers"]["X-Groups"]

    def test_removes_entry_when_no_groups(self, tmp_claude_config: Path):
        existing = {
            "numStartups": 42,
            "mcpServers": {
                "also-mcp": {"type": "http", "url": "https://alsoml.com/mcp"},
                "other": {"type": "stdio"},
            },
        }
        tmp_claude_config.write_text(json.dumps(existing))
        state = _make_state()
        result = _sync_mcp_config(state)
        assert result is True
        config = json.loads(tmp_claude_config.read_text())
        assert "also-mcp" not in config.get("mcpServers", {})
        assert "other" in config["mcpServers"]
        assert config["numStartups"] == 42

    def test_removes_mcp_servers_key_when_last_entry(self, tmp_claude_config: Path):
        existing = {
            "numStartups": 42,
            "mcpServers": {
                "also-mcp": {"type": "http", "url": "https://alsoml.com/mcp"},
            },
        }
        tmp_claude_config.write_text(json.dumps(existing))
        state = _make_state()
        _sync_mcp_config(state)
        config = json.loads(tmp_claude_config.read_text())
        assert "mcpServers" not in config

    def test_no_groups_no_existing_file(self, tmp_claude_config: Path):
        state = _make_state()
        result = _sync_mcp_config(state)
        assert result is False
        assert not tmp_claude_config.exists()

    def test_handles_corrupt_claude_json(self, tmp_claude_config: Path):
        tmp_claude_config.write_text("{invalid json!!!")
        state = _make_state({"team1": {"password": "pw1"}})
        result = _sync_mcp_config(state)
        assert result is True
        config = json.loads(tmp_claude_config.read_text())
        assert "also-mcp" in config["mcpServers"]

    def test_preserves_project_level_mcp_servers(self, tmp_claude_config: Path):
        existing = {
            "numStartups": 100,
            "projects": {
                "/Users/test/myproject": {
                    "mcpServers": {
                        "project-server": {"type": "stdio", "command": "bar"}
                    }
                }
            },
        }
        tmp_claude_config.write_text(json.dumps(existing))
        state = _make_state({"team1": {"password": "pw1"}})
        _sync_mcp_config(state)
        config = json.loads(tmp_claude_config.read_text())
        assert "also-mcp" in config["mcpServers"]
        project_servers = config["projects"]["/Users/test/myproject"]["mcpServers"]
        assert "project-server" in project_servers

    def test_top_level_mcp_servers_key_location(self, tmp_claude_config: Path):
        existing = {"numStartups": 50}
        tmp_claude_config.write_text(json.dumps(existing))
        state = _make_state({"team1": {"password": "pw1"}})
        _sync_mcp_config(state)
        config = json.loads(tmp_claude_config.read_text())
        assert "mcpServers" in config
        assert isinstance(config["mcpServers"], dict)
        assert config["mcpServers"]["also-mcp"]["type"] == "http"
        assert config["mcpServers"]["also-mcp"]["url"] == "https://alsoml.com/mcp"


class TestRemoveMcpConfig:
    def test_removes_also_mcp_entry(self, tmp_claude_config: Path):
        existing = {
            "mcpServers": {
                "also-mcp": {"type": "http"},
                "other": {"type": "stdio"},
            }
        }
        tmp_claude_config.write_text(json.dumps(existing))
        result = _remove_mcp_config()
        assert result is True
        config = json.loads(tmp_claude_config.read_text())
        assert "also-mcp" not in config["mcpServers"]
        assert "other" in config["mcpServers"]

    def test_noop_when_no_file(self, tmp_claude_config: Path):
        assert not tmp_claude_config.exists()
        result = _remove_mcp_config()
        assert result is False

    def test_noop_when_no_also_mcp(self, tmp_claude_config: Path):
        existing = {"mcpServers": {"other": {"type": "stdio"}}}
        tmp_claude_config.write_text(json.dumps(existing))
        result = _remove_mcp_config()
        assert result is False
