import modal

image = (
    modal.Image.debian_slim(python_version="3.12")
    .pip_install(
        "fastmcp>=2.14.5",
        "sse-starlette>=3.2.0",
        "httpx>=0.28.0",
        "uvicorn>=0.34.0",
        "pydantic>=2.10.0",
        "clickhouse-connect>=0.8.0",
        "bcrypt>=4.0.0",
    )
    .env({"PYTHONPATH": "/root/src"})
    .add_local_dir("src", remote_path="/root/src")
)

app = modal.App("relay-server", image=image)


@app.function(
    timeout=86400,
    scaledown_window=300,
    secrets=[modal.Secret.from_name("clickhouse-creds"), modal.Secret.from_name("workos-creds")],
)
@modal.concurrent(max_inputs=1000)
@modal.asgi_app(custom_domains=["alsoml.com"])
def web():
    from relay.server.app import create_app

    return create_app()
