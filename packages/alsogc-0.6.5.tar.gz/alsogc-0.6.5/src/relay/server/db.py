from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime

import clickhouse_connect
from clickhouse_connect.driver.asyncclient import AsyncClient


DDL_DATABASE = "CREATE DATABASE IF NOT EXISTS relay"

DDL_MESSAGES = """
CREATE TABLE IF NOT EXISTS relay.messages (
    message_id   String,
    group_id     LowCardinality(String),
    from_peer    String,
    from_display String,
    content      String,
    timestamp    DateTime64(6, 'UTC'),
    seq          UInt64
) ENGINE = MergeTree
ORDER BY (group_id, seq)
"""

DDL_ACCOUNTS = """
CREATE TABLE IF NOT EXISTS relay.accounts (
    email      String,
    api_key    String,
    created_at DateTime64(6, 'UTC') DEFAULT now64(6)
) ENGINE = ReplacingMergeTree(created_at)
ORDER BY email
"""

DDL_USERS = """
CREATE TABLE IF NOT EXISTS relay.users (
    user_id       String,
    account_email String,
    display_name  String,
    deleted       UInt8 DEFAULT 0,
    updated_at    DateTime64(6, 'UTC') DEFAULT now64(6)
) ENGINE = ReplacingMergeTree(updated_at, deleted)
ORDER BY user_id
"""

DDL_USER_GROUPS = """
CREATE TABLE IF NOT EXISTS relay.user_groups (
    user_id    String,
    group_id   LowCardinality(String),
    deleted    UInt8 DEFAULT 0,
    updated_at DateTime64(6, 'UTC') DEFAULT now64(6)
) ENGINE = ReplacingMergeTree(updated_at, deleted)
ORDER BY (user_id, group_id)
"""

DDL_CURSORS = """
CREATE TABLE IF NOT EXISTS relay.cursors (
    peer_id    String,
    group_id   LowCardinality(String),
    last_seq   UInt64,
    updated_at DateTime64(6, 'UTC') DEFAULT now64(6)
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (group_id, peer_id)
"""

DDL_GROUPS = """
CREATE TABLE IF NOT EXISTS relay.groups (
    group_id      String,
    password_hash String,
    created_at    DateTime64(6, 'UTC') DEFAULT now64(6),
    deleted       UInt8 DEFAULT 0,
    updated_at    DateTime64(6, 'UTC') DEFAULT now64(6)
) ENGINE = ReplacingMergeTree(updated_at, deleted)
ORDER BY group_id
"""


@dataclass(frozen=True)
class ClickHouseConfig:
    host: str = "localhost"
    port: int = 8123
    username: str = "default"
    password: str = ""
    database: str = "relay"
    secure: bool = False


@dataclass(frozen=True)
class AccountRow:
    email: str
    api_key: str


@dataclass(frozen=True)
class UserRow:
    user_id: str
    account_email: str
    display_name: str


@dataclass(frozen=True)
class UserGroupRow:
    user_id: str
    group_id: str


@dataclass(frozen=True)
class MessageRow:
    message_id: str
    group_id: str
    from_peer: str
    from_display: str
    content: str
    timestamp: datetime
    seq: int


class RelayDB:
    _client: AsyncClient

    def __init__(self, config: ClickHouseConfig) -> None:
        self._config = config
        self._seq_locks: defaultdict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    async def connect(self) -> None:
        self._client = await clickhouse_connect.get_async_client(
            host=self._config.host,
            port=self._config.port,
            username=self._config.username,
            password=self._config.password,
            secure=self._config.secure,
        )

    async def close(self) -> None:
        await self._client.close()

    async def ensure_schema(self) -> None:
        await self._client.command(DDL_DATABASE)
        await self._client.command(DDL_MESSAGES)
        await self._client.command(DDL_ACCOUNTS)
        await self._client.command(DDL_USERS)
        await self._client.command(DDL_USER_GROUPS)
        await self._client.command(DDL_CURSORS)
        await self._client.command(DDL_GROUPS)

    async def create_account(self, email: str, api_key: str) -> None:
        await self._client.command(
            "INSERT INTO relay.accounts (email, api_key) "
            "VALUES ({email:String}, {api_key:String})",
            parameters={"email": email, "api_key": api_key},
        )

    async def get_account_by_api_key(self, api_key: str) -> AccountRow | None:
        result = await self._client.query(
            "SELECT email, api_key "
            "FROM relay.accounts FINAL "
            "WHERE api_key = {api_key:String}",
            parameters={"api_key": api_key},
        )
        if not result.result_rows:
            return None
        row = result.result_rows[0]
        return AccountRow(email=row[0], api_key=row[1])

    async def get_account_by_email(self, email: str) -> AccountRow | None:
        result = await self._client.query(
            "SELECT email, api_key "
            "FROM relay.accounts FINAL "
            "WHERE email = {email:String}",
            parameters={"email": email},
        )
        if not result.result_rows:
            return None
        row = result.result_rows[0]
        return AccountRow(email=row[0], api_key=row[1])

    async def create_user(
        self, user_id: str, account_email: str, display_name: str
    ) -> None:
        await self._client.command(
            "INSERT INTO relay.users (user_id, account_email, display_name) "
            "VALUES ({uid:String}, {ae:String}, {dn:String})",
            parameters={"uid": user_id, "ae": account_email, "dn": display_name},
        )

    async def list_users(self, account_email: str) -> list[UserRow]:
        result = await self._client.query(
            "SELECT user_id, account_email, display_name "
            "FROM relay.users FINAL "
            "WHERE account_email = {ae:String} AND deleted = 0",
            parameters={"ae": account_email},
        )
        return [
            UserRow(user_id=row[0], account_email=row[1], display_name=row[2])
            for row in result.result_rows
        ]

    async def get_user(self, user_id: str) -> UserRow | None:
        result = await self._client.query(
            "SELECT user_id, account_email, display_name "
            "FROM relay.users FINAL "
            "WHERE user_id = {uid:String} AND deleted = 0",
            parameters={"uid": user_id},
        )
        if not result.result_rows:
            return None
        row = result.result_rows[0]
        return UserRow(user_id=row[0], account_email=row[1], display_name=row[2])

    async def delete_user(self, user_id: str) -> None:
        await self._client.command(
            "INSERT INTO relay.users (user_id, account_email, display_name, deleted) "
            "VALUES ({uid:String}, '', '', 1)",
            parameters={"uid": user_id},
        )

    async def add_user_to_group(self, user_id: str, group_id: str) -> None:
        await self._client.command(
            "INSERT INTO relay.user_groups (user_id, group_id) "
            "VALUES ({uid:String}, {gid:String})",
            parameters={"uid": user_id, "gid": group_id},
        )

    async def remove_user_from_group(self, user_id: str, group_id: str) -> None:
        await self._client.command(
            "INSERT INTO relay.user_groups (user_id, group_id, deleted) "
            "VALUES ({uid:String}, {gid:String}, 1)",
            parameters={"uid": user_id, "gid": group_id},
        )

    async def get_user_groups(self, user_id: str) -> list[str]:
        result = await self._client.query(
            "SELECT group_id "
            "FROM relay.user_groups FINAL "
            "WHERE user_id = {uid:String} AND deleted = 0",
            parameters={"uid": user_id},
        )
        return [row[0] for row in result.result_rows]

    async def insert_message(
        self,
        message_id: str,
        group_id: str,
        from_peer: str,
        from_display: str,
        content: str,
        timestamp: datetime,
    ) -> int:
        async with self._seq_locks[group_id]:
            result = await self._client.query(
                "SELECT coalesce(max(seq), 0) FROM relay.messages "
                "WHERE group_id = {g_id:String}",
                parameters={"g_id": group_id},
            )
            next_seq = int(result.result_rows[0][0]) + 1
            await self._client.command(
                "INSERT INTO relay.messages "
                "(message_id, group_id, from_peer, from_display, content, timestamp, seq) "
                "VALUES ({m_id:String}, {g_id:String}, {fp:String}, {fd:String}, "
                "{ct:String}, {ts:DateTime64(6, 'UTC')}, {seq:UInt64})",
                parameters={
                    "m_id": message_id,
                    "g_id": group_id,
                    "fp": from_peer,
                    "fd": from_display,
                    "ct": content,
                    "ts": timestamp,
                    "seq": next_seq,
                },
            )
            return next_seq

    async def get_messages_after(
        self, group_id: str, after_seq: int
    ) -> list[MessageRow]:
        result = await self._client.query(
            "SELECT message_id, group_id, from_peer, from_display, "
            "content, timestamp, seq "
            "FROM relay.messages "
            "WHERE group_id = {g_id:String} AND seq > {aseq:UInt64} "
            "ORDER BY seq ASC",
            parameters={"g_id": group_id, "aseq": after_seq},
        )
        return [self._row_to_message(row) for row in result.result_rows]

    async def get_all_messages(self, group_id: str) -> list[MessageRow]:
        result = await self._client.query(
            "SELECT message_id, group_id, from_peer, from_display, "
            "content, timestamp, seq "
            "FROM relay.messages "
            "WHERE group_id = {g_id:String} "
            "ORDER BY seq ASC",
            parameters={"g_id": group_id},
        )
        return [self._row_to_message(row) for row in result.result_rows]

    async def get_cursor(self, peer_id: str, group_id: str) -> int:
        result = await self._client.query(
            "SELECT last_seq "
            "FROM relay.cursors FINAL "
            "WHERE peer_id = {p_id:String} AND group_id = {g_id:String}",
            parameters={"p_id": peer_id, "g_id": group_id},
        )
        if not result.result_rows:
            return 0
        return int(result.result_rows[0][0])

    async def set_cursor(
        self, peer_id: str, group_id: str, last_seq: int
    ) -> None:
        await self._client.command(
            "INSERT INTO relay.cursors (peer_id, group_id, last_seq) "
            "VALUES ({p_id:String}, {g_id:String}, {ls:UInt64})",
            parameters={
                "p_id": peer_id,
                "g_id": group_id,
                "ls": last_seq,
            },
        )

    async def create_group(self, group_id: str, password_hash: str) -> None:
        await self._client.command(
            "INSERT INTO relay.groups (group_id, password_hash) "
            "VALUES ({g_id:String}, {ph:String})",
            parameters={"g_id": group_id, "ph": password_hash},
        )

    async def list_groups(self) -> list[str]:
        result = await self._client.query(
            "SELECT group_id FROM relay.groups FINAL WHERE deleted = 0"
        )
        return [row[0] for row in result.result_rows]

    async def get_group_password_hash(self, group_id: str) -> str | None:
        result = await self._client.query(
            "SELECT password_hash FROM relay.groups FINAL "
            "WHERE group_id = {g_id:String} AND deleted = 0",
            parameters={"g_id": group_id},
        )
        if not result.result_rows:
            return None
        return str(result.result_rows[0][0])

    async def group_exists(self, group_id: str) -> bool:
        return (await self.get_group_password_hash(group_id)) is not None

    @staticmethod
    def _row_to_message(row: tuple) -> MessageRow:  # type: ignore[type-arg]
        return MessageRow(
            message_id=row[0],
            group_id=row[1],
            from_peer=row[2],
            from_display=row[3],
            content=row[4],
            timestamp=row[5],
            seq=int(row[6]),
        )
