from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from relay.server.models import Group, Message, Peer

if TYPE_CHECKING:
    from relay.server.db import MessageRow, RelayDB


class RelayState:
    def __init__(self, db: RelayDB | None = None) -> None:
        self._db = db
        self.groups: dict[str, Group] = {}
        self.sessions: dict[str, tuple[str, list[str]]] = {}
        self.sse_queues: dict[str, asyncio.Queue[dict[str, Any]]] = {}
        self._users: dict[str, dict[str, Peer]] = {}

    async def startup(self) -> None:
        if self._db is not None:
            await self._db.connect()
            await self._db.ensure_schema()

    def _ensure_group(self, group_id: str) -> Group:
        if group_id not in self.groups:
            self.groups[group_id] = Group(group_id=group_id)
        return self.groups[group_id]

    def _build_notification(self, message: Message) -> dict[str, Any]:
        return {
            "type": "message",
            "message_id": message.message_id,
            "group_id": message.group_id,
            "from_display": message.from_display,
            "preview": message.content[:100],
        }

    def _row_to_message(self, row: MessageRow) -> Message:
        return Message(
            message_id=row.message_id,
            from_peer=row.from_peer,
            from_display=row.from_display,
            content=row.content,
            timestamp=row.timestamp,
            group_id=row.group_id,
        )

    def _ensure_user_cache(self, group_id: str) -> dict[str, Peer]:
        if group_id not in self._users:
            self._users[group_id] = {}
        return self._users[group_id]

    async def register(
        self,
        session_id: str,
        group_id: str,
        user_id: str,
        display_name: str,
    ) -> Peer:
        if self._db is not None:
            peer = Peer(
                user_id=user_id,
                display_name=display_name,
                group_id=group_id,
            )
            if user_id in self.sse_queues:
                peer.online = True
            cache = self._ensure_user_cache(group_id)
            cache[user_id] = peer
            if session_id in self.sessions:
                _, existing_groups = self.sessions[session_id]
                if group_id not in existing_groups:
                    existing_groups.append(group_id)
            else:
                self.sessions[session_id] = (user_id, [group_id])
            return peer

        group = self._ensure_group(group_id)
        peer = Peer(
            user_id=user_id,
            display_name=display_name,
            group_id=group_id,
        )
        if user_id in self.sse_queues:
            peer.online = True
        group.peers[user_id] = peer
        if session_id in self.sessions:
            _, existing_groups = self.sessions[session_id]
            if group_id not in existing_groups:
                existing_groups.append(group_id)
        else:
            self.sessions[session_id] = (user_id, [group_id])
        return peer

    async def ensure_user_session(
        self,
        session_id: str,
        user_id: str,
        display_name: str,
        group_ids: list[str],
    ) -> str:
        if session_id in self.sessions:
            existing_user_id, existing_groups = self.sessions[session_id]
            for gid in group_ids:
                if gid not in existing_groups:
                    await self.register(
                        session_id, gid, existing_user_id, display_name
                    )
            return existing_user_id
        for gid in group_ids:
            await self.register(session_id, gid, user_id, display_name)
        return user_id

    async def resolve_session(self, session_id: str) -> tuple[str, list[str]]:
        if session_id not in self.sessions:
            raise ValueError(f"Unknown session: {session_id}")
        return self.sessions[session_id]

    async def send_message(self, group_id: str, from_user_id: str, content: str) -> Message:
        if self._db is not None:
            cache = self._ensure_user_cache(group_id)
            peer = cache[from_user_id]
            message = Message(
                from_peer=from_user_id,
                from_display=peer.display_name,
                content=content,
                group_id=group_id,
            )
            await self._db.insert_message(
                message_id=message.message_id,
                group_id=group_id,
                from_peer=from_user_id,
                from_display=peer.display_name,
                content=content,
                timestamp=message.timestamp,
            )
            notification = self._build_notification(message)
            for uid in cache:
                if uid != from_user_id and uid in self.sse_queues:
                    self.sse_queues[uid].put_nowait(notification)
            return message

        group = self.groups[group_id]
        peer = group.peers[from_user_id]
        message = Message(
            from_peer=from_user_id,
            from_display=peer.display_name,
            content=content,
            group_id=group_id,
        )
        group.messages.append(message)
        notification = self._build_notification(message)
        for uid in group.peers:
            if uid != from_user_id and uid in self.sse_queues:
                self.sse_queues[uid].put_nowait(notification)
        return message

    async def read_new_messages(self, group_id: str, user_id: str) -> list[Message]:
        if self._db is not None:
            cursor = await self._db.get_cursor(user_id, group_id)
            rows = await self._db.get_messages_after(group_id, cursor)
            messages = [self._row_to_message(row) for row in rows]
            if rows:
                await self._db.set_cursor(user_id, group_id, rows[-1].seq)
            return messages

        group = self.groups[group_id]
        peer = group.peers[user_id]
        new_msgs = group.messages[peer.last_read_index:]
        peer.last_read_index = len(group.messages)
        return new_msgs

    async def list_peers(self, group_id: str) -> list[Peer]:
        if self._db is not None:
            cache = self._ensure_user_cache(group_id)
            return list(cache.values())

        return list(self.groups[group_id].peers.values())

    async def get_history(self, group_id: str) -> list[Message]:
        if self._db is not None:
            rows = await self._db.get_all_messages(group_id)
            return [self._row_to_message(row) for row in rows]

        group = self.groups[group_id]
        return list(group.messages)

    def _broadcast_presence(self, user_id: str, event_type: str) -> None:
        for group_id, group in self.groups.items():
            if user_id in group.peers:
                peer = group.peers[user_id]
                notification = {
                    "type": event_type,
                    "message_id": f"{event_type}-{user_id}",
                    "user_id": user_id,
                    "display_name": peer.display_name,
                    "group_id": group_id,
                }
                for uid in group.peers:
                    if uid != user_id and uid in self.sse_queues:
                        self.sse_queues[uid].put_nowait(notification)
        for group_id, cache in self._users.items():
            if user_id in cache:
                peer = cache[user_id]
                notification = {
                    "type": event_type,
                    "message_id": f"{event_type}-{user_id}",
                    "user_id": user_id,
                    "display_name": peer.display_name,
                    "group_id": group_id,
                }
                for uid in cache:
                    if uid != user_id and uid in self.sse_queues:
                        self.sse_queues[uid].put_nowait(notification)

    async def connect_sse(self, user_id: str) -> asyncio.Queue[dict[str, Any]]:
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self.sse_queues[user_id] = queue
        for group in self.groups.values():
            if user_id in group.peers:
                group.peers[user_id].online = True
        for group_cache in self._users.values():
            if user_id in group_cache:
                group_cache[user_id].online = True
        self._broadcast_presence(user_id, "peer_joined")
        return queue

    async def disconnect_sse(self, user_id: str) -> None:
        self._broadcast_presence(user_id, "peer_left")
        self.sse_queues.pop(user_id, None)
        for group in self.groups.values():
            if user_id in group.peers:
                group.peers[user_id].online = False
        for group_cache in self._users.values():
            if user_id in group_cache:
                group_cache[user_id].online = False

    async def leave_group(self, session_id: str, group_id: str) -> None:
        if session_id not in self.sessions:
            return
        user_id, group_ids = self.sessions[session_id]
        if group_id not in group_ids:
            return
        group_ids.remove(group_id)
        if not group_ids:
            self.sessions.pop(session_id)
            self.sse_queues.pop(user_id, None)
        if self._db is not None:
            await self._db.remove_user_from_group(user_id, group_id)
            if group_id in self._users:
                self._users[group_id].pop(user_id, None)
        else:
            if group_id in self.groups:
                self.groups[group_id].peers.pop(user_id, None)
