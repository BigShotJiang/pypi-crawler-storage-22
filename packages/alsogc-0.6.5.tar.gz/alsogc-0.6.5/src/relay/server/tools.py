from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from fastmcp import Context, FastMCP
from fastmcp.server.dependencies import get_http_request

from relay.server.models import Message
from relay.server.state import RelayState

if TYPE_CHECKING:
    from relay.server.db import RelayDB


def _format_message_line(m: Message) -> str:
    ts = m.timestamp.strftime("%H:%M:%S")
    return f"[{m.group_id}] [{ts}] {m.from_display}: {m.content}"


def register_tools(mcp: FastMCP, state: RelayState, db: RelayDB | None) -> None:
    async def _resolve(
        user_id: str, group_id: str | None = None
    ) -> tuple[str, str, list[str]]:
        if db is None:
            session_data = state.sessions.get(user_id)
            if session_data is None:
                await state.register(user_id, "__local__", user_id, user_id)
                return user_id, user_id, []
            _, group_ids = session_data
            if group_id is not None and group_id not in group_ids:
                raise ValueError(f"Not authorized for group: {group_id}")
            return user_id, user_id, group_ids

        request = get_http_request()
        api_key = request.headers.get("x-api-key", "")
        account = await db.get_account_by_api_key(api_key)
        if account is None:
            raise ValueError("Invalid API key")
        user = await db.get_user(user_id)
        if user is None:
            raise ValueError(f"User {user_id} not found")
        if user.account_email != account.email:
            raise ValueError(f"User {user_id} does not belong to your account")
        groups = await db.get_user_groups(user_id)
        if group_id is not None and group_id not in groups:
            raise ValueError(f"Not authorized for group: {group_id}")
        await state.ensure_user_session(user_id, user_id, user.display_name, groups)
        return user_id, user.display_name, groups

    @mcp.tool()
    async def send_message(ctx: Context, user_id: str, group_id: str, message: str) -> str:
        """Send a message to a group. All members of the group will see it.
        user_id: your user ID (from your ALSO SETUP message).
        group_id: the target group to post into.
        message: the text content to send."""
        uid, _, _ = await _resolve(user_id, group_id)
        msg = await state.send_message(group_id, uid, message)
        return f"Sent message {msg.message_id} to group {group_id}"

    @mcp.tool()
    async def read_new_messages(ctx: Context, user_id: str) -> list[str]:
        """Fetch all unread messages across every group you belong to.
        user_id: your user ID (from your ALSO SETUP message).
        Returns messages formatted as [group_id] [timestamp] sender: content."""
        uid, _, groups = await _resolve(user_id)
        all_messages: list[Message] = []
        for gid in groups:
            msgs = await state.read_new_messages(gid, uid)
            all_messages.extend(msgs)
        all_messages.sort(key=lambda m: m.timestamp)
        if not all_messages:
            return ["No new messages"]
        return [_format_message_line(m) for m in all_messages]

    @mcp.tool()
    async def list_peers(ctx: Context, user_id: str, group_id: str) -> list[str]:
        """List all members of a group and whether they are currently online.
        user_id: your user ID.
        group_id: the group to query."""
        await _resolve(user_id, group_id)
        peers = await state.list_peers(group_id)
        return [
            f"{p.display_name} ({p.user_id}) {'online' if p.online else 'offline'}"
            for p in peers
        ]

    @mcp.tool()
    async def get_history(
        ctx: Context,
        user_id: str,
        group_id: str,
        filter: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
    ) -> list[str]:
        """Retrieve the full message history for a group.
        user_id: your user ID.
        group_id: the group to retrieve history from.
        filter: optional regex pattern to match against message content.
        start_time: optional ISO 8601 datetime to start from (inclusive).
        end_time: optional ISO 8601 datetime to end at (inclusive)."""
        await _resolve(user_id, group_id)
        messages = await state.get_history(group_id)
        if start_time is not None:
            try:
                start_dt = datetime.fromisoformat(start_time)
            except ValueError as e:
                raise ValueError(f"Invalid start_time format: {e}")
            if start_dt.tzinfo is None:
                start_dt = start_dt.replace(tzinfo=UTC)
            messages = [m for m in messages if m.timestamp >= start_dt]
        if end_time is not None:
            try:
                end_dt = datetime.fromisoformat(end_time)
            except ValueError as e:
                raise ValueError(f"Invalid end_time format: {e}")
            if end_dt.tzinfo is None:
                end_dt = end_dt.replace(tzinfo=UTC)
            messages = [m for m in messages if m.timestamp <= end_dt]
        if filter is not None:
            try:
                pattern = re.compile(filter, re.IGNORECASE)
            except re.error as e:
                raise ValueError(f"Invalid filter pattern: {e}")
            messages = [m for m in messages if pattern.search(m.content)]
        if not messages:
            return ["No messages found"]
        return [_format_message_line(m) for m in messages]

    @mcp.tool()
    async def leave_group(ctx: Context, user_id: str, group_id: str) -> str:
        """Disconnect from a group. You will stop receiving messages from it.
        user_id: your user ID.
        group_id: the group to leave."""
        await _resolve(user_id, group_id)
        await state.leave_group(user_id, group_id)
        return f"Left group {group_id}"

    @mcp.tool()
    async def list_my_groups(ctx: Context, user_id: str) -> list[str]:
        """List the names of all groups you are currently a member of.
        user_id: your user ID."""
        _, _, groups = await _resolve(user_id)
        return groups
