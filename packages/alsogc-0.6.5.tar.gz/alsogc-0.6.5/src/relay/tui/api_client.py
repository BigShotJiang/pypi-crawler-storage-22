from __future__ import annotations

from typing import Any

import httpx


class ApiClient:
    def __init__(self, server_url: str, api_key: str, user_id: str) -> None:
        self._base_url = server_url.rstrip("/")
        self.user_id = user_id
        self._client = httpx.AsyncClient(
            timeout=10,
            headers={"X-Api-Key": api_key},
        )

    async def get_user_groups(self) -> list[str]:
        resp = await self._client.get(
            f"{self._base_url}/auth/users/{self.user_id}/groups",
        )
        resp.raise_for_status()
        return resp.json()["groups"]

    async def get_messages(
        self, group_id: str, since_seq: int = 0, limit: int = 100
    ) -> list[dict[str, Any]]:
        resp = await self._client.get(
            f"{self._base_url}/auth/groups/{group_id}/messages",
            params={"since_seq": since_seq, "limit": limit, "user_id": self.user_id},
        )
        resp.raise_for_status()
        return resp.json()["messages"]

    async def get_peers(self, group_id: str) -> list[dict[str, Any]]:
        resp = await self._client.get(
            f"{self._base_url}/auth/groups/{group_id}/peers",
            params={"user_id": self.user_id},
        )
        resp.raise_for_status()
        return resp.json()["peers"]

    async def close(self) -> None:
        await self._client.aclose()
