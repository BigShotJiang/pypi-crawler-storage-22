from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from typing import Any

import httpx
from httpx_sse import aconnect_sse


class SSEListener:
    def __init__(
        self,
        server_url: str,
        user_id: str,
        api_key: str,
        on_event: Callable[[dict[str, Any]], Awaitable[None]],
    ) -> None:
        self.server_url = server_url.rstrip("/")
        self.user_id = user_id
        self.api_key = api_key
        self.on_event = on_event
        self.connected: bool = False
        self._task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        self._task = asyncio.create_task(self._listen_loop())

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        self.connected = False

    async def _listen_loop(self) -> None:
        backoff = 1.0
        max_backoff = 30.0
        url = f"{self.server_url}/notifications/{self.user_id}"
        headers: dict[str, str] = {"X-Api-Key": self.api_key}

        while True:
            try:
                async with httpx.AsyncClient(timeout=None, headers=headers) as client:
                    async with aconnect_sse(client, "GET", url) as event_source:
                        self.connected = True
                        backoff = 1.0
                        async for event in event_source.aiter_sse():
                            if event.event != "notification" or not event.data:
                                continue
                            try:
                                parsed: dict[str, Any] = json.loads(event.data)
                            except (json.JSONDecodeError, TypeError):
                                continue
                            await self.on_event(parsed)
            except asyncio.CancelledError:
                self.connected = False
                return
            except (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError, httpx.ConnectTimeout):
                self.connected = False
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, max_backoff)
            except Exception:
                self.connected = False
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, max_backoff)
