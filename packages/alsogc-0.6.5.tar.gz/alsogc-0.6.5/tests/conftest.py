import pytest

from relay.server.models import Peer
from relay.server.state import RelayState


@pytest.fixture
def state() -> RelayState:
    return RelayState()


@pytest.fixture
async def registered_pair(state: RelayState) -> tuple[RelayState, Peer, Peer]:
    peer_a = await state.register("sess-a", "g1", "u-alice", "Alice")
    peer_b = await state.register("sess-b", "g1", "u-bob", "Bob")
    return state, peer_a, peer_b
