"""
Main Alter Vault SDK client.

This module provides the primary AlterVault class for interacting with
the Alter Vault OAuth token management system.
"""

import asyncio
import logging
import re
import time
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from alter_sdk.exceptions import (
    ConnectionNotFoundError,
    NetworkError,
    PolicyViolationError,
    ProviderAPIError,
    TokenExpiredError,
    TokenRetrievalError,
)
from alter_sdk.models import APICallAuditLog, TokenResponse
from alter_sdk.providers.enums import HttpMethod, Provider

logger = logging.getLogger(__name__)

# SDK version — single source of truth is alter_sdk.__version__
# Imported lazily to avoid circular import; set in _sdk_user_agent().
_SDK_USER_AGENT: str | None = None


def _sdk_user_agent() -> str:
    """Return the SDK User-Agent string, cached after first call."""
    global _SDK_USER_AGENT  # noqa: PLW0603
    if _SDK_USER_AGENT is None:
        from alter_sdk import __version__

        _SDK_USER_AGENT = f"alter-sdk-python/{__version__}"
    return _SDK_USER_AGENT


# HTTP status codes as constants
HTTP_FORBIDDEN = 403
HTTP_NOT_FOUND = 404
HTTP_BAD_REQUEST = 400
HTTP_UNAUTHORIZED = 401
HTTP_BAD_GATEWAY = 502
HTTP_INTERNAL_SERVER_ERROR = 500
HTTP_SERVICE_UNAVAILABLE = 503

# Request/Response size limits
MAX_BODY_SIZE_BYTES = 10000  # 10KB max for audit log bodies
HTTP_CLIENT_ERROR_START = 400  # HTTP status codes >= 400 are errors

# Actor header validation
MAX_ACTOR_STRING_LENGTH = 255  # Max length for actor string parameters
MAX_TRACKING_ID_LENGTH = 255  # Max length for tracking IDs (thread_id, tool_call_id)
_SAFE_HEADER_PATTERN = re.compile(r"^[\x20-\x7E]+$")  # Printable ASCII only

# URL scheme validation
_ALLOWED_URL_SCHEMES = ("https://", "http://")


class AlterVault:
    """
    Main SDK class for Alter Vault OAuth token management.

    This class handles:
    - Executing API requests to any OAuth provider with automatic token injection
    - Audit logging of API calls
    - Actor tracking for AI agents and MCP servers

    Zero Token Exposure:
    - Tokens are retrieved internally but NEVER exposed to developers
    - All API calls inject tokens automatically behind the scenes
    - Developers only see API results, never authentication credentials

    HTTP Client Architecture (Security):
        This SDK uses TWO separate HTTP clients to prevent credential leakage:

        1. _alter_client (for Alter backend):
           - Communicates with api.alter.com
           - Includes x-api-key header for authentication
           - Used by: _get_token(), _log_api_call()

        2. _provider_client (for external APIs):
           - Calls Google, Stripe, GitHub, etc.
           - NO x-api-key header (prevents leakage!)
           - OAuth token added per-request
           - Used by: request()

        SECURITY: The _alter_client must NEVER be used for external API calls,
           as it would leak the Alter API key to third-party providers.

    Example:
        ```python
        from alter_sdk import AlterVault, Provider, HttpMethod

        vault = AlterVault(api_key="alter_key_...")

        # Make API request (token injected automatically)
        response = await vault.request(
            Provider.GOOGLE, HttpMethod.GET,
            "https://www.googleapis.com/calendar/v3/calendars/primary/events",
            user={"user_id": "alice"},
        )
        events = response.json()

        # Clean up
        await vault.close()
        ```
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.alter.com",
        enable_audit_logging: bool = True,
        timeout: float = 30.0,
        # Actor tracking (optional - for AI agents and MCP servers)
        actor_type: str | None = None,
        actor_identifier: str | None = None,
        actor_name: str | None = None,
        actor_version: str | None = None,
        client_type: str | None = None,
        framework: str | None = None,
    ) -> None:
        """
        Initialize Alter Vault client.

        Args:
            api_key: Alter Vault API key (starts with "alter_key_")
            base_url: Base URL for Alter Vault API
            enable_audit_logging: Whether to send audit logs to backend
            timeout: HTTP request timeout in seconds
            actor_type: Actor type ("ai_agent" or "mcp_server") for tracking
            actor_identifier: Unique identifier for the actor (e.g., "email-assistant-v2")
            actor_name: Human-readable name for the actor (defaults to actor_identifier)
            actor_version: Actor version string (e.g., "1.0.0")
            client_type: MCP client type (e.g., "cursor", "claude-desktop")
            framework: AI framework (e.g., "langchain", "langgraph", "crewai")

        Raises:
            ValueError: If api_key is invalid

        Actor Tracking:
            Tracks which AI agent or MCP server is making requests, for audit
            logging and observability. Two fields form the unique identity:

            - actor_type + actor_identifier = unique lookup key in the database
            - actor_name, actor_version, framework, client_type = metadata

            Registration flow:
            1. First request: SDK sends actor_type + actor_identifier as headers
            2. Backend registers the actor (idempotent upsert) and assigns a UUID
            3. Backend returns the UUID as X-Alter-Actor-ID in the response
            4. SDK caches the UUID automatically
            5. Subsequent requests send the cached UUID (skips DB lookup)

            Per-request tracking fields (run_id, thread_id, tool_call_id) can be
            passed on each vault.request() call for execution-level granularity.

            Example:
                ```python
                vault = AlterVault(
                    api_key="alter_key_...",
                    actor_type="ai_agent",
                    actor_identifier="email-assistant-v2",
                    actor_name="Email Assistant",
                    actor_version="2.0.0",
                    framework="langgraph",
                )

                # Actor headers sent automatically on every request
                response = await vault.request(
                    "google", "GET", "https://...",
                    user={"user_id": "alice"},
                    run_id="550e8400-...",      # optional per-request tracking
                    thread_id="thread-xyz",     # optional per-request tracking
                )
                ```
        """
        # Validate inputs
        self._validate_init_params(api_key, actor_type, actor_identifier)
        # Validate actor string lengths and characters
        for _name, _val in [
            ("actor_identifier", actor_identifier),
            ("actor_name", actor_name),
            ("actor_version", actor_version),
            ("client_type", client_type),
            ("framework", framework),
        ]:
            self._validate_actor_string(_val, _name)

        self._api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.enable_audit_logging = enable_audit_logging

        # Actor tracking configuration
        self._actor_type = actor_type
        self._actor_identifier = actor_identifier
        self._actor_name = actor_name
        self._actor_version = actor_version
        self._client_type = client_type
        self._framework = framework
        # Cached actor_id from backend response (avoids DB lookup on subsequent requests)
        self._cached_actor_id: str | None = None
        # Background audit tasks (prevent GC of fire-and-forget tasks)
        self._audit_tasks: set[asyncio.Task[None]] = set()

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # HTTP CLIENT ARCHITECTURE - TWO SEPARATE CLIENTS FOR SECURITY
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        #
        # We maintain TWO separate HTTP clients to prevent credential leakage:
        #
        # _alter_client  → Alter backend (has x-api-key + actor headers)
        # _provider_client → External APIs (NO secrets, Bearer token per-request)
        #
        # SECURITY: Never use _alter_client for external API calls!

        # Shared connection pool settings for performance
        try:
            import h2  # type: ignore  # noqa: F401

            _http2_enabled = True
        except Exception:
            _http2_enabled = False

        _shared_limits = httpx.Limits(
            max_keepalive_connections=20,
            max_connections=100,
            keepalive_expiry=30.0,
        )

        user_agent = _sdk_user_agent()

        # CLIENT 1: Alter Backend Client (_alter_client)
        # Auth: x-api-key + X-Alter-* actor headers
        # Target: Alter Vault backend only
        alter_headers = self._build_alter_client_headers()

        self._alter_client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=alter_headers,
            timeout=timeout,
            limits=_shared_limits,
            http2=_http2_enabled,
        )

        # CLIENT 2: Provider API Client (_provider_client)
        # Auth: OAuth Bearer token (added per-request)
        # Target: External APIs (Google, Stripe, GitHub, etc.)
        # SECURITY: NO x-api-key header!
        try:
            self._provider_client = httpx.AsyncClient(
                headers={
                    "User-Agent": user_agent,
                },
                timeout=timeout,
                limits=_shared_limits,
                http2=_http2_enabled,
            )
        except Exception:
            # Ensure _alter_client is not leaked if _provider_client fails.
            # We can't call aclose() synchronously, but deleting the reference
            # allows httpx's __del__ to clean up the transport.
            del self._alter_client
            raise

    @staticmethod
    def _validate_actor_string(
        value: str | None,
        name: str,
        max_length: int = MAX_ACTOR_STRING_LENGTH,
    ) -> None:
        """Validate an actor string parameter for length and safe characters."""
        if value is None:
            return
        if len(value) > max_length:
            raise ValueError(f"{name} exceeds max length ({max_length}): {len(value)}")
        if not _SAFE_HEADER_PATTERN.match(value):
            raise ValueError(f"{name} contains invalid characters (only printable ASCII allowed)")

    @staticmethod
    def _validate_init_params(
        api_key: str,
        actor_type: str | None,
        actor_identifier: str | None,
    ) -> None:
        """Validate constructor parameters. Raises ValueError on invalid input."""
        if not api_key:
            raise ValueError("api_key is required")
        if not api_key.startswith("alter_key_"):
            raise ValueError("api_key must start with 'alter_key_'")

        if actor_type and actor_type not in ("ai_agent", "mcp_server"):
            raise ValueError("actor_type must be 'ai_agent' or 'mcp_server'")
        if actor_type and not actor_identifier:
            raise ValueError("actor_identifier is required when actor_type is set")

    def _build_alter_client_headers(self) -> dict[str, str]:
        """
        Build default headers for the Alter backend HTTP client.

        Includes x-api-key for authentication and X-Alter-* headers for
        actor tracking (if configured). These headers are only sent to
        the Alter backend, never to external providers.
        """
        headers: dict[str, str] = {
            "x-api-key": self._api_key,
            "User-Agent": _sdk_user_agent(),
        }

        # Actor tracking headers (only added when actor is configured)
        _actor_headers = {
            "X-Alter-Actor-Type": self._actor_type,
            "X-Alter-Actor-Identifier": self._actor_identifier,
            "X-Alter-Actor-Name": self._actor_name,
            "X-Alter-Actor-Version": self._actor_version,
            "X-Alter-Client-Type": self._client_type,
            "X-Alter-Framework": self._framework,
        }
        headers.update({k: v for k, v in _actor_headers.items() if v})

        return headers

    def _get_actor_request_headers(
        self,
        run_id: str | None = None,
        thread_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> dict[str, str]:
        """
        Build per-request actor headers for instance tracking.

        These headers supplement the static actor headers set on _alter_client.
        They include the cached actor_id (for fast path) and instance-specific
        tracking fields (run_id, thread_id, tool_call_id) which change per request.

        Args:
            run_id: LangGraph run execution ID (UUID string)
            thread_id: LangGraph conversation thread ID
            tool_call_id: LangGraph tool invocation ID

        Returns:
            Dict of per-request headers to include in the request
        """
        headers: dict[str, str] = {}

        # Include cached actor_id for fast path (skip DB registration)
        if self._cached_actor_id:
            headers["X-Alter-Actor-ID"] = self._cached_actor_id

        # Instance tracking fields (per-request, not per-actor)
        if run_id:
            try:
                UUID(run_id)
                headers["X-Alter-Run-ID"] = run_id
            except ValueError:
                logger.warning("Invalid run_id (must be UUID), skipping: %s", run_id)
        if thread_id:
            if len(thread_id) <= MAX_TRACKING_ID_LENGTH and _SAFE_HEADER_PATTERN.match(thread_id):
                headers["X-Alter-Thread-ID"] = thread_id
            else:
                logger.warning("Invalid thread_id (too long or invalid chars), skipping")
        if tool_call_id:
            if len(tool_call_id) <= MAX_TRACKING_ID_LENGTH and _SAFE_HEADER_PATTERN.match(
                tool_call_id,
            ):
                headers["X-Alter-Tool-Call-ID"] = tool_call_id
            else:
                logger.warning("Invalid tool_call_id (too long or invalid chars), skipping")

        return headers

    def _cache_actor_id_from_response(self, response: httpx.Response) -> None:
        """
        Cache actor_id from response header for subsequent requests.

        The backend returns X-Alter-Actor-ID after registering the actor.
        SDK caches this to include in future requests, allowing the backend
        to skip database lookups (fast path).
        """
        actor_id = response.headers.get("X-Alter-Actor-ID")
        if actor_id and not self._cached_actor_id:
            try:
                UUID(actor_id)
            except ValueError:
                logger.warning(
                    "Invalid actor_id in response header (not a UUID), ignoring: %s",
                    actor_id,
                )
                return
            self._cached_actor_id = actor_id
            logger.debug("Cached actor_id from backend: %s", actor_id)
        elif actor_id and self._cached_actor_id and actor_id != self._cached_actor_id:
            # Log when backend returns a different actor_id (should not happen
            # with idempotent upsert, but helps diagnose backend bugs).
            logger.warning(
                "Backend returned different actor_id (%s) than cached (%s), ignoring",
                actor_id,
                self._cached_actor_id,
            )

    @staticmethod
    def _safe_parse_json(response: httpx.Response) -> dict[str, Any]:
        """Parse JSON from response, returning empty dict on failure."""
        try:
            return response.json()  # type: ignore[no-any-return]
        except Exception:
            return {"message": response.text[:500] if response.text else "Unknown error"}

    def _raise_policy_violation(self, error_data: dict[str, Any]) -> None:
        """Raise PolicyViolationError from error data."""
        raise PolicyViolationError(
            message=error_data.get("message", "Access denied by policy"),
            policy_error=error_data.get("error"),
            details=error_data.get("details", {}),
        )

    def _raise_connection_not_found(self, error_data: dict[str, Any]) -> None:
        """Raise ConnectionNotFoundError from error data."""
        raise ConnectionNotFoundError(
            message=error_data.get(
                "message",
                "OAuth connection not found for these attributes",
            ),
            details=error_data,
        )

    def _raise_token_expired(self, error_data: dict[str, Any]) -> None:
        """Raise TokenExpiredError from error data."""
        raise TokenExpiredError(
            message=error_data.get(
                "message",
                "Token expired and refresh failed",
            ),
            connection_id=error_data.get("connection_id"),
            details=error_data,
        )

    def _handle_error_response(self, response: httpx.Response) -> None:
        """
        Handle HTTP error responses from backend.

        Raises appropriate exceptions based on status code.
        Uses _safe_parse_json to avoid crashes on non-JSON responses
        (e.g. HTML from reverse proxies or load balancers).
        """
        if response.status_code == HTTP_FORBIDDEN:
            error_data = self._safe_parse_json(response)
            self._raise_policy_violation(error_data)

        if response.status_code == HTTP_NOT_FOUND:
            error_data = self._safe_parse_json(response)
            self._raise_connection_not_found(error_data)

        if response.status_code in (HTTP_BAD_REQUEST, HTTP_BAD_GATEWAY):
            error_data = self._safe_parse_json(response)
            if "token_expired" in str(error_data).lower():
                self._raise_token_expired(error_data)
            raise TokenRetrievalError(
                message=error_data.get("message", f"Backend error {response.status_code}"),
                details=error_data,
            )

        if response.status_code == HTTP_UNAUTHORIZED:
            error_data = self._safe_parse_json(response)
            raise TokenRetrievalError(
                message=error_data.get("message", "Unauthorized — check your API key"),
                details=error_data,
            )

        if response.status_code in (HTTP_INTERNAL_SERVER_ERROR, HTTP_SERVICE_UNAVAILABLE):
            error_data = self._safe_parse_json(response)
            raise TokenRetrievalError(
                message=error_data.get(
                    "message",
                    f"Backend unavailable (HTTP {response.status_code})",
                ),
                details=error_data,
            )

        # Catch-all for any other error status codes
        if response.status_code >= HTTP_CLIENT_ERROR_START:
            error_data = self._safe_parse_json(response)
            raise TokenRetrievalError(
                message=error_data.get(
                    "message",
                    f"Unexpected backend error (HTTP {response.status_code})",
                ),
                details=error_data,
            )

    async def _get_token(
        self,
        provider_id: str,
        attributes: dict[str, Any],
        reason: str | None = None,
        run_id: str | None = None,
        thread_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> TokenResponse:
        """
        Retrieve OAuth access token for a provider and user (INTERNAL USE ONLY).

        This is a private method. Tokens are NEVER exposed to developers.
        Use request() instead, which handles tokens internally.

        Args:
            provider_id: OAuth provider identifier (e.g., "google", "github")
            attributes: User attributes to match connection (e.g., {"user_id": "alice"})
            reason: Optional reason for token access (for audit)
            run_id: Run execution ID (for actor instance tracking)
            thread_id: Conversation thread ID
            tool_call_id: Tool invocation ID

        Returns:
            TokenResponse with access token and metadata (for internal use only)

        Raises:
            PolicyViolationError: If access denied by policy (403)
            ConnectionNotFoundError: If no connection found (404)
            TokenExpiredError: If token refresh failed (400/502)
            NetworkError: If backend unreachable
            TokenRetrievalError: For other errors
        """
        actor_headers = self._get_actor_request_headers(
            run_id=run_id,
            thread_id=thread_id,
            tool_call_id=tool_call_id,
        )

        try:
            response = await self._alter_client.post(
                "/oauth/token",
                json={
                    "provider_id": provider_id,
                    "attributes": attributes,
                    "reason": reason,
                },
                headers=actor_headers,
            )

            self._cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise NetworkError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            PolicyViolationError,
            ConnectionNotFoundError,
            TokenExpiredError,
            TokenRetrievalError,
        ):
            raise

        except Exception as e:
            raise TokenRetrievalError(
                message=f"Failed to retrieve token: {e}",
                details={"provider_id": provider_id, "error": str(e)},
            ) from e
        else:
            token_data = response.json()
            token = TokenResponse(**token_data)

            logger.debug("Retrieved token for %s", provider_id)
            return token

    async def _log_api_call(
        self,
        connection_id: UUID,
        provider_id: str,
        method: str,
        url: str,
        request_headers: dict[str, str] | None = None,
        request_body: Any | None = None,
        response_status: int = 0,
        response_headers: dict[str, str] | None = None,
        response_body: Any | None = None,
        latency_ms: int = 0,
        reason: str | None = None,
    ) -> None:
        """
        Log an API call to the backend audit endpoint (INTERNAL).

        This method NEVER raises exceptions to avoid crashing the application
        if audit logging fails.
        """
        if not self.enable_audit_logging:
            return

        try:
            audit_log = APICallAuditLog(
                connection_id=connection_id,
                provider_id=provider_id,
                method=method,
                url=url,
                request_headers=request_headers,
                request_body=request_body,
                response_status=response_status,
                response_headers=response_headers,
                response_body=response_body,
                latency_ms=latency_ms,
                reason=reason,
            )

            sanitized = audit_log.sanitize()

            actor_headers = self._get_actor_request_headers()
            response = await self._alter_client.post(
                "/oauth/audit/api-call",
                json=sanitized,
                headers=actor_headers,
            )

            self._cache_actor_id_from_response(response)
            response.raise_for_status()

            logger.debug("Logged API call to %s", url)

        except Exception as e:
            # NEVER raise - log warning and continue
            logger.warning("Failed to log API call (non-fatal): %s", e)

    @staticmethod
    def _safe_response_body(response: httpx.Response, max_bytes: int = MAX_BODY_SIZE_BYTES) -> str:
        """Extract response body for audit logging without decoding large/binary payloads."""
        content_length = len(response.content)
        if content_length == 0:
            return ""
        # Skip decode for large responses (e.g. binary file downloads)
        if content_length > max_bytes:
            return f"<response too large: {content_length} bytes>"
        try:
            text = response.text
        except Exception:
            return f"<binary response: {content_length} bytes>"
        if len(text) > max_bytes:
            return text[:max_bytes] + "..."
        return text

    def _schedule_audit_log(
        self,
        **kwargs: Any,
    ) -> None:
        """Schedule audit logging as a background task (true fire-and-forget)."""
        task = asyncio.create_task(self._log_api_call(**kwargs))
        self._audit_tasks.add(task)
        task.add_done_callback(self._audit_tasks.discard)

    async def request(
        self,
        provider: Provider | str,
        method: HttpMethod | str,
        url: str,
        *,
        user: dict[str, Any],
        json: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        query_params: dict[str, Any] | None = None,
        path_params: dict[str, str] | None = None,
        reason: str | None = None,
        run_id: str | None = None,
        thread_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> httpx.Response:
        """
        Execute an HTTP request to a provider API with automatic token injection.

        This is the single entry point for all provider API calls. The SDK:
        1. Fetches an OAuth token from Alter backend (never exposed)
        2. Injects the token as a Bearer header
        3. Calls the provider API
        4. Logs the call for audit (if enabled, fire-and-forget)
        5. Returns the raw response

        Args:
            provider: OAuth provider (Provider enum or string).
                     - Type-safe: Provider.GOOGLE, Provider.SALESFORCE
                     - String: "google", "stripe" (forward compatible)
            method: HTTP method (HttpMethod enum or string).
                   - Type-safe: HttpMethod.GET, HttpMethod.POST
                   - String: "GET", "POST" (forward compatible)
            url: Full URL of the provider API endpoint. Must start with
                 ``https://`` or ``http://``. Supports ``{placeholder}``
                 templates when used with *path_params*.
            user: User attributes to match connection (e.g., {"user_id": "alice"})
            json: Optional JSON request body
            extra_headers: Optional additional headers *in addition to* the
                          auto-injected Authorization Bearer header. Note:
                          an ``Authorization`` key here will be overwritten.
            query_params: Optional URL query parameters
            path_params: Optional URL path template substitutions.
                        e.g. url="/items/{item_id}" + path_params={"item_id": "123"}
                        → "/items/123"
            reason: Optional reason for API call (for audit)
            run_id: Run execution ID (UUID, for actor instance tracking)
            thread_id: Conversation thread ID
            tool_call_id: Tool invocation ID

        Returns:
            httpx.Response from the provider API

        Raises:
            ValueError: If URL scheme is invalid or path_params are missing
            PolicyViolationError: If access denied by policy (403)
            ConnectionNotFoundError: If no connection found (404)
            TokenExpiredError: If token refresh failed (400/502)
            NetworkError: If API or backend unreachable
            ProviderAPIError: If provider API returns error (4xx/5xx)

        Example:
            ```python
            # Simple GET
            response = await vault.request(
                Provider.GOOGLE, HttpMethod.GET,
                "https://www.googleapis.com/calendar/v3/calendars/primary/events",
                user={"user_id": "alice"},
                query_params={"maxResults": 10},
            )

            # URL path templating
            response = await vault.request(
                Provider.SALESFORCE, HttpMethod.GET,
                "https://api.example.com/v1/items/{item_id}",
                user={"org_id": "acme"},
                path_params={"item_id": "123"},
            )

            # Full example with all options
            response = await vault.request(
                Provider.GOOGLE, HttpMethod.POST,
                "https://api.example.com/v1/items/{item_id}",
                user={"user_id": "alice"},
                path_params={"item_id": "123"},
                query_params={"fields": "name,price"},
                json={"name": "Updated"},
                extra_headers={"Notion-Version": "2022-06-28"},
                reason="Updating item",
            )
            ```
        """
        provider_str = provider.value if isinstance(provider, Provider) else str(provider)
        method_str = method.value if isinstance(method, HttpMethod) else str(method).upper()

        # Validate URL scheme to prevent SSRF (token sent to arbitrary destinations)
        if not any(url.startswith(scheme) for scheme in _ALLOWED_URL_SCHEMES):
            raise ValueError(
                f"URL must start with https:// or http://, got: {url[:50]}",
            )

        # Apply path_params to URL template (URL-encode values for safety)
        if path_params:
            encoded_params = {k: quote(str(v), safe="") for k, v in path_params.items()}
            try:
                url = url.format(**encoded_params)
            except (KeyError, ValueError) as e:
                raise ValueError(
                    f"Invalid URL template or missing path_params: {e}. "
                    f"URL: {url}, path_params: {path_params}",
                ) from e

        # Warn if extra_headers contains Authorization (will be overwritten)
        if extra_headers and "Authorization" in extra_headers:
            logger.warning(
                "extra_headers contains 'Authorization' which will be overwritten "
                "with the auto-injected Bearer token",
            )

        # Get token internally (NEVER exposed to developer)
        token_response = await self._get_token(
            provider_id=provider_str,
            attributes=user,
            reason=reason,
            run_id=run_id,
            thread_id=thread_id,
            tool_call_id=tool_call_id,
        )

        # Build headers with automatic token injection
        request_headers = extra_headers.copy() if extra_headers else {}
        request_headers["Authorization"] = f"Bearer {token_response.access_token}"
        request_headers.setdefault("User-Agent", _sdk_user_agent())

        # Execute request using provider client (NO x-api-key!)
        start_time = time.time()
        try:
            response = await self._provider_client.request(
                method=method_str,
                url=url,
                json=json,
                headers=request_headers,
                params=query_params,
            )

            latency_ms = int((time.time() - start_time) * 1000)

            # Strip Authorization header before passing to audit log
            # (defense-in-depth: sanitize() also strips it, but don't send it at all)
            audit_headers = {
                k: v for k, v in request_headers.items() if k.lower() != "authorization"
            }

            # Schedule audit log as fire-and-forget background task
            self._schedule_audit_log(
                connection_id=token_response.connection_id,
                provider_id=provider_str,
                method=method_str,
                url=url,
                request_headers=audit_headers,
                request_body=json,
                response_status=response.status_code,
                response_headers=dict(response.headers),
                response_body=self._safe_response_body(response),
                latency_ms=latency_ms,
                reason=reason,
            )

            # Check for HTTP errors
            if response.status_code >= HTTP_CLIENT_ERROR_START:
                raise ProviderAPIError(  # noqa: TRY301
                    message=f"Provider API returned error {response.status_code}",
                    status_code=response.status_code,
                    response_body=self._safe_response_body(response),
                    details={
                        "provider": provider_str,
                        "method": method_str,
                        "url": url,
                    },
                )

            return response  # noqa: TRY300

        except ProviderAPIError:
            raise
        except httpx.HTTPError as e:
            raise NetworkError(
                message=f"Failed to call provider API: {e}",
                details={
                    "provider": provider_str,
                    "method": method_str,
                    "url": url,
                    "error": str(e),
                },
            ) from e

    async def close(self) -> None:
        """Close HTTP clients and release resources."""
        # Wait for any pending audit tasks before closing clients
        if self._audit_tasks:
            await asyncio.gather(*self._audit_tasks, return_exceptions=True)
        try:
            await self._alter_client.aclose()
        finally:
            await self._provider_client.aclose()

    async def __aenter__(self) -> "AlterVault":
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Async context manager exit."""
        await self.close()
