#!/usr/bin/sh
pytest
