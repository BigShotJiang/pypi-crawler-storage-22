"""
AMIAI SDK - Build AI agents with local tool execution

Example:
    from amiai_sdk import tool, Harness

    @tool(
        name="web_search",
        description="Search the web for information"
    )
    async def search(query: str) -> dict:
        # Your API key stays local
        response = await fetch(f"https://api.example.com/search?q={query}")
        return response.json()

    # Start the harness
    harness = Harness(api_key="amiai_xxx", tools=[search])
    await harness.start()
"""

from .tool import tool, Tool
from .harness import Harness, start_harness

__version__ = "0.1.0"
__all__ = ["tool", "Tool", "Harness", "start_harness"]
