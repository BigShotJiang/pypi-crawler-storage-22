"""
AMIAI CLI - Run the tool harness

Usage:
    amiai dev                    # Discover and run tools
    amiai dev --pattern "*.py"   # Custom pattern
"""

import argparse
import asyncio
import importlib.util
import os
import sys
from glob import glob
from pathlib import Path
from typing import List

from .tool import Tool
from .harness import Harness


def discover_tools(patterns: List[str]) -> List[Tool]:
    """Discover tools from Python files matching patterns."""
    tools: List[Tool] = []
    seen_files: set = set()
    
    for pattern in patterns:
        for file_path in glob(pattern, recursive=True):
            abs_path = os.path.abspath(file_path)
            if abs_path in seen_files:
                continue
            seen_files.add(abs_path)
            
            # Skip __pycache__ and hidden files
            if "__pycache__" in file_path or file_path.startswith("."):
                continue
            
            try:
                tools.extend(load_tools_from_file(file_path))
            except Exception as e:
                print(f"Warning: Failed to load {file_path}: {e}")
    
    return tools


def load_tools_from_file(file_path: str) -> List[Tool]:
    """Load Tool instances from a Python file."""
    tools: List[Tool] = []
    
    spec = importlib.util.spec_from_file_location("tool_module", file_path)
    if spec is None or spec.loader is None:
        return tools
    
    module = importlib.util.module_from_spec(spec)
    
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        print(f"Warning: Error loading {file_path}: {e}")
        return tools
    
    # Find all Tool instances in the module
    for name in dir(module):
        obj = getattr(module, name)
        if isinstance(obj, Tool):
            tools.append(obj)
    
    return tools


async def run_harness(api_key: str, tools: List[Tool], url: str) -> None:
    """Run the harness with discovered tools."""
    print(f"\n{'='*50}")
    print("AMIAI Tool Harness")
    print(f"{'='*50}\n")
    
    if not tools:
        print("No tools found!")
        print("\nCreate a tool file like this:")
        print("  # tools/search.py")
        print("  from amiai_sdk import tool")
        print("")
        print("  @tool(name='web_search', description='Search the web')")
        print("  async def search(query: str) -> dict:")
        print("      return {'results': [...]}")
        return
    
    print(f"Found {len(tools)} tool(s):")
    for t in tools:
        print(f"  - {t.name}: {t.description[:50]}...")
    print()
    
    def on_connect(session_id: str) -> None:
        print(f"✓ Connected to AMIAI")
        print(f"  Session ID: {session_id}")
        print(f"\n✓ Waiting for invocations...\n")
    
    def on_disconnect() -> None:
        print("⚠ Disconnected from AMIAI")
    
    def on_invoke(tool_name: str, args: dict) -> None:
        print(f"→ Invoking: {tool_name}")
        print(f"  Args: {args}")
    
    def on_result(tool_name: str, result: any) -> None:
        result_str = str(result)
        if len(result_str) > 100:
            result_str = result_str[:100] + "..."
        print(f"← Result: {result_str}")
    
    def on_error(error: Exception) -> None:
        print(f"✗ Error: {error}")
    
    harness = Harness(
        api_key=api_key,
        tools=tools,
        url=url,
        on_connect=on_connect,
        on_disconnect=on_disconnect,
        on_invoke=on_invoke,
        on_result=on_result,
        on_error=on_error,
    )
    
    try:
        await harness.run_forever()
    except KeyboardInterrupt:
        print("\n\nStopping...")
        await harness.stop()
        print("Done!")


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="AMIAI Tool Harness - Run local tools for AI agents"
    )
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # dev command
    dev_parser = subparsers.add_parser("dev", help="Run the tool harness")
    dev_parser.add_argument(
        "--pattern",
        "-p",
        action="append",
        default=None,
        help="Glob pattern for tool files (default: **/*.tool.py, **/tools/*.py)",
    )
    dev_parser.add_argument(
        "--url",
        default=os.environ.get("AMIAI_URL", "wss://backend.amiai.com/api/tools/live"),
        help="AMIAI WebSocket URL",
    )
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    if args.command == "dev":
        api_key = os.environ.get("AMIAI_API_KEY")
        if not api_key:
            print("Error: AMIAI_API_KEY environment variable is required")
            print("\nUsage:")
            print("  export AMIAI_API_KEY=amiai_xxx")
            print("  amiai dev")
            sys.exit(1)
        
        patterns = args.pattern or ["**/*.tool.py", "**/tools/*.py"]
        tools = discover_tools(patterns)
        
        asyncio.run(run_harness(api_key, tools, args.url))


if __name__ == "__main__":
    main()
