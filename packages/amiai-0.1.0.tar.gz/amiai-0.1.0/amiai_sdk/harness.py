"""
AMIAI Harness - WebSocket client for local tool execution

Connects to AMIAI backend and registers tools. When the agent needs to
call a tool, the invocation is routed here and executed locally.
"""

import asyncio
import json
import logging
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field

import websockets
from websockets.client import WebSocketClientProtocol

from .tool import Tool

logger = logging.getLogger("amiai_sdk")

DEFAULT_URL = "wss://backend.amiai.com/api/tools/live"
RECONNECT_DELAY_SEC = 5
HEARTBEAT_INTERVAL_SEC = 30


@dataclass
class HarnessOptions:
    """Configuration for the Harness."""
    api_key: str
    tools: List[Tool]
    url: str = DEFAULT_URL
    on_connect: Optional[Callable[[str], None]] = None
    on_disconnect: Optional[Callable[[], None]] = None
    on_invoke: Optional[Callable[[str, Dict[str, Any]], None]] = None
    on_result: Optional[Callable[[str, Any], None]] = None
    on_error: Optional[Callable[[Exception], None]] = None
    auto_reconnect: bool = True


class Harness:
    """
    WebSocket client for local tool execution.
    
    Example:
        harness = Harness(
            api_key="amiai_xxx",
            tools=[my_tool],
            on_connect=lambda sid: print(f"Connected: {sid}"),
        )
        await harness.start()
    """
    
    def __init__(
        self,
        api_key: str,
        tools: List[Tool],
        url: str = DEFAULT_URL,
        on_connect: Optional[Callable[[str], None]] = None,
        on_disconnect: Optional[Callable[[], None]] = None,
        on_invoke: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        on_result: Optional[Callable[[str, Any], None]] = None,
        on_error: Optional[Callable[[Exception], None]] = None,
        auto_reconnect: bool = True,
    ):
        self.api_key = api_key
        self.tools = {t.name: t for t in tools}
        self.tools_list = tools
        self.url = url
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect
        self.on_invoke = on_invoke
        self.on_result = on_result
        self.on_error = on_error
        self.auto_reconnect = auto_reconnect
        
        self._ws: Optional[WebSocketClientProtocol] = None
        self._session_id: Optional[str] = None
        self._running = False
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._receive_task: Optional[asyncio.Task] = None
    
    @property
    def session_id(self) -> Optional[str]:
        """Get the current session ID."""
        return self._session_id
    
    @property
    def is_connected(self) -> bool:
        """Check if connected to AMIAI."""
        return self._ws is not None and self._session_id is not None
    
    async def start(self) -> str:
        """
        Start the harness and connect to AMIAI.
        
        Returns:
            The session ID
        """
        self._running = True
        return await self._connect()
    
    async def stop(self) -> None:
        """Stop the harness and disconnect."""
        self._running = False
        self.auto_reconnect = False
        
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
        
        if self._receive_task:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass
        
        if self._ws:
            await self._ws.close()
            self._ws = None
        
        self._session_id = None
    
    async def run_forever(self) -> None:
        """Run the harness until stopped."""
        await self.start()
        
        while self._running:
            await asyncio.sleep(1)
    
    async def _connect(self) -> str:
        """Connect to AMIAI and register tools."""
        try:
            self._ws = await websockets.connect(self.url)
            
            # Send hello
            await self._send({
                "type": "hello",
                "apiKey": self.api_key,
                "tools": [t.to_manifest() for t in self.tools_list],
            })
            
            # Wait for ack
            response = await self._ws.recv()
            message = json.loads(response)
            
            if message.get("type") == "ack":
                self._session_id = message.get("sessionId")
                if self._session_id and self.on_connect:
                    self.on_connect(self._session_id)
                
                # Start background tasks
                self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                self._receive_task = asyncio.create_task(self._receive_loop())
                
                return self._session_id or ""
            elif message.get("type") == "error":
                raise Exception(f"Connection error: {message.get('message')}")
            else:
                raise Exception(f"Unexpected response: {message}")
                
        except Exception as e:
            if self.on_error:
                self.on_error(e)
            raise
    
    async def _send(self, message: Dict[str, Any]) -> None:
        """Send a message to the server."""
        if self._ws:
            await self._ws.send(json.dumps(message))
    
    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeats."""
        while self._running and self._ws:
            try:
                await asyncio.sleep(HEARTBEAT_INTERVAL_SEC)
                await self._send({"type": "heartbeat"})
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.debug(f"Heartbeat error: {e}")
    
    async def _receive_loop(self) -> None:
        """Receive and handle messages from server."""
        while self._running and self._ws:
            try:
                message_str = await self._ws.recv()
                message = json.loads(message_str)
                await self._handle_message(message)
            except websockets.ConnectionClosed:
                logger.info("Connection closed")
                self._session_id = None
                if self.on_disconnect:
                    self.on_disconnect()
                
                if self.auto_reconnect and self._running:
                    await self._reconnect()
                break
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Receive error: {e}")
                if self.on_error:
                    self.on_error(e)
    
    async def _reconnect(self) -> None:
        """Attempt to reconnect after disconnection."""
        logger.info(f"Reconnecting in {RECONNECT_DELAY_SEC}s...")
        await asyncio.sleep(RECONNECT_DELAY_SEC)
        
        if self._running:
            try:
                await self._connect()
            except Exception as e:
                logger.error(f"Reconnection failed: {e}")
                if self._running:
                    await self._reconnect()
    
    async def _handle_message(self, message: Dict[str, Any]) -> None:
        """Handle an incoming message."""
        msg_type = message.get("type")
        
        if msg_type == "invoke":
            call_id = message.get("callId")
            tool_name = message.get("tool")
            args = message.get("args", {})
            
            if call_id and tool_name:
                await self._handle_invoke(call_id, tool_name, args)
        
        elif msg_type == "cancel":
            call_id = message.get("callId")
            logger.info(f"Cancellation requested for {call_id}")
        
        elif msg_type == "ping":
            await self._send({"type": "heartbeat"})
        
        elif msg_type == "error":
            error_msg = message.get("message", "Unknown error")
            logger.error(f"Server error: {error_msg}")
            if self.on_error:
                self.on_error(Exception(error_msg))
    
    async def _handle_invoke(
        self,
        call_id: str,
        tool_name: str,
        args: Dict[str, Any],
    ) -> None:
        """Handle a tool invocation."""
        tool = self.tools.get(tool_name)
        
        if not tool:
            await self._send({
                "type": "error",
                "callId": call_id,
                "message": f"Tool not found: {tool_name}",
            })
            return
        
        if self.on_invoke:
            self.on_invoke(tool_name, args)
        
        try:
            # Send started event
            await self._send({
                "type": "event",
                "callId": call_id,
                "event": "started",
                "data": {"tool": tool_name},
            })
            
            # Execute the tool
            if asyncio.iscoroutinefunction(tool.execute):
                result = await tool.execute(**args)
            else:
                result = tool.execute(**args)
            
            # Send result
            await self._send({
                "type": "result",
                "callId": call_id,
                "output": result,
            })
            
            if self.on_result:
                self.on_result(tool_name, result)
                
        except Exception as e:
            error_msg = str(e)
            await self._send({
                "type": "error",
                "callId": call_id,
                "message": error_msg,
            })
            
            if self.on_error:
                self.on_error(e)


async def start_harness(
    api_key: str,
    tools: List[Tool],
    url: str = DEFAULT_URL,
    **kwargs,
) -> Harness:
    """
    Create and start a harness.
    
    Example:
        harness = await start_harness(
            api_key="amiai_xxx",
            tools=[my_tool],
        )
    """
    harness = Harness(api_key=api_key, tools=tools, url=url, **kwargs)
    await harness.start()
    return harness
