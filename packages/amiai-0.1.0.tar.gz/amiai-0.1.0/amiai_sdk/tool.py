"""
Tool definition and decorator for AMIAI SDK

Example:
    from amiai_sdk import tool

    @tool(name="calculator", description="Evaluate math expressions")
    async def calculate(expression: str) -> dict:
        result = eval(expression)
        return {"expression": expression, "result": result}
"""

from typing import Any, Callable, Dict, List, Optional, Type, get_type_hints
from dataclasses import dataclass
import inspect
import json


@dataclass
class InputField:
    """Schema for a tool input field."""
    type: str
    description: Optional[str] = None
    required: bool = True
    default: Any = None
    enum: Optional[List[str]] = None


@dataclass
class Tool:
    """A tool that can be registered with AMIAI."""
    name: str
    description: str
    input_schema: Dict[str, Any]
    execute: Callable[..., Any]

    def to_manifest(self) -> Dict[str, Any]:
        """Convert to manifest format for registration."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


def _python_type_to_json_type(python_type: Type) -> str:
    """Convert Python type hints to JSON Schema types."""
    type_map = {
        str: "string",
        int: "number",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
        List: "array",
        Dict: "object",
    }
    
    # Handle generic types like List[str], Dict[str, Any]
    origin = getattr(python_type, "__origin__", None)
    if origin is not None:
        if origin is list:
            return "array"
        if origin is dict:
            return "object"
    
    return type_map.get(python_type, "string")


def _derive_schema_from_function(func: Callable) -> Dict[str, Any]:
    """Derive JSON Schema from function signature."""
    sig = inspect.signature(func)
    hints = get_type_hints(func) if hasattr(func, "__annotations__") else {}
    
    properties: Dict[str, Any] = {}
    required: List[str] = []
    
    for name, param in sig.parameters.items():
        if name in ("self", "cls"):
            continue
        
        # Get type from hints or default to string
        param_type = hints.get(name, str)
        json_type = _python_type_to_json_type(param_type)
        
        properties[name] = {
            "type": json_type,
        }
        
        # Check if parameter has a default
        if param.default is inspect.Parameter.empty:
            required.append(name)
        else:
            properties[name]["default"] = param.default
    
    return {
        "type": "object",
        "properties": properties,
        "required": required,
    }


def tool(
    name: str,
    description: str,
    input_schema: Optional[Dict[str, Any]] = None,
) -> Callable[[Callable], Tool]:
    """
    Decorator to define a tool for AMIAI agents.
    
    Args:
        name: Unique name for the tool
        description: Description shown to the AI
        input_schema: Optional JSON Schema for inputs (auto-derived if not provided)
    
    Example:
        @tool(name="web_search", description="Search the web")
        async def search(query: str) -> dict:
            response = await fetch(f"https://api.example.com/search?q={query}")
            return response.json()
    
    Example with explicit schema:
        @tool(
            name="calculator",
            description="Evaluate math expressions",
            input_schema={
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "e.g., 2+2"}
                },
                "required": ["expression"]
            }
        )
        async def calculate(expression: str) -> dict:
            return {"result": eval(expression)}
    """
    def decorator(func: Callable) -> Tool:
        schema = input_schema or _derive_schema_from_function(func)
        
        return Tool(
            name=name,
            description=description,
            input_schema=schema,
            execute=func,
        )
    
    return decorator
