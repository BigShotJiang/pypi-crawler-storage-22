"""
Example: Calculator Tool

A simple calculator that doesn't require external APIs.
Good for testing the Live Tool RPC flow.

Run with: AMIAI_API_KEY=xxx amiai dev
"""

from amiai_sdk import tool


@tool(name="calculator", description="Perform mathematical calculations")
def calculator(expression: str) -> dict:
    """
    Evaluate a mathematical expression.
    
    Args:
        expression: Math expression like "2 + 2 * 3"
    """
    print(f"[calculator] Evaluating: {expression}")
    
    # Safe evaluation - only allow numbers and basic operators
    import re
    sanitized = re.sub(r'[^0-9+\-*/().%\s]', '', expression)
    
    if sanitized != expression:
        raise ValueError("Invalid characters in expression")
    
    result = eval(sanitized)
    print(f"[calculator] Result: {result}")
    
    return {
        "expression": expression,
        "result": result,
    }
