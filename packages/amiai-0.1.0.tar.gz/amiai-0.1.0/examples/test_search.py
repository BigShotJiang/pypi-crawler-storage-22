"""
Test script for Parallel AI Search via Live Tool RPC (Python)

Usage:
    1. Start worker: cd apps/worker && pnpm dev
    2. Run this: PARALLEL_API_KEY=xxx AMIAI_API_KEY=xxx python test_search.py
"""

import asyncio
import os
import httpx
from amiai_sdk import tool, Harness


@tool(name="web_search", description="Search the web using Parallel AI")
async def search(query: str) -> dict:
    api_key = os.environ.get("PARALLEL_API_KEY")
    if not api_key:
        raise ValueError("PARALLEL_API_KEY environment variable is required")
    
    print(f"[web_search] Searching for: {query}")
    
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "https://api.parallel.ai/v1beta/search",
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "parallel-beta": "search-extract-2025-10-10",
            },
            json={"search_queries": [query]},
            timeout=30.0,
        )
        response.raise_for_status()
        data = response.json()
    
    results = data.get("results", [])
    print(f"[web_search] Found {len(results)} results")
    
    return {
        "query": query,
        "results": [
            {
                "title": r.get("title", ""),
                "url": r.get("url", ""),
                "snippet": (r.get("excerpts") or [""])[0][:300],
            }
            for r in results[:5]
        ]
    }


async def main():
    api_key = os.environ.get("AMIAI_API_KEY", "amiai_dev_0000000000000000000000000000000000000000")
    ws_url = os.environ.get("AMIAI_URL", "ws://localhost:8787/api/tools/live")
    
    if not os.environ.get("PARALLEL_API_KEY"):
        print("Error: PARALLEL_API_KEY environment variable is required")
        return
    
    print("=== Live Tool RPC - Python Search Test ===\n")
    
    session_id = None
    
    def on_connect(sid: str):
        nonlocal session_id
        session_id = sid
        print(f"✓ Connected with session ID: {sid}")
    
    def on_invoke(tool_name: str, args: dict):
        print(f"→ Tool invoked: {tool_name}")
    
    def on_result(tool_name: str, result):
        print(f"← Result received for: {tool_name}")
    
    harness = Harness(
        api_key=api_key,
        tools=[search],
        url=ws_url,
        on_connect=on_connect,
        on_invoke=on_invoke,
        on_result=on_result,
    )
    
    await harness.start()
    
    print(f"\nHarness connected. Session ID: {session_id}")
    print("Waiting for invocations... Press Ctrl+C to stop.\n")
    
    try:
        await harness.run_forever()
    except KeyboardInterrupt:
        print("\nStopping...")
        await harness.stop()


if __name__ == "__main__":
    asyncio.run(main())
