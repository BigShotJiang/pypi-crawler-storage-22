from typing import Protocol

from src.page_scraper.entities.models import PageContext


class ContentStep(Protocol):
    def run(self, page: PageContext) -> PageContext:
        ...