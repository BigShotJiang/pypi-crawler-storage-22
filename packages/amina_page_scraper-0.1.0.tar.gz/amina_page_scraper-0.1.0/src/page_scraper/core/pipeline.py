from src.page_scraper.content.base import ContentStep
from src.page_scraper.detectors.protocol import EntityDetector, PageStep
from src.page_scraper.entities.models import PageContext
from src.page_scraper.infrastructure.fetcher import HttpFetcher
from src.page_scraper.meta.base import MetaStep
from src.page_scraper.links.base import ScraperStep


class EntityPipeline:
    def __init__(self, detectors: list[EntityDetector]):
        self.detectors = detectors

    def run(self, page):
        entities = []
        for detector in self.detectors:
            entities.extend(detector.detect(page))
        page.entities = entities
        return entities

class CrawlerPipeline:
    def __init__(self, steps: list[PageStep]):
        self.steps = steps
    def process(self, url:str) -> PageContext:
        page = PageContext(url=url)
        for step in self.steps:
            page = step.run(page)
        return page

class ScraperPipeline:
    def __init__(self, steps: list[ScraperStep]):
        self.steps = steps

    def run(self, page: PageContext) -> PageContext:
        for step in self.steps:
            page = step.run(page)
        return page

class MetaPipeline:
    def __init__(self, steps: list[MetaStep]):
        self.steps = steps

    def run(self, page: PageContext) -> PageContext:
        for step in self.steps:
            page = step.run(page)
        return page

class ContentPipeline:
    def __init__(self, steps: list[ContentStep]):
        self.steps = steps

    def run(self, page: PageContext) -> PageContext:
        for step in self.steps:
            page = step.run(page)
        return page