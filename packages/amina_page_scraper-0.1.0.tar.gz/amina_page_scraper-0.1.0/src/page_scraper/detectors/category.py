from src.page_scraper.core.node_utils import has_type
from src.page_scraper.entities.models import Entity, PageContext
from src.page_scraper.entities.builders import build_entity

class CategoryPageDetector:
    def detect(self, page: PageContext) -> list[Entity]:
        categories = []
        for entry  in page.nodes:
            node = entry['node']

            if not has_type(node, "CollectionPage"):
                continue

            categories.append(build_entity(node, "Category"))

        return categories