from typing import Protocol
from src.page_scraper.entities.models import PageContext
from src.page_scraper.infrastructure.fetcher import HttpFetcher


class ScraperStep(Protocol):
    def run(self, page: PageContext) -> PageContext:
        ...