"""
Data generation utilities for AMM backtesting.

Provides synthetic data generation for testing and research.
"""

from ammbt.data.synthetic import generate_swaps, generate_price_path

__all__ = ['generate_swaps', 'generate_price_path']
