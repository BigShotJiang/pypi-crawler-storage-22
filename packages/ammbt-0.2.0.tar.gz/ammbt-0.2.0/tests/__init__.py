"""Tests for ammbt package."""
