"""Integration tests for ammbt."""
