"""Unit tests for ammbt."""
