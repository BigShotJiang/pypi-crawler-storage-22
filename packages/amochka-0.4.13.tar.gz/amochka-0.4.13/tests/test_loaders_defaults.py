import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))


def test_upsert_lead_facts_score_default_zero():
    """Score в БД NOT NULL, но из amoCRM может прийти null: должны писать 0."""

    from etl.config import DatabaseConfig
    from etl.loaders import PostgresLoader

    class DummyCursor:
        def __init__(self):
            self.last_sql = None
            self.last_params = None

        def execute(self, sql, params=None):
            self.last_sql = sql
            self.last_params = params

        def fetchone(self):
            return (123,)

    class LoaderForTest(PostgresLoader):
        def _get_or_create_date_id(self, _cursor, _dt):
            return 1

        def _get_or_create_clientid_id(self, _cursor, _value):
            return 10

        def _get_or_create_traffic_id(self, _cursor, _traffic):
            return 20

        def _get_or_create_company_internal_id(self, _cursor, account_id, company_id):
            return 30

    loader = LoaderForTest(DatabaseConfig(host="x", port=5432, dbname="x", user="x", password="x", schema="core"))
    cur = DummyCursor()

    facts_data = {
        "account_id": 1,
        "companies_id": None,
        "contacts_id": None,
        "users_id": None,
        "price": 0,
        "labor_cost": 0,
        "score": None,
        "created_date": None,
        "modified_date": None,
    }
    loader.upsert_lead_facts(cur, facts_data=facts_data, leads_id=999)

    # score is 12th positional param in upsert_lead_facts execute call, see loaders.py
    assert cur.last_params[11] == 0

