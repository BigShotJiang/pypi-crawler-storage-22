-- Делаем unsorteds_id опциональным (в amoCRM "неразобранное" есть не у всех сделок)
ALTER TABLE IF EXISTS amocrm_leads_facts
    ALTER COLUMN unsorteds_id DROP NOT NULL;
