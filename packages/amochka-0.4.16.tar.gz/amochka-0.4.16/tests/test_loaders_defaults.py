import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))


def test_upsert_lead_facts_score_default_zero():
    """Score в БД NOT NULL, но из amoCRM может прийти null: должны писать 0."""

    from etl.config import DatabaseConfig
    from etl.loaders import PostgresLoader

    class DummyCursor:
        def __init__(self):
            self.last_sql = None
            self.last_params = None

        def execute(self, sql, params=None):
            self.last_sql = sql
            self.last_params = params

        def fetchone(self):
            return (123,)

    class LoaderForTest(PostgresLoader):
        def _get_or_create_date_id(self, _cursor, _dt):
            return 1

        def _get_or_create_clientid_id(self, _cursor, _value):
            return 10

        def _get_or_create_company_internal_id(self, _cursor, account_id, company_id):
            return 30

    loader = LoaderForTest(DatabaseConfig(host="x", port=5432, dbname="x", user="x", password="x", schema="core"))
    cur = DummyCursor()

    facts_data = {
        "account_id": 1,
        "companies_id": None,
        "contacts_id": None,
        "users_id": None,
        "price": 0,
        "labor_cost": 0,
        "score": None,
        "created_date": None,
        "modified_date": None,
    }
    loader.upsert_lead_facts(cur, facts_data=facts_data, leads_id=999)

    # score is 11th positional param in upsert_lead_facts execute call (traffic_id removed), see loaders.py
    assert cur.last_params[10] == 0




def test_upsert_lead_attributes_dedup():
    """В атрибутах сделки возможны дубли attribute_id: должны дедуплицироваться."""

    from etl.config import DatabaseConfig
    from etl.loaders import PostgresLoader

    class DummyCursor:
        def __init__(self):
            self.calls = []

        def execute(self, sql, params=None):
            self.calls.append(("execute", sql, params))

        def executemany(self, sql, seq_of_params):
            self.calls.append(("executemany", sql, list(seq_of_params)))

    loader = PostgresLoader(DatabaseConfig(host="x", port=5432, dbname="x", user="x", password="x", schema="core"))
    cur = DummyCursor()

    attributes = [
        {"account_id": 53859, "attribute_id": 989733, "name": "A", "value": "v1"},
        {"account_id": 53859, "attribute_id": 989733, "name": "A", "value": "v2"},
    ]

    inserted = loader.upsert_lead_attributes(cur, attributes=attributes, leads_id=213596)
    assert inserted == 1

    # Проверяем, что вставка идёт с ON CONFLICT и только по одному ключу.
    em_calls = [c for c in cur.calls if c[0] == "executemany"]
    assert len(em_calls) == 1
    sql = em_calls[0][1]
    vals = em_calls[0][2]
    assert "ON CONFLICT" in sql
    assert len(vals) == 1
    assert vals[0][2] == 989733
    assert vals[0][4] == "v2"  # последнее значение побеждает


def test_upsert_lead_tags_dedup():
    """В тегах сделки возможны дубли tag_id: должны дедуплицироваться."""

    from etl.config import DatabaseConfig
    from etl.loaders import PostgresLoader

    class DummyCursor:
        def __init__(self):
            self.calls = []

        def execute(self, sql, params=None):
            self.calls.append(("execute", sql, params))

        def executemany(self, sql, seq_of_params):
            self.calls.append(("executemany", sql, list(seq_of_params)))

    loader = PostgresLoader(DatabaseConfig(host="x", port=5432, dbname="x", user="x", password="x", schema="core"))
    cur = DummyCursor()

    tags = [
        {"account_id": 53859, "tag_id": 161545, "name": "T1"},
        {"account_id": 53859, "tag_id": 161545, "name": "T2"},
    ]

    inserted = loader.upsert_lead_tags(cur, tags=tags, leads_id=5899)
    assert inserted == 1

    em_calls = [c for c in cur.calls if c[0] == "executemany"]
    assert len(em_calls) == 1
    sql = em_calls[0][1]
    vals = em_calls[0][2]
    assert "ON CONFLICT" in sql
    assert len(vals) == 1
    assert vals[0][2] == 161545
    assert vals[0][3] == "T2"  # последнее имя побеждает
