from abc import abstractmethod
from datetime import timedelta
from typing import Protocol

from . import AcceptableDegrees, ConstraintList, Matrix, Poly


class CustomClientResultProtocol(Protocol):
    """Defines the required interface for results returned by custom solver clients.

    This result class should be corresponding to a response data that the custom client receives from the solver
    service in the implementation. Implementations also must provide access to solution values and timing information
     as received from the solver service response.
    """

    @property
    @abstractmethod
    def _solutions(self) -> list[tuple[list[float], timedelta]]:
        """Returns a list of pairs consisting of the variable values and the time taken to find that solution.

        Raises:
            NotImplementedError: Implementation required.

        Returns:
            list[tuple[list[float], timedelta]]: List of solutions with their corresponding times.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def _response_time(self) -> timedelta:
        """Returns the response time taken by the solver service to respond.

        This should be measured in the custom client `solve` implementation.

        Raises:
            NotImplementedError: Implementation required.

        Returns:
            timedelta: Response time.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def _execution_time(self) -> timedelta:
        """Returns the execution time taken by the solver service to solve the problem internally.

        This should be extracted from the response data received from the solver service.
        If the solver service does not provide this information, return response time instead.

        Raises:
            NotImplementedError: Implementation required.

        Returns:
            timedelta: Execution time.
        """
        raise NotImplementedError


class CustomClientProtocol(Protocol):
    """Defines the required interface for custom solver client implementations.

    The custom client class should be corresponding to a solver service to integrate with Amplify.
    This protocol defines the required properties and methods that a custom client must implement.
    """

    parameters: object
    """An object containing solver's request parameters which can be configured by the user.
    This should be initialized in the custom client constructor.

    Note that when add other configurations for changing client's behavior, implement properties in
    the client class instead of adding attributes to this `parameters` object.
    """

    @property
    @abstractmethod
    def acceptable_degrees(self) -> AcceptableDegrees:
        """Define the maximum degrees of polynomial for objective, equality constraints and inequality constraints for each variable type.

        Raises:
            NotImplementedError: Implementation required.

        Returns:
            AcceptableDegrees: The acceptable degrees for the solver service.
        """  # noqa: E501
        raise NotImplementedError

    @abstractmethod
    def solve(
        self, objective: Poly | Matrix, constraints: ConstraintList | None, dry_run: bool = False
    ) -> CustomClientResultProtocol | None:
        """Call the solver service to solve the given optimization problem.

        Args:
            objective (Poly | Matrix): The objective function to be minimized.
            constraints (ConstraintList | None): constrains for the problem. If None, no constraints are applied.
            dry_run (bool, optional): Dry run. Defaults to False.

        Raises:
            NotImplementedError: Implementation required.

        Returns:
            CustomClientResultProtocol | None: The result from the solver service or None if dry_run is True.

        Note:
            - In dry run mode, the implementation should not make any actual requests to the solver service.
              Instead, it can perform validation and health checks, then return None.
            - According to the `acceptable_degrees` property, the degrees of the objective and constraints are already
              validated.
            - If constraints are provided and the solver service does not support constraints directly,
              the constraints must be converted to the penalty functions and add them to the objective before sending
              to the solver service in the implementation.
        """
        raise NotImplementedError

    @abstractmethod
    def version(self) -> str:
        """Returns the version string of the solver service.

        Raises:
            NotImplementedError: Implementation required.

        Returns:
            str: version string of the solver service.
        """
        raise NotImplementedError
