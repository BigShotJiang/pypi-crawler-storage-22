import contextlib

with contextlib.suppress(ModuleNotFoundError):
    from amplify_qaoa import *
