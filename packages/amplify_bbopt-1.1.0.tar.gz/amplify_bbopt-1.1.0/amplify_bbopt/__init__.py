# ruff: noqa: E402

# Private constant for floating-point comparisons
_ISCLOSE_ATOL: float = 1e-08

from .__version__ import __version__
from .amplify_model import AmplifyModel
from .bbopt_logging import AMPLIFY_BBOPT_LOG_FORMATTER, AMPLIFY_BBOPT_LOGGER_NAME
from .blackbox import BlackBoxFuncBase, blackbox
from .data_transformer import DataTransformer, ExpScaler
from .encoder import EncodingInfo, decode_values, encode_constraints, encode_input, encode_variables
from .optimizer import FlattenedSolution, IterationResult, Optimizer, Solution
from .surrogate import SurrogateModel
from .trainer import Dataset, FMTrainer, KernelModel, KMTrainer, TorchFM
from .variable import (
    BinaryVariable,
    DiscreteVariable,
    DiscretizationMethod,
    DiscretizationSpec,
    EncodingMethod,
    IntegerVariable,
    RealVariable,
    Variable,
)

__all__ = [
    "AMPLIFY_BBOPT_LOGGER_NAME",
    "AMPLIFY_BBOPT_LOG_FORMATTER",
    "AmplifyModel",
    "BinaryVariable",
    "BlackBoxFuncBase",
    "DataTransformer",
    "Dataset",
    "DiscreteVariable",
    "DiscretizationMethod",
    "DiscretizationSpec",
    "EncodingInfo",
    "EncodingMethod",
    "ExpScaler",
    "FMTrainer",
    "FlattenedSolution",
    "IntegerVariable",
    "IterationResult",
    "KMTrainer",
    "KernelModel",
    "Optimizer",
    "RealVariable",
    "Solution",
    "SurrogateModel",
    "TorchFM",
    "Variable",
    "__version__",
    "blackbox",
    "decode_values",
    "encode_constraints",
    "encode_input",
    "encode_variables",
]
