from abc import ABC, abstractmethod
from enum import Enum
from typing import Literal, final

import numpy as np
import numpy.typing as npt

from . import _ISCLOSE_ATOL
from .trainer import Dataset


class DataTransformer(ABC):
    """Base class for training data transform methods."""

    def transform(self, data: Dataset) -> Dataset:
        scaled_y = self._scale_y(data.y)
        assert scaled_y.shape == data.y.shape
        return Dataset(x=data.x, y=scaled_y)

    @abstractmethod
    def _scale_y(self, y: npt.NDArray[np.float64]) -> npt.NDArray[np.float64]:
        pass


@final
class ExpScaler(DataTransformer):
    """Exponential scaling method.

    The scaling is defined as:
        y_scaled = -exp(-(y - y_offset) / c_m)
    where:
        - y_offset = min(y): Minimum value in the data
        - c_m: Calculated based on cm_method from (y - y_offset)

    Args:
        dynamic (bool): If True, recalculates scaling parameters (y_offset, c_m) every time
            transform() is called. If False, calculates them only once on the first call.
            Default is False.
        cm_method (CmMethod | Literal["mean", "median"]):
            Method to calculate c_m from the data. Options are:
            - "mean": Use mean of (y - y_offset)
            - "median": Use median of (y - y_offset)
            Default is "mean".
    """

    class CmMethod(Enum):
        """Method to calculate c_m for exponential scaling."""

        MEAN = "mean"
        MEDIAN = "median"

    def __init__(
        self,
        dynamic: bool = False,
        cm_method: CmMethod | Literal["mean", "median"] = CmMethod.MEAN,
    ) -> None:
        self._dynamic = dynamic
        self._cm_method: ExpScaler.CmMethod = (
            cm_method if isinstance(cm_method, ExpScaler.CmMethod) else ExpScaler.CmMethod(cm_method)
        )
        self._c_m: float | None = None
        self._y_offset: float | None = None

    def _scale_y(self, y: npt.NDArray[np.float64]) -> npt.NDArray[np.float64]:
        """Apply exponential scaling to objective values.

        Args:
            y (np.ndarray): Array of objective values.

        Returns:
            np.ndarray: Array of scaled objective values.
        """
        # Calculate parameters
        if self._y_offset is None or self._dynamic:
            self._y_offset = np.min(y)
        if self._c_m is None or self._dynamic:
            y_star = y - self._y_offset
            match self._cm_method:
                case ExpScaler.CmMethod.MEDIAN:
                    val = np.median(y_star)
                case ExpScaler.CmMethod.MEAN:
                    val = np.mean(y_star)
            c_m = float(val)
            self._c_m = 1.0 if np.isclose(c_m, 0, atol=_ISCLOSE_ATOL) else c_m

        with np.errstate(over="raise"):
            return -np.exp(-(y - self._y_offset) / self._c_m)
