from enum import Enum

class ServerZone(Enum):
    US = "US"
    EU = "EU"
