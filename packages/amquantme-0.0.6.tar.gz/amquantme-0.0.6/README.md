Use ***from AMQuantME import express_visual*** to import the main module.


Use ***express_visual.express_pict()*** to show the picture version of the express. 