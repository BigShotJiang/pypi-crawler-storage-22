__version__ = "beta0.0.0.1"
# __author__ = "Justan"
# __organization__ = "Future Stringer"
# __welcom__ = "Welcom from China Quant."
print("Welcome from FutureStringer!")