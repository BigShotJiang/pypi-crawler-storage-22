import pandas as pd
import pandas_ta as ta

from AMQuantME import fetchpv as ftpv
from AMQuantME import normdf as nd

import datetime as dt
todaydate = dt.date.today()
todaystr = f"{todaydate.year}-{todaydate.month}-{todaydate.day}"
print(f"Today is {todaystr}.")

# Fetch raw price-volume data of the target index
exsymb_SSEC = "sh.000001"
print(f"Fetching {exsymb_SSEC}, namely SSEC...")
pv_SSEC = ftpv.bsindexpv(exsymb = exsymb_SSEC, enddate = todaystr)

exsymb_CNIA = "sz.399317"
print(f"Fetching {exsymb_CNIA}, namely CNIA...")
pv_CNIA = ftpv.bsindexpv(exsymb = exsymb_CNIA, enddate = todaystr)

print(f"Data have been updated to {pv_SSEC['date'][len(pv_SSEC) - 1]}")

# Format the DataFrames
pv_SSEC_norm = nd.normdftype(pv_SSEC)
pv_CNIA_norm = nd.normdftype(pv_CNIA)

# Record the historical max of the indices
SSEC_hs_max = pv_SSEC_norm.CLOSE.max()
CNIA_hs_max = pv_CNIA_norm.CLOSE.max()

# Truncate interested timeframe and reset the index
pv_SSEC_timeframe = pv_SSEC_norm[pv_SSEC_norm["DATE"] >= "2024-09-23"]
pv_SSEC_timeframe.reset_index(drop = True, inplace = True)

pv_CNIA_timeframe = pv_CNIA_norm[pv_CNIA_norm["DATE"] >= "2024-09-23"]
pv_CNIA_timeframe.reset_index(drop = True, inplace = True)

# Enhance the original DataFrame with calculated daily Return and other interested items
SSEC_Daily_df = pv_SSEC_timeframe.copy(deep = True)

SSEC_Daily_df["Return"] = SSEC_Daily_df["CLOSE"].pct_change()
# Compress VOLUME into millions and AMOUNT into billions
SSEC_Daily_df["Volume_mln"] = SSEC_Daily_df["VOLUME"]/(10**6)
SSEC_Daily_df = SSEC_Daily_df.drop("VOLUME", axis=1)
    
SSEC_Daily_df["Amount_bln"] = SSEC_Daily_df["AMOUNT"]/(10**9)
SSEC_Daily_df = SSEC_Daily_df.drop("AMOUNT", axis=1)

# Calculate daily volume percent change of SSEC to illustrate price-volume relationship
SSEC_Daily_df["Vol_chg"] = SSEC_Daily_df["Volume_mln"].pct_change()
SSEC_Daily_df["Amt_chg"] = SSEC_Daily_df["Amount_bln"].pct_change()

# Calculate normalized VARation
SSEC_Daily_df["PurchasePower"] = SSEC_Daily_df["Volume_mln"] / SSEC_Daily_df["Amount_bln"]
SSEC_Daily_df["VARatio_norm"] = SSEC_Daily_df["PurchasePower"] / SSEC_Daily_df["PurchasePower"][0]

# Do the same to the auxiliary index
CNIA_Daily_df = pv_CNIA_timeframe.copy(deep = True)
CNIA_Daily_df["Return"] = CNIA_Daily_df["CLOSE"].pct_change()
CNIA_Daily_df["Volume_mln"] = CNIA_Daily_df["VOLUME"]/(10**6)
CNIA_Daily_df = CNIA_Daily_df.drop("VOLUME", axis=1)
CNIA_Daily_df["Amount_bln"] = CNIA_Daily_df["AMOUNT"]/(10**9)
CNIA_Daily_df = CNIA_Daily_df.drop("AMOUNT", axis=1)
CNIA_Daily_df["Vol_chg"] = CNIA_Daily_df["Volume_mln"].pct_change()
CNIA_Daily_df["PurchasePower"] = CNIA_Daily_df["Volume_mln"] / CNIA_Daily_df["Amount_bln"]
CNIA_Daily_df["VARatio_norm"] = CNIA_Daily_df["PurchasePower"] / CNIA_Daily_df["PurchasePower"][0]

# Calculate employed technical indicators
rstd = ta.stdev(SSEC_Daily_df["Return"], 5)
pmacd = ta.macd(SSEC_Daily_df.CLOSE, fast = 5, slow = 10, signal = 7)
amt_chg_sma = ta.sma(SSEC_Daily_df["Amt_chg"], 10)
obv = ta.obv(SSEC_Daily_df.CLOSE, SSEC_Daily_df.Volume_mln)
pvmfi = ta.mfi(SSEC_Daily_df.HIGH, SSEC_Daily_df.LOW, SSEC_Daily_df.CLOSE, SSEC_Daily_df.Volume_mln, length = 10)