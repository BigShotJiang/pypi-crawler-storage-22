import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
import matplotlib.dates as mdates
from matplotlib import font_manager
my_font = font_manager.FontProperties(fname="C:/WINDOWS/Fonts/STSONG.TTF")

from AMQuantME import augcal as ac

'''
Visualize CLOSE, Volumes, Amount, and their changes of the target index during the whole timeframe
and employ some technical indicators to illustrate the movement of the index.
'''

# Record the first, second, and last time points with in the interested timeframe for calculation and illustration
date_index = ac.SSEC_Daily_df["DATE"]
fst_date = f"{date_index[0].year}-{date_index[0].month}-{date_index[0].day}"
sec_date = f"{date_index[1].year}-{date_index[1].month}-{date_index[1].day}"
lst_date = f"{date_index[len(date_index)-1].year}-{date_index[len(date_index)-1].month}-{date_index[len(date_index)-1].day}"

def express_pict(df = ac.SSEC_Daily_df, aux_df = ac.CNIA_Daily_df):
    fig, axs = plt.subplots(4, 1, figsize = (18, 24), constrained_layout=True)
    date_index = pd.to_datetime(df["DATE"]).dt.to_period("D")

    
    # Subplot 1 
    '''Price behavior'''
    # Plot daily CLOSE of the main index (x1) on the left axis
    x1 = df["CLOSE"]
    last_x_ind, last_x_val = len(x1) - 1, x1.iloc[-1]
    axs[0].plot(range(len(x1)), np.where(np.isnan(x1), None, x1), 
                linewidth = 1, color = "b", label = f"SSEC, Close: {fst_date} - {lst_date}")
    
    # Plot the latest daily close of x1
    axs[0].plot(last_x_ind, last_x_val, "ro", alpha=0.4)
    axs[0].annotate(f"{lst_date:>16}:\n{last_x_val:>16.2f}", 
                    xy=(last_x_ind, last_x_val), xytext=(-40, 10), textcoords = "offset points", fontsize=10, color="royalblue")

    # Plot expending mean and up quartile of x1
    exp_mean1 = x1.expanding().mean()
    exp_qu1 = x1.expanding().quantile(0.75)
    axs[0].plot(range(len(x1)), exp_mean1, linewidth = 1, color = "skyblue", 
                label = f"SSEC, Close, Expanding Mean, latest{exp_mean1[len(exp_mean1) - 1]:.0f}")
    axs[0].plot(range(len(x1)), exp_qu1, linewidth = 1, color = (174/255, 11/255, 42/255), label = "SSEC, Close, Expanding Upper Quartile")
    
    
    # axs0_high = x1.mean() + (max(x1) - x1.mean()) * 1.2
    # axs0_low = x1.mean() + (min(x1) - x1.mean()) * 1.2
    axs0_high = 6000
    axs0_low = 2500
    axs[0].set_ylim(axs0_low,axs0_high)
    
    # Set sparse display of the date index
    data_locator = MultipleLocator(40)
    axs[0].set_xticks(range(len(x1)), date_index)
    axs[0].xaxis.set_major_locator(data_locator)
    axs[0].legend(loc = 4)

    # Plot dialy CLOSE of the auxiliary index (x1_1) on the right axis
    axs0_r = axs[0].twinx()
    x1_1 = aux_df["CLOSE"]
    last_x1_1_ind, last_x1_1_val = len(x1_1) - 1, x1_1.iloc[-1]
    axs0_r.plot(range(len(x1_1)), np.where(np.isnan(x1_1), None, x1_1), 
                linewidth = 1, color = "orange", label = f"CNIS, Close: {fst_date} - {lst_date}")
    axs0_r.plot(last_x1_1_ind, last_x1_1_val, "ro", alpha=0.5)
    axs0_r.annotate(f"{lst_date:>16}:\n{last_x1_1_val:>16.2f}", 
                    xy=(last_x1_1_ind, last_x1_1_val), xytext=(-40, 10), textcoords = "offset points", fontsize=10, color="royalblue")

    # Plot the highest daily close of x1_1 within the timeframe
    max_aux = np.argmax(x1_1)
    max_x1_1_ind, max_x1_1_val = range(len(x1_1))[max_aux], x1_1[max_aux]
    auxmax_date = f"{date_index[max_aux].year}-{date_index[max_aux].month}-{date_index[max_aux].day}"
    axs0_r.plot(max_x1_1_ind, max_x1_1_val, "bo", alpha=0.3)
    axs0_r.annotate(f"{auxmax_date:>16}:\n{max_x1_1_val:>16.2f}", 
                    xy=(max_x1_1_ind, max_x1_1_val), xytext=(-60, 5), textcoords = "offset points", fontsize=10, color="royalblue")

    # Plot the historical highest daily close of x1_1
    aux_hs_max = ac.CNIA_hs_max
    axs0_r.axhline(y = aux_hs_max, 
                   color="magenta", linestyle="--", linewidth=1, 
                   label=f"CNIA Historical Max: {aux_hs_max:.0f} = {aux_hs_max / max_x1_1_val:.2f} * {max_x1_1_val:.0f}")
    
    # axs0_r_high = x1_1.mean() + (max(x1_1) - x1_1.mean()) * 1.2
    # axs0_r_low = x1_1.mean() + (min(x1_1) - x1_1.mean()) * 1.2    
    axs0_r_high = 8000
    axs0_r_low = 3500
    axs0_r.set_ylim(axs0_r_low,axs0_r_high)
    axs0_r.legend(loc = 2)

    
    # Subplot 2
    '''Volume behavior'''
    x2 = df["Volume_mln"]/(10**3)
    x2_mean = x2.mean()
    last_x2 = x2.iloc[-1]
    x2_1 = aux_df["Volume_mln"]/(10**3)
    
    axs[1].bar(range(len(x2_1)), np.nan_to_num(x2_1), 
                width = 1, color = "Orange", alpha = 0.6, label = f"CNIA, Volume in bln shares: {fst_date} - {lst_date}")
    axs[1].bar(range(len(x2)), np.nan_to_num(x2), 
               width = 1, color = "Royalblue", alpha = 0.8, label = f"SSEC, Volume in bln shares: {fst_date} - {lst_date}")
    
    axs[1].annotate(f"{lst_date:>16}:\n{last_x2:>16.2f}", 
                    xy=(last_x_ind, last_x2), xytext=(-40, 20), textcoords = "offset points", fontsize=10, color="royalblue")
    
    # Plot mean of daily Volume of SSEC during the whole time span 
    axs[1].axhline(y = x2_mean, 
                   color="navy", linestyle="--", linewidth=1, label=f"Volume_mean: {x2_mean:.2f}")
    
    varatio_norm_aux = aux_df["VARatio_norm"] * 100
    axs[1].plot(range(len(x2_1)), varatio_norm_aux, linewidth = 2, color = "yellow", alpha = 0.8, label = "CNIA, VARatio_norm*100")
    
    varatio_norm = df["VARatio_norm"] * 100
    axs[1].plot(range(len(x2)), varatio_norm, linewidth = 2, color = "magenta", alpha = 0.8, label = f"SSEC, VARatio_norm*100: {round(varatio_norm[len(x2) - 1],2)}")
    
    axs1_high = max(x2.mean() + (max(x2) - x2.mean()) * 1.2, x2_1.mean() + (max(x2_1) - x2_1.mean()) * 1.2, 0)
    axs1_low = min(x2.mean() + (min(x2) - x2.mean()) * 1.2, x2_1.mean() + (max(x2_1) - x2_1.mean()) * 1.2, 0)
    axs[1].set_ylim(axs1_low,axs1_high)
    axs[1].set_xticks(range(len(x1)), date_index)
    axs[1].xaxis.set_major_locator(data_locator)
    axs[1].legend(loc = 9)
    
    
    # Subplot 3
    '''Return behavior'''
    x3 = df["Return"]
    x3_mean = x3.mean()
    axs[2].bar(range(len(x3)), np.nan_to_num(x3), width = 0.5, color = "b", label = f"SSEC, Daily return: {sec_date} - {lst_date}")
    axs[2].axhline(y=x3_mean, 
                   color="navy", linestyle="--", linewidth=0.5, label=f"return_mean: {x3_mean:.4f}")
    
    exp_std3 = x3.expanding().std()
    axs[2].plot(range(len(x3)), exp_std3, linewidth = 1.5, color = "violet", label = "SSEC, Daily return, Expanding Standard Deviation")
    
    x3_2 = ac.pmacd.MACDh_5_10_7 / 200
    axs[2].bar(range(len(x3_2)), np.nan_to_num(x3_2), width = 0.5, color = "c", alpha = 0.6, label = "SSEC, CLOSE, MACD_5_10_7")
    
    x3_3 = ac.rstd
    axs[2].plot(range(len(x3_3)), x3_3, linewidth = 1.5, color = "orange", label = "SSEC, Daily return, Rolling Std_5")
    
    axs[2].set_xticks(range(len(x3)), date_index)
    axs[2].xaxis.set_major_locator(data_locator)
    axs[2].legend(loc = 4)
    
    # Subplot 4
    '''Amount behavior'''
    x4 = df["Amt_chg"]
    x4_mean = x4.mean()
    axs[3].plot(range(len(x4)), np.where(np.isnan(x4), None, x4), 
                linewidth = 1, color = "b", label = f"SSEC, Amount Percentage Change: {sec_date} - {lst_date}")
    axs[3].axhline(y = x4_mean, 
                   color="navy", linestyle="--", linewidth=0.5, label=f"Amount Percentage Change_mean: {x4_mean:.4f}")

    sma4 = ac.amt_chg_sma
    axs[3].plot(range(len(x4)), sma4, linewidth = 2, color = (174/255, 11/255, 42/255), label = "SSEC, Amount Pct. Change, SMA_10")

    x4_2 = ac.obv / (10 ** 7)
    axs[3].bar(range(len(x4_2)), np.nan_to_num(x4_2), 
               width = 0.5, color = "skyblue", alpha = 0.6, label = "SSEC, OBV")
    
    max_x4_2 = np.argmax(x4_2)
    max_x4_2_ind, max_x4_2_val = range(len(x4_2))[max_x4_2], x4_2[max_x4_2]
    max_x4_2date = f"{date_index[max_x4_2].year}-{date_index[max_x4_2].month}-{date_index[max_x4_2].day}"
    
    axs[3].plot(max_x4_2_ind, max_x4_2_val, "ro", alpha=0.5)
    axs[3].annotate(f"{max_x4_2date:>16}", 
                    xy=(max_x4_2_ind, max_x4_2_val), xytext=(-50, 10), textcoords = "offset points", fontsize=10, color="royalblue")

    axs[3].plot(range(len(x4)), ac.pvmfi / 100, linewidth = 1.5, alpha = 0.8, linestyle = "--", color = "red", label = "SSEC, MFI_10")
    
    axs[3].set_xticks(range(len(x4)), date_index)
    axs[3].xaxis.set_major_locator(data_locator)
    axs[3].legend(loc = 9)
    
    fig.suptitle(
        ("Chinese SSEC Index Daily Close, Volume, Amount and Their Daily Percentage Changes: "
        ) + (f"{fst_date} - {lst_date}")
    )
    
    plt.savefig("Chinese SSEC Daily Closes Volumes Amounts and Changes_beta002.png")
    plt.show()
    print("For technical indicator explanation, please refer to https://mp.weixin.qq.com/s/PU70IyS-ByyIen5iTnuwfQ")

    return