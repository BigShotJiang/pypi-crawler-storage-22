import pandas as pd
import baostock as bs

def bsindexpv(exsymb, enddate):
    '''
    As instance code, taking CSI A Shares("sz.399317")
    end_date form: '2026-01-27'
    adjustflag: "1" for hfq, "2" for qfq, "3" for bfq
    tradestatus: 1 for in trading, 0 for out of trading
    Indices has no adjustflag
    '''
    lg = bs.login()
    pv_bs = bs.query_history_k_data_plus(exsymb,
                                     "date,code,open,high,low,close,volume,amount",
                                     start_date = '1900-01-01', end_date = enddate, 
                                     frequency = "d")
    _result_list = []
    while (pv_bs.error_code == '0') & pv_bs.next():
            _result_list.append(pv_bs.get_row_data())
    _result = pd.DataFrame(_result_list, columns = pv_bs.fields)
    bs.logout()
    
    return _result