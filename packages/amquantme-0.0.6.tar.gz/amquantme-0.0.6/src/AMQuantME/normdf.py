import pandas as pd

def normdftype(pvdf):
    # Change data type of fields
    df = pvdf.copy()
    df["date"] = pd.to_datetime(df["date"])
    
    for field in ["open", "high", "low", "close", "volume", "amount"]:
        df[field] = df[field].astype(float)
    
    # Keep appropriate decimal
    df.round({"open":4, "high":4, "low":4, "close":4, "volume":4, "amount":4})
    
    # Rename the original fields
    original_rename_dict = {"date":"DATE", "code":"CODE", 
                            "open":"OPEN", "high":"HIGH", "low":"LOW", "close":"CLOSE",
                            "volume":"VOLUME", "amount":"AMOUNT"}
    df.rename(columns = original_rename_dict, inplace = True)

    return df