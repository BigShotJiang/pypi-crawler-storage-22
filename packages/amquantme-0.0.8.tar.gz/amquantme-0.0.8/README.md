Welcome to Stringer_Divinator series product - AMQuantME


This is an express system helping trace the behavior of Chinese A Share market.


You can use the sentences


***from AMQuantME import express_visual*** 


***express_visual.express_pict()***


to import the main module and show the picture version of the express with just one single hit.


The report version may be coming soon.


Have a nice stay.