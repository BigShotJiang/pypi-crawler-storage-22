"""Constants for auth module."""

# Use this to mark a model/transaction as publicly accessible (no scopes required)
# Example: __scopes__ = ALLOW_ANY
ALLOW_ANY: list[str] = []
