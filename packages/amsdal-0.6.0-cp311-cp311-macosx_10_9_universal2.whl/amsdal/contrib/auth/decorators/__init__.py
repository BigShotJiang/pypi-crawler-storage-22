import asyncio
from collections.abc import Callable
from functools import wraps
from typing import Any

from amsdal_server.apps.common.errors import AmsdalAuthorizationError
from amsdal_server.apps.common.permissions.enums import Action

from amsdal.context.manager import AmsdalContextManager
from amsdal.contrib.auth.errors import AuthenticationError


def require_auth(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that requires user to be authenticated."""
    if asyncio.iscoroutinefunction(func):

        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            request = AmsdalContextManager().get_context().get('request', None)

            if not request or not request.user or not request.user.is_authenticated:
                msg = 'Authentication required'
                raise AuthenticationError(msg)

            return await func(*args, **kwargs)

    else:

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            request = AmsdalContextManager().get_context().get('request', None)

            if not request or not request.user or not request.user.is_authenticated:
                msg = 'Authentication required'
                raise AuthenticationError(msg)

            return func(*args, **kwargs)

    return wrapper


def require_scopes(*required_scopes: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that requires user to have specific scopes.

    Multiple scopes passed to a single decorator are ANDed together.
    Multiple decorators are ORed together.

    Examples:
        @require_scopes('models.Post:read')  # requires read scope
        @require_scopes('models.Post:read', 'models.Post:create')  # requires BOTH
        @require_scopes('models.Post:read')
        @require_scopes('models.Post:create')  # requires read OR create
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        if asyncio.iscoroutinefunction(func):

            @wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                from amsdal.contrib.auth.utils.scopes import match_scope

                request = AmsdalContextManager().get_context().get('request', None)

                if not request or not request.auth:
                    msg = 'Authentication required'
                    raise AuthenticationError(msg)

                user_scopes = set(getattr(request.auth, 'scopes', []))

                if not all(match_scope(scope, user_scopes) for scope in required_scopes):
                    raise AmsdalAuthorizationError(
                        action=Action.EXECUTE,
                        resource_name=func.__name__,
                        error_message=f'Required scopes: {", ".join(required_scopes)}',
                    )

                return await func(*args, **kwargs)

        else:

            @wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                from amsdal.contrib.auth.utils.scopes import match_scope

                request = AmsdalContextManager().get_context().get('request', None)

                if not request or not request.auth:
                    msg = 'Authentication required'
                    raise AuthenticationError(msg)

                user_scopes = set(getattr(request.auth, 'scopes', []))

                if not all(match_scope(scope, user_scopes) for scope in required_scopes):
                    raise AmsdalAuthorizationError(
                        action=Action.EXECUTE,
                        resource_name=func.__name__,
                        error_message=f'Required scopes: {", ".join(required_scopes)}',
                    )

                return func(*args, **kwargs)

        return wrapper

    return decorator
