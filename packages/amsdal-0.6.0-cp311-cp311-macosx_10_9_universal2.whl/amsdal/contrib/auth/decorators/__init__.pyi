from amsdal.context.manager import AmsdalContextManager as AmsdalContextManager
from amsdal.contrib.auth.errors import AuthenticationError as AuthenticationError
from collections.abc import Callable as Callable
from typing import Any

def require_auth(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that requires user to be authenticated."""
def require_scopes(*required_scopes: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that requires user to have specific scopes.

    Multiple scopes passed to a single decorator are ANDed together.
    Multiple decorators are ORed together.

    Examples:
        @require_scopes('models.Post:read')  # requires read scope
        @require_scopes('models.Post:read', 'models.Post:create')  # requires BOTH
        @require_scopes('models.Post:read')
        @require_scopes('models.Post:create')  # requires read OR create
    """
