from _typeshed import Incomplete
from amsdal.contrib.auth.errors import AuthenticationError as AuthenticationError
from amsdal.contrib.auth.models.user import User as User
from amsdal.contrib.auth.users import AuthenticatedUser as AuthenticatedUser
from amsdal_server.apps.common.events.auth import AuthenticateContext
from amsdal_utils.events import AsyncNextFn as AsyncNextFn, EventListener, NextFn as NextFn
from typing import Any

logger: Incomplete

class AuthenticateUserListener(EventListener[AuthenticateContext]):
    """Authenticates a user based on a provided JWT token.

    This listener decodes the JWT token from the auth_header and retrieves
    the corresponding user from the database. If the token is invalid or expired,
    it raises an `AuthenticationError`.
    """
    def handle(self, context: AuthenticateContext, next_fn: NextFn[AuthenticateContext]) -> AuthenticateContext: ...
    async def ahandle(self, context: AuthenticateContext, next_fn: AsyncNextFn[AuthenticateContext]) -> AuthenticateContext: ...
    def _generate_scopes(self, permissions: list[Any]) -> list[str]:
        """Generate scopes from loaded permissions."""
    def _load_permissions(self, user: User) -> list[Any]:
        """Load user permissions (sync)."""
    async def _aload_permissions(self, user: User) -> list[Any]:
        """Load user permissions (async)."""
