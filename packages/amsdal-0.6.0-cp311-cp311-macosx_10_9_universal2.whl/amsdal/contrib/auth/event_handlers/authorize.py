"""Event listeners for authorization."""

import logging
from typing import Any

from amsdal_models.classes.class_manager import ClassManager
from amsdal_models.classes.model import Model
from amsdal_server.apps.common.events.authorize import ClassAuthorizeContext
from amsdal_server.apps.common.events.authorize import ObjectAuthorizeContext
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn

logger = logging.getLogger(__name__)


class ClassAuthorizeListener(EventListener[ClassAuthorizeContext]):
    """Handles class-level authorization checks.

    Checks if the user has the required scope in request.auth.scopes.
    Scopes are generated during authentication from user.permissions.
    """

    def handle(
        self,
        context: ClassAuthorizeContext,
        next_fn: NextFn[ClassAuthorizeContext],
    ) -> ClassAuthorizeContext:
        authorized, error_message = self._check_scopes(
            request=context.request,
            resource_type=context.resource_type,
            resource_name=context.resource_name,
            action=context.action,
        )

        return next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    async def ahandle(
        self,
        context: ClassAuthorizeContext,
        next_fn: AsyncNextFn[ClassAuthorizeContext],
    ) -> ClassAuthorizeContext:
        authorized, error_message = self._check_scopes(
            request=context.request,
            resource_type=context.resource_type,
            resource_name=context.resource_name,
            action=context.action,
        )

        return await next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    def _check_scopes(
        self,
        request: Any,
        resource_type: ResourceType,
        resource_name: str,
        action: Action,
    ) -> tuple[bool, str | None]:
        """Check if user has the required scope."""
        from amsdal.contrib.auth.utils.scopes import match_scope

        user_scopes = set(getattr(request.auth, 'scopes', []))
        required_scope = f'{resource_type.value}.{resource_name}:{action.value}'

        # Check if user has the required scope
        if match_scope(required_scope, user_scopes):
            return True, None

        # Check if resource requires this scope via __scopes__ attribute
        if not self._is_scope_required(resource_name, required_scope):
            return True, None

        return False, f'Permission denied for {action.value} on {resource_type.value}.{resource_name}'

    def _is_scope_required(self, resource_name: str, required_scope: str) -> bool:
        """Check if model class requires this scope via __scopes__ attribute."""
        from amsdal.contrib.auth.settings import auth_settings
        from amsdal.contrib.auth.utils.scopes import match_scope

        try:
            model_class = ClassManager().import_class(resource_name)
        except (ValueError, ImportError):
            return auth_settings.REQUIRE_DEFAULT_AUTHORIZATION

        model_scopes = getattr(model_class, '__scopes__', None)

        # __scopes__ not defined - use default authorization setting
        if model_scopes is None:
            return auth_settings.REQUIRE_DEFAULT_AUTHORIZATION

        # __scopes__ = [] (ALLOW_ANY) - public resource, no scope required
        if not model_scopes:
            return False

        # __scopes__ = [...] - check if required scope matches
        return match_scope(required_scope, set(model_scopes))


class ObjectAuthorizeListener(EventListener[ObjectAuthorizeContext]):
    """Handles object-level authorization checks.

    Checks has_object_permission() on the model instance if it exists.
    """

    def handle(
        self,
        context: ObjectAuthorizeContext,
        next_fn: NextFn[ObjectAuthorizeContext],
    ) -> ObjectAuthorizeContext:
        authorized, error_message = self._check_object_permission(
            request=context.request,
            obj=context.obj,
            action=context.action,
            update_data=context.update_data,
        )

        return next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    async def ahandle(
        self,
        context: ObjectAuthorizeContext,
        next_fn: AsyncNextFn[ObjectAuthorizeContext],
    ) -> ObjectAuthorizeContext:
        authorized, error_message = self._check_object_permission(
            request=context.request,
            obj=context.obj,
            action=context.action,
            update_data=context.update_data,
        )

        return await next_fn(
            context.create_next(
                listener_id=self.listener_id,
                authorized=authorized,
                error_message=error_message,
            )
        )

    def _check_object_permission(
        self,
        request: Any,
        obj: Model,
        action: Action,
        update_data: dict[str, Any] | None = None,
    ) -> tuple[bool, str | None]:
        """Check if user has permission on the specific object."""
        if hasattr(obj, 'has_object_permission'):
            if not obj.has_object_permission(request.user, action, update_data=update_data, auth=request.auth):
                return False, f'Permission denied for {action.value} on {obj.__class__.__name__} object'

        return True, None
