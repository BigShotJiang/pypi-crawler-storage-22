from _typeshed import Incomplete
from amsdal_models.classes.model import Model
from amsdal_server.apps.common.events.authorize import ClassAuthorizeContext, ObjectAuthorizeContext
from amsdal_server.apps.common.permissions.enums import Action as Action, ResourceType as ResourceType
from amsdal_utils.events import AsyncNextFn as AsyncNextFn, EventListener, NextFn as NextFn
from typing import Any

logger: Incomplete

class ClassAuthorizeListener(EventListener[ClassAuthorizeContext]):
    """Handles class-level authorization checks.

    Checks if the user has the required scope in request.auth.scopes.
    Scopes are generated during authentication from user.permissions.
    """
    def handle(self, context: ClassAuthorizeContext, next_fn: NextFn[ClassAuthorizeContext]) -> ClassAuthorizeContext: ...
    async def ahandle(self, context: ClassAuthorizeContext, next_fn: AsyncNextFn[ClassAuthorizeContext]) -> ClassAuthorizeContext: ...
    def _check_scopes(self, request: Any, resource_type: ResourceType, resource_name: str, action: Action) -> tuple[bool, str | None]:
        """Check if user has the required scope."""
    def _is_scope_required(self, resource_name: str, required_scope: str) -> bool:
        """Check if model class requires this scope via __scopes__ attribute."""

class ObjectAuthorizeListener(EventListener[ObjectAuthorizeContext]):
    """Handles object-level authorization checks.

    Checks has_object_permission() on the model instance if it exists.
    """
    def handle(self, context: ObjectAuthorizeContext, next_fn: NextFn[ObjectAuthorizeContext]) -> ObjectAuthorizeContext: ...
    async def ahandle(self, context: ObjectAuthorizeContext, next_fn: AsyncNextFn[ObjectAuthorizeContext]) -> ObjectAuthorizeContext: ...
    def _check_object_permission(self, request: Any, obj: Model, action: Action, update_data: dict[str, Any] | None = None) -> tuple[bool, str | None]:
        """Check if user has permission on the specific object."""
