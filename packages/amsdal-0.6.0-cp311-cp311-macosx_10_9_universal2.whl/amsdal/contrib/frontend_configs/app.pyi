from amsdal.contrib.app_config import AppConfig as AppConfig

class FrontendConfigAppConfig(AppConfig):
    """
    Application configuration class for frontend configurations.

    This class extends the AppConfig and sets up event listeners
    to process frontend configurations.
    """
    def on_setup(self) -> None:
        """
        Registers extended response models and event listeners.

        This method:
        1. Registers ExtendedColumnInfo to extend the base ColumnInfo model
        2. Registers extended object/transaction response models with 'control' field
        3. Subscribes event listeners to add 'control' field to responses
        4. Subscribes route listener for dashboard config endpoint

        Returns:
            None
        """
