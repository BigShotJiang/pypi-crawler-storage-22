from _typeshed import Incomplete
from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectDetailResponse as ExtendedObjectDetailResponse, ExtendedObjectListResponse as ExtendedObjectListResponse
from amsdal_server.apps.objects.events.pre_response import ObjectDetailPreResponseContext, ObjectListPreResponseContext
from amsdal_utils.events import AsyncNextFn as AsyncNextFn, EventListener, NextFn as NextFn
from amsdal_utils.schemas.schema import PropertyData
from typing import Any

_CORE_TO_FRONTEND_TYPES: Incomplete

def _process_property(field_name: str, property_data: PropertyData) -> dict[str, Any]:
    """Convert property data to frontend configuration dictionary."""
def _populate_frontend_config_with_values(config: dict[str, Any], values: dict[str, Any]) -> dict[str, Any]:
    """Populate frontend config with values from response."""
def _get_values_from_response(response: dict[str, Any] | list[dict[str, Any]]) -> dict[str, Any]:
    """Extract values from response rows."""
def _get_default_control(class_name: str) -> dict[str, Any]:
    """Get default frontend control config for a class."""
async def _aget_default_control(class_name: str) -> dict[str, Any]:
    """Async version: Get default frontend control config for a class."""
def _get_control_config(class_name: str) -> dict[str, Any] | None:
    """Load control config from FrontendModelConfig or get default."""
async def _aget_control_config(class_name: str) -> dict[str, Any] | None:
    """Async version: Load control config from FrontendModelConfig or get default."""

class ObjectListControlListener(EventListener[ObjectListPreResponseContext]):
    """Listener that adds control field to object list response."""
    def handle(self, context: ObjectListPreResponseContext, next_fn: NextFn[ObjectListPreResponseContext]) -> ObjectListPreResponseContext: ...
    async def ahandle(self, context: ObjectListPreResponseContext, next_fn: AsyncNextFn[ObjectListPreResponseContext]) -> ObjectListPreResponseContext: ...

class ObjectDetailControlListener(EventListener[ObjectDetailPreResponseContext]):
    """Listener that adds control field to object detail response."""
    def handle(self, context: ObjectDetailPreResponseContext, next_fn: NextFn[ObjectDetailPreResponseContext]) -> ObjectDetailPreResponseContext: ...
    async def ahandle(self, context: ObjectDetailPreResponseContext, next_fn: AsyncNextFn[ObjectDetailPreResponseContext]) -> ObjectDetailPreResponseContext: ...
