from amsdal_server.apps.objects.serializers.responses import _ObjectDetailResponse, _ObjectListResponse
from typing import Any

class ExtendedObjectListResponse(_ObjectListResponse):
    """Object list response with control field for form configuration."""
    control: dict[str, Any] | None

class ExtendedObjectDetailResponse(_ObjectDetailResponse):
    """Object detail response with control field for form configuration."""
    control: dict[str, Any] | None
