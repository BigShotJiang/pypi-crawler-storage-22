## [v0.6.1](https://pypi.org/project/amsdal_cli/0.6.1/) - 2025-02-05

### Added

- Add support for events
