## [v0.7.1](https://pypi.org/project/amsdal_cli/0.7.1/) - 2026-02-16

### Fixed

- Fixed missing `await` for `get_transactions()` call in async worker mode
