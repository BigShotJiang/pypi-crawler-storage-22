# SPDX-FileCopyrightText: 2023-present
#
# SPDX-License-Identifier: AMSDAL End User License Agreement
__version__ = '0.7.1'
