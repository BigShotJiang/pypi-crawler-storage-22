import tempfile
import typing
from pathlib import Path

import typer
from rich import print as rprint
from typer import Option

from amsdal_cli.commands.cloud.app import cloud_sub_app


@cloud_sub_app.command(name='gen-token, gen_token, gt')
def gen_token_command(
    ctx: typer.Context,
    env_name: typing.Annotated[
        typing.Optional[str],  # noqa: UP007
        Option('--env', help='Environment name. Default is the current environment from configuration.'),
    ] = None,
    email: typing.Annotated[
        typing.Optional[str],  # noqa: UP007
        Option('--email', '-e', help='Email for authentication.'),
    ] = None,
    password: typing.Annotated[
        typing.Optional[str],  # noqa: UP007
        Option('--password', '-p', help='Password for authentication.'),
    ] = None,
    mfa_code: typing.Annotated[
        typing.Optional[str],  # noqa: UP007
        Option('--mfa-code', help='MFA code for two-factor authentication.'),
    ] = None,
) -> None:
    """
    Generates an authentication token from a deployed AMSDAL API.
    """
    from amsdal.errors import AmsdalCloudError
    from amsdal.manager import AmsdalManager
    from amsdal.manager import AsyncAmsdalManager
    from amsdal_utils.config.manager import AmsdalConfigManager

    from amsdal_cli.commands.build.services.builder import AppBuilder
    from amsdal_cli.commands.cloud.environments.utils import get_current_env
    from amsdal_cli.services.gen_token import generate_token
    from amsdal_cli.utils.cli_config import CliConfig
    from amsdal_cli.utils.text import rich_error
    from amsdal_cli.utils.text import rich_highlight
    from amsdal_cli.utils.text import rich_info

    cli_config: CliConfig = ctx.meta['config']
    env_name = env_name or get_current_env(cli_config)

    rprint(rich_info(f'Generating token for environment: {rich_highlight(env_name)}'))

    with tempfile.TemporaryDirectory() as _temp_dir:
        output_path: Path = Path(_temp_dir)

        app_builder = AppBuilder(
            cli_config=cli_config,
            config_path=cli_config.config_path,
        )

        app_builder.build(output_path, is_silent=True)
        manager: AsyncAmsdalManager | AmsdalManager

        manager = AsyncAmsdalManager() if AmsdalConfigManager().get_config().async_mode else AmsdalManager()

        manager.authenticate()

    try:
        list_response = manager.cloud_actions_manager.list_deploys(list_all=False)
    except AmsdalCloudError as e:
        rprint(rich_error(str(e)))
        raise typer.Exit(code=1) from e

    if not list_response or not list_response.deployments:
        rprint(rich_error('No deployments found.'))
        raise typer.Exit(code=1)

    deployment = next(
        (
            d
            for d in list_response.deployments
            if d.application_uuid == cli_config.application_uuid and d.environment_name == env_name
        ),
        None,
    )

    if not deployment:
        rprint(rich_error(f'No deployment found for environment: {env_name}'))
        raise typer.Exit(code=1)

    if not deployment.domain_url:
        rprint(rich_error(f'No domain URL found for deployment in environment: {env_name}'))
        raise typer.Exit(code=1)

    if not email:
        email = typer.prompt('Email')

    if not password:
        password = typer.prompt('Password', hide_input=True)

    domain_url = deployment.domain_url.rstrip('/')
    base_url = f'{domain_url}/api' if not domain_url.endswith('/api') else domain_url
    generate_token(base_url, email, password, mfa_code=mfa_code)
