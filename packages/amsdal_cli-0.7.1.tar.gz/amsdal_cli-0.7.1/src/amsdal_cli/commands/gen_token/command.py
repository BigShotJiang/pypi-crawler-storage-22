import typing

import typer
from typer import Option

from amsdal_cli.app import app


@app.command(name='gen-token, gen_token, gt')
def gen_token_command(
    ctx: typer.Context,
    email: typing.Annotated[
        typing.Optional[str],  # noqa: UP007
        Option('--email', '-e', help='Email for authentication.'),
    ] = None,
    password: typing.Annotated[
        typing.Optional[str],  # noqa: UP007
        Option('--password', '-p', help='Password for authentication.'),
    ] = None,
    mfa_code: typing.Annotated[
        typing.Optional[str],  # noqa: UP007
        Option('--mfa-code', help='MFA code for two-factor authentication.'),
    ] = None,
) -> None:
    """
    Generates an authentication token from the local AMSDAL API server.
    """
    from amsdal_cli.services.gen_token import generate_token
    from amsdal_cli.utils.cli_config import CliConfig

    cli_config: CliConfig = ctx.meta['config']

    base_url = f'http://localhost:{cli_config.http_port}/api'

    if not email:
        email = typer.prompt('Email')

    if not password:
        password = typer.prompt('Password', hide_input=True)

    generate_token(base_url, email, password, mfa_code=mfa_code)
