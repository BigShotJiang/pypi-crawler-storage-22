from amsdal.contrib.app_config import AppConfig


class MainAppConfig(AppConfig):
    """Application configuration for {{ ctx.application_name }}."""

    def on_setup(self) -> None:
        """Called after all contrib modules are initialized."""
        pass
