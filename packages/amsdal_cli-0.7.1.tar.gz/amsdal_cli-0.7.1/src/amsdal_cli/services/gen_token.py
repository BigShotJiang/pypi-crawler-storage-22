import subprocess
import time

import httpx
import jwt
import typer
from rich import print as rprint
from starlette import status

from amsdal_cli.utils.text import rich_error
from amsdal_cli.utils.text import rich_highlight
from amsdal_cli.utils.text import rich_info
from amsdal_cli.utils.text import rich_success


def generate_token(base_url: str, email: str, password: str, mfa_code: str | None = None) -> str:
    payload: dict[str, str] = {'email': email, 'password': password}

    if mfa_code:
        payload['mfa_code'] = mfa_code

    try:
        response = httpx.post(
            f"{base_url.rstrip('/')}/objects/",
            params={'class_name': 'LoginSession', 'load_references': 'false'},
            json=payload,
            timeout=30,
        )
    except httpx.RequestError as e:
        rprint(rich_error(f'Request failed: {e}'))
        raise typer.Exit(code=1) from e

    if response.status_code == status.HTTP_401_UNAUTHORIZED:
        data = response.json()

        if data.get('is_mfa_required'):
            mfa_code = typer.prompt('MFA Code')
            return generate_token(base_url, email, password, mfa_code=mfa_code)

        rprint(rich_error(f'Authentication failed: {data}'))
        raise typer.Exit(code=1)

    if response.status_code not in (status.HTTP_200_OK, status.HTTP_201_CREATED):
        rprint(rich_error(f'Authentication failed: {response.status_code} - {response.text}'))
        raise typer.Exit(code=1)

    data = response.json()
    token = data.get('token')

    if not token:
        rprint(rich_error('Authentication failed: No token in response'))
        raise typer.Exit(code=1)

    try:
        decoded = jwt.decode(token, options={'verify_signature': False})
        exp = decoded.get('exp')
        expiration = time.ctime(exp) if exp else 'unknown'
    except Exception:
        expiration = 'unknown'

    rprint(rich_success('Authentication successful!'))
    rprint(rich_info(f'Email: {rich_highlight(email)}'))
    rprint(rich_info(f'Base URL: {rich_highlight(base_url)}'))
    rprint(rich_info(f'Token expires at: {rich_highlight(expiration)}'))

    rprint(rich_info(f'Token: {rich_highlight(token)}'))

    try:
        subprocess.run(['pbcopy'], input=token.encode(), check=True)  # noqa: S603, S607
        rprint(rich_success('Token copied to clipboard!'))
    except (FileNotFoundError, subprocess.CalledProcessError):
        pass

    return token
