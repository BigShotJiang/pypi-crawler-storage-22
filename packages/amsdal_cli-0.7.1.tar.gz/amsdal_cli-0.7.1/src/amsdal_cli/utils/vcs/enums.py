from enum import StrEnum


class VCSOptions(StrEnum):
    git = 'git'
