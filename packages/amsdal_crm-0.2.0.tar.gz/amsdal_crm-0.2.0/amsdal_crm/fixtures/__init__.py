"""CRM Fixtures."""
