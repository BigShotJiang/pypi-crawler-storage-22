"""CRM App Configuration."""

from amsdal.contrib.app_config import AppConfig
from amsdal_utils.events import EventBus


class CRMAppConfig(AppConfig):
    """Configuration for the CRM application."""

    def on_setup(self) -> None:
        """Set up CRM lifecycle listeners and initialize module."""
        from amsdal_server.apps.objects.events.pre_response import ObjectDetailPreResponseEvent

        from amsdal_crm.event_handlers.object_control import ObjectDetailControlCustomAttributeListener

        EventBus.subscribe(
            ObjectDetailPreResponseEvent,
            ObjectDetailControlCustomAttributeListener,
            after=['amsdal.contrib.frontend_configs.event_handlers.object_control.ObjectDetailControlListener'],
        )
