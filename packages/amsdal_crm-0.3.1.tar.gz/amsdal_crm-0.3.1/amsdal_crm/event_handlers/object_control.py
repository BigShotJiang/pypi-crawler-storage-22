import logging
from typing import Any

from amsdal.contrib.frontend_configs.serializers.extended_object_response import ExtendedObjectDetailResponse
from amsdal_server.apps.objects.events.pre_response import ObjectDetailPreResponseContext
from amsdal_utils.events import AsyncNextFn
from amsdal_utils.events import EventListener
from amsdal_utils.events import NextFn
from amsdal_utils.models.enums import Versions

# Entity types that support custom fields
CRM_ENTITY_TYPES = {'Entity', 'EntityRelationship', 'Deal', 'EntityIdentifier', 'EntityContactPoint', 'EntityAddress'}

logger = logging.getLogger(__name__)


def _custom_field_def_to_control(field_def: Any, values: dict[str, Any]) -> dict[str, Any]:
    """Convert a CustomFieldDefinition to a frontend control config.

    Args:
        field_def: A CustomFieldDefinition instance with metadata about a custom field

    Returns:
        A dictionary representing the frontend control configuration
    """
    control: dict[str, Any] = {
        'name': f'{field_def.field_name}',
        'label': field_def.field_label,
        'required': field_def.is_required,
    }

    if field_def.help_text:
        control['description'] = field_def.help_text

    if field_def.default_value is not None:
        control['value'] = field_def.default_value

    if field_def.field_type == 'text':
        control['type'] = 'text'
    elif field_def.field_type == 'number':
        control['type'] = 'number'
    elif field_def.field_type == 'date':
        control['type'] = 'date'
    elif field_def.field_type == 'choice':
        control['type'] = 'select'
        if field_def.choices:
            control['options'] = [{'label': choice, 'value': choice} for choice in field_def.choices]

    if values and field_def.field_name in values:
        control['value'] = values[field_def.field_name]

    return control


def _add_custom_fields_to_control(control: dict[str, Any], custom_field_controls: list[dict[str, Any]]) -> None:
    """Add custom field controls to the main control configuration.

    Args:
        control: The main frontend control configuration
        custom_field_controls: List of custom field control configurations
    """
    if not custom_field_controls:
        return

    if 'controls' not in control:
        control['controls'] = []

    # Find the custom_fields control and update it, or append custom fields at the end
    custom_fields_control = None
    for ctrl in control.get('controls', []):
        if ctrl.get('name') == 'custom_fields':
            custom_fields_control = ctrl
            break

    if custom_fields_control:
        # Update the custom_fields control to be a group with nested controls
        custom_fields_control['type'] = 'group'
        custom_fields_control['controls'] = custom_field_controls
        if 'control' in custom_fields_control:
            custom_fields_control.pop('control', None)
    else:
        # Add custom fields as a new group at the end
        control['controls'].append(
            {
                'type': 'group',
                'name': 'custom_fields',
                'label': 'Custom Fields',
                'controls': custom_field_controls,
            }
        )

    control['controls'].sort(key=lambda x: 100 if x.get('name') == 'custom_fields' else x.get('order', 0))


def _get_values_from_rows(rows: list[Any]) -> dict[str, Any]:
    """
    Extracts values from a response dictionary or list of dictionaries.

    This function processes a response to extract the relevant values. It checks if the response
    is a dictionary containing a 'rows' key and processes the rows to find the appropriate values.
    If the response is not in the expected format, it returns an empty dictionary.

    Args:
        response (dict[str, Any] | list[dict[str, Any]]): The response to extract values from.

    Returns:
        dict[str, Any]: A dictionary containing the extracted values.
    """
    if not rows:
        return {}

    for row in rows:
        if not isinstance(row, dict):
            continue
        if '_metadata' in row and row['_metadata'].get('next_version') is None:
            return row

    return rows[0]


def get_values_from_response(rows: list[Any]) -> dict[str, Any]:
    _values = _get_values_from_rows(rows)
    if 'custom_fields' in _values:
        return _values['custom_fields']
    return {}


class ObjectDetailControlCustomAttributeListener(EventListener[ObjectDetailPreResponseContext]):
    """Listener that adds control field to object list response."""

    def handle(
        self,
        context: ObjectDetailPreResponseContext,
        next_fn: NextFn[ObjectDetailPreResponseContext],
    ) -> ObjectDetailPreResponseContext:
        from amsdal_crm.models.custom_field_definition import CustomFieldDefinition

        _response: ExtendedObjectDetailResponse = context.response.model_copy()  # type: ignore

        if context.class_name not in CRM_ENTITY_TYPES or not _response.control:
            return next_fn(context)

        values = get_values_from_response(_response.rows)

        custom_field_defs = list(
            CustomFieldDefinition.objects.filter(
                entity_type=context.class_name,
                _metadata__is_deleted=False,
                _address__object_version=Versions.LATEST,
            ).execute()
        )

        if not custom_field_defs:
            return next_fn(context)

        custom_field_defs.sort(key=lambda x: x.display_order)

        custom_field_controls = [
            _custom_field_def_to_control(field_def, values=values) for field_def in custom_field_defs
        ]

        _add_custom_fields_to_control(_response.control, custom_field_controls)

        context.create_next(
            listener_id=self.listener_id,
            response=_response,
        )

        return next_fn(context)

    async def ahandle(
        self,
        context: ObjectDetailPreResponseContext,
        next_fn: AsyncNextFn[ObjectDetailPreResponseContext],
    ) -> ObjectDetailPreResponseContext:
        from amsdal_crm.models.custom_field_definition import CustomFieldDefinition

        _response: ExtendedObjectDetailResponse = context.response.model_copy()  # type: ignore

        if context.class_name not in CRM_ENTITY_TYPES or not _response.control:
            return await next_fn(context)

        values = get_values_from_response(_response.rows)

        custom_field_defs = list(
            await CustomFieldDefinition.objects.filter(
                entity_type=context.class_name,
                _metadata__is_deleted=False,
                _address__object_version=Versions.LATEST,
            ).aexecute()
        )

        if not custom_field_defs:
            return await next_fn(context)

        # Sort by display_order
        custom_field_defs.sort(key=lambda x: x.display_order)

        custom_field_controls = [
            _custom_field_def_to_control(field_def, values=values) for field_def in custom_field_defs
        ]

        _add_custom_fields_to_control(_response.control, custom_field_controls)

        context.create_next(
            listener_id=self.listener_id,
            response=_response,
        )

        return await next_fn(context)
