from typing import Any

from pydantic.fields import Field


class CustomFieldsMixin:
    custom_fields: dict[str, Any] | None = Field(default=None, title='Custom Fields')

    @classmethod
    def custom_fields_cell_template(cls) -> str:
        return 'JsonTemplate'

    def pre_create(self) -> None:
        self._validate_custom_fields()
        super().pre_create()  # type: ignore

    async def apre_create(self) -> None:
        await self._avalidate_custom_fields()
        await super().apre_create()  # type: ignore

    def pre_update(self) -> None:
        self._validate_custom_fields()
        super().pre_update()  # type: ignore

    async def apre_update(self) -> None:
        await self._avalidate_custom_fields()
        await super().apre_update()  # type: ignore

    def _validate_custom_fields(self) -> None:
        if self.custom_fields:
            from amsdal_crm.services.custom_field_service import CustomFieldService

            self.custom_fields = CustomFieldService.validate_custom_fields(
                self.__class__.__name__,
                self.custom_fields,
            )

    async def _avalidate_custom_fields(self) -> None:
        if self.custom_fields:
            from amsdal_crm.services.custom_field_service import CustomFieldService

            self.custom_fields = await CustomFieldService.avalidate_custom_fields(
                self.__class__.__name__,
                self.custom_fields,
            )
