"""Account Model."""

from typing import Any
from typing import ClassVar
from typing import Literal

from amsdal.contrib.auth.models.user import User
from amsdal.contrib.auth.utils.scopes import is_super_admin
from amsdal.models.mixins import TimestampMixin
from amsdal_models.classes.data_models.constraints import UniqueConstraint
from amsdal_models.classes.data_models.indexes import IndexInfo
from amsdal_models.classes.model import Model
from amsdal_models.managers.model_manager import Manager
from amsdal_models.querysets.base_queryset import QuerySet
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field
from starlette.authentication import AuthCredentials
from starlette.authentication import BaseUser

from amsdal_crm.models.common import CustomFieldsMixin


class EntityManager(Manager):
    def get_queryset(self) -> QuerySet['Entity']:
        return super().get_queryset().select_related('assigned_to')


class Entity(CustomFieldsMixin, TimestampMixin, Model):
    """Entity (Person/Organization/Trust) model.

    Represents a company or organization in the CRM system.
    Owned by individual users with permission controls.
    """

    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB
    __constraints__: ClassVar[list[UniqueConstraint]] = [UniqueConstraint(name='unq_entity_name', fields=['name'])]
    __indexes__: ClassVar[list[IndexInfo]] = [
        IndexInfo(name='idx_entity_created_at', field='created_at'),
    ]

    # Core fields
    name: str = Field(title='Entity Name')
    legal_name: str | None = Field(default=None, title='Legal Name')
    status: Literal['Active', 'Inactive'] = Field(default='Active', title='Status')
    note: str | None = Field(default=None, title='Note')

    assigned_to: User | None = Field(default=None, title='Assigned To')

    objects = EntityManager()

    @property
    def display_name(self) -> str:
        """Return display name for the account."""
        return self.name

    def has_object_permission(
        self,
        user: 'BaseUser',
        action: 'Action',  # noqa: ARG002
        update_data: dict[str, Any] | None = None,  # noqa: ARG002
        auth: 'AuthCredentials | None' = None,
    ) -> bool:
        """Check if user has permission to perform action on this account.

        Args:
            user: The user attempting the action
            action: The action being attempted (read, create, update, delete)

        Returns:
            True if user has permission, False otherwise
        """
        if not user.is_authenticated:
            return False

        if self.assigned_to and self.assigned_to.email == user.identity:
            return True

        user_scopes = set(getattr(auth, 'scopes', [])) if auth else set()

        if is_super_admin(user_scopes):
            return True

        return False

    def post_update(self) -> None:
        """Hook called after updating account."""
        from amsdal_crm.services.workflow_service import WorkflowService

        WorkflowService.execute_rules('Entity', 'update', self)

    async def apost_update(self) -> None:
        """Async hook called after updating account."""
        from amsdal_crm.services.workflow_service import WorkflowService

        await WorkflowService.aexecute_rules('Entity', 'update', self)


class EntityRelationship(CustomFieldsMixin, TimestampMixin, Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    from_entity: Entity = Field(title='From Entity')
    to_entity: Entity = Field(title='To Entity')
    start_date: str | None = Field(default=None, title='Start Date')
    end_date: str | None = Field(default=None, title='End Date')
    relationship_group_name: str | None = Field(default=None, title='Relationship Group Name')


class EntityIdentifier(CustomFieldsMixin, TimestampMixin, Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    entity: Entity = Field(title='Entity')
    value: str = Field(title='Identifier Value')
    country: str | None = Field(default=None, title='Country')

    # TODO: validate one per entity
    is_primary: bool = Field(default=False, title='Is Primary')


class EntityContactPoint(CustomFieldsMixin, TimestampMixin, Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    entity: Entity = Field(title='Entity')
    value: str = Field(title='Contact Point Value')

    # TODO: validate one per entity
    is_primary: bool = Field(default=False, title='Is Primary')
    can_contact: bool = Field(default=True, title='Can Contact')


class EntityAddress(CustomFieldsMixin, TimestampMixin, Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB

    line1: str | None = Field(title='Address Line 1')
    line2: str | None = Field(default=None, title='Address Line 2')
    city: str | None = Field(title='City')
    region: str | None = Field(default=None, title='Region/State')
    postal_code: str | None = Field(default=None, title='Postal Code')
    country: str | None = Field(title='Country')

    # TODO: validate one per entity
    is_primary: bool = Field(default=False, title='Is Primary')
