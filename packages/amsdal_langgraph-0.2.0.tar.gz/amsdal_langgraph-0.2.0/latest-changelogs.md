## [v0.2.0](https://pypi.org/project/amsdal_langgraph/0.2.0/) - 2026-02-06

- Upgrade to amsdal v0.6.0