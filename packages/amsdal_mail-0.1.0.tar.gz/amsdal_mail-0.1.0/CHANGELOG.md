# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-06

### Added
- Core architecture with backend abstraction and registry pattern
- `send_mail()` and `asend_mail()` high-level API
- `EmailMessage` and `Attachment` Pydantic models with full validation
- `SendStatus` with per-recipient tracking (`is_success`, `has_failures`, etc.)
- Console backend for development and debugging
- Dummy backend for testing
- SMTP backend with TLS/SSL support and async via aiosmtplib
- AWS SES backend with boto3/aioboto3
- Template support with `template_id`, `merge_data`, `merge_global_data` (SES)
- Tags and metadata for email categorization and tracking
- Click and open tracking (`track_opens`, `track_clicks`)
- Inline images (CID) support via `Attachment.content_id`
- Webhook handlers for SES tracking events (bounce, complaint, delivery, etc.)
- Email tracking events via AMSDAL EventBus
- AMSDAL Framework integration via `MailAppConfig`
- Settings management via pydantic_settings
- Exception hierarchy: `EmailError`, `ConfigurationError`, `EmailConnectionError`, `SendError`
