"""AMSDAL Mail - Universal email integration for AMSDAL Framework."""

from amsdal_mail.backends import get_connection
from amsdal_mail.events import EmailTrackingContext
from amsdal_mail.events import EmailTrackingEvent
from amsdal_mail.events import TrackingEventType
from amsdal_mail.exceptions import ConfigurationError
from amsdal_mail.exceptions import EmailConnectionError
from amsdal_mail.exceptions import EmailError
from amsdal_mail.exceptions import SendError
from amsdal_mail.message import Attachment
from amsdal_mail.message import EmailMessage
from amsdal_mail.settings import mail_settings
from amsdal_mail.status import RecipientStatus
from amsdal_mail.status import SendStatus
from amsdal_mail.status import SendStatusType

__all__ = [
    'Attachment',
    'ConfigurationError',
    'EmailConnectionError',
    'EmailError',
    'EmailMessage',
    'EmailTrackingContext',
    'EmailTrackingEvent',
    'RecipientStatus',
    'SendError',
    'SendStatus',
    'SendStatusType',
    'TrackingEventType',
    'asend_mail',
    'get_connection',
    'mail_settings',
    'send_mail',
]


def send_mail(
    subject: str,
    message: str,
    from_email: str,
    recipient_list: list[str] | str,
    *,
    fail_silently: bool = False,
    html_message: str | None = None,
    connection=None,
    **kwargs,
) -> SendStatus:
    """
    Send a single email message.

    This is a convenience function for sending simple emails. For more control,
    use EmailMessage and get_connection() directly.

    Args:
        subject: Email subject line
        message: Plain text body
        from_email: Sender email address
        recipient_list: List of recipient email addresses (or single string)
        fail_silently: If True, suppress exceptions and return empty SendStatus on failure
        html_message: HTML version of body (optional)
        connection: Reuse existing connection (optional)
        **kwargs: Additional arguments passed to EmailMessage

    Returns:
        SendStatus object with message IDs, statuses, and ESP response

    Raises:
        SendError: If sending fails and fail_silently is False

    Examples:
        >>> status = send_mail(
        ...     'Hello',
        ...     'This is a test email',
        ...     'sender@example.com',
        ...     ['recipient@example.com'],
        ... )
        >>> status.message_id
        'msg-123'
        >>> status.is_success
        True
    """
    # Get or create connection
    connection = connection or get_connection(fail_silently=fail_silently)

    # Normalize recipient_list to list
    if isinstance(recipient_list, str):
        recipient_list = [recipient_list]

    # Create email message
    mail = EmailMessage(
        subject=subject,
        body=message,
        from_email=from_email,
        to=recipient_list,
        html_body=html_message,
        **kwargs,
    )

    # Send message
    return connection.send_messages([mail])


async def asend_mail(
    subject: str,
    message: str,
    from_email: str,
    recipient_list: list[str] | str,
    *,
    fail_silently: bool = False,
    html_message: str | None = None,
    connection=None,
    **kwargs,
) -> SendStatus:
    """
    Send a single email message asynchronously.

    Async version of send_mail(). See send_mail() for parameter documentation.

    Args:
        subject: Email subject line
        message: Plain text body
        from_email: Sender email address
        recipient_list: List of recipient email addresses (or single string)
        fail_silently: If True, suppress exceptions and return empty SendStatus on failure
        html_message: HTML version of body (optional)
        connection: Reuse existing connection (optional)
        **kwargs: Additional arguments passed to EmailMessage

    Returns:
        SendStatus object with message IDs, statuses, and ESP response

    Raises:
        SendError: If sending fails and fail_silently is False

    Examples:
        >>> status = await asend_mail(
        ...     'Hello',
        ...     'This is a test email',
        ...     'sender@example.com',
        ...     ['recipient@example.com'],
        ... )
        >>> status.message_id
        'msg-123'
    """
    # Get or create connection
    connection = connection or get_connection(fail_silently=fail_silently)

    # Normalize recipient_list to list
    if isinstance(recipient_list, str):
        recipient_list = [recipient_list]

    # Create email message
    mail = EmailMessage(
        subject=subject,
        body=message,
        from_email=from_email,
        to=recipient_list,
        html_body=html_message,
        **kwargs,
    )

    # Send message asynchronously
    return await connection.asend_messages([mail])
