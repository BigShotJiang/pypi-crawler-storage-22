"""AMSDAL integration for amsdal_mail plugin."""

from amsdal.contrib.app_config import AppConfig


class MailAppConfig(AppConfig):
    """
    AMSDAL plugin configuration for amsdal_mail.

    Register this in your AMSDAL application settings:
        AMSDAL_CONTRIBS = 'amsdal_mail.app.MailAppConfig'
    """

    name = 'amsdal_mail'
    verbose_name = 'AMSDAL Email Integration'

    def on_setup(self) -> None:
        """Called when the plugin is loaded by AMSDAL."""
        from amsdal_mail.settings import mail_settings

        if mail_settings.WEBHOOK_ENABLED:
            self._setup_webhooks()

    @staticmethod
    def _setup_webhooks() -> None:
        from amsdal_server.apps.common.events.server import RouterSetupEvent  # type: ignore[import-not-found]
        from amsdal_utils.events import EventBus

        from amsdal_mail.settings import mail_settings
        from amsdal_mail.webhooks.listener import WebhookRouterListener
        from amsdal_mail.webhooks.registry import WebhookRegistry
        from amsdal_mail.webhooks.ses import SESWebhookParser

        WebhookRegistry.register('ses', SESWebhookParser(secret=mail_settings.WEBHOOK_SES_SECRET))

        EventBus.subscribe(RouterSetupEvent, WebhookRouterListener)
