"""Dummy email backend - does not send emails."""

from typing import Any

from amsdal_mail.backends.base import BaseEmailBackend
from amsdal_mail.message import EmailMessage
from amsdal_mail.status import RecipientStatus
from amsdal_mail.status import SendStatus


class DummyBackend(BaseEmailBackend):
    """
    Email backend that does not actually send emails.

    Useful for testing - pretends to send messages successfully but does nothing.
    Optionally stores messages for inspection during tests.
    """

    def __init__(self, *, store_messages: bool = False, **kwargs: Any) -> None:
        """
        Initialize the dummy backend.

        Args:
            store_messages: If True, store sent messages in self.messages list
            **kwargs: Additional backend options (passed to parent)
        """
        super().__init__(**kwargs)
        self.store_messages = store_messages
        self.messages: list[EmailMessage] = []

    def send_messages(self, email_messages: list[EmailMessage]) -> SendStatus:
        """
        Pretend to send email messages.

        Args:
            email_messages: List of EmailMessage instances to "send"

        Returns:
            SendStatus with 'sent' status for all recipients
        """
        if self.store_messages:
            self.messages.extend(email_messages)

        status = SendStatus()
        recipients = {}

        # Mark all recipients as sent (but don't actually send)
        for message in email_messages:
            for recipient in message.recipients():
                recipients[recipient] = RecipientStatus(
                    message_id=None,  # Dummy backend doesn't generate message IDs
                    status='sent',
                )

        status.set_recipient_status(recipients)
        return status
