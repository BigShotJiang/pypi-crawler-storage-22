"""Webhook tracking event definitions."""

from datetime import datetime
from enum import StrEnum
from typing import Any

from amsdal_utils.events import ErrorStrategy
from amsdal_utils.events import Event
from amsdal_utils.events import EventContext
from pydantic import Field


class TrackingEventType(StrEnum):
    QUEUED = 'queued'
    SENT = 'sent'
    DELIVERED = 'delivered'
    DEFERRED = 'deferred'
    BOUNCED = 'bounced'
    REJECTED = 'rejected'
    FAILED = 'failed'
    OPENED = 'opened'
    CLICKED = 'clicked'
    COMPLAINED = 'complained'
    UNSUBSCRIBED = 'unsubscribed'
    UNKNOWN = 'unknown'


class EmailTrackingContext(EventContext):
    event_type: TrackingEventType
    message_id: str
    recipient: str
    timestamp: datetime
    esp_name: str
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    reject_reason: str | None = None
    description: str | None = None
    click_url: str | None = None
    user_agent: str | None = None
    raw_event: dict[str, Any] = Field(default_factory=dict)


class EmailTrackingEvent(Event[EmailTrackingContext]):
    """Emitted when webhook receives tracking event from ESP."""

    default_error_strategy = ErrorStrategy.LOG_AND_CONTINUE
