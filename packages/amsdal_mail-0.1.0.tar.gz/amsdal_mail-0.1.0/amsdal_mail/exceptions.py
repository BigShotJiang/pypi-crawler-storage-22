"""Exception classes for amsdal_mail."""


class EmailError(Exception):
    """Base exception for all email-related errors."""

    pass


class ConfigurationError(EmailError):
    """Raised when an email backend is misconfigured."""

    pass


class EmailConnectionError(EmailError):
    """Raised when a connection to an email service fails."""

    pass


class SendError(EmailError):
    """Raised when sending an email message fails."""

    pass
