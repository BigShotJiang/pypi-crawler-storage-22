"""Mail plugin settings."""

from pydantic_settings import BaseSettings
from pydantic_settings import SettingsConfigDict


class MailSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix='AMSDAL_MAIL_',
        case_sensitive=True,
        env_file='.env',
        env_file_encoding='utf-8',
        extra='ignore',
    )

    WEBHOOK_ENABLED: bool = False
    WEBHOOK_BASE_PATH: str = '/webhooks/mail'
    WEBHOOK_SES_SECRET: str | None = None


mail_settings = MailSettings()
