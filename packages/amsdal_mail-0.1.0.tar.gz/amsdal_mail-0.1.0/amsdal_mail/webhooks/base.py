"""Abstract base class for webhook parsers."""

from abc import ABC
from abc import abstractmethod

from amsdal_mail.events import EmailTrackingContext


class BaseWebhookParser(ABC):
    @abstractmethod
    def verify(self, body: bytes, headers: dict[str, str]) -> bool:
        """Verify webhook request authenticity.

        Args:
            body: Raw request body bytes.
            headers: HTTP request headers.

        Returns:
            True if the request is valid.
        """

    @abstractmethod
    def parse(self, body: bytes, headers: dict[str, str]) -> list[EmailTrackingContext]:
        """Parse webhook payload into tracking events.

        Args:
            body: Raw request body bytes.
            headers: HTTP request headers.

        Returns:
            List of normalized tracking contexts.
        """
