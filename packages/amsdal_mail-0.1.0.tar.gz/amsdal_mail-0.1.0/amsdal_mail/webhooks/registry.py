"""Webhook parser registry."""

from typing import ClassVar

from amsdal_mail.webhooks.base import BaseWebhookParser


class WebhookRegistry:
    _parsers: ClassVar[dict[str, BaseWebhookParser]] = {}

    @classmethod
    def register(cls, esp_name: str, parser: BaseWebhookParser) -> None:
        cls._parsers[esp_name] = parser

    @classmethod
    def get_parser(cls, esp_name: str) -> BaseWebhookParser | None:
        return cls._parsers.get(esp_name)

    @classmethod
    def reset(cls) -> None:
        cls._parsers.clear()
