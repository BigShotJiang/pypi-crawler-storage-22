# AMSDAL Mail Documentation

Complete documentation for the AMSDAL Mail plugin.

## 📚 Documentation Index

### Getting Started
- [Main README](../README.md) - Installation, quick start, and usage examples

### Architecture & Design
- [Architecture](ARCHITECTURE.md) - System architecture, design decisions, and patterns

### Feature Guides
- [SMTP Usage Guide](SMTP_USAGE.md) - Detailed SMTP examples (Gmail, attachments, inline images, etc.)
- [Tracking Guide](TRACKING.md) - Email click and open tracking setup
- [Webhooks](../README.md#webhooks) - Receiving tracking events from ESPs

## 🎯 Quick Links

### For Users
- **Installation**: See [README - Installation](../README.md#installation)
- **Quick Start**: See [README - Quick Start](../README.md#quick-start)
- **Configuration**: See [README - Configuration](../README.md#configuration)
- **Tracking Setup**: See [TRACKING.md](TRACKING.md)

### For Developers
- **Architecture**: See [ARCHITECTURE.md](ARCHITECTURE.md)
- **Contributing**: See [README - Development](../README.md)

## 📖 Topics

### Email Basics
- Sending simple text emails
- Sending HTML emails
- Adding attachments
- Inline images (CID)
- Managing recipients (to, cc, bcc)

### Advanced Features
- **Template Support**: Using ESP templates with merge data
- **Tags & Metadata**: Categorizing and tracking emails
- **Click/Open Tracking**: Monitoring email engagement
- **Async Operations**: Using async/await for email sending

### Backend Configuration
- **AWS SES**: Configuration Sets, templates, tracking
- **SMTP**: TLS/SSL setup, authentication
- **Console**: Development and debugging
- **Dummy**: Testing without sending

### Implemented Features
- ✅ **SendStatus**: Rich status objects with message IDs and per-recipient tracking
- ✅ **Template Support**: ESP templates with merge data (SES)
- ✅ **Tags & Metadata**: Message categorization and custom data (SES)
- ✅ **Click/Open Tracking**: Email engagement monitoring (SES)
- ✅ **Inline Images**: Embed images in HTML via CID references

### Future Features
- SendGrid backend (planned)
- Mailgun backend (planned)
- Postmark backend (planned)

## 🔗 External Resources

### AWS SES
- [SES Configuration Sets](https://docs.aws.amazon.com/ses/latest/dg/using-configuration-sets.html)
- [SES Templates](https://docs.aws.amazon.com/ses/latest/dg/send-personalized-email-api.html)
- [SES Event Publishing](https://docs.aws.amazon.com/ses/latest/dg/monitor-using-event-publishing.html)

### Related Projects
- [AMSDAL Framework](https://github.com/amsdal/amsdal)
