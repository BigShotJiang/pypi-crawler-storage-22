"""Tests for amsdal_mail."""
