"""Tests for amsdal_mail public API."""

import pytest

from amsdal_mail import SendStatus
from amsdal_mail import asend_mail
from amsdal_mail import get_connection
from amsdal_mail import send_mail
from amsdal_mail.backends.dummy import DummyBackend


class TestSendMail:
    """Tests for send_mail function."""

    def test_send_mail_simple(self):
        """Test sending a simple email."""
        status = send_mail(
            'Test Subject',
            'Test message',
            'sender@example.com',
            ['recipient@example.com'],
        )

        assert isinstance(status, SendStatus)
        assert status.is_success
        assert status.status is not None and 'sent' in status.status
        assert 'recipient@example.com' in status.recipients

    def test_send_mail_with_html(self):
        """Test sending email with HTML."""
        status = send_mail(
            'Test',
            'Plain text',
            'sender@example.com',
            ['recipient@example.com'],
            html_message='<h1>HTML</h1>',
        )

        assert isinstance(status, SendStatus)
        assert status.is_success

    def test_send_mail_single_recipient_string(self):
        """Test sending to single recipient as string."""
        status = send_mail(
            'Test',
            'Message',
            'sender@example.com',
            'recipient@example.com',  # Single string, not list
        )

        assert isinstance(status, SendStatus)
        assert status.is_success

    def test_send_mail_multiple_recipients(self):
        """Test sending to multiple recipients."""
        status = send_mail(
            'Test',
            'Message',
            'sender@example.com',
            ['recipient1@example.com', 'recipient2@example.com', 'recipient3@example.com'],
        )

        assert isinstance(status, SendStatus)
        assert status.is_success
        assert len(status.recipients) == 3

    def test_send_mail_with_custom_connection(self):
        """Test sending with custom connection."""
        backend = DummyBackend(store_messages=True)

        status = send_mail(
            'Test',
            'Message',
            'sender@example.com',
            ['recipient@example.com'],
            connection=backend,
        )

        assert isinstance(status, SendStatus)
        assert status.is_success
        assert len(backend.messages) == 1
        assert backend.messages[0].subject == 'Test'

    def test_send_mail_with_extra_kwargs(self):
        """Test sending with extra kwargs (cc, bcc, etc)."""
        backend = DummyBackend(store_messages=True)

        status = send_mail(
            'Test',
            'Message',
            'sender@example.com',
            ['recipient@example.com'],
            cc=['cc@example.com'],
            bcc=['bcc@example.com'],
            connection=backend,
        )

        assert isinstance(status, SendStatus)
        assert status.is_success
        assert backend.messages[0].cc == ['cc@example.com']
        assert backend.messages[0].bcc == ['bcc@example.com']

    def test_send_mail_fail_silently(self):
        """Test fail_silently parameter."""
        # Console backend always succeeds, so just test it accepts the parameter
        status = send_mail(
            'Test',
            'Message',
            'sender@example.com',
            ['recipient@example.com'],
            fail_silently=True,
        )

        assert isinstance(status, SendStatus)
        assert status.is_success

    def test_send_mail_uses_default_backend(self, monkeypatch):
        """Test that send_mail uses default backend."""
        # Set environment to use dummy backend
        monkeypatch.setenv('AMSDAL_EMAIL_BACKEND', 'dummy')

        status = send_mail(
            'Test',
            'Message',
            'sender@example.com',
            ['recipient@example.com'],
        )

        assert isinstance(status, SendStatus)
        assert status.is_success


class TestAsendMail:
    """Tests for asend_mail function."""

    @pytest.mark.asyncio
    async def test_asend_mail_simple(self):
        """Test sending a simple email asynchronously."""
        status = await asend_mail(
            'Test Subject',
            'Test message',
            'sender@example.com',
            ['recipient@example.com'],
        )

        assert isinstance(status, SendStatus)
        assert status.is_success

    @pytest.mark.asyncio
    async def test_asend_mail_with_html(self):
        """Test sending email with HTML asynchronously."""
        status = await asend_mail(
            'Test',
            'Plain text',
            'sender@example.com',
            ['recipient@example.com'],
            html_message='<h1>HTML</h1>',
        )

        assert isinstance(status, SendStatus)
        assert status.is_success

    @pytest.mark.asyncio
    async def test_asend_mail_single_recipient_string(self):
        """Test sending to single recipient as string asynchronously."""
        status = await asend_mail(
            'Test',
            'Message',
            'sender@example.com',
            'recipient@example.com',
        )

        assert isinstance(status, SendStatus)
        assert status.is_success

    @pytest.mark.asyncio
    async def test_asend_mail_with_custom_connection(self):
        """Test async sending with custom connection."""
        backend = DummyBackend(store_messages=True)

        status = await asend_mail(
            'Test',
            'Message',
            'sender@example.com',
            ['recipient@example.com'],
            connection=backend,
        )

        assert isinstance(status, SendStatus)
        assert status.is_success
        assert len(backend.messages) == 1
        assert backend.messages[0].subject == 'Test'

    @pytest.mark.asyncio
    async def test_asend_mail_multiple_calls(self):
        """Test making multiple async calls."""
        backend = DummyBackend(store_messages=True)

        statuses = []
        for i in range(3):
            status = await asend_mail(
                f'Test {i}',
                'Message',
                'sender@example.com',
                ['recipient@example.com'],
                connection=backend,
            )
            statuses.append(status)

        assert all(isinstance(s, SendStatus) for s in statuses)
        assert all(s.is_success for s in statuses)
        assert len(backend.messages) == 3


class TestGetConnection:
    """Tests for get_connection function (already covered in test_backends.py)."""

    def test_get_connection_exported(self):
        """Test that get_connection is exported from main module."""
        from amsdal_mail import get_connection as imported_get_connection

        assert imported_get_connection == get_connection
