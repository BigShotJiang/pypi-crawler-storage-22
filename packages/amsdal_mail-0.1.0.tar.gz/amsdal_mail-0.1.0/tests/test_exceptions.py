"""Tests for amsdal_mail exceptions."""

import pytest

from amsdal_mail.exceptions import ConfigurationError
from amsdal_mail.exceptions import EmailConnectionError
from amsdal_mail.exceptions import EmailError
from amsdal_mail.exceptions import SendError


def test_email_error_is_base_exception():
    """Test that EmailError is the base exception."""
    error = EmailError('Test error')
    assert isinstance(error, Exception)
    assert str(error) == 'Test error'


def test_configuration_error_inherits_from_email_error():
    """Test that ConfigurationError inherits from EmailError."""
    error = ConfigurationError('Invalid config')
    assert isinstance(error, EmailError)
    assert isinstance(error, Exception)
    assert str(error) == 'Invalid config'


def test_email_connection_error_inherits_from_email_error():
    """Test that EmailConnectionError inherits from EmailError."""
    error = EmailConnectionError('Connection failed')
    assert isinstance(error, EmailError)
    assert isinstance(error, Exception)
    assert str(error) == 'Connection failed'


def test_send_error_inherits_from_email_error():
    """Test that SendError inherits from EmailError."""
    error = SendError('Send failed')
    assert isinstance(error, EmailError)
    assert isinstance(error, Exception)
    assert str(error) == 'Send failed'


def test_exceptions_can_be_raised():
    """Test that all exceptions can be raised and caught."""
    with pytest.raises(EmailError):
        raise EmailError('test')

    with pytest.raises(ConfigurationError):
        raise ConfigurationError('test')

    with pytest.raises(EmailConnectionError):
        raise EmailConnectionError('test')

    with pytest.raises(SendError):
        raise SendError('test')


def test_exception_hierarchy():
    """Test exception hierarchy with catch blocks."""
    # ConfigurationError can be caught as EmailError
    with pytest.raises(EmailError):
        raise ConfigurationError('test')

    # EmailConnectionError can be caught as EmailError
    with pytest.raises(EmailError):
        raise EmailConnectionError('test')

    # SendError can be caught as EmailError
    with pytest.raises(EmailError):
        raise SendError('test')
