## [v0.3.0](https://pypi.org/project/amsdal_ml/0.3.0/) - 2026-02-06

## Update to amsdal v0.6.0