# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.2] - 2026-02-06

### Added
- AMSDAL EULA license
- CHANGELOG.md in Keep a Changelog format
- Consolidated CI/CD workflows

## [0.3.1] - 2026-02-06

### Fixed
- Fixed on_setup for AppConfig

## [0.3.0] - 2026-02-06

### Changed
- Update to amsdal v0.6.0

## [0.2.2] - 2026-01-19

### Fixed
- Added support for `JSON_SCHEMA` response format when using attachments in OpenAI Responses API
- Support for images in OpenAI Responses API (automatically selects `input_image` based on MIME type)
- Added `mime_type` support to `FileAttachment` and `OpenAIFileLoader`

## [0.2.1] - 2025-12-23

### Changed
- Upgraded dependencies: pydantic~=2.12, pydantic-settings~=2.12

## [0.2.0] - 2025-12-16

### Added
- `PythonTool`: Tool for executing Python functions within agents
- `FunctionalCallingAgent`: Agent specialized in functional calling with configurable tools
- `NLQueryRetriever`: Retriever for natural language queries on AMSDAL querysets
- `DefaultIngestionPipeline`: Pipeline for document ingestion including loader, cleaner, splitter, embedder, and store
- `ModelIngester`: High-level ingester for processing models with customizable pipelines and metadata
- `PdfLoader`: Document loader using pymupdf for PDF processing
- `TextCleaner`: Processor for cleaning and normalizing text
- `TokenSplitter`: Splitter for dividing text into chunks based on token count
- `OpenAIEmbedder`: Embedder for generating embeddings via OpenAI API
- `EmbeddingDataStore`: Store for saving embedding data linked to source objects

## [0.1.4] - 2025-10-15

### Fixed
- Fixed lazy initialization of OpenAIRetriever to ensure env vars are loaded
- Added missing env parameter to stdio_client for non-persistent sessions
- Environment variables now properly passed to MCP stdio subprocesses
- Updated README.md to be production-ready
- Added RELEASE.md with step-by-step release guide

## [0.1.3] - 2025-10-13

### Fixed
- Pass env vars into stdio server
- Cleanup of app.py

## [0.1.2] - 2025-10-08

### Fixed
- Fix for UserWarning: Field name "object_id" in "EmbeddingModel" shadows an attribute in parent "Model"

## [0.1.1] - 2025-10-08

### Added
- BaseFileLoader interface and OpenAI Files API implementation

## [0.1.0] - 2025-09-22

### Added
- Interfaces and default OpenAI-based implementations