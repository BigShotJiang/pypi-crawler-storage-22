# Release Guide

Follow these steps each time you release a new version of `amsdal-ml`.

---

## Step 1: Update Version and Changelog

1. Create a release branch:
   ```bash
   git checkout -b release/X.Y.Z
   ```

2. Bump version in `amsdal_ml/__about__.py`:
   ```python
   __version__ = 'X.Y.Z'
   ```

3. Add entry to `CHANGELOG.md` following [Keep a Changelog](https://keepachangelog.com/) format

4. Commit and push:
   ```bash
   git add amsdal_ml/__about__.py CHANGELOG.md
   git commit -m "Bump version to X.Y.Z"
   git push origin release/X.Y.Z
   ```

**Version format**: `MAJOR.MINOR.PATCH`
- PATCH: Bug fixes (e.g., `0.3.1` → `0.3.2`)
- MINOR: New features (e.g., `0.3.2` → `0.4.0`)
- MAJOR: Breaking changes (e.g., `0.4.0` → `1.0.0`)

---

## Step 2: Create and Merge Pull Request

1. Create PR from `release/X.Y.Z` → `main`
2. CI will run lint + tests automatically
3. Merge the PR

---

## Step 3: Automatic Release

Once the `release/*` PR is merged to `main`, the CD workflow automatically:
1. Reads version from `__about__.py`
2. Runs license check
3. Builds the package
4. Creates and pushes git tag `vX.Y.Z`
5. Publishes to PyPI
6. Creates GitHub Release with changelog

---

## Step 4: Verify Release

### Check PyPI
https://pypi.org/project/amsdal-ml/

### Check GitHub Releases
https://github.com/amsdal/amsdal_ml/releases

### Test Installation
```bash
pip install --upgrade amsdal-ml
python -c "import amsdal_ml; print(amsdal_ml.__version__)"
```

---

## Troubleshooting

**If CD fails:**
1. Check logs at https://github.com/amsdal/amsdal_ml/actions
2. Fix the issue, bump version again, create a new release branch and PR

**If you need to rollback:**
- Release a new patch version with the fix (recommended)
- Or yank the release from PyPI using `twine`