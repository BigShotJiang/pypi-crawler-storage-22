## [v0.6.1](https://pypi.org/project/amsdal_server/0.6.1/) - 2026-02-05

### Changed

- Add support for amsdal v0.6
