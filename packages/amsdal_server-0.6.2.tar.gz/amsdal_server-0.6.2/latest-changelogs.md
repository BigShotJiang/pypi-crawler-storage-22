## [v0.6.2](https://pypi.org/project/amsdal_server/0.6.2/) - 2026-02-05

### Changed

- Added lock for amsdal v0.6.*
