from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.events import EventBus
from starlette.authentication import AuthCredentials
from starlette.authentication import AuthenticationBackend
from starlette.authentication import BaseUser
from starlette.authentication import UnauthenticatedUser
from starlette.requests import HTTPConnection

from amsdal_server.apps.common.events.auth import AuthenticateContext
from amsdal_server.apps.common.events.auth import AuthenticateEvent
from amsdal_server.configs.main import settings


class AmsdalAuthenticationBackend(AuthenticationBackend):
    async def authenticate(self, conn: HTTPConnection) -> tuple[AuthCredentials, BaseUser] | None:
        credentials = AuthCredentials([])
        user: BaseUser = UnauthenticatedUser()

        if settings.AUTHORIZATION_HEADER in conn.headers:
            auth = conn.headers[settings.AUTHORIZATION_HEADER]
            context = AuthenticateContext(auth_header=auth, connection=conn)

            if AmsdalConfigManager().get_config().async_mode:
                result = await EventBus.aemit(AuthenticateEvent, context)
            else:
                result = EventBus.emit(AuthenticateEvent, context)

            if result.user:
                credentials = AuthCredentials(result.scopes)
                user = result.user

        return credentials, user
