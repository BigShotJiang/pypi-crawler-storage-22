# mypy: disable-error-code="call-arg,arg-type"
import base64
from typing import Any

from amsdal_data.transactions.decorators import async_transaction
from amsdal_data.transactions.decorators import transaction
from amsdal_models.classes.class_manager import ClassManager
from amsdal_models.classes.errors import AmsdalUniquenessError
from amsdal_models.classes.errors import ObjectAlreadyExistsError
from amsdal_models.classes.model import Model
from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.models.data_models.address import Address
from pydantic import BaseModel

from amsdal_server.apps.classes.errors import ClassNotFoundError
from amsdal_server.apps.common.mixins.permissions_mixin import PermissionsMixin
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType
from amsdal_server.apps.common.utils import import_class_model
from amsdal_server.apps.objects.mixins.object_data_mixin import ObjectDataMixin
from amsdal_server.apps.objects.utils import normalize_address


class BulkAddressBody(BaseModel):
    address: str


class BulkUpdateBody(BulkAddressBody):
    data: dict[str, Any]


class ObjectApi(PermissionsMixin, ObjectDataMixin):
    @classmethod
    def _is_async_mode(cls) -> bool:
        return AmsdalConfigManager().get_config().async_mode

    @classmethod
    async def create_object(
        cls,
        base_url: str,
        class_name: str,
        data: dict[str, Any],
        *,
        load_references: bool = False,
    ) -> dict[str, Any]:
        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=class_name,
            action=Action.CREATE,
        )

        model_class = cls._get_model_class(class_name)
        _data = cls._decode_bytes(data)
        object_item = model_class(**_data)

        await cls.authorize_object(object_item, Action.CREATE)

        try:
            if cls._is_async_mode():
                await object_item.asave(force_insert=True)
            else:
                object_item.save(force_insert=True)
        except ObjectAlreadyExistsError as e:
            msg = 'Object with the same ID already exists'
            raise ValueError(msg) from e
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        return await cls.build_object_data(
            object_item,
            base_url=base_url,
            load_references=load_references,
            include_metadata=True,
        )

    @classmethod
    async def bulk_create_objects(
        cls,
        base_url: str,
        class_name: str,
        data: list[dict[str, Any]],
        *,
        load_references: bool = False,
    ) -> list[dict[str, Any]]:
        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=class_name,
            action=Action.CREATE,
        )

        model_class = cls._get_model_class(class_name)
        _data = cls._decode_bytes(data)

        object_items = []
        for object_data in _data:
            if '_object_id' in object_data:
                msg = 'Object ID cannot be provided for bulk create'
                raise ValueError(msg)
            object_items.append(model_class(**object_data))

        for object_item in object_items:
            await cls.authorize_object(object_item, Action.CREATE)

        try:
            if cls._is_async_mode():
                await model_class.objects.bulk_acreate(object_items, force_insert=True)
            else:
                model_class.objects.bulk_create(object_items, force_insert=True)
        except ObjectAlreadyExistsError as e:
            msg = 'Object with the same ID already exists'
            raise ValueError(msg) from e
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        return [
            await cls.build_object_data(
                object_item,
                base_url=base_url,
                load_references=load_references,
                include_metadata=True,
            )
            for object_item in object_items
        ]

    @classmethod
    async def validate_object(
        cls,
        class_name: str,
        data: dict[str, Any],
    ) -> None:
        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=class_name,
            action=Action.READ,
        )
        model_class = cls._get_model_class(class_name=class_name)
        model_class(**data)

    @classmethod
    async def update_object(
        cls,
        base_url: str,
        address: str,
        data: dict[str, Any],
        *,
        load_references: bool = False,
    ) -> dict[str, Any]:
        _address = Address.from_string(address)

        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=_address.class_name,
            action=Action.UPDATE,
        )

        model_class = cls._get_model_class(_address.class_name)
        qs = model_class.objects.get(
            _metadata__is_deleted=False,
            _address__object_id=_address.object_id,
            _address__class_version=_address.class_version,
            _address__object_version=_address.object_version,
        )

        if cls._is_async_mode():
            object_item = await qs.aexecute()
            _metadata = await object_item.aget_metadata()
        else:
            object_item = qs.execute()
            _metadata = object_item.get_metadata()

        _data = cls._decode_bytes(data)
        await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

        updated_item = model_class(
            **_data,
            _metadata=_metadata,
            _object_id=object_item.object_id,
        )

        try:
            if cls._is_async_mode():
                await updated_item.asave()
            else:
                updated_item.save()
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        return await cls.build_object_data(updated_item, base_url=base_url, load_references=load_references)

    @classmethod
    async def bulk_update_objects(
        cls,
        base_url: str,
        data: list[BulkUpdateBody],
        *,
        load_references: bool = False,
    ) -> list[dict[str, Any]]:
        objects_to_update: dict[str, list[Model]] = {}

        for data_item in data:
            _address = Address.from_string(data_item.address)
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=_address.class_name,
                action=Action.UPDATE,
            )
            model_class = cls._get_model_class(_address.class_name)
            objects_to_update.setdefault(_address.class_name, [])

            qs = model_class.objects.get(
                _metadata__is_deleted=False,
                _address__object_id=_address.object_id,
                _address__class_version=_address.class_version,
                _address__object_version=_address.object_version,
            )

            if cls._is_async_mode():
                object_item = await qs.aexecute()
                _metadata = await object_item.aget_metadata()
            else:
                object_item = qs.execute()
                _metadata = object_item.get_metadata()

            _data = cls._decode_bytes(data_item.data)
            await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

            objects_to_update[_address.class_name].append(
                model_class(
                    **_data,
                    _metadata=_metadata,
                    _object_id=object_item.object_id,
                )
            )

        if cls._is_async_mode():
            result_objects = await cls._async_bulk_update(objects_to_update)
        else:
            result_objects = cls._sync_bulk_update(objects_to_update)

        return [
            await cls.build_object_data(updated_item, base_url=base_url, load_references=load_references)
            for updated_item in result_objects
        ]

    @classmethod
    @transaction
    def _sync_bulk_update(cls, objects_to_update: dict[str, list[Model]]) -> list[Model]:
        result_objects = []
        for class_name, objects in objects_to_update.items():
            model_class = ClassManager().import_class(class_name)
            model_class.objects.bulk_update(objects)
            result_objects.extend(objects)
        return result_objects

    @classmethod
    @async_transaction
    async def _async_bulk_update(cls, objects_to_update: dict[str, list[Model]]) -> list[Model]:
        result_objects = []
        for class_name, objects in objects_to_update.items():
            model_class = ClassManager().import_class(class_name)
            await model_class.objects.bulk_aupdate(objects)
            result_objects.extend(objects)
        return result_objects

    @classmethod
    async def partial_update_object(
        cls,
        base_url: str,
        address: str,
        data: dict[str, Any],
        *,
        load_references: bool = False,
    ) -> dict[str, Any]:
        _address = Address.from_string(address)

        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=_address.class_name,
            action=Action.UPDATE,
        )

        model_class = cls._get_model_class(_address.class_name)
        qs = model_class.objects.get(
            _metadata__is_deleted=False,
            _address__object_id=_address.object_id,
            _address__class_version=_address.class_version,
            _address__object_version=_address.object_version,
        )

        if cls._is_async_mode():
            object_item = await qs.aexecute()
        else:
            object_item = qs.execute()

        _data = cls._decode_bytes(data)
        await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

        for _field, _value in _data.items():
            if hasattr(object_item, _field):
                setattr(object_item, _field, _value)

        try:
            if cls._is_async_mode():
                await object_item.asave()
            else:
                object_item.save()
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        return await cls.build_object_data(object_item, base_url=base_url, load_references=load_references)

    @classmethod
    async def bulk_partial_update_objects(
        cls,
        base_url: str,
        data: list[BulkUpdateBody],
        *,
        load_references: bool = False,
    ) -> list[dict[str, Any]]:
        objects_to_update: dict[str, list[Model]] = {}

        for data_item in data:
            _address = Address.from_string(data_item.address)
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=_address.class_name,
                action=Action.UPDATE,
            )
            model_class = cls._get_model_class(_address.class_name)
            objects_to_update.setdefault(_address.class_name, [])

            qs = model_class.objects.get(
                _metadata__is_deleted=False,
                _address__object_id=_address.object_id,
                _address__class_version=_address.class_version,
                _address__object_version=_address.object_version,
            )

            if cls._is_async_mode():
                object_item = await qs.aexecute()
            else:
                object_item = qs.execute()

            _data = cls._decode_bytes(data_item.data)
            await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

            for _field, _value in _data.items():
                if hasattr(object_item, _field):
                    setattr(object_item, _field, _value)

            objects_to_update[_address.class_name].append(object_item)

        if cls._is_async_mode():
            result_objects = await cls._async_bulk_update(objects_to_update)
        else:
            result_objects = cls._sync_bulk_update(objects_to_update)

        return [
            await cls.build_object_data(updated_item, base_url=base_url, load_references=load_references)
            for updated_item in result_objects
        ]

    @classmethod
    async def delete_object(
        cls,
        address: str,
    ) -> None:
        address = normalize_address(address)
        _address = Address.from_string(address)

        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=_address.class_name,
            action=Action.DELETE,
        )

        model_class = cls._get_model_class(_address.class_name)
        qs = model_class.objects.get(
            _metadata__is_deleted=False,
            _address__object_id=_address.object_id,
            _address__class_version=_address.class_version,
            _address__object_version=_address.object_version,
        )

        if cls._is_async_mode():
            object_item = await qs.aexecute()
        else:
            object_item = qs.execute()

        await cls.authorize_object(object_item, Action.DELETE)

        if cls._is_async_mode():
            await object_item.adelete()
        else:
            object_item.delete()

    @classmethod
    async def bulk_delete_objects(cls, data: list[BulkAddressBody]) -> None:
        objects_to_delete: dict[str, list[Model]] = {}

        for data_item in data:
            _address = Address.from_string(data_item.address)
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=_address.class_name,
                action=Action.DELETE,
            )
            model_class = cls._get_model_class(_address.class_name)
            objects_to_delete.setdefault(_address.class_name, [])

            qs = model_class.objects.get(
                _metadata__is_deleted=False,
                _address__object_id=_address.object_id,
                _address__class_version=_address.class_version,
                _address__object_version=_address.object_version,
            )
            if cls._is_async_mode():
                object_item = await qs.aexecute()
            else:
                object_item = qs.execute()

            await cls.authorize_object(object_item, Action.DELETE)
            objects_to_delete[_address.class_name].append(object_item)

        if cls._is_async_mode():
            await cls._async_bulk_delete(objects_to_delete)
        else:
            cls._sync_bulk_delete(objects_to_delete)

    @classmethod
    @transaction
    def _sync_bulk_delete(cls, objects_to_delete: dict[str, list[Model]]) -> None:
        for class_name, objects in objects_to_delete.items():
            model_class = ClassManager().import_class(class_name)
            model_class.objects.bulk_delete(objects)

    @classmethod
    @async_transaction
    async def _async_bulk_delete(cls, objects_to_delete: dict[str, list[Model]]) -> None:
        for class_name, objects in objects_to_delete.items():
            model_class = ClassManager().import_class(class_name)
            await model_class.objects.bulk_adelete(objects)

    @classmethod
    def _get_model_class(cls, class_name: str) -> type[Model]:
        try:
            return import_class_model(class_name)
        except ImportError as e:
            raise ClassNotFoundError(class_name) from e

    @classmethod
    def _decode_bytes(cls, data: Any) -> Any:
        if isinstance(data, dict):
            return {key: cls._decode_bytes(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [cls._decode_bytes(item) for item in data]
        elif isinstance(data, str) and data.startswith('data:binary;base64, '):
            return base64.b64decode(data.replace('data:binary;base64, ', '').encode('utf-8'))
        return data
