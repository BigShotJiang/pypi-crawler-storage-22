## [v0.6.0](https://pypi.org/project/amsdal_utils/0.6.0/) - 2026-01-27

### Added

- The events system, replacement for the lifecycle.
