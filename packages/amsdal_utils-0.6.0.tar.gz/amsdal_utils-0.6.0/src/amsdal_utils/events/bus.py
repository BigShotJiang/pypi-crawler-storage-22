import importlib
import logging
from collections.abc import Awaitable
from collections.abc import Callable
from typing import Any
from typing import ClassVar
from typing import TypeVar

from amsdal_utils.events.config import ErrorStrategy
from amsdal_utils.events.config import _ListenerRegistration
from amsdal_utils.events.context import EventContext
from amsdal_utils.events.event import Event
from amsdal_utils.events.listener import EventListener

logger = logging.getLogger(__name__)

TContext = TypeVar('TContext', bound=EventContext)


def _resolve_listener_id(listener: type[EventListener[Any]] | str) -> str:
    """
    Resolve listener to its listener_id string.

    Args:
        listener: Either a listener class or a fully-qualified module path string

    Returns:
        The listener_id string

    Raises:
        ValueError: If string path cannot be imported or is malformed
        TypeError: If the resolved object is not a subclass of EventListener

    Example:
        _resolve_listener_id(MyListener)  # Returns "module.MyListener" (from listener.listener_id)
        _resolve_listener_id("module.path.MyListener")  # Validates import and returns listener_id
    """
    if isinstance(listener, str):
        # String path - strict validation by import
        parts = listener.rsplit('.', 1)
        expected_parts_count = 2
        if len(parts) != expected_parts_count:
            msg = f'Invalid listener path "{listener}". Expected format: "module.ClassName"'
            raise ValueError(msg)

        module_path, class_name = parts

        try:
            module = importlib.import_module(module_path)
        except ImportError as e:
            msg = f'Cannot import module "{module_path}" from listener path "{listener}". Check for typos: {e}'
            raise ValueError(msg) from e

        try:
            listener_cls = getattr(module, class_name)
        except AttributeError as e:
            msg = f'Class "{class_name}" not found in module "{module_path}". Check for typos.'
            raise ValueError(msg) from e

        # Verify it's an EventListener subclass
        if not isinstance(listener_cls, type) or not issubclass(listener_cls, EventListener):
            msg = f'"{listener}" is not a subclass of EventListener'
            raise TypeError(msg)

        # Successfully validated - return its listener_id
        return listener_cls.listener_id
    else:
        # Class type - return its listener_id
        if not isinstance(listener, type) or not issubclass(listener, EventListener):
            msg = f'Expected EventListener subclass or string path, got {type(listener)}'
            raise TypeError(msg)
        return listener.listener_id


class EventBus:
    """
    Central event bus for middleware-style event handling.

    Features:
    - Type-safe event/context binding
    - Middleware chain pattern
    - Dependency-based ordering
    - Context history tracking
    - Caching of sorted listeners for performance

    Example:
        # Register listener
        EventBus.subscribe(MyEvent, MyListener, priority=100)

        # Emit event
        context = MyContext(value=10)
        result = EventBus.emit(MyEvent, context)

        # Or async
        result = await EventBus.aemit(MyEvent, context)
    """

    _listeners: ClassVar[dict[type[Event[Any]], list[_ListenerRegistration]]] = {}
    _sorted_cache: ClassVar[dict[type[Event[Any]], list[_ListenerRegistration]]] = {}

    @classmethod
    def subscribe(
        cls,
        event: type[Event[TContext]],
        listener: type[EventListener[TContext]],
        after: list[type[EventListener[Any]] | str] | None = None,
        before: list[type[EventListener[Any]] | str] | None = None,
        priority: int = 500,
        error_strategy: ErrorStrategy | None = None,
    ) -> None:
        """
        Subscribe listener to event.

        Args:
            event: Event class to listen to
            listener: Listener class (will be instantiated per execution)
            after: List of listeners or listener_id strings this should run after.
                   Strings must be fully-qualified paths (e.g., "module.ClassName")
            before: List of listeners or listener_id strings this should run before.
                    Strings must be fully-qualified paths (e.g., "module.ClassName")
            priority: Numeric priority (0-999, lower = earlier)
            error_strategy: How to handle errors (None = use event's default)

        Raises:
            ValueError: If string path cannot be imported (typo in listener reference)
            TypeError: If listener reference is not an EventListener subclass

        Example:
            # Using class references (type-safe)
            EventBus.subscribe(MyEvent, ListenerA, after=[ListenerB])

            # Using string paths (for cross-module references)
            EventBus.subscribe(MyEvent, ListenerA, after=["other.module.ListenerB"])

            # Mixed approach
            EventBus.subscribe(MyEvent, ListenerC, after=[ListenerA, "other.module.ListenerB"])
        """
        # Use event's default error strategy if not specified
        if error_strategy is None:
            error_strategy = event.default_error_strategy

        # Resolve listener references to IDs
        after_ids = [_resolve_listener_id(dep) for dep in (after or [])]
        before_ids = [_resolve_listener_id(dep) for dep in (before or [])]

        # Check for duplicate registration
        existing_listeners = cls._listeners.get(event, [])
        if any(reg.listener_id == listener.listener_id for reg in existing_listeners):
            return  # Already registered, skip

        registration = _ListenerRegistration(
            listener=listener,
            after=after_ids,
            before=before_ids,
            priority=priority,
            error_strategy=error_strategy,
        )

        cls._listeners.setdefault(event, []).append(registration)
        # Invalidate cache
        cls._sorted_cache.pop(event, None)

    @classmethod
    def unsubscribe(cls, event: type[Event[Any]], listener_id: str) -> bool:
        """
        Unsubscribe listener from event.

        Args:
            event: Event type
            listener_id: Listener ID to remove

        Returns:
            True if listener was found and removed
        """
        if event not in cls._listeners:
            return False

        initial_count = len(cls._listeners[event])
        cls._listeners[event] = [reg for reg in cls._listeners[event] if reg.listener_id != listener_id]

        if len(cls._listeners[event]) < initial_count:
            cls._sorted_cache.pop(event, None)
            return True
        return False

    @classmethod
    def emit(
        cls,
        event: type[Event[TContext]],
        context: TContext,
    ) -> TContext:
        """
        Emit event synchronously and execute middleware chain.

        Args:
            event: Event type to emit
            context: Initial context

        Returns:
            Final context after all listeners

        Raises:
            Any exception raised by listeners (depends on error_strategy)
        """
        listeners = cls._get_sorted_listeners(event)

        if not listeners:
            return context

        chain = cls._build_sync_chain(listeners)
        return chain(context)

    @classmethod
    async def aemit(
        cls,
        event: type[Event[TContext]],
        context: TContext,
    ) -> TContext:
        """
        Emit event asynchronously and execute middleware chain.

        Args:
            event: Event type to emit
            context: Initial context

        Returns:
            Final context after all listeners

        Raises:
            Any exception raised by listeners (depends on error_strategy)
        """
        listeners = cls._get_sorted_listeners(event)

        if not listeners:
            return context

        chain = cls._build_async_chain(listeners)
        return await chain(context)

    @classmethod
    def _get_sorted_listeners(cls, event: type[Event[Any]]) -> list[_ListenerRegistration]:
        """
        Get listeners sorted by dependencies and priority.
        Uses cache to avoid re-sorting on every emit.
        """
        if event in cls._sorted_cache:
            return cls._sorted_cache[event]

        listeners = cls._listeners.get(event, [])
        sorted_listeners = cls._sort_listeners(listeners)

        cls._sorted_cache[event] = sorted_listeners
        return sorted_listeners

    @classmethod
    def _sort_listeners(cls, registrations: list[_ListenerRegistration]) -> list[_ListenerRegistration]:
        """
        Sort listeners by priority and dependencies (after/before).

        Uses topological sort with cycle detection.
        Priority is used as tiebreaker when no dependencies exist.

        Raises:
            ValueError: If circular dependencies detected
        """
        if not registrations:
            return []

        # Build adjacency graph and in-degree map
        graph: dict[str, list[str]] = {}  # listener_id -> [dependencies]
        in_degree: dict[str, int] = {}
        listener_map: dict[str, _ListenerRegistration] = {}

        # Initialize
        for reg in registrations:
            listener_id = reg.listener_id
            listener_map[listener_id] = reg
            graph[listener_id] = []
            in_degree[listener_id] = 0

        # Build dependency graph
        for reg in registrations:
            listener_id = reg.listener_id

            # "after" means this listener depends on others (they must run first)
            for dependency in reg.after:
                if dependency in listener_map:
                    graph[dependency].append(listener_id)
                    in_degree[listener_id] += 1

            # "before" means others depend on this listener (this must run first)
            for dependent in reg.before:
                if dependent in listener_map:
                    graph[listener_id].append(dependent)
                    in_degree[dependent] += 1

        # Kahn's algorithm for topological sort
        queue: list[str] = []
        for listener_id, degree in in_degree.items():
            if degree == 0:
                queue.append(listener_id)

        # Sort queue by priority for deterministic ordering
        queue.sort(key=lambda lid: listener_map[lid].priority)

        result: list[_ListenerRegistration] = []

        while queue:
            # Pop listener with lowest priority
            queue.sort(key=lambda lid: listener_map[lid].priority)
            current = queue.pop(0)
            result.append(listener_map[current])

            # Reduce in-degree for neighbors
            for neighbor in graph[current]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Check for cycles
        if len(result) != len(registrations):
            # Find which listeners are in the cycle
            remaining = [lid for lid, deg in in_degree.items() if deg > 0]
            msg = f'Circular dependency detected among listeners: {remaining}'
            raise ValueError(msg)

        return result

    @classmethod
    def _build_sync_chain(
        cls,
        registrations: list[_ListenerRegistration],
    ) -> Callable[[TContext], TContext]:
        """Build synchronous middleware chain"""

        def create_next(index: int) -> Callable[[TContext], TContext]:
            if index >= len(registrations):
                # End of chain - return context as-is
                return lambda ctx: ctx

            registration = registrations[index]
            next_fn = create_next(index + 1)

            def middleware(ctx: TContext) -> TContext:
                listener_instance = registration.listener()

                try:
                    return listener_instance.handle(ctx, next_fn)

                except Exception as e:
                    if registration.error_strategy == ErrorStrategy.PROPAGATE:
                        raise
                    if registration.error_strategy == ErrorStrategy.LOG_AND_CONTINUE:
                        logger.exception(f'Error in listener {registration.listener_id}: {e}')
                        return next_fn(ctx)
                    # SILENT
                    return next_fn(ctx)

            return middleware

        return create_next(0)

    @classmethod
    def _build_async_chain(
        cls,
        registrations: list[_ListenerRegistration],
    ) -> Callable[[TContext], Awaitable[TContext]]:
        """Build asynchronous middleware chain"""

        def create_next(index: int) -> Callable[[TContext], Awaitable[TContext]]:
            if index >= len(registrations):
                # End of chain - return context as-is
                async def final(ctx: TContext) -> TContext:
                    return ctx

                return final

            registration = registrations[index]
            next_fn = create_next(index + 1)

            async def middleware(ctx: TContext) -> TContext:
                listener_instance = registration.listener()

                try:
                    return await listener_instance.ahandle(ctx, next_fn)
                except Exception as e:
                    if registration.error_strategy == ErrorStrategy.PROPAGATE:
                        raise
                    if registration.error_strategy == ErrorStrategy.LOG_AND_CONTINUE:
                        logger.exception(f'Error in listener {registration.listener_id}: {e}')
                        return await next_fn(ctx)
                    # SILENT
                    return await next_fn(ctx)

            return middleware

        return create_next(0)

    @classmethod
    def reset(cls) -> None:
        """Clear all listeners and cache (useful for testing)"""
        cls._listeners.clear()
        cls._sorted_cache.clear()

    @classmethod
    def get_listeners(cls, event: type[Event[Any]]) -> list[str]:
        """
        Get list of listener IDs for event (for introspection).

        Args:
            event: Event type

        Returns:
            List of listener IDs in execution order
        """
        configs = cls._get_sorted_listeners(event)
        return [cfg.listener_id for cfg in configs]
