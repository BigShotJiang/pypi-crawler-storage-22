from dataclasses import dataclass
from dataclasses import field
from enum import Enum
from typing import Any


class ErrorStrategy(Enum):
    """Strategy for handling errors in listeners"""

    PROPAGATE = 'propagate'  # raise exception, stop chain
    LOG_AND_CONTINUE = 'log_and_continue'  # log error but continue chain
    SILENT = 'silent'  # ignore errors completely


@dataclass
class _ListenerRegistration:
    """Internal: stores listener with metadata"""

    listener: type[Any]  # type[EventListener] but can't import here
    after: list[str] = field(default_factory=list)
    before: list[str] = field(default_factory=list)
    priority: int = 500
    error_strategy: ErrorStrategy = ErrorStrategy.PROPAGATE

    @property
    def listener_id(self) -> str:
        return self.listener.listener_id  # type: ignore[attr-defined,unused-ignore]
