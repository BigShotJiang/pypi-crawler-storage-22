from abc import ABC
from time import time
from typing import Any
from typing import TypeVar

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field


def _safe_deep_copy(value: Any) -> Any:
    """
    Safely deep copy a value.

    - Primitives (None, bool, int, float, str, bytes): returned as-is (immutable)
    - Pydantic BaseModel: uses model_copy(deep=True)
    - dict: recursively copies each key-value pair
    - list: recursively copies each item
    - tuple: recursively copies each item and returns tuple
    - set/frozenset: recursively copies each item
    - Other objects (Request, Response, etc.): returned as-is (reference)
    """
    if value is None or isinstance(value, bool | int | float | str | bytes):
        return value

    if isinstance(value, BaseModel):
        # For Pydantic models, use safe copy on each field
        data = {}
        for field_name in value.__class__.model_fields:
            field_value = getattr(value, field_name)
            data[field_name] = _safe_deep_copy(field_value)
        return value.__class__.model_construct(**data)

    if isinstance(value, dict):
        return {_safe_deep_copy(k): _safe_deep_copy(v) for k, v in value.items()}

    if isinstance(value, list):
        return [_safe_deep_copy(item) for item in value]

    if isinstance(value, tuple):
        return tuple(_safe_deep_copy(item) for item in value)

    if isinstance(value, set):
        return {_safe_deep_copy(item) for item in value}

    if isinstance(value, frozenset):
        return frozenset(_safe_deep_copy(item) for item in value)

    # For anything else (Request, Response, file handles, etc.), keep reference
    return value


class ContextHistoryEntry(BaseModel):
    """Single entry in context history"""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    context_snapshot: Any  # snapshot of context at this point
    listener_id: str  # which listener created this version
    timestamp: float  # when created


TContext = TypeVar('TContext', bound='EventContext')


class EventContext(BaseModel, ABC):
    """
    Base class for all event contexts.

    Each listener creates new immutable version, history is preserved.
    Uses Pydantic with frozen=True to enforce immutability.

    Example:
        class MyContext(EventContext):
            value: int
            processed: bool = False

        # In listener - ✅ correct way
        new_context = context.create_next(
            listener_id=self.listener_id,
            value=context.value * 2,
        )

        # ❌ This will raise ValidationError
        context.value = 42  # pydantic prevents mutation
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    history_: list[ContextHistoryEntry] = Field(default_factory=list, repr=False)
    current_listener_: str | None = Field(default=None, repr=False)

    def create_next(self: TContext, listener_id: str, **changes: Any) -> TContext:
        """
        Create new context version with changes.
        Preserves history.

        Args:
            listener_id: ID of listener creating new version
            **changes: Fields to update in new context

        Returns:
            New context instance with updated fields

        Example:
            new_ctx = context.create_next(
                listener_id="my.Listener",
                value=42,
                processed=True,
            )
        """
        # Add snapshot to history
        # Using _safe_deep_copy to avoid issues with non-copyable objects like Request
        new_history = [
            *self.history_,
            ContextHistoryEntry(
                context_snapshot=_safe_deep_copy(self),
                listener_id=listener_id,
                timestamp=time(),
            ),
        ]

        # Use model_copy to avoid serialization issues with Reference fields
        return self.model_copy(
            update={
                **changes,
                'history_': new_history,
                'current_listener_': listener_id,
            }
        )

    @property
    def history(self) -> list[ContextHistoryEntry]:
        """Get full history of context mutations"""
        return self.history_

    def get_by_listener(self, listener_id: str) -> 'EventContext | None':
        """
        Get context version created by specific listener.

        Args:
            listener_id: Listener ID to search for

        Returns:
            Context snapshot or None if not found
        """
        for entry in self.history_:
            if entry.listener_id == listener_id:
                return entry.context_snapshot
        return None
