from collections.abc import Callable
from typing import Any
from typing import TypeVar

from amsdal_utils.events.bus import EventBus
from amsdal_utils.events.config import ErrorStrategy
from amsdal_utils.events.context import EventContext
from amsdal_utils.events.event import Event
from amsdal_utils.events.listener import EventListener

TContext = TypeVar('TContext', bound=EventContext)


def listen_to(
    event: type[Event[TContext]],
    after: list[type[EventListener[Any]] | str] | None = None,
    before: list[type[EventListener[Any]] | str] | None = None,
    priority: int = 500,
    error_strategy: ErrorStrategy | None = None,
) -> Callable[[type[EventListener[TContext]]], type[EventListener[TContext]]]:
    """
    Decorator to auto-register listener to event.

    Args:
        event: Event class to listen to
        after: List of listeners or listener_id strings this should run after.
               Strings must be fully-qualified paths (e.g., "module.ClassName")
        before: List of listeners or listener_id strings this should run before.
                Strings must be fully-qualified paths (e.g., "module.ClassName")
        priority: Numeric priority (0-999, lower = earlier)
        error_strategy: How to handle errors (None = use event's default)

    Returns:
        Decorated listener class (unchanged)

    Raises:
        ValueError: If string path cannot be imported (typo in listener reference)
        TypeError: If listener reference is not an EventListener subclass

    Example:
        # Using class references (type-safe)
        @listen_to(MyEvent, after=[OtherListener], priority=100)
        class MyListener(EventListener[MyContext]):
            def handle(self, context, next_fn):
                return next_fn(context)

        # Using string paths (for cross-module references)
        @listen_to(MyEvent, after=["other.module.OtherListener"], priority=100)
        class MyListener(EventListener[MyContext]):
            def handle(self, context, next_fn):
                return next_fn(context)

        # Mixed approach
        @listen_to(MyEvent, after=[LocalListener, "other.module.RemoteListener"])
        class MyListener(EventListener[MyContext]):
            def handle(self, context, next_fn):
                return next_fn(context)
    """

    def decorator(listener_cls: type[EventListener[TContext]]) -> type[EventListener[TContext]]:
        EventBus.subscribe(
            event=event,
            listener=listener_cls,
            after=after,
            before=before,
            priority=priority,
            error_strategy=error_strategy,
        )
        return listener_cls

    return decorator
