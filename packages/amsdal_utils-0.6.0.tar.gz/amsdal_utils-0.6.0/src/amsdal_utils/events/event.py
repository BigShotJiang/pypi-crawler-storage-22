from typing import Generic
from typing import TypeVar
from typing import get_args

from amsdal_utils.events.config import ErrorStrategy
from amsdal_utils.events.context import EventContext

TContext = TypeVar('TContext', bound=EventContext)


class Event(Generic[TContext]):
    """
    Base event class with typed context.

    Each event type automatically extracts its context type from the generic parameter.
    Optionally define default error strategy for all listeners of this event.

    Usage:
        class MyEvent(Event[MyContext]):
            pass

        # With custom error strategy
        class NonCriticalEvent(Event[MyContext]):
            default_error_strategy = ErrorStrategy.LOG_AND_CONTINUE

    Attributes:
        context_type: Type of context this event uses (auto-detected)
        default_error_strategy: Default error handling strategy for listeners
    """

    context_type: type[TContext]
    default_error_strategy: ErrorStrategy = ErrorStrategy.PROPAGATE

    def __init_subclass__(cls, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init_subclass__(**kwargs)
        # Auto-detect context type from generic parameter
        if hasattr(cls, '__orig_bases__'):
            for base in cls.__orig_bases__:
                if hasattr(base, '__args__'):
                    args = get_args(base)
                    if args:
                        cls.context_type = args[0]
                        break
