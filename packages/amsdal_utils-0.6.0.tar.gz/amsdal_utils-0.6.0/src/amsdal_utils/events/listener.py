from abc import ABC
from abc import abstractmethod
from collections.abc import Awaitable
from collections.abc import Callable
from typing import Generic
from typing import TypeVar

from amsdal_utils.events.context import EventContext

TContext = TypeVar('TContext', bound=EventContext)

# Type aliases for next function
NextFn = Callable[[TContext], TContext]
AsyncNextFn = Callable[[TContext], Awaitable[TContext]]


class EventListener(ABC, Generic[TContext]):
    """
    Base event listener acting as middleware.

    Each listener receives context and next() function.
    Must call next(context) to continue chain or raise exception to stop.

    The listener_id is auto-generated from module and class name.

    Example:
        class MyListener(EventListener[MyContext]):
            def handle(self, context: MyContext, next: NextFn) -> MyContext:
                # Your logic
                if not self.is_valid(context):
                    raise ValueError("Invalid context")

                # Modify context
                new_ctx = context.create_next(
                    listener_id=self.listener_id,
                    some_field="new_value",
                )

                # Continue chain
                return next(new_ctx)
    """

    listener_id: str

    def __init_subclass__(cls, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init_subclass__(**kwargs)
        # Auto-generate listener_id from module + class name
        if not hasattr(cls, 'listener_id') or cls.listener_id == EventListener.listener_id:
            cls.listener_id = f'{cls.__module__}.{cls.__name__}'

    @abstractmethod
    def handle(self, context: TContext, next_fn: NextFn[TContext]) -> TContext:
        """
        Sync handler (default).

        Args:
            context: Event context (immutable - create new with context.create_next())
            next_fn: Function to call next listener

        Returns:
            Context (original or modified)

        Raises:
            Any exception to stop chain execution
            NotImplementedError: If only async is supported
        """
        msg = f'{self.__class__.__name__} does not implement sync handling'
        raise NotImplementedError(msg)

    @abstractmethod
    async def ahandle(self, context: TContext, next_fn: AsyncNextFn[TContext]) -> TContext:
        """
        Async handler.

        Args:
            context: Event context (immutable - create new with context.create_next())
            next_fn: Async function to call next listener

        Returns:
            Context (original or modified)

        Raises:
            Any exception to stop chain execution
            NotImplementedError: If only sync is supported
        """
        msg = f'{self.__class__.__name__} does not implement async handling'
        raise NotImplementedError(msg)
