"""
AmunPy: Python interface for AMUN simulation outputs.

This package provides tools to read, validate, and process datasets
produced by the AMUN magnetohydrodynamics code
(https://amuncode.org).

It includes:
- snapshot readers for supported formats (AmunXML, AmunH5)
"""
from .amunxml import *
from .amunh5 import *

__all__ = [ 'AmunXML', 'AmunH5' ]

__author__ = "Grzegorz Kowal"
__copyright__ = "Copyright 2018-2026 Grzegorz Kowal <grzegorz@amuncode.org>"
__version__ = "1.0.0"
__maintainer__ = "Grzegorz Kowal"
__email__ = "grzegorz@amuncode.org"
