"""
AmunPy exception hierarchy.

Semantic exception types used throughout AmunPy to distinguish
validation, dataset access, and decoding errors.
"""
class AmunPyError(Exception):
    """Base exception for all AmunPy errors."""


class AmunPyAttributeError(AmunPyError):
    """Raised when global snapshot attributes are missing or invalid."""


class AmunPyChunkError(AmunPyError):
    """Raised when chunk metadata is missing, inconsistent, or invalid."""


class AmunPyVariableError(AmunPyError):
    """Raised when a requested dataset/variable is unknown or unavailable."""


class AmunPyDatasetError(AmunPyError):
    """Raised when dataset reconstruction or assembly parameters are invalid."""


class AmunPyDecodeError(AmunPyError):
    """Raised for binary payload decoding or integrity errors."""
