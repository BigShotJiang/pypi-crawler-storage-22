# tests/test_empty_chunks.py

import numpy as np
import pytest

from amunpy.amun import Amun


class FakeAmun(Amun):
    def __init__(self):
        self.path = "fake"
        self.dataformat = "fake"
        self.attributes = {}
        self.chunks = {}
        self.variables = {}
        self.initialized = True

    def __read_binary_data__(self, *args, **kwargs):
        raise RuntimeError("not used")


@pytest.mark.parametrize(
    "ndims, expected_zblocks",
    [
        (2, 0),
        (3, 1),
    ],
)
def test_check_chunks_allows_empty_chunk_dblocks_zero(ndims, expected_zblocks):
    a = FakeAmun()

    # Provide the minimal attribute set expected by base validation.
    # (Keep consistent with existing tests that set ndims/maxlev/xblocks/yblocks.)
    a.attributes = {
        "nchunks": 1,
        "ndims": ndims,
        "maxlev": 0,
        "xblocks": 1,
        "yblocks": 1,
    }
    if ndims == 3:
        a.attributes["zblocks"] = expected_zblocks

    # IMPORTANT: For ndims=2, your schema tests allow coords/bounds with 3 columns
    # (dummy z). For dblocks=0 we mirror that convention exactly: (0, 3) and (0, 2, 3).
    a.chunks = {
        0: {
            "filename": "c0",
            "dblocks": 0,
            "levels": np.empty((0,), dtype=int),
            "coords": np.empty((0, 3), dtype=float),
            "bounds": np.empty((0, 2, 3), dtype=float),
        }
    }

    # should not raise
    a.__check_chunks__()

    # sanity: shapes consistent
    ch = a.chunks[0]
    assert int(ch["dblocks"]) == 0
    assert np.asarray(ch["levels"]).shape == (0,)
    assert np.asarray(ch["coords"]).shape == (0, 3)
    assert np.asarray(ch["bounds"]).shape == (0, 2, 3)

