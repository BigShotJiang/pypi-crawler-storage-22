# tests/test_compression.py
import pytest

from amunpy.compression import decompress, CompressionError


def _payload_512() -> bytes:
    # Deterministic 512-byte sequence: 0..255 repeated twice
    return bytes(range(256)) + bytes(range(256))


def test_decompress_none_is_noop():
    b = _payload_512()
    assert decompress(b, None) == b
    assert decompress(b, "none") == b
    assert decompress(b, "") == b
    assert decompress(b, "  NONE  ") == b


def test_decompress_unknown_raises():
    with pytest.raises(CompressionError):
        decompress(b"x", "unknown")


def test_decompress_lzma_roundtrip():
    import lzma

    raw = _payload_512()
    comp = lzma.compress(raw)
    out = decompress(comp, "lzma")
    assert out == raw


def test_decompress_zstd_roundtrip():
    zstd = pytest.importorskip("zstandard")

    raw = _payload_512()
    cctx = zstd.ZstdCompressor()
    comp = cctx.compress(raw)

    out = decompress(comp, "zstd")
    assert out == raw

    # Optional: ensure alias works if you support it
    out2 = decompress(comp, "zstandard")
    assert out2 == raw


def test_decompress_lz4_roundtrip():
    lz4f = pytest.importorskip("lz4.frame")

    raw = _payload_512()
    comp = lz4f.compress(raw)

    out = decompress(comp, "lz4")
    assert out == raw
