import pytest

from amunpy.amun import Amun
from amunpy.exceptions import AmunPyVariableError


class FakeAmun(Amun):
    def __init__(self):
        self.path = "fake"
        self.dataformat = "fake"
        self.initialized = True

        # alias catalog (full names -> 4-char ids)
        self.variables = {"density": "dens"}

        # raw snapshot ids
        self.raw_variables = {"dens": "dens"}

    def __read_binary_data__(self, *args, **kwargs):
        raise RuntimeError("not used")


def test_resolve_dataset_id_from_alias():
    a = FakeAmun()
    assert a.__resolve_dataset_id__("density") == "dens"


def test_resolve_dataset_id_from_raw():
    a = FakeAmun()
    assert a.__resolve_dataset_id__("dens") == "dens"


def test_resolve_dataset_id_unknown_raises():
    a = FakeAmun()
    with pytest.raises(AmunPyVariableError):
        a.__resolve_dataset_id__("not_a_dataset")

