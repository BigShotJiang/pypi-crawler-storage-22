import pytest
from amunpy.digests import verify_digest, compute_digest, DigestError

def test_verify_digest_passes():
    data = b"hello world"
    expected = compute_digest(data, "xxh64")
    verify_digest(data=data, expected=expected, hash_type="xxh64", policy="raise")

def test_verify_digest_raises_on_mismatch():
    data = b"hello world"
    with pytest.raises(DigestError):
        verify_digest(data=data, expected="0"*16, hash_type="xxh64", policy="raise")

def test_verify_digest_ignore():
    data = b"hello world"
    verify_digest(data=data, expected="0"*16, hash_type="xxh64", policy="ignore")
