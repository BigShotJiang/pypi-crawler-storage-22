# Changelog

## 0.4.2 (2026-02-16)

Full Changelog: [v0.4.1...v0.4.2](https://github.com/AnagramaGames/anagrama-python/compare/v0.4.1...v0.4.2)

## 0.4.1 (2026-02-13)

Full Changelog: [v0.4.0...v0.4.1](https://github.com/AnagramaGames/anagrama-python/compare/v0.4.0...v0.4.1)

### Chores

* format all `api.md` files ([6c3be10](https://github.com/AnagramaGames/anagrama-python/commit/6c3be10499cababbd78e1c1c21a46327f877558d))
* **internal:** fix lint error on Python 3.14 ([eb28362](https://github.com/AnagramaGames/anagrama-python/commit/eb28362d6ded08d9447c202dd1f3c6c9f010b5be))

## 0.4.0 (2026-02-09)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/AnagramaGames/anagrama-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([9b02a1f](https://github.com/AnagramaGames/anagrama-python/commit/9b02a1f10c6dde83ea6c4b6759984220ba9c47e0))

## 0.3.0 (2026-02-09)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/AnagramaGames/anagrama-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([c6568fa](https://github.com/AnagramaGames/anagrama-python/commit/c6568fa3ab078c6057937d58f2eecee2c24f49e3))
* **api:** api update ([77f37c0](https://github.com/AnagramaGames/anagrama-python/commit/77f37c07532c62b5b0c52240c06725b074970489))

## 0.2.0 (2026-02-09)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/AnagramaGames/anagrama-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([bfcc3aa](https://github.com/AnagramaGames/anagrama-python/commit/bfcc3aa704709de1a28fb35d26c38b4d3fcafe80))
* **api:** api update ([eb3d47f](https://github.com/AnagramaGames/anagrama-python/commit/eb3d47febf3883f47056f4737a4e28be5f10d875))
* **api:** api update ([3b42669](https://github.com/AnagramaGames/anagrama-python/commit/3b42669af23d61d20bf565e30be80db8c5c4a497))


### Chores

* update SDK settings ([49a6597](https://github.com/AnagramaGames/anagrama-python/commit/49a6597af7d81618cc69a48890dc8faf009acdf8))
* update SDK settings ([1b23462](https://github.com/AnagramaGames/anagrama-python/commit/1b23462ed8d2ec4eb6ddde9107e45f87d2529754))
* update SDK settings ([e249fbd](https://github.com/AnagramaGames/anagrama-python/commit/e249fbd0da4eba984a92e83ea8a8e4243d034e8f))
* update SDK settings ([d767fa1](https://github.com/AnagramaGames/anagrama-python/commit/d767fa1f868f2aede6521a43080ee66e9519675d))
* update SDK settings ([4aafab5](https://github.com/AnagramaGames/anagrama-python/commit/4aafab5ae22a0e84b5b7f56ad384ad7f17b923da))

## 0.1.0 (2026-02-09)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/AnagramaGames/anagrama-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([e3a84c4](https://github.com/AnagramaGames/anagrama-python/commit/e3a84c4241a14910c8e6f8910fc1ab4ceacd09c0))


### Chores

* update SDK settings ([3fae6d0](https://github.com/AnagramaGames/anagrama-python/commit/3fae6d0079635cb2db9cb5238ed26998d125bffe))
* update SDK settings ([44c4d82](https://github.com/AnagramaGames/anagrama-python/commit/44c4d8209669750aa8e171fef96d8dd28319c555))
* update SDK settings ([0efae2d](https://github.com/AnagramaGames/anagrama-python/commit/0efae2d484f53bef635b7040f1bbaf0ae6495be5))
* update SDK settings ([70785ae](https://github.com/AnagramaGames/anagrama-python/commit/70785ae89d9e0a837285a77bbc16c30b2c1db569))
