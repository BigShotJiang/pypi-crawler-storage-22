# Words

Types:

```python
from anagrama_sdk.types import WordGetDailyResponse, WordGetRandomResponse
```

Methods:

- <code title="get /v1/words/daily">client.words.<a href="./src/anagrama_sdk/resources/words.py">get_daily</a>() -> <a href="./src/anagrama_sdk/types/word_get_daily_response.py">WordGetDailyResponse</a></code>
- <code title="get /v1/words/random">client.words.<a href="./src/anagrama_sdk/resources/words.py">get_random</a>(\*\*<a href="src/anagrama_sdk/types/word_get_random_params.py">params</a>) -> <a href="./src/anagrama_sdk/types/word_get_random_response.py">WordGetRandomResponse</a></code>

# Wordsets

Types:

```python
from anagrama_sdk.types import WordsetResponse, WordsetWord
```

Methods:

- <code title="get /v1/wordsets/{wordsetId}">client.wordsets.<a href="./src/anagrama_sdk/resources/wordsets.py">retrieve</a>(wordset_id, \*\*<a href="src/anagrama_sdk/types/wordset_retrieve_params.py">params</a>) -> <a href="./src/anagrama_sdk/types/wordset_response.py">WordsetResponse</a></code>

# Cli

## Auth

Types:

```python
from anagrama_sdk.types.cli import AuthCompleteResponse, AuthPollResponse, AuthStartResponse
```

Methods:

- <code title="post /cli/auth/complete">client.cli.auth.<a href="./src/anagrama_sdk/resources/cli/auth.py">complete</a>(\*\*<a href="src/anagrama_sdk/types/cli/auth_complete_params.py">params</a>) -> <a href="./src/anagrama_sdk/types/cli/auth_complete_response.py">AuthCompleteResponse</a></code>
- <code title="post /cli/auth/poll">client.cli.auth.<a href="./src/anagrama_sdk/resources/cli/auth.py">poll</a>(\*\*<a href="src/anagrama_sdk/types/cli/auth_poll_params.py">params</a>) -> <a href="./src/anagrama_sdk/types/cli/auth_poll_response.py">AuthPollResponse</a></code>
- <code title="post /cli/auth/start">client.cli.auth.<a href="./src/anagrama_sdk/resources/cli/auth.py">start</a>(\*\*<a href="src/anagrama_sdk/types/cli/auth_start_params.py">params</a>) -> <a href="./src/anagrama_sdk/types/cli/auth_start_response.py">AuthStartResponse</a></code>
