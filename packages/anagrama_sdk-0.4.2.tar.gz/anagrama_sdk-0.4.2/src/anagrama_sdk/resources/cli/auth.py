# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.cli import auth_poll_params, auth_start_params, auth_complete_params
from ..._base_client import make_request_options
from ...types.cli.auth_poll_response import AuthPollResponse
from ...types.cli.auth_start_response import AuthStartResponse
from ...types.cli.auth_complete_response import AuthCompleteResponse

__all__ = ["AuthResource", "AsyncAuthResource"]


class AuthResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AuthResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#accessing-raw-response-data-eg-headers
        """
        return AuthResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AuthResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#with_streaming_response
        """
        return AuthResourceWithStreamingResponse(self)

    def complete(
        self,
        *,
        device_code: str | Omit = omit,
        user_code: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthCompleteResponse:
        """
        Called by the web application after the user approves the CLI authentication
        request. This endpoint requires a valid Anagrama web session (browser
        cookie-based auth) and is not intended for direct SDK use.

        Approves the pending session identified by `deviceCode` or `userCode`, generates
        an API token, and stores it. The CLI can then retrieve the token by polling
        `/cli/auth/poll`.

        Args:
          device_code: The device code from the authentication session.

          user_code: The user code from the authentication session.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/cli/auth/complete",
            body=maybe_transform(
                {
                    "device_code": device_code,
                    "user_code": user_code,
                },
                auth_complete_params.AuthCompleteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthCompleteResponse,
        )

    def poll(
        self,
        *,
        device_code: str | Omit = omit,
        user_code: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthPollResponse:
        """Polls the status of a device-flow authentication session.

        The CLI should call
        this endpoint at the interval specified in the `/cli/auth/start` response until
        it receives a status of `"approved"` with a token.

        The token is returned exactly once -- if the session has already been consumed
        by a previous successful poll, a `409` status is returned.

        Rate limited to 30 requests per minute per IP address.

        Args:
          device_code: The device code returned from `/cli/auth/start`.

          user_code: The user code returned from `/cli/auth/start`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Authorization": omit, **(extra_headers or {})}
        return self._post(
            "/cli/auth/poll",
            body=maybe_transform(
                {
                    "device_code": device_code,
                    "user_code": user_code,
                },
                auth_poll_params.AuthPollParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthPollResponse,
        )

    def start(
        self,
        *,
        client_name: str | Omit = omit,
        label: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthStartResponse:
        """Initiates a device-flow authentication session.

        Returns a device code, a
        human-readable user code, and a verification URL. The CLI should display the
        verification URL and user code to the user, then poll `/cli/auth/poll` until the
        session is approved.

        Rate limited to 10 requests per minute per IP address.

        Args:
          client_name: The name of the CLI client application (e.g., "anagrama-cli").

          label: A human-readable label for this token (e.g., "My Laptop"). HTML special
              characters are stripped. Truncated to 100 characters.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Authorization": omit, **(extra_headers or {})}
        return self._post(
            "/cli/auth/start",
            body=maybe_transform(
                {
                    "client_name": client_name,
                    "label": label,
                },
                auth_start_params.AuthStartParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthStartResponse,
        )


class AsyncAuthResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncAuthResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#accessing-raw-response-data-eg-headers
        """
        return AsyncAuthResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAuthResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#with_streaming_response
        """
        return AsyncAuthResourceWithStreamingResponse(self)

    async def complete(
        self,
        *,
        device_code: str | Omit = omit,
        user_code: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthCompleteResponse:
        """
        Called by the web application after the user approves the CLI authentication
        request. This endpoint requires a valid Anagrama web session (browser
        cookie-based auth) and is not intended for direct SDK use.

        Approves the pending session identified by `deviceCode` or `userCode`, generates
        an API token, and stores it. The CLI can then retrieve the token by polling
        `/cli/auth/poll`.

        Args:
          device_code: The device code from the authentication session.

          user_code: The user code from the authentication session.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/cli/auth/complete",
            body=await async_maybe_transform(
                {
                    "device_code": device_code,
                    "user_code": user_code,
                },
                auth_complete_params.AuthCompleteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthCompleteResponse,
        )

    async def poll(
        self,
        *,
        device_code: str | Omit = omit,
        user_code: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthPollResponse:
        """Polls the status of a device-flow authentication session.

        The CLI should call
        this endpoint at the interval specified in the `/cli/auth/start` response until
        it receives a status of `"approved"` with a token.

        The token is returned exactly once -- if the session has already been consumed
        by a previous successful poll, a `409` status is returned.

        Rate limited to 30 requests per minute per IP address.

        Args:
          device_code: The device code returned from `/cli/auth/start`.

          user_code: The user code returned from `/cli/auth/start`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Authorization": omit, **(extra_headers or {})}
        return await self._post(
            "/cli/auth/poll",
            body=await async_maybe_transform(
                {
                    "device_code": device_code,
                    "user_code": user_code,
                },
                auth_poll_params.AuthPollParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthPollResponse,
        )

    async def start(
        self,
        *,
        client_name: str | Omit = omit,
        label: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthStartResponse:
        """Initiates a device-flow authentication session.

        Returns a device code, a
        human-readable user code, and a verification URL. The CLI should display the
        verification URL and user code to the user, then poll `/cli/auth/poll` until the
        session is approved.

        Rate limited to 10 requests per minute per IP address.

        Args:
          client_name: The name of the CLI client application (e.g., "anagrama-cli").

          label: A human-readable label for this token (e.g., "My Laptop"). HTML special
              characters are stripped. Truncated to 100 characters.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Authorization": omit, **(extra_headers or {})}
        return await self._post(
            "/cli/auth/start",
            body=await async_maybe_transform(
                {
                    "client_name": client_name,
                    "label": label,
                },
                auth_start_params.AuthStartParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthStartResponse,
        )


class AuthResourceWithRawResponse:
    def __init__(self, auth: AuthResource) -> None:
        self._auth = auth

        self.complete = to_raw_response_wrapper(
            auth.complete,
        )
        self.poll = to_raw_response_wrapper(
            auth.poll,
        )
        self.start = to_raw_response_wrapper(
            auth.start,
        )


class AsyncAuthResourceWithRawResponse:
    def __init__(self, auth: AsyncAuthResource) -> None:
        self._auth = auth

        self.complete = async_to_raw_response_wrapper(
            auth.complete,
        )
        self.poll = async_to_raw_response_wrapper(
            auth.poll,
        )
        self.start = async_to_raw_response_wrapper(
            auth.start,
        )


class AuthResourceWithStreamingResponse:
    def __init__(self, auth: AuthResource) -> None:
        self._auth = auth

        self.complete = to_streamed_response_wrapper(
            auth.complete,
        )
        self.poll = to_streamed_response_wrapper(
            auth.poll,
        )
        self.start = to_streamed_response_wrapper(
            auth.start,
        )


class AsyncAuthResourceWithStreamingResponse:
    def __init__(self, auth: AsyncAuthResource) -> None:
        self._auth = auth

        self.complete = async_to_streamed_response_wrapper(
            auth.complete,
        )
        self.poll = async_to_streamed_response_wrapper(
            auth.poll,
        )
        self.start = async_to_streamed_response_wrapper(
            auth.start,
        )
