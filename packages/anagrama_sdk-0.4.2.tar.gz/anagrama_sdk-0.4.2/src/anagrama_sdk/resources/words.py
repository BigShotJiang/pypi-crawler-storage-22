# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import word_get_random_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.word_get_daily_response import WordGetDailyResponse
from ..types.word_get_random_response import WordGetRandomResponse

__all__ = ["WordsResource", "AsyncWordsResource"]


class WordsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> WordsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#accessing-raw-response-data-eg-headers
        """
        return WordsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WordsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#with_streaming_response
        """
        return WordsResourceWithStreamingResponse(self)

    def get_daily(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WordGetDailyResponse:
        """
        Returns a deterministic daily word that is the same for all users on a given
        calendar date (UTC). The word is selected from puzzle-quality words of 5-6
        characters in length using a seeded random algorithm. Requires a valid API key
        as a Bearer token. Subject to daily rate limiting (1,000 requests/day).
        """
        return self._get(
            "/v1/words/daily",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WordGetDailyResponse,
        )

    def get_random(
        self,
        *,
        count: int | Omit = omit,
        max_length: int | Omit = omit,
        min_length: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WordGetRandomResponse:
        """Returns one or more random words from the Anagrama word pool.

        Words can be
        filtered by length. Requires a valid API key as a Bearer token. Subject to daily
        rate limiting (1,000 requests/day).

        Args:
          count: Number of random words to return. Clamped to the range [1, 10]. Defaults to 1.

          max_length: Maximum word length (inclusive). Clamped to the range [3, 15]. Defaults to 15.
              If minLength > maxLength, they are swapped automatically.

          min_length: Minimum word length (inclusive). Clamped to the range [3, 15]. Defaults to 3.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/words/random",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "count": count,
                        "max_length": max_length,
                        "min_length": min_length,
                    },
                    word_get_random_params.WordGetRandomParams,
                ),
            ),
            cast_to=WordGetRandomResponse,
        )


class AsyncWordsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncWordsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWordsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWordsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#with_streaming_response
        """
        return AsyncWordsResourceWithStreamingResponse(self)

    async def get_daily(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WordGetDailyResponse:
        """
        Returns a deterministic daily word that is the same for all users on a given
        calendar date (UTC). The word is selected from puzzle-quality words of 5-6
        characters in length using a seeded random algorithm. Requires a valid API key
        as a Bearer token. Subject to daily rate limiting (1,000 requests/day).
        """
        return await self._get(
            "/v1/words/daily",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WordGetDailyResponse,
        )

    async def get_random(
        self,
        *,
        count: int | Omit = omit,
        max_length: int | Omit = omit,
        min_length: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WordGetRandomResponse:
        """Returns one or more random words from the Anagrama word pool.

        Words can be
        filtered by length. Requires a valid API key as a Bearer token. Subject to daily
        rate limiting (1,000 requests/day).

        Args:
          count: Number of random words to return. Clamped to the range [1, 10]. Defaults to 1.

          max_length: Maximum word length (inclusive). Clamped to the range [3, 15]. Defaults to 15.
              If minLength > maxLength, they are swapped automatically.

          min_length: Minimum word length (inclusive). Clamped to the range [3, 15]. Defaults to 3.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/words/random",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "count": count,
                        "max_length": max_length,
                        "min_length": min_length,
                    },
                    word_get_random_params.WordGetRandomParams,
                ),
            ),
            cast_to=WordGetRandomResponse,
        )


class WordsResourceWithRawResponse:
    def __init__(self, words: WordsResource) -> None:
        self._words = words

        self.get_daily = to_raw_response_wrapper(
            words.get_daily,
        )
        self.get_random = to_raw_response_wrapper(
            words.get_random,
        )


class AsyncWordsResourceWithRawResponse:
    def __init__(self, words: AsyncWordsResource) -> None:
        self._words = words

        self.get_daily = async_to_raw_response_wrapper(
            words.get_daily,
        )
        self.get_random = async_to_raw_response_wrapper(
            words.get_random,
        )


class WordsResourceWithStreamingResponse:
    def __init__(self, words: WordsResource) -> None:
        self._words = words

        self.get_daily = to_streamed_response_wrapper(
            words.get_daily,
        )
        self.get_random = to_streamed_response_wrapper(
            words.get_random,
        )


class AsyncWordsResourceWithStreamingResponse:
    def __init__(self, words: AsyncWordsResource) -> None:
        self._words = words

        self.get_daily = async_to_streamed_response_wrapper(
            words.get_daily,
        )
        self.get_random = async_to_streamed_response_wrapper(
            words.get_random,
        )
