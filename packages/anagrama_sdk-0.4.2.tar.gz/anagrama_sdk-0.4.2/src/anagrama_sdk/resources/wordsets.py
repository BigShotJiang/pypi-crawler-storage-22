# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import wordset_retrieve_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.wordset_response import WordsetResponse

__all__ = ["WordsetsResource", "AsyncWordsetsResource"]


class WordsetsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> WordsetsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#accessing-raw-response-data-eg-headers
        """
        return WordsetsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WordsetsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#with_streaming_response
        """
        return WordsetsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        wordset_id: str,
        *,
        category: str | Omit = omit,
        limit: int | Omit = omit,
        max_length: int | Omit = omit,
        min_length: int | Omit = omit,
        random: Literal["true", "false"] | Omit = omit,
        scramble: Literal["true", "false"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WordsetResponse:
        """Retrieves a user-created wordset by its ID.

        Public wordsets (`isPublic: true`)
        can be accessed without authentication. Private wordsets require the creator's
        API key passed as a Bearer token.

        Words in the response can be filtered, shuffled, limited, and optionally
        scrambled using query parameters. Each request increments the wordset's hit
        counter for analytics.

        Args:
          category: Filter words by category (case-insensitive match). Only words with a matching
              `category` field are returned.

          limit: Maximum number of words to return. Applied after filtering and optional
              shuffling.

          max_length: Filter words to only include those with at most this many characters.

          min_length: Filter words to only include those with at least this many characters.

          random: When set to `"true"`, shuffles the word list into a random order before applying
              the limit.

          scramble: When set to `"true"`, scrambles the letters of each word in the response
              (Fisher-Yates shuffle on characters). Useful for building anagram puzzles.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not wordset_id:
            raise ValueError(f"Expected a non-empty value for `wordset_id` but received {wordset_id!r}")
        return self._get(
            f"/v1/wordsets/{wordset_id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "category": category,
                        "limit": limit,
                        "max_length": max_length,
                        "min_length": min_length,
                        "random": random,
                        "scramble": scramble,
                    },
                    wordset_retrieve_params.WordsetRetrieveParams,
                ),
            ),
            cast_to=WordsetResponse,
        )


class AsyncWordsetsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncWordsetsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWordsetsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWordsetsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/AnagramaGames/anagrama-python#with_streaming_response
        """
        return AsyncWordsetsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        wordset_id: str,
        *,
        category: str | Omit = omit,
        limit: int | Omit = omit,
        max_length: int | Omit = omit,
        min_length: int | Omit = omit,
        random: Literal["true", "false"] | Omit = omit,
        scramble: Literal["true", "false"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WordsetResponse:
        """Retrieves a user-created wordset by its ID.

        Public wordsets (`isPublic: true`)
        can be accessed without authentication. Private wordsets require the creator's
        API key passed as a Bearer token.

        Words in the response can be filtered, shuffled, limited, and optionally
        scrambled using query parameters. Each request increments the wordset's hit
        counter for analytics.

        Args:
          category: Filter words by category (case-insensitive match). Only words with a matching
              `category` field are returned.

          limit: Maximum number of words to return. Applied after filtering and optional
              shuffling.

          max_length: Filter words to only include those with at most this many characters.

          min_length: Filter words to only include those with at least this many characters.

          random: When set to `"true"`, shuffles the word list into a random order before applying
              the limit.

          scramble: When set to `"true"`, scrambles the letters of each word in the response
              (Fisher-Yates shuffle on characters). Useful for building anagram puzzles.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not wordset_id:
            raise ValueError(f"Expected a non-empty value for `wordset_id` but received {wordset_id!r}")
        return await self._get(
            f"/v1/wordsets/{wordset_id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "category": category,
                        "limit": limit,
                        "max_length": max_length,
                        "min_length": min_length,
                        "random": random,
                        "scramble": scramble,
                    },
                    wordset_retrieve_params.WordsetRetrieveParams,
                ),
            ),
            cast_to=WordsetResponse,
        )


class WordsetsResourceWithRawResponse:
    def __init__(self, wordsets: WordsetsResource) -> None:
        self._wordsets = wordsets

        self.retrieve = to_raw_response_wrapper(
            wordsets.retrieve,
        )


class AsyncWordsetsResourceWithRawResponse:
    def __init__(self, wordsets: AsyncWordsetsResource) -> None:
        self._wordsets = wordsets

        self.retrieve = async_to_raw_response_wrapper(
            wordsets.retrieve,
        )


class WordsetsResourceWithStreamingResponse:
    def __init__(self, wordsets: WordsetsResource) -> None:
        self._wordsets = wordsets

        self.retrieve = to_streamed_response_wrapper(
            wordsets.retrieve,
        )


class AsyncWordsetsResourceWithStreamingResponse:
    def __init__(self, wordsets: AsyncWordsetsResource) -> None:
        self._wordsets = wordsets

        self.retrieve = async_to_streamed_response_wrapper(
            wordsets.retrieve,
        )
