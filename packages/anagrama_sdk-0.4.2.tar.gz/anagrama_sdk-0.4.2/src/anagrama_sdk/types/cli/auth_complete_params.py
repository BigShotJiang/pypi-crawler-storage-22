# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["AuthCompleteParams"]


class AuthCompleteParams(TypedDict, total=False):
    device_code: str
    """The device code from the authentication session."""

    user_code: str
    """The user code from the authentication session."""
