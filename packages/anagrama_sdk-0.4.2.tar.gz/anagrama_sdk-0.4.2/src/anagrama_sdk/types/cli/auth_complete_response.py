# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["AuthCompleteResponse"]


class AuthCompleteResponse(BaseModel):
    ok: bool
    """Always `true` on success."""

    status: Literal["approved"]
    """The resulting session status."""
