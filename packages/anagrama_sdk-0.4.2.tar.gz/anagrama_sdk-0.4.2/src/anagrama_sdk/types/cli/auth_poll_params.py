# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["AuthPollParams"]


class AuthPollParams(TypedDict, total=False):
    device_code: str
    """The device code returned from `/cli/auth/start`."""

    user_code: str
    """The user code returned from `/cli/auth/start`."""
