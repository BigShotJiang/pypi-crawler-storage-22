# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["AuthPollResponse", "User"]


class User(BaseModel):
    """Basic profile information for the authenticated user."""

    display_name: str = FieldInfo(alias="displayName")
    """The user's display name.

    Falls back to username, first name, last name, or "Player".
    """

    user_id: str = FieldInfo(alias="userId")
    """The user's unique identifier."""

    username: Optional[str] = None
    """The user's username, or null if not set."""


class AuthPollResponse(BaseModel):
    token: str
    """The API token (prefixed with `cli_`).

    Store this securely and use it as a Bearer token for authenticated API calls.
    """

    status: Literal["approved"]
    """The session status. Always `"approved"` for a 200 response."""

    user: User
    """Basic profile information for the authenticated user."""
