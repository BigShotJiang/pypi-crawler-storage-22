# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["AuthStartParams"]


class AuthStartParams(TypedDict, total=False):
    client_name: Annotated[str, PropertyInfo(alias="clientName")]
    """The name of the CLI client application (e.g., "anagrama-cli")."""

    label: str
    """A human-readable label for this token (e.g., "My Laptop").

    HTML special characters are stripped. Truncated to 100 characters.
    """
