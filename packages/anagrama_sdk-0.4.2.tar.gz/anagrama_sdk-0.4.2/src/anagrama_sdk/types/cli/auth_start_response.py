# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["AuthStartResponse"]


class AuthStartResponse(BaseModel):
    device_code: str
    """Unique device code for this authentication session.

    Used when polling for approval.
    """

    expires_in: int
    """Number of seconds until this authentication session expires.

    Default is 900 (15 minutes).
    """

    interval: int
    """Minimum number of seconds the CLI should wait between poll requests.

    Default is 3.
    """

    user_code: str
    """A short, human-readable code displayed to the user for verification."""

    verification_url: str
    """The full URL the user should visit to authorize the CLI.

    Includes the device_code and user_code as query parameters.
    """
