# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import datetime

from .._models import BaseModel

__all__ = ["WordGetDailyResponse"]


class WordGetDailyResponse(BaseModel):
    date: datetime.date
    """The UTC date (YYYY-MM-DD) for which this word was selected."""

    word: str
    """The daily word. Always 5-6 characters long."""
