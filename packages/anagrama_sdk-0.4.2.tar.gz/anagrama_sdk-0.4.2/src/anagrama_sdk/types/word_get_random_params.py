# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["WordGetRandomParams"]


class WordGetRandomParams(TypedDict, total=False):
    count: int
    """Number of random words to return. Clamped to the range [1, 10]. Defaults to 1."""

    max_length: Annotated[int, PropertyInfo(alias="maxLength")]
    """Maximum word length (inclusive).

    Clamped to the range [3, 15]. Defaults to 15. If minLength > maxLength, they are
    swapped automatically.
    """

    min_length: Annotated[int, PropertyInfo(alias="minLength")]
    """Minimum word length (inclusive). Clamped to the range [3, 15]. Defaults to 3."""
