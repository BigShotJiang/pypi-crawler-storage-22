# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel

__all__ = ["WordGetRandomResponse"]


class WordGetRandomResponse(BaseModel):
    count: int
    """The number of words returned. May be 0 if no words match the length criteria."""

    words: List[str]
    """Array of random words matching the length criteria."""
