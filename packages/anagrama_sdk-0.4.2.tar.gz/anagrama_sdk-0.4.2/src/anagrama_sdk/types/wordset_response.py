# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .wordset_word import WordsetWord

__all__ = ["WordsetResponse"]


class WordsetResponse(BaseModel):
    """A wordset with its words, optionally filtered and/or scrambled."""

    created_at: datetime = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the wordset was created."""

    description: str
    """A description of the wordset."""

    is_public: bool = FieldInfo(alias="isPublic")
    """Whether the wordset is publicly accessible."""

    name: str
    """The name of the wordset."""

    total_word_count: int = FieldInfo(alias="totalWordCount")
    """The total number of words in the wordset (before filtering)."""

    word_count: int = FieldInfo(alias="wordCount")
    """The number of words in the `words` array (after filtering)."""

    words: List[WordsetWord]
    """
    The list of words in the wordset, after applying any query filters (minLength,
    maxLength, category, random, limit, scramble).
    """

    wordset_id: str = FieldInfo(alias="wordsetId")
    """The unique wordset identifier."""
