# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["WordsetRetrieveParams"]


class WordsetRetrieveParams(TypedDict, total=False):
    category: str
    """Filter words by category (case-insensitive match).

    Only words with a matching `category` field are returned.
    """

    limit: int
    """Maximum number of words to return.

    Applied after filtering and optional shuffling.
    """

    max_length: Annotated[int, PropertyInfo(alias="maxLength")]
    """Filter words to only include those with at most this many characters."""

    min_length: Annotated[int, PropertyInfo(alias="minLength")]
    """Filter words to only include those with at least this many characters."""

    random: Literal["true", "false"]
    """
    When set to `"true"`, shuffles the word list into a random order before applying
    the limit.
    """

    scramble: Literal["true", "false"]
    """
    When set to `"true"`, scrambles the letters of each word in the response
    (Fisher-Yates shuffle on characters). Useful for building anagram puzzles.
    """
