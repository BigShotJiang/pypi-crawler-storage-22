# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["WordsetWord"]


class WordsetWord(BaseModel):
    """A word entry in a wordset."""

    word: str
    """The word string. If `scramble=true` was requested, the letters are shuffled."""

    category: Optional[str] = None
    """An optional category label for the word (e.g., "animals", "food")."""

    hint: Optional[str] = None
    """An optional hint or clue for the word."""
