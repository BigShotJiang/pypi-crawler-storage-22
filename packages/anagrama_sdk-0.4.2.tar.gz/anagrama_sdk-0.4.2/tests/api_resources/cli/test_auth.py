# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from anagrama_sdk import Anagrama, AsyncAnagrama
from anagrama_sdk.types.cli import (
    AuthPollResponse,
    AuthStartResponse,
    AuthCompleteResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAuth:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_complete(self, client: Anagrama) -> None:
        auth = client.cli.auth.complete()
        assert_matches_type(AuthCompleteResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_complete_with_all_params(self, client: Anagrama) -> None:
        auth = client.cli.auth.complete(
            device_code="dvc_a1b2c3d4e5f6",
            user_code="ABCD-1234",
        )
        assert_matches_type(AuthCompleteResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_complete(self, client: Anagrama) -> None:
        response = client.cli.auth.with_raw_response.complete()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(AuthCompleteResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_complete(self, client: Anagrama) -> None:
        with client.cli.auth.with_streaming_response.complete() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(AuthCompleteResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_poll(self, client: Anagrama) -> None:
        auth = client.cli.auth.poll()
        assert_matches_type(AuthPollResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_poll_with_all_params(self, client: Anagrama) -> None:
        auth = client.cli.auth.poll(
            device_code="dvc_a1b2c3d4e5f6",
            user_code="user_code",
        )
        assert_matches_type(AuthPollResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_poll(self, client: Anagrama) -> None:
        response = client.cli.auth.with_raw_response.poll()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(AuthPollResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_poll(self, client: Anagrama) -> None:
        with client.cli.auth.with_streaming_response.poll() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(AuthPollResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_start(self, client: Anagrama) -> None:
        auth = client.cli.auth.start()
        assert_matches_type(AuthStartResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_start_with_all_params(self, client: Anagrama) -> None:
        auth = client.cli.auth.start(
            client_name="anagrama-cli",
            label="My MacBook Pro",
        )
        assert_matches_type(AuthStartResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_start(self, client: Anagrama) -> None:
        response = client.cli.auth.with_raw_response.start()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(AuthStartResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_start(self, client: Anagrama) -> None:
        with client.cli.auth.with_streaming_response.start() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(AuthStartResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAuth:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_complete(self, async_client: AsyncAnagrama) -> None:
        auth = await async_client.cli.auth.complete()
        assert_matches_type(AuthCompleteResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_complete_with_all_params(self, async_client: AsyncAnagrama) -> None:
        auth = await async_client.cli.auth.complete(
            device_code="dvc_a1b2c3d4e5f6",
            user_code="ABCD-1234",
        )
        assert_matches_type(AuthCompleteResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_complete(self, async_client: AsyncAnagrama) -> None:
        response = await async_client.cli.auth.with_raw_response.complete()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(AuthCompleteResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_complete(self, async_client: AsyncAnagrama) -> None:
        async with async_client.cli.auth.with_streaming_response.complete() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(AuthCompleteResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_poll(self, async_client: AsyncAnagrama) -> None:
        auth = await async_client.cli.auth.poll()
        assert_matches_type(AuthPollResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_poll_with_all_params(self, async_client: AsyncAnagrama) -> None:
        auth = await async_client.cli.auth.poll(
            device_code="dvc_a1b2c3d4e5f6",
            user_code="user_code",
        )
        assert_matches_type(AuthPollResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_poll(self, async_client: AsyncAnagrama) -> None:
        response = await async_client.cli.auth.with_raw_response.poll()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(AuthPollResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_poll(self, async_client: AsyncAnagrama) -> None:
        async with async_client.cli.auth.with_streaming_response.poll() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(AuthPollResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_start(self, async_client: AsyncAnagrama) -> None:
        auth = await async_client.cli.auth.start()
        assert_matches_type(AuthStartResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_start_with_all_params(self, async_client: AsyncAnagrama) -> None:
        auth = await async_client.cli.auth.start(
            client_name="anagrama-cli",
            label="My MacBook Pro",
        )
        assert_matches_type(AuthStartResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_start(self, async_client: AsyncAnagrama) -> None:
        response = await async_client.cli.auth.with_raw_response.start()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(AuthStartResponse, auth, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_start(self, async_client: AsyncAnagrama) -> None:
        async with async_client.cli.auth.with_streaming_response.start() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(AuthStartResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True
