# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from anagrama_sdk import Anagrama, AsyncAnagrama
from anagrama_sdk.types import WordGetDailyResponse, WordGetRandomResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestWords:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_daily(self, client: Anagrama) -> None:
        word = client.words.get_daily()
        assert_matches_type(WordGetDailyResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_daily(self, client: Anagrama) -> None:
        response = client.words.with_raw_response.get_daily()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        word = response.parse()
        assert_matches_type(WordGetDailyResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_daily(self, client: Anagrama) -> None:
        with client.words.with_streaming_response.get_daily() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            word = response.parse()
            assert_matches_type(WordGetDailyResponse, word, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_random(self, client: Anagrama) -> None:
        word = client.words.get_random()
        assert_matches_type(WordGetRandomResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_random_with_all_params(self, client: Anagrama) -> None:
        word = client.words.get_random(
            count=1,
            max_length=3,
            min_length=3,
        )
        assert_matches_type(WordGetRandomResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_random(self, client: Anagrama) -> None:
        response = client.words.with_raw_response.get_random()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        word = response.parse()
        assert_matches_type(WordGetRandomResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_random(self, client: Anagrama) -> None:
        with client.words.with_streaming_response.get_random() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            word = response.parse()
            assert_matches_type(WordGetRandomResponse, word, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncWords:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_daily(self, async_client: AsyncAnagrama) -> None:
        word = await async_client.words.get_daily()
        assert_matches_type(WordGetDailyResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_daily(self, async_client: AsyncAnagrama) -> None:
        response = await async_client.words.with_raw_response.get_daily()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        word = await response.parse()
        assert_matches_type(WordGetDailyResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_daily(self, async_client: AsyncAnagrama) -> None:
        async with async_client.words.with_streaming_response.get_daily() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            word = await response.parse()
            assert_matches_type(WordGetDailyResponse, word, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_random(self, async_client: AsyncAnagrama) -> None:
        word = await async_client.words.get_random()
        assert_matches_type(WordGetRandomResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_random_with_all_params(self, async_client: AsyncAnagrama) -> None:
        word = await async_client.words.get_random(
            count=1,
            max_length=3,
            min_length=3,
        )
        assert_matches_type(WordGetRandomResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_random(self, async_client: AsyncAnagrama) -> None:
        response = await async_client.words.with_raw_response.get_random()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        word = await response.parse()
        assert_matches_type(WordGetRandomResponse, word, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_random(self, async_client: AsyncAnagrama) -> None:
        async with async_client.words.with_streaming_response.get_random() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            word = await response.parse()
            assert_matches_type(WordGetRandomResponse, word, path=["response"])

        assert cast(Any, response.is_closed) is True
