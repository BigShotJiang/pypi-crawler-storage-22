# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from anagrama_sdk import Anagrama, AsyncAnagrama
from anagrama_sdk.types import WordsetResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestWordsets:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Anagrama) -> None:
        wordset = client.wordsets.retrieve(
            wordset_id="ws__6fxAv1b",
        )
        assert_matches_type(WordsetResponse, wordset, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_with_all_params(self, client: Anagrama) -> None:
        wordset = client.wordsets.retrieve(
            wordset_id="ws__6fxAv1b",
            category="category",
            limit=1,
            max_length=1,
            min_length=1,
            random="true",
            scramble="true",
        )
        assert_matches_type(WordsetResponse, wordset, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Anagrama) -> None:
        response = client.wordsets.with_raw_response.retrieve(
            wordset_id="ws__6fxAv1b",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wordset = response.parse()
        assert_matches_type(WordsetResponse, wordset, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Anagrama) -> None:
        with client.wordsets.with_streaming_response.retrieve(
            wordset_id="ws__6fxAv1b",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wordset = response.parse()
            assert_matches_type(WordsetResponse, wordset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Anagrama) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `wordset_id` but received ''"):
            client.wordsets.with_raw_response.retrieve(
                wordset_id="",
            )


class TestAsyncWordsets:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncAnagrama) -> None:
        wordset = await async_client.wordsets.retrieve(
            wordset_id="ws__6fxAv1b",
        )
        assert_matches_type(WordsetResponse, wordset, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_with_all_params(self, async_client: AsyncAnagrama) -> None:
        wordset = await async_client.wordsets.retrieve(
            wordset_id="ws__6fxAv1b",
            category="category",
            limit=1,
            max_length=1,
            min_length=1,
            random="true",
            scramble="true",
        )
        assert_matches_type(WordsetResponse, wordset, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncAnagrama) -> None:
        response = await async_client.wordsets.with_raw_response.retrieve(
            wordset_id="ws__6fxAv1b",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        wordset = await response.parse()
        assert_matches_type(WordsetResponse, wordset, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncAnagrama) -> None:
        async with async_client.wordsets.with_streaming_response.retrieve(
            wordset_id="ws__6fxAv1b",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            wordset = await response.parse()
            assert_matches_type(WordsetResponse, wordset, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncAnagrama) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `wordset_id` but received ''"):
            await async_client.wordsets.with_raw_response.retrieve(
                wordset_id="",
            )
