# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from .circuit import Circuit, Net, Instance, Subcircuit, Subckt, SubcircuitInstance, CircuitInstance, auto_comment_params
from .devices import (
    nmos, pmos,
    resistor, capacitor, inductor,
    vsource, isource, vpulse, vsin,
    vcvs, vccs, ccvs, cccs,
    diode,
    generic, iprobe
)
from .spectre import generate_spectre
from .testbench import Testbench, SimulatorOptions
from .analysis import Analysis, DC, AC, Transient, Noise, STB
from .save import SaveConfig, SaveOptions
from .command import SpectreCommand
from .batch import SimulationBatch

__all__ = [
    # Core
    "Circuit",
    "Subcircuit",  # Alias for Circuit (backwards compatibility)
    "Subckt",      # Alias for Circuit (SPICE terminology)
    "Net",
    "Instance",
    "SubcircuitInstance",
    "CircuitInstance",  # Alias for SubcircuitInstance
    "auto_comment_params",  # Decorator for automatic parameter comments
    # Testbench
    "Testbench",
    "SimulatorOptions",
    # Analysis
    "Analysis",
    "DC",
    "AC",
    "Transient",
    "Noise",
    "STB",
    # Save
    "SaveConfig",
    "SaveOptions",
    # Command
    "SpectreCommand",
    # Batch
    "SimulationBatch",
    # Devices - MOSFETs
    "nmos",
    "pmos",
    # Devices - Passives
    "resistor",
    "capacitor",
    "inductor",
    # Devices - Sources
    "vsource",
    "isource",
    "vpulse",
    "vsin",
    # Devices - Controlled sources
    "vcvs",
    "vccs",
    "ccvs",
    "cccs",
    # Devices - Other
    "diode",
    "generic",
    "iprobe",
    # Generators
    "generate_spectre",
]

