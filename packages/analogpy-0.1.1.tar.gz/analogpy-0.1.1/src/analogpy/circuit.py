# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import functools
import inspect
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Union, Callable, ClassVar


def _get_assignment_target() -> Optional[str]:
    """
    Try to capture the variable name from the caller's source code.

    This inspects the call stack to find the line where a Circuit is being
    assigned to a variable, and extracts the variable name.

    Returns:
        The variable name if found, None otherwise.

    Note:
        This works for most cases but fails in:
        - REPL/Jupyter (no source file)
        - list.append(Circuit(...)) style calls
        - Complex expressions
    """
    try:
        for frame_info in inspect.stack()[3:]:  # Skip this func, __init__, and immediate caller
            if frame_info.code_context:
                line = frame_info.code_context[0]
                # Skip decorator wrapper internals (e.g., "result = func(*args, **kwargs)")
                if 'func(*args' in line or 'func( *args' in line:
                    continue
                # Match: var_name = func_name( or var_name = Class(
                match = re.match(r'\s*(\w+)\s*=\s*\w+\s*\(', line)
                if match:
                    var_name = match.group(1)
                    # Skip common temporary variable names used in wrappers/frameworks
                    if var_name not in ('result', 'ret', 'rv', 'value', '_', 'code', 'obj', 'item', 'x'):
                        return var_name
    except Exception:
        pass
    return None


@dataclass
class Net:
    name: str


@dataclass
class Instance:
    name: str
    kind: str                 # "mos", "res", "cap", ...
    pins: Dict[str, Net]     # {"d": Net, "g": Net, ...}
    params: Dict[str, float] # {"w": 1e-6, "l": 180e-9}
    model: str = None        # model name (optional)


@dataclass
class VoltageSource:
    name: str       # instance name, e.g., "Vvdd"
    p: Net          # positive terminal
    n: Net          # negative terminal
    dc: float       # DC voltage value


@dataclass
class SubcircuitInstance:
    """Instance of a subcircuit within a parent circuit"""
    name: str                           # instance name, e.g., "X1"
    subcircuit: 'Subcircuit'           # reference to subcircuit definition
    connections: Dict[str, Net]         # port_name -> connected net
    params: Dict[str, any] = field(default_factory=dict)  # parameter values


@dataclass
class _CircuitBase:
    """Internal base class for circuit containers."""
    name: str
    nets: Dict[str, Net] = field(default_factory=dict)
    instances: List[Instance] = field(default_factory=list)
    supplies: List[VoltageSource] = field(default_factory=list)
    subcircuit_instances: List['CircuitInstance'] = field(default_factory=list)

    def net(self, name: str) -> Net:
        if name not in self.nets:
            self.nets[name] = Net(name)
        return self.nets[name]

    def add(self, inst: Instance):
        self.instances.append(inst)
        return inst

    def gnd(self):
        return self.net("0")

    def vdd(self, name="vdd"):
        return self.net(name)

    def vss(self, name="vss"):
        return self.net(name)

    def supply(self, name: str, voltage: float, gnd: str = "0") -> Net:
        p = self.net(name)
        n = self.net(gnd)
        src = VoltageSource(
            name=f"V{name}",
            p=p,
            n=n,
            dc=voltage
        )
        self.supplies.append(src)
        return p

    def instantiate(self, circuit: 'Circuit', instance_name: str,
                    params: Dict[str, any] = None,
                    **port_connections) -> 'CircuitInstance':
        """
        Instantiate a circuit within this circuit.

        Args:
            circuit: The Circuit to instantiate
            instance_name: Name for this instance (e.g., "X1", "X_AMP")
            params: Parameter values for parameterized circuits (optional)
            **port_connections: port_name=net mappings

        Returns:
            CircuitInstance

        Example:
            amp = Circuit("amplifier", ports=["in", "out", "vdd", "gnd"])
            top.instantiate(amp, "X1", in=vin, out=vout, vdd=vdd, gnd=gnd)

            # With parameters (Cadence-compatible):
            oled = Circuit("oled_model", ports=["ANODE", "ELVSS"],
                           parameters=["OLED_size", "OLED_model_D1"])
            top.instantiate(oled, "IOLED1", params={"OLED_size": 938.488},
                            ANODE=v_single, ELVSS=gnd)
        """
        if params is None:
            params = {}
        # Validate all ports are connected
        for port in circuit.ports:
            if port not in port_connections:
                raise ValueError(
                    f"Port '{port}' of circuit '{circuit.name}' not connected "
                    f"in instance '{instance_name}'"
                )

        # Validate no extra connections
        for conn in port_connections:
            if conn not in circuit.ports:
                raise ValueError(
                    f"'{conn}' is not a port of circuit '{circuit.name}'. "
                    f"Available ports: {circuit.ports}"
                )

        # Convert string connections to Net objects
        connections = {}
        for port, net in port_connections.items():
            if isinstance(net, str):
                connections[port] = self.net(net)
            elif isinstance(net, Net):
                connections[port] = net
            else:
                raise TypeError(f"Connection for port '{port}' must be Net or str, got {type(net)}")

        inst = CircuitInstance(
            name=instance_name,
            subcircuit=circuit,
            connections=connections,
            params=params
        )
        self.subcircuit_instances.append(inst)
        return inst


@dataclass
class Circuit(_CircuitBase):
    """
    A reusable circuit block with defined ports.

    This is the primary building block in analogpy. It maps to SPICE/Spectre's
    'subckt' keyword. Use Circuit to define reusable blocks that can be
    instantiated multiple times.

    Circuit names are automatically made unique:
    1. First, tries to capture the Python variable name (e.g., oled_single_blue)
    2. Falls back to auto-incrementing (e.g., oled_model, oled_model_1, oled_model_2)

    Aliases: Subcircuit, Subckt (all equivalent)

    Example:
        # Names are auto-captured from variable names:
        oled_blue = Circuit("oled", ports=["A", "B"])   # name = "oled_blue"
        oled_red = Circuit("oled", ports=["A", "B"])    # name = "oled_red"

        # Or auto-incremented if variable name can't be captured:
        circuits = [Circuit("oled", ports=["A", "B"]) for _ in range(3)]
        # names = "oled", "oled_1", "oled_2"
    """
    ports: List[str] = field(default_factory=list)
    parameters: List[str] = field(default_factory=list)
    comments: List[str] = field(default_factory=list)

    # Class-level counter for auto-incrementing names (not a dataclass field)
    _name_counters: ClassVar[Dict[str, int]] = {}

    def __init__(self, name: str, ports: List[str], parameters: List[str] = None):
        # Hybrid naming strategy:
        # - First use of a base name: use as-is (respect explicit name)
        # - Subsequent uses: try to capture variable name, fall back to counter
        if name in Circuit._name_counters:
            # Name already used - must resolve conflict
            var_name = _get_assignment_target()
            if var_name and var_name != name:
                final_name = var_name
            else:
                Circuit._name_counters[name] += 1
                final_name = f"{name}_{Circuit._name_counters[name]}"
        else:
            # First use of this base name - use as-is
            Circuit._name_counters[name] = 0
            final_name = name

        super().__init__(final_name)
        self.ports = ports
        self.parameters = parameters or []
        self.comments = []
        # Pre-create nets for all ports
        for port in ports:
            self.net(port)

    def comment(self, text: str) -> 'Circuit':
        """Add a comment to this circuit for documentation/traceability."""
        self.comments.append(text)
        return self

    @classmethod
    def reset_name_counters(cls):
        """Reset the name counters. Useful for testing."""
        cls._name_counters.clear()


# Aliases for compatibility and convenience
Subcircuit = Circuit  # Backwards compatibility
Subckt = Circuit      # SPICE terminology


# Also rename SubcircuitInstance to CircuitInstance for consistency
CircuitInstance = SubcircuitInstance


def auto_comment_params(func: Callable[..., Circuit]) -> Callable[..., Circuit]:
    """
    Decorator that automatically adds function arguments as comments to the returned Circuit.

    Use this on factory functions that create Circuit objects. All function arguments
    will be captured and added as comments to the Circuit for traceability.

    Example:
        @auto_comment_params
        def make_oled_circuit(oled_model_d1: str, oled_size: float) -> Circuit:
            oled = Circuit("oled_model", ports=["ANODE", "ELVSS"])
            # ... build circuit ...
            return oled

        # When called:
        circuit = make_oled_circuit(oled_model_d1="model.txt", oled_size=938.488)
        # The circuit will automatically have comments:
        #   oled_model_d1 = model.txt
        #   oled_size = 938.488
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Get function signature to map positional args to parameter names
        sig = inspect.signature(func)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()

        # Call the original function
        result = func(*args, **kwargs)

        # Add comments for all arguments if result is a Circuit
        if isinstance(result, Circuit):
            for param_name, value in bound.arguments.items():
                result.comment(f"{param_name} = {value}")

        return result

    return wrapper
