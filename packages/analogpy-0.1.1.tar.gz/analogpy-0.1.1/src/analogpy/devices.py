# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Device constructors for circuit primitives."""

from typing import Optional, Union
from .circuit import Net, Instance


# =============================================================================
# MOSFETs
# =============================================================================

def nmos(name: str, d: Net, g: Net, s: Net, b: Net,
         w: float, l: float, model: str = "nch",
         nf: int = 1, **params) -> Instance:
    """
    Create an NMOS transistor.

    Args:
        name: Instance name
        d, g, s, b: Drain, gate, source, bulk nets
        w: Width in meters
        l: Length in meters
        model: Model name (default "nch")
        nf: Number of fingers (default 1)
        **params: Additional parameters

    Returns:
        Instance object
    """
    all_params = {"w": w, "l": l}
    if nf > 1:
        all_params["nf"] = nf
    all_params.update(params)

    return Instance(
        name=name,
        kind="nmos",
        model=model,
        pins={"d": d, "g": g, "s": s, "b": b},
        params=all_params
    )


def pmos(name: str, d: Net, g: Net, s: Net, b: Net,
         w: float, l: float, model: str = "pch",
         nf: int = 1, **params) -> Instance:
    """
    Create a PMOS transistor.

    Args:
        name: Instance name
        d, g, s, b: Drain, gate, source, bulk nets
        w: Width in meters
        l: Length in meters
        model: Model name (default "pch")
        nf: Number of fingers (default 1)
        **params: Additional parameters

    Returns:
        Instance object
    """
    all_params = {"w": w, "l": l}
    if nf > 1:
        all_params["nf"] = nf
    all_params.update(params)

    return Instance(
        name=name,
        kind="pmos",
        model=model,
        pins={"d": d, "g": g, "s": s, "b": b},
        params=all_params
    )


# =============================================================================
# Passive Components
# =============================================================================

def resistor(name: str, p: Net, n: Net, r: float,
             model: Optional[str] = None, **params) -> Instance:
    """
    Create a resistor.

    Args:
        name: Instance name
        p: Positive terminal
        n: Negative terminal
        r: Resistance in ohms
        model: Optional model name
        **params: Additional parameters

    Returns:
        Instance object
    """
    all_params = {"r": r}
    all_params.update(params)

    return Instance(
        name=name,
        kind="resistor",
        model=model,
        pins={"p": p, "n": n},
        params=all_params
    )


def capacitor(name: str, p: Net, n: Net, c: float,
              model: Optional[str] = None, **params) -> Instance:
    """
    Create a capacitor.

    Args:
        name: Instance name
        p: Positive terminal
        n: Negative terminal
        c: Capacitance in farads
        model: Optional model name
        **params: Additional parameters

    Returns:
        Instance object
    """
    all_params = {"c": c}
    all_params.update(params)

    return Instance(
        name=name,
        kind="capacitor",
        model=model,
        pins={"p": p, "n": n},
        params=all_params
    )


def inductor(name: str, p: Net, n: Net, l: float,
             model: Optional[str] = None, **params) -> Instance:
    """
    Create an inductor.

    Args:
        name: Instance name
        p: Positive terminal
        n: Negative terminal
        l: Inductance in henries
        model: Optional model name
        **params: Additional parameters

    Returns:
        Instance object
    """
    all_params = {"l": l}
    all_params.update(params)

    return Instance(
        name=name,
        kind="inductor",
        model=model,
        pins={"p": p, "n": n},
        params=all_params
    )


# =============================================================================
# Sources
# =============================================================================

def vsource(name: str, p: Net, n: Net,
            dc: Optional[float] = None,
            ac: Optional[float] = None,
            type: str = "vsource", **params) -> Instance:
    """
    Create a voltage source.

    Args:
        name: Instance name
        p: Positive terminal
        n: Negative terminal
        dc: DC voltage value
        ac: AC magnitude
        type: Source type (default "vsource")
        **params: Additional parameters (for pulse, sine, etc.)

    Returns:
        Instance object
    """
    all_params = {}
    if dc is not None:
        all_params["dc"] = dc
    if ac is not None:
        all_params["mag"] = ac
    all_params.update(params)

    return Instance(
        name=name,
        kind="vsource",
        model=type,
        pins={"p": p, "n": n},
        params=all_params
    )


def isource(name: str, p: Net, n: Net,
            dc: Optional[float] = None,
            ac: Optional[float] = None,
            type: str = "isource", **params) -> Instance:
    """
    Create a current source.

    Args:
        name: Instance name
        p: Positive terminal (current flows from p to n)
        n: Negative terminal
        dc: DC current value
        ac: AC magnitude
        type: Source type (default "isource")
        **params: Additional parameters

    Returns:
        Instance object
    """
    all_params = {}
    if dc is not None:
        all_params["dc"] = dc
    if ac is not None:
        all_params["mag"] = ac
    all_params.update(params)

    return Instance(
        name=name,
        kind="isource",
        model=type,
        pins={"p": p, "n": n},
        params=all_params
    )


def vpulse(name: str, p: Net, n: Net,
           val0: float, val1: float,
           period: float, width: Optional[float] = None,
           rise: float = 1e-12, fall: float = 1e-12,
           delay: float = 0) -> Instance:
    """
    Create a pulse voltage source.

    Args:
        name: Instance name
        p: Positive terminal
        n: Negative terminal
        val0: Initial/low value
        val1: Pulsed/high value
        period: Period
        width: Pulse width (default period/2)
        rise: Rise time
        fall: Fall time
        delay: Initial delay

    Returns:
        Instance object
    """
    if width is None:
        width = period / 2

    return Instance(
        name=name,
        kind="vsource",
        model="vsource",
        pins={"p": p, "n": n},
        params={
            "type": "pulse",
            "val0": val0,
            "val1": val1,
            "period": period,
            "width": width,
            "rise": rise,
            "fall": fall,
            "delay": delay
        }
    )


def vsin(name: str, p: Net, n: Net,
         dc: float = 0, ampl: float = 1,
         freq: float = 1e6) -> Instance:
    """
    Create a sinusoidal voltage source.

    Args:
        name: Instance name
        p: Positive terminal
        n: Negative terminal
        dc: DC offset
        ampl: Amplitude
        freq: Frequency in Hz

    Returns:
        Instance object
    """
    return Instance(
        name=name,
        kind="vsource",
        model="vsource",
        pins={"p": p, "n": n},
        params={
            "type": "sine",
            "dc": dc,
            "ampl": ampl,
            "freq": freq
        }
    )


# =============================================================================
# Controlled Sources
# =============================================================================

def vcvs(name: str, p_out: Net, n_out: Net, p_in: Net, n_in: Net,
         gain: float) -> Instance:
    """
    Voltage-Controlled Voltage Source.

    Args:
        name: Instance name
        p_out: Positive output terminal
        n_out: Negative output terminal
        p_in: Positive input (sense) terminal
        n_in: Negative input (sense) terminal
        gain: Voltage gain

    Returns:
        Instance object
    """
    return Instance(
        name=name,
        kind="vcvs",
        model="vcvs",
        pins={"p_out": p_out, "n_out": n_out, "p_in": p_in, "n_in": n_in},
        params={"gain": gain}
    )


def vccs(name: str, p_out: Net, n_out: Net, p_in: Net, n_in: Net,
         gm: float) -> Instance:
    """
    Voltage-Controlled Current Source.

    Args:
        name: Instance name
        p_out: Positive output terminal
        n_out: Negative output terminal
        p_in: Positive input (sense) terminal
        n_in: Negative input (sense) terminal
        gm: Transconductance (A/V)

    Returns:
        Instance object
    """
    return Instance(
        name=name,
        kind="vccs",
        model="vccs",
        pins={"p_out": p_out, "n_out": n_out, "p_in": p_in, "n_in": n_in},
        params={"gm": gm}
    )


def ccvs(name: str, p_out: Net, n_out: Net, p_in: Net, n_in: Net,
         rm: float) -> Instance:
    """
    Current-Controlled Voltage Source.

    Args:
        name: Instance name
        p_out: Positive output terminal
        n_out: Negative output terminal
        p_in: Positive input (sense) terminal
        n_in: Negative input (sense) terminal
        rm: Transresistance (V/A)

    Returns:
        Instance object
    """
    return Instance(
        name=name,
        kind="ccvs",
        model="ccvs",
        pins={"p_out": p_out, "n_out": n_out, "p_in": p_in, "n_in": n_in},
        params={"rm": rm}
    )


def cccs(name: str, p_out: Net, n_out: Net, p_in: Net, n_in: Net,
         gain: float) -> Instance:
    """
    Current-Controlled Current Source.

    Args:
        name: Instance name
        p_out: Positive output terminal
        n_out: Negative output terminal
        p_in: Positive input (sense) terminal
        n_in: Negative input (sense) terminal
        gain: Current gain

    Returns:
        Instance object
    """
    return Instance(
        name=name,
        kind="cccs",
        model="cccs",
        pins={"p_out": p_out, "n_out": n_out, "p_in": p_in, "n_in": n_in},
        params={"gain": gain}
    )


# =============================================================================
# Diode
# =============================================================================

def diode(name: str, p: Net, n: Net,
          model: str = "diode", **params) -> Instance:
    """
    Create a diode.

    Args:
        name: Instance name
        p: Anode (positive terminal)
        n: Cathode (negative terminal)
        model: Model name
        **params: Additional parameters

    Returns:
        Instance object
    """
    return Instance(
        name=name,
        kind="diode",
        model=model,
        pins={"p": p, "n": n},
        params=params
    )


# =============================================================================
# Generic Device (for Verilog-A and custom models)
# =============================================================================

def generic(name: str, model: str, pins: list, **params) -> Instance:
    """
    Create a generic device instance for Verilog-A or custom models.

    This is the most flexible device constructor - use it for any device
    type that doesn't have a dedicated constructor (Verilog-A models,
    custom primitives, etc.)

    Args:
        name: Instance name (e.g., "I21", "XOLED1")
        model: Model/module name (e.g., "oled_LUT_dc", "cap_LUT_oled")
        pins: List of net connections in order (e.g., [net1, net2])
              Can be Net objects or strings
        **params: Device parameters (e.g., tmdata="file.txt", area=938.488)

    Returns:
        Instance object

    Example:
        # Verilog-A OLED model
        oled = generic("I21", "oled_LUT_dc",
                       pins=[gnd, gnd],
                       tmdata="Open_R_25C_R3.txt",
                       area=938.488)

        # Custom capacitor LUT model
        cap = generic("I22", "cap_LUT_oled",
                      pins=[anode, elvss],
                      tmCVdata="Atlas_B_25C_1RC_C.txt",
                      area=oled_size)
    """
    # Convert pins list to dict with positional keys
    pin_dict = {}
    for i, pin in enumerate(pins):
        if isinstance(pin, Net):
            pin_dict[f"_{i}"] = pin
        elif isinstance(pin, str):
            pin_dict[f"_{i}"] = Net(pin)
        else:
            raise TypeError(f"Pin must be Net or str, got {type(pin)}")

    return Instance(
        name=name,
        kind="generic",
        model=model,
        pins=pin_dict,
        params=params
    )


# =============================================================================
# Probes
# =============================================================================

def iprobe(name: str, p: Net, n: Net) -> Instance:
    """
    Create a current probe (iprobe).

    Current probes measure current flowing from p to n.
    They appear as zero-resistance elements in the circuit.

    Args:
        name: Instance name (e.g., "I_OLED", "Iprobe1")
        p: Positive terminal (current enters here)
        n: Negative terminal (current exits here)

    Returns:
        Instance object

    Example:
        # Probe current into OLED
        probe = iprobe("I_OLED", anode, net09)
    """
    return Instance(
        name=name,
        kind="iprobe",
        model="iprobe",
        pins={"p": p, "n": n},
        params={}
    )

