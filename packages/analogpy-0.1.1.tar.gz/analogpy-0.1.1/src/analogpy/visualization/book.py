# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
SchematicBook - Main class for generating PDF schematic documentation.
"""

import io
import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, TYPE_CHECKING

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak,
    Table, TableStyle, Image
)
from reportlab.lib import colors

from pypdf import PdfReader, PdfWriter

from .config import SymbolStyle, SymbolConfig, LayoutHints, BookConfig
from .symbols import SymbolRenderer, create_circuit_drawing, create_testbench_block_diagram

if TYPE_CHECKING:
    from ..circuit import Circuit
    from ..testbench import Testbench


class SchematicBook:
    """
    Generates PDF schematic documentation from analogpy circuits.

    The PDF starts directly with the testbench block diagram on page 1,
    with table of contents available in the PDF sidebar (bookmarks).

    Example:
        from analogpy.visualization import SchematicBook

        book = SchematicBook(title="OLED Design")
        book.add_testbench(tb)
        book.render("schematic.pdf")
    """

    def __init__(
        self,
        title: str = "Schematic Documentation",
        author: str = "",
        default_style: SymbolStyle = SymbolStyle.STANDARD,
        page_size: str = "letter"  # "letter" or "a4"
    ):
        self.config = BookConfig(
            title=title,
            author=author,
            default_style=default_style,
        )
        self.page_size = letter if page_size == "letter" else A4
        self.renderer = SymbolRenderer(default_style)

        # Content to render
        self.testbenches: List['Testbench'] = []
        self.circuits: List['Circuit'] = []
        self.circuit_map: Dict[str, 'Circuit'] = {}  # name -> Circuit

        # Track page numbers for bookmarks
        self._page_bookmarks: List[tuple] = []  # [(title, page_num), ...]

        # Track temp files to clean up after build
        self._temp_files: List[str] = []

        # Styles
        self.styles = getSampleStyleSheet()
        self._setup_styles()

    def _setup_styles(self):
        """Setup custom paragraph styles."""
        self.styles.add(ParagraphStyle(
            name='ChapterTitle',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceBefore=6,
            spaceAfter=12,
        ))
        self.styles.add(ParagraphStyle(
            name='SectionTitle',
            parent=self.styles['Heading2'],
            fontSize=12,
            spaceBefore=8,
            spaceAfter=6,
        ))
        self.styles.add(ParagraphStyle(
            name='CellInfo',
            parent=self.styles['Normal'],
            fontSize=9,
            leftIndent=20,
        ))
        self.styles.add(ParagraphStyle(
            name='SmallInfo',
            parent=self.styles['Normal'],
            fontSize=8,
            textColor=colors.gray,
        ))

    def register_model_style(
        self,
        model: str,
        style: SymbolStyle = SymbolStyle.STANDARD,
        label: Optional[str] = None,
        color: str = "#E8E8E8",
        template: Optional[str] = None,
        **kwargs
    ):
        """Register a custom symbol configuration for a model."""
        config = SymbolConfig(
            style=style,
            label=label,
            color=color,
            template=template,
            **kwargs
        )
        self.renderer.register_model(model, config)
        self.config.model_configs[model] = config

    def set_layout(self, circuit_name: str, hints: LayoutHints):
        """Set layout hints for a specific circuit."""
        self.config.layout_hints[circuit_name] = hints

    def add_testbench(self, testbench: 'Testbench'):
        """
        Add a testbench to the book.

        This also adds all subcircuits referenced by the testbench.
        """
        self.testbenches.append(testbench)

        # Collect all unique subcircuits
        for inst in testbench.subcircuit_instances:
            subckt = inst.subcircuit
            if subckt.name not in self.circuit_map:
                self.circuit_map[subckt.name] = subckt
                self.circuits.append(subckt)

    def add_circuit(self, circuit: 'Circuit'):
        """Add a standalone circuit to the book."""
        if circuit.name not in self.circuit_map:
            self.circuit_map[circuit.name] = circuit
            self.circuits.append(circuit)

    def _render_drawing_to_image(self, drawing, width_inches: float = 6.0) -> Optional[Image]:
        """Convert a schemdraw Drawing to a reportlab Image."""
        try:
            # Create temp file for PNG (don't delete yet - reportlab needs it)
            fd, temp_path = tempfile.mkstemp(suffix='.png')
            os.close(fd)

            # Save drawing to PNG
            drawing.save(temp_path, dpi=150)

            # Track for cleanup later
            self._temp_files.append(temp_path)

            # Create reportlab Image
            img = Image(temp_path, width=width_inches * inch)

            return img
        except Exception as e:
            print(f"Warning: Could not render drawing: {e}")
            return None

    def _cleanup_temp_files(self):
        """Clean up temporary image files."""
        for temp_path in self._temp_files:
            try:
                os.unlink(temp_path)
            except:
                pass
        self._temp_files = []

    def _create_testbench_page(self, testbench: 'Testbench', page_num: int) -> List:
        """Create a page for a testbench (this is page 1)."""
        elements = []

        # Record bookmark
        self._page_bookmarks.append((f"Testbench: {testbench.name}", page_num))

        # Title with testbench name prominently
        elements.append(Paragraph(f"Testbench: {testbench.name}", self.styles['ChapterTitle']))

        # Generation info (small, unobtrusive)
        gen_info = f"Generated by analogpy | {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        if self.config.author:
            gen_info = f"{self.config.author} | {gen_info}"
        elements.append(Paragraph(gen_info, self.styles['SmallInfo']))
        elements.append(Spacer(1, 0.15 * inch))

        # Block diagram FIRST - this is what users want to see
        elements.append(Paragraph("Block Diagram", self.styles['SectionTitle']))

        try:
            drawing = create_testbench_block_diagram(testbench, self.renderer)
            img = self._render_drawing_to_image(drawing, width_inches=5.5)  # Scaled down to fit on page
            if img:
                elements.append(img)
            else:
                elements.append(Paragraph("[Block diagram rendering failed]", self.styles['Normal']))
        except Exception as e:
            elements.append(Paragraph(f"[Diagram error: {e}]", self.styles['Normal']))

        elements.append(Spacer(1, 0.3 * inch))

        # Testbench info below the diagram
        info_lines = []

        # Supplies
        if testbench.supplies:
            supplies_str = ", ".join([f"{s.name}={s.dc}V" for s in testbench.supplies])
            info_lines.append(f"<b>Supplies:</b> {supplies_str}")

        # Instances count
        if testbench.subcircuit_instances:
            info_lines.append(f"<b>Instances:</b> {len(testbench.subcircuit_instances)} subcircuits")

        # Analyses
        if hasattr(testbench, 'analyses') and testbench.analyses:
            analyses_str = ", ".join([a.name if hasattr(a, 'name') else str(type(a).__name__)
                                      for a in testbench.analyses])
            info_lines.append(f"<b>Analyses:</b> {analyses_str}")

        for line in info_lines:
            elements.append(Paragraph(line, self.styles['CellInfo']))

        elements.append(PageBreak())
        return elements

    def _create_circuit_page(self, circuit: 'Circuit', page_num: int) -> List:
        """Create a page for a circuit/cell."""
        elements = []

        # Record bookmark
        self._page_bookmarks.append((f"Cell: {circuit.name}", page_num))

        elements.append(Paragraph(f"Cell: {circuit.name}", self.styles['ChapterTitle']))

        # Circuit info
        if circuit.ports:
            elements.append(Paragraph(
                f"<b>Ports:</b> {', '.join(circuit.ports)}",
                self.styles['CellInfo']
            ))

        # Schematic drawing FIRST
        elements.append(Spacer(1, 0.15 * inch))
        elements.append(Paragraph("Schematic", self.styles['SectionTitle']))

        try:
            drawing = create_circuit_drawing(circuit, self.renderer, self.config.default_style)
            img = self._render_drawing_to_image(drawing, width_inches=6.0)
            if img:
                elements.append(img)
            else:
                elements.append(Paragraph("[Schematic rendering failed]", self.styles['Normal']))
        except Exception as e:
            elements.append(Paragraph(f"[Diagram error: {e}]", self.styles['Normal']))

        elements.append(Spacer(1, 0.2 * inch))

        # Devices info
        if circuit.instances:
            elements.append(Paragraph("<b>Devices:</b>", self.styles['CellInfo']))
            for inst in circuit.instances:
                model = inst.model or inst.kind
                elements.append(Paragraph(f"  {inst.name} ({model})", self.styles['CellInfo']))

        # Parameters from comments (added by @auto_comment_params)
        if hasattr(circuit, 'comments') and circuit.comments:
            elements.append(Spacer(1, 0.1 * inch))
            elements.append(Paragraph("<b>Parameters:</b>", self.styles['CellInfo']))
            for comment in circuit.comments[:8]:  # Limit to 8
                elements.append(Paragraph(f"  {comment}", self.styles['CellInfo']))

        elements.append(PageBreak())
        return elements

    def _add_bookmarks_to_pdf(self, input_path: str, output_path: str):
        """Add bookmarks/outline to the PDF for sidebar navigation."""
        reader = PdfReader(input_path)
        writer = PdfWriter()

        # Copy all pages
        for page in reader.pages:
            writer.add_page(page)

        # Add bookmarks (outline)
        for title, page_num in self._page_bookmarks:
            # page_num is 1-indexed, pypdf uses 0-indexed
            writer.add_outline_item(title, page_num - 1)

        # Set PDF metadata
        writer.add_metadata({
            '/Title': self.config.title,
            '/Author': self.config.author or 'analogpy',
            '/Creator': 'analogpy SchematicBook',
            '/Producer': 'reportlab + pypdf',
        })

        # Write output
        with open(output_path, 'wb') as f:
            writer.write(f)

    def render(self, output_path: str):
        """
        Render the schematic book to a PDF file.

        Page 1 shows the testbench block diagram immediately.
        Table of contents is in PDF sidebar (bookmarks).

        Args:
            output_path: Path to save the PDF
        """
        # Create temp file for initial PDF (without bookmarks)
        fd, temp_path = tempfile.mkstemp(suffix='.pdf')
        os.close(fd)

        try:
            doc = SimpleDocTemplate(
                temp_path,
                pagesize=self.page_size,
                leftMargin=self.config.margin * inch,
                rightMargin=self.config.margin * inch,
                topMargin=self.config.margin * inch,
                bottomMargin=self.config.margin * inch,
            )

            elements = []
            self._page_bookmarks = []
            self._temp_files = []  # Reset temp files
            page_num = 1

            # Testbench pages FIRST (page 1 = testbench)
            for tb in self.testbenches:
                elements.extend(self._create_testbench_page(tb, page_num))
                page_num += 1

            # Circuit pages
            for circuit in self.circuits:
                elements.extend(self._create_circuit_page(circuit, page_num))
                page_num += 1

            # Build initial PDF
            doc.build(elements)

            # Clean up image temp files after build
            self._cleanup_temp_files()

            # Add bookmarks and write final PDF
            self._add_bookmarks_to_pdf(temp_path, output_path)

            print(f"Schematic PDF generated: {output_path}")
            print(f"  - {len(self.testbenches)} testbench(es)")
            print(f"  - {len(self.circuits)} cell(s)")
            print("  - Table of contents in PDF sidebar (bookmarks)")

        finally:
            # Clean up temp PDF file
            try:
                os.unlink(temp_path)
            except:
                pass
            # Clean up any remaining image temp files
            self._cleanup_temp_files()

    def render_to_bytes(self) -> bytes:
        """Render the schematic book to bytes (for in-memory use)."""
        # Create temp files
        fd1, temp_path1 = tempfile.mkstemp(suffix='.pdf')
        fd2, temp_path2 = tempfile.mkstemp(suffix='.pdf')
        os.close(fd1)
        os.close(fd2)

        try:
            doc = SimpleDocTemplate(
                temp_path1,
                pagesize=self.page_size,
                leftMargin=self.config.margin * inch,
                rightMargin=self.config.margin * inch,
                topMargin=self.config.margin * inch,
                bottomMargin=self.config.margin * inch,
            )

            elements = []
            self._page_bookmarks = []
            page_num = 1

            for tb in self.testbenches:
                elements.extend(self._create_testbench_page(tb, page_num))
                page_num += 1

            for circuit in self.circuits:
                elements.extend(self._create_circuit_page(circuit, page_num))
                page_num += 1

            doc.build(elements)
            self._add_bookmarks_to_pdf(temp_path1, temp_path2)

            with open(temp_path2, 'rb') as f:
                return f.read()
        finally:
            try:
                os.unlink(temp_path1)
                os.unlink(temp_path2)
            except:
                pass
