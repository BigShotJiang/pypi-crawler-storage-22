# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Configuration classes for schematic visualization."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple


class SymbolStyle(Enum):
    """Symbol rendering styles."""
    MINIMAL = "minimal"      # Just model name in box
    STANDARD = "standard"    # Model name + port labels
    DETAILED = "detailed"    # Model name + ports + parameters


@dataclass
class SymbolConfig:
    """Configuration for a specific symbol."""
    style: SymbolStyle = SymbolStyle.STANDARD
    label: Optional[str] = None          # Custom label (overrides model name)
    color: str = "#E8E8E8"               # Fill color
    border_color: str = "#000000"        # Border color
    port_names: Optional[List[str]] = None  # Custom port names
    template: Optional[str] = None       # Use built-in template (e.g., "capacitor")
    width: float = 2.0                   # Symbol width in inches
    height: float = 1.0                  # Symbol height in inches


@dataclass
class LayoutHints:
    """Layout hints for positioning components."""
    positions: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    rows: Dict[int, List[str]] = field(default_factory=dict)
    relative: Dict[str, Dict[str, str]] = field(default_factory=dict)

    def position(self, instance_name: str, x: float, y: float) -> 'LayoutHints':
        """Set absolute position for an instance."""
        self.positions[instance_name] = (x, y)
        return self

    def row(self, row_num: int, instances: List[str]) -> 'LayoutHints':
        """Place instances in a row."""
        self.rows[row_num] = instances
        return self

    def below(self, instance: str, reference: str) -> 'LayoutHints':
        """Place instance below reference."""
        if instance not in self.relative:
            self.relative[instance] = {}
        self.relative[instance]["below"] = reference
        return self

    def right_of(self, instance: str, reference: str) -> 'LayoutHints':
        """Place instance to the right of reference."""
        if instance not in self.relative:
            self.relative[instance] = {}
        self.relative[instance]["right_of"] = reference
        return self


@dataclass
class BookConfig:
    """Configuration for the entire schematic book."""
    title: str = "Schematic Documentation"
    author: str = ""
    default_style: SymbolStyle = SymbolStyle.STANDARD
    show_parameters: bool = True
    show_port_names: bool = True
    page_width: float = 8.5              # inches (Letter)
    page_height: float = 11.0            # inches
    margin: float = 0.75                 # inches

    # Model-specific configurations
    model_configs: Dict[str, SymbolConfig] = field(default_factory=dict)

    # Layout configurations per circuit
    layout_hints: Dict[str, LayoutHints] = field(default_factory=dict)
