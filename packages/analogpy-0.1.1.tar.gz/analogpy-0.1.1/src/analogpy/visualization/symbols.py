# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Symbol rendering using schemdraw."""

import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend BEFORE importing pyplot

from typing import Dict, List, Optional, Tuple, TYPE_CHECKING
import schemdraw
import schemdraw.elements as elm
from schemdraw import Drawing

from .config import SymbolStyle, SymbolConfig

if TYPE_CHECKING:
    from ..circuit import Circuit, Instance


class SymbolRenderer:
    """Renders circuit symbols using schemdraw."""

    # Built-in templates for common device types
    TEMPLATES = {
        "resistor": "R",
        "capacitor": "C",
        "inductor": "L",
        "diode": "D",
        "ammeter": "ammeter",
        "voltmeter": "voltmeter",
    }

    def __init__(self, default_style: SymbolStyle = SymbolStyle.STANDARD):
        self.default_style = default_style
        self.model_configs: Dict[str, SymbolConfig] = {}

    def register_model(self, model: str, config: SymbolConfig):
        """Register a custom configuration for a model."""
        self.model_configs[model] = config

    def get_config(self, model: str) -> SymbolConfig:
        """Get configuration for a model, using defaults if not registered."""
        if model in self.model_configs:
            return self.model_configs[model]
        return SymbolConfig(style=self.default_style)


def create_circuit_drawing(
    circuit: 'Circuit',
    renderer: SymbolRenderer,
    style: SymbolStyle = SymbolStyle.STANDARD
) -> Drawing:
    """
    Create a schemdraw Drawing for a circuit.

    Uses flow-based layout with connections between components.
    Professional minimal color scheme.
    """
    with schemdraw.Drawing() as d:
        d.config(unit=2, fontsize=10)

        # Get all instances
        instances = circuit.instances if hasattr(circuit, 'instances') else []
        supplies = circuit.supplies if hasattr(circuit, 'supplies') else []

        # Professional color scheme - minimal
        DEVICE_COLOR = '#FFFFFF'     # White for devices
        PROBE_COLOR = '#F8F8F8'      # Slightly off-white for probes
        WIRE_COLOR = '#333333'       # Dark gray for wires

        # Layout configuration
        spacing_x = 3.0
        spacing_y = 2.0
        box_width = 2.5
        box_height = 1.0

        # Build net-to-instance mapping for connections
        net_instances = {}  # net_name -> [(instance_idx, port_name), ...]

        for idx, inst in enumerate(instances):
            if hasattr(inst, 'connections'):
                for port, net in inst.connections.items():
                    if hasattr(net, 'name'):
                        net_name = net.name
                    elif isinstance(net, str):
                        net_name = net
                    else:
                        continue
                    if net_name not in net_instances:
                        net_instances[net_name] = []
                    net_instances[net_name].append((idx, port))

        # Track instance positions
        instance_positions = {}  # idx -> (x_center, y_center)

        # Draw supplies on top
        y_pos = 0
        for i, supply in enumerate(supplies):
            x = i * spacing_x + box_width/2
            d += elm.Rect(w=box_width, h=box_height).at((x, y_pos - box_height/2)).fill(DEVICE_COLOR)
            d += elm.Label().at((x, y_pos - 0.3)).label(supply.name)
            d += elm.Label().at((x, y_pos - 0.6)).label(f"{supply.dc}V")

        if supplies:
            y_pos -= spacing_y

        # Draw instances in rows
        instances_per_row = 3
        for i, inst in enumerate(instances):
            row = i // instances_per_row
            col = i % instances_per_row

            x = col * spacing_x + box_width/2
            y = y_pos - row * spacing_y

            instance_positions[i] = (x, y - box_height/2)

            config = renderer.get_config(inst.model or inst.kind)
            label = config.label or inst.model or inst.kind

            # Use probe color for iprobe, otherwise device color
            fill_color = PROBE_COLOR if inst.kind == "iprobe" else DEVICE_COLOR

            # Draw device box
            d += elm.Rect(w=box_width, h=box_height).at((x, y - box_height/2)).fill(fill_color)
            d += elm.Label().at((x, y - 0.3)).label(inst.name)
            d += elm.Label().at((x, y - 0.6)).label(f"({label})")

        # Draw connections between instances sharing the same net
        drawn_connections = set()
        for net_name, connected in net_instances.items():
            if len(connected) < 2:
                continue
            # Skip ground connections (too cluttered)
            if net_name in ('0', 'gnd', 'GND', 'VSS', 'vss'):
                continue

            # Connect first instance to others in this net
            first_idx, first_port = connected[0]
            if first_idx not in instance_positions:
                continue
            x1, y1 = instance_positions[first_idx]

            for other_idx, other_port in connected[1:]:
                if other_idx not in instance_positions:
                    continue
                conn_key = tuple(sorted([first_idx, other_idx]))
                if conn_key in drawn_connections:
                    continue
                drawn_connections.add(conn_key)

                x2, y2 = instance_positions[other_idx]

                # Draw connection line with routing
                if abs(x1 - x2) < 0.1:
                    # Vertical connection
                    d += elm.Line().at((x1, y1 + box_height/2)).to((x2, y2 - box_height/2)).color(WIRE_COLOR)
                else:
                    # Route horizontally then vertically
                    mid_y = (y1 + y2) / 2 + box_height
                    d += elm.Line().at((x1, y1 + box_height/2)).to((x1, mid_y)).color(WIRE_COLOR)
                    d += elm.Line().at((x1, mid_y)).to((x2, mid_y)).color(WIRE_COLOR)
                    d += elm.Line().at((x2, mid_y)).to((x2, y2 + box_height/2)).color(WIRE_COLOR)
                    d += elm.Dot(radius=0.05).at((x1, mid_y)).color(WIRE_COLOR)
                    d += elm.Dot(radius=0.05).at((x2, mid_y)).color(WIRE_COLOR)

    return d


def _draw_dc_supply(d, x: float, y: float, name: str, voltage: float, scale: float = 1.0):
    """
    Draw a standard DC supply symbol (circle with + and -).

    Returns tuple: (top_connection_y, bottom_connection_y)
    - Top (+) is the positive voltage terminal
    - Bottom (-) is the negative/ground terminal
    """
    r = 0.4 * scale  # radius

    # Draw circle using arc segments (full circle)
    import math
    steps = 32
    for i in range(steps):
        a1 = 2 * math.pi * i / steps
        a2 = 2 * math.pi * (i + 1) / steps
        x1 = x + r * math.cos(a1)
        y1 = y + r * math.sin(a1)
        x2 = x + r * math.cos(a2)
        y2 = y + r * math.sin(a2)
        d += elm.Line().at((x1, y1)).to((x2, y2)).color('#000000')

    # Plus sign in upper half
    plus_y = y + r * 0.4
    ps = r * 0.25  # plus sign size
    d += elm.Line().at((x - ps, plus_y)).to((x + ps, plus_y)).color('#000000')
    d += elm.Line().at((x, plus_y - ps)).to((x, plus_y + ps)).color('#000000')

    # Minus sign in lower half
    minus_y = y - r * 0.4
    d += elm.Line().at((x - ps, minus_y)).to((x + ps, minus_y)).color('#000000')

    # Top lead (+ terminal)
    lead_len = 0.4 * scale
    top_y = y + r + lead_len
    d += elm.Line().at((x, y + r)).to((x, top_y)).color('#000000')

    # Bottom lead (- terminal)
    bottom_y = y - r - lead_len
    d += elm.Line().at((x, y - r)).to((x, bottom_y)).color('#000000')

    # Labels to the right (with offset to avoid overlap)
    label_x = x + r + 0.6 * scale
    d += elm.Label().at((label_x, y + 0.15 * scale)).label(name)
    d += elm.Label().at((label_x, y - 0.15 * scale)).label(f"{voltage}V")

    # Return both connection points
    return (top_y, bottom_y)


def create_testbench_block_diagram(
    testbench,
    renderer: SymbolRenderer
) -> Drawing:
    """
    Create a block diagram for a testbench showing subcircuit instances.
    Uses minimal professional color scheme with connections.
    Scaled to 60% to fit on single page.
    """
    with schemdraw.Drawing() as d:
        # Scale down to 60% - smaller unit and font
        d.config(unit=1.2, fontsize=7)

        # Get subcircuit instances
        instances = testbench.subcircuit_instances if hasattr(testbench, 'subcircuit_instances') else []
        supplies = testbench.supplies if hasattr(testbench, 'supplies') else []

        # Layout configuration (scaled down)
        spacing_x = 2.5
        spacing_y = 1.8
        box_width = 2.2
        box_height = 0.8

        # Professional color scheme - minimal
        INSTANCE_COLOR = '#FFFFFF'   # White for instances
        WIRE_COLOR = '#333333'       # Dark gray for wires

        # Track positions for connections
        supply_positions = {}  # supply_name -> (x, y_bottom)
        instance_positions = []  # [(x_center, y_top, connections), ...]

        # Draw DC supply symbols on top row
        y_supply = 0
        supply_top = {}     # supply_name -> (x, top_y) for + terminal
        supply_bottom = {}  # supply_name -> (x, bottom_y) for - terminal
        for i, supply in enumerate(supplies):
            x = i * spacing_x + box_width/2
            # Draw standard DC supply symbol
            top_y, bottom_y = _draw_dc_supply(d, x, y_supply, supply.name, supply.dc, scale=0.8)
            supply_top[supply.name] = (x, top_y)
            supply_bottom[supply.name] = (x, bottom_y)

        # Draw subcircuit instances in rows
        y_inst_start = -spacing_y - 0.5  # Account for supply symbol height
        instances_per_row = 3

        for i, inst in enumerate(instances):
            row = i // instances_per_row
            col = i % instances_per_row

            x = col * spacing_x + box_width/2
            y = y_inst_start - row * spacing_y

            # Draw instance box - all same color
            d += elm.Rect(w=box_width, h=box_height).at((x, y - box_height/2)).fill(INSTANCE_COLOR)
            d += elm.Label().at((x, y - 0.2)).label(inst.name)
            d += elm.Label().at((x, y - 0.5)).label(f"({inst.subcircuit.name})")

            # Track position and connections for wiring
            connections = {}
            if hasattr(inst, 'connections'):
                connections = inst.connections
            instance_positions.append((x, y, y - box_height, connections))

        # Draw ground at bottom
        num_rows = max(1, (len(instances) - 1) // instances_per_row + 1)
        gnd_y = y_inst_start - num_rows * spacing_y
        gnd_x = (instances_per_row - 1) * spacing_x / 2 + box_width/2  # Center

        d += elm.Ground().at((gnd_x, gnd_y))

        # Draw horizontal ground bus
        if instances:
            left_x = box_width/2 - 0.3
            right_x = (min(len(instances), instances_per_row) - 1) * spacing_x + box_width/2 + 0.3
            gnd_bus_y = gnd_y + 0.25
            d += elm.Line().at((left_x, gnd_bus_y)).to((right_x, gnd_bus_y)).color(WIRE_COLOR)

        # Connect supply - terminals to ground bus
        for supply_name, (sx, sy) in supply_bottom.items():
            # Vertical line from supply - terminal down to ground bus
            d += elm.Line().at((sx, sy)).to((sx, gnd_bus_y)).color(WIRE_COLOR)
            d += elm.Dot(radius=0.04).at((sx, gnd_bus_y)).color(WIRE_COLOR)

        # Connect instances to supplies (+ terminal) and ground
        for (ix, iy_top, iy_bottom, connections) in instance_positions:
            # Find which supply this instance connects to (ANODE)
            for port, net in connections.items():
                if hasattr(net, 'name'):
                    net_name = net.name
                elif isinstance(net, str):
                    net_name = net
                else:
                    continue

                # Connect to supply + terminal if matches
                if net_name in supply_top:
                    sx, sy_top = supply_top[net_name]
                    # Line from instance top up, then horizontal to supply's + lead
                    mid_y = iy_top + 0.2
                    d += elm.Line().at((ix, iy_top)).to((ix, mid_y)).color(WIRE_COLOR)
                    d += elm.Line().at((ix, mid_y)).to((sx, mid_y)).color(WIRE_COLOR)
                    d += elm.Line().at((sx, mid_y)).to((sx, sy_top)).color(WIRE_COLOR)
                    d += elm.Dot(radius=0.04).at((sx, mid_y)).color(WIRE_COLOR)

            # Connect instance bottom to ground bus
            d += elm.Line().at((ix, iy_bottom)).to((ix, gnd_bus_y)).color(WIRE_COLOR)
            d += elm.Dot(radius=0.04).at((ix, gnd_bus_y)).color(WIRE_COLOR)

    return d
