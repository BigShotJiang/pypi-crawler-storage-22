"""JSON Schemas shipped with anatomize."""
