"""Tests for anatomize package."""
