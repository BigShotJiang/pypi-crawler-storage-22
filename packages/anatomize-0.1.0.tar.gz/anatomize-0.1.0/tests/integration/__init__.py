"""Integration tests for anatomize."""
