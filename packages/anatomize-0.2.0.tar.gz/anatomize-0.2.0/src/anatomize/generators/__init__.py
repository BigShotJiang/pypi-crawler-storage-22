"""Skeleton generators for different resolution levels."""

from anatomize.generators.main import SkeletonGenerator

__all__ = ["SkeletonGenerator"]
