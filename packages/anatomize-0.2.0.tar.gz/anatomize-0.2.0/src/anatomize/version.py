"""Package version (single source of truth)."""

__version__ = "0.2.0"
