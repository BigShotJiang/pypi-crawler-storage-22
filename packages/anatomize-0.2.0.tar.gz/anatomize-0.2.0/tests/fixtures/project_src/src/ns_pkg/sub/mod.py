"""Namespace package module (no __init__.py in parents)."""


def g(x: int) -> int:
    return x + 1

