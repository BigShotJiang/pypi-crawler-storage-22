"""Regular package fixture."""

