"""Top-level module fixture."""


VALUE = 1

