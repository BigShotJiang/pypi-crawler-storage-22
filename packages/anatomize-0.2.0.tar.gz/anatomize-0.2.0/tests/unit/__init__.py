"""Unit tests for anatomize."""
