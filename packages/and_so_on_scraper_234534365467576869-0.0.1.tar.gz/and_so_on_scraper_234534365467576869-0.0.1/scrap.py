import requests
from bs4 import BeautifulSoup as bs
import pandas as pd

def scrape_quote():
    BASE_URL = "https://quotes.toscrape.com/"
    url = BASE_URL
    data = []

    while url:
        response = requests.get(url)
        if response.status_code != 200:
            print("Load error", url)
            break

        soup = bs(response.text, "html.parser")
        quotes = soup.find_all("div", class_="quote")
        for quote in quotes:
            text = quote.find("span", class_="text").get_text()
            author = quote.find("small", class_="author").get_text()
            tags = [tag.get_text() for tag in quote.find_all("a", class_="tag")]
            data.append({
                "text": text,
                "author": author,
                "tags": tags
            })

        next_btn = soup.find("li", class_="next")
        if next_btn:
            url = BASE_URL + next_btn.find("a")["href"]
        else:
            url = None

    return data

quotes = scrape_quote()
df = pd.DataFrame(quotes)
df["tags_str"] = df["tags"].apply(lambda x: ", ".join(x))
all_tags = sorted({tag for tags in df["tags"] for tag in tags})
all_tags.insert(0, "All")

all_authors = sorted(df["author"].unique().tolist())
all_authors.insert(0, "All")

from tkinter import ttk, filedialog, messagebox
import tkinter as tk

root = tk.Tk()
root.title("Quotes scrapper")
root.geometry("1000x600")

filter_frame = tk.Frame(root)
filter_frame.pack(pady=10)

tk.Label(filter_frame, text="Tag: ").grid(row=0, column=0, padx=5)
selected_tag = tk.StringVar(value="All")
tag_box = ttk.Combobox(
    filter_frame,
    textvariable=selected_tag,
    values=all_tags,
    state="readonly",
    width=25
)
tag_box.grid(row=0, column=1, padx=5)

tk.Label(filter_frame, text="Author: ").grid(row=0, column=2, padx=5)
selected_author = tk.StringVar(value="All")
author_box = ttk.Combobox(
    filter_frame,
    textvariable=selected_author,
    values=all_authors,
    state="readonly",
    width=20
)
author_box.grid(row=0, column=3, padx=5)

text_area = tk.Text(root, wrap="word")
text_area.pack(expand=True, fill="both", padx=10, pady=10)

def get_filtered_df():
    filtered_df = df
    tag = selected_tag.get()
    author = selected_author.get()
    if tag != "All":
        filtered_df = filtered_df[
            filtered_df["tags"].apply(lambda tags: tag in tags)
        ]

    if author != "All":
        filtered_df = filtered_df[
            filtered_df["author"] == author
        ]
    return filtered_df

def show_quotes(*args):
    text_area.delete("1.0", tk.END)
    filtered_df = get_filtered_df()
    for _, row in filtered_df.iterrows():
        text_area.insert(
            tk.END,
            f"{row['text']}\n{row['author']}\n{row['tags_str']}\n\n"
        )

def save_csv():
    filtered_df = get_filtered_df()
    path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV Files", "*.csv")],
        initialfile=f"{selected_author.get()} {selected_tag.get()}"
    )
    if path:
        filtered_df[["text", "author", "tags_str"]].to_csv(
            path,
            index=False,
            encoding="utf-8"
        )
        messagebox.showinfo("Success", f"Saved {len(filtered_df)} quotes to {path}")

def save_json():
    filtered_df = get_filtered_df()
    path = filedialog.asksaveasfilename(
        defaultextension=".json",
        filetypes=[("JSON Files", "*.json")],
        initialfile = f"{selected_author.get()} {selected_tag.get()}"
    )
    if path:
        filtered_df[["text", "author", "tags_str"]].to_json(
            path,
            orient="records",
            force_ascii=False,
            indent=4
        )
        messagebox.showinfo("Success", f"Saved {len(filtered_df)} quotes to {path}")

btn_frame = tk.Frame(root)
btn_frame.pack(pady=10)
tk.Button(btn_frame, text="Save CSV", command=save_csv).pack(side="left", padx=5)
tk.Button(btn_frame, text="Save JSON", command=save_json).pack(side="left", padx=5)

show_quotes()

tag_box.bind("<<ComboboxSelected>>", show_quotes)
author_box.bind("<<ComboboxSelected>>", show_quotes)


root.mainloop()