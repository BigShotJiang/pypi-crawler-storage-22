.. _filters-introduction:

##############
 Introduction
##############

This section introduces the concept of filters in the Anemoi ecosystem,
explaining their purpose and how they can be utilized to manipulate and
transform data effectively.
