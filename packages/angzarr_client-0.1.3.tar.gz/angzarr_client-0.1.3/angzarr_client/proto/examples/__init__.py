"""Example proto definitions."""
