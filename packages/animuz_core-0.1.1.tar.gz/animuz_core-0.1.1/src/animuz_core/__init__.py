"""Animuz Core - Shared utilities for RAG system.

This package provides core utilities for building RAG (Retrieval-Augmented Generation) systems:
- LLM clients (OpenAI, Anthropic, Ollama)
- RAG pipelines (Simple and Agentic)
- Vector database integration (Qdrant)
- Embedding clients (Modal, S3, SageMaker)
- Document ingestion (Azure Doc AI, Unstructured, structured parsers)
"""

from .genai.base import BaseLLM, BaseAgent
from .genai.openai_client import OpenAIAgentClient
from .genai.openai_llm_client import OpenAILLMClient
from .genai.openai_streaming_client import OpenAIAgentClientStreaming
from .genai.openai_responses_client import OpenAIAgentClientResponses
from .genai.anthropic_client import AnthropicClient, AnthropicAgentClient
from .genai.ollama_client import OLlamaClient
from .genai.tools import MCPTools
from .pipelines.base import BasePipeline
from .pipelines.agentic_rag import AgenticRAG
from .pipelines.simple_rag import SimpleRAG
from .vectordb.utils import MyQdrantClient as QdrantDBClient
from .embedding.embedding_client import EmbeddingClient
from .embedding.modal_embedding_client import ModalEmbeddingClient
from .embedding.s3_embedding_client import S3EmbeddingClient
from .ingest.azure_doc_ai_client import AzureDocAiClient
from .ingest.custom_unstructured_client import MyUnstructuredClient
from .ingest.structured import Structured
from .streaming.sse import format_sse_event, format_sse_error
from .streaming.message_mappers import map_to_responses_api, clean_output
from .profiling import Profiler
from .rag import RAG, RAGConfig
from .tooling import ToolSpec, tool

__version__ = "0.1.0"

__all__ = [
    # Base classes
    "BaseLLM",
    "BaseAgent",
    "BasePipeline",
    # LLM clients
    "OpenAIAgentClient",
    "OpenAILLMClient",
    "OpenAIAgentClientStreaming",
    "OpenAIAgentClientResponses",
    "AnthropicClient",
    "AnthropicAgentClient",
    "OLlamaClient",
    # Tools
    "MCPTools",
    # Pipelines
    "AgenticRAG",
    "SimpleRAG",
    # Vector DB
    "QdrantDBClient",
    # Embedding
    "EmbeddingClient",
    "ModalEmbeddingClient",
    "S3EmbeddingClient",
    # Ingestion
    "AzureDocAiClient",
    "MyUnstructuredClient",
    "Structured",
    # Streaming helpers
    "format_sse_event",
    "format_sse_error",
    "map_to_responses_api",
    "clean_output",
    # Profiling
    "Profiler",
    # Unified RAG
    "RAG",
    "RAGConfig",
    "ToolSpec",
    "tool",
]
