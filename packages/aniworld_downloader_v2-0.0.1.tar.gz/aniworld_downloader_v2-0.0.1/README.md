# Aniworld Downloader V2

Aniworld Downloader V2 for PyPI upload.

## Installation

```bash
pip install aniworld-downloader-v2
```

## Quick Start

CLI:
```bash
aniworld
```

Web UI:
```bash
aniworld --web-ui
```

Then open:
```
http://127.0.0.1:5000
```

## Common Options

```bash
# Start Web UI on a custom port
aniworld --web-ui --web-port 5000

# Download to a custom directory
aniworld --output-dir "C:\\Users\\YourName\\Downloads"

# Choose language and provider
aniworld --language "German Dub" --provider "VOE"

# Download specific episode URLs
aniworld --episode "https://aniworld.to/anime/stream/slug/staffel-1/episode-1"
```

## Notes

- `--web-ui` starts the Flask web interface.
- `--web-expose` binds to `0.0.0.0` for LAN access.
- `--no-browser` prevents auto-opening the browser.
