def hello():\n    return 'Hello from example_package_lianomeister'\n
