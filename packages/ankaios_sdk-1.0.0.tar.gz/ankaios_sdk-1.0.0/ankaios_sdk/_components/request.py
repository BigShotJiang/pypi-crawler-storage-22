# Copyright (c) 2024 Elektrobit Automotive GmbH
#
# This program and the accompanying materials are made available under the
# terms of the Apache License, Version 2.0 which is available at
# https://www.apache.org/licenses/LICENSE-2.0.
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""
This module defines the Request class for creating and handling
requests to the Ankaios system.

Classes
-------

- :class:`Request`:
    Represents the base request to the Ankaios system. It is an abstract
    class that should be subclassed for specific request types.
- :class:`GetStateRequest`:
    Represents a request to get the state of the Ankaios system.
- :class:`UpdateStateRequest`:
    Represents a request to update the state of the Ankaios system.
- :class:`LogsRequest`:
    Represents a request to get logs from the Ankaios system.
- :class:`LogsCancelRequest`:
    Represents a request to stop the real-time log stream from the
    Ankaios system.
- :class:`EventsRequest`:
    Represents a request to register for events from the Ankaios system.
- :class:`EventsCancelRequest`:
    Represents a request to unregister from the event stream of a specific
    event campaign in the Ankaios system.

Usage
-----

- Create a Request for updating the state:
    .. code-block:: python

        complete_state = CompleteState()
        request = UpdateStateRequest(
            complete_state, masks=["desiredState.workloads"]
        )

- Create a Request for getting the state:
    .. code-block:: python

        request = GetStateRequest(masks=["desiredState.workloads"])

- Create a Request for getting logs for a workload:
    .. code-block:: python

        workload_name: WorkloadInstanceName = ...
        request = LogsRequest(workload_names=[workload_name])

- Create a Request for getting a continuous stream of logs:
    .. code-block:: python

        workload_name: WorkloadInstanceName = ...
        request = LogsRequest(workload_names=[workload_name], follow=True)

- Create a Request for stopping the log stream:
    .. code-block:: python

        request = LogsCancelRequest()

- Get the request ID:
    .. code-block:: python

        request_id = request.get_id()
"""

__all__ = [
    "Request",
    "GetStateRequest",
    "UpdateStateRequest",
    "LogsRequest",
    "LogsCancelRequest",
    "EventsRequest",
    "EventsCancelRequest",
]

import uuid
from typing import Union
from datetime import datetime
from .._protos import _ank_base
from ..utils import get_logger
from .complete_state import CompleteState
from .workload_state import WorkloadInstanceName


class Request:
    """
    Represents a request to the Ankaios system.
    """

    def __init__(self, _id: str = None) -> None:
        """
        Initializes a Request instance.

        :param _id: The request ID. If None, a new UUID will be generated.
        :type _id: str

        :raises TypeError: If the Request class is instantiated directly.
        """
        if self.__class__ is Request:
            raise TypeError("Request cannot be instantiated directly.")
        self._request = _ank_base.Request()
        self._set_id(_id if _id else str(uuid.uuid4()))
        self._logger = get_logger()

    def __str__(self) -> str:
        """
        Returns the string representation of the request.

        :returns: The string representation of the request.
        :rtype: str
        """
        return str(self._to_proto())

    def get_id(self) -> str:
        """
        Gets the request ID.

        :returns: The request ID.
        :rtype: str
        """
        return self._request.requestId

    def _set_id(self, request_id: str) -> None:
        """
        Sets the request ID.

        :param request_id: The request ID to set.
        :type request_id: str
        """
        self._request.requestId = request_id

    def _to_proto(self) -> _ank_base.Request:
        """
        Converts the Request object to a proto message.

        :returns: The protobuf message representing the request.
        :rtype: _ank_base.Request
        """
        return self._request


# pylint: disable=too-few-public-methods, dangerous-default-value
class GetStateRequest(Request):
    """
    Represents a request for getting the state of the Ankaios system.
    This request includes an optional list of masks to specify which
    fields should be included in the response.
    """

    def __init__(self, masks: list = []) -> None:
        """
        Initializes a GetStateRequest instance.

        :param masks: The masks to set for the request.
        :type masks: list
        """
        super().__init__()
        self._request.completeStateRequest.fieldMask[:] = masks
        self._request.completeStateRequest.subscribeForEvents = False

        self._logger.debug(
            "Created request of type GetState with id %s",
            self._request.requestId,
        )


# pylint: disable=too-few-public-methods, dangerous-default-value
class UpdateStateRequest(Request):
    """
    Represents a request for updating the state of the Ankaios system.
    This request includes the new state and an optional list of masks
    to specify which fields should be updated.
    """

    def __init__(
        self, complete_state: CompleteState, masks: list = []
    ) -> None:
        """
        Initializes an UpdateStateRequest instance.

        :param complete_state: The new state to set.
        :type complete_state: CompleteState
        :param masks: The masks to set for the request.
        :type masks: list
        """
        super().__init__()
        self._request.updateStateRequest.updateMask[:] = masks
        self._request.updateStateRequest.newState.CopyFrom(
            complete_state._to_proto()
        )

        self._logger.debug(
            "Created request of type UpdateState with id %s",
            self._request.requestId,
        )


# pylint: disable=too-few-public-methods, dangerous-default-value
class LogsRequest(Request):
    """
    Represents a request for getting logs from the Ankaios system.
    """

    # pylint: disable=too-many-arguments
    def __init__(
        self,
        workload_names: list[WorkloadInstanceName],
        *,
        follow: bool = False,
        tail: int = -1,
        since: Union[str, datetime] = "",
        until: Union[str, datetime] = "",
    ) -> None:
        """
        Initializes an LogsRequest instance.

        :param workload_names: The workload instance
            names for which to get logs.
        :type workload_names: list[WorkloadInstanceName]
        :param follow: If true, the logs will be continuously streamed.
        :type follow: bool
        :param tail: The number of lines to display from
            the end of the logs.
        :type tail: int
        :param since: The start time for the logs. If string,
            it must be in the RFC3339 format.
        :type since: str / datetime
        :param until: The end time for the logs. If string,
            it must be in the RFC3339 format.
        :type until: str / datetime

        :raises ValueError: If no workload names are provided.
        """
        if len(workload_names) == 0:
            raise ValueError("At least one workload name must be provided.")

        super().__init__()
        self._request.logsRequest.CopyFrom(
            _ank_base.LogsRequest(
                workloadNames=[name._to_proto() for name in workload_names],
                follow=follow,
                tail=tail,
            )
        )
        if since:
            if isinstance(since, str):
                self._request.logsRequest.since = since
            else:
                self._request.logsRequest.since = since.isoformat()
        if until:
            if isinstance(until, str):
                self._request.logsRequest.until = until
            else:
                self._request.logsRequest.until = until.isoformat()

        self._logger.debug(
            "Created request of type LogsRequest with id %s",
            self._request.requestId,
        )


# pylint: disable=too-few-public-methods, dangerous-default-value
class LogsCancelRequest(Request):
    """
    Represents a request for stopping the real-time log stream
    from the Ankaios system.
    """

    def __init__(self, request_id: str) -> None:
        """
        Initializes an LogsCancelRequest instance.

        :param request_id: The request ID.
        :type request_id: str
        """
        super().__init__(_id=request_id)
        self._request.logsCancelRequest.CopyFrom(_ank_base.LogsCancelRequest())

        self._logger.debug(
            "Created request of type LogsCancelRequest with id %s",
            self._request.requestId,
        )


# pylint: disable=too-few-public-methods, dangerous-default-value
class EventsRequest(Request):
    """
    Represents a request for registering on events configured by the
    given masks.
    """

    def __init__(self, masks: list = []) -> None:
        """
        Initializes a EventsRequest instance.

        :param masks: The masks to subscribe to for the event.
        :type masks: list
        """
        super().__init__()
        self._request.completeStateRequest.fieldMask[:] = masks
        self._request.completeStateRequest.subscribeForEvents = True

        self._logger.debug(
            "Created request of type EventsRequest with id %s",
            self._request.requestId,
        )


# pylint: disable=too-few-public-methods, dangerous-default-value
class EventsCancelRequest(Request):
    """
    Represents a request for unregistering from the event stream
    of a specific event campaign in the Ankaios system.
    """

    def __init__(self, request_id: str) -> None:
        """
        Initializes an EventsCancelRequest instance.

        :param request_id: The request ID.
        :type request_id: str
        """
        super().__init__(_id=request_id)
        self._request.eventsCancelRequest.CopyFrom(
            _ank_base.EventsCancelRequest()
        )

        self._logger.debug(
            "Created request of type EventsCancelRequest with id %s",
            self._request.requestId,
        )
