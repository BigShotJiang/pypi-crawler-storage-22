"""GUI icon resources."""
