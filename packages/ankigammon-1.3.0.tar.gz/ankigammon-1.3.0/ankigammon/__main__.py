"""Entry point for running AnkiGammon as a module."""

from ankigammon.gui.app import main

if __name__ == "__main__":
    raise SystemExit(main())
