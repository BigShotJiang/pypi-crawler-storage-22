"""Board rendering utilities."""

from ankigammon.renderer.svg_board_renderer import SVGBoardRenderer

__all__ = ["SVGBoardRenderer"]
