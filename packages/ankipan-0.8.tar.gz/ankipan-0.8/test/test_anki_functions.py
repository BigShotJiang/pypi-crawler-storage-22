import pytest

from ankipan import HtmlWrappers, OngoingTask

# TODO
@pytest.mark.xfail
def test_anki_functions(generate_test_environment, request, data_dir, client_call_recorder, mock_gpt_translations):
    exposed_field_names = ["example_sentences"]
    testenv = generate_test_environment(
        field_names=exposed_field_names,
        extract_kwargs={"lemma_counts": {"haben": 1}},
        example_sentence_sources={'ankipan_default/youtube/video_collections/calisthenics':0.9,
                                  'ankipan_default/youtube/video_collections/baking':0.4,
                                  'ankipan_default/youtube/video_collections/fitness':0.2,
                                },
        learning_lang = 'de'
    )

    testenv.collection.trigger_fields(testenv.deck_name)
    testenv.collect_until_ready(field_names=exposed_field_names)
    testenv.collection.sync_with_anki('testsource', overwrite=True)
    with open(data_dir / '.field.html', 'w', encoding='utf-8') as f:
        f.write(testenv.first_card.standalone_backside())
