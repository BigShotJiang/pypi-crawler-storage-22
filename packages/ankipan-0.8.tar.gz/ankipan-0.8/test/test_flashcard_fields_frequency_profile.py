import pytest

from ankipan import HtmlWrappers

field_name = "frequency_profile"


def test_frequency_profile(generate_test_environment, request, data_dir, client_call_recorder):
    testenv = generate_test_environment(
        field_names=[field_name, "example_sentences/ankipan_default/youtube", "example_sentences/ankipan_default/Leipzig News Corpus"],
        extract_kwargs={"lemma_counts": {"貢献": 1}},
    )

    testenv.collection.trigger_fields(testenv.deck_name)
    testenv.collect_until_ready(field_names=[field_name])
    assert isinstance(testenv.get_flashcard_field(field_name), HtmlWrappers.CardSection)

    html = testenv.first_card.standalone_backside()
    assert "frequency-profile" in html
    with open(data_dir / ".field.html", "w", encoding="utf-8") as f:
        f.write(html)
