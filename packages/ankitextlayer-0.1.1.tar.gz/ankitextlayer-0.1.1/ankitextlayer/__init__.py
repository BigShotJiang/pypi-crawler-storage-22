"""AnkiTextLayer – bidirectional sync between Anki and Markdown."""

from ankitextlayer.cli import main

__version__ = "0.1.1"
__all__ = ["main", "__version__"]
