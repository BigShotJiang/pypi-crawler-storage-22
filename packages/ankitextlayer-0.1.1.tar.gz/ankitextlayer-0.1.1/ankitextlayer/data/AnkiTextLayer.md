Q: We have the Basic format:
A: Question & Answer
E: An extra field for extras.
M: And a field behind a button.

---

T: We also have {{c1::clozes}}. And {{c1::multiple clozes::???}}.

---

Q: What else is there?
A: Support for many markdown features, including:

- lists,
  - nested lists,
  - numbered lists,
- ==highlighted texts== and *other formatting*,
- formulas (\(E = mc^2\)), inline and block formats,
- `inline code`, tables, and much more.
E: ***All managed from markdown documents*** that can be easily:

1. version controlled,
2. batched edited,
3. improved with AI tools, and
4. shared with others.
M: Code blocks still need some polishing:
```python
def hello():
    print("Hello, world!")
```
Maybe you can help with that? Pull requests are welcome!

---

Q: How can I create new cards?
A: There are two card types: `LayerQA` for question-answer cards and `LayerCloze` for cloze deletion cards.

In the markdown file, a new line with

- `Q:` starts a new question, `A:` starts the answer,
- `T:` starts a text field for clozes which we add with the `{{c1:: ...` syntax,
- `E:` and `M:` start the extra and button fields (more), respectively.
  - You can omit the `E:` and `M:` fields if you don't need them.
E: ==Between cards, there is exactly one blank line, three dashes, and another blank line.==
For example:
```
Q: What is the capital of France?
A: Paris.

\---

Q: What is the capital of Germany?
A: Berlin.
```

---

Q: How does bidirectional syncing work between markdown and Anki?
A: Run `ankitextlayer ma` to sync markdown edits into Anki, 

--> use `ankitextlayer am` to pull Anki changes back into markdown.
E: `ma` and `am` are just shorthand for `markdown-to-anki` and `anki-to-markdown`.

You can also use the full commands if you prefer.

---

Q: What is the recommended workflow?
A: Write your cards in markdown, sync them into Anki, review and edit them in Anki, and then pull the changes back into markdown to keep everything up to date.
E: In the background, auto-commits to Git are made before every AnkiTextLayer sync, so you can track changes easily.
M: VS Code is the recommended editor as it enables pasting images directly into markdown files, which will be saved in the media collection of Anki (`media/LayerMedia/`). This is set up automatically via a symlink when you initialize AnkiTextLayer (`ankitextlayer init`) in your collection folder (an arbitrary directory of your choice, not the Anki data directory).

The add-on `Markdown Preview Enhanced` provides a smooth preview experience. ==Important==: Disable all markdown formatters.

---

Q: What happens behind the scenes when you sync?
A: Every deck and every card gets an ID assigned as an HTML tag in your markdown document with the first sync (e.g.: `card_id: 1234`).

--> Do not edit these IDs! AnkiTextLayer uses these to track what's new, changed, moved, or deleted.
E: 
| Action | Result |
|--------|--------|
| Delete the card's ID tag | The old card gets deleted in Anki and a new one gets created with a new ID |
| Delete a card completely | The note is deleted from Anki (and vice versa) |
| Move a card to a different markdown file | It moves decks in Anki (and vice versa) |
| Rename a deck in Anki | The file gets renamed on the next export |

==Important==: While you can create new decks by simply creating new markdown files (`__` for the `::` subdeck separator), renaming decks by renaming a markdown file is not supported (just rename the deck in Anki and pull the changes into markdown).
M: LayerQA cards have a `card_id`, while LayerCloze cards have a `note_id` HTML tag. This is because cloze cards can have multiple cards per note.

---

Q: Can I lose my work?
A: Unlikely. AnkiTextLayer auto-commits a Git snapshot *before* every sync, so you can always roll back.

Also, AnkiTextLayer only acts on cards of the type `LayerQA` and `LayerCloze`, so your other decks and cards are safe.
There are no issues with mixing AnkiTextLayer-managed cards with regular Anki cards in the same deck.
E: Still, keep regular backups of your Anki decks, especially when using new tools. And if you find any bugs, please report them or submit a fix!

***==Have fun!==***