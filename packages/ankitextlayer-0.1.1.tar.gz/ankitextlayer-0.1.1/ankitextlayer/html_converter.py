"""HTML to Markdown converter."""

import re

from bs4 import BeautifulSoup, NavigableString, Tag


class HTMLToMarkdown:
    """Convert HTML to clean Markdown."""

    _INLINE_WRAPPERS = {"strong": "**", "b": "**", "em": "*", "i": "*", "code": "`"}
    _BLOCK_TAGS = {"p", "div"}
    _RED_HEX_COLORS = {"#ff0000", "#fc0000", "#ff453a"}
    _RED_RGB_PATTERNS = {(255, 0, 0), (252, 0, 0), (255, 0, 4)}

    def __init__(self):
        self._handlers = {
            **{tag: self._handle_block for tag in self._BLOCK_TAGS},
            **{tag: self._handle_inline for tag in self._INLINE_WRAPPERS},
            **{f"h{i}": self._handle_heading for i in range(1, 7)},
            "br": self._handle_br,
            "u": self._handle_underline,
            "pre": self._handle_pre,
            "a": self._handle_link,
            "img": self._handle_image,
            "ul": self._handle_ul,
            "ol": self._handle_ol,
            "span": self._handle_colored_text,
            "font": self._handle_colored_text,
            "table": self._handle_table,
        }

    def _get_children(self, element, indent=0, preserve_space=True):
        return "".join(
            self._convert_node(child, indent, preserve_space)
            for child in element.children
        )

    def _convert_node(self, node, indent=0, preserve_space=True):
        if isinstance(node, NavigableString):
            return self._handle_text(str(node), preserve_space)
        if not isinstance(node, Tag):
            return ""
        if node.name is None:
            return self._get_children(node, indent, preserve_space)
        handler = self._handlers.get(node.name, self._handle_unknown)
        return handler(node, indent)

    def _handle_text(self, text, preserve_space):
        text = text.replace("\xa0", " ")
        text = text.replace("→", "-->")
        if not preserve_space:
            return " ".join(text.split())
        starts = text and text[0].isspace()
        ends = text and text[-1].isspace()
        collapsed = " ".join(text.split())
        if not collapsed:
            return " " if text else ""
        if starts:
            collapsed = " " + collapsed
        if ends:
            collapsed = collapsed + " "
        return collapsed

    def _wrap_preserving_space(self, content, wrapper):
        """Wrap content with markers, preserving leading/trailing whitespace outside."""
        if not content.strip():
            return ""
        leading = " " if content and content[0].isspace() else ""
        # Preserve newlines as newlines, not spaces
        if content.endswith("\n"):
            trailing = "\n"
        elif content and content[-1].isspace():
            trailing = " "
        else:
            trailing = ""
        return f"{leading}{wrapper}{content.strip()}{wrapper}{trailing}"

    def _handle_block(self, el, indent):
        content = self._get_children(el, indent)
        # Treat as inline if display:inline is set
        style = el.get("style", "")
        if "display:" in style and "inline" in style:
            return content
        content = content.strip()
        return "\n" + content + "\n" if content else ""

    def _handle_inline(self, el, indent):
        wrapper = self._INLINE_WRAPPERS.get(el.name, "")
        content = self._get_children(el, indent)
        return self._wrap_preserving_space(content, wrapper)

    def _is_red_color(self, color_str):
        """Check if a color string represents a red color."""
        if not color_str:
            return False
        color_str = color_str.lower().strip()
        # Check hex colors
        if color_str in self._RED_HEX_COLORS:
            return True
        # Check rgb() format
        rgb_match = re.match(
            r"rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", color_str
        )
        if rgb_match:
            rgb = (
                int(rgb_match.group(1)),
                int(rgb_match.group(2)),
                int(rgb_match.group(3)),
            )
            return rgb in self._RED_RGB_PATTERNS
        return False

    def _handle_colored_text(self, el, indent):
        """Handle span/font elements, highlighting red text with ==."""
        content = self._get_children(el, indent)
        # Check for color in style attribute (span)
        style = el.get("style", "")
        color_match = re.search(r"color:\s*([^;]+)", style)
        color = color_match.group(1).strip() if color_match else None
        # Check for color attribute (font)
        if not color:
            color = el.get("color", "")
        # Wrap in == if red
        if self._is_red_color(color):
            if not content.strip():
                return content
            return self._wrap_preserving_space(content, "==")
        return content

    def _handle_br(self, el, indent):
        # Skip newline if <br> immediately follows a <pre> (which already ends with \n)
        prev = el.previous_sibling
        if isinstance(prev, Tag) and prev.name == "pre":
            return ""
        return "\n"

    def _handle_underline(self, el, indent):
        content = self._get_children(el, indent).strip()
        return f"<u>{content}</u>" if content else ""

    def _handle_pre(self, el, indent):
        # Check for nested <code> with optional language class
        code_el = el.find("code")
        lang = ""
        if code_el:
            classes = code_el.get("class", [])
            for cls in classes:
                if cls.startswith("language-"):
                    lang = cls[len("language-") :]
                    break
        content = el.get_text().strip()
        fence = f"```{lang}" if lang else "```"
        return f"{fence}\n{content}\n```\n" if content else ""

    def _handle_heading(self, el, indent):
        level = int(el.name[1])
        content = self._get_children(el, indent).strip()
        return f"{'#' * level} {content}\n\n" if content else ""

    def _handle_link(self, el, indent):
        content = self._get_children(el, indent).strip()
        href = el.get("href", "")
        return f"[{content}]({href})" if href else content

    def _handle_image(self, el, indent):
        src = el.get("src", "")
        if not src:
            return ""
        alt = el.get("alt", "")
        # Extract width from style attribute
        style = el.get("style", "")
        width_match = re.search(r"width:\s*([\d.]+)px", style)
        width_attr = (
            f"{{width={int(float(width_match.group(1)))}}}" if width_match else ""
        )
        # Use angle brackets for URLs with special characters (parens, spaces)
        # This is standard markdown syntax for URLs with special chars
        return f"![{alt}](<media/{src}>){width_attr}"

    def _handle_ul(self, el, indent):
        items = [
            self._format_li(li, indent, "-")
            for li in el.find_all("li", recursive=False)
        ]
        return "\n".join(items) + "\n\n" if items else ""

    def _handle_ol(self, el, indent):
        items = [
            self._format_li(li, indent, f"{i}.")
            for i, li in enumerate(el.find_all("li", recursive=False), 1)
        ]
        return "\n".join(items) + "\n\n" if items else ""

    def _handle_unknown(self, el, indent):
        return self._get_children(el, indent)

    def _handle_table(self, el, indent):
        """Convert HTML table to markdown table."""
        rows = []
        # Get header rows from thead or first row with th elements
        thead = el.find("thead")
        if thead:
            for tr in thead.find_all("tr", recursive=False):
                cells = [
                    self._get_cell_content(cell)
                    for cell in tr.find_all(["th", "td"], recursive=False)
                ]
                if cells:
                    rows.append(cells)
        # Get body rows
        tbody = el.find("tbody")
        body_rows = (
            tbody.find_all("tr", recursive=False)
            if tbody
            else el.find_all("tr", recursive=False)
        )
        for tr in body_rows:
            cells = [
                self._get_cell_content(cell)
                for cell in tr.find_all(["th", "td"], recursive=False)
            ]
            if cells:
                rows.append(cells)
        if not rows or all(cell.strip() == "" for row in rows for cell in row):
            return ""
        # Build markdown table
        col_count = max(len(row) for row in rows)
        lines = []
        for i, row in enumerate(rows):
            # Pad row to have consistent columns
            row = row + [""] * (col_count - len(row))
            lines.append("| " + " | ".join(row) + " |")
            # Add separator after first row (header)
            if i == 0:
                lines.append("| " + " | ".join(["---"] * col_count) + " |")
        return "\n" + "\n".join(lines) + "\n\n"

    def _get_cell_content(self, cell):
        """Get cell content, escaping pipes."""
        content = self._get_children(cell).strip()
        return content.replace("|", "\\|")

    def _format_li(self, li, indent, bullet):
        result = []
        indent_str = "  " * indent
        item_parts, nested = [], []

        for child in li.children:
            if isinstance(child, NavigableString):
                text = str(child).strip().replace("\xa0", " ")
                if text:
                    item_parts.append(text)
            elif isinstance(child, Tag):
                if child.name in ["ul", "ol"]:
                    nested.append(child)
                else:
                    content = self._convert_node(child, indent)
                    if content and not content.isspace():
                        item_parts.append(content.strip())

        # Join parts, avoiding space before punctuation
        joined = ""
        for part in item_parts:
            if joined and part and part[0] not in ",.?!:;)]":
                joined += " "
            joined += part
        result.append(f"{indent_str}{bullet} {joined.strip()}")

        for n in nested:
            if n.name == "ul":
                result.extend(
                    self._format_li(nli, indent + 1, "-")
                    for nli in n.find_all("li", recursive=False)
                )
            else:
                result.extend(
                    self._format_li(nli, indent + 1, f"{i}.")
                    for i, nli in enumerate(n.find_all("li", recursive=False), 1)
                )

        return "\n".join(result)

    def _fix_malformed_lists(self, soup):
        """Fix Anki's malformed nested lists."""
        for list_tag in soup.find_all(["ul", "ol"]):
            if list_tag.parent and list_tag.parent.name in ["ul", "ol"]:
                prev_li = list_tag.find_previous_sibling("li")
                if prev_li:
                    list_tag.extract()
                    prev_li.append(list_tag)

    def convert(self, html):
        """Convert HTML to Markdown."""
        if not html or not html.strip():
            return ""

        soup = BeautifulSoup(html, "html.parser")
        self._fix_malformed_lists(soup)
        markdown = self._convert_node(soup)

        # Cleanup
        lines = []
        in_code_fence = False
        for line in markdown.strip().split("\n"):
            if line.strip().startswith("```"):
                in_code_fence = not in_code_fence
                lines.append(line.strip())
                continue
            if in_code_fence:
                lines.append(line)
                continue
            leading = len(line) - len(line.lstrip())
            content = " ".join(line.lstrip().split())
            # Escape + at line start to prevent markdown list interpretation
            if content.startswith("+"):
                content = "\\" + content
            lines.append(" " * leading + content)
        markdown = "\n".join(lines)
        markdown = re.sub(r"\n{3,}", "\n\n", markdown)
        return markdown
