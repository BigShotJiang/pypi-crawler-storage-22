"""Markdown to HTML converter for Anki import."""

import re


class MarkdownToHTML:
    """Convert Markdown back to HTML for Anki."""

    def __init__(self):
        # Inline patterns ordered by specificity (most specific first)
        # Each tuple: (pattern, replacement_func or replacement_string)
        self._inline_patterns = [
            # Bold+Italic (must come before bold and italic)
            (r"\*\*\*(.+?)\*\*\*", r"<b><i>\1</i></b>"),
            # Bold
            (r"\*\*(.+?)\*\*", r"<b>\1</b>"),
            # Italic (negative lookbehind/ahead to avoid matching **)
            (r"(?<!\*)\*([^*]+?)\*(?!\*)", r"<i>\1</i>"),
            # Inline code
            (r"`([^`]+?)`", r"<code>\1</code>"),
            # Highlight (==text==) -> red span
            (r"==(.+?)==", r'<span style="color: #ff0000">\1</span>'),
            # Images with angle brackets: ![alt](<media/path>){width=123}
            (
                r"!\[([^\]]*)\]\(<media/([^>]+)>\)\{width=(\d+)\}",
                r'<img src="\2" alt="\1" style="width: \3px;">',
            ),
            (
                r"!\[([^\]]*)\]\(<([^>]+)>\)\{width=(\d+)\}",
                r'<img src="\2" alt="\1" style="width: \3px;">',
            ),
            (r"!\[([^\]]*)\]\(<media/([^>]+)>\)", r'<img src="\2" alt="\1">'),
            (r"!\[([^\]]*)\]\(<([^>]+)>\)", r'<img src="\2" alt="\1">'),
            # Images without angle brackets: ![alt](media/path){width=123}
            (
                r"!\[([^\]]*)\]\(media/([^)]+)\)\{width=(\d+)\}",
                r'<img src="\2" alt="\1" style="width: \3px;">',
            ),
            (
                r"!\[([^\]]*)\]\(([^)]+)\)\{width=(\d+)\}",
                r'<img src="\2" alt="\1" style="width: \3px;">',
            ),
            (r"!\[([^\]]*)\]\(media/([^)]+)\)", r'<img src="\2" alt="\1">'),
            (r"!\[([^\]]*)\]\(([^)]+)\)", r'<img src="\2" alt="\1">'),
            # Links [text](url)
            (r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>'),
            # Arrow -->
            (r"-->", r"→"),
        ]

    def convert(self, markdown: str) -> str:
        """Convert markdown string to HTML."""
        if not markdown or not markdown.strip():
            return ""

        lines = markdown.split("\n")
        html_parts = []
        i = 0

        while i < len(lines):
            line = lines[i]

            # Code blocks (```)
            if line.strip().startswith("```"):
                code_lines, lang, consumed = self._parse_code_block(lines, i)
                if code_lines is not None:
                    escaped_code = self._escape_html("\n".join(code_lines))
                    lang_attr = f' class="language-{lang}"' if lang else ""
                    html_parts.append(
                        f"<pre><code{lang_attr}>{escaped_code}</code></pre>"
                    )
                i += consumed
                continue

            # Tables (line with | and next line is separator)
            if (
                "|" in line
                and i + 1 < len(lines)
                and re.match(r"^\|[\s\-:|]+\|$", lines[i + 1].strip())
            ):
                table_html, consumed = self._parse_table(lines, i)
                if table_html:
                    html_parts.append(table_html)
                i += consumed
                continue

            # Unordered lists
            if re.match(r"^(\s*)- ", line):
                list_html, consumed = self._parse_list(lines, i, ordered=False)
                html_parts.append(list_html)
                i += consumed
                continue

            # Ordered lists
            if re.match(r"^(\s*)\d+\. ", line):
                list_html, consumed = self._parse_list(lines, i, ordered=True)
                html_parts.append(list_html)
                i += consumed
                continue

            # Headings (# H1, ## H2, etc.)
            heading_match = re.match(r"^(#{1,6})\s+(.+)$", line)
            if heading_match:
                level = len(heading_match.group(1))
                content = self._convert_inline(heading_match.group(2))
                html_parts.append(f"<h{level}>{content}</h{level}>")
                i += 1
                continue

            # Empty line -> break
            if not line.strip():
                html_parts.append("<br>")
                i += 1
                continue

            # Regular text line
            html_parts.append(self._convert_inline(line))
            i += 1

        return self._join_html(html_parts)

    def _convert_inline(self, text: str) -> str:
        """Convert inline markdown formatting to HTML."""
        # Unescape escaped characters
        text = text.replace(r"\+", "+")
        text = text.replace(r"\|", "|")

        for pattern, replacement in self._inline_patterns:
            text = re.sub(pattern, replacement, text)

        return text

    def _parse_code_block(
        self,
        lines: list[str],
        start: int,
    ) -> tuple[list[str] | None, str | None, int]:
        """Parse a fenced code block, return (code_lines, language, lines_consumed)."""
        # Extract optional language hint from opening fence (e.g., ```python)
        opening = lines[start].strip()
        lang = opening[3:].strip() or None

        code_lines: list[str] = []
        i = start + 1  # Skip opening ```

        while i < len(lines):
            if lines[i].strip() == "```":
                return code_lines, lang, i - start + 1
            code_lines.append(lines[i])
            i += 1

        # No closing fence found, return what we have
        return code_lines, lang, i - start

    def _parse_table(
        self,
        lines: list[str],
        start: int,
    ) -> tuple[str, int]:
        """Parse a markdown table, return (html, lines_consumed)."""
        rows = []
        i = start

        while i < len(lines) and "|" in lines[i]:
            line = lines[i].strip()

            # Skip separator row (| --- | --- |)
            if re.match(r"^\|[\s\-:|]+\|$", line):
                i += 1
                continue

            # Parse cells
            if line.startswith("|"):
                line = line[1:]
            if line.endswith("|"):
                line = line[:-1]

            cells = [
                self._convert_inline(c.strip().replace(r"\|", "|"))
                for c in line.split("|")
            ]
            rows.append(cells)
            i += 1

        if not rows:
            return "", 0

        # Build HTML table
        html_parts = ["<table>"]
        for idx, row in enumerate(rows):
            html_parts.append("<tr>")
            tag = "th" if idx == 0 else "td"
            for cell in row:
                html_parts.append(f"<{tag}>{cell}</{tag}>")
            html_parts.append("</tr>")
        html_parts.append("</table>")

        return "".join(html_parts), i - start

    def _parse_list(
        self,
        lines: list[str],
        start: int,
        ordered: bool,
    ) -> tuple[str, int]:
        """Parse a markdown list (handles nesting), return (html, lines_consumed)."""
        items = []
        i = start
        base_indent = self._get_indent(lines[start])
        bullet_pattern = r"^(\s*)\d+\. " if ordered else r"^(\s*)- "

        while i < len(lines):
            line = lines[i]

            # Check if this line is a list item
            match = re.match(bullet_pattern, line)
            if not match:
                # Check for continuation or nested list with different type
                other_pattern = r"^(\s*)- " if ordered else r"^(\s*)\d+\. "
                other_match = re.match(other_pattern, line)
                if other_match:
                    # Different list type at same or greater indent - stop
                    break
                if not line.strip():
                    # Empty line might end the list
                    if i + 1 < len(lines):
                        next_match = re.match(bullet_pattern, lines[i + 1])
                        if next_match:
                            i += 1
                            continue
                    break
                # Non-list line - stop
                break

            indent = self._get_indent(line)
            if indent < base_indent:
                break

            # Extract content after bullet/number
            content = re.sub(bullet_pattern, "", line)
            items.append((indent - base_indent, self._convert_inline(content)))
            i += 1

        # Build HTML list
        tag = "ol" if ordered else "ul"
        return self._build_nested_list(items, tag), i - start

    def _build_nested_list(
        self,
        items: list[tuple[int, str]],
        tag: str,
    ) -> str:
        """Build nested HTML list from (indent_level, content) pairs."""
        if not items:
            return ""

        html = [f"<{tag}>"]
        stack = [0]  # Track indent levels

        for indent, content in items:
            # Close nested lists if we're going back up
            while len(stack) > 1 and indent < stack[-1]:
                stack.pop()
                html.append(f"</li></{tag}>")

            # Open new nested list if going deeper
            if indent > stack[-1]:
                html.append(f"<{tag}>")
                stack.append(indent)

            # Close previous item if at same level
            if len(html) > 1 and not html[-1].endswith(f"<{tag}>"):
                html.append("</li>")

            html.append(f"<li>{content}")

        # Close all remaining tags
        while stack:
            stack.pop()
            html.append(f"</li></{tag}>")

        return "".join(html)

    def _get_indent(self, line: str) -> int:
        """Get the indentation level of a line."""
        return len(line) - len(line.lstrip())

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters in code blocks."""
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def _join_html(self, parts: list[str]) -> str:
        """Join HTML parts with appropriate separators."""
        if not parts:
            return ""

        output = []
        for part in parts:
            if part == "<br>":
                # Blank line marker - contributes an extra <br>
                output.append("<br>")
            elif part:
                # Content - add separator before (except at start)
                if output:
                    output.append("<br>")
                output.append(part)

        html = "".join(output)
        # Cap consecutive breaks at 2
        html = re.sub(r"(<br>){3,}", "<br><br>", html)
        return html
