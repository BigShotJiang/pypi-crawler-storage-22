# Card templates for AnkiTextLayer
