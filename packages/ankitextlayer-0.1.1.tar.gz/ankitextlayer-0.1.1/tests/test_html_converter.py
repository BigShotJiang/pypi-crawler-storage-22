"""Tests for HTMLToMarkdown converter."""

import pytest

from ankitextlayer.html_converter import HTMLToMarkdown


@pytest.fixture
def converter():
    return HTMLToMarkdown()


class TestBasicConversion:
    def test_empty_input(self, converter):
        assert converter.convert("") == ""
        assert converter.convert("   ") == ""

    def test_plain_text(self, converter):
        assert converter.convert("Hello world") == "Hello world"

    def test_paragraph(self, converter):
        assert converter.convert("<p>Hello</p>") == "Hello"

    def test_multiple_paragraphs(self, converter):
        result = converter.convert("<p>First</p><p>Second</p>")
        assert "First" in result
        assert "Second" in result


class TestInlineFormatting:
    def test_bold(self, converter):
        assert converter.convert("<b>bold</b>") == "**bold**"
        assert converter.convert("<strong>bold</strong>") == "**bold**"

    def test_preserves_trailing_newline_in_formatting(self, converter):
        # <br> inside formatting should produce newline after closing markers
        html = "nach <b><i>Perrez: <br></i></b>Ein Trauma"
        result = converter.convert(html)
        assert "***Perrez:***\n" in result
        assert "Ein Trauma" in result

    def test_preserves_trailing_space(self, converter):
        # Space after "über" must be preserved outside the formatting
        result = converter.convert("<b><i>über </i></b>das")
        assert result == "***über*** das"

    def test_preserves_leading_space(self, converter):
        result = converter.convert("foo<b> bar</b>")
        assert result == "foo **bar**"

    def test_preserves_whitespace_between_elements(self, converter):
        # Newline between elements should become a space
        html = '<font color="#ff0000">ab Adoleszenz</font>\n<b>deutlicher</b>'
        assert converter.convert(html) == "==ab Adoleszenz== **deutlicher**"

    def test_italic(self, converter):
        assert converter.convert("<i>italic</i>") == "*italic*"
        assert converter.convert("<em>italic</em>") == "*italic*"

    def test_code(self, converter):
        assert converter.convert("<code>code</code>") == "`code`"

    def test_underline(self, converter):
        assert converter.convert("<u>underlined</u>") == "<u>underlined</u>"

    def test_nested_formatting(self, converter):
        result = converter.convert("<b><i>bold and italic</i></b>")
        assert "**" in result
        assert "*" in result


class TestHeadings:
    def test_headings(self, converter):
        assert converter.convert("<h1>Title</h1>").strip() == "# Title"
        assert converter.convert("<h2>Subtitle</h2>").strip() == "## Subtitle"
        assert converter.convert("<h3>Section</h3>").strip() == "### Section"


class TestInlineStyleDiv:
    def test_display_inline_div_no_line_break(self, converter):
        # div with display:inline should not cause line breaks
        html = '<div style="display: inline !important;">abc i</div>mmer'
        result = converter.convert(html)
        assert "immer" in result  # should be joined, not "i\nmmer"


class TestEscaping:
    def test_plus_at_line_start_escaped(self, converter):
        # + at start of line should be escaped to prevent markdown list interpretation
        html = "Note:<br>+ additional info"
        result = converter.convert(html)
        assert r"\+" in result

    def test_plus_in_middle_not_escaped(self, converter):
        html = "1 + 2 = 3"
        result = converter.convert(html)
        assert result == "1 + 2 = 3"


class TestLists:
    def test_unordered_list(self, converter):
        html = "<ul><li>One</li><li>Two</li></ul>"
        result = converter.convert(html)
        assert "- One" in result
        assert "- Two" in result

    def test_ordered_list(self, converter):
        html = "<ol><li>First</li><li>Second</li></ol>"
        result = converter.convert(html)
        assert "1. First" in result
        assert "2. Second" in result

    def test_nested_list(self, converter):
        html = "<ul><li>Parent<ul><li>Child</li></ul></li></ul>"
        result = converter.convert(html)
        assert "- Parent" in result
        assert "  - Child" in result

    def test_malformed_anki_list(self, converter):
        # Anki produces malformed HTML where nested lists are siblings of <li>
        html = "<ul><li>Item 1</li><li>Item 2</li><ul><li>Nested</li></ul></ul>"
        result = converter.convert(html)
        assert "- Item 1" in result
        assert "- Item 2" in result
        assert "  - Nested" in result


class TestLinks:
    def test_link(self, converter):
        html = '<a href="https://example.com">Link text</a>'
        assert converter.convert(html) == "[Link text](https://example.com)"

    def test_link_without_href(self, converter):
        html = "<a>Just text</a>"
        assert converter.convert(html) == "Just text"


class TestImages:
    def test_image(self, converter):
        html = '<img src="photo.jpg" alt="A photo">'
        assert converter.convert(html) == "![A photo](<media/photo.jpg>)"

    def test_image_no_alt(self, converter):
        html = '<img src="photo.jpg">'
        assert converter.convert(html) == "![](<media/photo.jpg>)"


class TestCodeBlocks:
    def test_preformatted(self, converter):
        html = "<pre>def foo():\n    pass</pre>"
        result = converter.convert(html)
        assert "```\ndef foo():\n    pass\n```" in result

    def test_preformatted_preserves_indentation(self, converter):
        html = '<pre>def greet(name):\n    return f"Hello, {name}!"</pre>'
        result = converter.convert(html)
        assert '```\ndef greet(name):\n    return f"Hello, {name}!"\n```' in result

    def test_pre_code_with_language(self, converter):
        html = '<pre><code class="language-python">def foo():\n    pass</code></pre>'
        result = converter.convert(html)
        assert "```python\ndef foo():\n    pass\n```" in result

    def test_pre_code_without_language(self, converter):
        html = "<pre><code>some code</code></pre>"
        result = converter.convert(html)
        assert "```\nsome code\n```" in result

    def test_pre_code_round_trip(self, converter):
        """Language hint survives HTML → MD → HTML round trip."""
        html = '<pre><code class="language-javascript">const x = 1;</code></pre>'
        md = converter.convert(html)
        assert "```javascript" in md


class TestTables:
    def test_simple_table(self, converter):
        html = """
        <table>
            <tr><th>Name</th><th>Age</th></tr>
            <tr><td>Alice</td><td>30</td></tr>
        </table>
        """
        result = converter.convert(html)
        assert "| Name | Age |" in result
        assert "| --- | --- |" in result
        assert "| Alice | 30 |" in result

    def test_table_escapes_pipes(self, converter):
        html = "<table><tr><td>a | b</td></tr></table>"
        result = converter.convert(html)
        assert r"a \| b" in result


class TestColoredText:
    def test_red_hex_color_highlight(self, converter):
        html = '<span style="color: #ff0000">important</span>'
        assert converter.convert(html) == "==important=="

    def test_red_rgb_color_highlight(self, converter):
        html = '<span style="color: rgb(255, 0, 0)">important</span>'
        assert converter.convert(html) == "==important=="

    def test_font_color_attribute(self, converter):
        html = '<font color="#ff0000">important</font>'
        assert converter.convert(html) == "==important=="

    def test_non_red_color_unchanged(self, converter):
        html = '<span style="color: blue">normal</span>'
        assert converter.convert(html) == "normal"

    def test_preserves_trailing_space(self, converter):
        html = '<font color="#ff0000">important </font>text'
        assert converter.convert(html) == "==important== text"
