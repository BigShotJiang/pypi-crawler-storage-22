"""Test HTML to Markdown conversion for nested lists."""

from bs4 import BeautifulSoup

from ankitextlayer.html_converter import HTMLToMarkdown

# The problematic HTML from Anki
html = """<ul><li>Vertraulichkeit durch Schweigepflicht</li><li>Informierte Einwilligung (durch Aufklärung):</li><ul><li>&nbsp;über Diagnose, Prognose, Behandlungsart, -wirkung, -alternativen, -dauer, -risiken &amp; Behandlungsvertrag</li><li><b>&nbsp;muss: </b>rechtzeitig/zu Beginn, mündlich u. schriftlich, verständlich</li></ul><li>Dokumentationspflicht, -einsichtnahmerecht&nbsp;</li></ul>"""

converter = HTMLToMarkdown()

# Parse and check structure before fix
soup = BeautifulSoup(html, "html.parser")
print("BEFORE fixing malformed lists:")
print(soup.prettify())
print("\n" + "=" * 60 + "\n")

# Fix malformed lists
converter._fix_malformed_lists(soup)
print("AFTER fixing malformed lists:")
print(soup.prettify())
print("\n" + "=" * 60 + "\n")

# Convert to markdown
result = converter.convert(html)
print("MARKDOWN OUTPUT:")
print(repr(result))  # Use repr to see actual characters
print(result)
print("\n" + "=" * 60 + "\n")

# Expected output
expected = """- Vertraulichkeit durch Schweigepflicht
- Informierte Einwilligung (durch Aufklärung):
  - über Diagnose, Prognose, Behandlungsart, -wirkung, -alternativen, -dauer, -risiken & Behandlungsvertrag
  - **muss:** rechtzeitig/zu Beginn, mündlich u. schriftlich, verständlich
- Dokumentationspflicht, -einsichtnahmerecht"""

print("EXPECTED OUTPUT:")
print(repr(expected))
print(expected)

# Compare line by line
result_lines = result.split("\n")
expected_lines = expected.split("\n")
print("\n" + "=" * 60)
print("LINE BY LINE COMPARISON:")
for i, (r, e) in enumerate(zip(result_lines, expected_lines)):
    match = "✓" if r == e else "✗"
    print(f"{match} Line {i}:")
    print(f"  Got:      {repr(r)}")
    print(f"  Expected: {repr(e)}")
    if r != e:
        print(f"  Diff: Got {len(r)} chars, expected {len(e)} chars")
