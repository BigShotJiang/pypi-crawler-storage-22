"""Tests for MarkdownToHTML converter."""

import pytest

from ankitextlayer.markdown_converter import MarkdownToHTML


@pytest.fixture
def converter():
    return MarkdownToHTML()


class TestBasicConversion:
    def test_empty_input(self, converter):
        assert converter.convert("") == ""
        assert converter.convert("   ") == ""

    def test_plain_text(self, converter):
        result = converter.convert("Hello world")
        assert "Hello world" in result


class TestInlineFormatting:
    def test_bold(self, converter):
        result = converter.convert("**bold**")
        assert "<b>bold</b>" in result

    def test_italic(self, converter):
        result = converter.convert("*italic*")
        assert "<i>italic</i>" in result

    def test_bold_italic(self, converter):
        result = converter.convert("***bold italic***")
        assert "<b><i>bold italic</i></b>" in result

    def test_inline_code(self, converter):
        result = converter.convert("`code`")
        assert "<code>code</code>" in result

    def test_highlight(self, converter):
        result = converter.convert("==important==")
        assert "color: #ff0000" in result
        assert "important" in result

    def test_mixed_formatting(self, converter):
        result = converter.convert("**bold** and *italic* text")
        assert "<b>bold</b>" in result
        assert "<i>italic</i>" in result


class TestLinks:
    def test_link(self, converter):
        result = converter.convert("[Link text](https://example.com)")
        assert '<a href="https://example.com">Link text</a>' in result

    def test_link_with_special_chars(self, converter):
        result = converter.convert("[Click here](https://example.com/path?q=1&r=2)")
        assert "https://example.com/path?q=1&r=2" in result


class TestImages:
    def test_image_with_media_prefix(self, converter):
        result = converter.convert("![alt text](<media/photo.jpg>)")
        assert '<img src="photo.jpg" alt="alt text">' in result

    def test_image_without_alt(self, converter):
        result = converter.convert("![](<media/photo.jpg>)")
        assert '<img src="photo.jpg" alt="">' in result

    def test_image_without_media_prefix(self, converter):
        result = converter.convert("![alt](<photo.jpg>)")
        assert '<img src="photo.jpg" alt="alt">' in result


class TestHeadings:
    def test_h1(self, converter):
        result = converter.convert("# Title")
        assert "<h1>Title</h1>" in result

    def test_h2(self, converter):
        result = converter.convert("## Subtitle")
        assert "<h2>Subtitle</h2>" in result

    def test_h3(self, converter):
        result = converter.convert("### Section")
        assert "<h3>Section</h3>" in result

    def test_heading_with_formatting(self, converter):
        result = converter.convert("## **Bold** Title")
        assert "<h2>" in result
        assert "<b>Bold</b>" in result


class TestLists:
    def test_unordered_list(self, converter):
        md = "- Item 1\n- Item 2"
        result = converter.convert(md)
        assert "<ul>" in result
        assert "<li>" in result
        assert "Item 1" in result
        assert "Item 2" in result

    def test_ordered_list(self, converter):
        md = "1. First\n2. Second"
        result = converter.convert(md)
        assert "<ol>" in result
        assert "First" in result
        assert "Second" in result

    def test_nested_unordered_list(self, converter):
        md = "- Parent\n  - Child"
        result = converter.convert(md)
        assert "<ul>" in result
        assert "Parent" in result
        assert "Child" in result

    def test_list_with_formatting(self, converter):
        md = "- **Bold** item"
        result = converter.convert(md)
        assert "<b>Bold</b>" in result


class TestTables:
    def test_simple_table(self, converter):
        md = "| Name | Age |\n| --- | --- |\n| Alice | 30 |"
        result = converter.convert(md)
        assert "<table>" in result
        assert "<th>Name</th>" in result
        assert "<th>Age</th>" in result
        assert "<td>Alice</td>" in result
        assert "<td>30</td>" in result

    def test_table_with_formatting(self, converter):
        md = "| Header |\n| --- |\n| **bold** |"
        result = converter.convert(md)
        assert "<b>bold</b>" in result


class TestCodeBlocks:
    def test_fenced_code_block(self, converter):
        md = "```\ndef foo():\n    pass\n```"
        result = converter.convert(md)
        assert "<pre><code>" in result
        assert "</code></pre>" in result
        assert "def foo():" in result

    def test_fenced_code_block_with_language(self, converter):
        md = "```python\ndef foo():\n    pass\n```"
        result = converter.convert(md)
        assert '<pre><code class="language-python">' in result
        assert "def foo():" in result
        assert "</code></pre>" in result

    def test_fenced_code_block_no_language(self, converter):
        md = "```\nsome code\n```"
        result = converter.convert(md)
        assert "<pre><code>" in result
        assert "class=" not in result

    def test_code_block_escapes_html(self, converter):
        md = "```\n<div>test</div>\n```"
        result = converter.convert(md)
        assert "&lt;div&gt;" in result


class TestEscaping:
    def test_escaped_plus(self, converter):
        md = r"\+ item"
        result = converter.convert(md)
        assert "+ item" in result

    def test_escaped_pipe_in_table(self, converter):
        md = r"| a \| b |"
        # This isn't a complete table, but tests pipe unescaping
        result = converter.convert(md)
        assert "a | b" in result


class TestMultilineContent:
    def test_multiple_lines(self, converter):
        md = "Line 1\nLine 2\nLine 3"
        result = converter.convert(md)
        assert "Line 1" in result
        assert "Line 2" in result
        assert "Line 3" in result

    def test_empty_lines_become_breaks(self, converter):
        md = "Para 1\n\nPara 2"
        result = converter.convert(md)
        assert "<br>" in result


class TestRoundTrip:
    """Test that HTML->Markdown->HTML produces equivalent results."""

    def test_bold_roundtrip(self, converter):
        from ankitextlayer.html_converter import HTMLToMarkdown

        html_to_md = HTMLToMarkdown()

        original_html = "<b>bold text</b>"
        markdown = html_to_md.convert(original_html)
        restored_html = converter.convert(markdown)

        assert "<b>" in restored_html
        assert "bold text" in restored_html

    def test_italic_roundtrip(self, converter):
        from ankitextlayer.html_converter import HTMLToMarkdown

        html_to_md = HTMLToMarkdown()

        original_html = "<i>italic text</i>"
        markdown = html_to_md.convert(original_html)
        restored_html = converter.convert(markdown)

        assert "<i>" in restored_html
        assert "italic text" in restored_html

    def test_highlight_roundtrip(self, converter):
        from ankitextlayer.html_converter import HTMLToMarkdown

        html_to_md = HTMLToMarkdown()

        original_html = '<span style="color: #ff0000">important</span>'
        markdown = html_to_md.convert(original_html)
        restored_html = converter.convert(markdown)

        assert "#ff0000" in restored_html
        assert "important" in restored_html

    def test_link_roundtrip(self, converter):
        from ankitextlayer.html_converter import HTMLToMarkdown

        html_to_md = HTMLToMarkdown()

        original_html = '<a href="https://example.com">link</a>'
        markdown = html_to_md.convert(original_html)
        restored_html = converter.convert(markdown)

        assert "https://example.com" in restored_html
        assert "link" in restored_html


class TestRealWorldExamples:
    """Test with patterns from actual Anki cards."""

    def test_german_text_with_formatting(self, converter):
        md = "==Derealisation== (S)\nUmwelt wird als unwirklich wahrgenommen"
        result = converter.convert(md)
        assert "Derealisation" in result
        assert "#ff0000" in result

    def test_list_with_arrow(self, converter):
        md = "- Item 1\n- Item 2\n\n→ Additional note"
        result = converter.convert(md)
        assert "Item 1" in result
        assert "→" in result

    def test_multiline_field_content(self, converter):
        md = """Was sind Symptome?
- Symptom 1
- Symptom 2

→ Wichtige Anmerkung"""
        result = converter.convert(md)
        assert "Symptome" in result
        assert "Symptom 1" in result
        assert "Wichtige Anmerkung" in result
