This file is `10x_pbmc68k_reduced.h5ad`.

It was created by @fidelram in [scverse/scanpy#228](https://github.com/scverse/scanpy/pull/228).

In the few days the PR was open, anndata 0.6.6 was current.
It looks like the anndata writing code was [not changed between 0.5.0 and 0.6.6](https://github.com/scverse/anndata/blame/0.6.6/anndata/readwrite/write.py),
that’s why this is the v0.5.0 example.
