# pylint: disable=too-many-lines
from __future__ import annotations

import abc
import argparse
import collections
import copy
import json
import logging
import tempfile
import zipfile
from collections import Counter, defaultdict
from collections.abc import Collection, Iterator
from dataclasses import dataclass, field
from enum import Enum
from functools import partial
from pathlib import Path
from typing import Any

import annofabapi
import pandas
from annofabapi.models import ProjectMemberRole, TaskPhase, TaskStatus
from annofabapi.parser import (
    SimpleAnnotationParser,
    SimpleAnnotationParserByTask,
    lazy_parse_simple_annotation_dir,
    lazy_parse_simple_annotation_dir_by_task,
    lazy_parse_simple_annotation_zip,
    lazy_parse_simple_annotation_zip_by_task,
)
from annofabapi.pydantic_models.additional_data_definition_type import AdditionalDataDefinitionType
from dataclasses_json import DataClassJsonMixin, config

import annofabcli.common.cli
from annofabcli.common.cli import (
    ArgumentParser,
    CommandLine,
    build_annofabapi_resource_and_login,
)
from annofabcli.common.download import DownloadingFile
from annofabcli.common.enums import OutputFormat
from annofabcli.common.facade import (
    AnnofabApiFacade,
    TaskQuery,
    convert_annotation_specs_labels_v2_to_v1,
    match_annotation_with_task_query,
)
from annofabcli.common.utils import print_csv, print_json
from annofabcli.common.visualize import AddProps, MessageLocale

logger = logging.getLogger(__name__)

AttributeValueKey = tuple[str, str, str]
"""
属性のキー.
tuple[label_name_en, attribute_name_en, attribute_value] で表す。
"""

LabelKeys = Collection[str]

AttributeNameKey = tuple[str, str]
"""
属性名のキー.
tuple[label_name_en, attribute_name_en] で表す。
"""


AttributeKeys = Collection[Collection]


class CsvType(Enum):
    """出力するCSVの種類"""

    LABEL = "label"
    """ラベルごとのアノテーション数を出力"""
    ATTRIBUTE = "attribute"
    """属性値ごとのアノテーション数を出力"""


class GroupBy(Enum):
    TASK_ID = "task_id"
    INPUT_DATA_ID = "input_data_id"


def encode_annotation_count_by_attribute(
    annotation_count_by_attribute: Counter[AttributeValueKey],
) -> dict[str, dict[str, dict[str, int]]]:
    """annotation_count_by_attributeを `{label_name: {attribute_name: {attribute_value: annotation_count}}}`のdictに変換します。
    JSONへの変換用関数です。
    """

    def _factory():  # noqa: ANN202
        """入れ子の辞書を利用できるようにするための関数"""
        return collections.defaultdict(_factory)

    result: dict[str, dict[str, dict[str, int]]] = defaultdict(_factory)
    for (label_name, attribute_name, attribute_value), annotation_count in annotation_count_by_attribute.items():
        result[label_name][attribute_name][attribute_value] = annotation_count
    return result


@dataclass(frozen=True)
class AnnotationCounter(abc.ABC):
    """
    アノテーションの集計情報を保持する抽象基底クラス。

    Attributes:
        annotation_count: アノテーションの総数
        annotation_count_by_label: ラベルごとのアノテーション数
        annotation_count_by_attribute: 属性値ごとのアノテーション数
    """

    annotation_count: int
    annotation_count_by_label: Counter[str]
    annotation_count_by_attribute: Counter[AttributeValueKey] = field(
        metadata=config(
            encoder=encode_annotation_count_by_attribute,
        )
    )


@dataclass(frozen=True)
class AnnotationCounterByTask(AnnotationCounter, DataClassJsonMixin):
    """
    タスク単位でのアノテーション集計情報。

    Attributes:
        project_id: プロジェクトID
        task_id: タスクID
        task_status: タスクのステータス
        task_phase: タスクのフェーズ
        task_phase_stage: タスクフェーズのステージ番号
        input_data_count: タスクに含まれる入力データの数
    """

    project_id: str
    task_id: str
    task_status: TaskStatus
    task_phase: TaskPhase
    task_phase_stage: int
    input_data_count: int


@dataclass(frozen=True)
class AnnotationCounterByInputData(AnnotationCounter, DataClassJsonMixin):
    """
    入力データ単位でのアノテーション集計情報。

    Attributes:
        project_id: プロジェクトID
        task_id: タスクID
        task_status: タスクのステータス
        task_phase: タスクのフェーズ
        task_phase_stage: タスクフェーズのステージ番号
        input_data_id: 入力データID
        input_data_name: 入力データ名
        updated_datetime: アノテーションJSONに格納されているアノテーションの更新日時
        frame_no: フレーム番号。アノテーションJSONには含まれていない情報なので、Optionalにする
    """

    project_id: str
    task_id: str
    task_status: TaskStatus
    task_phase: TaskPhase
    task_phase_stage: int

    input_data_id: str
    input_data_name: str
    updated_datetime: str | None
    """アノテーションJSONに格納されているアノテーションの更新日時"""
    frame_no: int | None = None
    """アノテーションJSONには含まれていない情報なので、Optionalにする"""


def lazy_parse_simple_annotation_by_input_data(annotation_path: Path) -> Iterator[SimpleAnnotationParser]:
    """
    アノテーションzipまたはディレクトリから、入力データ単位でアノテーションを遅延パースするイテレータを返します。

    Args:
        annotation_path: アノテーションzipまたはzipを展開したディレクトリのパス

    Returns:
        SimpleAnnotationParserのイテレータ

    Raises:
        RuntimeError: 指定されたパスが存在しない場合、またはzipファイルでもディレクトリでもない場合
    """
    if not annotation_path.exists():
        raise RuntimeError(f"'{annotation_path}' は存在しません。")

    if annotation_path.is_dir():
        return lazy_parse_simple_annotation_dir(annotation_path)
    elif zipfile.is_zipfile(str(annotation_path)):
        return lazy_parse_simple_annotation_zip(annotation_path)
    else:
        raise RuntimeError(f"'{annotation_path}'は、zipファイルまたはディレクトリではありません。")


def lazy_parse_simple_annotation_by_task(annotation_path: Path) -> Iterator[SimpleAnnotationParserByTask]:
    """
    アノテーションzipまたはディレクトリから、タスク単位でアノテーションを遅延パースするイテレータを返します。

    Args:
        annotation_path: アノテーションzipまたはzipを展開したディレクトリのパス

    Returns:
        SimpleAnnotationParserByTaskのイテレータ

    Raises:
        RuntimeError: 指定されたパスが存在しない場合、またはzipファイルでもディレクトリでもない場合
    """
    if not annotation_path.exists():
        raise RuntimeError(f"'{annotation_path}' は存在しません。")

    if annotation_path.is_dir():
        return lazy_parse_simple_annotation_dir_by_task(annotation_path)
    elif zipfile.is_zipfile(str(annotation_path)):
        return lazy_parse_simple_annotation_zip_by_task(annotation_path)
    else:
        raise RuntimeError(f"'{annotation_path}'は、zipファイルまたはディレクトリではありません。")


class ListAnnotationCounterByInputData:
    """入力データ単位で、ラベルごと/属性ごとのアノテーション数を集計情報を取得するメソッドの集まり。

    Args:
        target_labels: 集計対象のラベル（label_name_en）。`non_target_labels`との同時指定不可。
        target_attribute_names: 集計対象の属性名。`non_target_attribute_names`との同時指定不可。
        non_target_labels: 集計対象外のラベル。`target_labels`との同時指定不可。
        non_target_attribute_names: 集計対象外の属性名のキー。`target_attribute_names`との同時指定不可。
        target_attribute_names_only: 集計対象の属性名（属性名のみでフィルタリング）。ラベル名に関係なく、指定された属性名のみが対象になります。
        frame_no_map: key:task_id,input_data_idのtuple, value:フレーム番号

    Raises:
        ValueError: `target_labels`と`non_target_labels`の両方が指定された場合、
            または`target_attribute_names`と`non_target_attribute_names`の両方が指定された場合に発生します。

    """

    def __init__(
        self,
        *,
        target_labels: Collection[str] | None = None,
        non_target_labels: Collection[str] | None = None,
        target_attribute_names: Collection[AttributeNameKey] | None = None,
        non_target_attribute_names: Collection[AttributeNameKey] | None = None,
        target_attribute_names_only: Collection[str] | None = None,
        frame_no_map: dict[tuple[str, str], int] | None = None,
    ) -> None:
        if target_labels is not None and non_target_labels is not None:
            raise ValueError("`target_labels`と`non_target_labels`の両方が指定されています。")
        if target_attribute_names is not None and non_target_attribute_names is not None:
            raise ValueError("`target_attribute_names`と`non_target_attribute_names`の両方が指定されています。")

        self.target_labels = set(target_labels) if target_labels is not None else None
        self.target_attribute_names = set(target_attribute_names) if target_attribute_names is not None else None
        self.non_target_labels = set(non_target_labels) if non_target_labels is not None else None
        self.non_target_attribute_names = set(non_target_attribute_names) if non_target_attribute_names is not None else None
        self.target_attribute_names_only = set(target_attribute_names_only) if target_attribute_names_only is not None else None
        self.frame_no_map = frame_no_map

    def get_annotation_counter(
        self,
        simple_annotation: dict[str, Any],
    ) -> AnnotationCounterByInputData:
        """
        1個の入力データに対して、ラベルごと/属性ごとのアノテーション数を集計情報を取得する。

        Args:
            simple_annotation: JSONファイルの内容
        """

        def convert_attribute_value_to_key(value: bool | str | float) -> str:  # noqa: FBT001
            """
            アノテーションJSONに格納されている属性値を、dict用のkeyに変換する。

            Notes:
                アノテーションJSONに格納されている属性値の型はbool, str, floatの3つ

            """
            if isinstance(value, bool):
                # str関数で変換せずに、直接文字列を返している理由：
                # bool値をstr関数に渡すと、`True/False`が返る。
                # CSVの列名やJSONのキーとして扱う場合、`True/False`だとPythonに依存した表現に見えるので、`true/false`に変換する
                if value:
                    return "true"
                elif not value:
                    return "false"
            return str(value)

        details = simple_annotation["details"]

        annotation_count_by_label = collections.Counter([e["label"] for e in details])
        if self.target_labels is not None:
            annotation_count_by_label = collections.Counter({label: count for label, count in annotation_count_by_label.items() if label in self.target_labels})
        if self.non_target_labels is not None:
            annotation_count_by_label = collections.Counter({label: count for label, count in annotation_count_by_label.items() if label not in self.non_target_labels})

        attributes_list: list[AttributeValueKey] = []
        for detail in details:
            label = detail["label"]
            for attribute, value in detail["attributes"].items():
                attributes_list.append((label, attribute, convert_attribute_value_to_key(value)))

        annotation_count_by_attribute = collections.Counter(attributes_list)
        if self.target_attribute_names is not None:
            annotation_count_by_attribute = collections.Counter(
                {
                    (label, attribute_name, attribute_value): count
                    for (label, attribute_name, attribute_value), count in annotation_count_by_attribute.items()
                    if (label, attribute_name) in self.target_attribute_names
                }
            )
        if self.target_attribute_names_only is not None:
            annotation_count_by_attribute = collections.Counter(
                {
                    (label, attribute_name, attribute_value): count
                    for (label, attribute_name, attribute_value), count in annotation_count_by_attribute.items()
                    if attribute_name in self.target_attribute_names_only
                }
            )
        if self.non_target_attribute_names is not None:
            annotation_count_by_attribute = collections.Counter(
                {
                    (label, attribute_name, attribute_value): count
                    for (label, attribute_name, attribute_value), count in annotation_count_by_attribute.items()
                    if (label, attribute_name) not in self.non_target_attribute_names
                }
            )

        task_id = simple_annotation["task_id"]
        input_data_id = simple_annotation["input_data_id"]
        frame_no: int | None = None
        if self.frame_no_map is not None:
            frame_no = self.frame_no_map.get((task_id, input_data_id))

        return AnnotationCounterByInputData(
            project_id=simple_annotation["project_id"],
            task_id=simple_annotation["task_id"],
            task_phase=TaskPhase(simple_annotation["task_phase"]),
            task_phase_stage=simple_annotation["task_phase_stage"],
            task_status=TaskStatus(simple_annotation["task_status"]),
            input_data_id=simple_annotation["input_data_id"],
            input_data_name=simple_annotation["input_data_name"],
            updated_datetime=simple_annotation["updated_datetime"],
            annotation_count=sum(annotation_count_by_label.values()),
            annotation_count_by_label=annotation_count_by_label,
            annotation_count_by_attribute=annotation_count_by_attribute,
            frame_no=frame_no,
        )

    def get_annotation_counter_list(
        self,
        annotation_path: Path,
        *,
        target_task_ids: Collection[str] | None = None,
        task_query: TaskQuery | None = None,
    ) -> list[AnnotationCounterByInputData]:
        """
        アノテーションzipまたはそれを展開したディレクトリから、ラベルごと/属性ごとのアノテーション数を集計情報を取得する。

        """

        counter_list = []

        target_task_ids = set(target_task_ids) if target_task_ids is not None else None

        iter_parser = lazy_parse_simple_annotation_by_input_data(annotation_path)

        logger.debug("アノテーションzip/ディレクトリを読み込み中")
        for index, parser in enumerate(iter_parser):
            if (index + 1) % 1000 == 0:
                logger.debug(f"{index + 1}  件目のJSONを読み込み中")

            if target_task_ids is not None and parser.task_id not in target_task_ids:
                continue

            simple_annotation_dict = parser.load_json()
            if task_query is not None:  # noqa: SIM102
                if not match_annotation_with_task_query(simple_annotation_dict, task_query):
                    continue

            input_data_counter = self.get_annotation_counter(simple_annotation_dict)
            counter_list.append(input_data_counter)

        return counter_list


class ListAnnotationCounterByTask:
    """タスク単位で、ラベルごと/属性ごとのアノテーション数を集計情報を取得するメソッドの集まり。

    Args:
        target_labels: 集計対象のラベル（label_name_en）。`non_target_labels`との同時指定不可。
        target_attribute_names: 集計対象の属性名。`non_target_attribute_names`との同時指定不可。
        non_target_labels: 集計対象外のラベル。`target_labels`との同時指定不可。
        non_target_attribute_names: 集計対象外の属性名のキー。`target_attribute_names`との同時指定不可。
        target_attribute_names_only: 集計対象の属性名（属性名のみでフィルタリング）。ラベル名に関係なく、指定された属性名のみが対象になります。

    Raises:
        ValueError: `target_labels`と`non_target_labels`の両方が指定された場合、
            または`target_attribute_names`と`non_target_attribute_names`の両方が指定された場合に発生します。

    """

    def __init__(
        self,
        *,
        target_labels: Collection[str] | None = None,
        non_target_labels: Collection[str] | None = None,
        target_attribute_names: Collection[AttributeNameKey] | None = None,
        non_target_attribute_names: Collection[AttributeNameKey] | None = None,
        target_attribute_names_only: Collection[str] | None = None,
    ) -> None:
        if target_labels is not None and non_target_labels is not None:
            raise ValueError("`target_labels`と`non_target_labels`の両方が指定されています。")
        if target_attribute_names is not None and non_target_attribute_names is not None:
            raise ValueError("`target_attribute_names`と`non_target_attribute_names`の両方が指定されています。")

        self.counter_by_input_data = ListAnnotationCounterByInputData(
            target_labels=target_labels,
            non_target_labels=non_target_labels,
            target_attribute_names=target_attribute_names,
            non_target_attribute_names=non_target_attribute_names,
            target_attribute_names_only=target_attribute_names_only,
        )

    def get_annotation_counter(self, task_parser: SimpleAnnotationParserByTask) -> AnnotationCounterByTask:
        """
        1個のタスクに対して、ラベルごと/属性ごとのアノテーション数を集計情報を取得する。

        Args:
            simple_annotation: JSONファイルの内容
            target_labels: 集計対象のラベル（label_name_en）
            target_attributes: 集計対象の属性


        """

        annotation_count_by_label: Counter[str] = collections.Counter()
        annotation_count_by_attribute: Counter[tuple[str, str, str]] = collections.Counter()

        last_simple_annotation = None
        input_data_count = 0
        for parser in task_parser.lazy_parse():
            # parse()メソッドは遅いので、使わない
            simple_annotation_dict = parser.load_json()
            input_data = self.counter_by_input_data.get_annotation_counter(simple_annotation_dict)
            annotation_count_by_label += input_data.annotation_count_by_label
            annotation_count_by_attribute += input_data.annotation_count_by_attribute
            last_simple_annotation = simple_annotation_dict
            input_data_count += 1

        if last_simple_annotation is None:
            raise RuntimeError(f"{task_parser.task_id} ディレクトリにはjsonファイルが1つも含まれていません。")

        return AnnotationCounterByTask(
            project_id=last_simple_annotation["project_id"],
            task_id=last_simple_annotation["task_id"],
            task_status=TaskStatus(last_simple_annotation["task_status"]),
            task_phase=TaskPhase(last_simple_annotation["task_phase"]),
            task_phase_stage=last_simple_annotation["task_phase_stage"],
            input_data_count=input_data_count,
            annotation_count=sum(annotation_count_by_label.values()),
            annotation_count_by_label=annotation_count_by_label,
            annotation_count_by_attribute=annotation_count_by_attribute,
        )

    def get_annotation_counter_list(
        self,
        annotation_path: Path,
        *,
        target_task_ids: Collection[str] | None = None,
        task_query: TaskQuery | None = None,
    ) -> list[AnnotationCounterByTask]:
        """
        アノテーションzipまたはそれを展開したディレクトリから、ラベルごと/属性ごとのアノテーション数を集計情報を取得する。

        """

        counter_list = []
        iter_task_parser = lazy_parse_simple_annotation_by_task(annotation_path)

        target_task_ids = set(target_task_ids) if target_task_ids is not None else None

        logger.debug("アノテーションzip/ディレクトリを読み込み中")
        for task_index, task_parser in enumerate(iter_task_parser):
            if (task_index + 1) % 1000 == 0:
                logger.debug(f"{task_index + 1}  件目のタスクディレクトリを読み込み中")

            if target_task_ids is not None and task_parser.task_id not in target_task_ids:
                continue

            if task_query is not None:
                json_file_path_list = task_parser.json_file_path_list
                if len(json_file_path_list) == 0:
                    continue

                input_data_parser = task_parser.get_parser(json_file_path_list[0])
                dict_simple_annotation = input_data_parser.load_json()
                if not match_annotation_with_task_query(dict_simple_annotation, task_query):
                    continue

            task_counter = self.get_annotation_counter(task_parser)
            counter_list.append(task_counter)

        return counter_list


class AttributeCountCsv:
    """
    属性値ごとのアノテーション数を記載するCSV。
    """

    def _value_columns(
        self,
        counter_list: Collection[AnnotationCounter],
        prior_attribute_columns: list[AttributeValueKey] | None,
    ) -> list[AttributeValueKey]:
        """
        CSV出力のための属性値列の順序を決定します。

        Args:
            counter_list: アノテーション集計情報のコレクション
            prior_attribute_columns: 優先的に配置する属性値のキーのリスト。Noneの場合はソート順で配置されます。

        Returns:
            属性値のキーのリスト（CSV列の順序）
        """
        all_attr_key_set = {attr_key for c in counter_list for attr_key in c.annotation_count_by_attribute}
        if prior_attribute_columns is not None:
            remaining_columns = sorted(all_attr_key_set - set(prior_attribute_columns))

            # `remaining_columns`には、属性値が空である列などが格納されている
            # `remaining_columns`を、`value_columns`の関連している位置に挿入する。
            value_columns = copy.deepcopy(prior_attribute_columns)
            for remaining_column in remaining_columns:
                is_inserted = False
                for i in range(len(value_columns) - 1, -1, -1):
                    col = value_columns[i]
                    if col[0:2] == remaining_column[0:2]:
                        value_columns.insert(i + 1, remaining_column)
                        is_inserted = True
                        break
                if not is_inserted:
                    value_columns.append(remaining_column)

            assert len(value_columns) == len(prior_attribute_columns) + len(remaining_columns)

        else:
            remaining_columns = sorted(all_attr_key_set)
            value_columns = remaining_columns

        # 重複している場合は、重複要素を取り除く。ただし元の順番は維持する
        value_columns = list(dict.fromkeys(value_columns).keys())
        return value_columns

    def print_csv_by_task(
        self,
        counter_list: list[AnnotationCounterByTask],
        output_file: Path,
        prior_attribute_columns: list[AttributeValueKey] | None = None,
    ) -> None:
        """
        タスク単位の属性値ごとアノテーション数をCSVファイルに出力します。

        Args:
            counter_list: タスク単位のアノテーション集計情報のリスト
            output_file: 出力先CSVファイルのパス
            prior_attribute_columns: 優先的に配置する属性値のキーのリスト
        """

        def get_columns() -> list[AttributeValueKey]:
            basic_columns = [
                ("project_id", "", ""),
                ("task_id", "", ""),
                ("task_phase", "", ""),
                ("task_phase_stage", "", ""),
                ("task_status", "", ""),
                ("input_data_count", "", ""),
                ("annotation_count", "", ""),
            ]
            value_columns = self._value_columns(counter_list, prior_attribute_columns)
            return basic_columns + value_columns

        def to_cell(c: AnnotationCounterByTask) -> dict[AttributeValueKey, Any]:
            cell = {
                ("project_id", "", ""): c.project_id,
                ("task_id", "", ""): c.task_id,
                ("task_status", "", ""): c.task_status.value,
                ("task_phase", "", ""): c.task_phase.value,
                ("task_phase_stage", "", ""): c.task_phase_stage,
                ("input_data_count", "", ""): c.input_data_count,
                ("annotation_count", "", ""): c.annotation_count,
            }
            cell.update(c.annotation_count_by_attribute)
            return cell

        columns = get_columns()
        df = pandas.DataFrame([to_cell(e) for e in counter_list], columns=pandas.MultiIndex.from_tuples(columns))

        # `task_id`列など`basic_columns`も`fillna`対象だが、nanではないはずので問題ない
        df.fillna(0, inplace=True)

        print_csv(df, output=output_file)

    def print_csv_by_input_data(
        self,
        counter_list: list[AnnotationCounterByInputData],
        output_file: Path,
        prior_attribute_columns: list[AttributeValueKey] | None = None,
    ) -> None:
        """
        入力データ単位の属性値ごとアノテーション数をCSVファイルに出力します。

        Args:
            counter_list: 入力データ単位のアノテーション集計情報のリスト
            output_file: 出力先CSVファイルのパス
            prior_attribute_columns: 優先的に配置する属性値のキーのリスト
        """

        def get_columns() -> list[AttributeValueKey]:
            basic_columns = [
                ("project_id", "", ""),
                ("task_id", "", ""),
                ("task_phase", "", ""),
                ("task_phase_stage", "", ""),
                ("task_status", "", ""),
                ("input_data_id", "", ""),
                ("input_data_name", "", ""),
                ("frame_no", "", ""),
                ("updated_datetime", "", ""),
                ("annotation_count", "", ""),
            ]
            value_columns = self._value_columns(counter_list, prior_attribute_columns)
            return basic_columns + value_columns

        def to_cell(c: AnnotationCounterByInputData) -> dict[tuple[str, str, str], Any]:
            cell = {
                ("project_id", "", ""): c.project_id,
                ("input_data_id", "", ""): c.input_data_id,
                ("input_data_name", "", ""): c.input_data_name,
                ("frame_no", "", ""): c.frame_no,
                ("updated_datetime", "", ""): c.updated_datetime,
                ("task_id", "", ""): c.task_id,
                ("task_status", "", ""): c.task_status.value,
                ("task_phase", "", ""): c.task_phase.value,
                ("task_phase_stage", "", ""): c.task_phase_stage,
                ("annotation_count", "", ""): c.annotation_count,
            }
            cell.update(c.annotation_count_by_attribute)

            return cell

        columns = get_columns()
        df = pandas.DataFrame([to_cell(e) for e in counter_list], columns=pandas.MultiIndex.from_tuples(columns))

        # アノテーション数の列のNaNを0に変換する
        value_columns = self._value_columns(counter_list, prior_attribute_columns)
        df = df.fillna(dict.fromkeys(value_columns, 0))

        print_csv(df, output=output_file)


class LabelCountCsv:
    """
    ラベルごとのアノテーション数を記載するCSV。


    """

    def _value_columns(self, counter_list: Collection[AnnotationCounter], prior_label_columns: list[str] | None) -> list[str]:
        """
        CSV出力のためのラベル列の順序を決定します。

        Args:
            counter_list: アノテーション集計情報のコレクション
            prior_label_columns: 優先的に配置するラベル名のリスト。Noneの場合はソート順で配置されます。

        Returns:
            ラベル名のリスト（CSV列の順序）
        """
        all_attr_key_set = {attr_key for c in counter_list for attr_key in c.annotation_count_by_label}
        if prior_label_columns is not None:
            remaining_columns = sorted(all_attr_key_set - set(prior_label_columns))
            value_columns = prior_label_columns + remaining_columns
        else:
            remaining_columns = sorted(all_attr_key_set)
            value_columns = remaining_columns

        return value_columns

    def print_csv_by_task(
        self,
        counter_list: list[AnnotationCounterByTask],
        output_file: Path,
        prior_label_columns: list[str] | None = None,
    ) -> None:
        """
        タスク単位のラベルごとアノテーション数をCSVファイルに出力します。

        Args:
            counter_list: タスク単位のアノテーション集計情報のリスト
            output_file: 出力先CSVファイルのパス
            prior_label_columns: 優先的に配置するラベル名のリスト
        """

        def get_columns() -> list[str]:
            basic_columns = [
                "project_id",
                "task_id",
                "task_phase",
                "task_phase_stage",
                "task_status",
                "input_data_count",
                "annotation_count",
            ]
            value_columns = self._value_columns(counter_list, prior_label_columns)
            return basic_columns + value_columns

        def to_dict(c: AnnotationCounterByTask) -> dict[str, Any]:
            d = {
                "project_id": c.project_id,
                "task_id": c.task_id,
                "task_status": c.task_status.value,
                "task_phase": c.task_phase.value,
                "task_phase_stage": c.task_phase_stage,
                "input_data_count": c.input_data_count,
                "annotation_count": c.annotation_count,
            }
            # キーをラベル名、値をラベルごとのアノテーション数にしたdictに変換する
            d.update(c.annotation_count_by_label)
            return d

        df = pandas.DataFrame([to_dict(e) for e in counter_list], columns=get_columns())

        # NaNを0に変換する
        # `basic_columns`は必ずnanではないので、すべての列に対してfillnaを実行しても問題ないはず
        df.fillna(0, inplace=True)
        print_csv(df, output=output_file)

    def print_csv_by_input_data(
        self,
        counter_list: list[AnnotationCounterByInputData],
        output_file: Path,
        prior_label_columns: list[str] | None = None,
    ) -> None:
        """
        入力データ単位のラベルごとアノテーション数をCSVファイルに出力します。

        Args:
            counter_list: 入力データ単位のアノテーション集計情報のリスト
            output_file: 出力先CSVファイルのパス
            prior_label_columns: 優先的に配置するラベル名のリスト
        """

        def get_columns() -> list[str]:
            basic_columns = [
                "project_id",
                "task_id",
                "task_phase",
                "task_phase_stage",
                "task_status",
                "input_data_id",
                "input_data_name",
                "frame_no",
                "updated_datetime",
                "annotation_count",
            ]
            value_columns = self._value_columns(counter_list, prior_label_columns)
            return basic_columns + value_columns

        def to_dict(c: AnnotationCounterByInputData) -> dict[str, Any]:
            d = {
                "project_id": c.project_id,
                "input_data_id": c.input_data_id,
                "input_data_name": c.input_data_name,
                "frame_no": c.frame_no,
                "updated_datetime": c.updated_datetime,
                "task_id": c.task_id,
                "task_status": c.task_status.value,
                "task_phase": c.task_phase.value,
                "task_phase_stage": c.task_phase_stage,
                "annotation_count": c.annotation_count,
            }
            d.update(c.annotation_count_by_label)
            return d

        columns = get_columns()
        df = pandas.DataFrame([to_dict(e) for e in counter_list], columns=columns)

        # アノテーション数列のNaNを0に変換する
        value_columns = self._value_columns(counter_list, prior_label_columns)
        df = df.fillna(dict.fromkeys(value_columns, 0))

        print_csv(df, output=output_file)


class AnnotationSpecs:
    """

    Args:
        annotation_type: 出力対象のラベルの種類。

    """

    def __init__(self, service: annofabapi.Resource, project_id: str, *, annotation_type: str | None = None) -> None:
        self.service = service
        self.project_id = project_id

        annotation_specs, _ = service.api.get_annotation_specs(project_id, query_params={"v": "2"})
        self._annotation_specs = annotation_specs

        labels_v2 = annotation_specs["labels"]
        if annotation_type is not None:
            labels_v2 = [e for e in labels_v2 if e["annotation_type"] == annotation_type]

        self._labels_v1 = convert_annotation_specs_labels_v2_to_v1(labels_v2=labels_v2, additionals_v2=annotation_specs["additionals"])

    def label_keys(self) -> list[str]:
        """ラベル名（英語名）のキーの一覧"""

        def to_label_name(label: dict[str, Any]) -> str:
            label_name_en = AddProps.get_message(label["label_name"], MessageLocale.EN)
            label_name_en = label_name_en if label_name_en is not None else ""
            return label_name_en

        result = [to_label_name(label) for label in self._labels_v1]
        duplicated_labels = [key for key, value in collections.Counter(result).items() if value > 1]
        if len(duplicated_labels) > 0:
            logger.warning(f"アノテーション仕様のラベル英語名が重複しています。アノテーション個数が正しく算出できない可能性があります。:: {duplicated_labels}")
        return result

    def attribute_name_keys(
        self,
        excluded_attribute_types: Collection[AdditionalDataDefinitionType] | None = None,
        include_attribute_types: Collection[AdditionalDataDefinitionType] | None = None,
    ) -> list[tuple[str, str]]:
        """
        属性名の一覧を取得します。

        Args:
            include_attribute_types: 指定した属性の種類に合致した属性名の一覧を取得します。
            excluded_attribute_types: 指定した属性の種類に合致していない属性名の一覧を取得します。

        Raise:
            ValueError: `include_attribute_types`と`excluded_attribute_types`の両方が指定された場合に発生します。
        """
        if excluded_attribute_types is not None and include_attribute_types is not None:
            raise ValueError("`include_attribute_types`と`excluded_attribute_types`の両方が指定されています。")

        result = []
        for label in self._labels_v1:
            label_name_en = AddProps.get_message(label["label_name"], MessageLocale.EN)
            assert label_name_en is not None

            for attribute in label["additional_data_definitions"]:
                if excluded_attribute_types is not None and AdditionalDataDefinitionType(attribute["type"]) in excluded_attribute_types:
                    continue

                if include_attribute_types is not None and AdditionalDataDefinitionType(attribute["type"]) not in include_attribute_types:
                    continue

                attribute_name_en = AddProps.get_message(attribute["name"], MessageLocale.EN)
                assert attribute_name_en is not None
                result.append((label_name_en, attribute_name_en))

        duplicated_attribute_names = [key for key, value in collections.Counter(result).items() if value > 1]
        if len(duplicated_attribute_names) > 0:
            logger.warning(f"アノテーション仕様の属性情報（ラベル英語名、属性英語名）が重複しています。アノテーション個数が正しく算出できない可能性があります。:: {duplicated_attribute_names}")

        return result

    def get_attribute_value_keys_for_target_attributes(self, target_attribute_names: Collection[AttributeNameKey]) -> list[AttributeValueKey]:
        """
        指定された属性名のキーに対応する属性値のキーの一覧を取得します。

        Args:
            target_attribute_names: 属性値のキーを取得する対象の属性名のキー。
        """
        target_attribute_value_keys = []
        target_attribute_names_set = set(target_attribute_names)
        for label in self._labels_v1:
            label_name_en = AddProps.get_message(label["label_name"], MessageLocale.EN)
            label_name_en = label_name_en if label_name_en is not None else ""

            for attribute in label["additional_data_definitions"]:
                attribute_name_en = AddProps.get_message(attribute["name"], MessageLocale.EN)
                attribute_name_en = attribute_name_en if attribute_name_en is not None else ""

                if (label_name_en, attribute_name_en) not in target_attribute_names_set:
                    continue

                attribute_type = AdditionalDataDefinitionType(attribute["type"])
                if attribute_type in [AdditionalDataDefinitionType.CHOICE, AdditionalDataDefinitionType.SELECT]:
                    for choice in attribute["choices"]:
                        choice_name_en = AddProps.get_message(choice["name"], MessageLocale.EN)
                        choice_name_en = choice_name_en if choice_name_en is not None else ""
                        target_attribute_value_keys.append((label_name_en, attribute_name_en, choice_name_en))

                elif attribute_type == AdditionalDataDefinitionType.FLAG:
                    target_attribute_value_keys.extend([(label_name_en, attribute_name_en, "true"), (label_name_en, attribute_name_en, "false")])

        return target_attribute_value_keys

    def selective_attribute_value_keys(self) -> list[AttributeValueKey]:
        """
        選択系（ドロップダウン／ラジオボタン／チェックボックス／フラグ）の属性の属性値のキーの一覧。

        対象となる属性種類:
        * ドロップダウン
        * ラジオボタン
        * チェックボックス
        * フラグ
        """
        selective_attribute_names = self.selective_attribute_name_keys()
        target_attribute_value_keys = self.get_attribute_value_keys_for_target_attributes(selective_attribute_names)

        duplicated_attributes = [key for key, value in collections.Counter(target_attribute_value_keys).items() if value > 1]
        if len(duplicated_attributes) > 0:
            logger.warning(
                f"アノテーション仕様の属性情報（ラベル英語名、属性英語名、選択肢英語名）が重複しています。アノテーション個数が正しく算出できない可能性があります。:: {duplicated_attributes}"
            )

        return target_attribute_value_keys

    def selective_attribute_name_keys(self) -> list[AttributeNameKey]:
        """
        選択系の属性の名前のキーの一覧
        * ドロップダウン
        * ラジオボタン
        * チェックボックス
        """
        target_attributes_columns = []
        for label in self._labels_v1:
            label_name_en = AddProps.get_message(label["label_name"], MessageLocale.EN)
            label_name_en = label_name_en if label_name_en is not None else ""

            for attribute in label["additional_data_definitions"]:
                attribute_name_en = AddProps.get_message(attribute["name"], MessageLocale.EN)
                attribute_name_en = attribute_name_en if attribute_name_en is not None else ""

                if AdditionalDataDefinitionType(attribute["type"]) in [
                    AdditionalDataDefinitionType.CHOICE,
                    AdditionalDataDefinitionType.SELECT,
                    AdditionalDataDefinitionType.FLAG,
                ]:
                    target_attributes_columns.append((label_name_en, attribute_name_en))

        return target_attributes_columns

    def get_attribute_name_keys_by_attribute_names(self, attribute_names: Collection[str]) -> tuple[list[AttributeNameKey], list[str]]:
        """
        指定された属性名を持つ全てのラベルと属性の組み合わせを取得します。

        Args:
            attribute_names: 検索対象の属性名のリスト

        Returns:
            (見つかった属性名キーのリスト, 見つからなかった属性名のリスト) のタプル
        """
        attribute_names_set = set(attribute_names)
        result = []
        found_attribute_names = set()
        for label in self._labels_v1:
            label_name_en = AddProps.get_message(label["label_name"], MessageLocale.EN)
            label_name_en = label_name_en if label_name_en is not None else ""

            for attribute in label["additional_data_definitions"]:
                attribute_name_en = AddProps.get_message(attribute["name"], MessageLocale.EN)
                attribute_name_en = attribute_name_en if attribute_name_en is not None else ""

                if attribute_name_en in attribute_names_set:
                    result.append((label_name_en, attribute_name_en))
                    found_attribute_names.add(attribute_name_en)

        not_found_attribute_names = list(attribute_names_set - found_attribute_names)
        return result, not_found_attribute_names

    def non_selective_attribute_name_keys(self) -> list[AttributeNameKey]:
        """
        非選択系の属性の名前のキー
        * トラッキングID
        * 数値
        * テキスト
        * アノテーションリンク


        """
        target_attributes_columns = []
        for label in self._labels_v1:
            label_name_en = AddProps.get_message(label["label_name"], MessageLocale.EN)
            label_name_en = label_name_en if label_name_en is not None else ""

            for attribute in label["additional_data_definitions"]:
                attribute_name_en = AddProps.get_message(attribute["name"], MessageLocale.EN)
                attribute_name_en = attribute_name_en if attribute_name_en is not None else ""

                if AdditionalDataDefinitionType(attribute["type"]) in [
                    AdditionalDataDefinitionType.INTEGER,
                    AdditionalDataDefinitionType.TEXT,
                    AdditionalDataDefinitionType.COMMENT,
                    AdditionalDataDefinitionType.TRACKING,
                    AdditionalDataDefinitionType.LINK,
                ]:
                    target_attributes_columns.append((label_name_en, attribute_name_en))

        return target_attributes_columns


class ListAnnotationCountMain:
    def __init__(self, service: annofabapi.Resource, annotation_specs: AnnotationSpecs) -> None:
        """
        Args:
            service: AnnofabのAPIリソース
            annotation_specs: アノテーション仕様
        """
        self.service = service
        self.annotation_specs = annotation_specs

    @staticmethod
    def get_frame_no_map(task_json_path: Path) -> dict[tuple[str, str], int]:
        """
        タスクJSONファイルから、(task_id, input_data_id)をキーとし、フレーム番号を値とするマップを取得します。
        フレーム番号は1始まりです。

        Args:
            task_json_path: タスクJSONファイルのパス

        Returns:
            key: (task_id, input_data_id)のタプル、value: フレーム番号のdict
        """
        with task_json_path.open(encoding="utf-8") as f:
            task_list = json.load(f)

        result = {}
        for task in task_list:
            task_id = task["task_id"]
            input_data_id_list = task["input_data_id_list"]
            for index, input_data_id in enumerate(input_data_id_list):
                # 画面に合わせて1始まりにする
                result[(task_id, input_data_id)] = index + 1
        return result

    def print_annotation_counter_csv_by_input_data(
        self,
        annotation_path: Path,
        csv_type: CsvType,
        output_file: Path,
        *,
        task_json_path: Path | None = None,
        target_task_ids: Collection[str] | None = None,
        task_query: TaskQuery | None = None,
        additional_attribute_names: Collection[AttributeNameKey] | None = None,
        specified_attribute_names: Collection[AttributeNameKey] | None = None,
    ) -> None:
        """
        ラベルごと/属性ごとのアノテーション数を入力データ単位でCSVファイルに出力します。

        Args:
            annotation_path: アノテーションzipまたはzipを展開したディレクトリのパス
            csv_type: 出力するCSVの種類（ラベルごと/属性ごと）
            output_file: 出力先のCSVファイルパス
            task_json_path: タスクJSONファイルのパス。フレーム番号を出力する場合に指定します。
            target_task_ids: 集計対象のタスクIDのコレクション
            task_query: 集計対象タスクを絞り込むためのクエリ条件
            additional_attribute_names: デフォルトの選択系属性に加えて集計対象とする属性名のキー
            specified_attribute_names: 集計対象とする属性名のキー。指定した場合、これらの属性のみが集計対象になります。

        Raises:
            ValueError: `additional_attribute_names`と`specified_attribute_names`の両方が指定された場合に発生します。
        """
        if additional_attribute_names is not None and specified_attribute_names is not None:
            raise ValueError("`additional_attribute_names`と`specified_attribute_names`の両方が指定されています。")

        if specified_attribute_names is not None:
            # specified_attribute_namesから属性名のみを抽出
            target_attribute_names_only = list({attr_name for _, attr_name in specified_attribute_names})
        elif additional_attribute_names is not None:
            # デフォルトの選択系属性の属性名を取得
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            default_attribute_names = {attr_name for _, attr_name in default_selective_attributes}
            # additional_attribute_namesから属性名のみを抽出
            additional_attr_names = {attr_name for _, attr_name in additional_attribute_names}
            # 両方を組み合わせる
            target_attribute_names_only = list(default_attribute_names | additional_attr_names)
        else:
            # デフォルトでは選択肢系の属性のみを集計対象とする
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            target_attribute_names_only = list({attr_name for _, attr_name in default_selective_attributes})

        frame_no_map = self.get_frame_no_map(task_json_path) if task_json_path is not None else None
        counter_by_input_data = ListAnnotationCounterByInputData(
            target_attribute_names_only=target_attribute_names_only,
            frame_no_map=frame_no_map,
        )
        counter_list_by_input_data = counter_by_input_data.get_annotation_counter_list(
            annotation_path,
            target_task_ids=target_task_ids,
            task_query=task_query,
        )

        if csv_type == CsvType.LABEL:
            # ラベル名の列順が、アノテーション仕様にあるラベル名の順番に対応するようにする。
            label_columns = self.annotation_specs.label_keys()
            LabelCountCsv().print_csv_by_input_data(counter_list_by_input_data, output_file, prior_label_columns=label_columns)
        elif csv_type == CsvType.ATTRIBUTE:
            if specified_attribute_names is not None:
                # 指定された属性名に対応する属性値のキーのみを取得
                attribute_columns = self.annotation_specs.get_attribute_value_keys_for_target_attributes(specified_attribute_names)
            elif additional_attribute_names is not None:
                # デフォルトの選択系属性とadditional_attribute_namesを組み合わせた属性値のキーを取得
                default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
                combined_attributes = list(set(default_selective_attributes) | set(additional_attribute_names))
                attribute_columns = self.annotation_specs.get_attribute_value_keys_for_target_attributes(combined_attributes)
            else:
                attribute_columns = self.annotation_specs.selective_attribute_value_keys()
            AttributeCountCsv().print_csv_by_input_data(counter_list_by_input_data, output_file, prior_attribute_columns=attribute_columns)

    def print_annotation_counter_csv_by_task(
        self,
        annotation_path: Path,
        csv_type: CsvType,
        output_file: Path,
        *,
        target_task_ids: Collection[str] | None = None,
        task_query: TaskQuery | None = None,
        additional_attribute_names: Collection[AttributeNameKey] | None = None,
        specified_attribute_names: Collection[AttributeNameKey] | None = None,
    ) -> None:
        """
        ラベルごと/属性ごとのアノテーション数をタスク単位でCSVファイルに出力します。

        Args:
            annotation_path: アノテーションzipまたはzipを展開したディレクトリのパス
            csv_type: 出力するCSVの種類（ラベルごと/属性ごと）
            output_file: 出力先のCSVファイルパス
            target_task_ids: 集計対象のタスクIDのコレクション
            task_query: 集計対象タスクを絞り込むためのクエリ条件
            additional_attribute_names: デフォルトの選択系属性に加えて集計対象とする属性名のキー
            specified_attribute_names: 集計対象とする属性名のキー。指定した場合、これらの属性のみが集計対象になります。

        Raises:
            ValueError: `additional_attribute_names`と`specified_attribute_names`の両方が指定された場合に発生します。
        """
        if additional_attribute_names is not None and specified_attribute_names is not None:
            raise ValueError("`additional_attribute_names`と`specified_attribute_names`の両方が指定されています。")

        if specified_attribute_names is not None:
            # specified_attribute_namesから属性名のみを抽出
            target_attribute_names_only = list({attr_name for _, attr_name in specified_attribute_names})
        elif additional_attribute_names is not None:
            # デフォルトの選択系属性の属性名を取得
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            default_attribute_names = {attr_name for _, attr_name in default_selective_attributes}
            # additional_attribute_namesから属性名のみを抽出
            additional_attr_names = {attr_name for _, attr_name in additional_attribute_names}
            # 両方を組み合わせる
            target_attribute_names_only = list(default_attribute_names | additional_attr_names)
        else:
            # デフォルトでは選択肢系の属性のみを集計対象とする
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            target_attribute_names_only = list({attr_name for _, attr_name in default_selective_attributes})

        counter_list_by_task = ListAnnotationCounterByTask(
            target_attribute_names_only=target_attribute_names_only,
        ).get_annotation_counter_list(
            annotation_path,
            target_task_ids=target_task_ids,
            task_query=task_query,
        )

        if csv_type == CsvType.LABEL:
            # 列順が、アノテーション仕様にあるラベル名の順番に対応するようにする。
            label_columns = self.annotation_specs.label_keys()
            LabelCountCsv().print_csv_by_task(counter_list_by_task, output_file, prior_label_columns=label_columns)

        elif csv_type == CsvType.ATTRIBUTE:
            # 列順が、アノテーション仕様にある属性名と属性値の順番に対応するようにする。
            if specified_attribute_names is not None:
                # 指定された属性名に対応する属性値のキーのみを取得
                attribute_columns = self.annotation_specs.get_attribute_value_keys_for_target_attributes(specified_attribute_names)
            elif additional_attribute_names is not None:
                # デフォルトの選択系属性とadditional_attribute_namesを組み合わせた属性値のキーを取得
                default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
                combined_attributes = list(set(default_selective_attributes) | set(additional_attribute_names))
                attribute_columns = self.annotation_specs.get_attribute_value_keys_for_target_attributes(combined_attributes)
            else:
                attribute_columns = self.annotation_specs.selective_attribute_value_keys()
            AttributeCountCsv().print_csv_by_task(counter_list_by_task, output_file, prior_attribute_columns=attribute_columns)

    def print_annotation_counter_json_by_input_data(
        self,
        annotation_path: Path,
        output_file: Path,
        *,
        task_json_path: Path | None = None,
        target_task_ids: Collection[str] | None = None,
        task_query: TaskQuery | None = None,
        json_is_pretty: bool = False,
        additional_attribute_names: Collection[AttributeNameKey] | None = None,
        specified_attribute_names: Collection[AttributeNameKey] | None = None,
    ) -> None:
        """
        ラベルごと/属性ごとのアノテーション数を入力データ単位でJSONファイルに出力します。

        Args:
            annotation_path: アノテーションzipまたはzipを展開したディレクトリのパス
            output_file: 出力先のJSONファイルパス
            task_json_path: タスクJSONファイルのパス。フレーム番号を出力する場合に指定します。
            target_task_ids: 集計対象のタスクIDのコレクション
            task_query: 集計対象タスクを絞り込むためのクエリ条件
            json_is_pretty: Trueの場合、整形されたJSON（pretty print）を出力します
            additional_attribute_names: デフォルトの選択系属性に加えて集計対象とする属性名のキー
            specified_attribute_names: 集計対象とする属性名のキー。指定した場合、これらの属性のみが集計対象になります。

        Raises:
            ValueError: `additional_attribute_names`と`specified_attribute_names`の両方が指定された場合に発生します。
        """
        if additional_attribute_names is not None and specified_attribute_names is not None:
            raise ValueError("`additional_attribute_names`と`specified_attribute_names`の両方が指定されています。")

        if specified_attribute_names is not None:
            # specified_attribute_namesから属性名のみを抽出
            target_attribute_names_only = list({attr_name for _, attr_name in specified_attribute_names})
        elif additional_attribute_names is not None:
            # デフォルトの選択系属性の属性名を取得
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            default_attribute_names = {attr_name for _, attr_name in default_selective_attributes}
            # additional_attribute_namesから属性名のみを抽出
            additional_attr_names = {attr_name for _, attr_name in additional_attribute_names}
            # 両方を組み合わせる
            target_attribute_names_only = list(default_attribute_names | additional_attr_names)
        else:
            # デフォルトでは選択肢系の属性のみを集計対象とする
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            target_attribute_names_only = list({attr_name for _, attr_name in default_selective_attributes})

        frame_no_map = self.get_frame_no_map(task_json_path) if task_json_path is not None else None
        counter_by_input_data = ListAnnotationCounterByInputData(
            target_attribute_names_only=target_attribute_names_only,
            frame_no_map=frame_no_map,
        )
        counter_list_by_input_data = counter_by_input_data.get_annotation_counter_list(
            annotation_path,
            target_task_ids=target_task_ids,
            task_query=task_query,
        )

        print_json(
            [e.to_dict(encode_json=True) for e in counter_list_by_input_data],
            is_pretty=json_is_pretty,
            output=output_file,
        )

    def print_annotation_counter_json_by_task(
        self,
        annotation_path: Path,
        output_file: Path,
        *,
        target_task_ids: Collection[str] | None = None,
        task_query: TaskQuery | None = None,
        json_is_pretty: bool = False,
        additional_attribute_names: Collection[AttributeNameKey] | None = None,
        specified_attribute_names: Collection[AttributeNameKey] | None = None,
    ) -> None:
        """
        ラベルごと/属性ごとのアノテーション数をタスク単位でJSONファイルに出力します。

        Args:
            annotation_path: アノテーションzipまたはzipを展開したディレクトリのパス
            output_file: 出力先のJSONファイルパス
            target_task_ids: 集計対象のタスクIDのコレクション
            task_query: 集計対象タスクを絞り込むためのクエリ条件
            json_is_pretty: Trueの場合、整形されたJSON（pretty print）を出力します
            additional_attribute_names: デフォルトの選択系属性に加えて集計対象とする属性名のキー
            specified_attribute_names: 集計対象とする属性名のキー。指定した場合、これらの属性のみが集計対象になります。

        Raises:
            ValueError: `additional_attribute_names`と`specified_attribute_names`の両方が指定された場合に発生します。
        """
        if additional_attribute_names is not None and specified_attribute_names is not None:
            raise ValueError("`additional_attribute_names`と`specified_attribute_names`の両方が指定されています。")

        if specified_attribute_names is not None:
            # specified_attribute_namesから属性名のみを抽出
            target_attribute_names_only = list({attr_name for _, attr_name in specified_attribute_names})
        elif additional_attribute_names is not None:
            # デフォルトの選択系属性の属性名を取得
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            default_attribute_names = {attr_name for _, attr_name in default_selective_attributes}
            # additional_attribute_namesから属性名のみを抽出
            additional_attr_names = {attr_name for _, attr_name in additional_attribute_names}
            # 両方を組み合わせる
            target_attribute_names_only = list(default_attribute_names | additional_attr_names)
        else:
            # デフォルトでは選択肢系の属性のみを集計対象とする
            default_selective_attributes = self.annotation_specs.selective_attribute_name_keys()
            target_attribute_names_only = list({attr_name for _, attr_name in default_selective_attributes})

        counter_list_by_task = ListAnnotationCounterByTask(
            target_attribute_names_only=target_attribute_names_only,
        ).get_annotation_counter_list(
            annotation_path,
            target_task_ids=target_task_ids,
            task_query=task_query,
        )

        print_json(
            [e.to_dict(encode_json=True) for e in counter_list_by_task],
            is_pretty=json_is_pretty,
            output=output_file,
        )

    def print_annotation_counter(
        self,
        annotation_path: Path,
        group_by: GroupBy,
        output_file: Path,
        arg_format: OutputFormat,
        *,
        task_json_path: Path | None = None,
        target_task_ids: Collection[str] | None = None,
        task_query: TaskQuery | None = None,
        csv_type: CsvType | None = None,
        additional_attribute_names: Collection[AttributeNameKey] | None = None,
        specified_attribute_names: Collection[AttributeNameKey] | None = None,
    ) -> None:
        """
        ラベルごと/属性ごとのアノテーション数を出力します。

        Args:
            annotation_path: アノテーションzipまたはzipを展開したディレクトリのパス
            group_by: 集計単位（タスク単位または入力データ単位）
            output_file: 出力先ファイルのパス
            arg_format: 出力形式（CSV、JSON、整形済みJSON）
            task_json_path: タスクJSONファイルのパス。フレーム番号を出力する場合に指定します。
            target_task_ids: 集計対象のタスクIDのコレクション
            task_query: 集計対象タスクを絞り込むためのクエリ条件
            csv_type: CSV出力時の種類（ラベルごと/属性ごと）。CSV形式の場合は必須です。
            additional_attribute_names: デフォルトの選択系属性に加えて集計対象とする属性名のキー
            specified_attribute_names: 集計対象とする属性名のキー。指定した場合、これらの属性のみが集計対象になります。
        """
        if arg_format == OutputFormat.CSV:
            assert csv_type is not None
            if group_by == GroupBy.INPUT_DATA_ID:
                self.print_annotation_counter_csv_by_input_data(
                    annotation_path=annotation_path,
                    task_json_path=task_json_path,
                    output_file=output_file,
                    csv_type=csv_type,
                    target_task_ids=target_task_ids,
                    task_query=task_query,
                    additional_attribute_names=additional_attribute_names,
                    specified_attribute_names=specified_attribute_names,
                )

            elif group_by == GroupBy.TASK_ID:
                self.print_annotation_counter_csv_by_task(
                    annotation_path=annotation_path,
                    output_file=output_file,
                    csv_type=csv_type,
                    target_task_ids=target_task_ids,
                    task_query=task_query,
                    additional_attribute_names=additional_attribute_names,
                    specified_attribute_names=specified_attribute_names,
                )

        elif arg_format in [OutputFormat.PRETTY_JSON, OutputFormat.JSON]:
            json_is_pretty = arg_format == OutputFormat.PRETTY_JSON

            if group_by == GroupBy.INPUT_DATA_ID:
                self.print_annotation_counter_json_by_input_data(
                    annotation_path=annotation_path,
                    task_json_path=task_json_path,
                    output_file=output_file,
                    target_task_ids=target_task_ids,
                    task_query=task_query,
                    json_is_pretty=json_is_pretty,
                    additional_attribute_names=additional_attribute_names,
                    specified_attribute_names=specified_attribute_names,
                )

            elif group_by == GroupBy.TASK_ID:
                self.print_annotation_counter_json_by_task(
                    annotation_path=annotation_path,
                    output_file=output_file,
                    target_task_ids=target_task_ids,
                    task_query=task_query,
                    json_is_pretty=json_is_pretty,
                    additional_attribute_names=additional_attribute_names,
                    specified_attribute_names=specified_attribute_names,
                )


class ListAnnotationCount(CommandLine):
    """
    アノテーション数情報を出力する。
    """

    def main(self) -> None:
        """
        アノテーション数情報を出力するメイン処理。
        コマンドライン引数を解析し、アノテーションzip/ディレクトリから集計情報を取得して、
        指定された形式（CSV/JSON）で出力します。
        """
        args = self.args

        project_id: str = args.project_id
        super().validate_project(project_id, project_member_roles=[ProjectMemberRole.OWNER, ProjectMemberRole.TRAINING_DATA_USER])

        annotation_path = args.annotation

        task_id_list = annofabcli.common.cli.get_list_from_args(args.task_id) if args.task_id is not None else None
        task_query = TaskQuery.from_dict(annofabcli.common.cli.get_json_from_args(args.task_query)) if args.task_query is not None else None

        # アノテーション仕様を取得
        annotation_specs = AnnotationSpecs(self.service, project_id)

        additional_attribute_names: list[AttributeNameKey] | None = None
        specified_attribute_names: list[AttributeNameKey] | None = None

        if args.additional_attribute_name is not None:
            attribute_name_str_list = annofabcli.common.cli.get_list_from_args(args.additional_attribute_name)
            # アノテーション仕様から属性名を検索してAttributeNameKeyのリストに変換
            additional_attribute_names, not_found_names = annotation_specs.get_attribute_name_keys_by_attribute_names(attribute_name_str_list)
            if len(not_found_names) > 0:
                logger.warning(f"指定された属性名のうち、アノテーション仕様に見つからなかった属性名があります。 :: {not_found_names}")
        elif args.attribute_name is not None:
            attribute_name_str_list = annofabcli.common.cli.get_list_from_args(args.attribute_name)
            # アノテーション仕様から属性名を検索してAttributeNameKeyのリストに変換
            specified_attribute_names, not_found_names = annotation_specs.get_attribute_name_keys_by_attribute_names(attribute_name_str_list)
            if len(not_found_names) > 0:
                logger.warning(f"指定された属性名のうち、アノテーション仕様に見つからなかった属性名があります。 :: {not_found_names}")

        group_by = GroupBy(args.group_by)
        csv_type = CsvType(args.type)
        output_file: Path = args.output
        arg_format = OutputFormat(args.format)
        main_obj = ListAnnotationCountMain(self.service, annotation_specs)

        downloading_obj = DownloadingFile(self.service)

        def download_and_process_annotation(temp_dir: Path, *, is_latest: bool, annotation_path: Path | None) -> None:
            # タスク全件ファイルは、group_by=input_data_idの場合のみフレーム番号を参照するのに利用する
            task_json_path: Path | None = None
            if group_by == GroupBy.INPUT_DATA_ID:
                task_json_path = downloading_obj.download_task_json_to_dir(
                    project_id,
                    temp_dir,
                    is_latest=is_latest,
                )

            func = partial(
                main_obj.print_annotation_counter,
                task_json_path=task_json_path,
                group_by=group_by,
                csv_type=csv_type,
                arg_format=arg_format,
                output_file=output_file,
                target_task_ids=task_id_list,
                task_query=task_query,
                additional_attribute_names=additional_attribute_names,
                specified_attribute_names=specified_attribute_names,
            )

            if annotation_path is None:
                annotation_path = downloading_obj.download_annotation_zip_to_dir(
                    project_id,
                    temp_dir,
                    is_latest=is_latest,
                )
                func(annotation_path=annotation_path)
            else:
                func(annotation_path=annotation_path)

        if args.temp_dir is not None:
            download_and_process_annotation(temp_dir=args.temp_dir, is_latest=args.latest, annotation_path=annotation_path)
        else:
            with tempfile.TemporaryDirectory() as str_temp_dir:
                download_and_process_annotation(temp_dir=Path(str_temp_dir), is_latest=args.latest, annotation_path=annotation_path)


def parse_args(parser: argparse.ArgumentParser) -> None:
    """
    コマンドライン引数のパーサーを設定します。

    Args:
        parser: argparseのArgumentParserインスタンス
    """
    argument_parser = ArgumentParser(parser)

    parser.add_argument(
        "--annotation",
        type=Path,
        help="アノテーションzip、またはzipを展開したディレクトリを指定します。指定しない場合はAnnofabからダウンロードします。",
    )

    argument_parser.add_project_id()

    parser.add_argument(
        "--group_by",
        type=str,
        choices=[GroupBy.TASK_ID.value, GroupBy.INPUT_DATA_ID.value],
        default=GroupBy.TASK_ID.value,
        help="アノテーションの個数をどの単位で集約するかを指定してます。",
    )

    parser.add_argument(
        "--type",
        type=str,
        choices=[e.value for e in CsvType],
        default=CsvType.LABEL.value,
        help="出力するCSVの種類を指定してください。 ``--format csv`` を指定したときのみ有効なオプションです。\n"
        "\n"
        "* label: ラベルごとにアノテーション数が記載されているCSV\n"
        "* attribute: 属性値ごとにアノテーション数が記載されているCSV",
    )

    argument_parser.add_format(
        choices=[OutputFormat.CSV, OutputFormat.JSON, OutputFormat.PRETTY_JSON],
        default=OutputFormat.CSV,
    )

    argument_parser.add_output()

    parser.add_argument(
        "-tq",
        "--task_query",
        type=str,
        help="集計対象タスクを絞り込むためのクエリ条件をJSON形式で指定します。使用できるキーは task_id, status, phase, phase_stage です。"
        " ``file://`` を先頭に付けると、JSON形式のファイルを指定できます。",
    )
    argument_parser.add_task_id(required=False)

    parser.add_argument(
        "--latest",
        action="store_true",
        help="``--annotation`` を指定しないとき、最新のアノテーションzipを参照します。このオプションを指定すると、アノテーションzipを更新するのに数分待ちます。",
    )

    parser.add_argument(
        "--temp_dir",
        type=Path,
        help="指定したディレクトリに、アノテーションZIPなどの一時ファイルをダウンロードします。",
    )

    # --attribute_nameと--additional_attribute_nameは排他的
    attribute_group = parser.add_mutually_exclusive_group()
    attribute_group.add_argument(
        "--additional_attribute_name",
        type=str,
        nargs="+",
        help="デフォルトで集計される選択肢系の属性（ドロップダウン、ラジオボタン、チェックボックス）に加えて、集計したい属性の英語名を指定します。"
        "ラベル名に関係なく、デフォルト属性と指定した属性名を持つ属性が集計対象になります。"
        " ``file://`` を先頭に付けると、属性名が記載されたファイルを指定できます。"
        " ``--type attribute`` を指定したときのみ有効なオプションです。",
    )

    attribute_group.add_argument(
        "--attribute_name",
        type=str,
        nargs="+",
        help="集計対象とする属性の英語名を指定します。指定した属性名のみが集計対象になります（デフォルトの選択肢系属性は含まれません）。"
        "ラベル名に関係なく、指定した属性名を持つ属性のみが集計対象になります。"
        " ``file://`` を先頭に付けると、属性名が記載されたファイルを指定できます。"
        " ``--type attribute`` を指定したときのみ有効なオプションです。",
    )

    parser.set_defaults(subcommand_func=main)


def main(args: argparse.Namespace) -> None:
    """
    list_annotation_countコマンドのエントリーポイント。

    Args:
        args: コマンドライン引数
    """
    service = build_annofabapi_resource_and_login(args)
    facade = AnnofabApiFacade(service)
    ListAnnotationCount(service, facade, args).main()


def add_parser(subparsers: argparse._SubParsersAction | None = None) -> argparse.ArgumentParser:
    """
    list_annotation_countサブコマンドのパーサーを追加します。

    Args:
        subparsers: 親パーサーのサブパーサーアクション

    Returns:
        作成されたArgumentParserインスタンス
    """
    subcommand_name = "list_annotation_count"
    subcommand_help = "ラベルごとまたは属性値ごとにアノテーション数を出力します。"
    epilog = "オーナロールまたはアノテーションユーザロールを持つユーザで実行してください。"
    parser = annofabcli.common.cli.add_parser(subparsers, subcommand_name, subcommand_help, description=subcommand_help, epilog=epilog)
    parse_args(parser)
    return parser
