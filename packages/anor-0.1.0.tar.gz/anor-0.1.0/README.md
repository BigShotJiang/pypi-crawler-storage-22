# Anor CLI

Managed GPU compute made simple.

## Installation

```bash
pip install anor
```

## Quick Start

```bash
# Login to your account
anor login

# Run a training job
anor run --grade standard --gpus 8 --max-rate 2.20 "python train.py"

# List your jobs
anor jobs list

# Get job logs
anor jobs logs <job-id>

# View pricing
anor pricing
```

## Commands

| Command | Description |
|---------|-------------|
| `anor login` | Login and store credentials |
| `anor logout` | Clear stored credentials |
| `anor whoami` | Show current user |
| `anor run` | Submit a compute job |
| `anor jobs list` | List your jobs |
| `anor jobs get <id>` | Get job details |
| `anor jobs logs <id>` | Get job logs |
| `anor jobs cancel <id>` | Cancel a job |
| `anor pricing` | Show current pricing |

## Compute Grades

| Grade | Price | GPU Types |
|-------|-------|-----------|
| Standard | $1.80/GPU/hr | T4, V100, L4 |
| Performance | $2.50/GPU/hr | A100, A100-80GB |
| Premium | $4.00/GPU/hr | H100, H200, B200 |

## Documentation

https://docs.anor.cloud
