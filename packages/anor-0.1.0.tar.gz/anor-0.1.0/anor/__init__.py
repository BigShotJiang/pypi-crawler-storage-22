"""Anor Cloud GPU CLI"""
__version__ = "0.1.0"
