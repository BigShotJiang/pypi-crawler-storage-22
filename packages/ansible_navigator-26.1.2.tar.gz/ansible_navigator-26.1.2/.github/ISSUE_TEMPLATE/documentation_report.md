---
name: "📝 Documentation Report"
about: Ask us about docs
labels: documentation, new
---

<!-- Issues are for **concrete, actionable bugs and feature requests** only - if you're just asking for debugging help or technical support, please use:

TODO: Add ansible-navigator specific channels

We have to limit this because of limited volunteer time to respond to issues! -->

##### ISSUE TYPE

- Doc issue

##### SUMMARY

<!-- Explain the problem briefly below, add suggestions to wording or structure. -->
