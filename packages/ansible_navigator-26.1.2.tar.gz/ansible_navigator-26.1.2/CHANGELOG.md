# Changelog

All notable changes to Ansible Navigator will be documented in this file.

Please see the [release notes](https://github.com/ansible/ansible-navigator/releases)
