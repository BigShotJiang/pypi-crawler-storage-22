<p align="center">
<a href="https://t.me/rktechnoindians"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>

<a name="readme-top"></a>


# ANSILIBX


<p align="center"> 
<a href="https://t.me/rktechnoindians"><img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=800&size=35&pause=1000&color=F74848&center=true&vCenter=true&random=false&width=435&lines=ANSILIBX" /></a>
 </p>


Installation Method
-------
**💢 Requirement PKG 💢**

```bash
pkg install python -y
```

**💢 PYPI 💢**

    pip install ANSILIBX

[![PyPI](https://img.shields.io/badge/pypi-3776AB?style=for-the-badge&logo=python&logoColor=FFD43B)](https://pypi.org/project/ANSILIBX) [![Version](https://img.shields.io/pypi/v/ANSILIBX?label=&style=for-the-badge&color=FF8C00&labelColor=FF8C00)](https://pypi.org/project/ANSILIBX)


Uninstall ApkPatcher
-----

    pip uninstall ANSILIBX


# Usage ANSI Library Example


ANSILIBX
-----

**First Import Library : `from ANSILIBX.ANSI import C`**

# ===== BASIC COLORS =====
    print(f"{C.R}")    # RED
    print(f"{C.G}")    # GREEN
    print(f"{C.Y}")    # YELLOW
    print(f"{C.B}")    # BLUE
    print(f"{C.P}")    # PURPLE
    print(f"{C.C}")    # CYAN
    print(f"{C.W}")    # WHITE

# ===== BRIGHT COLORS =====
    print(f"{C.BR}")   # BRIGHT RED
    print(f"{C.BG}")   # BRIGHT GREEN
    print(f"{C.BY}")   # BRIGHT YELLOW
    print(f"{C.BB}")   # BRIGHT BLUE
    print(f"{C.BP}")   # BRIGHT PURPLE
    print(f"{C.BC}")   # BRIGHT CYAN
    print(f"{C.BW}")   # BRIGHT WHITE

# ===== OTHER COLORS =====
    print(f"{C.DG}")   # DARK GREEN
    print(f"{C.GR}")   # GRAY

# ===== 256 COLORS =====
    print(f"{C.PN}")   # PINK
    print(f"{C.OG}")   # ORANGE

# ===== CLEAR CODES =====
    print(f"{C.CL}")   # CLEAR LINE
    print(f"{C.CC}")   # CLEAR COLOR

# ===== TAGS =====
    print(f"{C.S} INFORMATION {C.E}")   # [ INFORMATION ]
    print(f"{C.X}")        # [ * ]
    print(f"{C.FYI}")      # [ FYI ]
    print(f"{C.INFO}")     # [ INFO ]
    print(f"{C.WARN}")     # [ WARN ]
    print(f"{C.ERROR}")    # [ ERROR ]
    print(f"{C.SUGGEST}")  # [ SUGGEST ]


# CREDITS


## 🇮🇳 Welcome By Techno India 🇮🇳

[![Telegram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://t.me/rktechnoindians)
  </a><p>
[![Telegram](https://img.shields.io/badge/TELEGRAM-OWNER-red?style=for-the-badge&logo=telegram)](https://t.me/RK_TECHNO_INDIA)
</p>