# CHANGELOG

This project uses [towncrier](https://towncrier.readthedocs.io/) to generate
changelogs.

Refer to the [raw release notes](doc/source/changelog.rst) for more
information.

[Published release
notes](https://tools.docs.pyansys.com/version/stable/changelog.html) can be
found in the online documentation.
