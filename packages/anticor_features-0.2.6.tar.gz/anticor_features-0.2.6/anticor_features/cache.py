from __future__ import annotations

import gzip
import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def _default_cache_dir() -> Path:
    base = os.environ.get("XDG_CACHE_HOME")
    if base:
        return Path(base) / "anticor_features"
    return Path.home() / ".cache" / "anticor_features"


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("wb", delete=False, dir=str(path.parent)) as tmp:
        tmp.write(data)
        tmp.flush()
        os.fsync(tmp.fileno())
        tmp_path = Path(tmp.name)
    tmp_path.replace(path)


def _atomic_write_text(path: Path, text: str) -> None:
    _atomic_write_bytes(path, text.encode("utf-8"))


@dataclass(frozen=True)
class DiskCache:
    root: Path | None = None

    def __post_init__(self) -> None:
        if self.root is None:
            object.__setattr__(self, "root", _default_cache_dir())

    def _key_to_paths(self, namespace: str, key: str) -> tuple[Path, Path]:
        safe_ns = namespace.replace("/", "_")
        base = Path(self.root) / safe_ns / key
        return base.with_suffix(".json.gz"), base.with_suffix(".meta.json")

    def get_json(self, namespace: str, payload: dict[str, Any]) -> dict[str, Any] | None:
        key = _sha256_bytes(json.dumps(payload, sort_keys=True).encode("utf-8"))
        data_path, meta_path = self._key_to_paths(namespace, key)
        if not data_path.exists() or not meta_path.exists():
            return None
        with gzip.open(data_path, "rt", encoding="utf-8") as fh:
            return json.load(fh)

    def put_json(self, namespace: str, payload: dict[str, Any], response: dict[str, Any]) -> None:
        key = _sha256_bytes(json.dumps(payload, sort_keys=True).encode("utf-8"))
        data_path, meta_path = self._key_to_paths(namespace, key)
        meta = {
            "namespace": namespace,
            "key": key,
            "payload_sha256": _sha256_bytes(json.dumps(payload, sort_keys=True).encode("utf-8")),
            "response_sha256": _sha256_bytes(json.dumps(response, sort_keys=True).encode("utf-8")),
        }
        _atomic_write_text(meta_path, json.dumps(meta, indent=2, sort_keys=True) + "\n")
        with gzip.open(data_path, "wb") as fh:
            fh.write(json.dumps(response, sort_keys=True).encode("utf-8"))

