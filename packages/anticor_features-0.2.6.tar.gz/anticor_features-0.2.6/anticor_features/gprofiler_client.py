from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests

from .cache import DiskCache


class OfflineModeError(RuntimeError):
    pass


@dataclass(frozen=True)
class GProfilerClient:
    base_url: str = "https://biit.cs.ut.ee/gprofiler"
    timeout_s: float = 30.0
    offline_mode: bool = False
    cache: DiskCache | None = None

    def _post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        if self.cache is not None:
            cached = self.cache.get_json(path, payload)
            if cached is not None:
                return cached
        if self.offline_mode:
            raise OfflineModeError(
                "offline_mode=True and cache miss for g:Profiler request. "
                "Run once with network access to warm the cache, or generate an ID bank."
            )
        url = self.base_url.rstrip("/") + path
        resp = requests.post(url=url, json=payload, timeout=self.timeout_s)
        resp.raise_for_status()
        data = resp.json()
        if self.cache is not None:
            self.cache.put_json(path, payload, data)
        return data

    def organisms_list(self) -> dict[str, Any]:
        if self.offline_mode:
            raise OfflineModeError(
                "offline_mode=True: cannot fetch organisms_list. "
                "Provide a cached response or a pinned organisms snapshot."
            )
        url = self.base_url.rstrip("/") + "/api/util/organisms_list"
        resp = requests.get(url=url, timeout=self.timeout_s)
        resp.raise_for_status()
        return resp.json()

    def data_versions(self) -> dict[str, Any]:
        # util endpoint is a GET in current g:Profiler API.
        if self.offline_mode:
            raise OfflineModeError(
                "offline_mode=True: cannot fetch data_versions. "
                "Provide a cached response or pin versions in your artifacts."
            )
        url = self.base_url.rstrip("/") + "/api/util/data_versions"
        resp = requests.get(url=url, timeout=self.timeout_s)
        resp.raise_for_status()
        return resp.json()

    def convert_terms_to_ensembl(self, organism: str, terms: list[str]) -> dict[str, Any]:
        """
        Calls g:Profiler g:Convert endpoint with term IDs (e.g., GO:...).

        The API may return additional fields (e.g., name) depending on server version.
        """
        payload = {"organism": organism, "target": "ENSG", "query": terms}
        return self._post_json("/api/convert/convert/", payload)

    def convert_ids(self, organism: str, target: str, query: list[str]) -> dict[str, Any]:
        payload = {"organism": organism, "target": target, "query": query}
        return self._post_json("/api/convert/convert/", payload)
