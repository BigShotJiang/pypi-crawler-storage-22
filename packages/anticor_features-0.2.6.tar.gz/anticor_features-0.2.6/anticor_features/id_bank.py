from __future__ import annotations

import csv
import gzip
import os
from dataclasses import dataclass
from pathlib import Path


class IdBankNotFoundError(FileNotFoundError):
    pass


@dataclass(frozen=True)
class IdBank:
    root: Path

    @staticmethod
    def packaged_root() -> Path:
        return Path(__file__).parent / "resources" / "id_bank"

    def species_dir(self, species: str) -> Path:
        return self.root / species

    def remove_genes_path(self, species: str) -> Path:
        return self.species_dir(species) / "remove_genes.tsv.gz"

    def remove_genes_manifest_path(self, species: str) -> Path:
        return self.species_dir(species) / "remove_genes.manifest.json"

    def load_remove_gene_set(self, species: str) -> set[str]:
        """
        Returns a set of identifiers to remove (uppercased).

        The remove-gene bank is intended to support typical single-cell inputs where
        feature IDs are either gene symbols (e.g. "RPLP0") or Ensembl gene IDs
        (e.g. "ENSG000001..."). This is not a full universal ID converter.
        """
        path = self.remove_genes_path(species)
        if not path.exists():
            raise IdBankNotFoundError(
                f"ID bank not found for species={species!r}. Expected: {path}"
            )

        remove_ids: set[str] = set()
        with gzip.open(path, "rt", encoding="utf-8", newline="") as fh:
            reader = csv.DictReader(fh, delimiter="\t")
            for row in reader:
                for key in ("gene_symbol", "ensembl_gene_id"):
                    value = (row.get(key) or "").strip()
                    if value:
                        remove_ids.add(value.upper())
        return remove_ids


def get_default_id_bank(bank_dir: str | Path | None = None) -> IdBank:
    if bank_dir is None:
        env_dir = os.environ.get("ANTICOR_FEATURES_ID_BANK_DIR")
        if env_dir:
            root = Path(env_dir)
        else:
            root = IdBank.packaged_root()
    else:
        root = Path(bank_dir)
    return IdBank(root=root)
