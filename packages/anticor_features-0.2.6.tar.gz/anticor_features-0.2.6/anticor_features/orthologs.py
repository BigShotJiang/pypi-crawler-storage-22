from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests

from .cache import DiskCache


class OrthologMappingError(RuntimeError):
    pass


@dataclass(frozen=True)
class EnsemblOrthologMapper:
    """
    Minimal Ensembl REST ortholog mapper intended for small/rare use.

    This is *not* designed for mapping tens of thousands of features at runtime.
    Prefer generating a per-species ID bank offline.
    """

    base_url: str = "https://rest.ensembl.org"
    timeout_s: float = 30.0
    offline_mode: bool = False
    cache: DiskCache | None = None

    def _get_json(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        cache_payload = {"path": path, "params": params}
        if self.cache is not None:
            cached = self.cache.get_json("ensembl_rest_get", cache_payload)
            if cached is not None:
                return cached
        if self.offline_mode:
            raise OrthologMappingError(
                "offline_mode=True and cache miss for Ensembl REST request. "
                "Precompute/seed caches or generate an ID bank for your species."
            )
        url = self.base_url.rstrip("/") + path
        resp = requests.get(
            url=url,
            params=params,
            timeout=self.timeout_s,
            headers={"Accept": "application/json", "User-Agent": "anticor_features"},
        )
        resp.raise_for_status()
        data = resp.json()
        if self.cache is not None:
            self.cache.put_json("ensembl_rest_get", cache_payload, data)
        return data

    def symbol_to_human_ensg(self, species: str, symbol: str) -> str | None:
        """
        Returns the first human Ensembl gene ID (ENSG...) ortholog for the given symbol.
        """
        payload = self._get_json(
            f"/homology/symbol/{species}/{symbol}",
            params={"target_species": "human", "type": "orthologues", "format": "condensed"},
        )
        data = payload.get("data") or []
        if not data:
            return None
        homologies = data[0].get("homologies") or []
        for h in homologies:
            target = h.get("target") or {}
            target_id = target.get("id") or target.get("stable_id") or ""
            if isinstance(target_id, str) and target_id.startswith("ENSG"):
                return target_id
        return None


def map_symbols_to_human_ensg(
    *,
    species: str,
    symbols: list[str],
    offline_mode: bool = False,
    cache_dir: str | None = None,
    timeout_s: float = 30.0,
) -> dict[str, str | None]:
    cache = DiskCache(root=cache_dir) if cache_dir is not None else None
    if offline_mode and cache is None:
        raise OrthologMappingError("offline_mode=True requires cache_dir to be set for Ensembl ortholog mapping.")
    mapper = EnsemblOrthologMapper(timeout_s=timeout_s, offline_mode=offline_mode, cache=cache)
    out: dict[str, str | None] = {}
    for sym in symbols:
        out[sym] = mapper.symbol_to_human_ensg(species, sym)
    return out
