# ID Bank

This directory can hold precomputed, offline-friendly identifier “banks” per species.

## Purpose

`anticor_features` historically used g:Profiler at runtime to resolve pathway/GO terms into genes to remove (mitochondrial/ribosomal/etc.). That breaks on offline/HPC nodes and makes results harder to reproduce across g:Profiler database updates.

An ID bank lets `get_anti_cor_genes(..., offline_mode=True)` remove default pathway genes without any network access.

## Layout

Each species has its own directory:

```
anticor_features/resources/id_bank/{species}/
  remove_genes.tsv.gz
  remove_genes.manifest.json
```

`remove_genes.tsv.gz` is a TSV with (at least) these columns:

- `ensembl_gene_id`
- `gene_symbol`
- `source_term` (e.g., GO term)
- `category` (mitochondrial / ribosomal / ...)

Only `ensembl_gene_id` and `gene_symbol` are used at runtime.

## Generating banks

See `ROADMAP.md` for the detailed plan. The generator script is intended to run in an environment with network access; this repo’s execution sandbox may not have DNS/network connectivity.

## Shipped banks

This package may ship a small curated set of banks so default pathway removal works offline out of the box:

- `hsapiens`
- `mmusculus`

You can regenerate or extend these locally with:

```bash
python3 scripts/build_id_bank.py --species hsapiens --provider ncbi --out_dir anticor_features/resources/id_bank --force
```
