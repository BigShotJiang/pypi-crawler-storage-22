#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import os
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from anticor_features.cache import DiskCache
    from anticor_features.gprofiler_client import GProfilerClient
except ModuleNotFoundError:
    REPO_ROOT = Path(__file__).resolve().parents[1]
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from anticor_features.cache import DiskCache
    from anticor_features.gprofiler_client import GProfilerClient


DEFAULT_REMOVE_TERMS = [
    "GO:0044429",
    "GO:0006390",
    "GO:0005739",
    "GO:0005743",
    "GO:0070125",
    "GO:0070126",
    "GO:0005759",
    "GO:0032543",
    "GO:0044455",
    "GO:0005761",
    "GO:0005840",
    "GO:0003735",
    "GO:0022626",
    "GO:0044391",
    "GO:0006614",
    "GO:0006613",
    "GO:0045047",
    "GO:0000184",
    "GO:0043043",
    "GO:0006413",
    "GO:0022613",
    "GO:0043604",
    "GO:0015934",
    "GO:0006415",
    "GO:0015935",
    "GO:0072599",
    "GO:0071826",
    "GO:0042254",
    "GO:0042273",
    "GO:0042274",
    "GO:0006364",
    "GO:0022618",
    "GO:0005730",
    "GO:0005791",
    "GO:0098554",
    "GO:0019843",
    "GO:0030492",
]

DEFAULT_SPECIES_TO_TAX_ID = {
    "hsapiens": 9606,
    "mmusculus": 10090,
    "rnorvegicus": 10116,
    "drerio": 7955,
    "celegans": 6239,
    "dmelanogaster": 7227,
    "scerevisiae": 559292,
}


def _sha256_str(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class BankManifest:
    species: str
    created_at_utc: str
    base_url: str
    data_versions: dict[str, Any] | None
    remove_terms: list[str]
    remove_terms_sha256: str
    generator: str


def _write_gz_tsv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, delimiter="\t", fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _write_json(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _iter_organism_codes(organisms_payload: Any) -> list[str]:
    """
    g:Profiler util/organisms_list response is usually a JSON array of objects.
    Some deployments may wrap in {"result": [...]}.
    """
    raw: Any
    if isinstance(organisms_payload, dict) and "result" in organisms_payload:
        raw = organisms_payload["result"]
    else:
        raw = organisms_payload
    if not isinstance(raw, list):
        raise ValueError("Unexpected organisms_list schema; expected list or {'result': list}.")
    codes: list[str] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        code = (item.get("name") or item.get("organism") or "").strip()
        if code:
            codes.append(code)
    return sorted(set(codes))


def build_remove_genes_bank(
    *,
    species: str,
    out_dir: Path,
    base_url: str,
    cache_dir: Path | None,
    timeout_s: float,
    remove_terms: list[str],
    force: bool = False,
) -> None:
    cache = DiskCache(root=cache_dir) if cache_dir is not None else None
    client = GProfilerClient(base_url=base_url, timeout_s=timeout_s, offline_mode=False, cache=cache)

    # Best-effort: record g:Profiler data versions (may change over time).
    data_versions: dict[str, Any] | None
    try:
        data_versions = client.data_versions()
    except Exception:
        data_versions = None

    # Resolve GO terms → Ensembl IDs via g:Convert.
    raw = client.convert_terms_to_ensembl(organism=species, terms=remove_terms)
    result = raw.get("result") or []

    # The API schema varies across versions; use resilient field extraction.
    rows: list[dict[str, str]] = []
    for item in result:
        if not isinstance(item, dict):
            continue
        ensembl_gene_id = (item.get("converted") or "").strip()
        gene_symbol = (item.get("name") or "").strip()
        source_term = (item.get("incoming") or "").strip()
        if not ensembl_gene_id and not gene_symbol:
            continue
        rows.append(
            {
                "ensembl_gene_id": ensembl_gene_id,
                "gene_symbol": gene_symbol,
                "source_term": source_term,
                "category": "",
            }
        )

    species_dir = out_dir / species
    bank_path = species_dir / "remove_genes.tsv.gz"
    manifest_path = species_dir / "remove_genes.manifest.json"

    if not force and bank_path.exists() and manifest_path.exists():
        print(f"Skipping {species} (already exists): {species_dir}")
        return

    _write_gz_tsv(
        bank_path,
        rows=rows,
        fieldnames=["ensembl_gene_id", "gene_symbol", "source_term", "category"],
    )

    manifest = BankManifest(
        species=species,
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        base_url=base_url,
        data_versions=data_versions,
        remove_terms=remove_terms,
        remove_terms_sha256=_sha256_str("\n".join(remove_terms)),
        generator="scripts/build_id_bank.py",
    )
    _write_json(manifest_path, asdict(manifest))


def _download(url: str, dest: Path, timeout_s: float) -> None:
    import requests

    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".tmp")
    with requests.get(url, stream=True, timeout=timeout_s) as r:
        r.raise_for_status()
        with tmp.open("wb") as fh:
            for chunk in r.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    fh.write(chunk)
    tmp.replace(dest)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _ncbi_cache_dir() -> Path:
    xdg = os.environ.get("XDG_CACHE_HOME")
    return (Path(xdg) if xdg else Path.home() / ".cache") / "anticor_features" / "ncbi"


def _open_gz_tsv(path: Path):
    import gzip

    return gzip.open(path, "rt", encoding="utf-8", newline="")


def _parse_ncbi_gene2go_geneids(gene2go_gz: Path, tax_id: int, go_terms: set[str]) -> tuple[set[str], dict[str, set[str]]]:
    """
    Returns (gene_ids, gene_id -> set(GO terms)).
    gene2go columns: tax_id, GeneID, GO_ID, Evidence, Qualifier, GO_term, PubMed, Category
    """
    gene_ids: set[str] = set()
    gene_to_terms: dict[str, set[str]] = {}
    with _open_gz_tsv(gene2go_gz) as fh:
        for line in fh:
            if not line or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 3:
                continue
            if parts[0] != str(tax_id):
                continue
            gene_id = parts[1]
            go_id = parts[2]
            if go_id in go_terms:
                gene_ids.add(gene_id)
                gene_to_terms.setdefault(gene_id, set()).add(go_id)
    return gene_ids, gene_to_terms


def _parse_ncbi_gene_info(gene_info_gz: Path, tax_id: int, keep_gene_ids: set[str] | None) -> tuple[dict[str, str], dict[str, str]]:
    """
    Returns (gene_id->symbol, gene_id->chromosome)
    gene_info columns: tax_id, GeneID, Symbol, ... , chromosome, ...
    """
    gene_to_symbol: dict[str, str] = {}
    gene_to_chr: dict[str, str] = {}
    with _open_gz_tsv(gene_info_gz) as fh:
        for line in fh:
            if not line or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 9:
                continue
            if parts[0] != str(tax_id):
                continue
            gene_id = parts[1]
            if keep_gene_ids is not None and gene_id not in keep_gene_ids:
                continue
            symbol = parts[2]
            chromosome = parts[6]
            gene_to_symbol[gene_id] = symbol
            gene_to_chr[gene_id] = chromosome
    return gene_to_symbol, gene_to_chr


def _parse_ncbi_gene2ensembl(gene2ensembl_gz: Path, tax_id: int, keep_gene_ids: set[str]) -> dict[str, str]:
    """
    Returns gene_id->ensembl_gene_id.
    gene2ensembl columns: tax_id, GeneID, Ensembl_gene_identifier, RNA_nucleotide_accession.version, Ensembl_rna_identifier, ...
    """
    gene_to_ensg: dict[str, str] = {}
    with _open_gz_tsv(gene2ensembl_gz) as fh:
        for line in fh:
            if not line or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 3:
                continue
            if parts[0] != str(tax_id):
                continue
            gene_id = parts[1]
            if gene_id not in keep_gene_ids:
                continue
            ensg = parts[2]
            if ensg and gene_id not in gene_to_ensg:
                gene_to_ensg[gene_id] = ensg
    return gene_to_ensg


def build_remove_genes_bank_ncbi(
    *,
    species: str,
    tax_id: int,
    out_dir: Path,
    timeout_s: float,
    remove_terms: list[str],
    force: bool = False,
) -> None:
    """
    Build an offline removal bank using bulk NCBI downloads:
    - gene2go: GO term -> GeneID membership
    - gene_info: GeneID -> Symbol (+ chromosome for mito detection)
    - gene2ensembl: GeneID -> Ensembl gene ID
    """
    ncbi_dir = _ncbi_cache_dir()
    gene2go_gz = ncbi_dir / "gene2go.gz"
    gene_info_gz = ncbi_dir / "gene_info.gz"
    gene2ensembl_gz = ncbi_dir / "gene2ensembl.gz"

    urls = {
        "gene2go.gz": "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene2go.gz",
        "gene_info.gz": "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene_info.gz",
        "gene2ensembl.gz": "https://ftp.ncbi.nlm.nih.gov/gene/DATA/gene2ensembl.gz",
    }
    for filename, url in urls.items():
        path = ncbi_dir / filename
        if not path.exists():
            print(f"Downloading {url} -> {path}")
            _download(url, path, timeout_s=timeout_s)

    go_term_set = set(remove_terms)
    go_gene_ids, gene_to_terms = _parse_ncbi_gene2go_geneids(gene2go_gz, tax_id=tax_id, go_terms=go_term_set)

    # Also include heuristic filters (ribo/mito/hb) to keep behavior similar to earlier releases.
    # We only need gene_info rows for the tax_id; if the GO set is empty, we still need gene_info.
    gene_to_symbol_all, gene_to_chr_all = _parse_ncbi_gene_info(gene_info_gz, tax_id=tax_id, keep_gene_ids=None)
    ribo_gene_ids = {gid for gid, sym in gene_to_symbol_all.items() if sym.upper().startswith(("RPL", "RPS"))}
    hb_gene_ids = {gid for gid, sym in gene_to_symbol_all.items() if sym.upper().startswith("HB")}
    mito_gene_ids = {
        gid
        for gid, chrom in gene_to_chr_all.items()
        if chrom.upper() in {"MT", "M", "MITO", "MITOCHONDRION"}
    }

    all_gene_ids = set(go_gene_ids) | ribo_gene_ids | hb_gene_ids | mito_gene_ids
    gene_to_ensg = _parse_ncbi_gene2ensembl(gene2ensembl_gz, tax_id=tax_id, keep_gene_ids=all_gene_ids)

    rows: list[dict[str, str]] = []
    for gid in sorted(all_gene_ids, key=lambda x: int(x) if x.isdigit() else x):
        sym = gene_to_symbol_all.get(gid, "")
        ensg = gene_to_ensg.get(gid, "")
        terms = sorted(gene_to_terms.get(gid, set()))
        categories: list[str] = []
        if gid in ribo_gene_ids:
            categories.append("ribo_symbol_prefix")
        if gid in hb_gene_ids:
            categories.append("hb_symbol_prefix")
        if gid in mito_gene_ids:
            categories.append("mito_chromosome")
        source_term = "|".join(terms)
        category = "|".join(categories)
        rows.append(
            {
                "ensembl_gene_id": ensg,
                "gene_symbol": sym,
                "source_term": source_term,
                "category": category,
            }
        )

    species_dir = out_dir / species
    bank_path = species_dir / "remove_genes.tsv.gz"
    manifest_path = species_dir / "remove_genes.manifest.json"
    if not force and bank_path.exists() and manifest_path.exists():
        print(f"Skipping {species} (already exists): {species_dir}")
        return

    _write_gz_tsv(
        bank_path,
        rows=rows,
        fieldnames=["ensembl_gene_id", "gene_symbol", "source_term", "category"],
    )
    manifest = {
        "species": species,
        "tax_id": tax_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "provider": "ncbi",
        "remove_terms": remove_terms,
        "remove_terms_sha256": _sha256_str("\n".join(remove_terms)),
        "ncbi_urls": urls,
        "ncbi_files": {
            "gene2go.gz": {"sha256": _sha256_file(gene2go_gz)},
            "gene_info.gz": {"sha256": _sha256_file(gene_info_gz)},
            "gene2ensembl.gz": {"sha256": _sha256_file(gene2ensembl_gz)},
        },
        "generator": "scripts/build_id_bank.py",
        "counts": {
            "go_gene_ids": len(go_gene_ids),
            "ribo_gene_ids": len(ribo_gene_ids),
            "hb_gene_ids": len(hb_gene_ids),
            "mito_gene_ids": len(mito_gene_ids),
            "total_gene_ids": len(all_gene_ids),
        },
    }
    _write_json(manifest_path, manifest)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate offline ID banks for anticor_features.")
    parser.add_argument(
        "--species",
        action="append",
        default=[],
        help="g:Profiler organism code (repeatable), e.g. --species hsapiens --species mmusculus",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Generate banks for all organisms returned by g:Profiler organisms_list (may take a long time).",
    )
    parser.add_argument(
        "--provider",
        choices=["ncbi", "gprofiler"],
        default="ncbi",
        help="Lookup backend for building the bank. Prefer ncbi for reliability/offline reproducibility.",
    )
    parser.add_argument(
        "--tax_id",
        type=int,
        default=0,
        help="NCBI taxonomy ID (required for provider=ncbi unless species is one of the built-in mappings).",
    )
    parser.add_argument(
        "--out_dir",
        default="",
        help="Output root directory for banks (default: ~/.cache/anticor_features/id_bank or $XDG_CACHE_HOME).",
    )
    parser.add_argument("--base_url", default=os.environ.get("GPROFILER_BASE_URL", "https://biit.cs.ut.ee/gprofiler"))
    parser.add_argument("--cache_dir", default=os.environ.get("ANTICOR_FEATURES_CACHE_DIR", ""))
    parser.add_argument("--timeout_s", type=float, default=30.0)
    parser.add_argument("--force", action="store_true", help="Overwrite existing bank files.")
    parser.add_argument("--limit", type=int, default=0, help="Limit number of species when using --all (for testing).")
    parser.add_argument(
        "--organisms_snapshot",
        default="",
        help="If set, write the organisms_list JSON to this file for auditing/pinning.",
    )
    args = parser.parse_args()

    if args.out_dir:
        out_dir = Path(args.out_dir)
    else:
        xdg = os.environ.get("XDG_CACHE_HOME")
        out_dir = (Path(xdg) if xdg else Path.home() / ".cache") / "anticor_features" / "id_bank"
    cache_dir = Path(args.cache_dir) if args.cache_dir else None

    species_list: list[str] = []
    if args.all:
        client = GProfilerClient(base_url=args.base_url, timeout_s=args.timeout_s, offline_mode=False, cache=None)
        organisms_payload = client.organisms_list()
        if args.organisms_snapshot:
            snapshot_path = Path(args.organisms_snapshot)
            _write_json(snapshot_path, organisms_payload if isinstance(organisms_payload, dict) else {"result": organisms_payload})
        species_list = _iter_organism_codes(organisms_payload)
        if args.limit and args.limit > 0:
            species_list = species_list[: args.limit]
    species_list.extend(args.species)
    species_list = sorted(set([s.strip() for s in species_list if s.strip()]))
    if not species_list:
        parser.error("Provide at least one --species, or use --all.")

    for sp in species_list:
        if args.provider == "gprofiler":
            build_remove_genes_bank(
                species=sp,
                out_dir=out_dir,
                base_url=args.base_url,
                cache_dir=cache_dir,
                timeout_s=args.timeout_s,
                remove_terms=DEFAULT_REMOVE_TERMS,
                force=args.force,
            )
        else:
            tax_id = args.tax_id or DEFAULT_SPECIES_TO_TAX_ID.get(sp, 0)
            if not tax_id:
                raise SystemExit(
                    f"provider=ncbi requires --tax_id unless species is mapped. "
                    f"Unknown mapping for species={sp!r}. Provide --tax_id."
                )
            build_remove_genes_bank_ncbi(
                species=sp,
                tax_id=tax_id,
                out_dir=out_dir,
                timeout_s=args.timeout_s,
                remove_terms=DEFAULT_REMOVE_TERMS,
                force=args.force,
            )

    print(f"Done. Banks root: {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
