import os
import tempfile
import unittest
from pathlib import Path


class TestIdBank(unittest.TestCase):
    def test_default_bank_root_is_packaged(self):
        from anticor_features.id_bank import IdBank, get_default_id_bank

        bank = get_default_id_bank()
        self.assertEqual(bank.root, IdBank.packaged_root())

    def test_env_override_is_respected(self):
        from anticor_features.id_bank import get_default_id_bank

        with tempfile.TemporaryDirectory() as tmp:
            old = os.environ.get("ANTICOR_FEATURES_ID_BANK_DIR")
            os.environ["ANTICOR_FEATURES_ID_BANK_DIR"] = tmp
            try:
                bank = get_default_id_bank()
                self.assertEqual(bank.root, Path(tmp))
            finally:
                if old is None:
                    os.environ.pop("ANTICOR_FEATURES_ID_BANK_DIR", None)
                else:
                    os.environ["ANTICOR_FEATURES_ID_BANK_DIR"] = old

    def test_load_remove_gene_set_has_expected_markers(self):
        from anticor_features.id_bank import get_default_id_bank

        bank = get_default_id_bank()
        hs = bank.load_remove_gene_set("hsapiens")

        # Bank should include common ribosomal and hemoglobin markers (uppercased).
        self.assertIn("RPLP0", hs)
        self.assertTrue(any(g.startswith("RPS") for g in hs) or any(g.startswith("RPL") for g in hs))
        self.assertTrue(any(g.startswith("HB") for g in hs))
