import unittest

import numpy as np


class TestOfflinePathwayRemoval(unittest.TestCase):
    def test_offline_mode_uses_shipped_bank(self):
        from anticor_features.anticor_features import get_all_remove_genes

        exprs = np.array([[0, 1, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0]], dtype=float)
        features = ["RPLP0", "BAR", "HBZ"]

        rm, ann = get_all_remove_genes(
            pre_remove_features=[],
            pre_remove_pathways=["GO:0044429"],
            species="hsapiens",
            min_express_n=1,
            cell_axis=1,
            exprs=exprs,
            all_features=features,
            offline_mode=True,
            default_pre_remove_pathways=["GO:0044429"],
        )

        self.assertIn("RPLP0", rm)
        self.assertIn("HBZ", rm)
        self.assertEqual(
            ann.loc[ann["gene"] == "RPLP0", "pre_remove_pathway"].iloc[0],
            True,
        )

    def test_offline_mode_blocks_live_lookup(self):
        from anticor_features.anticor_features import get_all_remove_genes

        exprs = np.ones((2, 3), dtype=float)
        features = ["A", "B"]

        with self.assertRaises(ValueError):
            get_all_remove_genes(
                pre_remove_features=[],
                pre_remove_pathways=["GO:0044429"],
                species="hsapiens",
                min_express_n=1,
                cell_axis=1,
                exprs=exprs,
                all_features=features,
                offline_mode=True,
                default_pre_remove_pathways=["GO:0044429"],
                use_live_pathway_lookup=True,
            )

    def test_offline_mode_blocks_custom_terms(self):
        from anticor_features.anticor_features import get_all_remove_genes

        exprs = np.ones((2, 3), dtype=float)
        features = ["A", "B"]

        with self.assertRaises(ValueError):
            get_all_remove_genes(
                pre_remove_features=[],
                pre_remove_pathways=["GO:0005739"],
                species="hsapiens",
                min_express_n=1,
                cell_axis=1,
                exprs=exprs,
                all_features=features,
                offline_mode=True,
                default_pre_remove_pathways=["GO:0044429"],
            )

