import gzip
import tempfile
import unittest
from pathlib import Path


class TestPreflight(unittest.TestCase):
    def test_preflight_uses_shipped_bank(self):
        from anticor_features.anticor_features import preflight_pathway_removal

        prov = preflight_pathway_removal(species="hsapiens", pre_remove_pathways=None, offline_mode=True)
        self.assertEqual(prov["pathway_source"], "shipped_bank")
        self.assertTrue(prov["can_run_offline"])
        self.assertFalse(prov["would_require_live_lookup"])
        self.assertTrue(prov["bank_manifest_path"])
        self.assertTrue(prov["bank_sha256"])

    def test_preflight_detects_id_bank_dir(self):
        from anticor_features.anticor_features import preflight_pathway_removal

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "hsapiens"
            root.mkdir(parents=True, exist_ok=True)
            (root / "remove_genes.manifest.json").write_text("{}", encoding="utf-8")
            # Minimal TSV with required columns
            with gzip.open(root / "remove_genes.tsv.gz", "wt", encoding="utf-8") as fh:
                fh.write("ensembl_gene_id\tgene_symbol\tsource_term\tcategory\nENSG0000\tRPLP0\t\t\n")

            prov = preflight_pathway_removal(
                species="hsapiens",
                pre_remove_pathways=None,
                offline_mode=True,
                id_bank_dir=tmp,
            )
            self.assertEqual(prov["pathway_source"], "id_bank_dir")
            self.assertTrue(prov["can_run_offline"])
            self.assertTrue(prov["bank_manifest_path"].startswith(tmp))

    def test_preflight_blocks_live_lookup_when_offline(self):
        from anticor_features.anticor_features import preflight_pathway_removal

        with self.assertRaises(ValueError):
            preflight_pathway_removal(
                species="hsapiens",
                pre_remove_pathways=None,
                offline_mode=True,
                use_live_pathway_lookup=True,
            )

    def test_get_anti_cor_genes_preflight_only(self):
        from anticor_features.anticor_features import get_anti_cor_genes

        prov = get_anti_cor_genes(None, None, preflight_only=True, species="hsapiens")
        self.assertIn("pathway_source", prov)
        self.assertIn("requested_pathways", prov)
