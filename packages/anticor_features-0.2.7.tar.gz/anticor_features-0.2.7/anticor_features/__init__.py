"""
Top-level imports for anticor_features package.

This allows:
    from anticor_features import get_anti_cor_genes
"""

__version__ = "0.2.7"

__all__ = [
    "get_anti_cor_genes",
    "__version__",
]


def __getattr__(name: str):
    if name == "get_anti_cor_genes":
        from .anticor_features import get_anti_cor_genes

        return get_anti_cor_genes
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(list(globals().keys()) + ["get_anti_cor_genes"])
