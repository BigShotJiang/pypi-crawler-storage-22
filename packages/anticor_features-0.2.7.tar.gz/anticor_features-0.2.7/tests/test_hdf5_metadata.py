import tempfile
import unittest

import h5py
import numpy as np


class TestHdf5Metadata(unittest.TestCase):
    def test_write_scratch_metadata_adds_ids_and_meta(self):
        from anticor_features.anticor_features import _write_scratch_metadata

        with tempfile.TemporaryDirectory() as tmp:
            exprs_path = f"{tmp}/exprs.hdf5"
            spear_path = f"{tmp}/spearman.hdf5"

            with h5py.File(exprs_path, "w") as f:
                f.create_dataset("infile", data=np.zeros((2, 3), dtype=np.float32))
            with h5py.File(spear_path, "w") as f:
                f.create_dataset("infile", data=np.zeros((2, 2), dtype=np.float16))

            _write_scratch_metadata(
                exprs_h5_path=exprs_path,
                spearman_h5_path=spear_path,
                feature_ids_kept=["A", "B"],
                feature_original_idx=[10, 20],
                feature_ids_input=["X", "Y", "Z"],
                feature_ids_used=["X", "Y", "Z"],
                provenance={"pathway_source": "shipped_bank"},
            )

            for path in (exprs_path, spear_path):
                with h5py.File(path, "r") as f:
                    self.assertIn("infile", f)
                    self.assertIn("ids/feature_ids_kept", f)
                    self.assertIn("ids/feature_original_idx", f)
                    self.assertIn("meta/provenance_json", f)
                    kept = [x.decode("utf-8") if isinstance(x, (bytes, bytearray)) else str(x) for x in f["ids/feature_ids_kept"][...]]
                    self.assertEqual(kept, ["A", "B"])
                    idx = f["ids/feature_original_idx"][...].tolist()
                    self.assertEqual(idx, [10, 20])

