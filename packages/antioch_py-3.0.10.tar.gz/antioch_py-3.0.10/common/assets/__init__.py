import os

RIGGING_USD_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rigging.usd")
