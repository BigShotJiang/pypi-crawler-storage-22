#!/usr/bin/env python3

# Copyright (c) 2014-2016 Adrian Rossiter <adrian@antiprism.com>
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

'''
Make a arkDome-style dome:
https://groups.google.com/d/topic/geodesichelp/77YNlm8okcY/discussion
Project a tiling at a specified height, onto a unit hemisphere, by
gnomonic, stereographic or general point projection

pi/2/n - atan(tan(pi/2/n)*((1-tan(2*pi/n)/(2*sin(pi/n)))/(1+tan(2*pi/n)/
(2*sin(pi/n)))))
'''

import argparse
import sys
import math
import anti_lib
from anti_lib import Vec
from math import atan, sin, tan, cos
epsilon = 1e-13


def lines_nearest_points(P0, P1, Q0, Q1, eps=epsilon):
    u = (P1 - P0)
    v = (Q1 - Q0)
    w = P0 - Q0
    a = Vec.dot(u, u)
    b = Vec.dot(u, v)
    c = Vec.dot(v, v)
    d = Vec.dot(u, w)
    e = Vec.dot(v, w)
    D = a * c - b * b
    s = (b * e - c * d) / D
    t = (a * e - b * d) / D
    P = P0 + s * u
    Q = Q0 + t * v
    return (P, Q, (D >= eps))


def lines_intersection(P0, P1, Q0, Q1, eps=0):
    (P, Q, valid) = lines_nearest_points(P0, P1, Q0, Q1, eps)
    if eps == 0:
        if not valid:
            P = (P0 + P1) / 2.0
            Q = (Q0 + Q1) / 2.0
        return (P + Q) / 2.0
    else:
        # lines might not be parallel and still miss so check if
        # nearest points is not zero
        if valid and (P - Q).mag() < eps:
            return (P + Q) / 2.0
        else:
            Vec()


def make_tiling(pgon):
    """Make tiling with intersectinrg lines"""
    N = pgon.N
    D = pgon.D
    a = pgon.angle() / 2
    x = a / 2 - atan(tan(a / 2) * (
       (1 - tan(2 * a) / (2 * sin(a))) / (1 + tan(2 * a) / (
        2 * sin(a)))))
    print("ratio = " + str(x / a / 2), file=sys.stderr)
    A = Vec(1, 0, 0)
    B = Vec(cos(x), sin(x), 0)
    B2 = Vec(cos(2*a - x), sin(2*a - x), 0)
    C = lines_intersection(A.rot_z(2*a), Vec(0, 0, 0), B2, B2.rot_z(2*(a+x)))
    E = lines_intersection(A.rot_z(2*a), Vec(0, 0, 0), B, B.rot_z(2*(3*a-x)))
    F = lines_intersection(B, B.rot_z(2*(3*a-x)), B2, B2.rot_z(-2*(3*a-x)),)

    points = [anti_lib.Vec(0, 0, 0)]
    for i in range(N):
        ang_inc = i * 2 * math.pi * D / N
        points.append(A.rot_z(ang_inc))
        points.append(B.rot_z(ang_inc))
        points.append(B2.rot_z(ang_inc))
        points.append(C.rot_z(ang_inc))
        points.append(E.rot_z(ang_inc))
        points.append(F.rot_z(ang_inc))

    faces = []
    for i in range(N):
        faces.append([0, 5 + i * 6, 5 + ((i + 1) * 6) % (6 * N)])
        faces.append([5 + i * 6, 6 + ((i + 1) * 6) % (6 * N),
                     5 + ((i + 1) * 6) % (6 * N)])
        faces.append([6 + ((i + 1) * 6) % (6 * N), 5 + i * 6, 4 + i * 6])
        faces.append([5 + i * 6, 6 + i * 6, 4 + i * 6])
        faces.append([4 + i * 6, 1 + ((i + 1) * 6) % (6 * N),
                     2 + ((i + 1) * 6) % (6 * N)])
        faces.append([3 + i * 6, 1 + ((i + 1) * 6) % (6 * N), 4 + i * 6])
        faces.append([4 + i * 6, 6 + i * 6, 3 + ((i)*6) % (6*N)])
        faces.append([2 + i * 6, 3 + i * 6, 6 + i * 6])
        faces.append([4 + i * 6, 2 + ((i + 1)*6) % (6 * N),
                     6 + ((i + 1) * 6) % (6 * N)])

    return points, faces


def project_onto_sphere(points, ht):
    R = (1 / ht + ht) / 2
    print("R = ", R, file=sys.stderr)
    # cent = Vec(0, 0, ht - R)
    new_points = []
    for point in points:
        new_point = point
        if abs(ht) < 1 - epsilon:
            new_point[2] -= ht - R
            new_point = new_point.unit() * R
            new_point[2] += ht - R

        new_points.append(new_point)

    return new_points


def main():
    """Entry point"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        'polygon_fraction',
        help='number of sides of the base polygon (N), '
             'or a fraction for star polygons (N/D) (default: 6)',
        default='6',
        nargs='?',
        type=anti_lib.read_polygon)
    parser.add_argument(
        'dome_height',
        help='height of the dome',
        nargs='?',
        type=float,
        default=0.3)
    parser.add_argument(
        '-o', '--outfile',
        help='output file name (default: standard output)',
        type=argparse.FileType('w'),
        default=sys.stdout)

    args = parser.parse_args()

    pgon = args.polygon_fraction
    points, faces = make_tiling(pgon)
    new_points = project_onto_sphere(points, args.dome_height)
    out = anti_lib.OffFile(args.outfile)
    out.print_all(new_points, faces)


if __name__ == "__main__":
    main()
