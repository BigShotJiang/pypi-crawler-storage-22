# Antony Indicator Package

A custom Python package for technical analysis indicators.

## Installation

```bash
pip install .
```

## Usage

```python
import pandas as pd
from indicator.vpfr import vpfr

# ... create dataframe ...
result = vpfr(df)
print(result.poc, result.vah, result.val)
```
