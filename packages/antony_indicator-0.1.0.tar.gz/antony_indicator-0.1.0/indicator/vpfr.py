import pandas as pd
import numpy as np
from dataclasses import dataclass


class VPFRInputError(Exception):
    pass


@dataclass
class VPFRResult:
    profile: pd.DataFrame   # columns: price_level, volume
    poc: float
    vah: float
    val: float


# ---------- PRICE RESOLUTION ----------

def _resolve_price(df: pd.DataFrame, mode: str) -> pd.Series:
    mode = mode.lower()

    if mode == "close":
        _require_cols(df, ["close"])
        return df["close"]

    if mode == "hlc3":
        _require_cols(df, ["high", "low", "close"])
        return (df["high"] + df["low"] + df["close"]) / 3.0

    if mode == "typical":
        _require_cols(df, ["open", "high", "low", "close"])
        return (df["open"] + df["high"] + df["low"] + df["close"]) / 4.0

    raise VPFRInputError(f"Invalid price_mode: {mode}")


def _require_cols(df: pd.DataFrame, cols: list[str]):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise VPFRInputError(f"Missing columns: {missing}")


# ---------- CORE VPFR ----------

def vpfr(
    df: pd.DataFrame,
    price_mode: str = "typical",
    volume_col: str = "volume",
    bins: int = 100,
    value_area: float = 0.7,
) -> VPFRResult:
    """
    Volume Profile Fixed Range (VPFR)

    Parameters
    ----------
    df : pd.DataFrame
        Must contain OHLC + volume
    price_mode : str
        'close' | 'hlc3' | 'typical' (default)
    volume_col : str
        Volume column name
    bins : int
        Number of price bins
    value_area : float
        Value area percentage (default 0.7)

    Returns
    -------
    VPFRResult
    """

    if volume_col not in df.columns:
        raise VPFRInputError(f"Missing volume column: {volume_col}")

    if not 0 < value_area < 1:
        raise VPFRInputError("value_area must be between 0 and 1")

    price = _resolve_price(df, price_mode)
    volume = df[volume_col]

    if price.isna().any() or volume.isna().any():
        raise VPFRInputError("NaN values found in price or volume")

    # -------- BINNING --------

    if bins < 5:
        raise VPFRInputError("bins must be >= 5")

    price_min, price_max = price.min(), price.max()

    if price_min == price_max:
        raise VPFRInputError("Price range is zero; VPFR cannot be computed")

    edges = np.linspace(price_min, price_max, bins + 1)

    bin_idx = np.digitize(price, edges) - 1
    bin_idx = np.clip(bin_idx, 0, bins - 1)

    vol_profile = (
        pd.DataFrame({"bin": bin_idx, "volume": volume})
        .groupby("bin", as_index=False)
        .sum()
    )

    price_levels = (edges[:-1] + edges[1:]) / 2.0
    vol_profile["price_level"] = price_levels[vol_profile["bin"].values]

    profile = vol_profile[["price_level", "volume"]].sort_values(
        "price_level"
    ).reset_index(drop=True)

    if profile.empty:
        raise VPFRInputError("No volume accumulated in any bin")

    # -------- POC --------

    poc_idx = profile["volume"].idxmax()
    poc_price = profile.loc[poc_idx, "price_level"]

    # -------- VALUE AREA --------

    total_volume = profile["volume"].sum()
    target_volume = total_volume * value_area

    sorted_profile = profile.sort_values(
        "volume", ascending=False
    ).reset_index(drop=True)

    cum_vol = 0.0
    selected = []

    for _, row in sorted_profile.iterrows():
        cum_vol += row["volume"]
        selected.append(row["price_level"])
        if cum_vol >= target_volume:
            break

    vah = max(selected)
    val = min(selected)

    return VPFRResult(
        profile=profile,
        poc=float(poc_price),
        vah=float(vah),
        val=float(val),
    )
