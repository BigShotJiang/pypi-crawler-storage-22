# any2htpy

**any2htpy** is a principled converter for HTML/SVG and MathML to [htpy](https://htpy.dev) inspired by `html2htpy`, the built-in tool for `htpy`.

Unlike `html2htpy` any2htpy uses a feature-complete HTML parser called [justhtml](https://github.com/emilstenstrom/justhtml). 

## Features

- adheres to SVG and MathML 
- preserves case-sensitive attributes such as SVG `viewBox`
- preserves SVG path commands and other non-class attribute values with spaces 
- tries best-effort DOM for malformed HTML
- properly preserves whitespace for respective tags
- only supports `class_` syntax to allow stable parsing by TailwindCSS

A few things **any2htpy** needs to fix to be better suited for :

- auto-detect if code is just a fragment or a whole document
- boolean attributes are not yet detected (use `dict` syntax)
- special attribute detection for AlpineJS or HTMX 
    - specifically passing HTMX events `:` or AlpineJS `@`


Things that **any2htpy** will not do:

- add the `import htpy` code
- add the shorthand syntax of `htpy`


## Usage

```sh
usage: any2htpy [-h] [--input INPUT] [--stdin] [--debug] [--prefix PREFIX] [--fragment]

options:
  -h, --help       show this help message and exit
  --input INPUT    input as string or file
  --stdin          use stdin as input
  --debug          generate debug output
  --prefix PREFIX  use a prefix for the tags
  --fragment       use htpy fragment
```

### input through stdin

```sh
[me@machine ] echo "<p>Hello World</p>" | any2htpy --stdin --prefix htpy
htpy.p["Hello World"]
```

### fetching an icon from Bootstrap library:

```sh
[me@machine ] curl -s https://icons.getbootstrap.com/assets/icons/0-circle.svg | any2htpy --fragment --stdin
svg(xmlns="http://www.w3.org/2000/svg",width="16",height="16",fill="currentColor",class_=["bi","bi-0-circle"],viewBox="0 0 16 16")[path(d="M7.988 12.158c-1.851 0-2.941-1.57-2.941-3.99V7.84c0-2.408 1.101-3.996 2.965-3.996 1.857 0 2.935 1.57 2.935 3.996v.328c0 2.408-1.101 3.99-2.959 3.99M8 4.951c-1.008 0-1.629 1.09-1.629 2.895v.31c0 1.81.627 2.895 1.629 2.895s1.623-1.09 1.623-2.895v-.31c0-1.8-.621-2.895-1.623-2.895"),path(d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8")]
```

### convert a local file

```sh
[me@machine ] any2htpy --input icon.svg
```



## Disclaimer

As an AI-skeptic, specifically regarding code and software in general, justhtml is not exactly the obvious choice or more precisely the exact opposite one. However, the heavy test-rig with thousands of tests and the use as a parser **without** introducing it as a dependency in the resulting code make it a better choice than any other native Python parser library.

## License

Licensed under the terms of the MIT License 

## Copyright

Copyright (c) 2026 Hartmut Seichter
