import textwrap

from src.any2htpy import any2htpy


def test_simple_html():
    input = r"""<html>
    <head>
        <title>Hello World</title>
    </head>
    <body>
        <h1>Hello World</h1>
    </body>
</html>
"""
    expected = 'html[head[title["Hello World"]],body[h1["Hello World"]]]'

    actual = any2htpy(input, is_fragment=False)

    assert actual == expected


def test_simple_with_attributes_html():
    input = r"""<html>
    <head>
    </head>
    <body>
        <h1 class="font-bold m-2">Hello World</h1>
    </body>
</html>
"""
    expected = 'html[head,body[h1(class_=["font-bold","m-2"])["Hello World"]]]'

    actual = any2htpy(input, is_fragment=False)

    assert actual == expected


#
# blatantly stolen tests from html2htpy - some are modified!
#


def test_simple_html_fragment():
    input = r"""<div class="centered"><br/><p></p></div>"""
    expected = 'div(class_=["centered"])[br,p]'

    result = any2htpy(input, is_fragment=True)

    assert result == expected


def test_convert_explicit_id_class_syntax() -> None:
    input = """
        <div id="div-id" class="some-class other-class">
            <p>This is a paragraph.</p>
        </div>
    """

    # different output from html2htpy: to cater for tailwindcss detection using class list

    actual = any2htpy(input, is_fragment=True)
    expected = 'div(id="div-id",class_=["some-class","other-class"])[p["This is a paragraph."]]'

    assert actual == expected


def test_convert_self_closing_tags() -> None:
    input = """
        <img src="image.jpg" alt="An image" />
        <br />
        <input type="text" />
    """

    actual = any2htpy(input, is_fragment=True)

    # different output from html2htpy: the brackets (fragment) make no sense

    assert (
        actual == 'fragment[img(src="image.jpg",alt="An image"),br,input(type="text")]'
    )


def test_convert_attribute_with_special_characters() -> None:
    input = """<img src="path/to/image.jpg" alt="A <test> & 'image'" />"""
    actual = any2htpy(input, is_fragment=True)
    assert actual == """img(src="path/to/image.jpg",alt="A <test> & 'image'")"""


def test_convert_ignores_comments() -> None:
    input = """
    <!-- This is a comment -->
    <div>Content <!-- Another comment --> inside</div>
    """
    actual = any2htpy(input, is_fragment=True)
    assert (
        actual
        == 'fragment[comment(" This is a comment "),div["Content ",comment(" Another comment ")," inside"]]'
    )


def test_convert_style_tag() -> None:
    input = """
        <style>body { background-color: #fff; }</style>
    """
    # we correctly preserve whitespace inside of style
    actual = any2htpy(input, is_fragment=True)
    assert actual == """style[\"""body { background-color: #fff; }\"""]"""


def test_convert_html_doctype() -> None:
    input = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Test Document</title>
        </head>
        <body>
            <h1>Header</h1>
            <p>Paragraph</p>
        </body>
        </html>
    """

    actual = any2htpy(input, is_fragment=False)
    expected = (
        """html[head[title["Test Document"]],body[h1["Header"],p["Paragraph"]]]"""
    )

    assert actual == expected


def test_convert_void_elements() -> None:
    input = """
        <div>
        <div>
            <input type="text" />
        </div>

        <div>
            <input type="text">
        </div>
    </div>
    """

    actual = any2htpy(input, is_fragment=True)
    assert actual == 'div[div[input(type="text")],div[input(type="text")]]'


def test_convert_custom_tag() -> None:
    input = r"""
        <custom-element attribute="value">Custom content</custom-element>
    """

    actual = any2htpy(input, is_fragment=True)
    assert actual == """custom_element(attribute="value")["Custom content"]"""


def test_convert_malformed_html() -> None:
    input = """
        <div>
            <p>Paragraph without closing tag
            <div>Another div</p>
        </div>
    """
    actual = any2htpy(input, is_fragment=True)
    # it does a best effort to get the tags correct
    assert actual == """div[p["Paragraph without closing tag "],div["Another div",p]]"""


def test_reserved_keyword_attributes() -> None:
    input = '<img class="foo" del="x">'

    actual = actual = any2htpy(input, is_fragment=True)

    expected = 'img(class_=["foo"],del_="x")'

    assert actual == expected


def test_convert_pre_element_retains_all_whitespace() -> None:
    actual = any2htpy(
        textwrap.dedent(
            """\
            <pre>
            hello,   fellow   programmer.

            This   element   retains   newlines   and   whitespace.
            </pre>
            """
        ),
        is_fragment=True,
    )

    # original tested wrong: before the pre is another newline

    assert actual == textwrap.dedent(
        '''\
        pre["""hello,   fellow   programmer.

        This   element   retains   newlines   and   whitespace.
        """]'''
    )
