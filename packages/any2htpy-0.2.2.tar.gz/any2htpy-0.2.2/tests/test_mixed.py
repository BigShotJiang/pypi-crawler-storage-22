from src.any2htpy import any2htpy


def test_mixed_simple():
    input = r""" <!DOCTYPE html>
   <html>
       <body>
           <h1>My first SVG</h1>
           <svg width="100" height="100" xmlns="http://www.w3.org/2000/svg">
               <circle cx="50" cy="50" r="40" stroke="green" stroke-width="4" fill="yellow" />
           </svg>
       </body>
   </html>"""

    expected = """html[head,body[h1["My first SVG"],svg(width="100",height="100",xmlns="http://www.w3.org/2000/svg")[circle(cx="50",cy="50",r="40",stroke="green",stroke_width="4",fill="yellow")]]]"""

    actual = any2htpy(input, is_fragment=False)

    assert actual == expected
