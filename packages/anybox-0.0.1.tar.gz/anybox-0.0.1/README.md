# AnyBox (PyPI name reserve)

此目录是一个**最小可安装包**，仅用于在 PyPI 上占用 `anybox` 包名，不包含实际功能。  
正式版本开发完成后，请在**项目根目录**用主 `pyproject.toml` 构建并上传，届时会作为同一项目的更高版本发布。

## 上传步骤（仅执行一次占名）

```bash
cd pypi_reserve
pip install build twine
python -m build
twine upload dist/*
```

- 用户名填 `__token__`，密码填 PyPI 的 API token。
- 上传成功后即可删除本目录或保留作参考；后续正式发版在仓库根目录执行 `python -m build` 与 `twine upload dist/*`。
