"""AnyBox: Agent environment builder and runtime (placeholder package)."""

__version__ = "0.0.1"
