"""
允许通过 python -m anyencrypt 运行
"""
from .cli import main

if __name__ == '__main__':
    main()
