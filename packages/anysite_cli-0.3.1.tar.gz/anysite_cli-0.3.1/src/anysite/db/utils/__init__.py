"""Database utility functions."""
