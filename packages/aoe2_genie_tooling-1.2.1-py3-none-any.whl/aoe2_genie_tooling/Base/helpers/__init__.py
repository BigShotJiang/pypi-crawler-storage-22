# Helper functions
