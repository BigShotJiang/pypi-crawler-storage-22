# ruff: noqa: S105
from enum import StrEnum
