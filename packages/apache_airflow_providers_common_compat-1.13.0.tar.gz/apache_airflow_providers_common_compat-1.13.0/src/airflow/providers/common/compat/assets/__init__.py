# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from airflow.providers.common.compat.version_compat import (
    AIRFLOW_V_3_0_PLUS,
)

if TYPE_CHECKING:
    from airflow.api_fastapi.auth.managers.models.resource_details import AssetAliasDetails, AssetDetails
    from airflow.models.asset import expand_alias_to_assets
    from airflow.sdk.definitions.asset import Asset, AssetAlias, AssetAll, AssetAny
else:
    if AIRFLOW_V_3_0_PLUS:
        from airflow.api_fastapi.auth.managers.models.resource_details import AssetAliasDetails, AssetDetails
        from airflow.models.asset import expand_alias_to_assets
        from airflow.sdk.definitions.asset import Asset, AssetAlias, AssetAll, AssetAny
    else:
        # dataset is renamed to asset since Airflow 3.0
        from airflow.auth.managers.models.resource_details import DatasetDetails as AssetDetails
        from airflow.datasets import (
            Dataset as Asset,
            DatasetAlias as AssetAlias,
            DatasetAll as AssetAll,
            DatasetAny as AssetAny,
            expand_alias_to_datasets as expand_alias_to_assets,
        )


__all__ = [
    "Asset",
    "AssetAlias",
    "AssetAliasDetails",
    "AssetAll",
    "AssetAny",
    "AssetDetails",
    "expand_alias_to_assets",
]
