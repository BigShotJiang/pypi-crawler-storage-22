# ApeCode 🦧

A terminal code agent powered by AI.

## Status

🚧 **Under Development** - This is a placeholder release.

## Installation

```bash
uv pip install apecode
```

Or with pip:

```bash
pip install apecode
```

## Usage

```bash
ape
```

## Coming Soon

- Interactive AI code agent in your terminal
- Natural language task completion
- Code generation and editing
- File operations and git integration

## License

MIT
