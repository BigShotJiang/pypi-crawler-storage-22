"""
Scrape executor feature

fetch and extract website content.
"""

from apflow.extensions.scrape.scrape_executor import ScrapeExecutor

__all__ = ["ScrapeExecutor"]
