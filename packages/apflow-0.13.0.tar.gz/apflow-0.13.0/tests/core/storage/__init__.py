"""
Tests for core.storage module

This package contains tests for storage-related components.
"""

