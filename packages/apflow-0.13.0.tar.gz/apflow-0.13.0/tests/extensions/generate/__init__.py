"""
Tests for generate executor extension
"""

