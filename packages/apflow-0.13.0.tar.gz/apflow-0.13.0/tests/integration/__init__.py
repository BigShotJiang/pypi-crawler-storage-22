"""
Integration tests for apflow

These tests demonstrate real-world usage scenarios with actual database
and executor interactions.
"""

