"""
Tests for MCP Server
"""

