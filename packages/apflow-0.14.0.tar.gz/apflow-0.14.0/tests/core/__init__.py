"""
Core module tests
"""

