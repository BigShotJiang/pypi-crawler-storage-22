"""Tests for HTTP executor"""

