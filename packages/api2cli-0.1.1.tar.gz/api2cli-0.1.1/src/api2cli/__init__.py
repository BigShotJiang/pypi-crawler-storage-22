"""API to CLI converter."""

__version__ = "0.1.1"
