# API TestKit

Reusable Playwright API Automation Framework.

## Install

pip install api-testkit

## Run Tests

pytest --base-url https://api.com --email user@mail.com --password 123

## Fixtures

- api_request → authenticated
- unauth_api_request → without login
