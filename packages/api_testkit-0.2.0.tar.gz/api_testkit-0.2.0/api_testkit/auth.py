import json

def login(client, email, password, endpoint="api/v1/auth/login"):
    """
    Login using the SAME Playwright request context as APIClient.
    """

    res = client.request.post(
        endpoint,
        data=json.dumps({
            "email": email,
            "password": password
        }),
        headers={"Content-Type": "application/json"}
    )

    assert res.ok, f"Login failed: {res.status} {res.text()}"

    data = res.json()

    return {
        "accessToken": data.get("token") or data.get("accessToken") or data.get("access_token"),
        "refreshToken": data.get("refresh_token") or data.get("refreshToken")
    }




def refresh_token(client, refresh_token, endpoint="/api/auth/refresh"):
    """
    Uses refresh token to get a new access token when 401 happens.
    """

    res = client.request.post(
        endpoint,
        data=json.dumps({"refreshToken": refresh_token}),
        headers={"Content-Type": "application/json"}
    )

    assert res.ok, f"Token refresh failed: {res.status} {res.text()}"

    return res.json()
