from playwright.sync_api import sync_playwright
from .logging_utils import log_api_call
from .retry import request_with_retry
from .auth import refresh_token


class APIClient:
    def __init__(self, base_url, ignore_https_errors=False):
        self.playwright = sync_playwright().start()
        self.request = self.playwright.request.new_context(
            base_url=base_url,
            ignore_https_errors=ignore_https_errors
        )
        self.access_token = None
        self.refresh_token = None

    # ✅ ONLY store tokens
    def set_tokens(self, access, refresh=None):
        self.access_token = access
        self.refresh_token = refresh

    # 🔄 Handle response + auto-refresh
    def _handle_response(self, method, url, kwargs, res):
        log_api_call(method, url, kwargs, res)

        if res.status == 401 and self.refresh_token:
            tokens = refresh_token(self, self.refresh_token)
            self.set_tokens(tokens["accessToken"], tokens.get("refreshToken"))

            # retry request with new token
            headers = kwargs.get("headers", {})
            headers["Authorization"] = f"Bearer {self.access_token}"
            kwargs["headers"] = headers

            res = getattr(self.request, method.lower())(url, **kwargs)

        return res

    # 🚀 Main request handler
    def request_api(self, method, endpoint, **kwargs):
        method = method.lower()

        # ✅ Inject token header dynamically
        headers = kwargs.pop("headers", {})
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        kwargs["headers"] = headers

        res = request_with_retry(
            lambda: getattr(self.request, method)(endpoint, **kwargs)
        )

        return self._handle_response(method.upper(), endpoint, kwargs, res)

    # Shortcuts
    def get(self, endpoint, **kwargs):
        return self.request_api("get", endpoint, **kwargs)

    def post(self, endpoint, **kwargs):
        return self.request_api("post", endpoint, **kwargs)

    def put(self, endpoint, **kwargs):
        return self.request_api("put", endpoint, **kwargs)

    def delete(self, endpoint, **kwargs):
        return self.request_api("delete", endpoint, **kwargs)

    def patch(self, endpoint, **kwargs):
        return self.request_api("patch", endpoint, **kwargs)

    def close(self):
        self.request.dispose()
        self.playwright.stop()
