# def get_config(pytestconfig):
#     return {
#         "base_url": pytestconfig.getoption("--api-base-url"),
#         "email": pytestconfig.getoption("--email"),
#         "password": pytestconfig.getoption("--password"),
#         "ignore_https_errors": pytestconfig.getoption("--ignore-https-errors"),
#     }


def get_config(pytestconfig):
    return {
        "base_url": pytestconfig.getoption("base_url"),
        "email": pytestconfig.getoption("email"),
        "password": pytestconfig.getoption("password"),
        "ignore_https_errors": pytestconfig.getoption("ignore_https_errors"),
    }

