import json
from datetime import datetime


def log_api_call(method, url, request_data, response):
    log = {
        "time": str(datetime.now()),
        "method": method,
        "url": url,
        "request": request_data,
        "status": response.status,
        "response": response.text()
    }

    with open("api_logs.json", "a") as f:
        f.write(json.dumps(log) + "\n")
