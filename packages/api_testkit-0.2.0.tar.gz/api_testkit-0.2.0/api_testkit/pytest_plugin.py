# import pytest
# from .client import APIClient
# from .auth import login
# from .config import get_config


# def pytest_addoption(parser):
#     group = parser.getgroup("api-testkit")
#     group.addoption("--api-base-url", action="store", help="Base API URL")
#     group.addoption("--email", action="store", help="Login email")
#     group.addoption("--password", action="store", help="Login password")
#     group.addoption("--ignore-https-errors", action="store_true")


# @pytest.fixture(scope="session")
# def api_request(pytestconfig):
#     cfg = get_config(pytestconfig)

#     client = APIClient(
#         base_url=cfg["base_url"],
#         ignore_https_errors=cfg["ignore_https_errors"]
#     )

#     # 🔐 Perform login
#     tokens = login(client, cfg["email"], cfg["password"])

#     # 💾 Store tokens inside client (NO header setting here)
#     client.set_tokens(
#         access=tokens["accessToken"],
#         refresh=tokens.get("refreshToken")
#     )

#     yield client
#     client.close()


# @pytest.fixture(scope="session")
# def unauth_api_request(pytestconfig):
#     cfg = get_config(pytestconfig)

#     client = APIClient(
#         base_url=cfg["base_url"],
#         ignore_https_errors=cfg["ignore_https_errors"]
#     )

#     yield client
#     client.close()


import pytest
from .client import APIClient
from .auth import login
from .config import get_config
 
 
# def pytest_addoption(parser):
#     group = parser.getgroup("api-testkit")
#     group.addoption("--api-base-url", action="store", help="Base API URL")
#     group.addoption("--email", action="store", help="Login email")
#     group.addoption("--password", action="store", help="Login password")
#     group.addoption("--ignore-https-errors", action="store_true")
 
def pytest_addoption(parser):
    group = parser.getgroup("api-testkit")
 
    group.addoption(
        "--api-base-url",
        "--base-url",
        action="store",
        dest="base_url",
        help="Base API URL"
    )
 
    group.addoption("--email", action="store", help="Login email")
    group.addoption("--password", action="store", help="Login password")
 
    group.addoption(
        "--ignore-https-errors",
        action="store_true",
        dest="ignore_https_errors"
    )
 
@pytest.fixture(scope="session")
def api_request(pytestconfig):
    cfg = get_config(pytestconfig)
 
    client = APIClient(
        base_url=cfg["base_url"],
        ignore_https_errors=cfg["ignore_https_errors"]
    )
 
    # 🔐 Perform login
    tokens = login(client, cfg["email"], cfg["password"])
 
    #  Store tokens inside client (NO header setting here)
    client.set_tokens(
        access=tokens["accessToken"],
        refresh=tokens.get("refreshToken")
    )
 
    yield client
    client.close()
 
 
@pytest.fixture(scope="session")
def unauth_api_request(pytestconfig):
    cfg = get_config(pytestconfig)
 
    client = APIClient(
        base_url=cfg["base_url"],
        ignore_https_errors=cfg["ignore_https_errors"]
    )
 
    yield client
    client.close()
