import time
def request_with_retry(func, retries=3, delay=2):
    for _ in range(retries):
        res = func()
        if res.ok:
            return res
        time.sleep(delay)
    return res
