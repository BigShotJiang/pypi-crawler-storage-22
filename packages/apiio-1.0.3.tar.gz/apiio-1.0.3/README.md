# API.io

API.io is a complete local API management dashboard with secure OTP authentication. 

## Features


✅ Secure email OTP authentication system
- Send 6-digit OTP code to any email address
- OTP expires after 15 minutes
- Valid OTP cannot be reused
- Session management (24 hour sessions)

✅ Complete UI included:
- Beautiful landing page
- Email login page
- OTP verification page
- Full API Dashboard
- API Key Management
- API Documentation with code examples
- Usage Analytics with interactive charts
- Mobile responsive design

## Installation

```bash
pip install apiio