# Updated version number
__version__ = "1.0.3"
from apiio.server import app
from apiio.server import start_server
from apiio.email_service import otp_service