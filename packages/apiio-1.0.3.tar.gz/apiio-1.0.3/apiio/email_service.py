import smtplib
import random
import ssl
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


class OTPService:
    def __init__(self):
        self.sender_email = "louatimahdi390@gmail.com"
        self.app_password = "nucm mizw szlu oloq"  # Your app password
        self.otp_storage = {}  # Format: {email: {"otp": code, "expires_at": datetime}}

    def generate_otp(self, email: str, length: int = 6) -> str:
        """Generate 6-digit OTP and store it with 15 minute expiration"""
        otp = ''.join(random.choices('0123456789', k=length))
        expires_at = datetime.now() + timedelta(minutes=15)
        
        self.otp_storage[email] = {
            "otp": otp,
            "expires_at": expires_at
        }
        
        return otp

    def send_otp_email(self, recipient_email: str) -> tuple[bool, str]:
        """Send OTP to user email using your Gmail account"""
        try:
            otp = self.generate_otp(recipient_email)
            
            # Create email message
            message = MIMEMultipart("alternative")
            message["Subject"] = "Your API.io Access OTP Code"
            message["From"] = self.sender_email
            message["To"] = recipient_email

            # HTML email content
            html_content = f"""
            <html>
              <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #0f1014; color: #e5e7eb;">
                <div style="text-align: center; padding: 40px; border-radius: 12px; background-color: #1a1b23; border: 1px solid #2e2e3a;">
                  <h1 style="color: #3b82f6;">API.io</h1>
                  <h2 style="color: white;">Your One-Time Password</h2>
                  <p style="font-size: 18px; margin: 30px 0;">Enter this code to access your dashboard:</p>
                  
                  <div style="font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #3b82f6; padding: 20px; background-color: #0f1014; border-radius: 8px; margin: 20px 0;">
                    {otp}
                  </div>
                  
                  <p style="color: #9ca3af;">This OTP will expire in 15 minutes.</p>
                  <p style="color: #9ca3af; font-size: 14px; margin-top: 30px;">
                    If you did not request this code, you can safely ignore this email.
                  </p>
                </div>
              </body>
            </html>
            """

            part = MIMEText(html_content, "html")
            message.attach(part)

            # Send email using Gmail SMTP server
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
                server.login(self.sender_email, self.app_password)
                server.sendmail(self.sender_email, recipient_email, message.as_string())

            return True, f"OTP sent successfully to {recipient_email}"
            
        except Exception as e:
            return False, f"Failed to send email: {str(e)}"

    def verify_otp(self, email: str, user_provided_otp: str) -> bool:
        """Verify if the OTP provided by user is correct and not expired"""
        otp_data = self.otp_storage.get(email)
        
        if not otp_data:
            return False
            
        # Check if OTP is expired
        if datetime.now() > otp_data["expires_at"]:
            del self.otp_storage[email]
            return False
            
        # Check if OTP matches
        if otp_data["otp"] == user_provided_otp.strip():
            # OTP is valid, delete it so it can't be reused
            del self.otp_storage[email]
            return True
            
        return False


# Initialize singleton instance
otp_service = OTPService()