import typer
from typing import Optional

app = typer.Typer(
    name="api.io",
    help="✅ API.io - Local API Dashboard with OTP Authentication",
    add_completion=False
)


@app.command(name="start")
def start_server(
    host: Optional[str] = typer.Option("127.0.0.1", help="Host address to bind to"),
    port: Optional[int] = typer.Option(8000, help="Port number to use"),
    no_browser: Optional[bool] = typer.Option(False, help="Do not open browser automatically")
):
    """
    🚀 Start API.io server and open your dashboard locally at http://localhost:8000
    """
    from apiio.server import start_server
    start_server(host=host, port=port, open_browser=not no_browser)


@app.command(name="version")
def show_version():
    """📌 Show current version of API.io"""
    typer.echo("API.io v1.0.3")


if __name__ == "__main__":
    app()