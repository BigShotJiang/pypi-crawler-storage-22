from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import uvicorn
import webbrowser
from uuid import uuid4
from datetime import datetime, timedelta
from pathlib import Path
import os

from apiio.email_service import otp_service

app = FastAPI(title="API.io Dashboard")

# Setup paths
BASE_PATH = Path(__file__).parent

# Load HTML templates - This will always work
templates = Jinja2Templates(directory=str(BASE_PATH / "templates"))

# ✅ FIX: Automatically create static folder if it does not exist
# This eliminates the "directory does not exist" error forever
static_folder_path = BASE_PATH / "static"
static_folder_path.mkdir(exist_ok=True)

# Now it is safe to mount static files
app.mount("/static", StaticFiles(directory=static_folder_path), name="static")

# In-memory user sessions
user_sessions = {}  # Format: {session_token: {"email": string, "expires_at": datetime}}


def get_authenticated_user(request: Request):
    """Dependency to check if user is logged in via valid session"""
    session_token = request.cookies.get("session_token")
    
    if not session_token:
        return None
        
    session_data = user_sessions.get(session_token)
    
    if not session_data:
        return None
        
    # Check if session is expired
    if datetime.now() > session_data["expires_at"]:
        del user_sessions[session_token]
        return None
        
    return session_data["email"]


@app.get("/", response_class=HTMLResponse)
async def home(request: Request, user: str = Depends(get_authenticated_user)):
    """Landing page. If user is already authenticated, redirect to dashboard"""
    if user:
        return RedirectResponse(url="/dashboard")
        
    return templates.TemplateResponse("landing.html", {"request": request})


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})


@app.post("/send-otp")
async def send_otp(email: str = Form(...)):
    """Send OTP to user email and redirect to verification page"""
    success, message = otp_service.send_otp_email(email)
    
    if not success:
        return templates.TemplateResponse("login.html", {
            "request": request, 
            "error": message
        })
    
    # Store email temporarily in cookie for verification step
    response = RedirectResponse(url="/verify-otp", status_code=303)
    response.set_cookie(key="pending_email", value=email, max_age=900)  # 15 minutes
    return response


@app.get("/verify-otp", response_class=HTMLResponse)
async def verify_otp_page(request: Request, error: str = None):
    email = request.cookies.get("pending_email")
    
    if not email:
        return RedirectResponse(url="/login")
        
    return templates.TemplateResponse("otp_verify.html", {
        "request": request,
        "email": email,
        "error": error
    })


@app.post("/verify-otp")
async def verify_otp_submit(request: Request, otp: str = Form(...)):
    email = request.cookies.get("pending_email")
    
    if not email:
        return RedirectResponse(url="/login")
    
    if otp_service.verify_otp(email, otp):
        # Create session for authenticated user
        session_token = str(uuid4())
        user_sessions[session_token] = {
            "email": email,
            "expires_at": datetime.now() + timedelta(hours=24)
        }
        
        # Redirect to dashboard
        response = RedirectResponse(url="/dashboard", status_code=303)
        response.set_cookie(key="session_token", value=session_token, max_age=86400)  # 24 hours
        response.delete_cookie(key="pending_email")
        return response
    else:
        return templates.TemplateResponse("otp_verify.html", {
            "request": request,
            "email": email,
            "error": "Invalid or expired OTP. Please try again."
        })


@app.get("/dashboard")
@app.get("/keys")
@app.get("/analytics")
@app.get("/docs")
async def serve_dashboard(request: Request, user: str = Depends(get_authenticated_user)):
    """All protected routes. User must be authenticated to access."""
    if not user:
        return RedirectResponse(url="/login")
        
    return templates.TemplateResponse("dashboard.html", {"request": request})


@app.get("/logout")
async def logout(request: Request):
    session_token = request.cookies.get("session_token")
    
    if session_token in user_sessions:
        del user_sessions[session_token]
        
    response = RedirectResponse(url="/", status_code=303)
    response.delete_cookie(key="session_token")
    return response


# ✅ THIS IS THE FUNCTION THAT MAIN.PY IS TRYING TO IMPORT
# This was missing or unreachable in your previous version
def start_server(host: str = "127.0.0.1", port: int = 8000, open_browser: bool = True):
    """Start the web server"""
    url = f"http://{host}:{port}"
    
    if open_browser:
        webbrowser.open(url)
    
    print("=" * 70)
    print("🚀 API.io Server Started Successfully!")
    print(f"📍 Dashboard available at: {url}")
    print("📩 Login using email OTP authentication to access your dashboard")
    print("=" * 70)
    
    uvicorn.run(app, host=host, port=port)