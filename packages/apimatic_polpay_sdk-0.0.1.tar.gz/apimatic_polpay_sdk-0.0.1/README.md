
# Getting Started with POLi APIs

## Introduction

POLi provides the POLi API consisting of the following web services:  
Initiate Transaction -used to initiate a POLi transaction.

GETTransaction - used to acquire the status and details of a POLi transaction

GETDailyTransactions - used to acquire a list of transactions for a specified date

GETDailyTransactionsCSV - used to acquire a list of transactions for a specified date in csv format

GETFinancialInstitutions - used to acquire a list of Financial Institutions for a specified merchant

NOTE: The Notification URL field in your initiate transaction request must be provided. The POLi system will POST a 'NUDGE' to the specified notification URL and this will prompt your servers to make the GETTransaction API call.

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install apimatic-polpay-sdk==0.0.1
```

You can also view the package at:
https://pypi.python.org/pypi/apimatic-polpay-sdk/0.0.1

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 30** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/logging-configuration.md) | The SDK logging configuration for API calls |
| basic_auth_credentials | [`BasicAuthCredentials`](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/auth/basic-authentication.md) | The credential object for Basic Authentication |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
import logging

from poliapis.configuration import Environment
from poliapis.http.auth.basic_auth import BasicAuthCredentials
from poliapis.logging.configuration.api_logging_configuration import LoggingConfiguration
from poliapis.logging.configuration.api_logging_configuration import RequestLoggingConfiguration
from poliapis.logging.configuration.api_logging_configuration import ResponseLoggingConfiguration
from poliapis.poli_apis_client import PoliApisClient

client = PoliApisClient(
    basic_auth_credentials=BasicAuthCredentials(
        username='BasicAuthUserName',
        password='BasicAuthPassword'
    ),
    environment=Environment.PRODUCTION,
    logging_configuration=LoggingConfiguration(
        log_level=logging.INFO,
        request_logging_config=RequestLoggingConfiguration(
            log_body=True
        ),
        response_logging_config=ResponseLoggingConfiguration(
            log_headers=True
        )
    )
)
```

### Environment-Based Client Initialization

```python
from poliapis.poli_apis_client import PoliApisClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = PoliApisClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** Production environment |
| ENVIRONMENT2 | UAT environment |

## Authorization

This API uses the following authentication schemes.

* [`Basic (Basic Authentication)`](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/auth/basic-authentication.md)

## List of APIs

* [Payments API](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/controllers/payments-api.md)
* [PoLi Links API](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/controllers/poli-links-api.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/proxy-settings.md)
* [Environment-Based Client Initialization](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/environment-based-client-initialization.md)
* [AbstractLogger](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/abstract-logger.md)
* [LoggingConfiguration](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/logging-configuration.md)
* [RequestLoggingConfiguration](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/request-logging-configuration.md)
* [ResponseLoggingConfiguration](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/response-logging-configuration.md)

### HTTP

* [HttpResponse](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/http-response.md)
* [HttpRequest](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/http-request.md)

### Utilities

* [ApiResponse](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/api-response.md)
* [ApiHelper](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/sdks-io/apimatic-polpay-python-sdk/tree/0.0.1/doc/unix-date-time.md)

