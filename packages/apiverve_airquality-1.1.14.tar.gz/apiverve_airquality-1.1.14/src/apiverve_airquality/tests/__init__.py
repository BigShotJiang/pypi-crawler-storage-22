# Initialize test module
