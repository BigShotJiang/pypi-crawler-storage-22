class DomainavailabilityDomainAvailabilityAPIError(Exception):
    """A custom exception for API errors"""
    pass
