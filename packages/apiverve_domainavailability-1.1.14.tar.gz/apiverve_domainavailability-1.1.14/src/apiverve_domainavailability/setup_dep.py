from setuptools import setup, find_packages

setup(
    name='apiverve_domainavailability',
    version='1.1.14',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'requests',
        'setuptools'
    ],
    description='Domain Availability Checker is a simple tool for checking the availability of a domain. It returns if the domain is available or not.',
    author='APIVerve',
    author_email='hello@apiverve.com',
    url='https://domainavailability.apiverve.com?utm_source=pypi&utm_medium=homepage',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
