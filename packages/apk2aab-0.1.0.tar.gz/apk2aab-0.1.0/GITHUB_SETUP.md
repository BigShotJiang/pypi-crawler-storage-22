# Setting Up GitHub for Your Package

This guide will help you set up a GitHub repository for your `apk2aab` package.

## 🚀 Step 1: Create GitHub Repository

1. **Go to GitHub**: https://github.com/new

2. **Fill in repository details**:
   - Repository name: `apk2aab`
   - Description: `Convert Android APK files to AAB (Android App Bundle) for Google Play Store`
   - Choose: **Public** (required for PyPI)
   - ✅ Add a README file: **NO** (we already have one)
   - ✅ Add .gitignore: **NO** (we already have one)
   - ✅ Choose a license: **NO** (we already have LICENSE)

3. **Click**: "Create repository"

## 🔧 Step 2: Initialize Git and Push Code

Open PowerShell in your project directory:

```powershell
cd C:\Users\nithi\Downloads\apk2abb

# Initialize git repository
git init

# Add all files
git add .

# Make first commit
git commit -m "Initial commit - apk2aab package v0.1.0"

# Rename branch to main
git branch -M main

# Add GitHub remote (replace with your actual repo URL)
git remote add origin https://github.com/nithinjambula/apk2aab.git

# Push to GitHub
git push -u origin main
```

## 🔐 Step 3: Set Up PyPI API Token Secret

For automated publishing via GitHub Actions:

1. **Get your PyPI API token**:
   - Go to https://pypi.org/manage/account/
   - Scroll to "API tokens"
   - Click "Add API token"
   - Name: `GitHub Actions apk2aab`
   - Scope: "Entire account" or select your project after first manual upload
   - **Copy the token** (starts with `pypi-...`)

2. **Add token to GitHub**:
   - Go to your repository: `https://github.com/nithinjambula/apk2aab`
   - Click **Settings** tab
   - In left sidebar, click **Secrets and variables** → **Actions**
   - Click **New repository secret**
   - Name: `PYPI_API_TOKEN`
   - Value: Paste your PyPI token
   - Click **Add secret**

## 🎯 Step 4: Understanding GitHub Workflows

Your package now has 3 automated workflows in `.github/workflows/`:

### 1. **CI (Continuous Integration)** - `ci.yml`
- **Runs on**: Every push to main/develop, and all pull requests
- **Tests**: Package builds correctly on Windows, macOS, and Linux
- **Python versions**: Tests on Python 3.7, 3.8, 3.9, 3.10, 3.11
- **Checks**: Runs tests, builds package, validates with twine

### 2. **Publish to PyPI** - `publish.yml`
- **Runs on**: When you create a GitHub Release
- **Does**: Automatically builds and publishes to PyPI
- **Requires**: `PYPI_API_TOKEN` secret (Step 3)

### 3. **Test Build** - `test-build.yml`
- **Runs on**: Manual trigger only
- **Does**: Tests building the package without publishing
- **Use**: To verify package builds correctly before creating a release

## 📦 Step 5: Publishing a New Version

### Option A: Manual Publishing (Traditional)

```powershell
# Update version in 3 files:
# - setup.py (line 17)
# - pyproject.toml (line 6)
# - apk2aab/__init__.py (line 7)

# Build and upload
python -m build
twine upload dist/*
```

### Option B: Automated Publishing via GitHub (Recommended)

1. **Update version** in the 3 files mentioned above

2. **Commit and push changes**:
   ```powershell
   git add .
   git commit -m "Bump version to 0.1.1"
   git push
   ```

3. **Create a GitHub Release**:
   - Go to: `https://github.com/nithinjambula/apk2aab/releases`
   - Click: **Create a new release**
   - Click: **Choose a tag** → Type: `v0.1.1` → **Create new tag**
   - Release title: `v0.1.1`
   - Description: Write what changed (e.g., "Bug fixes and improvements")
   - Click: **Publish release**

4. **GitHub Actions will automatically**:
   - Build the package
   - Run tests
   - Publish to PyPI

5. **Check the workflow**:
   - Go to **Actions** tab
   - Watch the "Publish to PyPI" workflow run

## 🏷️ Step 6: Add Badges to README (Optional)

Your README already has badge placeholders. After publishing, they'll work automatically!

Example badges:
```markdown
[![PyPI version](https://badge.fury.io/py/apk2aab.svg)](https://badge.fury.io/py/apk2aab)
[![Python Support](https://img.shields.io/pypi/pyversions/apk2aab.svg)](https://pypi.org/project/apk2aab/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/nithinjambula/apk2aab/ci.yml?branch=main)](https://github.com/nithinjambula/apk2aab/actions)
```

## 🔄 Regular Workflow

When you make changes:

```powershell
# Make your code changes

# Test locally
python test_package.py

# Commit changes
git add .
git commit -m "Description of changes"
git push

# For new release:
# 1. Update version numbers
# 2. Commit and push
# 3. Create GitHub Release
# 4. Automated publishing happens!
```

## 📊 Monitoring

### Check CI Status
- Go to: `https://github.com/nithinjambula/apk2aab/actions`
- Green ✓ = All tests passed
- Red ✗ = Something failed, click to see details

### Check PyPI Downloads
- Go to: `https://pypi.org/project/apk2aab/`
- See download statistics (may take 24 hours to appear)

## 🛠️ Useful Git Commands

```powershell
# Check status
git status

# See what changed
git diff

# View commit history
git log --oneline

# Create a new branch
git checkout -b feature-name

# Switch back to main
git checkout main

# Pull latest changes
git pull

# Tag a version
git tag v0.1.0
git push --tags
```

## 🎓 GitHub Best Practices

1. **Write good commit messages**:
   - ✅ "Fix APK conversion for large files"
   - ❌ "fix stuff"

2. **Use branches for big changes**:
   ```powershell
   git checkout -b feature/new-feature
   # Make changes
   git add .
   git commit -m "Add new feature"
   git push -u origin feature/new-feature
   # Then create Pull Request on GitHub
   ```

3. **Keep README updated**: Document new features and changes

4. **Use GitHub Issues**: Track bugs and feature requests

5. **Respond to Issues**: Help users who have problems

## 🔐 Security Notes

- ✅ **Never commit** your PyPI API token to Git
- ✅ **Use GitHub Secrets** for sensitive data
- ✅ **Review** what files are committed (check .gitignore)
- ✅ **Don't commit** actual keystores or passwords

## 📚 Resources

- **GitHub Docs**: https://docs.github.com/
- **GitHub Actions**: https://docs.github.com/en/actions
- **Releasing**: https://docs.github.com/en/repositories/releasing-projects-on-github

---

**Your repository**: https://github.com/nithinjambula/apk2aab

**After setup, you'll have**:
- ✅ Automated testing on every push
- ✅ Automated PyPI publishing on release
- ✅ Professional open-source project
- ✅ Easy collaboration with contributors

🎉 **Happy coding!**
