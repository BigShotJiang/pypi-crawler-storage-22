#!/usr/bin/env python3
"""
Setup configuration for apk2aab package
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
if readme_file.exists():
    with open(readme_file, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "Convert Android APK files to AAB (Android App Bundle) format for Google Play Store"

setup(
    name="apk2aab",
    version="0.1.0",
    author="Nithin Jambula",
    author_email="nithinjambula89@gmail.com",
    description="Convert Android APK files to AAB (Android App Bundle) for Google Play Store publishing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/nithinjambula/apk2aab",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        # No external Python dependencies
    ],
    entry_points={
        "console_scripts": [
            "apk2aab-setup=apk2aab.download_bundletool:main",
            "apk2aab-cert=apk2aab.cert_manager:main",
            "apk2aab-convert=apk2aab.apk_to_aab:main",
            "apk2aab-analyze=apk2aab.analyze_aab:main",
        ],
    },
    keywords="apk aab android app bundle google play store converter",
    project_urls={
        "Bug Reports": "https://github.com/nithinjambula/apk2aab/issues",
        "Source": "https://github.com/nithinjambula/apk2aab",
    },
)
