# APK to AAB Converter

[![PyPI version](https://badge.fury.io/py/apk2abb.svg)](https://badge.fury.io/py/apk2abb)
[![Python Support](https://img.shields.io/pypi/pyversions/apk2abb.svg)](https://pypi.org/project/apk2abb/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Convert your Android APK files to Android App Bundle (AAB) format for Google Play Store deployment.

## Overview

This package automates the conversion of APK files to AAB (Android App Bundle) format using Google's bundletool, without requiring Android Studio. Perfect for publishing apps to the Google Play Store.

### Features

- ✅ **Simple Installation**: `pip install apk2abb`
- ✅ **Automated Setup**: Downloads bundletool automatically
- ✅ **Certificate Management**: Create and manage keystores
- ✅ **APK to AAB Conversion**: Convert APK files to AAB format
- ✅ **Automatic Signing**: Sign AAB files with your keystore
- ✅ **AAB Analysis**: Inspect AAB file contents
- ✅ **Comprehensive Logging**: Track all operations

## Prerequisites

- **Java 11+**: Required by Google's bundletool
  ```bash
  java -version
  ```
- **Python 3.7+**: Required for running the package
- **keytool**: Usually comes with Java (for certificate management)

## Installation

Install from PyPI:

```bash
pip install apk2abb
```

Or install from source:

```bash
git clone https://github.com/nithin434/apk2abb.git
cd apk2abb
pip install -e .
```

## Quick Start

### 1. Initial Setup

After installation, set up the required tools:

```bash
# Download bundletool
apk2abb-setup

# Create a keystore for signing
apk2abb-cert
```

This will create the following directories in your current working directory:
- `tools/` - Bundletool and other required tools
- `certs/` - Your keystores and certificates
- `logs/` - Log files from operations
- `output/` - Generated AAB files

### 2. Convert APK to AAB

```bash
apk2abb-convert path/to/your-app.apk
```

That's it! Your AAB file will be created in the `output/` directory.

### 3. Analyze AAB File

```bash
apk2abb-analyze output/your-app.aab
```

## Usage

### Command Line Interface

The package provides four command-line tools:

#### `apk2abb-setup`
Downloads and configures Google's bundletool:
```bash
apk2abb-setup
```

#### `apk2abb-cert`
Creates and manages keystores for signing:
```bash
apk2abb-cert
```

**Important**: Change the default passwords in production! Edit the keystore credentials in `certs/iot_marketplace_app.keystore`.

#### `apk2abb-convert`
Converts APK to AAB and signs it:
```bash
# Convert and sign
apk2abb-convert your-app.apk

# Convert without signing
apk2abb-convert your-app.apk --no-sign
```

#### `apk2abb-analyze`
Displays information about an AAB file:
```bash
apk2abb-analyze output/your-app.aab
```

### Python API

You can also use the package in your Python code:

```python
from apk2abb import APKtoAABConverter

# Create converter instance
converter = APKtoAABConverter()

# Convert APK to AAB
converter.process_apk("path/to/your-app.apk", sign=True)
```

```python
from apk2abb import create_keystore

# Create a custom keystore
create_keystore(
    keystore_path="my-app.keystore",
    keystore_pass="my-secure-password",
    alias="my-app-key",
    alias_pass="my-key-password",
    validity_days=25550  # ~70 years
)
```

## Directory Structure

After installation and setup, your working directory will have:

```
your-project/
├── tools/              # Bundletool JAR (auto-downloaded)
├── certs/              # Your keystores  
│   └── iot_marketplace_app.keystore
├── output/             # Generated AAB files
│   └── your-app.aab
└── logs/               # Operation logs
    ├── setup.log
    ├── cert.log
    └── conversion.log
```

**Note**: These directories are created in your current working directory, NOT in the package installation directory.

## Workflow

1. **Setup** (one-time):
   ```bash
   apk2abb-setup     # Download bundletool
   apk2abb-cert      # Create keystore
   ```

2. **Convert** (repeat as needed):
   ```bash
   apk2abb-convert your-app.apk
   ```

3. **Verify**:
   ```bash
   apk2abb-analyze output/your-app.aab
   ```

The AAB file will be created in the `output/` directory and is ready for Google Play Store upload!

## Configuration

### Keystore Credentials

**⚠️ Security Warning**: The default keystore uses demo credentials. For production:

1. Create your own keystore:
   ```bash
   keytool -genkey -v -keystore certs/my-app.keystore \
     -keyalg RSA -keysize 2048 -validity 25550 \
     -alias my-app-key
   ```

2. Update your code to use custom credentials:
   ```python
   from apk2abb import APKtoAABConverter
   
   converter = APKtoAABConverter()
   converter.keystore_path = "certs/my-app.keystore"
   converter.keystore_pass = "your-secure-password"
   converter.key_alias = "my-app-key"
   converter.key_pass = "your-key-password"
   
   converter.process_apk("your-app.apk")
   ```

### Bundletool Version

The package uses bundletool version 1.15.6 by default. To use a different version, you can download it manually to `tools/bundletool.jar`.

## Troubleshooting

### Java not found
```bash
# Check Java installation
java -version

# Install Java (Ubuntu/Debian)
sudo apt install default-jdk

# Install Java (macOS)
brew install openjdk@11

# Install Java (Windows)
# Download from https://www.oracle.com/java/technologies/downloads/
```

### Keystore issues
```bash
# List keystore contents
keytool -list -v -keystore certs/iot_marketplace_app.keystore

# Verify with password (default: iot_app_12345)
```

### Bundletool not downloaded
```bash
# Manually run setup again
apk2abb-setup
```

## Logs

All operations are logged to the `logs/` directory:
- `setup.log` - Bundletool download logs
- `cert.log` - Certificate operations
- `conversion.log` - APK to AAB conversion logs

View logs in real-time:
```bash
# Windows PowerShell
Get-Content logs/conversion.log -Wait

# Linux/Mac
tail -f logs/conversion.log
```

## Play Store Deployment

After generating your AAB file:

1. Sign in to [Google Play Console](https://play.google.com/console)
2. Select your app (or create a new one)
3. Go to **Release** → **Production** (or Testing track)
4. Click **Create new release**
5. Upload your AAB file from the `output/` directory
6. Complete the release details and publish

## Requirements

- Python 3.7 or higher
- Java 11 or higher
- Internet connection (for initial bundletool download)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Uses [Google's bundletool](https://github.com/google/bundletool) for AAB generation
- Built for easy Play Store deployment without Android Studio

## Support

If you encounter any issues or have questions:
- Open an issue on [GitHub](https://github.com/nithin434/apk2abb/issues)
- Check the logs in the `logs/` directory for detailed error messages

## Changelog

### Version 0.1.0 (2026-02-15)
- Initial release
- APK to AAB conversion
- Automatic bundletool download
- Keystore management
- AAB signing
- Command-line interface
- Python API

---

**Made with ❤️ for Android developers**
