# Example usages for apk2abb package

"""
This file contains example code snippets showing how to use the apk2abb package.
"""

# Example 1: Basic APK to AAB conversion using CLI
"""
After installing the package with: pip install apk2abb

# Step 1: Download bundletool
apk2abb-setup

# Step 2: Create keystore
apk2abb-cert

# Step 3: Convert APK to AAB
apk2abb-convert path/to/your-app.apk

# Step 4: Analyze the AAB file
apk2abb-analyze output/your-app.aab
"""

# Example 2: Using the Python API
"""
from apk2abb import APKtoAABConverter

# Create converter instance
converter = APKtoAABConverter()

# Convert APK to AAB with signing
converter.process_apk("path/to/your-app.apk", sign=True)

# Convert without signing
converter.process_apk("path/to/your-app.apk", sign=False)
"""

# Example 3: Custom keystore configuration
"""
from apk2abb import APKtoAABConverter

converter = APKtoAABConverter()

# Use custom keystore
converter.keystore_path = "path/to/custom.keystore"
converter.keystore_pass = "your-secure-password"
converter.key_alias = "your-key-alias"
converter.key_pass = "your-key-password"

# Process with custom keystore
converter.process_apk("your-app.apk")
"""

# Example 4: Create a custom keystore
"""
from apk2abb import create_keystore

# Create a new keystore
create_keystore(
    keystore_path="my-app.keystore",
    keystore_pass="my-secure-password",
    alias="my-app-key",
    alias_pass="my-key-password",
    validity_days=25550  # ~70 years
)
"""

# Example 5: Validate an existing keystore
"""
from apk2abb import validate_keystore, list_keystore_info

# Validate keystore
is_valid = validate_keystore(
    keystore_path="certs/iot_marketplace_app.keystore",
    keystore_pass="iot_app_12345",
    alias="iot_marketplace"
)

if is_valid:
    # List keystore information
    list_keystore_info(
        keystore_path="certs/iot_marketplace_app.keystore",
        keystore_pass="iot_app_12345"
    )
"""

# Example 6: Check prerequisites
"""
from apk2abb import check_java, download_bundletool

# Check if Java is installed
if check_java():
    print("Java is ready!")
    
    # Download bundletool if needed
    download_bundletool()
else:
    print("Please install Java 11 or higher")
"""

# Example 7: Batch conversion
"""
from apk2abb import APKtoAABConverter
from pathlib import Path

converter = APKtoAABConverter()

# Convert multiple APK files
apk_directory = Path("apks")
for apk_file in apk_directory.glob("*.apk"):
    print(f"Converting {apk_file.name}...")
    converter.process_apk(str(apk_file), sign=True)
    print(f"✓ Completed {apk_file.name}")
"""

# Example 8: Environment-based configuration
"""
import os
from apk2abb import APKtoAABConverter

converter = APKtoAABConverter()

# Use environment variables for sensitive data
converter.keystore_pass = os.getenv("KEYSTORE_PASSWORD", "default-password")
converter.key_pass = os.getenv("KEY_PASSWORD", "default-password")

# Process APK
converter.process_apk("your-app.apk")
"""

if __name__ == "__main__":
    print("=" * 60)
    print("apk2abb Package - Example Usage")
    print("=" * 60)
    print("\nThis file contains example code snippets.")
    print("Read the file contents to see various usage examples.")
    print("\nFor more information, see:")
    print("  - README.md")
    print("  - QUICKSTART.md")
    print("  - PUBLISHING.md")
    print("=" * 60)
