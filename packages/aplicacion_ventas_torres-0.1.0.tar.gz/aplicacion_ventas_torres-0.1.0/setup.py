from setuptools import setup, find_packages

setup(
    name='Aplicacion_ventas_Torres',
    version="0.1.0",
    author='Emerson Torres',
    author_email="emerson.torres@correo.com",
    description="Paquete para gestionar una aplicación de ventas, precios, impuestos y descuentos",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url="https://github.com/emerson-torres/Aplicacion_ventas",
    packages=find_packages(),
    install_requires=[],
    classifiers=[
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    ],

    python_requires='>=3.6',    
)

#https://pypi.org/account/register/  para crear cuenta en pypi