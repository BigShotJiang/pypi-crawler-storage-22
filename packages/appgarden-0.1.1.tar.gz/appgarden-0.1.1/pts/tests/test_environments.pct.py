# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
#|default_exp test_environments

# %%
#|hide
from nblite import nbl_export; nbl_export();

# %% [markdown]
# # Environment Tests
#
# Unit tests for appgarden.toml parsing, environment resolution,
# and app name derivation.

# %%
#|export
import pytest
from pathlib import Path

from appgarden.environments import (
    load_project_config, resolve_environment, resolve_all_environments,
    derive_app_name, list_environments,
    ProjectConfig, EnvironmentConfig,
)
from appgarden.cli import _resolve_deploy_params, _env_config_to_dict, DEPLOY_DEFAULTS

# %% [markdown]
# ## Sample TOML content

# %%
#|export
SAMPLE_TOML = """\
[app]
name = "mywebsite"
method = "dockerfile"
container_port = 3000
source = "."

[environments.production]
server = "myserver"
url = "mywebsite.apps.example.com"
branch = "main"
env = { NODE_ENV = "production" }

[environments.staging]
server = "myserver"
url = "mywebsite-staging.apps.example.com"
branch = "staging"
env = { NODE_ENV = "staging" }

[environments.dev]
server = "myserver"
url = "mywebsite-dev.apps.example.com"
branch = "develop"
env = { NODE_ENV = "development", DEBUG = "true" }
"""

# %% [markdown]
# ## load_project_config

# %%
#|export
def test_load_project_config(tmp_path):
    """Loads appgarden.toml and parses app + environments."""
    (tmp_path / "appgarden.toml").write_text(SAMPLE_TOML)
    cfg = load_project_config(tmp_path)
    assert cfg.app_name == "mywebsite"
    assert cfg.app_defaults["method"] == "dockerfile"
    assert "production" in cfg.environments
    assert "staging" in cfg.environments
    assert "dev" in cfg.environments

# %%
#|export
def test_load_project_config_missing(tmp_path):
    """Raises FileNotFoundError when no appgarden.toml exists."""
    with pytest.raises(FileNotFoundError):
        load_project_config(tmp_path)

# %%
#|export
def test_load_project_config_no_name(tmp_path):
    """Raises ValueError when [app] section has no name."""
    (tmp_path / "appgarden.toml").write_text("[app]\nmethod = 'static'\n")
    with pytest.raises(ValueError, match="must have.*name"):
        load_project_config(tmp_path)

# %% [markdown]
# ## derive_app_name

# %%
#|export
def test_derive_app_name_production():
    """Production environment uses base name without suffix."""
    assert derive_app_name("myapp", "production") == "myapp"

# %%
#|export
def test_derive_app_name_staging():
    """Non-production environments get a suffix."""
    assert derive_app_name("myapp", "staging") == "myapp-staging"

# %%
#|export
def test_derive_app_name_dev():
    """Dev environment gets -dev suffix."""
    assert derive_app_name("myapp", "dev") == "myapp-dev"

# %% [markdown]
# ## resolve_environment

# %%
#|export
def test_resolve_production(tmp_path):
    """Production env merges app defaults with env overrides."""
    (tmp_path / "appgarden.toml").write_text(SAMPLE_TOML)
    cfg = load_project_config(tmp_path)
    env = resolve_environment(cfg, "production")

    assert env.name == "production"
    assert env.app_name == "mywebsite"
    assert env.method == "dockerfile"
    assert env.url == "mywebsite.apps.example.com"
    assert env.branch == "main"
    assert env.container_port == 3000
    assert env.source == "."
    assert env.server == "myserver"
    assert env.env == {"NODE_ENV": "production"}

# %%
#|export
def test_resolve_staging(tmp_path):
    """Staging env has correct suffix and branch."""
    (tmp_path / "appgarden.toml").write_text(SAMPLE_TOML)
    cfg = load_project_config(tmp_path)
    env = resolve_environment(cfg, "staging")

    assert env.name == "staging"
    assert env.app_name == "mywebsite-staging"
    assert env.url == "mywebsite-staging.apps.example.com"
    assert env.branch == "staging"
    assert env.env == {"NODE_ENV": "staging"}

# %%
#|export
def test_resolve_env_merges_env_vars(tmp_path):
    """Environment env vars are merged with app-level env vars."""
    toml = """\
[app]
name = "myapp"
method = "command"
env = { SHARED = "base", OVERRIDE = "app" }

[environments.staging]
url = "staging.example.com"
env = { OVERRIDE = "staging", EXTRA = "yes" }
"""
    (tmp_path / "appgarden.toml").write_text(toml)
    cfg = load_project_config(tmp_path)
    env = resolve_environment(cfg, "staging")

    assert env.env["SHARED"] == "base"
    assert env.env["OVERRIDE"] == "staging"
    assert env.env["EXTRA"] == "yes"

# %%
#|export
def test_resolve_unknown_env(tmp_path):
    """Raises ValueError for undefined environment."""
    (tmp_path / "appgarden.toml").write_text(SAMPLE_TOML)
    cfg = load_project_config(tmp_path)
    with pytest.raises(ValueError, match="not found"):
        resolve_environment(cfg, "nonexistent")

# %% [markdown]
# ## list_environments & resolve_all

# %%
#|export
def test_list_environments(tmp_path):
    """list_environments returns sorted names."""
    (tmp_path / "appgarden.toml").write_text(SAMPLE_TOML)
    cfg = load_project_config(tmp_path)
    names = list_environments(cfg)
    assert names == ["dev", "production", "staging"]

# %%
#|export
def test_resolve_all_environments(tmp_path):
    """resolve_all_environments returns configs for all envs."""
    (tmp_path / "appgarden.toml").write_text(SAMPLE_TOML)
    cfg = load_project_config(tmp_path)
    envs = resolve_all_environments(cfg)
    assert len(envs) == 3
    names = {e.app_name for e in envs}
    assert names == {"mywebsite", "mywebsite-staging", "mywebsite-dev"}

# %% [markdown]
# ## Cascading config resolution

# %%
#|export
def test_cascade_cli_overrides_env():
    """CLI flags override environment config values."""
    env_cfg = {"method": "dockerfile", "branch": "main", "url": "app.example.com"}
    cli = {"branch": "hotfix", "method": None, "url": None}
    result = _resolve_deploy_params(cli, env_cfg=env_cfg)
    assert result["branch"] == "hotfix"
    assert result["method"] == "dockerfile"
    assert result["url"] == "app.example.com"

# %%
#|export
def test_cascade_global_defaults():
    """Global defaults fill in values not set by other layers."""
    cli = {"method": None, "source": None}
    global_defaults = {"method": "dockerfile", "container_port": 8080}
    result = _resolve_deploy_params(cli, global_defaults=global_defaults)
    assert result["method"] == "dockerfile"
    assert result["container_port"] == 8080

# %%
#|export
def test_cascade_full():
    """Full cascade: hardcoded < global < project < env < CLI."""
    global_defaults = {"method": "command", "container_port": 9090}
    project_defaults = {"method": "dockerfile", "source": "."}
    env_cfg = {"url": "app.example.com", "branch": "main"}
    cli = {"branch": "hotfix", "method": None, "source": None, "url": None}
    result = _resolve_deploy_params(cli, env_cfg=env_cfg, project_defaults=project_defaults, global_defaults=global_defaults)
    # CLI overrides branch
    assert result["branch"] == "hotfix"
    # env provides url
    assert result["url"] == "app.example.com"
    # project overrides global for method
    assert result["method"] == "dockerfile"
    # project provides source
    assert result["source"] == "."
    # global overrides hardcoded for container_port
    assert result["container_port"] == 9090

# %% [markdown]
# ## Subdomain / path / domain fields

# %%
#|export
def test_resolve_subdomain(tmp_path):
    """Environment with subdomain is preserved through resolution."""
    toml = """\
[app]
name = "myapp"
method = "dockerfile"

[environments.production]
subdomain = "myapp"
"""
    (tmp_path / "appgarden.toml").write_text(toml)
    cfg = load_project_config(tmp_path)
    env = resolve_environment(cfg, "production")
    assert env.subdomain == "myapp"
    assert env.url is None

# %%
#|export
def test_resolve_path_prefix(tmp_path):
    """Environment with path is preserved through resolution."""
    toml = """\
[app]
name = "myapp"
method = "static"

[environments.production]
path = "api"
"""
    (tmp_path / "appgarden.toml").write_text(toml)
    cfg = load_project_config(tmp_path)
    env = resolve_environment(cfg, "production")
    assert env.path == "api"
    assert env.subdomain is None

# %%
#|export
def test_cascade_subdomain_overrides_app_default(tmp_path):
    """Subdomain at [app] level can be overridden per environment."""
    toml = """\
[app]
name = "myapp"
method = "dockerfile"
subdomain = "default-sub"

[environments.production]
subdomain = "prod-sub"

[environments.staging]
server = "myserver"
"""
    (tmp_path / "appgarden.toml").write_text(toml)
    cfg = load_project_config(tmp_path)

    prod = resolve_environment(cfg, "production")
    assert prod.subdomain == "prod-sub"

    staging = resolve_environment(cfg, "staging")
    assert staging.subdomain == "default-sub"

# %%
#|export
def test_cascade_subdomain_to_deploy_params(tmp_path):
    """Subdomain from env config flows through _env_config_to_dict into deploy params."""
    toml = """\
[app]
name = "myapp"
method = "dockerfile"
source = "."

[environments.production]
subdomain = "myapp"
"""
    (tmp_path / "appgarden.toml").write_text(toml)
    cfg = load_project_config(tmp_path)
    env = resolve_environment(cfg, "production")
    env_dict = _env_config_to_dict(env)
    assert env_dict["subdomain"] == "myapp"

    cli = {"method": None, "source": None, "url": None, "subdomain": None}
    params = _resolve_deploy_params(cli, env_cfg=env_dict)
    assert params["subdomain"] == "myapp"
    assert params["method"] == "dockerfile"
    assert params["source"] == "."
