"""Reusable pytest fixtures for infra tests."""
