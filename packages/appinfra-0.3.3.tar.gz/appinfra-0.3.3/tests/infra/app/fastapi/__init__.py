"""Tests for FastAPI server framework."""
