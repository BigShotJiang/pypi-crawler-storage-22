# Tests for appinfra.app.tools
