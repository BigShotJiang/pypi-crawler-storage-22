"""Tests for appinfra.security module."""
