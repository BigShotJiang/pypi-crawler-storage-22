# apple-notes

A comprehensive CLI for managing Apple Notes from the terminal. macOS only.

## Install

```bash
uv tool install apple-notes
```

Or run directly without installing:

```bash
uvx apple-notes --help
```

## Usage

```bash
apple-notes --help
```

## Credits

This project is built upon [memo](https://github.com/antoniorodr/memo) by Antonio Rodriguez, licensed under the [MIT License](https://github.com/antoniorodr/memo/blob/main/LICENSE.md).

## License

[MIT](LICENSE)
