import click
from apple_notes.helpers.get_memo import get_note
from apple_notes.helpers.edit_memo import edit_note
from apple_notes.helpers.add_memo import add_note
from apple_notes.helpers.delete_memo import delete_note, delete_note_folder
from apple_notes.helpers.move_memo import move_note
from apple_notes.helpers.choice_memo import pick_note
from apple_notes.helpers.list_folder import notes_folders
from apple_notes.helpers.validation_memo import selection_notes_validation
from apple_notes.helpers.search_memo import fuzzy_notes
from apple_notes.helpers.export_memo import export_memo


@click.group(invoke_without_command=False)
@click.version_option()
def cli():
    """A comprehensive CLI for managing Apple Notes."""
    pass


@cli.command()
@click.option(
    "--folder",
    "-f",
    default="",
    help="Specify a folder to filter the notes (leave empty to get all).",
)
@click.option(
    "--add",
    "-a",
    is_flag=True,
    help="Add a note to the specified folder. Specify a folder using the --folder flag.",
)
@click.option(
    "--title",
    "-t",
    default=None,
    help="Note title (used with --add).",
)
@click.option(
    "--body",
    "-b",
    default=None,
    help="Note body content (used with --add). Also accepts stdin.",
)
@click.option(
    "--edit",
    "-e",
    is_flag=True,
    help="Edit a note in the specified folder. Specify a folder using the --folder flag.",
)
@click.option(
    "--delete",
    "-d",
    is_flag=True,
    help="Delete a note in the specified folder. Specify a folder using the --folder flag.",
)
@click.option(
    "--move",
    "-m",
    is_flag=True,
    help="Move a note to a different folder.",
)
@click.option(
    "--flist",
    "-fl",
    is_flag=True,
    help="List all the folders and subfolders.",
)
@click.option("--search", "-s", is_flag=True, help="Fuzzy search your notes.")
@click.option(
    "--remove",
    "-r",
    is_flag=True,
    help="Remove the folder you specified.",
)
@click.option(
    "--export",
    "-ex",
    is_flag=True,
    help="Export your notes to the Desktop.",
)
def notes(folder, edit, add, title, body, delete, move, flist, search, remove, export):
    """List, create, edit, delete, move, search, and export notes."""
    selection_notes_validation(
        folder, edit, delete, move, add, flist, search, remove, export
    )
    notes_info = get_note()
    note_map = notes_info[0]
    notes_list = notes_info[1]
    notes_list_filter = [
        note for note in enumerate(notes_list, start=1) if folder in note[1]
    ]
    folders = notes_folders()

    if not flist and not search and not remove and not export:
        click.secho("\nFetching notes...", fg="yellow")
        if folder not in folders:
            click.echo("\nThe folder does not exists.")
            click.echo("\nUse 'apple-notes notes -fl' to see your folders")
        elif not notes_list_filter:
            click.echo("\nNo notes found.")
        else:
            list_title = f"Your Notes in folder {folder}:" if folder else "All your notes:"
            click.echo(f"\n{list_title}\n")
            for note in notes_list_filter:
                click.echo(f"{note[0]}. {note[1]}")

    if edit:
        note_id = pick_note(note_map, notes_list_filter, "edit")
        edit_note(note_id)
    if add:
        add_note(folder, title=title, body=body)
    if move:
        note_id = pick_note(note_map, notes_list_filter, "move")
        if note_id is None:
            click.echo("Invalid selection.")
            return
        target_folder = click.prompt(
            "\nEnter the folder you want to move the note to", type=str
        )
        move_note(note_id, target_folder)
    if delete:
        note_id = pick_note(note_map, notes_list_filter, "delete")
        delete_note(note_id)
    if flist:
        click.echo("\nFolders and subfolders in Notes:")
        click.echo(f"\n{folders}")
    if search:
        click.secho("\nFetching notes...\n", fg="yellow")
        fuzzy_notes()
    if remove:
        click.echo(f"\n{folders}")
        click.secho(
            "\n⚠️ Make sure the folder is empty, because the notes it includes will be deleted too.",
            fg="red",
        )
        folder_to_delete = click.prompt(
            "\nEnter the name of the folder to delete",
            type=str,
        )
        delete_note_folder(folder_to_delete)
    if export:
        if click.confirm("\nAre you sure you want to export your notes to HTML?"):
            export_memo()
