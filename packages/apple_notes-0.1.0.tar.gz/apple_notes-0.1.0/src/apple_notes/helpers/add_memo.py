import subprocess
import sys
import click
import mistune


def add_note(folder_name, title=None, body=None):
    """Create a new note in the specified folder.

    Content can be provided via:
    - title and body parameters
    - stdin (reads markdown content from pipe)
    - interactive prompt (if no stdin and no body)
    """
    # Determine note content
    if body is None:
        if not sys.stdin.isatty():
            # Read from stdin
            body = sys.stdin.read().strip()
        else:
            # Interactive prompt
            body = click.prompt("\nEnter note content")

        if title is None:
            # Extract title from first markdown heading, or use first line
            lines = body.split("\n")
            for line in lines:
                stripped = line.strip()
                if stripped.startswith("# "):
                    title = stripped[2:].strip()
                    break
            if title is None:
                title = lines[0].strip()[:50] if lines else "New Note"

    if title is None:
        title = "New Note"

    if not body:
        click.echo("\nNote creation cancelled (empty content).")
        return

    note_html = mistune.markdown(body)

    # Escape for AppleScript
    escaped_title = title.replace("\\", "\\\\").replace('"', '\\"')
    escaped_html = note_html.replace("\\", "\\\\").replace('"', '\\"')
    escaped_folder = folder_name.replace("\\", "\\\\").replace('"', '\\"')

    script = f"""
        tell application "Notes"
            set targetFolder to first folder whose name is "{escaped_folder}"
            tell targetFolder
                make new note with properties {{name:"{escaped_title}", body:"{escaped_html}"}}
            end tell
        end tell
        """

    process = subprocess.run(
        ["osascript", "-e", script], capture_output=True, text=True
    )

    if process.returncode == 0:
        click.echo(f"\nNote '{title}' created in '{folder_name}' folder.")
    else:
        click.echo(f"\nError: Could not create note. {process.stderr}")
