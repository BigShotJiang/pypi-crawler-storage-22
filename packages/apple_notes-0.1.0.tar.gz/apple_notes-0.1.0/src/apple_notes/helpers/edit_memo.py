import subprocess
import sys
import click
import mistune
from apple_notes.helpers.id_search_memo import id_search_memo
from apple_notes.helpers.md_converter import md_converter


def edit_note(note_id, body=None):
    """Edit an existing note.

    New content can be provided via:
    - body parameter
    - stdin (reads markdown content from pipe)
    - interactive prompt (if no stdin and no body)
    """
    result = id_search_memo(note_id)
    original_md, original_html = md_converter(result)

    if "<img" in original_html or "<enclosure" in original_html:
        click.secho(
            "\n⚠️  Warning: This note contains images or attachments that could be lost!",
            fg="yellow",
        )
        if not click.confirm("\nDo you still want to continue editing the note?"):
            return

    if body is None:
        if not sys.stdin.isatty():
            body = sys.stdin.read().strip()
        else:
            click.echo(f"\nCurrent content:\n{original_md}\n")
            body = click.prompt("Enter new content")

    if body == original_md:
        click.secho("\nNo changes made.", fg="yellow")
        return

    edited_html = mistune.markdown(body)
    escaped_html = edited_html.replace("\\", "\\\\").replace('"', '\\"')

    update_script = f"""
        tell application "Notes"
            set selectedNote to first note whose id is "{note_id}"
            set body of selectedNote to "{escaped_html}"
        end tell
        """
    process = subprocess.run(
        ["osascript", "-e", update_script], capture_output=True, text=True
    )
    if process.returncode != 0:
        click.secho("\nError: Could not update note.\n", fg="red")
        click.secho(process.stderr, fg="red")
    else:
        click.secho("\nNote updated.", fg="green")
