# Appose: multi-language interprocess cooperation with shared memory.
# Copyright (C) 2023 - 2025 Appose developers.
# SPDX-License-Identifier: BSD-2-Clause

"""
TODO
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING

from .service import Service
from .syntax import GroovySyntax, PythonSyntax
from .util.filepath import find_exe

if TYPE_CHECKING:
    from .builder import Builder


class Environment:
    def __init__(self, base: Path | str, use_system_path: bool = False):
        self.base_path: Path = Path(base).absolute()
        self.use_system_path: bool = use_system_path

    def base(self) -> str:
        """
        Return the base directory of this environment.

        Returns:
            The absolute path to the base directory
        """
        return str(self.base_path)

    def bin_paths(self) -> list[str]:
        """
        Return the list of binary directories to search for executables.

        Returns:
            List of binary directory paths
        """
        # Default implementation - subclasses should override
        return [str(self.base_path / "bin")]

    def launch_args(self) -> list[str]:
        """
        Return the launch arguments to prepend when starting worker processes.

        Returns:
            List of launch arguments
        """
        # Default implementation - subclasses should override
        return []

    def env_vars(self) -> dict[str, str]:
        """
        Return environment variables to set when launching worker processes.

        Returns:
            Dictionary of environment variable names to values
        """
        # Default implementation - subclasses should override
        return {}

    def builder(self) -> Builder | None:
        """
        Get the builder that created this environment.

        Returns:
            The builder instance, or None if not created via a builder
        """
        # Default implementation - subclasses should override
        return None

    def type(self) -> str:
        """
        Get the type of this environment (e.g., "pixi", "mamba", "uv").

        Returns:
            The environment type name
        """
        builder = self.builder()
        return builder.env_type() if builder else "unknown"

    def rebuild(self) -> Environment:
        """
        Rebuilds this environment from scratch.
        This deletes the existing environment directory and rebuilds it using the
        current builder configuration.

        Returns:
            The newly rebuilt environment.
        Raises:
            BuildException: If something goes wrong during rebuild.
        """
        return self.builder().rebuild()

    def delete(self) -> Environment:
        """
        Deletes the existing environment directory, if any.

        Returns:
            This environment, for fluid chaining.
        Raises:
            OSError: If something goes wrong during deletion.
        """
        self.builder().delete()
        return self

    def python(self) -> Service:
        """
        Create a Python script service.

        This is a *high level* way to create a service, enabling execution of
        Python scripts asynchronously on its linked process running a
        `python_worker`.

        Returns:
            The newly created service.

        Raises:
            IOError: If something goes wrong starting the worker process.

        See Also:
            groovy(): To create a service for Groovy script execution.
        """
        python_exes = [
            "python",
            "python3",
            "python.exe",
            "bin/python",
            "bin/python.exe",
        ]
        return self.service(
            python_exes,
            "-c",
            "import appose.python_worker; appose.python_worker.main()",
        ).syntax(PythonSyntax())

    def groovy(
        self,
        class_path: list[str] | None = None,
        jvm_args: list[str] | None = None,
    ) -> Service:
        """
        Create a Groovy script service.

        Groovy (https://groovy-lang.org/) is a script language for the JVM,
        capable of running Java bytecode conveniently and succinctly, as well
        as downloading and importing dependencies dynamically at runtime using
        its Grape subsystem (https://groovy-lang.org/Grape).

        This is a *high level* way to create a service, enabling execution of
        Groovy scripts asynchronously on its linked process running a
        `GroovyWorker`.

        Args:
            class_path: Additional classpath elements to pass to the JVM
                via its `-cp` command line option.
            jvm_args: Command line arguments to pass to the JVM invocation (e.g. `-Xmx4g`).

        Returns:
            The newly created service.

        Raises:
            IOError: If something goes wrong starting the worker process.

        See Also:
            python(): To create a service for Python script execution.
        """
        return self.java(
            "org.apposed.appose.GroovyWorker", class_path=class_path, jvm_args=jvm_args
        ).syntax(GroovySyntax())

    def java(
        self,
        main_class: str,
        class_path: list[str] | None = None,
        jvm_args: list[str] | None = None,
    ) -> Service:
        # Collect classpath elements into a set, to avoid duplicate entries.
        cp: dict[str] = {}  # NB: Use dict instead of set to maintain insertion order.

        # TODO: Ensure that the classpath includes Appose and its dependencies.

        # Append any explicitly requested classpath elements.
        if class_path is not None:
            for element in class_path:
                cp[element] = None

        # Build up the service arguments.
        args = [
            "-cp",
            os.pathsep.join(cp),
        ]
        if jvm_args is not None:
            args.extend(jvm_args)
        args.append(main_class)

        # Create the service.
        java_exes = [
            "java",
            "java.exe",
            "bin/java",
            "bin/java.exe",
            "jre/bin/java",
            "jre/bin/java.exe",
        ]
        return self.service(java_exes, *args)

    def service(self, exes: list[str], *args) -> Service:
        """
        Create a service with the given command line arguments.

        This is a **low level** way to create a service. It assumes the
        specified executable conforms to the Appose worker process contract,
        meaning it accepts requests on stdin and produces responses on
        stdout, both formatted according to Appose's assumptions.

        Args:
            exes: List of executables to try for launching the worker process.
            args: Command line arguments to pass to the worker process
                (e.g. ["-v", "--enable-everything"]).

        Returns:
            The newly created service.

        See Also:
            groovy(): To create a service for Groovy script execution.
            python(): To create a service for Python script execution.
        """
        if not exes:
            raise ValueError("No executable given")

        # Calculate exe string.
        launch_args_list = self.launch_args()
        if launch_args_list:
            # When there are launchArgs (e.g., "pixi run" or "mamba run"), use the bare
            # executable name. The launcher will activate the environment and find the
            # executable. This approach also avoids issues with pixi/mamba not properly
            # handling executable paths containing spaces.
            exe_path = exes[0]
        else:
            # No launchArgs, so we need to find and use the full path to the executable.
            # Get binary paths from environment configuration
            bin_paths = self.bin_paths()

            # Add system PATH if use_system_path is enabled
            dirs: list[str] = bin_paths if bin_paths else []
            if self.use_system_path:
                dirs.extend(os.environ["PATH"].split(os.pathsep))

            # Fall back to base directory if no bin paths configured
            if not dirs:
                dirs = [str(self.base_path)]

            exe_file = find_exe(dirs, exes)
            if exe_file is None:
                raise ValueError(f"No executables found amongst candidates: {exes}")

            # Use absolute path instead of relative path to preserve symlinks.
            # This is important for Python virtual environments where the python symlink
            # needs to be used directly (not the resolved target) for proper site-packages access.
            exe_path = str(exe_file.absolute())

        # Construct final args list: launchArgs + exe + args
        all_args: list[str] = []
        all_args.extend(launch_args_list)
        all_args.append(exe_path)
        all_args.extend(args)

        return Service(self.base(), self.env_vars(), *all_args)
