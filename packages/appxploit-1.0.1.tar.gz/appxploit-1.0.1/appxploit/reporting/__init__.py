"""Reporting module initialization"""

from appxploit.reporting.generator import ReportGenerator

__all__ = ["ReportGenerator"]
