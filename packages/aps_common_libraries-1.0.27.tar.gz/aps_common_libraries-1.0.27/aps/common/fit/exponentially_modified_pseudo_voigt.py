#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import numpy as np
import matplotlib.pyplot as plt

from scipy.optimize import curve_fit, differential_evolution
from scipy.special import erfc
from scipy.stats import median_abs_deviation


# ============================================================
# 1) Line-shape primitives (unit-area forms)
# ============================================================

def gaussian_unit(x, mu, sigma):
    """Unit-area Gaussian."""
    sigma = np.clip(float(sigma), 1e-14, None)
    z = (x - mu) / sigma
    return np.exp(-0.5 * z * z) / (sigma * np.sqrt(2 * np.pi))


def lorentz_unit(x, mu, gamma):
    """Unit-area Lorentzian."""
    gamma = np.clip(float(gamma), 1e-14, None)
    return (gamma / np.pi) / ((x - mu)**2 + gamma**2)


# ============================================================
# 2) Exponentially-modified components (one-sided tail)
#    tau > 0: right tail, tau < 0: left tail
# ============================================================

def exgauss_unit(x, mu, sigma, tau):
    """
    Unit-area ex-Gaussian:
      Gaussian(mu,sigma) convolved with one-sided exponential(tau).
    """
    x = np.asarray(x, dtype=float)
    sigma = np.clip(float(sigma), 1e-14, None)
    tau = float(tau)
    if np.abs(tau) < 1e-14:
        tau = 1e-14

    z = (mu + (sigma**2)/tau - x) / (np.sqrt(2.0) * sigma)
    y = (1.0 / (2.0 * np.abs(tau))) * np.exp((sigma**2)/(2.0*tau**2) - (x - mu)/tau) * erfc(z)
    return y


def exlorentz_unit_numeric_fft(x, mu, gamma, tau, pad_factor=4):
    """
    Numerically compute ex-Lorentzian (Lorentz * one-sided exponential)
    using FFT on (approximately) uniform x-grid.

    Returns unit-area-like sampled profile on x.
    """
    x = np.asarray(x, dtype=float)
    n = x.size
    if n < 8:
        raise ValueError("Need at least 8 points in x for FFT-based convolution.")

    # check uniform grid
    dxs = np.diff(x)
    dx = np.median(dxs)
    if not np.allclose(dxs, dx, rtol=1e-4, atol=1e-12):
        raise ValueError("x must be (nearly) uniformly spaced for FFT ex-Lorentz.")

    gamma = np.clip(float(gamma), 1e-14, None)
    tau = float(tau)
    if np.abs(tau) < 1e-14:
        tau = 1e-14

    # padded grid to reduce circular artifacts
    m = int(2 ** np.ceil(np.log2(pad_factor * n)))
    x0 = x[0]
    xp = x0 + dx * np.arange(m)

    # center lorentzian on mu
    L = (gamma / np.pi) / ((xp - mu)**2 + gamma**2)

    # one-sided exponential kernel, normalized continuous-like: (1/|tau|) exp(-t/tau) on tau*t >= 0
    t = dx * np.arange(m)
    if tau > 0:
        k = np.exp(-t / tau) / tau
    else:
        # left-tail kernel: equivalent by reversing direction
        # for numeric convolution we model right-tail then mirror around mu mapping:
        # simpler robust approach: use right-tail on mirrored x and map back
        # Here implement by using right-tail and flipping signal coordinates:
        # We'll handle tau<0 by transforming x->-x, mu->-mu externally.
        # So this branch shouldn't be used directly.
        k = np.exp(-t / np.abs(tau)) / np.abs(tau)

    # discrete convolution approximation includes dx
    conv = np.fft.irfft(np.fft.rfft(L, n=m) * np.fft.rfft(k, n=m), n=m) * dx

    # extract first n points corresponding to x
    y = conv[:n]
    return y


def exlorentz_unit(x, mu, gamma, tau):
    """
    Wrapper that supports tau sign:
      tau>0 right tail directly
      tau<0 left tail by mirror transform x->-x, mu->-mu, |tau|
    """
    x = np.asarray(x, dtype=float)
    tau = float(tau)
    if np.abs(tau) < 1e-14:
        tau = 1e-14

    if tau > 0:
        return exlorentz_unit_numeric_fft(x, mu, gamma, tau)
    else:
        # mirror trick: left-tail at x equals right-tail on mirrored axis
        xm = -x[::-1]
        ym = exlorentz_unit_numeric_fft(xm, -mu, gamma, np.abs(tau))
        return ym[::-1]


# ============================================================
# 3) Pseudo-Voigt core with exponential tail (single function)
# ============================================================

def exp_pseudo_voigt_peak(x, A, mu, fwhm, eta, tau, y0):
    """
    Exponentially-modified pseudo-Voigt + constant baseline.

    Core:
      pV = eta * Lorentz(gamma=FWHM/2) + (1-eta) * Gaussian(sigma=FWHM/(2*sqrt(2ln2)))
    Tail:
      one-sided exponential with scale tau (right if tau>0, left if tau<0)

    Parameters
    ----------
    x : array (must be ~uniformly spaced because ex-Lorentz is FFT-based)
    A : total area/intensity scale (>0)
    mu : center
    fwhm : core FWHM (>0)
    eta : Lorentz mixing in [0,1]
    tau : tail constant (sign sets tail side)
    y0 : constant baseline
    """
    x = np.asarray(x, dtype=float)
    A = float(A)
    fwhm = np.clip(float(fwhm), 1e-14, None)
    eta = np.clip(float(eta), 0.0, 1.0)
    tau = float(tau)
    if np.abs(tau) < 1e-14:
        tau = 1e-14

    sigma = fwhm / (2.0 * np.sqrt(2.0 * np.log(2.0)))
    gamma = fwhm / 2.0

    g_tail = exgauss_unit(x, mu, sigma, tau)
    l_tail = exlorentz_unit(x, mu, gamma, tau)

    y = A * ((1.0 - eta) * g_tail + eta * l_tail) + y0
    return y


# ============================================================
# 4) Helpers: guesses, bounds, metrics
# ============================================================

def robust_fwhm_guess(x, y):
    x = np.asarray(x); y = np.asarray(y)
    i0 = np.argmax(y)
    yb = np.percentile(y, 5)
    yp = y - yb
    p = yp[i0]
    if p <= 0:
        return 0.05 * (x.max() - x.min())

    h = 0.5 * p
    left = np.where(yp[:i0] <= h)[0]
    right = np.where(yp[i0:] <= h)[0]
    if left.size and right.size:
        return max(x[i0 + right[0]] - x[left[-1]], 1e-12)
    return 0.05 * (x.max() - x.min())


def initial_guess_epv(x, y):
    x = np.asarray(x); y = np.asarray(y)
    y0 = np.percentile(y, 5)
    i0 = np.argmax(y)
    mu0 = x[i0]
    fwhm0 = robust_fwhm_guess(x, y)

    # area-like A guess from peak height * width
    h = max(y.max() - y0, 1e-9)
    A0 = h * fwhm0

    # skew sign estimate
    yp = np.clip(y - y0, 0, None)
    if yp.sum() > 0:
        m = np.sum(x * yp) / np.sum(yp)
        m3 = np.sum(((x - m)**3) * yp) / np.sum(yp)
        sign = 1.0 if m3 >= 0 else -1.0
    else:
        sign = 1.0

    tau0 = sign * max(0.15 * (x.max() - x.min()), fwhm0)
    eta0 = 0.3
    return np.array([A0, mu0, fwhm0, eta0, tau0, y0], dtype=float)


def bounds_epv(x, y):
    xr = x.max() - x.min()
    yr = max(y.max() - y.min(), 1e-12)
    lb = np.array([
        0.0,                     # A
        x.min(),                 # mu
        1e-12,                   # fwhm
        0.0,                     # eta
        -20.0 * xr,              # tau
        y.min() - 2*max(1.0, abs(y.min()))  # y0
    ], dtype=float)

    ub = np.array([
        200.0 * yr * max(xr, 1e-9),  # A
        x.max(),                     # mu
        xr,                          # fwhm
        1.0,                         # eta
        20.0 * xr,                   # tau
        y.max() + 2*max(1.0, abs(y.max()))  # y0
    ], dtype=float)
    return lb, ub


def fit_metrics(y, yhat, k):
    y = np.asarray(y); yhat = np.asarray(yhat)
    n = y.size
    r = y - yhat
    sse = np.sum(r**2)
    rmse = np.sqrt(sse / n)
    tss = np.sum((y - y.mean())**2)
    r2 = 1.0 - sse/tss if tss > 0 else np.nan
    sse_n = max(sse / n, 1e-300)
    aic = n*np.log(sse_n) + 2*k
    bic = n*np.log(sse_n) + k*np.log(n)
    return {"SSE": sse, "RMSE": rmse, "R2": r2, "AIC": aic, "BIC": bic}


# ============================================================
# 5) Fitters
# ============================================================

def fit_epv_curve_fit(x, y, p0=None, sigma_y=None, absolute_sigma=False, maxfev=60000):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    # enforce sort and uniform grid requirement (for FFT ex-Lorentz)
    idx = np.argsort(x)
    x = x[idx]; y = y[idx]

    if p0 is None:
        p0 = initial_guess_epv(x, y)
    lb, ub = bounds_epv(x, y)

    popt, pcov = curve_fit(
        exp_pseudo_voigt_peak, x, y,
        p0=p0, bounds=(lb, ub),
        sigma=sigma_y, absolute_sigma=absolute_sigma,
        maxfev=maxfev
    )
    yhat = exp_pseudo_voigt_peak(x, *popt)
    perr = np.sqrt(np.diag(pcov))
    met = fit_metrics(y, yhat, k=len(popt))
    return x, y, popt, pcov, perr, yhat, met


def fit_epv_de(x, y, seed=0, workers=1, polish=True):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    idx = np.argsort(x)
    x = x[idx]; y = y[idx]

    lb, ub = bounds_epv(x, y)
    bounds = list(zip(lb, ub))

    mad = median_abs_deviation(y, scale='normal')
    scale = max(float(mad), 1e-12)

    def objective(p):
        r = y - exp_pseudo_voigt_peak(x, *p)
        delta = 2.0 * scale
        # pseudo-Huber robust loss
        return np.sum(delta**2 * (np.sqrt(1.0 + (r/delta)**2) - 1.0))

    res = differential_evolution(
        objective, bounds=bounds, seed=seed, workers=workers, polish=polish
    )
    pbest = res.x
    yhat = exp_pseudo_voigt_peak(x, *pbest)
    met = fit_metrics(y, yhat, k=len(pbest))
    return x, y, pbest, yhat, met, res


def fit_epv_hybrid(x, y, seed=0):
    x, y, p_de, yhat_de, met_de, res_de = fit_epv_de(x, y, seed=seed, polish=True)
    x, y, popt, pcov, perr, yhat, met = fit_epv_curve_fit(x, y, p0=p_de)
    return {
        "x": x, "y": y,
        "p_de": p_de, "yhat_de": yhat_de, "met_de": met_de, "res_de": res_de,
        "p_opt": popt, "pcov": pcov, "perr": perr, "yhat": yhat, "metrics": met
    }


# ============================================================
# 6) Synthetic generator (using same model)
# ============================================================

def generate_synthetic_epv_data(
    n=600, x_min=-5, x_max=12,
    A=120, mu=1.0, fwhm=0.9, eta=0.35, tau=1.8, y0=2.0,
    noise_std=0.5, outlier_frac=0.0, outlier_scale=10.0, seed=1
):
    rng = np.random.default_rng(seed)
    x = np.linspace(x_min, x_max, n)
    y_clean = exp_pseudo_voigt_peak(x, A, mu, fwhm, eta, tau, y0)
    y = y_clean + rng.normal(0.0, noise_std, size=n)

    if outlier_frac > 0:
        m = int(np.floor(outlier_frac * n))
        idx = rng.choice(n, size=m, replace=False)
        y[idx] += rng.normal(0.0, outlier_scale * noise_std, size=m)

    return x, y, y_clean


# ============================================================
# 7) Plotting & reporting
# ============================================================

def pv_core_visual(x, A, mu, fwhm, eta, y0):
    sigma = fwhm / (2.0 * np.sqrt(2.0 * np.log(2.0)))
    gamma = fwhm / 2.0
    core = A * ((1.0 - eta) * gaussian_unit(x, mu, sigma) + eta * lorentz_unit(x, mu, gamma)) + y0
    return core


def plot_fit(x, y, yhat, p, title="Exp-modified pseudo-Voigt fit"):
    A, mu, fwhm, eta, tau, y0 = p

    fig = plt.figure(figsize=(9, 5))
    ax = fig.add_subplot(111)
    ax.plot(x, y, ".", ms=4, label="Data")
    ax.plot(x, yhat, "-", lw=2, label="Fit")
    ax.plot(x, pv_core_visual(x, A, mu, fwhm, eta, y0), "--", lw=1.5, label="Pseudo-Voigt core (guide)")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    ax.legend()
    plt.tight_layout()
    plt.show()

    fig2 = plt.figure(figsize=(9, 3.4))
    ax2 = fig2.add_subplot(111)
    res = y - yhat
    ax2.axhline(0.0, lw=1)
    ax2.plot(x, res, ".", ms=4)
    ax2.set_xlabel("x")
    ax2.set_ylabel("Residual")
    ax2.set_title("Residuals")
    ax2.grid(alpha=0.25)
    plt.tight_layout()
    plt.show()


def print_report(name, p, metrics, perr=None):
    names = ["A", "mu", "fwhm", "eta", "tau", "y0"]
    print(f"\n=== {name} ===")
    if perr is None:
        for n, v in zip(names, p):
            print(f"{n:>6s} = {v: .8g}")
    else:
        for n, v, e in zip(names, p, perr):
            print(f"{n:>6s} = {v: .8g} ± {e:.3g}")

    print("Metrics:")
    for k, v in metrics.items():
        print(f"  {k:>4s} = {v: .8g}")


# ============================================================
# 8) Demo / usage
# ============================================================

if __name__ == "__main__":
    # Synthetic test
    x, y, y_clean = generate_synthetic_epv_data(
        n=700,
        A=150, mu=0.7, fwhm=0.75, eta=0.45, tau=1.5, y0=20.8,
        noise_std=2.35, outlier_frac=0.01, outlier_scale=12, seed=42
    )

    # curve_fit only
    x1, y1, p_cf, cov_cf, e_cf, yhat_cf, m_cf = fit_epv_curve_fit(x, y)
    print_report("curve_fit", p_cf, m_cf, perr=e_cf)

    # DE only
    x2, y2, p_de, yhat_de, m_de, res_de = fit_epv_de(x, y, seed=42, polish=True)
    print_report("differential_evolution", p_de, m_de, perr=None)

    # Hybrid (recommended)
    out = fit_epv_hybrid(x, y, seed=42)
    print_report("hybrid (DE -> curve_fit)", out["p_opt"], out["metrics"], perr=out["perr"])
    plot_fit(out["x"], out["y"], out["yhat"], out["p_opt"])

    # Example for real data:
    # idx = np.argsort(x_data)
    # xr = np.asarray(x_data)[idx]
    # yr = np.asarray(y_data)[idx]
    # out = fit_epv_hybrid(xr, yr, seed=123)
    # print_report("real data", out["p_opt"], out["metrics"], perr=out["perr"])
    # plot_fit(out["x"], out["y"], out["yhat"], out["p_opt"])
