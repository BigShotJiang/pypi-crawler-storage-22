import datetime as dt
from dataclasses import dataclass
from typing import Optional, Sequence, Tuple, Mapping, Any

import numpy as np
from pandas import DataFrame

from apsimNGpy.core.model_tools import find_all_in_scope, CastHelper
from apsimNGpy.core.model_tools import find_child_of_class
from apsimNGpy.starter.starter import CLR
from apsimNGpy.core_utils.soil_lay_calculator import auto_gen_thickness_layers
from apsimNGpy.logger import logger
from apsimNGpy.soils.helpers import _is_within_USA_mainland
from apsimNGpy.soils.soilgrid import get_soil_profile_soil_grid
from apsimNGpy.soils.soilmanager import DownloadsurgoSoiltables, OrganiseSoilProfile

Models = CLR.Models
Array, Double = CLR.System.Array, CLR.System.Double


# -------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------

# def _to_net_double_array(values) -> Array[Double]:
#     """Fast-ish conversion of a 1D numeric sequence to .NET double[]."""
#     a = np.asarray(values, dtype=np.float64)
#     # pythonnet marshaling from list -> double[] is reliable and reasonably fast
#     return Array[Double](a.tolist())


def _to_net_double_array(values) -> Array[Double]:
    """Safe conversion of a 1D numeric sequence to .NET double[]"""
    a = np.asarray(values, dtype=np.float64).ravel()

    net_arr = Array[Double](len(a))
    for i, v in enumerate(a):
        net_arr[i] = float(v)  # force System.Double-compatible value

    return net_arr


def fill_in_meta_info(*,
                      record_number=0,
                      asc_order=None,
                      asc_sub_order=None,
                      soil_type=None,
                      local_name=None,
                      site=None,
                      nearest_town=None,
                      region=None,
                      state=None,
                      country=None,
                      natural_vegetation=None,
                      apsoil_number=None,
                      latitude=0.0,
                      longitude=0.0,
                      location_accuracy=None,
                      year_of_sampling=None,
                      data_source=None,
                      comments=None):
    return {
        "RecordNumber": record_number,
        "ASCOrder": asc_order,
        "ASCSubOrder": asc_sub_order,
        "SoilType": soil_type,
        "LocalName": local_name,
        "Site": site,
        "NearestTown": nearest_town,
        "Region": region,
        "State": state,
        "Country": country,
        "NaturalVegetation": natural_vegetation,
        "ApsoilNumber": apsoil_number,
        "Latitude": latitude,
        "Longitude": longitude,
        "LocationAccuracy": location_accuracy,
        "YearOfSampling": year_of_sampling,
        "DataSource": data_source,
        "Comments": comments
    }


class Soils(Models.Soils.Soil):
    pass


@dataclass(order=True, slots=True, repr=False)
class SoilManager:
    simulation_model: Models.Core.Simulation
    lonlat: Optional[Tuple[float, float]] = None
    soil_tables: Optional[Sequence[Any]] = None
    soil_series: str = None
    thickness_sequence: Optional[Sequence[Any]] = 'auto'
    thickness_value: int = None  # mm
    max_depth: Optional[int] = 2400  # mm
    n_layers: int = 10
    thinnest_layer: int = 100  # mm
    thickness_growth_rate: float = 1.5  # unit less
    soil_profile: Optional[Mapping] = None  # cached once
    source: str = 'soil grid',
    top_finert: float = 0.65,
    top_fom: float = 180,
    top_fbiom: float = 0.04,
    fom_cnr: float = 40,
    soil_cnr: float = 12,
    top_urea: float = 0,
    top_nh3: float = 0.5,
    top_nh4: float = 0.05
    swcon:float =0.3,

    # ------------------------ Profile prep ------------------------
    def __post_init__(self):
        if self.thickness_sequence == 'auto':
            self.thickness_sequence = auto_gen_thickness_layers(max_depth=self.max_depth,
                                                                n_layers=self.n_layers,
                                                                thin_thickness=self.thinnest_layer,
                                                                growth_type='linear',
                                                                thick_growth_rate=self.thickness_growth_rate)

    def _ensure_soil_profile(self) -> None:
        """
        Prepare `self.soil_profile` ONCE. No-ops if already set.
        This avoids re-downloading SSURGO and re-organizing on every edit.
        """
        if self.soil_profile is not None:
            return

        if self.lonlat is not None:
            if self.source.lower() == 'ssurgo':
                if not _is_within_USA_mainland(self.lonlat):
                    raise ValueError(f'Coordinates:  {self.lonlat} are outside USA. Please use source =`isric` instead')
                self.soil_profile = self.get_soil_profile_from_lonlat_ssurgo(
                    self.lonlat,
                    thickness=self.thickness_value,
                    n_layers=self.n_layers,
                    max_depth=self.max_depth,
                    soil_series=self.soil_series,
                    thickness_sequence=self.thickness_sequence,
                )
            elif self.source.lower() == 'isric':
                self.soil_profile = get_soil_profile_soil_grid(lonlat=self.lonlat,
                                                               thickness_values_mm=self.thickness_sequence,
                                                               top_finert=self.top_finert,
                                                               top_fom=self.top_fom,
                                                               top_fbiom=self.top_fbiom,
                                                               fom_cnr=self.fom_cnr,
                                                               soil_cnr=self.soil_cnr,
                                                               top_urea=self.top_urea,
                                                               top_nh3=self.top_nh3,
                                                               top_nh4=self.top_nh4,
                                                               swcon= self.swcon

                                                               )
            else:
                raise NotImplementedError(
                    f' source `{self.source}` not supported. Please choose from `isric` or `ssurgo`')

        # Fallback to provided tables (dict-like expected)
        if isinstance(self.soil_tables, dict):
            self.soil_profile = self.soil_tables
            self.thickness_sequence = self.soil_tables.get('Thickness', self.thickness_sequence)
            return

    # @staticmethod
    def get_soil_profile_from_lonlat_ssurgo(self,
                                            lonlat,
                                            *,
                                            thickness_sequence=None,
                                            soil_series=None,
                                            thickness=None,
                                            max_depth=2400,
                                            n_layers=10, ):
        assert any([thickness_sequence, thickness]), \
            "both thickness_sequence and thickness must not be None"
        if all([thickness_sequence, thickness]):
            logger.warning(
                'Both "thickness_sequence" and "thickness" are provided; only "thickness_sequence" will be used.'
            )

        date_str = dt.datetime.now().isoformat(timespec="seconds")

        sdf = DownloadsurgoSoiltables(lonlat=lonlat, select_componentname=soil_series, summarytable=False)
        if soil_series in sdf.componentname.unique():
            sdf = sdf[sdf['componentname'] == soil_series]
        elif soil_series is None:
            max_compo_value = sdf.prcent.max()
            sdf = sdf[sdf['prcent'] == max_compo_value]

        else:

            print(sdf.componentname.unique())
            raise KeyError(f'{soil_series} not any of the available ones: {', '.join(sdf.componentname.unique())}')
        # update
        soil_series = sdf['componentname'].iloc[0]
        mu_name = sdf['muname'].iloc[0]
        chkey = sdf['chkey'].iloc[0]
        soil_profile = OrganiseSoilProfile(sdf,
                                           thickness_values=thickness_sequence)
        try:
            rn = int(int(chkey))
        except TypeError as e:
            rn = 0
        meta_info = fill_in_meta_info(
            soil_type=mu_name,
            record_number=rn,
            latitude=lonlat[1],
            longitude=lonlat[0],
            local_name=soil_series,
            data_source=(
                f"{soil_series}: downloaded by apsimNGpy: `DownloadsurgoSoiltables` \n accessed from SSURGO on: {date_str}"

            ),
            comments=f"number of layers: {n_layers}, max depth: {max_depth}mm"
        )
        return soil_profile.cal_missingFromSurgo(metadata=meta_info,
                                                 top_finert=self.top_finert,
                                                 top_fom=self.top_fom,
                                                 top_fbiom=self.top_fbiom,
                                                 fom_cnr=self.fom_cnr,
                                                 soil_cnr=self.soil_cnr,
                                                 top_urea=self.top_urea,
                                                 top_nh3=self.top_nh3,
                                                 top_nh4=self.top_nh4)

    # ------------------------ Editors ------------------------

    def _edit_soil_section(self, section_key: str, model_type, data=None) -> None:
        """
        Generic editor: sets properties on a .NET soil section from a pandas DataFrame
        found in self.soil_profile[section_key]. Uses vectorized conversion and .NET arrays.
        if not data:
           then data is loaded from the default soil profile
        data is used to load ancillary soil info not from self.soil_profile[section_key]
        """
        self._ensure_soil_profile()

        section = find_child_of_class(self.simulation_model, child_class=model_type)
        if section:
            cast_as = CastHelper.CastAs[model_type]  # cache the generic once
            tmp = cast_as(section)
            if tmp:
                section = tmp
        else:
            section = model_type()  # NOTE: if needed, attach to parent outside
        if data:
            df = data
        else:
            df = self.soil_profile[section_key]

        # Cache attribute membership to avoid repeated hasattr C-bound lookups
        # (dir() is surprisingly cheap vs many hasattr calls)
        attr_set = set(dir(section))
        if isinstance(df, dict):
            df = DataFrame.from_dict(df)
        for prop in df:
            if prop not in attr_set:
                continue

            col = df[prop]
            if prop == 'Depth':
                # Depth often strings like "[0-100]"; keep as-is to avoid coercion overhead
                setattr(section, prop, col.values)
            else:
                # Vectorized -> .NET double[] in one shot
                setattr(section, prop, _to_net_double_array(col.to_numpy(copy=False)))

    def edit_solute_sections(self) -> None:
        self._ensure_soil_profile()
        all_solutes = find_all_in_scope(self.simulation_model, child_class=Models.Soils.Solute)
        if not all_solutes:
            return

        for sol in all_solutes:
            sol = CastHelper.CastAs[Models.Soils.Solute](sol)
            name = sol.Name
            df = self.soil_profile.get(name)
            if df is None:
                continue

            attr_set = set(dir(sol))
            for column in df.columns:
                if column not in attr_set:
                    continue
                col = df[column]
                if column == 'Depth':
                    setattr(sol, column, col.values)
                else:
                    setattr(sol, column, _to_net_double_array(col.to_numpy(copy=False)))

    def edit_soil_crop(self, crops_in: Sequence[str] = ()) -> None:
        """
        Edits the shared SoilCrop first, then adds explicit crop entries as requested.
        """
        self._ensure_soil_profile()
        df = self.soil_profile.get('soil_crop')
        if df is None:
            return
        physical = find_child_of_class(parent=self.simulation_model, child_class=Models.Soils.Physical)
        if not physical:
            return
        physical = CastHelper.CastAs[Models.Soils.Physical](physical) or physical

        crop_soil = find_all_in_scope(physical, child_class=Models.Soils.SoilCrop)
        if not crop_soil:
            return
        for soilc in crop_soil:
            crop_soil = CastHelper.CastAs[Models.Soils.SoilCrop](soilc) or crop_soil

            attr_set = set(dir(crop_soil))
            for prop in df.columns:
                if prop not in attr_set:
                    continue
                col = df[prop]
                if prop == 'Depth':
                    setattr(crop_soil, prop, col.values)
                else:
                    setattr(crop_soil, prop, _to_net_double_array(col.to_numpy(copy=False)))

        # Add explicit crop entries, copying values in bulk
        for crop in crops_in or ():
            sc = Models.Soils.SoilCrop()
            sc.Name = crop
            attr_set2 = set(dir(sc))
            for prop in df.columns:
                if prop not in attr_set2:
                    continue
                col = df[prop]
                if prop == 'Depth':
                    setattr(sc, prop, col.values)
                else:
                    setattr(sc, prop, _to_net_double_array(col.to_numpy(copy=False)))
            physical.Children.Add(sc)

    # Thin wrappers
    def edit_soil_physical(self) -> None:
        self._edit_soil_section('physical', Models.Soils.Physical)

    def edit_soil_organic(self) -> None:
        self._edit_soil_section('organic', Models.Soils.Organic)

    def edit_soil_chemical(self) -> None:
        self._edit_soil_section('chemical', Models.Soils.Chemical)

    def edit_meta_info(self) -> None:
        self._ensure_soil_profile()
        soils = find_child_of_class(self.simulation_model, Models.Soils.Soil)
        cast__a_soil = CastHelper.CastAs[Models.Soils.Soil](soils)
        meta_info = self.soil_profile['meta_info']
        for key in meta_info:
            if hasattr(cast__a_soil, key):

                if key == 'RecordNumber':
                    value = int(meta_info[key])
                else:
                    value = meta_info[key]

                setattr(cast__a_soil, key, value)

    def edit_soil_water_balance(self) -> None:
        self._edit_soil_section('soil_water', Models.WaterModel.WaterBalance)

    def edit_soil_initial_water(self) -> None:
        self._edit_soil_section('water', Models.Soils.Water)

    # Stubs kept for future parity
    def edit_som(self) -> None:
        pass

    def edit_sim3(self) -> None:
        pass

    def edit_meta_data(self) -> None:
        pass

    def edit_soil_layer_structure(self) -> None:
        pass

    def edit_soil_crops(self) -> None:
        pass

    def edit_sim3_solute(self) -> None:
        pass


if __name__ == "__main__":
    from apsimNGpy.core.apsim import ApsimModel

    model = ApsimModel('Maize', out_path='out__maize.apsimx')
    # soil = SoilManager(simulation_model=model.simulations[0], lonlat=(-93.97702, 42.8780025), soil_tables=[])
    # # sp = soil.get_soil_profile_from_lonlat(lonlat=(-92.297702, 41.321), thickness=100)
    # soil.edit_soil_physical()
    # soil.edit_soil_chemical()
    # soil.edit_soil_organic()
    # soil.edit_soil_initial_water()
    # soil.edit_solute_sections()
    # soil.edit_soil_water_balance()
    # soil.edit_soil_crop(crops_in=['Soybean'])
    # model.save()
    # model.preview_simulation()
