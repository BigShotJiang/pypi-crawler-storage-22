#!/usr/bin/env python
from setuptools import setup

# grab metadata
version = '1.00'
with open('apt') as f:
    for line in f:
        if line.startswith('__version__'):
            try:
                version = line.split("'")[1]
            except IndexError:
                pass
            break
# readme is needed at register time, not install time
try:
    with open('readme.rst') as f:
        long_description = f.read()
except IOError:
    long_description = ''


setup(
    name          = 'apt-wrapper',
    version       = version,
    description   = 'A simpler interface to the Debian/Ubuntu APT command-line tools.',
    author        = 'Army of Light',
    author_email  = 'aol@noreply.codeberg.org',
    license       = 'GPL-3.0-or-later',
    scripts       = ['apt'],

    long_description = long_description,
    classifiers     = [
        'Development Status :: 5 - Production/Stable',
        'Environment :: Console',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 3',
        'Topic :: System :: Installation/Setup',
        'Topic :: System :: Systems Administration',
        'Topic :: Utilities',
    ],
)
