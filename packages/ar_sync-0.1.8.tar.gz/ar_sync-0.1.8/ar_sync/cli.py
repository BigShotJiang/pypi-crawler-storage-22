"""Command-line interface for ar-sync.

This module provides the CLI commands for ar-sync using Typer framework.
"""

import logging
import shutil
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import typer

from ar_sync.config_manager import ConfigManager
from ar_sync.constants import DEFAULT_TARGETS, SYNC_MODE_LINK
from ar_sync.errors import ARSyncError, ErrorCategory
from ar_sync.git_backend import GitBackend
from ar_sync.models import LocalConfig, StoreMetadata
from ar_sync.project_manager import ProjectManager
from ar_sync.store_manager import StoreManager
from ar_sync.sync.bidirectional_sync import BidirectionalSync
from ar_sync.sync.models import ResolutionStrategy, SyncOptions, SyncResult

if TYPE_CHECKING:
    from rich.console import Console

    from ar_sync.template_manager import TemplateManager
    from ar_sync.template_models import TemplateMetadata

# Global debug flag
DEBUG_MODE = False

# Configure logging
logger = logging.getLogger("ar_sync")


def setup_logging(debug: bool = False) -> None:
    """Configure logging based on debug mode.

    Args:
        debug: Enable debug logging if True
    """
    global DEBUG_MODE
    DEBUG_MODE = debug

    level = logging.DEBUG if debug else logging.WARNING
    handler = logging.StreamHandler(sys.stderr)

    if debug:
        formatter = logging.Formatter(
            "[%(levelname)s] %(name)s:%(funcName)s:%(lineno)d - %(message)s"
        )
    else:
        formatter = logging.Formatter("[%(levelname)s] %(message)s")

    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(level)

    # Also configure root logger for third-party libraries
    logging.basicConfig(level=level, handlers=[handler], force=True)


def debug_log(message: str) -> None:
    """Log a debug message.

    Note: Due to Typer's internal behavior, this may be called twice.
    This is normal and does not affect functionality.

    Args:
        message: Log message
    """
    logger.debug(message)


def perform_auto_sync(config: LocalConfig) -> None:
    """Perform automatic git sync if auto_sync is enabled.

    Args:
        config: Local configuration with auto_sync setting
    """
    if not config.auto_sync:
        return

    if config.backend != "git":
        return

    if not config.repo_url:
        return  # Skip auto-sync if no remote URL configured

    typer.echo("\nAuto-syncing with remote...")

    try:
        store_path = Path(config.store_path)
        git_backend = GitBackend(store_path, config.repo_url)
        git_backend.initialize()
        git_backend.sync()
        typer.echo("✓ Auto-sync complete")
    except Exception as e:
        typer.echo(f"⚠️  Auto-sync failed: {e}", err=True)
        typer.echo("You can manually sync later with 'ars sync'", err=True)


app = typer.Typer(
    name="ar-sync",
    help="Synchronize AI IDE settings across machines using Git",
    add_completion=False,
    no_args_is_help=True,
)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        from ar_sync.__version__ import __version__

        typer.echo(f"ar-sync version {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """Callback to handle global options."""
    pass


@app.command()
def setup(
    backend: str = typer.Option(None, help="Storage backend: 'git' or 'local'"),
    path: str = typer.Option(None, help="Local store path"),
    repo_url: str = typer.Option(None, help="Git repository URL (required for 'git' backend)"),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Initialize ar-sync global configuration and storage backend.

    This is a one-time setup command that creates the global configuration
    and initializes the storage backend (Git repository or local directory).

    Examples:
        ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git
        ars setup --backend local --path ~/Dropbox/ar-sync-store
        ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git --debug
    """
    setup_logging(debug)

    try:
        # 1. Check for existing config and use defaults
        config_manager = ConfigManager()
        existing_config = None
        try:
            existing_config = config_manager.load()
        except FileNotFoundError:
            pass

        # Use existing values as defaults if not provided
        if backend is None:
            if existing_config:
                backend = existing_config.backend
            else:
                backend = "git"  # Default to git if no existing config

        # 2. Validate backend
        if backend not in ["git", "local"]:
            raise ARSyncError(
                f"Unsupported backend: {backend}",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Use 'git' or 'local' as the backend",
                    "Example (git): ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                    "Example (local): ars setup --backend local --path ~/Dropbox/ar-sync-store",
                ],
            )

        # 3. Use existing values as defaults if not provided
        if path is None:
            if existing_config:
                path = existing_config.store_path
            else:
                raise ARSyncError(
                    "Store path is required",
                    ErrorCategory.USER_INPUT,
                    recovery_steps=[
                        "Provide --path option",
                        "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                    ],
                )

        if repo_url is None:
            if existing_config:
                repo_url = existing_config.repo_url
            elif backend == "git":
                raise ARSyncError(
                    "Repository URL is required for 'git' backend",
                    ErrorCategory.USER_INPUT,
                    recovery_steps=[
                        "Provide --repo-url option",
                        "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                    ],
                )
            else:
                repo_url = ""  # Not required for local backend

        # 4. Expand path and convert to Path object
        store_path = Path(path).expanduser().resolve()

        # 3. Create LocalConfig
        config = LocalConfig(
            version=1,
            backend=backend,
            store_path=str(store_path),
            repo_url=repo_url,
            default_targets=list(DEFAULT_TARGETS),
            auto_sync=False,
            backup_originals=True,
            backup_dir=str(Path.home() / ".config" / "ar-sync" / "backups"),
        )

        # 4. Save configuration using ConfigManager
        config_manager.save(config)

        typer.echo(f"✓ Configuration saved to {ConfigManager.CONFIG_PATH}")

        # 5. Initialize Git repository (only for git backend)
        if backend == "git":
            # Verify remote access before initializing
            typer.echo("Verifying remote repository access...")
            if not GitBackend.verify_remote_access(repo_url):
                raise ARSyncError(
                    f"Cannot access remote repository: {repo_url}",
                    ErrorCategory.GIT,
                    recovery_steps=[
                        "SSH key may not be configured. Run: ssh-keygen -t ed25519",
                        "Add your SSH key to the Git hosting service (GitHub, GitLab, etc.)",
                        "Check repository URL is correct and accessible",
                        "Test SSH connection: ssh -T git@github.com (or your Git host)",
                        "Ensure the repository exists and you have access permissions",
                    ],
                )
            typer.echo("✓ Remote repository is accessible")

            git_backend = GitBackend(store_path, repo_url)
            git_backend.initialize()
            typer.echo(f"✓ Git repository initialized at {store_path}")
        else:
            # For local backend, just ensure directory exists
            store_path.mkdir(parents=True, exist_ok=True)
            typer.echo(f"✓ Store directory created at {store_path}")

        # 6. Initialize store metadata using StoreManager
        store_manager = StoreManager(store_path)
        store_manager.initialize()

        typer.echo(f"✓ Store metadata created at {store_path / StoreManager.METADATA_FILENAME}")

        typer.echo("\n✓ Initialization complete!")
        typer.echo(f"\nBackend: {backend}")
        typer.echo(f"Store location: {store_path}")
        if backend == "git":
            typer.echo(f"Remote repository: {repo_url}")
        typer.echo("\nNext steps:")
        typer.echo("  1. cd to your project directory")
        typer.echo("  2. Run 'ars init' to initialize the project")

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during setup")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Initialization failed: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=[
                "Check that the path is valid and writable",
                "Ensure Git is installed and available in PATH",
                "Verify the repository URL is correct",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during setup")
        raise typer.Exit(code=1)


@app.command()
def add(
    name: str | None = typer.Option(None, help="Project name (defaults to current directory name)"),
    targets: str | None = typer.Option(
        None, help="Comma-separated targets (defaults to .cursor,.kiro,.gemini,.qwen,AGENTS.md)"
    ),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Add current project to store.

    Copies target files to store, updates metadata, and syncs to remote.

    Examples:
        ars add
        ars add --name my-project
        ars add --targets .cursor,.kiro,.vscode,AGENTS.md
        ars add --debug
    """
    setup_logging(debug)

    try:
        # 1. Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store not initialized",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize the store",
                    "Example: ars setup --backend local --path ~/Dropbox/ar-sync-store",
                ],
            )

        # 2. Determine project name
        project_name = name if name else ProjectManager.get_current_project_name()

        # 3. Determine targets
        if targets:
            target_list = [t.strip() for t in targets.split(",")]
        else:
            target_list = config.default_targets

        # 4. Scan for targets in current directory
        project_dir = Path.cwd()
        found_targets = ProjectManager.scan_targets(project_dir, target_list)

        if not found_targets:
            raise ARSyncError(
                "No target files found in current directory",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    f"Expected targets: {', '.join(target_list)}",
                    "Make sure you're in the correct project directory",
                    "Or specify custom targets with --targets option",
                ],
            )

        typer.echo(f"Found targets: {', '.join(found_targets)}")

        # 5. Copy files to store
        store_path = Path(config.store_path)
        backup_dir = Path(config.backup_dir)
        project_manager = ProjectManager(store_path, backup_dir)

        typer.echo("Copying files to store...")
        project_manager.add_project(project_dir, project_name, found_targets)

        typer.echo(f"✓ Files copied to {store_path / project_name}")

        # 6. Update store metadata
        hostname = ProjectManager.get_hostname()
        store_manager = StoreManager(store_path)
        store_manager.add_project(project_name, found_targets, hostname)

        typer.echo("✓ Store metadata updated")

        # 7. Commit and push (only for git backend)
        if config.backend == "git" and config.repo_url:
            git_backend = GitBackend(store_path, config.repo_url)
            git_backend.initialize()

            typer.echo("Committing and pushing changes...")
            commit_message = f"Add project: {project_name} (targets: {', '.join(found_targets)})"
            git_backend.commit_and_push(commit_message)

            typer.echo("✓ Changes pushed to remote")
        else:
            typer.echo("✓ Changes saved to local store")

        typer.echo(f"\n✓ Project '{project_name}' added successfully!")
        typer.echo("\nNext steps:")
        typer.echo(
            f"  - On another machine, run 'ars link --project {project_name}' to link these settings"
        )

        # Perform auto-sync if enabled
        perform_auto_sync(config)

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during add")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Failed to add project: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=[
                "Check that you have write permissions to the store directory",
                "Verify Git is configured correctly",
                "Ensure the remote repository is accessible",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during add")
        raise typer.Exit(code=1)


def _handle_template_init(
    from_template: bool,
    list_templates: bool,
    output_dir: str | None,
    category: str | None,
    search: str | None,
) -> None:
    """Handle template-related init operations.

    Requirements:
    - 4.1: --from-template 옵션으로 대화식 템플릿 선택 모드 시작
    - 4.2: -t 별칭 동작
    - 4.4: --output-dir 옵션으로 지정된 디렉토리에 템플릿 복사
    - 4.5: --category 옵션으로 해당 카테고리의 템플릿만 표시
    - 4.6: --list 옵션으로 대화식 모드 없이 템플릿 목록 표시
    - 5.2: --search 옵션과 함께 --list 사용 시 검색 결과만 표시

    Args:
        from_template: Start interactive template selection
        list_templates: List available templates
        output_dir: Output directory for templates
        category: Filter by category
        search: Search query
    """
    from rich.console import Console

    from ar_sync.template_copier import TemplateCopier
    from ar_sync.template_manager import TemplateManager
    from ar_sync.template_selector import TemplateSelector

    console = Console()

    try:
        template_manager = TemplateManager()
    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        raise typer.Exit(code=1)

    # Handle --list option (Requirement 4.6)
    if list_templates:
        _list_templates(template_manager, console, category, search)
        return

    # Handle --from-template option (Requirement 4.1, 4.2)
    if from_template:
        selector = TemplateSelector(template_manager, console)

        # Prepare category filter
        categories = [category] if category else None

        # Run interactive selection
        selected = selector.run_interactive_selection(
            categories=categories,
            search_query=search,
        )

        if not selected:
            return

        # Copy selected templates
        output_path = Path(output_dir) if output_dir else None
        copier = TemplateCopier(output_dir=output_path, console=console)

        result = copier.copy_templates(selected)

        if result.success:
            console.print("\n[green]✓ 템플릿 초기화 완료![/green]")
            console.print("\n[dim]다음 단계:[/dim]")
            console.print("  1. 복사된 템플릿을 프로젝트에 맞게 수정하세요")
            console.print("  2. AI IDE에서 템플릿을 활용하세요")


def _list_templates(
    template_manager: "TemplateManager",
    console: "Console",
    category: str | None,
    search: str | None,
) -> None:
    """List available templates.

    Requirements:
    - 4.6: --list 옵션으로 대화식 모드 없이 템플릿 목록 표시
    - 5.2: --search 옵션과 함께 --list 사용 시 검색 결과만 표시

    Args:
        template_manager: Template manager instance
        console: Rich console instance
        category: Filter by category
        search: Search query
    """
    from ar_sync.template_manager import TemplateManager

    console.print("\n[bold cyan]📚 사용 가능한 템플릿[/bold cyan]")

    if search:
        console.print(f"[dim]검색어: '{search}'[/dim]")
        templates = template_manager.search_templates(search, category)

        if not templates:
            console.print(f"\n[yellow]'{search}' 검색 결과가 없습니다.[/yellow]")
            console.print(
                "[dim]다른 검색어를 시도하거나 --list만 사용하여 전체 목록을 확인하세요.[/dim]"
            )
            return

        # Group by category
        by_category: dict[str, list[TemplateMetadata]] = {}
        for t in templates:
            if t.category not in by_category:
                by_category[t.category] = []
            by_category[t.category].append(t)

        for cat in TemplateManager.CATEGORIES:
            if cat in by_category:
                _print_category_table(console, cat, by_category[cat])
    else:
        # Show all templates
        all_templates = template_manager.scan_templates()

        categories_to_show = [category] if category else TemplateManager.CATEGORIES

        for cat in categories_to_show:
            templates = all_templates.get(cat, [])
            if templates:
                _print_category_table(console, cat, templates)

    console.print("\n[dim]대화식 선택: ars init -t[/dim]")
    console.print("[dim]카테고리 필터: ars init --list --category agents[/dim]")


def _print_category_table(
    console: "Console", category: str, templates: list["TemplateMetadata"]
) -> None:
    """Print a table of templates for a category.

    Args:
        console: Rich console instance
        category: Category name
        templates: List of templates
    """
    from rich.table import Table

    table = Table(
        title=f"[bold]{category.upper()}[/bold] ({len(templates)}개)",
        show_header=True,
        header_style="bold",
    )
    table.add_column("이름", style="cyan")
    table.add_column("설명", style="dim", max_width=60)

    for template in templates:
        table.add_row(
            template.display_name,
            template.short_description or "[dim]설명 없음[/dim]",
        )

    console.print(table)
    console.print()


@app.command()
def init(
    name: str | None = typer.Option(None, help="Project name (defaults to current directory name)"),
    targets: str | None = typer.Option(
        None, help="Comma-separated targets (defaults to .cursor,.kiro,.gemini,.qwen,AGENTS.md)"
    ),
    from_template: bool = typer.Option(
        False, "--from-template", "-t", help="Start interactive template selection"
    ),
    output_dir: str | None = typer.Option(
        None, "--output-dir", "-o", help="Output directory for templates (default: .claude)"
    ),
    category: str | None = typer.Option(
        None, "--category", "-c", help="Filter by category (agents, rules, skills)"
    ),
    list_templates: bool = typer.Option(
        False, "--list", "-l", help="List available templates without interactive mode"
    ),
    search: str | None = typer.Option(
        None, "--search", "-s", help="Search templates by name or description"
    ),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Initialize current project and optionally add templates.

    This command adds the current project to the store and, if using local backend,
    automatically creates symlinks. This is the recommended way to set up a new project.

    With --from-template (-t), starts interactive template selection to copy
    AI IDE configuration templates (agents, rules, skills) to your project.

    Examples:
        ars init
        ars init --name my-project
        ars init --targets .cursor,.kiro,.vscode,AGENTS.md
        ars init -t                          # Interactive template selection
        ars init --list                      # List available templates
        ars init --list --search security    # Search templates
        ars init -t --category agents        # Select from agents only
        ars init -t -o .cursor               # Output to .cursor directory
        ars init --debug
    """
    setup_logging(debug)

    # Handle template-related options first (independent of store configuration)
    if list_templates or from_template:
        _handle_template_init(
            from_template=from_template,
            list_templates=list_templates,
            output_dir=output_dir,
            category=category,
            search=search,
        )
        # If only listing templates, exit here
        if list_templates and not from_template:
            return

    try:
        # 1. Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            # If only doing template operations, this is fine
            if from_template or list_templates:
                return
            raise ARSyncError(
                "Global configuration not found",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize global configuration",
                    "Example: ars setup --backend local --path ~/Dropbox/ar-sync-store",
                ],
            )

        # 2. Determine project name
        project_name = name if name else ProjectManager.get_current_project_name()

        # 3. Determine targets
        if targets:
            target_list = [t.strip() for t in targets.split(",")]
        else:
            target_list = config.default_targets

        # 4. Scan for targets in current directory
        project_dir = Path.cwd()
        found_targets = ProjectManager.scan_targets(project_dir, target_list)

        if not found_targets:
            raise ARSyncError(
                "No target files found in current directory",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    f"Expected targets: {', '.join(target_list)}",
                    "Make sure you're in the correct project directory",
                    "Or specify custom targets with --targets option",
                ],
            )

        typer.echo(f"Found targets: {', '.join(found_targets)}")

        # 5. Copy files to store
        store_path = Path(config.store_path)
        backup_dir = Path(config.backup_dir)
        project_manager = ProjectManager(store_path, backup_dir)

        typer.echo("Copying files to store...")
        project_manager.add_project(project_dir, project_name, found_targets)

        typer.echo(f"✓ Files copied to {store_path / project_name}")

        # 6. Update store metadata
        hostname = ProjectManager.get_hostname()
        store_manager = StoreManager(store_path)
        store_manager.add_project(project_name, found_targets, hostname)

        typer.echo("✓ Store metadata updated")

        # 7. Commit and push (only for git backend)
        if config.backend == "git" and config.repo_url:
            git_backend = GitBackend(store_path, config.repo_url)
            git_backend.initialize()

            typer.echo("Committing and pushing changes...")
            commit_message = f"Add project: {project_name} (targets: {', '.join(found_targets)})"
            git_backend.commit_and_push(commit_message)

            typer.echo("✓ Changes pushed to remote")
        else:
            typer.echo("✓ Changes saved to local store")

        # 8. For local backend, automatically create symlinks
        if config.backend == "local":
            typer.echo("\nCreating symlinks...")

            # Remove existing files/directories before linking
            for target in found_targets:
                target_path = project_dir / target
                if target_path.exists() or target_path.is_symlink():
                    if target_path.is_dir() and not target_path.is_symlink():
                        shutil.rmtree(target_path)
                    else:
                        target_path.unlink()

            # Create symlinks
            backed_up_files = project_manager.link_project(
                project_dir, project_name, found_targets, force=True
            )

            if backed_up_files:
                typer.echo("\n⚠️  Original files were backed up:")
                for backup_path in backed_up_files:
                    typer.echo(f"   → {backup_path}")
                typer.echo(f"\nBackup location: {backup_dir}")

            typer.echo("✓ Symlinks created")

        typer.echo(f"\n✓ Project '{project_name}' initialized successfully!")

        if config.backend == "git":
            typer.echo("\nNext steps:")
            typer.echo("  - On another machine, run 'ars link' to link these settings")
        else:
            typer.echo(f"\nYour project is now synced via {store_path}")

        # Perform auto-sync if enabled
        perform_auto_sync(config)

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during init")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Failed to initialize project: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=[
                "Check that you have write permissions to the store directory",
                "Verify the store directory is accessible",
                "Ensure you're in the correct project directory",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during init")
        raise typer.Exit(code=1)


@app.command()
def link(
    project: str | None = typer.Option(
        None, help="Project name (defaults to current directory name)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files"),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Link store settings to current directory.

    Creates symlinks from current directory to store. Backs up existing files unless --force is used.

    Examples:
        ars link
        ars link --project my-project
        ars link --force
        ars link --debug
    """
    setup_logging(debug)

    try:
        # 1. Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store not initialized",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize the store",
                    "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                ],
            )

        # 2. Determine project name
        project_name = project if project else ProjectManager.get_current_project_name()

        # 3. Check if store directory exists
        store_path = Path(config.store_path)
        if not store_path.exists():
            raise ARSyncError(
                f"Store directory does not exist: {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store directory may have been deleted or moved",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                    "Or update the store path: ars config --path /path/to/store",
                ],
            )

        # 4. Get project info from store
        store_manager = StoreManager(store_path)

        try:
            project_info = store_manager.get_project(project_name)
        except FileNotFoundError:
            raise ARSyncError(
                f"Store metadata file not found at {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store may not be properly initialized",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                ],
            )

        if project_info is None:
            raise ARSyncError(
                f"Project '{project_name}' not found in store",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars status' to see available projects",
                    "Or run 'ars add' to add this project first",
                ],
            )

        typer.echo(f"Linking project: {project_name}")
        typer.echo(f"Targets: {', '.join(project_info.targets)}")

        # 5. Check if project directory exists in store
        project_store_dir = store_path / project_name
        if not project_store_dir.exists():
            raise ARSyncError(
                f"Project directory not found in store: {project_store_dir}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The project metadata exists but the directory is missing",
                    "Run 'ars add' to recreate the project in store",
                    "Or check if the store directory has been modified manually",
                ],
            )

        # 6. Create symlinks
        project_dir = Path.cwd()
        backup_dir = Path(config.backup_dir)
        project_manager = ProjectManager(store_path, backup_dir)

        try:
            backed_up_files = project_manager.link_project(
                project_dir, project_name, project_info.targets, force
            )
        except FileExistsError as e:
            raise ARSyncError(
                str(e),
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Use --force to overwrite existing files",
                    "Or manually remove/rename the existing files",
                ],
            )

        # Show backup information if files were backed up
        if backed_up_files:
            typer.echo("\n⚠️  Existing files were backed up:")
            for backup_path in backed_up_files:
                typer.echo(f"   → {backup_path}")
            typer.echo(f"\nBackup location: {backup_dir}")

        typer.echo("✓ Symlinks created")

        # 7. Update store metadata with current machine and set sync_mode to "link"
        hostname = ProjectManager.get_hostname()
        store_manager.add_project(
            project_name, project_info.targets, hostname, sync_mode=SYNC_MODE_LINK
        )

        typer.echo("✓ Store metadata updated (sync_mode: link)")

        typer.echo(f"\n✓ Project '{project_name}' linked successfully!")
        typer.echo(f"Machine: {hostname}")

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during link")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Failed to link project: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=[
                "Check that you have write permissions in the current directory",
                "On Windows, ensure Developer Mode is enabled for symlink support",
                "Verify the store directory is accessible",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during link")
        raise typer.Exit(code=1)


def _display_current_project_status(
    config: LocalConfig,
    metadata: StoreMetadata,
    project_name: str,
    detection_method: str | None,
    store_path: Path,
    current_dir: Path,
) -> None:
    """Display detailed status for current project."""
    project_info = metadata.projects[project_name]

    typer.echo(f"Project: {project_name}")
    typer.echo(f"Status: Synced with store (detected by {detection_method})")
    typer.echo(f"Targets: {', '.join(project_info.targets)}")
    typer.echo(f"Sync Mode: {project_info.sync_mode}")
    typer.echo()

    # Local status - check each target (only for symlink mode)
    if project_info.sync_mode == "symlink":
        typer.echo("Local Status:")
        for target in project_info.targets:
            local_path = current_dir / target
            store_target_path = store_path / project_name / target

            if local_path.is_symlink():
                target_resolved = local_path.resolve()
                if target_resolved == store_target_path.resolve():
                    typer.echo(f"  {target:20s} Linked to store")
                else:
                    typer.echo(f"  {target:20s} Symlink (wrong target)")
            elif local_path.exists():
                typer.echo(f"  {target:20s} Exists (not linked)")
            else:
                typer.echo(f"  {target:20s} Missing")
        typer.echo()

    # Store status
    typer.echo("Store Status:")
    typer.echo(f"  Path: {store_path / project_name}")

    # Check Git status if git backend
    if config.backend == "git" and config.repo_url:
        try:
            from ar_sync.git_backend import GitBackend

            git_backend = GitBackend(store_path, config.repo_url)
            git_backend.initialize()

            if git_backend.repo is not None:
                is_dirty = git_backend.repo.is_dirty(untracked_files=True)
                if is_dirty:
                    typer.echo("  Uncommitted changes: Yes")
                else:
                    typer.echo("  Uncommitted changes: None")
        except Exception:
            pass
    typer.echo()

    # Remote status
    if config.backend == "git" and config.repo_url:
        typer.echo("Remote Status:")
        typer.echo(f"  Repository: {config.repo_url}")
        typer.echo()

    # Machines
    typer.echo(f"Machines ({len(project_info.machines)}):")
    current_hostname = ProjectManager.get_hostname()
    for machine in project_info.machines:
        is_current_machine = machine.hostname == current_hostname
        marker = " (current)" if is_current_machine else ""
        typer.echo(f"  - {machine.hostname}{marker}")
        typer.echo(f"    Last sync: {machine.linked_at}")
    typer.echo()

    typer.echo("Tip: Run 'ars status --all' to see all registered projects")


def _display_unregistered_status(
    config: LocalConfig, metadata: StoreMetadata, current_dir: Path, store_path: Path
) -> None:
    """Display status when current directory is not registered."""
    typer.echo("Current directory is not registered with ar-sync.")
    typer.echo()

    # Scan for available targets
    found_targets = ProjectManager.scan_targets(current_dir, config.default_targets)
    if found_targets:
        typer.echo("Available targets detected:")
        for target in found_targets:
            typer.echo(f"  {target}")
        typer.echo()
        typer.echo("To add this project:")
        typer.echo("  ars init")
        typer.echo()

    # Show registered projects summary
    typer.echo(f"Registered projects ({len(metadata.projects)}):")
    for project_name in metadata.projects.keys():
        typer.echo(f"  - {project_name}")
    typer.echo()

    typer.echo("Tip: Run 'ars status --all' for detailed information")


def _display_all_projects_status(
    config: LocalConfig, metadata: StoreMetadata, current_project: str | None, store_path: Path
) -> None:
    """Display overview of all registered projects."""
    typer.echo(f"Store: {store_path}")
    typer.echo(f"Remote: {config.repo_url if config.repo_url else '(local only)'}")
    typer.echo()
    typer.echo(f"Registered projects ({len(metadata.projects)}):")
    typer.echo()

    current_hostname = ProjectManager.get_hostname()

    for project_name, project_info in metadata.projects.items():
        is_current = project_name == current_project
        prefix = "→ " if is_current else "  "
        current_marker = " (current directory)" if is_current else ""

        typer.echo(f"{prefix}{project_name}{current_marker}")
        typer.echo(f"    Targets: {', '.join(project_info.targets)}")
        typer.echo(f"    Sync Mode: {project_info.sync_mode}")

        # Check if current machine is in the list
        machine_names = [m.hostname for m in project_info.machines]
        if current_hostname in machine_names:
            typer.echo("    Status: Synced on this machine")
        else:
            typer.echo("    Status: Not synced on this machine")

        typer.echo(f"    Machines: {', '.join(machine_names)}")
        typer.echo()


@app.command()
def status(
    all_projects: bool = typer.Option(
        False, "--all", "-a", help="Show all registered projects with details"
    ),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Show project sync status.

    By default, shows detailed status for the current project if registered.
    Use --all to see all registered projects.

    Examples:
        ars status              # Current project details
        ars status --all        # All projects overview
        ars status --debug      # With debug logging
    """
    setup_logging(debug)

    try:
        # 1. Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store not initialized",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize the store",
                    "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                ],
            )

        # 2. Check if store directory exists
        store_path = Path(config.store_path)
        if not store_path.exists():
            raise ARSyncError(
                f"Store directory does not exist: {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store directory may have been deleted or moved",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                    "Or update the store path: ars config --path /path/to/store",
                ],
            )

        # 3. Load store metadata
        store_manager = StoreManager(store_path)

        try:
            metadata = store_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                f"Store metadata file not found at {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store may not be properly initialized",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                ],
            )

        # 4. Detect current project using hybrid approach
        current_dir = Path.cwd()
        detected_project, detection_method = ProjectManager.detect_current_project(
            store_path, current_dir
        )

        # Verify detected project exists in metadata
        if detected_project and detected_project not in metadata.projects:
            detected_project = None
            detection_method = None

        # 4.5. Sync metadata with actual store contents for all projects
        synced_projects = []
        for project_name in metadata.projects.keys():
            if store_manager.sync_metadata_with_store(project_name):
                synced_projects.append(project_name)

        # Reload metadata if any projects were synced
        if synced_projects:
            metadata = store_manager.load()
            if DEBUG_MODE:
                typer.echo(
                    f"Synced metadata for projects: {', '.join(synced_projects)}\n", err=True
                )

        # 5. Display status based on context
        if not metadata.projects:
            typer.echo("No projects registered yet.")
            typer.echo("\nRun 'ars add' in a project directory to add it to the store.")
            return

        # Show all projects overview
        if all_projects:
            _display_all_projects_status(config, metadata, detected_project, store_path)
        # Show current project details
        elif detected_project:
            _display_current_project_status(
                config, metadata, detected_project, detection_method, store_path, current_dir
            )
        # Show unregistered directory status
        else:
            _display_unregistered_status(config, metadata, current_dir, store_path)

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during status")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Failed to get status: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=[
                "Check that the store directory is accessible",
                "Verify the metadata file is not corrupted",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during status")
        raise typer.Exit(code=1)


def _display_sync_result(result: SyncResult, dry_run: bool, diff_only: bool) -> None:
    """Display sync result with Rich formatting.

    Args:
        result: SyncResult from BidirectionalSync.sync()
        dry_run: Whether this was a dry-run operation
        diff_only: Whether this was a diff-only operation

    Validates:
    - Requirement 1.2: Display the number of files changed from remote
    - Requirement 1.3: Display "already up to date" message when no changes
    - Requirement 8.1, 8.2, 8.3: Display push results
    """
    from rich.console import Console
    from rich.table import Table

    console = Console()

    # For diff-only mode, result display is handled by BidirectionalSync
    if diff_only:
        return

    # Build summary
    prefix = "[DRY-RUN] " if dry_run else ""

    # Create summary table
    table = Table(show_header=False, box=None)
    table.add_column("Metric", style="dim")
    table.add_column("Value", style="bold")

    if result.pulled_files > 0:
        table.add_row("Files pulled from remote:", f"{result.pulled_files}")

    if result.conflicts_resolved > 0:
        table.add_row("Conflicts resolved:", f"{result.conflicts_resolved}")

    if result.pushed_files > 0:
        table.add_row("Files pushed to remote:", f"{result.pushed_files}")

    if result.skipped_files:
        table.add_row("Files skipped:", f"{len(result.skipped_files)}")

    if result.errors:
        table.add_row("Errors:", f"[red]{len(result.errors)}[/red]")

    # Display summary if there's anything to show
    if table.row_count > 0:
        console.print(f"\n{prefix}[bold]Sync Summary:[/bold]")
        console.print(table)

    # Display errors if any
    if result.errors:
        console.print(f"\n{prefix}[red bold]Errors:[/red bold]")
        for error in result.errors:
            console.print(f"  [red]• {error}[/red]")

    # Display skipped files if any
    if result.skipped_files:
        console.print(f"\n{prefix}[yellow]Skipped files:[/yellow]")
        for skipped in result.skipped_files:
            console.print(f"  [dim]• {skipped}[/dim]")

    # Final status message
    if not result.errors:
        if dry_run:
            console.print(f"\n{prefix}[green]✓ Dry-run complete. No changes were made.[/green]")
        else:
            total_changes = result.pulled_files + result.conflicts_resolved + result.pushed_files
            if total_changes > 0:
                console.print("\n[green]✓ Sync complete![/green]")
            else:
                console.print("\n[green]✓ Already in sync. No changes needed.[/green]")
    else:
        console.print(f"\n{prefix}[yellow]⚠️  Sync completed with errors.[/yellow]")


@app.command()
def sync(
    message: str | None = typer.Option(None, "-m", help="Commit message"),
    pull_only: bool = typer.Option(False, "--pull", help="Pull only (Remote → Store → Project)"),
    push_only: bool = typer.Option(False, "--push", help="Push only (Project → Store → Remote)"),
    local: bool = typer.Option(
        False, "--local", help="Automatically prefer local (project) files for all conflicts"
    ),
    remote: bool = typer.Option(
        False, "--remote", help="Automatically prefer remote (store) files for all conflicts"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without applying them"),
    diff: bool = typer.Option(False, "--diff", help="Show differences only without syncing"),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Synchronize project files with store and remote repository.

    This command performs bidirectional synchronization between:
    - Project directory (current working directory)
    - Store (~/.ar-sync-store)
    - Remote Git repository

    Sync Phases:
    1. Pull Phase: Remote → Store → Project
    2. Change Detection: Compare Project ↔ Store
    3. Conflict Resolution: Interactive or automatic
    4. Push Phase: Project → Store → Remote

    Conflict Resolution Options:
    - Interactive (default): Prompt for each conflict [l]ocal/[r]emote/[m]erge/[s]kip
    - --local: Automatically use project directory version for all conflicts
    - --remote: Automatically use store version for all conflicts

    Examples:
        ars sync                    # Full bidirectional sync (interactive)
        ars sync -m "Update"        # Full sync with custom commit message
        ars sync --pull             # Only pull from remote to project
        ars sync --push             # Only push from project to remote
        ars sync --local            # Auto-resolve conflicts using local files
        ars sync --remote           # Auto-resolve conflicts using remote files
        ars sync --dry-run          # Preview what would change
        ars sync --diff             # Show differences only
        ars sync --debug            # Show detailed logs
    """
    setup_logging(debug)

    try:
        # 1. Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store not initialized",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize the store",
                    "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                ],
            )

        # 2. Get store path
        store_path = Path(config.store_path)

        # 3. Perform sync based on backend type
        if config.backend == "git":
            # Git backend: sync with remote repository
            git_backend = GitBackend(store_path, config.repo_url)
            git_backend.initialize()

            # 4. Perform sync
            if pull_only and push_only:
                raise ARSyncError(
                    "Cannot use --pull and --push together",
                    ErrorCategory.USER_INPUT,
                    recovery_steps=[
                        "Use --pull for pull only",
                        "Use --push for push only",
                        "Or use neither for full sync",
                    ],
                )

            # Validate --local and --remote mutual exclusivity (Requirement 6.3)
            if local and remote:
                raise ARSyncError(
                    "Cannot use --local and --remote together",
                    ErrorCategory.USER_INPUT,
                    recovery_steps=[
                        "Use --local to prefer project directory files for all conflicts",
                        "Use --remote to prefer store files for all conflicts",
                        "Or use neither for interactive conflict resolution",
                    ],
                )

            # Get current project info for bidirectional sync
            current_project = ProjectManager.get_current_project_name()
            current_dir = Path.cwd()
            store_manager = StoreManager(store_path)

            try:
                project_info = store_manager.get_project(current_project)
            except FileNotFoundError:
                project_info = None

            # If project is registered, use BidirectionalSync
            if project_info is not None:
                # Create SyncOptions from CLI arguments (Requirement 6.1, 6.2, 7.1, 3.3, 9.1, 9.2)
                if local:
                    strategy = ResolutionStrategy.LOCAL
                elif remote:
                    strategy = ResolutionStrategy.REMOTE
                else:
                    strategy = ResolutionStrategy.INTERACTIVE

                sync_options = SyncOptions(
                    strategy=strategy,
                    dry_run=dry_run,
                    diff_only=diff,
                    pull_only=pull_only,
                    push_only=push_only,
                )

                # Get project store path (project-specific subdirectory)
                project_store_path = store_path / current_project

                # Create BidirectionalSync instance
                bidirectional_sync = BidirectionalSync(
                    project_dir=current_dir,
                    store_path=project_store_path,
                    project_name=current_project,
                    targets=project_info.targets,
                    git_backend=git_backend,
                )

                # Execute sync and get result
                result = bidirectional_sync.sync(sync_options)

                # Display results with Rich formatting
                _display_sync_result(result, dry_run, diff)

            else:
                # Project not registered - fall back to legacy sync behavior
                # Handle --diff mode (Requirement 3.3)
                if diff:
                    typer.echo("[DRY-RUN] Showing differences only (no changes will be made)\n")
                    typer.echo(
                        "⚠️  Project not registered. Use 'ars init' or 'ars add' first for full diff support."
                    )
                    return

                # Handle --dry-run mode (Requirement 7.1)
                if dry_run:
                    typer.echo("[DRY-RUN] Preview mode - no changes will be applied\n")
                    typer.echo(
                        "⚠️  Project not registered. Use 'ars init' or 'ars add' first for full dry-run support."
                    )

                if not push_only:
                    typer.echo("[1/2] Pulling changes from remote repository...")
                    pull_result = git_backend.pull()
                    if pull_result["files_changed"] > 0:
                        typer.echo(f"✓ Pulled {pull_result['files_changed']} file(s) from remote")
                    else:
                        typer.echo("✓ No changes from remote (already up to date)")

                if not pull_only:
                    typer.echo("[2/2] Committing and pushing local changes...")
                    push_result = git_backend.commit_and_push(message)
                    if push_result["committed"]:
                        typer.echo(f"✓ Committed {push_result['files_changed']} file(s)")
                        typer.echo("✓ Pushed to remote")
                    else:
                        typer.echo("✓ No local changes to push")
        else:
            # Local backend: just sync metadata and pull missing targets
            if pull_only or push_only or message or local or remote or dry_run or diff:
                typer.echo(
                    "⚠️  --pull, --push, -m, --local, --remote, --dry-run, --diff options are only available for 'git' backend"
                )
                typer.echo(
                    "For 'local' backend, sync only updates metadata and pulls missing targets\n"
                )

            typer.echo("Syncing metadata with store contents...")

        # 5. Sync metadata with actual store contents
        store_manager = StoreManager(store_path)
        try:
            metadata = store_manager.load()
            synced_projects = []
            for project_name in metadata.projects.keys():
                if store_manager.sync_metadata_with_store(project_name):
                    synced_projects.append(project_name)
                    project = metadata.projects[project_name]
                    typer.echo(
                        f"  Updated targets for '{project_name}': {', '.join(project.targets)}"
                    )

            if synced_projects:
                typer.echo(f"\n✓ Synced metadata for {len(synced_projects)} project(s)")
        except FileNotFoundError:
            pass  # Metadata file doesn't exist yet

        # 6. Check if current directory is a registered project and pull missing targets
        current_project = ProjectManager.get_current_project_name()
        current_dir = Path.cwd()

        try:
            project_info = store_manager.get_project(current_project)
            if project_info is not None:
                # Check which targets exist in store but not in current directory
                missing_targets = []
                for target in project_info.targets:
                    target_path = current_dir / target
                    store_target_path = store_path / current_project / target

                    # Target exists in store but not in project directory
                    if store_target_path.exists() and not target_path.exists():
                        missing_targets.append(target)

                if missing_targets:
                    typer.echo(
                        f"\nProject '{current_project}' missing targets: {', '.join(missing_targets)}"
                    )
                    typer.echo("Pulling missing targets from store...")

                    # Pull only missing targets
                    for target in missing_targets:
                        source = store_path / current_project / target
                        dest = current_dir / target

                        # Remove stale symlinks or existing files if needed
                        if dest.is_symlink():
                            dest.unlink()
                        elif dest.exists():
                            if dest.is_dir():
                                shutil.rmtree(dest)
                            else:
                                dest.unlink()

                        if source.is_dir():
                            shutil.copytree(source, dest)
                        else:
                            dest.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(source, dest)

                        typer.echo(f"  ✓ {target} copied")

                    typer.echo(f"✓ Pulled {len(missing_targets)} target(s) from store")
        except FileNotFoundError:
            pass  # Project not found or metadata doesn't exist

        typer.echo("\n✓ Store synchronization complete!")

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during sync")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Synchronization failed: {str(e)}",
            ErrorCategory.GIT,
            recovery_steps=[
                "Check your network connection",
                "Verify Git credentials are configured",
                "Ensure the remote repository is accessible",
                "If there are conflicts, resolve them manually in the store directory",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during sync")
        raise typer.Exit(code=1)


@app.command()
def pull(
    project: str | None = typer.Option(
        None, help="Project name (defaults to current directory name)"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Force pull even if project uses symlinks"
    ),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Pull changes from store to current project directory.

    This command copies files from the store to your project directory.
    For git backend: pulls from remote to store first, then copies to project.
    For local backend: directly copies from store to project.

    Operations (git backend):
    1. Pull remote changes to store
    2. Copy files from store to project directory

    Operations (local backend):
    1. Copy files from store to project directory

    Examples:
        ars pull                    # Pull to current directory
        ars pull --project my-proj  # Pull specific project
        ars pull --force            # Force pull even if using symlinks
        ars pull --debug            # Show detailed logs
    """
    setup_logging(debug)

    try:
        # 1. Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store not initialized",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize the store",
                    "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                ],
            )

        # 2. Determine project name
        project_name = project if project else ProjectManager.get_current_project_name()

        # 3. Check if store directory exists
        store_path = Path(config.store_path)
        if not store_path.exists():
            raise ARSyncError(
                f"Store directory does not exist: {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store directory may have been deleted or moved",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                ],
            )

        # 4. For git backend, check if we need to sync first
        if config.backend == "git" and config.repo_url:
            git_backend = GitBackend(store_path, config.repo_url)
            git_backend.initialize()

            # Smart detection: check if store is behind remote
            if git_backend.needs_pull():
                typer.echo("Store is behind remote. Syncing first...")
                typer.echo("[1/2] Pulling changes from remote repository to store...")
                pull_result = git_backend.pull()
                if pull_result["files_changed"] > 0:
                    typer.echo(
                        f"✓ Pulled {pull_result['files_changed']} file(s) from remote to store"
                    )
                else:
                    typer.echo("✓ Store is up to date with remote")
            else:
                typer.echo("[1/2] Store is already up to date with remote")

        # 5. Get project info from store and sync metadata
        store_manager = StoreManager(store_path)

        # Sync metadata with actual store contents
        if store_manager.sync_metadata_with_store(project_name):
            typer.echo(f"  Synced metadata for '{project_name}'")

        try:
            project_info = store_manager.get_project(project_name)
        except FileNotFoundError:
            raise ARSyncError(
                f"Store metadata file not found at {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store may not be properly initialized",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                ],
            )

        if project_info is None:
            raise ARSyncError(
                f"Project '{project_name}' not found in store",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars status' to see available projects",
                    "Or run 'ars add' to add this project first",
                ],
            )

        # 5.5. Check sync_mode and warn if using symlinks
        if project_info.sync_mode == SYNC_MODE_LINK and not force:
            typer.echo(
                "Warning: This project uses symlinks. "
                "Use 'ars link' instead, or use --force to override.",
                err=True,
            )
            raise typer.Exit(code=1)

        # 6. Copy files from store to project directory
        project_dir = Path.cwd()
        backup_dir = Path(config.backup_dir)
        project_manager = ProjectManager(store_path, backup_dir)

        step_num = "[2/2]" if config.backend == "git" else "[1/1]"
        typer.echo(f"{step_num} Copying files from store to project directory...")
        typer.echo(f"  Project: {project_name}")
        typer.echo(f"  Targets: {', '.join(project_info.targets)}")

        project_manager.pull_from_store(project_dir, project_name, project_info.targets)

        typer.echo(f"✓ Files copied to {project_dir}")
        typer.echo("\n✓ Pull complete!")

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during pull")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Pull failed: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=[
                "Check that you have write permissions in the current directory",
                "Verify the store directory is accessible",
                "For git backend, ensure network connection is available",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during pull")
        raise typer.Exit(code=1)


@app.command()
def push(
    project: str | None = typer.Option(
        None, help="Project name (defaults to current directory name)"
    ),
    message: str | None = typer.Option(None, "-m", help="Commit message (git backend only)"),
    force: bool = typer.Option(
        False, "--force", "-f", help="Force push even if project uses symlinks"
    ),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Push changes from current project directory to store.

    For git backend: copies files to store, then commits and pushes to remote.
    For local backend: copies files to store.

    Examples:
        ars push
        ars push --project my-project
        ars push -m "Update settings"
        ars push --force              # Force push even if using symlinks
        ars push --debug
    """
    setup_logging(debug)

    try:
        # 1. Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store not initialized",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize the store",
                    "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                ],
            )

        # 2. Determine project name
        project_name = project if project else ProjectManager.get_current_project_name()

        # 3. Check if store directory exists
        store_path = Path(config.store_path)
        if not store_path.exists():
            raise ARSyncError(
                f"Store directory does not exist: {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store directory may have been deleted or moved",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                ],
            )

        # 4. Get project info from store
        store_manager = StoreManager(store_path)

        try:
            project_info = store_manager.get_project(project_name)
        except FileNotFoundError:
            raise ARSyncError(
                f"Store metadata file not found at {store_path}",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[
                    "The store may not be properly initialized",
                    f"Run 'ars setup --backend {config.backend} --path {store_path}' to reinitialize",
                ],
            )

        if project_info is None:
            raise ARSyncError(
                f"Project '{project_name}' not found in store",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars status' to see available projects",
                    "Or run 'ars add' to add this project first",
                ],
            )

        # 4.5. Check sync_mode and warn if using symlinks
        if project_info.sync_mode == SYNC_MODE_LINK and not force:
            typer.echo(
                "Warning: This project uses symlinks. "
                "Use 'ars link' instead, or use --force to override.",
                err=True,
            )
            raise typer.Exit(code=1)

        # 5. Scan for targets in current directory and update if needed
        project_dir = Path.cwd()
        found_targets = ProjectManager.scan_targets(project_dir, config.default_targets)

        # Check if there are new targets
        current_targets = set(project_info.targets)
        new_targets = set(found_targets) - current_targets

        if new_targets:
            typer.echo(f"Found new targets: {', '.join(sorted(new_targets))}")
            # Update metadata with new targets
            all_targets = sorted(current_targets | set(found_targets))
            hostname = ProjectManager.get_hostname()
            store_manager.add_project(project_name, all_targets, hostname)
            project_info.targets = all_targets
            typer.echo(f"✓ Updated targets: {', '.join(all_targets)}")

        # 6. Copy files from project directory to store
        backup_dir = Path(config.backup_dir)
        project_manager = ProjectManager(store_path, backup_dir)

        typer.echo("Copying files from project directory to store...")
        typer.echo(f"Targets: {', '.join(project_info.targets)}")

        project_manager.push_to_store(project_dir, project_name, project_info.targets)

        typer.echo(f"✓ Files copied to {store_path / project_name}")

        # 7. For git backend, commit and push to remote
        if config.backend == "git" and config.repo_url:
            git_backend = GitBackend(store_path, config.repo_url)
            git_backend.initialize()

            typer.echo("Committing and pushing changes to remote...")

            if message is None:
                message = f"Update project: {project_name}"

            git_backend.commit_and_push(message)

            typer.echo("✓ Changes pushed to remote")
        else:
            typer.echo("✓ Changes saved to local store")

        typer.echo("\n✓ Push complete!")

        # Perform auto-sync if enabled
        perform_auto_sync(config)

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during push")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Push failed: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=[
                "Check that you have write permissions to the store directory",
                "Verify the store directory is accessible",
                "For git backend, ensure network connection and Git credentials are configured",
            ],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during push")
        raise typer.Exit(code=1)


@app.command()
def config(
    show: bool = typer.Option(False, "--show", help="Show current configuration"),
    backend: str | None = typer.Option(None, "--backend", help="Set backend (git or local)"),
    path: str | None = typer.Option(None, "--path", help="Set store path"),
    repo_url: str | None = typer.Option(None, "--repo-url", help="Set repository URL"),
    targets: str | None = typer.Option(
        None, "--targets", help="Set default targets (comma-separated)"
    ),
    auto_sync: str | None = typer.Option(
        None, "--auto-sync", help="Enable/disable auto sync (true/false)"
    ),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """View or modify configuration settings.

    Shows current config or updates specific settings.

    Examples:
        ars config --show
        ars config --backend git
        ars config --path ~/new-store-path
        ars config --repo-url git@github.com:user/new-repo.git
        ars config --targets .cursor,.kiro,.vscode
        ars config --auto-sync true
        ars config --debug
    """
    setup_logging(debug)

    try:
        # Load existing configuration
        config_manager = ConfigManager()
        try:
            current_config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Configuration not found",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars setup' first to initialize configuration",
                    "Example: ars setup --backend git --path ~/ar-sync-store --repo-url git@github.com:user/repo.git",
                ],
            )

        # If show flag is set or no options provided, display current config
        if show or (
            backend is None
            and path is None
            and repo_url is None
            and targets is None
            and auto_sync is None
        ):
            typer.echo("Current configuration:\n")
            typer.echo(f"Backend:         {current_config.backend}")
            typer.echo(f"Store path:      {current_config.store_path}")
            typer.echo(
                f"Repository URL:  {current_config.repo_url if current_config.repo_url else '(not set)'}"
            )
            typer.echo(f"Default targets: {', '.join(current_config.default_targets)}")
            typer.echo(f"Auto sync:       {current_config.auto_sync}")
            typer.echo(f"Backup originals: {current_config.backup_originals}")
            typer.echo(f"Backup directory: {current_config.backup_dir}")
            typer.echo(f"\nConfig file: {ConfigManager.CONFIG_PATH}")
            return

        # Update configuration
        updated = False

        if backend is not None:
            if backend not in ["git", "local"]:
                raise ARSyncError(
                    f"Invalid backend: {backend}",
                    ErrorCategory.USER_INPUT,
                    recovery_steps=["Use 'git' or 'local' as the backend"],
                )
            current_config.backend = backend
            updated = True
            typer.echo(f"✓ Backend set to: {backend}")

        if path is not None:
            expanded_path = str(Path(path).expanduser().resolve())
            current_config.store_path = expanded_path
            updated = True
            typer.echo(f"✓ Store path set to: {expanded_path}")

        if repo_url is not None:
            current_config.repo_url = repo_url
            updated = True
            typer.echo(f"✓ Repository URL set to: {repo_url}")

        if targets is not None:
            target_list = [t.strip() for t in targets.split(",")]
            current_config.default_targets = target_list
            updated = True
            typer.echo(f"✓ Default targets set to: {', '.join(target_list)}")

        if auto_sync is not None:
            auto_sync_lower = auto_sync.lower()
            if auto_sync_lower not in ["true", "false"]:
                raise ARSyncError(
                    f"Invalid auto-sync value: {auto_sync}",
                    ErrorCategory.USER_INPUT,
                    recovery_steps=["Use 'true' or 'false' for --auto-sync option"],
                )
            current_config.auto_sync = auto_sync_lower == "true"
            updated = True
            typer.echo(f"✓ Auto sync set to: {current_config.auto_sync}")

        if updated:
            config_manager.save(current_config)
            typer.echo(f"\n✓ Configuration updated and saved to {ConfigManager.CONFIG_PATH}")

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during config")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Configuration operation failed: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=["Check file permissions", "Ensure configuration file is not corrupted"],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during config")
        raise typer.Exit(code=1)


@app.command()
def remove(
    project_name: str = typer.Argument(..., help="Name of the project to remove"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable debug logging"),
) -> None:
    """Remove a project from ar-sync.

    Unregisters the project from store metadata. Does not delete files.

    Examples:
        ars remove my-project
        ars remove my-project --yes
    """
    setup_logging(debug)

    try:
        # Load configuration
        config_manager = ConfigManager()
        try:
            config = config_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store not initialized",
                ErrorCategory.USER_INPUT,
                recovery_steps=["Run 'ars setup' first to initialize the store"],
            )

        # Check if store exists
        store_path = Path(config.store_path)
        if not store_path.exists():
            raise ARSyncError(
                "Store directory does not exist",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=[f"Create store directory at {store_path}"],
            )

        # Load store metadata
        store_manager = StoreManager(store_path)
        try:
            metadata = store_manager.load()
        except FileNotFoundError:
            raise ARSyncError(
                "Store metadata not found",
                ErrorCategory.FILE_SYSTEM,
                recovery_steps=["Run 'ars setup' to initialize the store"],
            )

        # Check if project exists
        if project_name not in metadata.projects:
            raise ARSyncError(
                f"Project '{project_name}' not found",
                ErrorCategory.USER_INPUT,
                recovery_steps=[
                    "Run 'ars status' to see registered projects",
                    "Check project name spelling",
                ],
            )

        # Confirm removal
        if not yes:
            confirm = typer.confirm(
                f"Remove project '{project_name}' from ar-sync?\n"
                "This will unregister the project but will not delete any files."
            )
            if not confirm:
                typer.echo("Operation cancelled")
                return

        # Remove project from metadata
        store_manager.remove_project(project_name)

        typer.echo(f"✓ Project '{project_name}' removed from ar-sync")

    except ARSyncError as e:
        typer.echo(e.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("ARSyncError occurred during remove")
        raise typer.Exit(code=1)
    except Exception as e:
        error = ARSyncError(
            f"Remove operation failed: {str(e)}",
            ErrorCategory.FILE_SYSTEM,
            recovery_steps=["Check file permissions", "Ensure configuration file is accessible"],
        )
        typer.echo(error.format_error(), err=True)
        if DEBUG_MODE:
            logger.exception("Unexpected error occurred during remove")
        raise typer.Exit(code=1)


def main() -> None:
    """Entry point for the CLI application."""
    app()


if __name__ == "__main__":
    main()
