This directory contains scripts meant to help configuring ARA with Ansible.

For more information, visit the documentation_.

.. _documentation: https://ara.readthedocs.io/en/latest/ansible-configuration.html
