Vendored static assets
======================

Via: https://getbootstrap.com/docs/5.3/getting-started/download/ (https://github.com/twbs/bootstrap/releases/download/v5.3.3/bootstrap-5.3.3-dist.zip)

- ``bootstrap-5.3.3-dist/css/bootstrap.min.css``: css/bootstrap.min.css (sha256 3c8f27e6009ccfd710a905e6dcf12d0ee3c6f2ac7da05b0572d3e0d12e736fc8)
- ``bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js``: js/bootstrap.bundle.min.js (sha256 0833b2e9c3a26c258476c46266e6877fc75218625162e0460be9a3a098a61c6c)

Via: https://github.com/twbs/icons/releases/download/v1.13.1/bootstrap-icons-1.13.1.zip

- ``bootstrap-icons-1.13.1/bootstrap-icons.min.css``: css/bootstrap-icons.min.css (sha256 a5d6387a32ca3baec4d02336b5b3edab50c9dd518355576a011ea3dd9c1d884e)
- ``bootstrap-icons-1.13.1/fonts/bootstrap-icons.woff2``: css/fonts/bootstrap-icons.woff2 (sha256 6c75710364a1ca5604267716f6d28997b26319fdb078cf11e0b42ab66ff2ea61)
