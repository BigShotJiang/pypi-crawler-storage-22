from ara_cli.file_loaders.document_reader import DocumentReader

class ExcelReader(DocumentReader):
    """Reader for Excel files"""

    def read(self, extract_images: bool = False) -> str:
        import pandas as pd

        try:
            # Read all sheets
            sheets_dict = pd.read_excel(self.file_path, sheet_name=None)
            markdown_output = []

            for sheet_name, df in sheets_dict.items():
                markdown_output.append(f"### Sheet: {sheet_name}")
                if df.empty:
                    markdown_output.append("_Empty Sheet_")
                else:
                    # Convert to markdown, managing NaN values
                    markdown_table = df.fillna("").to_markdown(index=False)
                    markdown_output.append(markdown_table)
                markdown_output.append("")  # Add empty line between sheets

            return "\n".join(markdown_output)

        except Exception as e:
            return f"Error reading Excel file: {str(e)}"
