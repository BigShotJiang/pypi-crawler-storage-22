# version.py
__version__ = "0.1.14.0"   # fith parameter like .0 for local install test purposes only. official numbers should be 4 digit numbers
