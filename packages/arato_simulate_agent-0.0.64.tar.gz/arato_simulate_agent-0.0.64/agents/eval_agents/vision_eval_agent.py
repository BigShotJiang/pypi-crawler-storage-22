"""
Base class for vision-based evaluation agents using Gemini Flash.

Provides reusable infrastructure for:
- Screenshot reading and base64 encoding
- Multimodal LLM calls (Gemini Flash with image input)
- Bounding box annotation on screenshots
- Template method evaluate_turn() with pre-check and prompt hooks

Subclasses implement:
- _should_evaluate(): pre-check whether vision evaluation is needed
- _build_eval_prompt(): build the domain-specific evaluation prompt
- Optionally _process_result(): custom result handling
"""

import base64
import logging
import textwrap
from pathlib import Path
from typing import Any

from browser_use.llm.messages import SystemMessage, UserMessage
from json_repair import loads as repair_json
from PIL import Image, ImageDraw, ImageFont

from constants import (
    CATEGORY_ACCURACY,
    SCORE_THRESHOLD_GOOD,
    SCORE_THRESHOLD_PASS,
    VERTEX_MODEL_ID_GEMINI_FLASH,
)
from core.multiagent.capabilities import Capability
from core.multiagent.context import ConversationContext, EvalContext, RunContext
from core.multiagent.finding import Finding
from core.multiagent.strands_eval_agent import EvalState, StrandsEvalAgent
from core.multiagent.sub_agent import LLMEvalResult
from utils.token_tracker import TokenUsage

logger = logging.getLogger(__name__)


class VisionEvalAgent(StrandsEvalAgent):
    """Base class for vision-based evaluation agents.

    Uses Gemini Flash with multimodal input to evaluate screenshots.
    Subclasses provide domain-specific pre-checks and prompts.

    Template method evaluate_turn():
      1. Read screenshot -> skip if none
      2. _should_evaluate(context) -> subclass pre-check (default: True)
      3. _build_eval_prompt(context) -> subclass provides prompt
      4. _call_vision_llm() -> shared Gemini multimodal call
      5. _process_result() -> create Finding + annotate if detected
    """

    def __init__(
        self,
        agent_id: str,
        name: str,
        description: str,
        capabilities: set[Capability],
        category: str = CATEGORY_ACCURACY,
        version: str = "2.0.0",
        tags: list[str] | None = None,
        domains: list[str] | None = None,
        finding_title: str = "Vision Validation",
        finding_what_was_tested: str = "Visual validation of screenshot",
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            name=name,
            description=description,
            capabilities=capabilities,
            category=category,
            version=version,
            tags=tags,
            domains=domains,
        )
        self._model_id = VERTEX_MODEL_ID_GEMINI_FLASH
        self._system_prompt: str = ""  # Subclasses set this
        self._finding_title = finding_title
        self._finding_what_was_tested = finding_what_was_tested

    def get_tools(
        self, state: EvalState, context: EvalContext | ConversationContext | RunContext
    ) -> list:
        """Return base tools only - vision evaluation doesn't use additional tools."""
        return super().get_tools(state, context)

    # ── Template method ─────────────────────────────────────────────

    async def evaluate_turn(self, context: EvalContext) -> list[Finding]:
        """Evaluate using vision. Subclasses customize via hooks."""
        results: list[Finding] = []
        log_prefix = f"[{self.agent_id.upper()}]"

        # 1. Read screenshot
        screenshot_data = self._read_screenshot(context.screenshot_path)
        if screenshot_data is None:
            logger.debug(f"{log_prefix} No screenshot available - skipping")
            return results

        screenshot_b64, screenshot_path = screenshot_data

        # 2. Pre-check
        if not await self._should_evaluate(context):
            logger.debug(f"{log_prefix} Pre-check returned False - skipping")
            return results

        # 3. Build prompt
        eval_prompt = self._build_eval_prompt(context)

        # 4. Call vision LLM
        eval_result = await self._call_vision_llm(
            eval_prompt, context, screenshot_b64, screenshot_path
        )

        # 5. Process result
        if eval_result is not None:
            finding = self._process_result(eval_result, context, screenshot_path)
            if finding is not None:
                results.append(finding)

        self.log_evaluate_turn_results(context, results)
        return results

    # ── Hooks for subclasses ────────────────────────────────────────

    async def _should_evaluate(self, context: EvalContext) -> bool:
        """Pre-check whether vision evaluation is needed.

        Override in subclasses for domain-specific filtering.
        Default: always evaluate.
        """
        return True

    def _build_eval_prompt(self, context: EvalContext) -> str:
        """Build the evaluation prompt for the vision LLM.

        Must be overridden by subclasses.
        """
        raise NotImplementedError("Subclasses must implement _build_eval_prompt")

    def _process_result(
        self,
        eval_result: LLMEvalResult,
        context: EvalContext,
        screenshot_path: Path,
    ) -> Finding | None:
        """Process the LLM result into a Finding.

        Default: create finding + annotate screenshot if detected.
        Override for custom behavior.
        """
        if eval_result.skip_finding:
            return None

        finding = self._create_finding(
            category=self._category,
            title=self._finding_title,
            what_was_tested=self._finding_what_was_tested,
            score=eval_result.score,
            explanation=eval_result.explanation,
            confidence=eval_result.confidence,
            turn_id=context.turn_id,
            turn_number=context.turn_number,
            user_message=context.user_message,
            bot_response=context.bot_response,
            impact=eval_result.impact,
        )
        finding.bounding_box = eval_result.bounding_box

        # Annotate screenshot if issue detected
        if eval_result.detected and eval_result.bounding_box:
            self._annotate_screenshot(
                screenshot_path,
                eval_result.bounding_box,
                eval_result.explanation,
            )

        return finding

    # ── Shared vision infrastructure ────────────────────────────────

    def _read_screenshot(
        self, screenshot_path_str: str | None
    ) -> tuple[str, Path] | None:
        """Read and base64 encode a screenshot.

        Returns:
            (base64_data, path) or None if unavailable
        """
        if not screenshot_path_str:
            return None

        path = Path(screenshot_path_str)
        if not path.exists():
            logger.warning(
                f"[{self.agent_id.upper()}] Screenshot not found: {screenshot_path_str}"
            )
            return None

        try:
            with open(path, "rb") as f:
                data = f.read()
            return base64.b64encode(data).decode("utf-8"), path
        except Exception as e:
            logger.error(f"Failed to read screenshot: {e}")
            return None

    async def _call_vision_llm(
        self,
        evaluation_prompt: str,
        context: EvalContext,
        image_b64: str,
        screenshot_path: Path,
    ) -> LLMEvalResult | None:
        """Call Gemini Flash with text + image for multimodal evaluation.

        Returns:
            LLMEvalResult or None on failure
        """
        log_prefix = f"[{self.agent_id.upper()}]"
        llm = self._get_llm()

        # Build score description
        critical_max = SCORE_THRESHOLD_PASS - 1
        warning_max = SCORE_THRESHOLD_GOOD - 1
        score_desc = (
            f"0-{critical_max} is Critical issue, "
            f"{SCORE_THRESHOLD_PASS}-{warning_max} is Warning, "
            f"{SCORE_THRESHOLD_GOOD}-100 is Good"
        )

        full_prompt = f"""{evaluation_prompt}

USER MESSAGE:
{context.user_message}

BOT RESPONSE:
{context.bot_response}

Respond with ONLY a JSON object (no markdown, no explanation):
{{
  "score": <0-100 where {score_desc}>,
  "explanation": "<brief explanation of your assessment>",
  "confidence": <0.0-1.0 how confident you are>,
  "detected": <true if any issue was detected, false otherwise>,
  "skip_finding": <true if this is routine/trivial good behavior not worth reporting, false otherwise>,
  "impact": "<describe the real-world consequences if this issue affects users - leave empty string for Good scores>",
  "bounding_box": {{
    "top": <top y-coordinate normalized to 0-1000 range>,
    "left": <left x-coordinate normalized to 0-1000 range>,
    "bottom": <bottom y-coordinate normalized to 0-1000 range>,
    "right": <right x-coordinate normalized to 0-1000 range>
  }}
}}

IMPORTANT:
- Set "skip_finding" to true for Good scores ({SCORE_THRESHOLD_GOOD}+) when the behavior is routine/expected.
- Only set "skip_finding" to false for Good scores when the behavior is notably exceptional.
- The bounding_box should highlight the main element you are discussing in your explanation. Use coordinates normalized to a 0-1000 range (where 0 is the top/left edge and 1000 is the bottom/right edge of the image). If you cannot identify a specific element, set bounding_box to null."""

        try:
            messages = []
            if self._system_prompt:
                messages.append(SystemMessage(content=self._system_prompt))
            messages.append(UserMessage(content=full_prompt))

            if hasattr(llm, "_client"):
                from browser_use.llm.google.serializer import GoogleMessageSerializer
                from google.genai import types

                contents, system_instruction = (
                    GoogleMessageSerializer.serialize_messages(messages)
                )

                # Add image part
                image_part = types.Part(
                    inline_data=types.Blob(
                        mime_type="image/png", data=base64.b64decode(image_b64)
                    )
                )
                if contents and isinstance(contents, list) and len(contents) > 0:
                    last_content = contents[-1]
                    if hasattr(last_content, "parts") and last_content.parts:
                        last_content.parts.append(image_part)  # type: ignore[union-attr]
                    else:
                        last_content.parts = [types.Part(text=full_prompt), image_part]  # type: ignore[union-attr]

                config_dict: dict[str, Any] = {}
                if system_instruction:
                    config_dict["system_instruction"] = system_instruction
                if llm.max_tokens:
                    config_dict["max_output_tokens"] = llm.max_tokens
                if llm.temperature is not None:
                    config_dict["temperature"] = llm.temperature

                logger.info(
                    f"{log_prefix} Calling Gemini Flash API with model: {llm.model}"
                )

                response = await llm._client.aio.models.generate_content(
                    model=llm.model,
                    contents=contents,
                    config=types.GenerateContentConfig(**config_dict)
                    if config_dict
                    else None,
                )

                if not response.candidates or not response.candidates[0].content:
                    logger.error(f"{log_prefix} Empty response from Gemini")
                    raise Exception("Empty response from Gemini")

                response_text = response.candidates[0].content.parts[0].text
                usage_info = response.usage_metadata
            else:
                logger.warning(
                    "Could not access Gemini client directly for multimodal content"
                )
                response = await llm.ainvoke(messages)
                response_text = response.completion.strip()
                usage_info = getattr(response, "usage", None)

            # Track token usage
            if usage_info:
                input_tokens = (
                    getattr(usage_info, "prompt_token_count", 0)
                    or getattr(usage_info, "input_tokens", 0)
                    or getattr(usage_info, "prompt_tokens", 0)
                )
                output_tokens = (
                    getattr(usage_info, "candidates_token_count", 0)
                    or getattr(usage_info, "output_tokens", 0)
                    or getattr(usage_info, "completion_tokens", 0)
                )
                total_tokens = getattr(usage_info, "total_token_count", 0) or getattr(
                    usage_info, "total_tokens", 0
                )
                if not total_tokens:
                    total_tokens = (input_tokens or 0) + (output_tokens or 0)
                if total_tokens:
                    self._token_usages.append(
                        TokenUsage(
                            input_tokens=input_tokens or 0,
                            output_tokens=output_tokens or 0,
                            total_tokens=total_tokens,
                            model_id=self._model_id,
                            source=f"sub_agent:{self.agent_id}",
                        )
                    )
                    logger.info(
                        f"{log_prefix} Token usage - input: {input_tokens}, "
                        f"output: {output_tokens}, total: {total_tokens}"
                    )

            # Parse JSON response
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
                response_text = response_text.strip()

            parsed = repair_json(response_text)
            result = parsed if isinstance(parsed, dict) else {}
            logger.info(
                f"{log_prefix} Parsed result: score={result.get('score')}, "
                f"detected={result.get('detected')}, skip_finding={result.get('skip_finding')}"
            )
            logger.info(
                f"{log_prefix} Explanation: {result.get('explanation', '')[:200]}"
            )

            score = float(result.get("score", 50))
            detected = bool(result.get("detected", False))
            bounding_box = result.get("bounding_box")
            skip_finding = bool(result.get("skip_finding", False))

            # If an issue is detected, don't skip the finding
            if detected:
                skip_finding = False

            return LLMEvalResult(
                score=score,
                explanation=result.get("explanation", "No explanation provided"),
                confidence=float(result.get("confidence", 0.5)),
                detected=detected,
                skip_finding=skip_finding,
                impact=result.get("impact", ""),
                bounding_box=bounding_box,
            )

        except Exception as e:
            logger.warning(f"Failed to perform LLM evaluation with image: {e}")
            return None

    def _annotate_screenshot(
        self,
        screenshot_path: Path,
        bounding_box: dict[str, Any],
        explanation: str,
    ) -> Path | None:
        """Draw bounding box and explanation text on screenshot.

        Returns:
            Path to annotated image, or None on failure
        """
        log_prefix = f"[{self.agent_id.upper()}]"

        if not isinstance(bounding_box, dict):
            return None

        top_norm = bounding_box.get("top")
        left_norm = bounding_box.get("left")
        bottom_norm = bounding_box.get("bottom")
        right_norm = bounding_box.get("right")

        if (
            top_norm is None
            or left_norm is None
            or bottom_norm is None
            or right_norm is None
        ):
            logger.debug(f"{log_prefix} Bounding box coordinates incomplete")
            return None

        try:
            img = Image.open(screenshot_path)
            img_width, img_height = img.size

            # Convert normalized 0-1000 coords to pixels
            top = max(0, min(int(float(top_norm) / 1000 * img_height), img_height - 1))
            left = max(0, min(int(float(left_norm) / 1000 * img_width), img_width - 1))
            bottom = max(
                0, min(int(float(bottom_norm) / 1000 * img_height), img_height)
            )
            right = max(0, min(int(float(right_norm) / 1000 * img_width), img_width))

            logger.info(
                f"{log_prefix} Normalized coords: top={top_norm}, left={left_norm}, "
                f"bottom={bottom_norm}, right={right_norm} -> "
                f"Pixel coords: top={top}, left={left}, bottom={bottom}, right={right} "
                f"(image: {img_width}x{img_height})"
            )

            draw = ImageDraw.Draw(img)
            draw.rectangle([left, top, right, bottom], outline="red", width=3)

            # Add text annotation
            if explanation:
                font_size = 24
                font: Any = None
                try:
                    for font_name in [
                        "Arial.ttf",
                        "LiberationSans-Regular.ttf",
                        "DejaVuSans.ttf",
                        "arial.ttf",
                    ]:
                        try:
                            font = ImageFont.truetype(font_name, font_size)
                            break
                        except OSError:
                            continue
                    if font is None:
                        font = ImageFont.load_default(size=font_size)
                except Exception:
                    font = ImageFont.load_default()
                    font_size = 12

                max_width_px = img.width - 40
                avg_char_width = font_size * 0.6
                est_chars_per_line = int(max_width_px / avg_char_width)
                wrapped_lines = textwrap.wrap(explanation, width=est_chars_per_line)

                # Measure text block
                dummy_draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
                max_line_width = 0.0
                for line in wrapped_lines:
                    try:
                        if hasattr(dummy_draw, "textbbox"):
                            bbox = dummy_draw.textbbox((0, 0), line, font=font)
                            lw = float(bbox[2] - bbox[0])
                        elif hasattr(dummy_draw, "textlength"):
                            lw = float(dummy_draw.textlength(line, font=font))
                        else:
                            lw = len(line) * avg_char_width
                    except Exception:
                        lw = len(line) * avg_char_width
                    max_line_width = max(max_line_width, lw)

                line_height = font_size * 1.5
                block_height = len(wrapped_lines) * line_height

                # Position above bounding box if space, otherwise below
                text_y = max(10, top - 10 - block_height)
                if text_y < 10:
                    text_y = bottom + 10
                text_x = 20

                bg_width = min(max_line_width + 40, img.width - 40)
                bg_box = [
                    int(text_x - 10),
                    int(text_y - 10),
                    int(text_x + bg_width),
                    int(text_y + block_height + 10),
                ]
                draw.rectangle(bg_box, fill=(0, 0, 0, 200))

                for i, line in enumerate(wrapped_lines):
                    y_pos = int(text_y + (i * line_height))
                    draw.text((text_x, y_pos), line, fill="white", font=font)

            annotated_path = screenshot_path.with_stem(
                f"{screenshot_path.stem}_annotated"
            )
            img.save(annotated_path)
            logger.info(f"{log_prefix} Saved annotated screenshot: {annotated_path}")
            return annotated_path

        except Exception as e:
            logger.warning(f"{log_prefix} Failed to annotate screenshot: {e}")
            return None

    # ── Pre-check helper ────────────────────────────────────────────

    async def _text_only_llm_check(
        self,
        system_message: str,
        prompt: str,
        result_key: str = "should_evaluate",
        max_tokens: int = 200,
    ) -> bool:
        """Lightweight text-only LLM call for pre-checks.

        Calls Gemini without image to classify whether full evaluation
        is needed. Returns True if the LLM says yes or on failure.

        Args:
            system_message: System prompt for the classifier
            prompt: User prompt with classification question
            result_key: JSON key to read from response (default: "should_evaluate")
            max_tokens: Max response tokens
        """
        log_prefix = f"[{self.agent_id.upper()}]"
        llm = self._get_llm()

        try:
            messages = [
                SystemMessage(content=system_message),
                UserMessage(content=prompt),
            ]

            if hasattr(llm, "_client"):
                from browser_use.llm.google.serializer import GoogleMessageSerializer
                from google.genai import types

                contents, system_instruction = (
                    GoogleMessageSerializer.serialize_messages(messages)
                )
                config_dict: dict[str, Any] = {
                    "max_output_tokens": max_tokens,
                    "temperature": 0.0,
                }
                if system_instruction:
                    config_dict["system_instruction"] = system_instruction

                response = await llm._client.aio.models.generate_content(
                    model=llm.model,
                    contents=contents,
                    config=types.GenerateContentConfig(**config_dict),
                )

                if not response.candidates or not response.candidates[0].content:
                    return True
                response_text = response.candidates[0].content.parts[0].text
            else:
                resp = await llm.ainvoke(messages)
                response_text = resp.completion.strip()

            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
                response_text = response_text.strip()

            parsed = repair_json(response_text)
            if isinstance(parsed, dict):
                value = bool(parsed.get(result_key, True))
                reason = parsed.get("reason", "")
                logger.debug(
                    f"{log_prefix} Pre-check: {result_key}={value}, reason={reason}"
                )
                return value

            return True

        except Exception as e:
            logger.warning(f"{log_prefix} Pre-check failed: {e}, defaulting to True")
            return True


__all__ = ["VisionEvalAgent"]
