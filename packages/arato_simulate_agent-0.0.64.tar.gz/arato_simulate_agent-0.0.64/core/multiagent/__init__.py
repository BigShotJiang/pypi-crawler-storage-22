"""
Multi-agent coordination system for Arato.Agent.

This module provides the foundation for pluggable evaluation agents that can
be dispatched during conversation turns, conversation summaries, and run summaries.

NOTE: Skills are NOT agents. Skills are domain-specific capabilities that
agents can activate during conversation (see skills/ directory and SkillTool).
"""

from core.multiagent.capabilities import AgentCard, Capability
from core.multiagent.context import ConversationContext, EvalContext, RunContext
from core.multiagent.domain_detector import (
    KNOWN_DOMAINS,
    DomainDetector,
    detect_domains_from_context,
)
from core.multiagent.event_bus import AgentEventBus
from core.multiagent.finding import Finding, score_to_label
from core.multiagent.registry import (
    AgentRegistry,
    get_agent_registry,
    reset_agent_registry,
)
from core.multiagent.strands_eval_agent import EvalState, StrandsEvalAgent
from core.multiagent.sub_agent import (
    CONVERSATION_EVAL_JSON_FORMAT,
    FINDING_GENERATION_GUIDANCE,
    SubAgent,
    build_conversation_eval_prompt,
    get_rating_scale,
)

__all__ = [
    "AgentCard",
    "AgentEventBus",
    "AgentRegistry",
    "CONVERSATION_EVAL_JSON_FORMAT",
    "Capability",
    "ConversationContext",
    "DomainDetector",
    "EvalContext",
    "EvalState",
    "FINDING_GENERATION_GUIDANCE",
    "Finding",
    "KNOWN_DOMAINS",
    "RunContext",
    "StrandsEvalAgent",
    "SubAgent",
    "build_conversation_eval_prompt",
    "detect_domains_from_context",
    "get_agent_registry",
    "get_rating_scale",
    "reset_agent_registry",
    "score_to_label",
]
