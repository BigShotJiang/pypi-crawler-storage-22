"""
Context dataclasses for agent communication.

These contexts are passed to sub-agents during dispatch operations.
They contain references to files for efficient context sharing.
"""

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class EvalContext:
    """Context for per-turn evaluation.

    Passed to agents with EVALUATE_TURN capability.
    """

    user_message: str
    bot_response: str
    conversation_id: str
    turn_number: int
    turn_id: str = ""  # UUID of the turn for precise matching
    persona_id: str = ""
    app_context_path: str = ""  # Path to app_context.json
    transcript_path: str = ""  # Path to current transcript
    session_dir: str = ""  # Session directory for artifacts
    screenshot_path: str | None = None
    target_url: str | None = None
    model: str | None = None
    error: str | None = None
    app_context: str | None = None  # Inline app context (alternative to path)
    conversation_history: list[dict[str, Any]] = field(default_factory=list)
    ground_truth: list[dict[str, Any]] = field(
        default_factory=list
    )  # Ground truth data from skills
    test_suite_config: dict[str, Any] | None = (
        None  # Test suite configuration with allowed_disclosures
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    def to_file(self, path: Path) -> None:
        """Save context to file."""
        path.write_text(json.dumps(self.to_dict(), indent=2))

    @classmethod
    def from_file(cls, path: Path) -> "EvalContext":
        """Load context from file."""
        return cls(**json.loads(path.read_text()))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "EvalContext":
        """Create from dictionary."""
        return cls(**data)


@dataclass
class ConversationContext:
    """Context for conversation summary.

    Passed to agents with SUMMARIZE_CONVERSATION capability.
    """

    conversation_id: str
    persona_id: str = ""
    transcript_path: str = ""
    app_context_path: str = ""
    session_dir: str = ""
    target_url: str = ""
    app_context: str | None = None  # Inline app context (alternative to path)
    all_evals: list[dict[str, Any]] = field(default_factory=list)
    total_turns: int = 0
    # In-memory transcript data (alternative to transcript_path)
    # When provided, agents use this instead of reading from disk
    transcript_data: list[dict[str, Any]] = field(default_factory=list)
    # Test suite configuration with allowed_disclosures
    test_suite_config: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    def to_file(self, path: Path) -> None:
        """Save context to file."""
        path.write_text(json.dumps(self.to_dict(), indent=2))

    @classmethod
    def from_file(cls, path: Path) -> "ConversationContext":
        """Load context from file."""
        return cls(**json.loads(path.read_text()))


@dataclass
class RunContext:
    """Context for cross-conversation summary.

    Passed to agents with SUMMARIZE_RUN capability.
    """

    run_id: str = ""
    session_id: str = ""
    target_url: str = ""
    app_context_path: str = ""
    app_context: str | None = None  # Inline app context (alternative to path)
    session_dir: str = ""
    conversation_ids: list[str] = field(default_factory=list)  # Conversation IDs
    all_conversations: list[str] = field(default_factory=list)  # Paths to transcripts
    all_summaries: list[str] = field(default_factory=list)  # Paths to summaries
    all_findings: list[dict[str, Any]] = field(default_factory=list)
    total_personas: int = 0
    # Test suite configuration with allowed_disclosures
    test_suite_config: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    def to_file(self, path: Path) -> None:
        """Save context to file."""
        path.write_text(json.dumps(self.to_dict(), indent=2))

    @classmethod
    def from_file(cls, path: Path) -> "RunContext":
        """Load context from file."""
        return cls(**json.loads(path.read_text()))
