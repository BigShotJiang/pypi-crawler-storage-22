"""
In-process event bus for agent coordination.

Provides async dispatch to registered sub-agents based on their capabilities.
"""

import asyncio
import logging
from collections import defaultdict
from typing import TYPE_CHECKING

from constants import (
    SUB_AGENT_EVALUATE_TURN_TIMEOUT,
    SUB_AGENT_SUMMARIZE_CONVERSATION_TIMEOUT,
    SUB_AGENT_SUMMARIZE_RUN_TIMEOUT,
)
from core.multiagent.capabilities import Capability
from core.multiagent.context import ConversationContext, EvalContext, RunContext
from core.multiagent.finding import Finding

if TYPE_CHECKING:
    from core.multiagent.strands_eval_agent import StrandsEvalAgent
    from core.multiagent.sub_agent import SubAgent

    RegisterableAgent = SubAgent | StrandsEvalAgent

logger = logging.getLogger(__name__)


class AgentEventBus:
    """In-process event bus for sub-agent coordination.

    Manages registration of sub-agents and dispatches requests to agents
    based on their declared capabilities. All dispatch operations run
    agents in parallel with configurable timeouts.
    """

    def __init__(self) -> None:
        self._agents: dict[str, RegisterableAgent] = {}
        self._capability_index: dict[Capability, list[str]] = defaultdict(list)

    def register(self, agent: "RegisterableAgent") -> None:
        """Register a sub-agent with its capabilities.

        Args:
          agent: The sub-agent to register
        """
        card = agent.card
        if card.agent_id in self._agents:
            logger.warning(f"Agent {card.agent_id} already registered, replacing")
            self.unregister(card.agent_id)

        self._agents[card.agent_id] = agent
        for cap in card.capabilities:
            self._capability_index[cap].append(card.agent_id)

        logger.info(
            f"Registered agent: {card.agent_id} ({card.name}) "
            f"with capabilities: {[c.name for c in card.capabilities]}"
        )

    def unregister(self, agent_id: str) -> None:
        """Remove an agent from the bus.

        Args:
          agent_id: ID of the agent to remove
        """
        if agent_id not in self._agents:
            return

        del self._agents[agent_id]
        for cap_list in self._capability_index.values():
            if agent_id in cap_list:
                cap_list.remove(agent_id)

        logger.info(f"Unregistered agent: {agent_id}")

    def get_agents(self, capability: Capability) -> list["RegisterableAgent"]:
        """Get all agents with a specific capability.

        Args:
          capability: The capability to filter by

        Returns:
          List of agents supporting the capability
        """
        return [
            self._agents[aid]
            for aid in self._capability_index[capability]
            if aid in self._agents
        ]

    def get_agents_for_domains(
        self,
        capability: Capability,
        detected_domains: set[str] | None = None,
    ) -> list["RegisterableAgent"]:
        """Get agents with a capability, filtered by applicable domains.

        Args:
          capability: The capability to filter by
          detected_domains: Set of domains detected from app_context.
                           If None, returns all agents (no domain filtering).

        Returns:
          List of agents that should run (generic + matching domain-specific)
        """
        all_agents = self.get_agents(capability)

        if detected_domains is None:
            # No domain filtering, return all
            logger.info(
                f"No domain filtering - returning all {len(all_agents)} agents "
                f"for capability {capability.name}"
            )
            return all_agents

        logger.info(f"Filtering agents for detected domains: {detected_domains}")

        # Filter by domain applicability
        applicable_agents = []
        skipped_agents = []

        for agent in all_agents:
            if agent.card.applies_to_domains(detected_domains):
                applicable_agents.append(agent)
            else:
                skipped_agents.append(agent.agent_id)

        # Log which domain-specific agents are being used (more useful than skipped)
        domain_specific_used = [a.agent_id for a in applicable_agents if a.card.domains]
        generic_agents = [a.agent_id for a in applicable_agents if not a.card.domains]

        logger.info(
            f"Agent filtering result: {len(applicable_agents)} applicable "
            f"({len(generic_agents)} generic: {generic_agents}, "
            f"{len(domain_specific_used)} domain-specific: {domain_specific_used}), "
            f"{len(skipped_agents)} skipped: {skipped_agents}"
        )

        if domain_specific_used:
            logger.info(
                f"Using {len(domain_specific_used)} domain-specific agents "
                f"for domains {detected_domains}: {domain_specific_used}"
            )
        elif detected_domains:
            logger.debug(
                f"No domain-specific agents matched domains {detected_domains}"
            )

        return applicable_agents

    def get_all_agents(self) -> list["RegisterableAgent"]:
        """Get all registered agents."""
        return list(self._agents.values())

    def get_agent(self, agent_id: str) -> "RegisterableAgent | None":
        """Get a specific agent by ID."""
        return self._agents.get(agent_id)

    @property
    def agent_count(self) -> int:
        """Get the number of registered agents."""
        return len(self._agents)

    async def dispatch_evaluate_turn(
        self,
        context: EvalContext,
        timeout: float | None = None,
        detected_domains: set[str] | None = None,
    ) -> list[Finding]:
        """Dispatch evaluation request to applicable EVALUATE_TURN agents.

        Runs all matching agents in parallel and collects their results.
        Failed or timed-out agents are logged but don't fail the dispatch.

        Args:
          context: The evaluation context for this turn
          timeout: Maximum time to wait for all agents (default: SUB_AGENT_EVALUATE_TURN_TIMEOUT)
          detected_domains: Set of domains detected from app_context.
                           Domain-specific agents only run if their domain matches.

        Returns:
          Aggregated list of Findings from all agents
        """
        if timeout is None:
            timeout = SUB_AGENT_EVALUATE_TURN_TIMEOUT

        agents = self.get_agents_for_domains(Capability.EVALUATE_TURN, detected_domains)
        if not agents:
            logger.debug("No applicable agents for EVALUATE_TURN")
            return []

        logger.info(
            f"Dispatching EVALUATE_TURN to {len(agents)} agents for turn {context.turn_number}: "
            f"{[a.agent_id for a in agents]}"
        )

        # Create tasks with agent tracking for better timeout logging
        task_to_agent: dict[asyncio.Task[list[Finding]], RegisterableAgent] = {}
        for agent in agents:
            task = asyncio.create_task(agent.evaluate_turn(context))
            task_to_agent[task] = agent

        results: list[Finding] = []
        done, pending = await asyncio.wait(task_to_agent.keys(), timeout=timeout)

        # Cancel and log timed-out tasks with agent names
        for task in pending:
            task.cancel()
            agent = task_to_agent.get(task)
            agent_name = agent.card.name if agent else "unknown"
            logger.warning(
                f"Agent evaluation timed out: {agent_name} (turn {context.turn_number})"
            )

        # Collect successful results
        for task in done:
            try:
                task_results = task.result()
                if task_results:
                    results.extend(task_results)
            except Exception as e:
                agent = task_to_agent.get(task)
                agent_name = agent.card.name if agent else "unknown"
                logger.warning(f"Agent evaluation failed ({agent_name}): {e}")

        logger.info(
            f"EVALUATE_TURN completed: {len(results)} findings from {len(done)} agents (timed out: {len(pending)})"
        )
        return results

    async def dispatch_summarize_conversation(
        self,
        context: ConversationContext,
        timeout: float | None = None,
        detected_domains: set[str] | None = None,
    ) -> list[Finding]:
        """Dispatch summary request to applicable SUMMARIZE_CONVERSATION agents.

        Args:
          context: The conversation context to summarize
          timeout: Maximum time to wait for all agents (default: SUB_AGENT_SUMMARIZE_CONVERSATION_TIMEOUT)
          detected_domains: Set of domains detected from app_context.
                           Domain-specific agents only run if their domain matches.

        Returns:
          Aggregated list of Findings from all agents
        """
        if timeout is None:
            timeout = SUB_AGENT_SUMMARIZE_CONVERSATION_TIMEOUT

        agents = self.get_agents_for_domains(
            Capability.SUMMARIZE_CONVERSATION, detected_domains
        )
        if not agents:
            logger.debug("No applicable agents for SUMMARIZE_CONVERSATION")
            return []

        agent_names = [a.card.agent_id for a in agents]
        logger.info(
            f"Dispatching SUMMARIZE_CONVERSATION to {len(agents)} agents: {agent_names}"
        )

        # Create tasks with agent tracking for better timeout logging
        task_to_agent: dict[asyncio.Task[list[Finding]], RegisterableAgent] = {}
        for agent in agents:
            task = asyncio.create_task(agent.summarize_conversation(context))
            task_to_agent[task] = agent

        findings: list[Finding] = []
        done, pending = await asyncio.wait(task_to_agent.keys(), timeout=timeout)

        for task in pending:
            task.cancel()
            agent = task_to_agent.get(task)
            agent_name = agent.card.name if agent else "unknown"
            logger.warning(f"Agent summarize_conversation timed out: {agent_name}")

        for task in done:
            try:
                task_findings = task.result()
                if task_findings:
                    findings.extend(task_findings)
            except Exception as e:
                agent = task_to_agent.get(task)
                agent_name = agent.card.name if agent else "unknown"
                logger.warning(
                    f"Agent summarize_conversation failed ({agent_name}): {e}"
                )

        logger.info(
            f"SUMMARIZE_CONVERSATION completed: {len(findings)} findings from {len(done)} agents (timed out: {len(pending)})"
        )
        return findings

    async def dispatch_summarize_run(
        self,
        context: RunContext,
        timeout: float | None = None,
        detected_domains: set[str] | None = None,
    ) -> list[Finding]:
        """Dispatch run summary request to applicable SUMMARIZE_RUN agents.

        Args:
          context: The run context with all conversation data
          timeout: Maximum time to wait for all agents (default: SUB_AGENT_SUMMARIZE_RUN_TIMEOUT)
          detected_domains: Set of domains detected from app_context.
                           Domain-specific agents only run if their domain matches.

        Returns:
          Aggregated list of cross-conversation Findings
        """
        if timeout is None:
            timeout = SUB_AGENT_SUMMARIZE_RUN_TIMEOUT

        agents = self.get_agents_for_domains(Capability.SUMMARIZE_RUN, detected_domains)
        if not agents:
            logger.debug("No applicable agents for SUMMARIZE_RUN")
            return []

        agent_names = [a.card.agent_id for a in agents]
        logger.info(f"Dispatching SUMMARIZE_RUN to {len(agents)} agents: {agent_names}")

        # Create tasks with agent tracking for better timeout logging
        task_to_agent: dict[asyncio.Task[list[Finding]], RegisterableAgent] = {}
        for agent in agents:
            task = asyncio.create_task(agent.summarize_run(context))
            task_to_agent[task] = agent

        findings: list[Finding] = []
        done, pending = await asyncio.wait(task_to_agent.keys(), timeout=timeout)

        for task in pending:
            task.cancel()
            agent = task_to_agent.get(task)
            agent_name = agent.card.name if agent else "unknown"
            logger.warning(f"Agent summarize_run timed out: {agent_name}")

        for task in done:
            try:
                task_findings = task.result()
                if task_findings:
                    findings.extend(task_findings)
            except Exception as e:
                agent = task_to_agent.get(task)
                agent_name = agent.card.name if agent else "unknown"
                logger.warning(f"Agent summarize_run failed ({agent_name}): {e}")

        logger.info(
            f"SUMMARIZE_RUN completed: {len(findings)} findings from {len(done)} agents (timed out: {len(pending)})"
        )
        return findings

    def clear(self) -> None:
        """Remove all registered agents."""
        self._agents.clear()
        self._capability_index.clear()
        logger.info("Cleared all agents from event bus")


# Global event bus instance (optional singleton pattern)
_global_event_bus: AgentEventBus | None = None


def get_event_bus() -> AgentEventBus:
    """Get or create the global event bus instance."""
    global _global_event_bus
    if _global_event_bus is None:
        _global_event_bus = AgentEventBus()
    return _global_event_bus


def set_event_bus(bus: AgentEventBus) -> None:
    """Set the global event bus instance."""
    global _global_event_bus
    _global_event_bus = bus


def reset_event_bus() -> None:
    """Reset the global event bus (for testing)."""
    global _global_event_bus
    if _global_event_bus:
        _global_event_bus.clear()
    _global_event_bus = None
