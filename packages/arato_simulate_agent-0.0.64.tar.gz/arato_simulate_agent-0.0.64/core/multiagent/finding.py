"""
Finding dataclass for all evaluation and analysis results.

This module defines the unified Finding class that is used throughout the system:
- Per-turn evaluations (EVALUATE_TURN capability)
- Conversation summaries (SUMMARIZE_CONVERSATION capability)
- Cross-conversation analysis (SUMMARIZE_RUN capability)

The Finding class provides:
- Consistent structure across all evaluation types
- Required agent_id field to track which sub-agent produced the finding
- Automatic label computation from score
- Serialization to dictionary format for JSON output
"""

from dataclasses import dataclass, field
from typing import Any

from constants import (
    DEFAULT_CONFIDENCE_HIGH,
    SCORE_LABEL_CRITICAL,
    SCORE_LABEL_GOOD,
    SCORE_LABEL_WARNING,
    SCORE_THRESHOLD_GOOD,
    SCORE_THRESHOLD_PASS,
    SKIP_SCREENSHOTS_FOR_GOOD_FINDINGS,
)


def score_to_label(score: float) -> str:
    """Convert a score (0-100) to its corresponding label.

    Score ranges (from constants.py):
    - 0-9: Critical (score < SCORE_THRESHOLD_PASS)
    - 10-74: Warning (SCORE_THRESHOLD_PASS <= score < SCORE_THRESHOLD_GOOD)
    - 75-100: Good (score >= SCORE_THRESHOLD_GOOD)

    Args:
        score: Quality score from 0-100

    Returns:
        Label string: 'Critical', 'Warning', or 'Good'
    """
    if score >= SCORE_THRESHOLD_GOOD:
        return SCORE_LABEL_GOOD
    elif score >= SCORE_THRESHOLD_PASS:
        return SCORE_LABEL_WARNING
    else:
        return SCORE_LABEL_CRITICAL


@dataclass
class Finding:
    """A unified finding from any evaluation or analysis.

    Findings are the single output type for all sub-agent capabilities:
    - EVALUATE_TURN: Per-turn findings (quality, compliance, UX checks)
    - SUMMARIZE_CONVERSATION: Conversation-level findings (patterns, issues)
    - SUMMARIZE_RUN: Cross-conversation findings (trends, correlations)

    IMPORTANT: This structure matches summary.json and report_data.json exactly.
    We use 'label' (not 'severity') because findings can be positive (Good) or
    negative (Warning/Critical). The term 'severity' implies only negative findings.

    The label is computed from the score using these thresholds (from constants.py):
    - Score 0-9: Critical
    - Score 10-74: Warning
    - Score 75-100: Good

    For per-turn evaluations, use the create() classmethod for convenience.
    """

    # Required fields - who generated this finding
    agent_id: str  # ID of the sub-agent that produced this finding

    # Required fields - what was evaluated
    category: str  # Category from EVAL_CATEGORIES (e.g., "Security", "User Experience")
    title: str  # Short descriptive title (e.g., "pii-email", "ux-clarity")
    what_was_tested: str  # Description of what was evaluated

    # Required fields - evaluation results
    score: float  # Numerical score (0-100)
    confidence: float  # Confidence score (0-1)
    explanation: str  # Human-readable explanation

    # Auto-computed field (set in __post_init__)
    label: str = field(default="")  # 'Critical', 'Warning', or 'Good'

    # Optional fields for turn-level context
    turn_id: str | None = (
        None  # UUID of the turn for precise matching (source of truth)
    )
    turn_number: int | None = None  # Turn number if from EVALUATE_TURN
    user_message: str | None = None  # User input for this turn
    bot_response: str | None = None  # Chatbot response for this turn

    # Optional fields for additional context
    assessment: str = ""  # Detailed assessment (can be same as explanation)
    impact: str = ""  # Description of impact/validation_details

    # Optional metadata
    skill_name: str | None = None  # Name of skill that produced this result
    screenshot_path: str | None = None  # Path to screenshot evidence
    bounding_box: dict[str, int] | None = (
        None  # UI element coordinates {top, left, bottom, right}
    )
    metadata: dict[str, Any] = field(default_factory=dict)
    # For cross-conversation findings: list of persona_ids that contributed to this pattern
    contributing_sources: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Compute label from score after initialization."""
        if not self.label:
            self.label = score_to_label(self.score)
        if not self.assessment:
            self.assessment = self.explanation

    @classmethod
    def create(
        cls,
        agent_id: str,
        category: str,
        title: str,
        what_was_tested: str,
        score: float,
        explanation: str,
        confidence: float,
        turn_id: str | None = None,
        turn_number: int | None = None,
        user_message: str | None = None,
        bot_response: str | None = None,
        skill_name: str | None = None,
        screenshot_path: str | None = None,
        bounding_box: dict[str, int] | None = None,
        impact: str = "",
        metadata: dict[str, Any] | None = None,
        contributing_sources: list[str] | None = None,
    ) -> "Finding":
        """Factory method to create a Finding with common defaults.

        This is the preferred way to create findings from sub-agents.

        Args:
            agent_id: ID of the sub-agent creating this finding
            category: Category from EVAL_CATEGORIES (e.g., "Security", "User Experience")
            title: Short descriptive title for this finding
            what_was_tested: Description of what was evaluated
            score: Score 0-100
            explanation: Human-readable explanation
            confidence: Confidence score 0-1
            turn_id: UUID of the turn for precise matching (source of truth for turn-level findings)
            turn_number: Turn number if from EVALUATE_TURN
            user_message: User input for this turn
            bot_response: Chatbot response for this turn
            skill_name: Optional skill name
            screenshot_path: Optional path to screenshot evidence
            bounding_box: Optional UI element coordinates {top, left, bottom, right}
            impact: Description of impact (default empty)
            metadata: Additional metadata dict
            contributing_sources: For cross-conversation findings, list of persona IDs

        Returns:
            Finding instance with computed label
        """
        # Skip screenshots for Good findings to reduce noise
        # Good findings don't need visual evidence - we assume the chatbot works well
        effective_screenshot_path = screenshot_path
        if SKIP_SCREENSHOTS_FOR_GOOD_FINDINGS and score >= SCORE_THRESHOLD_GOOD:
            effective_screenshot_path = None

        return cls(
            agent_id=agent_id,
            category=category,
            title=title,
            what_was_tested=what_was_tested,
            score=score,
            confidence=confidence,
            explanation=explanation,
            turn_id=turn_id,
            turn_number=turn_number,
            user_message=user_message,
            bot_response=bot_response,
            impact=impact,
            skill_name=skill_name,
            screenshot_path=effective_screenshot_path,
            bounding_box=bounding_box,
            metadata=metadata or {},
            contributing_sources=contributing_sources or [],
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary matching summary.json structure.

        The output format is designed for report generation and JSON serialization.
        It includes the nested 'evidence' and 'evaluation_results' structure
        expected by the UI.
        """
        result: dict[str, Any] = {
            "agent_id": self.agent_id,
            "category": self.category,
            "title": self.title,
            "what_was_tested": self.what_was_tested,
            "evidence": {
                "turn_id": self.turn_id,
                "turn_number": self.turn_number,
                "agent_input": self.user_message or "",
                "chatbot_response": self.bot_response or "",
            },
            "evaluation_results": {
                "score": self.score,
                "confidence": self.confidence,
                "explanation": self.explanation,
            },
            "assessment": self.assessment,
            "impact": self.impact,
            "label": self.label,
        }
        if self.skill_name:
            result["skill_name"] = self.skill_name
        if self.screenshot_path:
            result["screenshot_path"] = self.screenshot_path
        if self.bounding_box:
            result["bounding_box"] = self.bounding_box
        if self.metadata:
            result["metadata"] = self.metadata
        if self.contributing_sources:
            result["contributing_sources"] = self.contributing_sources
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Finding":
        """Create from dictionary (reverse of to_dict).

        Handles both the nested structure (from summary.json) and flat structure.
        """
        # Handle nested evidence structure
        evidence = data.get("evidence", {})
        turn_id = evidence.get("turn_id") or data.get("turn_id")
        turn_number = evidence.get("turn_number") or data.get("turn_number")
        user_message = evidence.get("agent_input") or data.get("user_message")
        bot_response = evidence.get("chatbot_response") or data.get("bot_response")

        # Handle nested evaluation_results structure
        eval_results = data.get("evaluation_results", {})
        score = eval_results.get("score") or data.get("score", 50)
        confidence = eval_results.get("confidence") or data.get(
            "confidence", DEFAULT_CONFIDENCE_HIGH
        )
        explanation = (
            eval_results.get("explanation")
            or data.get("explanation")
            or data.get("assessment", "")
        )

        return cls(
            agent_id=data.get("agent_id", "unknown"),
            category=data["category"],
            title=data["title"],
            what_was_tested=data.get("what_was_tested", ""),
            score=score,
            confidence=confidence,
            explanation=explanation,
            label=data.get("label", ""),
            turn_id=turn_id,
            turn_number=turn_number,
            user_message=user_message,
            bot_response=bot_response,
            assessment=data.get("assessment", ""),
            impact=data.get("impact", ""),
            skill_name=data.get("skill_name"),
            screenshot_path=data.get("screenshot_path"),
            bounding_box=data.get("bounding_box"),
            metadata=data.get("metadata", {}),
            contributing_sources=data.get("contributing_sources", []),
        )

    @property
    def is_critical(self) -> bool:
        """Check if this is a critical finding."""
        return self.label == SCORE_LABEL_CRITICAL

    @property
    def is_warning(self) -> bool:
        """Check if this is a warning finding."""
        return self.label == SCORE_LABEL_WARNING

    @property
    def is_good(self) -> bool:
        """Check if this is a good/positive finding."""
        return self.label == SCORE_LABEL_GOOD
