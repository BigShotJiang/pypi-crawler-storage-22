"""
ChatRunner integration for the multi-agent system.

This module provides the AgentRegistry for managing sub-agents and
the dispatch functions that integrate with ChatRunner's evaluation flow.
"""

import logging
from typing import Any

from core.multiagent.capabilities import AgentCard
from core.multiagent.context import ConversationContext, EvalContext, RunContext
from core.multiagent.domain_detector import detect_domains_from_context
from core.multiagent.event_bus import AgentEventBus
from core.multiagent.finding import Finding
from core.multiagent.strands_eval_agent import StrandsEvalAgent
from core.multiagent.sub_agent import SubAgent
from utils.token_tracker import TokenUsage

logger = logging.getLogger(__name__)

# Type alias for agents that can be registered (SubAgent or StrandsEvalAgent)
RegisterableAgent = SubAgent | StrandsEvalAgent


class AgentRegistry:
    """Registry for managing sub-agents in the multi-agent system.

    This class provides lifecycle management for sub-agents and
    integrates with the AgentEventBus for dispatching evaluations.

    Usage:
      registry = AgentRegistry()
      registry.register_default_agents()

      # During ChatRunner execution
      results = await registry.evaluate_turn(context)
    """

    def __init__(self) -> None:
        """Initialize the agent registry."""
        self._event_bus = AgentEventBus()
        self._agents: dict[str, RegisterableAgent] = {}

    def _log_agent_card(self, card: AgentCard) -> None:
        """Pretty-print an agent card to the log.

        Args:
          card: The agent card to display
        """
        capability_names = [cap.name for cap in card.capabilities]

        logger.info(
            f"\n{'=' * 60}\n"
            f"Registered Agent: {card.name}\n"
            f"{'=' * 60}\n"
            f"ID:           {card.agent_id}\n"
            f"Version:      {card.version}\n"
            f"Description:  {card.description}\n"
            f"Capabilities: {', '.join(capability_names)}\n"
            f"Tags:         {', '.join(card.tags) if card.tags else 'None'}\n"
            f"{'=' * 60}"
        )

    @property
    def event_bus(self) -> AgentEventBus:
        """Get the event bus."""
        return self._event_bus

    def register(self, agent: RegisterableAgent) -> None:
        """Register a sub-agent.

        Args:
          agent: The sub-agent to register
        """
        self._agents[agent.agent_id] = agent
        self._event_bus.register(agent)
        self._log_agent_card(agent.get_agent_card())

    def unregister(self, agent_id: str) -> None:
        """Unregister a sub-agent.

        Args:
          agent_id: ID of the agent to unregister
        """
        if agent_id in self._agents:
            self._agents.pop(agent_id)
            self._event_bus.unregister(agent_id)
            logger.info(f"Unregistered sub-agent: {agent_id}")

    def get_agent(self, agent_id: str) -> RegisterableAgent | None:
        """Get a registered agent by ID.

        Args:
          agent_id: The agent ID

        Returns:
          The agent or None if not found
        """
        return self._agents.get(agent_id)

    def get_agent_ids(self) -> list[str]:
        """Get list of all registered agent IDs.

        Returns:
          Sorted list of agent IDs
        """
        return sorted(self._agents.keys())

    def get_agent_name_map(self) -> dict[str, str]:
        """Get mapping of agent IDs to human-readable names.

        Returns:
          Dictionary mapping agent_id to display name
        """
        return {agent.agent_id: agent.name for agent in self._agents.values()}

    def get_all_agents(self) -> list[RegisterableAgent]:
        """Get all registered agents.

        Returns:
          List of all registered agents
        """
        return list(self._agents.values())

    def get_agent_cards(self) -> list[AgentCard]:
        """Get AgentCards for all registered agents.

        Returns:
          List of AgentCards
        """
        return [agent.get_agent_card() for agent in self._agents.values()]

    def get_all_token_usage(self) -> list[TokenUsage]:
        """Get aggregated token usage from all registered agents.

        Returns:
          List of all TokenUsage records from all agents
        """
        all_usage: list[TokenUsage] = []
        for agent in self._agents.values():
            all_usage.extend(agent.get_token_usage())
        return all_usage

    def get_total_tokens(self) -> int:
        """Get total tokens used by all agents.

        Returns:
          Total token count across all agents
        """
        return sum(agent.get_total_tokens() for agent in self._agents.values())

    def clear_all_token_usage(self) -> None:
        """Clear token usage records from all agents."""
        for agent in self._agents.values():
            agent.clear_token_usage()
        logger.debug("Cleared token usage from all agents")

    def register_default_agents(self) -> None:
        """Register the default set of sub-agents.

        This registers all core, security, compliance, domain,
        quality, accessibility, and flow agents.
        """
        # Import Strands-based agents (new architecture)
        from agents.eval_agents.accessibility_agent import (
            create_accessibility_agent,
        )
        from agents.eval_agents.analytics_validation_agent import (
            create_analytics_validation_agent,
        )
        from agents.eval_agents.compliance_agent import create_compliance_agent
        from agents.eval_agents.consistency_agent import (
            create_consistency_agent,
        )
        from agents.eval_agents.context_retention_agent import (
            create_context_retention_agent,
        )
        from agents.eval_agents.data_leakage_agent import (
            create_data_leakage_agent,
        )
        from agents.eval_agents.ecommerce_agent import create_ecommerce_agent
        from agents.eval_agents.escalation_agent import create_escalation_agent
        from agents.eval_agents.financial_compliance_agent import (
            create_financial_compliance_agent,
        )
        from agents.eval_agents.goal_completion_agent import (
            create_goal_completion_agent,
        )
        from agents.eval_agents.hallucination_agent import (
            create_hallucination_agent,
        )
        from agents.eval_agents.healthcare_compliance_agent import (
            create_healthcare_compliance_agent,
        )
        from agents.eval_agents.honeycomb_agent import create_honeycomb_agent
        from agents.eval_agents.hr_agent import create_hr_agent
        from agents.eval_agents.insurance_agent import create_insurance_agent
        from agents.eval_agents.jailbreak_detection_agent import (
            create_jailbreak_detection_agent,
        )
        from agents.eval_agents.multilingual_agent import (
            create_multilingual_agent,
        )
        from agents.eval_agents.repetition_agent import create_repetition_agent
        from agents.eval_agents.scope_adherence_agent import (
            create_scope_adherence_agent,
        )
        from agents.eval_agents.tech_support_agent import (
            create_tech_support_agent,
        )
        from agents.eval_agents.travel_agent import create_travel_agent
        from agents.eval_agents.ui_validation_agent import (
            create_ui_validation_agent,
        )
        from agents.eval_agents.ux_agent import create_ux_agent

        # Register Strands-based core agents
        self.register(create_compliance_agent())
        self.register(create_ux_agent())
        self.register(create_hallucination_agent())

        # Register Strands-based security agents
        self.register(create_jailbreak_detection_agent())
        self.register(create_data_leakage_agent())

        # Register Strands-based compliance agents
        self.register(create_financial_compliance_agent())
        self.register(create_healthcare_compliance_agent())
        self.register(create_hr_agent())

        # Register Strands-based domain agents
        self.register(create_ecommerce_agent())
        self.register(create_insurance_agent())
        self.register(create_tech_support_agent())
        self.register(create_travel_agent())

        # Register Strands-based client-specific agents
        self.register(create_honeycomb_agent())

        # Register Strands-based quality agents
        self.register(create_consistency_agent())
        self.register(create_context_retention_agent())

        # Register Strands-based accessibility agents
        self.register(create_accessibility_agent())
        self.register(create_multilingual_agent())

        # Register Strands-based flow agents
        self.register(create_escalation_agent())
        self.register(create_goal_completion_agent())
        self.register(create_repetition_agent())

        # Register Strands-based UI validation agents
        self.register(create_ui_validation_agent())

        # Register Strands-based analytics validation agents
        self.register(create_analytics_validation_agent())

        # Register Strands-based scope adherence agents
        self.register(create_scope_adherence_agent())

        logger.info(f"Registered {len(self._agents)} default agents")

    async def evaluate_turn(
        self,
        user_message: str,
        bot_response: str,
        conversation_id: str,
        turn_number: int,
        turn_id: str = "",
        persona_id: str | None = None,
        target_url: str | None = None,
        app_context: str | None = None,
        conversation_history: list[dict[str, Any]] | None = None,
        ground_truth: list[dict[str, Any]] | None = None,
        test_suite_config: dict[str, Any] | None = None,
        screenshot_path: str | None = None,
        session_dir: str | None = None,
    ) -> list[Finding]:
        """Evaluate a conversation turn using all registered agents.

        This is the main entry point for turn evaluation in ChatRunner.

        Args:
          user_message: The user's message
          bot_response: The chatbot's response
          conversation_id: Unique conversation identifier
          turn_number: Current turn number
          turn_id: UUID of the turn for reliable matching
          persona_id: Optional persona identifier
          target_url: Target URL being tested
          app_context: Application context markdown
          conversation_history: Previous conversation turns
          ground_truth: Ground truth data extracted by skills for validation
          test_suite_config: Test suite configuration with allowed_disclosures
          screenshot_path: Path to screenshot for vision-based validation
          session_dir: Session directory for artifacts

        Returns:
          Aggregated list of Findings from all agents
        """
        context = EvalContext(
            user_message=user_message,
            bot_response=bot_response,
            conversation_id=conversation_id,
            turn_number=turn_number,
            turn_id=turn_id,
            persona_id=persona_id or "",
            target_url=target_url,
            app_context=app_context,
            conversation_history=conversation_history or [],
            ground_truth=ground_truth or [],
            test_suite_config=test_suite_config,
            screenshot_path=screenshot_path,
            session_dir=session_dir or "",
        )

        # Build detected_domains from test_suite_config:
        # 1. domain: vertical domain (e.g., "insurance")
        # 2. custom_agents: explicit agent identifiers (e.g., ["honeycomb"])
        # Fall back to LLM-based detection from app_context if no config
        detected_domains: set[str] = set()

        if test_suite_config:
            # Add vertical domain
            if test_suite_config.get("domain"):
                detected_domains.add(test_suite_config["domain"])

            # Add custom agent identifiers
            custom_agents = test_suite_config.get("custom_agents", [])
            if isinstance(custom_agents, str):
                custom_agents = [custom_agents]
            detected_domains.update(custom_agents)

        # Fall back to LLM detection if no domains from config
        if not detected_domains:
            detected_domains = await detect_domains_from_context(app_context)

        return await self._event_bus.dispatch_evaluate_turn(
            context, detected_domains=detected_domains
        )

    async def summarize_conversation(
        self,
        conversation_id: str,
        persona_id: str | None = None,
        target_url: str | None = None,
        app_context: str | None = None,
        transcript_path: str | None = None,
        total_turns: int = 0,
        transcript_data: list[dict] | None = None,
        test_suite_config: dict[str, Any] | None = None,
    ) -> list[Finding]:
        """Summarize a conversation using all registered agents.

        Called at the end of a ChatRunner conversation.

        Args:
          conversation_id: Unique conversation identifier
          persona_id: Optional persona identifier
          target_url: Target URL that was tested
          app_context: Application context markdown
          transcript_path: Path to the transcript file
          total_turns: Total number of conversation turns
          transcript_data: In-memory transcript data (preferred over file)
          test_suite_config: Test suite configuration with allowed_disclosures

        Returns:
          Aggregated list of Findings from all agents
        """
        context = ConversationContext(
            conversation_id=conversation_id,
            persona_id=persona_id or "",
            target_url=target_url or "",
            app_context=app_context,
            transcript_path=transcript_path or "",
            total_turns=total_turns,
            transcript_data=transcript_data or [],
            test_suite_config=test_suite_config or {},
        )

        # Build detected_domains from test_suite_config
        detected_domains: set[str] = set()

        if test_suite_config:
            if test_suite_config.get("domain"):
                detected_domains.add(test_suite_config["domain"])
            custom_agents = test_suite_config.get("custom_agents", [])
            if isinstance(custom_agents, str):
                custom_agents = [custom_agents]
            detected_domains.update(custom_agents)

        if not detected_domains:
            detected_domains = await detect_domains_from_context(app_context)

        return await self._event_bus.dispatch_summarize_conversation(
            context, detected_domains=detected_domains
        )

    async def summarize_run(
        self,
        run_id: str,
        target_url: str | None = None,
        app_context: str | None = None,
        conversation_ids: list[str] | None = None,
        session_dir: str | None = None,
        all_findings: list[dict[str, Any]] | None = None,
        test_suite_config: dict[str, Any] | None = None,
    ) -> list[Finding]:
        """Cross-conversation analysis using all registered agents.

        Called by the Orchestrator at the end of a multi-persona run.

        Args:
          run_id: Unique run identifier
          target_url: Target URL that was tested
          app_context: Application context markdown
          conversation_ids: List of conversation IDs in this run
          session_dir: Path to the session directory
          all_findings: List of all findings from all conversations (for pattern analysis)
          test_suite_config: Test suite configuration with domain and other config

        Returns:
          Aggregated list of cross-conversation Findings
        """
        logger.info(
            f"summarize_run called with app_context: "
            f"{len(app_context) if app_context else 0} chars, "
            f"all_findings: {len(all_findings) if all_findings else 0}"
        )
        context = RunContext(
            run_id=run_id,
            target_url=target_url or "",
            app_context=app_context,
            conversation_ids=conversation_ids or [],
            session_dir=session_dir or "",
            all_findings=all_findings or [],
            test_suite_config=test_suite_config or {},
        )

        # Build detected_domains from test_suite_config
        detected_domains: set[str] = set()

        if test_suite_config:
            if test_suite_config.get("domain"):
                detected_domains.add(test_suite_config["domain"])
            custom_agents = test_suite_config.get("custom_agents", [])
            if isinstance(custom_agents, str):
                custom_agents = [custom_agents]
            detected_domains.update(custom_agents)

        if not detected_domains:
            detected_domains = await detect_domains_from_context(app_context)

        return await self._event_bus.dispatch_summarize_run(
            context, detected_domains=detected_domains
        )

    def clear_agent_state(self, conversation_id: str | None = None) -> None:
        """Clear internal state from all agents.

        Call this between conversations to reset agent state.

        Args:
          conversation_id: If specified, clear only that conversation's state
        """
        for agent in self._agents.values():
            # Each agent should implement a clear method
            clear_func = getattr(agent, "clear_detections", None)
            if clear_func is not None:
                clear_func(conversation_id)
                continue

            clear_func = getattr(agent, "clear_evaluations", None)
            if clear_func is not None:
                clear_func(conversation_id)

        logger.debug(
            f"Cleared agent state for: {conversation_id or 'all conversations'}"
        )


# Global registry instance for convenience
_global_registry: AgentRegistry | None = None


def get_agent_registry() -> AgentRegistry:
    """Get the global agent registry, creating it if needed.

    Returns:
      The global AgentRegistry instance
    """
    global _global_registry
    if _global_registry is None:
        _global_registry = AgentRegistry()
        _global_registry.register_default_agents()
    return _global_registry


def reset_agent_registry() -> None:
    """Reset the global agent registry.

    Useful for testing or reinitializing agents.
    """
    global _global_registry
    _global_registry = None
