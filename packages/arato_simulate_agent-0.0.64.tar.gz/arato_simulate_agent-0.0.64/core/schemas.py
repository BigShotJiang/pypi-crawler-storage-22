"""All Pydantic model definitions for the Arato Agent project."""

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl, field_validator, model_validator

from constants import (
    DEFAULT_MAX_PARALLEL_PERSONAS,
    DEFAULT_MAX_TURNS,
    DEFAULT_SEED_UTTERANCE,
    DEFAULT_STEP_TIMEOUT,
)

# ID prefixes and status constants for database records
RUN_ID_PREFIX = "run_"
TASK_ID_PREFIX = "task_"
STATUS_PENDING = "PENDING"
STATUS_RUNNING = "RUNNING"
STATUS_COMPLETE = "COMPLETE"
STATUS_FAILED = "FAILED"

# ============================================================================
# Base Event Classes
# ============================================================================


class BaseEvent(BaseModel):
    """Base class for all queue events."""

    org_id: str = Field(..., description="Organization ID for multi-tenancy")

    @field_validator("org_id")
    @classmethod
    def validate_org_id(cls, v: str) -> str:
        """Validate org_id is not empty."""
        if not v:
            raise ValueError("org_id is required for all operations")
        return v

    model_config = {"extra": "forbid"}


class TimestampedEvent(BaseEvent):
    """Event with automatic timestamp."""

    timestamp: str = Field(
        default_factory=lambda: datetime.now(UTC).isoformat(),
        description="ISO timestamp when event was created",
    )

    model_config = {"extra": "forbid"}


# ============================================================================
# Task-related Models (from polling/validation.py)
# ============================================================================


class TaskGoal(StrEnum):
    """Task execution goal options."""

    DISCOVER = "discover"  # Run only app context discovery
    CHAT = "chat"  # Run discovery + chat runner (default)
    GROUND_TRUTH = "ground_truth"  # Run only ground truth agent


class TaskPayload(BaseModel):
    """Validated task payload schema."""

    task_id: str | None = Field(
        None, description="Unique task identifier from ARATO API"
    )
    target_url: HttpUrl = Field(..., description="URL to test")
    goal: TaskGoal = Field(
        TaskGoal.CHAT,
        description="Execution goal: 'discover', 'ground_truth', or 'chat' (default)",
    )
    persona_ids: list[str] | None = Field(
        None, description="List of persona IDs with optional multipliers"
    )
    exclude_persona_ids: list[str] | None = Field(
        None,
        description="List of persona IDs or glob patterns to exclude from execution",
    )
    max_turns: int = Field(
        DEFAULT_MAX_TURNS, ge=1, le=100, description="Max conversation turns"
    )
    seed_utterance: str = Field(DEFAULT_SEED_UTTERANCE, description="Initial message")
    max_parallel: int = Field(
        DEFAULT_MAX_PARALLEL_PERSONAS, ge=1, le=200, description="Max parallel personas"
    )
    step_timeout: int = Field(
        DEFAULT_STEP_TIMEOUT,
        ge=10,
        le=300,
        description="Timeout per agent step in seconds",
    )
    storage_state: str | None = Field(
        None, description="Path to JSON file with saved authentication state"
    )
    org_id: str | None = Field(None, description="Organization ID")
    arato_api_url: str | None = Field(None, description="Override logging URL")
    arato_api_key: str | None = Field(None, description="Override API key")
    receipt_handle: str | None = Field(
        None,
        alias="_receipt_handle",
        description="Receipt handle for task acknowledgment/deletion",
    )
    broadcast_identity: bool = Field(
        False,
        description="If True, send 'arato_agent/<task_id>' as the first message",
    )
    force_discovery: bool = Field(
        False,
        description="If True, ignore cached app context and rediscover from scratch",
    )
    force_ground_truth: bool = Field(
        False,
        description="If True, ignore cached ground truth and re-collect from scratch",
    )
    session_prefix: str | None = Field(
        None,
        description="Prefix to prepend to auto-generated conversation session directory names (not applied to discovery sessions)",
    )
    include_eu_ai_act_report: bool = Field(
        False,
        description="Whether to include EU AI Act compliance assessment (default: False)",
    )
    domain: str | None = Field(
        None,
        description="Domain for test suite configuration",
    )
    test_suite_id: str | None = Field(
        None,
        description="Test suite identifier to load configuration from (e.g., 'hibob', 'kayak')",
    )
    target_urls: list[str] | None = Field(
        None,
        description="List of target URLs for multi-URL testing",
    )

    @field_validator("target_url")
    @classmethod
    def validate_url_scheme(cls, v: HttpUrl) -> HttpUrl:
        """Ensure URL uses http or https."""
        if v.scheme not in ["http", "https"]:
            raise ValueError("URL must use http or https scheme")
        return v

    @field_validator("persona_ids")
    @classmethod
    def validate_persona_ids(cls, v: list[str] | None) -> list[str] | None:
        """Validate persona ID format."""
        if v:
            for persona_spec in v:
                # Check format: "persona_name" or "persona_name:count"
                if ":" in persona_spec:
                    parts = persona_spec.split(":")
                    if len(parts) != 2:
                        raise ValueError(f"Invalid persona format: {persona_spec}")
                    try:
                        count = int(parts[1])
                        if count < 1:
                            raise ValueError(f"Count must be >= 1: {persona_spec}")
                    except ValueError as e:
                        raise ValueError(
                            f"Invalid count in persona: {persona_spec}"
                        ) from e
        return v

    model_config = {
        "extra": "forbid",
        "populate_by_name": True,
    }  # Reject unknown fields, allow alias or field name


class TaskStatus(StrEnum):
    """Allowed lifecycle statuses a task can transition through."""

    ACTIVE = "active"
    WAIT = "wait"
    COMPLETE = "complete"


class AgentCommand(StrEnum):
    """Agent command enum for task execution control.

    Attributes:
        CONTINUE: Agent should continue processing tasks
        STOP: Agent should stop processing (task not found or invalid)
    """

    CONTINUE = "continue"
    STOP = "stop"


class ItemStatus(StrEnum):
    """Status values for ReportRun and Task items."""

    PENDING = STATUS_PENDING
    RUNNING = STATUS_RUNNING
    COMPLETE = STATUS_COMPLETE
    FAILED = STATUS_FAILED


class TaskType(StrEnum):
    """Task type enum for different kinds of tasks."""

    CONVERSATION = "CONVERSATION"
    SUMMARY = "SUMMARY"
    DISCOVERY = "DISCOVERY"


class TranscriptTurn(BaseModel):
    """Single conversation turn captured in a result transcript."""

    role: str = Field(..., description="Actor role, e.g. 'user' or 'assistant'")
    text: str = Field(..., description="Utterance text")

    model_config = {"extra": "forbid"}


class ArtifactsInfo(BaseModel):
    """Information about uploaded artifacts."""

    storage_url: str | None = Field(
        None,
        description="Storage URL for artifacts (S3, local filesystem, etc.)",
    )
    files: list[str] | None = Field(None, description="List of uploaded files")
    total_size: int | None = Field(None, description="Total size in bytes")

    model_config = {"extra": "allow"}


class AgentIdentity(BaseModel):
    """Information about the agent executing the task."""

    name: str | None = Field(None, description="Agent name or identifier")
    platform: str | None = Field(None, description="Platform or runtime environment")

    model_config = {"extra": "allow"}


class HITLInterventionInfo(BaseModel):
    """HITL intervention details for a persona waiting on human assistance."""

    intervention_id: str = Field(..., description="Unique intervention identifier")
    reason: str = Field(..., description="Human-readable reason for intervention")
    intervention_type: str = Field(
        ..., description="Type of intervention (captcha, login, etc.)"
    )
    requested_at: str = Field(
        ..., description="ISO timestamp when intervention was requested"
    )
    timeout_seconds: int = Field(..., description="Maximum wait time in seconds")
    url_before: str | None = Field(None, description="URL before intervention started")
    screenshot_url: str | None = Field(
        None, description="S3 URL of screenshot at intervention time"
    )
    state: str = Field(
        ..., description="Current state: waiting, completed, timeout, error"
    )

    model_config = {"extra": "allow"}


class PersonaResult(BaseModel):
    """Result for a single persona execution."""

    target_url: str | None = Field(None, description="Target URL for this persona")
    transcript: list[dict[str, Any]] | None = Field(
        None, description="Conversation transcript for this persona"
    )
    total_turns: int | None = Field(None, description="Total turns for this persona")
    error: str | None = Field(None, description="Error if persona failed")

    model_config = {"extra": "forbid"}


class PersonaProgressInfo(BaseModel):
    """Per-persona progress information from ProgressTracker."""

    persona_id: str | None = Field(None, description="Base persona identifier")
    instance_name: str | None = Field(None, description="Unique instance name")
    status: str | None = Field(
        None, description="Current status: pending, running, completed, failed, stopped"
    )
    current_step: int | None = Field(None, description="Current execution step")
    total_steps: int | None = Field(None, description="Total expected steps")
    completion_percentage: float | None = Field(
        None, description="Progress completion percentage (0-100)"
    )
    transcript_turns: int | None = Field(
        None, description="Number of conversation turns completed"
    )
    last_action: str | None = Field(None, description="Description of last action")
    started_at: str | None = Field(None, description="ISO timestamp when started")
    updated_at: str | None = Field(None, description="ISO timestamp of last update")
    completed_at: str | None = Field(None, description="ISO timestamp when completed")
    finish_reason: str | None = Field(
        None,
        description="Reason for completion: reached_max_turns, agent_stopped, timeout, error, unknown",
    )
    error: str | None = Field(None, description="Error message if failed")

    # HITL intervention tracking
    hitl_intervention: HITLInterventionInfo | None = Field(
        None,
        description="HITL intervention details if persona is waiting for human intervention",
    )

    # Artifact paths
    persona_video: str | None = Field(
        None, description="Relative path to persona run video file"
    )
    transcript_json: str | None = Field(
        None, description="Relative path to persona - chat transcript"
    )
    summary_json: str | None = Field(
        None, description="Relative path to persona - summary file"
    )

    model_config = {"extra": "allow"}


class AppDiscoveryProgressInfo(BaseModel):
    """App context discovery progress information."""

    status: str | None = Field(
        None, description="Current status: pending, running, completed, failed"
    )
    current_step: int | None = Field(None, description="Current step number")
    total_steps: int | None = Field(None, description="Total expected steps")
    last_action: str | None = Field(None, description="Description of last action")
    started_at: str | None = Field(None, description="ISO timestamp when started")
    completed_at: str | None = Field(None, description="ISO timestamp when completed")
    error: str | None = Field(None, description="Error message if failed")
    app_context_json: str | None = Field(
        None, description="Discovered application context JSON"
    )
    screenshots: list[str] | None = Field(
        None, description="List of screenshot filenames captured during discovery"
    )
    discovery_video: str | None = Field(
        None, description="Relative path to discovery video file"
    )

    model_config = {"extra": "allow"}


class OrchestratorProgressInfo(BaseModel):
    """Orchestrator-level progress information from ProgressTracker."""

    phase: str | None = Field(
        None,
        description="Current execution phase: initializing, discovery, running_personas, generating_summary, uploading_artifacts, complete",
    )
    total_personas: int | None = Field(
        None, description="Total number of persona instances"
    )
    completed_personas: int | None = Field(
        None, description="Number of personas completed"
    )
    failed_personas: int | None = Field(None, description="Number of personas failed")
    last_action: str | None = Field(
        None, description="Description of last orchestrator action"
    )
    started_at: str | None = Field(None, description="ISO timestamp when started")
    completed_at: str | None = Field(None, description="ISO timestamp when completed")
    goal: str | None = Field(None, description="Execution mode: discover or chat")
    app_context_cached: bool | None = Field(
        None, description="Whether app context was loaded from cache"
    )
    personas: dict[str, int] | None = Field(
        None, description="Map of persona_id to instance count"
    )
    run_summary_json: str | None = Field(
        None, description="Relative path to consolidated summary JSON file"
    )

    model_config = {"extra": "allow"}


class ProgressSnapshot(BaseModel):
    """Snapshot of execution progress from ProgressTracker."""

    orchestrator: OrchestratorProgressInfo | None = Field(
        None, description="Orchestrator-level progress"
    )
    app_discovery: AppDiscoveryProgressInfo | None = Field(
        None, description="App context discovery progress"
    )
    personas: dict[str, PersonaProgressInfo] | None = Field(
        None, description="Per-persona progress keyed by instance_name"
    )
    updated_at: str | None = Field(
        None, description="ISO timestamp of last progress update"
    )

    model_config = {"extra": "allow"}


class TaskResult(BaseModel):
    """
    Result structure for agent task execution.
    All fields are optional to support partial updates.
    Supports both single-persona and multi-persona execution results.
    """

    status: TaskStatus | None = Field(
        default=TaskStatus.COMPLETE, description="Task execution status"
    )
    session_id: str | None = Field(
        default=None, description="Unique session identifier"
    )
    target_url: str | None = Field(default=None, description="Target URL for the task")

    # Single persona results (used when persona_ids is None or has 1 item)
    transcript: list[TranscriptTurn] | None = Field(
        default=None, description="Conversation transcript for single persona"
    )
    total_turns: int | None = Field(
        default=None, description="Total conversation turns for single persona"
    )

    # Multi-persona results (used when persona_ids has multiple items)
    personas_run: int | None = Field(
        default=None, description="Number of personas that ran"
    )
    results: dict[str, PersonaResult] | None = Field(
        default=None, description="Results per persona (key: persona_instance_name)"
    )

    # Common fields
    app_context: str | None = Field(
        default=None, description="Application context discovery report"
    )
    output_dir: str | None = Field(
        default=None, description="Directory containing artifacts"
    )
    artifacts: ArtifactsInfo | None = Field(
        default=None, description="Information about uploaded S3 artifacts"
    )
    agent_identity: AgentIdentity | None = Field(
        default=None, description="Information about the agent executing the task"
    )

    # Error tracking
    error: str | None = Field(default=None, description="Error message if task failed")
    error_details: dict[str, Any] | None = Field(
        default=None, description="Additional error context"
    )

    # Detailed progress tracking from ProgressTracker
    progress: ProgressSnapshot | None = Field(
        default=None,
        description="Detailed progress snapshot including orchestrator and persona states",
    )

    # Report data (generated report JSON to be stored server-side)
    report_data: dict[str, Any] | None = Field(
        default=None,
        description="Full report data JSON to be stored by the server",
    )

    model_config = {"extra": "allow"}  # allow forward compatible fields


class TaskUpdate(BaseModel):
    """Outgoing update request body for /task POST operations."""

    task_id: str = Field(..., description="Unique task identifier")
    status: TaskStatus = Field(..., description="New task status")
    receipt_handle: str | None = Field(
        None,
        alias="_receipt_handle",
        description="SQS receipt handle for acknowledgment/deletion",
    )
    result: TaskResult | None = Field(
        None, description="Optional execution result when completing"
    )

    model_config = {
        "extra": "forbid",
        "populate_by_name": True,
    }

    @model_validator(mode="after")
    def validate_result_status(self) -> "TaskUpdate":
        """Validate that result.status matches update.status."""
        if self.result and self.result.status != self.status:
            raise ValueError(
                f"TaskResult.status ({self.result.status}) must match TaskUpdate.status ({self.status})"
            )
        return self


class AgentCommandResponse(BaseModel):
    """Response structure for agent task update operations.

    Attributes:
        command: Instruction for agent on how to proceed
        task_id: Task identifier
        message: Optional human-readable message
    """

    command: AgentCommand = Field(
        ..., description="Command for agent execution control"
    )
    task_id: str = Field(..., description="Task identifier")
    message: str | None = Field(None, description="Human-readable message")

    model_config = {"extra": "allow"}


# ============================================================================
# Job Event Models (from models/events/jobs.py)
# ============================================================================


class ConversationWorkerEvent(BaseEvent):
    """Message schema for conversation execution jobs."""

    org_id: str = Field(..., description="Organization ID for multi-tenancy")
    task_id: str | None = Field(None, description="Optional task identifier")
    job_type: str = Field("persona_conversation", description="Type of job")
    status: str = Field(
        ..., description="Job status: queued, started, completed, failed"
    )
    session_id: str = Field(..., description="Session identifier")
    run_id: str | None = Field(None, description="Unique run identifier")
    conversation_id: str | None = Field(
        None, description="Unique conversation identifier"
    )
    persona_id: str = Field(..., description="Persona identifier")
    persona_instance_name: str = Field(..., description="Unique persona instance name")
    target_url: str = Field(..., description="Target URL for conversation")
    max_turns: int | None = Field(None, description="Maximum conversation turns")
    seed_utterance: str | None = Field(
        None, description="Initial message to start conversation"
    )
    app_context_s3_path: str | None = Field(
        None, description="S3 path to app context file"
    )
    queued_at: str = Field(
        default_factory=lambda: datetime.now(UTC).isoformat(),
        description="ISO timestamp when job was queued",
    )
    source: str = Field("orchestrator", description="Source of the job message")

    model_config = {"extra": "forbid"}


# ============================================================================
# Update Event Models (from models/events/updates.py)
# ============================================================================


class UpdateType(StrEnum):
    """Types of update events."""

    TURN_UPDATE = "turn_update"
    COMPLETE = "complete"
    FAILED = "failed"


class UpdateEvent(TimestampedEvent):
    """Message schema for progress updates."""

    run_id: str = Field(..., description="Unique run identifier")
    conversation_id: str = Field(..., description="Unique conversation identifier")
    event_type: str = Field(
        ..., description="Type of update event: turn_update | complete | failed"
    )
    data: dict[str, Any] = Field(
        default_factory=dict, description="Event-specific payload"
    )

    model_config = {"extra": "forbid"}


class TurnUpdate(UpdateEvent):
    """Specific schema for turn updates."""

    event_type: str = Field(
        default=UpdateType.TURN_UPDATE.value, description="Turn update event type"
    )

    model_config = {"extra": "forbid"}


class CompletionEvent(UpdateEvent):
    """Specific schema for completion."""

    event_type: str = Field(
        default=UpdateType.COMPLETE.value, description="Completion event type"
    )

    model_config = {"extra": "forbid"}


class FailureEvent(UpdateEvent):
    """Specific schema for failures."""

    event_type: str = Field(
        default=UpdateType.FAILED.value, description="Failure event type"
    )

    model_config = {"extra": "forbid"}


# ============================================================================
# Database Models (from models/events/database.py)
# ============================================================================


class RunItemData(BaseModel):
    """Data stored in ReportRun.item_data field.

    This schema mirrors TaskPayload to store execution parameters,
    with additional orchestration-specific fields (session_id, num_personas).
    """

    # Core execution parameters (from TaskPayload)
    target_url: str = Field(..., description="Target URL being tested")
    task_id: str | None = Field(None, description="Optional task identifier")
    goal: str | None = Field(None, description="Execution goal: discover or chat")
    persona_ids: list[str] | None = Field(
        None, description="List of persona IDs with optional multipliers"
    )
    exclude_persona_ids: list[str] | None = Field(
        None,
        description="List of persona IDs or glob patterns to exclude from execution",
    )
    max_turns: int | None = Field(None, description="Maximum conversation turns")
    seed_utterance: str | None = Field(None, description="Initial message")
    max_parallel: int | None = Field(None, description="Max parallel personas")
    step_timeout: int | None = Field(
        None, description="Timeout per agent step in seconds"
    )
    storage_state: str | None = Field(
        None, description="Path to JSON file with saved authentication state"
    )
    arato_api_url: str | None = Field(None, description="Override logging URL")
    arato_api_key: str | None = Field(None, description="Override API key")
    broadcast_identity: bool | None = Field(
        None,
        description="If True, send 'arato_agent/<task_id>' as the first message",
    )
    force_discovery: bool | None = Field(
        None,
        description="If True, ignore cached app context and rediscover from scratch",
    )
    session_prefix: str | None = Field(
        None,
        description="Prefix to prepend to auto-generated conversation session directory names",
    )
    include_eu_ai_act_report: bool | None = Field(
        None,
        description="Whether to include EU AI Act compliance assessment",
    )

    # Orchestration-specific fields (not in TaskPayload)
    session_id: str | None = Field(None, description="Session identifier")
    num_personas: int | None = Field(
        None, description="Number of persona instances (computed from persona_ids)"
    )

    model_config = {
        "extra": "allow"
    }  # Allow additional fields for forward compatibility


class ConversationItemData(BaseModel):
    """Data stored in Task.item_data field for conversation tasks."""

    task_type: TaskType = Field(
        TaskType.CONVERSATION,
        description="Task type (always CONVERSATION for this data type)",
    )
    persona_id: str = Field(..., description="Persona identifier")
    persona_instance_name: str = Field(..., description="Unique persona instance name")
    max_turns: int | None = Field(None, description="Maximum conversation turns")
    completed_steps: int = Field(
        0, description="Number of steps completed in conversation execution"
    )

    model_config = {
        "extra": "allow"
    }  # Allow additional fields for forward compatibility


class ReportRun(BaseModel):
    """Schema for report run database records.

    Note: run_id should start with RUN_ID_PREFIX ('run_')
    """

    org_id: str = Field(..., description="Organization ID")
    run_id: str = Field(
        ..., description="Unique run identifier (must start with 'run_' prefix)"
    )
    item_status: ItemStatus = Field(
        ItemStatus.PENDING, description="Status: PENDING | RUNNING | COMPLETE | FAILED"
    )
    created_by: str = Field(..., description="User who created the run")
    created_at: str = Field(..., description="ISO timestamp when run was created")
    updated_at: str = Field(..., description="ISO timestamp when run was last updated")
    item_data: RunItemData = Field(..., description="Run-specific data")

    @field_validator("run_id")
    @classmethod
    def validate_run_id_prefix(cls, v: str) -> str:
        """Validate run_id has correct prefix."""
        if not v.startswith(RUN_ID_PREFIX):
            raise ValueError(f"run_id must start with {RUN_ID_PREFIX}, got: {v}")
        return v

    model_config = {"extra": "forbid"}

    def to_dynamodb_item(self) -> dict[str, Any]:
        """Convert to DynamoDB item format."""
        return {
            "PK": self.org_id,
            "SK": self.run_id,
            "id": self.run_id,
            "item_status": self.item_status,
            "created_by": self.created_by,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "item_data": self.item_data.model_dump()
            if isinstance(self.item_data, BaseModel)
            else self.item_data,
        }


class Task(BaseModel):
    """Schema for task database records.

    Note: run_id should start with RUN_ID_PREFIX ('run_')
          task_id should start with TASK_ID_PREFIX ('task_')
    """

    org_id: str = Field(..., description="Organization ID")
    run_id: str = Field(
        ..., description="Unique run identifier (must start with 'run_' prefix)"
    )
    task_id: str = Field(
        ...,
        description="Unique task identifier (must start with 'task_' prefix)",
    )
    item_status: ItemStatus = Field(ItemStatus.PENDING, description="Task status")
    created_by: str = Field(..., description="User who created the task")
    created_at: str = Field(..., description="ISO timestamp when task was created")
    updated_at: str = Field(..., description="ISO timestamp when task was last updated")
    item_data: ConversationItemData = Field(
        ..., description="Task-specific data (type varies by task_type)"
    )

    @field_validator("run_id")
    @classmethod
    def validate_run_id_prefix(cls, v: str) -> str:
        """Validate run_id has correct prefix."""
        if not v.startswith(RUN_ID_PREFIX):
            raise ValueError(f"run_id must start with {RUN_ID_PREFIX}, got: {v}")
        return v

    @field_validator("task_id")
    @classmethod
    def validate_task_id_prefix(cls, v: str) -> str:
        """Validate task_id has correct prefix."""
        if not v.startswith(TASK_ID_PREFIX):
            raise ValueError(f"task_id must start with {TASK_ID_PREFIX}, got: {v}")
        return v

    model_config = {"extra": "forbid"}

    def to_dynamodb_item(self) -> dict[str, Any]:
        """Convert to DynamoDB item format."""
        return {
            "PK": self.org_id,
            "SK": f"{self.run_id}/{self.task_id}",
            "id": self.task_id,
            "item_status": self.item_status,
            "created_by": self.created_by,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "item_data": self.item_data.model_dump()
            if isinstance(self.item_data, BaseModel)
            else self.item_data,
        }


class Conversation(Task):
    """Conversation is a specific type of Task with task_type=CONVERSATION.

    This class provides a semantic alias for conversation tasks while maintaining
    the same database schema as Task. Use this when working with conversation-specific
    logic in the application layer.
    """

    @field_validator("item_data")
    @classmethod
    def validate_conversation_type(
        cls, v: ConversationItemData
    ) -> ConversationItemData:
        """Ensure item_data has task_type=CONVERSATION."""
        if isinstance(v, ConversationItemData) and v.task_type != TaskType.CONVERSATION:
            raise ValueError(
                f"Conversation task must have task_type=CONVERSATION, got {v.task_type}"
            )
        return v


# ============================================================================
# Validation Functions
# ============================================================================


def validate_task(task: dict[str, Any]) -> TaskPayload:
    """
    Validate task payload and return typed object.

    Args:
        task: Raw task dictionary

    Returns:
        Validated TaskPayload object

    Raises:
        ValidationError: If task is invalid
    """
    return TaskPayload(**task)


def build_task_update(update: dict[str, Any]) -> TaskUpdate:
    """Validate & build TaskUpdate from raw dict."""
    return TaskUpdate(**update)


# Export all public classes and enums
__all__ = [
    # Base classes
    "BaseEvent",
    "TimestampedEvent",
    # Task-related
    "TaskGoal",
    "TaskPayload",
    "TaskStatus",
    "TaskResult",
    "TaskUpdate",
    # Agent-related
    "AgentCommand",
    "AgentCommandResponse",
    "AgentIdentity",
    "ItemStatus",
    # Progress tracking
    "TranscriptTurn",
    "ArtifactsInfo",
    "PersonaResult",
    "PersonaProgressInfo",
    "AppDiscoveryProgressInfo",
    "OrchestratorProgressInfo",
    "ProgressSnapshot",
    # HITL
    "HITLInterventionInfo",
    # Jobs and events
    "ConversationWorkerEvent",
    "UpdateType",
    "UpdateEvent",
    "TurnUpdate",
    "CompletionEvent",
    "FailureEvent",
    # Database models
    "ReportRun",
    "Task",
    "Conversation",
    "TaskType",
    "RunItemData",
    "ConversationItemData",
]
