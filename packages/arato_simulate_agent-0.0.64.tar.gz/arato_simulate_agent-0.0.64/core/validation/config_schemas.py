"""
Pydantic schemas for validating YAML configuration files.

These schemas enforce structure and required fields for all config types
in the config/ directory. Validation runs at load time to fail fast on
misconfigured files.
"""

from typing import Any

from pydantic import BaseModel, Field, field_validator


class DomainSchema(BaseModel):
    """Schema for domain configuration files (config/domains/*/domain.yaml)."""

    id: str
    name: str
    description: str
    sub_agent: str | None = None
    key_concepts: list[str | dict[str, str]] = Field(default_factory=list)
    workflows: dict[str, Any] | list[str] = Field(default_factory=dict)
    regulations: list[str | dict[str, str]] = Field(default_factory=list)
    evaluation_focus: list[str] = Field(default_factory=list)
    example_applications: list[str] = Field(default_factory=list)

    model_config = {"extra": "forbid"}


class ScenarioSchema(BaseModel):
    """Schema for scenario configuration files (config/domains/*/<scenario>.yaml)."""

    id: str
    name: str
    description: str
    goals: list[str] = Field(default_factory=list)
    sample_interactions: dict[str, Any] = Field(default_factory=dict)
    success_criteria: list[str] = Field(default_factory=list)

    model_config = {"extra": "ignore"}


class RoleSchema(BaseModel):
    """Schema for role configuration files (config/roles/*.yaml)."""

    id: str
    name: str
    description: str
    permissions: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    behavioral_traits: list[str] = Field(default_factory=list)
    applicable_domains: list[str] = Field(default_factory=list)
    # Optional enrichment fields
    assistant_guidance: list[str] = Field(default_factory=list)
    context: str = ""

    model_config = {"extra": "ignore"}


class PersonaSchema(BaseModel):
    """Schema for persona configuration files (config/personas/*.yaml)."""

    id: str
    name: str
    description: str
    language: str = "en"
    location: str = "Global"
    traits: list[str] = Field(default_factory=list)
    conversation_style: list[str] = Field(default_factory=list)
    risk_level: str = "medium"
    risk_description: str = ""
    attack_vectors: list[str] = Field(default_factory=list)
    compliance_focus: list[str] = Field(default_factory=list)
    github_resources: list[dict[str, str]] = Field(default_factory=list)

    model_config = {"extra": "ignore"}


class GroundTruthAgentConfigSchema(BaseModel):
    """Schema for ground truth agent configs (config/ground_truth_agents/*.yaml)."""

    id: str
    name: str
    description: str
    target_urls: list[str] = Field(default_factory=list)
    timeout: int = 900
    max_steps: int = 100
    data_collection: list[dict[str, Any]] = Field(default_factory=list)
    task_instructions: str = ""

    model_config = {"extra": "forbid"}


class QuestionToAnswer(BaseModel):
    """Schema for a question_to_answer entry."""

    id: str = ""
    question: str
    description: str = ""
    priority: str = "medium"

    model_config = {"extra": "forbid"}

    @field_validator("priority")
    @classmethod
    def validate_priority(cls, v: str) -> str:
        allowed = {"critical", "high", "medium", "low"}
        if v not in allowed:
            msg = f"priority must be one of {allowed}, got '{v}'"
            raise ValueError(msg)
        return v


class KeyRisk(BaseModel):
    """Schema for a key_risk entry."""

    id: str = ""
    name: str = ""
    description: str = ""
    priority: str = "medium"

    model_config = {"extra": "forbid"}

    @field_validator("priority")
    @classmethod
    def validate_priority(cls, v: str) -> str:
        allowed = {"critical", "high", "medium", "low"}
        if v not in allowed:
            msg = f"priority must be one of {allowed}, got '{v}'"
            raise ValueError(msg)
        return v


class TestCaseSchema(BaseModel):
    """Schema for individual test case entries within a test suite."""

    id: str
    name: str
    description: str
    persona: str
    role: str
    scenarios: list[str] = Field(default_factory=list)
    max_turns: int = 10
    locale: str = "en_US"

    model_config = {"extra": "forbid"}


class TestSuiteSchema(BaseModel):
    """Schema for test suite configuration files (config/test_suites/*.yaml)."""

    name: str
    application: str
    domain: str
    target_urls: list[str]
    application_context: str
    tests: list[TestCaseSchema]
    # Structured evaluation config — required for all suites
    questions_to_answer: list[QuestionToAnswer | str]
    key_risks: list[KeyRisk | str]
    compliance_requirements: dict[str, list[str]]
    # Optional fields
    admin_only_fields: dict[str, list[str]] = Field(default_factory=dict)
    allowed_disclosures: list[str] = Field(default_factory=list)
    allowed_behaviors: list[str] = Field(default_factory=list)
    custom_agents: list[str] = Field(default_factory=list)
    ground_truth_agent: str | None = None

    model_config = {"extra": "forbid"}


def validate_config(
    data: dict[str, Any], schema: type[BaseModel], filepath: str
) -> None:
    """Validate a YAML config dict against a Pydantic schema.

    Args:
      data: Raw YAML data dict
      schema: Pydantic schema class to validate against
      filepath: Path to the config file (for error messages)

    Raises:
      SystemExit: If validation fails, with a descriptive error message
    """
    try:
        schema.model_validate(data)
    except Exception as e:
        raise SystemExit(
            f"\n{'=' * 60}\n"
            f"CONFIG VALIDATION ERROR\n"
            f"{'=' * 60}\n"
            f"File: {filepath}\n"
            f"Schema: {schema.__name__}\n\n"
            f"{e}\n"
            f"{'=' * 60}\n"
            f"Fix the configuration file and try again.\n"
        ) from None
