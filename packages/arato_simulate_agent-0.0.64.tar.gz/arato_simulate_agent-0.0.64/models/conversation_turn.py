"""
Data model for conversation tracking.
"""

import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ConversationTurn:
    """Represents a single turn in the conversation."""

    role: str  # "user" or "assistant"
    text: str
    id: str = field(
        default_factory=lambda: str(uuid.uuid4())
    )  # Unique identifier for this turn
    turn_number: int | None = (
        None  # Sequential turn number (1, 2, 3...), 0 for welcome message
    )
    timestamp: str | None = (
        None  # ISO 8601 timestamp (e.g., "2025-11-17T14:00:00.000Z")
    )
    evals: list[dict[str, Any]] | None = None  # Evaluation results for this turn
    screenshot: str | None = None  # Screenshot filename (e.g., "screenshot_001.png")
    measurements: dict[str, Any] | None = (
        None  # Performance measurements (latency, etc.)
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "role": self.role,
            "text": self.text,
            "turn_number": self.turn_number,
            "timestamp": self.timestamp,
            "evals": self.evals,
            "screenshot": self.screenshot,
            "measurements": self.measurements,
        }


def calculate_turn_count(transcript: list[ConversationTurn]) -> int:
    """
    Calculate the number of completed conversation turns.

    A turn is a user message + assistant response pair.
    Welcome messages (turn_number=0, assistant-only) are not counted as turns.

    Args:
        transcript: List of conversation turns

    Returns:
        Number of completed user+assistant turn pairs
    """
    if not transcript:
        return 0

    # Check if first message is a welcome message (turn 0, assistant-only)
    has_welcome = transcript[0].turn_number == 0

    # Calculate turns: (total messages - welcome offset) / 2
    welcome_offset = 1 if has_welcome else 0
    return (len(transcript) - welcome_offset) // 2


def has_welcome_message(transcript: list[ConversationTurn]) -> bool:
    """
    Check if the transcript starts with a welcome message.

    Args:
        transcript: List of conversation turns

    Returns:
        True if the first turn is a welcome message (turn_number=0)
    """
    return bool(transcript) and transcript[0].turn_number == 0


def calculate_turn_count_from_raw(transcript: list[dict]) -> int:
    """
    Calculate the number of completed conversation turns from raw transcript data.

    This function works with transcript data loaded from JSON files (list of dicts)
    rather than ConversationTurn objects.

    A turn is a user message + assistant response pair.
    Welcome messages (turn_number=0, assistant-only) are not counted as turns.

    Args:
        transcript: List of transcript entries as dictionaries with 'turn_number' key

    Returns:
        Number of completed user+assistant turn pairs
    """
    if not transcript:
        return 0

    # Check if first message is a welcome message (turn 0, assistant-only)
    first_entry = transcript[0]
    has_welcome = first_entry.get("turn_number") == 0

    # Calculate turns: (total messages - welcome offset) / 2
    welcome_offset = 1 if has_welcome else 0
    return (len(transcript) - welcome_offset) // 2
