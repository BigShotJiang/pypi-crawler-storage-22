"""Constants specific to AWS AgentCore platform."""

DEFAULT_AWS_REGION = "us-east-1"
DEFAULT_AGENTCORE_RETRY_CONFIG = {"max_attempts": 5, "mode": "adaptive"}

# AgentCore MicroVMs have 2 vCPU / 8GB RAM with remote browsers,
# so we can safely run more parallel personas than local (which defaults to 4).
# This can be overridden to 100+ via the payload's max_parallel field.
AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS = 100
