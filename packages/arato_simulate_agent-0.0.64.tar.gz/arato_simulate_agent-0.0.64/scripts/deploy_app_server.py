#!/usr/bin/env python3
"""Deploy app server infrastructure to AWS ECS/Fargate + Aurora PostgreSQL.

This script manages CloudFormation-based deployment of:
- ECS Cluster + Fargate Service
- Application Load Balancer
- Aurora PostgreSQL Serverless v2
- ECR Repository
- IAM roles and security groups
"""

import argparse
import logging
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

DEFAULT_STACK_NAME = "arato-app-server"
DEFAULT_REGION = "us-east-1"


def load_template() -> str:
    """Load CloudFormation template."""
    template_path = (
        Path(__file__).resolve().parent / "templates" / "app_server_infrastructure.yaml"
    )
    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")
    return template_path.read_text()


def get_default_vpc(region: str) -> tuple[str, list[str]]:
    """Auto-detect default VPC and subnets.

    Returns:
        Tuple of (vpc_id, subnet_ids)
    """
    ec2 = boto3.client("ec2", region_name=region)

    # Find default VPC
    vpcs = ec2.describe_vpcs(Filters=[{"Name": "isDefault", "Values": ["true"]}])
    if not vpcs["Vpcs"]:
        raise RuntimeError(
            "No default VPC found. Please specify --vpc-id and --subnet-ids"
        )
    vpc_id = vpcs["Vpcs"][0]["VpcId"]

    # Get subnets in that VPC
    subnets = ec2.describe_subnets(Filters=[{"Name": "vpc-id", "Values": [vpc_id]}])
    subnet_ids = [s["SubnetId"] for s in subnets["Subnets"]]

    if len(subnet_ids) < 2:
        raise RuntimeError(
            "Need at least 2 subnets in different AZs. Please specify --subnet-ids"
        )

    return vpc_id, subnet_ids


def deploy_stack(
    stack_name: str = DEFAULT_STACK_NAME,
    region: str = DEFAULT_REGION,
    vpc_id: str | None = None,
    subnet_ids: str | None = None,
    db_name: str = "arato",
    desired_count: int = 0,
) -> None:
    """Deploy or update the CloudFormation infrastructure stack."""
    cfn = boto3.client("cloudformation", region_name=region)

    # Auto-detect VPC if not provided
    if not vpc_id or not subnet_ids:
        logger.info("Auto-detecting VPC and subnets...")
        detected_vpc, detected_subnets = get_default_vpc(region)
        vpc_id = vpc_id or detected_vpc
        subnet_ids = subnet_ids or ",".join(detected_subnets)

    logger.info("=" * 60)
    logger.info("Arato App Server Infrastructure Deployment")
    logger.info("=" * 60)
    logger.info(f"Stack Name: {stack_name}")
    logger.info(f"Region: {region}")
    logger.info(f"VPC: {vpc_id}")
    logger.info(f"Subnets: {subnet_ids}")
    logger.info(f"Database: {db_name}")
    logger.info("")

    template_body = load_template()

    parameters = [
        {"ParameterKey": "VpcId", "ParameterValue": vpc_id},
        {"ParameterKey": "SubnetIds", "ParameterValue": subnet_ids},
        {"ParameterKey": "DatabaseName", "ParameterValue": db_name},
        {"ParameterKey": "DesiredCount", "ParameterValue": str(desired_count)},
    ]

    try:
        # Check if stack exists
        try:
            cfn.describe_stacks(StackName=stack_name)
            logger.info(f"Stack {stack_name} exists, updating...")
            cfn.update_stack(
                StackName=stack_name,
                TemplateBody=template_body,
                Parameters=parameters,
                Capabilities=["CAPABILITY_IAM", "CAPABILITY_NAMED_IAM"],
            )
            waiter = cfn.get_waiter("stack_update_complete")
        except ClientError as e:
            if "does not exist" in str(e):
                logger.info(f"Creating new stack: {stack_name}")
                cfn.create_stack(
                    StackName=stack_name,
                    TemplateBody=template_body,
                    Parameters=parameters,
                    Capabilities=["CAPABILITY_IAM", "CAPABILITY_NAMED_IAM"],
                )
                waiter = cfn.get_waiter("stack_create_complete")
            elif "No updates are to be performed" in str(e):
                logger.info("No updates needed - stack is already up to date")
                return
            else:
                raise

        logger.info("Waiting for stack operation to complete...")
        waiter.wait(
            StackName=stack_name, WaiterConfig={"Delay": 15, "MaxAttempts": 120}
        )
        logger.info(f"Stack {stack_name} deployed successfully")

        # Display outputs
        response = cfn.describe_stacks(StackName=stack_name)
        outputs = response["Stacks"][0].get("Outputs", [])
        if outputs:
            logger.info("\nStack Outputs:")
            for output in outputs:
                logger.info(f"  {output['OutputKey']}: {output['OutputValue']}")

    except Exception as e:
        logger.error(f"Failed to deploy stack: {e}")
        raise


def get_stack_outputs(stack_name: str, region: str) -> dict[str, str]:
    """Get CloudFormation stack outputs as a dict."""
    cfn = boto3.client("cloudformation", region_name=region)
    response = cfn.describe_stacks(StackName=stack_name)
    outputs = response["Stacks"][0].get("Outputs", [])
    return {o["OutputKey"]: o["OutputValue"] for o in outputs}


def deploy_service(
    stack_name: str = DEFAULT_STACK_NAME,
    region: str = DEFAULT_REGION,
    skip_build: bool = False,
    skip_migrations: bool = False,
    health_url: str | None = None,
) -> None:
    """Build Docker image, push to ECR, and update ECS service."""
    logger.info("=" * 60)
    logger.info("Arato App Server Deployment")
    logger.info("=" * 60)

    # Get stack outputs
    try:
        outputs = get_stack_outputs(stack_name, region)
    except ClientError:
        logger.error(f"Stack {stack_name} not found. Run 'app-server configure' first.")
        sys.exit(1)

    ecr_repo = outputs.get("ECRRepositoryUri")
    cluster_name = outputs.get("ECSClusterName")
    service_name = outputs.get("ECSServiceName")
    db_endpoint = outputs.get("AuroraEndpoint")

    if not ecr_repo or not cluster_name or not service_name:
        logger.error("Missing required stack outputs. Stack may not be fully deployed.")
        sys.exit(1)

    logger.info(f"ECR Repository: {ecr_repo}")
    logger.info(f"ECS Cluster: {cluster_name}")
    logger.info(f"ECS Service: {service_name}")
    if db_endpoint:
        logger.info(f"Aurora Endpoint: {db_endpoint}")
    logger.info("")

    # Step 1: Build Docker image
    image_tag = f"{ecr_repo}:latest"
    project_root = Path(__file__).resolve().parent.parent

    if not skip_build:
        logger.info("Step 1: Building Docker image...")
        # Get git commit hash for build-time injection into the client
        git_commit = "unknown"
        try:
            git_result = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                capture_output=True,
                text=True,
                cwd=str(project_root),
            )
            if git_result.returncode == 0:
                git_commit = git_result.stdout.strip()
        except Exception:
            pass
        result = subprocess.run(
            [
                "docker",
                "build",
                "--platform",
                "linux/amd64",
                "--build-arg",
                f"GIT_COMMIT={git_commit}",
                "-f",
                str(project_root / "app" / "apps" / "server" / "Dockerfile"),
                "-t",
                image_tag,
                str(project_root),
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            logger.error(f"Docker build failed:\n{result.stderr}")
            sys.exit(1)
        logger.info("Docker image built successfully")
    else:
        logger.info("Step 1: Skipping Docker build")

    # Step 2: Push to ECR
    logger.info("Step 2: Pushing to ECR...")

    # ECR login
    ecr_client = boto3.client("ecr", region_name=region)
    token = ecr_client.get_authorization_token()
    auth_data = token["authorizationData"][0]
    registry = auth_data["proxyEndpoint"]

    result = subprocess.run(
        [
            "docker",
            "login",
            "--username",
            "AWS",
            "--password-stdin",
            registry,
        ],
        input=__import__("base64")
        .b64decode(auth_data["authorizationToken"])
        .decode()
        .split(":")[1],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        logger.error(f"ECR login failed:\n{result.stderr}")
        sys.exit(1)

    result = subprocess.run(
        ["docker", "push", image_tag],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        logger.error(f"Docker push failed:\n{result.stderr}")
        sys.exit(1)
    logger.info("Image pushed to ECR")

    ecs = boto3.client("ecs", region_name=region)

    # Step 3: Run Prisma migrations via one-off Fargate task
    if not skip_migrations and db_endpoint:
        logger.info("Step 3: Running Prisma migrations...")

        # Get task definition and network config from the running service
        svc_info = ecs.describe_services(cluster=cluster_name, services=[service_name])
        service = svc_info["services"][0]
        task_def = service["taskDefinition"]
        net_config = service["networkConfiguration"]

        logger.info(f"  Task definition: {task_def}")

        # Run migration as a one-off Fargate task
        run_resp = ecs.run_task(
            cluster=cluster_name,
            taskDefinition=task_def,
            launchType="FARGATE",
            networkConfiguration=net_config,
            overrides={
                "containerOverrides": [
                    {"name": "app", "command": ["npx", "prisma", "migrate", "deploy"]}
                ]
            },
        )
        task_arn = run_resp["tasks"][0]["taskArn"]
        logger.info(f"  Migration task: {task_arn}")

        # Wait for task to complete
        logger.info("  Waiting for migration task to finish...")
        waiter = ecs.get_waiter("tasks_stopped")
        waiter.wait(cluster=cluster_name, tasks=[task_arn])

        # Check exit code
        task_desc = ecs.describe_tasks(cluster=cluster_name, tasks=[task_arn])
        exit_code = task_desc["tasks"][0]["containers"][0].get("exitCode", -1)

        if exit_code != 0:
            reason = task_desc["tasks"][0]["containers"][0].get("reason", "unknown")
            logger.error(f"  Migration failed (exit code {exit_code}): {reason}")
            sys.exit(1)

        logger.info("  Migrations completed successfully")
    else:
        logger.info("Step 3: Skipping migrations")

    # Step 4: Force new deployment
    logger.info("Step 4: Updating ECS service...")

    # Check if auto-scaling manages desired count
    try:
        aas = boto3.client("application-autoscaling", region_name=region)
        targets = aas.describe_scalable_targets(
            ServiceNamespace="ecs",
            ResourceIds=[f"service/{cluster_name}/{service_name}"],
        )
        has_autoscaling = len(targets.get("ScalableTargets", [])) > 0
    except Exception:
        has_autoscaling = False

    update_params: dict = {
        "cluster": cluster_name,
        "service": service_name,
        "forceNewDeployment": True,
    }

    if not has_autoscaling:
        update_params["desiredCount"] = 1
        logger.info("ECS service update triggered (desiredCount=1, no auto-scaling)")
    else:
        logger.info("ECS service update triggered (auto-scaling manages desired count)")

    ecs.update_service(**update_params)

    # Step 5: Wait for deployment to stabilize
    logger.info("Step 5: Waiting for ECS deployment to stabilize...")
    waiter = ecs.get_waiter("services_stable")
    waiter.wait(
        cluster=cluster_name,
        services=[service_name],
        WaiterConfig={"Delay": 15, "MaxAttempts": 40},
    )
    logger.info("Deployment stabilized")

    # Step 6: Health check
    alb_dns = outputs.get("ALBDnsName")
    check_url = health_url or (f"http://{alb_dns}/health" if alb_dns else None)
    if check_url:
        logger.info(f"Step 6: Verifying health at {check_url}...")
        for attempt in range(1, 4):
            try:
                req = urllib.request.Request(check_url, method="GET")
                with urllib.request.urlopen(req, timeout=10) as resp:
                    if resp.status == 200:
                        logger.info("Health check passed!")
                        break
            except (urllib.error.URLError, OSError) as e:
                logger.warning(f"  Attempt {attempt}/3 failed: {e}")
            if attempt < 3:
                time.sleep(10)
        else:
            logger.error("Health check failed after 3 attempts")
            sys.exit(1)
    else:
        logger.info("Step 6: Skipping health check (no URL available)")

    logger.info("")
    logger.info("=" * 60)
    logger.info("Deployment Complete")
    logger.info("=" * 60)
    if check_url:
        logger.info(f"App URL: {check_url.replace('/health', '')}")


def get_stack_status(
    stack_name: str = DEFAULT_STACK_NAME,
    region: str = DEFAULT_REGION,
) -> None:
    """Check CloudFormation stack and ECS service status."""
    cfn = boto3.client("cloudformation", region_name=region)

    logger.info("=" * 60)
    logger.info("Arato App Server Status")
    logger.info("=" * 60)

    try:
        response = cfn.describe_stacks(StackName=stack_name)
        stack = response["Stacks"][0]
        logger.info(f"Stack: {stack_name}")
        logger.info(f"Status: {stack['StackStatus']}")
        logger.info(f"Created: {stack['CreationTime']}")
        if "LastUpdatedTime" in stack:
            logger.info(f"Updated: {stack['LastUpdatedTime']}")

        outputs = {o["OutputKey"]: o["OutputValue"] for o in stack.get("Outputs", [])}

        if outputs:
            logger.info("\nResources:")
            for key, value in outputs.items():
                logger.info(f"  {key}: {value}")

        # Check ECS service status
        cluster_name = outputs.get("ECSClusterName")
        service_name = outputs.get("ECSServiceName")
        if cluster_name and service_name:
            ecs = boto3.client("ecs", region_name=region)
            services = ecs.describe_services(
                cluster=cluster_name,
                services=[service_name],
            )
            if services["services"]:
                svc = services["services"][0]
                logger.info("\nECS Service:")
                logger.info(f"  Status: {svc['status']}")
                logger.info(f"  Running: {svc['runningCount']}")
                logger.info(f"  Desired: {svc['desiredCount']}")
                logger.info(f"  Pending: {svc['pendingCount']}")

    except ClientError as e:
        if "does not exist" in str(e):
            logger.info(f"Stack {stack_name} does not exist")
        else:
            logger.error(f"Error: {e}")
            raise


def destroy_stack(
    stack_name: str = DEFAULT_STACK_NAME,
    region: str = DEFAULT_REGION,
) -> None:
    """Delete the CloudFormation stack and all resources."""
    cfn = boto3.client("cloudformation", region_name=region)

    logger.info("=" * 60)
    logger.info("Arato App Server Destruction")
    logger.info("=" * 60)
    logger.info(f"Stack: {stack_name}")
    logger.info(f"Region: {region}")
    logger.info("")

    try:
        cfn.delete_stack(StackName=stack_name)
        logger.info("Waiting for stack deletion...")
        waiter = cfn.get_waiter("stack_delete_complete")
        waiter.wait(
            StackName=stack_name, WaiterConfig={"Delay": 15, "MaxAttempts": 120}
        )
        logger.info(f"Stack {stack_name} deleted successfully")
    except ClientError as e:
        if "does not exist" in str(e):
            logger.warning(f"Stack {stack_name} does not exist")
        else:
            logger.error(f"Failed to delete stack: {e}")
            raise

    logger.info("")
    logger.info("=" * 60)
    logger.info("Destruction Complete")
    logger.info("=" * 60)


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Deploy Arato app server to AWS ECS/Fargate"
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Configure
    configure_parser = subparsers.add_parser(
        "configure", help="Deploy CloudFormation infrastructure"
    )
    configure_parser.add_argument("--stack-name", default=DEFAULT_STACK_NAME)
    configure_parser.add_argument("--region", default=DEFAULT_REGION)
    configure_parser.add_argument("--vpc-id")
    configure_parser.add_argument("--subnet-ids")
    configure_parser.add_argument("--db-name", default="arato")
    configure_parser.add_argument(
        "--desired-count",
        type=int,
        default=0,
        help="Initial ECS desired task count (default: 0)",
    )

    # Deploy
    deploy_parser = subparsers.add_parser("deploy", help="Build, push, and deploy")
    deploy_parser.add_argument("--stack-name", default=DEFAULT_STACK_NAME)
    deploy_parser.add_argument("--region", default=DEFAULT_REGION)
    deploy_parser.add_argument("--skip-build", action="store_true")
    deploy_parser.add_argument("--skip-migrations", action="store_true")
    deploy_parser.add_argument(
        "--health-url", help="URL for post-deploy health check (default: ALB /health)"
    )

    # Status
    status_parser = subparsers.add_parser("status", help="Check status")
    status_parser.add_argument("--stack-name", default=DEFAULT_STACK_NAME)
    status_parser.add_argument("--region", default=DEFAULT_REGION)

    # Destroy
    destroy_parser = subparsers.add_parser("destroy", help="Destroy stack")
    destroy_parser.add_argument("--stack-name", default=DEFAULT_STACK_NAME)
    destroy_parser.add_argument("--region", default=DEFAULT_REGION)
    destroy_parser.add_argument("--force", action="store_true")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "configure":
        deploy_stack(
            args.stack_name,
            args.region,
            args.vpc_id,
            args.subnet_ids,
            args.db_name,
            args.desired_count,
        )
    elif args.command == "deploy":
        deploy_service(
            args.stack_name,
            args.region,
            args.skip_build,
            args.skip_migrations,
            args.health_url,
        )
    elif args.command == "status":
        get_stack_status(args.stack_name, args.region)
    elif args.command == "destroy":
        if not args.force:
            response = input("Are you sure? (yes/no): ")
            if response.lower() != "yes":
                logger.info("Aborted.")
                sys.exit(0)
        destroy_stack(args.stack_name, args.region)


if __name__ == "__main__":
    main()
