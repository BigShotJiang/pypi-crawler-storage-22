#!/usr/bin/env python3
"""
Extract summary.json files from transcript.json.

This script can work in two modes:
1. Session Mode: Process an entire session directory (all personas inside).
2. Persona Mode: Process a single persona directory.

Usage:
    uv run extract-summaries sessions/my_session
    uv run extract-summaries sessions/my_session/malicious_user_01
"""

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path

from constants import PERSONA_SETTINGS_DIR, TRANSCRIPT_FILENAME
from models.conversation_turn import ConversationTurn
from utils.config_loader import (
    Persona,
    Role,
    get_available_personas,
    get_available_roles,
    load_persona,
    load_role,
)
from utils.persona_summary_generator import generate_persona_summary

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _parse_folder_name(folder_name: str) -> tuple[str | None, str | None]:
    """Parse folder name to extract persona and role IDs.

    Folder names follow the pattern: {persona}_{role}_{instance}
    Examples:
      - technical_expert_manager_01 -> (technical_expert, manager)
      - business_professional_manager_01 -> (business_professional, manager)
      - compliance_tester_hr_admin_01 -> (compliance_tester, hr_admin)

    Returns:
      Tuple of (persona_id, role_id) or (None, None) if parsing fails
    """
    # Remove instance number suffix (e.g., _01, _02)
    parts = folder_name.split("_")
    if parts and parts[-1].isdigit():
        parts = parts[:-1]

    if not parts:
        return None, None

    # Get available personas and roles to match against
    available_personas = get_available_personas()
    available_roles = get_available_roles()

    # Try to find the longest matching persona prefix
    best_persona = None
    best_persona_parts = 0

    for i in range(len(parts), 0, -1):
        candidate = "_".join(parts[:i])
        if candidate in available_personas:
            best_persona = candidate
            best_persona_parts = i
            break

    if not best_persona:
        return None, None

    # Remaining parts should be the role
    remaining = parts[best_persona_parts:]
    if remaining:
        role_candidate = "_".join(remaining)
        if role_candidate in available_roles:
            return best_persona, role_candidate

    return best_persona, None


def _build_persona_description(persona: Persona, role: Role | None = None) -> str:
    """Build a markdown description from a Persona config object."""
    lines = [
        f"# {persona.name}",
        "",
        "## Persona ID",
        f"`{persona.id}`",
        "",
        "## Description",
        persona.description,
        "",
    ]

    # Add role information if available
    if role:
        lines.extend(
            [
                f"# ROLE: {role.name}",
                "",
                role.description,
                "",
            ]
        )
        if role.permissions:
            lines.extend(
                [
                    "## Permissions",
                    *[f"- {p}" for p in role.permissions],
                    "",
                ]
            )
        if role.constraints:
            lines.extend(
                [
                    "## Constraints",
                    *[f"- {c}" for c in role.constraints],
                    "",
                ]
            )

    if persona.traits:
        lines.extend(
            [
                "## Behavioral Characteristics",
                *[f"- {trait}" for trait in persona.traits],
                "",
            ]
        )

    if persona.conversation_style:
        lines.extend(
            [
                "## Conversation Style",
                *[f"- {style}" for style in persona.conversation_style],
                "",
            ]
        )

    if persona.risk_description:
        lines.extend(
            [
                f"## Risk Level: {persona.risk_level}",
                persona.risk_description,
                "",
            ]
        )

    if persona.attack_vectors:
        lines.extend(
            [
                "## Attack Vectors",
                *[f"- {vector}" for vector in persona.attack_vectors],
                "",
            ]
        )

    return "\n".join(lines)


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Generate summary.json from transcript.json"
    )
    parser.add_argument(
        "path",
        type=str,
        help="Path to session directory OR single persona directory",
    )
    parser.add_argument(
        "--test-suite",
        type=str,
        default=None,
        help="Test suite ID for allowed_disclosures (e.g., 'hibob')",
    )
    return parser.parse_args()


async def extract_summary_from_transcript(
    persona_dir: Path,
    target_url: str = "",
    test_suite_config: dict | None = None,
) -> None:
    """
    Generate summary.json from transcript.json for a single persona.

    Args:
        persona_dir: Directory containing transcript.json
        target_url: Target URL (optional, attempts to read from transcript if empty)
        test_suite_config: Optional test suite configuration with allowed_disclosures
    """
    transcript_file = persona_dir / TRANSCRIPT_FILENAME
    if not transcript_file.exists():
        logger.warning(f"❌ No transcript found at {transcript_file}")
        return

    logger.info(f"Processing persona folder: {persona_dir}")

    # Load transcript
    with open(transcript_file, encoding="utf-8") as f:
        transcript_data = json.load(f)

    # 1. Determine Target URL
    # Priority: Function Argument > Transcript JSON > Default
    if not target_url:
        target_url = transcript_data.get("target_url", "Unknown")

    # 2. Parse Transcript Turns
    # (Logic adapted from regenerate_persona_summary.py for robustness)
    transcript_list = transcript_data.get("transcript", [])
    transcript_turns = []
    current_turn = 1

    for turn_data in transcript_list:
        turn = ConversationTurn(
            role=turn_data["role"],
            text=turn_data["text"],
            timestamp=turn_data.get("timestamp", ""),
            # Robust parsing for additional fields
            screenshot=turn_data.get("screenshot"),
            measurements=turn_data.get("measurements"),
            evals=turn_data.get("evals", []),
        )

        # Handle 'findings' (new) or 'validation_responses' (legacy) from transcript
        if not turn.evals:
            turn.evals = turn_data.get("findings") or turn_data.get(
                "validation_responses", []
            )

        # Assign turn numbers to assistant responses
        if turn.role == "assistant":
            turn.turn_number = current_turn
            current_turn += 1

        transcript_turns.append(turn)

    if not transcript_turns:
        logger.warning(f"❌ Empty transcript at {transcript_file}")
        return

    # 3. Determine Persona ID and Description
    persona_id = persona_dir.name
    persona_description = ""

    # Parse folder name to extract persona and role IDs
    # Format: {persona}_{role}_{instance} e.g., technical_expert_manager_01
    parsed_persona_id, parsed_role_id = _parse_folder_name(persona_id)

    if parsed_persona_id:
        # Try to load persona and role from config/
        try:
            persona = load_persona(parsed_persona_id)
            role = None
            if parsed_role_id:
                try:
                    role = load_role(parsed_role_id)
                    logger.info(
                        f"Loaded persona '{parsed_persona_id}' + role '{parsed_role_id}' from config"
                    )
                except FileNotFoundError:
                    logger.warning(
                        f"Role '{parsed_role_id}' not found, using persona only"
                    )
            else:
                logger.info(f"Loaded persona '{parsed_persona_id}' from config")

            persona_description = _build_persona_description(persona, role)
        except FileNotFoundError:
            parsed_persona_id = None  # Fall back to legacy

    if not persona_description:
        # Fall back to legacy .persona files
        # Extract base ID (remove instance number suffix like _01, _02)
        base_persona_id = persona_id
        parts = persona_id.split("_")
        if len(parts) > 1 and parts[-1].isdigit():
            base_persona_id = "_".join(parts[:-1])

        persona_file_candidates = [
            Path(PERSONA_SETTINGS_DIR) / f"{persona_id}.persona",
            Path(PERSONA_SETTINGS_DIR) / f"{base_persona_id}.persona",
        ]

        for p_file in persona_file_candidates:
            if p_file.exists():
                logger.info(f"Found legacy persona file: {p_file}")
                persona_description = p_file.read_text(encoding="utf-8")
                break

    if not persona_description:
        logger.warning(
            f"⚠️  Persona not found for {persona_id}, continuing with ID only"
        )
        persona_description = f"Persona ID: {persona_id}"

    # 4. Generate Summary
    logger.info(f"🤖 Generating summary for {persona_id}...")

    await generate_persona_summary(
        output_dir=str(persona_dir),
        persona_id=persona_id,
        persona_description=persona_description,
        transcript=transcript_turns,
        final_url=target_url,
        test_suite_config=test_suite_config,
    )
    logger.info(f"✅ Summary generated: {persona_dir / 'summary.json'}")


async def extract_all_summaries(
    session_dir: Path, test_suite_config: dict | None = None
) -> None:
    """
    Extract summaries from all persona directories in a session.

    Args:
        session_dir: Path to session directory
        test_suite_config: Optional test suite configuration with allowed_disclosures
    """
    if not session_dir.exists():
        logger.error(f"❌ Session directory not found: {session_dir}")
        return

    # Load session metadata
    progress_file = session_dir / "progress.json"
    target_url = ""
    if progress_file.exists():
        try:
            with open(progress_file) as f:
                progress = json.load(f)
                target_url = progress.get("orchestrator", {}).get("target_url", "")
        except Exception as e:
            logger.warning(f"⚠️  Failed to read progress.json: {e}")
    else:
        logger.info("No progress.json found, will read target_url from transcripts")

    # Find all persona directories (contains transcript.json)
    persona_dirs = []
    for item in session_dir.iterdir():
        if item.is_dir() and (item / TRANSCRIPT_FILENAME).exists():
            persona_dirs.append(item)

    if not persona_dirs:
        logger.error(
            f"❌ No persona directories with transcripts found in {session_dir}"
        )
        return

    logger.info(f"📂 Found {len(persona_dirs)} persona directories")

    # Process each persona
    for persona_dir in persona_dirs:
        try:
            await extract_summary_from_transcript(
                persona_dir=persona_dir,
                target_url=target_url,
                test_suite_config=test_suite_config,
            )
        except Exception as e:
            logger.error(f"❌ Failed to process {persona_dir.name}: {e}")
            # Log traceback for debugging
            import traceback

            logger.error(traceback.format_exc())

    logger.info(f"✅ Completed session processing for {len(persona_dirs)} directories")


async def async_main() -> int:
    """Async main entry point."""
    args = parse_args()
    path = Path(args.path)

    if not path.exists():
        logger.error(f"❌ Path not found: {path}")
        return 1

    # Initialize local platform for LLM access
    from platforms.local import LocalPlatformAdapter

    logger.info("🚀 Initializing local platform adapter...")
    LocalPlatformAdapter()

    # Load test suite config if provided
    test_suite_config: dict | None = None
    if args.test_suite:
        from utils.config_loader import load_test_suite

        test_suite = load_test_suite(args.test_suite)
        if test_suite:
            test_suite_config = {
                "allowed_disclosures": getattr(test_suite, "allowed_disclosures", []),
            }
            logger.info(
                f"✓ Loaded test suite '{args.test_suite}' with "
                f"{len(test_suite_config.get('allowed_disclosures', []))} allowed disclosures"
            )
        else:
            logger.warning(f"⚠️  Test suite '{args.test_suite}' not found")

    # Determine mode based on content
    is_persona_dir = (path / TRANSCRIPT_FILENAME).exists()

    if is_persona_dir:
        logger.info("Detecting SINGLE PERSONA mode")
        await extract_summary_from_transcript(path, test_suite_config=test_suite_config)
    else:
        logger.info("Detecting SESSION mode")
        await extract_all_summaries(path, test_suite_config=test_suite_config)

    return 0


def main() -> int:
    """CLI entry point."""
    return asyncio.run(async_main())


if __name__ == "__main__":
    sys.exit(main())
