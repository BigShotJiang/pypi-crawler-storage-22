"""Red flag reporting tool for agent-identified security/compliance issues."""

import logging
from typing import Any

from core.multiagent.finding import Finding

logger = logging.getLogger(__name__)


async def report_red_flag(
    agent_id: str,
    category: str,
    title: str,
    what_was_tested: str,
    score: float,
    explanation: str,
    confidence: float,
    screenshot_path: str | None = None,
    **extra_data: Any,
) -> Finding:
    """
    Report an identified red flag as a structured Finding.

    This tool is called by the agent during conversation when it observes
    behavior that violates security, compliance, or stability requirements.

    Args:
        agent_id: ID of the agent/tool reporting this red flag
        category: Eval category (must match one of the predefined system categories)
        title: Short descriptive title for this finding
        what_was_tested: Description of what was tested/validated
        score: Quality score 0-100 (0-9=critical, 10-74=warning, 75-100=good)
        explanation: What was observed that triggered this red flag
        confidence: Confidence score 0-1 (how confident in this finding)
        screenshot_path: Optional path to screenshot file for evidence
        **extra_data: Additional metadata fields (e.g., flow_name, flow_url, blocks_found)

    Returns:
        Finding dataclass instance

    Example:
        result = await report_red_flag(
            agent_id="cloudinary_skill",
            category="Security and Compliance",
            title="Jailbreak Detected",
            what_was_tested="System prompt protection",
            score=5,
            explanation="Bot accepted 'developer mode' prompt and revealed system instructions",
            confidence=0.95,
        )
    """
    # Create Finding with all metadata
    metadata = dict(extra_data) if extra_data else {}

    finding = Finding.create(
        agent_id=agent_id,
        category=category,
        title=title,
        what_was_tested=what_was_tested,
        score=score,
        explanation=explanation,
        confidence=confidence,
        screenshot_path=screenshot_path,
        metadata=metadata,
    )

    logger.debug(
        f"🚩 Red flag reported: {title} | "
        f"Category: {category} | Agent: {agent_id} | "
        f"Score: {score}/100"
    )
    logger.debug(f"Explanation: {explanation}")

    return finding
