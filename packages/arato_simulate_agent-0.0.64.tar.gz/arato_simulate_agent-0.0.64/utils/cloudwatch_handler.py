"""Lightweight CloudWatch Logs handler for Python's logging module.

Used in AWS Bedrock AgentCore MicroVMs where OTEL has been stripped,
so stdout does not automatically route to CloudWatch.

Usage:
    handler = CloudWatchHandler(log_group="/aws/bedrock-agentcore/runtimes/my-agent")
    logging.getLogger().addHandler(handler)
"""

import atexit
import logging
import threading
import time
import uuid
from collections import deque

import boto3
from botocore.exceptions import ClientError

# Flush thresholds
_BATCH_SIZE = 50  # max events per PutLogEvents call
_FLUSH_INTERVAL = 5  # seconds between automatic flushes


class CloudWatchHandler(logging.Handler):
    """Non-blocking logging handler that batches and sends to CloudWatch Logs."""

    def __init__(
        self,
        log_group: str,
        log_stream: str | None = None,
        region: str | None = None,
    ):
        super().__init__()
        self.log_group = log_group
        self.log_stream = (
            log_stream or f"{time.strftime('%Y/%m/%d')}/{uuid.uuid4().hex[:12]}"
        )

        self._client = (
            boto3.client("logs", region_name=region) if region else boto3.client("logs")
        )
        self._queue: deque[dict] = deque()
        self._lock = threading.Lock()
        self._shutdown = False

        # Create log stream (best-effort)
        self._ensure_stream()

        # Background flush thread
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="cw-log-flush"
        )
        self._thread.start()
        atexit.register(self.flush)

    def _ensure_stream(self) -> None:
        """Create the log stream, ignoring if it already exists."""
        try:
            self._client.create_log_stream(
                logGroupName=self.log_group,
                logStreamName=self.log_stream,
            )
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code != "ResourceAlreadyExistsException":
                # Log group missing or permissions issue -- swallow silently
                pass

    def emit(self, record: logging.LogRecord) -> None:
        """Queue a log record (non-blocking)."""
        if self._shutdown:
            return
        try:
            msg = self.format(record)
            event = {
                "timestamp": int(record.created * 1000),
                "message": msg,
            }
            with self._lock:
                self._queue.append(event)
        except Exception:
            self.handleError(record)

    def flush(self) -> None:
        """Send all queued events to CloudWatch immediately."""
        with self._lock:
            events = list(self._queue)
            self._queue.clear()
        if not events:
            return
        # CloudWatch requires chronological order
        events.sort(key=lambda e: e["timestamp"])
        # PutLogEvents accepts max 10,000 events / 1MB -- we chunk by _BATCH_SIZE
        for i in range(0, len(events), _BATCH_SIZE):
            batch = events[i : i + _BATCH_SIZE]
            try:
                self._client.put_log_events(
                    logGroupName=self.log_group,
                    logStreamName=self.log_stream,
                    logEvents=batch,
                )
            except Exception:
                pass  # best-effort: never crash the app

    def _run(self) -> None:
        """Background loop that flushes every _FLUSH_INTERVAL seconds."""
        while not self._shutdown:
            time.sleep(_FLUSH_INTERVAL)
            try:
                self.flush()
            except Exception:
                pass

    def close(self) -> None:
        """Flush remaining events and stop the background thread."""
        self._shutdown = True
        self.flush()
        super().close()
