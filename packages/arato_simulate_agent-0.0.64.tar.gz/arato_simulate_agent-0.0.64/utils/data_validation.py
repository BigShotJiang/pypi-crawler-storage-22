"""Utilities for safely handling potentially malformed data structures.

This module provides defensive data extraction functions that gracefully handle
unexpected types, missing keys, and malformed JSON structures.
"""

import logging
from typing import Any

from utils.scoring import calculate_label, normalize_severity_to_label

logger = logging.getLogger(__name__)


def safe_get(
    obj: Any, key: str, default: Any = None, expected_type: type | None = None
) -> Any:
    """Safely get a value from a dict-like object with type validation.

    Args:
      obj: Object to extract value from (should be dict, but handles any type)
      key: Key to look up
      default: Default value if key not found or type mismatch
      expected_type: Expected type of the value (optional)

    Returns:
      Value from obj[key] if valid, otherwise default
    """
    if not isinstance(obj, dict):
        logger.debug(
            f"safe_get: object is not dict (type={type(obj).__name__}), returning default"
        )
        return default

    value = obj.get(key, default)

    if expected_type is not None and value is not default:
        if not isinstance(value, expected_type):
            logger.debug(
                f'safe_get: key "{key}" has wrong type '
                f"(expected={expected_type.__name__}, got={type(value).__name__}), returning default"
            )
            return default

    return value


def safe_dict_list(
    obj: Any, key: str, default: list[dict[str, Any]] | None = None
) -> list[dict[str, Any]]:
    """Safely get a list of dictionaries, filtering out non-dict entries.

    Args:
      obj: Object to extract from
      key: Key to look up
      default: Default value if key not found

    Returns:
      List of dict entries, with non-dict entries filtered out
    """
    if default is None:
        default = []

    if not isinstance(obj, dict):
        return default

    value = obj.get(key, default)

    if not isinstance(value, list):
        logger.debug(
            f'safe_dict_list: key "{key}" is not a list (type={type(value).__name__})'
        )
        return default

    # Filter to only dict entries
    result = []
    for i, item in enumerate(value):
        if isinstance(item, dict):
            result.append(item)
        else:
            logger.debug(
                f"safe_dict_list: skipping non-dict entry at index {i} "
                f'(type={type(item).__name__}) in key "{key}"'
            )

    return result


def safe_str(obj: Any, key: str, default: str = "") -> str:
    """Safely get a string value, converting if necessary.

    Args:
      obj: Object to extract from
      key: Key to look up
      default: Default value if key not found

    Returns:
      String value, converted if necessary
    """
    value = safe_get(obj, key, default)

    if value is None:
        return default

    if isinstance(value, str):
        return value

    # Convert to string if not already
    try:
        return str(value)
    except Exception as e:
        logger.debug(f"safe_str: failed to convert value to string: {e}")
        return default


def safe_int(obj: Any, key: str, default: int = 0) -> int:
    """Safely get an integer value, converting if necessary.

    Args:
      obj: Object to extract from
      key: Key to look up
      default: Default value if key not found or conversion fails

    Returns:
      Integer value, converted if necessary
    """
    value = safe_get(obj, key, default)

    if isinstance(value, int):
        return value

    if isinstance(value, float | str):
        try:
            return int(value)
        except (ValueError, TypeError):
            logger.debug(f'safe_int: failed to convert "{value}" to int')
            return default

    return default


def safe_float(obj: Any, key: str, default: float = 0.0) -> float:
    """Safely get a float value, converting if necessary.

    Args:
      obj: Object to extract from
      key: Key to look up
      default: Default value if key not found or conversion fails

    Returns:
      Float value, converted if necessary
    """
    value = safe_get(obj, key, default)

    if isinstance(value, int | float):
        return float(value)

    if isinstance(value, str):
        try:
            return float(value)
        except (ValueError, TypeError):
            logger.debug(f'safe_float: failed to convert "{value}" to float')
            return default

    return default


def validate_finding(finding: Any) -> dict[str, Any] | None:
    """Validate and sanitize a finding object.

    Args:
      finding: Potentially malformed finding object

    Returns:
      Sanitized dict if valid, None if invalid
    """
    if not isinstance(finding, dict):
        logger.warning(
            f"validate_finding: finding is not dict (type={type(finding).__name__})"
        )
        return None

    # Ensure required fields exist
    required_fields = ["category", "title"]
    for field in required_fields:
        if field not in finding:
            logger.warning(f'validate_finding: missing required field "{field}"')
            return None

    # Initialize sanitized dict with basic fields
    # Initialize sanitized dict with basic fields
    sanitized = {
        "agent_id": safe_str(finding, "agent_id", "unknown"),
        "category": safe_str(finding, "category", "Unknown"),
        "original_category": safe_str(
            finding, "original_category", safe_str(finding, "category", "Unknown")
        ),
        "title": safe_str(finding, "title", "Untitled"),
        "what_was_tested": safe_str(finding, "what_was_tested", ""),
        "assessment": safe_str(finding, "assessment", ""),
        "impact": safe_str(finding, "impact", ""),
        "evidence": {},
        "evaluation_results": {},
    }

    # Handle evidence (can be dict or missing)
    evidence = finding.get("evidence", {})
    if isinstance(evidence, dict):
        sanitized["evidence"] = evidence

    # Handle evaluation_results (can be dict, list, or missing)
    eval_results = finding.get("evaluation_results")
    if isinstance(eval_results, dict):
        sanitized["evaluation_results"] = eval_results
    elif isinstance(eval_results, list) and eval_results:
        # If it's a list, try to use first dict entry
        for item in eval_results:
            if isinstance(item, dict):
                sanitized["evaluation_results"] = item
                logger.debug(
                    "validate_finding: converted list evaluation_results to dict (using first entry)"
                )
                break

    # Resolve Severity/Label from Quality Score if needed
    # Priority: 1. explicit label, 2. explicit severity, 3. compute from score, 4. fallback
    label = safe_str(finding, "label", "")
    severity = safe_str(finding, "severity", "")

    if label:
        # 1. Use explicit label (highest priority)
        pass
    elif severity:
        # 2. Use explicit severity - map to label
        label = normalize_severity_to_label(severity)
    else:
        # 3. Try to compute from score
        score = -1.0
        if "quality" in sanitized["evaluation_results"]:
            score = safe_float(sanitized["evaluation_results"], "quality", -1.0)
        elif "score" in sanitized["evaluation_results"]:
            score = safe_float(sanitized["evaluation_results"], "score", -1.0)

        if score != -1.0:
            label = calculate_label(score)
        else:
            # 4. Fallback default
            label = "Warning"

    sanitized["label"] = label

    return sanitized


def sanitize_findings_list(findings: Any) -> list[dict[str, Any]]:
    """Sanitize a list of findings, filtering out invalid entries.

    Args:
      findings: Potentially malformed list of findings

    Returns:
      List of validated finding dicts
    """
    if not isinstance(findings, list):
        logger.warning(
            f"sanitize_findings_list: input is not list (type={type(findings).__name__})"
        )
        return []

    result = []
    for i, finding in enumerate(findings):
        validated = validate_finding(finding)
        if validated:
            result.append(validated)
        else:
            logger.debug(
                f"sanitize_findings_list: skipped invalid finding at index {i}"
            )

    return result
