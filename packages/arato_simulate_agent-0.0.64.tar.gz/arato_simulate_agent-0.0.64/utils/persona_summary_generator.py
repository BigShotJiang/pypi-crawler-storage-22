"""
Shared utility for generating persona conversation summaries.

This module extracts the summary generation logic used by both:
- agents/chat_runner.py (during conversation)
- scripts/extract_summaries_from_transcripts.py (post-processing)
"""

import asyncio
import json
import logging
import os
import re
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlparse

from pydantic import BaseModel

from constants import (
    FINDING_CATEGORIES,
    FINDING_CATEGORY_DESCRIPTIONS,
    SCORE_THRESHOLD_GOOD,
    SCORE_THRESHOLD_PASS,
    SUMMARY_FILENAME,
)
from core.llm import create_chat_model
from models.conversation_turn import ConversationTurn, calculate_turn_count
from utils import save_text_file
from utils.arato_monitor import AratoMonitor
from utils.prompt_loader import load_prompt
from utils.scoring import calculate_label, calculate_status

logger = logging.getLogger(__name__)


# Pydantic models for structured output
class ConversationMetadata(BaseModel):
    url: str
    persona: str
    date: str
    total_turns: int
    total_messages: int
    user_messages: int
    assistant_responses: int
    avg_user_message_length: float
    avg_assistant_message_length: float


class EvidenceDetail(BaseModel):
    turn_id: str | None = None  # UUID for precise turn matching
    turn_number: int
    agent_input: str
    chatbot_response: str


class EvaluationResults(BaseModel):
    status: str
    score: float
    confidence: float
    explanation: str


class Finding(BaseModel):
    category: str
    title: str
    status: str
    severity: str
    what_was_tested: str
    evidence: EvidenceDetail
    evaluation_results: EvaluationResults
    assessment: str
    impact: str


class Recommendations(BaseModel):
    critical: list[str]
    high: list[str]
    medium: list[str]
    low: list[str]
    reinforce_strengths: list[str]


class AnalysisMetadata(BaseModel):
    total_turns: int
    total_findings: int
    critical_failures: int
    high_failures: int
    medium_issues: int
    low_issues: int


class MetricScore(BaseModel):
    """A metric with score and explanation."""

    score: float
    explanation: str


class Stats(BaseModel):
    factuality: MetricScore
    coherence: MetricScore
    tone_adherence: MetricScore
    context_retention: MetricScore | None
    turn_to_resolution: MetricScore | None
    topic_coverage: MetricScore
    instruction_following: MetricScore


class Analysis(BaseModel):
    stats: Stats
    findings: list[Finding]
    recommendations: Recommendations
    summary: str
    metadata: AnalysisMetadata


class PersonaSummary(BaseModel):
    conversation_metadata: ConversationMetadata
    analysis: Analysis


def _validate_category(category: str | None) -> str | None:
    """Validate a finding category against FINDING_CATEGORIES.

    This function does NOT attempt to fix or map invalid categories.
    If the LLM outputs an invalid category, we log an ERROR and return None
    to signal the finding should be removed.

    Args:
        category: The category string from LLM output

    Returns:
        The category if valid, None if invalid (finding should be removed)
    """
    if not category:
        logger.error(
            "🚨 LLM returned finding with NO category. "
            f"Valid categories: {FINDING_CATEGORIES}. Finding will be REMOVED."
        )
        return None

    # Valid category - just return it
    if category in FINDING_CATEGORIES:
        return category

    # INVALID category - log ERROR and return None to remove finding
    logger.error(
        f"🚨 LLM returned INVALID category: '{category}'. "
        f"This means the prompt constraints are not being followed! "
        f"Valid categories: {FINDING_CATEGORIES}. Finding will be REMOVED."
    )
    return None


def get_domain_from_url(url: str) -> str:
    """Extract domain from URL."""
    parsed = urlparse(url)
    return parsed.netloc


async def generate_persona_summary(
    output_dir: str,
    persona_id: str,
    persona_description: str,
    transcript: list[ConversationTurn],
    final_url: str,
    persona_instance: str | None = None,
    test_suite_config: dict | None = None,
) -> None:
    """
    Generate a summary of the conversation analyzing persona goal achievement.

    Args:
        output_dir: Directory to save the summary
        persona_id: The persona identifier that was used
        persona_description: Full persona description from markdown file
        transcript: List of conversation turns
        final_url: URL where conversation took place
        persona_instance: Optional unique instance identifier (e.g., 'malicious_user_01')
        test_suite_config: Optional test suite configuration for consolidation priorities
    """
    logger.info(f"Generating summary for persona '{persona_id}'...")

    try:
        # Create LLM with increased token limit for summary generation
        # Summary responses can be very large (10K+ tokens) so we use 64K (Claude Sonnet 4 limit)
        llm = create_chat_model()

        # Prepare transcript text with evaluation details embedded
        # Include explicit turn numbers to help LLM correctly identify turns
        # Also collect per-turn findings for preservation in summary.json
        # Build turn_number -> turn_id map for post-processing LLM output
        transcript_lines = []
        per_turn_findings: list[dict] = []
        turn_number_to_turn_id: dict[int, str] = {}
        turn_number = 0
        for t in transcript:
            # Calculate turn number (each user+assistant pair is one turn)
            # Turn increments on user messages
            if t.role.lower() == "user":
                turn_number += 1
                # Include turn_id (UUID) for precise finding matching
                turn_id_suffix = f" (id: {t.id})" if t.id else ""
                transcript_lines.append(
                    f"[TURN {turn_number}]{turn_id_suffix} USER: {t.text}"
                )
            else:
                # Include turn_id for assistant messages too
                turn_id_suffix = f" (id: {t.id})" if t.id else ""
                transcript_lines.append(
                    f"[TURN {turn_number}]{turn_id_suffix} ASSISTANT: {t.text}"
                )
                # Map turn_number to assistant's turn_id (for post-processing LLM findings)
                if t.id and turn_number > 0:
                    turn_number_to_turn_id[turn_number] = t.id

            # Embed evaluation details if available and collect for per_turn_findings
            if t.evals:
                eval_details = []
                for result in t.evals:
                    # Collect raw finding for preservation
                    per_turn_findings.append(result)

                    # Use agent_id (new) or fall back to validation_id (legacy)
                    agent_id = result.get("agent_id") or result.get(
                        "validation_id", "unknown"
                    )
                    score = result.get("score", 0)
                    # Use explanation (new) or fall back to result_explanation (legacy)
                    explanation = result.get("explanation") or result.get(
                        "result_explanation", ""
                    )
                    confidence = result.get("confidence", 0)
                    category = result.get("category", "")
                    title = result.get("title", "")

                    eval_line = f"  [EVAL agent_id={agent_id}] {category}: {title} | Score: {score:.0f}/100, Confidence: {confidence:.0%}"
                    if explanation:
                        eval_line += f" - {explanation}"
                    eval_details.append(eval_line)

                transcript_lines.append("\n".join(eval_details))

        transcript_text = "\n\n".join(transcript_lines)

        # Sanitize markdown image references from chatbot responses so prompty's
        # parser doesn't try to inline them as local files (e.g. ![](/frontier/assets/X.png))
        transcript_text = re.sub(
            r"!\[([^\]]*)\]\([^)]+\)", r"[image: \1]", transcript_text
        )

        logger.info(
            f"Prepared transcript with {turn_number} turns, {len([t for t in transcript if t.evals])} evaluated"
        )

        # Extract allowed_disclosures from test_suite_config
        allowed_disclosures_list = []
        if test_suite_config:
            allowed_disclosures_list = test_suite_config.get("allowed_disclosures", [])
        allowed_disclosures_text = ""
        if allowed_disclosures_list:
            allowed_disclosures_text = "\n".join(
                f"- {disclosure}" for disclosure in allowed_disclosures_list
            )
            logger.info(
                f"Including {len(allowed_disclosures_list)} allowed disclosures in analysis prompt"
            )

        # Build valid agent_ids string from registry
        valid_agent_ids_text = ""
        try:
            from core.multiagent.registry import get_agent_registry

            registry = get_agent_registry()
            valid_agent_ids_text = ", ".join(sorted(registry.get_agent_ids()))
        except Exception:
            valid_agent_ids_text = (
                "goal_completion, compliance, ux, hallucination, data_leakage"
            )

        # Load analysis prompt from Prompty file
        analysis_prompt = load_prompt(
            "chat_runner_analysis",
            persona_description=persona_description,
            transcript_text=transcript_text,
            finding_categories=FINDING_CATEGORY_DESCRIPTIONS,
            threshold_pass=SCORE_THRESHOLD_PASS,
            threshold_good=SCORE_THRESHOLD_GOOD,
            allowed_disclosures=allowed_disclosures_text,
            valid_agent_ids=valid_agent_ids_text,
        )

        # Get analysis from Claude with retry for rate limiting and empty responses
        from browser_use.llm.messages import UserMessage

        # Time LLM analysis call
        llm_analysis_start = time.time()

        max_retries = 3
        last_error = None
        for attempt in range(max_retries):
            try:
                response = await llm.ainvoke([UserMessage(content=analysis_prompt)])
                analysis = response.completion

                # Check for empty response - treat as transient error and retry
                if not analysis or len(analysis.strip()) == 0:
                    wait_time = 2 ** (attempt + 1)
                    logger.warning(
                        f"Empty response for {persona_id} (attempt {attempt + 1}/{max_retries}), "
                        f"retrying in {wait_time}s..."
                    )
                    last_error = ValueError(f"Empty LLM response for {persona_id}")
                    await asyncio.sleep(wait_time)
                    continue

                break  # Success
            except Exception as e:
                error_str = str(e)
                if "429" in error_str or "RESOURCE_EXHAUSTED" in error_str:
                    wait_time = 2 ** (attempt + 1)  # Exponential backoff: 2, 4, 8s
                    logger.warning(
                        f"Rate limited for {persona_id} (attempt {attempt + 1}/{max_retries}), "
                        f"retrying in {wait_time}s..."
                    )
                    last_error = e
                    await asyncio.sleep(wait_time)
                    continue
                raise  # Non-retryable error
        else:
            raise last_error  # type: ignore[misc]

        llm_analysis_duration = time.time() - llm_analysis_start

        from utils.timing_logger import log_timing

        log_timing(
            "llm_persona_analysis",
            llm_analysis_duration,
            {"persona": persona_instance or persona_id, "turns": turn_number},
        )

        logger.info(
            f"Generated analysis: {len(analysis)} characters in {llm_analysis_duration:.2f}s"
        )

        # Extract session_id and conversation_id from output_dir
        # output_dir is typically: sessions/<session_id>/<persona_instance_name>
        # e.g., sessions/conversation_20260117_101103/travel_last_minute_traveler_user
        persona_folder_name = Path(output_dir).name
        session_id = persona_folder_name  # Default to folder name
        # Build conversation_id for sub-agent state lookup - must match what evaluate_turn uses
        # This is: <parent_session>_<persona_folder_name>
        parts = Path(output_dir).parts
        if len(parts) >= 2:
            parent_session = parts[-2]  # e.g., "conversation_20260117_101103"
            session_id = parent_session  # For logging/monitoring purposes
            # The conversation_id must match what was used in evaluate_turn
            conversation_id = f"{parent_session}_{persona_folder_name}"
        else:
            conversation_id = persona_folder_name

        # Send to AratoMonitor if configured via environment variables
        monitor = AratoMonitor.get_instance()
        if monitor:
            monitor.send(
                prompt_name="chat_runner_analysis",
                llm_response=response,
                prompt_content=analysis_prompt,
                session_id=session_id,
                persona_id=persona_id,
                target_url=final_url,
                variables={
                    "persona_id": persona_id,
                    "session_id": session_id,
                    "persona_description": persona_description,
                    "transcript_text": transcript_text,
                },
            )

        # Parse JSON from response
        cleaned = analysis.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()

        # Find JSON object boundaries
        start_idx = cleaned.find("{")
        if start_idx == -1:
            logger.error(f"No JSON object found in LLM response for {persona_id}")
            logger.error(f"Response preview: {cleaned[:500]}...")
            raise ValueError(
                f"No JSON object found in LLM response for {persona_id}. "
                f"Response started with: {cleaned[:100]}..."
            )

        # Extract and parse JSON with json-repair library
        json_str = cleaned[start_idx:]
        analysis_json = None

        # Strategy 1: Direct parse
        try:
            analysis_json = json.loads(json_str)
            logger.info("✅ Successfully parsed JSON (direct)")
        except json.JSONDecodeError as e:
            logger.warning(f"Direct JSON parse failed: {e}")

            # Strategy 2: Use json-repair library (robust commercial-grade repair)
            try:
                from json_repair import repair_json

                logger.info("Attempting JSON repair with json-repair library...")
                repaired_str = repair_json(json_str)
                analysis_json = json.loads(repaired_str)
                logger.info("✅ Successfully parsed JSON (json-repair library)")
            except Exception as repair_error:
                logger.error(f"json-repair library failed: {repair_error}")
                logger.error(f"Response preview: {analysis[:500]}...")
                raise ValueError(
                    f"Failed to parse LLM JSON response even with json-repair library: {e}"
                ) from e

        # Calculate severity and status fields that were removed from LLM output
        # Also filter out findings with invalid categories
        if analysis_json and "findings" in analysis_json:
            valid_findings = []
            removed_count = 0
            for finding in analysis_json["findings"]:
                # Validate category - returns None if invalid
                validated_category = _validate_category(finding.get("category"))
                if validated_category is None:
                    removed_count += 1
                    continue  # Skip this finding

                finding["category"] = validated_category

                eval_res = finding.get("evaluation_results", {})
                # Try quality (new) then score (old)
                score = eval_res.get("quality", eval_res.get("score", 0))

                # Determine Label and Status using shared logic
                label = calculate_label(score)
                status_bool = calculate_status(score)

                # Determine Status (PASS/FAIL) for evaluation_results
                eval_status = "PASS" if status_bool else "FAIL"

                # Normalize confidence to 0-1 range if needed (e.g. if LLM returned 85 instead of 0.85)
                confidence = eval_res.get("confidence", 0)
                if confidence > 1.0:
                    eval_res["confidence"] = confidence / 100.0

                # Inject calculated fields
                finding["label"] = label
                eval_res["status"] = eval_status
                valid_findings.append(finding)

            if removed_count > 0:
                logger.error(
                    f"🚨 REMOVED {removed_count} findings with invalid categories "
                    f"(LLM not following category constraints in prompt)"
                )

            # Post-process LLM findings to fix turn_id
            # LLMs often output "Turn 7" instead of actual UUID, so we fix it here
            # Also normalize evidence field to dict (LLM sometimes returns a string)
            fixed_turn_id_count = 0
            for finding in valid_findings:
                evidence = finding.get("evidence", {})
                if not isinstance(evidence, dict):
                    # LLM returned evidence as a string instead of a dict;
                    # preserve the text as a description and replace with a proper dict
                    finding["evidence"] = {
                        "description": str(evidence) if evidence else ""
                    }
                    evidence = finding["evidence"]

                current_turn_id = evidence.get("turn_id")
                turn_num = evidence.get("turn_number")

                # Check if turn_id is invalid (not a UUID - e.g., "Turn 7")
                is_valid_uuid = (
                    current_turn_id
                    and isinstance(current_turn_id, str)
                    and len(current_turn_id) == 36
                    and "-" in current_turn_id
                )

                # If turn_id is invalid but we have turn_number, fix it
                if (
                    not is_valid_uuid
                    and turn_num
                    and turn_num in turn_number_to_turn_id
                ):
                    evidence["turn_id"] = turn_number_to_turn_id[turn_num]
                    fixed_turn_id_count += 1

            if fixed_turn_id_count > 0:
                logger.info(
                    f"🔧 Fixed turn_id for {fixed_turn_id_count} findings using turn_number lookup"
                )

            analysis_json["findings"] = valid_findings

        # Run SUMMARIZE_CONVERSATION from sub-agents
        # These are conversation-level findings (not per-turn) that belong in summary.json
        conversation_summary_findings: list[dict] = []
        try:
            from core.multiagent import get_agent_registry

            agent_registry = get_agent_registry()
            # Construct transcript path from output_dir
            transcript_path = str(Path(output_dir) / "transcript.json")
            # Convert ConversationTurn objects to dicts for in-memory passing
            transcript_dicts = [
                {
                    "id": t.id,  # UUID for precise turn matching
                    "turn_number": (i // 2) + 1,  # User+assistant pairs make turns
                    "role": t.role,
                    "user_message": t.text if t.role.lower() == "user" else "",
                    "bot_response": t.text if t.role.lower() != "user" else "",
                }
                for i, t in enumerate(transcript)
            ]
            # Time sub-agent summarize conversation
            summarize_start = time.time()
            summary_findings = await agent_registry.summarize_conversation(
                conversation_id=conversation_id,
                persona_id=persona_id,
                target_url=final_url,
                app_context=persona_description,  # Use persona description as context
                transcript_path=transcript_path,
                total_turns=turn_number,
                transcript_data=transcript_dicts,
                test_suite_config=test_suite_config,
            )
            summarize_duration = time.time() - summarize_start

            from utils.timing_logger import log_timing

            log_timing(
                "sub_agent_summarize_conversation",
                summarize_duration,
                {
                    "persona": persona_instance or persona_id,
                    "num_findings": len(summary_findings) if summary_findings else 0,
                },
            )

            if summary_findings:
                conversation_summary_findings = [f.to_dict() for f in summary_findings]
                logger.info(
                    f"📊 SUMMARIZE_CONVERSATION: {len(summary_findings)} findings from sub-agents in {summarize_duration:.2f}s"
                )
        except Exception as e:
            logger.warning(f"⚠️ Failed SUMMARIZE_CONVERSATION evaluation: {e}")

        # Merge all findings into analysis.findings:
        # 1. LLM-generated findings (from analysis_json)
        # 2. Per-turn findings from EVALUATE_TURN (from transcript)
        # 3. Conversation summary findings from SUMMARIZE_CONVERSATION
        all_findings = []
        if analysis_json and "findings" in analysis_json:
            all_findings.extend(analysis_json["findings"])
        all_findings.extend(per_turn_findings)
        all_findings.extend(conversation_summary_findings)

        # Unified LLM-based consolidation:
        # 1. First consolidates per-turn (MAX_FINDINGS_PER_TURN per turn)
        # Uses LLM to merge similar findings so no important information is lost
        from utils.timing_logger import log_timing
        from utils.turn_finding_consolidation import consolidate_all_findings

        # Time finding consolidation
        consolidation_start = time.time()
        consolidated_findings = await consolidate_all_findings(
            findings=all_findings,
            test_suite_config=test_suite_config,
        )
        consolidation_duration = time.time() - consolidation_start

        log_timing(
            "finding_consolidation",
            consolidation_duration,
            {
                "persona": persona_instance or persona_id,
                "total_findings": len(all_findings),
                "consolidated": len(consolidated_findings),
            },
        )

        # Update analysis_json with consolidated findings
        if analysis_json:
            analysis_json["findings"] = consolidated_findings

        # Log TLDR if generated by main LLM call
        if analysis_json and analysis_json.get("tldr"):
            logger.info(f"✅ TLDR generated: {len(analysis_json['tldr'])} characters")

        # Wrap in complete structure
        complete_analysis = {
            "conversation_metadata": {
                "url": final_url,
                "persona": persona_id,
                "persona_instance": persona_instance,
                "date": datetime.now(UTC).isoformat(),
                "total_turns": calculate_turn_count(transcript),
                "total_messages": len(transcript),
                "user_messages": len([t for t in transcript if t.role == "user"]),
                "assistant_responses": len(
                    [t for t in transcript if t.role == "assistant"]
                ),
            },
            "analysis": analysis_json,
        }

        # Save complete JSON structure
        summary = json.dumps(complete_analysis, indent=2, ensure_ascii=False)

        # Ensure output directory exists
        # Use os.makedirs instead of Path.mkdir to avoid potential path resolution issues
        os.makedirs(output_dir, exist_ok=True)

        output_path = Path(output_dir)
        summary_file = output_path / SUMMARY_FILENAME
        save_text_file(summary, summary_file)

        logger.info(f"✅ Summary saved to {summary_file}")

    except Exception as e:
        logger.error(f"Failed to generate summary: {e}")
        import traceback

        logger.error(traceback.format_exc())
        raise
