"""
Utility functions for loading and rendering Prompty templates.
"""

from pathlib import Path
from typing import Any

import prompty


def load_prompt(prompt_name: str, **inputs: Any) -> str:
    """
    Load and render a Prompty template with the given inputs.

    Args:
        prompt_name: Name of the .prompty file (without extension)
        **inputs: Variables to pass to the template

    Returns:
        Rendered prompt as a string (all messages concatenated)

    Example:
        >>> prompt = load_prompt('app_context_discovery_task', target_url='https://example.com')
    """
    prompts_dir = Path(__file__).parent.parent / "prompts"
    prompt_file = prompts_dir / f"{prompt_name}.prompty"

    if not prompt_file.exists():
        raise FileNotFoundError(f"Prompt file not found: {prompt_file}")

    # Load the prompty file
    prompty_obj = prompty.load(str(prompt_file))

    # Prepare (render) the prompt with inputs
    # Returns a list of message dicts with 'role' and 'content' keys
    rendered = prompty.prepare(prompty_obj, inputs)

    # Concatenate all messages into a single prompt string
    if isinstance(rendered, list) and len(rendered) > 0:
        parts = []
        for message in rendered:
            if isinstance(message, dict) and "content" in message:
                parts.append(str(message["content"]))
        if parts:
            return "\n\n".join(parts)

    # Fallback if structure is unexpected
    return str(rendered)
