"""
Report data generation utility.

This module extracts structured data from persona testing results and LLM summaries,
creating a report_data.json file that can be reused for HTML generation without
re-running the LLM.

Migration: Now supports both JSON-based extraction (preferred) and legacy markdown parsing.
"""

import asyncio
import json
import logging
import re
import uuid
from pathlib import Path

# Import type for type hints only (avoid circular imports)
from typing import TYPE_CHECKING, Any
from urllib.parse import urljoin, urlparse

import httpx
import json_repair
import prompty
from browser_use.llm.messages import SystemMessage, UserMessage

from constants import (
    CROSS_CONVERSATION_FINDINGS_FILENAME,
    FINDING_CATEGORIES,
    FINDING_CATEGORY_DESCRIPTIONS,
    GENERIC_PERSONA_IDS,
    ICON_NAME_SUCCESS,
    ICON_NAME_WARNING,
    MAX_KEY_FINDING_GROUPS,
    REPORT_DATA_FILENAME,
    SCORE_COLOR_CRITICAL,
    SCORE_COLOR_GOOD,
    SCORE_COLOR_WARNING,
    SCORE_LABEL_CRITICAL,
    SCORE_LABEL_GOOD,
    SCORE_LABEL_WARNING,
    SCORE_THRESHOLD_GOOD,
    SCORE_THRESHOLD_PASS,
    STATUS_BG_CRITICAL,
    STATUS_BG_GOOD,
    STATUS_BG_WARNING,
    STATUS_OUTER_CRITICAL,
    STATUS_OUTER_GOOD,
    STATUS_OUTER_WARNING,
    TRANSCRIPT_FILENAME,
)
from core.llm.base import LLMAdapter
from models.conversation_turn import calculate_turn_count_from_raw
from utils.data_validation import (
    safe_float,
    safe_get,
    safe_int,
    safe_str,
    sanitize_findings_list,
)
from utils.eu_ai_act_compliance import assess_eu_ai_act_compliance
from utils.executive_summary import generate_executive_summary_from_findings
from utils.file_utils import get_local_logo_data_uri
from utils.scoring import calculate_label
from utils.stats import calculate_dynamic_distribution

if TYPE_CHECKING:
    from utils.config_loader import TestSuite

logger = logging.getLogger(__name__)


def _validate_category(category: str | None) -> str | None:
    """Validate a category against FINDING_CATEGORIES.

    Returns the category if valid, None if invalid (finding should be removed).
    NO MAPPING - if the category is wrong, the finding is removed.

    Args:
        category: The category name to validate

    Returns:
        The category if valid, None if invalid
    """
    if not category:
        logger.error(
            f"🚨 Finding has NO category. Valid: {FINDING_CATEGORIES}. "
            "Finding will be REMOVED."
        )
        return None

    if category in FINDING_CATEGORIES:
        return category

    logger.error(
        f"🚨 INVALID category: '{category}'. Valid: {FINDING_CATEGORIES}. "
        "Finding will be REMOVED."
    )
    return None


def _get_valid_agent_ids() -> set[str]:
    """Get the set of valid agent IDs from the registry.

    Returns:
        Set of valid agent IDs, or empty set if registry unavailable
    """
    try:
        from core.multiagent.registry import get_agent_registry

        registry = get_agent_registry()
        return set(registry.get_agent_ids())
    except Exception:
        return set()


def _validate_agent_id(
    agent_id: str | None, valid_ids: set[str] | None = None
) -> str | None:
    """Validate an agent_id against valid agent IDs.

    Returns the agent_id if valid, None if invalid (finding should be removed).
    NO MAPPING - if the agent_id is wrong, the finding is removed.

    Args:
        agent_id: The agent ID to validate
        valid_ids: Optional set of valid IDs (will be fetched if not provided)

    Returns:
        The agent_id if valid, None if invalid
    """
    if valid_ids is None:
        valid_ids = _get_valid_agent_ids()

    # If we couldn't get valid IDs, don't filter (allow all)
    if not valid_ids:
        return agent_id

    if not agent_id:
        logger.warning(
            f"⚠️ Finding has NO agent_id. Valid: {sorted(valid_ids)}. "
            "Finding will be REMOVED."
        )
        return None

    if agent_id in valid_ids:
        return agent_id

    logger.error(
        f"🚨 INVALID agent_id: '{agent_id}'. Valid: {sorted(valid_ids)}. "
        "Finding will be REMOVED."
    )
    return None


def build_allowed_disclosures_string(test_suite: "TestSuite | None") -> str:
    """Build a formatted string of allowed disclosures for prompty templates.

    Extracts allowed_disclosures from the test suite config and formats them
    as a bulleted list for use in prompty templates. This tells the LLM which
    types of data the test user is AUTHORIZED to see (e.g., admin users).

    Args:
        test_suite: Optional TestSuite object with allowed_disclosures list

    Returns:
        Formatted string with allowed disclosures, or empty string if none
    """
    if test_suite is None:
        return ""

    allowed_disclosures = getattr(test_suite, "allowed_disclosures", [])
    if not allowed_disclosures:
        return ""

    lines = []
    for disclosure in allowed_disclosures:
        if isinstance(disclosure, str) and disclosure.strip():
            lines.append(f"- {disclosure.strip()}")

    if not lines:
        return ""

    return "\n".join(lines)


def _get_valid_agent_ids_string() -> str:
    """Get a formatted string of valid agent IDs from the registry.

    This is used in consolidation prompts to prevent LLM from inventing
    fake agent IDs like "summary" or "security_compliance_agent".

    Returns:
        Formatted string with valid agent IDs, or empty string if registry unavailable
    """
    try:
        from core.multiagent.registry import get_agent_registry

        registry = get_agent_registry()
        agent_ids = registry.get_agent_ids()
        if agent_ids:
            return "\n".join(f"- {agent_id}" for agent_id in agent_ids)
    except Exception:
        # Registry not available, return empty string
        pass
    return ""


def build_test_suite_priorities(test_suite: "TestSuite | None") -> str:
    """Build a JSON string of test suite priorities for prompty templates.

    Extracts questions_to_answer and key_risks from the test suite config
    and formats them for use in prompty templates.

    Args:
        test_suite: Optional TestSuite object with questions and risks

    Returns:
        JSON string with priorities, or empty string if no priorities
    """
    if test_suite is None:
        return ""

    priorities: dict[str, Any] = {}

    # Extract questions with priority
    questions = getattr(test_suite, "questions_to_answer", [])
    if questions:
        priorities["questions_to_answer"] = [
            {
                "id": q.get("id", ""),
                "question": q.get("question", ""),
                "priority": q.get("priority", "normal"),
            }
            for q in questions
            if isinstance(q, dict)
        ]

    # Extract key risks with priority
    risks = getattr(test_suite, "key_risks", [])
    if risks:
        priorities["key_risks"] = [
            {
                "id": r.get("id", ""),
                "name": r.get("name", ""),
                "priority": r.get("priority", "normal"),
            }
            for r in risks
            if isinstance(r, dict)
        ]

    if not priorities:
        return ""

    return json.dumps(priorities, indent=2)


def _extract_common_domain(urls: list[str]) -> str:
    """Extract the common top-level domain from a list of URLs.

    For URLs with the same domain, returns that domain.
    For URLs with different subdomains, returns the common parent domain.
    Falls back to first URL's domain if no commonality found.

    Args:
        urls: List of URLs to analyze

    Returns:
        Common domain string, or first URL's domain if no common pattern

    Examples:
        ["https://a.example.com", "https://b.example.com"] -> "example.com"
        ["https://app.staging.example.com"] -> "app.staging.example.com"
        ["https://foo.com", "https://bar.com"] -> "foo.com"  # fallback
    """
    if not urls:
        return ""

    # Extract domains from all URLs
    domains = []
    for url in urls:
        try:
            parsed = urlparse(url)
            domain = parsed.netloc
            if domain:
                domains.append(domain)
        except Exception:
            continue

    if not domains:
        return ""

    if len(domains) == 1:
        return domains[0]

    # Split each domain into parts and find common suffix
    domain_parts = [d.split(".") for d in domains]

    # Find the longest common suffix among all domains
    min_parts = min(len(parts) for parts in domain_parts)
    common_suffix = []

    for i in range(1, min_parts + 1):
        # Get the i-th part from the end of each domain
        parts_at_position = [parts[-i] for parts in domain_parts]
        if len(set(parts_at_position)) == 1:
            # All domains have the same part at this position
            common_suffix.insert(0, parts_at_position[0])
        else:
            break

    if common_suffix:
        return ".".join(common_suffix)

    # Fallback to first domain
    return domains[0]


def _generate_scoring_metadata() -> dict[str, Any]:
    """Generate scoring metadata with constants for the HTML renderer.

    This centralizes all scoring decisions (thresholds, labels, colors) so the
    HTML generator can be a pure renderer without business logic.

    Returns:
        Dictionary containing scoring and category metadata for report rendering.
    """
    return {
        "scoring": {
            "thresholds": {
                "good": SCORE_THRESHOLD_GOOD,  # Score >= 75 -> Good
                "pass": SCORE_THRESHOLD_PASS,  # Score >= 20 -> Pass (Warning)
                # Score < 20 -> Critical (Fail)
            },
            "labels": {
                "good": SCORE_LABEL_GOOD,
                "warning": SCORE_LABEL_WARNING,
                "critical": SCORE_LABEL_CRITICAL,
            },
            "colors": {
                "good": SCORE_COLOR_GOOD,
                "warning": SCORE_COLOR_WARNING,
                "critical": SCORE_COLOR_CRITICAL,
            },
            # Pre-computed color mappings for common use cases
            "color_by_label": {
                SCORE_LABEL_GOOD.lower(): SCORE_COLOR_GOOD,
                SCORE_LABEL_WARNING.lower(): SCORE_COLOR_WARNING,
                SCORE_LABEL_CRITICAL.lower(): SCORE_COLOR_CRITICAL,
            },
            # Color types for badge rendering (critical/warning/good)
            "color_types": {
                "critical": {
                    "outer": STATUS_OUTER_CRITICAL,
                    "bg": STATUS_BG_CRITICAL,
                    "foreground": SCORE_COLOR_CRITICAL,
                    "icon": "🔴",
                    "icon_class": "ph-warning",
                    "icon_name": ICON_NAME_WARNING,
                    "priority": 1,
                },
                "warning": {
                    "outer": STATUS_OUTER_WARNING,
                    "bg": STATUS_BG_WARNING,
                    "foreground": SCORE_COLOR_WARNING,
                    "icon": "🟡",
                    "icon_class": "ph-warning-circle",
                    "icon_name": ICON_NAME_WARNING,
                    "priority": 2,
                },
                "good": {
                    "outer": STATUS_OUTER_GOOD,
                    "bg": STATUS_BG_GOOD,
                    "foreground": SCORE_COLOR_GOOD,
                    "icon": "🟢",
                    "icon_class": "ph-check-circle",
                    "icon_name": ICON_NAME_SUCCESS,
                    "priority": 3,
                },
            },
        },
        "categories": {
            "list": FINDING_CATEGORIES,
            "descriptions": FINDING_CATEGORY_DESCRIPTIONS,
        },
    }


METRIC_INFO = {
    "factuality": {
        "label": "Factuality",
        "description": "Measures if response claims are supported by context and general knowledge.",
    },
    "coherence": {
        "label": "Coherence",
        "description": "Assesses if responses are logically sound and contradiction-free.",
    },
    "tone_adherence": {
        "label": "Tone",
        "description": "Evaluates adherence to expected professional tone or persona guidelines.",
    },
    "instruction_following": {
        "label": "Instruction Following",
        "description": "Measures ability to follow complex user instructions or constraints.",
    },
    "topic_coverage": {
        "label": "Coverage",
        "description": "Indicates comprehensiveness in covering expected topics.",
    },
    "context_retention": {
        "label": "Context Retention",
        "description": "Depth of conversation memory (how many turns back facts are recalled).",
    },
    "turn_to_resolution": {
        "label": "Resolution",
        "description": "Efficiency measure: Optimal Turns / Actual Turns.",
    },
    "aes_score": {
        "label": "Agent Expertise",
        "description": "Composite score measuring the testing agent's capability (Lexical Specificity, Taxonomy Coverage, Constraint Density, Contextual Continuity).",
    },
}


def _fetch_favicon_url(target_url: str) -> str | None:
    """
    Fetch the favicon URL from a website.

    Tries multiple common favicon locations:
    1. /favicon.ico
    2. Link tags in HTML with rel="icon" or rel="shortcut icon"
    3. Apple touch icon

    Args:
        target_url: The target URL to fetch favicon from

    Returns:
        Absolute URL to the favicon, or None if not found
    """
    try:
        parsed = urlparse(target_url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        # First, try the standard /favicon.ico location
        favicon_url = urljoin(base_url, "/favicon.ico")
        try:
            with httpx.Client(timeout=5.0, follow_redirects=True) as client:
                response = client.head(favicon_url)
                if response.status_code == 200:
                    logger.info(f"Found favicon at: {favicon_url}")
                    return favicon_url
        except Exception:
            pass

        # If that doesn't work, try parsing the HTML for link tags
        try:
            with httpx.Client(timeout=10.0, follow_redirects=True) as client:
                response = client.get(target_url)
                if response.status_code == 200:
                    html = response.text

                    # Match various icon link patterns
                    patterns = [
                        r'<link[^>]*rel=["\'](?:shortcut )?icon["\'][^>]*href=["\']([^"\'>]+)["\']',
                        r'<link[^>]*href=["\']([^"\'>]+)["\'][^>]*rel=["\'](?:shortcut )?icon["\']',
                        r'<link[^>]*rel=["\']apple-touch-icon["\'][^>]*href=["\']([^"\'>]+)["\']',
                    ]

                    for pattern in patterns:
                        match = re.search(pattern, html, re.IGNORECASE)
                        if match:
                            icon_path = match.group(1)
                            # Make absolute URL
                            if icon_path.startswith(("http://", "https://")):
                                favicon_url = icon_path
                            else:
                                favicon_url = urljoin(base_url, icon_path)
                            logger.info(f"Found favicon from HTML: {favicon_url}")
                            return favicon_url
        except Exception as e:
            logger.debug(f"Failed to parse HTML for favicon: {e}")

        # Fallback: return the standard favicon.ico path even if we couldn't verify it
        favicon_url = urljoin(base_url, "/favicon.ico")
        logger.info(f"Using fallback favicon URL: {favicon_url}")
        return favicon_url

    except Exception as e:
        logger.warning(f"Failed to fetch favicon for {target_url}: {e}")
        return None


# ==============================================================================
# JSON-BASED EXTRACTION FUNCTIONS (Phase 1 Migration)
# ==============================================================================


def _filter_findings_with_invalid_turns(
    findings: list[dict[str, Any]],
    conversations: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Filter out findings with invalid turn numbers.

    Findings with turn_number that exceeds the actual conversation length
    are discarded entirely (not clamped) to prevent incorrect data association.

    Args:
        findings: List of finding dictionaries with evidence.turn_number
        conversations: List of conversation dictionaries with transcript

    Returns:
        Filtered list of findings with only valid turn numbers
    """
    # Build a map of persona_id -> max valid turn number
    persona_max_turns: dict[str, int] = {}
    for conv in conversations:
        persona_id = conv.get("persona_id", "")
        transcript = conv.get("transcript", [])
        # Each turn = 1 user + 1 assistant message (accounting for welcome message)
        max_turn = calculate_turn_count_from_raw(transcript)
        persona_max_turns[persona_id] = max_turn

    valid_findings = []
    clamped_count = 0

    for finding in findings:
        # Get the finding's source persona and turn number
        source = finding.get("source", "")
        evidence = finding.get("evidence") or {}
        # Turn number can be in evidence.turn_number OR at top level
        turn_number = (
            evidence.get("turn_number")
            if isinstance(evidence, dict)
            else finding.get("turn_number")
        ) or finding.get("turn_number")

        # If no turn number, keep the finding (can't validate)
        if turn_number is None:
            valid_findings.append(finding)
            continue

        # Get max turn for this persona
        max_turn = persona_max_turns.get(source, 0)

        # Clamp turn number to valid range instead of discarding
        # This preserves valuable finding content even if LLM miscounted turns
        if turn_number >= 1 and turn_number <= max_turn:
            valid_findings.append(finding)
        elif max_turn > 0:
            # Clamp to max valid turn
            clamped_turn = min(max(1, turn_number), max_turn)
            clamped_count += 1
            logger.debug(
                f"Clamped turn_number={turn_number} to {clamped_turn} "
                f"(max={max_turn}) for persona '{source}': {finding.get('title', 'Unknown')}"
            )
            # Update the finding with clamped turn number
            finding_copy = finding.copy()
            if "evidence" in finding_copy and finding_copy["evidence"]:
                finding_copy["evidence"] = finding_copy["evidence"].copy()
                finding_copy["evidence"]["turn_number"] = clamped_turn
            valid_findings.append(finding_copy)
        else:
            # No valid turns for this persona, keep finding without modification
            valid_findings.append(finding)

    if clamped_count > 0:
        logger.info(
            f"📍 Clamped {clamped_count} findings with out-of-range turn numbers "
            f"(total {len(valid_findings)} findings)"
        )

    return valid_findings


def _filter_findings_with_invalid_turns(
    findings: list[dict[str, Any]],
    conversations: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Validate and clamp findings with invalid turn numbers.

    Findings with turn_number that exceeds the actual conversation length
    are clamped to the max valid turn to preserve valuable finding content
    while fixing the turn reference.

    Args:
        findings: List of finding dictionaries with evidence.turn_number
        conversations: List of conversation dictionaries with transcript

    Returns:
        List of findings with validated/clamped turn numbers
    """
    # Build a map of persona_id -> max valid turn number
    persona_max_turns: dict[str, int] = {}
    for conv in conversations:
        persona_id = conv.get("persona_id", "")
        transcript = conv.get("transcript", [])
        # Each turn = 1 user + 1 assistant message (accounting for welcome message)
        max_turn = calculate_turn_count_from_raw(transcript)
        persona_max_turns[persona_id] = max_turn

    valid_findings = []
    clamped_count = 0

    for finding in findings:
        # Get the finding's source persona and turn number
        source = finding.get("source", "")
        evidence = finding.get("evidence") or {}
        # Turn number can be in evidence.turn_number OR at top level
        turn_number = (
            evidence.get("turn_number")
            if isinstance(evidence, dict)
            else finding.get("turn_number")
        ) or finding.get("turn_number")

        # If no turn number, keep the finding (can't validate)
        if turn_number is None:
            valid_findings.append(finding)
            continue

        # Get max turn for this persona
        max_turn = persona_max_turns.get(source, 0)

        # Clamp turn number to valid range instead of discarding
        # This preserves valuable finding content even if LLM miscounted turns
        if turn_number >= 1 and turn_number <= max_turn:
            valid_findings.append(finding)
        elif max_turn > 0:
            # Clamp to max valid turn
            clamped_turn = min(max(1, turn_number), max_turn)
            clamped_count += 1
            logger.debug(
                f"Clamped turn_number={turn_number} to {clamped_turn} "
                f"(max={max_turn}) for persona '{source}': {finding.get('title', 'Unknown')}"
            )
            # Update the finding with clamped turn number
            finding_copy = finding.copy()
            if "evidence" in finding_copy and finding_copy["evidence"]:
                finding_copy["evidence"] = finding_copy["evidence"].copy()
                finding_copy["evidence"]["turn_number"] = clamped_turn
            valid_findings.append(finding_copy)
        else:
            # No valid turns for this persona, keep finding without modification
            valid_findings.append(finding)

    if clamped_count > 0:
        logger.info(
            f"📍 Clamped {clamped_count} findings with out-of-range turn numbers "
            f"(total {len(valid_findings)} findings)"
        )

    return valid_findings


def _load_persona_summaries(
    session_dir: str, persona_ids: list[str]
) -> list[dict[str, Any]]:
    """Load summary.json files from all persona directories.

    Args:
        session_dir: Session directory path
        persona_ids: List of persona IDs to load

    Returns:
        List of parsed summary.json dictionaries
    """
    summaries = []
    session_path = Path(session_dir)

    for persona_id in persona_ids:
        persona_dir = session_path / persona_id
        summary_path = persona_dir / "summary.json"

        if summary_path.exists():
            try:
                with open(summary_path, encoding="utf-8") as f:
                    summary_data = json.load(f)
                    summary_data["_persona_id"] = persona_id  # Add for reference
                    summary_data["_session_dir"] = str(
                        session_path
                    )  # Add session dir for transcript access
                    summaries.append(summary_data)
                    logger.debug(f"Loaded summary.json for {persona_id}")
            except Exception as e:
                logger.warning(f"Failed to load summary.json for {persona_id}: {e}")
        else:
            logger.debug(f"No summary.json found for {persona_id} at {summary_path}")

    logger.info(f"Loaded {len(summaries)} persona summaries from JSON")
    return summaries


def _load_cross_conversation_findings(session_dir: str) -> list[dict[str, Any]]:
    """Load cross-conversation findings from JSON file.

    Cross-conversation findings are generated by sub-agents (ComplianceAgent)
    that analyze patterns across multiple conversations.

    Args:
        session_dir: Session directory path

    Returns:
        List of finding dictionaries
    """
    findings_path = Path(session_dir) / CROSS_CONVERSATION_FINDINGS_FILENAME

    if not findings_path.exists():
        logger.debug(f"No cross-conversation findings file at {findings_path}")
        return []

    try:
        with open(findings_path, encoding="utf-8") as f:
            data = json.load(f)

        findings = data.get("findings", [])

        # Convert Finding.to_dict() format to report format if needed
        converted_findings = []
        for finding in findings:
            # For cross-conversation findings, use contributing_sources if available
            contributing = finding.get("contributing_sources", [])
            if contributing and "source" not in finding:
                # Use first contributing source as the primary source (for linking)
                finding["source"] = contributing[0]
                finding["persona_id"] = contributing[0]
                # Store all contributing sources for the instances
                finding["all_contributing_sources"] = contributing
            elif "source" not in finding:
                # Fallback for old data without contributing_sources
                finding["source"] = "Cross-Conversation Analysis"
                finding["persona_id"] = "cross_conversation"

            if "turn_number" not in finding:
                # Cross-conversation findings aren't tied to specific turns
                finding["turn_number"] = None
            converted_findings.append(finding)

        logger.info(f"Loaded {len(converted_findings)} cross-conversation findings")
        return converted_findings

    except Exception as e:
        logger.warning(f"Failed to load cross-conversation findings: {e}")
        return []


def _consolidate_findings_heuristic(
    findings: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Consolidate similar findings across multiple personas using title matching (Fallback).

    Groups findings by (title, category) to identify duplicates.
    Merges sources and tracks occurrences/instances.

    Args:
        findings: List of raw finding dictionaries

    Returns:
        List of consolidated finding dictionaries
    """
    if not findings:
        return []

    consolidated_map = {}
    valid_agent_ids = _get_valid_agent_ids()

    for finding in findings:
        # Validate category - skip findings with invalid categories
        validated_category = _validate_category(finding.get("category"))
        if validated_category is None:
            continue  # Skip this finding

        # Validate agent_id - skip findings with invalid agent_ids
        validated_agent_id = _validate_agent_id(
            finding.get("agent_id"), valid_agent_ids
        )
        if validated_agent_id is None:
            continue  # Skip this finding

        # Create a unique key based on title and validated category
        # Normalize title to lowercase and strip whitespace for matching
        title_key = finding["title"].strip().lower()
        finding["category"] = validated_category
        finding["agent_id"] = validated_agent_id
        key = (title_key, validated_category)

        # Build instance object with source (persona) and turn number
        # Handle evidence that might be None or a dict
        evidence = finding.get("evidence") or {}
        # Turn number can be in evidence.turn_number OR at top level
        turn_number = (
            evidence.get("turn_number")
            if isinstance(evidence, dict)
            else finding.get("turn_number")
        ) or finding.get("turn_number")
        # Determine if this is a turn-level or conversation-level finding
        level = "turn" if turn_number is not None else "conversation"
        instance = {
            "source": finding["source"],
            "turn": turn_number,
            "level": level,
            "evidence": evidence if isinstance(evidence, dict) else {},
        }

        if key not in consolidated_map:
            # First occurrence - initialize consolidated finding
            consolidated_map[key] = finding.copy()
            consolidated_map[key]["count"] = 1
            consolidated_map[key]["sources"] = [finding["source"]]
            consolidated_map[key]["instances"] = [instance]

            # Ensure ID exists
            if "id" not in finding:
                finding["id"] = str(uuid.uuid4())

            # Initialize finding_ids list
            consolidated_map[key]["finding_ids"] = [finding["id"]]

            # Initialize temp lists for stats calculation
            consolidated_map[key]["_scores"] = (
                [finding.get("score")] if finding.get("score") is not None else []
            )
            consolidated_map[key]["_confidences"] = (
                [finding.get("confidence")]
                if finding.get("confidence") is not None
                else []
            )

        else:
            # Duplicate found
            existing = consolidated_map[key]
            existing["count"] += 1
            existing["sources"].append(finding["source"])
            existing["instances"].append(instance)

            # Ensure ID exists
            if "id" not in finding:
                finding["id"] = str(uuid.uuid4())

            # Add finding ID
            existing["finding_ids"].append(finding["id"])

            # Add stats
            if finding.get("score") is not None:
                existing["_scores"].append(finding["score"])
            if finding.get("confidence") is not None:
                existing["_confidences"].append(finding["confidence"])

    # Post-process consolidated findings
    result = []
    for finding in consolidated_map.values():
        unique_sources = sorted(set(finding["sources"]))

        # Always store unique_sources count for frequency-based prioritization
        finding["unique_sources"] = len(unique_sources)
        finding["affected_conversations"] = len(unique_sources)

        # Update source display string
        if len(unique_sources) > 1:
            # If strictly 2 sources, show "A, B"
            # If > 2 sources, show "X personas (A, B, ...)"
            if len(unique_sources) <= 3:
                finding["source"] = ", ".join(unique_sources)
            else:
                finding["source"] = (
                    f"{len(unique_sources)} personas ({', '.join(unique_sources[:3])}...)"
                )
        else:
            finding["source"] = unique_sources[0]

        # Calculate average stats from accumulated lists
        scores = finding.pop("_scores", [])
        if scores:
            finding["score"] = int(sum(scores) / len(scores))
            finding["label"] = calculate_label(finding["score"])
            finding["label"] = calculate_label(finding["score"])

        confidences = finding.pop("_confidences", [])
        if confidences:
            finding["confidence"] = round(sum(confidences) / len(confidences), 1)

        # Remove temporary fields used for consolidation
        finding.pop("sources", None)

        result.append(finding)

    logger.info(
        f"Consolidated {len(findings)} findings into {len(result)} unique issues (Heuristic)"
    )
    return result


def _limit_finding_groups(
    findings: list[dict[str, Any]], max_groups: int
) -> list[dict[str, Any]]:
    """Limit the number of finding groups by selecting the top findings by severity.

    The key findings tab should show the most important/critical findings from the
    already-consolidated results. This function simply sorts by severity (lowest
    score = most critical) and returns the top N findings.

    Args:
        findings: List of consolidated finding dictionaries
        max_groups: Maximum number of groups to return

    Returns:
        List of top findings limited to max_groups
    """
    if len(findings) <= max_groups:
        return findings

    logger.info(f"Selecting top {max_groups} findings from {len(findings)} by severity")

    # Sort by severity: lowest score first (most critical), then by instance count (more = more important)
    sorted_findings = sorted(
        findings, key=lambda x: (x.get("score") or 50, -len(x.get("instances", [])))
    )

    # Return the top N most severe findings
    result = sorted_findings[:max_groups]

    logger.info(f"Selected top {len(result)} findings by severity")
    return result


async def _consolidate_findings_smartly(
    findings: list[dict[str, Any]],
    total_conversations: int = 0,
    max_parallel: int = 4,
    test_suite_priorities: str = "",
    allowed_disclosures: str = "",
    valid_agent_ids: str = "",
) -> list[dict[str, Any]]:
    """Consolidate findings using LLM semantic grouping with parallel batch processing.

    Args:
        findings: List of raw finding dictionaries
        total_conversations: Total number of conversations in the test session
        max_parallel: Maximum number of parallel LLM calls (default: 4)
        test_suite_priorities: Optional JSON string with questions/risks from test suite
        allowed_disclosures: Optional formatted string of allowed disclosure types
        valid_agent_ids: Optional formatted string of valid agent IDs

    Returns:
        List of consolidated finding dictionaries or None if LLM fails
    """
    if not findings:
        return []

    try:
        if len(findings) < 2:
            return _consolidate_findings_heuristic(findings)

        # Batch configuration
        BATCH_SIZE = 50

        # Load prompt and model once
        prompts_dir = Path(__file__).parent.parent / "prompts"
        prompt_file = prompts_dir / "finding_consolidation.prompty"

        if not prompt_file.exists():
            logger.warning(f"Prompt file not found: {prompt_file}. Using heuristic.")
            return _consolidate_findings_heuristic(findings)

        prompty_obj = prompty.load(str(prompt_file))
        llm_adapter = LLMAdapter()

        # Create batches
        batches = []
        for chunk_start in range(0, len(findings), BATCH_SIZE):
            chunk_end = min(chunk_start + BATCH_SIZE, len(findings))
            batch_findings = findings[chunk_start:chunk_end]
            batches.append((chunk_start, batch_findings))

        logger.info(
            f"Processing {len(findings)} findings in {len(batches)} batches "
            f"(max {max_parallel} parallel)"
        )

        # Process batches in parallel using semaphore
        import asyncio

        semaphore = asyncio.Semaphore(max_parallel)

        async def process_batch(
            chunk_start: int, batch_findings: list[dict[str, Any]]
        ) -> tuple[int, list[dict[str, Any]], set[int]]:
            """Process a single batch and return results."""
            async with semaphore:
                chat_model = llm_adapter.create_chat_model()
                batch_results = []
                batch_covered = set()

                # Prepare input for LLM (simplified to save tokens)
                findings_input = []
                for i, f in enumerate(batch_findings):
                    # Extract chatbot_response from evidence if available
                    evidence = f.get("evidence", {})
                    chatbot_response = None
                    if isinstance(evidence, dict):
                        chatbot_response = evidence.get("chatbot_response")

                    finding_data = {
                        "id": i,  # Local index relative to batch
                        "title": f.get("title"),
                        "label": f.get("label"),  # Good/Warning/Critical
                        "category": f.get("category"),
                        "description": f.get("description"),
                        "source": f.get("source"),
                    }
                    # Include chatbot_response if available (for dedup detection)
                    if chatbot_response:
                        finding_data["chatbot_response"] = chatbot_response

                    findings_input.append(finding_data)

                json_input = json.dumps(findings_input, indent=2)
                total = total_conversations or len(findings)
                fifteen_percent_threshold = max(1, int(total * 0.15))
                # Format valid categories from constants
                valid_categories_str = "\n".join(
                    f"- {cat}" for cat in FINDING_CATEGORIES
                )
                prepare_vars: dict[str, Any] = {
                    "findings": json_input,
                    "total_conversations": total,
                    "fifteen_percent_threshold": fifteen_percent_threshold,
                    "valid_categories": valid_categories_str,
                }
                # Add test suite priorities if available (from outer scope)
                if test_suite_priorities:
                    prepare_vars["test_suite_priorities"] = test_suite_priorities
                # Add allowed disclosures if available (from outer scope)
                if allowed_disclosures:
                    prepare_vars["allowed_disclosures"] = allowed_disclosures
                # Add valid agent IDs if available (from outer scope)
                if valid_agent_ids:
                    prepare_vars["valid_agent_ids"] = valid_agent_ids

                rendered = prompty.prepare(prompty_obj, prepare_vars)

                messages = []
                for msg in rendered:
                    if msg["role"] == "system":
                        messages.append(SystemMessage(content=msg["content"]))
                    elif msg["role"] == "user":
                        messages.append(UserMessage(content=msg["content"]))

                # Retry logic for transient LLM errors
                max_retries = 3
                retry_delay = 2.0
                last_error = None
                response_text = ""

                for attempt in range(max_retries):
                    try:
                        # Call LLM
                        response_msg = await chat_model.ainvoke(messages)

                        if hasattr(response_msg, "completion"):
                            response_text = response_msg.completion
                        elif hasattr(response_msg, "content"):
                            response_text = response_msg.content
                        else:
                            response_text = str(response_msg)

                        # Success - log if this was a retry
                        if attempt > 0:
                            logger.info(
                                f"Batch {chunk_start} LLM call succeeded on attempt {attempt + 1}/{max_retries}"
                            )
                        break

                    except Exception as llm_err:
                        last_error = llm_err
                        if attempt < max_retries - 1:
                            logger.warning(
                                f"Batch {chunk_start} LLM call failed (attempt {attempt + 1}/{max_retries}): {llm_err}. "
                                f"Retrying in {retry_delay}s..."
                            )
                            await asyncio.sleep(retry_delay)
                            retry_delay *= 2  # Exponential backoff
                        else:
                            logger.error(
                                f"Batch {chunk_start} LLM call failed after {max_retries} attempts: {llm_err}"
                            )
                            raise last_error from llm_err

                try:
                    # Parse JSON
                    parsed = json_repair.loads(response_text)
                    groups = []
                    if isinstance(parsed, dict):
                        groups = parsed.get("groups", [])

                    if not groups:
                        logger.warning(f"No groups returned for batch {chunk_start}")
                        return chunk_start, [], set()

                    for group in groups:
                        if not isinstance(group, dict):
                            continue

                        local_indices = group.get("finding_indices", [])
                        if not local_indices:
                            continue

                        # Map local indices to global and validate
                        valid_global_indices = []
                        for idx in local_indices:
                            if 0 <= idx < len(batch_findings):
                                valid_global_indices.append(chunk_start + idx)

                        if not valid_global_indices:
                            continue

                        batch_covered.update(valid_global_indices)

                        # Create consolidated finding base from first item
                        first_idx = valid_global_indices[0]
                        first_finding = findings[first_idx]
                        if not first_finding:
                            logger.warning(
                                f"Finding at index {first_idx} is None, skipping group"
                            )
                            continue
                        consolidated = first_finding.copy()

                        # Override with LLM suggested title/category/description
                        # Use .get() with safe defaults to handle missing keys
                        consolidated["title"] = group.get(
                            "consolidated_title", consolidated.get("title", "Untitled")
                        )
                        # Validate category - use LLM category or original
                        llm_category = group.get(
                            "consolidated_category", consolidated.get("category")
                        )
                        validated_category = _validate_category(llm_category)
                        if validated_category is None:
                            # Try original category
                            validated_category = _validate_category(
                                consolidated.get("category")
                            )
                        if validated_category is None:
                            logger.error(
                                f"Finding {first_idx} has no valid category after consolidation - SKIPPING"
                            )
                            continue  # Skip this consolidated finding
                        consolidated["category"] = validated_category

                        # Validate agent_id - use LLM agent_id or original
                        valid_agent_ids_set = _get_valid_agent_ids()
                        llm_agent_id = group.get(
                            "agent_id", consolidated.get("agent_id")
                        )
                        validated_agent_id = _validate_agent_id(
                            llm_agent_id, valid_agent_ids_set
                        )
                        if validated_agent_id is None:
                            # Try original agent_id
                            validated_agent_id = _validate_agent_id(
                                consolidated.get("agent_id"), valid_agent_ids_set
                            )
                        if validated_agent_id is None:
                            logger.error(
                                f"Finding {first_idx} has no valid agent_id after consolidation - SKIPPING"
                            )
                            continue  # Skip this consolidated finding
                        consolidated["agent_id"] = validated_agent_id

                        consolidated["description"] = group.get(
                            "consolidated_description",
                            consolidated.get("description", ""),
                        )

                        # Clear assessment field - the consolidated_description
                        # is now the authoritative text and may differ from
                        # the original finding's assessment (e.g., after considering
                        # allowed_disclosures for admin users)
                        consolidated["assessment"] = ""

                        # Aggregate metadata
                        sources = []
                        finding_ids = []
                        instances = []

                        for idx in valid_global_indices:
                            f = findings[idx]
                            if "id" not in f:
                                f["id"] = str(uuid.uuid4())
                            sources.append(f["source"])
                            finding_ids.append(f["id"])
                            # Build instance with source and turn number
                            # Handle evidence that might be None or a dict
                            evidence = f.get("evidence") or {}
                            # Turn number can be in evidence.turn_number OR at top level
                            turn_number = (
                                evidence.get("turn_number")
                                if isinstance(evidence, dict)
                                else f.get("turn_number")
                            ) or f.get("turn_number")
                            # Determine if this is a turn-level or conversation-level finding
                            level = (
                                "turn" if turn_number is not None else "conversation"
                            )
                            instances.append(
                                {
                                    "source": f["source"],
                                    "turn": turn_number,
                                    "level": level,
                                    "evidence": evidence
                                    if isinstance(evidence, dict)
                                    else {},
                                }
                            )

                        consolidated["count"] = len(valid_global_indices)
                        consolidated["finding_ids"] = finding_ids
                        consolidated["instances"] = instances

                        # Update source string
                        unique_sources = sorted(set(sources))

                        # Always store unique_sources count for frequency-based prioritization
                        num_affected = len(unique_sources)
                        consolidated["unique_sources"] = num_affected
                        consolidated["affected_conversations"] = num_affected

                        # Calculate and inject accurate percentage into description
                        total = total_conversations or len(findings)
                        if total > 0 and num_affected > 1:
                            percentage = round((num_affected / total) * 100, 1)
                            consolidated["affected_percentage"] = percentage

                            if percentage >= 15:
                                desc = consolidated.get("description", "")
                                occurrence_note = (
                                    f"\n\n**Occurrence**: This issue appeared in "
                                    f"{num_affected} out of {total} conversations "
                                    f"({percentage}%)."
                                )
                                desc = re.sub(r"\([^)]*\d+(\.\d+)?%[^)]*\)", "", desc)
                                desc = re.sub(
                                    r"representing \d+(\.\d+)?% of", "across", desc
                                )
                                consolidated["description"] = (
                                    desc.strip() + occurrence_note
                                )
                            else:
                                title = consolidated.get("title", "")
                                if "systemic" in title.lower() and percentage < 15:
                                    title = re.sub(
                                        r"\bSystemic\s+", "", title, flags=re.IGNORECASE
                                    )
                                    consolidated["title"] = title.strip()

                        if len(unique_sources) > 1:
                            if len(unique_sources) <= 3:
                                consolidated["source"] = ", ".join(unique_sources)
                            else:
                                consolidated["source"] = (
                                    f"{len(unique_sources)} personas "
                                    f"({', '.join(unique_sources[:3])}...)"
                                )
                        else:
                            consolidated["source"] = unique_sources[0]

                        # Average stats
                        scores = [
                            findings[idx]["score"]
                            for idx in valid_global_indices
                            if findings[idx].get("score") is not None
                        ]
                        if scores:
                            consolidated["score"] = int(sum(scores) / len(scores))
                            consolidated["label"] = calculate_label(
                                consolidated["score"]
                            )

                        # Severity escalation based on percentage
                        if total > 0 and num_affected > 1:
                            percentage = consolidated.get("affected_percentage", 0)
                            current_label = consolidated.get("label", "")

                            if current_label == "Warning":
                                if percentage >= 40:
                                    consolidated["escalated_label"] = "Critical"
                                    consolidated["escalation_reason"] = (
                                        f"Escalated from Warning to Critical: "
                                        f"systemic issue affecting {percentage}% "
                                        "of conversations"
                                    )
                                elif percentage >= 20:
                                    consolidated["escalated_label"] = "High Priority"
                                    consolidated["escalation_reason"] = (
                                        f"Escalated from Warning to High Priority: "
                                        f"repeated issue affecting {percentage}% "
                                        "of conversations"
                                    )

                        confidences = [
                            findings[idx]["confidence"]
                            for idx in valid_global_indices
                            if findings[idx].get("confidence") is not None
                        ]
                        if confidences:
                            consolidated["confidence"] = round(
                                sum(confidences) / len(confidences), 1
                            )

                        batch_results.append(consolidated)

                    # Check for missing indices within this batch and add as single-item groups
                    expected_indices = set(
                        range(chunk_start, chunk_start + len(batch_findings))
                    )
                    missing_in_batch = expected_indices - batch_covered
                    if missing_in_batch:
                        logger.debug(
                            f"Batch {chunk_start}: {len(missing_in_batch)} findings not grouped by LLM, adding as individual groups"
                        )
                        valid_agent_ids_set = _get_valid_agent_ids()
                        for missing_idx in missing_in_batch:
                            finding = findings[missing_idx]
                            if finding:
                                # Validate category - skip if invalid
                                validated_category = _validate_category(
                                    finding.get("category")
                                )
                                if validated_category is None:
                                    continue  # Skip finding with invalid category

                                # Validate agent_id - skip if invalid
                                validated_agent_id = _validate_agent_id(
                                    finding.get("agent_id"), valid_agent_ids_set
                                )
                                if validated_agent_id is None:
                                    continue  # Skip finding with invalid agent_id

                                single_item = finding.copy()
                                single_item["count"] = 1
                                if "id" not in finding:
                                    finding["id"] = str(uuid.uuid4())
                                single_item["finding_ids"] = [finding["id"]]
                                single_item["category"] = validated_category
                                single_item["agent_id"] = validated_agent_id
                                # Build instance for single finding
                                # Handle evidence that might be None or a dict
                                evidence = finding.get("evidence") or {}
                                # Turn number can be in evidence.turn_number OR at top level
                                turn_number = (
                                    evidence.get("turn_number")
                                    if isinstance(evidence, dict)
                                    else finding.get("turn_number")
                                ) or finding.get("turn_number")
                                # Determine if this is a turn-level or conversation-level finding
                                level = (
                                    "turn"
                                    if turn_number is not None
                                    else "conversation"
                                )
                                single_item["instances"] = [
                                    {
                                        "source": finding["source"],
                                        "turn": turn_number,
                                        "level": level,
                                        "evidence": evidence
                                        if isinstance(evidence, dict)
                                        else {},
                                    }
                                ]
                                batch_results.append(single_item)
                                batch_covered.add(missing_idx)

                    return chunk_start, batch_results, batch_covered

                except Exception as batch_err:
                    logger.error(
                        f"Error processing batch {chunk_start}: {batch_err}",
                        exc_info=True,
                    )
                    return chunk_start, [], set()

        # Run all batches in parallel with progress tracking
        completed_count = 0
        total_batches = len(batches)
        import time

        start_time = time.time()

        async def process_batch_with_progress(
            start: int, batch: list[dict[str, Any]]
        ) -> tuple[int, list[dict[str, Any]], set[int]]:
            nonlocal completed_count
            batch_num = start // BATCH_SIZE + 1
            result = await process_batch(start, batch)
            completed_count += 1
            elapsed = time.time() - start_time
            logger.info(
                f"  ✓ Batch {batch_num} done [{completed_count}/{total_batches}] "
                f"({completed_count * 100 // total_batches}%) @ {elapsed:.1f}s"
            )
            return result

        tasks = [process_batch_with_progress(start, batch) for start, batch in batches]
        batch_outputs = await asyncio.gather(*tasks, return_exceptions=True)

        # Combine results from all batches
        result: list[dict[str, Any]] = []
        covered_indices: set[int] = set()

        for output in batch_outputs:
            if isinstance(output, BaseException):
                logger.error(f"Batch failed with exception: {output}")
                continue
            chunk_start, batch_results, batch_covered = output
            result.extend(batch_results)
            covered_indices.update(batch_covered)

        # Add any findings that were missed (fallback safety - should be rare now)
        missed = [f for i, f in enumerate(findings) if i not in covered_indices]
        if missed:
            logger.debug(
                f"{len(missed)} findings not covered after batch processing, "
                "adding via heuristic fallback."
            )
            heuristic_missed = _consolidate_findings_heuristic(missed)
            result.extend(heuristic_missed)

        logger.info(
            f"Consolidated {len(findings)} findings into {len(result)} unique issues "
            f"(Smart LLM, {len(batches)} parallel batches)"
        )

        # Second pass: Deduplicate across batches
        if len(result) > 1:
            result = await _deduplicate_findings(
                result,
                valid_agent_ids=valid_agent_ids,
            )

        return result

    except Exception as e:
        logger.error(f"Error in smart finding consolidation: {e}", exc_info=True)
        return _consolidate_findings_heuristic(findings)


def _merge_finding_into(
    keep_finding: dict[str, Any],
    merge_finding: dict[str, Any],
) -> None:
    """Merge one finding into another (in-place mutation of keep_finding)."""
    # Combine counts
    keep_count = keep_finding.get("count", 1)
    merge_count = merge_finding.get("count", 1)
    keep_finding["count"] = keep_count + merge_count

    # Combine instances
    keep_instances = keep_finding.get("instances", [])
    merge_instances = merge_finding.get("instances", [])
    keep_finding["instances"] = keep_instances + merge_instances

    # Combine finding_ids
    keep_ids = keep_finding.get("finding_ids", [])
    merge_finding_ids = merge_finding.get("finding_ids", [])
    keep_finding["finding_ids"] = keep_ids + merge_finding_ids

    # Use lowest score (most severe)
    keep_score = keep_finding.get("score", 50)
    merge_score = merge_finding.get("score", 50)
    is_more_severe = merge_score is not None and (
        keep_score is None or merge_score < keep_score
    )
    if is_more_severe:
        keep_finding["score"] = merge_score
        keep_finding["label"] = calculate_label(merge_score)

    # Update unique_sources and affected_conversations
    unique_sources = sorted(
        {
            inst.get("source", "")
            for inst in keep_finding.get("instances", [])
            if inst.get("source")
        }
    )
    keep_finding["unique_sources"] = len(unique_sources)
    keep_finding["affected_conversations"] = len(unique_sources)

    # Update source string
    if len(unique_sources) > 3:
        prefix = f"{len(unique_sources)} personas"
        sample = ", ".join(unique_sources[:3])
        keep_finding["source"] = f"{prefix} ({sample}...)"
    elif len(unique_sources) > 1:
        keep_finding["source"] = ", ".join(unique_sources)
    elif len(unique_sources) == 1:
        keep_finding["source"] = unique_sources[0]


def _deduplicate_exact_titles(
    findings: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Fast heuristic deduplication by exact title matching.

    Merges findings with identical titles (case-insensitive, stripped).

    Args:
        findings: List of consolidated finding dictionaries

    Returns:
        List of deduplicated findings
    """
    if len(findings) <= 1:
        return findings

    # Group by normalized title
    title_groups: dict[str, list[dict[str, Any]]] = {}
    for f in findings:
        title = f.get("title", "").strip().lower()
        if title not in title_groups:
            title_groups[title] = []
        title_groups[title].append(f)

    result = []
    merged_count = 0

    for _title, group in title_groups.items():
        if len(group) == 1:
            result.append(group[0])
        else:
            # Merge all into the first one
            keep = group[0]
            for merge in group[1:]:
                _merge_finding_into(keep, merge)
                merged_count += 1
            result.append(keep)

    if merged_count > 0:
        logger.info(
            f"Exact title dedup: Merged {merged_count} findings "
            f"({len(findings)} → {len(result)})"
        )

    return result


async def _deduplicate_findings(
    findings: list[dict[str, Any]],
    valid_agent_ids: str = "",
) -> list[dict[str, Any]]:
    """Second-pass deduplication to merge similar consolidated findings.

    This function performs two-phase deduplication:
    1. Fast heuristic pass: Merge findings with exact/near-exact titles
    2. LLM semantic pass: Merge semantically similar findings (on a subset)

    Args:
        findings: List of consolidated finding dictionaries
        valid_agent_ids: Optional formatted string of valid agent IDs

    Returns:
        List of deduplicated findings
    """
    if len(findings) <= 1:
        return findings

    # Phase 1: Fast heuristic deduplication by exact title
    findings = _deduplicate_exact_titles(findings)

    if len(findings) <= 1:
        return findings

    # Phase 2: LLM semantic deduplication
    # Only process top N findings by severity to limit token usage
    MAX_FOR_LLM_DEDUP = 100

    if len(findings) > MAX_FOR_LLM_DEDUP:
        # Sort by severity (lowest score first)
        sorted_findings = sorted(
            findings, key=lambda x: (x.get("score") or 50, -x.get("count", 1))
        )
        # LLM dedup only the top ones, keep the rest as-is
        to_dedup = sorted_findings[:MAX_FOR_LLM_DEDUP]
        remaining = sorted_findings[MAX_FOR_LLM_DEDUP:]

        deduped = await _deduplicate_findings_with_llm(to_dedup, valid_agent_ids)
        return deduped + remaining
    else:
        return await _deduplicate_findings_with_llm(findings, valid_agent_ids)


async def _deduplicate_findings_with_llm(
    findings: list[dict[str, Any]],
    valid_agent_ids: str = "",
) -> list[dict[str, Any]]:
    """LLM-based semantic deduplication of findings.

    Args:
        findings: List of consolidated finding dictionaries (should be <= 100)
        valid_agent_ids: Optional formatted string of valid agent IDs

    Returns:
        List of deduplicated findings
    """
    if len(findings) <= 1:
        return findings

    try:
        # Load prompt
        prompts_dir = Path(__file__).parent.parent / "prompts"
        prompt_file = prompts_dir / "finding_deduplication.prompty"

        if not prompt_file.exists():
            logger.warning(f"Dedup prompt not found: {prompt_file}. Skipping dedup.")
            return findings

        prompty_obj = prompty.load(str(prompt_file))
        llm_adapter = LLMAdapter()
        chat_model = llm_adapter.create_chat_model()

        # Prepare simplified input for LLM
        findings_input = []
        for f in findings:
            findings_input.append(
                {
                    "id": f.get("id"),
                    "title": f.get("title"),
                    "description": f.get("description", "")[
                        :500
                    ],  # Truncate for tokens
                    "category": f.get("category"),
                    "score": f.get("score"),
                    "label": f.get("label"),
                    "count": f.get("count", 1),
                }
            )

        # Format valid categories and agent IDs
        valid_categories_str = "\n".join(f"- {cat}" for cat in FINDING_CATEGORIES)
        if not valid_agent_ids:
            valid_agent_ids = _get_valid_agent_ids_string()

        prepare_vars = {
            "findings": json.dumps(findings_input, indent=2),
            "valid_categories": valid_categories_str,
            "valid_agent_ids": valid_agent_ids,
        }

        rendered = prompty.prepare(prompty_obj, prepare_vars)

        messages = []
        for msg in rendered:
            if msg["role"] == "system":
                messages.append(SystemMessage(content=msg["content"]))
            elif msg["role"] == "user":
                messages.append(UserMessage(content=msg["content"]))

        # Call LLM
        response_msg = await chat_model.ainvoke(messages)

        if hasattr(response_msg, "completion"):
            response_text = response_msg.completion
        elif hasattr(response_msg, "content"):
            response_text = response_msg.content
        else:
            response_text = str(response_msg)

        # Parse response
        parsed = json_repair.loads(response_text)
        if not isinstance(parsed, dict):
            logger.warning("Deduplication: Invalid response format, skipping")
            return findings
        merged_groups = parsed.get("merged_groups", [])

        if not merged_groups:
            logger.info("Deduplication: No duplicates found")
            return findings

        # Build lookup map
        findings_by_id = {f["id"]: f for f in findings}
        merged_ids: set[str] = set()

        # Process merges
        for group in merged_groups:
            keep_id = group.get("keep_id")
            merge_ids = group.get("merge_ids", [])

            if not keep_id or keep_id not in findings_by_id:
                continue

            keep_finding = findings_by_id[keep_id]

            # Update title/description from LLM suggestion (apply once, before merges)
            if group.get("merged_title"):
                keep_finding["title"] = group["merged_title"]
            if group.get("merged_description"):
                keep_finding["description"] = group["merged_description"]
            if group.get("merged_category"):
                validated_cat = _validate_category(group["merged_category"])
                if validated_cat:
                    keep_finding["category"] = validated_cat

            # Merge each finding into the keeper
            for merge_id in merge_ids:
                if merge_id not in findings_by_id or merge_id == keep_id:
                    continue

                merge_finding = findings_by_id[merge_id]
                merged_ids.add(merge_id)
                _merge_finding_into(keep_finding, merge_finding)

        # Build result excluding merged findings
        result = [f for f in findings if f["id"] not in merged_ids]

        logger.info(
            f"LLM semantic dedup: Merged {len(merged_ids)} findings "
            f"({len(findings)} → {len(result)})"
        )

        return result

    except Exception as e:
        logger.error(f"Error in LLM finding deduplication: {e}", exc_info=True)
        return findings  # Return original on error


async def _consolidate_findings(
    findings: list[dict[str, Any]],
    total_conversations: int = 0,
    test_suite_priorities: str = "",
    allowed_disclosures: str = "",
    valid_agent_ids: str = "",
) -> list[dict[str, Any]]:
    """Consolidate similar findings across multiple personas.

    Attempts to use LLM for semantic grouping first, falls back to heuristic title matching.

    Args:
        findings: List of raw finding dictionaries
        total_conversations: Total number of conversations in the test session
        test_suite_priorities: Optional JSON string with questions/risks from test suite
        allowed_disclosures: Optional formatted string of allowed disclosure types
        valid_agent_ids: Optional formatted string of valid agent IDs
    """
    return await _consolidate_findings_smartly(
        findings,
        total_conversations,
        test_suite_priorities=test_suite_priorities,
        allowed_disclosures=allowed_disclosures,
        valid_agent_ids=valid_agent_ids,
    )


async def _extract_findings_from_json(
    persona_summaries: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Extract findings from persona summary.json and transcript.json files.

    Findings are sourced from:
    1. summary.json analysis.findings - LLM-generated comprehensive findings
    2. transcript[].findings - EVALUATE_TURN findings from sub-agents (per-turn)

    The summary.json findings are the primary source and typically contain
    richer analysis. Transcript findings are included for completeness.

    Args:
        persona_summaries: List of parsed summary.json dictionaries

    Returns:
        List of finding dictionaries for executive summary
    """
    findings = []

    for persona_data in persona_summaries:
        persona_id = safe_str(persona_data, "_persona_id", "unknown")
        # Get target_url from conversation_metadata
        conv_metadata = safe_get(
            persona_data, "conversation_metadata", {}, expected_type=dict
        )
        persona_target_url = safe_str(conv_metadata, "url", "")

        # 1. Extract findings from summary.json analysis.findings (primary source)
        analysis = safe_get(persona_data, "analysis", {}, expected_type=dict)
        summary_findings = analysis.get("findings", [])
        if summary_findings:
            findings.extend(
                _process_findings_list(summary_findings, persona_id, persona_target_url)
            )

        # 2. Also extract from transcript.json per-turn findings (secondary source)
        session_dir = Path(persona_data.get("_session_dir", ""))
        if session_dir:
            transcript_file = session_dir / persona_id / TRANSCRIPT_FILENAME
            if transcript_file.exists():
                try:
                    with open(transcript_file, encoding="utf-8") as f:
                        transcript_data = json.load(f)
                        transcript = transcript_data.get("transcript", [])

                        # Extract findings from each turn
                        for turn in transcript:
                            turn_findings = turn.get("evals") or turn.get(
                                "findings", []
                            )
                            findings.extend(
                                _process_findings_list(
                                    turn_findings, persona_id, persona_target_url
                                )
                            )
                except Exception as e:
                    logger.warning(f"Failed to load transcript for {persona_id}: {e}")

    logger.info(f"Extracted {len(findings)} findings from summary and transcript JSON")

    return findings


def _process_findings_list(
    raw_findings: list[dict[str, Any]], persona_id: str, target_url: str = ""
) -> list[dict[str, Any]]:
    """Process a list of findings into normalized format.

    Args:
        raw_findings: List of raw finding dictionaries
        persona_id: The persona ID for source attribution
        target_url: The target URL where this persona ran

    Returns:
        List of normalized finding dictionaries
    """
    findings = []

    for validated_finding in sanitize_findings_list(raw_findings):
        # Handle both nested evaluation_results format (summary findings)
        # and flat format (per-turn findings)
        eval_results = validated_finding.get("evaluation_results", {})

        # Try nested first, then flat
        score = safe_int(eval_results, "score", 0) or safe_int(
            validated_finding, "score", 0
        )

        # Standardize confidence to 0-1 range (try nested then flat)
        confidence = safe_float(eval_results, "confidence", 0.0) or safe_float(
            validated_finding, "confidence", 0.0
        )
        if confidence > 1.0:
            confidence = confidence / 100.0

        # Construct rich description
        # Try nested explanation first, then flat
        explanation = safe_str(eval_results, "explanation", "") or safe_str(
            validated_finding, "explanation", ""
        )
        assessment = validated_finding.get("assessment", "")
        impact = validated_finding.get("impact", "")
        what_tested = validated_finding.get("what_was_tested", "")

        desc_parts = []

        # 1. Assessment (Main Narrative) - always first
        if assessment:
            desc_parts.append(assessment)

        # 2. Impact
        if impact:
            desc_parts.append(f"\n**Impact:**\n{impact}")

        # 3. What was tested (Context)
        if what_tested:
            desc_parts.append(f"\n**What was tested:**\n{what_tested}")

        # 4. Evaluation Reasoning (if distinct from assessment)
        if explanation and explanation != assessment:
            desc_parts.append(f"\n**Evaluation Reasoning:**\n{explanation}")

        description = (
            "\n".join(desc_parts) if desc_parts else "No description available."
        )

        # Build evidence - handle both formats
        evidence = validated_finding.get("evidence", {})
        if not evidence and validated_finding.get("turn_number"):
            # Build evidence from flat per-turn format
            evidence = {
                "turn_number": validated_finding.get("turn_number"),
                "agent_input": validated_finding.get("user_message", ""),
                "chatbot_response": validated_finding.get("bot_response", ""),
            }

        findings.append(
            {
                # Preserve agent_id for traceability
                "agent_id": validated_finding.get("agent_id", "unknown"),
                "label": validated_finding.get("label", calculate_label(score)),
                "title": validated_finding.get("title", "Untitled Finding"),
                "source": f"{persona_id}",
                "sources": [persona_id],  # Track all contributing sources
                "unique_sources": 1,  # Default to 1, updated during consolidation
                "affected_conversations": 1,  # Default to 1, updated during consolidation
                "target_url": target_url,
                "description": description,
                "category": validated_finding.get("category", "Uncategorized"),
                "impact": impact,
                # Fields from JSON
                "id": validated_finding.get("id") or str(uuid.uuid4()),
                "score": score,
                "confidence": confidence,
                "evidence": evidence,
                "evaluation_explanation": explanation,
                "what_was_tested": what_tested,
                # Preserve assessment explicitly
                "assessment": assessment,
            }
        )

    return findings


def _extract_metadata_from_json(
    persona_summaries: list[dict[str, Any]],
) -> dict[str, Any]:
    """Extract aggregate metadata from persona summaries.

    Args:
        persona_summaries: List of parsed summary.json dictionaries

    Returns:
        Aggregate metadata dictionary (total_turns, total_personas only)
    """
    total_turns = 0

    # Calculate turns from summaries (source of truth for turns)
    for persona_data in persona_summaries:
        conv_metadata = persona_data.get("conversation_metadata", {})
        metadata = persona_data.get("analysis", {}).get("metadata", {})

        if "total_turns" in conv_metadata:
            total_turns += conv_metadata["total_turns"]
        else:
            total_turns += metadata.get("total_turns", 0)

    return {
        "total_turns": total_turns,
        "total_personas": len(persona_summaries),
    }


def _compute_aggregate_evaluation_metrics(
    findings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Compute aggregate evaluation metrics from findings.

    Args:
        findings: List of finding dictionaries with evaluation scores

    Returns:
        Dictionary with aggregate metrics
    """
    if not findings:
        return {
            "avg_score": 0.0,
            "avg_confidence": 0.0,
            "high_confidence_count": 0,
            "total_findings": 0,
        }

    scores = [f.get("score", 0) for f in findings if f.get("score") is not None]
    confidences = [
        f.get("confidence", 0.0) for f in findings if f.get("confidence") is not None
    ]
    high_confidence_count = sum(1 for c in confidences if c > 0.9)

    return {
        "avg_score": round(sum(scores) / len(scores), 1) if scores else 0.0,
        "avg_confidence": round(sum(confidences) / len(confidences), 1)
        if confidences
        else 0.0,
        "high_confidence_count": high_confidence_count,
        "total_findings": len(findings),
    }


async def _generate_key_questions_and_risks(
    test_suite: "TestSuite | None",
    findings: list[dict[str, Any]],
    total_conversations: int,
    allowed_disclosures: str = "",
    max_parallel: int = 5,
) -> dict[str, list[dict[str, Any]]]:
    """Generate Key Questions and Key Risks summaries from test suite.

    For each question in questions_to_answer and each risk in key_risks,
    generates a consolidated summary of relevant findings using LLM.

    Args:
        test_suite: Test suite with questions_to_answer and key_risks
        findings: List of all unconsolidated findings
        total_conversations: Total number of conversations in the session
        allowed_disclosures: Optional allowed disclosures string
        max_parallel: Maximum parallel LLM calls

    Returns:
        Dict with 'key_questions' and 'key_risks' lists, each containing
        summary objects in the same format as key_findings
    """
    if test_suite is None:
        return {"key_questions": [], "key_risks": []}

    questions = getattr(test_suite, "questions_to_answer", []) or []
    risks = getattr(test_suite, "key_risks", []) or []

    if not questions and not risks:
        return {"key_questions": [], "key_risks": []}

    # Load the prompty template
    prompts_dir = Path(__file__).parent.parent / "prompts"
    prompty_file = prompts_dir / "question_risk_summary.prompty"

    if not prompty_file.exists():
        logger.warning(f"Prompty file not found: {prompty_file}")
        return {"key_questions": [], "key_risks": []}

    prompty_obj = prompty.load(str(prompty_file))
    llm_adapter = LLMAdapter()

    # Build items to process: (item_type, item_data)
    items_to_process: list[tuple[str, dict[str, Any]]] = []

    for q in questions:
        if isinstance(q, dict):
            items_to_process.append(("question", q))

    for r in risks:
        if isinstance(r, dict):
            items_to_process.append(("risk", r))

    if not items_to_process:
        return {"key_questions": [], "key_risks": []}

    logger.info(
        f"Generating summaries for {len(questions)} questions and {len(risks)} risks"
    )

    import asyncio

    semaphore = asyncio.Semaphore(max_parallel)

    async def process_item(
        item_type: str, item_data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Process a single question or risk and return summary."""
        # Extract item_id before try block for error logging
        item_id = item_data.get("id", "unknown")
        async with semaphore:
            try:
                # Extract item details
                if item_type == "question":
                    item_name = item_data.get("question", "")
                else:
                    item_name = item_data.get("name", "")
                item_description = item_data.get("description", "")
                item_priority = item_data.get("priority", "normal")

                # Filter findings relevant to this question/risk
                # Use simple keyword matching on title, description, category
                keywords = _extract_keywords(item_name, item_description, item_id)
                relevant_findings = _filter_findings_by_keywords(findings, keywords)

                # If no relevant findings, create a minimal summary
                if not relevant_findings:
                    return {
                        "id": item_id,
                        "title": f"No findings for: {item_name[:50]}..."
                        if len(item_name) > 50
                        else f"No findings for: {item_name}",
                        "description": f"No findings were detected that directly relate to this {item_type}. This may indicate the chatbot was not tested in scenarios relevant to this {item_type}, or it performed without notable issues.",
                        "label": "Good",
                        "score": 75,
                        "count": 0,
                        "unique_sources": 0,
                        "affected_percentage": 0,
                        "category": "Feature Completeness",
                        "agent_id": "summary",
                        "verdict": "INCONCLUSIVE",
                        "item_type": item_type,
                        "item_name": item_name,
                        "item_priority": item_priority,
                    }

                # Prepare findings JSON for prompty
                findings_for_prompt = []
                for f in relevant_findings[:20]:  # Limit to avoid token overflow
                    findings_for_prompt.append(
                        {
                            "title": f.get("title"),
                            "description": f.get("description"),
                            "label": f.get("label"),
                            "score": f.get("score"),
                            "category": f.get("category"),
                            "source": f.get("source"),
                        }
                    )

                # Prepare prompty variables
                prepare_vars = {
                    "item_type": item_type,
                    "item_id": item_id,
                    "item_name": item_name,
                    "item_description": item_description,
                    "item_priority": item_priority,
                    "findings_json": json.dumps(findings_for_prompt, indent=2),
                    "total_conversations": total_conversations,
                    "allowed_disclosures": allowed_disclosures,
                }

                rendered = prompty.prepare(prompty_obj, prepare_vars)

                messages = []
                for msg in rendered:
                    if msg["role"] == "system":
                        messages.append(SystemMessage(content=msg["content"]))
                    elif msg["role"] == "user":
                        messages.append(UserMessage(content=msg["content"]))

                chat_model = llm_adapter.create_chat_model()
                response_msg = await chat_model.ainvoke(messages)

                if hasattr(response_msg, "completion"):
                    response_text = response_msg.completion
                elif hasattr(response_msg, "content"):
                    response_text = response_msg.content
                else:
                    response_text = str(response_msg)

                # Parse JSON response
                parsed = json_repair.loads(response_text)

                if not isinstance(parsed, dict):
                    logger.warning(
                        f"Invalid response format for {item_type} '{item_id}'"
                    )
                    return None

                # Add metadata
                parsed["id"] = item_id
                parsed["item_type"] = item_type
                parsed["item_name"] = item_name
                parsed["item_priority"] = item_priority

                return parsed

            except Exception as e:
                logger.error(f"Error processing {item_type} '{item_id}': {e}")
                return None

    # Process all items in parallel
    tasks = [
        process_item(item_type, item_data) for item_type, item_data in items_to_process
    ]
    results = await asyncio.gather(*tasks)

    # Separate results into questions and risks
    key_questions = []
    key_risks = []

    for result in results:
        if result is None:
            continue
        if result.get("item_type") == "question":
            key_questions.append(result)
        else:
            key_risks.append(result)

    logger.info(
        f"Generated {len(key_questions)} question summaries and {len(key_risks)} risk summaries"
    )

    return {"key_questions": key_questions, "key_risks": key_risks}


def _extract_keywords(name: str, description: str, item_id: str) -> set[str]:
    """Extract keywords from question/risk for finding matching.

    Args:
        name: Question text or risk name
        description: Item description
        item_id: Item ID (often contains key concepts)

    Returns:
        Set of lowercase keywords for matching
    """
    # Combine all text sources
    text = f"{name} {description} {item_id}".lower()

    # Remove common stop words
    stop_words = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "can",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "under",
        "again",
        "further",
        "then",
        "once",
        "here",
        "there",
        "when",
        "where",
        "why",
        "how",
        "all",
        "each",
        "few",
        "more",
        "most",
        "other",
        "some",
        "such",
        "no",
        "nor",
        "not",
        "only",
        "own",
        "same",
        "so",
        "than",
        "too",
        "very",
        "just",
        "and",
        "but",
        "if",
        "or",
        "because",
        "until",
        "while",
        "about",
        "against",
        "also",
        "this",
        "that",
        "these",
        "those",
        "what",
        "which",
        "who",
        "whom",
        "it",
        "its",
        "you",
        "your",
        "we",
        "our",
        "they",
        "their",
    }

    # Split into words and filter
    import re

    words = re.findall(r"\b[a-z]{3,}\b", text)
    keywords = {w for w in words if w not in stop_words}

    return keywords


def _filter_findings_by_keywords(
    findings: list[dict[str, Any]], keywords: set[str]
) -> list[dict[str, Any]]:
    """Filter findings that match any of the keywords.

    Args:
        findings: List of finding dictionaries
        keywords: Set of keywords to match against

    Returns:
        List of findings that match at least one keyword
    """
    if not keywords:
        return []

    matched = []
    for finding in findings:
        # Build searchable text from finding
        title = (finding.get("title") or "").lower()
        description = (finding.get("description") or "").lower()
        category = (finding.get("category") or "").lower()
        finding_text = f"{title} {description} {category}"

        # Check if any keyword matches
        for keyword in keywords:
            if keyword in finding_text:
                matched.append(finding)
                break

    return matched


async def _generate_executive_summary_from_json(
    persona_summaries: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    target_url: str,  # Added parameter
    conversation_count: int = 0,
    message_count: int = 0,
    test_suite_priorities: str = "",
) -> dict[str, Any]:
    """Generate executive summary from JSON data.

    Args:
        persona_summaries: List of persona summary dictionaries
        findings: List of finding dictionaries
        target_url: Target URL being tested
        conversation_count: Total number of conversations
        message_count: Total number of multi-step messages
        test_suite_priorities: Optional JSON string with questions/risks from test suite

    Returns:
        Executive summary with top issues, strengths, and risk level
    """

    # Generate test details from actual data
    unique_persona_types = set()
    for persona_data in persona_summaries:
        persona_id = persona_data.get("_persona_id", "")
        # Remove instance numbers to get base persona type
        base_type = re.sub(r"\d+$", "", persona_id).rstrip("_")
        if base_type and base_type != "domain_settings":
            unique_persona_types.add(base_type)

    # Format persona names for display (convert snake_case to Title Case)
    # Sort custom personas first, then generic personas
    def sort_personas(persona_id: str) -> tuple[int, str]:
        """Sort key: (0 for custom, 1 for generic), then alphabetically."""
        is_generic = persona_id.lower() in GENERIC_PERSONA_IDS
        return (1 if is_generic else 0, persona_id)

    persona_names = [
        p.replace("_", " ").title()
        for p in sorted(unique_persona_types, key=sort_personas)
        if p
    ]

    # Get unique categories (filter out empty strings)
    unique_categories = set()
    for finding in findings:
        category = (finding.get("category") or "").strip()
        if category:
            unique_categories.add(category)

    # Count displayable findings using same logic as UI (FindingsView):
    # - Turn-based findings (have evidence.turn_number): include all
    # - Conversation-level findings (no turn_number): only include Critical
    displayable_findings_count = sum(
        1
        for f in findings
        if f.get("evidence", {}).get("turn_number") is not None
        or f.get("label", "").lower() == SCORE_LABEL_CRITICAL.lower()
    )

    test_details = {
        "conversation_count": conversation_count or len(persona_summaries),
        "message_count": message_count,
        "finding_count": displayable_findings_count,
        "persona_count": len(unique_persona_types),
        "persona_names": persona_names,
        "category_count": len(unique_categories),
        "category_names": sorted(unique_categories)[:10],  # Top 10 categories
    }

    # Calculate pass rate based on persona instances with at least one CRITICAL failure
    # Formula: (1 - (personas_with_critical_failure / total_personas)) * 100
    # Note: We count instances (e.g., malicious_user, malicious_user2) not base types
    # Only Critical severity failures count towards pass rate
    # UI displays: Critical = red 🔴, Warning = yellow 🟡
    #
    # IMPORTANT: Use same counting logic as UI (Conversations tab):
    # - Turn-based findings (have evidence.turn_number): count Critical
    # - Conversation-level findings (no turn_number): only count if Critical
    personas_with_failure = set()
    for finding in findings:
        # Check if this is a Critical failure based on label ONLY
        # Trust the label field - don't recalculate from score
        # (Some positive findings may have low scores but "Good" labels)
        label = finding.get("label", "")
        is_critical = label.lower() == SCORE_LABEL_CRITICAL.lower()

        if is_critical:
            source = finding.get("source", "")
            if source:
                personas_with_failure.add(source)

    # Count all persona instances (not just unique base types)
    total_personas = len(persona_summaries) if persona_summaries else 1

    # Verify we're not counting domain_settings or other non-persona entries
    if any(p.get("_persona_id") == "domain_settings" for p in persona_summaries):
        total_personas = sum(
            1 for p in persona_summaries if p.get("_persona_id") != "domain_settings"
        )
        # Guard against all entries being filtered out
        if total_personas == 0:
            total_personas = 1

    pass_rate = int((1 - (len(personas_with_failure) / total_personas)) * 100)
    fail_rate = 100 - pass_rate

    logger.info(
        f"Pass/Fail rate: {total_personas} persona instances, "
        f"{len(personas_with_failure)} with critical failures, "
        f"fail_rate={fail_rate}%, pass_rate={pass_rate}%"
    )

    # Generate high-level executive summary (failures or positive outcomes)
    logger.info("Generating high-level executive summary...")

    # Await it directly since we're in async context
    high_level_summary = await generate_executive_summary_from_findings(
        findings=findings,
        target_url=target_url,  # Use the function parameter, not metadata
        fail_rate=fail_rate,
        test_suite_priorities=test_suite_priorities,
    )

    # Override title to "Overall Impression"
    if high_level_summary and "overall_summary" in high_level_summary:
        high_level_summary["overall_summary"]["title"] = "Overall Impression"

    if high_level_summary:
        logger.info(
            f"✅ High-level executive summary generated with {len(high_level_summary) - 1} categories"
        )
    else:
        logger.info(
            "Insufficient data for executive summary generation (need >5 critical failures or >3 successes per category)"
        )

    logger.info(f"Generated executive summary: pass_rate={pass_rate}%")
    return {
        "test_details": test_details,
        "pass_rate": pass_rate,  # Findings-based pass rate for overview
        "high_level_summary": high_level_summary,
    }


AES_SYSTEM_PROMPT = """You are an expert evaluator of conversational agents.
Your goal is to assess the "Agent Expertise Score" (AES) of a Testing Agent based on its conversation with a Chatbot.
You are evaluating the Testing Agent's ability to conduct an intelligent, deep, and expert-level inquiry.
Focus ONLY on the Testing Agent's questions and strategy, not the Chatbot's responses.

You will score the Testing Agent on four specific pillars (0-10 scale):

1. Lexical Specificity (Weight: 10%): Does the agent use accurate, domain-specific terminology and jargon appropriate for the subject matter? (0=General/Vague, 10=Highly Technical/Specific)
2. Taxonomy Coverage (Weight: 20%): Does the agent explore the breadth of the domain, covering various sub-topics and edge cases? (0=Narrow/Single-Topic, 10=Comprehensive/Full-Spectrum)
3. Constraint Density (Weight: 20%): Does the agent impose complex constraints and conditions in its questions? (0=Simple Questions, 10=Complex/Multi-condition Questions)
4. Contextual Continuity (Weight: 50%): Does the agent maintain conversation flow, build upon previous answers, and drill down logically? (0=Disjointed/Checklist-style, 10=Fluid/Deeply Threaded)

Output your evaluation in JSON format:
{
  "lexical_specificity": {
    "score": <0-10>,
    "reason": "<explanation>"
  },
  "taxonomy_coverage": {
    "score": <0-10>,
    "reason": "<explanation>"
  },
  "constraint_density": {
    "score": <0-10>,
    "reason": "<explanation>"
  },
  "contextual_continuity": {
    "score": <0-10>,
    "reason": "<explanation>"
  },
  "composite_score": <0-100 calculated score>
}
"""


async def _calculate_aes_for_session(
    conversations: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Calculate Agent Expertise Score (AES) for the entire session using LLM.

    AES evaluates the testing capabilities across all personas and conversations combined.
    This gives a better measure of Taxonomy Coverage compared to individual conversations.
    """
    if not conversations:
        return None

    try:
        # Collect all valid turns from all conversations
        # We group them by persona to help the LLM understand these are parallel/distinct efforts
        combined_trace = []

        for conv in conversations:
            persona_id = conv.get("persona_id", "unknown")
            transcript = conv.get("transcript", [])

            if not transcript or len(transcript) < 2:
                continue

            combined_trace.append(f"\\n--- CONVERSATION WITH PERSONA: {persona_id} ---")

            for turn in transcript:
                role = turn.get("role", "unknown")
                content = turn.get("content") or turn.get("text") or ""
                if role in ["user", "assistant", "model"]:
                    combined_trace.append(f"[{role.upper()}]: {content}")

        if not combined_trace:
            return None

        full_trace_text = "\\n".join(combined_trace)

        messages = [
            SystemMessage(content=AES_SYSTEM_PROMPT),
            UserMessage(
                content=f"Evaluate the testing agent's expertise based on these consolidated conversation traces from a full session:\\n\\n{full_trace_text}"
            ),
        ]

        # Call LLM
        llm_adapter = LLMAdapter()
        chat_model = llm_adapter.create_chat_model()
        response_msg = await chat_model.ainvoke(messages)

        if hasattr(response_msg, "completion"):
            response_text = response_msg.completion
        elif hasattr(response_msg, "content"):
            response_text = response_msg.content
        else:
            response_text = str(response_msg)

        # Parse JSON
        parsed = json_repair.loads(response_text)

        if not isinstance(parsed, dict):
            return None

        # Calculate composite score if not provided or double check
        # (0.1 * Lexical) + (0.2 * Constraint) + (0.2 * Taxonomy) + (0.5 * Continuity)
        # Scaled to 0-100

        lex = safe_int(parsed.get("lexical_specificity", {}), "score", 0)
        tax = safe_int(parsed.get("taxonomy_coverage", {}), "score", 0)
        con = safe_int(parsed.get("constraint_density", {}), "score", 0)
        cont = safe_int(parsed.get("contextual_continuity", {}), "score", 0)

        composite = (0.1 * lex + 0.2 * tax + 0.2 * con + 0.5 * cont) * 10
        parsed["composite_score"] = round(composite, 1)

        return parsed

    except Exception as e:
        logger.warning(f"Failed to calculate AES: {e}")
        return None


def _calculate_category_stats(
    findings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Calculate label counts by category matching frontend logic."""
    stats = {}
    category_map = {}

    # 1. Group by category
    for finding in findings:
        cat = finding.get("category", "Uncategorized")
        if cat not in category_map:
            category_map[cat] = []
        category_map[cat].append(finding)

    # 2. Calculate stats per category
    for cat, cat_findings in category_map.items():
        red = 0  # Critical - Failing
        yellow = 0  # High - Failing
        green = 0  # Passing (Any level)
        total_instances = 0

        for f in cat_findings:
            # Replicating JS logic exactly
            # But adapting for new standard where label might be missing
            raw_label = f.get("label") or f.get("severity")
            score = safe_float(f, "score") or 0.0

            if raw_label:
                label = raw_label.lower()
            else:
                # Derive label from score if missing using centralized logic
                label = calculate_label(score).lower()

            # Determine pass/fail status using new threshold
            is_pass = score >= SCORE_THRESHOLD_PASS

            # Determine bucket
            bucket = None
            if is_pass:
                # Passing items are Green (Good)
                bucket = SCORE_LABEL_GOOD.lower()
            else:
                # Failing items
                if label == SCORE_LABEL_CRITICAL.lower():
                    bucket = SCORE_LABEL_CRITICAL.lower()
                elif label == SCORE_LABEL_WARNING.lower():
                    bucket = SCORE_LABEL_WARNING.lower()
                # Low/Info failures are ignored (Gray) as per new 3-color requirement

            if bucket:
                # Count instances
                count = 1
                if "finding_ids" in f:
                    count = len(f["finding_ids"])
                elif "count" in f:
                    count = int(f["count"])

                total_instances += count

                if bucket == SCORE_LABEL_CRITICAL.lower():
                    red += count
                elif bucket == SCORE_LABEL_WARNING.lower():
                    yellow += count
                elif bucket == SCORE_LABEL_GOOD.lower():
                    green += count

        stats[cat] = {
            "total_findings": total_instances,
            SCORE_LABEL_CRITICAL.lower(): red,
            SCORE_LABEL_WARNING.lower(): yellow,
            SCORE_LABEL_GOOD.lower(): green,
        }

    return stats


async def _generate_test_scenario_summary(
    test_suite: "TestSuite",
    all_findings: list[dict[str, Any]],
    _conversations: list[dict[str, Any]],
    llm_adapter: LLMAdapter | None = None,
    max_parallel: int = 16,
) -> dict[str, Any]:
    """Generate summaries grouped by test and scenario from the test suite.

    Args:
        test_suite: TestSuite configuration object
        all_findings: List of all unconsolidated findings
        conversations: List of conversation data with persona info
        llm_adapter: Optional LLM adapter for generating summaries
        max_parallel: Maximum number of parallel LLM calls (default: 16)

    Returns:
        Dictionary containing test and scenario summaries:
        {
            "suite_name": "Kayak Travel Tests",
            "suite_domain": "travel",
            "tests": [
                {
                    "id": "budget_flight_search",
                    "name": "Budget Traveler - Flight Search",
                    "description": "...",
                    "persona": "budget_conscious",
                    "role": "consumer",
                    "scenarios": ["flight_booking", "price_comparison"],
                    "status": "completed|failed|partial",
                    "findings_count": {"critical": 2, "warning": 5, "good": 10},
                    "summary": "LLM-generated summary of findings",
                    "key_findings": [top 3-5 findings]
                },
                ...
            ],
            "scenarios": {
                "flight_booking": {
                    "name": "Flight Booking",
                    "tests_using": ["budget_flight_search", "family_trip_planning"],
                    "findings_count": {"critical": 3, "warning": 8, "good": 15},
                    "summary": "LLM-generated summary across tests",
                    "key_findings": [top 3-5 findings]
                },
                ...
            }
        }
    """
    from utils.config_loader import load_scenario

    logger.info(f"Generating test/scenario summary for suite: {test_suite.name}")

    # Phase 1: Collect all test data without LLM calls
    test_data_list: list[dict[str, Any]] = []
    scenario_findings: dict[str, list[dict[str, Any]]] = {}
    scenario_tests: dict[str, list[str]] = {}

    for test in test_suite.tests:
        # Find findings for this test's persona
        # The source field is persona_instance (e.g., "budget_conscious_consumer")
        # which is "<persona>_<role>", so we match sources that start with the persona
        test_findings = [
            f for f in all_findings if f.get("source", "").startswith(test.persona)
        ]

        # Count findings by label
        findings_count = {
            "critical": 0,
            "warning": 0,
            "good": 0,
        }
        for f in test_findings:
            label = f.get("label", "").lower()
            if label in findings_count:
                findings_count[label] += 1

        # Get top findings (Critical first, then Warning)
        sorted_findings = sorted(
            test_findings,
            key=lambda x: (
                0
                if x.get("label", "").lower() == "critical"
                else 1
                if x.get("label", "").lower() == "warning"
                else 2,
                -x.get("score", 50),
            ),
        )
        key_findings = sorted_findings[:5]

        # Determine status based on findings
        status = "completed"
        if findings_count["critical"] > 5:
            status = "failed"
        elif findings_count["critical"] > 0 or findings_count["warning"] > 5:
            status = "partial"

        # Store test data for later processing
        test_data_list.append(
            {
                "test": test,
                "test_findings": test_findings,
                "findings_count": findings_count,
                "key_findings": key_findings,
                "status": status,
            }
        )

        # Aggregate findings by scenario
        for scenario_id in test.scenarios:
            if scenario_id not in scenario_findings:
                scenario_findings[scenario_id] = []
                scenario_tests[scenario_id] = []
            scenario_findings[scenario_id].extend(test_findings)
            scenario_tests[scenario_id].append(test.id)

    # Phase 2: Generate LLM summaries in parallel
    async def generate_summary_for_test(
        test_data: dict[str, Any],
        semaphore: asyncio.Semaphore,
    ) -> str:
        """Generate summary for a single test with semaphore control."""
        test = test_data["test"]
        test_findings = test_data["test_findings"]
        findings_count = test_data["findings_count"]

        if llm_adapter and test_findings:
            async with semaphore:
                try:
                    return await _generate_test_summary_llm(
                        llm_adapter, test, test_findings
                    )
                except Exception as e:
                    logger.warning(
                        f"Failed to generate LLM summary for test {test.id}: {e}"
                    )
                    return _generate_test_summary_simple(
                        test, test_findings, findings_count
                    )
        return _generate_test_summary_simple(test, test_findings, findings_count)

    # Run LLM calls in parallel with semaphore
    semaphore = asyncio.Semaphore(max_parallel)
    logger.info(
        f"Generating {len(test_data_list)} test summaries in parallel "
        f"(max_parallel={max_parallel})..."
    )

    tasks = [
        generate_summary_for_test(test_data, semaphore) for test_data in test_data_list
    ]
    summaries = await asyncio.gather(*tasks, return_exceptions=True)

    # Phase 3: Assemble test summaries with generated summaries
    tests_summary = []
    for i, test_data in enumerate(test_data_list):
        test = test_data["test"]
        findings_count = test_data["findings_count"]
        key_findings = test_data["key_findings"]
        status = test_data["status"]

        # Get the summary (handle exceptions from gather)
        summary_result = summaries[i]
        if isinstance(summary_result, BaseException):
            logger.warning(f"Test summary failed for {test.id}: {summary_result}")
            summary = _generate_test_summary_simple(
                test, test_data["test_findings"], findings_count
            )
        else:
            summary = summary_result

        tests_summary.append(
            {
                "id": test.id,
                "name": test.name,
                "description": test.description,
                "persona": test.persona,
                "role": test.role,
                "scenarios": test.scenarios,
                "status": status,
                "findings_count": findings_count,
                "total_findings": sum(findings_count.values()),
                "summary": summary,
                "key_findings": [
                    {
                        "title": f.get("title", ""),
                        "category": f.get("category", ""),
                        "label": f.get("label", ""),
                        "score": f.get("score", 50),
                        "assessment": f.get("assessment", ""),
                    }
                    for f in key_findings
                ],
            }
        )

    logger.info(f"✅ Generated {len(tests_summary)} test summaries")

    # Build scenario summaries
    scenarios_summary = {}
    for scenario_id, findings in scenario_findings.items():
        # Try to load scenario metadata
        scenario_name = scenario_id.replace("_", " ").title()
        try:
            scenario_data = load_scenario(test_suite.domain, scenario_id)
            scenario_name = scenario_data.name
        except Exception:
            pass  # Use default name

        # Count findings
        findings_count = {
            "critical": 0,
            "warning": 0,
            "good": 0,
        }
        for f in findings:
            label = f.get("label", "").lower()
            if label in findings_count:
                findings_count[label] += 1

        # Get top findings
        sorted_findings = sorted(
            findings,
            key=lambda x: (
                0
                if x.get("label", "").lower() == "critical"
                else 1
                if x.get("label", "").lower() == "warning"
                else 2,
                -x.get("score", 50),
            ),
        )
        key_findings = sorted_findings[:5]

        # Generate simple summary for scenarios
        summary = _generate_scenario_summary_simple(
            scenario_name, findings, findings_count, scenario_tests[scenario_id]
        )

        scenarios_summary[scenario_id] = {
            "name": scenario_name,
            "tests_using": scenario_tests[scenario_id],
            "findings_count": findings_count,
            "total_findings": sum(findings_count.values()),
            "summary": summary,
            "key_findings": [
                {
                    "title": f.get("title", ""),
                    "category": f.get("category", ""),
                    "label": f.get("label", ""),
                    "score": f.get("score", 50),
                    "assessment": f.get("assessment", ""),
                }
                for f in key_findings
            ],
        }

    return {
        "suite_name": test_suite.name,
        "suite_domain": test_suite.domain,
        "suite_application": test_suite.application,
        "tests": tests_summary,
        "scenarios": scenarios_summary,
    }


def _generate_test_summary_simple(
    test: Any,
    _findings: list[dict[str, Any]],
    counts: dict[str, int],
) -> str:
    """Generate a simple text summary for a test without LLM."""
    total = sum(counts.values())
    if total == 0:
        return f"No findings recorded for {test.name}."

    summary_parts = [f"**{test.name}** ({test.persona} as {test.role})"]

    if counts["critical"] > 0:
        summary_parts.append(
            f"Found {counts['critical']} critical issue(s) requiring attention."
        )
    if counts["warning"] > 0:
        summary_parts.append(f"Identified {counts['warning']} warning(s) to review.")
    if counts["good"] > 0:
        summary_parts.append(f"{counts['good']} aspect(s) performed well.")

    return " ".join(summary_parts)


def _generate_scenario_summary_simple(
    scenario_name: str,
    _findings: list[dict[str, Any]],
    counts: dict[str, int],
    test_ids: list[str],
) -> str:
    """Generate a simple text summary for a scenario without LLM."""
    total = sum(counts.values())
    if total == 0:
        return f"No findings recorded for {scenario_name} scenario."

    summary_parts = [
        f"**{scenario_name}** scenario tested across {len(test_ids)} test(s)."
    ]

    if counts["critical"] > 0:
        summary_parts.append(f"Found {counts['critical']} critical issue(s).")
    if counts["warning"] > 0:
        summary_parts.append(f"Identified {counts['warning']} warning(s).")
    if counts["good"] > 0:
        summary_parts.append(f"{counts['good']} positive finding(s).")

    return " ".join(summary_parts)


async def _generate_test_summary_llm(
    llm_adapter: LLMAdapter,
    test: Any,
    findings: list[dict[str, Any]],
) -> str:
    """Generate an LLM-powered summary for a test's findings."""
    # Create a concise prompt for the LLM
    findings_text = "\n".join(
        [
            f"- [{f.get('label', 'Unknown')}] {f.get('title', 'No title')}: {f.get('assessment', '')}"
            for f in findings[:10]  # Limit to top 10 findings
        ]
    )

    prompt = f"""Summarize the test results for "{test.name}" in 2-3 sentences.

Test Description: {test.description}
Persona: {test.persona} (Role: {test.role})

Key Findings:
{findings_text}

Provide a concise executive summary focusing on the most important issues and overall quality."""

    try:
        model = llm_adapter.create_chat_model()
        messages = [UserMessage(content=prompt)]
        response = await model.ainvoke(messages)
        content = response.content if hasattr(response, "content") else str(response)
        return str(content) if content else ""
    except Exception as e:
        logger.warning(f"LLM summary generation failed: {e}")
        return ""


def _prepare_report_data_for_prompty(report_data: dict[str, Any]) -> dict[str, Any]:
    """Prepare report data for prompty by removing large fields.

    The full report_data.json can be 10+ MB which exceeds LLM context limits.
    This function creates a summarized version suitable for LLM processing.

    Args:
        report_data: Full report data

    Returns:
        Summarized report data suitable for LLM context
    """
    # Keep essential summary fields
    data: dict[str, Any] = {
        "metadata": report_data.get("metadata", {}),
        "stats": report_data.get("stats", {}),
        "executive_summary": report_data.get("executive_summary", {}),
    }

    # Include key_findings (already consolidated, reasonable size)
    key_findings = report_data.get("key_findings", [])
    data["key_findings"] = key_findings  # These are already consolidated

    # Summarize conversations (exclude full transcripts)
    conversations = report_data.get("conversations", [])
    data["conversations_summary"] = [
        {
            "persona_id": c.get("persona_id"),
            "persona_name": c.get("persona_name"),
            "target_url": c.get("target_url"),
            "turn_count": len(c.get("transcript", [])),
            "finding_count": sum(
                len(t.get("evals") or t.get("findings", []))
                for t in c.get("transcript", [])
            ),
        }
        for c in conversations
    ]

    # Include test_summary if available (already summarized)
    if "test_summary" in report_data:
        data["test_summary"] = report_data["test_summary"]

    return data


async def _generate_custom_report(
    test_suite_id: str,
    report_data: dict[str, Any],
) -> dict[str, Any] | None:
    """Generate a custom report from a prompty file if it exists.

    Looks for a prompty file matching the test suite ID in config/custom_reports/
    and generates a markdown report using LLM.

    Args:
        test_suite_id: The test suite identifier (e.g., 'honeycomb')
        report_data: The full report data to pass to the prompty

    Returns:
        Dict with 'title' and 'content' (markdown) if prompty exists, None otherwise
    """
    # Look for custom report prompty file
    custom_reports_dir = Path(__file__).parent.parent / "config" / "custom_reports"
    prompty_file = custom_reports_dir / f"{test_suite_id}.prompty"

    if not prompty_file.exists():
        logger.debug(f"No custom report prompty found at {prompty_file}")
        return None

    logger.info(f"Generating custom report from {prompty_file.name}...")

    try:
        # Load and prepare the prompty
        prompty_obj = prompty.load(str(prompty_file))

        # Get the report name from prompty metadata (or use test_suite_id)
        report_name = (
            prompty_obj.name if hasattr(prompty_obj, "name") else test_suite_id
        )

        # Prepare summarized report data (full data is too large for LLM context)
        summarized_data = _prepare_report_data_for_prompty(report_data)
        report_data_json = json.dumps(summarized_data, indent=2, ensure_ascii=False)
        logger.debug(
            f"Custom report input size: {len(report_data_json):,} chars "
            f"(reduced from {len(json.dumps(report_data)):,})"
        )

        rendered = prompty.prepare(
            prompty_obj,
            {"report_data": report_data_json},
        )

        # Build messages from rendered prompt
        messages = []
        for msg in rendered:
            if msg["role"] == "system":
                messages.append(SystemMessage(content=msg["content"]))
            elif msg["role"] == "user":
                messages.append(UserMessage(content=msg["content"]))

        # Call LLM to generate the report
        llm_adapter = LLMAdapter()
        chat_model = llm_adapter.create_chat_model()
        response = await chat_model.ainvoke(messages)

        # Extract text content from response
        if hasattr(response, "completion"):
            content = response.completion
        elif hasattr(response, "content"):
            # Handle case where content might be a list of blocks
            raw_content = response.content
            if isinstance(raw_content, list) and len(raw_content) > 0:
                first_block = raw_content[0]
                if hasattr(first_block, "text"):
                    content = first_block.text
                else:
                    content = str(first_block)
            else:
                content = str(raw_content)
        else:
            content = str(response)

        if not content or not content.strip():
            logger.warning("Custom report generation returned empty content")
            return None

        logger.info(f"✅ Custom report generated: {len(content)} characters")

        return {
            "title": report_name,
            "content": content.strip(),
        }

    except Exception as e:
        logger.warning(f"Custom report generation failed: {e}")
        import traceback

        logger.debug(traceback.format_exc())
        return None


async def _select_featured_findings(
    key_findings: list[dict[str, Any]],
    target_url: str,
    domain_ids: list[str] | None = None,
    test_suite_priorities: str = "",
) -> list[str]:
    """Select the top 4 findings to feature prominently in the UI.

    Uses LLM to intelligently select the most important findings based on:
    - Test suite priorities (questions and risks, if provided)
    - Domain relevance (e.g., insurance agent findings for insurance domains)
    - Data quality/consistency issues
    - Evidence count (findings with more instances are more convincing)
    - Severity/actionability

    Args:
        key_findings: List of consolidated key findings
        target_url: The target URL being tested (for domain context)
        domain_ids: List of domain IDs from test_config (e.g., ['insurance', 'healthcare'])
        test_suite_priorities: Optional JSON string with questions/risks from test suite

    Returns:
        List of 4 finding IDs to feature in the UI, ordered by importance
    """
    if not key_findings:
        return []

    # Use domain_ids from test_config if provided, otherwise use 'general'
    if domain_ids:
        unique_domains = sorted(set(domain_ids))
        domain_context = ", ".join(unique_domains)
    else:
        domain_context = "general business"

    # Prepare findings summary for LLM (include key fields only)
    findings_for_llm = []
    for f in key_findings:
        if not f.get("id"):
            continue
        # Use pre-calculated unique_sources, or calculate from instances as fallback
        unique_sources = f.get("unique_sources") or f.get("affected_conversations")
        if unique_sources is None:
            # Fallback: calculate from instances
            instances = f.get("instances", [])
            unique_sources = len(
                {inst.get("source") for inst in instances if inst.get("source")}
            )
        # Default to 1 if still not set (every finding comes from at least 1 conversation)
        if not unique_sources:
            unique_sources = 1
        findings_for_llm.append(
            {
                "id": f.get("id"),
                "title": f.get("title"),
                "category": f.get("category"),
                "label": f.get("label"),
                "score": f.get("score"),
                "count": f.get("count", 1),
                "unique_sources": unique_sources,  # Number of different personas/conversations affected
                "agent_id": f.get("agent_id"),
                "description": f.get("description") or "",
            }
        )

    if len(findings_for_llm) <= 4:
        # If we have 4 or fewer findings, just return all of them
        return [str(f["id"]) for f in findings_for_llm if f.get("id")]

    # Load prompty file
    prompty_path = Path(__file__).parent.parent / "prompts" / "top_ui_findings.prompty"

    if not prompty_path.exists():
        raise FileNotFoundError(f"Top UI findings prompty not found at {prompty_path}")

    max_retries = 3
    last_error: Exception | None = None

    for attempt in range(max_retries):
        try:
            if attempt == 0:
                logger.info("Selecting featured findings for UI via LLM...")
            else:
                logger.info(
                    f"Retrying featured findings selection (attempt {attempt + 1}/{max_retries})..."
                )

            # Load and prepare the prompty
            prompty_obj = prompty.load(str(prompty_path))
            findings_json = json.dumps(findings_for_llm, indent=2, ensure_ascii=False)

            prepare_vars: dict[str, Any] = {
                "key_findings": findings_json,
                "domain_context": domain_context,
                "target_url": target_url or "unknown",
            }
            # Add test suite priorities if available
            if test_suite_priorities:
                prepare_vars["test_suite_priorities"] = test_suite_priorities

            rendered = prompty.prepare(prompty_obj, prepare_vars)

            # Build messages from rendered prompt
            messages = []
            for msg in rendered:
                if msg["role"] == "system":
                    messages.append(SystemMessage(content=msg["content"]))
                elif msg["role"] == "user":
                    messages.append(UserMessage(content=msg["content"]))

            # Call LLM
            llm_adapter = LLMAdapter()
            chat_model = llm_adapter.create_chat_model()
            response = await chat_model.ainvoke(messages)

            # Extract content from response
            if hasattr(response, "completion"):
                content = response.completion
            elif hasattr(response, "content"):
                raw_content = response.content
                if isinstance(raw_content, list) and len(raw_content) > 0:
                    first_block = raw_content[0]
                    if hasattr(first_block, "text"):
                        content = first_block.text
                    else:
                        content = str(first_block)
                else:
                    content = str(raw_content)
            else:
                content = str(response)

            # Parse JSON response
            result = json_repair.loads(content)
            if not isinstance(result, dict):
                raise ValueError("LLM response is not a JSON object")
            featured_ids = result.get("featured_finding_ids", [])
            reasoning = result.get("selection_reasoning", "")

            if featured_ids and isinstance(featured_ids, list):
                # Validate that all IDs exist in the findings
                valid_ids = {str(f["id"]) for f in findings_for_llm if f.get("id")}
                featured_ids = [str(fid) for fid in featured_ids if fid in valid_ids]

                if featured_ids:
                    if attempt > 0:
                        logger.info(
                            f"Featured findings LLM call succeeded on attempt {attempt + 1}/{max_retries}"
                        )
                    logger.info(
                        f"✅ Selected {len(featured_ids)} featured findings: {reasoning[:100]}..."
                    )
                    return featured_ids[:10]

            # If we get here, response was valid but no featured_ids found
            raise ValueError("No valid featured finding IDs in LLM response")

        except Exception as e:
            last_error = e
            logger.warning(
                f"Featured findings selection failed (attempt {attempt + 1}/{max_retries}): {e}"
            )
            if attempt < max_retries - 1:
                await asyncio.sleep(2**attempt)  # Exponential backoff: 1s, 2s

    # All retries failed - fallback gracefully
    logger.warning(
        f"Featured findings LLM selection failed after {max_retries} attempts: {last_error}"
    )
    logger.info("Falling back to severity-based featured findings selection")
    return [str(f["id"]) for f in findings_for_llm[:10] if f.get("id")]


async def generate_report_data(
    target_url: str,
    results: dict[str, Any],
    persona_ids: list[str],
    session_dir: str,
    include_eu_ai_act_report: bool = False,
    include_test_summary: bool = False,
    test_suite: "TestSuite | None" = None,
    max_parallel: int = 4,
    include_aes_score: bool = False,
) -> dict[str, Any]:
    """
    Generate structured report data from testing results and LLM summary.

    This creates a comprehensive JSON structure that contains all information
    needed to generate HTML reports, avoiding the need to re-parse or re-analyze.

    Migration: Prefers JSON extraction from summary.json files, falls back to markdown parsing.

    Args:
        target_url: The target URL that was tested
        results: Dictionary mapping persona_id to result dict
        persona_ids: List of persona IDs that were run
        session_dir: Session directory path
        include_eu_ai_act_report: Whether to include EU AI Act compliance assessment (default: False)
        include_test_summary: Whether to include test/scenario summary generation (default: False)
        test_suite: Optional TestSuite object for generating per-test/scenario summaries
        max_parallel: Maximum number of parallel LLM calls for finding consolidation (default: 4)
        include_aes_score: Whether to calculate Agent Expertise Score (default: False, slow LLM call)

    Returns:
        Dictionary containing all report data
    """
    logger.info("Generating report data...")

    # Build test suite priorities JSON for prompty templates
    test_suite_priorities = build_test_suite_priorities(test_suite)
    if test_suite_priorities:
        logger.info("Using test suite priorities for finding consolidation")

    # Build allowed disclosures string for prompty templates
    # This tells consolidation which data types the test user is authorized to see
    allowed_disclosures = build_allowed_disclosures_string(test_suite)
    if allowed_disclosures:
        logger.info("Using allowed disclosures for finding consolidation")

    # Get valid agent IDs from the registry for consolidation prompts
    # This prevents LLM from inventing fake agent IDs like "summary" or "security_compliance_agent"
    valid_agent_ids = _get_valid_agent_ids_string()
    if valid_agent_ids:
        logger.info("Using valid agent IDs for finding consolidation")

    # Load conversation data FIRST (needed for turn number validation)
    conversations = _load_conversation_data(session_dir, persona_ids)

    # Load conversation data FIRST (needed for turn number validation)
    conversations = _load_conversation_data(session_dir, persona_ids)

    # JSON-based extraction is now the PRIMARY source of truth (Migration complete)
    # Markdown parsing functions are DEPRECATED and kept only for legacy fallback
    # See PHASE1_COMPLETE.md, PHASE2_COMPLETE.md, PHASE3_COMPLETE.md, PHASE4_COMPLETE.md
    persona_summaries = _load_persona_summaries(session_dir, persona_ids)
    use_json = len(persona_summaries) > 0

    if use_json:
        logger.info(
            f"✅ Using JSON-based extraction ({len(persona_summaries)} personas)"
        )
        raw_findings = await _extract_findings_from_json(persona_summaries)
        logger.info(f"Extracted {len(raw_findings)} raw findings from transcripts")

        # Load cross-conversation findings from sub-agent analysis
        cross_conv_findings = _load_cross_conversation_findings(session_dir)
        if cross_conv_findings:
            raw_findings.extend(cross_conv_findings)
            logger.info(
                f"Added {len(cross_conv_findings)} cross-conversation findings "
                f"(total: {len(raw_findings)})"
            )

        # CRITICAL: Filter out findings with invalid turn numbers BEFORE any aggregation
        # This ensures consistent data across all views (cards, detail, executive summary)
        # Note: Cross-conversation findings have turn_number=None and are preserved
        unconsolidated_findings = _filter_findings_with_invalid_turns(
            raw_findings, conversations
        )

        # Total conversations = number of persona summaries (each persona = one conversation)
        total_conversations = len(persona_summaries)

        # Consolidate for Key Findings tab (pattern detection)
        findings = await _consolidate_findings_smartly(
            unconsolidated_findings,
            total_conversations,
            max_parallel=max_parallel,
            test_suite_priorities=test_suite_priorities,
            allowed_disclosures=allowed_disclosures,
            valid_agent_ids=valid_agent_ids,
        )
        logger.info(
            f"Consolidated into {len(findings)} grouped findings for key findings tab"
        )

        # CRITICAL: Filter out findings with empty/null categories
        # These should NEVER appear in reports as they violate data quality requirements
        findings_before_filter = len(findings)
        findings = [
            f for f in findings if f.get("category") and str(f.get("category")).strip()
        ]
        if len(findings) < findings_before_filter:
            filtered_count = findings_before_filter - len(findings)
            logger.warning(
                f"⚠️  Filtered out {filtered_count} findings with empty/null categories"
            )

        # Limit groups to MAX_KEY_FINDING_GROUPS to avoid overwhelming the UI
        if len(findings) > MAX_KEY_FINDING_GROUPS:
            findings = _limit_finding_groups(findings, MAX_KEY_FINDING_GROUPS)
            logger.info(
                f"Limited to {len(findings)} groups (max: {MAX_KEY_FINDING_GROUPS})"
            )

        json_metadata = _extract_metadata_from_json(persona_summaries)
        evaluation_metrics = _compute_aggregate_evaluation_metrics(
            unconsolidated_findings
        )

        # Phase 2: Computed fields (use consolidated for severity)

        logger.info(
            f"📊 Evaluation metrics: avg_score={evaluation_metrics['avg_score']:.1f}, "
            f"avg_confidence={evaluation_metrics['avg_confidence']:.2f}, "
            f"high_confidence_findings={evaluation_metrics['high_confidence_count']}"
        )
    else:
        # No summary.json files found for the given persona_ids.
        # This should be prevented by upstream filtering in generate_consolidated_summary(),
        # but we raise here as a safety net rather than producing an empty report.
        logger.error("❌ No summary.json files found for personas: %s", persona_ids)
        raise FileNotFoundError(
            f"No summary.json files found in session directory: {session_dir} "
            f"for persona(s): {persona_ids}. "
            "Ensure persona runs completed successfully before generating reports."
        )

    # Calculate Agent Expertise Score (AES) for the entire session (optional, slow)
    aes_session_data = None
    if include_aes_score:
        logger.info("Calculating AES score for the session...")
        aes_session_data = await _calculate_aes_for_session(conversations)
        if aes_session_data:
            logger.info(f"Session AES Score: {aes_session_data.get('composite_score')}")

    # Build metrics summary
    metrics = _build_metrics_summary(results, persona_ids)

    # Calculate conversation and message counts for test_details
    conversation_count = len(conversations)
    message_count = sum(
        1
        for conv in conversations
        for turn in conv.get("transcript", [])
        if turn.get("role") == "assistant"
    )

    # Generate executive summary (pass_rate calculated from unconsolidated findings)
    # NOTE: Use unconsolidated_findings for accurate pass rate - it has source (persona) info
    executive_summary_json = await _generate_executive_summary_from_json(
        persona_summaries,
        unconsolidated_findings,
        target_url,
        conversation_count=conversation_count,
        message_count=message_count,
        test_suite_priorities=test_suite_priorities,
    )

    # Use JSON executive summary (no fallback to markdown)
    executive_summary = executive_summary_json

    # Generate Key Questions and Key Risks summaries (from test suite)
    # DISABLED: Skip key questions and risks generation for now
    key_questions_risks = {"key_questions": [], "key_risks": []}
    # key_questions_risks = await _generate_key_questions_and_risks(
    #     test_suite=test_suite,
    #     findings=unconsolidated_findings,
    #     total_conversations=conversation_count,
    #     allowed_disclosures=allowed_disclosures,
    # )
    # if key_questions_risks.get("key_questions") or key_questions_risks.get("key_risks"):
    #     logger.info(
    #         f"✅ Generated {len(key_questions_risks.get('key_questions', []))} question summaries "
    #         f"and {len(key_questions_risks.get('key_risks', []))} risk summaries"
    #     )

    # Extract latency information
    latency_info = _extract_latency_info(conversations)

    # Extract response length information
    response_length_info = _extract_response_length_info(conversations)

    # Extract aggregated metrics
    aggregated_metrics = _extract_aggregated_metrics(conversations)

    # Extract session-level AES score (stored separately from aggregated_metrics)
    aes_score_data = None
    if aes_session_data and aes_session_data.get("composite_score") is not None:
        # Create details dict excluding redundancy
        details = aes_session_data.copy()
        details.pop("composite_score", None)

        aes_score_data = {
            "score": aes_session_data.get("composite_score"),
            "details": details,
        }

    # Fetch favicon/logo for the target website
    # First check for local logo file in session directory
    logger.info(f"Checking for logo in session directory: {session_dir}...")
    favicon_url = get_local_logo_data_uri(session_dir)

    if favicon_url:
        logger.info("✅ Using local logo from session directory")
    else:
        # Fallback to fetching from website
        logger.info(f"Fetching favicon for {target_url}...")
        favicon_url = _fetch_favicon_url(target_url)
        if favicon_url:
            logger.info(f"✅ Favicon found: {favicon_url}")
        else:
            logger.info("ℹ️  No favicon found, will use default icon")

    # ========================================================================
    # BUSINESS LOGIC: Category Normalization (Simplified)
    # ========================================================================

    # Categories are now strictly enforced by the prompt, so no LLM normalization is needed.
    # CRITICAL: Exclude findings with empty categories (they should not appear anywhere in reports)
    findings_with_categories = [
        f for f in findings if f.get("category") and str(f.get("category")).strip()
    ]

    # Extract unique categories (excluding empty/null)
    categories = sorted(
        {str(f.get("category")) for f in findings_with_categories if f.get("category")}
    )

    if categories:
        logger.info(f"Processed {len(categories)} categories (strictly typed)")
        if len(findings_with_categories) < len(findings):
            uncategorized_count = len(findings) - len(findings_with_categories)
            logger.warning(
                f"⚠️  Excluded {uncategorized_count} findings with empty/null categories"
            )

        # Update executive summary test_details with categories
        if executive_summary and "test_details" in executive_summary:
            # Since categories are already parent categories, we just use them directly
            executive_summary["test_details"]["category_count"] = len(categories)
            executive_summary["test_details"]["category_names"] = categories

    # Generate EU AI Act compliance assessment
    eu_ai_act_compliance = None
    if include_eu_ai_act_report:
        logger.info("Generating EU AI Act compliance assessment...")
        eu_ai_act_compliance = await assess_eu_ai_act_compliance(
            findings=findings,
            metadata=json_metadata,
            target_url=target_url,
        )
        logger.info(
            f"EU AI Act: {eu_ai_act_compliance['risk_classification']['level']} - "
            f"{len(eu_ai_act_compliance['recommendations'])} recommendations"
        )
    else:
        logger.info("Skipping EU AI Act compliance assessment (disabled)")

    # Generate test/scenario summary if enabled and test suite is provided
    test_summary = None
    if include_test_summary and test_suite is not None:
        logger.info("Generating test/scenario summary from test suite...")
        from core.llm import get_llm_adapter

        try:
            llm_adapter = get_llm_adapter()
        except Exception:
            llm_adapter = None
        test_summary = await _generate_test_scenario_summary(
            test_suite=test_suite,
            all_findings=unconsolidated_findings,
            _conversations=conversations,
            llm_adapter=llm_adapter,
            max_parallel=max_parallel,
        )
        logger.info(
            f"✅ Test summary generated: {len(test_summary.get('tests', []))} tests, "
            f"{len(test_summary.get('scenarios', {}))} scenarios"
        )
    elif test_suite is not None:
        logger.info("Skipping test/scenario summary generation (disabled)")

    # Generate custom report if a prompty file exists for this test suite
    custom_report = None
    if test_suite is not None:
        logger.info(f"Checking for custom report prompty: {test_suite.id}.prompty")
        custom_report = await _generate_custom_report(
            test_suite_id=test_suite.id,
            report_data={
                "key_findings": findings,
                "conversations": conversations,
                "metadata": json_metadata,
                "executive_summary": executive_summary,
                "stats": {
                    "response_length": response_length_info,
                    "latency": latency_info,
                    "aggregated_metrics": aggregated_metrics,
                },
            },
        )
        if custom_report:
            logger.info(f"✅ Custom report generated: {custom_report.get('title')}")

    # Filter out unused fields from key_findings as requested
    # NOTE: source, confidence, and evidence are REQUIRED by the frontend for links and sorting
    # We only filter evaluation_explanation to save space if needed
    optimized_key_findings = [
        {k: v for k, v in f.items() if k not in {"evaluation_explanation"}}
        for f in findings
    ]

    # Agent ID to human-readable name mapping for UI display (from registry)
    from core.multiagent.registry import get_agent_registry

    registry = get_agent_registry()
    agent_name_map = registry.get_agent_name_map()
    # Add 'summary' for LLM-generated findings (not a registered agent)
    agent_name_map["summary"] = "Summary"

    # Generate scoring metadata for HTML renderer
    import time

    scoring_metadata = _generate_scoring_metadata()

    # Collect all unique target URLs from conversations (each persona may have tested a different URL)
    all_target_urls: list[str] = sorted(
        {
            str(conv.get("target_url"))
            for conv in conversations
            if conv.get("target_url")
        }
    )
    # Fallback to the passed target_url if no URLs found in conversations
    if not all_target_urls:
        all_target_urls = [target_url]

    # Generate a common domain for the title
    common_domain = _extract_common_domain(all_target_urls)
    report_title = f"Conversational UI Testing Report - {common_domain}"

    # Extract domain_ids from test_config in conversations (each persona's transcript has test_config.domain_id)
    domain_ids = [
        conv.get("test_config", {}).get("domain_id")
        for conv in conversations
        if conv.get("test_config", {}).get("domain_id")
    ]

    # Select featured findings for prominent UI display
    # Uses LLM to intelligently pick the most important findings based on domain, data quality, etc.
    featured_finding_ids = await _select_featured_findings(
        optimized_key_findings,
        target_url,
        domain_ids=domain_ids if domain_ids else None,
        test_suite_priorities=test_suite_priorities,
    )
    logger.info(f"Featured findings for UI: {len(featured_finding_ids)} selected")

    # Build complete report data structure (compatible with HTML template)
    report_data = {
        "key_findings": optimized_key_findings,
        "featured_finding_ids": featured_finding_ids,  # Top 10 findings for UI prominence
        "all_findings": unconsolidated_findings,  # Add unconsolidated findings for lookup
        # Key Questions and Key Risks (from test suite)
        "key_questions": key_questions_risks.get("key_questions", []),
        "key_risks": key_questions_risks.get("key_risks", []),
        "conversations": conversations,
        "metadata": {
            # Core identifiers
            "title": report_title,
            "target_urls": all_target_urls,
            "timestamp": int(time.time() * 1000),  # Epoch time in milliseconds
            "favicon_url": favicon_url,
            # Personas
            "personas": persona_ids,
            "successful_personas": metrics["successful_personas"],
            "total_personas": metrics["total_personas"],
            "total_scenarios": sum(
                len(c.get("transcript", [])) // 2 for c in conversations
            ),
            "total_turns": json_metadata.get("total_turns", 0),
            # Reference data for rendering
            "agent_name_map": agent_name_map,
            "categories": scoring_metadata["categories"],
            "metric_definitions": METRIC_INFO,
            "scoring": scoring_metadata["scoring"],
        },
        "stats": {
            "response_length": response_length_info,
            "latency": latency_info,
            "aggregated_metrics": aggregated_metrics,
            "aes_score": aes_score_data,
            "evals": evaluation_metrics,
            "usage": {
                "total_input_tokens": metrics.get("total_input_tokens", 0),
                "total_output_tokens": metrics.get("total_output_tokens", 0),
                "total_tokens": metrics["total_tokens"],
                "total_cost": metrics["total_cost"],
                "personas_with_usage": metrics["personas_with_usage"],
            },
            "finding_stats": {
                "by_category": _calculate_category_stats(findings),
                "all": _calculate_aggregate_finding_stats(conversations),
            },
        },
        "executive_summary": executive_summary,
        # EU AI Act compliance
        "eu_ai_act_compliance": eu_ai_act_compliance,
        # Test/scenario summary (if test suite provided)
        "test_summary": test_summary,
        # Custom report (if prompty file exists for test suite)
        "custom_report": custom_report,
    }

    # Save to JSON file
    output_path = Path(session_dir) / REPORT_DATA_FILENAME
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report_data, f, indent=2, ensure_ascii=False)

    logger.info(f"✅ Report data saved to: {output_path}")

    return report_data


def _attach_findings_to_turns(
    transcript: list[dict[str, Any]], findings: list[dict[str, Any]]
) -> None:
    """Attach findings from summary.json to their corresponding transcript turns.

    When EVALUATE_TURN is disabled for performance, findings are generated
    at conversation end (SUMMARIZE_CONVERSATION) with evidence.turn_id or turn_number.
    This function maps those findings back to their respective turns for
    display as annotations in the conversation view.

    Findings are always attached to ASSISTANT messages (the response being evaluated),
    never to user messages.

    Matching priority:
    1. turn_id (UUID) - reliable, source of truth
    2. turn_number - fallback for older findings without turn_id

    Args:
        transcript: List of transcript entries (modified in-place)
        findings: List of findings from summary.json with evidence.turn_id or turn_number
    """
    # Build a map of turn_id -> transcript index (primary matching)
    turn_id_to_index: dict[str, int] = {}
    for idx, msg in enumerate(transcript):
        turn_id = msg.get("id")
        if turn_id:
            turn_id_to_index[turn_id] = idx

    # Detect welcome message: first message is from assistant
    has_welcome = len(transcript) > 0 and transcript[0].get("role") == "assistant"
    welcome_offset = 1 if has_welcome else 0

    # Build a map of turn_number -> assistant message index (fallback)
    # Turn calculation matches the HTML generator logic
    turn_to_assistant_index: dict[int, int] = {}
    for idx, msg in enumerate(transcript):
        if msg.get("role") == "assistant":
            # Calculate turn number for this message
            if has_welcome and idx == 0:
                turn_num = 0  # Welcome message is turn 0
            else:
                turn_num = ((idx - welcome_offset) // 2) + 1
            turn_to_assistant_index[turn_num] = idx

    for finding in findings:
        # Get turn_id and turn_number from evidence or top level
        evidence = finding.get("evidence") or {}
        turn_id = (
            evidence.get("turn_id")
            if isinstance(evidence, dict)
            else finding.get("turn_id")
        ) or finding.get("turn_id")

        turn_number = (
            evidence.get("turn_number")
            if isinstance(evidence, dict)
            else finding.get("turn_number")
        ) or finding.get("turn_number")

        # Primary: Match by turn_id (UUID)
        turn_index = None
        if turn_id:
            turn_index = turn_id_to_index.get(turn_id)

        # Fallback: Match by turn_number if turn_id didn't match
        if turn_index is None and turn_number is not None:
            turn_index = turn_to_assistant_index.get(turn_number)

        if turn_index is None:
            # Finding doesn't have a matching turn
            continue

        turn = transcript[turn_index]
        # Initialize findings list if not present
        if "findings" not in turn:
            turn["findings"] = []
        # Add the finding to the turn (avoid duplicates by checking title)
        existing_titles = {f.get("title") for f in turn["findings"]}
        if finding.get("title") not in existing_titles:
            turn["findings"].append(finding)


def _count_finding_labels_from_list(findings: list[dict[str, Any]]) -> dict[str, int]:
    """Count finding labels from a list of findings.

    Counts the distribution of labels (Good/Warning/Critical) directly from
    a list of finding dictionaries.

    Args:
        findings: List of finding dictionaries

    Returns:
        Dict with finding stats: {'good': N, 'warning': N, 'critical': N}
    """
    finding_stats = {
        SCORE_LABEL_GOOD.lower(): 0,
        SCORE_LABEL_WARNING.lower(): 0,
        SCORE_LABEL_CRITICAL.lower(): 0,
    }

    for finding in findings:
        label = finding.get("label", "")
        if label:
            label_lower = label.lower()
            if label_lower in finding_stats:
                finding_stats[label_lower] += 1
        else:
            # Fallback: try to get score and calculate label
            score = finding.get("score")
            if score is None:
                eval_results = finding.get("evaluation_results", {})
                score = eval_results.get("score")

            if score is not None and isinstance(score, int | float):
                calculated_label = calculate_label(score)
                finding_stats[calculated_label.lower()] += 1

    return finding_stats


def _count_finding_labels(transcript: list[dict[str, Any]]) -> dict[str, int]:
    """Count finding labels in transcript and return finding stats.

    Counts the distribution of labels (Good/Warning/Critical) across all
    findings in the transcript.

    Args:
        transcript: List of transcript entries

    Returns:
        Dict with finding stats: {'good': N, 'warning': N, 'critical': N}
    """
    finding_stats = {
        SCORE_LABEL_GOOD.lower(): 0,
        SCORE_LABEL_WARNING.lower(): 0,
        SCORE_LABEL_CRITICAL.lower(): 0,
    }

    for turn in transcript:
        # Support both new 'findings' key and legacy 'validation_responses'
        findings = (
            turn.get("evals")
            or turn.get("findings")
            or turn.get("validation_responses", [])
        )
        if not findings:
            continue

        for finding in findings:
            # Get the label directly from the finding
            label = finding.get("label", "")
            if label:
                label_lower = label.lower()
                if label_lower in finding_stats:
                    finding_stats[label_lower] += 1
            else:
                # Fallback: try to get score and calculate label
                # Score might be at top level or nested in evaluation_results
                score = finding.get("score")
                if score is None:
                    eval_results = finding.get("evaluation_results", {})
                    score = eval_results.get("score")

                if score is not None and isinstance(score, int | float):
                    calculated_label = calculate_label(score)
                    finding_stats[calculated_label.lower()] += 1

    return finding_stats


def _calculate_aggregate_finding_stats(
    conversations: list[dict[str, Any]],
) -> dict[str, int]:
    """Calculate aggregate finding stats across all conversations.

    Sums up the finding_stats from each conversation to get totals.

    Args:
        conversations: List of conversation data dictionaries

    Returns:
        Dict with aggregate finding stats: {'good': N, 'warning': N, 'critical': N}
    """
    aggregate_stats = {
        SCORE_LABEL_GOOD.lower(): 0,
        SCORE_LABEL_WARNING.lower(): 0,
        SCORE_LABEL_CRITICAL.lower(): 0,
    }

    for conv in conversations:
        # finding_stats is nested inside conv["stats"]["finding_stats"]
        stats = conv.get("stats", {})
        conv_finding_stats = stats.get("finding_stats", {})
        for label in aggregate_stats:
            aggregate_stats[label] += conv_finding_stats.get(label, 0)

    return aggregate_stats


def _normalize_stats_format(stats: dict[str, Any] | None) -> dict[str, Any] | None:
    """Normalize stats to the new nested format.

    Converts old flat format (factuality_score, factuality_explanation)
    to new nested format (factuality: {score, explanation}).

    Args:
        stats: Stats dictionary in either old or new format

    Returns:
        Stats in new nested format, or None if input is None
    """
    if stats is None:
        return None

    # Check if already in new format (has nested objects with 'score' key)
    if "factuality" in stats and isinstance(stats.get("factuality"), dict):
        return stats

    # Convert from old flat format to new nested format
    old_to_new_mapping = {
        ("factuality_score", "factuality_explanation"): "factuality",
        ("coherence_score", "coherence_explanation"): "coherence",
        ("tone_adherence_score", "tone_adherence_explanation"): "tone_adherence",
        (
            "context_retention_limit",
            "context_retention_explanation",
        ): "context_retention",
        (
            "turn_to_resolution_ratio",
            "turn_to_resolution_explanation",
        ): "turn_to_resolution",
        ("topic_coverage", "topic_coverage_explanation"): "topic_coverage",
        (
            "instruction_following_score",
            "instruction_following_explanation",
        ): "instruction_following",
    }

    new_stats = {}
    for (score_key, explanation_key), new_key in old_to_new_mapping.items():
        score = stats.get(score_key)
        explanation = stats.get(explanation_key, "")

        if score is not None:
            new_stats[new_key] = {
                "score": score,
                "explanation": explanation,
            }

    # Preserve aes_score if present (it's already in the right format)
    if "aes_score" in stats:
        new_stats["aes_score"] = stats["aes_score"]

    return new_stats if new_stats else None


def _load_conversation_data(
    session_dir: str, persona_ids: list[str]
) -> list[dict[str, Any]]:
    """Load transcript and video data for each persona."""
    conversations = []
    session_path = Path(session_dir)

    for persona_id in persona_ids:
        persona_dir = session_path / persona_id

        if not persona_dir.is_dir():
            continue

        transcript_file = persona_dir / TRANSCRIPT_FILENAME
        video_file = persona_dir / "run.mp4"

        if not transcript_file.exists():
            logger.warning(f"Transcript not found for {persona_id}: {transcript_file}")
            continue

        try:
            with open(transcript_file, encoding="utf-8") as f:
                data = json.load(f)
                transcript = data.get("transcript", [])
                # Extract the actual URL this persona used (now captured per-persona)
                persona_target_url = data.get("target_url")
                # Extract persona instance if available
                persona_instance = data.get("persona_instance")

            # Round measurements in transcript
            for turn in transcript:
                if "measurements" in turn:
                    measurements = turn["measurements"]
                    for key in ["ttlt", "ttft", "length", "avg_latency"]:
                        if key in measurements and isinstance(measurements[key], float):
                            measurements[key] = round(measurements[key], 1)

            # Load stats and findings from summary.json if available
            summary_file = persona_dir / "summary.json"
            stats: dict[str, Any] = {}
            tldr: str | None = None
            summary_findings: list[dict[str, Any]] = []
            if summary_file.exists():
                try:
                    with open(summary_file, encoding="utf-8") as f:
                        summary_data = json.load(f)
                        raw_stats = summary_data.get("analysis", {}).get("stats")
                        # Normalize to new nested format (handles both old and new formats)
                        normalized = _normalize_stats_format(raw_stats)
                        if normalized:
                            stats = normalized

                        # Extract TLDR if available
                        tldr = summary_data.get("analysis", {}).get("tldr")

                        # Attach findings from summary.json to their corresponding turns
                        # This is needed because EVALUATE_TURN is disabled for performance,
                        # but findings are generated at conversation end with turn_number
                        summary_findings = summary_data.get("analysis", {}).get(
                            "findings", []
                        )
                        if summary_findings:
                            _attach_findings_to_turns(transcript, summary_findings)

                except Exception as e:
                    logger.warning(
                        f"Failed to load summary stats for {persona_id}: {e}"
                    )

            # Count finding labels from summary_findings (all findings),
            # not from transcript (only turn-attached findings)
            finding_stats = _count_finding_labels_from_list(summary_findings)

            # Format persona name nicely
            persona_name = persona_id.replace("_", " ").title()

            # Add finding_stats to the stats object
            stats["finding_stats"] = finding_stats

            conversation_data = {
                "persona_id": persona_id,
                "persona_instance": persona_instance,
                "persona_name": persona_name,
                "target_url": persona_target_url,
                "test_config": data.get("test_config", {}),
                "transcript": transcript,
                "stats": stats,
                "has_video": video_file.exists(),
                "video_path": f"{persona_id}/run.mp4" if video_file.exists() else None,
            }
            if tldr:
                conversation_data["tldr"] = tldr

            conversations.append(conversation_data)
        except Exception as e:
            logger.warning(f"Failed to load transcript for {persona_id}: {e}")

    return conversations


def _build_metrics_summary(
    results: dict[str, Any], persona_ids: list[str]
) -> dict[str, Any]:
    """Build aggregate metrics from results."""
    total_tokens = 0
    total_input_tokens = 0
    total_output_tokens = 0
    total_cost = 0.0
    personas_with_usage = 0
    successful = 0

    for persona_id in persona_ids:
        result = results.get(persona_id)
        if not result or "error" in result:
            continue

        successful += 1

        usage = result.get("usage")
        if not usage:
            # Try new location in stats
            usage = result.get("stats", {}).get("usage")

        if usage:
            personas_with_usage += 1
            if isinstance(usage, dict):
                total_tokens += usage.get("total_tokens", 0)
                total_input_tokens += usage.get("input_tokens", 0)
                total_output_tokens += usage.get("output_tokens", 0)
                total_cost += usage.get("total_cost", 0.0)
            else:
                if hasattr(usage, "total_tokens"):
                    total_tokens += usage.total_tokens
                if hasattr(usage, "input_tokens"):
                    total_input_tokens += usage.input_tokens
                if hasattr(usage, "output_tokens"):
                    total_output_tokens += usage.output_tokens
                if hasattr(usage, "total_cost"):
                    total_cost += usage.total_cost

    return {
        "total_personas": len(persona_ids),
        "successful_personas": successful,
        "total_tokens": total_tokens,
        "total_input_tokens": total_input_tokens,
        "total_output_tokens": total_output_tokens,
        "total_cost": total_cost,
        "personas_with_usage": personas_with_usage,
        "pass_rate": None,
    }


def _aggregate_distributions(distributions: list[dict[str, int]]) -> dict[str, int]:
    """Aggregate multiple distribution histograms into one."""
    aggregated = {}
    for dist in distributions:
        for bin_label, count in dist.items():
            aggregated[bin_label] = aggregated.get(bin_label, 0) + count
    return aggregated


def _extract_response_length_info(
    conversations: list[dict[str, Any]],
) -> dict[str, Any]:
    """Extract response length information from conversations."""
    all_lengths = []
    personas_with_data = 0

    for conversation in conversations:
        transcript = conversation.get("transcript", [])
        has_data = False

        for turn in transcript:
            if turn.get("role") == "assistant":
                # Try to get length from measurements first
                measurements = turn.get("measurements", {})
                if "length_chars" in measurements:
                    all_lengths.append(measurements["length_chars"])
                    has_data = True
                else:
                    # Fallback to calculating length from text
                    text = turn.get("text", "")
                    if text:
                        all_lengths.append(len(text))
                        has_data = True

        if has_data:
            personas_with_data += 1

    if not all_lengths:
        return {}

    avg_length = sum(all_lengths) / len(all_lengths)
    min_length = min(all_lengths)
    max_length = max(all_lengths)

    return {
        "total_measurements": len(all_lengths),
        "avg_length": round(avg_length, 1),
        "min_length": min_length,
        "max_length": max_length,
        "distribution": calculate_dynamic_distribution(all_lengths),
        "personas_with_measurements": personas_with_data,
        "total_personas": len(conversations),
    }


def _extract_latency_info(
    conversations: list[dict[str, Any]],
) -> dict[str, Any]:
    """Extract latency information from conversations."""
    all_latencies = []
    personas_with_data = 0

    for conversation in conversations:
        transcript = conversation.get("transcript", [])
        has_data = False

        for turn in transcript:
            if turn.get("role") == "assistant":
                measurements = turn.get("measurements", {})
                if "ttft" in measurements:
                    all_latencies.append(measurements["ttft"])
                    has_data = True

        if has_data:
            personas_with_data += 1

    if not all_latencies:
        return {}

    avg_latency = sum(all_latencies) / len(all_latencies)
    min_latency = min(all_latencies)
    max_latency = max(all_latencies)

    return {
        "total_measurements": len(all_latencies),
        "avg_latency": round(avg_latency, 1),
        "min_latency": round(min_latency, 1),
        "max_latency": round(max_latency, 1),
        "distribution": calculate_dynamic_distribution(all_latencies),
        "personas_with_measurements": personas_with_data,
        "total_personas": len(conversations),
    }


def _extract_aggregated_metrics(
    conversations: list[dict[str, Any]],
) -> dict[str, Any]:
    """Extract aggregated metrics from conversations.

    Supports both new nested format (metric.score) and legacy flat format (metric_score).
    """
    metrics = [
        "factuality",
        "coherence",
        "tone_adherence",
        "context_retention",
        "turn_to_resolution",
        "topic_coverage",
        "instruction_following",
        "aes_score",
    ]

    aggregated = {}

    for metric in metrics:
        values = []
        for c in conversations:
            if not c.get("stats"):
                continue
            stats = c["stats"]

            # Try new nested format first (metric.score)
            if metric in stats and isinstance(stats[metric], dict):
                score = stats[metric].get("score")
                if score is not None and isinstance(score, int | float):
                    values.append(score)
            # Fallback to legacy flat format (metric_score or metric)
            else:
                legacy_key = f"{metric}_score" if metric != "aes_score" else metric
                # Also try without _score suffix for topic_coverage etc
                if legacy_key in stats and stats[legacy_key] is not None:
                    val = stats[legacy_key]
                    if isinstance(val, int | float):
                        values.append(val)
                elif metric in stats and stats[metric] is not None:
                    val = stats[metric]
                    if isinstance(val, int | float):
                        values.append(val)

        if values:
            aggregated[metric] = {
                "avg": round(sum(values) / len(values), 1),
                "min": min(values),
                "max": max(values),
                "count": len(values),
            }

    return aggregated
