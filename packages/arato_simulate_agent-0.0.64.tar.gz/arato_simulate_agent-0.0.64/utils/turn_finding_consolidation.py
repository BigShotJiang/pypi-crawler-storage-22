"""
Turn Finding Consolidation Utility.

Consolidates multiple findings per conversation turn into a limited set,
prioritizing by test suite requirements and merging similar issues.
"""

import json
import logging
from typing import Any

from browser_use.llm.messages import UserMessage
from json_repair import repair_json

from constants import (
    FINDING_CATEGORIES,
    MAX_FINDINGS_PER_TURN,
)
from core.llm import create_chat_model
from utils.prompt_loader import load_prompt

logger = logging.getLogger(__name__)


async def consolidate_turn_findings(
    turn_number: int,
    user_message: str,
    bot_response: str,
    findings: list[dict[str, Any]],
    test_suite_priorities: dict[str, Any] | None = None,
    max_findings: int | None = None,
    test_suite_config: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """
    Consolidate findings for a single turn to a maximum count.

    Args:
        turn_number: The conversation turn number
        user_message: The user's message in this turn
        bot_response: The chatbot's response in this turn
        findings: List of findings from all agents for this turn
        test_suite_priorities: Optional dict with questions_to_answer and key_risks
        max_findings: Maximum findings to keep (defaults to MAX_FINDINGS_PER_TURN)
        test_suite_config: Optional test suite config containing allowed_disclosures

    Returns:
        Consolidated list of findings (at most max_findings)
    """
    if max_findings is None:
        max_findings = MAX_FINDINGS_PER_TURN

    # If already within limit, no consolidation needed
    if len(findings) <= max_findings:
        logger.debug(
            f"Turn {turn_number}: {len(findings)} findings within limit ({max_findings}), no consolidation needed"
        )
        return findings

    logger.info(
        f"Turn {turn_number}: Consolidating {len(findings)} findings to {max_findings}"
    )

    try:
        llm = create_chat_model()

        # Prepare findings JSON with indices for tracking
        findings_with_ids = []
        for i, f in enumerate(findings):
            finding_copy = f.copy()
            finding_copy["_index"] = i
            findings_with_ids.append(finding_copy)

        # Prepare test suite priorities JSON
        priorities_json = ""
        if test_suite_priorities:
            priorities_json = json.dumps(test_suite_priorities, indent=2)

        # Format valid categories for prompt
        valid_categories_str = "\n".join(f"- {cat}" for cat in FINDING_CATEGORIES)

        # Format allowed disclosures for prompt
        allowed_disclosures_str = ""
        if test_suite_config:
            allowed_disclosures_list = test_suite_config.get("allowed_disclosures", [])
            if allowed_disclosures_list:
                allowed_disclosures_str = "\n".join(
                    f"- {disclosure}" for disclosure in allowed_disclosures_list
                )

        # Get valid agent IDs from registry
        valid_agent_ids_str = ""
        try:
            from core.multiagent.registry import get_agent_registry

            registry = get_agent_registry()
            agent_ids = registry.get_agent_ids()
            if agent_ids:
                valid_agent_ids_str = "\n".join(f"- {aid}" for aid in agent_ids)
        except Exception:
            pass  # Registry not available

        # Load and render prompt
        prompt = load_prompt(
            "turn_finding_consolidation",
            turn_number=turn_number,
            user_message=user_message or "",
            bot_response=bot_response or "",
            findings=json.dumps(findings_with_ids, indent=2, ensure_ascii=False),
            max_findings=max_findings,
            test_suite_priorities=priorities_json,
            valid_categories=valid_categories_str,
            allowed_disclosures=allowed_disclosures_str,
            valid_agent_ids=valid_agent_ids_str,
        )

        # Call LLM
        response = await llm.ainvoke([UserMessage(content=prompt)])
        result_text = response.completion.strip()

        # Parse JSON response using json_repair (handles markdown code blocks and malformed JSON)
        result_json = repair_json(result_text, return_objects=True)
        if not isinstance(result_json, dict):
            logger.warning(
                f"Turn {turn_number}: repair_json returned {type(result_json).__name__} instead of dict, "
                f"falling back to truncation"
            )
            return findings[:max_findings]
        consolidated = result_json.get("consolidated_findings", [])

        if not consolidated:
            logger.warning(
                f"Turn {turn_number}: Empty consolidation result, keeping original findings"
            )
            return findings[:max_findings]

        # Validate and enrich consolidated findings
        validated_findings = []
        for cf in consolidated[:max_findings]:
            # Ensure required fields
            if "agent_id" not in cf:
                cf["agent_id"] = "consolidated"
            if "category" not in cf:
                cf["category"] = (
                    FINDING_CATEGORIES[0] if FINDING_CATEGORIES else "General"
                )
            if "score" not in cf:
                cf["score"] = 50
            if "confidence" not in cf:
                cf["confidence"] = 0.8

            # Normalize confidence to 0-1 range
            if cf.get("confidence", 0) > 1.0:
                cf["confidence"] = cf["confidence"] / 100.0

            # Add turn_number for context
            cf["turn_number"] = turn_number

            validated_findings.append(cf)

        consolidation_notes = result_json.get("consolidation_notes", "")
        if consolidation_notes:
            logger.info(f"Turn {turn_number} consolidation: {consolidation_notes}")

        logger.info(
            f"Turn {turn_number}: Consolidated {len(findings)} -> {len(validated_findings)} findings"
        )
        return validated_findings

    except Exception as e:
        logger.warning(
            f"Turn {turn_number}: Consolidation failed ({e}), using priority truncation"
        )
        # Fallback: sort by score (lowest first) and truncate
        sorted_findings = sorted(findings, key=lambda f: f.get("score", 100))
        return sorted_findings[:max_findings]


async def consolidate_all_findings(
    findings: list[dict[str, Any]],
    test_suite_config: dict[str, Any] | None = None,
    max_per_turn: int | None = None,
) -> list[dict[str, Any]]:
    """
    Unified LLM-based consolidation of all findings.

    This is the single entry point for finding consolidation. It:
    1. Groups findings by turn_number
    2. For each turn exceeding max_per_turn, uses LLM to consolidate

    Args:
        findings: List of all findings (from all sources)
        test_suite_config: Optional test suite configuration with priorities
        max_per_turn: Maximum findings per turn (defaults to MAX_FINDINGS_PER_TURN)

    Returns:
        Consolidated list of findings
    """
    if max_per_turn is None:
        max_per_turn = MAX_FINDINGS_PER_TURN

    if not findings:
        return []

    logger.info(f"Consolidating {len(findings)} findings (max {max_per_turn}/turn)")

    # Load test suite priorities
    test_suite_priorities = load_test_suite_priorities(test_suite_config)

    def _get_evidence_dict(f: dict[str, Any]) -> dict[str, Any]:
        """Safely extract evidence as a dict, handling cases where LLM returns a string."""
        evidence = f.get("evidence", {})
        return evidence if isinstance(evidence, dict) else {}

    def get_turn_number(f: dict[str, Any]) -> int | None:
        """Get turn_number from either evidence.turn_number or top-level turn_number."""
        return _get_evidence_dict(f).get("turn_number") or f.get("turn_number")

    def get_user_message(f: dict[str, Any]) -> str:
        """Extract user message from finding evidence."""
        return _get_evidence_dict(f).get("agent_input", "") or f.get("user_message", "")

    def get_bot_response(f: dict[str, Any]) -> str:
        """Extract bot response from finding evidence."""
        return _get_evidence_dict(f).get("chatbot_response", "") or f.get(
            "bot_response", ""
        )

    # Group findings by turn number (skip non-dict items)
    by_turn: dict[int | None, list[dict[str, Any]]] = {}
    for f in findings:
        if not isinstance(f, dict):
            logger.warning(
                f"Skipping non-dict finding. This is likely due to a malformed LLM response: {type(f).__name__}: {str(f)[:100]}"
            )
            continue
        turn = get_turn_number(f)
        if turn not in by_turn:
            by_turn[turn] = []
        by_turn[turn].append(f)

    # Per-turn consolidation using LLM
    final_consolidated: list[dict[str, Any]] = []

    for turn, turn_findings in by_turn.items():
        if turn is None:
            # Cross-conversation findings (no turn_number) - keep all for now
            final_consolidated.extend(turn_findings)
        elif len(turn_findings) <= max_per_turn:
            # Within limit, keep all
            final_consolidated.extend(turn_findings)
        else:
            # Exceeds limit - use LLM consolidation
            logger.info(
                f"Turn {turn}: Consolidating {len(turn_findings)} -> {max_per_turn} findings (LLM)"
            )
            # Get context from first finding with evidence
            user_msg = ""
            bot_resp = ""
            for f in turn_findings:
                if not user_msg:
                    user_msg = get_user_message(f)
                if not bot_resp:
                    bot_resp = get_bot_response(f)
                if user_msg and bot_resp:
                    break

            consolidated_turn = await consolidate_turn_findings(
                turn_number=turn,
                user_message=user_msg,
                bot_response=bot_resp,
                findings=turn_findings,
                test_suite_priorities=test_suite_priorities,
                max_findings=max_per_turn,
                test_suite_config=test_suite_config,
            )
            final_consolidated.extend(consolidated_turn)

    logger.info(
        f"Final consolidation: {len(findings)} -> {len(final_consolidated)} findings"
    )
    return final_consolidated


def load_test_suite_priorities_from_suite(test_suite: Any) -> dict[str, Any] | None:
    """
    Extract priority questions and risks from a TestSuite object.

    Args:
        test_suite: TestSuite configuration object (from config_loader)

    Returns:
        Dict with questions_to_answer and key_risks, or None if not available
    """
    if not test_suite:
        return None

    priorities = {}

    # Access attributes from TestSuite dataclass
    questions = getattr(test_suite, "questions_to_answer", None)
    if questions:
        priorities["questions_to_answer"] = questions

    risks = getattr(test_suite, "key_risks", None)
    if risks:
        priorities["key_risks"] = risks

    return priorities if priorities else None


def load_test_suite_priorities(
    test_suite_config: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """
    Extract priority questions and risks from test suite configuration dict.

    Args:
        test_suite_config: Test suite configuration dict (from YAML)

    Returns:
        Dict with questions_to_answer and key_risks, or None if not available
    """
    if not test_suite_config:
        return None

    priorities = {}

    questions = test_suite_config.get("questions_to_answer")
    if questions:
        priorities["questions_to_answer"] = questions

    risks = test_suite_config.get("key_risks")
    if risks:
        priorities["key_risks"] = risks

    return priorities if priorities else None
