#!/usr/bin/env python3
"""
Unified report generation utility for Arato sessions.

This script provides a single entry point for all report generation tasks,
with different modes depending on what you want to regenerate.

Modes:
    all   - Full pipeline: re-run sub-agents → summary.json → report_data.json → HTML
    data  - From existing summary.json: → report_data.json → HTML
    html  - From existing report_data.json: → HTML only

Usage:
    uv run generate sessions/my_session              # default: --mode all
    uv run generate sessions/my_session --mode all   # full pipeline
    uv run generate sessions/my_session --mode data  # from summary.json
    uv run generate sessions/my_session --mode html  # from report_data.json
"""

import argparse
import asyncio
import json
import logging
import re
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from constants import (
    APP_CONTEXT_FILENAME,
    CROSS_CONVERSATION_FINDINGS_FILENAME,
    PERSONA_SETTINGS_DIR,
    REPORT_DATA_FILENAME,
    TRANSCRIPT_FILENAME,
)
from models.conversation_turn import ConversationTurn
from utils.config_loader import (
    CONFIG_DIR,
    TestCase,
    compose_test_prompt,
    load_test_suite,
)
from utils.persona_summary_generator import generate_persona_summary

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


DEFAULT_PARALLEL = 32


def parse_time_delta(time_str: str) -> timedelta:
    """Parse a time string like '2h', '30m', '1d' into a timedelta."""
    match = re.match(r"^(\d+)([smhd])$", time_str.lower())
    if not match:
        raise ValueError(
            f"Invalid time format: {time_str}. Use format like '2h', '30m', '1d'"
        )
    value = int(match.group(1))
    unit = match.group(2)
    if unit == "s":
        return timedelta(seconds=value)
    elif unit == "m":
        return timedelta(minutes=value)
    elif unit == "h":
        return timedelta(hours=value)
    elif unit == "d":
        return timedelta(days=value)
    raise ValueError(f"Unknown time unit: {unit}")


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Generate reports for Arato sessions",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Modes:
  all   Full pipeline: re-run sub-agents, regenerate all summaries and reports
  data  From summary.json: regenerate report_data.json and HTML
  html  From report_data.json: regenerate HTML only

Examples:
  uv run generate sessions/my_session              # full pipeline (default)
  uv run generate sessions/my_session --mode data  # regenerate from summary.json
  uv run generate sessions/my_session --mode html  # regenerate HTML only
        """,
    )
    parser.add_argument(
        "path",
        type=str,
        help="Path to session directory OR single persona directory",
    )
    parser.add_argument(
        "--mode",
        "-m",
        type=str,
        choices=["all", "data", "html"],
        default="all",
        help="Generation mode (default: all)",
    )
    parser.add_argument(
        "--parallel",
        "-p",
        type=int,
        default=DEFAULT_PARALLEL,
        help=f"Number of parallel processes (default: {DEFAULT_PARALLEL})",
    )
    parser.add_argument(
        "--resume",
        "-r",
        type=str,
        default=None,
        help="Resume mode: only process personas with summary.json older than this. "
        "Format: '2h' (2 hours), '30m' (30 minutes), '1d' (1 day). "
        "Only applies to --mode all.",
    )
    parser.add_argument(
        "--limit",
        "-l",
        type=int,
        default=None,
        help="Limit to first N persona conversations (for quick testing).",
    )
    parser.add_argument(
        "--include-eu-ai-act-report",
        action="store_true",
        help="Include EU AI Act compliance report in summary",
    )
    parser.add_argument(
        "--include-aes-score",
        action="store_true",
        help="Calculate Agent Expertise Score (slow LLM call, disabled by default)",
    )
    return parser.parse_args()


# =============================================================================
# Mode: html - Generate HTML from existing report_data.json
# =============================================================================


async def generate_html_only(session_dir: Path) -> int:
    """Generate HTML from existing report_data.json.

    Also generates custom reports if a prompty file exists for the test suite
    and the custom_report field is missing or empty in report_data.json.
    """
    from utils.html_report_generator import generate_html_report

    report_data_file = session_dir / REPORT_DATA_FILENAME
    if not report_data_file.exists():
        logger.error(f"❌ {REPORT_DATA_FILENAME} not found in {session_dir}")
        logger.error("Run with --mode data first to create report_data.json")
        return 1

    logger.info(f"Loading report data from: {report_data_file}")

    try:
        # Load report data to check for custom report
        with open(report_data_file, encoding="utf-8") as f:
            report_data = json.load(f)

        # Generate custom report if missing and test_suite_id is available
        if not report_data.get("custom_report"):
            test_suite_id = _get_test_suite_id_from_session(session_dir)
            if test_suite_id:
                logger.info(
                    f"📝 Generating custom report for test suite: {test_suite_id}"
                )
                from utils.report_data_generator import _generate_custom_report

                custom_report = await _generate_custom_report(
                    test_suite_id=test_suite_id,
                    report_data=report_data,
                )
                if custom_report:
                    report_data["custom_report"] = custom_report
                    # Save updated report_data.json
                    with open(report_data_file, "w", encoding="utf-8") as f:
                        json.dump(report_data, f, indent=2, ensure_ascii=False)
                    logger.info(
                        f"✅ Custom report generated: {custom_report.get('title')}"
                    )

        # Generate full HTML report
        html_content = generate_html_report(report_data_file=str(report_data_file))
        output_path = session_dir / "summary.html"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        logger.info(f"✅ HTML report generated: {output_path}")

        # Generate conversations-only HTML report (conversations.html)
        conversations_html = generate_html_report(
            report_data_file=str(report_data_file),
            conversations_only=True,
        )
        conversations_output_path = session_dir / "conversations.html"
        with open(conversations_output_path, "w", encoding="utf-8") as f:
            f.write(conversations_html)
        logger.info(f"✅ Conversations report generated: {conversations_output_path}")

        # Generate presentation (slides.html) if custom report exists
        if report_data.get("custom_report"):
            from utils.presentation_generator import generate_presentation

            slides_path = session_dir / "slides.html"
            slides_html = generate_presentation(
                report_data_file=str(report_data_file),
                output_file=str(slides_path),
            )
            if slides_html:
                logger.info(f"✅ Slides generated: {slides_path}")

        return 0
    except Exception as e:
        logger.error(f"Failed to generate HTML report: {e}")
        import traceback

        logger.error(traceback.format_exc())
        return 1


def _get_test_suite_id_from_session(session_dir: Path) -> str | None:
    """Extract test_suite_id from transcript files in the session."""
    for item in session_dir.iterdir():
        if item.is_dir():
            transcript_file = item / TRANSCRIPT_FILENAME
            if transcript_file.exists():
                try:
                    with open(transcript_file, encoding="utf-8") as f:
                        transcript_data = json.load(f)
                        test_suite_id = transcript_data.get("test_suite_id")
                        if test_suite_id:
                            return test_suite_id
                except Exception:
                    pass
    return None


# =============================================================================
# Mode: data - Generate report_data.json from existing summary.json files
# =============================================================================


async def generate_from_summaries(
    session_dir: Path,
    include_eu_ai_act_report: bool = False,
    max_parallel: int = DEFAULT_PARALLEL,
    limit: int | None = None,
    include_aes_score: bool = False,
) -> int:
    """Generate report_data.json and HTML from existing summary.json files."""
    from utils.file_utils import save_json_file
    from utils.summary_generator import generate_consolidated_summary

    # Load session metadata
    progress_file = session_dir / "progress.json"
    target_url = ""
    if progress_file.exists():
        try:
            with open(progress_file) as f:
                progress = json.load(f)
                target_url = progress.get("orchestrator", {}).get("target_url", "")
        except Exception as e:
            logger.warning(f"⚠️  Failed to read progress.json: {e}")

    # Find persona directories with summary.json
    persona_dirs = []
    for item in session_dir.iterdir():
        if item.is_dir() and (item / "summary.json").exists():
            persona_dirs.append(item)

    if not persona_dirs:
        logger.error(
            f"❌ No persona directories with summary.json found in {session_dir}"
        )
        logger.error("Run with --mode all first to generate summary.json files")
        return 1

    # Apply limit if specified
    if limit and limit > 0:
        persona_dirs = sorted(persona_dirs)[:limit]
        logger.info(f"⚡ Limited to first {limit} personas for quick testing")

    logger.info(f"📂 Found {len(persona_dirs)} persona directories with summaries")

    # If target_url not found in progress.json, try to infer from first transcript
    if not target_url:
        for persona_dir in persona_dirs:
            transcript_file = persona_dir / TRANSCRIPT_FILENAME
            if transcript_file.exists():
                try:
                    with open(transcript_file, encoding="utf-8") as f:
                        transcript_data = json.load(f)
                        target_url = transcript_data.get("target_url", "")
                        if target_url:
                            logger.info(
                                f"Inferred target_url from transcript: {target_url}"
                            )
                            break
                except Exception as e:
                    logger.debug(f"Failed to read transcript for target_url: {e}")

    # Load app_context
    app_context = ""
    domain_settings_dir = session_dir / "domain_settings"
    if domain_settings_dir.exists():
        for domain_dir in domain_settings_dir.iterdir():
            if domain_dir.is_dir():
                app_context_file = domain_dir / APP_CONTEXT_FILENAME
                if app_context_file.exists():
                    app_context = app_context_file.read_text(encoding="utf-8")
                    logger.info(f"Loaded app context from {domain_dir.name}")
                    break

    # Load test suite config
    test_suite = None
    test_suite_config: dict[str, Any] | None = None
    for persona_dir in persona_dirs:
        transcript_file = persona_dir / TRANSCRIPT_FILENAME
        if transcript_file.exists():
            try:
                with open(transcript_file, encoding="utf-8") as f:
                    transcript_data = json.load(f)
                    test_suite_id = transcript_data.get("test_suite_id")
                    if test_suite_id:
                        test_suite = load_test_suite(test_suite_id)
                        test_suite_config = {
                            "domain": getattr(test_suite, "domain", None),
                            "custom_agents": getattr(test_suite, "custom_agents", []),
                            "allowed_disclosures": getattr(
                                test_suite, "allowed_disclosures", []
                            ),
                        }
                        logger.info(
                            f"Loaded test suite config: domain={test_suite_config.get('domain')}"
                        )
                        break
            except Exception:
                pass

    # Run cross-conversation analysis
    logger.info("\n🔄 Running cross-conversation analysis with sub-agents...")
    try:
        from core.multiagent import get_agent_registry

        agent_registry = get_agent_registry()
        session_id = session_dir.name
        persona_ids = [d.name for d in persona_dirs]

        findings = await agent_registry.summarize_run(
            run_id=session_id,
            target_url=target_url,
            app_context=app_context,
            conversation_ids=persona_ids,
            session_dir=str(session_dir),
            test_suite_config=test_suite_config,
        )
        cross_conversation_findings = [f.to_dict() for f in findings]
        logger.info(f"✓ Cross-conversation analysis produced {len(findings)} findings")

        if cross_conversation_findings:
            findings_path = session_dir / CROSS_CONVERSATION_FINDINGS_FILENAME
            save_json_file({"findings": cross_conversation_findings}, findings_path)
            logger.info(f"✓ Saved cross-conversation findings to {findings_path}")
    except Exception as e:
        logger.warning(f"Cross-conversation analysis failed: {e}")
        import traceback

        logger.debug(traceback.format_exc())

    # Build results dict from persona summaries
    results: dict[str, Any] = {}
    for persona_dir in persona_dirs:
        summary_file = persona_dir / "summary.json"
        if summary_file.exists():
            with open(summary_file, encoding="utf-8") as f:
                results[persona_dir.name] = json.load(f)

    # Generate consolidated summary
    logger.info("\n📊 Generating consolidated summary report...")
    try:
        persona_ids_list = [d.name for d in persona_dirs]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        await generate_consolidated_summary(
            target_url=target_url,
            results=results,
            persona_ids=persona_ids_list,
            output_dir=str(session_dir),
            timestamp=timestamp,
            format="html",
            include_eu_ai_act_report=include_eu_ai_act_report,
            test_suite=test_suite,
            max_parallel=max_parallel,
            include_aes_score=include_aes_score,
        )
        logger.info(f"✅ Generated report: {session_dir / 'summary.html'}")
        return 0
    except Exception as e:
        logger.error(f"Consolidated summary generation failed: {e}")
        import traceback

        logger.error(traceback.format_exc())
        return 1


# =============================================================================
# Mode: all - Full pipeline: re-run sub-agents and regenerate everything
# =============================================================================


def _clean_annotated_images(persona_dir: Path) -> int:
    """Remove annotated images from a previous run to avoid stale artifacts."""
    removed = 0
    for f in persona_dir.glob("*_annotated.*"):
        if f.is_file():
            f.unlink()
            removed += 1
    if removed:
        logger.info(f"🧹 Removed {removed} annotated image(s) from {persona_dir.name}")
    return removed


async def reevaluate_transcript(
    persona_dir: Path,
    target_url: str = "",
    app_context: str = "",
    test_suite_config: dict[str, Any] | None = None,
) -> None:
    """Re-run sub-agent evaluation on a transcript and regenerate summary."""
    from core.multiagent import get_agent_registry

    transcript_file = persona_dir / TRANSCRIPT_FILENAME
    if not transcript_file.exists():
        logger.warning(f"❌ No transcript found at {transcript_file}")
        return

    # Clean up annotated images from previous runs before re-evaluating
    _clean_annotated_images(persona_dir)

    logger.info(f"Processing persona folder: {persona_dir}")

    # Load transcript
    with open(transcript_file, encoding="utf-8") as f:
        transcript_data = json.load(f)

    if not target_url:
        target_url = transcript_data.get("target_url", "Unknown")

    transcript_list = transcript_data.get("transcript", [])
    transcript_turns: list[ConversationTurn] = []

    agent_registry = get_agent_registry()
    conversation_id = persona_dir.name

    persona_id = transcript_data.get("persona_id", persona_dir.name)
    base_persona_id = "_".join(p for p in persona_id.split("_") if not p.isdigit())

    logger.info(f"🔄 Re-evaluating {len(transcript_list)} turns for {persona_id}...")

    conversation_history: list[dict[str, Any]] = []
    current_turn = 0
    user_message = ""

    for turn_data in transcript_list:
        role = turn_data["role"]
        text = turn_data["text"]

        # Get or generate turn id for reliable finding matching
        turn_id = turn_data.get("id", str(uuid.uuid4()))
        # Backfill the id into turn_data so it's saved in output
        turn_data["id"] = turn_id

        if role.lower() == "user":
            user_message = text
            conversation_history.append({"role": "user", "content": text})
        else:
            current_turn += 1
            assistant_response = text

            logger.info(f"  📊 Evaluating turn {current_turn}...")

            # Build screenshot path if screenshot is referenced in turn data
            screenshot_path = None
            screenshot_name = turn_data.get("screenshot")
            if screenshot_name:
                screenshot_path = str(persona_dir / screenshot_name)

            try:
                findings = await agent_registry.evaluate_turn(
                    user_message=user_message,
                    bot_response=assistant_response,
                    conversation_id=conversation_id,
                    turn_number=current_turn,
                    turn_id=turn_id,
                    persona_id=base_persona_id,
                    target_url=target_url,
                    app_context=app_context,
                    conversation_history=conversation_history,
                    ground_truth=None,
                    test_suite_config=test_suite_config,
                    screenshot_path=screenshot_path,
                    session_dir=str(persona_dir),
                )

                evals = [f.to_dict() for f in findings]
                logger.info(f"    ✓ Got {len(evals)} findings")

                turn_data["evals"] = evals
                if "findings" in turn_data:
                    del turn_data["findings"]
                if "validation_responses" in turn_data:
                    del turn_data["validation_responses"]

            except Exception as e:
                logger.warning(f"    ⚠️  Evaluation failed for turn {current_turn}: {e}")
                turn_data["evals"] = []

            conversation_history.append({"role": "assistant", "content": text})

        turn = ConversationTurn(
            role=turn_data["role"],
            text=turn_data["text"],
            id=turn_id,  # Use preserved or backfilled turn id
            timestamp=turn_data.get("timestamp", ""),
            screenshot=turn_data.get("screenshot"),
            measurements=turn_data.get("measurements"),
            evals=turn_data.get("evals", []),
        )
        if role.lower() != "user":
            turn.turn_number = current_turn
        transcript_turns.append(turn)

    if not transcript_turns:
        logger.warning(f"❌ Empty transcript at {transcript_file}")
        return

    logger.info(
        f"💾 Saving updated transcript with {current_turn} re-evaluated turns..."
    )
    with open(transcript_file, "w", encoding="utf-8") as f:
        json.dump(transcript_data, f, indent=2, ensure_ascii=False)

    # Determine persona description
    persona_description = ""
    test_config = transcript_data.get("test_config")
    if test_config:
        config_persona_id = test_config.get("persona_id")
        config_role_id = test_config.get("role_id")
        config_domain_id = test_config.get("domain_id")

        if config_persona_id and config_domain_id:
            try:
                test_case = TestCase(
                    id=config_persona_id,
                    name=config_persona_id,
                    description=f"Persona: {config_persona_id}",
                    persona=config_persona_id,
                    role=config_role_id or "consumer",
                    scenarios=[],
                    max_turns=10,
                )
                persona_description = compose_test_prompt(
                    test_case=test_case,
                    domain_id=config_domain_id,
                    app_context=app_context,
                )
                logger.info(
                    f"✓ Loaded persona from test_config: persona={config_persona_id}"
                )
            except Exception as e:
                logger.warning(f"⚠️  Failed to compose test prompt: {e}")

    if not persona_description:
        persona_file_candidates = [
            CONFIG_DIR / "personas" / f"{persona_id}.yaml",
            Path(PERSONA_SETTINGS_DIR) / f"{persona_id}.persona",
        ]

        parts = persona_id.split("_")
        if len(parts) > 1 and parts[-1].isdigit():
            base_id = "_".join(parts[:-1])
            persona_file_candidates.extend(
                [
                    CONFIG_DIR / "personas" / f"{base_id}.yaml",
                    Path(PERSONA_SETTINGS_DIR) / f"{base_id}.persona",
                ]
            )
            parts = base_id.split("_")

        for i in range(1, min(3, len(parts))):
            base_persona = "_".join(parts[:i])
            persona_file_candidates.extend(
                [
                    CONFIG_DIR / "personas" / f"{base_persona}.yaml",
                    Path(PERSONA_SETTINGS_DIR) / f"{base_persona}.persona",
                ]
            )

        for p_file in persona_file_candidates:
            if p_file.exists():
                logger.info(f"Found persona file: {p_file}")
                persona_description = p_file.read_text(encoding="utf-8")
                break

    if not persona_description:
        logger.warning(f"⚠️  Persona file not found for {persona_id}, using ID only")
        persona_description = f"Persona ID: {persona_id}"

    logger.info(f"🤖 Generating summary for {persona_id}...")

    await generate_persona_summary(
        output_dir=str(persona_dir),
        persona_id=persona_id,
        persona_description=persona_description,
        transcript=transcript_turns,
        final_url=target_url,
        test_suite_config=test_suite_config,
    )
    logger.info(f"✅ Summary generated: {persona_dir / 'summary.json'}")


async def generate_all_pipeline(
    session_dir: Path,
    max_parallel: int = DEFAULT_PARALLEL,
    resume_older_than: timedelta | None = None,
    include_eu_ai_act_report: bool = False,
    include_aes_score: bool = False,
) -> int:
    """Full pipeline: re-run sub-agents and regenerate everything."""
    from utils.file_utils import save_json_file
    from utils.summary_generator import generate_consolidated_summary

    if not session_dir.exists():
        logger.error(f"❌ Session directory not found: {session_dir}")
        return 1

    # Load session metadata
    progress_file = session_dir / "progress.json"
    target_url = ""
    if progress_file.exists():
        try:
            with open(progress_file) as f:
                progress = json.load(f)
                target_url = progress.get("orchestrator", {}).get("target_url", "")
        except Exception as e:
            logger.warning(f"⚠️  Failed to read progress.json: {e}")

    # If target_url not found in progress.json, try to infer from first transcript
    if not target_url:
        for item in session_dir.iterdir():
            if item.is_dir() and (item / TRANSCRIPT_FILENAME).exists():
                try:
                    with open(item / TRANSCRIPT_FILENAME, encoding="utf-8") as f:
                        transcript_data = json.load(f)
                        target_url = transcript_data.get("target_url", "")
                        if target_url:
                            logger.info(
                                f"Inferred target_url from transcript: {target_url}"
                            )
                            break
                except Exception as e:
                    logger.debug(f"Failed to read transcript for target_url: {e}")

    # Load app_context
    app_context = ""
    domain_settings_dir = session_dir / "domain_settings"
    if domain_settings_dir.exists():
        for domain_dir in domain_settings_dir.iterdir():
            if domain_dir.is_dir():
                app_context_file = domain_dir / APP_CONTEXT_FILENAME
                if app_context_file.exists():
                    app_context = app_context_file.read_text(encoding="utf-8")
                    logger.info(f"Loaded app context from {domain_dir.name}")
                    break

    # Load test suite config
    test_suite = None
    test_suite_config: dict[str, Any] | None = None
    for item in session_dir.iterdir():
        if item.is_dir() and (item / TRANSCRIPT_FILENAME).exists():
            try:
                with open(item / TRANSCRIPT_FILENAME, encoding="utf-8") as f:
                    transcript_data = json.load(f)
                    test_suite_id = transcript_data.get("test_suite_id")
                    if test_suite_id:
                        test_suite = load_test_suite(test_suite_id)
                        test_suite_config = {
                            "domain": getattr(test_suite, "domain", None),
                            "custom_agents": getattr(test_suite, "custom_agents", []),
                            "allowed_disclosures": getattr(
                                test_suite, "allowed_disclosures", []
                            ),
                        }
                        logger.info(
                            f"Loaded test suite config: domain={test_suite_config.get('domain')}"
                        )
                        break
            except Exception:
                pass

    # Find persona directories
    persona_dirs = []
    skipped_recent = 0
    now = datetime.now()

    for item in session_dir.iterdir():
        if item.is_dir() and (item / TRANSCRIPT_FILENAME).exists():
            if resume_older_than:
                summary_file = item / "summary.json"
                if summary_file.exists():
                    mtime = datetime.fromtimestamp(summary_file.stat().st_mtime)
                    age = now - mtime
                    if age < resume_older_than:
                        skipped_recent += 1
                        continue
            persona_dirs.append(item)

    if resume_older_than and skipped_recent > 0:
        logger.info(f"⏭️  Skipping {skipped_recent} personas with recent summaries")

    if not persona_dirs:
        if resume_older_than:
            logger.info("✅ All personas have recent summaries, nothing to process")
            return 0
        logger.error(f"❌ No persona directories found in {session_dir}")
        return 1

    logger.info(f"📂 Found {len(persona_dirs)} persona directories to re-evaluate")
    logger.info(f"🔄 Processing with {max_parallel} parallel workers")

    # Process personas in parallel
    semaphore = asyncio.Semaphore(max_parallel)

    async def process_with_semaphore(persona_dir: Path) -> tuple[str, bool, str]:
        async with semaphore:
            try:
                await reevaluate_transcript(
                    persona_dir=persona_dir,
                    target_url=target_url,
                    app_context=app_context,
                    test_suite_config=test_suite_config,
                )
                return (persona_dir.name, True, "")
            except Exception:
                import traceback

                return (persona_dir.name, False, traceback.format_exc())

    tasks = [process_with_semaphore(persona_dir) for persona_dir in persona_dirs]
    results = await asyncio.gather(*tasks)

    succeeded = sum(1 for _, success, _ in results if success)
    failed = [(name, error) for name, success, error in results if not success]

    if failed:
        logger.warning(f"⚠️  {len(failed)} personas failed:")
        for name, error in failed:
            logger.error(f"❌ {name}: {error}")

    logger.info(f"✅ Re-evaluation complete: {succeeded}/{len(persona_dirs)} succeeded")

    # Run cross-conversation analysis
    logger.info("\n🔄 Running cross-conversation analysis with sub-agents...")
    try:
        from core.multiagent import get_agent_registry

        agent_registry = get_agent_registry()
        session_id = session_dir.name
        persona_ids = [d.name for d in persona_dirs]

        findings = await agent_registry.summarize_run(
            run_id=session_id,
            target_url=target_url,
            app_context=app_context,
            conversation_ids=persona_ids,
            session_dir=str(session_dir),
            test_suite_config=test_suite_config,
        )
        cross_conversation_findings = [f.to_dict() for f in findings]
        logger.info(f"✓ Cross-conversation analysis produced {len(findings)} findings")

        if cross_conversation_findings:
            findings_path = session_dir / CROSS_CONVERSATION_FINDINGS_FILENAME
            save_json_file({"findings": cross_conversation_findings}, findings_path)
            logger.info(f"✓ Saved cross-conversation findings to {findings_path}")
    except Exception as e:
        logger.warning(f"Cross-conversation analysis failed: {e}")
        import traceback

        logger.debug(traceback.format_exc())

    # Generate consolidated summary
    logger.info("\n📊 Generating consolidated summary report...")
    try:
        results_dict: dict[str, Any] = {}
        for persona_dir in persona_dirs:
            summary_file = persona_dir / "summary.json"
            if summary_file.exists():
                with open(summary_file, encoding="utf-8") as f:
                    results_dict[persona_dir.name] = json.load(f)

        persona_ids_list = [d.name for d in persona_dirs]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        await generate_consolidated_summary(
            target_url=target_url,
            results=results_dict,
            persona_ids=persona_ids_list,
            output_dir=str(session_dir),
            timestamp=timestamp,
            format="html",
            include_eu_ai_act_report=include_eu_ai_act_report,
            test_suite=test_suite,
            max_parallel=max_parallel,
            include_aes_score=include_aes_score,
        )
        logger.info(f"✅ Generated report: {session_dir / 'summary.html'}")
    except Exception as e:
        logger.error(f"Consolidated summary generation failed: {e}")
        import traceback

        logger.error(traceback.format_exc())
        return 1

    logger.info(f"✅ Completed full pipeline for session: {session_dir}")
    return 0


# =============================================================================
# Main entry point
# =============================================================================


async def async_main() -> int:
    """Async main entry point."""
    args = parse_args()
    path = Path(args.path)

    if not path.exists():
        logger.error(f"❌ Path not found: {path}")
        return 1

    # Determine session directory first (needed for html mode platform init check)
    is_persona_dir = (path / TRANSCRIPT_FILENAME).exists()
    if is_persona_dir:
        session_dir = path.parent
        logger.info(f"Detected persona directory, using session: {session_dir}")
    else:
        session_dir = path

    # Initialize local platform for LLM access
    # For html mode: only init if we might need to generate custom report
    if args.mode == "html":
        # Check if custom report generation is needed before initializing platform
        report_data_file = session_dir / REPORT_DATA_FILENAME
        needs_custom_report = False
        if report_data_file.exists():
            with open(report_data_file, encoding="utf-8") as f:
                report_data = json.load(f)
                if not report_data.get("custom_report"):
                    test_suite_id = _get_test_suite_id_from_session(session_dir)
                    if test_suite_id:
                        # Check if prompty file exists
                        custom_reports_dir = (
                            Path(__file__).parent.parent / "config" / "custom_reports"
                        )
                        prompty_file = custom_reports_dir / f"{test_suite_id}.prompty"
                        needs_custom_report = prompty_file.exists()

        if needs_custom_report:
            from platforms.local import LocalPlatformAdapter

            logger.info("🚀 Initializing local platform adapter for custom report...")
            LocalPlatformAdapter()
    else:
        from platforms.local import LocalPlatformAdapter

        logger.info("🚀 Initializing local platform adapter...")
        LocalPlatformAdapter()

    # Execute based on mode
    if args.mode == "html":
        logger.info("📄 Mode: html - Regenerating HTML from report_data.json")
        return await generate_html_only(session_dir)

    elif args.mode == "data":
        logger.info("📊 Mode: data - Generating from existing summary.json files")
        return await generate_from_summaries(
            session_dir,
            include_eu_ai_act_report=args.include_eu_ai_act_report,
            max_parallel=args.parallel,
            limit=args.limit,
            include_aes_score=args.include_aes_score,
        )

    else:  # mode == "all"
        logger.info("🔄 Mode: all - Full pipeline with sub-agent re-evaluation")

        resume_older_than = None
        if args.resume:
            try:
                resume_older_than = parse_time_delta(args.resume)
                logger.info(
                    f"⏱️  Resume mode: processing summaries older than {args.resume}"
                )
            except ValueError as e:
                logger.error(f"❌ {e}")
                return 1

        if is_persona_dir:
            # Single persona mode
            app_context = ""
            domain_settings_dir = session_dir / "domain_settings"
            if domain_settings_dir.exists():
                for domain_dir in domain_settings_dir.iterdir():
                    if domain_dir.is_dir():
                        app_context_file = domain_dir / APP_CONTEXT_FILENAME
                        if app_context_file.exists():
                            app_context = app_context_file.read_text(encoding="utf-8")
                            break

            await reevaluate_transcript(path, app_context=app_context)
            return 0
        else:
            return await generate_all_pipeline(
                session_dir,
                max_parallel=args.parallel,
                resume_older_than=resume_older_than,
                include_eu_ai_act_report=args.include_eu_ai_act_report,
                include_aes_score=args.include_aes_score,
            )


def main() -> int:
    """CLI entry point."""
    return asyncio.run(async_main())


if __name__ == "__main__":
    sys.exit(main())
