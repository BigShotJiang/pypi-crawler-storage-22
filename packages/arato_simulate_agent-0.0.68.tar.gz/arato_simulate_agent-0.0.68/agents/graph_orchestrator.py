#!/usr/bin/env python3
"""
Graph Orchestrator: Multi-agent orchestration using Strands Graph pattern.

This orchestrator uses a directed acyclic graph (DAG) to coordinate agents:

    ┌─────────────────────┐
    │  ConnectivityCheck  │  (verify target is reachable)
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │    SessionSetup     │  (create dirs, logging, analytics)
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │    AppDiscovery     │  (cached per domain)
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │    GroundTruth      │  (optional, if goal=ground_truth)
    └──────────┬──────────┘
               │
    ┌──────────▼─────────────────────────────────┐
    │         PersonaRunner (parallel)           │
    │  ┌─────────┐ ┌─────────┐ ┌─────────────┐  │
    │  │Persona 1│ │Persona 2│ │  Persona N  │  │
    │  └─────────┘ └─────────┘ └─────────────┘  │
    └──────────┬─────────────────────────────────┘
               │
    ┌──────────▼──────────┐
    │  CrossConversation  │  (sub-agent analysis)
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │      Summary        │  (generate reports)
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │   ArtifactUpload    │
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │   TaskCompletion    │  (mark task complete, send final progress)
    └─────────────────────┘

Each node is a proper MultiAgentBase that executes its specific task and
passes state to the next node via invocation_state.
"""

import asyncio
import logging
import os
import random
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, cast

from strands.agent.agent_result import AgentResult
from strands.multiagent import GraphBuilder
from strands.multiagent.base import (
    MultiAgentBase,
    MultiAgentInput,
    MultiAgentResult,
    NodeResult,
    Status,
)
from strands.telemetry.metrics import EventLoopMetrics
from strands.types.content import ContentBlock, Message

from agents.app_context_discovery import AppContextDiscoveryAgent
from agents.chat_runner import ChatRunner
from constants import (
    APP_CONTEXT_FILENAME,
    CROSS_CONVERSATION_FINDINGS_FILENAME,
    DEFAULT_MAX_PARALLEL_PERSONAS,
    DEFAULT_MAX_TURNS,
    DEFAULT_PIPELINE_TIMEOUT,
    DEFAULT_SEED_UTTERANCE,
    DEFAULT_STEP_TIMEOUT,
    DOMAIN_SETTINGS_DIR,
    REPORT_DATA_FILENAME,
    RUN_VIDEO_FILENAME,
    SUMMARY_FILENAME,
    TRANSCRIPT_FILENAME,
)
from core.multiagent import get_agent_registry
from core.schemas import (
    AgentCommand,
    AppDiscoveryProgressInfo,
    ArtifactsInfo,
    OrchestratorProgressInfo,
    PersonaProgressInfo,
    PersonaResult,
    ProgressSnapshot,
    TaskResult,
    TaskStatus,
)
from core.storage import (
    delete_domain_cache,
    download_domain_cache,
    upload_domain_cache,
    upload_persona_artifacts,
    upload_session_artifacts,
)
from tools.hitl_intervention import set_polling_context
from utils.analytics import AnalyticsClient, calculate_response_statistics
from utils.credential_manager import (
    check_credentials_periodically,
    get_credential_manager,
)
from utils.file_utils import save_json_file
from utils.finding_utils import finding_to_dict
from utils.logging_config import setup_logging
from utils.progress_tracker import (
    ExecutionStatus,
    FinishReason,
    OrchestratorPhase,
    ProgressTracker,
)
from utils.summary_generator import generate_consolidated_summary
from utils.timing_logger import get_timing_logger, log_timing
from utils.token_tracker import calculate_cost as calculate_token_cost
from utils.transcript_utils import extract_evals_from_transcript
from utils.url_utils import get_domain_from_url

logger = logging.getLogger(__name__)


# =============================================================================
# Shared State Keys
# =============================================================================

STATE_TARGET_URL = "target_url"
STATE_SESSION_ID = "session_id"
STATE_OUTPUT_DIR = "output_dir"
STATE_DOMAIN = "domain"
STATE_DOMAIN_SETTINGS_PATH = "domain_settings_path"
STATE_APP_CONTEXT = "app_context"
STATE_PERSONA_RESULTS = "persona_results"
STATE_PROGRESS_TRACKER = "progress_tracker"
STATE_CROSS_FINDINGS = "cross_conversation_findings"
STATE_TOTAL_TOKENS = "total_tokens"
STATE_CONFIG = "config"
STATE_AGENT_IDENTITY = "agent_identity"
STATE_RUN_METRICS = "run_metrics"
STATE_CREDENTIAL_CHECK_TASK = "credential_check_task"
STATE_EXPANDED_PERSONAS = "expanded_personas"
STATE_ARTIFACTS_INFO = "artifacts_info"


def _make_result(state: dict[str, Any], message: str) -> MultiAgentResult:
    """Helper to create a MultiAgentResult with the given state."""
    agent_result = AgentResult(
        stop_reason="end_turn",
        message=Message(role="assistant", content=[ContentBlock(text=message)]),
        metrics=EventLoopMetrics(),
        state=state,
    )
    return MultiAgentResult(
        status=Status.COMPLETED,
        results={"node": NodeResult(result=agent_result)},
    )


def _extract_state(invocation_state: dict[str, Any] | None) -> dict[str, Any]:
    """Extract accumulated state from invocation_state."""
    if not invocation_state:
        return {}
    return invocation_state.get("accumulated_state", {})


# =============================================================================
# Helper Functions (ported from orchestrator.py)
# =============================================================================


def apply_persona_exclusions(
    persona_ids: list[str], exclude_patterns: list[str] | None
) -> list[str]:
    """Filter out personas matching exclusion patterns."""
    if not exclude_patterns:
        return persona_ids

    expanded_excludes = expand_glob_patterns(exclude_patterns)
    exclude_ids = set()
    for exclude_spec in expanded_excludes:
        persona_id, _ = parse_persona_with_multiplier(exclude_spec)
        exclude_ids.add(persona_id)

    filtered = []
    for spec in persona_ids:
        persona_id, _ = parse_persona_with_multiplier(spec)
        if persona_id not in exclude_ids:
            filtered.append(spec)
    return filtered


def expand_glob_patterns(persona_specs: list[str]) -> list[str]:
    """Expand glob patterns in persona specifications to actual persona IDs."""
    from fnmatch import fnmatch

    from utils.config_loader import get_available_personas

    expanded = []
    available_personas = get_available_personas()

    flattened_specs = []
    for spec in persona_specs:
        if "," in spec:
            flattened_specs.extend([s.strip() for s in spec.split(",")])
        else:
            flattened_specs.append(spec)

    for spec in flattened_specs:
        if "*" in spec or "?" in spec:
            pattern, multiplier = parse_persona_with_multiplier(spec)
            matched = [p for p in available_personas if fnmatch(p, pattern)]
            if matched:
                for persona in matched:
                    if multiplier > 1:
                        expanded.append(f"{persona}:{multiplier}")
                    else:
                        expanded.append(persona)
            else:
                logger.warning(f"No personas matched pattern '{pattern}'")
        else:
            expanded.append(spec)

    return expanded


def parse_persona_with_multiplier(persona_spec: str) -> tuple[str, int]:
    """Parse a persona specification with optional multiplier."""
    if ":" in persona_spec:
        parts = persona_spec.split(":", 1)
        persona_id = parts[0].strip()
        try:
            count = int(parts[1].strip())
            if count < 1:
                count = 1
            return persona_id, count
        except ValueError:
            return persona_id, 1
    return persona_spec.strip(), 1


def expand_persona_list(persona_specs: list[str]) -> list[tuple[str, int]]:
    """Expand a list of persona specifications into individual instances."""
    result = []
    persona_counters: dict[str, int] = {}

    for spec in persona_specs:
        persona_id, count = parse_persona_with_multiplier(spec)
        if persona_id not in persona_counters:
            persona_counters[persona_id] = 0

        for _ in range(count):
            persona_counters[persona_id] += 1
            result.append((persona_id, persona_counters[persona_id]))

    return result


async def _send_progress_update(
    task: Any,
    polling_client: Any,
    progress_tracker: ProgressTracker,
    session_id: str,
    target_url: str,
) -> bool:
    """Send progress update to API via polling client.

    Returns:
        True if stop was requested by the server, False otherwise.
    """
    if not polling_client or not task:
        return False

    try:
        progress_data = progress_tracker.get_progress_snapshot()
        progress_snapshot = ProgressSnapshot(
            orchestrator=OrchestratorProgressInfo(**progress_data["orchestrator"]),
            app_discovery=(
                AppDiscoveryProgressInfo(**progress_data["app_discovery"])
                if "app_discovery" in progress_data and progress_data["app_discovery"]
                else None
            ),
            personas={
                name: PersonaProgressInfo(**data)
                for name, data in progress_data["personas"].items()
            },
            updated_at=progress_data["updated_at"],
        )

        result = TaskResult(
            session_id=session_id,
            target_url=target_url,
            progress=progress_snapshot,
        )

        response = await polling_client.send_progress_update(task, result)
        if hasattr(response, "command") and response.command == AgentCommand.STOP:
            logger.warning(
                f"🛑 Received STOP command from API for session {session_id}"
            )
            progress_tracker.stop_requested = True
            return True
        logger.debug(f"Sent progress update for session {session_id}")
        return False
    except Exception as e:
        logger.warning(f"Failed to send progress update: {e}")
        return False


# =============================================================================
# Node 1: Connectivity Check
# =============================================================================


class ConnectivityCheckNode(MultiAgentBase):
    """
    Check if target URL is reachable from agent runtime and browser.

    Input: Configuration from graph invocation
    Output State: connectivity_verified (bool)
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        import httpx

        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        target_url = config.get(
            "target_url", str(task) if isinstance(task, str) else ""
        )

        logger.info("=" * 80)
        logger.info("Graph Orchestrator - Connectivity Check")
        logger.info(f"Target URL: {target_url}")
        logger.info("=" * 80)

        # Check basic HTTP connectivity
        logger.info(f"🔍 Checking connectivity to {target_url}...")
        try:
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
                response = await client.get(target_url)
                logger.info(f"✓ Target reachable: HTTP {response.status_code}")
        except Exception as e:
            error_msg = f"CRITICAL: Unable to reach target URL {target_url}: {e}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

        # Check browser connectivity (for AgentCore)
        from core.browser import get_browser_manager

        browser_manager = get_browser_manager()

        # Only check browser connectivity for AgentCore
        try:
            from platforms.aws_agentcore.browser import AgentCoreBrowserManager

            if isinstance(browser_manager, AgentCoreBrowserManager):
                logger.info(f"🔍 Checking BROWSER connectivity to {target_url}...")
                # Browser connectivity check would go here
                # For now, we trust basic HTTP check passed
                logger.info("✓ Browser connectivity assumed OK")
        except ImportError:
            pass  # Not on AWS, skip browser check

        state["connectivity_verified"] = True
        return _make_result({"accumulated_state": state}, "Connectivity verified")


# =============================================================================
# Node 2: Session Setup
# =============================================================================


class SessionSetupNode(MultiAgentBase):
    """
    Initialize session: create directories, setup logging, analytics, polling.

    Input: Configuration from graph invocation
    Output State:
        - session_id
        - output_dir
        - domain
        - domain_settings_path
        - progress_tracker
        - agent_identity
        - run_metrics
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        target_url = config.get(
            "target_url", str(task) if isinstance(task, str) else ""
        )

        logger.info("=" * 80)
        logger.info("Graph Orchestrator - Session Setup")
        logger.info(f"Target URL: {target_url}")
        logger.info("=" * 80)

        # Get agent identity from platform adapter
        agent_identity = None
        platform_adapter = config.get("platform_adapter")
        if platform_adapter and hasattr(platform_adapter, "get_agent_identity"):
            try:
                agent_identity = platform_adapter.get_agent_identity()
                logger.info(
                    f"✓ Agent identity: {agent_identity.name} on {agent_identity.platform}"
                )
            except Exception as e:
                logger.warning(f"Failed to get agent identity: {e}")

        # Handle polling mode - mark task as active
        polling_client = config.get("polling_client")
        polling_task = config.get("task")

        if polling_task and polling_client:
            try:
                command_response = await polling_client.mark_active(
                    polling_task, agent_identity
                )
                logger.info(
                    f"✓ Task marked as ACTIVE, command: {command_response.command}"
                )

                if command_response.command == AgentCommand.STOP:
                    logger.warning(
                        f"Received STOP command from API: {command_response.message or 'No message'}"
                    )
                    stopped_session_id = (
                        f"stopped_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                    )
                    state[STATE_SESSION_ID] = stopped_session_id
                    state["stopped"] = True
                    state["stop_reason"] = command_response.message
                    return _make_result(
                        {"accumulated_state": state},
                        f"Task stopped by API: {command_response.message}",
                    )
            except Exception as e:
                logger.warning(f"Failed to mark task as ACTIVE: {e}")

            # Set polling context for HITL interventions
            try:
                set_polling_context(polling_client, polling_task, agent_identity)
                logger.info("✓ Polling context set for HITL interventions")
            except Exception as e:
                logger.warning(f"Failed to set polling context: {e}")

            # Wire polling client into browser manager for server-side HITL
            try:
                from core.browser import get_browser_manager

                bm = get_browser_manager()
                wire_fn = getattr(bm, "set_polling_client", None)
                if callable(wire_fn):
                    task_id = polling_task.task_id if polling_task else None
                    wire_fn(polling_client, task_id=task_id)
                    logger.info("✓ Browser manager wired for server-side HITL")
            except Exception as e:
                logger.warning(f"Failed to wire browser manager for HITL: {e}")

        # Generate session ID and output directory
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        goal = config.get("goal", "chat")
        session_prefix = config.get("session_prefix")
        output_dir = config.get("output_dir")

        if output_dir is None:
            if goal == "discover":
                output_dir = f"sessions/discovery_{timestamp}"
            elif goal == "ground_truth":
                output_dir = f"sessions/ground_truth_{timestamp}"
            elif session_prefix:
                output_dir = f"sessions/{session_prefix}_conversation_{timestamp}"
            else:
                output_dir = f"sessions/conversation_{timestamp}"

        session_id = Path(output_dir).name
        output_path = Path(output_dir)
        os.makedirs(output_path, exist_ok=True)

        # Setup logging
        setup_logging(session_dir=output_path)
        logger.info(f"Session folder: {output_path}")

        # Domain settings
        domain = get_domain_from_url(target_url)
        domain_settings_path = Path(DOMAIN_SETTINGS_DIR) / domain
        domain_settings_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"Domain: {domain}")

        # Clean up cache if force_discovery
        if config.get("force_discovery", False):
            logger.info("🔄 Clearing cached domain artifacts...")
            try:
                delete_domain_cache(domain, org_id=config.get("org_id"))
            except Exception as e:
                logger.warning(f"Failed to clear S3 cache: {e}")
            if domain_settings_path.exists():
                import shutil

                for item in domain_settings_path.iterdir():
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item)
            domain_settings_path.mkdir(parents=True, exist_ok=True)

        # Track analytics
        analytics = AnalyticsClient.get_instance()
        persona_ids = config.get("persona_ids", ["nice_user"])
        run_metrics = analytics.track_run_start(
            session_id=session_id,
            target_url=target_url,
            num_personas=len(persona_ids),
            org_id=config.get("org_id"),
            goal=goal,
            task_id=config.get("task_id"),
        )

        # Expand personas
        expanded_personas = expand_persona_list(
            apply_persona_exclusions(
                expand_glob_patterns(persona_ids),
                config.get("exclude_persona_ids"),
            )
        )

        # Initialize progress tracker
        progress_tracker = ProgressTracker(
            session_id=session_id,
            target_url=target_url,
            output_dir=str(output_path),
            total_personas=len(expanded_personas),
            org_id=config.get("org_id"),
            task_id=config.get("task_id"),
            goal=goal,
            polling_client=polling_client,
            task=polling_task,
        )
        progress_tracker.update_orchestrator(
            status=ExecutionStatus.RUNNING,
            phase=OrchestratorPhase.INITIALIZING,
            last_action="Session initialized",
        )
        # Track graph node progress
        progress_tracker.update_graph_node("connectivity_check", "completed")
        progress_tracker.update_graph_node("session_setup", "running")

        # Send initial progress update so the UI shows progress immediately
        await _send_progress_update(
            polling_task, polling_client, progress_tracker, session_id, target_url
        )

        # Initialize timing logger
        timing_log_file = output_path / "agent-timing.log"
        get_timing_logger(timing_log_file)
        logger.info(f"✓ Started timing logger: {timing_log_file}")

        # Start credential monitoring
        pause_file = output_path / ".arato_paused"
        credential_manager = get_credential_manager(pause_file)
        credential_check_task = asyncio.create_task(
            check_credentials_periodically(
                interval_minutes=30, credential_manager=credential_manager
            )
        )
        logger.info("✓ Started credential monitoring (30 min intervals)")

        # Build state for next node
        state.update(
            {
                STATE_TARGET_URL: target_url,
                STATE_SESSION_ID: session_id,
                STATE_OUTPUT_DIR: str(output_path),
                STATE_DOMAIN: domain,
                STATE_DOMAIN_SETTINGS_PATH: str(domain_settings_path),
                STATE_PROGRESS_TRACKER: progress_tracker,
                STATE_PERSONA_RESULTS: {},
                STATE_TOTAL_TOKENS: 0,
                STATE_AGENT_IDENTITY: agent_identity,
                STATE_RUN_METRICS: run_metrics,
                STATE_CREDENTIAL_CHECK_TASK: credential_check_task,
                STATE_EXPANDED_PERSONAS: expanded_personas,
                "credential_manager": credential_manager,
            }
        )

        # Store progress_tracker ref in config so run_pipeline can flush on timeout
        config["_progress_tracker"] = progress_tracker

        logger.info(f"✓ Session setup complete: {session_id}")
        logger.info(
            f"  Expanded {len(persona_ids)} specs to {len(expanded_personas)} instances"
        )

        progress_tracker.update_graph_node("session_setup", "completed")
        return _make_result(
            {"accumulated_state": state}, f"Session {session_id} initialized"
        )


# =============================================================================
# Node 3: App Discovery
# =============================================================================


class AppDiscoveryNode(MultiAgentBase):
    """
    Run app context discovery (with caching).

    Input State: session_id, output_dir, domain, domain_settings_path
    Output State: app_context (markdown string)
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})

        # Check if stopped
        if state.get("stopped"):
            return _make_result({"accumulated_state": state}, "Task was stopped")

        target_url = state[STATE_TARGET_URL]
        domain = state[STATE_DOMAIN]
        domain_settings_path = Path(state[STATE_DOMAIN_SETTINGS_PATH])
        output_dir = state[STATE_OUTPUT_DIR]
        progress_tracker: ProgressTracker = state[STATE_PROGRESS_TRACKER]
        org_id = config.get("org_id")
        goal = config.get("goal", "chat")
        force_discovery = config.get("force_discovery", False)
        test_suite = config.get("test_suite")
        polling_client = config.get("polling_client")
        polling_task = config.get("task")
        session_id = state[STATE_SESSION_ID]

        progress_tracker.update_graph_node("app_discovery", "running")
        progress_tracker.update_orchestrator(
            phase=OrchestratorPhase.DISCOVERY,
            last_action="Starting app context discovery",
        )

        # Send progress update
        await _send_progress_update(
            polling_task, polling_client, progress_tracker, session_id, target_url
        )

        # Priority 1: Test suite provides application_context
        app_context: str | None = None

        if (
            test_suite
            and hasattr(test_suite, "application_context")
            and test_suite.application_context
        ):
            raw_context = test_suite.application_context
            # Validate: must be a string and within reasonable size limits
            if not isinstance(raw_context, str):
                logger.warning(
                    "[TEST SUITE] application_context is not a string, skipping"
                )
            elif len(raw_context) > 100_000:
                logger.warning(
                    f"[TEST SUITE] application_context too large ({len(raw_context)} chars), truncating to 100k"
                )
                app_context = raw_context[:100_000]
            else:
                app_context = raw_context
            if app_context:
                logger.info("\n[TEST SUITE] Using application_context from test suite")
                logger.info(f"✓ Test suite context: {len(app_context)} characters")

            # Write to disk for chat runner (only if we have context)
            if app_context:
                app_context_file_path = domain_settings_path / APP_CONTEXT_FILENAME
                with open(app_context_file_path, "w") as f:
                    f.write(app_context)

                progress_tracker.update_app_discovery(
                    status=ExecutionStatus.COMPLETED,
                    current_step=5,
                    last_action="App context loaded from test suite",
                    app_context_json=app_context,
                    screenshots=[],
                    discovery_video=None,
                )
                progress_tracker.update_orchestrator(
                    last_action="App context loaded from test suite",
                    app_context_cached=True,
                )

        # Priority 2: Check cache (for discover goal)
        elif goal == "discover":
            logger.info("\n[STEP 1] App Context Discovery - Checking cache...")

            if not force_discovery:
                app_context = download_domain_cache(
                    domain, APP_CONTEXT_FILENAME, org_id=org_id
                )
                if not app_context:
                    domain_context_file = domain_settings_path / APP_CONTEXT_FILENAME
                    if domain_context_file.exists():
                        with open(domain_context_file) as f:
                            app_context = f.read()

            if app_context:
                logger.info("✓ Using cached app context!")
                progress_tracker.update_orchestrator(
                    last_action="App context loaded from cache",
                    app_context_cached=True,
                )
            else:
                # Run discovery agent
                logger.info("Discovering app context...")
                headless = config.get("headless", True)

                discovery_agent = AppContextDiscoveryAgent(headless=headless)

                app_context = await discovery_agent.discover_app_context(
                    target_url,
                    session_dir=output_dir,
                    timeout=DEFAULT_PIPELINE_TIMEOUT,
                    domain_dir=str(domain_settings_path),
                    progress_tracker=progress_tracker,
                    org_id=org_id,
                )

                # Cache it
                upload_domain_cache(
                    domain, app_context, APP_CONTEXT_FILENAME, org_id=org_id
                )
                with open(domain_settings_path / APP_CONTEXT_FILENAME, "w") as f:
                    f.write(app_context)

                progress_tracker.update_orchestrator(
                    last_action="App context discovery completed",
                    app_context_cached=False,
                )
                logger.info("✓ App context discovered and cached")

        # Priority 3: Chat mode - skip discovery
        else:
            logger.info("[CHAT MODE] Skipping app context discovery")
            progress_tracker.update_orchestrator(
                last_action="App context discovery skipped (chat mode)",
            )

        state[STATE_APP_CONTEXT] = app_context

        # Send progress update
        await _send_progress_update(
            polling_task, polling_client, progress_tracker, session_id, target_url
        )

        progress_tracker.update_graph_node("app_discovery", "completed")
        return _make_result({"accumulated_state": state}, "App context ready")


# =============================================================================
# Node 4: Ground Truth (Optional)
# =============================================================================


class GroundTruthNode(MultiAgentBase):
    """
    Collect ground truth data (if goal is ground_truth).

    Input State: app_context, domain_settings_path
    Output State: ground_truth_data
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        goal = config.get("goal", "chat")
        progress_tracker: ProgressTracker = state[STATE_PROGRESS_TRACKER]

        # Skip if not ground_truth goal
        if goal != "ground_truth":
            logger.info("[SKIP] Ground truth collection (goal != ground_truth)")
            progress_tracker.update_graph_node("ground_truth", "skipped")
            return _make_result({"accumulated_state": state}, "Ground truth skipped")

        # Check if stopped
        if state.get("stopped"):
            progress_tracker.update_graph_node("ground_truth", "skipped")
            return _make_result({"accumulated_state": state}, "Task was stopped")

        progress_tracker.update_graph_node("ground_truth", "running")

        target_url = state[STATE_TARGET_URL]
        output_dir = state[STATE_OUTPUT_DIR]

        logger.info("\n[GROUND TRUTH] Collecting ground truth data...")
        progress_tracker.update_orchestrator(
            last_action="Collecting ground truth data",
        )

        try:
            from agents.ground_truth_agent import GroundTruthAgent

            headless = config.get("headless", True)
            ground_truth_agent_id = config.get("ground_truth_agent_id", "default")
            storage_state = config.get("storage_state")
            org_id = config.get("org_id")
            force_ground_truth = config.get("force_ground_truth", False)

            ground_truth_agent = GroundTruthAgent(headless=headless)

            ground_truth_data = await ground_truth_agent.collect_ground_truth(
                agent_id=ground_truth_agent_id,
                session_dir=output_dir,
                target_url=target_url,
                storage_state=storage_state,
                org_id=org_id,
                force_collection=force_ground_truth,
            )

            state["ground_truth_data"] = ground_truth_data
            logger.info("✓ Ground truth collection completed")

        except Exception as e:
            logger.error(f"Ground truth collection failed: {e}")
            state["ground_truth_error"] = str(e)
            progress_tracker.update_graph_node("ground_truth", "failed", error=str(e))
            return _make_result({"accumulated_state": state}, "Ground truth processed")

        progress_tracker.update_graph_node("ground_truth", "completed")
        return _make_result({"accumulated_state": state}, "Ground truth processed")


# =============================================================================
# Node 5: Persona Runner (Parallel)
# =============================================================================


class PersonaRunnerNode(MultiAgentBase):
    """
    Run chat conversations for all personas in parallel.

    Input State: app_context, session_id, output_dir
    Output State: persona_results (dict mapping persona name to result)
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        goal = config.get("goal", "chat")
        progress_tracker: ProgressTracker = state[STATE_PROGRESS_TRACKER]

        # Check if stopped
        if state.get("stopped"):
            progress_tracker.update_graph_node("persona_runner", "skipped")
            return _make_result({"accumulated_state": state}, "Task was stopped")

        # Skip persona execution for non-chat goals
        if goal in ("discover", "ground_truth"):
            logger.info(f"[{goal.upper()} MODE] Skipping persona execution")
            state[STATE_PERSONA_RESULTS] = {}
            progress_tracker.update_graph_node("persona_runner", "skipped")
            return _make_result(
                {"accumulated_state": state}, f"Personas skipped for {goal} mode"
            )

        progress_tracker.update_graph_node("persona_runner", "running")

        target_url = state[STATE_TARGET_URL]
        session_id = state[STATE_SESSION_ID]
        output_dir = state[STATE_OUTPUT_DIR]
        domain_settings_path = Path(state[STATE_DOMAIN_SETTINGS_PATH])
        expanded_personas = state.get(STATE_EXPANDED_PERSONAS, [])
        agent_identity = state.get(STATE_AGENT_IDENTITY)
        credential_manager = state.get("credential_manager")

        # Config
        seed_utterance = config.get("seed_utterance", DEFAULT_SEED_UTTERANCE)
        max_turns = config.get("max_turns", DEFAULT_MAX_TURNS)
        max_parallel = config.get("max_parallel", DEFAULT_MAX_PARALLEL_PERSONAS)
        headless = config.get("headless", True)
        storage_state = config.get("storage_state")
        step_timeout = config.get("step_timeout", DEFAULT_STEP_TIMEOUT)
        timeout = config.get("timeout", DEFAULT_PIPELINE_TIMEOUT)
        arato_api_url = config.get("arato_api_url")
        arato_api_key = config.get("arato_api_key")
        broadcast_identity = config.get("broadcast_identity", False)
        task_id = config.get("task_id")
        org_id = config.get("org_id")
        target_urls = config.get("target_urls")
        polling_client = config.get("polling_client")
        polling_task = config.get("task")
        test_suite = config.get("test_suite")
        domain_config = config.get("domain")
        thread_id = config.get("thread_id")

        logger.info(
            f"\n[STEP 2] Running {len(expanded_personas)} persona(s) with max {max_parallel} parallel..."
        )
        progress_tracker.update_orchestrator(
            phase=OrchestratorPhase.RUNNING_PERSONAS,
            last_action=f"Starting {len(expanded_personas)} personas",
        )

        # Send progress update
        await _send_progress_update(
            polling_task, polling_client, progress_tracker, session_id, target_url
        )

        # Build URL pool
        url_pool = target_urls if target_urls else [target_url]

        # Create ChatRunner
        chat_runner = ChatRunner(
            headless=headless,
            storage_state=storage_state,
        )

        persona_tasks: list[tuple[str, str, Path, str]] = []

        for persona_id, instance_num in expanded_personas:
            # Generate instance name
            total_instances = sum(1 for p, _ in expanded_personas if p == persona_id)
            if total_instances > 1:
                persona_instance = f"{persona_id}_consumer_{instance_num:02d}"
            else:
                persona_instance = f"{persona_id}_consumer"

            persona_dir = Path(output_dir) / persona_instance
            persona_dir.mkdir(parents=True, exist_ok=True)

            # Select random URL
            persona_url = random.choice(url_pool)

            persona_tasks.append(
                (persona_id, persona_instance, persona_dir, persona_url)
            )

            # Add to progress tracker
            progress_tracker.add_persona(
                persona_id=persona_id,
                instance_name=persona_instance,
                total_steps=max_turns,
            )

        # Run personas in parallel with semaphore.
        # On a 2vCPU/8GB AgentCore MicroVM, ~15 concurrent is the safe max
        # (memory, httpx connections, file descriptors). Personas beyond
        # max_parallel queue on the semaphore and start as slots free up.
        semaphore = asyncio.Semaphore(max_parallel)
        results: dict[str, Any] = {}
        total_tokens = 0

        async def run_single_persona(
            persona_id: str,
            persona_instance: str,
            persona_dir: Path,
            persona_url: str,
        ) -> tuple[str, dict[str, Any]]:
            # === Run conversation under semaphore (limits browser concurrency) ===
            async with semaphore:
                # Check if stop was requested before starting this persona
                if progress_tracker.stop_requested:
                    logger.warning(
                        f"🛑 Skipping {persona_instance} — stop requested by user"
                    )
                    progress_tracker.update_persona(
                        instance_name=persona_instance,
                        status=ExecutionStatus.COMPLETED,
                        last_action="Skipped (stop requested)",
                        finish_reason=FinishReason.USER_STOPPED,
                    )
                    return persona_instance, {
                        "status": "stopped",
                        "finish_reason": "user_stopped",
                        "total_turns": 0,
                    }

                # Wait if credentials refresh is needed
                if credential_manager:
                    await credential_manager.wait_if_paused()

                logger.info(f"Starting {persona_instance}...")

                progress_tracker.update_persona(
                    instance_name=persona_instance,
                    status=ExecutionStatus.RUNNING,
                    last_action="Starting conversation",
                )

                # Update polling context
                if polling_client and polling_task:
                    try:
                        set_polling_context(
                            polling_client,
                            polling_task,
                            agent_identity,
                            progress_tracker,
                            persona_instance,
                        )
                    except Exception as e:
                        logger.warning(f"Failed to update polling context: {e}")

                try:
                    # Get test suite ID if available
                    test_suite_id = None
                    if test_suite and hasattr(test_suite, "id"):
                        test_suite_id = test_suite.id

                    result = await chat_runner.run_conversation(
                        target_url=persona_url,
                        seed_utterance=seed_utterance,
                        max_turns=max_turns,
                        output_dir=str(persona_dir),
                        app_context_file=str(
                            domain_settings_path / APP_CONTEXT_FILENAME
                        ),
                        persona_id=persona_id,
                        persona_instance=persona_instance,
                        arato_api_url=arato_api_url,
                        arato_api_key=arato_api_key,
                        thread_id=thread_id,
                        run_id=session_id,
                        org_id=org_id,
                        step_timeout=step_timeout,
                        timeout=timeout,
                        progress_tracker=progress_tracker,
                        broadcast_identity=broadcast_identity,
                        task_id=task_id,
                        domain=domain_config,
                        test_suite_id=test_suite_id,
                    )

                except Exception as e:
                    logger.exception(f"Error running {persona_instance}: {e}")
                    progress_tracker.update_persona(
                        instance_name=persona_instance,
                        status=ExecutionStatus.FAILED,
                        error=str(e),
                    )
                    return persona_instance, {"error": str(e), "status": "failed"}

            # === Outside semaphore: upload + progress update ===
            # Semaphore released — next persona can start its conversation immediately
            # while this one uploads artifacts to S3.

            # Map finish reason
            finish_reason_str = result.get("finish_reason", "unknown")
            finish_reason = {
                "reached_max_turns": FinishReason.REACHED_MAX_TURNS,
                "agent_stopped": FinishReason.AGENT_STOPPED,
                "chatbot_stopped": FinishReason.CHATBOT_STOPPED,
                "timeout": FinishReason.TIMEOUT,
                "user_stopped": FinishReason.USER_STOPPED,
                "error": FinishReason.ERROR,
            }.get(finish_reason_str, FinishReason.UNKNOWN)

            # Upload persona artifacts in a thread (don't block the event loop)
            file_urls: dict[str, str] = {}
            try:
                logger.info(f"Uploading artifacts for {persona_instance}...")
                file_urls = await asyncio.to_thread(
                    upload_persona_artifacts,
                    persona_directory=str(persona_dir),
                    persona_instance_name=persona_instance,
                    session_id=session_id,
                    org_id=org_id,
                    task_id=task_id,
                )
                logger.info(
                    f"✓ Uploaded {len(file_urls)} artifacts for {persona_instance}"
                )
                result["file_urls"] = file_urls
            except Exception as e:
                logger.warning(
                    f"Failed to upload artifacts for {persona_instance}: {e}"
                )

            # Extract artifact URLs for progress tracker
            video_url = file_urls.get(f"{persona_instance}/{RUN_VIDEO_FILENAME}")
            transcript_url = file_urls.get(f"{persona_instance}/{TRANSCRIPT_FILENAME}")
            summary_url = file_urls.get(f"{persona_instance}/{SUMMARY_FILENAME}")

            progress_tracker.update_persona(
                instance_name=persona_instance,
                status=ExecutionStatus.COMPLETED,
                last_action="Conversation completed",
                finish_reason=finish_reason,
                persona_video=video_url,
                transcript_json=transcript_url,
                summary_json=summary_url,
            )
            logger.info(
                f"✓ {persona_instance} completed: {result.get('total_turns', 0)} turns"
            )

            return persona_instance, result

        # Execute all personas
        tasks = [
            run_single_persona(pid, pinst, pdir, purl)
            for pid, pinst, pdir, purl in persona_tasks
        ]
        completed = await asyncio.gather(*tasks, return_exceptions=True)

        for item in completed:
            if isinstance(item, Exception):
                logger.error(f"Persona task exception: {item}")
            elif isinstance(item, tuple):
                name, result = item
                results[name] = result
                if "usage" in result:
                    total_tokens += result["usage"].get("total_tokens", 0)

        state[STATE_PERSONA_RESULTS] = results
        state[STATE_TOTAL_TOKENS] = state.get(STATE_TOTAL_TOKENS, 0) + total_tokens

        # Propagate stop flag from progress tracker to graph state
        if progress_tracker.stop_requested:
            state["stopped"] = True
            logger.warning(
                "🛑 Stop flag propagated to graph state after persona execution"
            )

        progress_tracker.update_orchestrator(
            last_action=f"Completed {len(results)} personas",
        )

        # Send progress update
        await _send_progress_update(
            polling_task, polling_client, progress_tracker, session_id, target_url
        )

        progress_tracker.update_graph_node("persona_runner", "completed")
        return _make_result(
            {"accumulated_state": state},
            f"Completed {len(results)} persona conversations",
        )


# =============================================================================
# Node 6: Cross-Conversation Analysis
# =============================================================================


class CrossConversationNode(MultiAgentBase):
    """
    Run cross-conversation analysis with sub-agents.

    Input State: persona_results, app_context
    Output State: cross_conversation_findings
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        goal = config.get("goal", "chat")
        persona_results = state.get(STATE_PERSONA_RESULTS, {})
        app_context = state.get(STATE_APP_CONTEXT, "")
        progress_tracker: ProgressTracker = state[STATE_PROGRESS_TRACKER]
        session_id = state[STATE_SESSION_ID]
        output_dir = state[STATE_OUTPUT_DIR]

        # Check if stopped
        if state.get("stopped"):
            progress_tracker.update_graph_node("cross_conversation", "skipped")
            return _make_result({"accumulated_state": state}, "Task was stopped")

        # Skip for non-chat modes
        if goal != "chat" or not persona_results:
            logger.info(f"[{goal.upper()} MODE] Skipping cross-conversation analysis")
            state[STATE_CROSS_FINDINGS] = []
            progress_tracker.update_graph_node("cross_conversation", "skipped")
            return _make_result({"accumulated_state": state}, "Analysis skipped")

        progress_tracker.update_graph_node("cross_conversation", "running")
        logger.info("\nRunning cross-conversation analysis with sub-agents...")
        progress_tracker.update_orchestrator(
            phase=OrchestratorPhase.GENERATING_SUMMARY,
            last_action="Running cross-conversation analysis",
        )

        cross_conversation_findings: list[dict[str, Any]] = []

        try:
            # Gather findings from summary and transcript separately to avoid duplication
            # Summary findings are already derived from transcript findings
            summary_findings: list[dict[str, Any]] = []
            summary_finding_ids: set[str] = set()
            transcript_only_findings: list[dict[str, Any]] = []

            for persona_name, result in persona_results.items():
                # Get summary findings (from summary.json)
                if isinstance(result, dict) and "findings" in result:
                    for finding in result["findings"]:
                        summary_findings.append(finding)
                        # Track IDs to filter duplicates
                        if "id" in finding:
                            summary_finding_ids.add(finding["id"])

                # Get transcript findings that are NOT already in summary
                persona_dir = Path(output_dir) / persona_name
                if persona_dir.exists():
                    try:
                        transcript_findings = extract_evals_from_transcript(persona_dir)
                        # Only include findings not already in summary
                        for finding_obj in transcript_findings:
                            finding_dict = finding_to_dict(finding_obj)
                            finding_id = finding_dict.get("id")
                            if finding_id and finding_id not in summary_finding_ids:
                                transcript_only_findings.append(finding_dict)
                    except Exception as e:
                        logger.warning(
                            f"Failed to load transcript findings for {persona_name}: {e}"
                        )

            # Combine summary findings and transcript-only findings
            all_findings = summary_findings + transcript_only_findings

            # Cap findings to avoid context window overflow with 100+ personas
            MAX_FINDINGS_FOR_CROSS_ANALYSIS = 500
            if len(all_findings) > MAX_FINDINGS_FOR_CROSS_ANALYSIS:
                logger.warning(
                    f"Capping findings from {len(all_findings)} to "
                    f"{MAX_FINDINGS_FOR_CROSS_ANALYSIS} for cross-analysis"
                )
                # Prioritize critical/warning findings over good ones
                critical = [f for f in all_findings if f.get("label") == "Critical"]
                warning = [f for f in all_findings if f.get("label") == "Warning"]
                good = [
                    f
                    for f in all_findings
                    if f.get("label") not in ("Critical", "Warning")
                ]
                all_findings = (critical + warning + good)[
                    :MAX_FINDINGS_FOR_CROSS_ANALYSIS
                ]

            # Gather conversation IDs
            conversation_ids = list(persona_results.keys())

            # Run sub-agents
            cross_conv_start = time.time()
            registry = get_agent_registry()

            # Build test_suite_config dict from TestSuite object
            test_suite = config.get("test_suite")
            test_suite_config: dict[str, Any] = {}
            if test_suite:
                test_suite_config = {
                    "allowed_disclosures": getattr(
                        test_suite, "allowed_disclosures", []
                    ),
                    "questions_to_answer": getattr(
                        test_suite, "questions_to_answer", []
                    ),
                    "key_risks": getattr(test_suite, "key_risks", []),
                    "compliance_requirements": getattr(
                        test_suite, "compliance_requirements", {}
                    ),
                }

            findings = await registry.summarize_run(
                run_id=session_id,
                target_url=state.get(STATE_TARGET_URL),
                app_context=app_context,
                conversation_ids=conversation_ids,
                session_dir=output_dir,
                all_findings=summary_findings,
                findings_from_transcripts=transcript_only_findings,
                test_suite_config=test_suite_config,
            )

            cross_conv_duration = time.time() - cross_conv_start
            log_timing(
                "cross_conversation_analysis",
                cross_conv_duration,
                {
                    "num_conversations": len(conversation_ids),
                    "num_findings": len(findings),
                },
            )

            cross_conversation_findings = [finding_to_dict(f) for f in findings]
            logger.info(
                f"✓ Cross-conversation analysis: {len(findings)} findings in {cross_conv_duration:.2f}s"
            )

            # Save findings to file
            if cross_conversation_findings:
                findings_path = Path(output_dir) / CROSS_CONVERSATION_FINDINGS_FILENAME
                save_json_file({"findings": cross_conversation_findings}, findings_path)
                logger.info(f"✓ Saved cross-conversation findings to {findings_path}")

            # Get token usage from sub-agents
            subagent_usage = registry.get_all_token_usage()
            for usage in subagent_usage:
                state[STATE_TOTAL_TOKENS] = (
                    state.get(STATE_TOTAL_TOKENS, 0) + usage.total_tokens
                )
            registry.clear_all_token_usage()

        except Exception as e:
            logger.warning(f"Cross-conversation analysis failed: {e}")
            logger.debug(traceback.format_exc())
            progress_tracker.update_graph_node(
                "cross_conversation", "failed", error=str(e)
            )

        state[STATE_CROSS_FINDINGS] = cross_conversation_findings
        progress_tracker.update_graph_node("cross_conversation", "completed")

        return _make_result(
            {"accumulated_state": state},
            f"Cross-conversation analysis complete: {len(cross_conversation_findings)} findings",
        )


# =============================================================================
# Node 7: Summary Generation
# =============================================================================


class SummaryNode(MultiAgentBase):
    """
    Generate consolidated summary and reports.

    Input State: persona_results, cross_conversation_findings, output_dir
    Output State: summary_generated (bool)
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        output_dir = state[STATE_OUTPUT_DIR]
        target_url = state[STATE_TARGET_URL]
        progress_tracker: ProgressTracker = state[STATE_PROGRESS_TRACKER]
        persona_results = state.get(STATE_PERSONA_RESULTS, {})
        goal = config.get("goal", "chat")
        include_eu_ai_act_report = config.get("include_eu_ai_act_report", False)
        test_suite = config.get("test_suite")

        # Check if stopped
        if state.get("stopped"):
            progress_tracker.update_graph_node("summary", "skipped")
            return _make_result({"accumulated_state": state}, "Task was stopped")

        progress_tracker.update_orchestrator(
            phase=OrchestratorPhase.GENERATING_SUMMARY,
            last_action="Generating consolidated summary",
        )

        # Skip summary generation for non-chat modes
        if goal != "chat" or not persona_results:
            logger.info("Skipping summary generation (no persona results)")
            progress_tracker.update_graph_node("summary", "skipped")
            return _make_result({"accumulated_state": state}, "Summary skipped")

        progress_tracker.update_graph_node("summary", "running")
        logger.info("\nGenerating consolidated summary...")

        # Get persona IDs from results
        persona_ids = list(persona_results.keys())

        try:
            summary_start = time.time()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

            await generate_consolidated_summary(
                target_url=target_url,
                results=persona_results,
                persona_ids=persona_ids,
                output_dir=output_dir,
                timestamp=timestamp,
                include_eu_ai_act_report=include_eu_ai_act_report,
                test_suite=test_suite,
            )

            summary_duration = time.time() - summary_start
            log_timing(
                "consolidated_summary_generation",
                summary_duration,
                {"num_personas": len(persona_ids)},
            )

            logger.info(f"✓ Summary generated in {summary_duration:.2f}s")

            progress_tracker.update_orchestrator(
                last_action=f"Summary generated in {summary_duration:.2f}s",
            )

        except Exception as e:
            logger.error(f"Failed to generate summary: {e}")
            logger.error(traceback.format_exc())
            progress_tracker.update_orchestrator(
                last_action=f"Summary generation failed: {str(e)}",
            )
            progress_tracker.update_graph_node("summary", "failed", error=str(e))
            return _make_result({"accumulated_state": state}, "Summary generated")

        progress_tracker.update_graph_node("summary", "completed")
        return _make_result({"accumulated_state": state}, "Summary generated")


# =============================================================================
# Node 8: Artifact Upload
# =============================================================================


class ArtifactUploadNode(MultiAgentBase):
    """
    Upload all artifacts to storage.

    Input State: output_dir, session_id
    Output State: artifacts_info
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        output_dir = state[STATE_OUTPUT_DIR]
        session_id = state[STATE_SESSION_ID]
        progress_tracker: ProgressTracker = state[STATE_PROGRESS_TRACKER]
        org_id = config.get("org_id")
        task_id = config.get("task_id")

        # Check if stopped
        if state.get("stopped"):
            progress_tracker.update_graph_node("artifact_upload", "skipped")
            return _make_result({"accumulated_state": state}, "Task was stopped")

        progress_tracker.update_graph_node("artifact_upload", "running")
        progress_tracker.update_orchestrator(
            phase=OrchestratorPhase.UPLOADING_ARTIFACTS,
            last_action="Uploading artifacts to storage",
        )

        logger.info("\nUploading artifacts to storage...")

        try:
            artifacts_info = upload_session_artifacts(
                output_dir, session_id=session_id, org_id=org_id, task_id=task_id
            )
            state[STATE_ARTIFACTS_INFO] = artifacts_info

            # Set file URL mappings in progress tracker
            file_urls = artifacts_info.get("file_urls", {})
            if isinstance(file_urls, dict):
                progress_tracker.set_file_url_mappings(file_urls)
                logger.info(f"Set file URL mappings with {len(file_urls)} entries")

            # Build storage location string
            storage_location = "storage"
            if "bucket" in artifacts_info:
                bucket = artifacts_info.get("bucket")
                prefix = artifacts_info.get("prefix", "")
                if isinstance(bucket, str):
                    storage_location = f"s3://{bucket}/{prefix}"
            elif "location" in artifacts_info:
                location = artifacts_info.get("location")
                if isinstance(location, str):
                    storage_location = location

            progress_tracker.update_orchestrator(
                last_action=f"Artifacts uploaded: {artifacts_info.get('file_count', 'N/A')} files to {storage_location}",
            )

            logger.info(f"✓ Uploaded to {storage_location}")

        except Exception as e:
            logger.error(f"Failed to upload artifacts: {e}")
            state[STATE_ARTIFACTS_INFO] = {"error": str(e)}
            progress_tracker.update_graph_node(
                "artifact_upload", "failed", error=str(e)
            )
            return _make_result({"accumulated_state": state}, "Artifacts uploaded")

        progress_tracker.update_graph_node("artifact_upload", "completed")
        return _make_result({"accumulated_state": state}, "Artifacts uploaded")


# =============================================================================
# Node 9: Task Completion
# =============================================================================


class TaskCompletionNode(MultiAgentBase):
    """
    Mark task as complete and send final progress update.

    Input State: All accumulated state
    Output State: Final completion status
    """

    async def invoke_async(
        self,
        task: MultiAgentInput,
        invocation_state: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiAgentResult:
        state = _extract_state(invocation_state)
        config = state.get(STATE_CONFIG, {})
        session_id = state[STATE_SESSION_ID]
        target_url = state[STATE_TARGET_URL]
        output_dir = state[STATE_OUTPUT_DIR]
        progress_tracker: ProgressTracker = state[STATE_PROGRESS_TRACKER]
        expanded_personas = state.get(STATE_EXPANDED_PERSONAS, [])
        persona_results = state.get(STATE_PERSONA_RESULTS, {})
        app_context = state.get(STATE_APP_CONTEXT)
        agent_identity = state.get(STATE_AGENT_IDENTITY)
        artifacts_info = state.get(STATE_ARTIFACTS_INFO, {})
        run_metrics = state.get(STATE_RUN_METRICS)
        credential_check_task = state.get(STATE_CREDENTIAL_CHECK_TASK)
        total_tokens = state.get(STATE_TOTAL_TOKENS, 0)

        polling_client = config.get("polling_client")
        polling_task = config.get("task")

        progress_tracker.update_graph_node("task_completion", "running")

        # Send final progress update
        await _send_progress_update(
            polling_task, polling_client, progress_tracker, session_id, target_url
        )

        # Mark final completion status
        is_stopped = state.get("stopped", False)
        if not is_stopped:
            progress_tracker.update_orchestrator(
                status=ExecutionStatus.COMPLETED,
                phase=OrchestratorPhase.COMPLETE,
                last_action="Pipeline completed successfully",
            )
        else:
            progress_tracker.update_orchestrator(
                last_action="Pipeline stopped by user",
            )

        # Mark task as complete if we have polling client
        # Always call mark_complete (even when stopped) so the server knows the task is done
        if polling_task and polling_client:
            try:
                # Convert results to PersonaResult format
                task_persona_results: dict[str, PersonaResult] = {}
                for persona_name, result_data in persona_results.items():
                    task_persona_results[persona_name] = PersonaResult(
                        target_url=result_data.get("target_url"),
                        transcript=result_data.get("transcript"),
                        total_turns=result_data.get("total_turns"),
                        error=result_data.get("error"),
                    )

                # Convert artifacts
                task_artifacts_storage_url = artifacts_info.get(
                    "storage_url"
                ) or artifacts_info.get("s3_url")
                task_artifacts_files = artifacts_info.get("files")
                task_artifacts_total_size = artifacts_info.get("total_size")

                artifacts = ArtifactsInfo(
                    storage_url=(
                        str(task_artifacts_storage_url)
                        if task_artifacts_storage_url
                        else None
                    ),
                    files=(
                        list(task_artifacts_files)
                        if isinstance(task_artifacts_files, list)
                        else None
                    ),
                    total_size=(
                        int(task_artifacts_total_size)
                        if isinstance(task_artifacts_total_size, (int, float))
                        else None
                    ),
                )

                # Get final progress snapshot
                final_progress_data = progress_tracker.get_progress_snapshot()
                final_progress_snapshot = ProgressSnapshot(
                    orchestrator=OrchestratorProgressInfo(
                        **final_progress_data["orchestrator"]
                    ),
                    app_discovery=(
                        AppDiscoveryProgressInfo(**final_progress_data["app_discovery"])
                        if "app_discovery" in final_progress_data
                        and final_progress_data["app_discovery"]
                        else None
                    ),
                    personas={
                        name: PersonaProgressInfo(**data)
                        for name, data in final_progress_data["personas"].items()
                    },
                    updated_at=final_progress_data["updated_at"],
                )

                # Load report_data.json if it exists
                loaded_report_data = None
                report_data_path = Path(output_dir) / REPORT_DATA_FILENAME
                if report_data_path.exists():
                    try:
                        import json

                        loaded_report_data = json.loads(
                            report_data_path.read_text(encoding="utf-8")
                        )
                        logger.info(f"✓ Loaded report data from {report_data_path}")
                    except Exception as e:
                        logger.warning(f"Failed to load report data: {e}")

                task_result = TaskResult(
                    status=TaskStatus.COMPLETE,
                    session_id=session_id,
                    target_url=target_url,
                    personas_run=len(expanded_personas),
                    results=task_persona_results,
                    app_context=app_context if app_context else None,
                    output_dir=output_dir,
                    artifacts=artifacts,
                    agent_identity=agent_identity,
                    progress=final_progress_snapshot,
                    report_data=loaded_report_data,
                )
                await polling_client.mark_complete(polling_task, task_result)
                logger.info("✓ Task marked as COMPLETE")
            except Exception as e:
                logger.warning(f"Failed to mark task as complete: {e}")

        # Flush pending progress uploads
        progress_tracker.flush_pending_upload()

        # Cancel credential check background task
        if credential_check_task:
            credential_check_task.cancel()
            try:
                await credential_check_task
            except asyncio.CancelledError:
                logger.info("✓ Credential monitoring stopped")
            except Exception as e:
                logger.warning(f"Error stopping credential monitoring: {e}")

        # Track analytics completion
        if run_metrics:
            try:
                analytics = AnalyticsClient.get_instance()

                # Calculate response statistics from persona results
                response_stats = calculate_response_statistics(persona_results)

                estimated_cost = calculate_token_cost(total_tokens)

                analytics.track_run_complete(
                    metrics=run_metrics,
                    num_conversations=len(persona_results),
                    total_tokens=total_tokens,
                    estimated_cost=estimated_cost,
                    response_stats=response_stats,
                    status="completed" if not state.get("stopped") else "stopped",
                )
            except Exception as e:
                logger.warning(f"Failed to track analytics: {e}")

        logger.info("=" * 80)
        logger.info("GRAPH PIPELINE COMPLETE")
        logger.info("=" * 80)

        progress_tracker.update_graph_node("task_completion", "completed")
        return _make_result({"accumulated_state": state}, "Task completion processed")


# =============================================================================
# Graph Orchestrator
# =============================================================================


class GraphOrchestrator:
    """
    Multi-agent orchestrator using Strands Graph pattern.

    Builds and executes a DAG of 9 nodes:
        ConnectivityCheck -> SessionSetup -> AppDiscovery -> GroundTruth
        -> PersonaRunner -> CrossConversation -> Summary -> ArtifactUpload -> TaskCompletion

    Each node is a proper MultiAgentBase that executes its specific task.
    State flows between nodes via invocation_state.
    """

    def __init__(
        self,
        headless: bool = True,
        storage_state: str | None = None,
    ):
        self.headless = headless
        self.storage_state = storage_state

        # Backward compatibility: expose agents as instance attributes for tests
        self.app_context_agent = AppContextDiscoveryAgent(headless=headless)
        self.chat_runner = ChatRunner(headless=headless, storage_state=storage_state)

    async def run_pipeline(
        self,
        target_url: str,
        seed_utterance: str = DEFAULT_SEED_UTTERANCE,
        max_turns: int = DEFAULT_MAX_TURNS,
        output_dir: str | None = None,
        persona_ids: list[str] | None = None,
        arato_api_url: str | None = None,
        arato_api_key: str | None = None,
        thread_id: str | None = None,
        max_parallel: int = DEFAULT_MAX_PARALLEL_PERSONAS,
        org_id: str | None = None,
        task_id: str | None = None,
        goal: str = "chat",
        step_timeout: int = DEFAULT_STEP_TIMEOUT,
        timeout: int = DEFAULT_PIPELINE_TIMEOUT,
        storage_state: str | None = None,
        task: Any | None = None,
        polling_client: Any | None = None,
        platform_adapter: Any | None = None,
        broadcast_identity: bool = False,
        force_discovery: bool = False,
        force_ground_truth: bool = False,
        session_prefix: str | None = None,
        exclude_persona_ids: list[str] | None = None,
        include_eu_ai_act_report: bool = False,
        domain: str | None = None,
        test_suite: Any | None = None,
        target_urls: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Run the multi-agent pipeline using graph orchestration.

        The pipeline flows through 9 nodes:
        1. ConnectivityCheck - Verify target URL is reachable
        2. SessionSetup - Initialize directories, logging, analytics, polling
        3. AppDiscovery - Run app context discovery (with caching)
        4. GroundTruth - Collect ground truth data (if goal=ground_truth)
        5. PersonaRunner - Run chat conversations in parallel
        6. CrossConversation - Run sub-agent analysis
        7. Summary - Generate consolidated reports
        8. ArtifactUpload - Upload all artifacts
        9. TaskCompletion - Mark task complete, send final progress

        Args:
            target_url: Website to test
            seed_utterance: Initial message for chat
            max_turns: Maximum conversation turns
            output_dir: Directory for artifacts (auto-generated if None)
            persona_ids: List of persona IDs with optional multipliers
            arato_api_url: Arato API endpoint for logging
            arato_api_key: Arato API key
            thread_id: Thread ID for logging correlation
            max_parallel: Maximum parallel personas
            org_id: Organization ID
            task_id: Task ID
            goal: 'discover', 'chat', or 'ground_truth'
            step_timeout: Timeout per agent step
            timeout: Total pipeline timeout
            storage_state: Path to saved authentication state
            task: Polling task payload
            polling_client: Polling client for progress updates
            platform_adapter: Platform adapter for agent identity
            broadcast_identity: Whether to broadcast identity
            force_discovery: Force app context rediscovery
            force_ground_truth: Force ground truth re-collection
            session_prefix: Prefix for session directory
            exclude_persona_ids: Personas to exclude
            include_eu_ai_act_report: Include EU AI Act report
            domain: Domain ID for composable config
            test_suite: TestSuite object for summaries
            target_urls: Multiple target URLs (random selection per persona)

        Returns:
            Pipeline results dictionary
        """
        if persona_ids is None:
            persona_ids = ["nice_user"]

        # Use instance storage_state if not provided
        if storage_state is None:
            storage_state = self.storage_state

        # Build configuration
        config = {
            "target_url": target_url,
            "seed_utterance": seed_utterance,
            "max_turns": max_turns,
            "output_dir": output_dir,
            "persona_ids": persona_ids,
            "arato_api_url": arato_api_url,
            "arato_api_key": arato_api_key,
            "thread_id": thread_id,
            "max_parallel": max_parallel,
            "org_id": org_id,
            "task_id": task_id,
            "goal": goal,
            "step_timeout": step_timeout,
            "timeout": timeout,
            "storage_state": storage_state,
            "task": task,
            "polling_client": polling_client,
            "platform_adapter": platform_adapter,
            "broadcast_identity": broadcast_identity,
            "force_discovery": force_discovery,
            "force_ground_truth": force_ground_truth,
            "session_prefix": session_prefix,
            "exclude_persona_ids": exclude_persona_ids,
            "include_eu_ai_act_report": include_eu_ai_act_report,
            "domain": domain,
            "test_suite": test_suite,
            "target_urls": target_urls,
            "headless": self.headless,
        }

        # Create graph nodes
        connectivity_check = ConnectivityCheckNode()
        session_setup = SessionSetupNode()
        app_discovery = AppDiscoveryNode()
        ground_truth = GroundTruthNode()
        persona_runner = PersonaRunnerNode()
        cross_conversation = CrossConversationNode()
        summary = SummaryNode()
        artifact_upload = ArtifactUploadNode()
        task_completion = TaskCompletionNode()

        # Build graph
        builder = GraphBuilder()
        builder.add_node(connectivity_check, "connectivity_check")
        builder.add_node(session_setup, "session_setup")
        builder.add_node(app_discovery, "app_discovery")
        builder.add_node(ground_truth, "ground_truth")
        builder.add_node(persona_runner, "persona_runner")
        builder.add_node(cross_conversation, "cross_conversation")
        builder.add_node(summary, "summary")
        builder.add_node(artifact_upload, "artifact_upload")
        builder.add_node(task_completion, "task_completion")

        # Define edges (sequential flow)
        builder.add_edge("connectivity_check", "session_setup")
        builder.add_edge("session_setup", "app_discovery")
        builder.add_edge("app_discovery", "ground_truth")
        builder.add_edge("ground_truth", "persona_runner")
        builder.add_edge("persona_runner", "cross_conversation")
        builder.add_edge("cross_conversation", "summary")
        builder.add_edge("summary", "artifact_upload")
        builder.add_edge("artifact_upload", "task_completion")

        builder.set_entry_point("connectivity_check")
        builder.set_execution_timeout(
            timeout + 1800
        )  # 30 min buffer for summary + upload phases

        graph = builder.build()

        logger.info("Executing graph orchestration pipeline...")
        logger.info(
            "  Nodes: connectivity -> session -> discovery -> ground_truth -> personas -> analysis -> summary -> upload -> complete"
        )

        # Execute graph with initial state
        initial_state = {"accumulated_state": {STATE_CONFIG: config}}
        result = graph(target_url, invocation_state=initial_state)

        # Always flush progress tracker after graph execution (even on timeout/error)
        progress_tracker_ref = cast(
            "ProgressTracker | None", config.get("_progress_tracker")
        )
        if progress_tracker_ref:
            if result.status != Status.COMPLETED:
                # Update progress to reflect the timeout/failure
                progress_tracker_ref.update_orchestrator(
                    status=ExecutionStatus.FAILED,
                    last_action=f"Pipeline stopped: {result.status.value}",
                    error=f"Graph execution ended with status: {result.status.value}",
                )
                # Mark any still-running graph nodes as failed
                for node_name, node_info in (
                    progress_tracker_ref.get_progress_snapshot()
                    .get("orchestrator", {})
                    .get("graph_nodes", {})
                    .items()
                ):
                    if (
                        isinstance(node_info, dict)
                        and node_info.get("status") == "running"
                    ):
                        progress_tracker_ref.update_graph_node(node_name, "failed")
            progress_tracker_ref.flush_pending_upload()
            logger.info(
                f"✓ Progress flushed after graph execution (status: {result.status})"
            )

        # Extract final state
        accumulated: dict[str, Any] = {}

        if result.status == Status.COMPLETED:
            final_node = result.results.get("task_completion")
            if final_node and hasattr(final_node, "result"):
                # The Graph wraps our MultiAgentResult in a NodeResult
                # Structure: NodeResult.result -> MultiAgentResult.results['node'] -> NodeResult.result -> AgentResult
                multi_agent_result = final_node.result
                if (
                    hasattr(multi_agent_result, "results")
                    and multi_agent_result.results
                    and isinstance(multi_agent_result.results, dict)
                ):
                    inner_node_result = multi_agent_result.results.get("node")  # type: ignore[arg-type]
                    if inner_node_result and hasattr(inner_node_result, "result"):
                        agent_result = inner_node_result.result
                        if hasattr(agent_result, "state") and agent_result.state:
                            final_state: dict[str, Any] = agent_result.state
                            accumulated = final_state.get("accumulated_state", {})

        # Check if we got valid accumulated state
        if accumulated:
            # Check if stopped
            if accumulated.get("stopped"):
                return {
                    "session_id": accumulated.get(STATE_SESSION_ID, "stopped"),
                    "target_url": accumulated.get(STATE_TARGET_URL, target_url),
                    "error": f"Task stopped by API: {accumulated.get('stop_reason', 'Unknown')}",
                    "status": TaskStatus.COMPLETE,
                    "goal": config.get("goal", "chat"),
                    "transcript": None,
                    "total_turns": 0,
                    "app_context": None,
                }

            # Calculate cost
            total_tokens = accumulated.get(STATE_TOTAL_TOKENS, 0)
            estimated_cost = calculate_token_cost(total_tokens)

            # Get persona results for transcript extraction
            persona_results = accumulated.get(STATE_PERSONA_RESULTS, {})

            # Extract first transcript and total_turns for backward compatibility
            transcript = None
            total_turns = 0
            for persona_result in persona_results.values():
                if isinstance(persona_result, dict):
                    if persona_result.get("transcript"):
                        transcript = persona_result["transcript"]
                    if persona_result.get("total_turns"):
                        total_turns = persona_result["total_turns"]
                    break  # Use first persona's result

            return {
                "status": "success",
                "session_id": accumulated.get(STATE_SESSION_ID, "unknown"),
                "target_url": accumulated.get(STATE_TARGET_URL, target_url),
                "app_context": accumulated.get(STATE_APP_CONTEXT),
                "results": persona_results,
                "personas_run": len(persona_results),
                "cross_conversation_findings": accumulated.get(
                    STATE_CROSS_FINDINGS, []
                ),
                "artifacts": accumulated.get(STATE_ARTIFACTS_INFO, {}),
                "total_tokens": total_tokens,
                "estimated_cost": estimated_cost,
                "output_dir": accumulated.get(STATE_OUTPUT_DIR),
                # Backward compatibility fields
                "goal": config.get("goal", "chat"),
                "transcript": transcript,
                "total_turns": total_turns,
            }

        # Fallback error result - include goal and transcript for backward compatibility
        logger.warning(f"Graph result extraction incomplete - status: {result.status}")
        if hasattr(result, "results"):
            logger.warning(f"Available result keys: {list(result.results.keys())}")
        return {
            "session_id": "error",
            "target_url": target_url,
            "status": "error",
            "error": f"Graph execution failed: {result.status}",
            "goal": config.get("goal", "chat"),
            "transcript": None,
            "total_turns": 0,
            "app_context": None,
        }


# Backward compatibility aliases
Orchestrator = GraphOrchestrator
SwarmOrchestrator = GraphOrchestrator

__all__ = [
    "GraphOrchestrator",
    "Orchestrator",
    "SwarmOrchestrator",
    "expand_glob_patterns",
    "expand_persona_list",
    "parse_persona_with_multiplier",
    "apply_persona_exclusions",
]
