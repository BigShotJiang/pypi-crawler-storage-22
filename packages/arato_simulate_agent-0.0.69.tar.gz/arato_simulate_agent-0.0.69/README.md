# arato-simulate-agent

Browser-based AI chat testing agent by [Arato](https://arato.ai). Polls your Arato server for simulation tasks and executes them using Playwright.

## Quick Start

```bash
export ARATO_API_KEY=ak_your_key_here
uvx arato-simulate-agent https://your-server.example.com
```

Playwright chromium is auto-installed on first run.

## CLI Usage

```
arato-simulate-agent [server_url] [--api-key KEY] [--polling-interval SECONDS]
```

| Argument | Required | Description |
|----------|----------|-------------|
| `server_url` | No | Server URL (e.g. `https://simulate.arato.dev`). The `/api/v1/agent-connect/task` path is appended automatically. |
| `--api-key` | No | Agent API key. Alternative to `ARATO_API_KEY` env var. |
| `--polling-interval` | No | Seconds between polls (default: 5). |

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ARATO_API_KEY` | Yes (or `--api-key`) | - | Agent authentication key |
| `ARATO_TASK_ENDPOINT` | No | `http://localhost:3000/api/v1/agent-connect/task` | Full task endpoint URL (overrides positional `server_url`) |
| `ARATO_POLLING_INTERVAL` | No | `5` | Polling interval in seconds |

CLI arguments take precedence over environment variables.

## Requirements

- Python >= 3.13
- Playwright chromium (auto-installed on first run)
