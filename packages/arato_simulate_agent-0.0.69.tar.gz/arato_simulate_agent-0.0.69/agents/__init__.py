"""Agent implementations."""

from agents.graph_orchestrator import (
    GraphOrchestrator,
    apply_persona_exclusions,
    expand_glob_patterns,
    expand_persona_list,
    parse_persona_with_multiplier,
)

# Backward compatibility aliases
Orchestrator = GraphOrchestrator
SwarmOrchestrator = GraphOrchestrator

__all__ = [
    "GraphOrchestrator",
    "Orchestrator",  # Alias for backward compatibility
    "SwarmOrchestrator",  # Deprecated alias for backward compatibility
    # Helper functions
    "apply_persona_exclusions",
    "expand_glob_patterns",
    "expand_persona_list",
    "parse_persona_with_multiplier",
]
