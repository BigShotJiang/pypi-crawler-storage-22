#!/usr/bin/env python3
"""
App Context Discovery Agent: Discovers and documents website/application context.
This agent explores the website to understand what the application does and provides
background context that will help other agents have more intelligent conversations.
"""

import asyncio
import ipaddress
import json
import logging
import time
from pathlib import Path
from typing import Any, cast

from browser_use import Agent, Controller, Tools
from dotenv import load_dotenv

from constants import (
    APP_CONTEXT_FILENAME,
    DISCOVERY_VIDEO_FILENAME,
    HAR_FILENAME,
    VIDEO_SUBDIR_DISCOVERY,
)
from core.browser import create_browser, setup_browser_kwargs
from core.llm import create_chat_model
from tools.app_context_report import app_context_report as generate_report
from tools.hitl_intervention import request_human_intervention, set_browser_context
from utils import move_discovery_video, save_text_file
from utils.progress_tracker import ExecutionStatus
from utils.prompt_loader import load_prompt
from utils.screenshot_utils import capture_and_upload_screenshot
from utils.url_utils import extract_domain_pattern, get_domain_from_url

load_dotenv()

logger = logging.getLogger(__name__)


class AppContextDiscoveryAgent:
    """Agent that discovers and documents website/application context."""

    def __init__(
        self,
        headless: bool = False,
    ):
        """
        Initialize the app context discovery agent.

        Args:
            headless: Run browser in headless mode
        """
        self.headless = headless
        self.llm = create_chat_model()

    async def discover_app_context(
        self,
        target_url: str,
        session_dir: str | None = None,
        timeout: int = 60,
        domain_dir: str | None = None,
        task: Any | None = None,
        polling_client: Any | None = None,
        progress_tracker: Any | None = None,
        org_id: str | None = None,
    ) -> str:
        """
        Explore the website and create a JSON document describing what the
        application/website does, its purpose, key features, and any relevant
        background information.

        Args:
            target_url: The website URL to explore
            session_dir: Optional directory path to save HAR file
            timeout: Maximum time in seconds for the discovery process (default: 60)
            domain_dir: Optional domain-specific directory for storing video
            task: Optional task payload for polling updates
            polling_client: Optional polling client for progress updates
            progress_tracker: Optional progress tracker for local updates
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            JSON string describing the application context
        """
        logger.info(f"Starting app context discovery for: {target_url}")

        if progress_tracker:
            progress_tracker.init_app_discovery(total_steps=5)
            progress_tracker.update_app_discovery(
                status=ExecutionStatus.RUNNING,
                last_action="Starting website exploration",
            )

        browser_kwargs = setup_browser_kwargs(
            headless=self.headless,
            disable_security=False,
        )

        # Restrict browser to target domain for security
        allowed_domains = extract_domain_pattern(target_url)

        # Check if it's an IP address - if so, disable domain restriction to avoid issues
        is_ip = False
        try:
            ipaddress.ip_address(allowed_domains[0])
            is_ip = True
        except (ValueError, IndexError):
            pass

        if is_ip:
            logger.info(
                f"Target is IP address {allowed_domains[0]}, disabling allowed_domains restriction"
            )
        else:
            browser_kwargs["allowed_domains"] = allowed_domains
            logger.info(f"Browser restricted to domains: {', '.join(allowed_domains)}")

        if session_dir:
            har_file_path = Path(session_dir) / HAR_FILENAME
            browser_kwargs["record_har_path"] = str(har_file_path)
            browser_kwargs["record_har_content"] = "embed"
            logger.info(f"Recording HAR to: {har_file_path}")

        if domain_dir:
            video_dir = Path(domain_dir) / VIDEO_SUBDIR_DISCOVERY
            video_dir.mkdir(parents=True, exist_ok=True)
            browser_kwargs["record_video_dir"] = str(video_dir)
            logger.info(f"Recording app context video to: {video_dir}")

        # Track uploaded discovery screenshots for progress tracking
        uploaded_discovery_screenshots: list[str] = []
        # Track discovery video URL for progress tracking
        uploaded_discovery_video_url: str | None = None

        async with create_browser(**browser_kwargs) as browser:
            controller: Controller[Any] = Controller()

            # Disable web search - agent should only explore the target domain
            tools: Tools[Any] = Tools(exclude_actions=["search"])

            @tools.action(
                description="Capture and save a screenshot of interesting pages during website exploration. "
                "Use this when you find pages that visually represent the website's purpose, features, or chat interface. "
                "Provide a descriptive name like 'homepage', 'chat-interface', 'product-page', 'dashboard', etc."
            )
            async def capture_discovery_screenshot(description: str) -> str:
                """
                Capture a screenshot of the current page and save it to domain settings folder.

                Use this tool when you encounter pages that provide visual context about:
                - The website's main purpose or homepage
                - Key features or functionality
                - Chat interface or customer support area
                - Important pages that help understand the application

                Args:
                    description: Short descriptive name for this screenshot (e.g., 'homepage', 'chat-page', 'dashboard')

                Returns:
                    Confirmation message with storage location
                """
                logger.info(f"📸 Capturing discovery screenshot: {description}")

                try:
                    # Get domain for storage path
                    domain = get_domain_from_url(target_url)

                    # Use shared screenshot utility (defer upload until end)
                    screenshot_url = await capture_and_upload_screenshot(
                        browser=browser,
                        upload_type="discovery",
                        description=description,
                        domain=domain,
                        org_id=org_id,
                    )

                    if screenshot_url:
                        # Track screenshot URL for progress tracking (use actual URL from storage adapter)
                        uploaded_discovery_screenshots.append(screenshot_url)
                        logger.info(f"✓ Tracked screenshot URL: {screenshot_url}")
                        return f"✅ Screenshot captured and saved successfully!\nDescription: {description}\nLocation: {screenshot_url}"
                    else:
                        return "❌ Failed to capture or save screenshot"

                except Exception as e:
                    logger.exception(f"Error capturing discovery screenshot: {e}")
                    return f"❌ Error capturing screenshot: {e}"

            # Get available domains for tool description
            from utils.config_loader import get_available_domains

            available_domains = get_available_domains()
            domain_list = (
                ", ".join(available_domains)
                if available_domains
                else "travel, hr, customer_success, media, govtech, telco, website_builder, insurance_declination"
            )

            @tools.action(
                description="Generate a properly formatted JSON report with app context discovery findings. "
                f"IMPORTANT: You MUST specify a domain from: {domain_list}"
            )
            def generate_app_context_report(
                summary: str,
                core_functionality: str,
                target_audience: str,
                technical_information: str,
                chat_interface_description: str,
                domain: str,
            ) -> str:
                """
                Generate a properly formatted JSON report for app context discovery.

                This tool MUST be called to output your final findings. It ensures the output
                is valid JSON instead of markdown text.

                IMPORTANT: You MUST specify a domain that best categorizes this application.

                Args:
                    summary: A brief overview of the application/website name and purpose
                    core_functionality: The main features or services offered
                    target_audience: Who is this application designed for
                    technical_information: Any important technical details about the company, product, or service
                    chat_interface_description: Description of any chat interfaces or support bots present
                    domain: The domain category for this application. REQUIRED. Must be one of:
                        - travel: Travel booking, trip planning, flight/hotel services (e.g., Kayak, Expedia)
                        - hr: Human resources, people management, payroll (e.g., HiBob, Workday, BambooHR)
                        - customer_success: Customer success platforms, support tools (e.g., Staircase AI, Gainsight)
                        - media: Media processing, digital assets, content (e.g., Cloudinary, Adobe)
                        - govtech: Government tech, civic engagement (e.g., Zencity, CivicPlus)
                        - ecommerce: Online shopping, retail (e.g., Shopify, Amazon)
                        - insurance: Insurance products, claims (e.g., Lemonade, Progressive)
                        - tech_support: Technical support, troubleshooting (e.g., Zendesk, Freshdesk)

                Returns:
                    JSON string with properly formatted app context information
                """
                return generate_report(
                    summary=summary,
                    core_functionality=core_functionality,
                    target_audience=target_audience,
                    technical_information=technical_information,
                    chat_interface_description=chat_interface_description,
                    domain=domain,
                )

            @tools.action(
                description="Request human intervention when encountering CAPTCHAs, consent dialogs, or other blocking elements"
            )
            async def request_human_help(
                reason: str, intervention_type: str = "custom"
            ) -> str:
                """
                Request human intervention when you encounter a task that requires human assistance.

                Use this when you encounter:
                - CAPTCHAs or reCAPTCHAs
                - Consent dialogs or cookie banners that block exploration
                - Login forms that block access to content
                - Any other blocker that prevents exploration

                Args:
                    reason: Clear explanation of why human help is needed (e.g., "Cookie consent banner blocking the page")
                    intervention_type: Type of intervention (captcha, consent, login, verification, custom)

                Returns:
                    Confirmation message indicating whether human completed the intervention
                """
                logger.info(f"🤚 Agent requesting human intervention: {reason}")

                try:
                    result = await request_human_intervention(
                        reason=reason,
                        intervention_type=intervention_type,
                    )

                    if result["success"]:
                        return (
                            f"✅ Human successfully completed the intervention!\n"
                            f"Reason: {reason}\n"
                            f"You can now continue exploring."
                        )
                    else:
                        return (
                            f"❌ Human intervention failed or timed out.\n"
                            f"Reason: {reason}\n"
                            f"Error: {result.get('message', 'Unknown error')}\n"
                            f"Try to continue exploring other areas of the site."
                        )

                except Exception as e:
                    logger.exception(f"Error during human intervention: {e}")
                    return (
                        f"❌ Error requesting human intervention: {e}\n"
                        f"Try continuing exploration without intervention."
                    )

            task = load_prompt("app_context_discovery_task", target_url=target_url)

            # Set browser context for HITL screenshot capture
            set_browser_context(browser)

            agent: Agent[Any, Any] = Agent(
                task=task,
                llm=self.llm,
                browser=browser,
                controller=controller,
                tools=tools,
                agent_directory=str(session_dir) if session_dir else None,
                use_vision=True,
                use_thinking=False,
                calculate_cost=True,
            )

            # Configure smaller screenshot size to avoid 5MB limit errors
            # Default browser-use auto-configures 1400x850 for Claude Sonnet which can exceed limits
            # Reducing to 1000x600 keeps under 5MB while maintaining usability
            # Note: Set after Agent creation to avoid browser-use bug where logger accesses
            # browser_session before it's initialized
            agent.browser_session.llm_screenshot_size = (1000, 600)
            logger.info("🖼️  Configured LLM screenshot size: 1000x600")

            logger.info("Running app context discovery with browser-use agent...")
            logger.info(f"Timeout set to {timeout} seconds")

            # Track start time for graceful timeout
            start_time = time.time()
            should_stop = False

            async def check_timeout(agent: Agent[Any, Any]) -> None:
                """Check if we've exceeded timeout and signal agent to wrap up"""
                nonlocal should_stop
                elapsed = time.time() - start_time

                # Update progress tracker with current step if provided
                if progress_tracker and hasattr(agent, "n_steps"):
                    progress_tracker.update_app_discovery(
                        status=ExecutionStatus.RUNNING,
                        current_step=agent.n_steps,
                        last_action=f"Exploring website (step {agent.n_steps})",
                    )

                if elapsed >= timeout and not should_stop:
                    should_stop = True
                    logger.warning(
                        f"⏱️  Discovery agent reached {timeout}s timeout after {elapsed:.1f}s"
                    )
                    logger.info(
                        "Signaling agent to stop gracefully and save current findings..."
                    )

                    # Update progress tracker about timeout
                    if progress_tracker:
                        progress_tracker.update_app_discovery(
                            last_action="Discovery timeout - wrapping up",
                        )

                    # Use browser-use's built-in stop() method to gracefully stop the agent
                    agent.stop()

            # Run agent with graceful timeout handling
            # Use a longer hard timeout (2x) as safety net
            async with asyncio.timeout(timeout * 2):
                history = await agent.run(max_steps=10, on_step_end=check_timeout)

            if should_stop:
                logger.info(
                    "✓ Agent stopped gracefully due to timeout, partial results preserved"
                )

            if history.usage:
                logger.info(f"💰 Token usage: {history.usage}")

        # Extract final result from agent history
        # First check if generate_app_context_report tool was called
        app_context_report: str = ""

        for step in history.history:
            if hasattr(step, "action") and step.action:
                action_name = getattr(step.action, "name", None)
                if action_name == "generate_app_context_report":
                    # Found the tool call! Use its result
                    result = getattr(step, "result", None)
                    if result:
                        app_context_report = str(result)
                        logger.info(
                            f"✓ Found generate_app_context_report tool output ({len(app_context_report)} chars)"
                        )
                        break

        # If no tool call found, fall back to final_result
        if not app_context_report:
            logger.warning("⚠️  generate_app_context_report tool was NOT called")
            logger.info("Falling back to agent's text output (this may be markdown)")
            final_result = history.final_result()
            app_context_report = str(final_result or "")

        if app_context_report:
            try:
                validated_data = self._validate_app_context_json(app_context_report)
                logger.info("✓ JSON validation successful")

                # Validate domain mapping
                domain = validated_data.get("domain")
                domain_validated = validated_data.get("domain_validated", False)

                if domain and domain_validated:
                    logger.info(f"✓ Domain validated: {domain}")
                elif domain and not domain_validated:
                    # Get available domains for error message
                    from utils.config_loader import get_available_domains

                    available_domains_list = get_available_domains()
                    logger.warning(
                        f"⚠️  Domain '{domain}' is not configured. "
                        f"Available domains: {available_domains_list}"
                    )
                    logger.warning(
                        f"To configure this domain, create: "
                        f"config/domains/{domain}/domain.yaml"
                    )
                else:
                    logger.warning(
                        "⚠️  No domain was identified for this application. "
                        "The agent should specify a domain."
                    )

            except ValueError as e:
                logger.warning(f"JSON validation failed: {e}")
                logger.info(f"Keeping result anyway ({len(app_context_report)} chars)")

        if not app_context_report:
            logger.warning("No content was generated by the agent, using placeholder")
            app_context_report = '{"summary": "No context discovered"}'
        else:
            logger.info(
                f"Agent completed. Final result length: {len(app_context_report)}"
            )

        # Always save app context to domain folder, even on timeout or empty
        if domain_dir:
            domain_app_context = Path(domain_dir) / APP_CONTEXT_FILENAME
            try:
                save_text_file(app_context_report, domain_app_context)
                logger.info(f"✓ Saved app context to {domain_app_context}")
            except Exception as exc:
                logger.error(
                    f"Failed to save {APP_CONTEXT_FILENAME} to domain: %s", exc
                )

        # Also save to session dir if provided (for logs/debugging)
        if session_dir:
            session_app_context = Path(session_dir) / APP_CONTEXT_FILENAME
            try:
                save_text_file(app_context_report, session_app_context)
                logger.info(f"✓ Saved app context to {session_app_context}")
            except Exception as exc:
                logger.error(
                    f"Failed to save {APP_CONTEXT_FILENAME} to session: %s", exc
                )

        # Always try to move video to domain directory, even on timeout
        discovery_video_path = None
        if domain_dir:
            try:
                moved = move_discovery_video(Path(domain_dir))
                if moved:
                    logger.info("✓ Moved discovery video to domain folder")
                    discovery_video_path = f"{domain_dir}/{DISCOVERY_VIDEO_FILENAME}"

                    # Defer video upload until end of run (upload with all other artifacts)
                    logger.info(
                        "✓ Discovery video saved locally (upload deferred until end of run)"
                    )
                else:
                    logger.warning("No discovery video found to move")
            except Exception as exc:
                logger.error(f"Failed to move discovery video: {exc}")

        preview = app_context_report[:200] if app_context_report else "EMPTY"
        logger.info("Captured context preview: %s...", preview)

        # Use tracked uploaded screenshots, supplemented by any locally saved files
        discovery_screenshots: list[str] = []
        discovery_video_for_progress: str | None = None

        # First, use the screenshots that were tracked during upload
        if uploaded_discovery_screenshots:
            discovery_screenshots = uploaded_discovery_screenshots
            logger.info(
                f"✓ Tracked {len(discovery_screenshots)} discovery screenshots from uploads"
            )

        # Fallback: also check for any locally saved screenshots (for backwards compatibility)
        if not discovery_screenshots and domain_dir:
            domain_for_storage = get_domain_from_url(target_url)
            screenshots_dir = Path(domain_dir) / "screenshots"
            if screenshots_dir.exists() and screenshots_dir.is_dir():
                screenshot_files = sorted(screenshots_dir.glob("*.png"))
                discovery_screenshots = [
                    f"domain_settings/{domain_for_storage}/screenshots/{f.name}"
                    for f in screenshot_files
                ]
                if discovery_screenshots:
                    logger.info(
                        f"✓ Found {len(discovery_screenshots)} discovery screenshots locally"
                    )

        # Determine final discovery video path for progress tracking
        discovery_video_for_progress = uploaded_discovery_video_url
        if not discovery_video_for_progress and domain_dir and discovery_video_path:
            domain_for_storage = get_domain_from_url(target_url)
            discovery_video_for_progress = (
                f"domain_settings/{domain_for_storage}/{DISCOVERY_VIDEO_FILENAME}"
            )

        if progress_tracker:
            progress_tracker.update_app_discovery(
                status=ExecutionStatus.COMPLETED,
                last_action="App context discovery completed",
                app_context_json=app_context_report,
                screenshots=discovery_screenshots,
                discovery_video=discovery_video_for_progress,
            )

        logger.info("✓ App context discovery complete!")
        return app_context_report

    def _extract_context_from_history(
        self, history: list[dict[str, Any]], target_url: str
    ) -> str:
        """
        Extract and format the application context from the agent's action history.

        Args:
            history: List of agent actions and results
            target_url: The URL that was explored

        Returns:
            Formatted markdown document with application context
        """
        # First, try to find the 'done' action which contains the final result
        final_result = None

        # Convert history to list if it's not already
        history_list = list(history) if not isinstance(history, list) else history

        for step in reversed(history_list):
            if isinstance(step, dict):
                action = step.get("action")
                if action and isinstance(action, dict):
                    if action.get("name") == "done":
                        # Found the done action, extract the text
                        done_result = step.get("result")
                        if isinstance(done_result, dict):
                            final_result = done_result.get("text")
                        elif isinstance(done_result, str):
                            final_result = done_result
                        break

        # If we found meaningful content from the agent, use it directly
        if final_result and isinstance(final_result, str) and len(final_result) > 10:
            # The agent has provided comprehensive context, use it as-is
            logger.info(f"Found detailed context ({len(final_result)} chars)")
            return str(final_result)

        # If no substantial content was found, return empty string
        # This signals that no useful context was discovered
        logger.warning("No meaningful context was discovered by the agent")
        return ""

    def _validate_app_context_json(self, json_str: str) -> dict[str, Any]:
        """
        Validate that the JSON string is well-formatted and contains all required sections.

        Args:
            json_str: The JSON string to validate

        Returns:
            The parsed JSON dict if valid

        Raises:
            ValueError: If validation fails
        """
        try:
            data = cast(dict[str, Any], json.loads(json_str))
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format: {e}") from e

        required_keys = [
            "summary",
            "core_functionality",
            "target_audience",
            "technical_information",
            "chat_interface_description",
        ]

        for key in required_keys:
            if key not in data:
                raise ValueError(f"Missing required section: {key}")
            value = data[key]
            if not value or (isinstance(value, str) and not value.strip()):
                raise ValueError(
                    f"Section '{key}' is empty or contains only whitespace"
                )

        return data
