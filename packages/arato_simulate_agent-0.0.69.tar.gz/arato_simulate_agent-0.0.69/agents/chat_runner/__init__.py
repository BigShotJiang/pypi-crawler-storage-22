"""
Chat Runner Package.

Contains the ChatRunner agent and its specialized components:
- ChatRunner: Main entry point that manages browser sessions and conversation flow
- ConversationOrchestrator: Strands Agent that coordinates conversation flow
- DiscoverySubagent: Discovers chat interfaces, handles authentication (browser-use)
- TurnSubagent: Executes a single conversation turn (browser-use)
- SummarySubagent: Generates persona conversation summaries (Strands Agent)
"""

from agents.chat_runner.conversation_orchestrator import ConversationOrchestrator
from agents.chat_runner.discovery_subagent import DiscoverySubagent
from agents.chat_runner.runner import ChatRunner
from agents.chat_runner.summary_subagent import SummarySubagent
from agents.chat_runner.turn_subagent import TurnSubagent

__all__ = [
    "ChatRunner",
    "ConversationOrchestrator",
    "DiscoverySubagent",
    "TurnSubagent",
    "SummarySubagent",
]
