"""
Discovery Subagent.

Browser-use based subagent for discovering chat interfaces and handling
authentication (login, OTP, CAPTCHA, HITL).

This subagent REPLACES the old discovery mechanism entirely.
"""

import json
import logging
from typing import Any

import json_repair
from browser_use import Agent, Controller

from constants import DEFAULT_DISCOVERY_MAX_STEPS
from models.discovery_result import DiscoveryResult
from tools.auto_login import auto_login_tool
from tools.auto_otp import auto_otp_tool
from tools.captcha_solver import solve_captcha_tool
from tools.hitl_intervention import request_human_intervention
from utils.auth_time_tracker import AuthTimeTracker
from utils.prompt_loader import load_prompt

logger = logging.getLogger(__name__)


class DiscoverySubagent:
    """
    Browser-use subagent for chat interface discovery and authentication.

    Responsibilities:
    - Navigate to target URL
    - Handle authentication (login, OTP, CAPTCHA, HITL)
    - Discover chat interface elements (input selector, submit button)
    - Capture welcome message (turn 0)
    """

    def __init__(
        self,
        browser_session: Any,
        llm: Any,
        target_url: str,
        output_dir: str | None = None,
        storage_state: str | None = None,
        auth_tracker: AuthTimeTracker | None = None,
    ):
        """
        Initialize the discovery subagent.

        Args:
            browser_session: Shared browser session (keep_alive=True)
            llm: LLM model for the browser-use agent
            target_url: URL to analyze for chat interface
            output_dir: Directory for session artifacts
            storage_state: Path to storage state file for auth
            auth_tracker: Optional auth time tracker for timeout exclusion
        """
        self.browser_session = browser_session
        self.llm = llm
        self.target_url = target_url
        self.output_dir = output_dir
        self.storage_state = storage_state
        self.auth_tracker = auth_tracker or AuthTimeTracker()

    async def discover(
        self,
        max_steps: int = DEFAULT_DISCOVERY_MAX_STEPS,
    ) -> DiscoveryResult:
        """
        Discover chat interface at the target URL.

        Handles navigation, authentication, and chat element discovery.

        Args:
            max_steps: Maximum browser-use agent steps (default: 10)

        Returns:
            DiscoveryResult with selectors and welcome message
        """
        logger.info("🕵️ Starting Discovery Subagent...")

        discovery_task = load_prompt(
            "chat_runner_discovery_task",
            target_url=self.target_url,
        )

        # Create browser-use agent with auth tools
        controller: Controller = Controller()

        # Register authentication tools
        self._register_auth_tools(controller, self.target_url)

        agent: Agent = Agent(
            task=discovery_task,
            llm=self.llm,
            browser=self.browser_session,
            controller=controller,
            use_vision=True,
        )

        # Set keep_alive=True to prevent session destruction (we reuse the browser)
        if hasattr(self.browser_session, "browser_profile"):
            self.browser_session.browser_profile.keep_alive = True

        try:
            history = await agent.run(max_steps=max_steps)

            # Capture usage data from browser-use agent
            usage = None
            if history and hasattr(history, "usage") and history.usage:
                usage = history.usage

            # Extract the final result from the history
            if history and history.final_result():
                result = history.final_result()

                # Use json_repair to extract json object from the result
                if result:
                    decoded_object = json_repair.repair_json(
                        result, return_objects=True
                    )

                    # json_repair may return a list (e.g. LLM wraps
                    # the JSON object in an array, or multiple objects
                    # are parsed).  Unwrap the first dict element when
                    # that happens so discovery can proceed.
                    if isinstance(decoded_object, list):
                        logger.info(
                            f"📋 Discovery returned a list with {len(decoded_object)} element(s), extracting first dict..."
                        )
                        dict_item = next(
                            (item for item in decoded_object if isinstance(item, dict)),
                            None,
                        )
                        if dict_item is not None:
                            decoded_object = dict_item
                        else:
                            logger.warning(
                                "⚠️ Discovery returned a list with no dict elements"
                            )
                            return DiscoveryResult.not_found(
                                "Discovery returned a list with no dict elements"
                            )

                    if isinstance(decoded_object, dict):
                        logger.info(
                            f"✅ Discovery Subagent finished. Findings: {json.dumps(decoded_object)}"
                        )
                        discovery_result = DiscoveryResult.from_json(decoded_object)
                        discovery_result.usage = usage
                        return discovery_result

                    logger.warning(
                        f"⚠️ Discovery returned non-dict: {type(decoded_object)}"
                    )
                    return DiscoveryResult.not_found(
                        "Discovery returned invalid format"
                    )

            logger.warning("⚠️ Discovery Subagent finished but returned no final result")
            return DiscoveryResult.not_found("No result returned")

        except Exception as e:
            logger.error(f"❌ Discovery Subagent failed: {e}")
            return DiscoveryResult.create_error(str(e))

        finally:
            # Cleanup EventBus to prevent memory leaks
            self._cleanup_event_bus(agent)

    def _register_auth_tools(self, controller: Controller, target_url: str) -> None:
        """Register authentication tools with the controller."""

        @controller.action(
            description="Attempt automatic login using stored credentials"
        )
        async def auto_login() -> str:
            """Attempt automatic login for this domain."""
            self.auth_tracker.start_auth("login")
            try:
                result = await auto_login_tool(
                    browser=self.browser_session,
                    target_url=target_url,
                )
                if result["success"]:
                    return f"✅ Login successful: {result['message']}"
                else:
                    return f"❌ Login failed: {result['message']}"
            finally:
                self.auth_tracker.end_auth()

        @controller.action(description="Attempt automatic OTP/2FA code entry")
        async def auto_otp() -> str:
            """Attempt automatic OTP entry."""
            self.auth_tracker.start_auth("otp")
            try:
                result = await auto_otp_tool(
                    browser=self.browser_session,
                    target_url=target_url,
                )
                if result["success"]:
                    return f"✅ OTP successful: {result['message']}"
                else:
                    return f"❌ OTP failed: {result['message']}"
            finally:
                self.auth_tracker.end_auth()

        @controller.action(description="Attempt to solve CAPTCHA automatically")
        async def solve_captcha() -> str:
            """Attempt to solve CAPTCHA on the page."""
            self.auth_tracker.start_auth("captcha")
            try:
                result = await solve_captcha_tool(
                    browser=self.browser_session,
                )
                if result.get("success"):
                    return f"✅ CAPTCHA solved: {result.get('message', 'Success')}"
                else:
                    return f"❌ CAPTCHA failed: {result.get('message', 'Failed')}"
            finally:
                self.auth_tracker.end_auth()

        @controller.action(
            description="Request human intervention for tasks that cannot be automated"
        )
        async def request_human_help(
            reason: str, intervention_type: str = "other"
        ) -> str:
            """Request human intervention via HITL service."""
            self.auth_tracker.start_auth("hitl")
            try:
                result = await request_human_intervention(
                    reason=reason,
                    intervention_type=intervention_type,
                )
                if result["success"]:
                    return f"✅ Human intervention completed: {result.get('learning_summary', 'Success')}"
                else:
                    return (
                        f"❌ Human intervention failed: {result.get('error', 'Failed')}"
                    )
            finally:
                self.auth_tracker.end_auth()

    def _cleanup_event_bus(self, agent: Agent) -> None:
        """Cleanup browser-use EventBus to prevent memory leaks."""
        try:
            if hasattr(agent, "browser_session") and hasattr(
                agent.browser_session, "_event_bus"
            ):
                event_bus = agent.browser_session._event_bus
                if event_bus and hasattr(event_bus, "stop"):
                    event_bus.stop(clear=True)  # type: ignore[union-attr]
                    logger.debug("✓ Cleaned up EventBus (cleared completed instances)")
        except Exception as cleanup_error:
            logger.warning(f"Failed to cleanup EventBus: {cleanup_error}")

    async def handle_mid_conversation_reauth(
        self,
        target_url: str,
    ) -> bool:
        """
        Handle re-authentication if kicked to login page mid-conversation.

        Args:
            target_url: Original target URL to navigate back to

        Returns:
            True if re-auth successful, False otherwise
        """
        logger.warning("🚨 DETECTED: Kicked to login page during conversation!")

        # Attempt re-authentication
        logger.info("🔐 Attempting automatic re-login...")
        self.auth_tracker.start_auth("login")

        try:
            result = await auto_login_tool(
                browser=self.browser_session,
                target_url=target_url,
            )

            if result["success"]:
                logger.info("✅ Re-login successful!")

                # Navigate back to original target URL
                page = await self.browser_session.get_current_page()
                if page:
                    logger.info(f"Navigating back to: {target_url}")
                    await page.goto(target_url)
                    import asyncio

                    await asyncio.sleep(2)  # Wait for page to stabilize

                return True
            else:
                logger.error(f"❌ Re-login failed: {result['message']}")
                return False

        finally:
            self.auth_tracker.end_auth()

    async def detect_login_page(self) -> bool:
        """
        Detect if currently on a login page.

        Returns:
            True if on login page, False otherwise
        """
        try:
            page = await self.browser_session.get_current_page()
            if not page:
                return False

            # Check current URL for login patterns
            current_url: str = str(page.url) if hasattr(page, "url") else ""
            login_url_patterns = ["login", "signin", "sign-in", "auth", "authenticate"]
            is_login_url = any(
                pattern in current_url.lower() for pattern in login_url_patterns
            )

            # Also check page content for login form
            try:
                page_check = await page.evaluate(
                    """
          () => {
              const hasPasswordField = document.querySelector('input[type="password"]') !== null;
              const hasLoginText = document.documentElement.outerHTML.toLowerCase().includes('login') ||
                                   document.documentElement.outerHTML.toLowerCase().includes('sign in');
              return JSON.stringify({
                  hasPasswordField: hasPasswordField,
                  hasLoginText: hasLoginText
              });
          }
          """
                )
                page_info = json.loads(page_check)
                is_login_page = page_info.get(
                    "hasPasswordField", False
                ) and page_info.get("hasLoginText", False)
            except Exception:
                is_login_page = False

            return is_login_url or is_login_page

        except Exception as e:
            logger.debug(f"Login detection check failed (non-critical): {e}")
            return False
