#!/usr/bin/env python3
"""
Chat Runner: A standalone agent that conducts conversations using browser-use LLM exclusively.
The agent discovers chat interfaces dynamically and interacts using browser actions.
"""

import importlib.util
import json
import logging
import os
import re
import tempfile
import traceback
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from dotenv import load_dotenv

from constants import (
    DEFAULT_MAX_TURNS,
    DEFAULT_PIPELINE_TIMEOUT,
    DEFAULT_SEED_UTTERANCE,
    DEFAULT_STEP_TIMEOUT,
    HITL_RECOVERY_ENABLED,
    HITL_RECOVERY_STRATEGY,
    MIN_ASSISTANT_MESSAGE_LENGTH,
    MIN_TURNS,
    MIN_USER_MESSAGE_LENGTH,
    SKIP_PHRASES,
    VIDEO_SUBDIR_RUN,
)
from core.browser import create_browser, get_browser_manager, setup_browser_kwargs
from core.llm import create_chat_model
from models.conversation_turn import (
    ConversationTurn,
    calculate_turn_count,
)
from tools.arato_logs_api import AratoLogsAPI
from utils import move_run_video, save_text_file
from utils.config_loader import get_config_summary
from utils.persona_summary_generator import generate_persona_summary
from utils.progress_tracker import FinishReason
from utils.url_utils import extract_domain_pattern

load_dotenv()

logger = logging.getLogger(__name__)


class ChatRunner:
    """Standalone agent that discovers and interacts with chat interfaces using LLM vision."""

    # Class variable to store current target_url for HITL intervention saves
    _current_target_url: str | None = None

    def __init__(
        self,
        headless: bool = False,
        storage_state: str | None = None,
    ):
        """
        Initialize the chat runner agent.

        Args:
            headless: Run browser in headless mode
            storage_state: Path to JSON file with saved authentication state.
                          If not provided, will auto-lookup based on target URL domain.
        """
        self.headless = headless
        self.storage_state = storage_state

    @staticmethod
    def _auto_lookup_storage_state(target_url: str) -> str | None:
        """Auto-lookup storage_state file based on target URL domain.

        Checks for auth_states/auth_<domain>.json file created by HITL interventions.

        Args:
            target_url: Target URL to extract domain from

        Returns:
            Path to storage_state file if found, None otherwise
        """
        try:
            parsed = urlparse(target_url)
            domain = parsed.netloc or parsed.path.split("/")[0]
            if not domain:
                return None

            # Check for domain-specific auth file
            safe_domain = domain.replace(":", "_").replace("/", "_")
            auth_file = Path("auth_states") / f"auth_{safe_domain}.json"

            if auth_file.exists():
                logger.info(f"🔍 Found saved authentication for {domain}: {auth_file}")
                return str(auth_file)

            return None

        except Exception as e:
            logger.debug(f"Error during storage_state auto-lookup: {e}")
            return None

    @staticmethod
    def _load_permissions_for_domain(target_url: str) -> list[str] | None:
        """Load browser permissions from domain_settings for the domain.

        Look for domain_settings/{domain}/permissions.json file.
        Format: {"permissions": ["audioCapture", "videoCapture"]}

        Args:
            target_url: Target URL to extract domain from

        Returns:
            List of permissions if found, None otherwise
        """
        try:
            parsed = urlparse(target_url)
            domain = parsed.netloc or parsed.path.split("/")[0]
            if not domain:
                return None

            permissions_file = Path("domain_settings") / domain / "permissions.json"
            if permissions_file.exists():
                try:
                    content = json.loads(permissions_file.read_text())
                    permissions = content.get("permissions")
                    if isinstance(permissions, list):
                        logger.info(
                            f"🎤 Loaded permissions for {domain}: {permissions}"
                        )
                        return permissions
                except json.JSONDecodeError:
                    logger.warning(
                        f"Invalid JSON in permissions file: {permissions_file}"
                    )

            return None
        except Exception as e:
            logger.warning(f"Failed to load permissions: {e}")
            return None

    @staticmethod
    def _format_intervention_response(result: dict[str, Any], reason: str) -> str:
        """
        Format the response message for a human intervention request.

        Args:
            result: Result dictionary from request_human_intervention
            reason: The reason for requesting intervention

        Returns:
            Formatted message string for the agent
        """
        if result["success"]:
            return (
                f"✅ Human successfully completed the intervention!\n"
                f"Reason: {reason}\n"
                f"You can now continue with your task."
            )

        # Check if this was a timeout
        state = result.get("state", "error")

        if state == "timeout":
            # TIMEOUT RECOVERY: Check if recovery is enabled
            logger.warning(f"⏱️  HITL intervention timed out for: {reason}")

            if not HITL_RECOVERY_ENABLED:
                logger.info("❌ HITL recovery is disabled - stopping agent")
                return (
                    f"⏱️  Human intervention timed out after waiting.\n"
                    f"Reason requested: {reason}\n\n"
                    f"Recovery is disabled. You must stop and cannot continue."
                )

            logger.info(
                f"🔄 HITL recovery enabled with strategy: {HITL_RECOVERY_STRATEGY}"
            )

            if HITL_RECOVERY_STRATEGY == "skip":
                # Skip strategy: Move on to other tests
                return (
                    f"⏱️  Human intervention timed out after waiting.\n"
                    f"Reason requested: {reason}\n\n"
                    f"🔄 RECOVERY STRATEGY (skip):\n"
                    f"1. Skip the blocked task entirely\n"
                    f"2. Document the blocker in your summary\n"
                    f"3. Focus on testing other features that don't require intervention\n\n"
                    f"Continue with alternative testing goals."
                )
            else:
                # Continue strategy: Attempt to proceed
                return (
                    f"⏱️  Human intervention timed out after waiting.\n"
                    f"Reason requested: {reason}\n\n"
                    f"🔄 RECOVERY STRATEGY (continue):\n"
                    f"1. Try to continue with the task - sometimes the blocker may have resolved itself\n"
                    f"2. Look for alternative paths (e.g., skip button, close dialog, different route)\n"
                    f"3. If the blocker is still present and cannot be bypassed:\n"
                    f"   - Document the issue in your summary\n"
                    f"   - Explain what was blocked and why you couldn't proceed\n"
                    f"   - Try to test other features that don't require human intervention\n\n"
                    f"Attempt to continue your conversation and testing goals."
                )
        else:
            # Other error types
            return (
                f"❌ Human intervention failed.\n"
                f"Reason: {reason}\n"
                f"Error: {result.get('message', 'Unknown error')}\n"
                f"You may need to try a different approach."
            )

    @staticmethod
    def _normalize_max_turns(value: Any, default: int = DEFAULT_MAX_TURNS) -> int:
        """Convert max_turns to a positive integer, logging adjustments when needed."""
        try:
            normalized = int(value)
        except (TypeError, ValueError):
            logger.warning(
                "Invalid max_turns value %r; defaulting to %s turns", value, default
            )
            return default

        if normalized < MIN_TURNS:
            logger.warning(
                "max_turns value %s is below %s; forcing a single turn",
                normalized,
                MIN_TURNS,
            )
            return MIN_TURNS

        return normalized

    @staticmethod
    def parse_max_turns_from_persona(persona_description: str) -> int | None:
        """Parse max_turns from persona description.

        Looks for:
        ## Max Turns
        `20`
        or
        ## Max Turns
        20
        """
        match = re.search(
            r"##\s*Max\s*Turns\s*\n\s*`?(\d+)`?", persona_description, re.IGNORECASE
        )
        if match:
            return int(match.group(1))
        return None

    def _extract_transcript_from_history(
        self, history: list[Any]
    ) -> list[ConversationTurn]:
        """
        Extract conversation turns from agent's action history.

        Parses the agent's history to find text inputs (user messages) and
        responses from the chat interface (assistant messages).

        Args:
            history: Agent's execution history

        Returns:
            List of ConversationTurn objects
        """
        transcript: list[ConversationTurn] = []
        last_user_message: str | None = None

        for item in history:
            # Extract timestamp from step metadata if available
            timestamp: str | None = None
            if hasattr(item, "metadata") and item.metadata:
                if hasattr(item.metadata, "step_start_time"):
                    # Convert Unix timestamp to ISO 8601 format
                    timestamp = datetime.fromtimestamp(
                        item.metadata.step_start_time, tz=UTC
                    ).isoformat()

            # Handle different possible structures
            if not isinstance(item, dict):
                # Try to convert to dict if it has __dict__
                if hasattr(item, "__dict__"):
                    item = item.__dict__
                else:
                    continue

            # Check if this is an action with a result
            # Try model_output first (browser-use format)
            if "model_output" in item:
                model_output = item["model_output"]
                action = model_output.get("action", {})
            else:
                action = item.get("action", {})

            result = item.get("result", {})

            # Also try 'step' key which might contain action info
            if not action and "step" in item:
                step = item["step"]
                if isinstance(step, dict):
                    action = step.get("action", {})
                    result = step.get("result", {})

            # Look for input actions (user messages)
            # Handle both dict format and list format for actions
            actions_to_check = []
            if isinstance(action, list):
                actions_to_check = action
            elif isinstance(action, dict):
                actions_to_check = [action]

            for act in actions_to_check:
                if not isinstance(act, dict):
                    continue

                action_name = act.get("name", "")

                # User sent a message (input action with text)
                if action_name == "input" and "text" in act:
                    user_text = act.get("text", "").strip()
                    if user_text and len(user_text) > MIN_USER_MESSAGE_LENGTH:
                        if last_user_message != user_text:
                            transcript.append(
                                ConversationTurn(
                                    role="user", text=user_text, timestamp=timestamp
                                )
                            )
                            last_user_message = user_text

                # Also check for send_message tool calls
                elif action_name == "send_message" and "message" in act:
                    user_text = act.get("message", "").strip()
                    if user_text and len(user_text) > 0:
                        if last_user_message != user_text:
                            transcript.append(
                                ConversationTurn(
                                    role="user", text=user_text, timestamp=timestamp
                                )
                            )
                            last_user_message = user_text

                # Check for fast_type_and_submit action (dict key format)
                elif "fast_type_and_submit" in act:
                    fast_type_action = act["fast_type_and_submit"]
                    if (
                        isinstance(fast_type_action, dict)
                        and "text" in fast_type_action
                    ):
                        user_text = fast_type_action.get("text", "").strip()
                        if user_text and len(user_text) > MIN_USER_MESSAGE_LENGTH:
                            if last_user_message != user_text:
                                transcript.append(
                                    ConversationTurn(
                                        role="user", text=user_text, timestamp=timestamp
                                    )
                                )
                                last_user_message = user_text

            if isinstance(result, dict):
                result_text = result.get("text", "") or result.get("content", "")

                if result_text and len(result_text) > MIN_ASSISTANT_MESSAGE_LENGTH:
                    # Skip if the message contains any skip phrase (case-insensitive to handle variations like "Thinking...", "🤖 Thinking", etc.)
                    if any(
                        phrase.lower() in result_text.lower() for phrase in SKIP_PHRASES
                    ):
                        continue

                    # Try to extract clean response text
                    # Format 1: "Sent: X\nReceived: Y"
                    if "\nReceived:" in result_text:
                        parts = result_text.split("\nReceived:")
                        if len(parts) == 2:
                            response = parts[1].strip().strip("'\"")
                            if response and len(response) > 3:
                                transcript.append(
                                    ConversationTurn(
                                        role="assistant",
                                        text=response,
                                        timestamp=timestamp,
                                    )
                                )
                    # Format 2: Just the response text
                    elif not result_text.startswith("Sent:"):
                        transcript.append(
                            ConversationTurn(
                                role="assistant",
                                text=result_text.strip(),
                                timestamp=timestamp,
                            )
                        )

        return transcript

    def _extract_user_messages_from_history(self, history: list[Any]) -> list[str]:
        """
        Extract only user messages from agent's action history.

        Used for reconciliation to recover any user messages that were typed
        but not captured in the live transcript due to exceptions or timing issues.

        Args:
            history: Agent's execution history

        Returns:
            List of user message strings (in order)
        """
        user_messages: list[str] = []
        last_user_message: str | None = None

        for item in history:
            # Handle different possible structures
            if not isinstance(item, dict):
                if hasattr(item, "__dict__"):
                    item = item.__dict__
                else:
                    continue

            # Try model_output first (browser-use format)
            if "model_output" in item:
                model_output = item["model_output"]
                action = model_output.get("action", {})
            else:
                action = item.get("action", {})

            # Handle both dict format and list format for actions
            actions_to_check = []
            if isinstance(action, list):
                actions_to_check = action
            elif isinstance(action, dict):
                actions_to_check = [action]

            for act in actions_to_check:
                if not isinstance(act, dict):
                    continue

                # Check for fast_type_and_submit action (dict key format)
                if "fast_type_and_submit" in act:
                    fast_type_action = act["fast_type_and_submit"]
                    if (
                        isinstance(fast_type_action, dict)
                        and "text" in fast_type_action
                    ):
                        user_text = fast_type_action.get("text", "").strip()
                        if user_text and len(user_text) > MIN_USER_MESSAGE_LENGTH:
                            # Deduplicate consecutive identical messages
                            if last_user_message != user_text:
                                user_messages.append(user_text)
                                last_user_message = user_text

                # Also check for input action with text
                action_name = act.get("name", "")
                if action_name == "input" and "text" in act:
                    user_text = act.get("text", "").strip()
                    if user_text and len(user_text) > MIN_USER_MESSAGE_LENGTH:
                        if last_user_message != user_text:
                            user_messages.append(user_text)
                            last_user_message = user_text

        return user_messages

    def _reconcile_transcript_with_history(
        self,
        transcript: list[ConversationTurn],
        history: list[Any],
    ) -> int:
        """
        Reconcile transcript with history to recover missing user messages.

        This method compares user messages in the live transcript with user messages
        extracted from the agent's history. Any messages that were typed but not
        captured (due to exceptions, timing issues, etc.) are logged for debugging.

        NOTE: We intentionally do NOT add missing messages to the transcript because:
        1. We don't have the corresponding assistant responses
        2. Adding orphan user messages would corrupt the transcript structure
        3. The summary generator expects paired user/assistant messages

        Instead, we log the discrepancy for debugging and let the summary handle it.

        Args:
            transcript: The live transcript (will NOT be modified)
            history: Agent's execution history

        Returns:
            Number of missing user messages detected
        """
        # Extract user messages from history
        history_user_messages = self._extract_user_messages_from_history(history)

        # Extract user messages from transcript
        transcript_user_messages = [t.text for t in transcript if t.role == "user"]

        # Find missing messages (in history but not in transcript)
        missing_count = 0
        for hist_msg in history_user_messages:
            # Check if this message exists in transcript (fuzzy match to handle whitespace)
            found = any(
                hist_msg.strip() == trans_msg.strip()
                for trans_msg in transcript_user_messages
            )
            if not found:
                missing_count += 1
                logger.warning(
                    f"⚠️ User message not captured in transcript: {hist_msg[:80]}..."
                )

        if missing_count > 0:
            logger.warning(
                f"📊 Transcript reconciliation: {missing_count} user message(s) missing "
                f"(history has {len(history_user_messages)}, transcript has {len(transcript_user_messages)})"
            )
        else:
            logger.info(
                f"✓ Transcript reconciliation: all {len(history_user_messages)} user messages captured"
            )

        return missing_count

    async def _generate_summary(
        self,
        output_dir: str,
        persona_id: str,
        persona_description: str,
        transcript: list[ConversationTurn],
        final_url: str,
        persona_instance: str | None = None,
        test_suite_config: dict[str, Any] | None = None,
    ) -> None:
        """
        Generate a summary of the conversation analyzing persona goal achievement.

        Args:
            output_dir: Directory to save the summary
            persona_id: The persona identifier that was used
            persona_description: Full persona description from markdown file
            transcript: List of conversation turns
            final_url: URL where conversation took place
            persona_instance: Optional unique instance identifier (e.g., 'malicious_user_01')
            test_suite_config: Optional test suite configuration for prioritizing findings
        """

        await generate_persona_summary(
            output_dir=output_dir,
            persona_id=persona_id,
            persona_description=persona_description,
            transcript=transcript,
            final_url=final_url,
            persona_instance=persona_instance,
            test_suite_config=test_suite_config,
        )

    async def _generate_basic_summary(
        self,
        output_dir: str,
        transcript: list[ConversationTurn],
        final_url: str,
    ) -> None:
        """
        Generate a basic summary without persona analysis.

        Args:
            output_dir: Directory to save the summary
            transcript: List of conversation turns
            final_url: URL where conversation took place
        """

        logger.info("Generating basic conversation summary...")

        try:
            # Get date from transcript timestamp if available, otherwise use current time
            # Use same ISO format as transcript timestamps
            if transcript and transcript[0].timestamp:
                date_str = transcript[0].timestamp
            else:
                date_str = datetime.now(UTC).isoformat()

            # Create basic summary document
            summary = f"""# Conversation Summary

**URL**: {final_url}
**Date**: {date_str}
**Total Turns**: {calculate_turn_count(transcript)}
**Total Messages**: {len(transcript)}

---

## Conversation Statistics

- **User messages**: {len([t for t in transcript if t.role == "user"])}
- **Assistant responses**: {len([t for t in transcript if t.role == "assistant"])}
- **Average user message length**: {sum(len(t.text) for t in transcript if t.role == "user") / max(len([t for t in transcript if t.role == "user"]), 1):.0f} characters
- **Average assistant message length**: {sum(len(t.text) for t in transcript if t.role == "assistant") / max(len([t for t in transcript if t.role == "assistant"]), 1):.0f} characters

---

## Conversation Preview

"""

            # Add first few exchanges
            num_preview = min(6, len(transcript))  # Show first 3 turns (6 messages)
            for turn in transcript[:num_preview]:
                summary += f"**{turn.role.upper()}**: {turn.text}\n\n"

            if len(transcript) > num_preview:
                summary += f"*...and {len(transcript) - num_preview} more messages*\n\n"

            summary += """---

## Full Transcript

See `{TRANSCRIPT_FILENAME}` for the complete conversation transcript.

## Related Files

- **Transcript**: `{TRANSCRIPT_FILENAME}`
"""

            # Ensure output directory exists
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)

            summary_file = output_path / "summary.md"
            save_text_file(summary, summary_file)

        except Exception as e:
            logger.error(f"Failed to generate basic summary: {e}")

            logger.error(traceback.format_exc())

    async def _load_bindings_from_code(self, source_code: str) -> tuple[Any, Any]:
        """
        Dynamically load the generated Python module and extract the two functions.

        Args:
            source_code: Python source code as a string

        Returns:
            Tuple of (input_text function, await_text_output function)
        """
        # Create a temporary file to hold the generated code
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write(source_code)
            tmp_path = tmp.name

        try:
            # Load the module dynamically
            spec = importlib.util.spec_from_file_location("chat_bindings", tmp_path)
            if spec is None or spec.loader is None:
                raise ImportError(f"Could not load module from {tmp_path}")

            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Extract the two required functions
            input_text = module.input_text
            await_text_output = module.await_text_output

            return input_text, await_text_output

        finally:
            # Clean up temp file
            try:
                os.unlink(tmp_path)
            except Exception as e:
                logger.warning(f"Could not delete temp file {tmp_path}: {e}")

    async def run_conversation(
        self,
        target_url: str,
        seed_utterance: str = DEFAULT_SEED_UTTERANCE,
        max_turns: int = DEFAULT_MAX_TURNS,
        output_dir: str | None = None,
        app_context_file: str | None = None,
        persona_id: str | None = None,
        persona_instance: str | None = None,
        arato_api_url: str | None = None,
        arato_api_key: str | None = None,
        thread_id: str | None = None,
        run_id: str | None = None,
        org_id: str | None = None,
        step_timeout: int = DEFAULT_STEP_TIMEOUT,
        timeout: int = DEFAULT_PIPELINE_TIMEOUT,
        progress_tracker: Any | None = None,
        broadcast_identity: bool = False,
        task_id: str | None = None,
        test_suite_id: str | None = None,
        domain: str | None = None,
        role: str | None = None,
        locale: str = "en_US",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Run conversation using Strands Agent orchestration.

        This is the new implementation that uses:
        - Strands Agent for orchestration and decision-making
        - Browser-use subagents for discovery and turn execution
        - Fresh agent per turn (no history accumulation)

        Args:
            target_url: URL of the chat interface to test
            seed_utterance: Initial message to send
            max_turns: Maximum conversation turns
            output_dir: Directory for session artifacts
            app_context_file: Path to app context JSON
            persona_id: Persona identifier (e.g., 'malicious_user')
            persona_instance: Unique instance name (e.g., 'malicious_user_01')
            arato_api_url: Arato API endpoint for logging
            arato_api_key: Arato API key
            thread_id: Thread ID for logging correlation
            run_id: Run identifier for task updates
            org_id: Organization ID
            step_timeout: Timeout per browser-use step
            timeout: Total conversation timeout
            progress_tracker: Progress tracker for UI updates
            broadcast_identity: If True, send 'arato_agent/<task_id>' as the first message
            task_id: Task identifier used for identity broadcast
            test_suite_id: Test suite ID for configuration
            domain: Domain ID (e.g., 'travel', 'hr')
            role: Role ID (e.g., 'consumer', 'manager')
            locale: IETF language tag (default: 'en_US')
            **kwargs: Additional arguments (ignored for compatibility)

        Returns:
            Result dictionary with transcript, metrics, and config
        """
        from agents.chat_runner.conversation_orchestrator import (
            ConversationOrchestrator,
        )
        from core.multiagent.registry import get_agent_registry
        from utils.config_loader import (
            TestCase,
            compose_test_prompt,
            get_available_personas,
        )

        logger.info(f"🚀 [Strands] Starting conversation at {target_url}")
        logger.info(f"   Persona: {persona_id}, Max turns: {max_turns}")

        # Store for HITL
        ChatRunner._current_target_url = target_url

        # Normalize max_turns
        max_turns = self._normalize_max_turns(max_turns)

        # Load app context
        app_context = ""
        if app_context_file:
            context_path = Path(app_context_file)
            if context_path.exists():
                try:
                    with open(context_path) as f:
                        file_content = f.read()
                    try:
                        context_data = json.loads(file_content)
                        app_context_parts = []
                        for key, value in context_data.items():
                            if isinstance(value, str) and value.strip():
                                app_context_parts.append(
                                    f"**{key.replace('_', ' ').title()}:** {value}"
                                )
                            elif value:
                                app_context_parts.append(
                                    f"**{key.replace('_', ' ').title()}:** {value}"
                                )
                        app_context = "\n".join(app_context_parts)
                    except json.JSONDecodeError:
                        app_context = file_content.strip()
                    if len(app_context) > 50:
                        logger.info(f"Loaded app context: {len(app_context)} chars")
                except Exception as e:
                    logger.warning(f"Failed to load app context: {e}")

        # Load test suite config
        test_suite_config: dict[str, Any] | None = None
        if test_suite_id:
            try:
                from utils.config_loader import load_test_suite

                test_suite = load_test_suite(test_suite_id)
                test_suite_config = {
                    "domain": getattr(test_suite, "domain", None),
                    "custom_agents": getattr(test_suite, "custom_agents", []),
                    "allowed_disclosures": getattr(
                        test_suite, "allowed_disclosures", []
                    ),
                    "admin_only_fields": getattr(test_suite, "admin_only_fields", {}),
                    "questions_to_answer": getattr(
                        test_suite, "questions_to_answer", []
                    ),
                    "key_risks": getattr(test_suite, "key_risks", []),
                }
                logger.info(f"✓ Loaded test suite '{test_suite_id}'")
            except Exception as e:
                logger.warning(f"Failed to load test suite '{test_suite_id}': {e}")

        # Determine domain
        detected_domain = domain
        if not detected_domain and app_context:
            try:
                context_data = json.loads(app_context)
                detected_domain = context_data.get("domain")
            except (json.JSONDecodeError, AttributeError) as e:
                logger.debug(
                    "Could not infer domain from app_context JSON; leaving detected_domain unchanged: %s",
                    e,
                )

        # Load persona description
        persona_description = ""
        if persona_id:
            available_personas = get_available_personas()
            if persona_id in available_personas and detected_domain:
                test_case = TestCase(
                    id=persona_id,
                    name=persona_id,
                    description=f"Persona: {persona_id}",
                    persona=persona_id,
                    role="consumer",
                    scenarios=[],
                    max_turns=max_turns,
                    locale=locale,
                )
                persona_description = compose_test_prompt(
                    test_case=test_case,
                    domain_id=detected_domain,
                    app_context=app_context,
                    test_suite_config=test_suite_config,
                )
                logger.info(
                    f"✓ Loaded persona '{persona_id}': {len(persona_description)} chars"
                )

                # Check for max_turns override
                persona_max_turns = self.parse_max_turns_from_persona(
                    persona_description
                )
                if persona_max_turns:
                    logger.info(
                        f"Overriding max_turns: {persona_max_turns} (was {max_turns})"
                    )
                    max_turns = persona_max_turns

        # Setup storage state
        storage_state = self.storage_state
        if not storage_state:
            storage_state = self._auto_lookup_storage_state(target_url)
            if storage_state:
                logger.info(f"📂 Auto-detected auth: {storage_state}")

        # Load domain permissions
        domain_permissions = self._load_permissions_for_domain(target_url)

        # Setup browser
        browser_kwargs = setup_browser_kwargs(
            headless=self.headless,
            disable_security=False,
            storage_state=storage_state,
            permissions=domain_permissions,
        )

        # Restrict to target domain
        allowed_domains = extract_domain_pattern(target_url)
        try:
            import ipaddress

            ipaddress.ip_address(allowed_domains[0])
        except (ValueError, IndexError):
            browser_kwargs["allowed_domains"] = allowed_domains
            logger.info(f"Browser restricted to: {', '.join(allowed_domains)}")

        # Setup video recording
        if output_dir:
            output_path = Path(output_dir).resolve()
            output_path.mkdir(parents=True, exist_ok=True)
            video_dir = output_path / VIDEO_SUBDIR_RUN
            video_dir.mkdir(parents=True, exist_ok=True)
            browser_kwargs["record_video_dir"] = str(video_dir)
            browser_kwargs["record_har_path"] = str(output_path / "conversation.har")
            browser_kwargs["record_har_content"] = "embed"

        # Initialize Arato client
        arato_client: AratoLogsAPI | None = None
        if arato_api_url and arato_api_key:
            arato_client = AratoLogsAPI(api_url=arato_api_url, api_key=arato_api_key)
            logger.info("✓ Arato logging enabled")

        # Get agent registry
        agent_registry = get_agent_registry()

        # Run with browser
        async with create_browser(**browser_kwargs) as browser:
            logger.info(f"✓ Browser created (PID: {os.getpid()})")

            # Report browser session info to progress tracker (for DCV viewer)
            if progress_tracker and persona_instance:
                try:
                    bm = get_browser_manager()
                    session_info = bm.get_session_info()
                    progress_tracker.update_persona(
                        persona_instance,
                        browser_session_id=session_info["session_id"],
                        browser_type=session_info["browser_type"],
                        browser_identifier=session_info.get("browser_identifier"),
                    )
                except Exception:
                    pass  # Non-critical — don't block agent execution

            # Create LLM
            llm = create_chat_model()

            # Create Strands orchestrator
            orchestrator = ConversationOrchestrator(
                browser_session=browser,
                llm=llm,
                target_url=target_url,
                persona_id=persona_id or "unknown",
                persona_description=persona_description,
                persona_instance=persona_instance,
                app_context=app_context,
                max_turns=max_turns,
                output_dir=output_dir or "",
                session_id=thread_id or "",
                arato_client=arato_client,
                agent_registry=agent_registry,
                progress_tracker=progress_tracker,
                test_suite_config=test_suite_config,
                seed_utterance=seed_utterance,
                storage_state=storage_state,
                timeout_seconds=timeout,
                step_timeout=step_timeout,
                broadcast_identity=broadcast_identity,
                task_id=task_id,
            )

            # Run orchestrator
            orchestrator_result = await orchestrator.run()

        # After browser context exits — move video artifacts
        if output_dir:
            move_run_video(Path(output_dir))
            logger.info("Moved video artifacts")

        # Determine finish_reason based on ACTUAL transcript entries, not
        # turn_count (which increments on every attempt, including failures).
        actual_turns = len(orchestrator.transcript) // 2  # user+assistant pairs
        if orchestrator.user_stopped:
            finish_reason = FinishReason.USER_STOPPED.value
        elif orchestrator.timed_out:
            finish_reason = FinishReason.TIMEOUT.value
        elif orchestrator.chatbot_terminated:
            finish_reason = FinishReason.CHATBOT_STOPPED.value
        elif orchestrator_result["success"]:
            if actual_turns >= max_turns:
                finish_reason = FinishReason.REACHED_MAX_TURNS.value
            else:
                finish_reason = FinishReason.AGENT_STOPPED.value
        else:
            finish_reason = FinishReason.ERROR.value

        # Build return result matching expected format
        serialized_transcript = [
            orchestrator._serialize_turn(t) for t in orchestrator.transcript
        ]
        result: dict[str, Any] = {
            "target_url": target_url,
            "persona_id": persona_id,
            "persona_instance": persona_instance,
            "transcript": serialized_transcript,
            "total_turns": actual_turns,
            "finish_reason": finish_reason,
            "timestamp": datetime.now(UTC).isoformat(),
        }

        if orchestrator.ground_truth_data:
            result["ground_truth"] = orchestrator.ground_truth_data

        if test_suite_id:
            result["test_suite_id"] = test_suite_id

        # Add merged test configuration for audit trail
        if persona_id:
            try:
                config_summary = get_config_summary(
                    persona_id=persona_id,
                    role_id=role,
                    domain_id=domain,
                )
                result["test_config"] = config_summary
            except Exception as e:
                logger.warning(f"Failed to get config summary: {e}")

        # Save final transcript.json with full metadata
        if output_dir:
            try:
                transcript_path = os.path.join(output_dir, "transcript.json")
                with open(transcript_path, "w") as f:
                    json.dump(result, f, indent=2)
                logger.info(f"💾 Final transcript saved: {transcript_path}")
            except Exception as e:
                logger.warning(f"Failed to save final transcript: {e}")

        # Add usage data to result (but don't save to transcript.json)
        final_result = result.copy()
        if (
            orchestrator.cumulative_usage
            and orchestrator.cumulative_usage["total_tokens"] > 0
        ):
            final_result["usage"] = orchestrator.cumulative_usage

        return final_result
