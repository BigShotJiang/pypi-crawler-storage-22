"""
Turn Subagent.

Browser-use based subagent for executing a single conversation turn.
Creates a fresh browser-use agent per turn (no history accumulation).

Responsibilities:
- Type user message into chat input
- Submit the message
- Wait for and extract chatbot response
"""

import logging
from collections.abc import Callable
from typing import Any

from browser_use import Agent, Controller

from constants import CHATBOT_TERMINATION_PHRASES
from models.turn_result import TurnResult
from tools.fast_typing import FastTyper
from tools.response_extraction import ResponseExtractor
from utils.prompt_loader import load_prompt
from utils.timing_logger import measure_time_with_browser

logger = logging.getLogger(__name__)

# Default step limit for turn execution
DEFAULT_TURN_MAX_STEPS = 5


class TurnSubagent:
    """
    Browser-use subagent for executing a single conversation turn.

    Creates a FRESH browser-use agent for each turn, eliminating the need
    for history pruning (no accumulated history).

    Responsibilities:
    - Type user message using fast CDP-based typing
    - Submit via button click or Enter key
    - Extract chatbot response using 4-phase pipeline
    - Detect chatbot termination (escalation/handoff)
    """

    def __init__(
        self,
        browser_session: Any,
        llm: Any,
        on_first_token_callback: Callable[[], None] | None = None,
    ):
        """
        Initialize the turn subagent.

        Args:
            browser_session: Shared browser session (keep_alive=True)
            llm: LLM model for response extraction
            on_first_token_callback: Optional callback for TTFT tracking (invoked when
                chatbot starts responding)
        """
        self.browser_session = browser_session
        self.llm = llm
        self.fast_typer = FastTyper(browser_session)
        self.response_extractor = ResponseExtractor(
            browser_session, llm, on_first_token_callback=on_first_token_callback
        )

    async def execute_turn(
        self,
        message: str,
        chat_input_selector: str,
        last_assistant_text: str | None = None,
        turn_number: int = 1,
        max_steps: int = DEFAULT_TURN_MAX_STEPS,
    ) -> TurnResult:
        """
        Execute a single conversation turn.

        1. Type the message using fast CDP typing
        2. Submit via button or Enter key
        3. Extract chatbot response using 4-phase pipeline
        4. Detect chatbot termination

        Args:
            message: User message to send
            chat_input_selector: CSS selector for chat input field
            last_assistant_text: Previous response for deduplication
            turn_number: Current turn number (1-indexed)
            max_steps: Maximum browser-use steps (default: 5)

        Returns:
            TurnResult with success status and response
        """
        logger.info(f"🔄 Executing turn {turn_number}: {message[:50]}...")

        try:
            # Step 1: Type and submit message
            typing_result = await self.fast_typer.type_and_submit(
                selector=chat_input_selector,
                text=message,
                press_enter=True,
            )

            if not typing_result.success:
                logger.error(f"❌ Typing failed: {typing_result.error}")
                return TurnResult.failed(
                    error=typing_result.error or "Typing failed",
                    user_message=message,
                )

            # Pass fingerprint to response extractor for change detection
            if typing_result.fingerprint:
                self.response_extractor.set_pre_send_fingerprint(
                    typing_result.fingerprint
                )

            logger.info("✅ Message sent, extracting response...")

            # Step 2: Extract chatbot response using 4-phase pipeline
            # Use measure_time_with_browser to capture browser metrics (CPU, memory, DOM nodes, etc.)
            extraction_metadata: dict[str, Any] = {}

            async with measure_time_with_browser(
                "response_extraction",
                browser=self.browser_session,
                turn=turn_number,
                context_metadata=extraction_metadata,
            ):
                extraction_result = (
                    await self.response_extractor.extract_latest_response(
                        user_message_context=message,
                        last_assistant_text=last_assistant_text,
                    )
                )
                # Merge extraction_metadata from ResponseExtractor
                if extraction_result.extraction_metadata:
                    extraction_metadata.update(extraction_result.extraction_metadata)

            if not extraction_result.success or not extraction_result.response_text:
                logger.warning(
                    f"⚠️ Response extraction failed: {extraction_result.error}"
                )
                return TurnResult.extraction_failed(user_message=message)

            response_text = extraction_result.response_text

            # Step 3: Check for chatbot termination
            chatbot_terminated = self._detect_chatbot_termination(response_text)
            if chatbot_terminated:
                logger.info("🔚 Detected chatbot termination (escalation/handoff)")

            logger.info(f"✓ Turn {turn_number} completed: {response_text[:100]}...")

            return TurnResult.success_turn(
                user_message=message,
                assistant_response=response_text,
                turn_number=turn_number,
                chatbot_terminated=chatbot_terminated,
                extraction_metadata=extraction_metadata,  # Includes browser metrics from timing
            )

        except Exception as e:
            logger.error(f"❌ Turn execution failed: {e}")
            return TurnResult.failed(error=str(e), user_message=message)

    async def execute_turn_with_agent(
        self,
        message: str,
        last_assistant_text: str | None = None,
        turn_number: int = 1,
        max_steps: int = DEFAULT_TURN_MAX_STEPS,
    ) -> TurnResult:
        """
        Execute a turn using a full browser-use agent (fallback for complex cases).

        Creates a fresh browser-use agent for this turn only. Use this when
        the simple execute_turn() fails (e.g., dynamic selectors, complex UI).

        Args:
            message: User message to send
            last_assistant_text: Previous response for deduplication
            turn_number: Current turn number (1-indexed)
            max_steps: Maximum browser-use steps (default: 5)

        Returns:
            TurnResult with success status and response
        """
        logger.info(
            f"🤖 Executing turn {turn_number} with browser-use agent: {message[:50]}..."
        )

        # Load turn execution prompt
        turn_task = load_prompt(
            "turn_execution_task",
            message=message,
            turn_number=turn_number,
        )

        # Create controller with typing and extraction tools
        controller: Controller = Controller()
        self._register_turn_tools(controller, message, last_assistant_text, turn_number)

        # Create FRESH browser-use agent for this turn
        agent: Agent = Agent(
            task=turn_task,
            llm=self.llm,
            browser=self.browser_session,
            controller=controller,
            use_vision=True,
        )

        # Set keep_alive to preserve browser session
        if hasattr(self.browser_session, "browser_profile"):
            self.browser_session.browser_profile.keep_alive = True

        try:
            history = await agent.run(max_steps=max_steps)

            # Capture usage data from browser-use agent
            usage = None
            if history and hasattr(history, "usage") and history.usage:
                usage = history.usage

            # Check if we captured a result
            if history and history.final_result():
                result_text = history.final_result()
                # Parse the result - agent should return structured data
                # For now, treat any substantial text as success
                if result_text and len(result_text) > 20:
                    # Check for termination
                    chatbot_terminated = self._detect_chatbot_termination(result_text)
                    result = TurnResult.success_turn(
                        user_message=message,
                        assistant_response=result_text,
                        turn_number=turn_number,
                        chatbot_terminated=chatbot_terminated,
                    )
                    result.usage = usage
                    return result

            return TurnResult.extraction_failed(user_message=message)

        except Exception as e:
            logger.error(f"❌ Agent-based turn execution failed: {e}")
            return TurnResult.failed(error=str(e), user_message=message)

        finally:
            self._cleanup_event_bus(agent)

    def _register_turn_tools(
        self,
        controller: Controller,
        message: str,
        last_assistant_text: str | None,
        turn_number: int,
    ) -> None:
        """Register tools for turn execution."""
        fast_typer = self.fast_typer
        response_extractor = self.response_extractor

        @controller.action(
            description="Type message and submit using fast CDP-based typing"
        )
        async def fast_type_and_submit(
            selector: str, text: str, press_enter: bool = True
        ) -> str:
            """Type text into input field and submit."""
            result = await fast_typer.type_and_submit(selector, text, press_enter)
            if result.fingerprint:
                response_extractor.set_pre_send_fingerprint(result.fingerprint)
            return result.message

        @controller.action(description="Extract the chatbot response from the page")
        async def extract_response() -> str:
            """Extract the latest chatbot response."""
            result = await response_extractor.extract_latest_response(
                user_message_context=message,
                last_assistant_text=last_assistant_text,
            )
            if result.success and result.response_text:
                return result.response_text
            return f"EXTRACTION_FAILED: {result.error}"

    def _detect_chatbot_termination(self, response_text: str) -> bool:
        """Check if the response contains phrases indicating chatbot ended conversation."""
        if not response_text:
            return False

        response_lower = response_text.lower()
        for phrase in CHATBOT_TERMINATION_PHRASES:
            if phrase.lower() in response_lower:
                logger.info(f"🔚 Detected chatbot termination phrase: '{phrase}'")
                return True
        return False

    def _cleanup_event_bus(self, agent: Agent) -> None:
        """Cleanup browser-use EventBus to prevent memory leaks."""
        try:
            if hasattr(agent, "browser_session") and hasattr(
                agent.browser_session, "_event_bus"
            ):
                event_bus = agent.browser_session._event_bus
                if event_bus and hasattr(event_bus, "stop"):
                    event_bus.stop(clear=True)  # type: ignore[union-attr]
                    logger.debug("✓ Cleaned up EventBus")
        except Exception as cleanup_error:
            logger.warning(f"Failed to cleanup EventBus: {cleanup_error}")

    async def capture_welcome_message(self) -> str | None:
        """
        Capture the welcome message from the chat (turn 0).

        Should be called BEFORE sending the first user message.

        Returns:
            Welcome message text, or None if not found
        """
        logger.info("📝 Attempting to capture welcome message...")

        try:
            # Extract current page content
            extraction_result = await self.response_extractor.extract_latest_response(
                user_message_context=None,
                last_assistant_text=None,
            )

            if extraction_result.success and extraction_result.response_text:
                logger.info(
                    f"✓ Captured welcome message: {extraction_result.response_text[:100]}..."
                )
                return extraction_result.response_text

            logger.debug("No welcome message found (may not exist)")
            return None

        except Exception as e:
            logger.debug(f"Failed to capture welcome message: {e}")
            return None
