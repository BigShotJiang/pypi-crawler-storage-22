"""
Evaluation agents for the multi-agent evaluation system.

Each evaluation agent implements specific evaluation capabilities
(EVALUATE_TURN, SUMMARIZE_CONVERSATION, SUMMARIZE_RUN) and is
registered via the AgentRegistry.

NOTE: Skills are NOT agents. Skills are domain-specific capabilities that
agents can activate during conversation (see skills/ directory and SkillTool).
"""

# Core agents
# Accessibility agents
from agents.eval_agents.accessibility_agent import AccessibilityAgent
from agents.eval_agents.compliance_agent import ComplianceAgent

# Quality agents
from agents.eval_agents.consistency_agent import ConsistencyAgent
from agents.eval_agents.context_retention_agent import ContextRetentionAgent
from agents.eval_agents.data_leakage_agent import DataLeakageAgent

# Domain-specific agents
from agents.eval_agents.ecommerce_agent import EcommerceAgent

# Conversation flow agents
from agents.eval_agents.escalation_agent import EscalationAgent

# Compliance agents
from agents.eval_agents.financial_compliance_agent import FinancialComplianceAgent
from agents.eval_agents.goal_completion_agent import GoalCompletionAgent
from agents.eval_agents.hallucination_agent import HallucinationAgent

# Strands-based agents (new architecture)
from agents.eval_agents.healthcare_compliance_agent import HealthcareComplianceAgent

# Client-specific agents
from agents.eval_agents.honeycomb_agent import HoneycombAgent
from agents.eval_agents.hr_agent import HRAgent
from agents.eval_agents.insurance_agent import InsuranceAgent

# Security agents
from agents.eval_agents.jailbreak_detection_agent import JailbreakDetectionAgent
from agents.eval_agents.multilingual_agent import MultilingualAgent
from agents.eval_agents.repetition_agent import RepetitionAgent
from agents.eval_agents.tech_support_agent import TechSupportAgent
from agents.eval_agents.travel_agent import TravelAgent

# UI validation agents
from agents.eval_agents.ui_validation_agent import UIValidationAgent
from agents.eval_agents.ux_agent import UXAgent

__all__ = [
    # Core
    "ComplianceAgent",
    "UXAgent",
    # Security
    "JailbreakDetectionAgent",
    "DataLeakageAgent",
    # Compliance
    "FinancialComplianceAgent",
    "HealthcareComplianceAgent",
    "HRAgent",
    "InsuranceAgent",
    "TechSupportAgent",
    # Domain
    "EcommerceAgent",
    "TravelAgent",
    # Client-specific
    "HoneycombAgent",
    # Quality
    "ConsistencyAgent",
    "HallucinationAgent",
    "ContextRetentionAgent",
    # Accessibility
    "AccessibilityAgent",
    "MultilingualAgent",
    # Flow
    "EscalationAgent",
    "GoalCompletionAgent",
    "RepetitionAgent",
    # UI Validation
    "UIValidationAgent",
]
