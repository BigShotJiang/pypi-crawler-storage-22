"""
Accessibility Agent - Strands-based evaluation agent.

Evaluates chatbot responses for accessibility, including screen reader
compatibility, cognitive accessibility, and clear communication for
users with disabilities.
"""

import logging

from strands import tool
from strands.types.tools import ToolContext

from constants import CATEGORY_UX
from core.multiagent.capabilities import Capability
from core.multiagent.context import ConversationContext, EvalContext, RunContext
from core.multiagent.strands_eval_agent import EvalState, StrandsEvalAgent

logger = logging.getLogger(__name__)


class AccessibilityAgent(StrandsEvalAgent):
    """Evaluates chatbot responses for accessibility compliance.

    Uses Strands tools to check for WCAG compliance, cognitive
    accessibility, screen reader compatibility, and inclusive design.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="accessibility",
            name="Accessibility Evaluator",
            description="Evaluates response accessibility and inclusive design",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_UX,
            version="2.0.0",
            tags=["accessibility", "inclusion", "wcag", "a11y"],
        )

    def get_system_prompt(self) -> str:
        return """You are an Accessibility Agent specialized in evaluating chatbot responses for accessibility.

Your expertise is in identifying:

1. **Cognitive Accessibility**: Clear, simple language; logical structure
   - Avoid jargon and complex sentence structures
   - Use clear, step-by-step instructions
   - Provide summaries for long content

2. **Screen Reader Compatibility**: Proper text flow, described visuals
   - Any visual elements should be described in text
   - Avoid relying on spatial references ("click the button on the right")
   - Use clear link text (not "click here")

3. **Reading Level**: Appropriate complexity for general audience
   - Content should be understandable by users with varying literacy levels
   - Technical terms should be explained

4. **Sensory Considerations**: Not relying solely on visual cues
   - Color should not be the only way to convey information
   - Avoid "see the red text" type references

5. **Navigation Support**: Clear instructions that don't assume abilities
   - Don't assume mouse use
   - Provide keyboard alternatives when relevant

WCAG Considerations:
- Clear and simple language (WCAG 3.1.5)
- Consistent navigation and terminology
- Error identification and suggestions
- Text alternatives for non-text content"""

    def get_tools(
        self, state: EvalState, context: EvalContext | ConversationContext | RunContext
    ) -> list:
        tools = super().get_tools(state, context)
        tools.extend(self._create_accessibility_tools(state, context))
        return tools

    def _create_accessibility_tools(
        self,
        state: EvalState,
        context: EvalContext | ConversationContext | RunContext,
    ) -> list:
        @tool(context="tool_context")
        def check_reading_level(
            tool_context: ToolContext,  # noqa: ARG001
            text: str,
        ) -> str:
            """Analyze text for reading level and complexity using textstat.

            Uses industry-standard readability formulas:
            - Flesch Reading Ease (0-100, higher = easier)
            - Flesch-Kincaid Grade Level (US school grade)
            - SMOG Index (years of education needed)
            - Dale-Chall Score (comprehensibility)

            Args:
                text: The text to analyze

            Returns comprehensive readability analysis.
            """
            import importlib
            import json
            from typing import Any, cast

            _mod = importlib.import_module("textstat")
            # Cast to Any to suppress type errors for untyped module
            textstat = cast(Any, _mod)

            # Get multiple readability metrics
            flesch_ease = textstat.flesch_reading_ease(text)
            flesch_grade = textstat.flesch_kincaid_grade(text)
            smog = textstat.smog_index(text)
            coleman_liau = textstat.coleman_liau_index(text)
            dale_chall = textstat.dale_chall_readability_score(text)
            difficult_words = textstat.difficult_words(text)
            reading_time_sec = textstat.reading_time(text)

            # Get text standard (consensus grade level)
            text_standard = textstat.text_standard(text, float_output=True)

            # Interpret Flesch ease
            if flesch_ease >= 80:
                ease_interpretation = "Easy (6th grade)"
            elif flesch_ease >= 60:
                ease_interpretation = "Standard (8th-9th grade)"
            elif flesch_ease >= 40:
                ease_interpretation = "Difficult (college level)"
            else:
                ease_interpretation = "Very difficult (graduate level)"

            return json.dumps(
                {
                    "tool": "textstat",
                    "flesch_reading_ease": round(flesch_ease, 1),
                    "flesch_ease_interpretation": ease_interpretation,
                    "flesch_kincaid_grade": round(flesch_grade, 1),
                    "smog_index": round(smog, 1),
                    "coleman_liau_index": round(coleman_liau, 1),
                    "dale_chall_score": round(dale_chall, 1),
                    "text_standard_grade": round(text_standard, 1),
                    "difficult_words_count": difficult_words,
                    "reading_time_seconds": round(reading_time_sec, 1),
                    "instruction": "If grade level > 8 or Flesch ease < 60, content may be too complex for general audience",
                }
            )

        return [
            check_reading_level,
        ]


def create_accessibility_agent() -> AccessibilityAgent:
    return AccessibilityAgent()


__all__ = ["AccessibilityAgent", "create_accessibility_agent"]
