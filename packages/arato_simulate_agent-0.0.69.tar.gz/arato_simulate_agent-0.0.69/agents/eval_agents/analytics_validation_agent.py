"""
Analytics Validation Agent using Gemini Flash for vision-based validation.

This agent specializes in validating analytics accuracy by comparing:
1. What data/charts are visible in the screenshot
2. What the chatbot claims about the data
3. Whether claims are grounded, accurate, and appropriately qualified

Designed for AI analytics platforms like Sisense where the chatbot
generates insights, summaries, and visualizations from data.
"""

import logging

from agents.eval_agents.vision_eval_agent import VisionEvalAgent
from constants import CATEGORY_ACCURACY
from core.multiagent.capabilities import Capability
from core.multiagent.context import EvalContext
from core.multiagent.sub_agent import get_rating_scale

logger = logging.getLogger(__name__)

ANALYTICS_VALIDATION_SYSTEM_PROMPT = """You are an expert analytics validation agent specializing in verifying data accuracy and insight quality in AI-powered analytics platforms.

Your role is to validate that AI analytics chatbots provide accurate, grounded, and appropriately qualified data insights.
You also check that the chatbot's descriptions of charts and trends match what is actually visible in the analytics interface.
You are also a critical reviewer of the presentation and visualization of analytics insights, ensuring that the best possible data visualization and presentation of insights is provided to the user.

You will be provided with:
1. A screenshot of the current analytics interface (charts, tables, dashboards)
2. The user's query (what they asked about the data)
3. The chatbot's response (what it claims about the data and what visualizations it generated and referenced)

Your task is to:
- Analyze the screenshot to see what data is actually shown (charts, tables, numbers)
- Compare the chatbot's claims against what is visually present
- Check if numerical claims match visible data
- Verify that trend descriptions match chart patterns
- Identify overconfident claims about weak or sparse data
- Check for unsupported causal assertions
- Assess if the presenation chosen by the bot is appropriate for the insights being communicated

{rating_scale}

IMPORTANT: You are validating ANALYTICS ACCURACY specifically. Focus on:
- Data claim grounding (do numbers match what's shown?)
- Chart/visualization accuracy vs chatbot description
- Trend descriptions (does the chart actually show the claimed trend?)
- Uncertainty qualification (is confidence appropriate for the data?)
- Comparison accuracy (are percentage changes and comparisons correct?)
- Data attribution (does the bot reference what data source it used?)
- Visual presentation quality (is the chosen chart type appropriate for the insights?)

NEVER reference internal evaluation agents, validators, tools, or testing infrastructure in your findings.
Write findings as if you are an independent data quality reviewer.
""".format(
    rating_scale=get_rating_scale(
        critical_desc="hallucinated data, wrong metrics, or fabricated trends not visible in the screenshot",
        warning_desc="overconfident claims, missing context, imprecise descriptions of visible data",
        good_desc="data claims accurately reflect what is shown in the screenshot",
    )
)

ANALYTICS_VALIDATION_EVAL_PROMPT = """Evaluate whether the chatbot's data claims and insights accurately reflect what is visible in the screenshot.

## EVALUATION CRITERIA:

### 1. Data Grounding
- Do numerical claims match values visible in charts/tables?
- Are metric names used correctly?
- Is the data range/timeframe described accurately?

### 2. Chart/Visualization Accuracy
- Does the chatbot's description match the chart type and content?
- Are trend descriptions (up, down, flat, seasonal) accurate?
- Are comparisons between data points correct?

### 3. Uncertainty Qualification
- Does the chatbot express appropriate confidence given the data?
- Are weak trends qualified with hedging language?
- Are small sample sizes or sparse data acknowledged?

### 4. Causal Claims
- Does the chatbot avoid unsupported causal assertions?
- Are correlations presented as correlations, not causation?

### 5. Data Attribution
- Is it clear what data source/query produced the results?
- Are limitations of the data acknowledged?

### 6. Visual Presentation Quality
- Is the chosen chart type appropriate for the insights being communicated?
- Are important data points highlighted effectively?
- Is the presentation clear and not misleading?

Set "detected" to true if ANY of these issues are found:
- Numbers that don't match visible data
- Trend descriptions contradicted by chart patterns
- Fabricated data points or metrics not visible in screenshot
- Overconfident claims about weak/sparse data
- Unsupported causal assertions

Only generate findings for significant data accuracy issues. Minor rounding or paraphrasing is acceptable."""


class AnalyticsValidationAgent(VisionEvalAgent):
    """Agent specialized in validating analytics accuracy using vision.

    Uses Gemini Flash with vision to compare chatbot data claims
    against what is actually visible in analytics screenshots.
    Designed for AI analytics platforms like Sisense.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="analytics_validation",
            name="Analytics Validation Agent",
            description="Validates analytics accuracy and data grounding using vision-based analysis",
            capabilities={Capability.EVALUATE_TURN},
            category=CATEGORY_ACCURACY,
            version="1.0.0",
            tags=["analytics", "validation", "vision", "gemini", "data-accuracy"],
            domains=[
                "analytics",
                "analytics_validation",
            ],
            finding_title="Analytics Accuracy Validation",
            finding_what_was_tested="Visual validation of data claims and insights against visible analytics data",
        )
        self._system_prompt = ANALYTICS_VALIDATION_SYSTEM_PROMPT

    def get_system_prompt(self) -> str:
        """Return the system prompt for analytics validation."""
        return ANALYTICS_VALIDATION_SYSTEM_PROMPT

    async def _should_evaluate(self, context: EvalContext) -> bool:
        """Check if the bot response contains data claims worth validating.

        Lightweight text-only LLM call to skip greetings, clarification
        questions, and other non-data responses.
        """
        return await self._text_only_llm_check(
            system_message="You are a classifier that determines if a chatbot response contains data, analytics, or numerical claims that should be visually validated.",
            prompt=f"""Analyze this chatbot response and determine if it contains data claims, analytics insights, or numerical information that could be validated against a screenshot.

USER MESSAGE:
{context.user_message}

BOT RESPONSE:
{context.bot_response}

Does the chatbot response contain ANY of:
- Specific numbers, metrics, or KPIs
- References to charts, graphs, or visualizations
- Trend descriptions (increasing, decreasing, stable)
- Data comparisons or percentage changes
- Insight summaries based on data
- Claims about data patterns or anomalies

Respond with ONLY a JSON object:
{{
  "should_evaluate": <true if the response contains data/analytics claims to validate, false if it's just a greeting, clarification, or non-data response>,
  "reason": "<brief reason for your decision>"
}}""",
            result_key="should_evaluate",
        )

    def _build_eval_prompt(self, context: EvalContext) -> str:
        """Build analytics-specific evaluation prompt."""
        return f"""{ANALYTICS_VALIDATION_EVAL_PROMPT}

## SCREENSHOT:
[A screenshot of the analytics interface is provided — examine charts, tables, and data visualizations carefully]

Note: Compare every numerical claim and trend description in the bot response against what is actually visible in the screenshot. Pay special attention to whether chart patterns match the described trends."""


def create_analytics_validation_agent() -> AnalyticsValidationAgent:
    """Factory function to create an analytics validation agent."""
    return AnalyticsValidationAgent()


__all__ = ["AnalyticsValidationAgent", "create_analytics_validation_agent"]
