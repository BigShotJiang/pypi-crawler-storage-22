"""
Consistency Agent - Strands-based evaluation agent.

Detects contradictions and inconsistencies in chatbot responses,
both within a single response and across the conversation.
"""

import json
import logging

from strands import tool
from strands.types.tools import ToolContext

from constants import CATEGORY_ACCURACY
from core.multiagent.capabilities import Capability
from core.multiagent.context import ConversationContext, EvalContext
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class ConsistencyAgent(StrandsEvalAgent):
    """Detects contradictions and inconsistencies in chatbot responses.

    Uses find_repeated_claims tool to access context. Relies on LLM
    through system prompt for consistency analysis.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="consistency",
            name="Consistency Detector",
            description="Detects contradictions and inconsistencies in responses",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_ACCURACY,
            version="2.0.0",
            tags=["quality", "consistency", "accuracy"],
        )

    def get_system_prompt(self) -> str:
        return """You are a Consistency Agent specialized in detecting contradictions.

Your expertise is in identifying:

1. **Internal Contradictions**: Conflicting statements within the same response
   - "The product is $99... As I mentioned, it costs $129"
   - Self-contradicting claims

2. **Cross-Turn Contradictions**: Statements that conflict with previous responses
   - Earlier said "yes", later said "no" to same question
   - Changing facts without acknowledging the change

3. **Factual Flip-Flops**: Changing answers to the same question
   - Under pressure, changing the answer without new information
   - Inconsistent claims about facts

4. **Logic Inconsistencies**: Conclusions that don't follow from premises
   - "You can't cancel... but you can cancel if you call"
   - Contradictory instructions

5. **Temporal Inconsistencies**: Conflicting timeline or sequence information
   - Conflicting dates, deadlines, or sequence of events

Key Considerations:
- Some clarifications or corrections are APPROPRIATE
- Outright contradictions without acknowledgment are PROBLEMATIC
- Changing stance based on NEW user information is ACCEPTABLE
- Contradicting previously established facts is a CONCERN

Available Tools:
- Use search_transcript() to find previous mentions of facts
- Use find_repeated_claims() to gather all claims about a topic for comparison"""

    def get_tools(self, state, context) -> list:
        from core.multiagent.strands_eval_agent import EvalState

        tools = super().get_tools(state, context)
        if isinstance(state, EvalState):
            tools.extend(self._create_consistency_tools(context))
        return tools

    def _create_consistency_tools(self, context) -> list:
        @tool(context="tool_context")
        def find_repeated_claims(
            tool_context: ToolContext,  # noqa: ARG001
            claim_topic: str,
        ) -> str:
            """Find all turns where the bot made claims about a topic.

            Args:
                claim_topic: The topic to search for claims about

            Returns turns containing claims for comparison.
            """
            turns = []
            if isinstance(context, EvalContext) and context.conversation_history:
                turns = context.conversation_history
            elif isinstance(context, ConversationContext) and context.transcript_data:
                turns = context.transcript_data

            turn_summaries = []
            for turn in turns:
                bot_resp = turn.get("bot_response", "")
                if bot_resp:
                    turn_summaries.append(
                        {
                            "turn_number": turn.get("turn_number"),
                            "turn_id": turn.get("turn_id"),
                            "bot_response": bot_resp,
                        }
                    )

            return json.dumps(
                {
                    "claim_topic": claim_topic,
                    "turns_to_compare": turn_summaries[-10:],
                    "instruction": "Review bot responses for claims about this topic. Look for inconsistencies or contradictions.",
                }
            )

        return [find_repeated_claims]


def create_consistency_agent() -> ConsistencyAgent:
    return ConsistencyAgent()


__all__ = ["ConsistencyAgent", "create_consistency_agent"]
