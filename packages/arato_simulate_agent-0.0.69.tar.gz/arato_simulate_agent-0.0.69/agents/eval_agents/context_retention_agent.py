"""
Context Retention Agent - Strands-based evaluation agent.

Detects when chatbots lose track of conversation context, forget
earlier information, or fail to maintain coherent state.
"""

import json
import logging

from strands import tool
from strands.types.tools import ToolContext

from constants import CATEGORY_ACCURACY
from core.multiagent.capabilities import Capability
from core.multiagent.context import ConversationContext, EvalContext
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class ContextRetentionAgent(StrandsEvalAgent):
    """Detects context retention failures in chatbot conversations.

    Uses get_conversation_summary tool to access context. Relies on
    LLM through system prompt for retention analysis.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="context_retention",
            name="Context Retention Detector",
            description="Detects when chatbots lose conversation context",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_ACCURACY,
            version="2.0.0",
            tags=["quality", "context", "memory"],
        )

    def get_system_prompt(self) -> str:
        return """You are a Context Retention Agent specialized in detecting when chatbots lose context.

Your expertise is in identifying:

1. **Forgotten Information**: Ignoring facts established earlier
   - User provided their name but bot asks for it again
   - User stated a preference but bot ignores it

2. **Lost Preferences**: Forgetting user preferences or choices
   - User selected an option but bot doesn't remember
   - User set parameters that bot later ignores

3. **Repeated Questions**: Asking for information already provided
   - "What's your email?" when user already provided it
   - Requesting the same details multiple times

4. **Context Drift**: Gradually losing track of the conversation topic
   - Losing thread of what user was trying to accomplish
   - Forgetting the original question

5. **Reference Failures**: Failing to understand references to earlier content
   - Not understanding "that product" or "the one I mentioned"
   - Losing track of pronouns and references

6. **State Amnesia**: Forgetting actions or decisions made earlier
   - "I've added it to your cart" then later not knowing it's in cart
   - Forgetting completed steps in a process

Key Considerations:
- Good bots reference previous turns appropriately
- Some clarification is acceptable; repeated forgetting is NOT
- Context retention is CRITICAL for multi-turn tasks

Available Tools:
- Use get_conversation_summary() to analyze the full conversation for context issues"""

    def get_tools(self, state, context) -> list:
        from core.multiagent.strands_eval_agent import EvalState

        tools = super().get_tools(state, context)
        if isinstance(state, EvalState):
            tools.extend(self._create_context_tools(context))
        return tools

    def _create_context_tools(self, context) -> list:
        @tool(context="tool_context")
        def get_conversation_summary(tool_context: ToolContext) -> str:  # noqa: ARG001
            """Get a summary of the conversation for context retention analysis.

            Returns user messages and bot responses for analysis.
            """
            turns = []
            if isinstance(context, EvalContext) and context.conversation_history:
                turns = context.conversation_history
            elif isinstance(context, ConversationContext) and context.transcript_data:
                turns = context.transcript_data

            turn_summaries = []
            for turn in turns:
                turn_summaries.append(
                    {
                        "turn_number": turn.get("turn_number"),
                        "user_message": turn.get("user_message", ""),
                        "bot_response": (turn.get("bot_response", "") or "")[:300],
                    }
                )

            return json.dumps(
                {
                    "conversation_turns": turn_summaries,
                    "total_turns": len(turn_summaries),
                    "check_for": [
                        "Information user provided that bot later forgot",
                        "Preferences user stated that bot ignored",
                        "Bot asking for same information multiple times",
                        "Bot failing to understand references to earlier content",
                        "Context drift (losing track of original topic)",
                    ],
                    "instruction": "Analyze conversation for context retention issues. Bot should remember and use user-provided info.",
                }
            )

        return [get_conversation_summary]


def create_context_retention_agent() -> ContextRetentionAgent:
    return ContextRetentionAgent()


__all__ = ["ContextRetentionAgent", "create_context_retention_agent"]
