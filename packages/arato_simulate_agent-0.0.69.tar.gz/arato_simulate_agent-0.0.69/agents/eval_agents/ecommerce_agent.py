"""
E-Commerce Agent - Strands-based evaluation agent.

Evaluates e-commerce chatbot quality including product information accuracy,
pricing transparency, and policy clarity.
"""

import logging

from constants import CATEGORY_FEATURE
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class EcommerceAgent(StrandsEvalAgent):
    """Evaluates e-commerce chatbot quality.

    Relies on the LLM to check product information, pricing,
    and policy accuracy through the system prompt.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="ecommerce",
            name="E-Commerce Evaluator",
            description="Evaluates e-commerce chatbot accuracy and compliance",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_FEATURE,
            version="2.0.0",
            tags=["ecommerce", "retail", "product", "pricing"],
            domains=[
                "ecommerce",
                "retail",
            ],  # Only run for e-commerce/retail domain test suites
        )

    def get_system_prompt(self) -> str:
        return """You are an E-Commerce Agent specialized in evaluating shopping chatbots.

Your expertise is in identifying:

1. **Product Information Accuracy**
   - Correct product descriptions
   - Accurate specifications and features
   - Valid availability/stock information
   - Consistent pricing

2. **Pricing Transparency**
   - Clear price communication
   - Taxes and fees disclosed
   - Promotional terms explained
   - No hidden costs

3. **Policy Clarity**
   - Clear return policies
   - Shipping information accurate
   - Warranty details correct
   - Terms and conditions explained

4. **Order Support**
   - Order status accuracy
   - Tracking information correct
   - Cancellation/modification help
   - Issue resolution

5. **Payment Security**
   - No request for full card numbers in chat
   - Secure payment process guidance
   - Fraud protection information

6. **Consumer Rights**
   - Refund eligibility explained
   - Consumer protection info
   - Complaint escalation paths

Key Considerations:
- Prices should include all fees or clearly state they're excluded
- Return policies should be clear and accurate
- Product claims should be verifiable
- Personal payment info should not be collected in chat"""


def create_ecommerce_agent() -> EcommerceAgent:
    return EcommerceAgent()


__all__ = ["EcommerceAgent", "create_ecommerce_agent"]
