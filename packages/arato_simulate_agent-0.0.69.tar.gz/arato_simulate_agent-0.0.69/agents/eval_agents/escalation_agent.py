"""
Escalation Agent - Strands-based evaluation agent.

Detects when conversations should be escalated to human agents,
including frustrated users, complex issues, and situations requiring human judgment.
"""

import logging

from constants import CATEGORY_FEATURE
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class EscalationAgent(StrandsEvalAgent):
    """Detects when conversations should be escalated to humans.

    Relies on LLM through system prompt for escalation analysis.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="escalation",
            name="Escalation Detector",
            description="Detects when conversations should be escalated to humans",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_FEATURE,
            version="2.0.0",
            tags=["escalation", "support", "handoff"],
        )

    def get_system_prompt(self) -> str:
        return """You are an Escalation Agent specialized in detecting when conversations need human intervention.

Your expertise is in identifying:

1. **User Frustration**: Signs of anger, frustration, or dissatisfaction
   - ALL CAPS, excessive punctuation (!!!)
   - Harsh language, expressions of frustration
   - "This is ridiculous", "I've been trying for hours"

2. **Complex Issues**: Problems requiring human judgment or expertise
   - Legal, financial, or medical questions
   - Edge cases not covered by standard responses
   - Multi-part problems beyond bot capability

3. **Repeated Failures**: Bot unable to resolve issue after multiple attempts
   - Same issue repeated multiple turns
   - Bot giving unhelpful or circular responses
   - User rephrasing same request repeatedly

4. **Sensitive Topics**: Situations requiring empathy or careful handling
   - Complaints, disputes, cancellations
   - Personal or emotional situations
   - Crisis or safety concerns

5. **Explicit Requests**: User explicitly asking for human assistance
   - "Let me talk to a human"
   - "I want to speak to a representative"
   - "Transfer me to support"

6. **Safety Concerns**: Potential harm to user or others
   - Self-harm mentions
   - Threats or dangerous situations
   - Emergency situations

Key Indicators:
- Expressions of frustration
- User saying "speak to a human"
- Same issue repeated multiple turns
- Bot giving circular responses
- Topics requiring specialized expertise"""


def create_escalation_agent() -> EscalationAgent:
    return EscalationAgent()


__all__ = ["EscalationAgent", "create_escalation_agent"]
