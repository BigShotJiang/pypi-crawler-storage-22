"""
Escalation Agent - Strands-based evaluation agent.

Detects when conversations should be escalated to human agents,
including frustrated users, complex issues, and situations requiring human judgment.
"""

import json
import logging

from strands import tool
from strands.types.tools import ToolContext

from constants import CATEGORY_FEATURE
from core.multiagent.capabilities import Capability
from core.multiagent.context import ConversationContext, EvalContext, RunContext
from core.multiagent.strands_eval_agent import EvalState, StrandsEvalAgent

logger = logging.getLogger(__name__)


class EscalationAgentStrands(StrandsEvalAgent):
    """Detects when conversations should be escalated to humans.

    Uses Strands tools to identify user frustration, complex issues,
    repeated failures, and explicit escalation requests.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="escalation",
            name="Escalation Detector",
            description="Detects when conversations should be escalated to humans",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_FEATURE,
            version="2.0.0",
            tags=["escalation", "support", "handoff"],
        )

    def get_system_prompt(self) -> str:
        return """You are an Escalation Agent specialized in detecting when conversations need human intervention.

Your expertise is in identifying:

1. **User Frustration**: Signs of anger, frustration, or dissatisfaction
   - ALL CAPS, excessive punctuation (!!!)
   - Harsh language, expressions of frustration
   - "This is ridiculous", "I've been trying for hours"

2. **Complex Issues**: Problems requiring human judgment or expertise
   - Legal, financial, or medical questions
   - Edge cases not covered by standard responses
   - Multi-part problems beyond bot capability

3. **Repeated Failures**: Bot unable to resolve issue after multiple attempts
   - Same issue repeated multiple turns
   - Bot giving unhelpful or circular responses
   - User rephrasing same request repeatedly

4. **Sensitive Topics**: Situations requiring empathy or careful handling
   - Complaints, disputes, cancellations
   - Personal or emotional situations
   - Crisis or safety concerns

5. **Explicit Requests**: User explicitly asking for human assistance
   - "Let me talk to a human"
   - "I want to speak to a representative"
   - "Transfer me to support"

6. **Safety Concerns**: Potential harm to user or others
   - Self-harm mentions
   - Threats or dangerous situations
   - Emergency situations

Key Indicators:
- Expressions of frustration
- User saying "speak to a human"
- Same issue repeated multiple turns
- Bot giving circular responses
- Topics requiring specialized expertise"""

    def get_tools(
        self, state: EvalState, context: EvalContext | ConversationContext | RunContext
    ) -> list:
        tools = super().get_tools(state, context)
        tools.extend(self._create_escalation_tools(state, context))
        return tools

    def _create_escalation_tools(
        self,
        state: EvalState,
        context: EvalContext | ConversationContext | RunContext,
    ) -> list:
        @tool(context="tool_context")
        def detect_frustration_signals(
            tool_context: ToolContext,  # noqa: ARG001
            text: str,
        ) -> str:
            """Analyze text for frustration signals.

            Args:
                text: User message to analyze

            Returns analysis of frustration indicators.
            """
            import re

            signals = {
                "caps_words": len(re.findall(r"\b[A-Z]{3,}\b", text)),
                "exclamation_marks": text.count("!"),
                "question_marks": text.count("?"),
            }

            frustration_phrases = [
                "frustrated",
                "ridiculous",
                "waste of time",
                "useless",
                "terrible",
                "awful",
                "horrible",
                "worst",
                "hate",
                "been trying",
                "still not working",
                "already told you",
            ]
            signals["frustration_phrases"] = [
                p for p in frustration_phrases if p in text.lower()
            ]

            escalation_requests = [
                "speak to a human",
                "talk to a person",
                "real person",
                "human agent",
                "representative",
                "supervisor",
                "manager",
                "transfer me",
                "escalate",
            ]
            signals["escalation_requests"] = [
                e for e in escalation_requests if e in text.lower()
            ]

            return json.dumps(
                {
                    "signals": signals,
                    "has_frustration": signals["caps_words"] > 2
                    or signals["exclamation_marks"] > 2
                    or len(signals["frustration_phrases"]) > 0,
                    "has_escalation_request": len(signals["escalation_requests"]) > 0,
                    "instruction": "If frustration or escalation request detected, evaluate if bot responded appropriately",
                }
            )

        @tool(context="tool_context")
        def check_resolution_progress(tool_context: ToolContext) -> str:  # noqa: ARG001
            """Check if the conversation is making progress toward resolution.

            Returns analysis of resolution progress.
            """
            # Get transcript
            turns = []
            if isinstance(context, EvalContext) and context.conversation_history:
                turns = context.conversation_history
            elif isinstance(context, ConversationContext) and context.transcript_data:
                turns = context.transcript_data

            # Look for patterns suggesting lack of progress
            user_messages = [
                t.get("user_message", "") for t in turns if t.get("user_message")
            ]
            # Note: bot_responses collected for potential future use
            _ = [t.get("bot_response", "") for t in turns if t.get("bot_response")]

            # Check for similar user messages (rephrasing)
            similar_messages = 0
            for i, msg1 in enumerate(user_messages):
                for msg2 in user_messages[i + 1 :]:
                    if msg1 and msg2:
                        # Simple similarity check
                        words1 = set(msg1.lower().split())
                        words2 = set(msg2.lower().split())
                        overlap = len(words1 & words2)
                        if (
                            overlap > 5
                            and overlap / max(len(words1), len(words2)) > 0.5
                        ):
                            similar_messages += 1

            return json.dumps(
                {
                    "total_turns": len(turns),
                    "similar_user_messages": similar_messages,
                    "likely_stuck": similar_messages > 1,
                    "instruction": "If user is rephrasing same request repeatedly, bot may need to escalate",
                }
            )

        @tool(context="tool_context")
        def check_sensitive_topics(
            tool_context: ToolContext,  # noqa: ARG001
            text: str,
        ) -> str:
            """Check if conversation involves sensitive topics requiring human handling.

            Args:
                text: Text to analyze

            Returns analysis of sensitive topic indicators.
            """
            sensitive_categories = {
                "safety": [
                    "suicide",
                    "self-harm",
                    "hurt myself",
                    "end my life",
                    "kill",
                ],
                "legal": [
                    "lawsuit",
                    "attorney",
                    "lawyer",
                    "sue",
                    "legal action",
                    "court",
                ],
                "medical": [
                    "diagnosis",
                    "treatment",
                    "medication",
                    "emergency",
                    "hospital",
                ],
                "financial": ["bankruptcy", "fraud", "stolen", "unauthorized charge"],
                "complaint": ["complaint", "refund", "cancel", "dispute", "report you"],
            }

            found = {}
            text_lower = text.lower()
            for category, keywords in sensitive_categories.items():
                matches = [k for k in keywords if k in text_lower]
                if matches:
                    found[category] = matches

            return json.dumps(
                {
                    "sensitive_topics_found": found,
                    "requires_escalation": len(found) > 0,
                    "high_priority": "safety" in found,
                    "instruction": "If sensitive topics found, bot should offer human escalation. Safety topics are CRITICAL.",
                }
            )

        return [
            detect_frustration_signals,
            check_resolution_progress,
            check_sensitive_topics,
        ]


def create_escalation_agent() -> EscalationAgentStrands:
    return EscalationAgentStrands()


__all__ = ["EscalationAgentStrands", "create_escalation_agent"]
