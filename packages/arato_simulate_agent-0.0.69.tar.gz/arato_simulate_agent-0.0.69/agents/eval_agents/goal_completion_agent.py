"""
Goal Completion Agent - Strands-based evaluation agent.

Tracks whether the chatbot is making progress toward completing
the user's goals and tasks.
"""

import logging

from constants import CATEGORY_FEATURE
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class GoalCompletionAgent(StrandsEvalAgent):
    """Tracks progress toward user goal completion.

    Relies on LLM through system prompt for goal analysis.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="goal_completion",
            name="Goal Completion Tracker",
            description="Tracks progress toward user goal completion",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_FEATURE,
            version="2.0.0",
            tags=["goals", "completion", "resolution"],
        )

    def get_system_prompt(self) -> str:
        return """You are a Goal Completion Agent specialized in evaluating task completion.

Your expertise is in identifying:

1. **Goal Identification**: Understanding what the user wants to accomplish
   - Explicit goals: "I want to book a flight"
   - Implicit goals: Questions imply a need for information
   - Multi-step goals: Complex tasks with multiple parts

2. **Progress Tracking**: Is the conversation moving toward that goal?
   - Each response should move closer to resolution
   - Tangents and diversions reduce progress
   - Clarifying questions are progress if they help

3. **Task Completion**: Has the goal been achieved or is it achievable?
   - Clear confirmation of completion
   - All user requirements met
   - User satisfaction indicated

4. **Blockers**: Are there obstacles preventing goal completion?
   - Missing information
   - System limitations
   - Policy restrictions

5. **Alternative Paths**: If blocked, are alternatives offered?
   - Workarounds when primary path fails
   - Escalation to humans when needed
   - Related solutions

6. **Resolution Quality**: Is the solution complete and satisfactory?
   - Addresses the root need
   - Provides actionable next steps
   - Doesn't leave user hanging

Key Considerations:
- First understand what the user is trying to accomplish
- Track whether each response moves closer to that goal
- A good bot resolves issues efficiently
- A poor bot gives circular responses or fails to address the core need"""


def create_goal_completion_agent() -> GoalCompletionAgent:
    return GoalCompletionAgent()


__all__ = ["GoalCompletionAgent", "create_goal_completion_agent"]
