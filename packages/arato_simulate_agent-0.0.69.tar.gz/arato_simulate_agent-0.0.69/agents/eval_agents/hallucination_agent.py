"""
Hallucination Detection Agent - Strands-based evaluation agent.

This agent detects factual errors and hallucinations in chatbot responses:
1. Checks claims against ground truth data
2. Detects contradictions within responses
3. Identifies unsupported factual claims
4. Validates citations and references

Uses the StrandsEvalAgent base class for common functionality.
"""

import json
import logging

from strands import tool
from strands.types.tools import ToolContext

from constants import CATEGORY_ACCURACY
from core.multiagent.capabilities import Capability
from core.multiagent.context import EvalContext
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class HallucinationAgent(StrandsEvalAgent):
    """Detects hallucinations and factual errors in chatbot responses.

    Uses get_ground_truth to access context and check_citation_validity
    to verify sources. Relies on LLM through system prompt for
    contradiction detection.
    """

    def __init__(self) -> None:
        """Initialize the hallucination detection agent."""
        super().__init__(
            agent_id="hallucination_detector",
            name="Hallucination Detection Agent",
            description="Detects factual errors, false claims, and hallucinations in chatbot responses",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_ACCURACY,
            version="2.0.0",
            tags=["accuracy", "factual", "hallucination", "verification"],
        )

    def get_system_prompt(self) -> str:
        """Get the system prompt for hallucination detection."""
        return """You are a Hallucination Detection Agent specialized in finding factual errors.

Your expertise is in identifying:
1. **Fabricated Facts**: Claims that are completely made up with no basis in reality
2. **Contradictions**: Statements that contradict earlier messages or known facts
3. **Unsupported Claims**: Statements presented as fact without supporting evidence
4. **Citation Errors**: Incorrect references to sources, documents, or data

Domain-Specific Guidance:
- Do NOT report opinions, subjective statements, or hedged language ("might", "could", "possibly")
- Focus on verifiable factual claims that can be checked against evidence
- Use get_ground_truth() to check claims against known facts
- Use search_transcript() to check for internal contradictions
- Use check_citation_validity() to verify sources and references"""

    def get_tools(self, state, context) -> list:
        """Get hallucination-specific tools plus common tools."""
        from core.multiagent.strands_eval_agent import EvalState

        tools = super().get_tools(state, context)
        if isinstance(state, EvalState):
            tools.extend(self._create_hallucination_tools(context))
        return tools

    def _create_hallucination_tools(self, context) -> list:
        """Create hallucination-specific detection tools."""

        @tool(context="tool_context")
        def get_ground_truth(tool_context: ToolContext) -> str:  # noqa: ARG001
            """Get ground truth data if available.

            Returns ground truth facts that can be used to verify claims.
            """
            if isinstance(context, EvalContext) and context.ground_truth:
                gt = context.ground_truth
                if isinstance(gt, dict):
                    return json.dumps(gt, indent=2)
                elif isinstance(gt, str):
                    return gt
                else:
                    return str(gt)

            return json.dumps(
                {
                    "available": False,
                    "message": "No ground truth data available. Use general knowledge for verification.",
                }
            )

        @tool(context="tool_context")
        def check_citation_validity(
            tool_context: ToolContext,  # noqa: ARG001
            citation: str,
            cited_fact: str,
        ) -> str:
            """Check if a citation or reference is valid.

            Args:
                citation: The source being cited (e.g., "according to our documentation")
                cited_fact: The fact being attributed to the source

            Returns validation result.
            """
            gt_available = False
            gt_supports = False

            if isinstance(context, EvalContext) and context.ground_truth:
                gt_available = True
                gt_str = str(context.ground_truth).lower()
                if cited_fact.lower() in gt_str:
                    gt_supports = True

            return json.dumps(
                {
                    "citation": citation,
                    "cited_fact": cited_fact,
                    "ground_truth_available": gt_available,
                    "ground_truth_supports": gt_supports,
                    "instruction": "Report as finding if citation appears fabricated or fact is unsupported",
                }
            )

        return [get_ground_truth, check_citation_validity]


def create_hallucination_agent() -> HallucinationAgent:
    """Factory function to create a hallucination detection agent."""
    return HallucinationAgent()


__all__ = ["HallucinationAgent", "create_hallucination_agent"]
