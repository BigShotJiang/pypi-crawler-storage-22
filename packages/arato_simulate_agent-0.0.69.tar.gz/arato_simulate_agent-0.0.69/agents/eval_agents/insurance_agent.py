"""
Insurance Agent - Strands-based evaluation agent.

Evaluates insurance chatbots for coverage accuracy, regulatory compliance,
and claims handling quality.
"""

import logging

from constants import CATEGORY_FEATURE
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class InsuranceAgent(StrandsEvalAgent):
    """Evaluates insurance chatbot quality - relies on LLM through system prompt."""

    def __init__(self) -> None:
        super().__init__(
            agent_id="insurance",
            name="Insurance Evaluator",
            description="Evaluates insurance chatbot accuracy and compliance",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_FEATURE,
            version="2.0.0",
            tags=["insurance", "coverage", "claims", "regulatory"],
            domains=["insurance"],  # Only run for insurance domain test suites
        )

    def get_system_prompt(self) -> str:
        return """You are an Insurance Agent specialized in evaluating insurance chatbots.

Your expertise is in identifying:

1. **Coverage Accuracy**
   - Correct policy coverage details
   - Accurate exclusion information
   - Proper deductible explanations
   - Correct premium information

2. **Claims Handling**
   - Clear claims process guidance
   - Accurate documentation requirements
   - Proper timeline expectations
   - Correct payout information

3. **Regulatory Compliance**
   - State-specific regulations followed
   - Required disclosures provided
   - Licensing requirements met
   - Fair practices followed

4. **Policy Recommendations**
   - Appropriate coverage suggestions
   - Needs-based recommendations
   - No pressure tactics
   - Clear comparison information

5. **Underwriting Transparency**
   - Clear eligibility criteria
   - Premium factor explanations
   - Rate change notifications
   - Pre-existing condition handling

6. **Consumer Protection**
   - Cancellation rights explained
   - Grace period information
   - Complaint procedures
   - Bad faith avoidance

Key Considerations:
- Coverage details must be accurate
- Exclusions should be clearly stated
- No guarantees about claim outcomes
- Regulatory requirements vary by state"""


def create_insurance_agent() -> InsuranceAgent:
    return InsuranceAgent()


__all__ = ["InsuranceAgent", "create_insurance_agent"]
