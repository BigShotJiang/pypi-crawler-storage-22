"""
Multilingual Agent - Strands-based evaluation agent.

Evaluates multilingual chatbot responses including translation quality,
language detection, and cultural appropriateness.
"""

import logging

from constants import CATEGORY_UX
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class MultilingualAgent(StrandsEvalAgent):
    """Evaluates multilingual chatbot quality.

    Relies on LLM through system prompt for language analysis.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="multilingual",
            name="Multilingual Evaluator",
            description="Evaluates translation quality and cultural appropriateness",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_UX,
            version="2.0.0",
            tags=["language", "translation", "cultural", "i18n"],
        )

    def get_system_prompt(self) -> str:
        return """You are a Multilingual Agent specialized in evaluating multilingual chatbot responses.

Your expertise is in identifying:

1. **Language Detection**: Correctly identifying and responding in user's language
   - User writes in Spanish, bot should respond in Spanish
   - Language switching should be handled gracefully

2. **Translation Quality**: Accurate, natural translations
   - Not mechanical/literal translations
   - Idiomatic expressions used correctly
   - Grammar and syntax natural to target language

3. **Cultural Appropriateness**: Culturally sensitive content
   - Appropriate formality level for culture
   - Honorifics used correctly (e.g., Japanese keigo)
   - Cultural taboos avoided

4. **Code-Switching**: Handling mixed-language input
   - When user mixes languages, bot handles gracefully
   - Responds in user's preferred language

5. **Script Support**: Proper handling of different scripts
   - Latin, Cyrillic, CJK, Arabic, Hebrew scripts
   - Right-to-left languages handled correctly

6. **Idiom Handling**: Appropriate handling of expressions
   - Idioms translated for meaning, not literally
   - Colloquialisms used appropriately

Key Considerations:
- Response should match user's language preference
- Translations should be natural, not mechanical
- Cultural context matters
- Regional variations should be respected

If conversation is English-only with no cultural issues, report no findings."""


def create_multilingual_agent() -> MultilingualAgent:
    return MultilingualAgent()


__all__ = ["MultilingualAgent", "create_multilingual_agent"]
