"""
Repetition Agent - Strands-based evaluation agent.

Detects when chatbots give repetitive responses, loop in conversations,
or fail to progress.
"""

import logging

from constants import CATEGORY_UX
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class RepetitionAgent(StrandsEvalAgent):
    """Detects repetitive responses and conversation loops.

    Relies on LLM through system prompt for repetition analysis.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="repetition",
            name="Repetition Detector",
            description="Detects repetitive responses and conversation loops",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_UX,
            version="2.0.0",
            tags=["quality", "repetition", "loops"],
        )

    def get_system_prompt(self) -> str:
        return """You are a Repetition Agent specialized in detecting repetitive patterns.

Your expertise is in identifying:

1. **Verbatim Repetition**: Exact same response given multiple times
   - Copy-paste identical responses
   - Same sentence structures word-for-word

2. **Paraphrased Repetition**: Same content with slightly different wording
   - Saying the same thing in different words
   - Not adding new information

3. **Conversation Loops**: Going in circles without progress
   - Returning to the same topic repeatedly
   - Not advancing toward resolution

4. **Template Overuse**: Over-reliance on canned responses
   - Generic responses that don't address specifics
   - Same template used inappropriately

5. **Question Loops**: Asking the same questions repeatedly
   - Requesting info already provided
   - Not remembering previous answers

6. **Failure Loops**: Repeatedly failing in the same way
   - Same error or limitation repeated
   - Not offering alternatives

Key Considerations:
- Some repetition is ACCEPTABLE (confirmations, acknowledgments)
- Problematic repetition PREVENTS PROGRESS
- Users get frustrated with circular conversations
- Each response should ADD VALUE"""


def create_repetition_agent() -> RepetitionAgent:
    return RepetitionAgent()


__all__ = ["RepetitionAgent", "create_repetition_agent"]
