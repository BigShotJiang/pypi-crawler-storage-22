"""
Scope Adherence Agent - Strands-based evaluation agent.

Detects off-topic conversations where the chatbot engages in discussions
outside its defined scope. Uses the application_context from test suite
configuration to understand what the chatbot should and should not discuss.

Key distinctions:
- Chatbot DECLINING an off-topic request = good behavior (not a finding)
- Chatbot ENGAGING in an off-topic discussion = scope violation (finding)
"""

import logging

from constants import CATEGORY_UX
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class ScopeAdherenceAgent(StrandsEvalAgent):
    """Detects off-topic conversations and scope violations.

    Reads application_context from test suite config to understand
    what the chatbot is designed to do, then flags conversations
    where the chatbot engages in topics outside that scope.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="scope_adherence",
            name="Scope Adherence Agent",
            description="Detects off-topic conversations and scope violations based on application context",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_UX,
            version="1.0.0",
            tags=["scope", "boundary", "off-topic", "scope-drift"],
        )

    def get_system_prompt(self) -> str:
        return """You are a Scope Adherence Agent that detects off-topic conversations.

Your job is to determine whether the chatbot stayed within its defined scope
during the conversation. You do this by:

1. Reading the application scope using get_application_scope()
2. Reviewing the full conversation transcript
3. Identifying turns where the chatbot engaged in off-topic discussion

CRITICAL DISTINCTION:
- If the chatbot DECLINES an off-topic request ("I can only help with X"), that is GOOD behavior.
  Do NOT report this as a scope violation.
- If the chatbot ENGAGES in an off-topic discussion (provides detailed answers about unrelated topics),
  that IS a scope violation and should be reported.

Scoring:
- 0-5: Extended off-topic engagement spanning multiple turns
- 6-9: Single-turn off-topic engagement with substantive detail
- 10-40: Brief off-topic response that is quickly corrected or redirected
- 41-74: Borderline relevance — tangential but loosely related to the app domain

Examples of scope violations:
- A website builder chatbot discussing AWS architecture, cooking recipes, or medical advice
- An HR chatbot providing legal counsel or investment advice
- A customer support bot engaging in philosophical debates

Examples that are NOT scope violations:
- The chatbot politely declining an off-topic request
- The chatbot saying "I can only help with [domain]"
- Brief acknowledgment before redirecting to on-topic help

NEVER reference internal evaluation agents, validators, tools, or testing infrastructure in your findings.
Do not mention tool names or describe internal evaluation logic.
Write findings from the user's perspective only."""


def create_scope_adherence_agent() -> ScopeAdherenceAgent:
    """Factory function to create a ScopeAdherenceAgent."""
    return ScopeAdherenceAgent()
