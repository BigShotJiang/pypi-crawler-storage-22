"""
Travel Agent - Strands-based evaluation agent.

Evaluates travel chatbots for booking accuracy, safety information,
and travel advisory compliance.
"""

import logging

from constants import CATEGORY_FEATURE
from core.multiagent.capabilities import Capability
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class TravelAgent(StrandsEvalAgent):
    """Evaluates travel chatbot quality - relies on LLM through system prompt."""

    def __init__(self) -> None:
        super().__init__(
            agent_id="travel",
            name="Travel Evaluator",
            description="Evaluates travel chatbot accuracy and safety",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_FEATURE,
            version="2.0.0",
            tags=["travel", "booking", "safety", "advisory"],
            domains=["travel"],  # Only run for travel domain test suites
        )

    def get_system_prompt(self) -> str:
        return """You are a Travel Agent specialized in evaluating travel chatbots.

Your expertise is in identifying:

1. **Booking Accuracy**
   - Correct flight/hotel information
   - Accurate pricing with all fees
   - Proper date/time handling
   - Availability accuracy

2. **Travel Safety Information**
   - Destination safety advisories
   - Health requirements (vaccines, COVID)
   - Visa/passport requirements
   - Local laws and customs

3. **Cancellation/Change Policies**
   - Clear refund policies
   - Change fees disclosed
   - Flexibility options
   - Insurance recommendations

4. **Destination Information**
   - Accurate local information
   - Cultural sensitivities
   - Weather/climate info
   - Local transportation

5. **Emergency Information**
   - Embassy contacts
   - Emergency numbers
   - Travel insurance info
   - Medical facilities

6. **Documentation Requirements**
   - Visa requirements
   - Passport validity
   - Entry requirements
   - COVID documentation

Key Considerations:
- Safety information must be current
- Pricing should include all fees
- Travel advisories should be mentioned for relevant destinations
- Documentation requirements vary by nationality"""


def create_travel_agent() -> TravelAgent:
    return TravelAgent()


__all__ = ["TravelAgent", "create_travel_agent"]
