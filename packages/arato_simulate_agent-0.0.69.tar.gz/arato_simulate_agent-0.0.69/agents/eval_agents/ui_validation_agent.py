"""
UI Validation Agent using Gemini Flash for vision-based validation.

This agent specializes in validating UI elements by comparing:
1. What the user asked for
2. What the chatbot claims it did
3. What is actually visible in the screenshot

Uses Gemini Flash's vision capabilities to detect discrepancies
between requested UI changes and actual implementation.
"""

import logging

from agents.eval_agents.vision_eval_agent import VisionEvalAgent
from constants import CATEGORY_ACCURACY
from core.multiagent.capabilities import Capability
from core.multiagent.context import EvalContext
from core.multiagent.sub_agent import get_rating_scale

logger = logging.getLogger(__name__)

UI_VALIDATION_SYSTEM_PROMPT = """You are an expert UI validation agent specializing in verifying that web interfaces match user requests.

Your role is to validate that chatbots (like Wix Aria) that build UIs and websites have correctly implemented what the user asked for.

You will be provided with:
1. A screenshot of the current UI state
2. The user's request (what they asked for)
3. The chatbot's response (what it claims it did)

Your task is to:
- Analyze the screenshot to see what was actually created
- Compare the actual UI against what the user requested
- Compare the actual UI against what the chatbot claimed it did
- Identify any discrepancies or missing implementations

{rating_scale}

IMPORTANT: You are validating UI/website implementations specifically. Focus on visual elements like:
- Layout and structure
- Colors and styling
- Text content and copy
- Images and media
- Interactive elements (buttons, forms, links)
- Responsive design elements

NEVER reference internal evaluation agents, validators, tools, or testing infrastructure in your findings.
Do not mention tool names like 'get_allowed_disclosures', 'check_cross_user_data', 'search_transcript', etc.
Do not mention "validation agent", "evaluator", "sub-agent", or similar internal terms.
Do not describe conflicts between internal tools or evaluation logic.
Write findings as if you are an independent quality reviewer describing issues from the user's perspective.
""".format(
    rating_scale=get_rating_scale(
        critical_desc="major discrepancies between requested and implemented UI",
        warning_desc="minor inconsistencies or partially implemented features",
        good_desc="UI matches user request and chatbot claims",
    )
)

UI_VALIDATION_EVAL_PROMPT = """Evaluate whether the UI visible in the screenshot matches what the user requested and what the chatbot claimed to have implemented.

## EVALUATION CRITERIA:

### 1. User Request Fulfillment
- Does the screenshot show the UI elements the user asked for?
- Are all requested features visible and implemented?
- Is the overall intent of the user's request fulfilled?

### 2. Chatbot Claims Accuracy
- Did the chatbot accurately describe what it implemented?
- Does the screenshot match what the chatbot said it would do?
- Are there any false claims in the chatbot's response?

### 3. Visual Quality
- Is the UI implementation well-executed?
- Does it match design expectations (if specified)?
- Are there obvious visual bugs or issues?

Set "detected" to true if ANY discrepancy is found between:
- User request and actual UI
- Chatbot claims and actual UI
- Expected design/functionality and actual implementation

Only generate findings for significant issues. Do not flag trivial styling differences unless they impact functionality."""


class UIValidationAgent(VisionEvalAgent):
    """Agent specialized in validating UI implementations using vision.

    Uses Gemini Flash with vision to compare screenshots against
    user requests and chatbot claims. Designed for chatbots that build
    UIs like Wix Aria.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="ui_validation",
            name="UI Validation Agent",
            description="Validates UI implementations against user requests using vision-based analysis",
            capabilities={Capability.EVALUATE_TURN},
            category=CATEGORY_ACCURACY,
            version="2.0.0",
            tags=["ui", "validation", "vision", "gemini", "wix"],
            domains=[
                "website-builder",
                "ui-builder",
                "wix",
                "ui_validation",
            ],
            finding_title="UI Implementation Validation",
            finding_what_was_tested="Visual validation of UI implementation against user request and chatbot claims",
        )
        self._system_prompt = UI_VALIDATION_SYSTEM_PROMPT

    def get_system_prompt(self) -> str:
        """Return the system prompt for UI validation."""
        return UI_VALIDATION_SYSTEM_PROMPT

    async def _should_evaluate(self, context: EvalContext) -> bool:
        """Check if the chatbot claims to have taken a UI action.

        Lightweight text-only LLM call to avoid expensive image calls
        when the bot just answered a question.
        """
        return await self._text_only_llm_check(
            system_message="You are a classifier that determines if a chatbot response claims to have taken a UI action.",
            prompt=f"""Analyze this chatbot response and determine if it claims to have taken any UI/visual action.

USER MESSAGE:
{context.user_message}

BOT RESPONSE:
{context.bot_response}

Does the chatbot claim to have:
- Created, added, or modified any UI elements (buttons, forms, sections, images, etc.)
- Changed colors, fonts, layouts, or styling
- Built, updated, or published any page or website content
- Made any visual or structural changes to the interface

Respond with ONLY a JSON object:
{{
  "should_evaluate": <true if the bot claims any UI/visual action, false if it just answered a question or provided information>,
  "reason": "<brief reason for your decision>"
}}""",
            result_key="should_evaluate",
        )

    def _build_eval_prompt(self, context: EvalContext) -> str:
        """Build UI-specific evaluation prompt."""
        return f"""{UI_VALIDATION_EVAL_PROMPT}

## SCREENSHOT:
[A screenshot of the current UI state is provided for analysis]

Note: Analyze the visual elements in the screenshot carefully to determine if they match the user's request and the chatbot's claims."""


def create_ui_validation_agent() -> UIValidationAgent:
    """Factory function to create a UI validation agent."""
    return UIValidationAgent()


__all__ = ["UIValidationAgent", "create_ui_validation_agent"]
