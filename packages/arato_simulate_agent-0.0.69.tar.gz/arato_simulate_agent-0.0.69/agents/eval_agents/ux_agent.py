"""
UX Agent - Strands-based evaluation agent.

This agent evaluates user experience quality in chatbot responses:
1. Response clarity and coherence
2. Tone and professionalism
3. Helpfulness and completeness
4. User satisfaction indicators

Uses the StrandsEvalAgent base class for common functionality.
"""

import json
import logging

from strands import tool
from strands.types.tools import ToolContext

from constants import CATEGORY_UX
from core.multiagent.capabilities import Capability
from core.multiagent.context import EvalContext
from core.multiagent.strands_eval_agent import StrandsEvalAgent

logger = logging.getLogger(__name__)


class UXAgent(StrandsEvalAgent):
    """Evaluates user experience quality in chatbot responses.

    Relies on LLM through system prompt for UX evaluation.
    Uses check_tone_consistency tool to access conversation history.
    """

    def __init__(self) -> None:
        """Initialize the UX agent."""
        super().__init__(
            agent_id="ux_evaluator",
            name="UX Agent",
            description="Evaluates response clarity, tone, helpfulness, and overall user experience",
            capabilities={Capability.SUMMARIZE_CONVERSATION},
            category=CATEGORY_UX,
            version="2.0.0",
            tags=["ux", "clarity", "tone", "helpfulness", "user_experience"],
        )

    def get_system_prompt(self) -> str:
        """Get the system prompt for UX evaluation."""
        return """You are a UX Evaluation Agent specialized in assessing user experience quality.

Your expertise is in identifying:
1. **Clarity Issues**: Confusing, ambiguous, or poorly structured responses
   - Unclear instructions or explanations
   - Overly technical jargon without context
   - Contradictory statements within response

2. **Tone Problems**: Inappropriate tone or unprofessional language
   - Overly casual or robotic tone
   - Condescending or dismissive language
   - Inconsistent tone across conversation

3. **Helpfulness**: Responses that don't adequately address user needs
   - Incomplete answers
   - Missing relevant information
   - Failure to provide actionable guidance

4. **UX Anti-patterns**: Common UX mistakes
   - Overly long responses (walls of text)
   - Lack of structure (no formatting, lists, sections)
   - Poor error handling or unhelpful error messages

Domain-Specific Guidance:
- Consider the context and domain when evaluating tone (technical vs. casual)
- Focus on issues that genuinely impact user experience, not minor style preferences
- Look for patterns of poor UX across multiple turns
- Evaluate whether the bot's response matches user expectations

Available Tools:
- Use check_tone_consistency() to compare current response tone with previous responses"""

    def get_tools(self, state, context) -> list:
        """Get UX-specific tools plus common tools."""
        from core.multiagent.strands_eval_agent import EvalState

        tools = super().get_tools(state, context)
        if isinstance(state, EvalState):
            tools.extend(self._create_ux_tools(context))
        return tools

    def _create_ux_tools(self, context) -> list:
        """Create UX-specific evaluation tools."""

        @tool(context="tool_context")
        def check_tone_consistency(
            tool_context: ToolContext,  # noqa: ARG001
            current_response: str,
        ) -> str:
            """Check if bot's tone is consistent with conversation history.

            Args:
                current_response: Current bot response

            Returns analysis of tone consistency.
            """
            previous_responses = []
            if isinstance(context, EvalContext) and context.conversation_history:
                for turn in context.conversation_history[-3:]:
                    bot_resp = turn.get("bot_response", "")
                    if bot_resp:
                        previous_responses.append(bot_resp[:100])

            return json.dumps(
                {
                    "current_response": current_response[:200],
                    "previous_responses": previous_responses,
                    "instruction": "Compare current tone with previous responses. Report inconsistencies (sudden formality/informality changes).",
                }
            )

        return [check_tone_consistency]


def create_ux_agent() -> UXAgent:
    """Factory function to create a UX agent.

    Returns:
        Configured UXAgent instance
    """
    return UXAgent()


__all__ = [
    "UXAgent",
    "create_ux_agent",
]
