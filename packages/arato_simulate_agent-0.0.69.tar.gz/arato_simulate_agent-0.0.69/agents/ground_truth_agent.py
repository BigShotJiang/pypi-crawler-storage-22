#!/usr/bin/env python3
"""
Ground Truth Agent: Collects organizational ground truth data before chat testing.

This agent runs BEFORE any chat runners to collect real data from the application
that can be used to validate chatbot responses. The collected data is cached and
shared across all chat runner instances.

Ground truth data is cached at the domain level (like app_context) so it can be
reused across multiple sessions without re-collection.
"""

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Any

from browser_use import Agent, Controller, Tools

from constants import CAPTCHA_SOLVER_ENABLED, DOMAIN_SETTINGS_DIR, GROUND_TRUTH_FILENAME
from core.browser import create_browser, setup_browser_kwargs
from core.llm import create_chat_model
from core.storage import download_ground_truth_cache, upload_ground_truth_cache
from tools.auto_login import auto_login_tool
from tools.auto_otp import auto_otp_tool
from tools.captcha_solver import solve_captcha_tool
from tools.hitl_intervention import request_human_intervention, set_browser_context
from utils.config_loader import GroundTruthAgentConfig, load_ground_truth_agent
from utils.otp_manager import domain_has_otp
from utils.url_utils import extract_domain_pattern, get_domain_from_url

logger = logging.getLogger(__name__)


class GroundTruthAgent:
    """Agent that collects ground truth data from applications before chat testing."""

    def __init__(
        self,
        headless: bool = False,
    ):
        """
        Initialize the ground truth agent.

        Args:
          headless: Run browser in headless mode
        """
        self.headless = headless
        self.llm = create_chat_model()

    async def collect_ground_truth(
        self,
        agent_id: str,
        session_dir: str,
        target_url: str | None = None,
        storage_state: str | None = None,
        org_id: str | None = None,
        force_collection: bool = False,
    ) -> dict[str, Any]:
        """
        Collect ground truth data from the application.

        Ground truth data is cached at the domain level and reused across sessions
        unless force_collection is True.

        Args:
          agent_id: ID of the ground truth agent config to use (e.g., 'hibob')
          session_dir: Directory to store session artifacts
          target_url: Optional override for target URL (uses config if not provided)
          storage_state: Optional path to JSON file with saved authentication state
          org_id: Optional organization ID for multi-tenant storage
          force_collection: If True, ignore cached data and re-collect

        Returns:
          Dictionary with collected ground truth data
        """
        # Load agent configuration
        try:
            config = load_ground_truth_agent(agent_id)
        except FileNotFoundError as e:
            logger.error(f"Ground truth agent config not found: {e}")
            return {"success": False, "error": str(e), "data": {}}

        logger.info(f"🔍 Starting ground truth collection: {config.name}")
        logger.info(f"   Description: {config.description}")
        logger.info(f"   Timeout: {config.timeout}s, Max Steps: {config.max_steps}")

        # Determine target URL
        effective_url = target_url or (
            config.target_urls[0] if config.target_urls else None
        )
        if not effective_url:
            logger.error("No target URL specified in config or parameters")
            return {"success": False, "error": "No target URL", "data": {}}

        # Get domain for caching
        domain = get_domain_from_url(effective_url)

        # Check for cached ground truth (unless force_collection)
        if not force_collection:
            logger.info(f"[GROUND TRUTH] Checking for cached data for domain: {domain}")
            cached_content = download_ground_truth_cache(domain, org_id=org_id)
            if cached_content:
                try:
                    cached_data = json.loads(cached_content)
                    entries = len(cached_data.get("ground_truth", []))
                    logger.info(f"✓ Using cached ground truth ({entries} entries)")

                    # Copy cached data to session directory for consistency
                    session_path = Path(session_dir)
                    gt_cache_dir = session_path / ".ground_truth_cache"
                    gt_cache_dir.mkdir(parents=True, exist_ok=True)
                    gt_file = gt_cache_dir / f"{agent_id}.json"
                    gt_file.write_text(cached_content)
                    logger.info(f"  ✓ Copied cached ground truth to session: {gt_file}")

                    return {
                        "success": True,
                        "cached": True,
                        "entries_collected": entries,
                        "data": cached_data.get("ground_truth", []),
                        "agent_id": agent_id,
                        "domain": domain,
                    }
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse cached ground truth: {e}")
                    # Continue to collect fresh data
        else:
            logger.info("[GROUND TRUTH] Force collection enabled - ignoring cache")

        # Setup browser
        browser_kwargs = setup_browser_kwargs(
            headless=self.headless,
            disable_security=False,
        )

        # Restrict browser to target domain
        allowed_domains = extract_domain_pattern(effective_url)
        browser_kwargs["allowed_domains"] = allowed_domains
        logger.info(f"Browser restricted to domains: {', '.join(allowed_domains)}")

        # Setup video recording
        session_path = Path(session_dir)
        video_dir = session_path / "ground_truth_video"
        video_dir.mkdir(parents=True, exist_ok=True)
        browser_kwargs["record_video_dir"] = str(video_dir)

        # Load storage state if provided
        if storage_state:
            storage_path = Path(storage_state)
            if storage_path.exists():
                browser_kwargs["storage_state"] = str(storage_path)
                logger.info(f"Loading authentication from: {storage_state}")
            else:
                logger.warning(f"Storage state file not found: {storage_state}")

        # Collected ground truth data
        ground_truth_data: list[dict[str, Any]] = []

        async with create_browser(**browser_kwargs) as browser:
            controller: Controller[Any] = Controller()
            tools: Tools[Any] = Tools(exclude_actions=["search"])

            # Create save_ground_truth tool
            @tools.action(
                description="Save ground truth data that you have extracted from the page. "
                "CRITICAL: The 'data_json' parameter MUST be a JSON STRING containing the actual data you extracted. "
                "Do NOT pass an empty string or '{}'. You must include the real information you see on screen. "
                'Example: data_json=\'{"employees": [{"name": "John Smith", "title": "Engineer"}], "total": 42}\''
            )
            async def save_ground_truth(
                source: str, data_type: str, data_json: str
            ) -> str:
                """
                Save ground truth data to the cache.

                Args:
                  source: Where the data came from (e.g., "hibob_people_page", "hibob_org_chart")
                  data_type: Type of data (e.g., "employee_directory", "department_summary")
                  data_json: A JSON STRING with the extracted data. Must contain actual data, not empty!

                Returns:
                  Confirmation message
                """
                logger.info(f"📋 Saving ground truth: {source}/{data_type}")
                logger.info(
                    f"📋 Data received (type={type(data_json).__name__}): {data_json}"
                )

                # Validate we received a string
                if not isinstance(data_json, str):
                    logger.warning(
                        f"⚠️ save_ground_truth received non-string data: {type(data_json)}"
                    )
                    data_json = json.dumps(data_json) if data_json else "{}"

                # Parse JSON string
                try:
                    parsed_data = json.loads(data_json)
                except json.JSONDecodeError as e:
                    logger.warning(f"⚠️ Invalid JSON: {e}")
                    return (
                        f"❌ FAILED: Invalid JSON format: {e}\n\n"
                        "The data_json parameter must be a valid JSON string.\n"
                        'Example: \'{"employees": [{"name": "John", "title": "Engineer"}]}\''
                    )

                # Reject if data is empty
                if not parsed_data or parsed_data == {}:
                    logger.warning("⚠️ save_ground_truth called with empty data!")
                    return (
                        "❌ FAILED: You called save_ground_truth with EMPTY data!\n\n"
                        "The 'data' parameter MUST contain the actual information you extracted from the page.\n"
                        "You need to:\n"
                        "1. First, look at the page and extract the information (names, titles, departments, etc.)\n"
                        "2. Then, organize that information into a structured format\n"
                        "3. Finally, call save_ground_truth with the structured data\n\n"
                        "Example of CORRECT usage:\n"
                        "save_ground_truth(\n"
                        "  source='hibob_people_page',\n"
                        "  data_type='employee_directory',\n"
                        "  data={\n"
                        "    'total_employees': 42,\n"
                        "    'employees': [\n"
                        "      {'name': 'John Smith', 'title': 'Senior Engineer', 'department': 'Engineering'},\n"
                        "      {'name': 'Jane Doe', 'title': 'Product Manager', 'department': 'Product'}\n"
                        "    ]\n"
                        "  }\n"
                        ")\n\n"
                        "DO NOT call this tool again until you have actual data to save!"
                    )

                # Create entry
                entry = {
                    "source": source,
                    "data_type": data_type,
                    "data": parsed_data,
                }
                ground_truth_data.append(entry)

                # Save to domain-level cache immediately for persistence across sessions
                try:
                    cache_content = json.dumps(
                        {
                            "version": "1.0",
                            "agent_id": agent_id,
                            "domain": domain,
                            "cached_at": time.strftime(
                                "%Y-%m-%dT%H:%M:%SZ", time.gmtime()
                            ),
                            "entry_count": len(ground_truth_data),
                            "ground_truth": ground_truth_data,
                        },
                        indent=2,
                    )
                    upload_success = upload_ground_truth_cache(
                        domain, cache_content, org_id=org_id
                    )
                    if upload_success:
                        logger.info(
                            f"✅ Ground truth saved to domain cache: {source}/{data_type}"
                        )
                        return f"✅ Ground truth saved successfully!\nSource: {source}\nType: {data_type}\nEntries in cache: {len(ground_truth_data)}\nCache location: domain_settings/{domain}/{GROUND_TRUTH_FILENAME}"
                    else:
                        logger.warning(
                            "⚠️ Failed to upload ground truth to domain cache"
                        )
                        return "⚠️ Data collected but domain cache upload failed"
                except Exception as e:
                    logger.error(f"Failed to save ground truth cache: {e}")
                    return f"⚠️ Data collected but cache save failed: {e}"

            # Create human intervention tool
            @tools.action(
                description="Request human intervention for CAPTCHAs, login forms, or other blockers"
            )
            async def request_human_help(
                reason: str, intervention_type: str = "custom"
            ) -> str:
                """Request human intervention when encountering blockers."""
                logger.info(f"🤚 Agent requesting human intervention: {reason}")

                try:
                    result = await request_human_intervention(
                        reason=reason,
                        intervention_type=intervention_type,
                    )

                    if result["success"]:
                        return "✅ Human completed the intervention. You can continue."
                    else:
                        return f"❌ Intervention failed: {result.get('message', 'Unknown error')}. Try to continue anyway."
                except Exception as e:
                    logger.exception(f"Error during human intervention: {e}")
                    return f"❌ Error: {e}. Try to continue anyway."

            # Create auto_login tool
            @tools.action(
                description="Attempt automatic login using stored credentials for the domain"
            )
            async def auto_login(_dummy: str | None = None) -> str:
                """
                Attempt automatic login using stored credentials.

                Use this when you encounter a login page or authentication form.
                This tool will:
                1. Check if credentials exist for the current domain in auth_states/.passwords
                2. Automatically fill username and password fields
                3. Submit the login form
                4. Return success/failure status

                Only call request_human_help if this fails or if no credentials are available.
                """
                logger.info("🔐 Agent attempting auto-login for domain")

                try:
                    # Get current URL using CDP (browser-use uses CDP, not Playwright)
                    current_url: str = await browser.get_current_page_url()
                    if not current_url or current_url == "about:blank":
                        current_url = effective_url  # Fallback to config URL

                    result = await auto_login_tool(
                        browser=browser,
                        target_url=current_url,
                    )

                    if result["success"]:
                        logger.info("✅ Auto-login completed")
                        return f"✅ AUTO-LOGIN SUCCEEDED! {result['message']}\n\n🎯 IMPORTANT: Do NOT call request_human_help. Proceed with your main task now."
                    elif not result["credentials_found"]:
                        logger.info("ℹ️  No credentials found")
                        return "❌ AUTO-LOGIN FAILED: No stored credentials found for this domain.\n\n→ You MUST call request_human_help('Need login credentials', 'login') now."
                    elif not result["login_attempted"]:
                        logger.info("⚠️  Login not attempted")
                        return f"❌ AUTO-LOGIN FAILED: Could not attempt login - {result['message']}\n\n→ You MUST call request_human_help('Login form not found', 'login') now."
                    else:
                        # Login attempted but needs additional steps - try OTP automatically
                        domain = get_domain_from_url(current_url)
                        if domain_has_otp(domain):
                            logger.info(
                                "🔄 Login needs additional steps, automatically trying OTP..."
                            )
                            await asyncio.sleep(1.5)

                            otp_result = await auto_otp_tool(
                                browser=browser,
                                target_url=current_url,
                            )

                            if otp_result["success"]:
                                logger.info("✅ Auto-login+OTP completed")
                                return f"✅ AUTO-LOGIN+OTP SUCCEEDED! {otp_result['message']}\n\n🎯 IMPORTANT: Do NOT call request_human_help. Proceed with your main task now."
                            else:
                                logger.info("⚠️  Auto-login+OTP failed")
                                return f"❌ AUTO-LOGIN PARTIAL: Login submitted but OTP failed - {otp_result['message']}\n\n→ You MUST call request_human_help('OTP verification needed', 'verification') now."
                        else:
                            logger.info("❌ Auto-login failed")
                            return f"❌ AUTO-LOGIN FAILED: {result['message']}\n\n→ You MUST call request_human_help('Login failed', 'login') now."

                except Exception as e:
                    logger.exception(f"Error during auto-login: {e}")
                    return f"❌ AUTO-LOGIN ERROR: {e}\n\n→ You MUST call request_human_help('Auto-login error', 'login') now."

            # Create auto_otp tool
            @tools.action(
                description="Attempt automatic OTP/2FA entry using stored codes for the domain"
            )
            async def auto_otp(_dummy: str | None = None) -> str:
                """
                Attempt automatic OTP/2FA entry using stored codes.

                Use this when you encounter an OTP verification screen after login.
                This tool will:
                1. Check if an OTP code exists for the current domain in auth_states/.otp_codes
                2. Automatically fill the OTP input field(s)
                3. Submit the verification form
                4. Return success/failure status

                Only call request_human_help if this fails or if no OTP code is available.
                """
                logger.info("🔑 Agent attempting auto-OTP for domain")

                try:
                    # Get current URL using CDP (browser-use uses CDP, not Playwright)
                    current_url: str = await browser.get_current_page_url()
                    if not current_url or current_url == "about:blank":
                        current_url = effective_url  # Fallback to config URL

                    result = await auto_otp_tool(
                        browser=browser,
                        target_url=current_url,
                    )

                    if result["success"]:
                        logger.info("✅ Auto-OTP completed")
                        return f"✅ AUTO-OTP SUCCEEDED! {result['message']}\n\n🎯 IMPORTANT: Do NOT call request_human_help. Proceed with your main task now."
                    elif not result["otp_found"]:
                        logger.info("ℹ️  No OTP code found")
                        return "❌ AUTO-OTP FAILED: No stored OTP code found.\n\n→ You MUST call request_human_help('OTP code needed', 'verification') now."
                    elif not result["otp_attempted"]:
                        logger.info("⚠️  OTP not attempted")
                        return f"❌ AUTO-OTP FAILED: Could not attempt OTP - {result['message']}\n\n→ You MUST call request_human_help('OTP form not found', 'verification') now."
                    else:
                        logger.info("❌ Auto-OTP failed")
                        return f"❌ AUTO-OTP FAILED: {result['message']}\n\n→ You MUST call request_human_help('OTP verification failed', 'verification') now."

                except Exception as e:
                    logger.exception(f"Error during auto-OTP: {e}")
                    return f"❌ AUTO-OTP ERROR: {e}\n\n→ You MUST call request_human_help('Auto-OTP error', 'verification') now."

            # Create solve_captcha tool
            @tools.action(
                description="Attempt to automatically solve CAPTCHAs on the page using AI-powered solving"
            )
            async def solve_captcha(_dummy: str | None = None) -> str:
                """
                Attempt to automatically solve CAPTCHA challenges on the page.

                Use this when you encounter a CAPTCHA (hCaptcha or reCAPTCHA).
                This tool will:
                1. Detect the CAPTCHA type
                2. Send the challenge to an AI solving service
                3. Click the correct grid cells
                4. Submit the solution

                Only call request_human_help if this fails.
                """
                if not CAPTCHA_SOLVER_ENABLED:
                    return (
                        "ℹ️  Automatic CAPTCHA solving is disabled.\n"
                        "Please use request_human_help() to request manual CAPTCHA solving."
                    )

                logger.info("🔐 Agent attempting automatic CAPTCHA solve")

                try:
                    result = await solve_captcha_tool(
                        browser=browser,
                    )

                    if result["success"]:
                        logger.info("✅ CAPTCHA solved")
                        return (
                            f"✅ CAPTCHA SOLVED! {result['message']}\n"
                            f"CAPTCHA type: {result.get('captcha_type', 'unknown')}\n\n"
                            f"🎯 IMPORTANT: Do NOT call request_human_help. Proceed with your main task now."
                        )
                    elif not result["captcha_detected"]:
                        logger.info("ℹ️  No CAPTCHA found")
                        return (
                            "ℹ️ No CAPTCHA found on page. Proceed with your main task."
                        )
                    elif not result["solve_attempted"]:
                        logger.info("⚠️  CAPTCHA solve not attempted")
                        return f"❌ CAPTCHA SOLVE FAILED: {result['message']}\n\n→ You MUST call request_human_help('CAPTCHA needs solving', 'captcha') now."
                    else:
                        logger.info("❌ CAPTCHA solve failed")
                        return f"❌ CAPTCHA SOLVE FAILED: {result['message']}\n\n→ You MUST call request_human_help('Automatic CAPTCHA solving failed', 'captcha') now."

                except Exception as e:
                    logger.exception(f"Error during CAPTCHA solving: {e}")
                    return f"❌ CAPTCHA ERROR: {e}\n\n→ You MUST call request_human_help('CAPTCHA solving error', 'captcha') now."

            # Build task from config
            task = self._build_task(config, effective_url)

            # Set browser context for HITL
            set_browser_context(browser)

            # Create and run agent
            agent: Agent[Any, Any] = Agent(
                task=task,
                llm=self.llm,
                browser=browser,
                controller=controller,
                tools=tools,
                agent_directory=session_dir,
                use_vision=True,
                use_thinking=False,
                calculate_cost=True,
            )

            # Configure screenshot size
            agent.browser_session.llm_screenshot_size = (1000, 600)
            logger.info("🖼️  Configured LLM screenshot size: 1000x600")

            # Track timeout
            start_time = time.time()
            should_stop = False

            async def check_timeout(agent: Agent[Any, Any]) -> None:
                """Check if we've exceeded timeout and signal agent to stop."""
                nonlocal should_stop
                elapsed = time.time() - start_time

                if elapsed >= config.timeout and not should_stop:
                    should_stop = True
                    logger.warning(
                        f"⏱️  Ground truth agent reached {config.timeout}s timeout"
                    )
                    agent.stop()

            # Run agent
            logger.info(
                f"Running ground truth collection (max {config.max_steps} steps)..."
            )
            try:
                async with asyncio.timeout(config.timeout * 2):
                    history = await agent.run(
                        max_steps=config.max_steps, on_step_end=check_timeout
                    )

                if should_stop:
                    logger.info(
                        "✓ Agent stopped due to timeout, partial results preserved"
                    )

                if history.usage:
                    logger.info(f"💰 Token usage: {history.usage}")

            except TimeoutError:
                logger.error("Ground truth collection hard timeout exceeded")

        # Return results
        success = len(ground_truth_data) > 0
        result = {
            "success": success,
            "cached": False,
            "agent_id": agent_id,
            "domain": domain,
            "entries_collected": len(ground_truth_data),
            "data": ground_truth_data,
            "cache_path": str(
                Path(DOMAIN_SETTINGS_DIR) / domain / GROUND_TRUTH_FILENAME
            ),
        }

        if success:
            logger.info(
                f"✅ Ground truth collection complete: {len(ground_truth_data)} entries"
            )

            # Upload to domain-level cache for reuse across sessions
            try:
                cache_content = json.dumps(
                    {
                        "version": "1.0",
                        "agent_id": agent_id,
                        "domain": domain,
                        "cached_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        "entry_count": len(ground_truth_data),
                        "ground_truth": ground_truth_data,
                    },
                    indent=2,
                )
                upload_success = upload_ground_truth_cache(
                    domain, cache_content, org_id=org_id
                )
                if upload_success:
                    logger.info(
                        f"✓ Ground truth uploaded to domain cache: {domain}/{GROUND_TRUTH_FILENAME}"
                    )
                else:
                    logger.warning("⚠️ Failed to upload ground truth to domain cache")
            except Exception as e:
                logger.warning(f"⚠️ Error uploading ground truth to domain cache: {e}")
        else:
            logger.warning("⚠️ No ground truth data was collected")
            result["error"] = "No data collected"

        return result

    def _build_task(self, config: GroundTruthAgentConfig, target_url: str) -> str:
        """Build the task instructions from config."""
        # Use task_instructions from config if provided
        if config.task_instructions:
            return config.task_instructions

        # Otherwise build from data_collection items
        lines = [
            f"# {config.name}",
            "",
            config.description,
            "",
            "## Authentication Tools Available",
            "",
            "If you encounter a login page, OTP verification, or CAPTCHA, you have these tools:",
            "",
            "1. **auto_login()** - Attempts automatic login using stored credentials. Call this FIRST",
            "   when you see a login form. It will automatically try OTP if needed.",
            "",
            "2. **auto_otp()** - Attempts automatic OTP/2FA entry. Usually called automatically by",
            "   auto_login, but you can call it separately if needed.",
            "",
            "3. **solve_captcha()** - Attempts to automatically solve CAPTCHA challenges.",
            "",
            "4. **request_human_help(reason, intervention_type)** - ONLY call this if the tools above",
            '   explicitly FAIL. Types: "login", "captcha", "verification", "custom"',
            "",
            "**CRITICAL Authentication Rules:**",
            '- If auto_login returns "SUCCEEDED" → DO NOT call request_human_help, proceed with task',
            '- If auto_login returns "FAILED" → THEN call request_human_help',
            "- Read the tool response carefully before deciding next action",
            "",
            "## Starting URL",
            f"Navigate to: {target_url}",
            "",
            "## Data to Collect",
            "",
        ]

        for i, item in enumerate(config.data_collection, 1):
            lines.append(f"### {i}. {item.get('id', 'Unknown')}")
            lines.append(f"**Source**: {item.get('source', 'unknown')}")
            if item.get("url"):
                lines.append(f"**URL**: {item['url']}")
            lines.append(f"**Description**: {item.get('description', '')}")
            lines.append("")
            if item.get("instructions"):
                lines.append("**Instructions**:")
                lines.append(item["instructions"])
                lines.append("")

        lines.extend(
            [
                "## IMPORTANT",
                "",
                "**You MUST call the `save_ground_truth` tool for each piece of data you collect!**",
                "",
                "The data is not automatically saved. Call save_ground_truth with:",
                '- source: Where the data came from (e.g., "hibob_people_page")',
                '- data_type: Type of data (e.g., "employee_directory")',
                "- data: A JSON object with the extracted data",
                "",
                "## Success Criteria",
                "",
                "You have succeeded when you have called save_ground_truth at least once with organizational data.",
            ]
        )

        return "\n".join(lines)
