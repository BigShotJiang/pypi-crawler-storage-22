"""
Planning Agent - Orchestrates pipeline execution with autonomous decision-making.

The PlanningAgent is a Strands-based agent that coordinates the entire test pipeline:
1. Connectivity verification
2. App context discovery
3. Ground truth collection
4. Persona execution scheduling
5. Cross-conversation analysis
6. Report generation
7. Artifact upload

It uses tools to observe state, make decisions, and delegate work to other components.
"""

import logging
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from strands import Agent, tool
from strands.types.tools import ToolContext

from core.llm import get_llm_adapter

logger = logging.getLogger(__name__)


class ExecutionPhase(StrEnum):
    """Phases of pipeline execution."""

    INITIALIZING = "initializing"
    CONNECTIVITY_CHECK = "connectivity_check"
    APP_DISCOVERY = "app_discovery"
    GROUND_TRUTH = "ground_truth"
    PERSONA_EXECUTION = "persona_execution"
    CROSS_ANALYSIS = "cross_analysis"
    REPORT_GENERATION = "report_generation"
    ARTIFACT_UPLOAD = "artifact_upload"
    COMPLETE = "complete"
    FAILED = "failed"


@dataclass
class PersonaTask:
    """Represents a persona execution task."""

    persona_id: str
    instance_name: str
    status: str = "pending"  # pending, running, completed, failed
    error: str | None = None
    result_path: str | None = None


@dataclass
class PlanningState:
    """State maintained by the planning agent."""

    target_url: str
    session_id: str
    goal: str = "chat"
    phase: ExecutionPhase = ExecutionPhase.INITIALIZING

    # Discovery results
    app_context_cached: bool = False
    app_context: str | None = None
    ground_truth: dict | None = None

    # Persona management
    persona_tasks: list[PersonaTask] = field(default_factory=list)
    max_parallel: int = 3
    completed_count: int = 0
    failed_count: int = 0

    # Results
    findings: list[dict] = field(default_factory=list)
    report_path: str | None = None
    error: str | None = None


class PlanningAgent:
    """Orchestrates pipeline execution using LLM-driven planning.

    The PlanningAgent uses Strands tools to:
    - Monitor execution state
    - Make decisions about what to do next
    - Handle failures gracefully
    - Coordinate parallel execution
    - Generate comprehensive reports

    This enables autonomous operation with intelligent error recovery
    and adaptive execution strategies.
    """

    def __init__(
        self,
        orchestrator: Any,  # AutonomousChatOrchestrator
    ) -> None:
        """Initialize the planning agent.

        Args:
            orchestrator: The chat orchestrator that executes actual work
        """
        self._orchestrator = orchestrator

    def _get_system_prompt(self) -> str:
        """Get the system prompt for the planning agent."""
        return """You are the Planning Agent for a chat interface testing system.

Your role is to orchestrate the execution of test pipelines:
1. Verify target connectivity
2. Discover app context (or use cache)
3. Collect ground truth if needed
4. Schedule and monitor persona executions
5. Run cross-conversation analysis
6. Generate reports
7. Upload artifacts

Use the tools provided to check status, run phases, and make decisions.
Be adaptive - if something fails, try alternative approaches.
Always ensure proper cleanup and reporting."""

    def _create_tools(self, state: PlanningState) -> list:
        """Create planning tools with state closure."""
        orchestrator = self._orchestrator

        @tool(context="tool_context")
        def get_execution_status(tool_context: ToolContext) -> str:
            """Get current pipeline execution status.

            Returns comprehensive status including:
            - Current phase
            - Completed phases
            - Persona progress
            - Any errors
            """
            import json

            completed = sum(1 for t in state.persona_tasks if t.status == "completed")
            failed = sum(1 for t in state.persona_tasks if t.status == "failed")
            running = sum(1 for t in state.persona_tasks if t.status == "running")
            pending = sum(1 for t in state.persona_tasks if t.status == "pending")

            return json.dumps(
                {
                    "phase": state.phase.value,
                    "goal": state.goal,
                    "target_url": state.target_url,
                    "session_id": state.session_id,
                    "app_context_cached": state.app_context_cached,
                    "has_app_context": state.app_context is not None,
                    "has_ground_truth": state.ground_truth is not None,
                    "persona_progress": {
                        "total": len(state.persona_tasks),
                        "completed": completed,
                        "failed": failed,
                        "running": running,
                        "pending": pending,
                    },
                    "findings_count": len(state.findings),
                    "error": state.error,
                }
            )

        @tool(context="tool_context")
        async def check_connectivity(tool_context: ToolContext) -> str:
            """Check if target URL is reachable.

            Returns connectivity status and any issues detected.
            """
            state.phase = ExecutionPhase.CONNECTIVITY_CHECK

            try:
                # Run connectivity check
                result = await orchestrator._check_connectivity(state.target_url)
                return (
                    f"Connectivity OK: {result}"
                    if result
                    else "Connectivity check passed"
                )
            except Exception as e:
                state.error = str(e)
                return f"Connectivity FAILED: {e}"

        @tool(context="tool_context")
        async def run_app_discovery(
            tool_context: ToolContext, force_refresh: bool = False
        ) -> str:
            """Run app context discovery.

            Args:
                force_refresh: If true, ignore cache and rediscover

            Returns status and discovered context summary.
            """
            state.phase = ExecutionPhase.APP_DISCOVERY

            try:
                # Check cache first
                if not force_refresh:
                    cached = await orchestrator._load_cached_app_context(
                        state.target_url
                    )
                    if cached:
                        state.app_context = cached
                        state.app_context_cached = True
                        return f"Loaded cached app context ({len(cached)} chars)"

                # Run discovery
                context = await orchestrator._run_app_discovery(state.target_url)
                state.app_context = context
                state.app_context_cached = False
                return f"Discovered app context ({len(context)} chars)"
            except Exception as e:
                state.error = str(e)
                return f"Discovery FAILED: {e}"

        @tool(context="tool_context")
        async def run_ground_truth_collection(tool_context: ToolContext) -> str:
            """Run ground truth collection if configured.

            Returns collected ground truth or skip message.
            """
            state.phase = ExecutionPhase.GROUND_TRUTH

            try:
                ground_truth = await orchestrator._run_ground_truth_collection()
                if ground_truth:
                    state.ground_truth = ground_truth
                    return f"Collected ground truth: {len(ground_truth)} items"
                return "Ground truth collection skipped (not configured)"
            except Exception as e:
                state.error = str(e)
                return f"Ground truth collection FAILED: {e}"

        @tool(context="tool_context")
        def get_persona_list(tool_context: ToolContext) -> str:
            """Get list of personas scheduled for execution.

            Returns persona tasks with their status.
            """
            import json

            tasks_info = [
                {
                    "persona_id": t.persona_id,
                    "instance_name": t.instance_name,
                    "status": t.status,
                    "error": t.error,
                }
                for t in state.persona_tasks
            ]
            return json.dumps(tasks_info)

        @tool(context="tool_context")
        def schedule_persona_execution(
            tool_context: ToolContext,
            persona_specs: list[str],
        ) -> str:
            """Schedule personas for execution.

            Args:
                persona_specs: List of persona specs (e.g., ["malicious_user:3", "nice_user"])

            Returns confirmation of scheduled tasks.
            """
            from agents import expand_persona_list

            expanded = expand_persona_list(persona_specs)

            state.persona_tasks = []
            for persona_id, instance_num in expanded:
                instance_name = f"{persona_id}_{instance_num:02d}"
                state.persona_tasks.append(
                    PersonaTask(
                        persona_id=persona_id,
                        instance_name=instance_name,
                        status="pending",
                    )
                )

            return f"Scheduled {len(state.persona_tasks)} persona tasks"

        @tool(context="tool_context")
        async def run_persona_batch(
            tool_context: ToolContext, batch_size: int | None = None
        ) -> str:
            """Run the next batch of pending personas.

            Args:
                batch_size: Number of personas to run (defaults to max_parallel)

            Returns status of batch execution.
            """
            state.phase = ExecutionPhase.PERSONA_EXECUTION
            size = batch_size or state.max_parallel

            # Get pending tasks
            pending = [t for t in state.persona_tasks if t.status == "pending"][:size]
            if not pending:
                return "No pending personas to run"

            # Mark as running
            for task in pending:
                task.status = "running"

            try:
                # Run personas in parallel
                results = await orchestrator._run_persona_batch(
                    [(t.persona_id, t.instance_name) for t in pending],
                    state.app_context,
                    state.ground_truth,
                )

                # Update task status
                completed = 0
                failed = 0
                for task, result in zip(pending, results, strict=True):
                    if result.get("success"):
                        task.status = "completed"
                        task.result_path = result.get("path")
                        completed += 1
                        state.findings.extend(result.get("findings", []))
                    else:
                        task.status = "failed"
                        task.error = result.get("error")
                        failed += 1

                state.completed_count += completed
                state.failed_count += failed

                return f"Batch complete: {completed} succeeded, {failed} failed"

            except Exception as e:
                for task in pending:
                    task.status = "failed"
                    task.error = str(e)
                state.failed_count += len(pending)
                return f"Batch FAILED: {e}"

        @tool(context="tool_context")
        async def run_cross_conversation_analysis(tool_context: ToolContext) -> str:
            """Run cross-conversation analysis on all findings.

            Returns analysis results summary.
            """
            state.phase = ExecutionPhase.CROSS_ANALYSIS

            try:
                analysis = await orchestrator._run_cross_analysis(state.findings)
                state.findings.extend(analysis.get("findings", []))
                return f"Cross-analysis complete: {len(analysis.get('findings', []))} patterns found"
            except Exception as e:
                return f"Cross-analysis FAILED: {e}"

        @tool(context="tool_context")
        async def generate_report(tool_context: ToolContext) -> str:
            """Generate the final report.

            Returns path to generated report.
            """
            state.phase = ExecutionPhase.REPORT_GENERATION

            try:
                report_path = await orchestrator._generate_report(
                    session_id=state.session_id,
                    findings=state.findings,
                    personas=[t.instance_name for t in state.persona_tasks],
                )
                state.report_path = report_path
                return f"Report generated: {report_path}"
            except Exception as e:
                state.error = str(e)
                return f"Report generation FAILED: {e}"

        @tool(context="tool_context")
        async def upload_artifacts(tool_context: ToolContext) -> str:
            """Upload all session artifacts.

            Returns upload status and URLs.
            """
            state.phase = ExecutionPhase.ARTIFACT_UPLOAD

            try:
                result = await orchestrator._upload_artifacts(state.session_id)
                return f"Artifacts uploaded: {result}"
            except Exception as e:
                return f"Artifact upload FAILED: {e}"

        @tool(context="tool_context")
        def handle_failure(tool_context: ToolContext, reason: str) -> str:
            """Handle pipeline failure.

            Args:
                reason: Explanation of why pipeline failed

            Returns confirmation of failure handling.
            """
            state.phase = ExecutionPhase.FAILED
            state.error = reason
            logger.error(f"Pipeline failed: {reason}")
            return f"Pipeline marked as FAILED: {reason}"

        @tool(context="tool_context")
        def complete_pipeline(tool_context: ToolContext) -> str:
            """Mark pipeline as complete.

            Returns final status summary.
            """
            import json

            state.phase = ExecutionPhase.COMPLETE

            return json.dumps(
                {
                    "status": "complete",
                    "session_id": state.session_id,
                    "personas_completed": state.completed_count,
                    "personas_failed": state.failed_count,
                    "findings_total": len(state.findings),
                    "report_path": state.report_path,
                }
            )

        return [
            get_execution_status,
            check_connectivity,
            run_app_discovery,
            run_ground_truth_collection,
            get_persona_list,
            schedule_persona_execution,
            run_persona_batch,
            run_cross_conversation_analysis,
            generate_report,
            upload_artifacts,
            handle_failure,
            complete_pipeline,
        ]

    def _build_agent(self, state: PlanningState) -> Agent:
        """Build the Strands agent with planning tools."""
        # Use adapter to create Strands model (handles provider selection)
        model = get_llm_adapter().create_strands_model()

        return Agent(
            model=model,
            system_prompt=self._get_system_prompt(),
            tools=self._create_tools(state),
        )

    async def plan_and_execute(
        self,
        target_url: str,
        session_id: str,
        persona_specs: list[str],
        goal: str = "chat",
        max_parallel: int = 3,
        force_discovery: bool = False,
    ) -> dict:
        """Plan and execute the test pipeline.

        For now, this directly delegates to the orchestrator's run_pipeline method.
        In the future, this can be enhanced to use LLM-driven planning with Strands tools
        for more intelligent orchestration and error recovery.

        Args:
            target_url: URL to test
            session_id: Session identifier
            persona_specs: List of persona specifications
            goal: Execution goal (chat, discover, ground_truth)
            max_parallel: Maximum parallel personas
            force_discovery: Force fresh app discovery

        Returns:
            Execution result dictionary
        """
        logger.info(f"🧠 PlanningAgent: Executing pipeline for {target_url}")
        logger.info(f"   Goal: {goal}")
        logger.info(f"   Personas: {persona_specs}")
        logger.info(f"   Max parallel: {max_parallel}")

        try:
            # Delegate to orchestrator's run_pipeline method
            result = await self._orchestrator.run_pipeline(
                target_url=target_url,
                persona_ids=persona_specs,
                goal=goal,
                max_parallel=max_parallel,
                force_discovery=force_discovery,
            )

            logger.info("✅ PlanningAgent: Pipeline completed successfully")
            return {
                "success": True,
                "session_id": session_id,
                "phase": "complete",
                "completed_count": result.get("personas_completed", 0),
                "failed_count": result.get("personas_failed", 0),
                "findings_count": result.get("findings_count", 0),
                "report_path": result.get("report_path"),
                "result": result,
                "error": None,
            }

        except Exception as e:
            logger.exception(f"❌ PlanningAgent: Pipeline failed: {e}")
            return {
                "success": False,
                "session_id": session_id,
                "phase": "failed",
                "completed_count": 0,
                "failed_count": 0,
                "findings_count": 0,
                "report_path": None,
                "error": str(e),
            }


__all__ = [
    "PlanningAgent",
    "PlanningState",
    "PersonaTask",
    "ExecutionPhase",
]
