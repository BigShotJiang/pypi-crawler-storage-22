"""
QA Agent - Calculates quality metrics and analytics from test results.

The QAAgent is a utility wrapper around stats_generator.py that:
1. Generates session statistics (stats.md)
2. Calculates overall and category-specific quality scores
3. Computes response latency statistics
4. Analyzes conversation efficiency metrics
5. Generates finding density analysis

This is NOT an LLM-based agent - it uses deterministic calculations.
"""

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from utils.stats_generator import (
    SessionStats,
    generate_session_stats,
    generate_stats_file,
)

logger = logging.getLogger(__name__)


@dataclass
class QAState:
    """State containing calculated QA metrics."""

    session_stats: SessionStats | None = None
    metrics: dict[str, Any] = field(default_factory=dict)
    stats_md_path: Path | None = None


class QAAgent:
    """Calculates quality metrics and analytics.

    This is a utility class (not an LLM agent) that wraps stats_generator.py
    to compute deterministic quality metrics from session data.

    Metrics calculated:
    - Total personas, completed, failed
    - Total turns across all conversations
    - Finding counts by severity (Critical, Warning, Good)
    - Finding score distribution (min, max, mean, median, std dev)
    - Findings by category and by evaluator agent
    - Conversation length distribution
    - Response extraction time distribution
    - Time to first token (TTFT) distribution
    - Time to last token (TTLT) distribution
    - Response length distribution
    - Within-run performance analysis (first vs last turn)
    - Per-persona summary
    """

    def __init__(self, agent_id: str = "qa_agent") -> None:
        """Initialize the QA agent.

        Args:
            agent_id: Agent identifier for logging
        """
        self._agent_id = agent_id

    def calculate_stats(self, session_dir: str | Path) -> QAState:
        """Calculate session statistics for a completed session.

        This is the main entry point - it reads all session data and
        generates the stats.md file with comprehensive metrics.

        Args:
            session_dir: Path to the session directory containing:
                - agent-timing.log (timing data)
                - */transcript.json (conversation transcripts)
                - */summary.json (persona summaries)
                - progress.json (execution progress)

        Returns:
            QAState with calculated metrics and path to stats.md
        """
        session_path = Path(session_dir)
        state = QAState()

        try:
            # Generate stats.md using the existing generator
            stats_file = generate_stats_file(session_path)
            state.stats_md_path = stats_file

            # Also parse the session data to populate metrics dict
            session_stats = generate_session_stats(session_path)
            state.session_stats = session_stats

            # Extract key metrics for programmatic access
            state.metrics = self._extract_metrics(session_stats)

            logger.info(
                f"QA stats generated: {stats_file}, "
                f"{state.metrics.get('total_findings', 0)} findings"
            )

        except Exception as e:
            logger.warning(f"Failed to generate QA stats: {e}")
            state.metrics["error"] = str(e)

        return state

    def _extract_metrics(self, stats: SessionStats) -> dict[str, Any]:
        """Extract key metrics from SessionStats for programmatic access.

        Args:
            stats: Parsed session statistics

        Returns:
            Dictionary with key metrics
        """
        metrics: dict[str, Any] = {
            # Overview
            "session_id": stats.session_id,
            "target_url": stats.target_url,
            "total_personas": stats.total_personas,
            "completed_personas": stats.completed_personas,
            "failed_personas": stats.failed_personas,
            "total_turns": stats.total_turns,
            # Timing
            "start_time": stats.start_time.isoformat() if stats.start_time else None,
            "end_time": stats.end_time.isoformat() if stats.end_time else None,
            "duration_minutes": stats.total_duration_min,
            # Findings summary
            "total_findings": stats.total_findings,
            "critical_count": stats.total_critical,
            "warning_count": stats.total_warning,
            "good_count": stats.total_good,
        }

        # Finding score statistics
        if stats.all_findings:
            scores = [f.score for f in stats.all_findings if f.score is not None]
            if scores:
                metrics["finding_scores"] = {
                    "min": min(scores),
                    "max": max(scores),
                    "mean": sum(scores) / len(scores),
                    "count": len(scores),
                }

        # Findings by category
        by_category: dict[str, dict[str, int]] = {}
        for finding in stats.all_findings:
            cat = finding.category
            if cat not in by_category:
                by_category[cat] = {"total": 0, "critical": 0, "warning": 0, "good": 0}
            by_category[cat]["total"] += 1
            label_key = finding.label.lower()
            if label_key in by_category[cat]:
                by_category[cat][label_key] += 1
        metrics["findings_by_category"] = by_category

        # Findings by agent
        by_agent: dict[str, int] = {}
        for finding in stats.all_findings:
            agent_id = finding.agent_id
            by_agent[agent_id] = by_agent.get(agent_id, 0) + 1
        metrics["findings_by_agent"] = by_agent

        # Per-persona metrics
        per_persona: dict[str, dict[str, Any]] = {}
        for persona_id, persona_stats in stats.persona_stats.items():
            per_persona[persona_id] = {
                "turns": persona_stats.total_turns,
                "duration_s": persona_stats.total_duration_s,
                "avg_extraction_s": persona_stats.avg_extraction_time_s,
                "findings": persona_stats.findings_count,
                "critical": persona_stats.critical_count,
                "warning": persona_stats.warning_count,
                "good": persona_stats.good_count,
            }
        metrics["per_persona"] = per_persona

        return metrics

    def get_overall_score(self, state: QAState) -> int:
        """Calculate overall quality score from metrics.

        Args:
            state: QAState with calculated metrics

        Returns:
            Quality score 0-100 (higher is better)
        """
        if not state.metrics:
            return 100  # No data = no issues found

        total = state.metrics.get("total_findings", 0)
        if total == 0:
            return 100

        critical = state.metrics.get("critical_count", 0)
        warning = state.metrics.get("warning_count", 0)
        good = state.metrics.get("good_count", 0)

        # Weighted score calculation
        # Critical findings hurt the score most
        # Good findings indicate the chatbot did well
        if total > 0:
            weighted_sum = (critical * 10) + (warning * 50) + (good * 100)
            weighted_count = critical + warning + good
            base_score = (
                int(weighted_sum / weighted_count) if weighted_count > 0 else 50
            )

            # Apply penalty for many critical findings
            if critical > 5:
                penalty = min(30, (critical - 5) * 3)
                base_score = max(0, base_score - penalty)

            return base_score

        return 50  # Default middle score
