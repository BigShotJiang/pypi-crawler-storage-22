"""Constants used across the Arato.Agent application."""

import os
from pathlib import Path

# Force ANONYMIZED_TELEMETRY to false for all runs (browser-use telemetry)
os.environ["ANONYMIZED_TELEMETRY"] = "false"

# Project root directory (where constants.py lives)
PROJECT_ROOT = Path(__file__).parent.resolve()

# AWS Configuration
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
DEFAULT_S3_BUCKET = os.getenv("STORAGE_BUCKET", "arato-agent-artifacts")

# Discovery Configuration
DEFAULT_DISCOVERY_MAX_STEPS = 10  # Default max steps for app context discovery

DEFAULT_MAX_TURNS = 10  # Default maximum number of conversation turns per persona
DEFAULT_SEED_UTTERANCE = "Hello!"  # Default initial message to start conversations
DEFAULT_MAX_PARALLEL_PERSONAS = 4  # Default maximum personas to run in parallel
MIN_TURNS = 1  # Minimum allowed conversation turns

# Browser Window Configuration
# Max dimensions to prevent full-screen browser (helps with screenshots and consistency)
BROWSER_MAX_WIDTH = 1280
BROWSER_MAX_HEIGHT = 980

# Agent Execution Configuration
AGENT_STEPS_BASE = 15  # Base number of browser automation steps allowed
AGENT_STEPS_PER_TURN = 10  # Additional steps allowed per conversation turn
DEFAULT_STEP_TIMEOUT = (
    120  # Default timeout in seconds for each agent step (increased for CAPTCHA/HITL)
)
DEFAULT_PIPELINE_TIMEOUT = (
    2400  # Default timeout in seconds for the entire pipeline execution
)

# Sub-Agent Evaluation Timeouts
# These control how long we wait for sub-agent LLM evaluations to complete
SUB_AGENT_EVALUATE_TURN_TIMEOUT = (
    60.0  # Timeout for per-turn evaluation (increased from 30s due to LLM latency)
)
SUB_AGENT_SUMMARIZE_CONVERSATION_TIMEOUT = 90.0  # Timeout for conversation summary
SUB_AGENT_SUMMARIZE_RUN_TIMEOUT = 120.0  # Timeout for run-level summary

# Response Extraction Configuration
RESPONSE_EXTRACTION_TIMEOUT = 120.0  # Timeout in seconds to wait for chatbot response (increased for slow sites like Wix)
AGENTCORE_PIPELINE_TIMEOUT = (
    14400  # 4 hours - large parallel runs with many personas can take hours
)
AGENTCORE_PERSONA_TIMEOUT = (
    7200  # 2 hours per persona - generous limit for long conversations
)

# Per-turn execution timeout (typing + response extraction + evaluation)
# Safety net to prevent a single turn from hanging indefinitely.
# Must be > RESPONSE_EXTRACTION_TIMEOUT (120s) + evaluation time (~60s) + buffer.
TURN_EXECUTION_TIMEOUT = 300.0  # 5 minutes per turn

# Context Management Configuration
# Defines how many recent history steps retain their screenshots.
# Screenshots from older steps are pruned to save tokens and avoid memory issues (e.g., 128k context limit).
# We keep a small window (e.g., 2) because we extract key details into text/evals,
# so we don't need to keep many historical screenshots for the vision model.
HISTORY_PRUNING_SAFE_WINDOW = 2

# Finding Consolidation Configuration
# Maximum number of findings to keep per conversation turn after consolidation.
# When a turn has more findings than this limit, similar findings are consolidated
# using LLM to merge them into overarching explanations.
MAX_FINDINGS_PER_TURN = 2

# Maximum number of grouped findings to show in the Key Findings tab.
# When batch consolidation produces more groups than this limit, a second-pass
# consolidation is performed to merge similar groups by category until within limit.
MAX_KEY_FINDING_GROUPS = 20

# Progress Tracking Configuration
S3_UPLOAD_INTERVAL_SECONDS = 10.0  # Upload to S3 at most once every 10 seconds
ARTIFACT_UPLOAD_INTERVAL_SECONDS = (
    30.0  # Upload persona artifacts (transcript + screenshots) at most every 30 seconds
)

# Finding Categories (Matching chat_runner_analysis.prompty)
CATEGORY_SECURITY = "Security and Compliance"
CATEGORY_ACCURACY = "Information Accuracy"
CATEGORY_UX = "User Experience"
CATEGORY_FEATURE = "Feature Completeness"

FINDING_CATEGORIES = [
    CATEGORY_SECURITY,
    CATEGORY_ACCURACY,
    CATEGORY_UX,
    CATEGORY_FEATURE,
]

# Finding Category Descriptions
FINDING_CATEGORY_DESCRIPTIONS = {
    CATEGORY_SECURITY: "Prompt injection, jailbreak acceptance, unauthorized access, PII disclosure, regulated content",
    CATEGORY_ACCURACY: "Incorrect facts, hallucinations, misleading info, outdated data",
    CATEGORY_UX: "Clarity, relevance, tone, alignment issues, latency issues",
    CATEGORY_FEATURE: "Missing functionality, broken flows, inability to complete tasks",
}

# Score Thresholds for Issues (Lower score = higher severity)
SCORE_THRESHOLD_GOOD = 75  # Score >= 75 -> Good
SCORE_THRESHOLD_PASS = 10  # Score >= 10 -> Pass (Warning label)
# Score < 10 -> Critical severity (Fail)

# Default values for LLM evaluation fallbacks
DEFAULT_CONFIDENCE = 0.8  # Default confidence when LLM doesn't return one
DEFAULT_CONFIDENCE_HIGH = 0.85  # High confidence for clear-cut cases

SKIP_SCREENSHOTS_FOR_GOOD_FINDINGS = True  # Don't capture screenshots for Good findings

SCORE_LABEL_GOOD = "Good"
SCORE_LABEL_WARNING = "Warning"
SCORE_LABEL_CRITICAL = "Critical"

SCORE_COLOR_GOOD = "#10b981"  # Emerald-500
SCORE_COLOR_WARNING = "#eab308"  # Yellow-500
SCORE_COLOR_CRITICAL = "#ef4444"  # Red-500

SCORE_COLOR_GOOD = "#0B7C30"  # Green-500
SCORE_COLOR_WARNING = "#FFCD6D"  # Yellow-500
SCORE_COLOR_CRITICAL = "#FF4722"  # Orange-500

# Status color tokens (background layers)
STATUS_OUTER_CRITICAL = "#FFE9E5"  # bg-orange-50
STATUS_BG_CRITICAL = "#FFD7CF"  # bg-orange-100
STATUS_OUTER_WARNING = "#FFFBF4"  # bg-yellow-50
STATUS_BG_WARNING = "#FBF5EB"  # bg-yellow-100
STATUS_OUTER_GOOD = "#DBECE1"  # bg-green-50
STATUS_BG_GOOD = "#B6DBC2"  # bg-green-100

# Icon names (frontend parity)
ICON_NAME_WARNING = "WarningDiamondLight"
ICON_NAME_SUCCESS = "OutlineCheckCircleOutline"

# Message Validation Configuration
MIN_USER_MESSAGE_LENGTH = 3  # Minimum characters required for user messages
MIN_ASSISTANT_MESSAGE_LENGTH = 10  # Minimum characters required for assistant responses
USER_MESSAGE_PREVIEW_LENGTH = 80  # Maximum characters to show in user message previews
ASSISTANT_MESSAGE_PREVIEW_LENGTH = (
    80  # Maximum characters to show in assistant message previews
)

# Transcript skip phrases - we don't want to record such responses. These sometime appear as temp message by the chatbot before it replies with the real message
SKIP_PHRASES = [
    "Navigated",
    "Clicked",
    "Typed",
    "Sent keys",
    "waited for",
    "Thinking",
    "Resuming after tool execution",
    "Processing Request",
    "Processing Complete",
    "Aggregating",
]

# Chat Termination Detection Configuration
# Phrases that indicate the chatbot has ended the conversation (escalation, handoff, etc.)
# When detected AND stability check confirms no new response, we conclude with 'chatbot_stopped'
CHATBOT_TERMINATION_PHRASES = [
    # Escalation/handoff to human
    "escalated to a human",
    "transferred to a human",
    "connecting you to a human",
    "human agent will",
    "human representative will",
    "will be contacted shortly",
    "someone will contact you",
    "someone will reach out",
    "a representative will",
    "an agent will",
    "our team will contact",
    "our team will reach out",
    # Conversation ending
    "this conversation has ended",
    "this chat has ended",
    "session has ended",
    "conversation is now closed",
    "chat is now closed",
    "goodbye and take care",
    "thank you for chatting",
    # Unable to continue
    "cannot continue this conversation",
    "unable to assist further",
    "cannot help further",
    "nothing more i can do",
    "no further assistance",
]

# Number of stability checks before confirming termination (higher = more confidence)
CHATBOT_TERMINATION_STABILITY_THRESHOLD = 3

# Generic Personas (will be sorted to the end in reports)
GENERIC_PERSONA_IDS = [
    "accessibility_tester_user",
    "boundary_user",
    "child_user",
    "chinese_speaking_user",
    "compliance_user",
    "conspiracy_user",
    "expert_user",
    "impatient_user",
    "malicious_user",
    "naive_user",
    "nice_user",
    "non_native_english_user",
    "passive_aggressive_user",
    "rabbit_hole_user",
    "vulnerable_user",
]

# File and Directory Names
DISCOVERY_VIDEO_FILENAME = "discovery.mp4"  # Filename for app context discovery videos
RUN_VIDEO_FILENAME = "run.mp4"  # Filename for conversation run videos
APP_CONTEXT_FILENAME = "app_context.json"  # Filename for application context data
GROUND_TRUTH_FILENAME = (
    "ground_truth.json"  # Filename for ground truth data (cached per domain)
)
TRANSCRIPT_FILENAME = "transcript.json"  # Filename for conversation transcripts
SUMMARY_FILENAME = "summary.json"  # Filename for conversation summaries
REPORT_DATA_FILENAME = "report_data.json"  # Filename for consolidated report data
TEST_SUITE_ID_FILENAME = "test_suite_id.txt"  # Filename for test suite ID reference
CROSS_CONVERSATION_FINDINGS_FILENAME = (
    "cross_conversation_findings.json"  # Sub-agent findings
)
STATIC_REPORT_UI_BUCKET = "arato-static-dev-d27c69b0"  # Bucket containing the pre-built static report UI (this is the bucket for dev.arato.io)
STATIC_REPORT_UI_PREFIX = "agent"  # Prefix for the pre-built static report UI


# AWS VPC Configuration
VPC_ENDPOINT_SERVICE_FORMAT = "com.amazonaws.{region}.{service_suffix}"

# Required VPC endpoints for Bedrock AgentCore with browser functionality
VPC_REQUIRED_ENDPOINTS = [
    {
        "service_suffix": "ecr.dkr",
        "type": "Interface",
        "name": "ECR Docker",
        "description": "Container image pull",
        "critical": True,
    },
    {
        "service_suffix": "ecr.api",
        "type": "Interface",
        "name": "ECR API",
        "description": "ECR authentication",
        "critical": True,
    },
    {
        "service_suffix": "s3",
        "type": "Gateway",
        "name": "S3",
        "description": "Artifact storage",
        "critical": True,
    },
    {
        "service_suffix": "logs",
        "type": "Interface",
        "name": "CloudWatch Logs",
        "description": "Log streaming",
        "critical": True,
    },
    {
        "service_suffix": "sts",
        "type": "Interface",
        "name": "STS",
        "description": "IAM operations",
        "critical": True,
    },
    {
        "service_suffix": "bedrock-runtime",
        "type": "Interface",
        "name": "Bedrock Runtime",
        "description": "LLM API calls",
        "critical": True,
    },
    {
        "service_suffix": "bedrock-agentcore",
        "type": "Interface",
        "name": "Bedrock AgentCore",
        "description": "Control plane (REQUIRED for browser)",
        "critical": True,
    },
    {
        "service_suffix": "bedrock-agentcore.gateway",
        "type": "Interface",
        "name": "Bedrock AgentCore Gateway",
        "description": "Browser management (REQUIRED, supports 2 AZs only)",
        "critical": True,
        "max_azs": 2,  # This endpoint only supports 2 AZs
    },
]
FINAL_RESULT_FILENAME = "final_result.json"  # Filename for final pipeline results
HAR_FILENAME = "app_context.har"  # Filename for HTTP Archive files

# Directory Structure
VIDEO_SUBDIR_DISCOVERY = "app_context_video"  # Subdirectory for discovery phase videos
VIDEO_SUBDIR_RUN = "run_video"  # Subdirectory for conversation run videos

PERSONA_SETTINGS_DIR = str(
    PROJECT_ROOT / "persona_settings"
)  # Directory containing persona definition files
SKILLS_DIR = str(
    PROJECT_ROOT / "skills"
)  # Directory containing skill definition files (.skill)
DOMAIN_SETTINGS_DIR = (
    "/tmp/domain_settings"  # Directory for domain-specific cached settings
)
TMP_SESSIONS_DIR = "/tmp/sessions"  # Temporary directory for session data
LOCAL_STORAGE_BASE_DIR = (
    "/tmp/local_storage"  # Base directory for local storage adapter
)

# HITL (Human-in-the-Loop) Configuration
HITL_DEFAULT_TIMEOUT_SECONDS = (
    600  # Default timeout for human intervention (10 minutes)
)
HITL_POLL_INTERVAL_SECONDS = 3  # How often to check intervention state (3 seconds)
HITL_MAX_POLL_ATTEMPTS = 200  # Maximum polling attempts (200 * 3s = 10 minutes)

# HITL Recovery Configuration
HITL_RECOVERY_ENABLED = True  # Enable automatic recovery when HITL times out
HITL_RECOVERY_STRATEGY = "continue"  # Strategy: "continue" (attempt to proceed), "skip" (skip task and continue testing)

# CAPTCHA Solver Configuration
CAPTCHA_SOLVER_ENABLED = True  # Enable automatic CAPTCHA solving before HITL fallback
CAPTCHA_SOLVER_MAX_ATTEMPTS = (
    5  # Maximum attempts to solve a CAPTCHA (increased for consecutive challenges)
)
CAPTCHA_SOLVER_CLICK_DELAY = 0.4  # Delay between cell clicks (seconds) to mimic human
CAPTCHA_SOLVER_POST_SOLVE_DELAY = 0.5  # Delay after clicking all cells before submit
CAPTCHA_SOLVER_MAX_DYNAMIC_ROUNDS = (
    8  # Maximum dynamic tile replacement rounds per attempt
)

# Bedrock model identifiers
BEDROCK_MODEL_ID_HAIKU = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
BEDROCK_MODEL_ID_SONNET = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"

# Vertex AI model identifiers
VERTEX_MODEL_ID_SONNET = "claude-sonnet-4-5@20250929"
VERTEX_MODEL_ID_HAIKU = "claude-haiku-4-5@20251001"
VERTEX_MODEL_ID_GEMINI_PRO = "gemini-3-pro-preview"
VERTEX_MODEL_ID_GEMINI_FLASH = "gemini-3-flash-preview"

# Token Cost Configuration (USD per million tokens)
# These are blended rates (input + output averaged) for cost estimation
# We calculate our own costs to avoid double-counting from different sources
# Pricing source: https://cloud.google.com/vertex-ai/generative-ai/pricing
TOKEN_COST_PER_MILLION_SONNET = 9.0  # Claude Sonnet 4.5: ~$3 input, ~$15 output
TOKEN_COST_PER_MILLION_HAIKU = 1.25  # Claude Haiku 4.5: ~$0.80 input, ~$4 output
TOKEN_COST_PER_MILLION_GEMINI_FLASH = 0.15  # Gemini Flash: ~$0.075 input, ~$0.30 output
TOKEN_COST_PER_MILLION_GEMINI_PRO = 2.50  # Gemini Pro: ~$1.25 input, ~$5 output
TOKEN_COST_PER_MILLION_DEFAULT = 3.0  # Conservative default for unknown models

# Google Cloud configuration for Vertex AI
# Check environment variables first (for tests), then use defaults
VERTEX_PROJECT_ID = os.getenv("VERTEX_PROJECT_ID", "arato-agent")
VERTEX_REGION = os.getenv("VERTEX_REGION", "global")

# Analytics Configuration
# Default to enabled (True), but allow disabling via env var
# Prioritize DISABLE_ANALYTICS for backward compatibility if set
_disable_analytics = os.getenv("DISABLE_ANALYTICS")
if _disable_analytics:
    ANALYTICS_ENABLED = _disable_analytics.lower() not in (
        "true",
        "1",
        "yes",
    )
else:
    ANALYTICS_ENABLED = os.getenv("ANALYTICS_ENABLED", "true").lower() in (
        "true",
        "1",
        "yes",
    )

BIGQUERY_PROJECT_ID = os.getenv("BIGQUERY_PROJECT_ID", "arato-agent")
BIGQUERY_DATASET_ID = os.getenv("BIGQUERY_DATASET_ID", "agent_analytics")
BIGQUERY_TABLE_ID = os.getenv("BIGQUERY_TABLE_ID", "agent_runs")

# LLM Provider Configuration
LLM_PROVIDER_VERTEX = "vertex"
LLM_PROVIDER_BEDROCK = "bedrock"

# AWS SSM Parameter Store keys
SSM_PARAM_GOOGLE_CREDENTIALS = "/arato_agent/google_credentials"
SSM_PARAM_AGENTCORE_AGENT_ID = "/arato_agent/agentcore/agent_id"
SSM_PARAM_AGENTCORE_AGENT_ARN = "/arato_agent/agentcore/agent_arn"

# DevOps Infrastructure Configuration
DEVOPS_DEFAULT_REGION = "us-east-1"

# Account-specific configuration for reports infrastructure
# Key: AWS Account ID, Value: (bucket_name, domain)
# Hosted zone IDs are looked up dynamically by setup script
DEVOPS_ACCOUNT_CONFIG: dict[str, tuple[str, str]] = {
    "637423350601": ("arato-agent-reports", "reports.arato.ai"),  # ProdApp
    "211125609257": ("arato-agent-reports-staging", "reports.arato.io"),  # Staging
}

# Default bucket name pattern for accounts not in DEVOPS_ACCOUNT_CONFIG
DEVOPS_DEFAULT_BUCKET_PREFIX = "arato-agent-reports"
