"""Adapter interfaces for storage operations."""
