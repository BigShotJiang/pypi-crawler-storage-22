"""Browser management abstractions.

This module provides platform-agnostic browser management through the
BrowserManager interface. Platform-specific implementations live in
platforms/<platform_name>/browser.py
"""

from core.browser.base import (
    BrowserManager,
    create_browser,
    get_browser_manager,
    set_browser_manager,
    setup_browser_kwargs,
)

__all__ = [
    "BrowserManager",
    "create_browser",
    "get_browser_manager",
    "set_browser_manager",
    "setup_browser_kwargs",
]
