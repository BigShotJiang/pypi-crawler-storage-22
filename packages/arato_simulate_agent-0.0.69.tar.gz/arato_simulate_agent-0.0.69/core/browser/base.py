"""Abstract browser manager for platform-independent browser operations.

This module provides the base interface for browser management,
allowing agents to work with browsers without knowing whether they're
local (Playwright) or cloud-based.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from browser_use import Browser


class BrowserManager(ABC):
    """Abstract browser manager interface.

    Each platform implements this to provide browser instances
    appropriate for that environment.
    """

    @abstractmethod
    @asynccontextmanager
    async def create_browser(self, **kwargs: Any) -> AsyncIterator[Browser]:
        """Create and manage a browser instance.

        Args:
            **kwargs: Browser configuration parameters

        Yields:
            Configured Browser instance
        """
        raise NotImplementedError  # pragma: no cover
        yield Browser()  # pragma: no cover

    @abstractmethod
    def setup_browser_kwargs(
        self,
        headless: bool = False,
        disable_security: bool = False,
        record_video_dir: str | None = None,
        record_har_path: str | None = None,
        record_har_content: str | None = None,
        storage_state: str | None = None,
        permissions: list[str] | None = None,
        **extra_kwargs: Any,
    ) -> dict[str, Any]:
        """Prepare platform-specific browser configuration.

        Args:
            headless: Run browser in headless mode
            disable_security: Disable browser security features
            record_video_dir: Directory to save video recordings
            record_har_path: Path to save HAR file
            record_har_content: HAR content mode ('omit', 'embed', 'attach')
            storage_state: Path to JSON file with saved authentication state
                          (cookies, localStorage). Use context.storage_state()
                          to save and load here to restore.
            permissions: List of permissions to grant (e.g., ['microphone'])
            **extra_kwargs: Additional configuration

        Returns:
            Dictionary of browser kwargs for Browser()
        """
        pass

    @abstractmethod
    async def get_current_url(self) -> str | None:
        """Get the current URL from the browser.

        Returns:
            Current URL or None if unavailable

        Raises:
            NotImplementedError: If platform doesn't support URL retrieval
        """
        pass

    def get_session_info(self) -> dict[str, str | None]:
        """Get browser session info for DCV viewer integration.

        Returns:
            Dict with session_id (AgentCore session ID or None),
            browser_type ("agentcore" or "local"), and
            browser_identifier (AgentCore browser identifier, e.g. "aws.browser.v1", or None).
        """
        return {"session_id": None, "browser_type": "local", "browser_identifier": None}

    async def capture_screenshot(self, browser: Browser | None = None) -> str | None:
        """Capture a screenshot of the current browser page using browser-use API.

        Args:
            browser: Browser instance to capture from (required)

        Returns:
            Base64-encoded screenshot string (PNG format) or None if capture failed.
            Use base64.b64decode() to convert to bytes if needed.
        """
        if browser is None:
            import logging

            logger = logging.getLogger(__name__)
            logger.error("Browser instance is required for screenshot capture")
            return None

        try:
            import logging

            logger = logging.getLogger(__name__)

            # Get the current page using browser-use API
            page = await browser.get_current_page()
            if page is None:
                logger.error("No active page for screenshot")
                return None

            # Capture screenshot using browser-use's page.screenshot()
            # Returns base64-encoded string
            screenshot_b64: str = await page.screenshot(format="png")
            logger.info("✓ Captured screenshot using browser-use API")
            return screenshot_b64

        except Exception as e:
            import logging

            logger = logging.getLogger(__name__)
            logger.error("Failed to capture screenshot: %s", e)
            return None

    @abstractmethod
    async def request_intervention(
        self,
        reason: str,
        intervention_type: str = "custom",
        session_id: str | None = None,
        timeout_seconds: int | None = None,
        url_before: str | None = None,
        screenshot_url: str | None = None,
    ) -> str:
        """Request human intervention and return an intervention ID.

        This method should:
        1. Create a unique intervention ID
        2. Update browser/session state to indicate intervention needed
        3. Return the intervention ID for polling

        Args:
            reason: Human-readable explanation of why intervention is needed
            intervention_type: Type of intervention (captcha, login, etc.)
            session_id: Optional browser session ID
            timeout_seconds: Optional timeout override
            url_before: Optional URL before intervention (for tracking)
            screenshot_url: Optional URL/path to screenshot of the page

        Returns:
            Unique intervention ID for tracking this request

        Raises:
            NotImplementedError: If platform doesn't support HITL
        """
        pass

    @abstractmethod
    async def check_intervention_state(self, intervention_id: str) -> dict[str, Any]:
        """Check the current state of an intervention request.

        Args:
            intervention_id: The intervention ID to check

        Returns:
            Dictionary with keys:
                - state: Current state (waiting, completed, timeout, error)
                - intervention_id: The intervention ID
                - completed_at: Timestamp if completed (optional)
                - error_message: Error message if state is error (optional)

        Raises:
            NotImplementedError: If platform doesn't support HITL
        """
        pass

    @abstractmethod
    async def wait_for_intervention_completion(
        self,
        intervention_id: str,
        timeout_seconds: int | None = None,
        poll_interval_seconds: int = 3,
    ) -> dict[str, Any]:
        """Wait for human to complete the intervention.

        This method polls check_intervention_state until:
        - State becomes 'completed' (returns response)
        - Timeout is reached (raises TimeoutError)
        - Error occurs (raises RuntimeError)

        Args:
            intervention_id: The intervention ID to wait for
            timeout_seconds: Maximum time to wait (uses default if None)
            poll_interval_seconds: How often to check state

        Returns:
            Dictionary with intervention response details

        Raises:
            TimeoutError: If intervention times out
            RuntimeError: If intervention encounters an error
            NotImplementedError: If platform doesn't support HITL
        """
        pass

    @abstractmethod
    async def cancel_intervention(
        self,
        intervention_id: str,
        reason: str | None = None,
    ) -> bool:
        """Cancel a pending intervention request.

        This allows agents to cancel an intervention if they find an alternative
        solution or no longer need human help.

        Args:
            intervention_id: The intervention ID to cancel
            reason: Optional reason for cancellation

        Returns:
            True if cancellation successful, False if intervention not found or already completed

        Raises:
            NotImplementedError: If platform doesn't support HITL
        """
        pass


# Global browser manager instance (set by application initialization)
_browser_manager: BrowserManager | None = None


def set_browser_manager(manager: BrowserManager) -> None:
    """Set the global browser manager instance.

    This should be called during application initialization to configure
    which browser backend to use.

    Args:
        manager: The browser manager instance to use
    """
    global _browser_manager
    _browser_manager = manager


def get_browser_manager() -> BrowserManager:
    """Get the current browser manager instance.

    Returns:
        The configured browser manager

    Raises:
        RuntimeError: If no manager has been configured
    """
    if _browser_manager is None:
        # Auto-initialize with default implementation if not explicitly configured
        from platforms.aws_agentcore.browser import AgentCoreBrowserManager

        set_browser_manager(AgentCoreBrowserManager())

    assert _browser_manager is not None
    return _browser_manager


@asynccontextmanager
async def create_browser(**kwargs: Any) -> AsyncIterator[Browser]:
    """Create a browser using the configured browser manager.

    This is the main entry point for creating browsers throughout the codebase.
    It delegates to the configured manager.

    Args:
        **kwargs: Browser configuration parameters

    Yields:
        Configured Browser instance

    Example:
        >>> async with create_browser(headless=True) as browser:
        ...     # Use browser
    """
    manager = get_browser_manager()
    async with manager.create_browser(**kwargs) as browser:
        yield browser


def setup_browser_kwargs(
    headless: bool = False,
    disable_security: bool = False,
    record_video_dir: str | None = None,
    record_har_path: str | None = None,
    record_har_content: str | None = None,
    user_data_dir: str | None = None,
    profile_directory: str | None = None,
    keep_alive: bool = False,
    **extra_kwargs: Any,
) -> dict[str, Any]:
    """Prepare browser configuration using the configured browser manager.

    This is the main entry point for preparing browser kwargs throughout the codebase.
    It delegates to the configured manager.

    Args:
        headless: Run browser in headless mode
        disable_security: Disable browser security features
        record_video_dir: Directory to save video recordings
        record_har_path: Path to save HAR file
        record_har_content: HAR content mode ('omit', 'embed', 'attach')
        user_data_dir: Directory to store browser profile data (cookies, cache, etc.)
                      for persisting authentication between sessions
        profile_directory: Browser profile directory name (default: "Default")
        keep_alive: Keep browser alive between sessions for faster subsequent runs
        **extra_kwargs: Additional configuration

    Returns:
        Dictionary of browser kwargs for Browser()

    Example:
        >>> kwargs = setup_browser_kwargs(headless=True, disable_security=False)
        >>> async with create_browser(**kwargs) as browser:
        ...     # Use browser
    """
    manager = get_browser_manager()
    return manager.setup_browser_kwargs(
        headless=headless,
        disable_security=disable_security,
        record_video_dir=record_video_dir,
        record_har_path=record_har_path,
        record_har_content=record_har_content,
        user_data_dir=user_data_dir,
        profile_directory=profile_directory,
        keep_alive=keep_alive,
        **extra_kwargs,
    )


__all__ = [
    "BrowserManager",
    "create_browser",
    "get_browser_manager",
    "set_browser_manager",
    "setup_browser_kwargs",
]
