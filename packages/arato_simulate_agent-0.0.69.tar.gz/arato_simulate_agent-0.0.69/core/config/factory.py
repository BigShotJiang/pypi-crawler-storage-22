"""Adapter factory for creating platform-specific implementations."""

from core.config.schemas import (
    AdapterConfig,
    StorageAdapterType,
)
from core.storage.base import StorageAdapter

try:
    from platforms.aws_agentcore.storage import S3StorageAdapter
except ImportError:
    S3StorageAdapter = None  # type: ignore

try:
    from platforms.local.storage import LocalStorageAdapter
except ImportError:
    LocalStorageAdapter = None  # type: ignore


def create_adapters(
    config: AdapterConfig,
) -> StorageAdapter:
    """Create storage adapter based on configuration.

    Args:
        config: AdapterConfig with platform settings

    Returns:
        StorageAdapter instance

    Raises:
        ValueError: If unknown adapter type specified
    """

    # Storage adapter
    if config.storage.adapter == StorageAdapterType.S3:
        if S3StorageAdapter is None:
            raise ImportError("AWS platform not available. Install aws dependencies.")
        storage_adapter = S3StorageAdapter(
            bucket_name=config.storage.bucket, region=config.storage.region
        )
    elif config.storage.adapter == StorageAdapterType.LOCAL_FILESYSTEM:
        if LocalStorageAdapter is None:
            raise ImportError("Local platform not available.")
        storage_adapter = LocalStorageAdapter(base_dir=config.storage.base_dir)
    else:
        raise ValueError(f"Unknown storage adapter: {config.storage.adapter}")

    return storage_adapter
