"""Configuration loader from YAML and environment."""

from pathlib import Path

import yaml

from core.config.schemas import (
    AdapterConfig,
    StorageConfig,
)


def load_config(config_path: str) -> AdapterConfig:
    """Load configuration from YAML file.

    Args:
        config_path: Path to YAML configuration file

    Returns:
        AdapterConfig instance

    Raises:
        FileNotFoundError: If config file doesn't exist
        ValidationError: If config is invalid
    """
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {config_path}")

    with open(path) as f:
        raw_config = yaml.safe_load(f)

    return AdapterConfig(**raw_config)


def load_config_from_env() -> AdapterConfig:
    """Load configuration from environment variables.

    Returns:
        AdapterConfig instance with values from environment

    Environment Variables:
        STORAGE_ADAPTER: s3 or local_filesystem
        STORAGE_BUCKET: S3 bucket name
        STORAGE_REGION: AWS region
        STORAGE_BASE_DIR: Local storage directory
    """
    import os

    return AdapterConfig(
        storage=StorageConfig(
            adapter=os.getenv("STORAGE_ADAPTER", "local_filesystem"),  # type: ignore[arg-type]
            bucket=os.getenv("STORAGE_BUCKET", "arato-agent-artifacts"),
            region=os.getenv("STORAGE_REGION", "us-east-1"),
            base_dir=os.getenv("STORAGE_BASE_DIR", "./local_storage/artifacts"),
        ),
    )
