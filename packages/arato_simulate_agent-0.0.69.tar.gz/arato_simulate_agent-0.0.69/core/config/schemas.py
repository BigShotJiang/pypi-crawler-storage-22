"""Configuration schemas using Pydantic."""

from enum import StrEnum

from pydantic import BaseModel


class StorageAdapterType(StrEnum):
    """Storage adapter types."""

    S3 = "s3"
    LOCAL_FILESYSTEM = "local_filesystem"


class StorageConfig(BaseModel):
    """Storage adapter configuration.

    Defaults should be provided by the config loader, not here.
    This keeps schema definitions pure and makes missing configs explicit.
    """

    adapter: StorageAdapterType
    bucket: str
    region: str
    base_dir: str


class AdapterConfig(BaseModel):
    """Complete adapter configuration."""

    storage: StorageConfig


class Config(AdapterConfig):
    """Alias for backwards compatibility."""

    pass
