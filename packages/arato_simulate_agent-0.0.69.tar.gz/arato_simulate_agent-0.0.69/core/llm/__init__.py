"""LLM abstractions for platform-independent language model access."""

from core.llm.base import (
    LLMAdapter,
    create_chat_model,
    get_llm_adapter,
    set_llm_adapter,
)

__all__ = [
    "LLMAdapter",
    "create_chat_model",
    "get_llm_adapter",
    "set_llm_adapter",
]
