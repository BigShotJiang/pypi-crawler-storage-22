"""ChatAnthropicVertex: Anthropic Claude via Google Cloud Vertex AI.

This module provides a browser-use compatible LLM adapter for using Anthropic's Claude
models through Google Cloud Vertex AI instead of direct Anthropic API.
"""

import asyncio
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, TypeVar, overload

import httpx
from anthropic import (
    AnthropicVertex,
    APIConnectionError,
    APIStatusError,
    NotGiven,
    RateLimitError,
    omit,
)
from anthropic.types import CacheControlEphemeralParam, Message, ToolParam
from anthropic.types.model_param import ModelParam
from anthropic.types.text_block import TextBlock
from anthropic.types.tool_choice_tool_param import ToolChoiceToolParam
from browser_use.llm.anthropic.serializer import AnthropicMessageSerializer
from browser_use.llm.base import BaseChatModel
from browser_use.llm.exceptions import ModelProviderError, ModelRateLimitError
from browser_use.llm.messages import BaseMessage
from browser_use.llm.schema import SchemaOptimizer
from browser_use.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from httpx import Timeout
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


@dataclass
class ChatAnthropicVertex(BaseChatModel):
    """
    A wrapper around Anthropic's chat model via Google Cloud Vertex AI.

    This adapter uses AnthropicVertex client to access Claude models through
    Google Cloud instead of directly through Anthropic API.

    Example:
        llm = ChatAnthropicVertex(
            model='claude-3-5-sonnet@20240620',
            project_id='your-gcp-project-id',
            region='us-east1',
            max_tokens=8192,
        )
    """

    # Model configuration
    model: str | ModelParam
    max_tokens: int = 8192
    temperature: float | None = None
    top_p: float | None = None

    # Google Cloud Vertex AI parameters
    project_id: str | None = None
    region: str = "us-east1"

    # Client initialization parameters (inherited from Anthropic)
    base_url: str | httpx.URL | None = None
    timeout: float | Timeout | None | NotGiven = NotGiven()
    max_retries: int = 10
    default_headers: Mapping[str, str] | None = None
    default_query: Mapping[str, object] | None = None
    http_client: httpx.AsyncClient | None = None

    # Static
    @property
    def provider(self) -> str:
        return "anthropic_vertex"

    def _get_client_params(self) -> dict[str, Any]:
        """Prepare client parameters dictionary."""
        # Define base client params
        base_params = {
            "project_id": self.project_id,
            "region": self.region,
            "base_url": self.base_url,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "default_headers": self.default_headers,
            "default_query": self.default_query,
            "http_client": self.http_client,
        }

        # Create client_params dict with non-None values and non-NotGiven values
        # Note: Must use isinstance check because each NotGiven() creates a new instance
        client_params = {}
        for k, v in base_params.items():
            if v is not None and not isinstance(v, type(NotGiven())):
                client_params[k] = v

        return client_params

    def _get_client_params_for_invoke(self) -> dict[str, Any]:
        """Prepare client parameters dictionary for invoke."""
        client_params = {}

        if self.temperature is not None:
            client_params["temperature"] = self.temperature

        if self.max_tokens is not None:
            client_params["max_tokens"] = self.max_tokens

        if self.top_p is not None:
            client_params["top_p"] = self.top_p

        return client_params

    def get_client(self) -> AnthropicVertex:
        """
        Returns an AnthropicVertex client.

        Returns:
            AnthropicVertex: An instance of the AnthropicVertex client.
        """
        client_params = self._get_client_params()
        return AnthropicVertex(**client_params)

    @property
    def name(self) -> str:
        return str(self.model)

    def _get_usage(self, response: Message) -> ChatInvokeUsage | None:
        usage = ChatInvokeUsage(
            prompt_tokens=response.usage.input_tokens
            + (
                response.usage.cache_read_input_tokens or 0
            ),  # Total tokens in Anthropic are a bit fucked, you have to add cached tokens to the prompt tokens
            completion_tokens=response.usage.output_tokens,
            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
            prompt_cached_tokens=response.usage.cache_read_input_tokens,
            prompt_cache_creation_tokens=response.usage.cache_creation_input_tokens,
            prompt_image_tokens=None,
        )
        return usage

    @overload
    async def ainvoke(
        self, messages: list[BaseMessage], output_format: None = None, **kwargs: Any
    ) -> ChatInvokeCompletion[str]: ...

    @overload
    async def ainvoke(
        self, messages: list[BaseMessage], output_format: type[T], **kwargs: Any
    ) -> ChatInvokeCompletion[T]: ...

    async def ainvoke(
        self,
        messages: list[BaseMessage],
        output_format: type[T] | None = None,
        **kwargs: Any,
    ) -> ChatInvokeCompletion[T] | ChatInvokeCompletion[str]:
        anthropic_messages, system_prompt = (
            AnthropicMessageSerializer.serialize_messages(list(messages))
        )

        try:
            if output_format is None:
                # Normal completion without structured output
                client = self.get_client()

                def _sync_create_message() -> Any:
                    return client.messages.create(
                        model=self.model,
                        messages=anthropic_messages,
                        system=system_prompt or omit,
                        **self._get_client_params_for_invoke(),
                    )

                response = await asyncio.to_thread(_sync_create_message)

                # Ensure we have a valid Message object before accessing attributes
                if not isinstance(response, Message):
                    raise ModelProviderError(
                        message=f"Unexpected response type from Anthropic Vertex API: {type(response).__name__}. Response: {str(response)[:200]}",
                        status_code=502,
                        model=self.name,
                    )

                usage = self._get_usage(response)

                # Extract text from the first content block
                first_content = response.content[0]
                if isinstance(first_content, TextBlock):
                    response_text = first_content.text
                else:
                    # If it's not a text block, convert to string
                    response_text = str(first_content)

                return ChatInvokeCompletion(
                    completion=response_text,
                    usage=usage,
                    stop_reason=response.stop_reason,
                )

            else:
                # Use tool calling for structured output
                # Create a tool that represents the output format
                tool_name = output_format.__name__
                schema = SchemaOptimizer.create_optimized_json_schema(output_format)

                # Remove title from schema if present (Anthropic doesn't like it in parameters)
                if "title" in schema:
                    del schema["title"]

                tool = ToolParam(
                    name=tool_name,
                    description=f"Extract information in the format of {tool_name}",
                    input_schema=schema,
                    cache_control=CacheControlEphemeralParam(type="ephemeral"),
                )

                # Force the model to use this tool
                tool_choice = ToolChoiceToolParam(type="tool", name=tool_name)

                client = self.get_client()

                def _sync_create_message_with_tools() -> Any:
                    return client.messages.create(
                        model=self.model,
                        messages=anthropic_messages,
                        tools=[tool],
                        system=system_prompt or omit,
                        tool_choice=tool_choice,
                        **self._get_client_params_for_invoke(),
                    )

                response = await asyncio.to_thread(_sync_create_message_with_tools)

                # Ensure we have a valid Message object
                if not isinstance(response, Message):
                    raise ModelProviderError(
                        message=f"Unexpected response type from Anthropic Vertex API: {type(response).__name__}. Response: {str(response)[:200]}",
                        status_code=502,
                        model=self.name,
                    )

                usage = self._get_usage(response)

                # Extract the tool call result
                for content in response.content:
                    if content.type == "tool_use":
                        # Parse the tool input as the structured output
                        try:
                            result = output_format.model_validate(content.input)
                            return ChatInvokeCompletion(
                                completion=result,
                                usage=usage,
                                stop_reason=response.stop_reason,
                            )
                        except Exception as e:
                            raise ModelProviderError(
                                message=f"Failed to validate structured output: {str(e)}",
                                status_code=500,
                                model=self.name,
                            ) from e

                # If we didn't find a tool use, raise an error
                raise ModelProviderError(
                    message="Model did not return structured output as expected",
                    status_code=500,
                    model=self.name,
                )

        except RateLimitError as e:
            raise ModelRateLimitError(
                message=f"Rate limit exceeded: {str(e)}",
                status_code=429,
                model=self.name,
            ) from e
        except APIStatusError as e:
            raise ModelProviderError(
                message=f"Anthropic Vertex API error: {e.message}",
                status_code=e.status_code,
                model=self.name,
            ) from e
        except APIConnectionError as e:
            raise ModelProviderError(
                message=f"Connection error to Anthropic Vertex API: {str(e)}",
                status_code=503,
                model=self.name,
            ) from e
        except Exception as e:
            raise ModelProviderError(
                message=f"Unexpected error: {str(e)}",
                status_code=500,
                model=self.name,
            ) from e
