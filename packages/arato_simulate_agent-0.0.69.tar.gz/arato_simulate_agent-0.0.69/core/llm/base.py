"""LLM interface using AWS Bedrock.

This module provides a concrete LLM adapter using AWS Bedrock with Anthropic Claude models.
Both local and AWS platforms use this same implementation.
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import Any, cast

import boto3
from botocore.client import BaseClient
from botocore.config import Config
from browser_use.llm.base import BaseChatModel

from constants import (
    BEDROCK_MODEL_ID_HAIKU,
    BEDROCK_MODEL_ID_SONNET,
    DEVOPS_DEFAULT_REGION,
    LLM_PROVIDER_BEDROCK,
    VERTEX_MODEL_ID_GEMINI_FLASH,
    VERTEX_MODEL_ID_GEMINI_PRO,
    VERTEX_MODEL_ID_HAIKU,
    VERTEX_MODEL_ID_SONNET,
    VERTEX_PROJECT_ID,
    VERTEX_REGION,
)
from core.llm.anthropic_vertex import ChatAnthropicVertex
from core.llm.gemini_vertex import ChatGeminiVertex
from utils.browser_use_patches import ChatAWSBedrockAdapter

_DEFAULT_RETRY_CONFIG = {"max_attempts": 5, "mode": "adaptive"}


class LLMAdapter:
    """LLM adapter using AWS Bedrock.

    Provides access to Anthropic Claude models hosted on Amazon Bedrock.
    Used by both local and AWS platforms.
    """

    def __init__(self, region: str | None = None):
        """Initialize LLM adapter with AWS Bedrock.

        Args:
            region: AWS region for Bedrock (defaults to environment detection)
        """
        self._region = region

    def resolve_region(self) -> str:
        """Resolve the AWS region to use for Bedrock requests."""
        if self._region:
            return self._region

        return (
            os.getenv("BEDROCK_REGION")
            or os.getenv("BEDROCK_AGENTCORE_REGION")
            or os.getenv("AWS_REGION")
            or os.getenv("AWS_DEFAULT_REGION")
            or DEVOPS_DEFAULT_REGION
            or "us-east-1"
        )

    @lru_cache(maxsize=1)
    def get_bedrock_runtime_client(self) -> BaseClient:
        """Create (and cache) a Bedrock runtime client following AWS best practices."""
        region = self.resolve_region()
        config = Config(retries=_DEFAULT_RETRY_CONFIG)
        return boto3.client("bedrock-runtime", region_name=region, config=config)

    @lru_cache(maxsize=1)
    def get_boto3_session(self) -> boto3.Session:
        """Create (and cache) a boto3 Session with AWS credentials.

        In AWS environments (like AgentCore), this uses IAM role credentials automatically.
        """
        region = self.resolve_region()
        return boto3.Session(region_name=region)

    def create_chat_model(
        self,
        model_id: str | None = None,
        **kwargs: Any,
    ) -> BaseChatModel:
        """Create a chat model instance.

        Args:
            model_id: The model ID or friendly name ('haiku'/'sonnet'/'claude_sonnet'/'gemini_flash').
                     Defaults to Gemini Flash on Vertex AI.
            **kwargs: Additional configuration parameters (temperature, max_tokens)

        Returns:
            BaseChatModel instance configured for browser-use
        """
        # Resolve model_id from friendly name if needed
        if model_id is None:
            resolved_model_id = self.get_default_model_id()
        elif model_id in self.get_available_models():
            resolved_model_id = self.get_available_models()[model_id]
        else:
            resolved_model_id = model_id

        params: dict[str, Any] = {k: v for k, v in kwargs.items() if v is not None}
        params.setdefault("max_retries", 10)

        # Determine which adapter to use based on model ID prefix
        is_gemini = resolved_model_id.startswith("gemini-")
        is_bedrock = resolved_model_id.startswith("us.anthropic.")

        if is_bedrock:
            # Set default max_tokens as 64k output for Bedrock models
            # This is critical for generating large summaries
            if "max_tokens" not in params:
                params["max_tokens"] = 64000
            # Use AWS Bedrock adapter for models like "us.anthropic.claude-*"
            # Note: ChatAWSBedrock doesn't support max_retries parameter
            bedrock_params = {k: v for k, v in params.items() if k != "max_retries"}
            bedrock_params["model"] = resolved_model_id
            # Pass boto3 Session (uses IAM role credentials in AWS environment)
            bedrock_params["session"] = self.get_boto3_session()
            # Cast to BaseChatModel - ChatAWSBedrockAdapter implements the same interface
            return cast(BaseChatModel, ChatAWSBedrockAdapter(**bedrock_params))
        elif is_gemini:
            # Use Gemini Vertex adapter for models like "gemini-*"
            project_id = os.getenv("VERTEX_PROJECT_ID") or VERTEX_PROJECT_ID
            if not project_id:
                raise ValueError(
                    "VERTEX_PROJECT_ID must be set via environment variable or constant"
                )
            params.update(
                {
                    "model": resolved_model_id,
                    "project_id": project_id,
                    "location": os.getenv("VERTEX_REGION") or VERTEX_REGION,
                }
            )
            return ChatGeminiVertex(**params)
        else:
            # Use Anthropic Vertex adapter for Claude models like "claude-*"
            project_id = os.getenv("VERTEX_PROJECT_ID") or VERTEX_PROJECT_ID
            if not project_id:
                raise ValueError(
                    "VERTEX_PROJECT_ID must be set via environment variable or constant"
                )
            params.update(
                {
                    "model": resolved_model_id,
                    "project_id": project_id,
                    "region": os.getenv("VERTEX_REGION") or VERTEX_REGION,
                }
            )
            return ChatAnthropicVertex(**params)

    def get_default_model_id(self) -> str:
        """Get the default model ID for this adapter.

        Returns:
            Default model identifier (Bedrock Sonnet on AWS, Gemini Flash elsewhere)
        """
        # Check explicit preference first
        provider = os.getenv("LLM_PROVIDER", "").lower()

        if provider == LLM_PROVIDER_BEDROCK:
            return BEDROCK_MODEL_ID_SONNET

        return VERTEX_MODEL_ID_GEMINI_FLASH

    def get_available_models(self) -> dict[str, str]:
        """Get available model IDs and their descriptions.

        Returns:
            Dictionary mapping model names to their identifiers
        """
        return {
            "vertex_haiku": VERTEX_MODEL_ID_HAIKU,
            "vertex_sonnet": VERTEX_MODEL_ID_SONNET,
            "bedrock_haiku": BEDROCK_MODEL_ID_HAIKU,
            "bedrock_sonnet": BEDROCK_MODEL_ID_SONNET,
            "gemini_pro": VERTEX_MODEL_ID_GEMINI_PRO,
            "gemini_flash": VERTEX_MODEL_ID_GEMINI_FLASH,
        }

    def create_strands_model(self, model_id: str | None = None) -> Any:
        """Create a Strands model instance for use with Strands agents.

        Uses LiteLLM to support multiple providers including Vertex AI.
        The model provider is determined by the model ID prefix.

        Args:
            model_id: Optional model ID override (defaults to get_default_model_id())

        Returns:
            Strands Model instance (LiteLLMModel or BedrockModel)
        """
        resolved_model_id = model_id or self.get_default_model_id()

        # Determine provider from model ID
        is_bedrock = resolved_model_id.startswith("us.anthropic.")
        is_gemini = resolved_model_id.startswith("gemini-")
        is_claude_vertex = resolved_model_id.startswith("claude-")

        if is_bedrock:
            # Use native BedrockModel for Bedrock models
            from strands.models import BedrockModel

            return BedrockModel(
                model_id=resolved_model_id,
                region_name=self.resolve_region(),
            )
        else:
            # Use LiteLLM for Vertex AI (both Gemini and Claude)
            from strands.models.litellm import LiteLLMModel

            # Build the LiteLLM model ID with vertex_ai prefix
            if is_gemini:
                # Gemini on Vertex AI: vertex_ai/gemini-3-flash-preview
                litellm_model_id = f"vertex_ai/{resolved_model_id}"
            elif is_claude_vertex:
                # Claude on Vertex AI: vertex_ai/claude-sonnet-4-5@20250929
                litellm_model_id = f"vertex_ai/{resolved_model_id}"
            else:
                # Fallback - assume it's a Vertex AI model
                litellm_model_id = f"vertex_ai/{resolved_model_id}"

            project_id = os.getenv("VERTEX_PROJECT_ID") or VERTEX_PROJECT_ID
            location = os.getenv("VERTEX_REGION") or VERTEX_REGION

            return LiteLLMModel(
                model_id=litellm_model_id,
                client_args={
                    "vertex_project": project_id,
                    "vertex_location": location,
                },
                params={
                    "max_tokens": 8192,
                },
            )


# Global adapter instance (set by application initialization)
_llm_adapter: LLMAdapter | None = None


def set_llm_adapter(adapter: LLMAdapter) -> None:
    """Set the global LLM adapter instance.

    This should be called during application initialization to configure
    which LLM provider to use.

    Args:
        adapter: The LLM adapter instance to use
    """
    global _llm_adapter
    _llm_adapter = adapter


def get_llm_adapter() -> LLMAdapter:
    """Get the current LLM adapter instance.

    Returns:
        The configured LLM adapter

    Raises:
        RuntimeError: If no adapter has been configured
    """
    if _llm_adapter is None:
        set_llm_adapter(LLMAdapter())

    assert _llm_adapter is not None
    return _llm_adapter


def create_chat_model(model_id: str | None = None, **kwargs: Any) -> BaseChatModel:
    """Create a chat model using the configured LLM adapter.

    This is the main entry point for creating chat models throughout the codebase.
    It delegates to the configured adapter.

    Args:
        model_id: Optional model identifier (adapter-specific)
        **kwargs: Additional configuration parameters

    Returns:
        BaseChatModel instance compatible with browser-use

    Example:
        >>> llm = create_chat_model()
        >>> llm = create_chat_model(model_id='sonnet')
    """
    adapter = get_llm_adapter()
    return adapter.create_chat_model(model_id=model_id, **kwargs)


__all__ = [
    "ChatAnthropicVertex",
    "ChatAWSBedrockAdapter",
    "ChatGeminiVertex",
    "LLMAdapter",
    "create_chat_model",
    "get_llm_adapter",
    "set_llm_adapter",
]
