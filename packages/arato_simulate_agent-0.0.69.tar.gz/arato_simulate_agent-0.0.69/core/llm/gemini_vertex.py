"""ChatGeminiVertex: Google Gemini via Google Gen AI SDK.

This module provides a browser-use compatible LLM adapter for using Google's Gemini
models through Google Cloud Vertex AI using the latest google-genai SDK.
"""

from dataclasses import dataclass, field
from typing import Any, TypeVar, overload

from browser_use.llm.base import BaseChatModel
from browser_use.llm.exceptions import ModelProviderError, ModelRateLimitError
from browser_use.llm.google.serializer import GoogleMessageSerializer
from browser_use.llm.messages import BaseMessage
from browser_use.llm.schema import SchemaOptimizer
from browser_use.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from google import genai
from google.api_core import exceptions as google_exceptions
from google.genai import types
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


@dataclass
class ChatGeminiVertex(BaseChatModel):
    """
    A wrapper around Google Gemini models via Google Gen AI SDK with Vertex AI.

    Example:
        llm = ChatGeminiVertex(
            model='gemini-3-flash-preview',
            project_id='your-gcp-project-id',
            location='global',
            max_tokens=8192,
        )
    """

    # Model configuration
    model: str
    max_tokens: int = 8192
    temperature: float | None = None
    top_p: float | None = None

    # Google Cloud Vertex AI parameters
    project_id: str | None = None
    location: str = "global"

    # Compatibility with base adapter
    max_retries: int = 10

    # Client instance (created lazily)
    _client: genai.Client = field(init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialize Google Gen AI client with Vertex AI."""
        self._client = genai.Client(
            vertexai=True,
            project=self.project_id,
            location=self.location,
        )

    @property
    def provider(self) -> str:
        return "gemini_vertex"

    @property
    def name(self) -> str:
        return self.model

    def _get_usage(self, usage_metadata: Any) -> ChatInvokeUsage | None:
        """Extract usage information from response."""
        if not usage_metadata:
            return None

        return ChatInvokeUsage(
            prompt_tokens=usage_metadata.prompt_token_count or 0,
            completion_tokens=usage_metadata.candidates_token_count or 0,
            total_tokens=usage_metadata.total_token_count or 0,
            prompt_cached_tokens=usage_metadata.cached_content_token_count or 0,
            prompt_cache_creation_tokens=None,
            prompt_image_tokens=None,
        )

    @overload
    async def ainvoke(
        self, messages: list[BaseMessage], output_format: None = None, **kwargs: Any
    ) -> ChatInvokeCompletion[str]: ...

    @overload
    async def ainvoke(
        self, messages: list[BaseMessage], output_format: type[T], **kwargs: Any
    ) -> ChatInvokeCompletion[T]: ...

    async def ainvoke(
        self,
        messages: list[BaseMessage],
        output_format: type[T] | None = None,
        **kwargs: Any,
    ) -> ChatInvokeCompletion[T] | ChatInvokeCompletion[str]:
        """Invoke the Gemini model with the given messages.

        Args:
            messages: List of conversation messages
            output_format: Optional Pydantic model for structured output
            **kwargs: Additional arguments (e.g., session_id for browser-use 0.11.2+)

        Returns:
            ChatInvokeCompletion with response text or structured output
        """
        # Use browser-use's GoogleMessageSerializer for proper message handling
        # This ensures system messages and content are formatted correctly
        contents, system_instruction = GoogleMessageSerializer.serialize_messages(
            list(messages)
        )

        # Build config
        config_dict: dict[str, Any] = {}

        # Set system instruction if present
        if system_instruction:
            config_dict["system_instruction"] = system_instruction

        if self.max_tokens is not None:
            config_dict["max_output_tokens"] = self.max_tokens

        if self.temperature is not None:
            config_dict["temperature"] = self.temperature

        if self.top_p is not None:
            config_dict["top_p"] = self.top_p

        # Type cast for mypy - list[Content] is valid ContentListUnion
        contents_arg: types.ContentListUnion = contents

        try:
            if output_format is None:
                # Normal text completion
                response = await self._client.aio.models.generate_content(
                    model=self.model,
                    contents=contents_arg,
                    config=types.GenerateContentConfig(**config_dict)
                    if config_dict
                    else None,
                )

                # Extract text from response
                if not response.candidates:
                    raise ModelProviderError(
                        message="No candidates in response",
                        status_code=500,
                        model=self.name,
                    )

                candidate = response.candidates[0]
                # Safely extract text - content or parts may be None
                if not candidate.content or not candidate.content.parts:
                    raise ModelProviderError(
                        message="Empty content in response candidate",
                        status_code=500,
                        model=self.name,
                    )
                response_text = candidate.content.parts[0].text
                if response_text is None:
                    raise ModelProviderError(
                        message="Response text is None",
                        status_code=500,
                        model=self.name,
                    )

                # Extract usage
                usage = self._get_usage(response.usage_metadata)

                # Map finish_reason
                finish_reason_map = {
                    "STOP": "end_turn",
                    "MAX_TOKENS": "max_tokens",
                    "SAFETY": "safety",
                    "RECITATION": "recitation",
                    "OTHER": "other",
                }
                stop_reason = finish_reason_map.get(
                    str(candidate.finish_reason) if candidate.finish_reason else "STOP",
                    "unknown",
                )

                return ChatInvokeCompletion(
                    completion=response_text, usage=usage, stop_reason=stop_reason
                )

            else:
                # Structured output using response schema
                schema = SchemaOptimizer.create_optimized_json_schema(output_format)

                # Remove title if present
                if "title" in schema:
                    del schema["title"]

                # Add response schema to config
                config_dict["response_mime_type"] = "application/json"
                config_dict["response_schema"] = schema

                response = await self._client.aio.models.generate_content(
                    model=self.model,
                    contents=contents_arg,
                    config=types.GenerateContentConfig(**config_dict),
                )

                # Extract and parse structured output
                if not response.candidates:
                    raise ModelProviderError(
                        message="No candidates in response",
                        status_code=500,
                        model=self.name,
                    )

                candidate = response.candidates[0]
                # Safely extract text - content or parts may be None
                if not candidate.content or not candidate.content.parts:
                    raise ModelProviderError(
                        message="Empty content in response candidate",
                        status_code=500,
                        model=self.name,
                    )
                response_text = candidate.content.parts[0].text

                # Parse JSON response into Pydantic model
                try:
                    result = output_format.model_validate_json(response_text)  # type: ignore[arg-type]
                except Exception as e:
                    raise ModelProviderError(
                        message=f"Failed to validate structured output: {str(e)}",
                        status_code=500,
                        model=self.name,
                    ) from e

                usage = self._get_usage(response.usage_metadata)

                finish_reason_map = {
                    "STOP": "end_turn",
                    "MAX_TOKENS": "max_tokens",
                    "SAFETY": "safety",
                    "RECITATION": "recitation",
                    "OTHER": "other",
                }
                stop_reason = finish_reason_map.get(
                    str(candidate.finish_reason) if candidate.finish_reason else "STOP",
                    "unknown",
                )

                return ChatInvokeCompletion(
                    completion=result, usage=usage, stop_reason=stop_reason
                )

        except google_exceptions.ResourceExhausted as e:
            raise ModelRateLimitError(
                message=f"Rate limit exceeded: {str(e)}",
                status_code=429,
                model=self.name,
            ) from e
        except google_exceptions.GoogleAPIError as e:
            status_code = getattr(e, "code", 500)
            raise ModelProviderError(
                message=f"Gemini API error: {str(e)}",
                status_code=status_code,
                model=self.name,
            ) from e
        except Exception as e:
            raise ModelProviderError(
                message=f"Unexpected error: {str(e)}",
                status_code=500,
                model=self.name,
            ) from e
