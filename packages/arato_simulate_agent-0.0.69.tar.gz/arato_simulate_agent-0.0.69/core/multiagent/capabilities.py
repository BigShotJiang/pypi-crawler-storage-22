"""
Agent capabilities and card definitions.

Defines the capability enum and agent card dataclass for sub-agent registration.
"""

from dataclasses import dataclass, field
from enum import Enum, auto


class Capability(Enum):
    """Capabilities that sub-agents can implement."""

    EVALUATE_TURN = auto()  # Per-turn evaluation
    SUMMARIZE_CONVERSATION = auto()  # Per-persona summary
    SUMMARIZE_RUN = auto()  # Cross-persona summary


@dataclass
class AgentCard:
    """A2A-inspired agent capability declaration.

    Attributes:
      agent_id: Unique identifier for the agent
      name: Human-readable name
      description: Description of what the agent does
      capabilities: Set of capabilities this agent supports
      version: Agent version string
      tags: Optional tags for categorization
      domains: List of domains this agent applies to. Empty = generic (always runs).
               Domain-specific agents only run when their domain is detected.
               Examples: ['travel'], ['hr', 'employment'], ['ecommerce', 'retail']
    """

    agent_id: str
    name: str
    description: str
    capabilities: set[Capability]
    version: str = "1.0.0"
    tags: list[str] = field(default_factory=list)
    domains: list[str] = field(default_factory=list)

    def has_capability(self, capability: Capability) -> bool:
        """Check if this agent has a specific capability."""
        return capability in self.capabilities

    def is_generic(self) -> bool:
        """Check if this is a generic agent (runs for all domains)."""
        return len(self.domains) == 0

    def applies_to_domains(self, detected_domains: set[str]) -> bool:
        """Check if this agent should run based on detected domains.

        Args:
            detected_domains: Set of domain keywords detected from app_context

        Returns:
            True if agent should run (generic or matching domain)
        """
        if self.is_generic():
            return True
        # Check if any of the agent's domains match the detected domains
        return bool(set(self.domains) & detected_domains)

    def __hash__(self) -> int:
        return hash(self.agent_id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, AgentCard):
            return False
        return self.agent_id == other.agent_id
