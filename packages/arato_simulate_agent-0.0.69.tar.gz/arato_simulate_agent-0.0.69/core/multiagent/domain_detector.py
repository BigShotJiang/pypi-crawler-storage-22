"""
Domain detection from app_context.

This module provides LLM-based detection of application domains from the
app_context text, enabling domain-specific agents to run only when relevant.
"""

import json
import logging

from browser_use.llm.messages import SystemMessage, UserMessage
from json_repair import repair_json

from core.llm import create_chat_model

logger = logging.getLogger(__name__)

# Known vertical domains that domain-specific agents can declare
KNOWN_DOMAINS = {
    "travel",  # Travel booking, airlines, hotels, tourism
    "hr",  # Human resources, employment, payroll, benefits
    "insurance",  # Insurance policies, claims, coverage
    "ecommerce",  # E-commerce, retail, shopping, products
    "tech_support",  # Technical support, IT help desk, troubleshooting
    "finance",  # Banking, investments, financial services
    "healthcare",  # Medical, health, clinical, pharmacy
    "education",  # Learning, courses, schools, training
    "real_estate",  # Property, housing, rentals, mortgages
    "legal",  # Law, legal services, contracts
    "food",  # Restaurants, food delivery, recipes
    "entertainment",  # Media, streaming, gaming, events
}


DOMAIN_DETECTION_PROMPT = """Analyze the following application context and identify which business domains this application belongs to.

Known domains to consider:
- travel: Travel booking, airlines, hotels, tourism, vacation planning
- hr: Human resources, employment, payroll, benefits, workplace policies
- insurance: Insurance policies, claims, coverage, premiums, underwriting
- ecommerce: E-commerce, retail, shopping, products, orders, inventory
- tech_support: Technical support, IT help desk, troubleshooting, software issues
- finance: Banking, investments, financial services, trading, payments
- healthcare: Medical, health, clinical, pharmacy, patient care
- education: Learning, courses, schools, training, academic
- real_estate: Property, housing, rentals, mortgages, real estate
- legal: Law, legal services, contracts, compliance
- food: Restaurants, food delivery, recipes, catering
- entertainment: Media, streaming, gaming, events, concerts

Return a JSON object with:
- "domains": array of domain names that apply (from the list above)
- "confidence": 0-1 confidence score
- "reasoning": brief explanation

Only include domains that clearly apply based on the context. If the application
is very generic or doesn't fit any specific domain, return an empty domains array.

APPLICATION CONTEXT:
{app_context}

Respond ONLY with valid JSON, no markdown formatting."""


class DomainDetector:
    """Detects application domains from app_context text using LLM analysis."""

    def __init__(self, model_id: str | None = None) -> None:
        """Initialize the domain detector.

        Args:
            model_id: Optional LLM model ID to use
        """
        self._model_id = model_id
        self._llm = None
        self._cache: dict[int, set[str]] = {}

    def _get_llm(self):
        """Lazy-load the LLM."""
        if self._llm is None:
            self._llm = create_chat_model(model_id=self._model_id)
        return self._llm

    def _get_cache_key(self, app_context: str) -> int:
        """Generate a cache key from app_context."""
        # Use first 2000 chars for caching to handle very long contexts
        return hash(app_context[:2000] if len(app_context) > 2000 else app_context)

    async def detect_domains(self, app_context: str | None) -> set[str]:
        """Detect domains from app_context text.

        Args:
            app_context: The application context text (markdown)

        Returns:
            Set of detected domain names
        """
        if not app_context or not app_context.strip():
            logger.info(
                "No app_context provided for domain detection, returning empty domains"
            )
            return set()

        logger.info(f"Detecting domains from app_context ({len(app_context)} chars)...")

        # Check cache
        cache_key = self._get_cache_key(app_context)
        if cache_key in self._cache:
            logger.info(f"Domain detection cache hit: {self._cache[cache_key]}")
            return self._cache[cache_key]

        try:
            llm = self._get_llm()
            prompt = DOMAIN_DETECTION_PROMPT.format(app_context=app_context[:4000])

            messages = [
                SystemMessage(content="You are a domain classification expert."),
                UserMessage(content=prompt),
            ]

            response = await llm.ainvoke(messages)
            content = (
                response.content if hasattr(response, "content") else str(response)
            )

            # Handle empty response
            if not content or not content.strip():
                logger.warning("Empty response from LLM for domain detection")
                self._cache[cache_key] = set()
                return set()

            # Use json_repair to handle malformed JSON (markdown, trailing commas, etc.)
            repaired = repair_json(content)
            result = json.loads(repaired)
            raw_domains = result.get("domains", [])

            # Handle case where LLM returns a string instead of array
            if isinstance(raw_domains, str):
                # Split comma-separated string or treat as single domain
                raw_domains = [d.strip() for d in raw_domains.split(",") if d.strip()]

            # Filter out invalid entries (single chars, empty strings, etc.)
            domains = set()
            for d in raw_domains if isinstance(raw_domains, list) else []:
                # Domain must be at least 2 chars and be a valid known domain format
                if isinstance(d, str) and len(d) >= 2:
                    domains.add(d.lower().strip())

            # Validate domains against known list
            valid_domains = domains & KNOWN_DOMAINS
            if domains != valid_domains:
                unknown = domains - KNOWN_DOMAINS
                logger.warning(f"Unknown domains detected and ignored: {unknown}")

            logger.info(
                f"Detected domains: {valid_domains} "
                f"(confidence: {result.get('confidence', 'unknown')})"
            )

            # Cache result
            self._cache[cache_key] = valid_domains
            return valid_domains

        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse domain detection response: {e}")
            return set()
        except Exception as e:
            logger.warning(f"Domain detection failed: {e}")
            return set()

    def clear_cache(self) -> None:
        """Clear the domain detection cache."""
        self._cache.clear()


# Global singleton for domain detection
_detector: DomainDetector | None = None


def get_domain_detector() -> DomainDetector:
    """Get the global domain detector instance."""
    global _detector
    if _detector is None:
        _detector = DomainDetector()
    return _detector


async def detect_domains_from_context(app_context: str | None) -> set[str]:
    """Convenience function to detect domains from app_context.

    Args:
        app_context: The application context text

    Returns:
        Set of detected domain names
    """
    detector = get_domain_detector()
    return await detector.detect_domains(app_context)
