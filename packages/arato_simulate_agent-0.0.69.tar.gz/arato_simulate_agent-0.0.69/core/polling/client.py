"""Core polling client for fetching tasks from Arato API."""

import asyncio
import logging
import threading
from datetime import UTC, datetime, timedelta
from typing import Any, cast

import httpx

from core.schemas import (
    AgentCommandResponse,
    TaskPayload,
    TaskResult,
    TaskStatus,
    TaskUpdate,
)

logger = logging.getLogger(__name__)


class CircuitBreaker:
    """Simple circuit breaker for API failures."""

    def __init__(self, failure_threshold: int = 5, timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout  # seconds
        self.failure_count = 0
        self.last_failure_time: datetime | None = None
        self.state = "closed"  # closed, open, half-open
        self._lock = threading.Lock()

    def record_success(self) -> None:
        """Record successful API call."""
        with self._lock:
            self.failure_count = 0
            self.state = "closed"

    def record_failure(self) -> None:
        """Record failed API call."""
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = datetime.now(UTC)

            if self.failure_count >= self.failure_threshold:
                self.state = "open"
                logger.warning(
                    f"Circuit breaker opened after {self.failure_count} failures"
                )

    def is_open(self) -> bool:
        """Check if circuit breaker is open."""
        with self._lock:
            if self.state == "open":
                # Check if timeout has passed
                if self.last_failure_time and datetime.now(
                    UTC
                ) - self.last_failure_time > timedelta(seconds=self.timeout):
                    self.state = "half-open"
                    logger.info("Circuit breaker entering half-open state")
                    return False
                return True
            return False


class TaskPollingClient:
    """HTTP client for task polling with circuit breaker for resilience."""

    def __init__(
        self,
        task_endpoint: str,
        api_key: str,
        agent_name: str,
        agent_platform: str,
        timeout: float = 10.0,
    ):
        """Initialize polling client.

        Args:
            task_endpoint: Full task endpoint URL (e.g., https://api.arato.ai/task)
            api_key: API key for authentication
            agent_name: Name or identifier of the agent
            agent_platform: Platform or runtime environment (e.g., 'aws_agentcore', 'local')
            timeout: Request timeout in seconds
        """
        self.task_endpoint = task_endpoint
        self.api_key = api_key
        self.agent_name = agent_name
        self.agent_platform = agent_platform
        self.circuit_breaker = CircuitBreaker()

        self.client = httpx.AsyncClient(
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "x-agent-name": agent_name,
                "x-agent-platform": agent_platform,
            },
        )

        logger.info("Polling client initialized:")
        logger.info(f"  Task endpoint: {self.task_endpoint}")

    async def poll_task(self) -> TaskPayload | None:
        """Poll for next available task."""
        if self.circuit_breaker.is_open():
            logger.warning("Circuit breaker open, skipping poll")
            return None

        try:
            response = await self.client.get(self.task_endpoint)

            if response.status_code in (204, 404):
                logger.debug(f"No tasks available ({response.status_code})")
                self.circuit_breaker.record_success()
                return None

            response.raise_for_status()
            raw = response.json()
            if not raw or not isinstance(raw, dict):
                logger.debug("No tasks available (empty response)")
                self.circuit_breaker.record_success()
                return None

            try:
                task: TaskPayload = TaskPayload.model_validate(raw)
                logger.info(f"📥 Received task {task.task_id} (validated)")
                self.circuit_breaker.record_success()
                return task
            except Exception as e:
                logger.error(f"Task payload validation failed (discarding): {e}")
                self.circuit_breaker.record_failure()
                return None
        except httpx.TimeoutException as e:
            self.circuit_breaker.record_failure()
            logger.warning(f"Polling timeout (will retry): {e.__class__.__name__}")
            return None
        except httpx.ConnectError as e:
            self.circuit_breaker.record_failure()
            logger.warning(f"Connection error (will retry): {e}")
            return None
        except httpx.HTTPError as e:
            self.circuit_breaker.record_failure()
            logger.error(f"Failed to poll for tasks: {e}")
            return None

    async def update_task(
        self,
        update: TaskUpdate,
        max_retries: int = 3,
        base_delay: float = 0.5,
    ) -> dict[str, Any]:
        """Update task status (and optionally results) back to API with retry/backoff."""
        payload = update.model_dump(by_alias=True)

        attempt = 0
        delay = base_delay
        last_exc: Exception | None = None
        while attempt < max_retries:
            logger.info(
                f"Updating task at {self.task_endpoint} with payload: {payload}"
            )
            try:
                response = await self.client.post(self.task_endpoint, json=payload)
                response.raise_for_status()
                data = response.json()
                if not isinstance(data, dict):
                    logger.error("Unexpected non-dict response for task update")
                    self.circuit_breaker.record_failure()
                    raise httpx.HTTPError("Invalid response payload type")
                self.circuit_breaker.record_success()
                return cast(dict[str, Any], data)
            except httpx.HTTPError as e:
                last_exc = e
                self.circuit_breaker.record_failure()
                attempt += 1
                if attempt >= max_retries:
                    logger.error(f"Task update failed after {attempt} attempts: {e}")
                    raise
                logger.warning(
                    f"Task update attempt {attempt} failed (will retry in {delay:.2f}s): {e}"
                )
                await asyncio.sleep(delay)
                delay = min(delay * 2, 60.0)  # Cap at 60 seconds
        if last_exc:
            raise last_exc
        raise httpx.HTTPError("Task update failed without exception context")

    async def _send_task_update(
        self,
        task: TaskPayload,
        status: TaskStatus,
        result: TaskResult | None = None,
    ) -> dict[str, Any]:
        """Internal method to send task updates with any status.

        Args:
            task: TaskPayload instance
            status: Task status to send
            result: Optional TaskResult with additional data

        Returns:
            Response from API
        """
        if not task.task_id:
            raise ValueError(f"Task must have a task_id to update status to {status}")

        # Ensure result status matches the update status
        if result:
            result.status = status

        update = TaskUpdate(
            task_id=task.task_id,
            status=status,
            _receipt_handle=task.receipt_handle,
            result=result,
        )
        return await self.update_task(update)

    async def mark_active(
        self, task: TaskPayload, agent_identity: Any = None
    ) -> AgentCommandResponse:
        """Mark task as active (agent is now processing it).

        Args:
            task: TaskPayload instance
            agent_identity: AgentIdentity with agent name and platform (for task body)

        Returns:
            AgentCommandResponse with command (CONTINUE or STOP) from the API
        """
        result = TaskResult(
            status=TaskStatus.ACTIVE,
            agent_identity=agent_identity,
        )
        response_data = await self._send_task_update(task, TaskStatus.ACTIVE, result)
        return AgentCommandResponse(**response_data)

    async def mark_complete(
        self, task: TaskPayload, result: TaskResult
    ) -> dict[str, Any]:
        """Mark task as complete with results."""
        return await self._send_task_update(task, TaskStatus.COMPLETE, result)

    async def mark_wait(
        self, task: TaskPayload, agent_identity: Any = None
    ) -> dict[str, Any]:
        """Mark task as waiting (agent paused, will resume later).

        Args:
            task: TaskPayload instance
            agent_identity: AgentIdentity with agent name and platform (for task body)
        """
        result = TaskResult(
            status=TaskStatus.WAIT,
            agent_identity=agent_identity,
        )
        return await self._send_task_update(task, TaskStatus.WAIT, result)

    async def send_progress_update(
        self, task: TaskPayload, partial_result: TaskResult
    ) -> AgentCommandResponse:
        """Send incremental progress update with partial results.

        This should be called during task execution to provide real-time updates
        about progress, artifacts, and intermediate results. The status will remain
        ACTIVE while sending partial results.

        Args:
            task: TaskPayload instance
            partial_result: TaskResult with partial/incremental data (status should be ACTIVE)

        Returns:
            AgentCommandResponse with command (CONTINUE or STOP) from the API
        """
        response_data = await self._send_task_update(
            task, TaskStatus.ACTIVE, partial_result
        )
        return AgentCommandResponse(**response_data)

    def derive_log_endpoint(self, task_id: str) -> str:
        """Derive log endpoint from task_id.

        Format: <server url>/<task_id>/log
        Example: https://5661-api.pr.arato.dev/api/task -> https://5661-api.pr.arato.dev/abc123/log

        Args:
            task_id: Task identifier

        Returns:
            Log endpoint URL
        """
        # Remove /api/task or /task suffix and append /{task_id}/log
        base_url = self.task_endpoint.removesuffix("/api/task").removesuffix("/task")

        log_endpoint = f"{base_url}/{task_id}/log"
        logger.debug(f"Derived log endpoint: {log_endpoint}")
        return log_endpoint

    def inject_logging_config(self, task: TaskPayload) -> TaskPayload:
        """
        Inject logging configuration into task if not present.

        Derives log endpoint from task_id: <server url>/<task_id>/log

        Args:
            task: Task payload (must have task_id)

        Returns:
            Task with logging config injected

        Raises:
            ValueError: If task_id is missing
        """
        if not task.task_id:
            raise ValueError("Cannot inject logging config: task_id is required")

        # Convert to dict for modification
        raw = task.model_dump()

        # Derive log endpoint from task_id if not already set
        if not task.arato_api_url:
            raw["arato_api_url"] = self.derive_log_endpoint(task.task_id)

        # Inject API key if not present
        if not task.arato_api_key:
            raw["arato_api_key"] = self.api_key

        # Return validated payload
        result: TaskPayload = TaskPayload.model_validate(raw)
        return result

    def _derive_hitl_endpoint(self) -> str:
        """Derive HITL endpoint from task_endpoint.

        Format: replace /task suffix with /hitl
        Example: .../api/v1/agent-connect/task -> .../api/v1/agent-connect/hitl
        """
        base = self.task_endpoint.removesuffix("/task")
        return base.rstrip("/") + "/hitl"

    async def notify_hitl(
        self,
        task_id: str,
        intervention_type: str,
        reason: str,
        timeout_seconds: int,
        url_before: str | None = None,
        screenshot_url: str | None = None,
        agentcore_session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Notify the server that the agent needs HITL intervention.

        Args:
            task_id: Agent run / task ID
            intervention_type: Type of intervention (captcha, login, etc.)
            reason: Human-readable reason for intervention
            timeout_seconds: Timeout for the intervention
            url_before: URL before intervention
            screenshot_url: Screenshot URL
            agentcore_session_id: AgentCore browser session ID for DCV
            metadata: Additional metadata

        Returns:
            Server response with intervention_id and state
        """
        endpoint = self._derive_hitl_endpoint()
        payload: dict[str, Any] = {
            "task_id": task_id,
            "intervention_type": intervention_type,
            "reason": reason,
            "timeout_seconds": timeout_seconds,
        }
        if url_before:
            payload["url_before"] = url_before
        if screenshot_url:
            payload["screenshot_url"] = screenshot_url
        if agentcore_session_id:
            payload["agentcore_session_id"] = agentcore_session_id
        if metadata:
            payload["metadata"] = metadata

        logger.info(f"Notifying server of HITL intervention at {endpoint}")
        try:
            response = await self.client.post(endpoint, json=payload)
            response.raise_for_status()
            data = response.json()
            logger.info(f"HITL intervention created: {data}")
            self.circuit_breaker.record_success()
            return cast(dict[str, Any], data)
        except httpx.HTTPError as e:
            self.circuit_breaker.record_failure()
            logger.error(f"Failed to notify HITL intervention: {e}")
            raise

    async def poll_hitl_state(self, intervention_id: str) -> dict[str, Any]:
        """Poll the server for the current state of an HITL intervention.

        Args:
            intervention_id: The intervention ID to check

        Returns:
            Server response with id, state, completed_at, url_after, error_message
        """
        endpoint = f"{self._derive_hitl_endpoint()}/{intervention_id}"
        try:
            response = await self.client.get(endpoint)
            response.raise_for_status()
            data = response.json()
            self.circuit_breaker.record_success()
            return cast(dict[str, Any], data)
        except httpx.HTTPError as e:
            self.circuit_breaker.record_failure()
            logger.error(f"Failed to poll HITL state for {intervention_id}: {e}")
            raise

    async def notify_hitl_timeout(self, intervention_id: str) -> None:
        """Notify the server that an HITL intervention has timed out.

        Args:
            intervention_id: The intervention ID that timed out
        """
        endpoint = f"{self._derive_hitl_endpoint()}/{intervention_id}/timeout"
        logger.info(f"Notifying server of HITL timeout: {intervention_id}")
        try:
            response = await self.client.post(endpoint)
            response.raise_for_status()
            self.circuit_breaker.record_success()
            logger.info(f"HITL timeout recorded for {intervention_id}")
        except httpx.HTTPError as e:
            self.circuit_breaker.record_failure()
            logger.error(f"Failed to notify HITL timeout for {intervention_id}: {e}")
            raise

    async def close(self) -> None:
        """Close HTTP client."""
        await self.client.aclose()
