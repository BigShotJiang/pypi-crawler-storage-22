"""Configuration for polling mode."""

import os
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class PollingConfig:
    """Configuration for task polling."""

    task_endpoint: str
    api_key: str
    polling_interval: int = 5  # seconds

    @classmethod
    def from_env(cls) -> Optional["PollingConfig"]:
        """
        Load config from environment variables.

        Environment variables:
            ARATO_TASK_ENDPOINT: Task polling endpoint (default: http://localhost:3000/api/v1/agent-connect/task)
            ARATO_API_KEY: API key for authentication (required)
            ARATO_POLLING_INTERVAL: Polling interval in seconds (default: 5)

        Returns:
            PollingConfig if ARATO_API_KEY is set, None otherwise
        """
        api_key = os.getenv("ARATO_API_KEY")

        if not api_key:
            return None

        task_endpoint = os.getenv(
            "ARATO_TASK_ENDPOINT", "http://localhost:3000/api/v1/agent-connect/task"
        )
        polling_interval = int(os.getenv("ARATO_POLLING_INTERVAL", "5"))

        return cls(
            task_endpoint=task_endpoint,
            api_key=api_key,
            polling_interval=polling_interval,
        )
