"""Observability utilities for polling mode with structured logging and metrics."""

import logging
import uuid
from datetime import UTC, datetime

logger = logging.getLogger(__name__)


class PollingObservability:
    """Observability helpers for polling operations."""

    @staticmethod
    def generate_correlation_id() -> str:
        """Generate unique correlation ID for request tracing."""
        return str(uuid.uuid4())

    @staticmethod
    def log_poll_started(correlation_id: str, endpoint: str) -> None:
        """Log polling attempt."""
        logger.info(
            "polling.started",
            extra={
                "correlation_id": correlation_id,
                "endpoint": endpoint,
                "timestamp": datetime.now(UTC).isoformat(),
            },
        )

    @staticmethod
    def log_poll_no_tasks(correlation_id: str, status_code: int) -> None:
        """Log no tasks available."""
        logger.debug(
            "polling.no_tasks",
            extra={"correlation_id": correlation_id, "status_code": status_code},
        )

    @staticmethod
    def log_poll_task_received(correlation_id: str, task_fields: int) -> None:
        """Log task received."""
        logger.info(
            "polling.task_received",
            extra={"correlation_id": correlation_id, "task_fields": task_fields},
        )

    @staticmethod
    def log_poll_error(correlation_id: str, error: Exception) -> None:
        """Log polling error."""
        logger.error(
            "polling.error",
            extra={
                "correlation_id": correlation_id,
                "error": str(error),
                "error_type": type(error).__name__,
            },
        )

    @staticmethod
    def log_task_execution_started(
        task_id: str, target_url: str, personas: str
    ) -> None:
        """Log task execution start."""
        logger.info(
            "task.execution.started",
            extra={"task_id": task_id, "target_url": target_url, "personas": personas},
        )

    @staticmethod
    def log_task_execution_completed(
        task_id: str, session_id: str, duration_seconds: float
    ) -> None:
        """Log task execution completion."""
        logger.info(
            "task.execution.completed",
            extra={
                "task_id": task_id,
                "session_id": session_id,
                "duration_seconds": duration_seconds,
            },
        )

    @staticmethod
    def log_task_execution_failed(task_id: str, error: Exception) -> None:
        """Log task execution failure."""
        logger.error(
            "task.execution.failed",
            extra={
                "task_id": task_id,
                "error": str(error),
                "error_type": type(error).__name__,
            },
        )

    @staticmethod
    def log_duplicate_task(task_hash: str) -> None:
        """Log duplicate task detection."""
        logger.warning("task.duplicate", extra={"task_hash": task_hash[:8]})


class AWSCloudWatchMetrics:
    """Publish metrics to AWS CloudWatch."""

    def __init__(self, region: str = "us-east-1"):
        try:
            import boto3

            self.cloudwatch = boto3.client("cloudwatch", region_name=region)
            self.enabled = True
        except Exception as e:
            logger.warning(f"CloudWatch metrics disabled: {e}")
            self.enabled = False

    def publish_metric(
        self, metric_name: str, value: float, unit: str = "Count"
    ) -> None:
        """Publish custom metric to CloudWatch."""
        if not self.enabled:
            return

        try:
            self.cloudwatch.put_metric_data(
                Namespace="AratoAgent/Polling",
                MetricData=[
                    {
                        "MetricName": metric_name,
                        "Value": value,
                        "Unit": unit,
                        "Timestamp": datetime.now(UTC),
                    }
                ],
            )
        except Exception as e:
            logger.warning(f"Failed to publish metric {metric_name}: {e}")

    def record_poll_attempt(self) -> None:
        """Record polling attempt."""
        self.publish_metric("PollAttempts", 1)

    def record_no_tasks(self) -> None:
        """Record no tasks available."""
        self.publish_metric("NoTasksAvailable", 1)

    def record_task_received(self) -> None:
        """Record task received."""
        self.publish_metric("TasksReceived", 1)

    def record_task_completed(self, duration_seconds: float) -> None:
        """Record task completion."""
        self.publish_metric("TasksCompleted", 1)
        self.publish_metric("TaskDuration", duration_seconds, "Seconds")

    def record_task_failed(self) -> None:
        """Record task failure."""
        self.publish_metric("TasksFailed", 1)
