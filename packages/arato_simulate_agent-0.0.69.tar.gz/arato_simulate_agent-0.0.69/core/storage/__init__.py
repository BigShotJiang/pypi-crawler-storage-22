"""Storage abstractions for platform-independent artifact and cache management."""

from core.storage.base import (
    StorageAdapter,
    delete_domain_cache,
    download_discovery_artifacts,
    download_domain_cache,
    download_ground_truth_cache,
    get_storage_adapter,
    set_storage_adapter,
    upload_domain_cache,
    upload_ground_truth_cache,
    upload_persona_artifacts,
    upload_session_artifacts,
)

__all__ = [
    "StorageAdapter",
    "delete_domain_cache",
    "download_discovery_artifacts",
    "download_domain_cache",
    "download_ground_truth_cache",
    "get_storage_adapter",
    "set_storage_adapter",
    "upload_domain_cache",
    "upload_ground_truth_cache",
    "upload_persona_artifacts",
    "upload_session_artifacts",
]
