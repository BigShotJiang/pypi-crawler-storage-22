"""Abstract storage interface for artifacts and caching.

This module provides a platform-agnostic storage interface that can be
implemented for different storage backends (S3, local filesystem, etc.).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Protocol

from constants import APP_CONTEXT_FILENAME, GROUND_TRUTH_FILENAME


class StorageBackend(Protocol):
    """Protocol defining the interface that all storage backends must implement."""

    def upload_artifacts(
        self,
        directory: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, str | dict[str, str]]:
        """Upload all files in a directory to storage."""
        ...

    def download_cache(
        self,
        domain: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
    ) -> str | None:
        """Download a cached file from storage."""
        ...

    def upload_cache(
        self,
        domain: str,
        content: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
    ) -> bool:
        """Upload a file to cache storage."""
        ...


class StorageAdapter(ABC):
    """Abstract base class for storage adapters.

    Each adapter implements platform-specific logic for storing and retrieving
    artifacts while exposing a consistent interface.
    """

    @abstractmethod
    def upload_artifacts(
        self,
        directory: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, str | dict[str, str]]:
        """Upload all files in a directory to storage.

        Args:
            directory: Path to directory containing artifacts
            session_id: Optional session identifier
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            Dictionary with storage location information and file mappings:
            - Standard keys: bucket, prefix, location, etc. (for backward compatibility)
            - file_urls: Dict mapping relative file paths to their full storage URLs
        """
        pass

    @abstractmethod
    def upload_progress_file(
        self,
        progress_file_path: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload only the progress.json file to storage.

        This method is optimized for frequent updates during execution,
        uploading only the progress file rather than all artifacts.

        Args:
            progress_file_path: Path to the progress.json file
            session_id: Optional session identifier
            org_id: Optional organization ID for multi-tenant storage
            task_id: Optional task identifier

        Returns:
            Storage URL of the uploaded progress file, or None if upload failed
        """
        pass

    @abstractmethod
    def upload_persona_artifacts(
        self,
        persona_directory: str,
        persona_instance_name: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, str]:
        """Upload artifacts for a single persona instance immediately after completion.

        Args:
            persona_directory: Path to persona's artifact directory
            persona_instance_name: Name of the persona instance (e.g., "boundary_user_01")
            session_id: Optional session identifier
            org_id: Optional organization ID
            task_id: Optional task identifier

        Returns:
            Dictionary mapping relative file paths to storage URLs
        """
        pass

    @abstractmethod
    def download_cache(
        self,
        domain: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
    ) -> str | None:
        """Download a cached file from storage.

        Args:
            domain: Domain name
            cache_key: Cache file identifier
            org_id: Optional organization identifier for isolation

        Returns:
            File content as string if found, None otherwise
        """

    @abstractmethod
    def upload_cache(
        self,
        domain: str,
        content: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
    ) -> bool:
        """Upload a file to cache storage.

        Args:
            domain: Domain name
            content: File content to upload
            cache_key: Cache file identifier
            org_id: Optional organization identifier for isolation

        Returns:
            True if upload successful, False otherwise
        """

    @abstractmethod
    def delete_domain_cache(
        self,
        domain: str,
        org_id: str | None = None,
    ) -> bool:
        """Delete all cached files for a domain.

        Args:
            domain: Domain name
            org_id: Optional organization identifier for isolation

        Returns:
            True if deletion successful, False otherwise
        """

    @abstractmethod
    def download_discovery_artifacts(
        self,
        domain: str,
        org_id: str | None = None,
    ) -> dict[str, str | list[str] | None]:
        """Download all discovery artifacts for a domain.

        Returns a dict with:
        - app_context: app_context.json content or None
        - discovery_video: Path/URL to discovery.mp4 or None
        - screenshots: List of paths/URLs to screenshot files or empty list

        Args:
            domain: Domain name
            org_id: Optional organization identifier for isolation

        Returns:
            Dictionary with artifact content and paths
        """

    @abstractmethod
    def get_storage_location(self) -> str:
        """Get a human-readable description of the storage location.

        Returns:
            Storage location (e.g., 's3://bucket-name', '/tmp/artifacts')
        """
        pass

    @abstractmethod
    def upload_screenshot(
        self,
        screenshot_bytes: bytes,
        session_id: str,
        intervention_id: str,
        org_id: str | None = None,
    ) -> str | None:
        """Upload a screenshot image to storage.

        Args:
            screenshot_bytes: Raw screenshot image bytes (PNG format)
            session_id: Session identifier (can be domain name for discovery screenshots)
            intervention_id: Intervention identifier (can be descriptive name for discovery)
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            Public URL or storage path to the screenshot, None if upload failed
        """
        pass

    @abstractmethod
    def upload_discovery_screenshot(
        self,
        screenshot_bytes: bytes,
        domain: str,
        filename: str,
        org_id: str | None = None,
    ) -> str | None:
        """Upload a discovery screenshot to domain settings folder.

        Args:
            screenshot_bytes: Raw screenshot image bytes (PNG format)
            domain: Domain name (used for folder organization)
            filename: Screenshot filename (e.g., '20241112_123456_homepage.png')
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            Public URL or storage path to the screenshot, None if upload failed
        """
        pass

    @abstractmethod
    def upload_discovery_video(
        self,
        video_path: str,
        domain: str,
        filename: str,
        org_id: str | None = None,
    ) -> str | None:
        """Upload a discovery video to domain settings folder.

        Args:
            video_path: Path to video file on disk
            domain: Domain name (used for folder organization)
            filename: Video filename (e.g., 'discovery.mp4')
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            Public URL or storage path to the video, None if upload failed
        """
        pass


# Global storage adapter instance (set by application initialization)
_storage_adapter: StorageAdapter | None = None


def set_storage_adapter(adapter: StorageAdapter) -> None:
    """Set the global storage adapter instance.

    This should be called during application initialization to configure
    which storage backend to use.

    Args:
        adapter: The storage adapter instance to use
    """
    global _storage_adapter
    _storage_adapter = adapter


def get_storage_adapter() -> StorageAdapter:
    """Get the current storage adapter instance.

    Returns:
        The configured storage adapter

    Raises:
        RuntimeError: If no adapter has been configured
    """
    if _storage_adapter is None:
        # Auto-initialize with default implementation if not explicitly configured
        from platforms.aws_agentcore.storage import S3StorageAdapter

        set_storage_adapter(S3StorageAdapter())

    assert _storage_adapter is not None
    return _storage_adapter


def upload_session_artifacts(
    directory: str,
    session_id: str | None = None,
    org_id: str | None = None,
    task_id: str | None = None,
) -> dict[str, str | dict[str, str]]:
    """Upload session artifacts using the configured storage adapter.

    Args:
        directory: Path to directory containing artifacts
        session_id: Optional session identifier
        org_id: Optional organization ID
        task_id: Optional task identifier

    Returns:
        Storage location information with file URL mappings
    """
    adapter = get_storage_adapter()
    return adapter.upload_artifacts(directory, session_id, org_id, task_id)


def upload_persona_artifacts(
    persona_directory: str,
    persona_instance_name: str,
    session_id: str | None = None,
    org_id: str | None = None,
    task_id: str | None = None,
) -> dict[str, str]:
    """Upload persona artifacts using the configured storage adapter.

    Args:
        persona_directory: Path to persona's artifact directory
        persona_instance_name: Name of the persona instance
        session_id: Optional session identifier
        org_id: Optional organization ID
        task_id: Optional task identifier

    Returns:
        Dictionary mapping relative file paths to storage URLs
    """
    adapter = get_storage_adapter()
    return adapter.upload_persona_artifacts(
        persona_directory, persona_instance_name, session_id, org_id, task_id
    )


def download_domain_cache(
    domain: str,
    cache_key: str = APP_CONTEXT_FILENAME,
    org_id: str | None = None,
) -> str | None:
    """Download domain cache using the configured storage adapter.

    Args:
        domain: Domain name
        cache_key: Cache file identifier
        org_id: Optional organization ID

    Returns:
        File contents or None
    """
    adapter = get_storage_adapter()
    return adapter.download_cache(domain, cache_key, org_id)


def upload_domain_cache(
    domain: str,
    content: str,
    cache_key: str = APP_CONTEXT_FILENAME,
    org_id: str | None = None,
) -> bool:
    """Upload domain cache using the configured storage adapter.

    Args:
        domain: Domain name
        content: File content
        cache_key: Cache file identifier
        org_id: Optional organization ID

    Returns:
        True if successful
    """
    adapter = get_storage_adapter()
    return adapter.upload_cache(domain, content, cache_key, org_id)


def download_discovery_artifacts(
    domain: str,
    org_id: str | None = None,
) -> dict[str, str | list[str] | None]:
    """Download all discovery artifacts for a domain using the configured storage adapter.

    Args:
        domain: Domain name
        org_id: Optional organization ID

    Returns:
        Dictionary with artifact content and paths containing:
        - app_context: app_context.json content or None
        - discovery_video: Path/URL to discovery.mp4 or None
        - screenshots: List of paths/URLs to screenshot files or empty list
    """
    adapter = get_storage_adapter()
    return adapter.download_discovery_artifacts(domain, org_id)


def delete_domain_cache(
    domain: str,
    org_id: str | None = None,
) -> bool:
    """Delete all cached files for a domain using the configured storage adapter.

    Args:
        domain: Domain name
        org_id: Optional organization ID

    Returns:
        True if deletion successful, False otherwise
    """
    adapter = get_storage_adapter()
    return adapter.delete_domain_cache(domain, org_id)


def download_ground_truth_cache(
    domain: str,
    org_id: str | None = None,
) -> str | None:
    """Download ground truth cache for a domain.

    Args:
        domain: Domain name
        org_id: Optional organization ID

    Returns:
        Ground truth JSON content or None if not cached
    """
    adapter = get_storage_adapter()
    return adapter.download_cache(domain, GROUND_TRUTH_FILENAME, org_id)


def upload_ground_truth_cache(
    domain: str,
    content: str,
    org_id: str | None = None,
) -> bool:
    """Upload ground truth cache for a domain.

    Args:
        domain: Domain name
        content: Ground truth JSON content
        org_id: Optional organization ID

    Returns:
        True if successful
    """
    adapter = get_storage_adapter()
    return adapter.upload_cache(domain, content, GROUND_TRUTH_FILENAME, org_id)


__all__ = [
    "StorageAdapter",
    "StorageBackend",
    "delete_domain_cache",
    "download_domain_cache",
    "download_discovery_artifacts",
    "download_ground_truth_cache",
    "get_storage_adapter",
    "set_storage_adapter",
    "upload_domain_cache",
    "upload_ground_truth_cache",
    "upload_session_artifacts",
]
