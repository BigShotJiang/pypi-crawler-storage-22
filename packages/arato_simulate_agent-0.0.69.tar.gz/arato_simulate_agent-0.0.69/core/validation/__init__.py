"""
Validation framework for Arato.Agent.

This module provides base types for validation results used by sub-agents.
"""

from .base import Eval, EvalContext, EvalResult

__all__ = [
    "Eval",
    "EvalContext",
    "EvalResult",
]
