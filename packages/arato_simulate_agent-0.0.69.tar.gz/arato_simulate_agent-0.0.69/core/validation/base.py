"""
Base validation classes and types for the Arato validation framework.

This module defines the core interfaces and types used by all validation
implementations in the Arato.Agent platform.
"""

from abc import ABC, abstractmethod
from typing import TypedDict

from constants import (
    CATEGORY_ACCURACY,
    CATEGORY_FEATURE,
    CATEGORY_SECURITY,
    CATEGORY_UX,
    FINDING_CATEGORIES,
)

# Predefined evaluation categories
EVAL_CATEGORIES = {
    CATEGORY_UX: ["Relevance", "Clarity", "Tone", "Alignment"],
    CATEGORY_SECURITY: [
        "Injection",
        "Misuse",
        "Access Control",
        "Sensitive Data",
        "Regulated Content",
        "Brand Alignment",
    ],
    CATEGORY_ACCURACY: ["Fact Verification", "Hallucination", "Contradiction"],
    CATEGORY_FEATURE: [
        "Missing Functionality",
        "Integration Issue",
        "Error Handling",
    ],
}
# Ensure keys match FINDING_CATEGORIES
assert set(EVAL_CATEGORIES.keys()) == set(FINDING_CATEGORIES), (
    "EVAL_CATEGORIES keys must match FINDING_CATEGORIES"
)


class EvalResult(TypedDict, total=False):
    """Standardized validation result format.

    Note: Additional arbitrary fields can be added at runtime by casting to dict,
    similar to the **extra_data pattern in report_red_flag. This allows skills
    and validators to include domain-specific metadata (e.g., flow_name, flow_url)
    without polluting the base type definition.
    """

    # Required fields
    validation_id: str  # Unique identifier for the validation type naming on purpose compatible with ataol eval structure
    score: float  # Numerical score (0-100)
    result_explanation: str  # Short text explanation or reasoning
    confidence: float  # Confidence score (0-1)

    # Optional fields for red flag reporting
    category: str  # One of EVAL_CATEGORIES keys
    eval_type: str  # Type within category (extensible)
    red_flag_id: str | None  # Reference identifier for specific red flag

    # Optional fields for skill validation metadata
    skill_name: str | None  # Name of the skill that produced this result
    validation_details: str | None  # Additional validation details
    screenshot_path: str | None  # Path to validation screenshot


class EvalContext(TypedDict, total=False):
    """Context data passed to validation methods."""

    # Required fields
    user_message: str
    bot_response: str
    conversation_id: str
    turn_number: int

    # Optional fields
    model: str | None
    chat_url: str | None
    persona: str | None
    target_selectors: dict[str, str] | None
    error: str | None


class Eval(ABC):
    """
    Abstract base class for all validation implementations.

    Each validation should have a unique validation_id and implement
    the validate method to return a standardized ValidationResult.
    """

    validation_id: str = "base-eval"

    @abstractmethod
    def validate(self, context: EvalContext) -> EvalResult:
        """
        Execute the validation and return a structured result.

        Args:
            context: Dictionary containing conversation context and metadata

        Returns:
            ValidationResult dictionary with standardized format
        """
        pass

    def _create_result(
        self,
        score: float,
        explanation: str = "",
        confidence: float = 0.95,
        category: str = CATEGORY_UX,
        eval_type: str = "Relevance",
        red_flag_id: str | None = None,
    ) -> EvalResult:
        """
        Helper method to create a standardized validation result.

        Args:
            score: Numerical score between 0-100
            explanation: Optional explanation text
            confidence: Confidence level between 0-1
            category: Evaluation category from EVAL_CATEGORIES
            eval_type: Type within category
            red_flag_id: Reference identifier for specific red flag

        Returns:
            Formatted EvalResult dictionary
        """
        return EvalResult(
            validation_id=self.validation_id,
            score=score,
            result_explanation=explanation,
            confidence=confidence,
            category=category,
            eval_type=eval_type,
            red_flag_id=red_flag_id,
        )
