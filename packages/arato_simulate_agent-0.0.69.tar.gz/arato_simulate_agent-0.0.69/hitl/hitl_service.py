#!/usr/bin/env python3
"""
HITL (Human-in-the-Loop) Service for Arato Agent.

This server provides a web interface for human intervention in agent workflows,
including remote browser access via AWS DCV, session management, and intervention
state tracking.
"""

import json
import logging
from datetime import UTC, datetime
from pathlib import Path

import boto3
from botocore.exceptions import BotoCoreError, ClientError
from flask import Flask, Response, jsonify, request, send_from_directory
from flask_cors import CORS

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)


@app.route("/")
def index() -> Response:
    """Serve the main viewer page."""
    viewer_dir = Path(__file__).parent / "static" / "viewer"
    return send_from_directory(viewer_dir, "index.html")


@app.route("/health")
def health() -> tuple[Response, int]:
    """Health check endpoint."""
    return jsonify({"status": "ok", "service": "hitl-service"}), 200


@app.route("/api/validate-url", methods=["POST"])
def validate_url() -> tuple[Response, int]:
    """Validate a DCV URL format."""
    data = request.get_json()
    url = data.get("url", "")

    try:
        from urllib.parse import urlparse

        parsed = urlparse(url)

        if parsed.scheme not in ["https", "http"]:
            return jsonify({"valid": False, "error": "URL must use http or https"}), 400

        if not parsed.netloc:
            return jsonify({"valid": False, "error": "Invalid URL format"}), 400

        return jsonify({"valid": True, "url": url}), 200

    except Exception as e:
        return jsonify({"valid": False, "error": str(e)}), 400


@app.route("/api/browser-sessions", methods=["GET"])
def list_browser_sessions() -> tuple[Response, int]:
    """List active browser sessions from AWS Bedrock AgentCore."""
    try:
        # Use aws.browser.v1 as the browser identifier
        # This is the standard identifier for AWS Bedrock AgentCore browser sessions
        browser_identifier = "aws.browser.v1"
        region = "us-east-1"

        # Create bedrock-agentcore client
        client = boto3.client("bedrock-agentcore", region_name=region)

        # List only READY sessions (active and available for connection)
        response = client.list_browser_sessions(
            browserIdentifier=browser_identifier, status="READY"
        )

        sessions = response.get("items", [])

        # Format sessions for frontend
        formatted_sessions = [
            {
                "session_id": session["sessionId"],
                "id": session["sessionId"],
                "name": session.get("name", "Unnamed session"),
                "status": session["status"],
                "created_at": session["createdAt"],
                "browser_identifier": session["browserIdentifier"],
            }
            for session in sessions
        ]

        logger.info(f"Found {len(formatted_sessions)} READY browser sessions")
        return jsonify({"sessions": formatted_sessions}), 200

    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        error_message = e.response.get("Error", {}).get("Message", str(e))
        logger.error(f"AWS API error ({error_code}): {error_message}")
        return jsonify(
            {"error": "Failed to list browser sessions", "details": error_message}
        ), 500
    except BotoCoreError as e:
        logger.error(f"Boto3 error: {e}")
        return jsonify({"error": "AWS SDK error", "details": str(e)}), 500
    except Exception as e:
        logger.error(f"Error listing browser sessions: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/browser-sessions/<session_id>/connect", methods=["POST"])
def connect_to_session(session_id: str) -> tuple[Response, int]:
    """Get the stream endpoint for an existing browser session and generate presigned URL."""
    try:
        from urllib.parse import urlparse

        from botocore.auth import SigV4QueryAuth
        from botocore.awsrequest import AWSRequest

        browser_identifier = "aws.browser.v1"
        region = "us-east-1"

        # Create bedrock-agentcore client
        client = boto3.client("bedrock-agentcore", region_name=region)

        # Get the browser session details including stream endpoints
        try:
            session_data = client.get_browser_session(
                browserIdentifier=browser_identifier, sessionId=session_id
            )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            if error_code == "ResourceNotFoundException":
                return jsonify(
                    {
                        "error": "Session not found",
                        "session_id": session_id,
                    }
                ), 404
            raise

        # Check if session is still active
        status = session_data.get("status")
        if status == "TERMINATED":
            return jsonify(
                {
                    "error": "Session has been terminated",
                    "session_id": session_id,
                    "status": status,
                }
            ), 410

        # Extract the live view stream endpoint (unsigned)
        streams = session_data.get("streams", {})
        live_view_stream = streams.get("liveViewStream", {})
        stream_endpoint = live_view_stream.get("streamEndpoint")

        if not stream_endpoint:
            return jsonify(
                {"error": "No live view stream endpoint found for this session"}
            ), 404

        # Sign the URL using AWS SigV4 to create a presigned URL
        # This is required for DCV WebSocket authentication
        expires_in = 300  # 5 minutes
        url = urlparse(stream_endpoint)
        boto_session = boto3.Session()
        credentials = boto_session.get_credentials().get_frozen_credentials()
        request = AWSRequest(
            method="GET", url=url.geturl(), headers={"host": url.hostname}
        )
        signer = SigV4QueryAuth(
            credentials=credentials,
            service_name="bedrock-agentcore",
            region_name=region,
            expires=expires_in,
        )
        signer.add_auth(request)

        if not request.url:
            raise RuntimeError("Failed to generate presigned URL")

        presigned_url = request.url
        logger.info(
            f"Generated presigned URL for session {session_id} (expires in {expires_in}s)"
        )

        return (
            jsonify(
                {
                    "session_id": session_id,
                    "presigned_url": presigned_url,
                    "status": status,
                    "expires_in": expires_in,
                }
            ),
            200,
        )

    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        error_message = e.response.get("Error", {}).get("Message", str(e))
        logger.error(f"AWS API error ({error_code}): {error_message}")
        return jsonify({"error": error_message, "code": error_code}), 500
    except BotoCoreError as e:
        logger.error(f"Boto3 error: {e}")
        return jsonify({"error": "AWS SDK error", "details": str(e)}), 500
    except Exception as e:
        logger.error(f"Error connecting to session {session_id}: {e}")
        return jsonify({"error": str(e)}), 500


# HITL (Human-in-the-Loop) Endpoints
@app.route("/api/interventions", methods=["GET"])
def list_pending_interventions() -> tuple[Response, int]:
    """List all pending HITL interventions across all sessions."""
    try:
        region = "us-east-1"

        # Get S3 bucket name
        from platforms.aws_agentcore.storage import S3StorageAdapter

        storage = S3StorageAdapter(region=region)
        bucket_name = storage._resolve_bucket_name()

        s3_client = boto3.client("s3", region_name=region)

        # List all intervention state files
        response = s3_client.list_objects_v2(
            Bucket=bucket_name, Prefix="hitl_interventions/"
        )

        interventions = []
        for obj in response.get("Contents", []):
            try:
                # Read state file
                state_response = s3_client.get_object(
                    Bucket=bucket_name, Key=obj["Key"]
                )
                state_data = state_response["Body"].read().decode("utf-8")

                intervention = json.loads(state_data)

                # Only include waiting interventions
                if intervention.get("state") == "waiting":
                    interventions.append(
                        {
                            "intervention_id": intervention.get("intervention_id"),
                            "session_id": intervention.get("session_id"),
                            "intervention_type": intervention.get("intervention_type"),
                            "reason": intervention.get("reason"),
                            "requested_at": intervention.get("requested_at"),
                            "timeout_seconds": intervention.get("timeout_seconds"),
                            "s3_key": obj["Key"],
                        }
                    )
            except Exception as e:
                logger.warning(f"Failed to read intervention {obj['Key']}: {e}")
                continue

        logger.info(f"Found {len(interventions)} pending interventions")
        return jsonify(
            {"interventions": interventions, "count": len(interventions)}
        ), 200

    except Exception as e:
        logger.error(f"Error listing interventions: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/browser-sessions/<session_id>/state", methods=["GET"])
def get_session_hitl_state(session_id: str) -> tuple[Response, int]:
    """Get the HITL state of a browser session from S3.

    Args:
        session_id: AgentCore browser session ID (from browser sessions API)
    """
    try:
        region = "us-east-1"

        # Get S3 bucket name
        from platforms.aws_agentcore.storage import S3StorageAdapter

        storage = S3StorageAdapter(region=region)
        bucket_name = storage._resolve_bucket_name()

        s3_client = boto3.client("s3", region_name=region)

        # Search all intervention folders (session_id is AgentCore session ID,
        # but interventions are stored by internal browser session ID)
        prefix = "hitl_interventions/"
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

        # Find the most recent waiting intervention matching this AgentCore session ID
        latest_intervention = None
        latest_time = None

        for obj in response.get("Contents", []):
            try:
                state_response = s3_client.get_object(
                    Bucket=bucket_name, Key=obj["Key"]
                )
                state_data = state_response["Body"].read().decode("utf-8")

                intervention = json.loads(state_data)

                # Match by AgentCore session ID (stored in intervention metadata)
                if (
                    intervention.get("state") == "waiting"
                    and intervention.get("agentcore_session_id") == session_id
                ):
                    requested_at = intervention.get("requested_at")
                    if latest_time is None or requested_at > latest_time:
                        latest_time = requested_at
                        latest_intervention = intervention
            except Exception as e:
                logger.warning(f"Failed to read intervention {obj['Key']}: {e}")
                continue

        if latest_intervention:
            response_data = {
                "session_id": session_id,
                "hitl_active": True,
                "hitl_state": "waiting",
                "intervention_id": latest_intervention.get("intervention_id"),
                "intervention_type": latest_intervention.get("intervention_type"),
                "intervention_reason": latest_intervention.get("reason"),
                "requested_at": latest_intervention.get("requested_at"),
                "timeout_seconds": latest_intervention.get("timeout_seconds"),
                "screenshot_url": latest_intervention.get("screenshot_url"),
                "url_before": latest_intervention.get("url_before"),
            }
        else:
            response_data = {
                "session_id": session_id,
                "hitl_active": False,
                "hitl_state": "none",
            }

        logger.info(f"Retrieved HITL state for session {session_id}")
        return jsonify(response_data), 200

    except Exception as e:
        logger.error(f"Error getting HITL state for session {session_id}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/interventions/<intervention_id>/complete", methods=["POST"])
def complete_intervention(intervention_id: str) -> tuple[Response, int]:
    """Mark a HITL intervention as complete by updating S3 state."""
    try:
        region = "us-east-1"
        data = request.get_json() or {}
        error_message = data.get("error_message")

        # Get S3 bucket name
        from platforms.aws_agentcore.storage import S3StorageAdapter

        storage = S3StorageAdapter(region=region)
        bucket_name = storage._resolve_bucket_name()

        s3_client = boto3.client("s3", region_name=region)

        # Find the intervention file (we need to search across sessions)
        response = s3_client.list_objects_v2(
            Bucket=bucket_name, Prefix="hitl_interventions/"
        )

        intervention_key = None
        for obj in response.get("Contents", []):
            if intervention_id in obj["Key"]:
                intervention_key = obj["Key"]
                break

        if not intervention_key:
            return jsonify(
                {
                    "error": "Intervention not found",
                    "intervention_id": intervention_id,
                }
            ), 404

        # Read current state
        state_response = s3_client.get_object(Bucket=bucket_name, Key=intervention_key)
        state_data = state_response["Body"].read().decode("utf-8")

        intervention = json.loads(state_data)

        # Check if already completed
        if intervention.get("state") != "waiting":
            return jsonify(
                {
                    "error": "Intervention is not waiting",
                    "intervention_id": intervention_id,
                    "current_state": intervention.get("state"),
                }
            ), 400

        # Update state
        if error_message:
            intervention["state"] = "error"
            intervention["error_message"] = error_message
        else:
            intervention["state"] = "completed"

        intervention["completed_at"] = datetime.now(UTC).isoformat()

        # Write updated state back to S3
        s3_client.put_object(
            Bucket=bucket_name,
            Key=intervention_key,
            Body=json.dumps(intervention, indent=2),
            ContentType="application/json",
        )

        logger.info(
            f"✓ Marked intervention {intervention_id} as {intervention['state']}"
        )

        return jsonify(
            {
                "intervention_id": intervention_id,
                "session_id": intervention.get("session_id"),
                "state": intervention["state"],
                "completed_at": intervention["completed_at"],
            }
        ), 200

    except Exception as e:
        logger.error(f"Error completing intervention {intervention_id}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/browser-sessions/<session_id>/resume", methods=["POST"])
def resume_session(session_id: str) -> tuple[Response, int]:
    """Resume a paused browser session by completing the latest waiting intervention.

    Args:
        session_id: AgentCore browser session ID
    """
    try:
        logger.info(f"🤝 Resume request received for session {session_id}")
        region = "us-east-1"

        # Get S3 bucket name
        from platforms.aws_agentcore.storage import S3StorageAdapter

        storage = S3StorageAdapter(region=region)
        bucket_name = storage._resolve_bucket_name()

        s3_client = boto3.client("s3", region_name=region)

        # Search all interventions for this AgentCore session ID
        prefix = "hitl_interventions/"
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

        logger.info(
            f"Searching for waiting interventions in s3://{bucket_name}/{prefix}"
        )

        latest_intervention = None
        latest_key = None
        checked_count = 0

        for obj in response.get("Contents", []):
            try:
                checked_count += 1
                state_response = s3_client.get_object(
                    Bucket=bucket_name, Key=obj["Key"]
                )
                state_data = state_response["Body"].read().decode("utf-8")

                intervention = json.loads(state_data)

                # Match by AgentCore session ID
                if (
                    intervention.get("state") == "waiting"
                    and intervention.get("agentcore_session_id") == session_id
                ):
                    logger.info(
                        f"Found matching intervention: {intervention.get('intervention_id')} in {obj['Key']}"
                    )
                    latest_intervention = intervention
                    latest_key = obj["Key"]
                    break  # Take first waiting intervention
            except Exception as e:
                logger.warning(f"Failed to read intervention {obj['Key']}: {e}")
                continue

        logger.info(f"Checked {checked_count} intervention files")

        if not latest_intervention:
            logger.warning(
                f"No waiting intervention found for session {session_id} after checking {checked_count} files"
            )
            return jsonify(
                {
                    "error": "No waiting intervention found",
                    "session_id": session_id,
                }
            ), 404

        # Mark intervention as completed
        intervention_id = latest_intervention.get("intervention_id")
        latest_intervention["state"] = "completed"
        latest_intervention["completed_at"] = datetime.now(UTC).isoformat()

        s3_client.put_object(
            Bucket=bucket_name,
            Key=latest_key,
            Body=json.dumps(latest_intervention, indent=2),
            ContentType="application/json",
        )

        logger.info(
            f"✓ Resumed session {session_id} - Intervention {intervention_id} marked as completed in {latest_key}"
        )

        return jsonify(
            {
                "session_id": session_id,
                "status": "resumed",
                "intervention_id": latest_intervention.get("intervention_id"),
                "hitl_state": "completed",
                "resumed_at": latest_intervention["completed_at"],
            }
        ), 200

    except Exception as e:
        logger.error(f"Error resuming session {session_id}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/browser-sessions/<session_id>/interventions", methods=["GET"])
def list_session_interventions(session_id: str) -> tuple[Response, int]:
    """List all HITL interventions for a browser session."""
    try:
        region = "us-east-1"

        # Get storage adapter
        from platforms.aws_agentcore.storage import S3StorageAdapter

        storage = S3StorageAdapter(region=region)

        # Use storage adapter's list method
        interventions = storage.list_hitl_interventions(
            session_id=session_id, org_id=None
        )

        # Calculate some basic statistics
        total = len(interventions)
        completed = 0
        waiting = 0
        timeout = 0
        error = 0

        for i in interventions:
            response = i.get("response")
            if isinstance(response, dict):
                state = response.get("state")
                if state == "completed":
                    completed += 1
                elif state == "waiting":
                    waiting += 1
                elif state == "timeout":
                    timeout += 1
                elif state == "error":
                    error += 1

        # Calculate average duration for completed interventions
        durations = []
        for intervention in interventions:
            request_data = intervention.get("request")
            response_data = intervention.get("response")

            if not isinstance(request_data, dict) or not isinstance(
                response_data, dict
            ):
                continue

            if response_data.get("state") == "completed":
                requested_at = request_data.get("requested_at")
                completed_at = response_data.get("completed_at")

                if requested_at and completed_at:
                    from datetime import datetime

                    try:
                        req_time = datetime.fromisoformat(
                            requested_at.replace("Z", "+00:00")
                        )
                        comp_time = datetime.fromisoformat(
                            completed_at.replace("Z", "+00:00")
                        )
                        duration = (comp_time - req_time).total_seconds()
                        durations.append(duration)
                    except Exception:
                        pass

        avg_duration = sum(durations) / len(durations) if durations else None

        logger.info(
            f"Retrieved {total} interventions for session {session_id} "
            f"(completed: {completed}, waiting: {waiting}, timeout: {timeout}, error: {error})"
        )

        return jsonify(
            {
                "session_id": session_id,
                "interventions": interventions,
                "statistics": {
                    "total": total,
                    "completed": completed,
                    "waiting": waiting,
                    "timeout": timeout,
                    "error": error,
                    "average_duration_seconds": round(avg_duration, 2)
                    if avg_duration
                    else None,
                },
            }
        ), 200

    except Exception as e:
        logger.error(f"Error listing interventions for session {session_id}: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/screenshots/<path:screenshot_path>", methods=["GET"])
def get_screenshot(screenshot_path: str) -> tuple[Response, int]:
    """Fetch a screenshot from S3 storage.

    Args:
        screenshot_path: S3 path in format 's3://bucket/key' or just 'bucket/key'
    """
    try:
        region = "us-east-1"

        # Parse S3 path
        if screenshot_path.startswith("s3://"):
            screenshot_path = screenshot_path[5:]  # Remove 's3://' prefix

        parts = screenshot_path.split("/", 1)
        if len(parts) != 2:
            return jsonify({"error": "Invalid screenshot path format"}), 400

        bucket_name, object_key = parts

        s3_client = boto3.client("s3", region_name=region)

        # Get screenshot from S3
        try:
            response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
            image_data = response["Body"].read()

            # Return image with proper content type
            return Response(
                image_data,
                mimetype="image/png",
                headers={
                    "Cache-Control": "public, max-age=3600",
                    "Content-Disposition": f'inline; filename="{object_key.split("/")[-1]}"',
                },
            ), 200

        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "NoSuchKey":
                logger.warning(
                    "Screenshot not found: s3://%s/%s", bucket_name, object_key
                )
                return jsonify({"error": "Screenshot not found"}), 404
            raise

    except Exception as e:
        logger.error("Error fetching screenshot: %s", e)
        return jsonify({"error": str(e)}), 500


# Static file serving for DCV SDK
@app.route("/static/<path:filename>")
def serve_static(filename: str) -> Response:
    """Serve static files including the DCV SDK."""
    static_dir = Path(__file__).parent / "static"
    logger.info(f"Serving static file: {filename} from {static_dir}")
    logger.info(f"Full path: {static_dir / filename}")
    logger.info(f"File exists: {(static_dir / filename).exists()}")
    return send_from_directory(static_dir, filename)


@app.route("/dcvjs/<path:filename>")
def serve_dcvjs(filename: str) -> Response:
    """Serve DCV SDK worker files from /dcvjs/ path (required by DCV SDK)."""
    static_dir = Path(__file__).parent / "static" / "dcvjs"
    logger.info(f"Serving DCV worker file: {filename} from {static_dir}")
    return send_from_directory(static_dir, filename)


def main() -> None:
    """Run the HITL service server."""
    import argparse

    parser = argparse.ArgumentParser(
        description="HITL Service for Remote Browser Sessions"
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind the server to (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port to bind the server to (default: 8080)",
    )
    parser.add_argument("--debug", action="store_true", help="Run in debug mode")

    args = parser.parse_args()

    logger.info(f"Starting HITL Service on {args.host}:{args.port}")
    logger.info("Open your browser and navigate to: http://%s:%d", args.host, args.port)

    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
