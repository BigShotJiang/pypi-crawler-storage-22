"""HTTP server that hosts the integration test AUT (Application Under Test).

Provides a deterministic multi-topic chat application for integration testing.
All responses are pattern-matched and fully predictable — no randomness.
"""

from __future__ import annotations

import argparse
import asyncio
import re
from datetime import UTC, datetime
from pathlib import Path

from aiohttp import web

BASE_DIR = Path(__file__).parent
INDEX_FILE = BASE_DIR / "index.html"

CORRECT_PASSCODE = "123abc"

WELCOME_MESSAGE = (
    "Welcome to TestBot! I can help you with: account information, "
    "product details, and troubleshooting. How can I assist you today?"
)


def get_response(text: str) -> str:
    """Deterministic response engine. Returns appropriate response based on input patterns.

    All responses are fully predictable for reliable integration test assertions.
    """
    lower = text.lower().strip()

    # Greetings
    if re.search(r"\b(hi|hello|hey|greetings|good morning|good afternoon)\b", lower):
        return (
            "Hello! Welcome to our support chat. I'm here to help you with "
            "any questions. You can ask me about your account, our products, "
            "or any issues you're experiencing."
        )

    # Help requests
    if re.search(r"\b(help|assist|support|what can you do)\b", lower):
        return (
            "I can help you with the following:\n"
            "1. Account information - Check your account status, update details\n"
            "2. Product catalog - Browse our available products and pricing\n"
            "3. Troubleshooting - Resolve common technical issues\n"
            "4. General inquiries - Answer questions about our services\n"
            "What would you like to know more about?"
        )

    # Account-related
    if re.search(r"\b(account|profile|settings|my info)\b", lower):
        return (
            "Your account is currently active and in good standing. "
            "Your plan is the Standard tier, which includes 24/7 support access. "
            "Would you like to update any of your account details?"
        )

    # Product-related
    if re.search(r"\b(product|catalog|pricing|price|buy|purchase)\b", lower):
        return (
            "We offer three product tiers:\n"
            "- Basic: $9.99/month - Essential features for individuals\n"
            "- Standard: $24.99/month - Advanced features for small teams\n"
            "- Enterprise: $99.99/month - Full suite for organizations\n"
            "Each plan includes a 14-day free trial. Which plan interests you?"
        )

    # Troubleshooting
    if re.search(r"\b(problem|issue|error|broken|not working|bug|trouble)\b", lower):
        return (
            "I'm sorry to hear you're experiencing an issue. "
            "Let me help you troubleshoot. Common solutions include:\n"
            "1. Clear your browser cache and cookies\n"
            "2. Try using a different browser\n"
            "3. Check your internet connection\n"
            "Could you describe the specific issue you're facing?"
        )

    # Thank you / closing
    if re.search(r"\b(thank|thanks|bye|goodbye|that's all|no more)\b", lower):
        return (
            "You're welcome! I'm glad I could help. "
            "If you have any other questions in the future, don't hesitate to reach out. "
            "Have a great day!"
        )

    # Default contextual response
    snippet = text[:50]
    return (
        f'Thank you for your message. I understand you\'re asking about "{snippet}". '
        "Let me look into that for you. Based on our records, I can provide "
        "the following information: Our system shows everything is operating "
        "normally. Is there anything specific you'd like me to clarify?"
    )


async def handle_index(_: web.Request) -> web.StreamResponse:
    """Serve the static chat interface."""
    if not INDEX_FILE.exists():
        raise web.HTTPInternalServerError(text="Missing index.html for AUT server")
    return web.FileResponse(INDEX_FILE)


async def handle_login(request: web.Request) -> web.Response:
    """Validate login passcode on the backend."""
    try:
        data = await request.json()
        passcode = data.get("passcode", "")

        if passcode == CORRECT_PASSCODE:
            return web.json_response({"success": True, "message": "Login successful"})
        else:
            return web.json_response(
                {"success": False, "message": "Invalid passcode"}, status=401
            )
    except Exception as e:
        return web.json_response(
            {"success": False, "message": f"Error: {str(e)}"}, status=400
        )


async def handle_welcome(_: web.Request) -> web.Response:
    """Return the welcome message for the chat interface."""
    return web.json_response(
        {
            "response": WELCOME_MESSAGE,
            "timestamp": datetime.now(UTC).isoformat(),
        }
    )


async def handle_chat(request: web.Request) -> web.Response:
    """Process a chat message and return a deterministic response."""
    try:
        data = await request.json()
        message = data.get("message", "").strip()

        if not message:
            return web.json_response({"error": "Message is required"}, status=400)

        response_text = get_response(message)
        return web.json_response(
            {
                "response": response_text,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )
    except Exception as e:
        return web.json_response({"error": f"Error: {str(e)}"}, status=500)


def create_app() -> web.Application:
    """Create an aiohttp application for serving the AUT."""
    app = web.Application()
    app.router.add_get("/", handle_index)
    app.router.add_post("/api/login", handle_login)
    app.router.add_get("/api/welcome", handle_welcome)
    app.router.add_post("/api/chat", handle_chat)
    return app


async def _run_app(host: str, port: int) -> None:
    runner = web.AppRunner(create_app())
    await runner.setup()
    site = web.TCPSite(runner, host=host, port=port)
    await site.start()

    print(f"Integration Test AUT server running at http://{host}:{port}")
    print("Press Ctrl+C to stop the server")

    # Block forever until cancelled
    try:
        while True:
            await asyncio.sleep(3600)
    except asyncio.CancelledError:
        pass
    finally:
        await runner.cleanup()


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the integration test AUT server")
    parser.add_argument(
        "--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port", type=int, default=5174, help="Port to bind (default: 5174)"
    )
    args = parser.parse_args()

    try:
        asyncio.run(_run_app(args.host, args.port))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
