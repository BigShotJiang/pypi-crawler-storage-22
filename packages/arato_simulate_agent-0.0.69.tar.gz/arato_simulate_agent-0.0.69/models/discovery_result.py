"""
Discovery Result Model.

Data class representing the result of chat interface discovery.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class DiscoveryResult:
    """Result of chat interface discovery."""

    success: bool
    """Whether discovery was successful."""

    status: str
    """Status code: 'FOUND', 'NOT_FOUND', 'ERROR'."""

    chat_input_selector: str | None = None
    """CSS selector for the chat input field."""

    submit_button_selector: str | None = None
    """CSS selector for the submit/send button."""

    chat_container_selector: str | None = None
    """CSS selector for the chat message container."""

    welcome_message: str | None = None
    """Welcome message captured during discovery (turn 0)."""

    chat_url: str | None = None
    """URL where chat was discovered (may differ from target_url)."""

    error: str | None = None
    """Error message if discovery failed."""

    raw_findings: dict[str, Any] = field(default_factory=dict)
    """Raw JSON findings from the discovery agent."""

    usage: Any = None
    """Token usage data from the browser-use agent run."""

    @classmethod
    def from_json(cls, json_data: dict[str, Any]) -> "DiscoveryResult":
        """Create DiscoveryResult from JSON response.

        Handles both flat format (chat_input_selector at top level) and
        nested format (selectors.input_selector from discovery prompt).
        """
        status = json_data.get("status", "NOT_FOUND")
        success = status == "FOUND"

        # Support nested selectors dict from discovery prompt output
        selectors = json_data.get("selectors", {})

        chat_input = json_data.get("chat_input_selector") or selectors.get(
            "input_selector"
        )
        submit_button = json_data.get("submit_button_selector") or selectors.get(
            "send_button_selector"
        )
        chat_container = json_data.get("chat_container_selector") or selectors.get(
            "message_container_selector"
        )

        return cls(
            success=success,
            status=status,
            chat_input_selector=chat_input,
            submit_button_selector=submit_button,
            chat_container_selector=chat_container,
            welcome_message=json_data.get("welcome_message"),
            chat_url=json_data.get("chat_url"),
            error=json_data.get("error"),
            raw_findings=json_data,
        )

    @classmethod
    def not_found(cls, note: str | None = None) -> "DiscoveryResult":
        """Create a NOT_FOUND result."""
        return cls(
            success=False,
            status="NOT_FOUND",
            error=note or "Chat interface not found",
        )

    @classmethod
    def create_error(cls, error_message: str) -> "DiscoveryResult":
        """Create an ERROR result."""
        return cls(
            success=False,
            status="ERROR",
            error=error_message,
        )
