"""Event schema imports - consolidated in core.schemas."""

# Import models from core schemas
from core.schemas import (
    BaseEvent,
    CompletionEvent,
    Conversation,
    ConversationWorkerEvent,
    FailureEvent,
    ReportRun,
    TimestampedEvent,
    TurnUpdate,
    UpdateEvent,
    UpdateType,
)

# Re-export for backwards compatibility
__all__ = [
    "BaseEvent",
    "TimestampedEvent",
    "ConversationWorkerEvent",
    "UpdateEvent",
    "UpdateType",
    "ReportRun",
    "Conversation",
    "CompletionEvent",
    "FailureEvent",
    "TurnUpdate",
]
