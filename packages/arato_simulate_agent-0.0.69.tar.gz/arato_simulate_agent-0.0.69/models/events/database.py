"""Database record schemas for report runs and conversations."""

# Import all database models from core schemas
from core.schemas import Conversation, ReportRun

# Re-export for backwards compatibility
__all__ = [
    "ReportRun",
    "Conversation",
]
