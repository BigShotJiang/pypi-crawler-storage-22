"""
Turn Result Model.

Data class representing the result of a single conversation turn execution.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TurnResult:
    """Result of executing a single conversation turn."""

    success: bool
    """Whether the turn was executed successfully."""

    user_message: str | None = None
    """The message sent by the user."""

    assistant_response: str | None = None
    """The response from the chatbot."""

    turn_number: int | None = None
    """The turn number (1-indexed, excluding welcome message)."""

    chatbot_terminated: bool = False
    """Whether the chatbot ended the conversation (escalation/handoff)."""

    error: str | None = None
    """Error message if turn execution failed."""

    extraction_metadata: dict[str, Any] = field(default_factory=dict)
    """Metadata from response extraction (e.g., context_chars)."""

    usage: Any = None
    """Token usage data from the browser-use agent run."""

    @classmethod
    def success_turn(
        cls,
        user_message: str,
        assistant_response: str,
        turn_number: int,
        chatbot_terminated: bool = False,
        extraction_metadata: dict[str, Any] | None = None,
    ) -> "TurnResult":
        """Create a successful turn result."""
        return cls(
            success=True,
            user_message=user_message,
            assistant_response=assistant_response,
            turn_number=turn_number,
            chatbot_terminated=chatbot_terminated,
            extraction_metadata=extraction_metadata or {},
        )

    @classmethod
    def failed(cls, error: str, user_message: str | None = None) -> "TurnResult":
        """Create a failed turn result."""
        return cls(
            success=False,
            user_message=user_message,
            error=error,
        )

    @classmethod
    def extraction_failed(cls, user_message: str) -> "TurnResult":
        """Create a result for when response extraction failed."""
        return cls(
            success=False,
            user_message=user_message,
            error="Response extraction failed - chatbot may not have responded",
        )
