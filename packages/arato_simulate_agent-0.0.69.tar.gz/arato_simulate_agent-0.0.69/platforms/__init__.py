"""Platform adapters for different deployment environments."""

from platforms.base import PlatformAdapter

__all__ = [
    "PlatformAdapter",
]

# AWS AgentCore adapter requires optional dependency
try:
    from platforms.aws_agentcore import AWSAgentCorePlatformAdapter  # noqa: F401

    __all__.append("AWSAgentCorePlatformAdapter")
except ImportError:
    pass  # AWS dependencies not installed
