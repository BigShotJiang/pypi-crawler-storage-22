"""AWS platform adapters."""
