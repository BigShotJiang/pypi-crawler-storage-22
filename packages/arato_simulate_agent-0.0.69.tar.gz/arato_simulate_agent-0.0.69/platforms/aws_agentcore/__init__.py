"""AWS AgentCore platform adapter module.

This module provides all AWS-specific implementations:
- Platform adapter for AgentCore runtime
- S3 storage adapter
- AgentCore Browser manager
- AWS-specific constants
"""

from platforms.aws_agentcore.adapter import AWSAgentCorePlatformAdapter
from platforms.aws_agentcore.browser import (
    AgentCoreBrowserManager,
    AgentCoreBrowserSession,
)
from platforms.aws_agentcore.platform_constants import (
    DEFAULT_AGENTCORE_RETRY_CONFIG,
    DEFAULT_AWS_REGION,
)
from platforms.aws_agentcore.storage import S3StorageAdapter

__all__ = [
    "AWSAgentCorePlatformAdapter",
    "AgentCoreBrowserManager",
    "AgentCoreBrowserSession",
    "S3StorageAdapter",
    "DEFAULT_AWS_REGION",
    "DEFAULT_AGENTCORE_RETRY_CONFIG",
]
