"""AWS AgentCore platform adapter implementation.

This module implements the PlatformAdapter interface for AWS Bedrock AgentCore
deployment, handling session management, background tasks, and invocation logic.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import boto3
from bedrock_agentcore.runtime import BedrockAgentCoreApp

from constants import (
    AGENTCORE_PIPELINE_TIMEOUT,
    DEFAULT_MAX_TURNS,
    DEFAULT_SEED_UTTERANCE,
    LLM_PROVIDER_VERTEX,
    SSM_PARAM_GOOGLE_CREDENTIALS,
)
from core.schemas import AgentIdentity
from platforms.aws_agentcore.platform_constants import (
    AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS,
)
from platforms.base import PlatformAdapter

logger = logging.getLogger(__name__)


class AWSAgentCorePlatformAdapter(PlatformAdapter):
    """Platform adapter for AWS Bedrock AgentCore deployment."""

    def __init__(self, region: str | None = None, memory_id: str | None = None):
        """Initialize AWS AgentCore platform adapter.

        Args:
            region: AWS region (defaults to DEFAULT_AWS_REGION)
            memory_id: Bedrock AgentCore memory ID (optional)
        """
        from core.llm import LLMAdapter, set_llm_adapter
        from platforms.aws_agentcore.platform_constants import DEFAULT_AWS_REGION

        self.region = region or os.getenv("AWS_REGION", DEFAULT_AWS_REGION)
        self.memory_id = memory_id or os.getenv("BEDROCK_AGENTCORE_MEMORY_ID")
        self._app = BedrockAgentCoreApp()

        self._check_and_configure_vertex_auth()

        logger.info(f"Initialized AWS AgentCore adapter (region={self.region})")
        # Initialize LLM adapter (auto-detects AWS environment and uses Bedrock)
        llm_adapter = LLMAdapter(region=self.region)
        set_llm_adapter(llm_adapter)

        logger.info(
            f"Initialized AWS AgentCore adapter (region={self.region}, memory_id={self.memory_id})"
        )

    def _check_and_configure_vertex_auth(self) -> None:
        """Setup Vertex AI credentials from SSM if configured."""
        provider = os.getenv("LLM_PROVIDER", "").lower()
        logger.info(f"Checking LLM provider configuration: {provider}")

        if provider != LLM_PROVIDER_VERTEX:
            return

        logger.info("Configuring Vertex AI credentials from SSM...")
        try:
            ssm = boto3.client("ssm", region_name=self.region)

            response = ssm.get_parameter(
                Name=SSM_PARAM_GOOGLE_CREDENTIALS, WithDecryption=True
            )
            creds_json = response["Parameter"]["Value"]

            # Write key file with restricted permissions (0600)
            import tempfile

            fd, creds_path_str = tempfile.mkstemp(
                suffix=".json", prefix="vertex_creds_"
            )
            os.fchmod(fd, 0o600)
            os.write(fd, creds_json.encode())
            os.close(fd)
            creds_path = Path(creds_path_str)

            # Set environment variables
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(creds_path)

            # Extract and set project ID
            creds_data = json.loads(creds_json)
            if "project_id" in creds_data:
                os.environ["VERTEX_PROJECT_ID"] = creds_data["project_id"]

            logger.info("✅ Vertex AI authentication configured successfully")

        except Exception as e:
            logger.error(f"Failed to configure Vertex AI auth: {e}")
            logger.warning("Agent may fail if using Vertex/Gemini models")

    def resolve_session_id(self, requested_id: str | None, context: Any = None) -> str:
        """Generate or return session ID.

        Args:
            requested_id: User-provided session ID or None
            context: Platform invocation context (unused for now)

        Returns:
            Session ID (generated if not provided)
        """
        if requested_id:
            return requested_id

        timestamp = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
        return f"session_{timestamp}_{uuid.uuid4().hex[:8]}"

    def get_session_directory(self, session_id: str) -> Path:
        """Get or create session directory.

        Args:
            session_id: Session identifier

        Returns:
            Path to session directory
        """
        from constants import TMP_SESSIONS_DIR

        session_root = Path(TMP_SESSIONS_DIR)
        session_path = session_root / session_id
        session_path.mkdir(parents=True, exist_ok=True)
        return session_path

    def supports_background_tasks(self) -> bool:
        """Check if platform supports background task execution.

        Returns:
            True for AgentCore (supports async tasks)
        """
        return True

    def supports_hitl(self) -> bool:
        """Check if platform supports Human-in-the-Loop interventions.

        Returns:
            True - AWS AgentCore supports HITL via HITL service
        """
        return True

    async def get_hitl_viewer_url(self, session_id: str) -> str | None:
        """Get the URL for the HITL viewer interface.

        For AWS AgentCore, this returns the HITL service URL that humans
        can use to view and interact with the browser session.

        Args:
            session_id: Browser session ID

        Returns:
            URL to HITL service or None if not available
        """
        # The HITL service is typically hosted at a known endpoint
        # For now, we return a localhost URL assuming the HITL service is running
        # In production, this would be a publicly accessible URL
        viewer_host = os.getenv("HITL_VIEWER_HOST", "http://localhost:8080")
        return f"{viewer_host}?session_id={session_id}"

    def get_agent_identity(self) -> AgentIdentity:
        """Get the agent identity information.

        Returns:
            AgentIdentity model with agent information
        """
        from utils.bedrock_config import get_agent_id

        try:
            agent_id = get_agent_id()
        except Exception as e:
            logger.warning(f"Failed to get agent ID: {e}")
            agent_id = "unknown"

        return AgentIdentity(name=agent_id, platform="aws_agentcore")

    async def invoke(self, payload: dict[str, Any], context: Any) -> dict[str, Any]:
        """Execute agent invocation on AWS AgentCore.

        This starts a background task and returns immediately. The actual
        pipeline runs asynchronously while the AgentCore session stays active.

        Args:
            payload: Request payload with target_url, persona_ids, etc.
            context: AgentCore context object

        Returns:
            Immediate response with background task status
        """
        # Extract parameters from payload
        target_url = payload.get("target_url", "")
        seed_utterance = payload.get("seed_utterance", DEFAULT_SEED_UTTERANCE)
        max_turns = payload.get("max_turns", DEFAULT_MAX_TURNS)
        persona_ids = payload.get("persona_ids")
        arato_api_url = payload.get("arato_api_url")
        arato_api_key = payload.get("arato_api_key")
        session_id = payload.get("session_id")
        max_parallel = payload.get(
            "max_parallel", AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS
        )
        org_id = payload.get("org_id")
        task_id = payload.get("task_id")
        goal = payload.get("goal", "chat")
        storage_state = payload.get("storage_state")
        force_discovery = payload.get("force_discovery", False)
        force_ground_truth = payload.get("force_ground_truth", False)
        exclude_persona_ids = payload.get("exclude_persona_ids")
        include_eu_ai_act_report = payload.get("include_eu_ai_act_report", False)
        broadcast_identity = payload.get("broadcast_identity", False)
        session_prefix = payload.get("session_prefix")
        domain = payload.get("domain")
        test_suite_id = payload.get("test_suite_id")
        target_urls = payload.get("target_urls")

        # Extract AgentCore thread_id from context
        thread_id = None
        if context:
            thread_id = getattr(context, "thread_id", None) or getattr(
                context, "session_id", None
            )

        # Resolve session ID
        requested_session_id = session_id or (
            getattr(context, "session_id", None) if context else None
        )
        resolved_session_id = self.resolve_session_id(requested_session_id, context)

        if not requested_session_id:
            logger.info(f"Generated session ID: {resolved_session_id}")

        logger.info(
            f"AgentCore thread_id: {thread_id}, session_id: {resolved_session_id}"
        )
        logger.info(f"AgentCore invocation: url={target_url}")
        if persona_ids:
            logger.info(f"Personas: {persona_ids}")

        # Prepare session directory (only for chat mode)
        # For discovery mode, let orchestrator handle output dir
        output_dir = None
        if goal == "chat":
            session_path = self.get_session_directory(resolved_session_id)
            output_dir = str(session_path)

        # Run the pipeline directly (blocking) to keep the MicroVM alive.
        # AgentCore shuts down the MicroVM when the invocation returns,
        # so fire-and-forget with asyncio.ensure_future() doesn't work.
        logger.info(f"Running pipeline synchronously for session {resolved_session_id}")

        result = await self._run_pipeline_async(
            target_url=target_url,
            seed_utterance=seed_utterance,
            max_turns=max_turns,
            output_dir=output_dir,
            persona_ids=persona_ids,
            arato_api_url=arato_api_url,
            arato_api_key=arato_api_key,
            session_id=resolved_session_id,
            thread_id=thread_id,
            max_parallel=max_parallel,
            org_id=org_id,
            task_id=task_id,
            goal=goal,
            storage_state=storage_state,
            force_discovery=force_discovery,
            force_ground_truth=force_ground_truth,
            exclude_persona_ids=exclude_persona_ids,
            include_eu_ai_act_report=include_eu_ai_act_report,
            broadcast_identity=broadcast_identity,
            session_prefix=session_prefix,
            domain=domain,
            test_suite_id=test_suite_id,
            target_urls=target_urls,
        )

        return {
            "status": "completed",
            "session_id": resolved_session_id,
            "target_url": target_url,
            "personas": persona_ids,
            "max_turns": max_turns,
            "goal": goal,
            "result": result,
            "live_view_url": f"https://{self.region}.console.aws.amazon.com/bedrock-agentcore/builtInTools",
            "note": "Check AWS Console Live View to watch browser automation in real-time. Results will be saved to S3.",
            "output_dir": output_dir,  # Will be None for discovery mode
        }

    async def _run_pipeline_async(
        self,
        target_url: str,
        seed_utterance: str,
        max_turns: int,
        output_dir: str | None,
        persona_ids: list[str] | None,
        arato_api_url: str | None,
        arato_api_key: str | None,
        session_id: str,
        thread_id: str | None = None,
        max_parallel: int = AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS,
        org_id: str | None = None,
        task_id: str | None = None,
        goal: str = "chat",
        storage_state: str | None = None,
        task: Any | None = None,
        polling_client: Any | None = None,
        force_discovery: bool = False,
        force_ground_truth: bool = False,
        session_prefix: str | None = None,
        exclude_persona_ids: list[str] | None = None,
        include_eu_ai_act_report: bool = False,
        broadcast_identity: bool = False,
        domain: str | None = None,
        test_suite_id: str | None = None,
        target_urls: list[str] | None = None,
    ) -> dict[str, Any]:
        """Background task that runs the chat pipeline asynchronously.

        Args:
            target_url: URL to test
            seed_utterance: Initial message
            max_turns: Maximum conversation turns
            output_dir: Directory for outputs (None for discovery mode)
            persona_ids: List of personas with optional multipliers
            arato_api_url: Optional Arato API endpoint
            arato_api_key: Optional Arato API key
            session_id: Session identifier
            thread_id: Optional AgentCore thread ID
            max_parallel: Maximum personas to run in parallel
            org_id: Optional organization ID
            task_id: Optional task ID
            goal: Execution goal - 'discover' (discovery only) or 'chat' (discovery + chat, default)
            storage_state: Optional path to JSON file with saved authentication state
            force_discovery: If True, ignore cached app context and rediscover from scratch
            force_ground_truth: If True, ignore cached ground truth and re-collect
            include_eu_ai_act_report: Whether to include EU AI Act compliance assessment
            broadcast_identity: If True, send agent identity as first message
            domain: Domain for test suite configuration
            test_suite_id: Test suite identifier to load configuration from
            target_urls: List of target URLs for multi-URL testing

        Returns:
            Pipeline execution result
        """
        from agents.graph_orchestrator import GraphOrchestrator
        from constants import FINAL_RESULT_FILENAME
        from core.browser.base import get_browser_manager
        from platforms.aws_agentcore.browser import AgentCoreBrowserManager

        logger.info(f"Starting async pipeline for session {session_id}")
        logger.info(f"   URL: {target_url}")
        logger.info(f"   Personas: {persona_ids}")
        logger.info(f"   Max turns: {max_turns}")
        if test_suite_id:
            logger.info(f"   Test suite: {test_suite_id}")

        # Load test suite configuration if test_suite_id is provided
        test_suite = None
        if test_suite_id:
            try:
                from utils.config_loader import load_test_suite

                test_suite = load_test_suite(test_suite_id)
                logger.info(f"Loaded test suite: {test_suite_id}")
            except Exception as e:
                logger.warning(f"Failed to load test suite '{test_suite_id}': {e}")

        try:
            # Set session_id on browser manager for HITL interventions
            browser_manager = get_browser_manager()
            if isinstance(browser_manager, AgentCoreBrowserManager):
                browser_manager.set_session_id(session_id)

            # Create orchestrator (adapters are already configured for AgentCore)
            orchestrator = GraphOrchestrator(headless=True, storage_state=storage_state)

            # Run complete pipeline with all parameters
            # Use AGENTCORE_PIPELINE_TIMEOUT to respect platform limits
            result = await orchestrator.run_pipeline(
                target_url=target_url,
                seed_utterance=seed_utterance,
                max_turns=max_turns,
                output_dir=output_dir,
                persona_ids=persona_ids,
                arato_api_url=arato_api_url,
                arato_api_key=arato_api_key,
                thread_id=thread_id,
                max_parallel=max_parallel,
                org_id=org_id,
                task_id=task_id,
                goal=goal,
                timeout=AGENTCORE_PIPELINE_TIMEOUT,
                storage_state=storage_state,
                task=task,
                polling_client=polling_client,
                broadcast_identity=broadcast_identity,
                force_discovery=force_discovery,
                force_ground_truth=force_ground_truth,
                session_prefix=session_prefix,
                exclude_persona_ids=exclude_persona_ids,
                include_eu_ai_act_report=include_eu_ai_act_report,
                domain=domain,
                test_suite=test_suite,
                target_urls=target_urls,
            )

            logger.info(f"Async pipeline completed for session {session_id}")

            # Save final result only if we have an output directory (chat mode)
            # Discovery mode doesn't need a final_result.json
            if output_dir:
                from utils import save_json_file

                result_file = Path(output_dir) / FINAL_RESULT_FILENAME
                save_json_file(result, result_file)

            return result

        except Exception as e:
            logger.error(f"Error in async pipeline: {e}", exc_info=True)

            # Save error result only if we have an output directory
            if output_dir:
                from utils import save_json_file

                error_result = {
                    "status": "error",
                    "error": str(e),
                    "error_type": type(e).__name__,
                }

                result_file = Path(output_dir) / FINAL_RESULT_FILENAME
                save_json_file(error_result, result_file)

            # Upload crash report + agent.log to S3 for debugging
            # (CloudWatch may not capture logs on AgentCore)
            try:
                import json
                import traceback

                import boto3

                s3_bucket = os.getenv("STORAGE_BUCKET", "arato-agent-artifacts")
                s3_prefix = f"{org_id or 'unknown'}/{task_id or session_id}"
                crash_data = {
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "traceback": traceback.format_exc(),
                    "session_id": session_id,
                    "task_id": task_id,
                }
                s3 = boto3.client(
                    "s3",
                    region_name=os.getenv("AWS_REGION", "us-east-1"),
                )
                s3.put_object(
                    Bucket=s3_bucket,
                    Key=f"{s3_prefix}/crash_report.json",
                    Body=json.dumps(crash_data, indent=2),
                    ContentType="application/json",
                )
                logger.info(
                    f"Crash report uploaded to s3://{s3_bucket}/{s3_prefix}/crash_report.json"
                )

                # Also upload agent.log if it exists
                if output_dir:
                    agent_log_path = Path(output_dir) / "agent.log"
                    if agent_log_path.exists():
                        s3.upload_file(
                            str(agent_log_path),
                            s3_bucket,
                            f"{s3_prefix}/agent.log",
                        )
                        logger.info(
                            f"Agent log uploaded to s3://{s3_bucket}/{s3_prefix}/agent.log"
                        )
            except Exception as upload_err:
                logger.error(f"Failed to upload crash report to S3: {upload_err}")

            raise


__all__ = ["AWSAgentCorePlatformAdapter"]
