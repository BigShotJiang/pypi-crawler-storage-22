#!/usr/bin/env python3
"""AgentCore Runtime Entry Point.

Main application entry point for AWS Bedrock AgentCore deployment.
This file now delegates to the AWS AgentCore platform adapter.

IMPORTANT: Keep module-level imports minimal to reduce cold-start time.
AgentCore MicroVMs must initialize within 120s. Heavy imports (browser-use,
playwright, strands, etc.) are deferred to first invocation via _get_adapter().

IMPORTANT: The @app.entrypoint handler must NOT perform blocking operations.
Blocking the main event loop also blocks the /ping health check endpoint,
causing AgentCore to think the MicroVM is dead and terminate it.
Long-running work must be dispatched to a separate thread.
"""

import asyncio
import logging
import os
import sys
import threading
from typing import Any

from bedrock_agentcore.runtime import BedrockAgentCoreApp

# Only import lightweight constants at module level
from constants import (
    DEFAULT_MAX_TURNS,
    DEFAULT_SEED_UTTERANCE,
)
from platforms.aws_agentcore.platform_constants import (
    AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS,
)

# Configure logging to write to STDOUT (AgentCore captures stdout → CloudWatch).
# OTEL is stripped from our Dockerfile, so we must emit logs directly to stdout.
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stdout,
    format="%(asctime)s %(levelname)-5s [%(name)s] %(message)s",
    force=True,
)
logger = logging.getLogger(__name__)

# Attach CloudWatch handler so logs reach CloudWatch even without OTEL.
# Best-effort: if boto3 or CloudWatch is unavailable, we silently skip.
try:
    from utils.cloudwatch_handler import CloudWatchHandler

    _cw_log_group = os.getenv(
        "CLOUDWATCH_LOG_GROUP",
        "/aws/bedrock-agentcore/runtimes/arato_agent-5x1zoK9pSm-DEFAULT",
    )
    _cw_handler = CloudWatchHandler(
        log_group=_cw_log_group,
        region=os.getenv("AWS_REGION"),
    )
    _cw_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)-5s [%(name)s] %(message)s")
    )
    logging.getLogger().addHandler(_cw_handler)
    logger.info(
        f"CloudWatch handler attached: {_cw_log_group}/{_cw_handler.log_stream}"
    )
except Exception as _cw_err:
    logger.debug(f"CloudWatch handler not attached: {_cw_err}")
    # Non-fatal: stdout logging still works

# Reduce noise from chatty loggers
logging.getLogger("botocore.credentials").setLevel(logging.WARNING)
logging.getLogger("botocore.httpsession").setLevel(logging.WARNING)
logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)

# Initialize AgentCore app (lightweight)
app = BedrockAgentCoreApp()

# Adapter is created lazily on first invocation to reduce cold-start time
_adapter = None


def _get_adapter():
    """Lazily initialize the platform adapter on first use."""
    global _adapter
    if _adapter is None:
        from platforms.aws_agentcore import AWSAgentCorePlatformAdapter
        from platforms.aws_agentcore.platform_constants import DEFAULT_AWS_REGION

        logger.info("Initializing platform adapter (deferred from cold start)...")
        _adapter = AWSAgentCorePlatformAdapter(
            region=os.getenv("AWS_REGION", DEFAULT_AWS_REGION),
            memory_id=os.getenv("BEDROCK_AGENTCORE_MEMORY_ID"),
        )
    return _adapter


def _normalize_max_turns(value: Any, default: int = DEFAULT_MAX_TURNS) -> int:
    """Convert max_turns to a positive integer.

    Inlined here to avoid importing ChatRunner (which pulls in heavy deps).
    """
    try:
        normalized = int(value)
    except (TypeError, ValueError):
        logger.warning(f"Invalid max_turns '{value}', using default {default}")
        return default
    if normalized <= 0:
        return 1
    return normalized


def _run_pipeline_in_thread(
    adapter,
    task_id_agentcore: int,
    **pipeline_kwargs,
) -> None:
    """Run the pipeline in a dedicated thread with its own event loop.

    This is the key pattern for long-running AgentCore agents:
    - The main event loop stays free for /ping health checks
    - app.add_async_task() keeps ping reporting HEALTHY_BUSY
    - The pipeline runs in an isolated thread with its own asyncio loop
    - app.complete_async_task() signals completion when done

    Args:
        adapter: The platform adapter instance
        task_id_agentcore: Task ID from app.add_async_task() for health tracking
        **pipeline_kwargs: All arguments forwarded to adapter._run_pipeline_async()
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        logger.info("Pipeline thread started, running async pipeline...")
        sys.stdout.flush()
        loop.run_until_complete(adapter._run_pipeline_async(**pipeline_kwargs))
        logger.info("Pipeline thread completed successfully")
    except Exception as e:
        logger.error(f"Pipeline thread failed: {e}", exc_info=True)
    finally:
        app.complete_async_task(task_id_agentcore)
        loop.close()
        logger.info("Pipeline thread cleaned up, async task completed")
        sys.stdout.flush()


@app.entrypoint
async def invoke(payload: dict[str, Any], context: Any) -> dict[str, Any]:
    """Main entry point for AgentCore Runtime invocations.

    Two invocation modes:

    1. **Polling mode** (Lambda poller): Send {"parameter_prefix": "/agent_id/polling"}.
       Returns immediately with {"status": "accepted"}. The pipeline runs in the
       background via @app.async_task and reports results to the control server.

    2. **Direct mode** (CLI): Send full payload with target_url. Dispatches the
       pipeline to a background thread and returns immediately. The thread runs
       with its own event loop so it doesn't block /ping health checks.
    """
    try:
        import json

        logger.info(f"RAW PAYLOAD RECEIVED: {json.dumps(payload, indent=2)}")

        # Check if this is a polling mode invocation
        parameter_prefix = payload.get("parameter_prefix")
        if parameter_prefix:
            logger.info(f"Polling mode detected with prefix: {parameter_prefix}")
            # Use @app.async_task decorated function to keep MicroVM alive.
            # Return immediately so the Lambda caller doesn't block.
            # The pipeline runs in the background and reports results to
            # the control server via TaskPollingClient.
            asyncio.ensure_future(poll_and_execute(parameter_prefix))
            return {
                "status": "accepted",
                "message": "Polling task started in background",
            }

        # Extract payload parameters
        target_url = payload.get("target_url")
        if not target_url:
            return {
                "status": "error",
                "error": "target_url is required (or use parameter_prefix for polling mode)",
                "usage": {
                    "target_url": "REQUIRED - URL to test (e.g., https://example.com)",
                    "parameter_prefix": "ALTERNATIVE - SSM prefix for polling mode (e.g., /agent_id/polling)",
                    "persona_id": "optional - single persona with multiplier (e.g., 'malicious_user:5')",
                    "persona_ids": "optional - list of personas with multipliers (e.g., ['malicious_user:10', 'compliance_user:5'])",
                    "seed_utterance": "optional - first message (default: Hello!)",
                    "max_turns": f"optional - conversation turns (default: {DEFAULT_MAX_TURNS})",
                },
            }

        # Handle both persona_id (singular) and persona_ids (plural)
        persona_id = payload.get("persona_id")
        persona_ids = payload.get("persona_ids")

        # Convert single persona_id to list format
        if persona_id and not persona_ids:
            # Handle case where persona_id is already a list (user error)
            if isinstance(persona_id, list):
                persona_ids = persona_id
            else:
                persona_ids = [persona_id]
        elif not persona_id and not persona_ids:
            # No persona specified - use default or None
            persona_ids = None

        seed_utterance = payload.get("seed_utterance", DEFAULT_SEED_UTTERANCE)
        raw_max_turns = payload.get("max_turns", DEFAULT_MAX_TURNS)
        max_turns = _normalize_max_turns(raw_max_turns)
        max_parallel = payload.get(
            "max_parallel", AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS
        )

        # Extract optional Arato logging parameters
        arato_api_url = payload.get("arato_api_url")
        arato_api_key = payload.get("arato_api_key")

        # Extract optional organization ID for S3 prefix
        org_id = payload.get("org_id")
        if org_id:
            logger.info(f"Organization ID: {org_id}")

        # Extract optional task ID
        task_id = payload.get("task_id")
        if task_id:
            logger.info(f"Task ID: {task_id}")

        # Extract optional session_id
        session_id = payload.get("session_id")

        # Extract goal parameter (default to "chat" for backwards compatibility)
        goal = payload.get("goal", "chat")

        # Extract optional flags
        force_discovery = payload.get("force_discovery", False)
        force_ground_truth = payload.get("force_ground_truth", False)
        storage_state = payload.get("storage_state")
        broadcast_identity = payload.get("broadcast_identity", False)
        exclude_persona_ids = payload.get("exclude_persona_ids")
        include_eu_ai_act_report = payload.get("include_eu_ai_act_report", False)
        session_prefix = payload.get("session_prefix")
        domain = payload.get("domain")
        test_suite_id = payload.get("test_suite_id")
        target_urls = payload.get("target_urls")

        # Compute output_dir for the session
        adapter = _get_adapter()
        resolved_session_id = adapter.resolve_session_id(session_id, context)
        output_dir = None
        if goal == "chat":
            session_path = adapter.get_session_directory(resolved_session_id)
            output_dir = str(session_path)

        # Register background task with AgentCore for health tracking.
        # This makes /ping return HEALTHY_BUSY, keeping the MicroVM alive.
        task_id_agentcore = app.add_async_task(
            "chat_pipeline",
            {"session_id": resolved_session_id, "target_url": target_url},
        )
        logger.info(
            f"Registered async task {task_id_agentcore} for session {resolved_session_id}"
        )

        # Dispatch pipeline to a SEPARATE THREAD with its own event loop.
        # This is critical: the main event loop must stay free for /ping
        # health check responses. CDP/Playwright operations can block the
        # event loop for extended periods, which would cause AgentCore to
        # think the MicroVM is unresponsive and terminate it.
        pipeline_thread = threading.Thread(
            target=_run_pipeline_in_thread,
            kwargs={
                "adapter": adapter,
                "task_id_agentcore": task_id_agentcore,
                "target_url": target_url,
                "seed_utterance": seed_utterance,
                "max_turns": max_turns,
                "output_dir": output_dir,
                "persona_ids": persona_ids,
                "arato_api_url": arato_api_url,
                "arato_api_key": arato_api_key,
                "session_id": resolved_session_id,
                "max_parallel": max_parallel,
                "org_id": org_id,
                "task_id": task_id,
                "goal": goal,
                "storage_state": storage_state,
                "force_discovery": force_discovery,
                "force_ground_truth": force_ground_truth,
                "exclude_persona_ids": exclude_persona_ids,
                "include_eu_ai_act_report": include_eu_ai_act_report,
                "broadcast_identity": broadcast_identity,
                "session_prefix": session_prefix,
                "domain": domain,
                "test_suite_id": test_suite_id,
                "target_urls": target_urls,
            },
            daemon=True,
        )
        pipeline_thread.start()

        return {
            "status": "started",
            "message": "Pipeline dispatched to background thread (main loop free for /ping)",
            "session_id": resolved_session_id,
            "target_url": target_url,
            "task_id": task_id,
            "org_id": org_id,
        }

    except Exception as e:
        logger.error(f"Error starting AgentCore invocation: {e}", exc_info=True)
        return {"status": "error", "error": str(e), "error_type": type(e).__name__}


@app.async_task
async def poll_and_execute(parameter_prefix: str | None = None) -> dict[str, Any]:
    """Poll for a task and execute it (for EventBridge Scheduler).

    This is a one-shot polling function designed to be triggered by
    EventBridge Scheduler on a recurring schedule.

    Args:
        parameter_prefix: SSM parameter prefix for configuration. If None, uses
            /{agent_id}/polling where agent_id is read from .bedrock_agentcore.yaml

    Returns:
        Execution result with status and details
    """
    from platforms.aws_agentcore.polling_handler import poll_and_execute_once

    return await poll_and_execute_once(parameter_prefix)


if __name__ == "__main__":
    app.run()
