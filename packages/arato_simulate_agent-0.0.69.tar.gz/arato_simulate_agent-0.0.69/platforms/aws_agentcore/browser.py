"""AWS AgentCore Browser manager implementation.

This module implements browser management for AWS Bedrock AgentCore Browser,
providing CDP-based remote browser access.
"""

from __future__ import annotations

import asyncio
import contextvars
import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from types import TracebackType
from typing import Any, cast

from browser_use import Browser

from constants import (
    BROWSER_MAX_HEIGHT,
    BROWSER_MAX_WIDTH,
    HITL_DEFAULT_TIMEOUT_SECONDS,
    HITL_POLL_INTERVAL_SECONDS,
)
from core.browser.base import BrowserManager
from utils.browser_use_patches import (
    patch_browser_use_debug_messages,
    patch_browser_use_dom_timeout,
    patch_browser_use_dom_warning,
    patch_browser_use_profile_warning,
    patch_browser_use_screensaver,
    patch_browser_use_timeout,
    patch_websocket_keepalive_timeout,
)
from utils.hitl_utils import (
    HITLState,
    create_intervention_request,
    create_intervention_response,
    log_intervention_request,
    log_intervention_response,
)

logger = logging.getLogger(__name__)

patch_browser_use_screensaver()
patch_browser_use_debug_messages()
patch_browser_use_timeout()
patch_browser_use_dom_timeout()
patch_browser_use_dom_warning()
patch_browser_use_profile_warning()
patch_websocket_keepalive_timeout()

_agentcore_cdp_headers: contextvars.ContextVar[dict[str, Any] | None] = (
    contextvars.ContextVar("agentcore_cdp_headers", default=None)
)
_cdp_patch_applied = False


def _ensure_agentcore_cdp_header_patch() -> None:
    """Monkey patch browser-use to forward additional headers to CDP connects."""
    global _cdp_patch_applied

    if _cdp_patch_applied:
        return

    logger.info("Applying AgentCore CDP header patch")

    try:
        from browser_use.browser import session as session_module
    except ImportError as exc:
        raise ImportError(
            "browser-use must be installed to use AgentCore Browser integration."
        ) from exc

    session = cast(Any, session_module)
    original_cdp_client: Any = session.CDPClient

    def _cdp_client_factory(url: str, *args: Any, **kwargs: Any) -> Any:
        headers: dict[str, str] | None = None
        if args:
            headers = args[0]
            args = args[1:]
        if headers is None:
            headers = kwargs.pop("additional_headers", None)
        if headers is None:
            headers = _agentcore_cdp_headers.get()
        if headers is not None:
            logger.info(
                "AgentCore CDP headers applied (keys=%s)",
                sorted(headers.keys()),
            )
            kwargs["additional_headers"] = headers
        return original_cdp_client(url, *args, **kwargs)

    session.CDPClient = _cdp_client_factory
    _cdp_patch_applied = True


class AgentCoreBrowserSession:
    """Context manager for AgentCore Browser sessions."""

    def __init__(self, region: str = "us-east-1") -> None:
        """Initialize the AgentCore Browser session manager.

        Args:
            region: AWS region for AgentCore Browser
        """
        self.region = region
        self._session_client: Any = None
        self._client: Any = None

    def __enter__(self) -> Any:
        """Start AgentCore Browser session."""
        try:
            from bedrock_agentcore.tools.browser_client import browser_session
        except ImportError as e:
            raise ImportError(
                "bedrock-agentcore is required for AgentCore Browser. "
                "Install it with: pip install bedrock-agentcore"
            ) from e

        logger.info(f"Starting AgentCore Browser session in region: {self.region}")

        # Check for custom browser ARN/ID from environment
        # This is set by agentcore_deploy.py when VPC is configured
        browser_arn = os.getenv("BEDROCK_AGENTCORE_BROWSER_ARN")

        if browser_arn:
            # Extract ID from ARN if needed (ARN format: .../browser-custom/ID)
            if "/" in browser_arn:
                browser_id = browser_arn.split("/")[-1]
                logger.info(f"Using custom browser resource: {browser_id} (from ARN)")
                self._session_client = browser_session(
                    self.region, identifier=browser_id
                )
            else:
                logger.info(f"Using custom browser resource: {browser_arn}")
                self._session_client = browser_session(
                    self.region, identifier=browser_arn
                )
        else:
            self._session_client = browser_session(self.region)

        self._client = self._session_client.__enter__()
        return self._client

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Stop AgentCore Browser session."""
        if self._session_client:
            logger.info("Stopping AgentCore Browser session")
            self._session_client.__exit__(exc_type, exc_val, exc_tb)
            self._session_client = None
            self._client = None


class AgentCoreBrowserManager(BrowserManager):
    """Browser manager for AWS AgentCore Browser."""

    def __init__(self, region: str = "us-east-1"):
        """Initialize AgentCore browser manager.

        Args:
            region: AWS region for AgentCore Browser
        """
        self.region = region
        self._session_id: str | None = None  # Internal browser-use session ID
        self._agentcore_session_id: str | None = None  # AgentCore browser session ID
        self._agentcore_browser_identifier: str | None = (
            None  # AgentCore browser identifier
        )
        self._polling_client: Any | None = (
            None  # TaskPollingClient for HITL via server DB
        )
        self._task_id: str | None = None  # Current agent run task ID

    def set_polling_client(
        self, polling_client: Any, task_id: str | None = None
    ) -> None:
        """Set the polling client for server-side HITL operations.

        Args:
            polling_client: TaskPollingClient instance
            task_id: Current agent run task ID
        """
        self._polling_client = polling_client
        self._task_id = task_id
        logger.info(f"Polling client set for HITL (task_id={task_id})")

    def set_session_id(self, session_id: str) -> None:
        """Set the session ID for this browser manager.

        Args:
            session_id: Browser session ID
        """
        self._session_id = session_id
        logger.info(f"Session ID set for AgentCore Browser: {session_id}")

    def get_session_info(self) -> dict[str, str | None]:
        """Get AgentCore browser session info for DCV viewer."""
        return {
            "session_id": self._agentcore_session_id,
            "browser_type": "agentcore",
            "browser_identifier": self._agentcore_browser_identifier,
        }

    @asynccontextmanager
    async def create_browser(self, **kwargs: Any) -> AsyncIterator[Browser]:
        """Create AgentCore Browser instance via CDP.

        Args:
            **kwargs: Browser configuration (passed to Browser())

        Yields:
            Browser instance connected to AgentCore Browser
        """
        session = AgentCoreBrowserSession(region=self.region)
        headers_token: contextvars.Token[dict[str, str] | None] | None = None

        try:
            # Start AgentCore Browser session
            client = session.__enter__()

            # Capture AgentCore browser session ID and identifier
            self._agentcore_session_id = getattr(client, "session_id", None)
            self._agentcore_browser_identifier = getattr(client, "identifier", None)
            logger.info(f"AgentCore browser session ID: {self._agentcore_session_id}")
            logger.info(
                f"AgentCore browser identifier: {self._agentcore_browser_identifier}"
            )

            # Get CDP WebSocket URL and auth headers
            ws_url, headers = client.generate_ws_headers()
            logger.info(f"AgentCore Browser CDP URL: {ws_url}")

            _ensure_agentcore_cdp_header_patch()
            headers_token = _agentcore_cdp_headers.set(headers)

            browser = Browser(
                cdp_url=ws_url,
                headers=headers,
                **kwargs,
            )

            logger.info("✓ Connected to AgentCore Browser via CDP")
            yield browser

        finally:
            # Ensure the browser instance is closed first
            try:
                if "browser" in locals() and browser:
                    logger.info("Closing browser-use Browser instance")
                    await browser.kill()
            except Exception as e:
                logger.warning(f"Error closing browser-use instance: {e}")

            if headers_token is not None:
                _agentcore_cdp_headers.reset(headers_token)

            try:
                session.__exit__(None, None, None)
            except Exception as e:
                logger.warning(f"Error during AgentCore session cleanup: {e}")

    def setup_browser_kwargs(
        self,
        headless: bool = False,
        disable_security: bool = False,
        record_video_dir: str | None = None,
        record_har_path: str | None = None,
        record_har_content: str | None = None,
        storage_state: str | None = None,
        permissions: list[str] | None = None,
        **extra_kwargs: Any,
    ) -> dict[str, Any]:
        """Prepare browser kwargs for AgentCore Browser.

        Note: headless parameter is ignored for AgentCore (cloud browser).

        Args:
            headless: Ignored for AgentCore
            disable_security: Disable browser security features
            record_video_dir: Directory to save video recordings
            record_har_path: Path to save HAR file
            record_har_content: HAR content mode
            storage_state: Path to JSON file with saved authentication (cookies, localStorage)
            permissions: List of permissions to grant (e.g., ['microphone'])
            **extra_kwargs: Additional configuration

        Returns:
            Browser configuration dict
        """
        browser_kwargs: dict[str, Any] = {
            "window_size": {"width": BROWSER_MAX_WIDTH, "height": BROWSER_MAX_HEIGHT},
        }

        if disable_security:
            browser_kwargs["disable_security"] = disable_security

        if record_video_dir:
            browser_kwargs["record_video_dir"] = record_video_dir

        if record_har_path:
            browser_kwargs["record_har_path"] = record_har_path
            if record_har_content:
                browser_kwargs["record_har_content"] = record_har_content

        if storage_state:
            browser_kwargs["storage_state"] = storage_state
            logger.info(
                f"♻️  Loading authentication from storage_state: {storage_state}"
            )

        browser_kwargs.update(extra_kwargs)

        # Apply permissions to new_context_config (merging with existing if any)
        if permissions:
            new_context_config = browser_kwargs.get("new_context_config", {}).copy()
            new_context_config["permissions"] = permissions
            browser_kwargs["new_context_config"] = new_context_config
            logger.info(f"🎤 Granting permissions for AgentCore: {permissions}")

            # Warn about Web Bot Auth incompatibility with new contexts
            if os.getenv("BEDROCK_AGENTCORE_BROWSER_ARN"):
                logger.warning(
                    "⚠️  Web Bot Auth may not be active: new_context_config creates "
                    "a new browser context. Per AWS docs, Web Bot Auth only works in "
                    "the default browser context."
                )

        return browser_kwargs

    async def get_current_url(self) -> str | None:
        """Get current URL from browser.

        For AWS AgentCore, the browser is managed remotely and we don't have
        direct access to the browser instance from the manager. This should be
        passed in from the agent/controller context.

        Returns:
            None (URL should be passed to request_intervention)
        """
        # AWS AgentCore doesn't maintain direct browser reference
        # URL should be captured by the agent before calling intervention
        return None

    async def request_intervention(
        self,
        reason: str,
        intervention_type: str = "custom",
        session_id: str | None = None,
        timeout_seconds: int | None = None,
        url_before: str | None = None,
        screenshot_url: str | None = None,
    ) -> str:
        """Request HITL intervention via Arato server DB.

        Creates a server-side HITLIntervention record, which triggers
        WebSocket broadcast, webhook, and email notifications.

        Args:
            reason: Why intervention is needed
            intervention_type: Type of intervention (e.g., "captcha", "login")
            session_id: Browser session ID (uses manager's session_id if not provided)
            timeout_seconds: Maximum time to wait for response
            url_before: URL before intervention (for tracking)
            screenshot_url: URL/path to screenshot of the page

        Returns:
            Intervention ID from the server

        Raises:
            ValueError: If session_id is not provided and not set on manager
            RuntimeError: If no polling client is configured or server request fails
        """
        effective_session_id = session_id or self._session_id

        if not effective_session_id:
            raise ValueError(
                "session_id is required for AWS AgentCore HITL interventions. "
                "Either pass it explicitly or set it on the browser manager using set_session_id()."
            )

        if not self._polling_client:
            raise RuntimeError(
                "Polling client is required for HITL interventions. "
                "Call set_polling_client() before requesting intervention."
            )

        task_id = self._task_id
        if not task_id:
            raise RuntimeError(
                "task_id is required for HITL interventions. "
                "Pass it via set_polling_client(client, task_id=...)."
            )

        timeout = (
            timeout_seconds
            if timeout_seconds is not None
            else HITL_DEFAULT_TIMEOUT_SECONDS
        )

        # Create intervention request for local logging
        request = create_intervention_request(
            intervention_id="pending",  # Server will assign the real ID
            reason=reason,
            intervention_type=intervention_type,  # type: ignore
            session_id=effective_session_id,
            metadata={
                "timeout_seconds": timeout,
                "platform": "aws_agentcore",
                "screenshot_url": screenshot_url,
            },
        )
        log_intervention_request(request)

        try:
            # Notify the Arato server — creates DB record + triggers notifications
            result = await self._polling_client.notify_hitl(
                task_id=task_id,
                intervention_type=intervention_type,
                reason=reason,
                timeout_seconds=timeout,
                url_before=url_before,
                screenshot_url=screenshot_url,
                agentcore_session_id=self._agentcore_session_id,
                metadata={"platform": "aws_agentcore"},
            )

            intervention_id = result.get("intervention_id", "")
            if not intervention_id:
                raise RuntimeError(
                    "Server returned empty intervention_id — HITL record may not have been created"
                )
            logger.info(
                f"✓ HITL intervention requested: {intervention_id} for session {effective_session_id}"
            )
            logger.info(f"  Type: {intervention_type}")
            logger.info(f"  Reason: {reason}")
            logger.info(f"  Timeout: {timeout}s")
            logger.warning(
                "⚠️  Agent is now WAITING for human intervention. "
                "Use the Arato dashboard to complete the task."
            )

            return intervention_id

        except Exception as e:
            logger.error(f"Failed to create HITL intervention on server: {e}")
            raise RuntimeError(f"HITL request failed: {e}") from e

    async def check_intervention_state(self, intervention_id: str) -> dict[str, Any]:
        """Check the current state of an intervention by polling the Arato server.

        Args:
            intervention_id: The intervention ID to check

        Returns:
            Dictionary with keys:
                - state: Current state (waiting, completed, timeout, error)
                - intervention_id: The intervention ID
                - completed_at: Timestamp if completed (optional)
                - url_after: URL after intervention (optional)
                - error_message: Error message if state is error (optional)
        """
        if not self._polling_client:
            return {
                "state": HITLState.ERROR.value,
                "intervention_id": intervention_id,
                "error_message": "No polling client configured",
            }

        try:
            data = await self._polling_client.poll_hitl_state(intervention_id)
            return {
                "state": data.get("state", HITLState.ERROR.value),
                "intervention_id": data.get("id", intervention_id),
                "completed_at": data.get("completed_at"),
                "url_after": data.get("url_after"),
                "error_message": data.get("error_message"),
            }
        except Exception as e:
            logger.error(f"Failed to check HITL intervention state: {e}")
            return {
                "state": HITLState.ERROR.value,
                "intervention_id": intervention_id,
                "error_message": str(e),
            }

    async def wait_for_intervention_completion(
        self,
        intervention_id: str,
        timeout_seconds: int | None = None,
        poll_interval_seconds: int = HITL_POLL_INTERVAL_SECONDS,
    ) -> dict[str, Any]:
        """Wait for human to complete the intervention by polling the server DB.

        Polls the Arato server until:
        - State becomes 'completed' (returns response)
        - Timeout is reached (notifies server + raises TimeoutError)
        - Error occurs (raises RuntimeError)

        Args:
            intervention_id: The intervention ID to wait for
            timeout_seconds: Maximum time to wait (uses default if None)
            poll_interval_seconds: How often to check state

        Returns:
            Dictionary with intervention response details

        Raises:
            TimeoutError: If intervention times out
            RuntimeError: If intervention encounters an error
        """
        timeout = timeout_seconds or HITL_DEFAULT_TIMEOUT_SECONDS
        max_attempts = int(timeout / poll_interval_seconds)
        attempt = 0

        logger.info(
            f"Waiting for HITL intervention {intervention_id} (timeout={timeout}s, poll_interval={poll_interval_seconds}s)"
        )

        while attempt < max_attempts:
            state_response = await self.check_intervention_state(intervention_id)
            state = state_response.get("state")

            if state == HITLState.COMPLETED.value:
                response = create_intervention_response(
                    intervention_id=intervention_id,
                    state=HITLState.COMPLETED,
                    metadata=state_response,
                )
                log_intervention_response(response)
                logger.info(
                    f"✓ HITL intervention {intervention_id} completed successfully"
                )
                return state_response

            if state == HITLState.ERROR.value:
                error_msg = state_response.get(
                    "error_message", "Unknown error occurred"
                )
                response = create_intervention_response(
                    intervention_id=intervention_id,
                    state=HITLState.ERROR,
                    error_message=error_msg,
                )
                log_intervention_response(response)
                raise RuntimeError(f"HITL intervention failed: {error_msg}")

            # Still waiting, continue polling
            attempt += 1
            if attempt < max_attempts:
                await asyncio.sleep(poll_interval_seconds)
                if attempt % 10 == 0:  # Log every 30 seconds
                    logger.info(
                        f"Still waiting for HITL intervention {intervention_id} ({attempt * poll_interval_seconds}s elapsed)"
                    )

        # Timeout reached — notify server so it can update DB + fire webhook
        if self._polling_client:
            try:
                await self._polling_client.notify_hitl_timeout(intervention_id)
            except Exception as e:
                logger.warning(f"Failed to notify server of HITL timeout: {e}")

        response = create_intervention_response(
            intervention_id=intervention_id,
            state=HITLState.TIMEOUT,
            error_message=f"Intervention timed out after {timeout}s",
        )
        log_intervention_response(response)
        raise TimeoutError(
            f"HITL intervention {intervention_id} timed out after {timeout}s"
        )

    async def cancel_intervention(
        self,
        intervention_id: str,
        reason: str | None = None,
    ) -> bool:
        """Cancel a pending intervention request.

        Uses the server's timeout endpoint to mark the intervention as resolved.
        The server records the state as 'timeout' (the server-side equivalent of
        agent-initiated cancellation). A dedicated 'cancel' state may be added
        in the future if the distinction matters for analytics.

        Args:
            intervention_id: The intervention ID to cancel
            reason: Optional reason for cancellation

        Returns:
            True if cancellation notified, False if no polling client
        """
        if not self._polling_client:
            logger.warning(
                f"Cannot cancel intervention {intervention_id}: no polling client"
            )
            return False

        try:
            await self._polling_client.notify_hitl_timeout(intervention_id)
            logger.info(
                f"✓ Cancelled intervention {intervention_id}"
                + (f" (reason: {reason})" if reason else "")
            )
            return True
        except Exception as e:
            logger.error(f"Failed to cancel intervention {intervention_id}: {e}")
            return False

    # Note: capture_screenshot() inherited from BrowserManager base class


__all__ = [
    "AgentCoreBrowserManager",
    "AgentCoreBrowserSession",
]
