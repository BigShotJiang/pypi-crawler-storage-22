"""Constants specific to AWS AgentCore platform."""

DEFAULT_AWS_REGION = "us-east-1"
DEFAULT_AGENTCORE_RETRY_CONFIG = {"max_attempts": 5, "mode": "adaptive"}

# AgentCore MicroVMs have 2 vCPU / 8GB RAM with remote browsers.
# Doubled from the original 25 after testing showed headroom, but kept
# conservative (50 instead of 100) until load testing confirms higher values
# won't cause OOM or file descriptor exhaustion. This can be overridden via
# the payload's max_parallel field. For 100+ total personas, the semaphore
# queues them and processes in batches of max_parallel.
AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS = 50
