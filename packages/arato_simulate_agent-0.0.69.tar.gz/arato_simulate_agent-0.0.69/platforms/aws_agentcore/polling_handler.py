"""AWS AgentCore polling mode handler with SSM configuration."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

from core.polling.client import TaskPollingClient
from core.polling.config import PollingConfig
from core.polling.observability import PollingObservability
from platforms.aws_agentcore.adapter import AWSAgentCorePlatformAdapter
from utils.bedrock_config import get_agent_id

logger = logging.getLogger(__name__)


@dataclass
class AgentCorePollingConfig:
    """Configuration for AWS AgentCore polling mode with SSM support."""

    api_key: str
    task_endpoint: str
    polling_interval: int = 30
    region: str = "us-east-1"
    circuit_breaker_threshold: int = 5
    circuit_breaker_timeout: int = 60

    @classmethod
    def from_ssm(cls, parameter_prefix: str | None = None) -> AgentCorePollingConfig:
        """Load configuration from AWS SSM Parameter Store.

        Args:
            parameter_prefix: SSM parameter prefix. If None, uses /{agent_id}/polling
                where agent_id is read from .bedrock_agentcore.yaml

        Returns:
            AgentCorePollingConfig instance

        SSM Parameters:
            - {prefix}/api_key (SecureString)
            - {prefix}/task_endpoint (String)
            - {prefix}/polling_interval (String, optional)
            - {prefix}/circuit_breaker_threshold (String, optional)
            - {prefix}/circuit_breaker_timeout (String, optional)
        """
        import boto3

        # Use agent ID from config if prefix not provided
        if parameter_prefix is None:
            agent_id = get_agent_id()
            parameter_prefix = f"/{agent_id}/polling"
            logger.info(f"Using SSM parameter prefix: {parameter_prefix}")

        region = os.getenv("AWS_REGION", "us-east-1")
        ssm = boto3.client("ssm", region_name=region)

        def get_param(name: str, default: str | None = None) -> str:
            """Get SSM parameter value."""
            try:
                response = ssm.get_parameter(
                    Name=f"{parameter_prefix}/{name}", WithDecryption=True
                )
                return str(response["Parameter"]["Value"])
            except ssm.exceptions.ParameterNotFound as e:
                if default is not None:
                    logger.warning(
                        f"SSM parameter {parameter_prefix}/{name} not found, using default: {default}"
                    )
                    return default
                raise ValueError(
                    f"Required SSM parameter not found: {parameter_prefix}/{name}"
                ) from e

        return cls(
            api_key=get_param("api_key"),
            task_endpoint=get_param("task_endpoint"),
            polling_interval=int(get_param("polling_interval", "30")),
            region=region,
            circuit_breaker_threshold=int(get_param("circuit_breaker_threshold", "5")),
            circuit_breaker_timeout=int(get_param("circuit_breaker_timeout", "60")),
        )

    def to_polling_config(self) -> PollingConfig:
        """Convert to core PollingConfig."""
        return PollingConfig(
            task_endpoint=self.task_endpoint,
            api_key=self.api_key,
            polling_interval=self.polling_interval,
        )


async def poll_and_execute_once(
    parameter_prefix: str | None = None,
) -> dict[str, Any]:
    """Poll for a task and execute it (one-shot for scheduled execution).

    This function is designed to be called by EventBridge Scheduler on a
    recurring schedule. Each invocation polls once, executes if a task is
    available, and exits.

    Args:
        parameter_prefix: SSM parameter prefix for configuration. If None, uses
            /{agent_id}/polling where agent_id is read from .bedrock_agentcore.yaml

    Returns:
        Execution result dictionary with status and details
    """
    obs = PollingObservability()
    correlation_id = obs.generate_correlation_id()

    try:
        # Load configuration from SSM
        logger.info(f"Loading configuration from SSM: {parameter_prefix}")
        agentcore_config = AgentCorePollingConfig.from_ssm(parameter_prefix)
        config = agentcore_config.to_polling_config()

        # Initialize AWS adapter to get agent identity
        adapter = AWSAgentCorePlatformAdapter(region=agentcore_config.region)
        agent_identity = adapter.get_agent_identity()

        # Initialize client
        client = TaskPollingClient(
            task_endpoint=config.task_endpoint,
            api_key=config.api_key,
            agent_name=agent_identity.name or "unknown",
            agent_platform=agent_identity.platform or "aws_agentcore",
        )
        obs.log_poll_started(correlation_id, config.task_endpoint)

        # Poll for task (already returns validated TaskPayload)
        task = await client.poll_task()

        if task is None:
            obs.log_poll_no_tasks(correlation_id, 200)
            await client.close()
            return {"status": "no_task", "correlation_id": correlation_id}

        obs.log_poll_task_received(correlation_id, len(task.model_dump()))
        logger.info(f"Task validated: {task.target_url}")

        # Inject logging configuration
        task = client.inject_logging_config(task)

        # Generate session ID for this execution
        session_id = adapter.resolve_session_id(task.task_id, None)

        # Execute task
        obs.log_task_execution_started(
            task_id=task.task_id or "unknown",
            target_url=str(task.target_url),
            personas=",".join(task.persona_ids) if task.persona_ids else "none",
        )

        result = await adapter._run_pipeline_async(
            target_url=str(task.target_url),
            persona_ids=task.persona_ids or [],
            seed_utterance=task.seed_utterance,
            max_turns=task.max_turns,
            output_dir=f"/tmp/sessions/{session_id}",
            arato_api_url=task.arato_api_url,
            arato_api_key=task.arato_api_key,
            session_id=session_id,
            thread_id=None,
            max_parallel=task.max_parallel,
            org_id=task.org_id,
            task_id=task.task_id,
            goal=task.goal.value,
            storage_state=task.storage_state,
            task=task,
            polling_client=client,
            force_discovery=task.force_discovery,
            force_ground_truth=task.force_ground_truth,
            session_prefix=task.session_prefix,
            include_eu_ai_act_report=task.include_eu_ai_act_report,
        )

        obs.log_task_execution_completed(
            task_id=task.task_id or "unknown",
            session_id=result.get("session_id", "N/A"),
            duration_seconds=result.get("duration_seconds", 0),
        )

        await client.close()

        return {
            "status": "success",
            "correlation_id": correlation_id,
            "session_id": result.get("session_id"),
            "task_id": task.task_id or "unknown",
        }

    except Exception as e:
        obs.log_poll_error(correlation_id, e)
        logger.error(f"Polling execution failed: {e}", exc_info=True)
        return {
            "status": "error",
            "correlation_id": correlation_id,
            "error": str(e),
            "error_type": type(e).__name__,
        }
