"""Deployment and management scripts for AWS AgentCore platform."""
