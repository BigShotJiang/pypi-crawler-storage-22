"""
CLI commands for AgentCore deployment and management.
These wrap the agentcore CLI tool for easier usage.
"""

import json
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

import boto3
import yaml

from constants import (
    LLM_PROVIDER_BEDROCK,
    LLM_PROVIDER_VERTEX,
    SSM_PARAM_GOOGLE_CREDENTIALS,
    VPC_ENDPOINT_SERVICE_FORMAT,
    VPC_REQUIRED_ENDPOINTS,
)
from platforms.aws_agentcore.scripts import validate_permissions
from utils import vpc_utils


def _apply_role_permissions(role_name: str | None) -> int:
    """Ensure the required inline policy is attached to the role."""

    if role_name:
        success = validate_permissions.apply_role_permissions(role_name)
        return 0 if success else 1

    try:
        validate_permissions.main()
    except SystemExit as exc:  # pragma: no cover - subprocess-like behavior
        if exc.code is None:
            return 0
        return exc.code if isinstance(exc.code, int) else 1

    return 0


def _check_vpc_dns_settings(ec2_client, vpc_id: str) -> tuple[bool, bool]:
    """Check if VPC has DNS resolution and DNS hostnames enabled.

    Returns:
        Tuple of (dns_support_enabled, dns_hostnames_enabled)
    """
    dns_support = ec2_client.describe_vpc_attribute(
        VpcId=vpc_id, Attribute="enableDnsSupport"
    )
    dns_hostnames = ec2_client.describe_vpc_attribute(
        VpcId=vpc_id, Attribute="enableDnsHostnames"
    )
    return (
        dns_support["EnableDnsSupport"]["Value"],
        dns_hostnames["EnableDnsHostnames"]["Value"],
    )


def _enable_vpc_dns_settings(ec2_client, vpc_id: str) -> None:
    """Enable DNS resolution and DNS hostnames for VPC."""
    print("  📡 Enabling DNS resolution and DNS hostnames...")
    try:
        ec2_client.modify_vpc_attribute(VpcId=vpc_id, EnableDnsSupport={"Value": True})
        ec2_client.modify_vpc_attribute(
            VpcId=vpc_id, EnableDnsHostnames={"Value": True}
        )
        print("  ✅ DNS settings enabled successfully")
    except Exception as e:
        print(f"  ⚠️  Warning: Failed to enable DNS settings: {e}")
        print("     Please enable DNS resolution and DNS hostnames manually")


def _call_agentcore_control(operation: str, region: str, **kwargs) -> dict:
    """Helper to call bedrock-agentcore-control API via AWS CLI.

    Args:
        operation: API operation name (e.g., 'list-browsers', 'create-browser')
        region: AWS region
        **kwargs: API parameters as keyword arguments

    Returns:
        Parsed JSON response
    """
    import json
    import subprocess

    cmd = [
        "aws",
        "bedrock-agentcore-control",
        operation,
        "--region",
        region,
        "--output",
        "json",
        "--no-cli-pager",
    ]

    # Add parameters as CLI arguments
    for key, value in kwargs.items():
        # Convert snake_case to kebab-case for CLI
        cli_key = key.replace("_", "-")
        cmd.extend(
            [
                f"--{cli_key}",
                json.dumps(value) if isinstance(value, dict | list) else str(value),
            ]
        )

    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    return json.loads(result.stdout)


def _configure_custom_browser(
    region: str,
    account_id: str,
    execution_role_arn: str,
    network_configuration: dict | None = None,
    browser_signing: dict | None = None,
    browser_name: str = "arato_agent_browser",
    description: str = "Arato agent browser with Web Bot Auth",
) -> tuple[str | None, str | None]:
    """Configure or verify a custom AgentCore Browser Tool.

    Creates (or reuses) a custom browser resource with optional VPC networking
    and Web Bot Auth signing.

    Args:
        region: AWS region
        account_id: AWS account ID
        execution_role_arn: ARN of the execution role
        network_configuration: Network config dict (defaults to PUBLIC mode)
        browser_signing: Web Bot Auth config, e.g. {"enabled": True}
        browser_name: Name for the browser resource
        description: Description for the browser resource

    Returns:
        Tuple of (browser_id, browser_arn) or (None, None) if failed
    """
    import subprocess

    if network_configuration is None:
        network_configuration = {"networkMode": "PUBLIC"}

    s3_bucket = f"arato-agent-artifacts-{account_id}"
    is_vpc = network_configuration.get("networkMode") == "VPC"

    mode_label = "VPC" if is_vpc else "PUBLIC"
    signing_label = " + Web Bot Auth" if browser_signing else ""
    print(f"\n🌐 Configuring AgentCore Browser Tool ({mode_label}{signing_label})...")

    try:
        # Ensure S3 bucket exists for browser recordings (using AWS CLI to avoid boto3 issues)
        print(f"  📦 Checking S3 bucket: {s3_bucket}")
        check_bucket = subprocess.run(
            ["aws", "s3", "ls", f"s3://{s3_bucket}/", "--region", region],
            capture_output=True,
            text=True,
        )

        if check_bucket.returncode != 0:
            print(f"  📦 Creating S3 bucket: {s3_bucket}")
            create_bucket = subprocess.run(
                ["aws", "s3", "mb", f"s3://{s3_bucket}/", "--region", region],
                capture_output=True,
                text=True,
            )
            if create_bucket.returncode == 0:
                print(f"  ✅ S3 bucket created: {s3_bucket}")
            else:
                print(f"  ⚠️  Failed to create S3 bucket: {create_bucket.stderr}")
                print("  💡 You may need to create it manually")
        else:
            print(f"  ✅ S3 bucket exists: {s3_bucket}")

        # Ensure execution role has S3 permissions for browser recordings
        print("  🔐 Checking execution role S3 permissions...")
        role_name = execution_role_arn.split("/")[-1]

        # Validate extracted role name
        import re

        if not re.match(r"^[\w+=,.@-]{1,64}$", role_name):
            raise ValueError(f"Invalid IAM role name extracted from ARN: '{role_name}'")

        policy_document = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "s3:PutObject",
                        "s3:GetObject",
                        "s3:ListBucket",
                        "s3:GetBucketLocation",
                    ],
                    "Resource": [
                        f"arn:aws:s3:::{s3_bucket}/*",
                        f"arn:aws:s3:::{s3_bucket}",
                    ],
                }
            ],
        }

        # Try to add inline policy for S3 access
        put_policy = subprocess.run(
            [
                "aws",
                "iam",
                "put-role-policy",
                "--role-name",
                role_name,
                "--policy-name",
                "BrowserToolS3Access",
                "--policy-document",
                json.dumps(policy_document),
                "--region",
                region,
            ],
            capture_output=True,
            text=True,
        )

        if put_policy.returncode == 0:
            print("  ✅ S3 permissions added to execution role")
            print("  ⏳ Waiting 10 seconds for IAM propagation...")
            import time

            time.sleep(10)
        else:
            print(f"  ⚠️  Failed to add S3 permissions: {put_policy.stderr}")
            print("  💡 You may need to add them manually")

        # Add Browser Tool permissions to execution role
        print("  🔐 Adding execution role Browser Tool permissions...")

        browser_policy_document = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "bedrock-agentcore:StartBrowserSession",
                        "bedrock-agentcore:StopBrowserSession",
                        "bedrock-agentcore:GetBrowser",
                        "bedrock-agentcore:ConnectBrowserAutomationStream",
                        "bedrock-agentcore:ConnectBrowserLiveViewStream",
                    ],
                    "Resource": f"arn:aws:bedrock-agentcore:{region}:{account_id}:browser-custom/*",
                }
            ],
        }

        put_browser_policy = subprocess.run(
            [
                "aws",
                "iam",
                "put-role-policy",
                "--role-name",
                role_name,
                "--policy-name",
                "BrowserToolAccess",
                "--policy-document",
                json.dumps(browser_policy_document),
                "--region",
                region,
            ],
            capture_output=True,
            text=True,
        )

        if put_browser_policy.returncode == 0:
            print("  ✅ Browser Tool permissions added to execution role")
        else:
            print(
                f"  ⚠️  Failed to add Browser Tool permissions: {put_browser_policy.stderr}"
            )
            print("  💡 You may need to add them manually")

        # Check if browser already exists
        print("  🔍 Checking for existing Browser Tool...")

        try:
            # List existing browsers using AWS CLI helper
            list_response = _call_agentcore_control("list-browsers", region)
            browsers = list_response.get("browserSummaries", [])
            existing_browser = next(
                (b for b in browsers if b["name"] == browser_name), None
            )

            if existing_browser:
                print(f"  ✅ Found existing Browser Tool: {browser_name}")
                browser_id = existing_browser["browserId"]
                browser_arn = existing_browser["browserArn"]

                # Get detailed browser config to verify settings
                print("  🔍 Verifying browser configuration...")
                browser_details = _call_agentcore_control(
                    "get-browser", region, browser_id=browser_id
                )

                # Check Web Bot Auth signing status
                existing_signing = browser_details.get("browserSigning", {})
                if browser_signing and not existing_signing.get("enabled"):
                    print("  ⚠️  Existing browser does NOT have Web Bot Auth enabled.")
                    print(
                        "     Delete the existing browser and redeploy to enable signing,"
                    )
                    print("     or create a new browser with a different name.")

                config_matches = True

                # For VPC mode, verify network configuration matches
                if is_vpc:
                    existing_net = browser_details.get("networkConfiguration", {})
                    vpc_config = existing_net.get("vpcConfig", {})
                    existing_subnets = set(vpc_config.get("subnets", []))
                    existing_sgs = set(vpc_config.get("securityGroups", []))
                    required_vpc = network_configuration.get("vpcConfig", {})
                    required_subnets = set(required_vpc.get("subnets", []))
                    required_sgs = set(required_vpc.get("securityGroups", []))

                    if (
                        existing_subnets != required_subnets
                        or existing_sgs != required_sgs
                    ):
                        config_matches = False
                        print("  ⚠️  VPC configuration mismatch!")
                        print(f"     Expected subnets: {required_subnets}")
                        print(f"     Existing subnets: {existing_subnets}")
                        print(f"     Expected security groups: {required_sgs}")
                        print(f"     Existing security groups: {existing_sgs}")

                if config_matches:
                    print("  ✅ Browser configuration matches requirements")
                    print("\n  📝 Browser Details:")
                    print(f"     Browser ID: {browser_id}")
                    print(f"     Browser ARN: {browser_arn}")
                    return browser_id, browser_arn
                else:
                    print("  🔄 Will create new browser with different name...")
                    # Generate unique name with timestamp
                    import time

                    browser_name = f"{browser_name}_{int(time.time())}"
                    print(f"  📝 New browser name: {browser_name}")

            # Create new browser (either doesn't exist or config mismatch)
            print(f"  📡 Creating Browser Tool: {browser_name}")
            if is_vpc:
                print(
                    "  ⏳ This may take 2-5 minutes while AWS provisions VPC network interfaces..."
                )

            create_kwargs: dict[str, Any] = {
                "name": browser_name,
                "description": description,
                "network_configuration": network_configuration,
                "execution_role_arn": execution_role_arn,
                "recording": {
                    "enabled": True,
                    "s3Location": {
                        "bucket": s3_bucket,
                        "prefix": "browser-recordings",
                    },
                },
            }

            if browser_signing:
                create_kwargs["browser_signing"] = browser_signing
                print("  🔐 Web Bot Auth (browserSigning) will be enabled")

            create_response = _call_agentcore_control(
                "create-browser",
                region,
                **create_kwargs,
            )

            browser_id = create_response["browserId"]
            browser_arn = create_response["browserArn"]

            print("  ✅ Browser Tool created successfully!")
            print("\n  📝 Browser Details:")
            print(f"     Browser ID: {browser_id}")
            print(f"     Browser ARN: {browser_arn}")

            return browser_id, browser_arn

        except Exception as e:
            print(f"  ❌ Failed to configure Browser Tool: {e}")
            raise

    except subprocess.CalledProcessError as e:
        print(f"  ❌ Browser Tool creation failed (exit code {e.returncode})")
        # Redact stderr to avoid leaking sensitive info (ARNs, tokens, role names)
        stderr_lines = (e.stderr or "").strip().split("\n")
        if stderr_lines:
            print(f"  📋 Error hint: {stderr_lines[0][:200]}")
        print("\n  💡 Troubleshooting:")
        print("     1. Verify IAM role has bedrock-agentcore-control permissions")
        if is_vpc:
            print("     2. Check that VPC subnets exist and are in supported AZs")
            print("     3. Ensure security groups exist in the VPC")
        print("     4. Verify execution role has necessary S3 permissions")
        print("\n  ⚠️  Continuing without custom Browser Tool...")
        print("     Browser will use default system browser (no Web Bot Auth)")
        return None, None
    except Exception as e:
        print(f"  ❌ Error configuring Browser Tool: {e}")
        print("\n  💡 Troubleshooting:")
        print("     1. Verify IAM role has bedrock-agentcore-control permissions")
        if is_vpc:
            print("     2. Check that VPC subnets exist and are in supported AZs")
            print("     3. Ensure security groups exist in the VPC")
        print("     4. Verify execution role has necessary S3 permissions")
        print("\n  ⚠️  Continuing without custom Browser Tool...")
        print("     Browser will use default system browser (no Web Bot Auth)")
        return None, None


def _get_required_vpc_endpoints(region: str) -> list[dict]:
    """Get list of required VPC endpoints for AgentCore with browser.

    Returns:
        List of endpoint configurations with service names, types, and descriptions.
    """
    endpoints = []
    for endpoint in VPC_REQUIRED_ENDPOINTS:
        # Create a copy to avoid modifying the constant
        ep = endpoint.copy()
        # Construct the full service name
        ep["service"] = VPC_ENDPOINT_SERVICE_FORMAT.format(
            region=region, service_suffix=ep.pop("service_suffix")
        )
        endpoints.append(ep)
    return endpoints


def _check_existing_endpoints(ec2_client, vpc_id: str, region: str) -> dict:
    """Check which required VPC endpoints already exist.

    Returns:
        Dict mapping service names to endpoint IDs (or None if missing)
    """
    required_endpoints = _get_required_vpc_endpoints(region)
    existing_endpoints = ec2_client.describe_vpc_endpoints(
        Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
    )["VpcEndpoints"]

    endpoint_map = {}
    for req in required_endpoints:
        service_name = req["service"]
        # Find matching endpoint
        matching = next(
            (
                ep
                for ep in existing_endpoints
                if ep["ServiceName"] == service_name and ep["State"] != "deleted"
            ),
            None,
        )
        endpoint_map[service_name] = matching["VpcEndpointId"] if matching else None

    return endpoint_map


def _create_vpc_endpoint(
    ec2_client,
    vpc_id: str,
    service_name: str,
    endpoint_type: str,
    subnet_ids: list[str],
    security_group_ids: list[str],
    max_azs: int | None = None,
) -> str:
    """Create a VPC endpoint.

    Args:
        ec2_client: boto3 EC2 client
        vpc_id: VPC ID
        service_name: AWS service name (e.g., com.amazonaws.us-east-1.s3)
        endpoint_type: 'Interface' or 'Gateway'
        subnet_ids: List of subnet IDs
        security_group_ids: List of security group IDs
        max_azs: Maximum number of availability zones (for gateway endpoint limitation)

    Returns:
        VPC endpoint ID
    """
    # Limit subnets if max_azs is specified
    if max_azs and len(subnet_ids) > max_azs:
        print(
            f"    ⚠️  Limiting to {max_azs} subnets (endpoint supports max {max_azs} AZs)"
        )
        subnet_ids = subnet_ids[:max_azs]

    kwargs = {
        "VpcId": vpc_id,
        "ServiceName": service_name,
        "VpcEndpointType": endpoint_type,
    }

    # Interface endpoints need subnets and security groups
    if endpoint_type == "Interface":
        kwargs["SubnetIds"] = subnet_ids
        kwargs["SecurityGroupIds"] = security_group_ids
        kwargs["PrivateDnsEnabled"] = True

    response = ec2_client.create_vpc_endpoint(**kwargs)
    endpoint_id = response["VpcEndpoint"]["VpcEndpointId"]

    # Wait for endpoint to become available
    print(f"    ⏳ Waiting for endpoint {endpoint_id} to become available...")
    waiter = ec2_client.get_waiter("vpc_endpoint_available")
    try:
        waiter.wait(
            VpcEndpointIds=[endpoint_id], WaiterConfig={"Delay": 5, "MaxAttempts": 60}
        )
        print(f"    ✅ Endpoint {endpoint_id} is now available")
    except Exception as e:
        print(f"    ⚠️  Endpoint created but availability check timed out: {e}")
        print("    Proceeding anyway - endpoint may still be initializing")

    return endpoint_id


def _validate_target_url(payload: dict) -> None:
    """Validate target_url format and warn about domain allowlist limitations.

    Browser Tool uses domain-based allowlists that don't match:
    - Raw IP addresses (e.g., 172.31.24.161)
    - EC2 private DNS without subdomain (e.g., ip-172-31-24-161.ec2.internal)

    Recommended formats:
    - Public DNS names (e.g., ec2-X-X-X-X.compute-1.amazonaws.com)
    - Custom domains with subdomains
    """
    import ipaddress
    from urllib.parse import urlparse

    target_url = payload.get("target_url", "")
    if not target_url:
        return

    # Parse URL to extract hostname
    if not target_url.startswith(("http://", "https://")):
        target_url = "http://" + target_url

    try:
        parsed = urlparse(target_url)
        hostname = parsed.hostname
    except Exception:
        # Invalid URL format, let agent runtime handle it
        return

    if not hostname:
        return

    # Check if hostname is an IP address
    is_ip = False
    try:
        ipaddress.ip_address(hostname)
        is_ip = True
    except ValueError:
        pass

    # Only warn for raw IP addresses (EC2 private DNS is now supported)
    if is_ip:
        print("\n" + "=" * 80)
        print("⚠️  WARNING: Target URL Format May Cause Navigation Timeout")
        print("=" * 80)

        print(f"\n🔍 Detected raw IP address: {hostname}")
        print("\n❌ Problem:")
        print("   Browser Tool uses domain-based allowlists (e.g., *.example.com)")
        print("   Raw IP addresses cannot be matched with wildcard patterns")
        print("   Result: Navigation will timeout after 15 seconds")

        print("\n✅ Recommended Solutions:")
        print("\n   1. Use EC2 DNS name (private or public):")
        print("      Get EC2 public DNS:")
        print('      AWS_PAGER="" aws ec2 describe-instances \\')
        print("        --filters Name=private-ip-address,Values=<IP> \\")
        print("        --query 'Reservations[0].Instances[0].PublicDnsName' \\")
        print("        --output text")
        print("\n      Get EC2 private DNS:")
        print('      AWS_PAGER="" aws ec2 describe-instances \\')
        print("        --filters Name=private-ip-address,Values=<IP> \\")
        print("        --query 'Reservations[0].Instances[0].PrivateDnsName' \\")
        print("        --output text")
        print("\n   2. Use custom domain:")
        print("      - Route 53 Private Hosted Zone: chat.internal.example.com")
        print("      - Application Load Balancer: chat.yourdomain.com")

        print(
            "\n📖 For detailed alternatives, see the VPC Configuration section in README.md"
        )
        print("=" * 80)

        proceed = (
            input("\n⚠️  Continue with this URL anyway? (will likely timeout) [y/N]: ")
            .strip()
            .lower()
        )
        if proceed != "y":
            print("\nInvocation cancelled. Please update target_url and try again.")
            sys.exit(0)

        print("\nProceeding with URL as specified...")


def _validate_and_create_vpc_endpoints(
    ec2_client, vpc_id: str, region: str, subnet_ids: list[str], sg_ids: list[str]
) -> bool:
    """Validate VPC endpoints and create missing ones.

    Returns:
        True if all endpoints exist or were created successfully, False otherwise
    """
    print("\n🔍 Validating VPC endpoints for AgentCore browser functionality...")

    required_endpoints = vpc_utils.get_required_vpc_endpoints(region)
    existing = vpc_utils.check_existing_endpoints(ec2_client, vpc_id, region)

    missing_endpoints = [
        ep for ep in required_endpoints if existing[ep["service"]] is None
    ]

    if not missing_endpoints:
        print("✅ All required VPC endpoints already exist:")
        for ep in required_endpoints:
            endpoint_id = existing[ep["service"]]
            print(f"   ✓ {ep['name']}: {endpoint_id}")
        return True

    # Show what exists and what's missing
    print(f"\n📋 VPC Endpoint Status ({len(existing)} checked):")
    for ep in required_endpoints:
        endpoint_id = existing[ep["service"]]
        if endpoint_id:
            print(f"   ✅ {ep['name']}: {endpoint_id}")
        else:
            print(f"   ❌ {ep['name']}: MISSING - {ep['description']}")

    print(f"\n⚠️  Missing {len(missing_endpoints)} required VPC endpoint(s)!")
    print(
        "\nWithout these endpoints, AgentCore browser functionality will NOT work in VPC:"
    )
    for ep in missing_endpoints:
        print(f"   • {ep['name']}: {ep['description']}")

    print(
        "\n💡 These endpoints are CRITICAL for AgentCore browser-based agents in VPC."
    )
    print(
        "   See: https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/agentcore-vpc.html"
    )

    create = (
        input("\nCreate missing VPC endpoints automatically? [Y/n]: ").strip().lower()
        or "y"
    )

    if create != "y":
        print(
            "\n⚠️  Proceeding without creating endpoints. Browser functionality may fail."
        )
        return False

    # Create missing endpoints
    print(f"\n🔧 Creating {len(missing_endpoints)} VPC endpoint(s)...")
    created_count = 0
    failed_endpoints = []

    for ep in missing_endpoints:
        print(f"\n📡 Creating {ep['name']} endpoint...")
        print(f"   Service: {ep['service']}")
        print(f"   Type: {ep['type']}")
        try:
            endpoint_id = vpc_utils.create_vpc_endpoint(
                ec2_client,
                vpc_id,
                ep["service"],
                ep["type"],
                subnet_ids,
                sg_ids,
                max_azs=ep.get("max_azs"),
            )
            print(f"   ✅ Created: {endpoint_id}")
            created_count += 1
        except Exception as e:
            print(f"   ❌ Failed to create endpoint: {e}")
            failed_endpoints.append(ep["name"])

    print("\n📊 VPC Endpoint Creation Summary:")
    print(f"   ✅ Created: {created_count}/{len(missing_endpoints)}")
    if failed_endpoints:
        print(f"   ❌ Failed: {', '.join(failed_endpoints)}")
        print(
            "\n⚠️  Some endpoints failed to create. Browser functionality may not work."
        )
        return False

    print("\n✅ All required VPC endpoints are now available!")
    return True


def _configure_llm_provider(
    region: str, use_vpc: bool, force_update: bool = False
) -> str:
    """Configure LLM provider and credentials if needed."""
    print("\n🤖 Configuring LLM Provider...")

    if use_vpc:
        print("  🔒 VPC deployment selected. Enforcing Bedrock LLM provider.")
        return LLM_PROVIDER_BEDROCK

    # Prompt for provider
    print("  Select LLM Provider:")
    print("  1. Vertex AI (Google Gemini) [Default]")
    print("  2. AWS Bedrock (Anthropic Claude)")
    choice = input("Select provider [1]: ").strip() or "1"

    if choice == "2":
        return LLM_PROVIDER_BEDROCK

    # Vertex selected
    print("\n  🔑 Checking Google Cloud Credentials for Vertex AI")

    # Check if credentials exist in SSM
    ssm = boto3.client("ssm", region_name=region)
    credentials_exist = False

    try:
        parameter = ssm.get_parameter(
            Name=SSM_PARAM_GOOGLE_CREDENTIALS, WithDecryption=True
        )
        existing_value = parameter["Parameter"]["Value"]

        # Check validity (Auth check)
        try:
            creds = json.loads(existing_value)

            # Structural check
            if all(
                k in creds
                for k in ["type", "project_id", "client_email", "private_key"]
            ):
                # Attempt to verify with Google Auth if available
                try:
                    from google.auth.transport.requests import Request
                    from google.oauth2 import service_account

                    print("  🔍 Verifying credentials with Google Cloud...")
                    credentials = service_account.Credentials.from_service_account_info(
                        creds, scopes=["https://www.googleapis.com/auth/cloud-platform"]
                    )
                    credentials.refresh(Request())
                    credentials_exist = True
                    print(
                        f"  ✅ Validation passed: Credentials are valid and active for {creds.get('client_email')}"
                    )
                except ImportError:
                    # Fallback to structural validation if libraries missing
                    credentials_exist = True
                    print(
                        f"  ✅ Validation passed (Structural only): Found existing credentials in SSM: {SSM_PARAM_GOOGLE_CREDENTIALS}"
                    )
                except Exception as e:
                    print(f"  ❌ Credential validation failed: {str(e)}")
                    print(
                        "     The stored credentials appear to be invalid or expired."
                    )
            else:
                print(
                    "  ⚠️  Existing credentials in SSM appear invalid (missing fields)."
                )
        except json.JSONDecodeError:
            print("  ⚠️  Existing credentials in SSM are not valid JSON.")

    except ssm.exceptions.ParameterNotFound:
        print(
            f"  ℹ️  No existing credentials found in SSM: {SSM_PARAM_GOOGLE_CREDENTIALS}"
        )
    except Exception as e:
        print(f"  ⚠️  Error checking existing credentials: {e}")

    # Determine need for update
    update_needed = True

    if credentials_exist:
        if force_update:
            print("  🔄 Update forced by parameter.")
        else:
            print("  ✅ Using existing credentials. Skipping upload.")
            update_needed = False

    if update_needed:
        print("\n  Please provide the path to your service account JSON key file.")
        print("  This will be securely stored in AWS SSM Parameter Store.")

        path = None
        while True:
            key_path = input("  Path to key file (e.g., ./credentials.json): ").strip()
            path = Path(key_path).expanduser().resolve()
            if path.exists() and path.is_file():
                break
            print(f"  ❌ File not found: {path}")

        # Read and upload to SSM
        try:
            with open(path) as f:
                credentials_json = f.read()

            # Validate basic JSON structure
            try:
                json.loads(credentials_json)
            except json.JSONDecodeError:
                print("  ⚠️  Warning: File does not contain valid JSON.")
                confirm = input("  Continue upload anyway? [y/N]: ").strip().lower()
                if confirm != "y":
                    return LLM_PROVIDER_VERTEX  # Or raise/retry

            ssm.put_parameter(
                Name=SSM_PARAM_GOOGLE_CREDENTIALS,
                Description="Google Cloud Credentials for Vertex AI",
                Value=credentials_json,
                Type="SecureString",
                Overwrite=True,
            )
            print(f"  ✅ Credentials stored in SSM: {SSM_PARAM_GOOGLE_CREDENTIALS}")
        except Exception as e:
            print(f"  ❌ Failed to store credentials in SSM: {e}")
            print(
                "\n  ⚠️  Critical Error: Cannot proceed with Vertex AI without storing credentials."
            )

            retry = input("  Retry credential upload? [Y/n]: ").strip().lower() or "y"
            if retry == "y":
                # Recursively retry logic could be complex here, so simplify by returning recursive call
                # or simply returning Bedrock as fallback if user decides.
                # Given the structure, let's ask if they want to switch to Bedrock or exit.
                pass  # Will loop is hard without restructuring, so let's simplify.

            print("  Options:")
            print("  1. Switch to AWS Bedrock (Anthropic Claude)")
            print("  2. Exit deployment")
            fallback = input("  Select option [1]: ").strip() or "1"

            if fallback == "1":
                print("  🔄 Switching to AWS Bedrock provider.")
                return LLM_PROVIDER_BEDROCK
            else:
                print("  ❌ Deployment cancelled.")
                sys.exit(1)

    return LLM_PROVIDER_VERTEX


def _add_ssm_permissions(region: str, agent_name: str) -> None:
    """Add SSM read permissions to the agent execution role."""
    # Try standard naming conventions
    possible_roles = [
        f"AratoAgentExecutionRole-{region}",
        f"BedrockExecutionRoleForAgents_{agent_name}",
    ]

    param_arn = f"arn:aws:ssm:{region}:*:parameter{SSM_PARAM_GOOGLE_CREDENTIALS}"
    policy_doc = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": "ssm:GetParameter",
                "Resource": param_arn,
            }
        ],
    }

    iam = boto3.client("iam", region_name=region)
    updated = False

    for role_name in possible_roles:
        try:
            iam.get_role(RoleName=role_name)
            # Role exists, attach policy
            iam.put_role_policy(
                RoleName=role_name,
                PolicyName="VertexCredentialsAccess",
                PolicyDocument=json.dumps(policy_doc),
            )
            print(f"  ✅ Added SSM permissions to role: {role_name}")
            updated = True
        except iam.exceptions.NoSuchEntityException:
            continue
        except Exception as e:
            print(f"  ⚠️ Could not update role {role_name}: {e}")

    if not updated:
        print(
            "\n  ⚠️ Execution role not found yet. Permissions will need to be added after deployment."
        )
        print(
            "     Run 'uv run agentcore-launch' to create the role, then re-run configure or add permissions manually."
        )


def configure() -> None:
    """Configure AgentCore deployment (IAM roles, ECR repository)."""
    # Parse arguments manually since this is invoked via entrypoint
    force_update = "--force-google-auth" in sys.argv

    print("Configuring Bedrock AgentCore...")

    # Get AWS region (default to us-east-1)
    region = input("\nAWS Region [us-east-1]: ").strip() or "us-east-1"

    # Check for VPCs in the account
    ec2 = boto3.client("ec2", region_name=region)
    vpcs = ec2.describe_vpcs()["Vpcs"]

    # Generate requirements.txt from pyproject.toml for configuration validation
    # We place it in platforms/aws_agentcore/requirements.txt to satisfy agentcore's project root check
    print("\n📦 Generating temporary requirements.txt for configuration...")
    req_path = Path("platforms/aws_agentcore/requirements.txt")
    req_path.parent.mkdir(parents=True, exist_ok=True)

    export_result = subprocess.run(
        [
            "uv",
            "export",
            "--format",
            "requirements-txt",
            "--no-editable",
            "--no-emit-project",
            "--output-file",
            str(req_path),
        ],
        cwd=".",
        capture_output=True,
        text=True,
    )

    if export_result.returncode != 0:
        print(f"❌ Failed to generate requirements.txt: {export_result.stderr}")
        sys.exit(1)
    print(f"   ✅ Generated {req_path}")

    configure_cmd = [
        "agentcore",
        "configure",
        "-e",
        "platforms/aws_agentcore/app.py",
        "-r",
        region,
        "-n",
        "arato_agent",
        "--disable-otel",
    ]

    # Point to the generated requirements file
    configure_cmd.extend(["-rf", "platforms/aws_agentcore/requirements.txt"])

    try:
        # VPC configuration
        if vpcs:
            # If only one VPC, auto-select it as default
            if len(vpcs) == 1:
                print(f"\n🌐 Found 1 VPC in {region}")
                default_vpc_idx = 0
                vpc_id = vpcs[default_vpc_idx]["VpcId"]
                vpc_name = next(
                    (
                        tag["Value"]
                        for tag in vpcs[default_vpc_idx].get("Tags", [])
                        if tag["Key"] == "Name"
                    ),
                    "Unnamed",
                )
                cidr = vpcs[default_vpc_idx].get("CidrBlock", "N/A")
                print(f"  1. {vpc_id} ({vpc_name}) - {cidr}")
                use_vpc = input("Deploy in this VPC? [Y/n]: ").strip().lower() or "y"
            else:
                print(f"\n🌐 Found {len(vpcs)} VPC(s) in {region}")
                use_vpc = (
                    input("Do you want to deploy in a VPC? [y/N]: ").strip().lower()
                )

            if use_vpc == "y":
                # List and select VPC
                if len(vpcs) == 1:
                    # Auto-select the only VPC
                    selected_vpc_id = vpcs[0]["VpcId"]
                    print(f"Using VPC: {selected_vpc_id}")
                else:
                    print("\nAvailable VPCs:")
                    for idx, vpc in enumerate(vpcs):
                        vpc_id = vpc["VpcId"]
                        vpc_name = next(
                            (
                                tag["Value"]
                                for tag in vpc.get("Tags", [])
                                if tag["Key"] == "Name"
                            ),
                            "Unnamed",
                        )
                        cidr = vpc.get("CidrBlock", "N/A")
                        print(f"  {idx + 1}. {vpc_id} ({vpc_name}) - {cidr}")

                    vpc_choice = (
                        int(input(f"\nSelect VPC (1-{len(vpcs)}): ").strip()) - 1
                    )
                    selected_vpc_id = vpcs[vpc_choice]["VpcId"]

                # Get subnets for the selected VPC
                subnets = ec2.describe_subnets(
                    Filters=[{"Name": "vpc-id", "Values": [selected_vpc_id]}]
                )["Subnets"]

                # Sort subnets by availability zone for logical ordering
                subnets.sort(key=lambda s: s["AvailabilityZone"])

                if subnets:
                    print(f"\n📡 Found {len(subnets)} subnet(s) in {selected_vpc_id}")
                    print("Available Subnets:")
                    for idx, subnet in enumerate(subnets):
                        subnet_id = subnet["SubnetId"]
                        subnet_name = next(
                            (
                                tag["Value"]
                                for tag in subnet.get("Tags", [])
                                if tag["Key"] == "Name"
                            ),
                            "Unnamed",
                        )
                        az = subnet["AvailabilityZone"]
                        cidr = subnet.get("CidrBlock", "N/A")
                        print(
                            f"  {idx + 1}. {subnet_id} ({subnet_name}) - {az} - {cidr}"
                        )

                    if len(subnets) == 1:
                        # Auto-select the only subnet
                        subnet_input = (
                            input("\nSelect subnet(s) (comma-separated) [1]: ").strip()
                            or "1"
                        )
                    else:
                        subnet_input = (
                            input(
                                "\nSelect subnet(s) (comma-separated) [1,2]: "
                            ).strip()
                            or "1,2"
                        )

                    subnet_indices = subnet_input.split(",")
                    selected_subnets = [
                        subnets[int(i.strip()) - 1]["SubnetId"] for i in subnet_indices
                    ]
                else:
                    print(f"❌ No subnets found in VPC {selected_vpc_id}")
                    sys.exit(1)

                # Get security groups for the selected VPC
                security_groups = ec2.describe_security_groups(
                    Filters=[{"Name": "vpc-id", "Values": [selected_vpc_id]}]
                )["SecurityGroups"]

                if security_groups:
                    print(
                        f"\n🔒 Found {len(security_groups)} security group(s) in {selected_vpc_id}"
                    )
                    print("Available Security Groups:")
                    for idx, sg in enumerate(security_groups):
                        sg_id = sg["GroupId"]
                        sg_name = sg.get("GroupName", "Unnamed")
                        sg_desc = sg.get("Description", "No description")
                        print(f"  {idx + 1}. {sg_id} ({sg_name}) - {sg_desc}")

                    # Find the 'default' security group
                    default_sg_idx = None
                    for idx, sg in enumerate(security_groups):
                        if sg.get("GroupName") == "default":
                            default_sg_idx = idx + 1
                            break

                    if len(security_groups) == 1:
                        # Auto-select the only security group
                        sg_input = (
                            input(
                                "\nSelect security group(s) (comma-separated) [1]: "
                            ).strip()
                            or "1"
                        )
                    elif default_sg_idx:
                        # Default to the 'default' security group if found
                        sg_input = input(
                            f"\nSelect security group(s) (comma-separated) [{default_sg_idx}]: "
                        ).strip() or str(default_sg_idx)
                    else:
                        sg_input = input(
                            "\nSelect security group(s) (comma-separated, e.g., 1,2): "
                        ).strip()

                    sg_indices = sg_input.split(",")
                    selected_sgs = [
                        security_groups[int(i.strip()) - 1]["GroupId"]
                        for i in sg_indices
                    ]
                else:
                    print(f"❌ No security groups found in VPC {selected_vpc_id}")
                    sys.exit(1)

                # Validate VPC DNS settings
                print("\n🔍 Validating VPC DNS settings...")
                dns_support, dns_hostnames = vpc_utils.check_vpc_dns_settings(
                    ec2, selected_vpc_id
                )

                if not dns_support or not dns_hostnames:
                    print(
                        "\n⚠️  VPC DNS settings are not fully enabled (required for private DNS names):"
                    )
                    print(
                        f"   DNS Resolution: {'✅' if dns_support else '❌ DISABLED'}"
                    )
                    print(
                        f"   DNS Hostnames: {'✅' if dns_hostnames else '❌ DISABLED'}"
                    )

                    enable = (
                        input("\nEnable DNS settings automatically? [Y/n]: ")
                        .strip()
                        .lower()
                        or "y"
                    )
                    if enable == "y":
                        vpc_utils.enable_vpc_dns_settings(ec2, selected_vpc_id)
                    else:
                        print(
                            "\n⚠️  Proceeding without enabling DNS. Private DNS names may not work."
                        )
                else:
                    print("✅ VPC DNS settings are properly enabled")

                # Validate and create VPC endpoints
                endpoints_ok = _validate_and_create_vpc_endpoints(
                    ec2, selected_vpc_id, region, selected_subnets, selected_sgs
                )

                if not endpoints_ok:
                    print(
                        "\n⚠️  VPC endpoint setup incomplete. Browser functionality may fail."
                    )
                    proceed = (
                        input("Continue with deployment anyway? [y/N]: ")
                        .strip()
                        .lower()
                    )
                    if proceed != "y":
                        print("Deployment cancelled.")
                        sys.exit(1)

                # Add VPC configuration to command
                configure_cmd.extend(
                    [
                        "--vpc",
                        "--subnets",
                        ",".join(selected_subnets),
                        "--security-groups",
                        ",".join(selected_sgs),
                    ]
                )

                print("\n✅ VPC configuration:")
                print(f"   VPC: {selected_vpc_id}")
                print(f"   Subnets: {', '.join(selected_subnets)}")
                print(f"   Security Groups: {', '.join(selected_sgs)}")

                # Add important note about target URLs
                print("\n💡 IMPORTANT: Target URL Requirements for VPC Deployment")
                print(
                    "   ✅ Use EC2 private DNS: ip-172-31-x-x.ec2.internal:port (RECOMMENDED)"
                )
                print(
                    "   ✅ Use PUBLIC DNS names: ec2-xxx.compute-1.amazonaws.com:port"
                )
                print("   ❌ Do NOT use private IPs: 172.31.x.x:port (will timeout)")
                print(
                    "   📖 Note: Browser Tool uses domain-based allowlists for URL access control"
                )
        else:
            print(f"\n📡 No VPCs found in {region}. Using PUBLIC network mode.")
            use_vpc = "n"

        # Determine if VPC is actually being used
        is_vpc_mode = use_vpc == "y"

        # Configure LLM Provider
        llm_provider = _configure_llm_provider(region, is_vpc_mode, force_update)

        print(f"\nRunning: {' '.join(configure_cmd)}\n")
        result = subprocess.run(configure_cmd, cwd=".")

        # Post-configuration: Update source_path and entrypoint in .bedrock_agentcore.yaml
        if result.returncode == 0:
            try:
                config_path = Path(".bedrock_agentcore.yaml")
                if config_path.exists():
                    print("\n📝 Updating configuration in .bedrock_agentcore.yaml...")
                    with open(config_path) as f:
                        config = yaml.safe_load(f)

                    agent_name = "arato_agent"
                    if "agents" in config and agent_name in config["agents"]:
                        agent_config = config["agents"][agent_name]

                        # 1. Fix source_path to be the repo root (current directory)
                        # agentcore configure sets it to platforms/aws_agentcore because of the entrypoint
                        repo_root = str(Path.cwd().absolute())
                        agent_config["source_path"] = repo_root
                        print(f"   ✅ Updated source_path to: {repo_root}")

                        # 2. Ensure entrypoint is absolute path
                        # It might be relative to the old source_path
                        entrypoint = Path("platforms/aws_agentcore/app.py").absolute()
                        agent_config["entrypoint"] = str(entrypoint)
                        print(f"   ✅ Updated entrypoint to: {entrypoint}")

                        # Add LLM Provider env var
                        if "env" not in agent_config:
                            agent_config["env"] = {}
                        agent_config["env"]["LLM_PROVIDER"] = llm_provider
                        print(f"   ✅ Set LLM_PROVIDER to: {llm_provider}")

                        with open(config_path, "w") as f:
                            yaml.dump(config, f, default_flow_style=False)

                        # Update IAM role permissions if using Vertex
                        if llm_provider == LLM_PROVIDER_VERTEX:
                            _add_ssm_permissions(region, agent_name)

                # 3. Patch Dockerfile CMD to point to the correct module
                dockerfile_path = Path(".bedrock_agentcore/arato_agent/Dockerfile")
                if dockerfile_path.exists():
                    print(f"\n📝 Patching Dockerfile at {dockerfile_path}...")
                    with open(dockerfile_path) as f:
                        dockerfile_content = f.read()

                    # Replace the CMD to point to the correct module
                    # The entrypoint is platforms/aws_agentcore/app.py, so module is platforms.aws_agentcore.app
                    # We handle both with and without opentelemetry just in case
                    replacements = [
                        (
                            'CMD ["opentelemetry-instrument", "python", "-m", "app"]',
                            'CMD ["python", "-m", "platforms.aws_agentcore.app"]',
                        ),
                        (
                            'CMD ["opentelemetry-instrument", "python", "-m", "platforms.aws_agentcore.app"]',
                            'CMD ["python", "-m", "platforms.aws_agentcore.app"]',
                        ),
                        (
                            'CMD ["python", "-m", "app"]',
                            'CMD ["python", "-m", "platforms.aws_agentcore.app"]',
                        ),
                    ]

                    patched = False
                    for old_cmd, new_cmd in replacements:
                        if old_cmd in dockerfile_content:
                            dockerfile_content = dockerfile_content.replace(
                                old_cmd, new_cmd
                            )
                            patched = True
                            print(f"   ✅ Updated CMD to: {new_cmd}")

                    # Strip OTEL distro install line (generates noisy JSON logs)
                    import re

                    dockerfile_content = re.sub(
                        r"\n*# Install OTEL[^\n]*\n*# \(opentelemetry[^\n]*\n*RUN uv pip install aws-opentelemetry-distro[^\n]*\n*",
                        "\n",
                        dockerfile_content,
                    )
                    # Also strip bare RUN line if comment pattern didn't match
                    dockerfile_content = re.sub(
                        r"\n*RUN uv pip install aws-opentelemetry-distro[^\n]*\n*",
                        "\n",
                        dockerfile_content,
                    )
                    # Strip OTEL env vars
                    dockerfile_content = re.sub(
                        r"\s*OTEL_[A-Z_]+=\S*", "", dockerfile_content
                    )

                    if patched:
                        with open(dockerfile_path, "w") as f:
                            f.write(dockerfile_content)
                    else:
                        print(
                            "   ⚠️ Could not find expected CMD in Dockerfile. Please verify manually."
                        )

            except Exception as e:
                print(f"   ⚠️ Failed to update config: {e}")

    finally:
        # Cleanup generated requirements.txt
        if req_path.exists():
            print(f"🧹 Cleaning up {req_path}...")
            req_path.unlink()

    if result.returncode == 0:
        print("\n✅ Configuration complete!")
        print("\nNext steps:")
        print(
            "1. Run: uv run agentcore-launch (auto-syncs requirements and applies browser permissions on first deploy)"
        )
        print("2. Then check status: uv run agentcore-status")
    else:
        print("\n❌ Configuration failed")
        sys.exit(1)


def _ensure_execution_role(
    region: str, account_id: str, _agent_name: str = "arato_agent"
) -> str:
    """Ensure an execution role exists for the agent.
    _
        If the role is missing in the config, this creates a custom role so that
        we have the ARN available for Browser Tool creation before the main launch.
    """
    role_name = f"AratoAgentExecutionRole-{region}"
    iam = boto3.client("iam", region_name=region)

    # Check if role exists
    role_exists = False
    role_arn = None
    try:
        role = iam.get_role(RoleName=role_name)
        print(f"  ✅ Found existing execution role: {role_name}")
        role_arn = role["Role"]["Arn"]
        role_exists = True
    except iam.exceptions.NoSuchEntityException:
        print(f"  ⚙️  Creating execution role: {role_name}")
        role_exists = False

    # Create role if it doesn't exist
    if not role_exists:
        trust_policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"Service": "bedrock-agentcore.amazonaws.com"},
                    "Action": "sts:AssumeRole",
                    "Condition": {
                        "StringEquals": {"aws:SourceAccount": account_id},
                        "ArnLike": {
                            "aws:SourceArn": f"arn:aws:bedrock-agentcore:{region}:{account_id}:*"
                        },
                    },
                }
            ],
        }

        try:
            role = iam.create_role(
                RoleName=role_name,
                AssumeRolePolicyDocument=json.dumps(trust_policy),
                Description="Execution role for Arato Agent (created by agentcore_deploy.py)",
            )
            role_arn = role["Role"]["Arn"]
            print(f"  ✅ Created role: {role_arn}")
        except Exception as e:
            print(f"  ❌ Failed to create execution role: {e}")
            sys.exit(1)

    # Always update permissions (whether role is new or existing)
    print("  🔐 Updating permissions on execution role...")

    # Basic execution policy
    execution_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": [
                    "ecr:BatchGetImage",
                    "ecr:GetDownloadUrlForLayer",
                    "ecr:GetAuthorizationToken",
                ],
                "Resource": "*",
            },
            {
                "Effect": "Allow",
                "Action": [
                    "logs:CreateLogGroup",
                    "logs:CreateLogStream",
                    "logs:PutLogEvents",
                    "logs:DescribeLogGroups",
                    "logs:DescribeLogStreams",
                ],
                "Resource": "arn:aws:logs:*:*:log-group:/aws/bedrock-agentcore/*",
            },
            {
                "Effect": "Allow",
                "Action": [
                    "bedrock:InvokeModel",
                    "bedrock:InvokeModelWithResponseStream",
                    "bedrock:ApplyGuardrail",
                ],
                "Resource": "*",
            },
            {"Effect": "Allow", "Action": ["bedrock-agentcore:*"], "Resource": "*"},
            {
                "Effect": "Allow",
                "Action": "cloudwatch:PutMetricData",
                "Resource": "*",
                "Condition": {
                    "StringEquals": {"cloudwatch:namespace": "bedrock-agentcore"}
                },
            },
            {
                "Effect": "Allow",
                "Action": "secretsmanager:GetSecretValue",
                "Resource": "*",
            },
            {
                "Effect": "Allow",
                "Action": [
                    "dynamodb:PutItem",
                    "dynamodb:GetItem",
                    "dynamodb:UpdateItem",
                    "dynamodb:Query",
                    "dynamodb:Scan",
                ],
                "Resource": [
                    f"arn:aws:dynamodb:{region}:{account_id}:table/arato-agent-runs",
                    f"arn:aws:dynamodb:{region}:{account_id}:table/arato-agent-runs/index/*",
                ],
            },
        ],
    }

    try:
        iam.put_role_policy(
            RoleName=role_name,
            PolicyName="AratoAgentExecutionPolicy",
            PolicyDocument=json.dumps(execution_policy),
        )
        print("  ✅ Updated execution policy with DynamoDB permissions")
    except Exception as e:
        print(f"  ❌ Failed to update execution policy: {e}")
        sys.exit(1)

    # Wait for propagation
    print("  ⏳ Waiting 10 seconds for IAM propagation...")
    import time

    time.sleep(10)

    # Ensure we have a valid role ARN (should always be set by now)
    assert role_arn is not None, "role_arn should be set by create or get operation"
    return role_arn


def _store_agent_metadata_in_ssm(region: str, agent_name: str = "arato_agent") -> None:
    """Store agent ID and ARN in SSM for cross-job discovery (e.g. polling deploy).

    Args:
        region: AWS region.
        agent_name: Agent name prefix for SSM paths. Defaults to 'arato_agent'
                    for production; PR environments use 'arato_pr{N}'.
    """
    from utils.bedrock_config import _read_yaml_config

    bedrock_config = _read_yaml_config()
    if not bedrock_config:
        print(
            "  ⚠️  Cannot read .bedrock_agentcore.yaml — skipping SSM metadata storage"
        )
        return

    agent_id = bedrock_config.get("agent_id")
    agent_arn = bedrock_config.get("agent_arn")

    if not agent_id or not agent_arn:
        print(
            f"  ⚠️  Missing agent metadata (id={agent_id}, arn={agent_arn}) — skipping SSM storage"
        )
        return

    # Use dynamic SSM paths based on agent name (supports PR isolation)
    ssm_agent_id_path = f"/{agent_name}/agentcore/agent_id"
    ssm_agent_arn_path = f"/{agent_name}/agentcore/agent_arn"

    ssm = boto3.client("ssm", region_name=region)
    for param_name, value, label in [
        (ssm_agent_id_path, agent_id, "agent_id"),
        (ssm_agent_arn_path, agent_arn, "agent_arn"),
    ]:
        ssm.put_parameter(Name=param_name, Value=value, Type="String", Overwrite=True)
        print(f"  ✅ Stored {label} in SSM: {param_name}")


def launch() -> None:
    """Build container and deploy to AgentCore.

    Supports AGENTCORE_AGENT_NAME env var to override the default agent name.
    This enables isolated deployments for PR environments (e.g. arato_pr123).
    """
    import os

    agent_name = os.environ.get("AGENTCORE_AGENT_NAME", "arato_agent")
    print(f"Building and deploying to AgentCore (agent: {agent_name})...")
    print("Syncing requirements.txt from pyproject.toml...")
    export_result = subprocess.run(
        [
            "uv",
            "export",
            "--format",
            "requirements-txt",
            "--no-editable",
            "--no-emit-project",
            "--output-file",
            "requirements.txt",
        ],
        cwd=".",
    )
    if export_result.returncode != 0:
        print("\n❌ Failed to export requirements.txt from pyproject.toml")
        sys.exit(1)

    # Get agent ID from config to pass as environment variable
    from utils.bedrock_config import get_agent_id

    agent_id = get_agent_id(required=False)
    if agent_id:
        print(f"Setting BEDROCK_AGENTCORE_AGENT_ID={agent_id}")
    else:
        print("\n⚠️  Warning: Could not determine agent ID (first deployment?)")
        print("Agent identity will be 'unknown' in deployed environment")

    # Auto-configure if .bedrock_agentcore.yaml doesn't exist (e.g. CI environment)
    if not Path(".bedrock_agentcore.yaml").exists():
        print(
            "\n⚙️  .bedrock_agentcore.yaml not found — running non-interactive configure..."
        )
        # Requirements file must be within the entrypoint's directory
        req_dest = Path("platforms/aws_agentcore/requirements.txt")
        req_src = Path("requirements.txt")
        if req_src.exists() and not req_dest.exists():
            import shutil

            shutil.copy2(req_src, req_dest)
        # Try with --deployment-type container first (0.2.x flag, forces CodeBuild).
        # Fall back without it for 0.1.x which doesn't have that flag.
        configure_cmd = [
            "agentcore",
            "configure",
            "--non-interactive",
            "--deployment-type",
            "container",
            "--disable-otel",
            "-e",
            "platforms/aws_agentcore/app.py",
            "-r",
            "us-east-1",
            "-n",
            agent_name,
            "-rf",
            "platforms/aws_agentcore/requirements.txt",
        ]
        configure_result = subprocess.run(configure_cmd, cwd=".")
        if configure_result.returncode != 0:
            print("   Retrying without --deployment-type (toolkit 0.1.x fallback)...")
            fallback_cmd = [
                c for c in configure_cmd if c not in ("--deployment-type", "container")
            ]
            configure_result = subprocess.run(fallback_cmd, cwd=".")
            if configure_result.returncode != 0:
                print("\n❌ Auto-configure failed")
                sys.exit(1)

        # Post-configure fixups: source_path and entrypoint
        config_path = Path(".bedrock_agentcore.yaml")
        if config_path.exists():
            with open(config_path) as f:
                auto_config = yaml.safe_load(f)
            if "agents" in auto_config and agent_name in auto_config["agents"]:
                ac = auto_config["agents"][agent_name]
                ac["source_path"] = str(Path.cwd().absolute())
                ac["entrypoint"] = str(
                    Path("platforms/aws_agentcore/app.py").absolute()
                )
                with open(config_path, "w") as f:
                    yaml.dump(auto_config, f, default_flow_style=False)
                print("   ✅ Fixed source_path and entrypoint")

            # Patch Dockerfile CMD if generated
            dockerfile_path = Path(f".bedrock_agentcore/{agent_name}/Dockerfile")
            if dockerfile_path.exists():
                with open(dockerfile_path) as f:
                    content = f.read()
                for old_cmd, new_cmd in [
                    (
                        'CMD ["opentelemetry-instrument", "python", "-m", "app"]',
                        'CMD ["python", "-m", "platforms.aws_agentcore.app"]',
                    ),
                    (
                        'CMD ["opentelemetry-instrument", "python", "-m", "platforms.aws_agentcore.app"]',
                        'CMD ["python", "-m", "platforms.aws_agentcore.app"]',
                    ),
                    (
                        'CMD ["python", "-m", "app"]',
                        'CMD ["python", "-m", "platforms.aws_agentcore.app"]',
                    ),
                ]:
                    if old_cmd in content:
                        content = content.replace(old_cmd, new_cmd)
                        print("   ✅ Patched Dockerfile CMD")
                        break
                # Strip OTEL distro install line (generates noisy JSON logs)
                import re

                content = re.sub(
                    r"\n*RUN uv pip install aws-opentelemetry-distro[^\n]*\n*",
                    "\n",
                    content,
                )
                with open(dockerfile_path, "w") as f:
                    f.write(content)

        print("   ✅ Auto-configure complete")

    # Configure custom Browser Tool with Web Bot Auth
    browser_arn = None
    agent_config = {}

    if Path(".bedrock_agentcore.yaml").exists():
        with open(".bedrock_agentcore.yaml") as f:
            config = yaml.safe_load(f)

        # Get the agent configuration from the agents section
        default_agent = config.get("default_agent", "arato_agent")
        agent_config = config.get("agents", {}).get(default_agent, {})

        print(f"\n🔍 Checking agent configuration for: {default_agent}")

        network_mode = (
            agent_config.get("aws", {})
            .get("network_configuration", {})
            .get("network_mode", "")
        )

        print(f"   Network mode: {network_mode}")

        if network_mode == "VPC":
            print("   ✅ VPC mode detected - checking Browser Tool configuration...")
            region = agent_config.get("aws", {}).get("region")
            account = agent_config.get("aws", {}).get("account")
            network_config = (
                agent_config.get("aws", {})
                .get("network_configuration", {})
                .get("network_mode_config", {})
            )
            security_groups = network_config.get("security_groups", [])
            subnets = network_config.get("subnets", [])
            execution_role = agent_config.get("aws", {}).get("execution_role")

            print(f"   Region: {region}")
            print(f"   Account: {account}")
            print(f"   Security Groups: {security_groups}")
            print(f"   Subnets: {len(subnets) if subnets else 0} subnet(s)")
            print(
                f"   Execution Role: {execution_role[:50]}..."
                if execution_role
                else "   Execution Role: None"
            )

            # If execution role is missing, create it now to enable Browser Tool creation
            if not execution_role and region and account:
                print("\n   ⚙️  Execution role missing - creating one now...")
                execution_role = _ensure_execution_role(region, account)

                # Update config in memory and on disk
                if "agents" in config and default_agent in config["agents"]:
                    config["agents"][default_agent]["aws"]["execution_role"] = (
                        execution_role
                    )
                    config["agents"][default_agent]["aws"][
                        "execution_role_auto_create"
                    ] = False

                    with open(".bedrock_agentcore.yaml", "w") as f:
                        yaml.dump(config, f, default_flow_style=False)

                    print(
                        f"   ✅ Updated .bedrock_agentcore.yaml with role: {execution_role}"
                    )
                else:
                    print("   ⚠️  Could not update config file structure")

            if all([region, account, security_groups, subnets, execution_role]):
                print("\n   📡 Creating VPC Browser Tool with Web Bot Auth...")
                browser_id, browser_arn = _configure_custom_browser(
                    region=region,
                    account_id=account,
                    execution_role_arn=execution_role,
                    network_configuration={
                        "networkMode": "VPC",
                        "vpcConfig": {
                            "subnets": subnets,
                            "securityGroups": security_groups,
                        },
                    },
                    browser_signing={"enabled": True},
                    browser_name=f"{agent_name}_vpc_browser",
                    description="Browser with VPC mode and Web Bot Auth",
                )
            else:
                print(
                    "\n⚠️  Warning: Missing VPC configuration values in .bedrock_agentcore.yaml"
                )
                print("     Browser Tool will use default public network mode")
                missing = []
                if not region:
                    missing.append("region")
                if not account:
                    missing.append("account")
                if not security_groups:
                    missing.append("security_groups")
                if not subnets:
                    missing.append("subnets")
                if not execution_role:
                    missing.append("execution_role")
                print(f"     Missing values: {', '.join(missing)}")
        else:
            # Non-VPC mode: create a PUBLIC custom browser with Web Bot Auth
            print("   ℹ️  Not in VPC mode - creating browser with Web Bot Auth...")
            region = agent_config.get("aws", {}).get("region")
            account = agent_config.get("aws", {}).get("account")
            execution_role = agent_config.get("aws", {}).get("execution_role")

            # Create execution role if missing (same pattern as VPC mode)
            if not execution_role and region and account:
                print("\n   ⚙️  Execution role missing - creating one now...")
                execution_role = _ensure_execution_role(region, account)
                if "agents" in config and default_agent in config["agents"]:
                    config["agents"][default_agent]["aws"]["execution_role"] = (
                        execution_role
                    )
                    with open(".bedrock_agentcore.yaml", "w") as f:
                        yaml.dump(config, f, default_flow_style=False)

            if all([region, account, execution_role]):
                print("\n   📡 Creating Browser Tool with Web Bot Auth...")
                browser_id, browser_arn = _configure_custom_browser(
                    region=region,
                    account_id=account,
                    execution_role_arn=execution_role,
                    browser_signing={"enabled": True},
                    browser_name=f"{agent_name}_signed_browser",
                    description="Browser with Web Bot Auth for CAPTCHA reduction",
                )
            else:
                print(
                    "   ⚠️  Missing region/account/execution_role"
                    " - using default browser without Web Bot Auth"
                )

    # Note: agentcore CLI creates source.zip from project root, NOT from .bedrock_agentcore/arato_agent
    # The Dockerfile COPY commands expect files relative to the zip root
    # pyproject.toml and uv.lock should already be in project root
    # Verify they exist
    print("📦 Verifying dependency files in project root...")
    for dep_file in ["pyproject.toml", "uv.lock"]:
        dep_path = Path(dep_file)
        if dep_path.exists():
            print(f"  ✓ {dep_file} exists in project root")
        else:
            print(f"  ❌ ERROR: {dep_file} NOT FOUND in project root!")
            print("     Docker build will fail without this file")
    print()

    # Patch Dockerfile: fix CMD module path
    dockerfile_path = Path(f".bedrock_agentcore/{agent_name}/Dockerfile")
    if dockerfile_path.exists():
        with open(dockerfile_path) as f:
            df_content = f.read()

        df_modified = False

        # Fix CMD to point to correct module (no OTEL wrapper to avoid noisy JSON logs)
        target_cmd = 'CMD ["python", "-m", "platforms.aws_agentcore.app"]'
        for old_cmd in [
            'CMD ["opentelemetry-instrument", "python", "-m", "app"]',
            'CMD ["opentelemetry-instrument", "python", "-m", "platforms.aws_agentcore.app"]',
            'CMD ["python", "-m", "app"]',
        ]:
            if old_cmd in df_content:
                df_content = df_content.replace(old_cmd, target_cmd)
                df_modified = True
                break

        # Strip OTEL distro install line (generates noisy JSON logs)
        import re as _re

        otel_stripped = _re.sub(
            r"\n*# Install OTEL[^\n]*\n*# \(opentelemetry[^\n]*\n*RUN uv pip install aws-opentelemetry-distro[^\n]*\n*",
            "\n",
            df_content,
        )
        if otel_stripped != df_content:
            df_content = otel_stripped
            df_modified = True
            print("   ✅ Stripped OTEL distro install")

        # Strip OTEL env vars
        otel_env_stripped = _re.sub(r"\s*OTEL_[A-Z_]+=\S*", "", df_content)
        if otel_env_stripped != df_content:
            df_content = otel_env_stripped
            df_modified = True

        if df_modified:
            with open(dockerfile_path, "w") as f:
                f.write(df_content)
            print("   ✅ Patched Dockerfile CMD")

    # Build launch command with environment variables
    launch_cmd = ["agentcore", "launch", "--auto-update-on-conflict"]
    if agent_id:
        launch_cmd.extend(["--env", f"BEDROCK_AGENTCORE_AGENT_ID={agent_id}"])

    # Set LLM_PROVIDER: use config value or default to vertex
    llm_provider = agent_config.get("env", {}).get("LLM_PROVIDER", LLM_PROVIDER_VERTEX)
    launch_cmd.extend(["--env", f"LLM_PROVIDER={llm_provider}"])
    print(f"   ✅ Setting LLM_PROVIDER: {llm_provider}")

    # Add custom environment variables from config (skip LLM_PROVIDER, already handled)
    custom_env = agent_config.get("env", {})
    for key, value in custom_env.items():
        if key == "LLM_PROVIDER":
            continue  # Already set above
        launch_cmd.extend(["--env", f"{key}={value}"])
        print(f"Setting custom env var: {key}={value}")

    # Disable browser-use telemetry (PostHog) to avoid VPC connectivity issues
    launch_cmd.extend(["--env", "ANONYMIZED_TELEMETRY=false"])

    # Add Browser ARN if custom Browser Tool was configured (VPC or signed)
    if browser_arn:
        launch_cmd.extend(["--env", f"BEDROCK_AGENTCORE_BROWSER_ARN={browser_arn}"])
        print(f"\n✅ Browser ARN will be passed to agent: {browser_arn}")

    result = subprocess.run(launch_cmd, cwd=".")

    if result.returncode == 0:
        print("\n✅ Deployment complete!")
        missing_permissions, role_name = validate_permissions.permissions_missing()
        if missing_permissions:
            print("\n🔐 Applying browser and S3 permissions via IAM...")
            exit_code = _apply_role_permissions(role_name)
            if exit_code != 0:
                print(
                    "\n❌ Browser/S3 permissions setup failed. Run 'uv run python scripts/validate_permissions.py' manually and retry."
                )
                sys.exit(exit_code)
            print("✅ Browser and S3 permissions are now configured.")
        else:
            print(
                "\n🔐 Browser and S3 permissions already configured; skipping update."
            )

        # Store agent metadata in SSM for cross-job discovery (e.g. polling deploy)
        region = agent_config.get("aws", {}).get("region", "us-east-1")
        print("\n📦 Storing agent metadata in SSM...")
        _store_agent_metadata_in_ssm(region, agent_name=agent_name)

        print("\nNext steps:")
        print("1. Check status: uv run agentcore-status")
        print(
            '2. Test invocation: uv run agentcore-invoke \'{"target_url": "https://example.com"}\''
        )
    else:
        print("\n❌ Deployment failed")
        sys.exit(1)


def invoke_agent() -> None:
    """Invoke the deployed agent using boto3 bedrock-agentcore client (better error visibility)."""
    if len(sys.argv) < 2:
        print("Usage: uv run agentcore-invoke '<json-payload>'")
        print(
            'Example: uv run agentcore-invoke \'{"target_url": "https://example.com"}\''
        )
        sys.exit(1)

    payload_str = sys.argv[1]
    print(f"Invoking agent with payload: {payload_str}")

    # Parse and validate payload
    try:
        payload = json.loads(payload_str)
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON payload: {e}")
        sys.exit(1)

    # Resolve agent config — either from payload's agent_name (SSM) or local YAML
    agent_name = payload.pop("agent_name", None)

    if agent_name:
        # PR / named agent: resolve ARN and ID from SSM Parameter Store
        region = "us-east-1"
        ssm = boto3.client("ssm", region_name=region)
        agent_id_param = f"/{agent_name}/agentcore/agent_id"
        agent_arn_param = f"/{agent_name}/agentcore/agent_arn"

        try:
            agent_id = ssm.get_parameter(Name=agent_id_param)["Parameter"]["Value"]
            agent_arn = ssm.get_parameter(Name=agent_arn_param)["Parameter"]["Value"]
        except Exception as e:
            print(f"❌ Failed to resolve agent '{agent_name}' from SSM: {e}")
            print(f"   Looked for: {agent_id_param}, {agent_arn_param}")
            sys.exit(1)

        print(f"🔗 Targeting agent: {agent_name}")
        print(f"Agent ID: {agent_id}")
        print(f"Agent ARN: {agent_arn}")
        print(f"Region: {region}")
        # Use a minimal agent_config for VPC validation below
        agent_config: dict[str, Any] = {"aws": {"region": region}}
    else:
        # Default: load from local .bedrock_agentcore.yaml
        import yaml

        config_path = Path(".bedrock_agentcore.yaml")
        if not config_path.exists():
            print("❌ Configuration file .bedrock_agentcore.yaml not found")
            print("Run 'uv run agentcore-configure' first")
            sys.exit(1)

        try:
            with open(config_path) as f:
                config = yaml.safe_load(f)

            default_agent = config.get("default_agent")
            agent_config = config.get("agents", {}).get(default_agent, {})
            bedrock_config = agent_config.get("bedrock_agentcore", {})

            agent_arn = bedrock_config.get("agent_arn")
            agent_id = bedrock_config.get("agent_id")
            region = agent_config.get("aws", {}).get("region", "us-east-1")

            if not agent_arn:
                print("❌ Agent ARN not found in configuration")
                print("Run 'uv run agentcore-status' to check deployment status")
                sys.exit(1)

            print(f"Agent ID: {agent_id}")
            print(f"Agent ARN: {agent_arn}")
            print(f"Region: {region}")

        except Exception as e:
            print(f"❌ Failed to load agent configuration: {e}")
            sys.exit(1)

    # Generate session ID (must be 33+ characters)
    session_id = str(uuid.uuid4()).replace("-", "") + str(uuid.uuid4())[:9]
    print(f"Session ID: {session_id}")

    # Validate target URL format (warn about private IPs)
    if not vpc_utils.validate_target_url(payload):
        print("\nInvocation cancelled. Please update target_url and try again.")
        sys.exit(0)

    # Validate VPC connectivity if in VPC mode
    network_config = agent_config.get("aws", {}).get("network_configuration", {})
    if network_config.get("network_mode") == "VPC":
        security_groups = network_config.get("network_mode_config", {}).get(
            "security_groups", []
        )
        if security_groups and payload.get("target_url"):
            ec2 = boto3.client("ec2", region_name=region)
            vpc_utils.validate_vpc_connectivity(
                ec2, security_groups[0], payload["target_url"], region
            )

    # Create bedrock-agentcore client with extended timeout for blocking invocations
    from botocore.config import Config

    invoke_config = Config(
        read_timeout=120,  # Response is immediate (pipeline runs in background thread)
        connect_timeout=30,
        retries={"max_attempts": 0},  # Don't retry on timeout
    )
    client = boto3.client("bedrock-agentcore", region_name=region, config=invoke_config)
    # Retry logic for cold-start timeouts.
    # The first invocation after deploy triggers a container pull + startup that
    # often exceeds the 120s init limit. The retry hits the now-warm MicroVM.
    max_retries = 5
    retry_delay = 30  # seconds between retries (allow image to cache)

    for attempt in range(1, max_retries + 1):
        try:
            print(
                f"\n🚀 Invoking agent via boto3 bedrock-agentcore client... (attempt {attempt}/{max_retries})"
            )

            # Invoke agent
            response = client.invoke_agent_runtime(
                agentRuntimeArn=agent_arn,
                runtimeSessionId=session_id,
                payload=json.dumps(payload),
                qualifier="DEFAULT",  # Use DEFAULT endpoint
            )

            # Read response
            response_body = response["response"].read()
            response_data = json.loads(response_body)

            print("\n📤 Agent Response:")
            print(json.dumps(response_data, indent=2))

            # Check status
            status = response_data.get("status")
            if status == "completed":
                print("\n✅ Pipeline completed successfully")
                result = response_data.get("result", {})
                if result.get("artifacts", {}).get("file_urls"):
                    print("\n📦 Artifacts:")
                    for name, url in result["artifacts"]["file_urls"].items():
                        print(f"   {name}: {url}")
            elif status == "started":
                print("\n✅ Background task started")
                print("\n💡 View logs:")
                print(
                    f'   AWS_PAGER="" aws logs tail /aws/bedrock-agentcore/runtimes/{agent_id}-DEFAULT --follow --region {region}'
                )
            elif status == "error":
                print("\n❌ Invocation failed with error")
                error_msg = response_data.get("error", "Unknown error")
                print(f"Error: {error_msg}")
                sys.exit(1)
            else:
                print(f"\n⚠️  Unexpected status: {status}")

            # Success - exit the retry loop
            break

        except client.exceptions.RuntimeClientError as e:
            error_msg = str(e)
            if (
                "initialization time exceeded" in error_msg.lower()
                and attempt < max_retries
            ):
                print(
                    f"\n⏳ MicroVM cold start exceeded 120s (attempt {attempt}/{max_retries})"
                )
                print(
                    f"   Retrying in {retry_delay}s (the MicroVM should be warming up)..."
                )
                import time

                time.sleep(retry_delay)
                # Generate a new session ID for the retry
                session_id = str(uuid.uuid4()).replace("-", "") + str(uuid.uuid4())[:9]
                continue
            else:
                print(f"\n❌ Runtime error: {e}")
                sys.exit(1)
        except client.exceptions.ValidationException as e:
            print(f"\n❌ Validation error: {e}")
            print("Check that your payload matches the expected format")
            sys.exit(1)
        except client.exceptions.ResourceNotFoundException as e:
            print(f"\n❌ Resource not found: {e}")
            print("Verify that the agent is deployed and the ARN is correct")
            sys.exit(1)
        except client.exceptions.ThrottlingException as e:
            print(f"\n❌ Throttling error: {e}")
            print("Too many requests. Wait a moment and try again")
            sys.exit(1)
        except Exception as e:
            from botocore.exceptions import ReadTimeoutError as BotoReadTimeout

            if isinstance(e, BotoReadTimeout) and attempt < max_retries:
                print(f"\n⏳ Read timeout after 900s (attempt {attempt}/{max_retries})")
                print(f"   Agent may still be running. Retrying in {retry_delay}s...")
                import time

                time.sleep(retry_delay)
                session_id = str(uuid.uuid4()).replace("-", "") + str(uuid.uuid4())[:9]
                continue

            print(f"\n❌ Invocation failed: {e}")
            print(f"Error type: {type(e).__name__}")
            import traceback

            print("\nFull traceback:")
            traceback.print_exc()
            sys.exit(1)


def invoke_all_agent() -> None:
    """Invoke the deployed agent with all available personas (1 instance of each).

    Usage:
        uv run agentcore-invoke-all <target_url>
        uv run agentcore-invoke-all '{"target_url": "https://example.com", ...}'

    Examples:
        # Simple usage with just URL
        uv run agentcore-invoke-all https://example.com

        # Advanced usage with JSON payload
        uv run agentcore-invoke-all '{
          "target_url": "https://example.com",
          "max_turns": 10,
          "arato_api_url": "https://api.arato.ai/workspace/log",
          "arato_api_key": "your-key"
        }'

    This command automatically discovers all .persona files in persona_settings/
    and runs one instance of each. It accepts the same parameters as agentcore-invoke
    except persona_ids (which is auto-generated).

    Supported parameters:
        - target_url (required): Website URL to test
        - max_turns (optional): Max conversation turns per persona (default: 10)
        - seed_utterance (optional): Initial message (default: "Hello!")
        - arato_api_url (optional): Arato API endpoint for logging
        - arato_api_key (optional): Arato API key
        - thread_id (optional): Thread ID for logging correlation
        - max_parallel (optional): Max personas to run in parallel (default: 3)
        - org_id (optional): Organization ID
    """
    if len(sys.argv) < 2:
        print("Usage: uv run agentcore-invoke-all <target_url>")
        print("   or: uv run agentcore-invoke-all '<json-payload>'")
        print()
        print("Examples:")
        print("  uv run agentcore-invoke-all https://example.com")
        print(
            '  uv run agentcore-invoke-all \'{"target_url": "https://example.com", "max_turns": 10}\''
        )
        sys.exit(1)

    payload_str = sys.argv[1]

    # Check if it's a simple URL or JSON payload
    if payload_str.startswith("{"):
        # JSON payload
        try:
            payload = json.loads(payload_str)
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON payload: {e}")
            sys.exit(1)

        # Validate required fields
        if "target_url" not in payload:
            print("❌ Missing required field: target_url")
            sys.exit(1)

        target_url = payload["target_url"]
    else:
        # Simple URL format
        target_url = payload_str.strip()
        if not target_url:
            print("❌ target_url must be a non-empty string")
            sys.exit(1)
        payload = {"target_url": target_url}

    # Discover all personas
    from pathlib import Path

    persona_settings_dir = (
        Path(__file__).parent.parent.parent.parent / "persona_settings"
    )
    persona_files = sorted(persona_settings_dir.glob("*.persona"))

    if not persona_files:
        print(f"❌ No persona files found in {persona_settings_dir}")
        sys.exit(1)

    # Extract persona IDs from filenames (remove .persona extension)
    persona_ids = [f.stem for f in persona_files]

    # Override persona_ids in payload
    payload["persona_ids"] = persona_ids

    # Ensure org_id is set
    if "org_id" not in payload:
        payload["org_id"] = "agentcore-cli"

    print("☁️  Invoking AgentCore with ALL personas...")
    print(f"   URL: {target_url}")
    print(f"   Discovered {len(persona_ids)} personas:")
    for persona_id in persona_ids:
        print(f"      - {persona_id}")
    if "max_turns" in payload:
        print(f"   Max turns: {payload['max_turns']}")
    if "max_parallel" in payload:
        print(f"   Max parallel: {payload['max_parallel']}")
    print()

    # Invoke via our invoke_agent() which has proper timeout and status handling
    payload_json = json.dumps(payload)
    original_argv = sys.argv
    sys.argv = ["agentcore-invoke-all", payload_json]
    try:
        invoke_agent()
    finally:
        sys.argv = original_argv


def pipeline() -> None:
    """Deploy the latest build and run a smoke test against the provided URL."""
    if len(sys.argv) < 2:
        print("Usage: uv run pipeline <target_url>")
        sys.exit(1)

    target_url = sys.argv[1].strip()
    if not target_url:
        print("Error: target_url must be a non-empty string")
        sys.exit(1)

    launch()

    payload = json.dumps(
        {
            "target_url": target_url,
            "org_id": "agentcore-cli",
        }
    )
    print("\n🚀 Running pipeline...")

    # Invoke via our invoke_agent() which has proper timeout and status handling
    original_argv = sys.argv
    sys.argv = ["pipeline", payload]
    try:
        invoke_agent()
    finally:
        sys.argv = original_argv


def status() -> None:
    """Check AgentCore deployment status."""
    print("Checking AgentCore deployment status...")
    result = subprocess.run(
        ["agentcore", "status"],
        cwd=".",
    )
    if result.returncode != 0:
        print("\n❌ Status check failed")
        sys.exit(1)


def destroy() -> None:
    """Destroy AgentCore deployment and resources."""
    print("⚠️  This will destroy the AgentCore deployment and all related resources.")
    confirm = input("Are you sure? Type 'yes' to continue: ")
    if confirm.lower() != "yes":
        print("Cancelled.")
        return

    print("Destroying AgentCore deployment...")
    result = subprocess.run(
        ["agentcore", "destroy"],
        cwd=".",
    )
    if result.returncode == 0:
        print("\n✅ Resources destroyed")
    else:
        print("\n❌ Destruction failed")
        sys.exit(1)


if __name__ == "__main__":
    print("This module provides CLI commands for AgentCore deployment.")
    print("Use the commands via uv run:")
    print("  - uv run agentcore-configure")
    print("  - uv run agentcore-launch")
    print("  - uv run agentcore-invoke '<payload>'")
    print("  - uv run agentcore-status")
    print("  - uv run agentcore-destroy")
