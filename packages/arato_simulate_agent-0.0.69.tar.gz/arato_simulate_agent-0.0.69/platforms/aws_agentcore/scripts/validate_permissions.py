#!/usr/bin/env python3
"""Validate and apply AgentCore execution role permissions."""

import json
import subprocess
import sys
from pathlib import Path
from urllib.parse import unquote

import yaml

from platforms.aws_agentcore.storage import S3StorageAdapter

BEDROCK_POLICY_NAME = "BedrockAgentCoreBrowserAccess"
REQUIRED_AGENTCORE_ACTIONS = {
    "bedrock-agentcore:CreateBrowser",
    "bedrock-agentcore:ListBrowsers",
    "bedrock-agentcore:GetBrowser",
    "bedrock-agentcore:DeleteBrowser",
    "bedrock-agentcore:StartBrowserSession",
    "bedrock-agentcore:ListBrowserSessions",
    "bedrock-agentcore:GetBrowserSession",
    "bedrock-agentcore:StopBrowserSession",
    "bedrock-agentcore:UpdateBrowserStream",
    "bedrock-agentcore:ConnectBrowserAutomationStream",
    "bedrock-agentcore:ConnectBrowserLiveViewStream",
}
REQUIRED_S3_ACTIONS = {
    "s3:CreateBucket",
    "s3:GetBucketLocation",
    "s3:ListBucket",
    "s3:PutObject",
    "s3:GetObject",
    "s3:DeleteObject",
}
REQUIRED_MARKETPLACE_ACTIONS = {
    "aws-marketplace:ViewSubscriptions",
    "aws-marketplace:Subscribe",
}
REQUIRED_BEDROCK_ACTIONS = {
    "bedrock:InvokeModel",
}
REQUIRED_ACTIONS = (
    REQUIRED_AGENTCORE_ACTIONS
    | REQUIRED_S3_ACTIONS
    | REQUIRED_MARKETPLACE_ACTIONS
    | REQUIRED_BEDROCK_ACTIONS
)


def _execution_role_from_config() -> str | None:
    """Read execution role from .bedrock_agentcore.yaml if available."""

    config_path = Path(".bedrock_agentcore.yaml")
    if not config_path.exists():
        return None

    try:
        config = yaml.safe_load(config_path.read_text())
    except (OSError, yaml.YAMLError):
        return None

    if not isinstance(config, dict):
        return None

    agents = config.get("agents")
    agents = agents if isinstance(agents, dict) else {}
    default_agent = config.get("default_agent")
    if not isinstance(default_agent, str):
        default_agent = None

    candidate_configs = []
    if default_agent and isinstance(agents.get(default_agent), dict):
        candidate_configs.append(agents[default_agent])

    candidate_configs.extend(
        cfg
        for key, cfg in agents.items()
        if key != default_agent and isinstance(cfg, dict)
    )

    for agent_cfg in candidate_configs:
        aws_cfg = agent_cfg.get("aws") if isinstance(agent_cfg, dict) else None
        if not isinstance(aws_cfg, dict):
            continue
        role_arn = aws_cfg.get("execution_role")
        if isinstance(role_arn, str) and role_arn:
            return role_arn.split("/")[-1]

    return None


def get_execution_role_name() -> str | None:
    """Get the AgentCore execution role name from status output."""
    result: subprocess.CompletedProcess[str] = subprocess.run(
        ["agentcore", "status"], capture_output=True, text=True
    )

    role_name = _execution_role_from_config()
    if role_name:
        return role_name
    if result.returncode != 0:
        print("❌ Failed to get AgentCore status. Is the agent configured?")
        print("Run: uv run agentcore-configure")
        sys.exit(1)

    # Parse output to find execution role
    for line in result.stdout.split("\n"):
        if "Execution Role" in line or "execution_role" in line:
            if "arn:aws:iam" in line:
                role_arn = line.split("arn:aws:iam")[1].strip().strip('":,')
                role_name = role_arn.split("/")[-1]
                return role_name

    print("⚠️  Could not find execution role from status output")
    print("Please provide the role name manually or check with:")
    print("  agentcore status")
    return None


def build_permissions_policy(bucket_name: str) -> dict[str, object]:
    """Build the inline policy granting browser, S3, marketplace, and Bedrock model access."""

    s3_bucket_arn = f"arn:aws:s3:::{bucket_name}"
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "BedrockAgentCoreBrowserFullAccess",
                "Effect": "Allow",
                "Action": sorted(REQUIRED_AGENTCORE_ACTIONS),
                "Resource": "arn:aws:bedrock-agentcore:*:*:browser/*",
            },
            {
                "Sid": "BedrockAgentCoreArtifactS3Access",
                "Effect": "Allow",
                "Action": sorted(REQUIRED_S3_ACTIONS),
                "Resource": [s3_bucket_arn, f"{s3_bucket_arn}/*"],
            },
            {
                "Sid": "BedrockMarketplaceAccess",
                "Effect": "Allow",
                "Action": sorted(REQUIRED_MARKETPLACE_ACTIONS),
                "Resource": "*",
            },
            {
                "Sid": "BedrockModelInvoke",
                "Effect": "Allow",
                "Action": sorted(REQUIRED_BEDROCK_ACTIONS),
                "Resource": ["arn:aws:bedrock:*::foundation-model/anthropic.claude-*"],
            },
        ],
    }


def apply_role_permissions(role_name: str) -> bool:
    """Add browser, S3, marketplace, Bedrock model invocation permissions, and SQS queue permissions to the execution role."""
    storage_adapter = S3StorageAdapter()
    bucket_name = storage_adapter._resolve_bucket_name()
    policy = build_permissions_policy(bucket_name)

    print(
        f"Adding browser, S3, marketplace, and Bedrock model invocation permissions to role: {role_name}"
    )
    print(f"Target artifact bucket: {bucket_name}")
    print(f"Policy name: {BEDROCK_POLICY_NAME}")

    # Apply browser/S3/marketplace/Bedrock permissions
    result = subprocess.run(
        [
            "aws",
            "iam",
            "put-role-policy",
            "--role-name",
            role_name,
            "--policy-name",
            BEDROCK_POLICY_NAME,
            "--policy-document",
            json.dumps(policy),
        ],
        capture_output=True,
        text=True,
    )

    core_permissions_success = result.returncode == 0

    if core_permissions_success:
        print(
            "\n✅ Browser, S3, marketplace, and Bedrock model invocation permissions added successfully!"
        )
    else:
        print("\n❌ Failed to add core permissions")
        print(f"Error: {result.stderr}")
        print("\nTry adding the policy manually:")
        print(f"1. Go to IAM Console → Roles → {role_name}")
        print("2. Add inline policy with the following:")
        print(json.dumps(policy, indent=2))

    if core_permissions_success:
        print("\n🎉 All permissions configured successfully!")
        print("\nNext steps:")
        print(
            '1. Test the agent: uv run agentcore-invoke \'{"target_url": "https://example.com"}\''
        )
        print(
            "2. View live browser sessions: https://us-east-1.console.aws.amazon.com/bedrock-agentcore/builtInTools"
        )
        return True
    else:
        print("\n❌ Failed to add core permissions")
        print("\nTry adding the policy manually:")
        print(f"1. Go to IAM Console → Roles → {role_name}")
        print("2. Add inline policy with the following:")
        print(json.dumps(policy, indent=2))
        return False


def _get_account_id() -> str:
    """Get the current AWS account ID."""
    result = subprocess.run(
        ["aws", "sts", "get-caller-identity", "--query", "Account", "--output", "text"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    else:
        raise RuntimeError(f"Failed to get account ID: {result.stderr}")


def permissions_missing() -> tuple[bool, str | None]:
    """Return (missing_permissions, role_name) for the AgentCore execution role."""

    role_name = get_execution_role_name()

    if not role_name:
        print("\n⚠️  Unable to determine AgentCore execution role automatically.")
        return True, None

    result = subprocess.run(
        [
            "aws",
            "iam",
            "list-role-policies",
            "--role-name",
            role_name,
            "--output",
            "json",
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print(
            "\n⚠️  Unable to verify browser permissions via IAM API (will attempt to apply)."
        )
        if result.stderr:
            print(result.stderr.strip())
        return True, role_name

    try:
        policy_names = json.loads(result.stdout).get("PolicyNames", [])
    except json.JSONDecodeError:
        print(
            "\n⚠️  Unexpected response while checking IAM role policies (will attempt to apply)."
        )
        return True, role_name

    if BEDROCK_POLICY_NAME not in policy_names:
        return True, role_name

    policy_fetch = subprocess.run(
        [
            "aws",
            "iam",
            "get-role-policy",
            "--role-name",
            role_name,
            "--policy-name",
            BEDROCK_POLICY_NAME,
        ],
        capture_output=True,
        text=True,
    )

    if policy_fetch.returncode != 0:
        print(
            "\n⚠️  Unable to inspect existing inline policy (will attempt to reapply)."
        )
        if policy_fetch.stderr:
            print(policy_fetch.stderr.strip())
        return True, role_name

    try:
        policy_data = json.loads(policy_fetch.stdout).get("PolicyDocument")
        if isinstance(policy_data, str):
            policy_data = json.loads(unquote(policy_data))
        if not isinstance(policy_data, dict):
            raise ValueError("PolicyDocument is not a dictionary")
        statements = policy_data.get("Statement", [])
        if isinstance(statements, dict):
            statements = [statements]
    except (json.JSONDecodeError, ValueError) as exc:
        print("\n⚠️  Unable to parse existing inline policy (will attempt to reapply).")
        print(str(exc))
        return True, role_name

    current_actions: set[str] = set()
    for statement in statements:
        actions = statement.get("Action") if isinstance(statement, dict) else None
        if isinstance(actions, str):
            current_actions.add(actions)
        elif isinstance(actions, list):
            current_actions.update(str(action) for action in actions)

    missing_actions = REQUIRED_ACTIONS - current_actions
    return (len(missing_actions) > 0), role_name


def main() -> None:
    """CLI entry point."""
    print("🔧 AgentCore Permission Validator\n")

    role_name = get_execution_role_name()

    if not role_name:
        print("\nManual mode: Please provide the execution role name")
        print(
            "(Find it in IAM Console, starts with: AmazonBedrockAgentCoreSDKRuntime-)"
        )
        role_name = input("Role name: ").strip()

        if not role_name:
            print("❌ No role name provided. Exiting.")
            sys.exit(1)

    print(f"Found role: {role_name}\n")

    if apply_role_permissions(role_name):
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
