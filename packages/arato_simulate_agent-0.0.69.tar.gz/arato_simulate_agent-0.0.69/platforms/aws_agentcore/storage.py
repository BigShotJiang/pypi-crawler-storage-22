"""AWS S3 storage adapter implementation.

This adapter provides storage capabilities using Amazon S3 for session artifacts
and domain caching.
"""

from __future__ import annotations

import logging
import os
import re
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path

import boto3
from botocore.client import BaseClient
from botocore.exceptions import ClientError, NoCredentialsError

from constants import APP_CONTEXT_FILENAME
from core.storage.base import StorageAdapter
from utils.hitl_utils import HITLInterventionRequest, HITLInterventionResponse

logger = logging.getLogger(__name__)

PREFIX_ENV = "ARTIFACTS_S3_PREFIX"
BUCKET_NAME_PREFIX = "arato-agent-artifacts"
US_EAST_1 = "us-east-1"


class S3StorageAdapter(StorageAdapter):
    def _get_storage_prefix(
        self,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str:
        """Determine storage prefix based on org_id and task_id."""
        s3_prefix_root = os.getenv(PREFIX_ENV, "").strip("/")
        parts = [s3_prefix_root] if s3_prefix_root else []
        if org_id and task_id:
            parts.extend([org_id, task_id])
        elif task_id:
            parts.append(task_id)
        elif org_id:
            parts.append(org_id)
        elif session_id:
            parts.append(session_id)
        return "/".join(parts)

    def __init__(self, bucket_name: str | None = None, region: str | None = None):
        """Initialize the S3 storage adapter.

        Args:
            bucket_name: Optional S3 bucket name (auto-generated if not provided)
            region: AWS region (defaults to us-east-1)
        """
        self._bucket_name = bucket_name
        self._region = region or US_EAST_1

    @lru_cache(maxsize=1)
    def _get_s3_client(self) -> BaseClient:
        """Return a cached S3 client for the resolved region."""
        return boto3.client("s3", region_name=self._region)

    @lru_cache(maxsize=1)
    def _get_us_east_1_client(self) -> BaseClient:
        """Return a cached S3 client pinned to us-east-1 for bucket management."""
        return boto3.client("s3", region_name=US_EAST_1)

    @lru_cache(maxsize=1)
    def _get_account_id(self) -> str | None:
        """Fetch the AWS account ID to help generate deterministic bucket names."""
        try:
            sts_client = boto3.client("sts")
            response = sts_client.get_caller_identity()
            account_raw = response.get("Account")
            if isinstance(account_raw, str):
                return account_raw
            return None
        except (ClientError, NoCredentialsError) as exc:
            logger.info("Unable to resolve AWS account id for artifact bucket: %s", exc)
            return None

    def _sanitize_bucket_component(self, value: str) -> str:
        """Sanitize a string so it can be used inside an S3 bucket name."""
        sanitized = re.sub(r"[^a-z0-9-]", "-", value.lower()).strip("-")
        return sanitized or "artifacts"

    def _resolve_bucket_name(self) -> str:
        """Resolve the bucket name, generating a deterministic default when absent."""
        if self._bucket_name:
            return self._bucket_name

        bucket_prefix = self._sanitize_bucket_component(BUCKET_NAME_PREFIX)
        account_id = self._get_account_id() or "local"
        region = self._sanitize_bucket_component(self._region)

        bucket_name = f"{bucket_prefix}-{account_id}-{region}"
        bucket_name = re.sub(r"-+", "-", bucket_name).strip("-")
        if len(bucket_name) > 63:
            bucket_name = bucket_name[:63].rstrip("-")
        if len(bucket_name) < 3:
            bucket_name = f"{bucket_name}123"[:3]

        return bucket_name

    def _ensure_bucket_exists(self, bucket_name: str) -> None:
        """Create the S3 bucket when it does not already exist."""
        s3_client = self._get_us_east_1_client()
        try:
            s3_client.head_bucket(Bucket=bucket_name)
            return
        except ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code", "")
            if error_code in {"301", "PermanentRedirect"}:
                logger.info(
                    "Bucket %s already exists in a different region; using existing bucket",
                    bucket_name,
                )
                return
            if error_code not in {"404", "NoSuchBucket", "NotFound"}:
                logger.error("Failed to validate bucket %s: %s", bucket_name, exc)
                raise

        try:
            s3_client.create_bucket(Bucket=bucket_name)
            logger.info("Created S3 bucket for artifacts in us-east-1: %s", bucket_name)
        except ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code", "")
            if error_code == "BucketAlreadyOwnedByYou":
                logger.info(
                    "Bucket %s already exists and is owned by current account",
                    bucket_name,
                )
                return
            if error_code == "BucketAlreadyExists":
                raise RuntimeError(
                    f"S3 bucket {bucket_name} already exists and is owned by another account"
                ) from exc
            raise

    def get_storage_location(self) -> str:
        """Get the S3 storage location."""
        bucket_name = self._resolve_bucket_name()
        return f"s3://{bucket_name}"

    def _get_content_type(self, file_path: str) -> str:
        """Get content type for a file based on its extension.

        Args:
            file_path: Path to file or filename

        Returns:
            MIME type string
        """
        suffix = Path(file_path).suffix.lower()
        content_type_map = {
            ".mp4": "video/mp4",
            ".har": "application/json",
            ".json": "application/json",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".txt": "text/plain",
            ".md": "text/markdown",
            ".html": "text/html",
        }
        return content_type_map.get(suffix, "application/octet-stream")

    def _upload_file_to_s3(
        self,
        local_path: str | None,
        s3_key: str,
        content: bytes | str | None = None,
        content_type: str | None = None,
    ) -> str:
        """Internal method to upload a file to S3.

        Args:
            local_path: Path to local file (for upload_file) or None if using content
            s3_key: S3 object key (path within bucket)
            content: Raw bytes or string content (for put_object) or None if using local_path
            content_type: Optional explicit content type, auto-detected if None

        Returns:
            S3 URL (s3://bucket/key)

        Raises:
            ClientError: If upload fails
        """
        bucket_name = self._resolve_bucket_name()
        self._ensure_bucket_exists(bucket_name)

        # Auto-detect content type if not provided
        if content_type is None:
            content_type = self._get_content_type(local_path or s3_key)

        s3_client = self._get_s3_client()

        if local_path:
            # Upload from file on disk
            logger.info(f"Uploading file to S3: s3://{bucket_name}/{s3_key}")
            s3_client.upload_file(
                local_path,
                bucket_name,
                s3_key,
                ExtraArgs={"ContentType": content_type},
            )
        elif content is not None:
            # Upload from bytes or string content
            logger.info(f"Uploading content to S3: s3://{bucket_name}/{s3_key}")
            if isinstance(content, str):
                content = content.encode("utf-8")
            s3_client.put_object(
                Bucket=bucket_name,
                Key=s3_key,
                Body=content,
                ContentType=content_type,
            )
        else:
            raise ValueError("Either local_path or content must be provided")

        s3_url = f"s3://{bucket_name}/{s3_key}"
        logger.info(f"✓ Uploaded to {s3_url}")
        return s3_url

    def upload_persona_artifacts(
        self,
        persona_directory: str,
        persona_instance_name: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, str]:
        """Upload artifacts for a single persona instance immediately after completion.

        Args:
            persona_directory: Path to persona's artifact directory
            persona_instance_name: Name of the persona instance (e.g., "boundary_user_01")
            session_id: Optional session identifier
            org_id: Optional organization ID
            task_id: Optional task identifier

        Returns:
            Dictionary mapping relative file paths to S3 URLs
        """
        persona_path = Path(persona_directory)
        if not persona_path.exists() or not persona_path.is_dir():
            logger.warning(f"Persona directory does not exist: {persona_directory}")
            return {}

        resolved_session_id = session_id or persona_path.parent.name
        prefix = self._get_storage_prefix(
            session_id=resolved_session_id, org_id=org_id, task_id=task_id
        )

        file_urls: dict[str, str] = {}
        uploaded_files = 0

        # Upload all files in the persona directory
        for file_path in persona_path.rglob("*"):
            if file_path.is_dir():
                continue

            # Create relative path from persona directory
            relative_to_persona = file_path.relative_to(persona_path).as_posix()

            # Skip temp video subdirectories — the final video is already
            # at the persona root as run.mp4 (copied by move_run_video)
            if relative_to_persona.startswith(("run_video/", "app_context_video/")):
                continue
            # Build S3 key with persona instance name
            relative_key = f"{persona_instance_name}/{relative_to_persona}"
            object_key = f"{prefix}/{relative_key}" if prefix else relative_key

            try:
                s3_url = self._upload_file_to_s3(
                    local_path=str(file_path),
                    s3_key=object_key,
                )
                uploaded_files += 1

                # Map relative path to full S3 URL for easy lookup
                file_urls[relative_key] = s3_url

            except ClientError as exc:
                logger.error(f"Failed to upload {file_path}: {exc}")
                raise

        return file_urls

    def upload_artifacts(
        self,
        directory: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, str | dict[str, str]]:
        """Upload all files in the directory to S3 under a task/org/session-specific prefix."""
        directory_path = Path(directory)
        if not directory_path.exists() or not directory_path.is_dir():
            logger.warning(f"Artifact directory does not exist: {directory}")
            return {"file_urls": {}}

        resolved_session_id = session_id or directory_path.name
        prefix = self._get_storage_prefix(
            session_id=resolved_session_id, org_id=org_id, task_id=task_id
        )
        bucket_name = self._resolve_bucket_name()

        uploaded_files = 0
        file_urls: dict[str, str] = {}
        seen_artifacts: dict[str, list[str]] = {
            "mp4": [],
            "har": [],
        }
        summary_files_found = []  # Track summary-related files

        for file_path in directory_path.rglob("*"):
            if file_path.is_dir():
                continue

            # Skip domain_settings folder - it's cached separately at org level
            # NEVER include domain_settings in task-level artifacts
            relative_key = file_path.relative_to(directory_path).as_posix()
            if relative_key.startswith("domain_settings/"):
                continue

            # Skip temp video subdirectories (run_video/, app_context_video/)
            # The final videos are already at persona root as run.mp4
            if "/run_video/" in relative_key or "/app_context_video/" in relative_key:
                continue

            object_key = f"{prefix}/{relative_key}" if prefix else relative_key

            try:
                s3_url = self._upload_file_to_s3(
                    local_path=str(file_path),
                    s3_key=object_key,
                )
                uploaded_files += 1

                # Map relative path to full S3 URL
                file_urls[relative_key] = s3_url

                suffix = file_path.suffix.lower()
                if suffix == ".mp4":
                    seen_artifacts["mp4"].append(object_key)
                elif suffix == ".har":
                    seen_artifacts["har"].append(object_key)

                # Track summary-related files for logging
                filename = file_path.name
                if filename in [
                    "summary.json",
                    "summary.md",
                    "summary.html",
                    "report_data.json",
                ]:
                    summary_files_found.append(relative_key)

            except ClientError as exc:
                logger.error(f"Failed to upload {file_path}: {exc}")
                raise

        logger.info(
            "Uploaded %s artifact file(s) to s3://%s/%s",
            uploaded_files,
            bucket_name,
            prefix,
        )

        if not seen_artifacts["mp4"]:
            logger.warning("No MP4 recordings found in %s for upload", directory)
        else:
            logger.info("MP4 recordings uploaded: %s", seen_artifacts["mp4"])

        if not seen_artifacts["har"]:
            logger.warning("No HAR files found in %s for upload", directory)
        else:
            logger.info("HAR files uploaded: %s", seen_artifacts["har"])

        # Log summary files explicitly
        if summary_files_found:
            logger.info(f"✅ Summary files uploaded: {', '.join(summary_files_found)}")

        return {"bucket": bucket_name, "prefix": prefix, "file_urls": file_urls}

    def upload_progress_file(
        self,
        progress_file_path: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload only the progress.json file to S3.

        Args:
            progress_file_path: Path to the progress.json file
            session_id: Optional session identifier
            org_id: Optional organization ID
            task_id: Optional task identifier

        Returns:
            S3 URL of the uploaded file, or None if upload failed
        """
        progress_path = Path(progress_file_path)
        if not progress_path.exists():
            logger.warning(f"Progress file does not exist: {progress_file_path}")
            return None

        # Determine session_id from file path if not provided
        resolved_session_id = session_id or progress_path.parent.name
        prefix = self._get_storage_prefix(
            session_id=resolved_session_id, org_id=org_id, task_id=task_id
        )

        # Build S3 key for progress.json
        object_key = f"{prefix}/progress.json" if prefix else "progress.json"

        try:
            s3_url = self._upload_file_to_s3(
                local_path=str(progress_path),
                s3_key=object_key,
            )
            logger.debug(f"✓ Uploaded progress.json to {s3_url}")
            return s3_url
        except ClientError as exc:
            logger.error(f"Failed to upload progress.json: {exc}")
            return None

    def download_cache(
        self,
        domain: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Download a domain cache file from S3.

        Domain cache is always stored at org level (not task level).
        """
        bucket_name = self._resolve_bucket_name()
        # Use ONLY org_id, never task_id for domain cache
        prefix = self._get_storage_prefix(org_id=org_id)
        if prefix:
            object_key = f"{prefix}/domain_settings/{domain}/{cache_key}"
        else:
            object_key = f"domain_settings/{domain}/{cache_key}"

        s3_client = self._get_s3_client()
        try:
            logger.info(
                f"Checking S3 for domain cache: s3://{bucket_name}/{object_key}"
            )
            response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
            content: str = response["Body"].read().decode("utf-8")
            logger.info(
                f"✓ Found cached {cache_key} for {domain} in S3 ({len(content)} chars)"
            )
            return content
        except ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code", "")
            if error_code in {"404", "NoSuchKey"}:
                logger.info(f"No cached {cache_key} found for {domain} in S3")
                return None
            logger.error(f"Error downloading domain cache from S3: {exc}")
            return None

    def download_discovery_artifacts(
        self,
        domain: str,
        org_id: str | None = None,
    ) -> dict[str, str | list[str] | None]:
        """Download all discovery artifacts for a domain from S3.

        Returns a dict with:
        - app_context: app_context.json content or None
        - discovery_video: S3 URL to discovery.mp4 or None
        - screenshots: List of S3 URLs to screenshot files or empty list

        Args:
            domain: Domain name
            org_id: Optional organization ID

        Returns:
            Dictionary with artifact URLs and content
        """
        from constants import (
            APP_CONTEXT_FILENAME,
            DISCOVERY_VIDEO_FILENAME,
        )

        bucket_name = self._resolve_bucket_name()
        prefix = self._get_storage_prefix(org_id=org_id)
        domain_prefix = (
            f"{prefix}/domain_settings/{domain}"
            if prefix
            else f"domain_settings/{domain}"
        )

        s3_client = self._get_s3_client()
        artifacts: dict[str, str | list[str] | None] = {
            "app_context": None,
            "discovery_video": None,
            "screenshots": [],
        }

        # Download app_context.json
        try:
            app_context_key = f"{domain_prefix}/{APP_CONTEXT_FILENAME}"
            response = s3_client.get_object(Bucket=bucket_name, Key=app_context_key)
            artifacts["app_context"] = response["Body"].read().decode("utf-8")
            logger.info(f"✓ Downloaded app_context.json for {domain}")
        except ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code", "")
            if error_code not in {"404", "NoSuchKey"}:
                logger.warning(f"Error downloading app_context.json: {exc}")

        # Generate URL for discovery.mp4 (if it exists)
        discovery_video_key = f"{domain_prefix}/{DISCOVERY_VIDEO_FILENAME}"
        try:
            # Check if the file exists
            s3_client.head_object(Bucket=bucket_name, Key=discovery_video_key)
            # Generate a URL for it
            artifacts["discovery_video"] = f"s3://{bucket_name}/{discovery_video_key}"
            logger.info(f"✓ Found discovery video for {domain}")
        except ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code", "")
            if error_code not in {"404", "NoSuchKey"}:
                logger.warning(f"Error checking discovery video: {exc}")

        # List all screenshots in the screenshots subdirectory
        screenshots_prefix = f"{domain_prefix}/screenshots/"
        try:
            paginator = s3_client.get_paginator("list_objects_v2")
            pages = paginator.paginate(
                Bucket=bucket_name,
                Prefix=screenshots_prefix,
            )
            screenshots_list: list[str] = artifacts["screenshots"]  # type: ignore[assignment]
            for page in pages:
                if "Contents" in page:
                    for obj in page["Contents"]:
                        key = obj["Key"]
                        # Only include actual files, not the prefix itself
                        if key != screenshots_prefix:
                            screenshots_list.append(f"s3://{bucket_name}/{key}")
            if screenshots_list:
                logger.info(f"✓ Found {len(screenshots_list)} screenshots for {domain}")
        except ClientError as exc:
            logger.warning(f"Error listing screenshots: {exc}")

        return artifacts

    def upload_cache(
        self,
        domain: str,
        content: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> bool:
        """Upload a domain cache file to S3.

        Domain cache is always stored at org level (not task level).
        """
        # Use ONLY org_id, never task_id for domain cache
        prefix = self._get_storage_prefix(org_id=org_id)
        if prefix:
            object_key = f"{prefix}/domain_settings/{domain}/{cache_key}"
        else:
            object_key = f"domain_settings/{domain}/{cache_key}"

        try:
            self._upload_file_to_s3(
                local_path=None,
                s3_key=object_key,
                content=content,
                content_type="text/markdown",
            )
            logger.info(
                f"✓ Uploaded {cache_key} for {domain} to S3 ({len(content)} chars)"
            )
            return True
        except ClientError as exc:
            logger.error(f"Error uploading domain cache to S3: {exc}")
            return False

    def delete_domain_cache(
        self,
        domain: str,
        org_id: str | None = None,
    ) -> bool:
        """Delete all domain cache files for a domain in S3.

        Removes all discovery artifacts including:
        - app_context.json
        - discovery video (discovery.mp4)
        - screenshots/

        Args:
            domain: Domain name
            org_id: Optional organization ID

        Returns:
            True if successful, False otherwise
        """
        bucket_name = self._resolve_bucket_name()
        prefix = self._get_storage_prefix(org_id=org_id)
        domain_prefix = (
            f"{prefix}/domain_settings/{domain}"
            if prefix
            else f"domain_settings/{domain}"
        )

        s3_client = self._get_s3_client()
        deleted_count = 0

        try:
            # List all objects in the domain_settings/{domain}/ prefix
            logger.info(f"Deleting domain cache for {domain}")
            paginator = s3_client.get_paginator("list_objects_v2")
            pages = paginator.paginate(
                Bucket=bucket_name,
                Prefix=f"{domain_prefix}/",
            )

            for page in pages:
                if "Contents" not in page:
                    continue

                # Delete all objects one by one
                for obj in page["Contents"]:
                    object_key = obj["Key"]
                    try:
                        s3_client.delete_object(Bucket=bucket_name, Key=object_key)
                        deleted_count += 1
                        logger.debug(f"  Deleted: {object_key}")
                    except ClientError as exc:
                        logger.error(f"Failed to delete {object_key}: {exc}")
                        return False

            logger.info(f"✓ Deleted {deleted_count} cache file(s) for domain {domain}")
            return True

        except ClientError as exc:
            logger.error(f"Error deleting domain cache from S3: {exc}")
            return False

    def save_hitl_intervention(
        self,
        session_id: str,
        intervention_id: str,
        request: HITLInterventionRequest,
        response: HITLInterventionResponse | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> bool:
        """Save HITL intervention details to S3 for audit trail.

        Args:
            session_id: Browser session ID
            intervention_id: Unique intervention identifier
            request: Intervention request details
            response: Optional intervention response details
            org_id: Optional organization ID for multi-tenant scenarios

        Returns:
            True if successfully saved, False otherwise
        """
        bucket_name = self._resolve_bucket_name()
        self._ensure_bucket_exists(bucket_name)

        # Build object key with timestamp for chronological ordering
        timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        prefix = self._get_storage_prefix(
            session_id=session_id, org_id=org_id, task_id=task_id
        )
        if prefix:
            object_key = f"{prefix}/hitl_interventions/{session_id}/{timestamp}_{intervention_id}.json"
        else:
            object_key = (
                f"hitl_interventions/{session_id}/{timestamp}_{intervention_id}.json"
            )

        # Build intervention record
        intervention_data = {
            "session_id": session_id,
            "intervention_id": intervention_id,
            "request": request.to_dict(),
            "response": response.to_dict() if response else None,
            "saved_at": datetime.now(UTC).isoformat(),
        }

        import json

        try:
            self._upload_file_to_s3(
                local_path=None,
                s3_key=object_key,
                content=json.dumps(intervention_data, indent=2),
                content_type="application/json",
            )
            logger.info(f"✓ Saved HITL intervention {intervention_id} to S3")
            return True
        except ClientError as exc:
            logger.error(f"Error saving HITL intervention to S3: {exc}")
            return False

    def list_hitl_interventions(
        self, session_id: str, org_id: str | None = None
    ) -> list[dict[str, str | dict[str, str] | None]]:
        """List all HITL interventions for a session from S3.

        Args:
            session_id: AgentCore browser session ID (not internal browser-use session ID)
            org_id: Optional organization ID for multi-tenant scenarios

        Returns:
            List of intervention records (empty list on error)
        """
        bucket_name = self._resolve_bucket_name()

        # Search all interventions (session_id is AgentCore session ID,
        # but interventions are stored by internal browser session ID)
        if org_id:
            prefix = f"{org_id}/hitl_interventions/"
        else:
            prefix = "hitl_interventions/"

        s3_client = self._get_s3_client()
        try:
            logger.info(
                f"Listing HITL interventions from S3: s3://{bucket_name}/{prefix}"
            )
            response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

            if "Contents" not in response:
                logger.info(f"No HITL interventions found for session {session_id}")
                return []

            import json

            interventions = []
            for obj in response["Contents"]:
                try:
                    obj_response = s3_client.get_object(
                        Bucket=bucket_name, Key=obj["Key"]
                    )
                    content = obj_response["Body"].read().decode("utf-8")
                    intervention_data = json.loads(content)

                    # Filter by AgentCore session ID
                    if intervention_data.get("agentcore_session_id") == session_id:
                        interventions.append(intervention_data)
                except (ClientError, json.JSONDecodeError) as exc:
                    logger.warning(
                        f"Failed to load intervention from {obj['Key']}: {exc}"
                    )
                    continue

            logger.info(
                f"✓ Found {len(interventions)} HITL interventions for session {session_id}"
            )
            return interventions

        except ClientError as exc:
            logger.error(f"Error listing HITL interventions from S3: {exc}")
            return []

    def upload_screenshot(
        self,
        screenshot_bytes: bytes,
        session_id: str,
        intervention_id: str,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload a screenshot to S3 and return the S3 URL.

        Args:
            screenshot_bytes: Raw screenshot image bytes (PNG format)
            session_id: Session identifier
            intervention_id: Intervention identifier
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            S3 URL to the screenshot, None if upload failed
        """
        # Build object key
        timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        prefix = self._get_storage_prefix(
            session_id=session_id, org_id=org_id, task_id=task_id
        )
        if prefix:
            object_key = f"{prefix}/hitl_screenshots/{session_id}/{timestamp}_{intervention_id}.png"
        else:
            object_key = (
                f"hitl_screenshots/{session_id}/{timestamp}_{intervention_id}.png"
            )

        try:
            s3_url = self._upload_file_to_s3(
                local_path=None,
                s3_key=object_key,
                content=screenshot_bytes,
                content_type="image/png",
            )
            return s3_url
        except ClientError as exc:
            logger.error(f"Error uploading screenshot to S3: {exc}")
            return None

    def upload_discovery_screenshot(
        self,
        screenshot_bytes: bytes,
        domain: str,
        filename: str,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload a discovery screenshot to domain settings folder in S3.

        Args:
            screenshot_bytes: Raw screenshot image bytes (PNG format)
            domain: Domain name (used for folder organization)
            filename: Screenshot filename (e.g., '20241112_123456_homepage.png')
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            S3 URL to the screenshot, None if upload failed
        """
        # Build object key in domain_settings folder (matching app_context.json location)
        # Discovery artifacts are always at org level (not task level)
        prefix = self._get_storage_prefix(org_id=org_id)
        if prefix:
            object_key = f"{prefix}/domain_settings/{domain}/screenshots/{filename}"
        else:
            object_key = f"domain_settings/{domain}/screenshots/{filename}"

        try:
            s3_url = self._upload_file_to_s3(
                local_path=None,
                s3_key=object_key,
                content=screenshot_bytes,
                content_type="image/png",
            )
            return s3_url
        except ClientError as exc:
            logger.error(f"Error uploading discovery screenshot to S3: {exc}")
            return None

    def upload_discovery_video(
        self,
        video_path: str,
        domain: str,
        filename: str,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload a discovery video to domain settings folder in S3.

        Args:
            video_path: Path to video file on disk
            domain: Domain name (used for folder organization)
            filename: Video filename (e.g., 'discovery.mp4')
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            S3 URL to the video, None if upload failed
        """
        # Build object key in domain_settings folder (matching app_context.json location)
        # Discovery artifacts are always at org level (not task level)
        prefix = self._get_storage_prefix(org_id=org_id)
        if prefix:
            object_key = f"{prefix}/domain_settings/{domain}/{filename}"
        else:
            object_key = f"domain_settings/{domain}/{filename}"

        try:
            s3_url = self._upload_file_to_s3(
                local_path=video_path,
                s3_key=object_key,
                content_type="video/mp4",
            )
            return s3_url
        except ClientError as exc:
            logger.error(f"Error uploading discovery video to S3: {exc}")
            return None


__all__ = [
    "S3StorageAdapter",
]
