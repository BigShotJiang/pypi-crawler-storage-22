"""Abstract base for platform adapters.

Platform adapters handle deployment-specific concerns like:
- Entry points and invocation handlers
- Browser management (local vs cloud)
- Session/storage management
- Platform-specific configuration
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from core.schemas import AgentIdentity


class PlatformAdapter(ABC):
    """Base class for platform-specific runtime adapters.

    Each platform (AWS AgentCore, local CLI, Google Cloud Run, etc.)
    implements this interface to provide platform-specific functionality
    while keeping core agent logic platform-agnostic.
    """

    @abstractmethod
    async def invoke(self, payload: dict[str, Any], context: Any) -> dict[str, Any]:
        """Platform-specific invocation entry point.

        Converts platform-specific payload to standardized format,
        runs core orchestrator, and returns platform-specific response.

        Args:
            payload: Platform-specific request payload
            context: Platform-specific invocation context

        Returns:
            Platform-specific response
        """
        pass

    @abstractmethod
    def get_session_directory(self, session_id: str) -> Path:
        """Get platform-specific session directory for artifacts.

        Args:
            session_id: Session identifier

        Returns:
            Path to session directory
        """
        pass

    @abstractmethod
    def resolve_session_id(self, requested_id: str | None, context: Any) -> str:
        """Resolve session ID from request or generate platform-appropriate one.

        Args:
            requested_id: Optional session ID from request
            context: Platform invocation context

        Returns:
            Resolved session ID
        """
        pass

    @abstractmethod
    def supports_background_tasks(self) -> bool:
        """Whether platform supports long-running background tasks.

        Returns:
            True if platform can run tasks asynchronously
        """
        pass

    @abstractmethod
    def supports_hitl(self) -> bool:
        """Whether platform supports Human-in-the-Loop interventions.

        Returns:
            True if platform supports HITL (e.g., AWS AgentCore with DCV)
            False if platform doesn't support HITL (e.g., local with visible browser)
        """
        pass

    @abstractmethod
    async def get_hitl_viewer_url(self, session_id: str) -> str | None:
        """Get the URL for the HITL viewer interface.

        Args:
            session_id: Browser session ID

        Returns:
            URL to HITL service or None if not available
        """
        pass

    @abstractmethod
    def get_agent_identity(self) -> AgentIdentity:
        """Get the agent identity information.

        Returns:
            AgentIdentity model with agent information
        """
        pass


__all__ = ["PlatformAdapter"]
