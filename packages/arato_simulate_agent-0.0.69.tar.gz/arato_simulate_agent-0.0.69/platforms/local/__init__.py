"""Local platform implementation for running agents without cloud dependencies.

This platform uses:
- Local Playwright browsers
- AWS Bedrock for LLM
- Local filesystem storage
"""

from platforms.local.adapter import (
    LocalPlatformAdapter,
    configure_local_platform,
    run_local_pipeline,
)
from platforms.local.browser import LocalBrowserManager
from platforms.local.storage import LocalStorageAdapter

__all__ = [
    "LocalPlatformAdapter",
    "LocalBrowserManager",
    "LocalStorageAdapter",
    "configure_local_platform",
    "run_local_pipeline",
]
