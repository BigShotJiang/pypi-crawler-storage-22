"""Local platform adapter for running agents locally.

This adapter configures the system to use local implementations:
- Local Playwright browser
- Local LLM (OpenAI or Anthropic)
- Local filesystem storage
"""

import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from botocore.exceptions import ClientError, NoCredentialsError
from google.auth.exceptions import DefaultCredentialsError

from constants import (
    DEFAULT_MAX_PARALLEL_PERSONAS,
    DEFAULT_MAX_TURNS,
    DEFAULT_PIPELINE_TIMEOUT,
    DEFAULT_SEED_UTTERANCE,
    DEFAULT_STEP_TIMEOUT,
    LOCAL_STORAGE_BASE_DIR,
)
from core.browser import set_browser_manager
from core.llm import LLMAdapter, set_llm_adapter
from core.schemas import AgentIdentity
from core.storage import set_storage_adapter
from platforms.local.browser import LocalBrowserManager
from platforms.local.storage import LocalStorageAdapter

logger = logging.getLogger(__name__)


class LocalPlatformAdapter:
    """Platform adapter for local development and testing.

    Configures all subsystems to use local implementations without
    requiring any cloud services.

    HITL Support:
    ------------
    The local platform has limited HITL (Human-in-the-Loop) support:
    - Browser is visible on screen (manual intervention is always possible)
    - HITL methods in LocalBrowserManager are no-ops by default
    - Set environment variable LOCAL_HITL_INTERACTIVE=true for CLI-based
      intervention mode that pauses execution and waits for user confirmation

    Use Cases:
    - Development: Test agent logic without AWS infrastructure
    - Testing: Interactive mode allows testing HITL workflows locally
    - Debugging: Visual browser allows manual intervention at any time
    """

    def __init__(
        self,
        storage_dir: str = LOCAL_STORAGE_BASE_DIR,
        enable_hitl_interactive: bool = False,
        s3_bucket_override: str | None = None,
    ):
        """Initialize local platform adapter.

        Args:
            storage_dir: Base directory for local storage (used if s3_bucket_override is not provided)
            enable_hitl_interactive: Enable interactive HITL mode (also controllable via
                                    LOCAL_HITL_INTERACTIVE environment variable)
            s3_bucket_override: S3 bucket path (e.g., 'my-bucket/pr-123') to use S3 storage
                              instead of local filesystem. Only valid for local platform.
                              Format: 'bucket-name/optional/path'
                              If not provided, auto-generates bucket in format:
                              'arato-agent-artifacts-pr-{branch_id}'
        """
        self.storage_dir = storage_dir
        self.enable_hitl_interactive = enable_hitl_interactive
        self.s3_bucket_override = s3_bucket_override

        # Set environment variable for HITL interactive mode if requested
        if enable_hitl_interactive:
            import os

            os.environ["LOCAL_HITL_INTERACTIVE"] = "true"
            logger.info("✓ HITL interactive mode enabled (CLI-based pause/resume)")

        # Initialize adapters
        self._initialize_adapters()

        logger.info("🏠 Local platform adapter initialized")
        # Get actual model name from adapter
        from core.llm import get_llm_adapter

        try:
            model_id = get_llm_adapter().get_default_model_id()
            logger.info(f"   LLM: {model_id}")
        except Exception:
            logger.info("   LLM: Unknown")

        if s3_bucket_override:
            logger.info(f"   Storage: S3 (override) - {s3_bucket_override}")
        else:
            branch_id = self._get_branch_id()
            if branch_id:
                logger.info(
                    f"   Storage: S3 (auto) - arato-agent-artifacts-pr-{branch_id}"
                )
            else:
                logger.info(f"   Storage: {Path(storage_dir).absolute()}")

    def _get_branch_id(self) -> str | None:
        """Automatically detect the current git branch ID.

        Returns:
            Branch name/ID if in a git repository, None otherwise
        """
        try:
            # Try to get current branch name from git
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                timeout=5,
                cwd=os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            )
            if result.returncode == 0:
                branch = result.stdout.strip()
                if branch and branch != "HEAD":
                    # Sanitize branch name for S3 bucket compatibility
                    # Only allow alphanumeric and hyphens
                    sanitized = "".join(
                        c if c.isalnum() or c == "-" else "-" for c in branch.lower()
                    )
                    sanitized = sanitized.strip("-").replace("--", "-")[:63]
                    return sanitized if sanitized else None
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception) as e:
            logger.debug(f"Could not detect git branch: {e}")
        return None

    def _initialize_adapters(self) -> None:
        """Initialize all platform adapters."""
        # Browser: Local Playwright
        set_browser_manager(LocalBrowserManager())
        logger.info("✓ Browser: Local Playwright")

        # LLM: Default
        llm_adapter = LLMAdapter()
        set_llm_adapter(llm_adapter)
        logger.info(f"✓ LLM: {llm_adapter.get_default_model_id()}")

        # Storage: S3 with auto-generated bucket if override not provided, or local filesystem
        if self.s3_bucket_override is not None:
            # User provided explicit S3 override
            from platforms.aws_agentcore.storage import S3StorageAdapter

            # Parse S3 path - format: "bucket-name/path/prefix"
            # Split into bucket and prefix
            parts = self.s3_bucket_override.split("/", 1)
            bucket_name = parts[0]
            prefix_path = parts[1] if len(parts) > 1 else ""

            # Set environment variable for S3 prefix (used by S3StorageAdapter)
            os.environ["ARTIFACTS_S3_PREFIX"] = prefix_path

            # Initialize S3 storage adapter with explicit bucket name
            set_storage_adapter(S3StorageAdapter(bucket_name=bucket_name))
            logger.info(f"✓ Storage: S3 (override) - {self.s3_bucket_override}")
        else:
            # Auto-generate S3 bucket with branch ID
            branch_id = self._get_branch_id()
            if branch_id:
                from platforms.aws_agentcore.storage import S3StorageAdapter

                bucket_name = f"arato-agent-artifacts-pr-{branch_id}"
                set_storage_adapter(S3StorageAdapter(bucket_name=bucket_name))
                logger.info(f"✓ Storage: S3 (auto) - {bucket_name}")
            else:
                # Fall back to local storage if branch ID cannot be determined
                set_storage_adapter(LocalStorageAdapter(base_dir=self.storage_dir))
                logger.info("✓ Storage: Local filesystem")

    def get_agent_identity(self) -> AgentIdentity:
        """Get the agent identity information.

        Returns:
            AgentIdentity model with agent information
        """
        pid = os.getpid()
        return AgentIdentity(
            name=f"arato_agent_{pid}",
            platform="local",
        )

    def _validate_aws_credentials(self) -> None:
        """Validate AWS credentials are configured and working.

        Logs a warning if credentials are missing or invalid, but allows
        the agent to continue running.
        """
        try:
            import boto3

            # Test AWS credentials by calling STS GetCallerIdentity
            sts = boto3.client("sts")
            identity = sts.get_caller_identity()
            logger.info(f"✓ AWS credentials validated (Account: {identity['Account']})")
        except NoCredentialsError:
            logger.warning("""⚠️ AWS credentials not found — continuing without AWS.

To configure AWS credentials, use one of:
  1. source <(arato aws-creds dev)
  2. aws configure
  3. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables

Note: S3 storage (artifacts, caching) will not be available.""")
        except ClientError as e:
            logger.warning(f"⚠️ AWS credentials validation failed: {e}")
            logger.warning("""To fix, verify your AWS credentials are valid:
  - Check if credentials have expired
  - Verify IAM permissions (need S3 access at minimum)
  - Try: source <(arato aws-creds dev)""")
        except Exception as e:
            logger.warning(f"⚠️ Unexpected error validating AWS credentials: {e}")

    def _validate_gcp_credentials(self) -> None:
        """Validate GCP credentials are configured and working.

        If a 'gcloud-service-account.json' file exists in the simulate-agent
        root directory, it will be used as the Google credentials key file.

        Raises:
            SystemExit: If GCP credentials are invalid or missing
        """
        # Check for service account key file in project root
        sa_key_path = (
            Path(__file__).resolve().parent.parent.parent
            / "gcloud-service-account.json"
        )
        if sa_key_path.is_file():
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(sa_key_path)
            logger.info(f"✓ Using GCP service account key: {sa_key_path}")

        try:
            import google.auth
            from google.auth.exceptions import RefreshError

            # Test GCP credentials
            credentials, project = google.auth.default()

            # CRITICAL: When using Workload Identity Federation with service account
            # impersonation, credentials must have scopes BEFORE refresh.
            # See: https://cloud.google.com/iam/docs/workload-identity-federation-with-deployment-pipelines#refresh
            if hasattr(credentials, "with_scopes"):
                credentials = credentials.with_scopes(
                    ["https://www.googleapis.com/auth/cloud-platform"]
                )

            # Try to refresh credentials to ensure they're not expired
            # This will fail if reauthentication is needed
            try:
                if hasattr(credentials, "refresh") and hasattr(credentials, "valid"):
                    if not credentials.valid:
                        import google.auth.transport.requests

                        request = google.auth.transport.requests.Request()
                        credentials.refresh(request)
            except RefreshError as refresh_err:
                logger.error(f"""❌ GCP credentials need reauthentication!

Error: {refresh_err}

Please run:
  gcloud auth application-default login

Required for: Claude on Vertex AI (LLM)""")
                sys.exit(1)

            if project:
                logger.info(f"✓ GCP credentials validated (Project: {project})")
            else:
                logger.info("✓ GCP credentials validated")
        except DefaultCredentialsError:
            logger.error("""❌ GCP credentials not found!

Please configure GCP credentials using:
  1. gcloud auth application-default login
  2. gcloud config set project 55452978084

Required for: Claude on Vertex AI (LLM)""")
            sys.exit(1)
        except Exception as e:
            logger.error(f"❌ Unexpected error validating GCP credentials: {e}")
            sys.exit(1)

    async def run_pipeline(
        self,
        target_url: str,
        persona_ids: list[str] | None = None,
        seed_utterance: str = DEFAULT_SEED_UTTERANCE,
        max_turns: int = DEFAULT_MAX_TURNS,
        output_dir: str | None = None,
        arato_api_url: str | None = None,
        arato_api_key: str | None = None,
        thread_id: str | None = None,
        max_parallel: int = DEFAULT_MAX_PARALLEL_PERSONAS,
        org_id: str | None = None,
        task_id: str | None = None,
        goal: str = "chat",
        step_timeout: int = DEFAULT_STEP_TIMEOUT,
        timeout: int = DEFAULT_PIPELINE_TIMEOUT,
        storage_state: str | None = None,
        task: Any | None = None,
        polling_client: Any | None = None,
        broadcast_identity: bool = False,
        force_discovery: bool = False,
        force_ground_truth: bool = False,
        session_prefix: str | None = None,
        exclude_persona_ids: list[str] | None = None,
        include_eu_ai_act_report: bool = False,
        domain: str | None = None,
        test_suite: Any | None = None,
        target_urls: list[str] | None = None,
    ) -> dict[str, Any]:
        """Run the agent pipeline using local implementations.

        Args:
            target_url: Website to test (used for discovery and as default if target_urls not provided)
            persona_ids: List of persona identifiers (e.g., ['malicious_user', 'nice_user'])
            seed_utterance: Initial message
            max_turns: Number of conversation turns
            output_dir: Directory to save artifacts (local path)
            arato_api_url: Optional Arato API endpoint for logging
            arato_api_key: Optional Arato API key
            thread_id: Optional thread ID for logging correlation
            max_parallel: Maximum personas to run in parallel
            org_id: Optional organization ID
            task_id: Optional task ID
            goal: Execution goal - 'discover' (discovery only) or 'chat' (discovery + chat, default)
            step_timeout: Timeout in seconds for each agent step (default: 60)
            timeout: Total timeout in seconds for chat conversation (default: 1200)
            include_eu_ai_act_report: If True, include EU AI Act compliance report in summary
            domain: Optional domain ID for composable config system (e.g., 'travel', 'hr', 'media')
            test_suite: Optional TestSuite object for generating per-test/scenario summaries
            target_urls: Optional list of URLs. If provided, each persona randomly selects one.

        Raises:
            SystemExit: If AWS or GCP credentials are not configured properly
            storage_state: Path to JSON file with saved authentication state
            broadcast_identity: If True, send 'arato_agent/<task_id>' as first message
            force_discovery: If True, ignore cached app context and rediscover from scratch
            force_ground_truth: If True, ignore cached ground truth and re-collect from scratch
            session_prefix: Optional prefix to prepend to auto-generated session directory names

        Returns:
            Pipeline execution result
        """
        # Validate credentials before starting any work
        logger.info("🔐 Validating credentials...")
        self._validate_aws_credentials()
        self._validate_gcp_credentials()

        from agents.graph_orchestrator import GraphOrchestrator

        logger.info("🚀 Starting local pipeline with GraphOrchestrator")
        logger.info(f"   URL: {target_url}")
        logger.info(f"   Personas: {persona_ids}")
        logger.info(f"   Max turns: {max_turns}")

        # Detect if running in CI/CD environment
        is_ci = (
            os.environ.get("GITHUB_ACTIONS") == "true" or os.environ.get("CI") == "true"
        )
        headless = is_ci
        if not headless:
            logger.info("🖥️  Browser will run in VISIBLE mode (not in CI)")
        else:
            logger.info("🤖 Browser will run in HEADLESS mode (CI detected)")

        # Create orchestrator (uses configured local adapters)
        orchestrator = GraphOrchestrator(
            headless=headless,
            storage_state=storage_state,
        )

        # Run pipeline
        result = await orchestrator.run_pipeline(
            target_url=target_url,
            persona_ids=persona_ids,
            seed_utterance=seed_utterance,
            max_turns=max_turns,
            output_dir=output_dir,
            arato_api_url=arato_api_url,
            arato_api_key=arato_api_key,
            thread_id=thread_id,
            max_parallel=max_parallel,
            org_id=org_id,
            task_id=task_id,
            goal=goal,
            step_timeout=step_timeout,
            timeout=timeout,
            storage_state=storage_state,
            task=task,
            polling_client=polling_client,
            platform_adapter=self,
            broadcast_identity=broadcast_identity,
            force_discovery=force_discovery,
            force_ground_truth=force_ground_truth,
            session_prefix=session_prefix,
            exclude_persona_ids=exclude_persona_ids,
            include_eu_ai_act_report=include_eu_ai_act_report,
            domain=domain,
            test_suite=test_suite,
            target_urls=target_urls,
        )

        logger.info("✅ Local pipeline completed")
        return result


def configure_local_platform(
    storage_dir: str = LOCAL_STORAGE_BASE_DIR,
    s3_bucket_override: str | None = None,
    **kwargs: Any,
) -> LocalPlatformAdapter:
    """Configure the system to use local platform implementations.

    This is a convenience function for setting up the local platform.

    Args:
        storage_dir: Base directory for storage (ignored if s3_bucket_override is provided)
        s3_bucket_override: S3 bucket path to use S3 storage instead of local filesystem
                          Format: 's3://bucket-name/path' or 'bucket-name/path'
        **kwargs: Additional configuration options

    Returns:
        Configured LocalPlatformAdapter instance

    Example:
        >>> from platforms.local import configure_local_platform
        >>> adapter = configure_local_platform()
        >>> await adapter.run_pipeline(
        ...     target_url='https://example.com',
        ...     persona_ids=['nice_user'],
        ...     max_turns=5,
        ... )

    Example with S3 override:
        >>> adapter = configure_local_platform(s3_bucket_override='my-bucket/pr-123')
        >>> await adapter.run_pipeline(
        ...     target_url='https://example.com',
        ...     persona_ids=['malicious_user'],
        ... )
    """
    return LocalPlatformAdapter(
        storage_dir=storage_dir, s3_bucket_override=s3_bucket_override, **kwargs
    )


async def run_local_pipeline(
    target_url: str,
    persona_ids: list[str] | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Quick function to run a pipeline with local platform.

    Args:
        target_url: Website to test
        persona_ids: List of persona identifiers
        **kwargs: Additional pipeline arguments (max_turns, storage_state, etc.)

    Returns:
        Pipeline execution result

    Example:
        >>> import asyncio
        >>> from platforms.local import run_local_pipeline
        >>> result = asyncio.run(run_local_pipeline(
        ...     target_url='https://example.com',
        ...     persona_ids=['nice_user'],
        ...     max_turns=5,
        ... ))
    """
    adapter = configure_local_platform()
    return await adapter.run_pipeline(
        target_url=target_url, persona_ids=persona_ids, **kwargs
    )
