"""Local browser manager implementation for local platform.

This module implements browser management using local Playwright browsers.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any

from browser_use import Browser

from constants import BROWSER_MAX_HEIGHT, BROWSER_MAX_WIDTH
from core.browser.base import BrowserManager
from tools.hitl_intervention import get_browser_context
from utils.browser_use_patches import (
    patch_browser_use_debug_messages,
    patch_browser_use_dom_timeout,
    patch_browser_use_dom_warning,
    patch_browser_use_profile_warning,
    patch_browser_use_screensaver,
    patch_browser_use_timeout,
    patch_websocket_keepalive_timeout,
)

logger = logging.getLogger(__name__)

# Apply Arato custom patches
patch_browser_use_screensaver()
patch_browser_use_debug_messages()
patch_browser_use_timeout()
patch_browser_use_dom_timeout()
patch_browser_use_dom_warning()
patch_browser_use_profile_warning()
patch_websocket_keepalive_timeout()


class LocalBrowserManager(BrowserManager):
    """Browser manager for local Playwright browsers."""

    def __init__(self, browser_type: str = "chromium"):
        """Initialize local browser manager.

        Args:
            browser_type: Browser type (chromium, firefox, webkit)
        """
        self.browser_type = browser_type
        self._pending_storage_save: dict[str, Any] | None = None

    async def _async_input_wait(self) -> None:
        """Wait for user input without blocking the event loop.

        This allows other asyncio tasks (like other ChatRunners) to continue
        while this agent waits for human intervention.
        """
        loop = asyncio.get_event_loop()
        # Run input() in a thread pool to avoid blocking the event loop
        await loop.run_in_executor(None, self._blocking_input)

    def _blocking_input(self) -> None:
        """Blocking input call - runs in thread pool."""
        try:
            sys.stdin.readline()
        except (KeyboardInterrupt, EOFError):
            pass

    @asynccontextmanager
    async def create_browser(self, **kwargs: Any) -> AsyncIterator[Browser]:
        """Create local Playwright browser instance.

        Args:
            **kwargs: Browser configuration (passed to Browser())

        Yields:
            Browser instance
        """
        logger.info(f"Creating local {self.browser_type} browser")
        browser = Browser(**kwargs)
        try:
            yield browser
        finally:
            logger.info("Closing local browser")
            await browser.kill()

    def setup_browser_kwargs(
        self,
        headless: bool = False,
        disable_security: bool = False,
        record_video_dir: str | None = None,
        record_har_path: str | None = None,
        record_har_content: str | None = None,
        storage_state: str | None = None,
        permissions: list[str] | None = None,
        **extra_kwargs: Any,
    ) -> dict[str, Any]:
        """Prepare browser kwargs for local Playwright browser.

        Args:
            headless: Run browser in headless mode
            disable_security: Disable browser security features
            record_video_dir: Directory to save video recordings
            record_har_path: Path to save HAR file
            record_har_content: HAR content mode
            storage_state: Path to JSON file with saved authentication
            permissions: List of permissions to grant (e.g., ['microphone'])
            **extra_kwargs: Additional configuration

        Returns:
            Browser configuration dict
        """
        browser_kwargs: dict[str, Any] = {
            "headless": headless,
            "window_size": {"width": BROWSER_MAX_WIDTH, "height": BROWSER_MAX_HEIGHT},
        }

        if disable_security:
            browser_kwargs["disable_security"] = disable_security

        if record_video_dir:
            browser_kwargs["record_video_dir"] = record_video_dir

        if record_har_path:
            browser_kwargs["record_har_path"] = record_har_path
            if record_har_content:
                browser_kwargs["record_har_content"] = record_har_content

        if storage_state:
            # Verify file exists before passing to Playwright
            from pathlib import Path

            storage_path = Path(storage_state)
            if not storage_path.exists():
                logger.error(
                    f"❌ storage_state file not found: {storage_state}\n"
                    f"   💡 Tip: Run 'python scripts/save_auth_state.py --url <URL> --output {storage_state}' first"
                )
                raise FileNotFoundError(
                    f"storage_state file not found: {storage_state}. "
                    f"Create it using: python scripts/save_auth_state.py --url <URL> --output {storage_state}"
                )

            browser_kwargs["storage_state"] = storage_state
            logger.info(
                f"♻️  Loading authentication from storage_state: {storage_state}"
            )

        browser_kwargs.update(extra_kwargs)

        # Apply permissions directly to browser_kwargs
        if permissions:
            browser_kwargs["permissions"] = permissions
            logger.info(f"🎤 Granting permissions: {permissions}")

        return browser_kwargs

    async def get_current_url(self) -> str | None:
        """Get current URL from browser.

        For local platform, retrieve URL from the browser context.
        Also triggers deferred storage_state save after HITL if pending.

        Returns:
            Current URL or None if browser not available
        """
        # Check if we have a pending storage_state save (after HITL)
        if self._pending_storage_save:
            logger.info("💾 Triggering deferred storage_state save after HITL...")
            from agents.chat_runner import ChatRunner

            target_url = ChatRunner._current_target_url
            browser = get_browser_context()
            if target_url and browser:
                await self._save_storage_state_with_browser(
                    browser=browser,
                    target_url=target_url,
                    intervention_type=self._pending_storage_save["intervention_type"],
                )
            self._pending_storage_save = None

        try:
            browser = get_browser_context()
            if browser and hasattr(browser, "context"):
                context = browser.context
                if context and hasattr(context, "pages") and context.pages:
                    # Get the active page from the context
                    page = context.pages[0]  # type: ignore[index]  # Use first/active page
                    url: str = page.url
                    return url
            return None
        except Exception as e:
            logger.warning(f"Failed to get current URL: {e}")
            return None

    async def request_intervention(
        self,
        reason: str,
        intervention_type: str = "custom",
        session_id: str | None = None,
        timeout_seconds: int | None = None,
        url_before: str | None = None,
        screenshot_url: str | None = None,
    ) -> str:
        """Request human intervention for local platform.

        Local browsers are visible and can be controlled directly,
        so HITL interventions are not necessary. This method logs a
        warning but doesn't block execution by default.

        Optional: Set environment variable LOCAL_HITL_INTERACTIVE=true
        to enable interactive CLI mode that pauses and waits for user confirmation.

        Args:
            reason: Why intervention is needed
            intervention_type: Type of intervention required
            session_id: Browser session ID (unused)
            timeout_seconds: How long to wait (unused)
            url_before: URL before intervention (for tracking)
            screenshot_url: URL/path to screenshot of the page (unused in local)

        Returns:
            Intervention ID (UUID if interactive mode, empty string otherwise)
        """
        intervention_id = str(uuid.uuid4())
        timestamp = datetime.now(UTC).isoformat()

        logger.warning(
            f"🤚 HITL intervention requested in local mode: {reason} "
            f"(type={intervention_type}, id={intervention_id})"
        )
        logger.info("ℹ️  In local mode, the browser is visible on your screen.")
        logger.info(
            "ℹ️  You can interact with the browser directly to complete the task."
        )

        # Interactive CLI mode - enabled by default to pause agent execution
        # Set LOCAL_HITL_INTERACTIVE=false to disable pausing (for automated tests)
        interactive_mode = os.getenv("LOCAL_HITL_INTERACTIVE", "true").lower() == "true"

        if interactive_mode:
            logger.info("")
            logger.info("=" * 70)
            logger.info("🛑 AGENT PAUSED - Human Intervention Required")
            logger.info("=" * 70)
            logger.info(f"Reason: {reason}")
            logger.info(f"Type: {intervention_type}")
            logger.info(f"Intervention ID: {intervention_id}")
            logger.info(f"Timestamp: {timestamp}")
            if url_before:
                logger.info(f"URL: {url_before}")
            logger.info("")
            logger.info(
                "Please complete the required action in the visible browser window,"
            )
            logger.info("then press Enter to resume THIS agent...")
            logger.info("(Other agents will continue running in parallel)")
            logger.info("=" * 70)

            try:
                # Use async input to avoid blocking the event loop
                # This allows other ChatRunners to continue while waiting
                await self._async_input_wait()
                logger.info("✓ User confirmed intervention complete - resuming agent")
                logger.info(
                    "ℹ️  storage_state will be saved after next agent action (allows OAuth cookies to propagate)"
                )

                # Set flag to save storage_state after next browser action
                # This gives time for OAuth popup cookies to propagate to main context
                self._pending_storage_save = {
                    "intervention_type": intervention_type,
                }
            except (KeyboardInterrupt, EOFError):
                logger.warning("⚠️  Intervention interrupted - resuming agent anyway")

            return intervention_id
        else:
            logger.warning(
                "⚠️  LOCAL_HITL_INTERACTIVE=false - Agent will continue without waiting!"
            )
            logger.info(
                "💡 Tip: Set LOCAL_HITL_INTERACTIVE=true (default) to enable CLI pause/resume mode"
            )
            # Return empty string to signal no intervention tracking needed
            return ""

    async def _save_storage_state_with_browser(
        self,
        browser: Any,
        target_url: str,
        intervention_type: str = "custom",
    ) -> None:
        """Save browser storage state after HITL intervention completion.

        Creates a domain-specific auth file in auth_states/ directory.

        Args:
            browser: Browser instance from browser-use
            target_url: Target URL from the invocation payload (used to extract domain)
            intervention_type: Type of intervention (e.g., 'login', 'captcha')
        """
        logger.info(
            f"💾 Saving storage_state after intervention: url={target_url}, type={intervention_type}"
        )
        try:
            from pathlib import Path
            from urllib.parse import urlparse

            if not browser:
                logger.warning("⚠️  No browser instance provided")
                return

            # Extract domain from target_url
            parsed = urlparse(target_url)
            domain = parsed.netloc or parsed.path.split("/")[0]
            if not domain:
                logger.warning(f"Could not extract domain from URL: {target_url}")
                return

            # Create auth_states directory
            auth_dir = Path("auth_states")
            auth_dir.mkdir(exist_ok=True)

            # Create filename: auth_<domain>.json
            safe_domain = domain.replace(":", "_").replace("/", "_")
            output_path = auth_dir / f"auth_{safe_domain}.json"

            # Save storage state using browser-use's export_storage_state() method
            logger.info(f"💾 Saving authentication state to: {output_path}")

            # Use browser-use's export_storage_state method
            if hasattr(browser, "export_storage_state"):
                try:
                    storage_state_data = await browser.export_storage_state()
                    # Write the storage state to file
                    import json

                    with open(output_path, "w") as f:
                        json.dump(storage_state_data, f, indent=2)
                    logger.info(f"✓ Storage state saved successfully: {output_path}")
                    logger.info(
                        f"💡 This file will be automatically used for future sessions on {domain}"
                    )
                except Exception as save_error:
                    logger.error(
                        f"❌ Failed to export storage_state: {save_error}",
                        exc_info=True,
                    )
            else:
                logger.warning(
                    f"Browser does not have export_storage_state method: {type(browser)}"
                )

        except Exception as e:
            logger.error(
                f"Failed to save storage_state after intervention: {e}", exc_info=True
            )

    # Note: capture_screenshot() inherited from BrowserManager base class

    async def check_intervention_state(self, intervention_id: str) -> dict[str, Any]:
        """Check intervention state for local platform.

        In non-interactive mode, always returns completed state.
        In interactive mode (LOCAL_HITL_INTERACTIVE=true), checks for
        completion signal file.

        Args:
            intervention_id: Intervention ID to check

        Returns:
            Dictionary with intervention state
        """
        if not intervention_id:
            # No intervention ID means non-interactive mode - always completed
            logger.debug(
                "HITL state check in local mode (non-interactive - always completed)"
            )
            return {"state": "completed", "intervention_id": ""}

        interactive_mode = (
            os.getenv("LOCAL_HITL_INTERACTIVE", "false").lower() == "true"
        )

        if interactive_mode:
            # Check for completion signal file (optional filesystem-based tracking)
            from pathlib import Path

            signal_dir = Path.home() / ".arato" / "hitl_signals"
            signal_file = signal_dir / f"{intervention_id}.complete"

            if signal_file.exists():
                logger.debug(
                    f"HITL intervention {intervention_id} completed (signal file found)"
                )
                # Clean up signal file
                try:
                    signal_file.unlink()
                except Exception as e:
                    logger.warning(f"Failed to remove signal file: {e}")

                return {
                    "state": "completed",
                    "intervention_id": intervention_id,
                    "completed_at": datetime.now(UTC).isoformat(),
                }
            else:
                logger.debug(f"HITL intervention {intervention_id} still waiting")
                return {
                    "state": "waiting",
                    "intervention_id": intervention_id,
                }
        else:
            # Non-interactive mode - always completed
            logger.debug(
                "HITL state check in local mode (non-interactive - always completed)"
            )
            return {"state": "completed", "intervention_id": intervention_id}

    async def wait_for_intervention_completion(
        self,
        intervention_id: str,
        timeout_seconds: int | None = None,
        poll_interval_seconds: int = 3,
    ) -> dict[str, Any]:
        """Wait for intervention completion for local platform.

        In non-interactive mode, returns immediately.
        In interactive mode (LOCAL_HITL_INTERACTIVE=true), the intervention
        was already completed in request_intervention() via input() call,
        so this also returns immediately.

        Args:
            intervention_id: Intervention ID to wait for
            timeout_seconds: Maximum time to wait (used for filesystem polling if needed)
            poll_interval_seconds: Poll interval (for future filesystem-based polling)

        Returns:
            Dictionary with intervention state (always completed for local)
        """
        if not intervention_id:
            # No intervention ID means non-interactive mode
            logger.debug(
                "HITL wait in local mode (non-interactive - returns immediately)"
            )
            return {"state": "completed", "intervention_id": ""}

        interactive_mode = (
            os.getenv("LOCAL_HITL_INTERACTIVE", "false").lower() == "true"
        )

        if interactive_mode:
            # In interactive mode, the user already pressed Enter in request_intervention()
            # So we can return completed immediately
            logger.debug(
                f"HITL wait in local mode (interactive - user already confirmed): {intervention_id}"
            )
            return {
                "state": "completed",
                "intervention_id": intervention_id,
                "completed_at": datetime.now(UTC).isoformat(),
            }
        else:
            # Non-interactive mode
            logger.debug(
                "HITL wait in local mode (non-interactive - returns immediately)"
            )
            return {"state": "completed", "intervention_id": intervention_id}

    async def cancel_intervention(
        self,
        intervention_id: str,
        reason: str | None = None,
    ) -> bool:
        """Cancel a pending intervention (no-op for local platform).

        Local platform doesn't support cancellation since interventions are
        either instant (non-interactive) or already handled (interactive).

        Args:
            intervention_id: The intervention ID to cancel
            reason: Optional reason for cancellation

        Returns:
            False (cancellation not supported for local platform)
        """
        logger.info(
            f"Intervention cancellation requested for {intervention_id} "
            f"(not supported in local mode)"
            + (f" - reason: {reason}" if reason else "")
        )
        return False


__all__ = ["LocalBrowserManager"]
