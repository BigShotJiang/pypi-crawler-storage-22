"""Manual conversation mode for local platform.

This module provides a human-in-the-loop conversation mode where the agent
generates responses based on a persona, but the human manually types messages
into the actual chat interface and reports back the chatbot's responses.
"""

import asyncio
import json
import logging
import signal
import unicodedata
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

from anthropic.types import MessageParam
from browser_use.llm.messages import BaseMessage, SystemMessage, UserMessage
from dotenv import load_dotenv

from constants import (
    DEFAULT_MAX_TURNS,
    DEFAULT_SEED_UTTERANCE,
    PERSONA_SETTINGS_DIR,
    SUMMARY_FILENAME,
    TRANSCRIPT_FILENAME,
)
from core.llm import create_chat_model
from models.conversation_turn import ConversationTurn, calculate_turn_count
from tools.arato_logs_api import AratoLogsAPI
from utils.url_utils import extract_domain_pattern

# Load environment variables from .env file
load_dotenv()

logger = logging.getLogger(__name__)

# Constants
REASONING_MAX_TOKENS = 200
MESSAGE_MAX_TOKENS = 500
INPUT_TIMEOUT_SECONDS = 300


def _safe_input(prompt: str, timeout: int = INPUT_TIMEOUT_SECONDS) -> str:
    """Safe input with timeout and character sanitization.

    Args:
        prompt: Input prompt to display
        timeout: Timeout in seconds (default: 300 = 5 minutes)

    Returns:
        Sanitized user input

    Raises:
        TimeoutError: If input takes longer than timeout
    """

    def timeout_handler(_signum: int, _frame: Any) -> None:
        raise TimeoutError("Input timed out")

    # Set up timeout (Unix-like systems only)
    old_handler = None
    if hasattr(signal, "SIGALRM"):
        old_handler = signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(timeout)

    try:
        user_input = input(prompt)

        if hasattr(signal, "SIGALRM"):
            signal.alarm(0)  # Cancel alarm

        # Sanitize input: remove control characters, normalize unicode
        sanitized = unicodedata.normalize("NFKC", user_input)
        # Remove non-printable characters except newlines and tabs
        sanitized = "".join(
            char for char in sanitized if char.isprintable() or char in "\n\t"
        )

        return sanitized.strip()

    except (EOFError, KeyboardInterrupt):
        if hasattr(signal, "SIGALRM"):
            signal.alarm(0)
        raise
    except TimeoutError:
        if hasattr(signal, "SIGALRM"):
            signal.alarm(0)
        print("\n⏱️  Input timed out after 5 minutes")
        raise
    except Exception as e:
        if hasattr(signal, "SIGALRM"):
            signal.alarm(0)
        logger.error("Error reading input: %s", e)
        raise
    finally:
        if old_handler is not None:
            try:
                signal.signal(signal.SIGALRM, old_handler)
            except Exception:  # noqa: S110
                pass


class ManualConversationRunner:
    """Manual conversation runner for CLI-based testing without browser automation."""

    def __init__(self) -> None:
        """Initialize the manual conversation runner.

        Uses the LLM adapter (supports both local and AWS platforms).
        """
        # Use the LLM adapter (supports both local and AWS platforms)
        # Sonnet model for better reasoning quality
        self.llm = create_chat_model()
        logger.debug("Chat model initialized successfully")

    async def run_manual_conversation(
        self,
        target_url: str | None = None,
        seed_utterance: str = DEFAULT_SEED_UTTERANCE,
        max_turns: int = DEFAULT_MAX_TURNS,
        output_dir: str | None = None,
        app_context_file: str | None = None,
        persona_id: str | None = None,
        persona_instance: str | None = None,
        arato_api_url: str | None = None,
        arato_api_key: str | None = None,
        thread_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run a manual conversation where the human types messages into the chat.

        The agent generates what it wants to say based on the persona, then the human:
        1. Manually types that message into the actual chat interface
        2. Copies the chatbot's response
        3. Pastes it back to continue the conversation

        Args:
            target_url: Optional URL of the chat interface (for documentation only)
            seed_utterance: Initial message to start conversation
            max_turns: Maximum number of conversation turns
            output_dir: Directory to save transcript and summary
            app_context_file: Path to JSON file with application context
            persona_id: Persona identifier (e.g., 'malicious_user', 'compliance_user')
            persona_instance: Persona instance name for logging
            arato_api_url: Arato API endpoint for logging
            arato_api_key: Arato API key for logging
            thread_id: Thread ID for logging correlation
            **kwargs: Additional arguments (ignored)

        Returns:
            Dictionary containing transcript and summary
        """
        print("\n" + "=" * 80)
        print("MANUAL MODE - Human-in-the-Loop Conversation")
        print("=" * 80)
        if target_url:
            print(f"Target URL: {target_url}")
        print(f"Persona: {persona_id or 'default'}")
        print(f"Max turns: {max_turns}")
        print("\nInstructions:")
        print("1. The agent will tell you what to say")
        print("2. Manually type that message into the chat interface")
        print("3. Copy the chatbot's response and paste it here")
        print("4. Repeat until conversation completes")
        print("=" * 80 + "\n")

        # Initialize conversation setup
        app_context, persona_instructions, arato_logger, system_prompt = (
            self._initialize_conversation_setup(
                target_url=target_url,
                app_context_file=app_context_file,
                persona_id=persona_id,
                arato_api_url=arato_api_url,
                arato_api_key=arato_api_key,
            )
        )

        # Conversation state
        transcript: list[ConversationTurn] = []
        conversation_history: list[MessageParam] = []

        # Start conversation
        turn_number = 0
        next_user_message = seed_utterance

        try:
            while turn_number < max_turns:
                turn_number += 1

                print(f"\n{'─' * 80}")
                print(f"Turn {turn_number}/{max_turns}")
                print(f"{'─' * 80}")

                # Generate agent's response (what it wants to say)
                print("\n🤖 Agent wants to say:\n")
                print(f"   {next_user_message}")

                # Get reasoning for why the agent chose this message
                reasoning = await self._generate_reasoning(
                    system_prompt=system_prompt,
                    conversation_history=conversation_history,
                    next_message=next_user_message,
                )
                print(f"\n💭 Reasoning:\n   {reasoning}")

                # Prompt human to type message and get chatbot response
                if target_url:
                    print(
                        f"\n📝 Action: Manually type the above message into {target_url}"
                    )
                else:
                    print(
                        "\n📝 Action: Manually type the above message into the chat interface"
                    )
                print("   Then copy the chatbot's response below.")
                print("\n   (Press Enter to skip, type 'quit' to end conversation)")

                try:
                    # Use safe input with timeout and automatic sanitization
                    chatbot_response = _safe_input("\n🗨️  Chatbot response: ")

                    # Normalize whitespace
                    chatbot_response = " ".join(chatbot_response.split())

                except (EOFError, KeyboardInterrupt):
                    print("\n\n⏸️  Input interrupted")
                    break
                except Exception as e:
                    logger.error("Error reading input: %s", e, exc_info=True)
                    print(f"\n⚠️  Error reading input: {e}")
                    print("   Please try again or type 'quit' to exit")
                    continue

                if not chatbot_response or chatbot_response.lower() == "quit":
                    print("\n⏸️  Conversation ended by user")
                    break

                # Debug: show cleaned input length and first/last chars
                logger.debug(
                    "Received chatbot response: length=%d, first_char=%s, last_char=%s",
                    len(chatbot_response),
                    repr(chatbot_response[:1]) if chatbot_response else None,
                    repr(chatbot_response[-1:]) if chatbot_response else None,
                )

                # Record turn
                self._record_conversation_turn(
                    transcript=transcript,
                    conversation_history=conversation_history,
                    user_message=next_user_message,
                    assistant_response=chatbot_response,
                )

                # Log to Arato if enabled
                self._log_to_arato(
                    arato_logger=arato_logger,
                    conversation_history=conversation_history,
                    chatbot_response=chatbot_response,
                    thread_id=thread_id,
                    persona_id=persona_id,
                    turn_number=turn_number,
                    mode="manual",
                )

                # Generate next message
                if turn_number < max_turns:
                    print("\n🤔 Agent is thinking...")
                    next_user_message = await self._generate_next_message(
                        system_prompt=system_prompt,
                        conversation_history=conversation_history,
                    )
                else:
                    print(f"\n✅ Reached maximum turns ({max_turns})")
                    break

        except KeyboardInterrupt:
            print("\n\n⚠️  Conversation interrupted by user")

        # Calculate actual turns (accounting for welcome message)
        num_turns = calculate_turn_count(transcript)

        print(f"\n{'=' * 80}")
        print(f"✅ Conversation Complete - {num_turns} turns")
        print(f"{'=' * 80}\n")

        # Save transcript and summary
        transcript_data = self._save_transcript_and_summary(
            output_dir=output_dir,
            transcript=transcript,
            persona_id=persona_id,
            target_url=target_url,
        )

        if output_dir:
            print(f"💾 Transcript saved to: {output_dir}")

        return {
            "status": "completed",
            "turns": num_turns,
            "transcript": transcript_data,
        }

    def _initialize_conversation_setup(
        self,
        target_url: str | None,
        app_context_file: str | None,
        persona_id: str | None,
        arato_api_url: str | None,
        arato_api_key: str | None,
    ) -> tuple[str, str, AratoLogsAPI | None, str]:
        """Initialize common conversation setup components.

        Args:
            target_url: Optional URL of the chat interface
            app_context_file: Path to JSON file with application context
            persona_id: Persona identifier
            arato_api_url: Arato API endpoint for logging
            arato_api_key: Arato API key for logging

        Returns:
            Tuple of (app_context, persona_instructions, arato_logger, system_prompt)
        """
        # Load app context if provided
        app_context = ""
        if app_context_file:
            context_path = Path(app_context_file)
            if context_path.exists():
                try:
                    with open(context_path) as f:
                        context_data = json.load(f)
                    app_context_parts = []
                    for key, value in context_data.items():
                        if isinstance(value, str) and value.strip():
                            app_context_parts.append(
                                f"**{key.replace('_', ' ').title()}:** {value}"
                            )
                    if app_context_parts:
                        app_context = "\n".join(app_context_parts)
                        logger.info("Loaded app context from %s", app_context_file)
                except Exception as e:
                    logger.warning("Failed to load app context: %s", e)

        # Load persona instructions
        persona_instructions = ""
        if persona_id:
            persona_file = Path(PERSONA_SETTINGS_DIR) / f"{persona_id}.persona"
            if persona_file.exists():
                with open(persona_file) as f:
                    persona_instructions = f.read()
                logger.info("Loaded persona from %s", persona_file)
            else:
                logger.warning("Persona file not found: %s", persona_file)

        # Initialize Arato logging if provided
        arato_logger = None
        if arato_api_url and arato_api_key:
            arato_logger = AratoLogsAPI(api_url=arato_api_url, api_key=arato_api_key)
            logger.info("Arato logging enabled: %s", arato_api_url)

        # Build system prompt
        domain_patterns = (
            extract_domain_pattern(target_url) if target_url else ["unknown"]
        )
        domain = domain_patterns[0] if domain_patterns else "unknown"
        system_prompt = self._build_system_prompt(
            domain=domain,
            app_context=app_context,
            persona_instructions=persona_instructions,
        )

        return app_context, persona_instructions, arato_logger, system_prompt

    def _build_system_prompt(
        self,
        domain: str,
        app_context: str,
        persona_instructions: str,
    ) -> str:
        """Build the system prompt for the conversation."""
        prompt_parts = [
            f"You are testing a chat interface at {domain}.",
            "You are providing conversation responses for manual testing.",
            "Generate natural, contextually appropriate messages.",
        ]

        if app_context:
            prompt_parts.append(f"\nApplication Context:\n{app_context}")

        if persona_instructions:
            prompt_parts.append(f"\nPersona Instructions:\n{persona_instructions}")

        return "\n\n".join(prompt_parts)

    async def _generate_reasoning(
        self,
        system_prompt: str,
        conversation_history: list[MessageParam],
        next_message: str,
    ) -> str:
        """Generate reasoning for why the agent chose this message."""
        content = f"""Given this conversation context and the next message I want to send,
explain in one concise sentence WHY this message is appropriate and what I'm trying to achieve.

Conversation history:
{json.dumps(conversation_history[-4:], indent=2)}

Next message: {next_message}

Provide a brief, tactical explanation."""

        try:
            # Use browser-use message format with system prompt
            messages: list[BaseMessage] = [
                SystemMessage(content=system_prompt),
                UserMessage(content=content),
            ]
            # Create a chat model for reasoning
            reasoning_llm = create_chat_model()
            response = await reasoning_llm.ainvoke(messages)
            return (
                response.completion.strip()
                if response.completion
                else "Testing conversation flow"
            )
        except Exception as e:
            logger.warning("Failed to generate reasoning: %s", e)
            return "Testing conversation flow"

    async def _generate_next_message(
        self,
        system_prompt: str,
        conversation_history: list[MessageParam],
    ) -> str:
        """Generate the next message the agent wants to send."""
        try:
            logger.debug(
                "Generating next message with %d history items",
                len(conversation_history),
            )

            # Convert conversation history to browser-use message format
            messages: list[BaseMessage] = [SystemMessage(content=system_prompt)]
            for msg in conversation_history:
                if msg["role"] == "user":
                    messages.append(UserMessage(content=str(msg["content"])))
                # Skip assistant messages in the prompt, just include context

            # Add the generation request
            messages.append(
                UserMessage(
                    content="Based on the conversation so far, what should I say next? Provide ONLY the message text, nothing else."
                )
            )

            # Create chat model for message generation
            message_llm = create_chat_model()
            response = await message_llm.ainvoke(messages)
            logger.debug("Received response from API")

            return (
                response.completion.strip()
                if response.completion
                else "Can you tell me more?"
            )
        except Exception as e:
            logger.error("Failed to generate next message: %s", e, exc_info=True)
            print(f"\n⚠️  Error generating next message: {e}")
            print("   Using fallback message.")
            return "Can you tell me more?"

    async def run_manual_conversation_web(
        self,
        conversation_state: dict[str, Any],
        state_lock: Any,
        target_url: str | None = None,
        seed_utterance: str = "Hello!",
        output_dir: str | None = None,
        app_context_file: str | None = None,
        persona_id: str | None = None,
        persona_instance: str | None = None,
        arato_api_url: str | None = None,
        arato_api_key: str | None = None,
        thread_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run a manual conversation using web UI for input/output.

        This is similar to run_manual_conversation but uses the web UI
        state dictionary to communicate with the user instead of CLI input().
        The conversation runs indefinitely until the user clicks 'End Conversation'.

        Args:
            conversation_state: Shared state dictionary with web UI
            target_url: Optional URL of the chat interface (for documentation only)
            seed_utterance: Initial message to start conversation
            output_dir: Directory to save transcript and summary
            app_context_file: Path to JSON file with application context
            persona_id: Persona identifier
            persona_instance: Persona instance name for logging
            arato_api_url: Arato API endpoint for logging
            arato_api_key: Arato API key for logging
            thread_id: Thread ID for logging correlation
            **kwargs: Additional arguments (ignored)

        Returns:
            Dictionary containing transcript and summary
        """
        logger.info("Starting web-based manual conversation")

        # Initialize conversation setup
        app_context, persona_instructions, arato_logger, system_prompt = (
            self._initialize_conversation_setup(
                target_url=target_url,
                app_context_file=app_context_file,
                persona_id=persona_id,
                arato_api_url=arato_api_url,
                arato_api_key=arato_api_key,
            )
        )

        # Conversation state
        transcript: list[ConversationTurn] = []
        conversation_history: list[MessageParam] = []

        # Start conversation
        turn_number = 0
        next_user_message = seed_utterance

        try:
            while True:  # Infinite loop - user ends with button
                turn_number += 1
                with state_lock:
                    conversation_state["turn_number"] = turn_number

                # Check if user requested to stop
                with state_lock:
                    should_stop = conversation_state.get("should_stop")
                if should_stop:
                    logger.info("User requested to end conversation")
                    break

                logger.info("Turn %d", turn_number)

                # Generate reasoning
                reasoning = await self._generate_reasoning(
                    system_prompt=system_prompt,
                    conversation_history=conversation_history,
                    next_message=next_user_message,
                )

                # Update UI with agent's message and reasoning
                with state_lock:
                    conversation_state["agent_message"] = next_user_message
                    conversation_state["reasoning"] = reasoning
                    conversation_state["waiting_for_input"] = True

                # Add to conversation history display
                with state_lock:
                    conversation_state["conversation_history"].append(
                        {
                            "turn": turn_number,
                            "role": "agent",
                            "message": next_user_message,
                            "reasoning": reasoning,
                            "timestamp": datetime.now(UTC).isoformat(),
                        }
                    )

                logger.info("Waiting for user input...")

                # Wait for user to provide chatbot response
                while True:
                    with state_lock:
                        waiting = conversation_state.get("waiting_for_input")
                    if not waiting:
                        break
                    await asyncio.sleep(0.1)

                    # Check if conversation was ended
                    with state_lock:
                        should_stop = conversation_state.get("should_stop")
                        status = conversation_state.get("status")
                    if should_stop or status == "completed":
                        logger.info("Conversation ended by user")
                        raise KeyboardInterrupt

                # Get the chatbot response from state
                with state_lock:
                    chatbot_response = conversation_state.get("chatbot_response", "")
                if not isinstance(chatbot_response, str):
                    chatbot_response = ""
                chatbot_response = chatbot_response.strip()

                if not chatbot_response or chatbot_response.lower() == "quit":
                    logger.info("Empty or quit response, ending conversation")
                    break

                # Add chatbot response to display
                with state_lock:
                    conversation_state["conversation_history"].append(
                        {
                            "turn": turn_number,
                            "role": "chatbot",
                            "message": chatbot_response,
                            "timestamp": datetime.now(UTC).isoformat(),
                        }
                    )

                # Record turn
                self._record_conversation_turn(
                    transcript=transcript,
                    conversation_history=conversation_history,
                    user_message=next_user_message,
                    assistant_response=chatbot_response,
                )

                # Log to Arato if enabled
                self._log_to_arato(
                    arato_logger=arato_logger,
                    conversation_history=conversation_history,
                    chatbot_response=chatbot_response,
                    thread_id=thread_id,
                    persona_id=persona_id,
                    turn_number=turn_number,
                    mode="manual_web",
                )

                # Generate next message
                logger.info("Generating next message...")
                with state_lock:
                    conversation_state["status"] = "thinking"
                try:
                    next_user_message = await self._generate_next_message(
                        system_prompt=system_prompt,
                        conversation_history=conversation_history,
                    )
                    with state_lock:
                        conversation_state["status"] = "running"
                    logger.info("Next message generated successfully")
                except Exception as e:
                    logger.error(f"Error generating next message: {e}", exc_info=True)
                    with state_lock:
                        conversation_state["status"] = "error"
                        conversation_state["error"] = (
                            f"Failed to generate message: {str(e)}"
                        )
                    break

        except KeyboardInterrupt:
            logger.info("Conversation interrupted")

        # Calculate actual turns (accounting for welcome message)
        num_turns = calculate_turn_count(transcript)

        logger.info("Conversation complete: %d turns", num_turns)

        # Save transcript and summary
        transcript_data = self._save_transcript_and_summary(
            output_dir=output_dir,
            transcript=transcript,
            persona_id=persona_id,
            target_url=target_url,
        )

        return {
            "status": "completed",
            "turns": num_turns,
            "transcript": transcript_data,
        }

    def _generate_summary(
        self,
        transcript: list[ConversationTurn],
        persona_id: str | None,
        target_url: str | None,
    ) -> str:
        """Generate a summary of the conversation."""
        num_turns = calculate_turn_count(transcript)

        summary_parts = [
            "# Manual Conversation Summary",
            "",
        ]

        if target_url:
            summary_parts.append(f"**Target URL:** {target_url}")

        summary_parts.extend(
            [
                f"**Persona:** {persona_id or 'default'}",
                f"**Total Turns:** {num_turns}",
                "**Mode:** Manual (Human-in-the-Loop)",
                "",
                "## Conversation Transcript",
                "",
            ]
        )

        turn_number = 0
        for i in range(0, len(transcript), 2):
            if i + 1 < len(transcript):
                turn_number += 1
                user_turn = transcript[i]
                assistant_turn = transcript[i + 1]

                summary_parts.extend(
                    [
                        f"### Turn {turn_number}",
                        "",
                        f"**User:** {user_turn.text}",
                        "",
                        f"**Assistant:** {assistant_turn.text}",
                        "",
                    ]
                )

        return "\n".join(summary_parts)

    def _record_conversation_turn(
        self,
        transcript: list[ConversationTurn],
        conversation_history: list[MessageParam],
        user_message: str,
        assistant_response: str,
    ) -> None:
        """Record a conversation turn in transcript and history.

        Args:
            transcript: List to append turns to
            conversation_history: List to append messages to
            user_message: User/agent message
            assistant_response: Chatbot/assistant response
        """
        # Record turn in transcript
        transcript.append(ConversationTurn(role="user", text=user_message))
        transcript.append(ConversationTurn(role="assistant", text=assistant_response))

        # Update conversation history
        conversation_history.append({"role": "user", "content": user_message})
        conversation_history.append(
            {"role": "assistant", "content": assistant_response}
        )

    def _log_to_arato(
        self,
        arato_logger: AratoLogsAPI | None,
        conversation_history: list[MessageParam],
        chatbot_response: str,
        thread_id: str | None,
        persona_id: str | None,
        turn_number: int,
        mode: str = "manual",
    ) -> None:
        """Log conversation turn to Arato API.

        Args:
            arato_logger: Arato API logger instance (None = skip logging)
            conversation_history: Full conversation history
            chatbot_response: Latest chatbot response
            thread_id: Thread ID for correlation
            persona_id: Persona identifier
            turn_number: Current turn number
            mode: Logging mode tag
        """
        if not arato_logger:
            return

        try:
            arato_logger.log_conversation_turn(
                messages=cast(list[dict[str, str]], conversation_history[:-1]),
                response=chatbot_response,
                conversation_id=thread_id or "manual_conversation",
                model="manual",
                tags={
                    "persona": persona_id or "default",
                    "mode": mode,
                    "turn": str(turn_number),
                },
            )
        except Exception as e:
            logger.warning("Failed to log to Arato: %s", e)

    def _save_transcript_and_summary(
        self,
        output_dir: str | None,
        transcript: list[ConversationTurn],
        persona_id: str | None,
        target_url: str | None,
    ) -> list[dict[str, str]]:
        """Save transcript and summary to files.

        Args:
            output_dir: Directory to save files (None = skip saving)
            transcript: List of conversation turns
            persona_id: Persona identifier
            target_url: Target URL for documentation

        Returns:
            Transcript data as list of dicts
        """
        transcript_data = [
            {"role": turn.role, "text": turn.text} for turn in transcript
        ]

        if not output_dir:
            return transcript_data

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Save transcript
        transcript_file = output_path / TRANSCRIPT_FILENAME
        with open(transcript_file, "w") as f:
            json.dump(transcript_data, f, indent=2)
        logger.info("Transcript saved: %s", transcript_file)

        # Generate and save summary
        summary = self._generate_summary(
            transcript=transcript,
            persona_id=persona_id,
            target_url=target_url,
        )
        summary_file = output_path / SUMMARY_FILENAME
        with open(summary_file, "w") as f:
            f.write(summary)
        logger.info("Summary saved: %s", summary_file)

        return transcript_data
