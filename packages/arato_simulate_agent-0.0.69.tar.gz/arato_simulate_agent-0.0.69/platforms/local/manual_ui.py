"""Web-based UI for manual conversation mode.

A simple Flask app that provides a web interface for manual conversation input/output,
replacing the problematic terminal input() mechanism.
"""

import asyncio
import logging
import threading
from typing import Any

from flask import Flask, Response, jsonify, render_template_string, request
from flask_cors import CORS

from platforms.local.manual_runner import ManualConversationRunner

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
STATUS_IDLE = "idle"
STATUS_RUNNING = "running"
STATUS_THINKING = "thinking"
STATUS_COMPLETED = "completed"
STATUS_ERROR = "error"
POLL_INTERVAL_MS = 500
DEFAULT_PORT = 8083
DEFAULT_HOST = "127.0.0.1"

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": ["http://127.0.0.1:*", "http://localhost:*"]}})

# Global state for the conversation
conversation_state: dict[str, Any] = {
    "runner": None,
    "turn_number": 0,
    "waiting_for_input": False,
    "agent_message": "",
    "reasoning": "",
    "conversation_history": [],
    "status": STATUS_IDLE,
    "error": None,
    "should_stop": False,
}

# Lock for synchronizing access to conversation_state
conversation_state_lock = threading.Lock()

# HTML template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Manual Conversation Mode</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #1a1a1a;
            color: #e0e0e0;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            color: #4fc3f7;
            margin-bottom: 20px;
            font-size: 28px;
        }
        .status-bar {
            background: #2d2d2d;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #4fc3f7;
        }
        .status-item {
            display: inline-block;
            margin-right: 20px;
            font-size: 14px;
        }
        .status-item strong {
            color: #4fc3f7;
        }
        .conversation-box {
            background: #2d2d2d;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            min-height: 200px;
        }
        .turn {
            margin-bottom: 20px;
            padding: 15px;
            background: #3d3d3d;
            border-radius: 6px;
        }
        .turn-header {
            color: #4fc3f7;
            font-weight: bold;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .message {
            margin: 10px 0;
            padding: 10px;
            background: #4d4d4d;
            border-radius: 4px;
        }
        .user-message { border-left: 3px solid #81c784; }
        .assistant-message { border-left: 3px solid #64b5f6; }
        .reasoning {
            margin-top: 10px;
            padding: 10px;
            background: #2d2d2d;
            border-radius: 4px;
            font-style: italic;
            color: #aaa;
            font-size: 14px;
        }
        .input-section {
            background: #2d2d2d;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .input-section h2 {
            color: #4fc3f7;
            margin-bottom: 15px;
            font-size: 20px;
        }
        textarea {
            width: 100%;
            min-height: 120px;
            background: #3d3d3d;
            border: 1px solid #555;
            border-radius: 4px;
            padding: 12px;
            color: #e0e0e0;
            font-size: 14px;
            font-family: inherit;
            resize: vertical;
        }
        textarea:focus {
            outline: none;
            border-color: #4fc3f7;
        }
        .button-group {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        button {
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .btn-primary {
            background: #4fc3f7;
            color: #000;
        }
        .btn-primary:hover:not(:disabled) {
            background: #29b6f6;
        }
        .btn-secondary {
            background: #666;
            color: #fff;
        }
        .btn-secondary:hover:not(:disabled) {
            background: #777;
        }
        .btn-danger {
            background: #e57373;
            color: #000;
        }
        .btn-danger:hover:not(:disabled) {
            background: #ef5350;
        }
        .error {
            background: #d32f2f;
            color: white;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .waiting {
            text-align: center;
            padding: 20px;
            color: #4fc3f7;
            font-size: 16px;
        }
        .hidden { display: none; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤝 Manual Conversation Mode</h1>

        <div class="status-bar">
            <span class="status-item"><strong>Status:</strong> <span id="status">Idle</span></span>
            <span class="status-item"><strong>Turn:</strong> <span id="turn">0</span></span>
        </div>

        <div id="error-box" class="error hidden"></div>

        <div class="input-section" id="input-section">
            <h2>Agent wants to say:</h2>
            <div class="message user-message" id="agent-message">
                Waiting for agent...
            </div>
            <div class="reasoning" id="reasoning">
                No reasoning yet
            </div>

            <h2 style="margin-top: 20px;">Enter chatbot's response:</h2>
            <textarea id="chatbot-response" placeholder="Paste the chatbot's response here..."></textarea>

            <div class="button-group">
                <button class="btn-primary" onclick="submitResponse()" id="submit-btn">Submit Response</button>
                <button class="btn-secondary" onclick="skipTurn()" id="skip-btn">Skip Turn</button>
                <button class="btn-danger" onclick="endConversation()" id="end-btn">End Conversation</button>
            </div>
        </div>

        <div class="waiting hidden" id="waiting-indicator">
            🤔 Agent is thinking...
        </div>

        <div class="conversation-box">
            <h2 style="color: #4fc3f7; margin-bottom: 15px;">Conversation History</h2>
            <div id="conversation-history">
                <p style="color: #888;">No messages yet</p>
            </div>
        </div>
    </div>

    <script>
        let pollInterval = null;

        function updateUI(state) {
            document.getElementById('status').textContent = state.status;
            document.getElementById('turn').textContent = state.turn_number;

            if (state.error) {
                document.getElementById('error-box').textContent = state.error;
                document.getElementById('error-box').classList.remove('hidden');
            } else {
                document.getElementById('error-box').classList.add('hidden');
            }

            if (state.waiting_for_input) {
                document.getElementById('agent-message').textContent = state.agent_message;
                document.getElementById('reasoning').textContent = '💭 ' + state.reasoning;
                document.getElementById('input-section').classList.remove('hidden');
                document.getElementById('waiting-indicator').classList.add('hidden');
                document.getElementById('submit-btn').disabled = false;
                document.getElementById('skip-btn').disabled = false;
                document.getElementById('end-btn').disabled = false;
            } else if (state.status === 'running' || state.status === 'thinking') {
                document.getElementById('input-section').classList.add('hidden');
                document.getElementById('waiting-indicator').classList.remove('hidden');
                // Update waiting message based on status
                const waitingText = state.status === 'thinking' ? '🤔 Agent is thinking...' : '⏳ Processing...';
                document.getElementById('waiting-indicator').textContent = waitingText;
            } else {
                document.getElementById('input-section').classList.add('hidden');
                document.getElementById('waiting-indicator').classList.add('hidden');
            }

            // Update conversation history
            const historyDiv = document.getElementById('conversation-history');
            if (state.conversation_history.length === 0) {
                historyDiv.innerHTML = '<p style="color: #888;">No messages yet</p>';
            } else {
                let html = '';
                let currentTurn = null;
                let turnData = {};

                state.conversation_history.forEach(entry => {
                    if (entry.role === 'agent') {
                        if (currentTurn !== null && turnData.user) {
                            // Close previous turn if incomplete
                            html += `
                                <div class="turn">
                                    <div class="turn-header">Turn ${escapeHtml(String(currentTurn))}</div>
                                    <div class="message user-message">
                                        <strong>Agent:</strong> ${escapeHtml(turnData.user)}
                                    </div>
                                    ${turnData.reasoning ? `<div class="reasoning">💭 ${escapeHtml(turnData.reasoning)}</div>` : ''}
                                </div>
                            `;
                        }
                        // Start new turn
                        currentTurn = entry.turn;
                        turnData = {
                            user: entry.message,
                            reasoning: entry.reasoning || '',
                            assistant: null
                        };
                    } else if (entry.role === 'chatbot' && currentTurn === entry.turn) {
                        turnData.assistant = entry.message;
                        // Complete turn
                        html += `
                            <div class="turn">
                                <div class="turn-header">Turn ${escapeHtml(String(currentTurn))}</div>
                                <div class="message user-message">
                                    <strong>Agent:</strong> ${escapeHtml(turnData.user)}
                                </div>
                                ${turnData.reasoning ? `<div class="reasoning">💭 ${escapeHtml(turnData.reasoning)}</div>` : ''}
                                <div class="message assistant-message">
                                    <strong>Chatbot:</strong> ${escapeHtml(turnData.assistant)}
                                </div>
                            </div>
                        `;
                        currentTurn = null;
                        turnData = {};
                    }
                });

                // Handle incomplete turn
                if (currentTurn !== null && turnData.user) {
                    html += `
                        <div class="turn">
                            <div class="turn-header">Turn ${escapeHtml(String(currentTurn))}</div>
                            <div class="message user-message">
                                <strong>Agent:</strong> ${escapeHtml(turnData.user)}
                            </div>
                            ${turnData.reasoning ? `<div class="reasoning">💭 ${escapeHtml(turnData.reasoning)}</div>` : ''}
                        </div>
                    `;
                }

                historyDiv.innerHTML = html || '<p style="color: #888;">No messages yet</p>';
            }
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function pollState() {
          fetch('/get_state')
                .then(r => r.json())
                .then(updateUI)
                .catch(err => console.error('Poll error:', err));
        }

        function submitResponse() {
            const response = document.getElementById('chatbot-response').value.trim();
            if (!response) {
                alert('Please enter a response');
                return;
            }

            document.getElementById('submit-btn').disabled = true;
            document.getElementById('skip-btn').disabled = true;
            document.getElementById('end-btn').disabled = true;

            fetch('/submit', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({response: response})
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('chatbot-response').value = '';
                    pollState();
                } else {
                    alert('Error: ' + data.error);
                    document.getElementById('submit-btn').disabled = false;
                    document.getElementById('skip-btn').disabled = false;
                    document.getElementById('end-btn').disabled = false;
                }
            })
            .catch(err => {
                alert('Error: ' + err);
                document.getElementById('submit-btn').disabled = false;
                document.getElementById('skip-btn').disabled = false;
                document.getElementById('end-btn').disabled = false;
            });
        }

        function skipTurn() {
            if (confirm('Skip this turn?')) {
                fetch('/skip', {method: 'POST'})
                    .then(r => r.json())
                    .then(pollState);
            }
        }

        function endConversation() {
            if (confirm('End conversation?')) {
                fetch('/end', {method: 'POST'})
                    .then(r => r.json())
                    .then(pollState);
            }
        }

        // Start polling (interval passed from backend)
        pollInterval = setInterval(pollState, {{ poll_interval_ms }});
        pollState();

        // Handle Enter key in textarea (Ctrl+Enter to submit)
        document.getElementById('chatbot-response').addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') {
                submitResponse();
            }
        });
    </script>
</body>
</html>
"""


@app.route("/")
def index() -> str:
    """Serve the main UI."""
    return render_template_string(HTML_TEMPLATE, poll_interval_ms=POLL_INTERVAL_MS)


@app.route("/get_state")
def get_state() -> Response:
    """Get current conversation state."""
    # Return state without the runner object (not JSON serializable)
    with conversation_state_lock:
        state_copy = {k: v for k, v in conversation_state.items() if k != "runner"}
    logger.debug(
        f"Returning state: status={state_copy.get('status')}, waiting={state_copy.get('waiting_for_input')}, turn={state_copy.get('turn_number')}"
    )
    response: Response = jsonify(state_copy)
    return response


@app.route("/submit", methods=["POST"])
def submit_response() -> Any:
    """Submit chatbot response."""
    data = request.json
    if not data or not isinstance(data, dict) or "response" not in data:
        return jsonify({"success": False, "error": "No response provided"})

    if not isinstance(data.get("response"), str):
        return jsonify({"success": False, "error": "Response must be a string"})

    response_text = data["response"].strip()
    if not response_text:
        return jsonify({"success": False, "error": "Empty response"})

    # Store the response and signal the runner
    logger.info(f"Received chatbot response: {response_text[:50]}...")
    _update_conversation_state(
        chatbot_response=response_text,
        waiting_for_input=False,
    )
    logger.info("Updated state: waiting_for_input=False")

    return jsonify({"success": True})


@app.route("/skip", methods=["POST"])
def skip_turn() -> Any:
    """Skip current turn."""
    _update_conversation_state(
        chatbot_response="",
        waiting_for_input=False,
    )
    return jsonify({"success": True})


@app.route("/end", methods=["POST"])
def end_conversation() -> Any:
    """End the conversation."""
    # Signal to stop the conversation loop
    _update_conversation_state(
        should_stop=True,
        chatbot_response="",
        waiting_for_input=False,
        status=STATUS_COMPLETED,
    )
    return jsonify({"success": True})


def _update_conversation_state(**updates: Any) -> None:
    """Update conversation state with thread-safe locking.

    Args:
        **updates: Key-value pairs to update in conversation_state
    """
    with conversation_state_lock:
        conversation_state.update(updates)


def run_conversation_async(
    target_url: str | None = None,
    persona_id: str | None = None,
    session_prefix: str | None = None,
    **kwargs: Any,
) -> None:
    """Run the conversation in a background thread."""

    async def _run() -> None:
        try:
            _update_conversation_state(
                status=STATUS_RUNNING,
                turn_number=0,
            )

            runner = ManualConversationRunner()
            _update_conversation_state(runner=runner)

            # Generate output directory with session prefix if provided
            output_dir = None
            if session_prefix:
                from datetime import datetime

                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_dir = (
                    f"sessions/{session_prefix}_manual_conversation_{timestamp}"
                )
            elif target_url or persona_id:  # Create default session if we have context
                from datetime import datetime

                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_dir = f"sessions/manual_conversation_{timestamp}"

            # Run the conversation with web-based input
            result = await runner.run_manual_conversation_web(
                target_url=target_url,
                persona_id=persona_id,
                output_dir=output_dir,
                conversation_state=conversation_state,
                state_lock=conversation_state_lock,
                **kwargs,
            )

            _update_conversation_state(status=STATUS_COMPLETED)
            logger.info("Conversation completed: %s", result)

        except Exception as e:
            logger.error("Error running conversation: %s", e, exc_info=True)
            _update_conversation_state(
                status=STATUS_ERROR,
                error=str(e),
            )

    # Run async function in thread
    def _thread_run() -> None:
        asyncio.run(_run())

    thread = threading.Thread(target=_thread_run, daemon=True)
    thread.start()


def main() -> None:
    """Main entry point for the web UI."""
    import argparse

    parser = argparse.ArgumentParser(description="Manual conversation web UI")
    parser.add_argument("--target-url", help="Target URL (optional)")
    parser.add_argument("--persona-id", default="nice_user", help="Persona ID")
    parser.add_argument(
        "--session-prefix", help="Session prefix for output directory naming"
    )
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Port to run on")
    parser.add_argument("--host", default=DEFAULT_HOST, help="Host to bind to")

    args = parser.parse_args()

    # Start conversation in background
    run_conversation_async(
        target_url=args.target_url,
        persona_id=args.persona_id,
        session_prefix=args.session_prefix,
    )

    print(f"\n{'=' * 60}")
    print("Manual Conversation Web UI")
    print(f"{'=' * 60}")
    print(f"\n🌐 Open your browser to: http://{args.host}:{args.port}")
    print(f"   Persona: {args.persona_id}")
    if args.target_url:
        print(f"   Target URL: {args.target_url}")
    print("\nPress Ctrl+C to stop\n")

    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
