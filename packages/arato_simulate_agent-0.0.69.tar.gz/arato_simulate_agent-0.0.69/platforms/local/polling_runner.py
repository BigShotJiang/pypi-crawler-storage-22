"""Local platform polling runner."""

import argparse
import asyncio
import logging
import os
import subprocess
import sys
from collections import deque

from core.polling.client import TaskPollingClient
from core.polling.config import PollingConfig
from core.schemas import AgentCommand, TaskPayload
from platforms.local.adapter import LocalPlatformAdapter

logger = logging.getLogger(__name__)


def _ensure_playwright_chromium() -> None:
    """Auto-install Playwright chromium if not already present."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "--dry-run", "chromium"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            logger.info("Installing Playwright chromium browser...")
            subprocess.run(
                [sys.executable, "-m", "playwright", "install", "chromium"],
                check=True,
                timeout=300,
            )
            logger.info("Playwright chromium installed successfully")
    except FileNotFoundError:
        logger.info("Installing Playwright chromium browser...")
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            check=True,
            timeout=300,
        )
        logger.info("Playwright chromium installed successfully")


class LocalPollingRunner:
    """Runs polling loop for local platform with task deduplication."""

    def __init__(self, config: PollingConfig):
        self.config = config
        self.adapter = LocalPlatformAdapter()
        agent_identity = self.adapter.get_agent_identity()
        self.client = TaskPollingClient(
            config.task_endpoint,
            config.api_key,
            agent_name=agent_identity.name or "unknown",
            agent_platform=agent_identity.platform or "local",
        )
        self.running = False

        # Task deduplication
        self.recent_task_hashes: deque[str] = deque(maxlen=100)

    def _get_task_hash(self, task: TaskPayload) -> str:
        """Generate a simple hash for the task for deduplication."""
        hash_key = f"{task.task_id}|{task.target_url}|{task.goal}"
        return str(hash(hash_key))

    def _recreate_client(self) -> None:
        """Recreate the HTTP client after transport/event loop errors."""
        logger.info("Recreating HTTP polling client...")
        agent_identity = self.adapter.get_agent_identity()
        self.client = TaskPollingClient(
            self.config.task_endpoint,
            self.config.api_key,
            agent_name=agent_identity.name or "unknown",
            agent_platform=agent_identity.platform or "local",
        )

    async def start(self) -> None:
        """Start the polling loop."""
        self.running = True

        logger.info("=" * 80)
        logger.info("LOCAL POLLING MODE STARTED")
        logger.info("=" * 80)
        logger.info(f"Task endpoint: {self.config.task_endpoint}")
        logger.info(f"Polling interval: {self.config.polling_interval}s")
        logger.info("=" * 80)

        while self.running:
            try:
                # Poll for task
                logger.debug("Polling for tasks...")
                task = await self.client.poll_task()

                if task:
                    await self._execute_task(task)
                    # Recreate client after each task to avoid stale connections
                    # (pipeline may break underlying httpx transport)
                    self._recreate_client()
                else:
                    logger.debug(
                        f"No tasks available, waiting {self.config.polling_interval}s..."
                    )

            except RuntimeError as e:
                if "Event loop is closed" in str(e):
                    logger.warning(
                        "HTTP transport broken after pipeline, recreating client..."
                    )
                    self._recreate_client()
                else:
                    logger.error(f"Unexpected runtime error: {e}", exc_info=True)

            except Exception as e:
                logger.error(f"Unexpected polling error: {e}", exc_info=True)
                logger.info("Continuing polling after error...")

            # Wait before next poll
            await asyncio.sleep(self.config.polling_interval)

    async def _execute_task(self, task: TaskPayload) -> None:
        """Execute a single task with validation and deduplication."""
        logger.info("▶️  Executing task...")

        # Log task details (already validated by poll_task)
        logger.info(f"   Target URL: {task.target_url}")
        logger.info(f"   Personas: {task.persona_ids}")
        if task.org_id:
            logger.info(f"   Org ID: {task.org_id}")

        # Check for duplicate
        task_hash = self._get_task_hash(task)
        if task_hash in self.recent_task_hashes:
            logger.warning(f"⚠️  Duplicate task detected, skipping: {task_hash[:8]}")
            return

        # Add to recent tasks
        self.recent_task_hashes.append(task_hash)

        try:
            # Mark task as active and check for STOP command
            agent_identity = self.adapter.get_agent_identity()
            command_response = await self.client.mark_active(task, agent_identity)
            logger.info(
                f"   Task marked as ACTIVE, command: {command_response.command}"
            )

            if command_response.command == AgentCommand.STOP:
                logger.warning(
                    f"Received STOP command from API: {command_response.message or 'No message'}. Aborting task."
                )
                return

            # Inject logging config
            task = self.client.inject_logging_config(task)

            # Execute through adapter with task and client for status updates
            result = await self.adapter.run_pipeline(
                target_url=str(task.target_url),
                persona_ids=task.persona_ids.split(",")
                if isinstance(task.persona_ids, str)
                else (task.persona_ids or []),
                seed_utterance=task.seed_utterance,
                max_turns=task.max_turns,
                output_dir=None,  # Not in TaskPayload
                arato_api_url=task.arato_api_url,
                arato_api_key=task.arato_api_key,
                thread_id=task.task_id,
                max_parallel=task.max_parallel,
                org_id=task.org_id,
                goal=task.goal.value,  # Extract goal from TaskGoal enum
                step_timeout=task.step_timeout,
                task=task,
                polling_client=self.client,
            )

            logger.info("✅ Task completed successfully")
            logger.info(f"   Session ID: {result.get('session_id', 'N/A')}")

        except Exception as e:
            logger.error(f"❌ Task execution failed: {e}", exc_info=True)

    async def stop(self) -> None:
        """Stop the polling loop."""
        logger.info("🛑 Stopping polling loop...")
        self.running = False
        await self.client.close()


async def async_main() -> None:
    """Async entry point for local polling mode (env-var config only)."""
    config = PollingConfig.from_env()

    if not config:
        logger.error("Polling mode requires ARATO_API_KEY environment variable")
        logger.error(
            "Set ARATO_API_KEY and optionally ARATO_TASK_ENDPOINT, ARATO_POLLING_INTERVAL"
        )
        return

    runner = LocalPollingRunner(config)

    try:
        await runner.start()
    except KeyboardInterrupt:
        logger.info("Received interrupt signal")
    finally:
        await runner.stop()


def main() -> None:
    """Entry point for arato-simulate-agent CLI and local-poll alias."""
    parser = argparse.ArgumentParser(
        prog="arato-simulate-agent",
        description="Arato Simulate Agent - polls for and executes simulation tasks",
    )
    parser.add_argument(
        "server_url",
        nargs="?",
        help=(
            "Server URL (e.g. https://simulate.arato.dev). "
            "The /api/v1/agent-connect/task suffix is appended automatically."
        ),
    )
    parser.add_argument(
        "--api-key",
        help="Agent API key (default: ARATO_API_KEY env var)",
    )
    parser.add_argument(
        "--polling-interval",
        type=int,
        default=None,
        help="Polling interval in seconds (default: 5)",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Ensure Playwright chromium is installed
    _ensure_playwright_chromium()

    # Build config: CLI args take precedence over env vars
    api_key: str | None = args.api_key or os.getenv("ARATO_API_KEY")
    if not api_key:
        logger.error("API key required: pass --api-key or set ARATO_API_KEY")
        sys.exit(1)

    assert api_key is not None  # narrowing for ty: sys.exit above guarantees this

    if args.server_url:
        task_endpoint = args.server_url.rstrip("/") + "/api/v1/agent-connect/task"
    else:
        task_endpoint = os.getenv(
            "ARATO_TASK_ENDPOINT",
            "http://localhost:3000/api/v1/agent-connect/task",
        )

    polling_interval = args.polling_interval or int(
        os.getenv("ARATO_POLLING_INTERVAL", "5")
    )

    config = PollingConfig(
        task_endpoint=task_endpoint,
        api_key=api_key,
        polling_interval=polling_interval,
    )

    runner = LocalPollingRunner(config)
    try:
        asyncio.run(runner.start())
    except KeyboardInterrupt:
        logger.info("Received interrupt signal")


if __name__ == "__main__":
    main()
