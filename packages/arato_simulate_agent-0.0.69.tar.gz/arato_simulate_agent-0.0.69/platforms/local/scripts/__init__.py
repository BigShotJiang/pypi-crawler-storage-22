"""Local platform scripts."""
