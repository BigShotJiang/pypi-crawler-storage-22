"""CLI commands for local platform execution.

This module contains the manual mode runner for human-in-the-loop
conversations without browser automation.

Note: For test suite execution, use:
  uv run local-invoke <suite_name>   (runs test suite locally)
  uv run agentcore-invoke <suite_name> (runs test suite on AWS AgentCore)
"""

import asyncio
import json
import logging
import sys
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)

# Silence verbose browser-use library logging
logging.getLogger("browser_use").setLevel(logging.WARNING)
logging.getLogger("bubus").setLevel(logging.WARNING)


def manual() -> None:
    """Run the agent in manual mode (human-in-the-loop without browser automation).

    Usage:
        uv run local-manual                    # Run with all defaults
        uv run local-manual '{"persona_id": "malicious_user"}'

    Examples:
        # Simple run with defaults
        uv run local-manual

        # With specific persona
        uv run local-manual '{"persona_id": "malicious_user", "max_turns": 5}'

        # With URL for documentation
        uv run local-manual '{"target_url": "https://example.com", "persona_id": "malicious_user"}'

    Supported parameters (all optional):
        - target_url: Website URL (for documentation only, not used in manual mode)
        - persona_id: Persona ID (e.g., "malicious_user", "nice_user")
        - max_turns: Max conversation turns (default: 10)
        - seed_utterance: Initial message (default: "Hello!")
        - output_dir: Directory for outputs
        - storage_dir: Base storage directory (default: "./local_storage")
        - arato_api_url: Arato API endpoint for logging
        - arato_api_key: Arato API key
        - thread_id: Thread ID for logging correlation
    """
    # Payload is optional - defaults to empty dict
    payload_str = sys.argv[1] if len(sys.argv) >= 2 else "{}"

    try:
        payload = json.loads(payload_str)
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON payload: {e}")
        print('Expected JSON format, e.g., \'{"persona_id": "malicious_user"}\'')
        sys.exit(1)

    # Extract configuration (all optional in manual mode)
    target_url = payload.pop("target_url", None)
    storage_dir = payload.pop("storage_dir", "./local_storage")
    persona_id = payload.get("persona_id")

    print("🤝 Running agent in MANUAL mode...")
    if target_url:
        print(f"   URL: {target_url}")
    if persona_id:
        print(f"   Persona: {persona_id}")
    if "max_turns" in payload:
        print(f"   Max turns: {payload['max_turns']}")
    print(f"   Storage: {Path(storage_dir).absolute()}")
    print()

    try:
        from platforms.local.manual_runner import ManualConversationRunner

        runner = ManualConversationRunner()

        # Set up output directory
        if "output_dir" not in payload:
            session_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            session_name = f"manual_{session_timestamp}"
            payload["output_dir"] = str(
                Path(storage_dir) / "artifacts" / "manual" / session_name
            )

        # Load app context if available (only if target_url provided)
        if target_url:
            domain = payload.get("domain")
            if not domain:
                from utils.url_utils import extract_domain_pattern

                domain_patterns = extract_domain_pattern(target_url)
                # Use the most specific pattern (first in list)
                domain = domain_patterns[0] if domain_patterns else "unknown"

            app_context_path = (
                Path(storage_dir) / "cache" / "manual" / domain / "app_context.json"
            )
            if app_context_path.exists():
                payload["app_context_file"] = str(app_context_path)

        result = asyncio.run(
            runner.run_manual_conversation(
                target_url=target_url,
                **payload,
            )
        )

        print("\n✅ Manual conversation completed!")
        print(f"\nResult: {json.dumps(result, indent=2)}")

        if result.get("status") == "error":
            print("\n⚠️  Conversation completed with errors.")
            sys.exit(1)

    except KeyboardInterrupt:
        print("\n\n⚠️  Conversation interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Manual mode failed: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    print("This module provides the manual mode CLI command.")
    print("Use the command via uv run:")
    print("  - uv run local-manual '<payload>'")
    print()
    print("For test suite execution, use:")
    print("  - uv run local-invoke <suite_name>")
    print("  - uv run agentcore-invoke <suite_name>")
