"""Local filesystem storage adapter.

Stores artifacts and cache files in local directories instead of cloud storage.
"""

import logging
import shutil
from datetime import datetime
from pathlib import Path

from constants import APP_CONTEXT_FILENAME, LOCAL_STORAGE_BASE_DIR
from core.storage import StorageAdapter

logger = logging.getLogger(__name__)


class LocalStorageAdapter(StorageAdapter):
    def _get_storage_path(
        self,
        base: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> Path:
        """Determine storage path based on org_id and task_id."""
        parts = [str(self.base_dir), base]
        if org_id and task_id:
            parts.extend([org_id, task_id])
        elif task_id:
            parts.append(task_id)
        elif org_id:
            parts.append(org_id)
        elif session_id:
            parts.append(session_id)
        return Path("/".join(parts))

    """Storage adapter using local filesystem."""

    def __init__(self, base_dir: str = LOCAL_STORAGE_BASE_DIR):
        """Initialize local storage adapter.

        Args:
            base_dir: Base directory for all storage operations
        """
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Initialized local storage at: {self.base_dir.absolute()}")

    def upload_artifacts(
        self,
        directory: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, str | dict[str, str]]:
        """Upload artifacts to local storage by copying directory.

        Args:
            directory: Source directory containing artifacts
            session_id: Optional session identifier
            org_id: Optional organization ID (used as subdirectory)

        Returns:
            Dictionary with storage location information and file mappings
        """
        source_path = Path(directory)
        if not source_path.exists():
            logger.error(f"Source directory does not exist: {directory}")
            return {"error": "Source directory not found", "file_urls": {}}

        # Build destination path using new logic
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_segment = session_id or f"session_{timestamp}"
        dest_path = self._get_storage_path(
            "artifacts", session_id=session_segment, org_id=org_id, task_id=task_id
        )
        dest_path.mkdir(parents=True, exist_ok=True)

        # Copy all files and track their full paths
        copied_files = []
        file_urls: dict[str, str] = {}
        summary_files_found = []  # Track summary-related files

        for item in source_path.rglob("*"):
            if item.is_file():
                relative_path = item.relative_to(source_path)

                # Skip domain_settings folder (it's redundant - already cached separately)
                if relative_path.parts and relative_path.parts[0] == "domain_settings":
                    continue

                # Skip temp video subdirectories (run_video/, app_context_video/)
                # The final videos are already at persona root as run.mp4
                if (
                    "run_video" in relative_path.parts
                    or "app_context_video" in relative_path.parts
                ):
                    continue

                dest_file = dest_path / relative_path
                dest_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dest_file)
                copied_files.append(str(relative_path))

                # Map relative path to absolute file path
                file_urls[str(relative_path)] = str(dest_file.absolute())

                # Track summary-related files for logging
                filename = item.name
                if filename in [
                    "summary.json",
                    "summary.md",
                    "summary.html",
                    "report_data.json",
                ]:
                    summary_files_found.append(str(relative_path))

        logger.info(f"Uploaded {len(copied_files)} artifacts to {dest_path.absolute()}")

        # Log summary files explicitly
        if summary_files_found:
            logger.info(f"✅ Summary files uploaded: {', '.join(summary_files_found)}")

        return {
            "location": str(dest_path.absolute()),
            "base_dir": str(self.base_dir.absolute()),
            "session_id": session_id or dest_path.name,
            "file_count": str(len(copied_files)),
            "file_urls": file_urls,
        }

    def upload_progress_file(
        self,
        progress_file_path: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload only the progress.json file to local storage.

        Args:
            progress_file_path: Path to the progress.json file
            session_id: Optional session identifier
            org_id: Optional organization ID
            task_id: Optional task identifier

        Returns:
            Local file path of the uploaded file, or None if upload failed
        """
        source_path = Path(progress_file_path)
        if not source_path.exists():
            logger.warning(f"Progress file does not exist: {progress_file_path}")
            return None

        # Determine session_id from file path if not provided
        resolved_session_id = session_id or source_path.parent.name

        # Build destination path in artifacts directory
        dest_path = self._get_storage_path(
            "artifacts", session_id=resolved_session_id, org_id=org_id, task_id=task_id
        )
        dest_path.mkdir(parents=True, exist_ok=True)

        dest_file = dest_path / "progress.json"

        try:
            # Copy the file
            shutil.copy2(str(source_path), str(dest_file))
            logger.debug(f"✓ Uploaded progress.json to {dest_file}")
            return str(dest_file)
        except Exception as exc:
            logger.error(f"Failed to upload progress.json: {exc}")
            return None

    def upload_persona_artifacts(
        self,
        persona_directory: str,
        persona_instance_name: str,
        session_id: str | None = None,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> dict[str, str]:
        """Upload artifacts for a single persona to local storage.

        Args:
            persona_directory: Path to persona's artifact directory
            persona_instance_name: Name of the persona instance
            session_id: Optional session identifier
            org_id: Optional organization ID
            task_id: Optional task identifier

        Returns:
            Dictionary mapping relative file paths to local file paths
        """
        source_path = Path(persona_directory)
        if not source_path.exists():
            logger.error(f"Persona directory does not exist: {persona_directory}")
            return {}

        # Build destination path for this persona
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_segment = session_id or f"session_{timestamp}"
        dest_path = (
            self._get_storage_path(
                "artifacts", session_id=session_segment, org_id=org_id, task_id=task_id
            )
            / persona_instance_name
        )
        dest_path.mkdir(parents=True, exist_ok=True)

        # Copy all files and track their full paths
        file_urls: dict[str, str] = {}
        for item in source_path.rglob("*"):
            if item.is_file():
                relative_path = item.relative_to(source_path)

                # Skip temp video subdirectories — the final video is already
                # at the persona root as run.mp4 (copied by move_run_video)
                relative_posix = relative_path.as_posix()
                if relative_posix.startswith(("run_video/", "app_context_video/")):
                    continue
                dest_file = dest_path / relative_path
                dest_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dest_file)

                # Map persona-relative path to absolute file path
                persona_relative_path = f"{persona_instance_name}/{relative_path}"
                file_urls[persona_relative_path] = str(dest_file.absolute())

        logger.info(
            f"Uploaded {len(file_urls)} artifacts for {persona_instance_name} to {dest_path.absolute()}"
        )
        return file_urls

    def download_cache(
        self,
        domain: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
    ) -> str | None:
        """Download cached file from local storage.

        Args:
            domain: Domain name for cache isolation
            cache_key: File identifier to retrieve
            org_id: Optional organization ID

        Returns:
            File contents as string, or None if not found
        """

        cache_dir = self._get_storage_path("cache", org_id=org_id)
        cache_path = cache_dir / domain / cache_key

        if not cache_path.exists():
            logger.debug(f"Cache miss: {cache_path}")
            return None

        try:
            with open(cache_path, encoding="utf-8") as f:
                content = f.read()
            logger.info(f"Cache hit: {cache_path}")
            return content
        except Exception as e:
            logger.error(f"Error reading cache file {cache_path}: {e}")
            return None

    def download_discovery_artifacts(
        self,
        domain: str,
        org_id: str | None = None,
    ) -> dict[str, str | list[str] | None]:
        """Download all discovery artifacts for a domain from local storage.

        Returns a dict with:
        - app_context: app_context.json content or None
        - discovery_video: Path to discovery.mp4 or None
        - screenshots: List of paths to screenshot files or empty list

        Args:
            domain: Domain name
            org_id: Optional organization ID

        Returns:
            Dictionary with artifact paths and content
        """
        from constants import (
            APP_CONTEXT_FILENAME,
            DISCOVERY_VIDEO_FILENAME,
        )

        cache_dir = self._get_storage_path("cache", org_id=org_id)
        domain_dir = cache_dir / domain

        artifacts: dict[str, str | list[str] | None] = {
            "app_context": None,
            "discovery_video": None,
            "screenshots": [],
        }

        # Load app_context.json
        app_context_path = domain_dir / APP_CONTEXT_FILENAME
        if app_context_path.exists():
            try:
                with open(app_context_path, encoding="utf-8") as f:
                    artifacts["app_context"] = f.read()
                logger.info(f"✓ Loaded app_context.json for {domain}")
            except Exception as e:
                logger.warning(f"Error reading app_context.json: {e}")

        # Check for discovery.mp4
        discovery_video_path = domain_dir / DISCOVERY_VIDEO_FILENAME
        if discovery_video_path.exists():
            artifacts["discovery_video"] = str(discovery_video_path)
            logger.info(f"✓ Found discovery video for {domain}")

        # List screenshots
        screenshots_dir = domain_dir / "screenshots"
        if screenshots_dir.exists():
            try:
                screenshot_files = sorted(screenshots_dir.glob("*.png"))
                artifacts["screenshots"] = [str(f) for f in screenshot_files]
                if artifacts["screenshots"]:
                    logger.info(
                        f"✓ Found {len(artifacts['screenshots'])} screenshots for {domain}"
                    )
            except Exception as e:
                logger.warning(f"Error listing screenshots: {e}")

        return artifacts

    def upload_cache(
        self,
        domain: str,
        content: str,
        cache_key: str = APP_CONTEXT_FILENAME,
        org_id: str | None = None,
    ) -> bool:
        """Upload file to local cache storage.

        Args:
            domain: Domain name for cache isolation
            content: File content to upload
            cache_key: File identifier
            org_id: Optional organization ID

        Returns:
            True if successful, False otherwise
        """

        cache_dir = self._get_storage_path("cache", org_id=org_id) / domain
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = cache_dir / cache_key

        try:
            with open(cache_path, "w", encoding="utf-8") as f:
                f.write(content)
            logger.info(f"Cached file to: {cache_path}")
            return True
        except Exception as e:
            logger.error(f"Error writing cache file {cache_path}: {e}")
            return False

    def delete_domain_cache(
        self,
        domain: str,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> bool:
        """Delete all cached files for a domain from local storage.

        Args:
            domain: Domain name
            org_id: Optional organization ID
            task_id: Optional task ID

        Returns:
            True if deletion successful, False otherwise
        """
        cache_dir = self._get_storage_path("cache", org_id=org_id, task_id=task_id)
        domain_cache_path = cache_dir / domain

        if not domain_cache_path.exists():
            return True

        try:
            shutil.rmtree(domain_cache_path)
            logger.info(f"✓ Deleted domain cache for domain: {domain}")
            return True
        except Exception as e:
            logger.error(f"Error deleting domain cache for domain '{domain}': {e}")
            return False

    def get_storage_location(self) -> str:
        """Get human-readable description of storage location.

        Returns:
            Storage location description
        """
        return str(self.base_dir.absolute())

    def upload_screenshot(
        self,
        screenshot_bytes: bytes,
        session_id: str,
        intervention_id: str,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload a screenshot to local storage.

        Args:
            screenshot_bytes: Raw screenshot image bytes (PNG format)
            session_id: Session identifier
            intervention_id: Intervention identifier
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            Local file path to the screenshot, None if upload failed
        """
        # Build destination path

        screenshot_dir = self._get_storage_path(
            "hitl_screenshots", session_id=session_id, org_id=org_id, task_id=task_id
        )
        screenshot_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        screenshot_path = screenshot_dir / f"{timestamp}_{intervention_id}.png"

        try:
            logger.info(f"Saving screenshot to: {screenshot_path}")
            with open(screenshot_path, "wb") as f:
                f.write(screenshot_bytes)
            logger.info(f"✓ Saved screenshot to {screenshot_path}")
            return str(screenshot_path.absolute())
        except Exception as e:
            logger.error(f"Error saving screenshot: {e}")
            return None

    def upload_discovery_screenshot(
        self,
        screenshot_bytes: bytes,
        domain: str,
        filename: str,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload a discovery screenshot to domain settings folder in local storage.

        Args:
            screenshot_bytes: Raw screenshot image bytes (PNG format)
            domain: Domain name (used for folder organization)
            filename: Screenshot filename (e.g., '20241112_123456_homepage.png')
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            Local file path to the screenshot, None if upload failed
        """
        # Build destination path in domain_settings folder

        screenshot_dir = (
            self._get_storage_path("domain_settings", org_id=org_id, task_id=task_id)
            / domain
            / "screenshots"
        )
        screenshot_dir.mkdir(parents=True, exist_ok=True)
        screenshot_path = screenshot_dir / filename

        try:
            logger.info(f"Saving discovery screenshot to: {screenshot_path}")
            with open(screenshot_path, "wb") as f:
                f.write(screenshot_bytes)
            logger.info(f"✓ Saved discovery screenshot to {screenshot_path}")
            return str(screenshot_path.absolute())
        except Exception as e:
            logger.error(f"Error saving discovery screenshot: {e}")
            return None

    def upload_discovery_video(
        self,
        video_path: str,
        domain: str,
        filename: str,
        org_id: str | None = None,
        task_id: str | None = None,
    ) -> str | None:
        """Upload a discovery video to domain settings folder in local storage.

        Args:
            video_path: Path to the video file
            domain: Domain name (used for folder organization)
            filename: Video filename (e.g., 'discovery.mp4')
            org_id: Optional organization ID for multi-tenant storage

        Returns:
            Local file path to the video, None if upload failed
        """
        # Build destination path in domain_settings folder

        video_dir = (
            self._get_storage_path("domain_settings", org_id=org_id, task_id=task_id)
            / domain
        )
        video_dir.mkdir(parents=True, exist_ok=True)
        dest_path = video_dir / filename

        try:
            logger.info(f"Copying discovery video to: {dest_path}")
            shutil.copy2(video_path, dest_path)
            logger.info(f"✓ Saved discovery video to {dest_path}")
            return str(dest_path.absolute())
        except Exception as e:
            logger.error(f"Error copying discovery video: {e}")
            return None
