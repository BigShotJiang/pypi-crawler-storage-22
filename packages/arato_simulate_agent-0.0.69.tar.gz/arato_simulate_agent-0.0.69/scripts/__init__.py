"""Shared scripts for development and CI/CD."""
