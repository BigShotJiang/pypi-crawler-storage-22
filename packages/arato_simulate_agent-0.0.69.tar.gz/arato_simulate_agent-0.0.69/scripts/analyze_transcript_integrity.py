#!/usr/bin/env python3
"""Analyze transcript integrity by comparing history.json and transcript.json.

This script identifies discrepancies between the number of user messages typed
(recorded in history.json via fast_type_and_submit actions) and the number of
user messages captured in transcript.json.

It also checks if conversations are coherent using an LLM to determine if
responses make sense given the captured user messages.
"""

import asyncio
import json
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path

from browser_use.llm.messages import UserMessage

# Set up logging
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)


@dataclass
class ConversationTurn:
    """A single turn in the conversation."""

    role: str
    text: str
    turn_number: int


@dataclass
class SessionAnalysis:
    """Analysis results for a single session."""

    session_name: str
    session_path: Path
    typed_messages: int
    captured_messages: int
    missing_messages: int
    typed_texts: list[str]
    captured_texts: list[str]
    missing_texts: list[str]
    conversation: list[ConversationTurn] = field(default_factory=list)
    is_coherent: bool = True
    coherence_issues: list[str] = field(default_factory=list)


def validate_gcloud_credentials() -> None:
    """Validate that gcloud credentials are available and not expired.

    Exits with error message if credentials are missing or expired.
    """
    try:
        import google.auth
        from google.auth.exceptions import DefaultCredentialsError

        try:
            credentials, project = google.auth.default()

            # Try to refresh credentials to check if they're valid
            from google.auth.transport.requests import Request

            if hasattr(credentials, "expired") and credentials.expired:
                if hasattr(credentials, "refresh"):
                    credentials.refresh(Request())

        except DefaultCredentialsError:
            print("\n❌ ERROR: Google Cloud credentials not found")
            print("\nPlease authenticate with one of:")
            print("  1. gcloud auth application-default login")
            print("  2. Set GOOGLE_APPLICATION_CREDENTIALS environment variable")
            print("\nExample:")
            print("  gcloud auth application-default login")
            print("  gcloud config set project YOUR_PROJECT_ID")
            sys.exit(1)
        except Exception as e:
            if (
                "Reauthentication is needed" in str(e)
                or "RefreshError" in type(e).__name__
            ):
                print("\n❌ ERROR: Google Cloud credentials expired")
                print("\nPlease re-authenticate:")
                print("  gcloud auth application-default login")
                sys.exit(1)
            # For other errors, let the script continue (may not need credentials)
            logger.debug(f"Credential check warning: {e}")

    except ImportError:
        # google-auth not installed - let script continue, will fail later if needed
        pass


def extract_typed_messages(history_path: Path) -> list[str]:
    """Extract all user messages from fast_type_and_submit actions in history.json."""
    if not history_path.exists():
        return []

    try:
        with open(history_path) as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return []

    messages = []
    agent_history = data.get("agent_history", [])

    for step in agent_history:
        model_output = step.get("model_output", {})
        actions = model_output.get("action", [])

        for action in actions:
            if "fast_type_and_submit" in action:
                text = action["fast_type_and_submit"].get("text")
                if text:  # Skip None values
                    messages.append(text)

    return messages


def extract_conversation(transcript_path: Path) -> list[ConversationTurn]:
    """Extract full conversation from transcript.json."""
    if not transcript_path.exists():
        return []

    try:
        with open(transcript_path) as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return []

    conversation = []
    transcript = data.get("transcript", [])
    turn_num = 0

    for turn in transcript:
        role = turn.get("role", "unknown")
        text = turn.get("text", "")
        if text:
            if role == "user":
                turn_num += 1
            conversation.append(
                ConversationTurn(role=role, text=text, turn_number=turn_num)
            )

    return conversation


def extract_captured_messages(transcript_path: Path) -> list[str]:
    """Extract all user messages from transcript.json."""
    if not transcript_path.exists():
        return []

    try:
        with open(transcript_path) as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return []

    messages = []
    transcript = data.get("transcript", [])

    for turn in transcript:
        if turn.get("role") == "user":
            text = turn.get("text", "")
            if text:
                messages.append(text)

    return messages


def find_missing_messages(typed: list[str], captured: list[str]) -> list[str]:
    """Find messages that were typed but not captured.

    Uses a simple approach: for each typed message, check if it exists
    in the captured list (by checking if the first 100 chars match).
    """
    missing = []
    captured_prefixes = {msg[:100] for msg in captured}

    for msg in typed:
        prefix = msg[:100]
        if prefix not in captured_prefixes:
            missing.append(msg)

    return missing


async def check_coherence_llm(
    conversation: list[ConversationTurn],
) -> tuple[bool, list[str]]:
    """Check if conversation is coherent using an LLM.

    The LLM evaluates whether assistant responses make sense given the
    preceding user messages, looking for signs that responses reference
    topics or information not present in the captured conversation.

    Returns (is_coherent, list of issues found).
    """
    if not conversation:
        return True, []

    # Format conversation for LLM
    conv_text = ""
    for turn in conversation:
        role = "User" if turn.role == "user" else "Assistant"
        conv_text += f"\n[{role}]: {turn.text}\n"

    prompt = f"""Analyze this conversation between a User and an AI Assistant for COHERENCE.

A conversation is INCOHERENT if:
- An assistant response references specific information that was never mentioned by the user
- The assistant answers a question that wasn't asked
- The assistant continues a topic that was never introduced
- The flow of conversation has unexplained jumps or references to phantom context

A conversation IS COHERENT even if:
- The assistant misunderstands a question
- The assistant gives a poor or wrong answer
- The conversation is about general topics that could come up naturally
- The assistant proactively brings up new related topics (that's normal assistant behavior)

CONVERSATION:
{conv_text}

Respond in JSON format:
{{
    "is_coherent": true/false,
    "issues": ["list of specific coherence issues found, or empty if coherent"],
    "reasoning": "brief explanation"
}}

Be conservative - only flag as incoherent if there are CLEAR signs that responses
reference specific information that was never provided by the user."""

    try:
        from core.llm import create_chat_model

        llm = create_chat_model()
        response = await llm.ainvoke([UserMessage(content=prompt)])
        result_text = response.completion.strip()

        # Parse JSON response
        from json_repair import repair_json

        result: dict = repair_json(result_text, return_objects=True)  # type: ignore[assignment]

        is_coherent = result.get("is_coherent", True)
        issues = result.get("issues", [])

        return is_coherent, issues if issues else []

    except Exception as e:
        logger.warning(f"LLM coherence check failed: {e}")
        return True, []  # Assume coherent if check fails


def analyze_session(session_dir: Path) -> SessionAnalysis | None:
    """Analyze a single session directory (without coherence check - that's async)."""
    history_path = session_dir / "history.json"
    transcript_path = session_dir / "transcript.json"

    if not history_path.exists() or not transcript_path.exists():
        return None

    typed = extract_typed_messages(history_path)
    captured = extract_captured_messages(transcript_path)
    missing = find_missing_messages(typed, captured)
    conversation = extract_conversation(transcript_path)

    return SessionAnalysis(
        session_name=session_dir.name,
        session_path=session_dir.resolve(),
        typed_messages=len(typed),
        captured_messages=len(captured),
        missing_messages=len(missing),
        typed_texts=typed,
        captured_texts=captured,
        missing_texts=missing,
        conversation=conversation,
        is_coherent=True,  # Will be updated by async coherence check
        coherence_issues=[],
    )


MAX_PARALLEL_CHECKS = 30


async def check_single_session(
    result: SessionAnalysis, semaphore: asyncio.Semaphore, progress: dict
) -> None:
    """Check coherence for a single session with semaphore control."""
    if not result.conversation:
        progress["done"] += 1
        return

    async with semaphore:
        progress["done"] += 1
        print(
            f"\r   Checking sessions... {progress['done']}/{progress['total']} "
            f"(✅ {progress['coherent']} ⚠️  {progress['issues']})",
            end="",
            flush=True,
        )

        is_coherent, issues = await check_coherence_llm(result.conversation)
        result.is_coherent = is_coherent
        result.coherence_issues = issues

        if is_coherent:
            progress["coherent"] += 1
        else:
            progress["issues"] += 1


async def run_coherence_checks(results: list[SessionAnalysis]) -> None:
    """Run LLM coherence checks on all sessions in parallel."""
    print(f"\n🔍 Running LLM coherence checks ({MAX_PARALLEL_CHECKS} parallel)...")

    semaphore = asyncio.Semaphore(MAX_PARALLEL_CHECKS)
    progress = {"done": 0, "total": len(results), "coherent": 0, "issues": 0}

    tasks = [check_single_session(r, semaphore, progress) for r in results]
    await asyncio.gather(*tasks)

    print()  # New line after progress


async def main_async():
    """Async main entry point."""
    # Validate credentials before doing any work
    validate_gcloud_credentials()

    if len(sys.argv) < 2:
        print("Usage: python analyze_transcript_integrity.py <sessions_folder>")
        print("Example: python analyze_transcript_integrity.py sessions/hibob")
        return

    sessions_dir = Path(sys.argv[1])

    if not sessions_dir.exists():
        print(f"Error: {sessions_dir} not found")
        return

    # Initialize the local platform adapter (sets up LLM)
    print("Initializing LLM...")
    from platforms.local.adapter import LocalPlatformAdapter

    LocalPlatformAdapter()

    # Find all session directories (exclude files)
    session_dirs = [d for d in sessions_dir.iterdir() if d.is_dir()]

    print(f"Analyzing {len(session_dirs)} sessions in {sessions_dir}...\n")
    print("=" * 80)

    results: list[SessionAnalysis] = []
    total_typed = 0
    total_captured = 0
    total_missing = 0
    sessions_with_issues = []

    for session_dir in sorted(session_dirs):
        result = analyze_session(session_dir)
        if result is None:
            continue

        results.append(result)
        total_typed += result.typed_messages
        total_captured += result.captured_messages
        total_missing += result.missing_messages

        if result.missing_messages > 0:
            sessions_with_issues.append(result)

    # Run async coherence checks
    await run_coherence_checks(results)

    # Find sessions with coherence issues
    sessions_with_coherence_issues = [r for r in results if not r.is_coherent]

    # Print summary
    print("\n" + "=" * 80)
    print("📊 TRANSCRIPT INTEGRITY ANALYSIS SUMMARY")
    print("=" * 80)

    # Overall stats
    coherent_count = len(results) - len(sessions_with_coherence_issues)
    coherence_rate = (coherent_count / len(results) * 100) if results else 0

    print(f"\n📁 Sessions analyzed: {len(results)}")
    print(f"   ├── ✅ Coherent:     {coherent_count} ({coherence_rate:.1f}%)")
    print(
        f"   └── ⚠️  With issues: {len(sessions_with_coherence_issues)} ({100 - coherence_rate:.1f}%)"
    )

    print("\n📝 Message Capture Stats:")
    print(f"   ├── Attempted (fast_type_and_submit): {total_typed}")
    print(f"   ├── Captured (transcript.json):       {total_captured}")
    print(f"   └── Uncaptured attempts:              {total_missing}")

    if total_typed > 0:
        gap_rate = (total_missing / total_typed) * 100
        print(f"\n   ℹ️  Attempt-vs-Capture Gap: {gap_rate:.1f}%")
        print("      (Failed typing attempts that were retried - not data loss)")

    # Coherence analysis details
    print("\n" + "-" * 80)
    print("🔍 COHERENCE ANALYSIS DETAILS")
    print("-" * 80)

    if sessions_with_coherence_issues:
        print(
            f"\n⚠️  {len(sessions_with_coherence_issues)} sessions have coherence issues:\n"
        )
        for result in sessions_with_coherence_issues:
            transcript_path = result.session_path / "transcript.json"
            print(f"📁 {result.session_name}")
            print(f"   → {transcript_path}")
            for issue in result.coherence_issues:
                print(f"   ❌ {issue}")
            print()
    else:
        print("\n✅ ALL CONVERSATIONS ARE COHERENT!")
        print("   → Responses logically follow from user messages")
        print("   → No evidence of missing context in assistant responses")
        print("   → The 'uncaptured attempts' were just failed retries")

    # Final verdict
    print("\n" + "=" * 80)
    if not sessions_with_coherence_issues:
        print("🎉 VERDICT: No transcript integrity issues detected!")
        print("   All conversations flow naturally without unexplained references.")
    else:
        print(f"⚠️  VERDICT: {len(sessions_with_coherence_issues)} sessions need review")
        print("   Some responses may reference information not in captured messages.")
    print("=" * 80)

    # Print sample conversation from first session with issues
    if sessions_with_issues and len(sys.argv) > 2 and sys.argv[2] == "--show-sample":
        sample = sessions_with_issues[0]
        print(f"\n\n📝 SAMPLE CONVERSATION: {sample.session_name}")
        print("=" * 80)
        for turn in sample.conversation[:10]:  # Show first 10 turns
            role_icon = "👤" if turn.role == "user" else "🤖"
            text_preview = turn.text[:150].replace("\n", " ")
            print(f"{role_icon} [{turn.role.upper()}]: {text_preview}...")


def main():
    """Sync entry point."""
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
