#!/usr/bin/env python3
"""Build script that runs all code quality checks and tests.

This script is used in CI/CD pipelines and local development to ensure
code quality before committing or deploying.

Usage:
    uv run build
"""

import subprocess
import sys
from pathlib import Path


def run_command(cmd: list[str], description: str) -> bool:
    """Run a command and return True if successful."""
    print(f"\n{'=' * 80}")
    print(f"Running: {description}")
    print(f"Command: {' '.join(cmd)}")
    print("=" * 80)

    try:
        subprocess.run(cmd, check=True, capture_output=False)
        print(f"✅ {description} - PASSED")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} - FAILED (exit code: {e.returncode})")
        return False


def run_all_checks() -> None:
    """Run all code quality checks and unit tests (integration tests excluded)."""
    project_root = Path(__file__).parent.parent

    print(f"\n{'=' * 80}")
    print("ARATO AGENT BUILD SCRIPT")
    print(f"Project: {project_root}")
    print("=" * 80)

    checks = [
        (["ruff", "format", "."], "Ruff Format (auto-fix)"),
        (["ruff", "check", "."], "Ruff Check (linting)"),
        (["ty", "check"], "Ty (type checking)"),
        (
            ["pytest", "--tb=short", "-v", "-m", "not integration"],
            "Pytest (unit tests, excluding integration)",
        ),
    ]

    results = []
    for cmd, description in checks:
        success = run_command(cmd, description)
        results.append((description, success))

    # Print summary
    print(f"\n{'=' * 80}")
    print("BUILD SUMMARY")
    print("=" * 80)

    all_passed = True
    for description, success in results:
        status = "✅ PASSED" if success else "❌ FAILED"
        print(f"{status:12} - {description}")
        if not success:
            all_passed = False

    print("=" * 80)

    if all_passed:
        print("✅ All checks passed! Ready to commit/deploy.")
        sys.exit(0)
    else:
        print("❌ Some checks failed. Please fix the issues above.")
        sys.exit(1)


def run_unit_tests() -> None:
    """Run only unit tests (excludes integration and slow tests)."""
    print(f"\n{'=' * 80}")
    print("RUNNING UNIT TESTS")
    print("=" * 80)

    cmd = ["pytest", "-v", "-m", "not slow and not integration", "--tb=short"]
    success = run_command(cmd, "Unit Tests")

    if success:
        print("\n✅ All unit tests passed!")
        sys.exit(0)
    else:
        print("\n❌ Some unit tests failed.")
        sys.exit(1)


def run_integration_tests() -> None:
    """Run only integration tests."""
    print(f"\n{'=' * 80}")
    print("RUNNING INTEGRATION TESTS")
    print("WARNING: Integration tests make real browser and API calls!")
    print("=" * 80)

    cmd = ["pytest", "-v", "-m", "integration or slow", "--tb=short"]
    success = run_command(cmd, "Integration Tests")

    if success:
        print("\n✅ All integration tests passed!")
        sys.exit(0)
    else:
        print("\n❌ Some integration tests failed.")
        sys.exit(1)


def run_all_tests() -> None:
    """Run all tests (unit + integration)."""
    print(f"\n{'=' * 80}")
    print("RUNNING ALL TESTS")
    print("WARNING: Includes integration tests with real browser and API calls!")
    print("=" * 80)

    cmd = ["pytest", "-v", "--tb=short"]
    success = run_command(cmd, "All Tests")

    if success:
        print("\n✅ All tests passed!")
        sys.exit(0)
    else:
        print("\n❌ Some tests failed.")
        sys.exit(1)


if __name__ == "__main__":
    run_all_checks()
