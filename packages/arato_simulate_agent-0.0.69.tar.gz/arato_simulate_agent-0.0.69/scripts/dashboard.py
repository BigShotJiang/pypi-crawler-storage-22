"""
CLI Dashboard for Arato Agent Pipeline Monitoring.

Uses Textual TUI framework to display real-time progress
from progress.json files (local or S3).
"""

import asyncio
import json
import re
from datetime import datetime, timedelta
from pathlib import Path
from statistics import mean
from typing import Any

from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, ScrollableContainer, Vertical
from textual.reactive import reactive
from textual.widgets import (
    Footer,
    Header,
    Label,
    ProgressBar,
    Static,
)


class PhaseIndicator(Static):
    """Widget showing current orchestrator phase."""

    phase = reactive("initializing")
    status = reactive("running")

    PHASE_EMOJI = {
        "initializing": "🔧",
        "connectivity": "🔌",
        "discovery": "🔍",
        "running_personas": "🎭",
        "generating_summary": "📝",
        "uploading_artifacts": "☁️",
        "complete": "✅",
        "failed": "❌",
    }

    def render(self) -> str:
        emoji = self.PHASE_EMOJI.get(self.phase, "⏳")
        status_color = (
            "green"
            if self.status == "completed"
            else "yellow"
            if self.status == "running"
            else "red"
        )
        return f"{emoji} [{status_color}]{self.phase.upper().replace('_', ' ')}[/]"


class TimerWidget(Static):
    """Widget showing elapsed time and ETA."""

    start_time: datetime | None = None
    completion_pct: float = 0.0

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._elapsed_str = "00:00:00"
        self._eta_str = "Calculating..."

    def set_start_time(self, start_time: datetime | None) -> None:
        self.start_time = start_time

    def set_completion_pct(self, pct: float) -> None:
        self.completion_pct = pct

    def update_display(self) -> None:
        """Update the elapsed time and ETA display."""
        if self.start_time is None:
            self._elapsed_str = "00:00:00"
            self._eta_str = "Waiting..."
            self.refresh()
            return

        now = datetime.now()
        elapsed = now - self.start_time
        self._elapsed_str = self._format_duration(elapsed)

        # Calculate ETA based on completion percentage
        if self.completion_pct > 0 and self.completion_pct < 100:
            elapsed_seconds = elapsed.total_seconds()
            estimated_total = elapsed_seconds / (self.completion_pct / 100)
            remaining_seconds = estimated_total - elapsed_seconds
            remaining = timedelta(seconds=max(0, remaining_seconds))
            self._eta_str = f"~{self._format_duration(remaining)} left"
        elif self.completion_pct >= 100:
            self._eta_str = "Complete!"
        else:
            self._eta_str = "Calculating..."

        self.refresh()

    def _format_duration(self, td: timedelta) -> str:
        """Format timedelta as HH:MM:SS."""
        total_seconds = int(td.total_seconds())
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def render(self) -> str:
        return f"⏱️  [bold cyan]{self._elapsed_str}[/]  |  🏁 [bold yellow]{self._eta_str}[/]"


class TimingStatsWidget(Static):
    """Widget showing timing statistics from agent-timing.log."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._stats = {
            "total_extractions": 0,
            "avg_extraction_s": 0.0,
            "min_extraction_s": 0.0,
            "max_extraction_s": 0.0,
            "avg_cpu_pct": 0.0,
            "total_io_s": 0.0,
            "error_count": 0,
        }

    def update_stats(self, stats: dict) -> None:
        self._stats = stats
        self.refresh()

    def render(self) -> str:
        s = self._stats
        if s["total_extractions"] == 0:
            return "[dim]No timing data yet[/]"

        lines = [
            "[bold]📊 Timing Stats[/]",
            f"  Extractions: [cyan]{s['total_extractions']}[/]",
            f"  Avg: [green]{s['avg_extraction_s']:.2f}s[/] "
            f"(min: {s['min_extraction_s']:.2f}s, max: {s['max_extraction_s']:.2f}s)",
            f"  CPU: [yellow]{s['avg_cpu_pct']:.1f}%[/] | I/O Wait: [blue]{s['total_io_s']:.1f}s[/]",
        ]
        if s["error_count"] > 0:
            lines.append(f"  [bold red]⚠️  Errors: {s['error_count']}[/]")
        return "\n".join(lines)


class StatsPanel(Static):
    """Panel showing execution statistics."""

    def __init__(self, title: str, value: str = "-", **kwargs) -> None:
        super().__init__(**kwargs)
        self._title = title
        self._value = value

    def compose(self) -> ComposeResult:
        yield Label(self._title, classes="stats-title")
        yield Label(
            self._value,
            id=f"stats-{self._title.lower().replace(' ', '-')}",
            classes="stats-value",
        )

    def update_value(self, value: str) -> None:
        self._value = value
        try:
            label = self.query_one(
                f"#stats-{self._title.lower().replace(' ', '-')}", Label
            )
            label.update(value)
        except Exception:
            pass


class PersonaRow(Static):
    """Widget for displaying a single persona's progress."""

    def __init__(
        self,
        instance_name: str,
        persona_id: str,
        status: str = "pending",
        current_step: int = 0,
        total_steps: int = 10,
        turns: int = 0,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.instance_name = instance_name
        self.persona_id = persona_id
        self._status = status
        self._current_step = current_step
        self._total_steps = total_steps
        self._turns = turns

    @property
    def progress_pct(self) -> float:
        if self._total_steps == 0:
            return 0.0
        return (self._current_step / self._total_steps) * 100

    def compose(self) -> ComposeResult:
        with Horizontal(classes="persona-row"):
            yield Label(self._get_status_icon(), classes="persona-status")
            yield Label(self.instance_name[:20].ljust(20), classes="persona-name")
            yield ProgressBar(total=100, show_eta=False, classes="persona-progress")
            yield Label(f"Turn {self._turns}", classes="persona-turns")

    def _get_status_icon(self) -> str:
        icons = {
            "pending": "⏳",
            "running": "🔄",
            "completed": "✅",
            "failed": "❌",
        }
        return icons.get(self._status, "❓")

    def update_state(
        self, status: str, current_step: int, total_steps: int, turns: int
    ) -> None:
        self._status = status
        self._current_step = current_step
        self._total_steps = total_steps
        self._turns = turns

        try:
            self.query_one(".persona-status", Label).update(self._get_status_icon())
            self.query_one(".persona-progress", ProgressBar).update(
                progress=self.progress_pct
            )
            self.query_one(".persona-turns", Label).update(f"Turn {turns}")
        except Exception:
            pass


class GraphProgressWidget(Static):
    """Widget showing graph pipeline progress visualization."""

    GRAPH_NODES = [
        "connectivity_check",
        "session_setup",
        "app_discovery",
        "ground_truth",
        "persona_runner",
        "cross_conversation",
        "summary",
        "artifact_upload",
        "task_completion",
    ]

    NODE_DISPLAY = {
        "connectivity_check": "Connect",
        "session_setup": "Setup",
        "app_discovery": "Discover",
        "ground_truth": "Ground",
        "persona_runner": "Personas",
        "cross_conversation": "Analysis",
        "summary": "Summary",
        "artifact_upload": "Upload",
        "task_completion": "Complete",
    }

    STATUS_ICONS = {
        "pending": "○",
        "running": "▶",
        "completed": "✓",
        "skipped": "⊘",
        "failed": "✗",
    }

    STATUS_COLORS = {
        "pending": "",
        "running": "yellow",
        "completed": "green",
        "skipped": "dim",
        "failed": "red",
    }

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._graph_nodes: dict[str, dict[str, Any]] = {}

    def update_graph(self, graph_nodes: dict[str, dict[str, Any]]) -> None:
        """Update graph node states."""
        self._graph_nodes = graph_nodes
        self.refresh()

    def render(self) -> str:
        """Render the graph pipeline progress."""
        lines = ["[bold cyan]Pipeline Progress[/]"]
        for node in self.GRAPH_NODES:
            data = self._graph_nodes.get(node, {})
            status = data.get("status", "pending")
            icon = self.STATUS_ICONS.get(status, "?")
            color = self.STATUS_COLORS.get(status, "")
            name = self.NODE_DISPLAY.get(node, node)
            dur_ms = data.get("duration_ms")
            dur_str = f" ({dur_ms}ms)" if dur_ms else ""
            tokens = data.get("total_tokens", 0)
            tok_str = f" [{tokens}tok]" if tokens else ""
            line = f"  {icon} {name:<10}{dur_str}{tok_str}"
            if color:
                line = f"[{color}]{line}[/]"
            lines.append(line)
        return "\n".join(lines)


class AratoDashboard(App):
    """Main dashboard application for monitoring Arato Agent execution."""

    CSS = """
    Screen {
        layout: grid;
        grid-size: 1;
        grid-rows: auto 1fr auto;
    }

    #header-container {
        height: auto;
        padding: 1;
        background: $surface;
        border-bottom: solid $primary;
    }

    #target-url {
        text-style: bold;
        color: $text;
    }

    #session-id {
        color: $text-muted;
    }

    #main-container {
        layout: grid;
        grid-size: 2;
        grid-columns: 1fr 2fr;
        padding: 1;
    }

    #left-panel {
        padding: 1;
        border: solid $primary;
        background: $surface;
    }

    #right-panel {
        padding: 1;
        border: solid $primary;
        background: $surface;
    }

    .stats-grid {
        layout: grid;
        grid-size: 2;
        grid-gutter: 1;
        height: auto;
        margin-bottom: 1;
    }

    StatsPanel {
        height: auto;
        padding: 1;
        background: $boost;
        border: solid $primary-lighten-1;
    }

    .stats-title {
        text-style: bold;
        color: $text-muted;
    }

    .stats-value {
        text-style: bold;
        color: $text;
        text-align: center;
    }

    PhaseIndicator {
        height: auto;
        padding: 1;
        margin-bottom: 1;
        text-align: center;
        text-style: bold;
        background: $boost;
        border: solid $primary;
    }

    TimerWidget {
        height: auto;
        padding: 1;
        margin-bottom: 1;
        text-align: center;
        background: $boost;
        border: solid $primary;
    }

    TimingStatsWidget {
        height: auto;
        padding: 1;
        margin-top: 1;
        background: $boost;
        border: solid $primary;
    }

    GraphProgressWidget {
        height: auto;
        padding: 1;
        margin-bottom: 1;
        background: $boost;
        border: solid $primary;
    }

    #personas-header {
        text-style: bold;
        padding: 1;
        background: $primary;
        color: $text;
    }

    .persona-row {
        height: 3;
        padding: 0 1;
        border-bottom: solid $surface-darken-1;
    }

    .persona-status {
        width: 4;
    }

    .persona-name {
        width: 22;
    }

    .persona-progress {
        width: 1fr;
    }

    .persona-turns {
        width: 10;
        text-align: right;
    }

    #status-bar {
        height: auto;
        padding: 1;
        background: $surface;
        border-top: solid $primary;
        color: $text-muted;
    }

    #last-update {
        text-align: right;
    }
    """

    TITLE = "Arato Agent Dashboard"
    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("r", "refresh", "Refresh"),
        Binding("p", "pause", "Pause/Resume"),
    ]

    progress_data = reactive({})
    auto_refresh = reactive(True)

    def __init__(self, progress_source: str, refresh_interval: float = 2.0) -> None:
        super().__init__()
        self.progress_source = progress_source
        self.refresh_interval = refresh_interval
        self._persona_widgets: dict[str, PersonaRow] = {}
        self._run_start_time: datetime | None = None
        self._timing_stats: dict = {}

    def compose(self) -> ComposeResult:
        yield Header()

        with Container(id="header-container"):
            yield Label("Target: Loading...", id="target-url")
            yield Label("Session: Loading...", id="session-id")

        with Horizontal(id="main-container"):
            with Vertical(id="left-panel"):
                yield PhaseIndicator(id="phase-indicator")
                yield GraphProgressWidget(id="graph-progress")
                yield TimerWidget(id="timer-widget")
                with Container(classes="stats-grid"):
                    yield StatsPanel("Total Personas", "0", id="stat-total")
                    yield StatsPanel("Completed", "0", id="stat-completed")
                    yield StatsPanel("Failed", "0", id="stat-failed")
                    yield StatsPanel("Total Turns", "0", id="stat-turns")
                yield TimingStatsWidget(id="timing-stats")

            with Vertical(id="right-panel"):
                yield Label("PERSONAS", id="personas-header")
                yield ScrollableContainer(id="personas-container")

        with Horizontal(id="status-bar"):
            yield Label("Auto-refresh: ON", id="refresh-status")
            yield Label("Last update: Never", id="last-update")

        yield Footer()

    def on_mount(self) -> None:
        """Start auto-refresh when app mounts."""
        self.refresh_data()
        self._start_timer_refresh()

    def _start_timer_refresh(self) -> None:
        """Start periodic timer updates (every second)."""
        self.set_interval(1.0, self._update_timer)

    def _update_timer(self) -> None:
        """Update the timer widget every second."""
        try:
            timer_widget = self.query_one("#timer-widget", TimerWidget)
            timer_widget.update_display()
        except Exception:
            pass

    @work(exclusive=True)
    async def refresh_data(self) -> None:
        """Refresh progress data from source."""
        while True:
            if self.auto_refresh:
                data = await self._load_progress()
                if data:
                    self.progress_data = data

                # Also load timing stats
                timing_stats = await self._load_timing_stats()
                if timing_stats:
                    self._timing_stats = timing_stats
                    try:
                        self.query_one("#timing-stats", TimingStatsWidget).update_stats(
                            timing_stats
                        )
                    except Exception:
                        pass
            await asyncio.sleep(self.refresh_interval)

    async def _load_progress(self) -> dict | None:
        """Load progress data from file or S3."""
        try:
            source = self.progress_source

            if source.startswith("s3://"):
                return await self._load_from_s3(source)
            else:
                return await self._load_from_file(source)

        except Exception as e:
            self.log.error(f"Failed to load progress: {e}")
            return None

    async def _load_from_file(self, path: str) -> dict | None:
        """Load progress from local file."""
        file_path = Path(path)

        # Check for progress.json in directory
        if file_path.is_dir():
            file_path = file_path / "progress.json"

        if not file_path.exists():
            return None

        content = await asyncio.to_thread(file_path.read_text)
        return json.loads(content)

    async def _load_from_s3(self, s3_uri: str) -> dict | None:
        """Load progress from S3."""
        import boto3

        # Parse s3://bucket/key
        parts = s3_uri.replace("s3://", "").split("/", 1)
        bucket = parts[0]
        key = parts[1] if len(parts) > 1 else "progress.json"

        # Add progress.json if key is a prefix
        if not key.endswith(".json"):
            key = f"{key.rstrip('/')}/progress.json"

        try:
            s3 = boto3.client("s3")
            response = await asyncio.to_thread(s3.get_object, Bucket=bucket, Key=key)
            content = response["Body"].read().decode("utf-8")
            return json.loads(content)
        except Exception:
            return None

    async def _load_timing_stats(self) -> dict | None:
        """Load and parse agent-timing.log for timing statistics."""
        try:
            source = self.progress_source

            if source.startswith("s3://"):
                timing_content = await self._load_timing_from_s3(source)
            else:
                timing_content = await self._load_timing_from_file(source)

            if not timing_content:
                return None

            return self._parse_timing_log(timing_content)

        except Exception as e:
            self.log.error(f"Failed to load timing stats: {e}")
            return None

    async def _load_timing_from_file(self, path: str) -> str | None:
        """Load agent-timing.log from local file."""
        file_path = Path(path)

        # Check for agent-timing.log in directory
        if file_path.is_dir():
            file_path = file_path / "agent-timing.log"
        else:
            file_path = file_path.parent / "agent-timing.log"

        if not file_path.exists():
            return None

        return await asyncio.to_thread(file_path.read_text)

    async def _load_timing_from_s3(self, s3_uri: str) -> str | None:
        """Load agent-timing.log from S3."""
        import boto3

        # Parse s3://bucket/key
        parts = s3_uri.replace("s3://", "").split("/", 1)
        bucket = parts[0]
        key = parts[1] if len(parts) > 1 else ""

        # Construct timing log key
        if key.endswith(".json"):
            key = key.rsplit("/", 1)[0] + "/agent-timing.log"
        else:
            key = f"{key.rstrip('/')}/agent-timing.log"

        try:
            s3 = boto3.client("s3")
            response = await asyncio.to_thread(s3.get_object, Bucket=bucket, Key=key)
            return response["Body"].read().decode("utf-8")
        except Exception:
            return None

    def _parse_timing_log(self, content: str) -> dict:
        """Parse agent-timing.log content and extract statistics."""
        stats = {
            "total_extractions": 0,
            "avg_extraction_s": 0.0,
            "min_extraction_s": float("inf"),
            "max_extraction_s": 0.0,
            "avg_cpu_pct": 0.0,
            "total_io_s": 0.0,
            "error_count": 0,
        }

        extraction_times: list[float] = []
        cpu_percentages: list[float] = []
        io_times: list[float] = []

        # Pattern for response_extraction entries
        extraction_pattern = re.compile(
            r"response_extraction: ([\d.]+)s.*cpu_pct=([\d.]+).*io_s=([\d.]+)"
        )

        # Pattern for errors (look for ERROR or error keywords)
        error_pattern = re.compile(r"\b(ERROR|error|Error|failed|Failed|FAILED)\b")

        for line in content.splitlines():
            # Skip comments
            if line.startswith("#") or line.startswith("="):
                continue

            # Check for errors
            if error_pattern.search(line):
                stats["error_count"] += 1

            # Parse extraction entries
            match = extraction_pattern.search(line)
            if match:
                duration = float(match.group(1))
                cpu_pct = float(match.group(2))
                io_s = float(match.group(3))

                extraction_times.append(duration)
                cpu_percentages.append(cpu_pct)
                io_times.append(io_s)

        if extraction_times:
            stats["total_extractions"] = len(extraction_times)
            stats["avg_extraction_s"] = mean(extraction_times)
            stats["min_extraction_s"] = min(extraction_times)
            stats["max_extraction_s"] = max(extraction_times)
            stats["avg_cpu_pct"] = mean(cpu_percentages) if cpu_percentages else 0.0
            stats["total_io_s"] = sum(io_times)
        else:
            stats["min_extraction_s"] = 0.0

        return stats

    def watch_progress_data(self, data: dict) -> None:
        """React to progress data changes."""
        if not data:
            return

        orchestrator = data.get("orchestrator", {})
        personas = data.get("personas", {})

        # Update header
        self.query_one("#target-url", Label).update(
            f"Target: {orchestrator.get('target_url', 'N/A')}"
        )
        self.query_one("#session-id", Label).update(
            f"Session: {orchestrator.get('session_id', 'N/A')[:40]}..."
        )

        # Update phase indicator
        phase_indicator = self.query_one("#phase-indicator", PhaseIndicator)
        phase_indicator.phase = orchestrator.get("phase", "initializing")
        phase_indicator.status = orchestrator.get("status", "running")

        # Update graph progress
        graph_nodes = orchestrator.get("graph_nodes", {})
        if graph_nodes:
            try:
                graph = self.query_one("#graph-progress", GraphProgressWidget)
                graph.update_graph(graph_nodes)
            except Exception:
                pass

        # Update stats
        self.query_one("#stat-total", StatsPanel).update_value(
            str(orchestrator.get("total_personas", 0))
        )
        self.query_one("#stat-completed", StatsPanel).update_value(
            str(orchestrator.get("completed_personas", 0))
        )
        self.query_one("#stat-failed", StatsPanel).update_value(
            str(orchestrator.get("failed_personas", 0))
        )

        # Calculate total turns from personas
        total_turns = sum(p.get("transcript_turns", 0) for p in personas.values())
        self.query_one("#stat-turns", StatsPanel).update_value(str(total_turns))

        # Update timer widget with start time and completion percentage
        timer_widget = self.query_one("#timer-widget", TimerWidget)

        # Parse start time from orchestrator
        started_at = orchestrator.get("started_at")
        if started_at and self._run_start_time is None:
            try:
                # Parse ISO format timestamp (handles both Z suffix and +00:00)
                dt = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
                # Convert to local timezone-naive datetime for comparison with datetime.now()
                if dt.tzinfo:
                    # Convert UTC to local time by using astimezone() then removing tzinfo
                    self._run_start_time = dt.astimezone().replace(tzinfo=None)
                else:
                    self._run_start_time = dt
                timer_widget.set_start_time(self._run_start_time)
            except (ValueError, TypeError):
                pass

        # Calculate overall completion percentage
        total_personas = orchestrator.get("total_personas", 0)
        if total_personas > 0 and personas:
            # Average completion percentage across all personas
            completion_pcts = [
                p.get("progress", {}).get("completion_percentage", 0)
                for p in personas.values()
            ]
            avg_completion = mean(completion_pcts) if completion_pcts else 0
            timer_widget.set_completion_pct(avg_completion)

        # Update personas
        self._update_personas(personas)

        # Update status bar
        self.query_one("#last-update", Label).update(
            f"Last update: {datetime.now().strftime('%H:%M:%S')}"
        )

    def _update_personas(self, personas: dict) -> None:
        """Update persona widgets."""
        container = self.query_one("#personas-container", ScrollableContainer)

        for instance_name, data in personas.items():
            if instance_name not in self._persona_widgets:
                # Create new widget
                widget = PersonaRow(
                    instance_name=instance_name,
                    persona_id=data.get("persona_id", "unknown"),
                    status=data.get("status", "pending"),
                    current_step=data.get("current_step", 0),
                    total_steps=data.get("total_steps", 10),
                    turns=data.get("transcript_turns", 0),
                )
                container.mount(widget)
            else:
                # Update existing widget
                widget = self._persona_widgets[instance_name]
                widget.update_state(
                    status=data.get("status", "pending"),
                    current_step=data.get("current_step", 0),
                    total_steps=data.get("total_steps", 10),
                    turns=data.get("transcript_turns", 0),
                )

    def action_refresh(self) -> None:
        """Manual refresh."""
        self.refresh_data()

    def action_pause(self) -> None:
        """Toggle auto-refresh."""
        self.auto_refresh = not self.auto_refresh
        status = "ON" if self.auto_refresh else "OFF"
        self.query_one("#refresh-status", Label).update(f"Auto-refresh: {status}")


def main() -> None:
    """CLI entry point for dashboard."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Arato Agent Pipeline Dashboard",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Monitor local session
  uv run dashboard sessions/conversation_20251201_120000

  # Monitor from S3
  uv run dashboard s3://arato-agent-artifacts/sessions/abc123

  # Custom refresh interval
  uv run dashboard sessions/latest --interval 5
        """,
    )

    parser.add_argument(
        "source",
        nargs="?",
        default=".",
        help="Progress source: local directory or S3 URI (default: current directory)",
    )

    parser.add_argument(
        "--interval",
        "-i",
        type=float,
        default=2.0,
        help="Refresh interval in seconds (default: 2.0)",
    )

    args = parser.parse_args()

    # Run the dashboard
    app = AratoDashboard(progress_source=args.source, refresh_interval=args.interval)
    app.run()


if __name__ == "__main__":
    main()
