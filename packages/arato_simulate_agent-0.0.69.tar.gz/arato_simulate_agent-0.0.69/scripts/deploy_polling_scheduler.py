#!/usr/bin/env python3
"""Deploy EventBridge Scheduler for polling mode with CloudFormation.

This script creates AWS infrastructure for scheduled polling:
- EventBridge Scheduler rule (recurring schedule)
- IAM role for EventBridge to invoke AgentCore
- SSM parameters for polling configuration
"""

import logging
import sys
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

# Add simulate-agent to path for utils
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "simulate-agent"))

from utils.bedrock_config import get_agent_id  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def get_template_path() -> Path:
    """Get path to CloudFormation template file.

    Returns:
        Path to polling_infrastructure.yaml template
    """
    return Path(__file__).parent / "templates" / "polling_infrastructure.yaml"


def load_cloudformation_template() -> str:
    """Load CloudFormation template from YAML file.

    Returns:
        CloudFormation template content as string
    """
    template_path = get_template_path()
    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")

    return template_path.read_text()


def deploy_ssm_parameters(
    parameter_prefix: str,
    api_key: str,
    task_endpoint: str,
    polling_interval: int = 30,
    circuit_breaker_threshold: int = 5,
    circuit_breaker_timeout: int = 60,
    region: str = "us-east-1",
) -> None:
    """Deploy SSM parameters for polling configuration.

    Args:
        parameter_prefix: SSM parameter prefix
        api_key: Arato API key (stored as SecureString)
        task_endpoint: Task polling endpoint URL
        polling_interval: Polling interval in seconds
        circuit_breaker_threshold: Circuit breaker failure threshold
        circuit_breaker_timeout: Circuit breaker timeout in seconds
        region: AWS region
    """
    ssm = boto3.client("ssm", region_name=region)

    parameters = [
        (f"{parameter_prefix}/api_key", api_key, "SecureString"),
        (f"{parameter_prefix}/task_endpoint", task_endpoint, "String"),
        (f"{parameter_prefix}/polling_interval", str(polling_interval), "String"),
        (
            f"{parameter_prefix}/circuit_breaker_threshold",
            str(circuit_breaker_threshold),
            "String",
        ),
        (
            f"{parameter_prefix}/circuit_breaker_timeout",
            str(circuit_breaker_timeout),
            "String",
        ),
    ]

    logger.info(f"Deploying SSM parameters with prefix: {parameter_prefix}")
    for name, value, param_type in parameters:
        try:
            ssm.put_parameter(
                Name=name,
                Value=value,
                Type=param_type,
                Overwrite=True,
                Description=f"Arato polling configuration - {name.split('/')[-1]}",
            )
            logger.info(f"  ✓ {name}")
        except Exception as e:
            logger.error(f"  ✗ Failed to create {name}: {e}")
            raise


def deploy_cloudformation_stack(
    stack_name: str,
    template_body: str,
    agentcore_arn: str,
    schedule_expression: str,
    parameter_prefix: str,
    region: str = "us-east-1",
) -> None:
    """Deploy CloudFormation stack.

    Args:
        stack_name: Stack name
        template_body: CloudFormation template YAML content
        agentcore_arn: ARN of the deployed AgentCore application
        schedule_expression: EventBridge schedule expression
        parameter_prefix: SSM parameter prefix for configuration
        region: AWS region
    """
    cfn = boto3.client("cloudformation", region_name=region)

    logger.info(f"Deploying CloudFormation stack: {stack_name}")

    parameters = [
        {"ParameterKey": "AgentCoreArn", "ParameterValue": agentcore_arn},
        {"ParameterKey": "ScheduleExpression", "ParameterValue": schedule_expression},
        {"ParameterKey": "ParameterPrefix", "ParameterValue": parameter_prefix},
    ]

    try:
        # Check if stack exists and handle stale states
        stack_exists = False
        try:
            resp = cfn.describe_stacks(StackName=stack_name)
            stack_status = resp["Stacks"][0]["StackStatus"]
            if stack_status in (
                "ROLLBACK_COMPLETE",
                "ROLLBACK_FAILED",
                "DELETE_FAILED",
            ):
                logger.info(
                    f"Stack {stack_name} is in {stack_status}, deleting before re-create..."
                )
                cfn.delete_stack(StackName=stack_name)
                delete_waiter = cfn.get_waiter("stack_delete_complete")
                delete_waiter.wait(StackName=stack_name)
                logger.info("Stale stack deleted.")
                stack_exists = False
            else:
                stack_exists = True
        except cfn.exceptions.ClientError as e:
            err_msg = (
                e.response["Error"]["Message"] if hasattr(e, "response") else str(e)
            )
            if "does not exist" in err_msg:
                stack_exists = False
            else:
                raise

        try:
            if stack_exists:
                logger.info(f"Stack {stack_name} exists, updating...")
                cfn.update_stack(
                    StackName=stack_name,
                    TemplateBody=template_body,
                    Parameters=parameters,
                    Capabilities=["CAPABILITY_IAM"],
                )
                waiter = cfn.get_waiter("stack_update_complete")
            else:
                logger.info(f"Creating new stack: {stack_name}")
                cfn.create_stack(
                    StackName=stack_name,
                    TemplateBody=template_body,
                    Parameters=parameters,
                    Capabilities=["CAPABILITY_IAM"],
                )
                waiter = cfn.get_waiter("stack_create_complete")
        except cfn.exceptions.ClientError as e:
            err_msg = (
                e.response["Error"]["Message"] if hasattr(e, "response") else str(e)
            )
            if "No updates are to be performed" in err_msg:
                logger.info(f"✓ Stack {stack_name} is already up to date")
                return
            else:
                raise

        logger.info("Waiting for stack operation to complete...")
        waiter.wait(StackName=stack_name)
        logger.info(f"✓ Stack {stack_name} deployed successfully")

        # Display outputs
        response = cfn.describe_stacks(StackName=stack_name)
        outputs = response["Stacks"][0].get("Outputs", [])
        if outputs:
            logger.info("\nStack Outputs:")
            for output in outputs:
                logger.info(f"  {output['OutputKey']}: {output['OutputValue']}")

    except Exception as e:
        logger.error(f"Failed to deploy stack: {e}")
        raise


def ensure_schedule_enabled(stack_name: str, region: str = "us-east-1") -> None:
    """Ensure the EventBridge schedule is enabled after deployment.

    CloudFormation won't re-enable a manually disabled schedule if no template
    changes are detected. This function explicitly enables the schedule.

    Args:
        stack_name: CloudFormation stack name (schedule name is derived from it)
        region: AWS region
    """
    scheduler = boto3.client("scheduler", region_name=region)
    schedule_name = f"{stack_name}-polling-schedule"

    try:
        schedule = scheduler.get_schedule(Name=schedule_name)
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "")
        if error_code == "ResourceNotFoundException":
            logger.warning(f"Schedule {schedule_name} not found (not yet created)")
            return
        raise

    if schedule.get("State") == "ENABLED":
        logger.info(f"✓ Schedule {schedule_name} is already enabled")
        return

    logger.info(f"Enabling schedule {schedule_name} (was {schedule.get('State')})...")
    scheduler.update_schedule(
        Name=schedule_name,
        ScheduleExpression=schedule["ScheduleExpression"],
        FlexibleTimeWindow=schedule["FlexibleTimeWindow"],
        Target=schedule["Target"],
        State="ENABLED",
    )
    logger.info(f"✓ Schedule {schedule_name} enabled")


def check_required_permissions(region: str = "us-east-1") -> bool:
    """Check if user has required permissions for deployment.

    Args:
        region: AWS region

    Returns:
        True if permissions are sufficient, False otherwise
    """
    import botocore.exceptions

    sts = boto3.client("sts", region_name=region)

    try:
        # Get current user identity
        identity = sts.get_caller_identity()
        logger.info(f"Checking permissions for: {identity['Arn']}")

        # List required permissions
        required_actions = [
            "scheduler:CreateSchedule",
            "scheduler:GetSchedule",
            "scheduler:UpdateSchedule",
            "scheduler:DeleteSchedule",
            "iam:CreateRole",
            "iam:PutRolePolicy",
            "cloudformation:CreateStack",
            "cloudformation:UpdateStack",
        ]

        logger.info("\nRequired IAM permissions for deployment:")
        for action in required_actions:
            logger.info(f"  - {action}")

        return True

    except botocore.exceptions.ClientError as e:
        logger.warning(f"Could not verify permissions: {e}")
        return True  # Continue anyway, let CloudFormation fail with better error


def main() -> None:
    """Main deployment entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Deploy EventBridge Scheduler for Arato polling mode"
    )
    parser.add_argument(
        "--stack-name",
        default="arato-agent-polling",
        help="CloudFormation stack name (default: arato-agent-polling)",
    )
    parser.add_argument(
        "--agentcore-arn",
        required=True,
        help="ARN of deployed AgentCore application",
    )
    parser.add_argument(
        "--schedule",
        default="rate(1 minute)",
        help="EventBridge schedule expression (default: rate(1 minute))",
    )
    parser.add_argument(
        "--parameter-prefix",
        default=None,
        help="SSM parameter prefix (default: /{agent_id}/polling from .bedrock_agentcore.yaml)",
    )
    parser.add_argument(
        "--api-key",
        required=True,
        help="Arato API key (stored securely in SSM)",
    )
    parser.add_argument(
        "--task-endpoint",
        required=True,
        help="Task polling endpoint URL",
    )
    parser.add_argument(
        "--polling-interval",
        type=int,
        default=30,
        help="Polling interval in seconds (default: 30)",
    )
    parser.add_argument(
        "--region",
        default="us-east-1",
        help="AWS region (default: us-east-1)",
    )

    args = parser.parse_args()

    try:
        # Get parameter prefix with agent ID if not provided
        parameter_prefix = args.parameter_prefix
        if parameter_prefix is None:
            agent_id = get_agent_id()
            parameter_prefix = f"/{agent_id}/polling"
            logger.info(f"Using agent ID from .bedrock_agentcore.yaml: {agent_id}")

        logger.info("=" * 60)
        logger.info("Arato Agent Polling Mode Deployment")
        logger.info("=" * 60)
        logger.info(f"Stack Name: {args.stack_name}")
        logger.info(f"AgentCore ARN: {args.agentcore_arn}")
        logger.info(f"Schedule: {args.schedule}")
        logger.info(f"Parameter Prefix: {parameter_prefix}")
        logger.info(f"Region: {args.region}")
        logger.info("")

        # Check required permissions
        check_required_permissions(args.region)
        logger.info("")

        # Step 1: Deploy SSM parameters
        deploy_ssm_parameters(
            parameter_prefix=parameter_prefix,
            api_key=args.api_key,
            task_endpoint=args.task_endpoint,
            polling_interval=args.polling_interval,
            region=args.region,
        )

        # Step 2: Load CloudFormation template
        template_body = load_cloudformation_template()

        # Step 3: Deploy CloudFormation stack
        deploy_cloudformation_stack(
            stack_name=args.stack_name,
            template_body=template_body,
            agentcore_arn=args.agentcore_arn,
            schedule_expression=args.schedule,
            parameter_prefix=parameter_prefix,
            region=args.region,
        )

        logger.info("")
        logger.info("=" * 60)
        logger.info("✓ Deployment Complete")
        logger.info("=" * 60)
        logger.info(
            f"EventBridge Scheduler is now running with schedule: {args.schedule}"
        )
        logger.info(
            f"To view logs: aws logs tail /aws/lambda/{args.stack_name}-poller --follow"
        )

    except Exception as e:
        logger.error(f"Deployment failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
