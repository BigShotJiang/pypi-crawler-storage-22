#!/usr/bin/env python3
"""Destroy EventBridge Scheduler and polling infrastructure.

This script removes AWS infrastructure for polling mode:
- EventBridge Scheduler rule
- IAM roles
- CloudFormation stack
- Optionally: SSM parameters
"""

import logging
import sys
from pathlib import Path

import boto3

# Add simulate-agent to path for utils
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "simulate-agent"))

from utils.bedrock_config import get_agent_id  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def delete_ssm_parameters(
    parameter_prefix: str,
    region: str = "us-east-1",
) -> None:
    """Delete SSM parameters for polling configuration.

    Args:
        parameter_prefix: SSM parameter prefix
        region: AWS region
    """
    ssm = boto3.client("ssm", region_name=region)

    parameter_names = [
        f"{parameter_prefix}/api_key",
        f"{parameter_prefix}/task_endpoint",
        f"{parameter_prefix}/polling_interval",
        f"{parameter_prefix}/circuit_breaker_threshold",
        f"{parameter_prefix}/circuit_breaker_timeout",
    ]

    logger.info(f"Deleting SSM parameters with prefix: {parameter_prefix}")
    for name in parameter_names:
        try:
            ssm.delete_parameter(Name=name)
            logger.info(f"  ✓ Deleted {name}")
        except ssm.exceptions.ParameterNotFound:
            logger.info(f"  ⊗ Parameter not found: {name}")
        except Exception as e:
            logger.error(f"  ✗ Failed to delete {name}: {e}")


def delete_lambda_function(
    function_name: str,
    region: str = "us-east-1",
) -> None:
    """Delete Lambda function if it exists.

    Args:
        function_name: Lambda function name
        region: AWS region
    """
    lambda_client = boto3.client("lambda", region_name=region)

    logger.info(f"Checking for Lambda function: {function_name}")

    try:
        lambda_client.get_function(FunctionName=function_name)
        logger.info(f"Found Lambda function, deleting: {function_name}")
        lambda_client.delete_function(FunctionName=function_name)
        logger.info(f"  ✓ Deleted Lambda function: {function_name}")
    except lambda_client.exceptions.ResourceNotFoundException:
        logger.info(f"  ⊗ Lambda function not found: {function_name}")
    except Exception as e:
        logger.error(f"  ✗ Failed to delete Lambda function: {e}")
        raise


def delete_cloudformation_stack(
    stack_name: str,
    region: str = "us-east-1",
) -> None:
    """Delete CloudFormation stack.

    Args:
        stack_name: Stack name
        region: AWS region
    """
    cfn = boto3.client("cloudformation", region_name=region)

    logger.info(f"Deleting CloudFormation stack: {stack_name}")

    try:
        cfn.delete_stack(StackName=stack_name)
        logger.info("Waiting for stack deletion to complete...")
        waiter = cfn.get_waiter("stack_delete_complete")
        waiter.wait(StackName=stack_name)
        logger.info(f"✓ Stack {stack_name} deleted successfully")

    except cfn.exceptions.ClientError as e:
        if "does not exist" in str(e):
            logger.warning(f"Stack {stack_name} does not exist")
        else:
            logger.error(f"Failed to delete stack: {e}")
            raise
    except Exception as e:
        logger.error(f"Failed to delete stack: {e}")
        raise


def main() -> None:
    """Main destruction entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Destroy EventBridge Scheduler for Arato polling mode"
    )
    parser.add_argument(
        "--stack-name",
        default="arato-agent-polling",
        help="CloudFormation stack name (default: arato-agent-polling)",
    )
    parser.add_argument(
        "--parameter-prefix",
        default=None,
        help="SSM parameter prefix (default: /{agent_id}/polling from .bedrock_agentcore.yaml)",
    )
    parser.add_argument(
        "--delete-parameters",
        action="store_true",
        help="Also delete SSM parameters",
    )
    parser.add_argument(
        "--region",
        default="us-east-1",
        help="AWS region (default: us-east-1)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Skip confirmation prompt",
    )

    args = parser.parse_args()

    try:
        # Get parameter prefix with agent ID if not provided
        parameter_prefix = args.parameter_prefix
        if parameter_prefix is None:
            agent_id = get_agent_id()
            parameter_prefix = f"/{agent_id}/polling"
            logger.info(f"Using agent ID from .bedrock_agentcore.yaml: {agent_id}")

        logger.info("=" * 60)
        logger.info("Arato Agent Polling Mode Cleanup")
        logger.info("=" * 60)
        logger.info(f"Stack Name: {args.stack_name}")
        logger.info(f"Region: {args.region}")
        if args.delete_parameters:
            logger.info(f"Parameter Prefix: {parameter_prefix}")
        logger.info("")

        if not args.force:
            response = input("Are you sure you want to proceed? (yes/no): ")
            if response.lower() != "yes":
                logger.info("Aborted.")
                sys.exit(0)

        # Step 1: Delete CloudFormation stack
        delete_cloudformation_stack(
            stack_name=args.stack_name,
            region=args.region,
        )

        # Step 2: Clean up orphaned Lambda function (in case stack was already deleted)
        logger.info("")
        lambda_function_name = f"{args.stack_name}-poller"
        delete_lambda_function(
            function_name=lambda_function_name,
            region=args.region,
        )

        # Step 3: Optionally delete SSM parameters
        if args.delete_parameters:
            logger.info("")
            delete_ssm_parameters(
                parameter_prefix=parameter_prefix,
                region=args.region,
            )

        logger.info("")
        logger.info("=" * 60)
        logger.info("✓ Destruction Complete")
        logger.info("=" * 60)

    except Exception as e:
        logger.error(f"Destruction failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
