"""DevOps utilities for Arato Agent infrastructure management.

This module provides utilities for:
- Setting up reports infrastructure (S3, CloudFront, Route53)
- Syncing report folders to S3 with CloudFront invalidation
- Managing Lambda@Edge authentication
"""

from scripts.devops.cli import main

__all__ = ["main"]
