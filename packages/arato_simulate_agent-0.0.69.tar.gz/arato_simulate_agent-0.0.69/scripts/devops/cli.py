"""CLI entry point for devops utilities.

This module provides a unified CLI interface for all DevOps commands,
using a plugin architecture for extensibility.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING

# Add simulate-agent to path for shared constants
_project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(_project_root / "simulate-agent"))

if TYPE_CHECKING:
    from scripts.devops.commands.base import PluginRegistry

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s",
)
logger = logging.getLogger(__name__)


def main() -> None:
    """Main entry point for devops CLI."""
    from scripts.devops.commands import register_all_plugins, registry

    # Register all command plugins
    register_all_plugins()

    parser = argparse.ArgumentParser(
        description="DevOps utilities for Arato Agent infrastructure",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=_build_epilog(registry),
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Add interactive command
    subparsers.add_parser(
        "interactive",
        help="Launch interactive TUI (default when no command given)",
    )

    # Add all registered plugin commands
    for plugin in registry.all():
        plugin.add_subparser(subparsers)

    args = parser.parse_args()

    # Default to interactive mode if no command given
    if not args.command:
        from scripts.devops.interactive import run_interactive

        run_interactive()
        return

    try:
        if args.command == "interactive":
            from scripts.devops.interactive import run_interactive

            run_interactive()
        else:
            # Dispatch to plugin handler
            plugin = registry.get(args.command)
            if plugin:
                plugin.handle(args)
            else:
                logger.error(f"Unknown command: {args.command}")
                sys.exit(1)
    except KeyboardInterrupt:
        logger.info("\nAborted.")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Command failed: {e}")
        sys.exit(1)


def _build_epilog(_registry: PluginRegistry) -> str:
    """Build the help epilog with examples for registered commands."""
    return """
Examples:
  # Interactive Mode (recommended)
  uv run devops                          # Launch interactive TUI
  uv run devops interactive              # Same as above
  uv run devops serve                    # Launch TUI in web browser

  # Reports Infrastructure
  uv run devops setup --dry-run          # Check what would be created
  uv run devops setup                    # Create S3, CloudFront, Route53
  uv run devops sync sessions/xxx        # Sync folder to S3

  # AgentCore Management
  uv run devops agentcore configure      # Configure VPC, IAM, credentials
  uv run devops agentcore launch         # Build and deploy container
  uv run devops agentcore status         # Check deployment status
  uv run devops agentcore destroy        # Remove deployment

  # Polling Mode
  uv run devops polling deploy --agentcore-arn ARN --api-key KEY --task-endpoint URL
  uv run devops polling destroy --force

  # Documentation
  uv run devops guide                    # View all documentation
  uv run devops guide google-oauth       # Google OAuth setup guide
"""


if __name__ == "__main__":
    main()
