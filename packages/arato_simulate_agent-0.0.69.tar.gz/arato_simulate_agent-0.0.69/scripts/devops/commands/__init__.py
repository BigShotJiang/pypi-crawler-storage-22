"""DevOps command plugins.

Each command module provides:
- CLI argument parser configuration
- Command handler function
- TUI screen class (optional)
- Help/documentation text
"""

from scripts.devops.commands.base import (
    CommandPlugin,
    PluginRegistry,
    register_all_plugins,
    registry,
)

__all__ = [
    "CommandPlugin",
    "PluginRegistry",
    "register_all_plugins",
    "registry",
]
