"""AgentCore deployment and management commands."""

import logging
import sys
from argparse import ArgumentParser, Namespace

from scripts.devops.commands.base import CommandPlugin

logger = logging.getLogger(__name__)


class AgentCoreCommand(CommandPlugin):
    """AgentCore deployment and management."""

    @property
    def name(self) -> str:
        return "agentcore"

    @property
    def description(self) -> str:
        return "AgentCore deployment and management commands"

    @property
    def icon(self) -> str:
        return "🤖"

    @property
    def menu_description(self) -> str:
        return "Deploy and manage AgentCore application"

    def add_arguments(self, parser: ArgumentParser) -> None:
        subparsers = parser.add_subparsers(
            dest="agentcore_command",
            help="AgentCore commands",
        )

        # Configure
        configure_parser = subparsers.add_parser(
            "configure",
            help="Configure AgentCore deployment (VPC, IAM, credentials)",
        )
        configure_parser.add_argument(
            "--force-google-auth",
            action="store_true",
            help="Force update of Google credentials even if cached",
        )

        # Launch
        subparsers.add_parser(
            "launch",
            help="Build and deploy AgentCore container",
        )

        # Status
        subparsers.add_parser(
            "status",
            help="Check AgentCore deployment status",
        )

        # Destroy
        subparsers.add_parser(
            "destroy",
            help="Remove AgentCore deployment",
        )

    def handle(self, args: Namespace) -> None:
        from platforms.aws_agentcore.scripts import agentcore_deploy

        if not hasattr(args, "agentcore_command") or not args.agentcore_command:
            logger.error(
                "No agentcore command specified. Use: configure, launch, status, destroy"
            )
            sys.exit(1)

        if args.agentcore_command == "configure":
            if hasattr(args, "force_google_auth") and args.force_google_auth:
                sys.argv = ["agentcore-configure", "--force-google-auth"]
            else:
                sys.argv = ["agentcore-configure"]
            agentcore_deploy.configure()
        elif args.agentcore_command == "launch":
            agentcore_deploy.launch()
        elif args.agentcore_command == "status":
            agentcore_deploy.status()
        elif args.agentcore_command == "destroy":
            agentcore_deploy.destroy()

    def get_help_content(self) -> str:
        return """# AgentCore Commands

## Overview

AgentCore is the AWS Bedrock deployment platform for the Arato Agent.
These commands help you configure, deploy, and manage your AgentCore instance.

## Commands

### Configure

Sets up the AWS environment for AgentCore:
- VPC endpoints for AWS services
- IAM roles and permissions
- Google Cloud credentials for Vertex AI

```bash
uv run devops agentcore configure

# Force update of Google credentials
uv run devops agentcore configure --force-google-auth
```

### Launch

Builds and deploys the AgentCore container:

```bash
uv run devops agentcore launch
```

This command:
1. Exports requirements from pyproject.toml
2. Builds the Docker container
3. Pushes to ECR
4. Deploys to Bedrock AgentCore

### Status

Check the current deployment status:

```bash
uv run devops agentcore status
```

### Destroy

Remove the AgentCore deployment:

```bash
uv run devops agentcore destroy
```

⚠️ **Warning**: This permanently removes your deployment!

## Prerequisites

- AWS CLI configured with appropriate credentials
- Docker installed and running
- VPC with required endpoints (created during configure)
"""
