"""App server deployment and management commands."""

import logging
import sys
from argparse import ArgumentParser, Namespace

from scripts.devops.commands.base import CommandPlugin

logger = logging.getLogger(__name__)


class AppServerCommand(CommandPlugin):
    """App server deployment and management on ECS/Fargate."""

    @property
    def name(self) -> str:
        return "app-server"

    @property
    def description(self) -> str:
        return "Deploy and manage the app server on ECS/Fargate"

    @property
    def icon(self) -> str:
        return "🖥️"

    @property
    def menu_description(self) -> str:
        return "Deploy and manage app server (ECS/Fargate + Aurora)"

    def add_arguments(self, parser: ArgumentParser) -> None:
        subparsers = parser.add_subparsers(
            dest="app_server_command",
            help="App server commands",
        )

        # Configure (deploy CloudFormation infrastructure)
        configure_parser = subparsers.add_parser(
            "configure",
            help="Deploy CloudFormation infrastructure (ECS cluster, ALB, Aurora, ECR)",
        )
        configure_parser.add_argument(
            "--stack-name",
            default="arato-app-server",
            help="CloudFormation stack name (default: arato-app-server)",
        )
        configure_parser.add_argument(
            "--region",
            default="us-east-1",
            help="AWS region (default: us-east-1)",
        )
        configure_parser.add_argument(
            "--vpc-id",
            help="VPC ID (auto-detected if not specified)",
        )
        configure_parser.add_argument(
            "--subnet-ids",
            help="Comma-separated subnet IDs (auto-detected if not specified)",
        )
        configure_parser.add_argument(
            "--db-name",
            default="arato",
            help="Aurora database name (default: arato)",
        )

        # Deploy (build, push, update service)
        deploy_parser = subparsers.add_parser(
            "deploy",
            help="Build Docker image, push to ECR, update ECS service, run migrations",
        )
        deploy_parser.add_argument(
            "--stack-name",
            default="arato-app-server",
            help="CloudFormation stack name (default: arato-app-server)",
        )
        deploy_parser.add_argument(
            "--region",
            default="us-east-1",
            help="AWS region (default: us-east-1)",
        )
        deploy_parser.add_argument(
            "--skip-build",
            action="store_true",
            help="Skip Docker build (use existing image)",
        )
        deploy_parser.add_argument(
            "--skip-migrations",
            action="store_true",
            help="Skip Prisma database migrations",
        )
        deploy_parser.add_argument(
            "--health-url",
            help="URL for post-deploy health check (default: ALB /health)",
        )

        # Status
        status_parser = subparsers.add_parser(
            "status",
            help="Check CloudFormation stack and ECS service status",
        )
        status_parser.add_argument(
            "--stack-name",
            default="arato-app-server",
            help="CloudFormation stack name (default: arato-app-server)",
        )
        status_parser.add_argument(
            "--region",
            default="us-east-1",
            help="AWS region (default: us-east-1)",
        )

        # Destroy
        destroy_parser = subparsers.add_parser(
            "destroy",
            help="Remove CloudFormation stack and all resources",
        )
        destroy_parser.add_argument(
            "--stack-name",
            default="arato-app-server",
            help="CloudFormation stack name (default: arato-app-server)",
        )
        destroy_parser.add_argument(
            "--region",
            default="us-east-1",
            help="AWS region (default: us-east-1)",
        )
        destroy_parser.add_argument(
            "--force",
            action="store_true",
            help="Skip confirmation prompt",
        )

    def handle(self, args: Namespace) -> None:
        if not hasattr(args, "app_server_command") or not args.app_server_command:
            logger.error(
                "No app-server command specified. Use: configure, deploy, status, destroy"
            )
            sys.exit(1)

        from scripts.deploy_app_server import (
            deploy_service,
            deploy_stack,
            destroy_stack,
            get_stack_status,
        )

        if args.app_server_command == "configure":
            deploy_stack(
                stack_name=args.stack_name,
                region=args.region,
                vpc_id=args.vpc_id,
                subnet_ids=args.subnet_ids,
                db_name=args.db_name,
            )
        elif args.app_server_command == "deploy":
            deploy_service(
                stack_name=args.stack_name,
                region=args.region,
                skip_build=args.skip_build,
                skip_migrations=args.skip_migrations,
                health_url=getattr(args, "health_url", None),
            )
        elif args.app_server_command == "status":
            get_stack_status(
                stack_name=args.stack_name,
                region=args.region,
            )
        elif args.app_server_command == "destroy":
            if not args.force:
                response = input(
                    "Are you sure you want to destroy the app server infrastructure? (yes/no): "
                )
                if response.lower() != "yes":
                    logger.info("Aborted.")
                    return
            destroy_stack(
                stack_name=args.stack_name,
                region=args.region,
            )

    def get_help_content(self) -> str:
        return """# App Server Commands

## Overview

Deploy and manage the Arato app server on AWS ECS/Fargate with Aurora PostgreSQL.

## Commands

### Configure

Deploy the CloudFormation infrastructure stack (ECS cluster, ALB, Aurora, ECR):

```bash
uv run devops app-server configure
uv run devops app-server configure --stack-name my-stack --region us-west-2
```

### Deploy

Build Docker image, push to ECR, update ECS service, and run Prisma migrations:

```bash
uv run devops app-server deploy
uv run devops app-server deploy --skip-build    # Redeploy existing image
uv run devops app-server deploy --skip-migrations
```

### Status

Check CloudFormation stack and ECS service status:

```bash
uv run devops app-server status
```

### Destroy

Remove all infrastructure:

```bash
uv run devops app-server destroy --force
```

## Prerequisites

- AWS CLI configured with appropriate credentials
- Docker installed and running
- VPC with at least 2 subnets in different AZs
"""
