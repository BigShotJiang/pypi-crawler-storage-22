"""Base classes for DevOps command plugins."""

from abc import ABC, abstractmethod
from argparse import ArgumentParser, Namespace, _SubParsersAction
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from textual.screen import Screen


class CommandPlugin(ABC):
    """Base class for DevOps command plugins.

    Each plugin provides:
    - name: Command name for CLI
    - description: Short description for help text
    - add_arguments: Configure CLI argument parser
    - handle: Execute the command
    - get_tui_screen: Return a TUI screen for interactive mode (optional)
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Command name (used in CLI: `devops <name>`)."""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """Short description for CLI help."""
        ...

    @property
    def icon(self) -> str:
        """Emoji icon for TUI menu."""
        return "📦"

    @property
    def menu_label(self) -> str:
        """Label for TUI main menu."""
        return f"{self.icon} {self.name.title()}"

    @property
    def menu_description(self) -> str:
        """Description shown in TUI menu."""
        return self.description

    @abstractmethod
    def add_arguments(self, parser: ArgumentParser) -> None:
        """Add command-specific arguments to the parser.

        Override this to add arguments for your command.
        """
        pass

    def add_subparser(self, subparsers: _SubParsersAction) -> ArgumentParser:
        """Add this command to the subparsers.

        Returns the created parser for further customization.
        """
        parser = subparsers.add_parser(self.name, help=self.description)
        self.add_arguments(parser)
        return parser

    @abstractmethod
    def handle(self, args: Namespace) -> None:
        """Execute the command with parsed arguments."""
        ...

    def get_tui_screen(self) -> "Screen | None":
        """Return a TUI screen for interactive mode.

        Override this to provide an interactive screen.
        Returns None if no TUI screen is available.
        """
        return None

    def get_help_content(self) -> str:
        """Return detailed help/documentation content as markdown.

        Override this to provide detailed documentation.
        """
        return f"# {self.name.title()}\n\n{self.description}"


class PluginRegistry:
    """Registry for command plugins."""

    def __init__(self):
        self._plugins: dict[str, CommandPlugin] = {}
        self._order: list[str] = []

    def register(self, plugin: CommandPlugin) -> None:
        """Register a command plugin."""
        self._plugins[plugin.name] = plugin
        if plugin.name not in self._order:
            self._order.append(plugin.name)

    def get(self, name: str) -> CommandPlugin | None:
        """Get a plugin by name."""
        return self._plugins.get(name)

    def all(self) -> list[CommandPlugin]:
        """Get all registered plugins in order."""
        return [self._plugins[name] for name in self._order if name in self._plugins]

    def names(self) -> list[str]:
        """Get all registered plugin names in order."""
        return [name for name in self._order if name in self._plugins]


# Global registry instance
registry = PluginRegistry()


def register_all_plugins() -> None:
    """Register all built-in command plugins."""
    # Import plugins directly as modules
    from scripts.devops.commands.agentcore import AgentCoreCommand
    from scripts.devops.commands.app_server import AppServerCommand
    from scripts.devops.commands.guide import GuideCommand
    from scripts.devops.commands.polling import PollingCommand
    from scripts.devops.commands.setup import SetupCommand
    from scripts.devops.commands.sync import SyncCommand

    # Register in desired menu order
    registry.register(SetupCommand())
    registry.register(SyncCommand())
    registry.register(AgentCoreCommand())
    registry.register(AppServerCommand())
    registry.register(PollingCommand())
    registry.register(GuideCommand())
