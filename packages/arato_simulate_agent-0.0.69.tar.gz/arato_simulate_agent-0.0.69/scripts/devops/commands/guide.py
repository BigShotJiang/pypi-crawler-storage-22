"""Guide command - Interactive documentation and setup guides."""

from argparse import ArgumentParser, Namespace

from scripts.devops.commands.base import CommandPlugin


class GuideCommand(CommandPlugin):
    """Interactive documentation and setup guides."""

    @property
    def name(self) -> str:
        return "guide"

    @property
    def description(self) -> str:
        return "Interactive documentation and setup guides"

    @property
    def icon(self) -> str:
        return "📖"

    @property
    def menu_description(self) -> str:
        return "View documentation and setup guides"

    def add_arguments(self, parser: ArgumentParser) -> None:
        parser.add_argument(
            "topic",
            nargs="?",
            choices=["google-oauth", "lambda-edge", "infrastructure", "all"],
            default="all",
            help="Topic to display (default: all)",
        )

    def handle(self, args: Namespace) -> None:
        topic = args.topic or "all"
        content = self._get_content(topic)
        print(content)

    def _get_content(self, topic: str) -> str:
        if topic == "google-oauth":
            return GOOGLE_OAUTH_GUIDE
        elif topic == "lambda-edge":
            return LAMBDA_EDGE_GUIDE
        elif topic == "infrastructure":
            return INFRASTRUCTURE_GUIDE
        else:
            return (
                f"{INFRASTRUCTURE_GUIDE}\n\n{GOOGLE_OAUTH_GUIDE}\n\n{LAMBDA_EDGE_GUIDE}"
            )

    def get_help_content(self) -> str:
        return f"""# Documentation & Guides

Welcome to the Arato DevOps documentation!

## Available Topics

1. **Infrastructure Overview** - How the reports hosting works
2. **Google OAuth Setup** - Configure Google Cloud for authentication
3. **Lambda@Edge Auth** - How authentication is deployed

---

{INFRASTRUCTURE_GUIDE}

---

{GOOGLE_OAUTH_GUIDE}

---

{LAMBDA_EDGE_GUIDE}
"""


# =============================================================================
# Guide Content
# =============================================================================

INFRASTRUCTURE_GUIDE = """# Infrastructure Overview

## Architecture

The Arato reports hosting infrastructure consists of:

```
┌─────────────────────────────────────────────────────────────────┐
│                        CloudFront CDN                            │
│  ┌─────────────────┐    ┌─────────────────┐                     │
│  │  Lambda@Edge    │    │   Origin Access  │                     │
│  │  (Google OAuth) │    │   Control (OAC)  │                     │
│  └────────┬────────┘    └────────┬─────────┘                     │
└───────────┼──────────────────────┼───────────────────────────────┘
            │                      │
            ▼                      ▼
┌───────────────────────────────────────────────────────────────────┐
│                         S3 Bucket                                  │
│  ┌─────────────────────────────────────────────────────────────┐  │
│  │ sessions/                                                    │  │
│  │   └── conversation_20250101_120000/                         │  │
│  │       ├── index.html          (Report dashboard)            │  │
│  │       ├── report_data.json    (Report data)                 │  │
│  │       ├── transcript.json     (Conversation logs)           │  │
│  │       └── run.mp4            (Video recording)              │  │
│  └─────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────────────┘
            │
            ▼
┌───────────────────────────────────────────────────────────────────┐
│  Route53 DNS (if custom domain)                                   │
│  reports.example.com → CloudFront Distribution                    │
└───────────────────────────────────────────────────────────────────┘
```

## Components

### S3 Bucket
- Stores all report files (HTML, JSON, videos, etc.)
- Private bucket (not publicly accessible)
- Access controlled via CloudFront OAC

### CloudFront Distribution
- Global CDN for fast delivery
- HTTPS with managed SSL certificate
- Custom error responses for SPA routing

### Route53 (Optional)
- Maps your custom domain to CloudFront
- Requires a hosted zone for your domain

### Lambda@Edge (Optional)
- Google OAuth authentication
- Runs at CloudFront edge locations
- Restricts access to specific email domains

## Security

- All traffic is HTTPS (HTTP redirected)
- S3 bucket blocks all public access
- CloudFront uses Origin Access Control (OAC)
- Optional: Google OAuth restricts to specific domains
"""

GOOGLE_OAUTH_GUIDE = """# Google OAuth Setup Guide

This guide explains how to set up Google OAuth for protecting your reports
with email-based authentication.

## Overview

When configured, users must sign in with their Google account to view reports.
Only users with email addresses from allowed domains can access the content.

## Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Click **Select a project** → **New Project**
3. Enter a project name (e.g., "Arato Reports Auth")
4. Click **Create**

## Step 2: Configure OAuth Consent Screen

1. Navigate to **APIs & Services** → **OAuth consent screen**
2. Select **External** user type (or Internal if using Google Workspace)
3. Click **Create**

### Fill in the form:

- **App name**: Arato Reports
- **User support email**: Your email
- **App logo**: (Optional)
- **App domain**: Your reports domain (e.g., reports.example.com)
- **Authorized domains**: Your domain (e.g., example.com)
- **Developer contact**: Your email

4. Click **Save and Continue**

### Scopes:

1. Click **Add or Remove Scopes**
2. Select:
   - `openid`
   - `email`
   - `profile`
3. Click **Update** → **Save and Continue**

### Test Users (External only):

- Add test email addresses during development
- After publishing, all users with allowed domains can access

## Step 3: Create OAuth Credentials

1. Navigate to **APIs & Services** → **Credentials**
2. Click **Create Credentials** → **OAuth client ID**
3. Select **Web application**

### Configure:

- **Name**: Arato Reports Auth
- **Authorized JavaScript origins**:
  - `https://your-cloudfront-domain.cloudfront.net`
  - `https://reports.example.com` (if using custom domain)
- **Authorized redirect URIs**:
  - `https://your-cloudfront-domain.cloudfront.net/_auth/callback`
  - `https://reports.example.com/_auth/callback` (if using custom domain)

4. Click **Create**
5. **Save the Client ID and Client Secret** - you'll need these!

## Step 4: Deploy with OAuth

Run the setup command with your OAuth credentials:

```bash
uv run devops setup \\
  --google-client-id "YOUR_CLIENT_ID.apps.googleusercontent.com" \\
  --google-client-secret "YOUR_CLIENT_SECRET" \\
  --allowed-domains "example.com,company.org"
```

### Parameters:

- **--google-client-id**: The Client ID from Google Cloud Console
- **--google-client-secret**: The Client Secret (keep this secure!)
- **--allowed-domains**: Comma-separated list of email domains allowed to access

## Step 5: Verify Setup

1. Open your reports URL in an incognito window
2. You should be redirected to Google sign-in
3. Sign in with an account from an allowed domain
4. You should be redirected back to the reports

## Updating OAuth Settings

To update OAuth credentials or allowed domains:

1. Run setup again with the new values
2. The Lambda@Edge function will be updated
3. CloudFront will deploy the new version (takes a few minutes)

## Troubleshooting

### "redirect_uri_mismatch" Error

- Ensure the callback URL is exactly:
  `https://YOUR_DOMAIN/_auth/callback`
- Check for trailing slashes or typos
- Wait 5 minutes after adding URIs (Google caches)

### "Email domain not allowed"

- Check `--allowed-domains` setting
- Ensure the email domain matches exactly (case-insensitive)

### Can't Sign In

- Ensure the user is added as a test user (if app is in testing mode)
- Or publish the OAuth app for production use

## Security Best Practices

1. **Never commit secrets**: Don't store Client Secret in code
2. **Use environment variables**: Pass secrets via CLI or env vars
3. **Rotate secrets regularly**: Create new credentials periodically
4. **Limit domains**: Only allow necessary email domains
5. **Monitor access**: Check CloudWatch logs for authentication events
"""

LAMBDA_EDGE_GUIDE = """# Lambda@Edge Authentication

## How It Works

Lambda@Edge runs your authentication code at CloudFront edge locations
worldwide, providing fast, secure authentication close to your users.

```
User Request                    Edge Location
    │                               │
    ▼                               ▼
┌───────┐                    ┌──────────────┐
│Browser│ ──── HTTPS ────▶  │ CloudFront   │
└───────┘                    │    Edge      │
    ▲                        │   ┌──────┐   │
    │                        │   │Lambda│   │
    │                        │   │@Edge │   │
    │                        │   └──┬───┘   │
    │                        └─────┼────────┘
    │                              │
    │    ┌─────────────────────────┘
    │    │
    │    ▼
    │  Authenticated? ──No──▶ Redirect to Google
    │    │
    │   Yes
    │    │
    │    ▼
    └── Return Content from S3
```

## Authentication Flow

1. **Request arrives** at CloudFront edge
2. **Lambda@Edge intercepts** viewer-request event
3. **Check for auth cookie**:
   - If valid → Allow request through to S3
   - If missing/invalid → Redirect to Google OAuth
4. **OAuth callback**:
   - Exchange code for token
   - Verify email domain
   - Set signed auth cookie
   - Redirect to original URL
5. **Subsequent requests**:
   - Cookie validated at edge
   - No Google roundtrip needed

## Cookie Security

The authentication cookie is:

- **Signed**: HMAC-SHA256 prevents tampering
- **HttpOnly**: Not accessible to JavaScript
- **Secure**: Only sent over HTTPS
- **SameSite=Lax**: CSRF protection
- **24-hour expiry**: Automatic re-authentication

## Lambda Function Details

The Lambda@Edge function:

- **Runtime**: Python 3.12
- **Memory**: 128 MB
- **Timeout**: 5 seconds
- **Region**: us-east-1 (required for Lambda@Edge)

### Code Location

The function code is generated dynamically during setup:
- Template: `scripts/devops/services/lambda_edge_code.py`
- Credentials injected at deployment time
- Versioned for CloudFront compatibility

## Monitoring

### CloudWatch Logs

Lambda@Edge logs are stored in the region closest to where the function executed:

```bash
# List log groups (check multiple regions)
aws logs describe-log-groups \\
  --log-group-name-prefix "/aws/lambda/us-east-1.arato-agent-reports-auth" \\
  --region us-east-1
```

### Metrics

Monitor these CloudWatch metrics:

- **Invocations**: Total auth checks
- **Errors**: Authentication failures
- **Duration**: Response time impact

## Updating the Function

When you change OAuth settings:

1. Setup command creates new function version
2. CloudFront distribution is updated
3. New version propagates globally (~5-15 minutes)

## Removing Authentication

To remove OAuth protection:

1. Run setup without OAuth parameters
2. Or manually:
   - Remove Lambda association from CloudFront
   - Delete the Lambda function
   - Delete the IAM role

```bash
# Remove Lambda association
aws cloudfront get-distribution-config --id DIST_ID > config.json
# Edit config.json to remove LambdaFunctionAssociations
aws cloudfront update-distribution --id DIST_ID --distribution-config file://config.json

# Delete Lambda function (all versions)
aws lambda delete-function --function-name arato-agent-reports-auth --region us-east-1
```

## Troubleshooting

### 502 Bad Gateway

- Check Lambda function logs
- Verify function timeout is sufficient
- Check memory allocation

### Cookie Not Setting

- Verify HTTPS is being used
- Check for cookie consent issues
- Verify domain configuration

### Slow Initial Load

- First request to each edge location is cold start
- Subsequent requests are fast (warm Lambda)
- Consider using provisioned concurrency for high traffic
"""
