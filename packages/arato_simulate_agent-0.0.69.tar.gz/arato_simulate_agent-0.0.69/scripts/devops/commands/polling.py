"""Polling mode deployment commands."""

import logging
import sys
from argparse import ArgumentParser, Namespace

from scripts.devops.commands.base import CommandPlugin

logger = logging.getLogger(__name__)


class PollingCommand(CommandPlugin):
    """Polling mode deployment and management."""

    @property
    def name(self) -> str:
        return "polling"

    @property
    def description(self) -> str:
        return "Polling mode deployment commands"

    @property
    def icon(self) -> str:
        return "⏱️"

    @property
    def menu_description(self) -> str:
        return "Configure behind-firewall polling mode"

    def add_arguments(self, parser: ArgumentParser) -> None:
        subparsers = parser.add_subparsers(
            dest="polling_command",
            help="Polling commands",
        )

        # Deploy
        deploy_parser = subparsers.add_parser(
            "deploy",
            help="Deploy EventBridge Scheduler for polling mode",
        )
        deploy_parser.add_argument(
            "--stack-name",
            default="arato-agent-polling",
            help="CloudFormation stack name (default: arato-agent-polling)",
        )
        deploy_parser.add_argument(
            "--agentcore-arn",
            default=None,
            help="ARN of deployed AgentCore application (auto-discovered from SSM if omitted)",
        )
        deploy_parser.add_argument(
            "--schedule",
            default="rate(1 minute)",
            help="EventBridge schedule expression (default: rate(1 minute))",
        )
        deploy_parser.add_argument(
            "--parameter-prefix",
            default=None,
            help="SSM parameter prefix (default: /{agent_id}/polling from .bedrock_agentcore.yaml)",
        )
        deploy_parser.add_argument(
            "--api-key",
            required=True,
            help="Arato API key (stored securely in SSM)",
        )
        deploy_parser.add_argument(
            "--task-endpoint",
            required=True,
            help="Task polling endpoint URL",
        )
        deploy_parser.add_argument(
            "--polling-interval",
            type=int,
            default=30,
            help="Polling interval in seconds (default: 30)",
        )
        deploy_parser.add_argument(
            "--region",
            default="us-east-1",
            help="AWS region (default: us-east-1)",
        )

        # Destroy
        destroy_parser = subparsers.add_parser(
            "destroy",
            help="Remove polling infrastructure",
        )
        destroy_parser.add_argument(
            "--stack-name",
            default="arato-agent-polling",
            help="CloudFormation stack name (default: arato-agent-polling)",
        )
        destroy_parser.add_argument(
            "--parameter-prefix",
            default=None,
            help="SSM parameter prefix (default: /{agent_id}/polling from .bedrock_agentcore.yaml)",
        )
        destroy_parser.add_argument(
            "--delete-parameters",
            action="store_true",
            help="Also delete SSM parameters",
        )
        destroy_parser.add_argument(
            "--region",
            default="us-east-1",
            help="AWS region (default: us-east-1)",
        )
        destroy_parser.add_argument(
            "--force",
            action="store_true",
            help="Skip confirmation prompt",
        )

    def handle(self, args: Namespace) -> None:
        if not hasattr(args, "polling_command") or not args.polling_command:
            logger.error("No polling command specified. Use: deploy, destroy")
            sys.exit(1)

        if args.polling_command == "deploy":
            self._handle_deploy(args)
        elif args.polling_command == "destroy":
            self._handle_destroy(args)

    def _handle_deploy(self, args: Namespace) -> None:
        from scripts.deploy_polling_scheduler import (
            check_required_permissions,
            deploy_cloudformation_stack,
            deploy_ssm_parameters,
            ensure_schedule_enabled,
            load_cloudformation_template,
        )
        from utils.bedrock_config import get_agent_arn, get_agent_id

        # Auto-discover agentcore ARN from SSM if not provided
        agentcore_arn = args.agentcore_arn
        if agentcore_arn is None:
            agentcore_arn = get_agent_arn(region=args.region)
            logger.info(f"Auto-discovered AgentCore ARN from SSM: {agentcore_arn}")

        parameter_prefix = args.parameter_prefix
        if parameter_prefix is None:
            agent_id = get_agent_id(region=args.region)
            parameter_prefix = f"/{agent_id}/polling"
            logger.info(f"Auto-discovered agent ID: {agent_id}")

        logger.info("=" * 60)
        logger.info("Arato Agent Polling Mode Deployment")
        logger.info("=" * 60)
        logger.info(f"Stack Name: {args.stack_name}")
        logger.info(f"AgentCore ARN: {agentcore_arn}")
        logger.info(f"Schedule: {args.schedule}")
        logger.info(f"Parameter Prefix: {parameter_prefix}")
        logger.info(f"Region: {args.region}")
        logger.info("")

        check_required_permissions(args.region)
        logger.info("")

        deploy_ssm_parameters(
            parameter_prefix=parameter_prefix,
            api_key=args.api_key,
            task_endpoint=args.task_endpoint,
            polling_interval=args.polling_interval,
            region=args.region,
        )
        logger.info("")

        template_body = load_cloudformation_template()
        deploy_cloudformation_stack(
            stack_name=args.stack_name,
            template_body=template_body,
            agentcore_arn=agentcore_arn,
            schedule_expression=args.schedule,
            parameter_prefix=parameter_prefix,
            region=args.region,
        )

        # Ensure the schedule is enabled (CloudFormation won't re-enable
        # a manually disabled schedule if no template changes are detected)
        ensure_schedule_enabled(
            stack_name=args.stack_name,
            region=args.region,
        )

        logger.info("")
        logger.info("✅ Polling mode deployment complete!")

    def _handle_destroy(self, args: Namespace) -> None:
        from scripts.destroy_polling_scheduler import (
            delete_cloudformation_stack,
            delete_lambda_function,
            delete_ssm_parameters,
        )
        from utils.bedrock_config import get_agent_id

        parameter_prefix = args.parameter_prefix
        if parameter_prefix is None:
            agent_id = get_agent_id()
            parameter_prefix = f"/{agent_id}/polling"
            logger.info(f"Using agent ID from .bedrock_agentcore.yaml: {agent_id}")

        logger.info("=" * 60)
        logger.info("Arato Agent Polling Mode Cleanup")
        logger.info("=" * 60)
        logger.info(f"Stack Name: {args.stack_name}")
        logger.info(f"Region: {args.region}")
        if args.delete_parameters:
            logger.info(f"Parameter Prefix: {parameter_prefix}")
        logger.info("")

        if not args.force:
            if not sys.stdin.isatty():
                logger.error(
                    "Cannot prompt for confirmation because stdin is not a TTY. "
                    "Re-run the command with --force to proceed in non-interactive environments."
                )
                sys.exit(1)
            response = input("Are you sure you want to proceed? (yes/no): ")
            if response.lower() != "yes":
                logger.info("Aborted.")
                sys.exit(0)

        delete_cloudformation_stack(
            stack_name=args.stack_name,
            region=args.region,
        )

        logger.info("")
        lambda_function_name = f"{args.stack_name}-poller"
        delete_lambda_function(
            function_name=lambda_function_name,
            region=args.region,
        )

        if args.delete_parameters:
            logger.info("")
            delete_ssm_parameters(
                parameter_prefix=parameter_prefix,
                region=args.region,
            )

        logger.info("")
        logger.info("✅ Polling mode cleanup complete!")

    def get_help_content(self) -> str:
        return """# Polling Mode Commands

## Overview

Polling mode enables the agent to run behind firewalls by polling a
control server for tasks instead of receiving direct invocations.

## Architecture

```
Control Server (Arato API)          │  Firewall/Private Network
                                    │
GET  /task          ←───────────────┼─── AWS Lambda (Scheduler)
                                    │     Invokes AgentCore
POST /log           ←───────────────┼─── Real-time logging
```

## Deploy

```bash
uv run devops polling deploy \\
  --agentcore-arn arn:aws:bedrock-agentcore:us-east-1:ACCOUNT:runtime/arato_agent-ID \\
  --api-key "your-api-key" \\
  --task-endpoint "https://api.example.com/task"
```

### Required Options

- **--agentcore-arn**: ARN of your deployed AgentCore
- **--api-key**: API key for authentication (stored in SSM)
- **--task-endpoint**: URL to poll for tasks

### Optional Settings

- **--schedule**: Polling frequency (default: "rate(5 minutes)")
- **--polling-interval**: Interval in seconds (default: 30)
- **--stack-name**: CloudFormation stack name

## Destroy

```bash
# Remove infrastructure (keeps SSM parameters)
uv run devops polling destroy --force

# Also delete SSM parameters
uv run devops polling destroy --force --delete-parameters
```

## Task Payload Format

Your control server should return:

```json
{
  "task_id": "test-task-001",
  "target_url": "https://example.com/chat",
  "persona_ids": ["malicious_user:5"],
  "max_turns": 10
}
```

Return HTTP 204 when no tasks are available.
"""
