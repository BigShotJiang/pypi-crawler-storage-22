"""Setup command for reports infrastructure.

Creates and configures:
- S3 bucket for reports
- CloudFront distribution
- Route53 DNS records
- ACM certificate (if custom domain)
- Lambda@Edge for Google OAuth authentication (optional)
"""

from argparse import ArgumentParser, Namespace

from constants import DEVOPS_DEFAULT_REGION
from scripts.devops.commands.base import CommandPlugin


class SetupCommand(CommandPlugin):
    """Setup AWS infrastructure for reports hosting."""

    @property
    def name(self) -> str:
        return "setup"

    @property
    def description(self) -> str:
        return "Setup AWS infrastructure (S3, CloudFront, Route53, Lambda@Edge)"

    @property
    def icon(self) -> str:
        return "📦"

    @property
    def menu_description(self) -> str:
        return "Create S3, CloudFront, Route53, Lambda@Edge"

    def add_arguments(self, parser: ArgumentParser) -> None:
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Check configuration and print what would be created without making changes",
        )
        parser.add_argument(
            "--bucket-name",
            help="S3 bucket name (auto-detected from AWS account if not specified)",
        )
        parser.add_argument(
            "--domain",
            help="Custom domain for CloudFront (auto-detected from AWS account if not specified)",
        )
        parser.add_argument(
            "--hosted-zone-id",
            help="Route53 hosted zone ID for the domain (auto-detected from AWS account if not specified)",
        )
        parser.add_argument(
            "--google-client-id",
            help="Google OAuth Client ID for authentication (enables Lambda@Edge auth)",
        )
        parser.add_argument(
            "--google-client-secret",
            help="Google OAuth Client Secret for authentication",
        )
        parser.add_argument(
            "--access-config",
            default="config/report_folders.yaml",
            help="Path to access control config YAML file (default: config/report_folders.yaml)",
        )
        parser.add_argument(
            "--region",
            default=DEVOPS_DEFAULT_REGION,
            help=f"AWS region (default: {DEVOPS_DEFAULT_REGION})",
        )
        parser.add_argument(
            "--stack-name",
            default="arato-agent-reports",
            help="CloudFormation stack name (default: arato-agent-reports)",
        )
        parser.add_argument(
            "--force-update-lambda",
            action="store_true",
            help="Force update Lambda@Edge function even if it already exists (use when changing access config)",
        )

    def handle(self, args: Namespace) -> None:
        from scripts.devops.commands.utils import get_account_defaults
        from scripts.devops.services.setup_service import run_setup

        default_bucket, default_domain = get_account_defaults()

        bucket_name = args.bucket_name or default_bucket
        domain = args.domain or default_domain
        hosted_zone_id = args.hosted_zone_id  # Will be looked up dynamically if None

        run_setup(
            bucket_name=bucket_name,
            domain=domain,
            hosted_zone_id=hosted_zone_id,
            google_client_id=args.google_client_id,
            google_client_secret=args.google_client_secret,
            access_config_path=args.access_config,
            region=args.region,
            stack_name=args.stack_name,
            dry_run=args.dry_run,
            force_update_lambda=args.force_update_lambda,
        )

    def get_help_content(self) -> str:
        return """# Setup Command

## Overview

The setup command creates and configures the complete AWS infrastructure
needed to host and serve reports securely:

- **S3 Bucket**: Stores report files (HTML, JSON, videos, etc.)
- **CloudFront Distribution**: Global CDN for fast, secure delivery
- **ACM Certificate**: SSL/TLS certificate for custom domain (if configured)
- **Route53 DNS**: Maps your custom domain to CloudFront
- **Lambda@Edge**: Optional Google OAuth authentication

## Basic Usage

```bash
# Check what would be created (dry run)
uv run devops setup --dry-run

# Create infrastructure with defaults
uv run devops setup

# Create with custom domain
uv run devops setup --domain reports.example.com --hosted-zone-id Z1234567890ABC
```

## With Google OAuth Authentication

```bash
uv run devops setup \\
  --google-client-id YOUR_CLIENT_ID.apps.googleusercontent.com \\
  --google-client-secret YOUR_CLIENT_SECRET \\
  --allowed-domains example.com,company.org
```

See the **Guide** section for detailed Google Cloud setup instructions.

## Auto-Detection

The command automatically detects settings based on your AWS account:
- Bucket name defaults to `arato-agent-reports-{account-id}`
- Known accounts have preconfigured domain and hosted zone settings
"""
