"""Sync command for uploading report folders to S3."""

from argparse import ArgumentParser, Namespace

from constants import DEVOPS_DEFAULT_REGION
from scripts.devops.commands.base import CommandPlugin


class SyncCommand(CommandPlugin):
    """Sync a folder to the reports S3 bucket."""

    @property
    def name(self) -> str:
        return "sync"

    @property
    def description(self) -> str:
        return "Sync a folder to the reports S3 bucket"

    @property
    def icon(self) -> str:
        return "📤"

    @property
    def menu_description(self) -> str:
        return "Upload folder to S3 reports bucket"

    def add_arguments(self, parser: ArgumentParser) -> None:
        parser.add_argument(
            "folder",
            nargs="?",  # Make optional for TUI
            help="Path to folder to sync (e.g., sessions/conversation_20250101_120000)",
        )
        parser.add_argument(
            "--bucket-name",
            help="S3 bucket name (auto-detected from AWS account if not specified)",
        )
        parser.add_argument(
            "--prefix",
            help="S3 prefix/path to sync to (default: folder name)",
        )
        parser.add_argument(
            "--invalidate",
            action="store_true",
            help="Create CloudFront invalidation after sync",
        )
        parser.add_argument(
            "--distribution-id",
            help="CloudFront distribution ID for invalidation (auto-detected if not provided)",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Show what would be synced without making changes",
        )
        parser.add_argument(
            "--region",
            default=DEVOPS_DEFAULT_REGION,
            help=f"AWS region (default: {DEVOPS_DEFAULT_REGION})",
        )

    def handle(self, args: Namespace) -> None:
        import logging

        from scripts.devops.commands.utils import get_account_defaults
        from scripts.devops.services.sync_service import run_sync

        logger = logging.getLogger(__name__)

        if not args.folder:
            logger.error("Folder path is required")
            raise ValueError("Folder path is required")

        default_bucket, _ = get_account_defaults()
        bucket_name = args.bucket_name or default_bucket

        run_sync(
            folder=args.folder,
            bucket_name=bucket_name,
            prefix=args.prefix,
            invalidate=args.invalidate,
            distribution_id=args.distribution_id,
            region=args.region,
            dry_run=args.dry_run,
        )

    def get_help_content(self) -> str:
        return """# Sync Command

## Overview

The sync command uploads a local folder to the reports S3 bucket.
It's used to publish generated reports to your hosting infrastructure.

## Basic Usage

```bash
# Sync a session folder
uv run devops sync sessions/conversation_20250101_120000

# Preview what would be synced (dry run)
uv run devops sync sessions/my_session --dry-run

# Sync and invalidate CloudFront cache
uv run devops sync sessions/my_session --invalidate
```

## Options

- **--bucket-name**: Override the target S3 bucket
- **--prefix**: Custom S3 path prefix (defaults to folder name)
- **--invalidate**: Create CloudFront cache invalidation after sync
- **--dry-run**: Show what would be uploaded without making changes

## File Handling

The sync command automatically:
- Sets correct content types (HTML, CSS, JS, etc.)
- Configures caching headers:
  - HTML/JSON: No cache (always fresh)
  - Static assets (JS, CSS, fonts): 1 year cache
  - Other files: 1 day cache
"""
