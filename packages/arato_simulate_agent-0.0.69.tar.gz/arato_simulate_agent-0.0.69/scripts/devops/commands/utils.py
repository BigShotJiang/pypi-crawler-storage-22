"""Utility functions shared across commands."""

import logging

import boto3

from constants import (
    DEVOPS_ACCOUNT_CONFIG,
    DEVOPS_DEFAULT_BUCKET_PREFIX,
    DEVOPS_DEFAULT_REGION,
)

logger = logging.getLogger(__name__)


def get_account_defaults() -> tuple[str, str | None]:
    """Get default bucket and domain based on AWS account.

    Hosted zone IDs are looked up dynamically by setup service.

    Returns:
        Tuple of (bucket_name, domain)
        - bucket_name is always set (falls back to default with account suffix)
        - domain may be None if account not configured
    """
    try:
        sts = boto3.client("sts", region_name=DEVOPS_DEFAULT_REGION)
        account_id = sts.get_caller_identity()["Account"]

        if account_id in DEVOPS_ACCOUNT_CONFIG:
            return DEVOPS_ACCOUNT_CONFIG[account_id]

        # Fallback: use account-specific bucket name
        return f"{DEVOPS_DEFAULT_BUCKET_PREFIX}-{account_id}", None
    except Exception:
        return DEVOPS_DEFAULT_BUCKET_PREFIX, None


def get_account_id() -> str | None:
    """Get the current AWS account ID.

    Returns:
        Account ID string, or None if not available
    """
    try:
        sts = boto3.client("sts", region_name=DEVOPS_DEFAULT_REGION)
        return sts.get_caller_identity()["Account"]
    except Exception:
        return None
