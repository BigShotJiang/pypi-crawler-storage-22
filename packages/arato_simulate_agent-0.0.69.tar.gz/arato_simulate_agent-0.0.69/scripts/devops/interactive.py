"""Interactive TUI for DevOps utilities using Textual."""

from __future__ import annotations

import logging
import subprocess
from typing import ClassVar

from textual import on, work
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, VerticalScroll
from textual.screen import Screen
from textual.validation import Length
from textual.widgets import (
    Button,
    Footer,
    Header,
    Input,
    OptionList,
    RichLog,
    Static,
    Switch,
)
from textual.widgets.option_list import Option

# Configure logging for the app
logging.basicConfig(level=logging.WARNING)


# ============================================================================
# Shared Styles (CSS)
# ============================================================================

APP_CSS = """
Screen {
    background: $surface;
}

#main-container {
    padding: 1 2;
}

.title {
    text-align: center;
    text-style: bold;
    color: $primary;
    padding: 1 0;
}

.subtitle {
    text-align: center;
    color: $text-muted;
    padding-bottom: 1;
}

.section-title {
    text-style: bold;
    color: $secondary;
    padding: 1 0 0 0;
}

.menu-option {
    padding: 1 2;
    margin: 0 1;
}

OptionList {
    height: auto;
    max-height: 20;
    border: round $primary;
    padding: 0 1;
}

OptionList:focus {
    border: round $accent;
}

OptionList > .option-list--option-highlighted {
    background: $primary;
    color: $text;
}

.form-container {
    padding: 1 2;
    height: auto;
}

.form-row {
    height: 3;
    margin: 0 0 1 0;
}

.form-label {
    width: 25;
    padding: 0 1;
    text-align: right;
}

.form-input {
    width: 1fr;
}

Input {
    border: tall $primary;
}

Input:focus {
    border: tall $accent;
}

Input.-valid {
    border: tall $success;
}

Input.-invalid {
    border: tall $error;
}

.button-row {
    height: 3;
    margin: 1 0;
    align: center middle;
}

Button {
    margin: 0 1;
}

Button.primary {
    background: $primary;
}

Button.success {
    background: $success;
}

Button.warning {
    background: $warning;
}

Button.error {
    background: $error;
}

#output-log {
    height: 100%;
    border: round $primary;
    background: $surface-darken-1;
}

.back-button {
    dock: left;
}

.info-box {
    border: round $primary;
    padding: 1 2;
    margin: 1 0;
    background: $surface-darken-1;
}

.success-text {
    color: $success;
}

.error-text {
    color: $error;
}

.warning-text {
    color: $warning;
}

#logo {
    text-align: center;
    color: $primary;
    padding: 1;
}

.status-running {
    color: $warning;
    text-style: bold italic;
}

.status-success {
    color: $success;
    text-style: bold;
}

.status-error {
    color: $error;
    text-style: bold;
}
"""

LOGO = """
╔═══════════════════════════════════════════════════════════════╗
║     _    ____      _  _____ ___    ____             ___       ║
║    / \\  |  _ \\    / \\|_   _/ _ \\  |  _ \\  _____   _/ _ \\ _ __ ___   ║
║   / _ \\ | |_) |  / _ \\ | || | | | | | | |/ _ \\ \\ / / | | | '_ \\/ __|  ║
║  / ___ \\|  _ <  / ___ \\| || |_| | | |_| |  __/\\ V /| |_| | |_) \\__ \\  ║
║ /_/   \\_\\_| \\_\\/_/   \\_\\_| \\___/  |____/ \\___| \\_/  \\___/| .__/|___/  ║
║                                                         |_|         ║
╚═══════════════════════════════════════════════════════════════╝
"""


# ============================================================================
# Command Execution Screen
# ============================================================================


class CommandScreen(Screen[None]):
    """Screen for executing and showing command output."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back"), ("q", "go_back", "Back")]

    def __init__(
        self, command: list[str], title: str = "Running Command", *args, **kwargs
    ):
        super().__init__(*args, **kwargs)
        self.command = command
        self.command_title = title
        self._process: subprocess.Popen[str] | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(
            Static(f"[bold]{self.command_title}[/bold]", classes="title"),
            Static(f"[dim]$ {' '.join(self.command)}[/dim]", classes="subtitle"),
            RichLog(id="output-log", highlight=True, markup=True),
            Horizontal(
                Button("Cancel", id="cancel-btn", variant="error"),
                Button("Back", id="back-btn", variant="default", disabled=True),
                classes="button-row",
            ),
            id="main-container",
        )
        yield Footer()

    def on_mount(self) -> None:
        self.run_command()

    @work(exclusive=True, thread=True)
    def run_command(self) -> None:
        """Run the command in a background thread."""

        log = self.query_one("#output-log", RichLog)
        cancel_btn = self.query_one("#cancel-btn", Button)
        back_btn = self.query_one("#back-btn", Button)

        try:
            process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )

            self._process = process

            assert process.stdout is not None

            for line in process.stdout:
                self.app.call_from_thread(log.write, line.rstrip())

            process.wait()

            if process.returncode == 0:
                self.app.call_from_thread(
                    log.write, "\n[green]✅ Command completed successfully![/green]"
                )
            else:
                self.app.call_from_thread(
                    log.write,
                    f"\n[red]❌ Command failed with exit code {process.returncode}[/red]",
                )

        except Exception as e:
            self.app.call_from_thread(log.write, f"\n[red]Error: {e}[/red]")

        finally:
            self.app.call_from_thread(cancel_btn.remove)
            self.app.call_from_thread(setattr, back_btn, "disabled", False)

    @on(Button.Pressed, "#cancel-btn")
    def on_cancel(self) -> None:
        if self._process:
            self._process.terminate()
            log = self.query_one("#output-log", RichLog)
            log.write("\n[yellow]⚠️ Command cancelled[/yellow]")

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    def action_go_back(self) -> None:
        if self._process and self._process.returncode is None:
            self._process.terminate()
        self.app.pop_screen()


# ============================================================================
# Setup Screen
# ============================================================================


class SetupScreen(Screen[None]):
    """Screen for configuring infrastructure setup."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def __init__(self, defaults: tuple[str, str | None], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.defaults = defaults

    def compose(self) -> ComposeResult:
        bucket, domain = self.defaults

        yield Header()
        yield VerticalScroll(
            Container(
                Static("[bold]📦 Reports Infrastructure Setup[/bold]", classes="title"),
                Static(
                    "Configure S3, CloudFront, Route53, and Lambda@Edge",
                    classes="subtitle",
                ),
                # S3 Bucket
                Static("[bold]S3 Configuration[/bold]", classes="section-title"),
                Horizontal(
                    Static("Bucket Name:", classes="form-label"),
                    Input(
                        value=bucket or "",
                        placeholder="my-reports-bucket",
                        id="bucket-name",
                        validators=[Length(minimum=3, maximum=63)],
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                # CloudFront/Domain
                Static("[bold]CloudFront & Domain[/bold]", classes="section-title"),
                Horizontal(
                    Static("Custom Domain:", classes="form-label"),
                    Input(
                        value=domain or "",
                        placeholder="reports.example.com (optional)",
                        id="domain",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Hosted Zone ID:", classes="form-label"),
                    Input(
                        value="",
                        placeholder="Auto-detected (or enter manually)",
                        id="hosted-zone-id",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                # Google OAuth
                Static("[bold]Google OAuth (Optional)[/bold]", classes="section-title"),
                Horizontal(
                    Static("Client ID:", classes="form-label"),
                    Input(
                        placeholder="your-client-id.apps.googleusercontent.com",
                        id="google-client-id",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Client Secret:", classes="form-label"),
                    Input(
                        placeholder="your-client-secret",
                        id="google-client-secret",
                        password=True,
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Access Config:", classes="form-label"),
                    Input(
                        value="config/report_folders.yaml",
                        placeholder="Path to access config YAML",
                        id="access-config",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                # Options
                Static("[bold]Options[/bold]", classes="section-title"),
                Horizontal(
                    Static("Dry Run:", classes="form-label"),
                    Switch(id="dry-run", value=False),
                    Static("  Preview changes without creating resources"),
                    classes="form-row",
                ),
                # Buttons
                Horizontal(
                    Button("← Back", id="back-btn", variant="default"),
                    Button("🔍 Dry Run", id="dry-run-btn", variant="warning"),
                    Button("🚀 Deploy", id="deploy-btn", variant="success"),
                    classes="button-row",
                ),
                classes="form-container",
            ),
            id="main-container",
        )
        yield Footer()

    def _build_command(self, dry_run: bool = False) -> list[str]:
        """Build the setup command from form values."""
        cmd = ["uv", "run", "devops", "setup"]

        bucket = self.query_one("#bucket-name", Input).value
        domain = self.query_one("#domain", Input).value
        zone_id = self.query_one("#hosted-zone-id", Input).value
        client_id = self.query_one("#google-client-id", Input).value
        client_secret = self.query_one("#google-client-secret", Input).value
        access_config = self.query_one("#access-config", Input).value

        if bucket:
            cmd.extend(["--bucket-name", bucket])
        if domain:
            cmd.extend(["--domain", domain])
        if zone_id:
            cmd.extend(["--hosted-zone-id", zone_id])
        if client_id:
            cmd.extend(["--google-client-id", client_id])
        if client_secret:
            cmd.extend(["--google-client-secret", client_secret])
        if access_config:
            cmd.extend(["--access-config", access_config])
        if dry_run:
            cmd.append("--dry-run")

        return cmd

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    @on(Button.Pressed, "#dry-run-btn")
    def on_dry_run(self) -> None:
        cmd = self._build_command(dry_run=True)
        self.app.push_screen(CommandScreen(cmd, "Setup (Dry Run)"))

    @on(Button.Pressed, "#deploy-btn")
    def on_deploy(self) -> None:
        cmd = self._build_command(dry_run=False)
        self.app.push_screen(CommandScreen(cmd, "Deploying Infrastructure"))

    def action_go_back(self) -> None:
        self.app.pop_screen()


# ============================================================================
# Sync Screen
# ============================================================================


class SyncScreen(Screen[None]):
    """Screen for syncing folders to S3."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def __init__(self, defaults: tuple[str, str | None], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.defaults = defaults

    def compose(self) -> ComposeResult:
        bucket, _ = self.defaults

        yield Header()
        yield VerticalScroll(
            Container(
                Static("[bold]📤 Sync to S3[/bold]", classes="title"),
                Static("Upload a folder to the reports bucket", classes="subtitle"),
                # Folder
                Static("[bold]Source[/bold]", classes="section-title"),
                Horizontal(
                    Static("Folder Path:", classes="form-label"),
                    Input(
                        placeholder="sessions/conversation_20250101_120000",
                        id="folder",
                        validators=[Length(minimum=1)],
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                # Destination
                Static("[bold]Destination[/bold]", classes="section-title"),
                Horizontal(
                    Static("Bucket Name:", classes="form-label"),
                    Input(
                        value=bucket or "",
                        placeholder="my-reports-bucket",
                        id="bucket-name",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("S3 Prefix:", classes="form-label"),
                    Input(
                        placeholder="(optional - defaults to folder name)",
                        id="prefix",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                # Options
                Static("[bold]Options[/bold]", classes="section-title"),
                Horizontal(
                    Static("CloudFront Invalidation:", classes="form-label"),
                    Switch(id="invalidate", value=True),
                    Static("  Invalidate cache after sync"),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Dry Run:", classes="form-label"),
                    Switch(id="dry-run", value=False),
                    Static("  Preview without uploading"),
                    classes="form-row",
                ),
                # Buttons
                Horizontal(
                    Button("← Back", id="back-btn", variant="default"),
                    Button("🔍 Preview", id="preview-btn", variant="warning"),
                    Button("📤 Sync", id="sync-btn", variant="success"),
                    classes="button-row",
                ),
                classes="form-container",
            ),
            id="main-container",
        )
        yield Footer()

    def _build_command(self, dry_run: bool = False) -> list[str]:
        """Build the sync command from form values."""
        folder = self.query_one("#folder", Input).value
        if not folder:
            return []

        cmd = ["uv", "run", "devops", "sync", folder]

        bucket = self.query_one("#bucket-name", Input).value
        prefix = self.query_one("#prefix", Input).value
        invalidate = self.query_one("#invalidate", Switch).value

        if bucket:
            cmd.extend(["--bucket-name", bucket])
        if prefix:
            cmd.extend(["--prefix", prefix])
        if invalidate:
            cmd.append("--invalidate")
        if dry_run:
            cmd.append("--dry-run")

        return cmd

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    @on(Button.Pressed, "#preview-btn")
    def on_preview(self) -> None:
        cmd = self._build_command(dry_run=True)
        if cmd:
            self.app.push_screen(CommandScreen(cmd, "Sync Preview"))
        else:
            self.notify("Please enter a folder path", severity="error")

    @on(Button.Pressed, "#sync-btn")
    def on_sync(self) -> None:
        cmd = self._build_command(dry_run=False)
        if cmd:
            self.app.push_screen(CommandScreen(cmd, "Syncing to S3"))
        else:
            self.notify("Please enter a folder path", severity="error")

    def action_go_back(self) -> None:
        self.app.pop_screen()


# ============================================================================
# AgentCore Screen
# ============================================================================


class AgentCoreScreen(Screen[None]):
    """Screen for AgentCore management."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(
            Static("[bold]🤖 AgentCore Management[/bold]", classes="title"),
            Static("Deploy and manage your AgentCore application", classes="subtitle"),
            OptionList(
                Option(
                    "⚙️  Configure    │ Set up VPC, IAM roles, and credentials",
                    id="configure",
                ),
                Option(
                    "🚀 Launch       │ Build and deploy the AgentCore container",
                    id="launch",
                ),
                Option(
                    "📊 Status       │ Check current deployment status",
                    id="status",
                ),
                None,  # Separator
                Option(
                    "💥 Destroy      │ Remove the AgentCore deployment",
                    id="destroy",
                ),
                id="agentcore-menu",
            ),
            Static(
                "\n[dim]Use ↑↓ to navigate, Enter to select, Escape to go back[/dim]",
                classes="subtitle",
            ),
            Horizontal(
                Button("← Back", id="back-btn", variant="default"),
                classes="button-row",
            ),
            id="main-container",
        )
        yield Footer()

    @on(OptionList.OptionSelected, "#agentcore-menu")
    def on_option_selected(self, event: OptionList.OptionSelected) -> None:
        option_id = event.option_id
        if option_id == "configure":
            self.app.push_screen(AgentCoreConfigureScreen())
        elif option_id == "launch":
            cmd = ["uv", "run", "devops", "agentcore", "launch"]
            self.app.push_screen(CommandScreen(cmd, "Launching AgentCore"))
        elif option_id == "status":
            cmd = ["uv", "run", "devops", "agentcore", "status"]
            self.app.push_screen(CommandScreen(cmd, "AgentCore Status"))
        elif option_id == "destroy":
            cmd = ["uv", "run", "devops", "agentcore", "destroy"]
            self.app.push_screen(CommandScreen(cmd, "Destroying AgentCore"))

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    def action_go_back(self) -> None:
        self.app.pop_screen()


class AgentCoreConfigureScreen(Screen[None]):
    """Screen for AgentCore configuration options."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield VerticalScroll(
            Container(
                Static("[bold]⚙️ AgentCore Configure[/bold]", classes="title"),
                Static("Set up VPC, IAM, and Google credentials", classes="subtitle"),
                # Options
                Static("[bold]Options[/bold]", classes="section-title"),
                Horizontal(
                    Static("Force Google Auth:", classes="form-label"),
                    Switch(id="force-google-auth", value=False),
                    Static("  Update Google credentials even if cached"),
                    classes="form-row",
                ),
                # Info
                Static(
                    "\n[dim]This command will interactively configure your AgentCore deployment.[/dim]\n"
                    "[dim]It sets up VPC endpoints, IAM roles, and Google Cloud credentials.[/dim]",
                    classes="info-box",
                ),
                # Buttons
                Horizontal(
                    Button("← Back", id="back-btn", variant="default"),
                    Button("🚀 Configure", id="configure-btn", variant="success"),
                    classes="button-row",
                ),
                classes="form-container",
            ),
            id="main-container",
        )
        yield Footer()

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    @on(Button.Pressed, "#configure-btn")
    def on_configure(self) -> None:
        cmd = ["uv", "run", "devops", "agentcore", "configure"]
        if self.query_one("#force-google-auth", Switch).value:
            cmd.append("--force-google-auth")
        self.app.push_screen(CommandScreen(cmd, "Configuring AgentCore"))

    def action_go_back(self) -> None:
        self.app.pop_screen()


# ============================================================================
# App Server Screen
# ============================================================================


class AppServerScreen(Screen[None]):
    """Screen for app server deployment and management on ECS/Fargate."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(
            Static("[bold]🖥️ App Server Management[/bold]", classes="title"),
            Static(
                "Deploy and manage the app server on ECS/Fargate + Aurora PostgreSQL",
                classes="subtitle",
            ),
            OptionList(
                Option(
                    "⚙️  Configure    │ Deploy CloudFormation infrastructure (ECS, ALB, Aurora, ECR)",
                    id="configure",
                ),
                Option(
                    "🚀 Deploy       │ Build Docker image, push to ECR, run migrations, update ECS",
                    id="deploy",
                ),
                Option(
                    "📊 Status       │ Check stack and ECS service status",
                    id="status",
                ),
                None,  # Separator
                Option(
                    "💥 Destroy      │ Remove all app server infrastructure",
                    id="destroy",
                ),
                id="app-server-menu",
            ),
            Static(
                "\n[dim]Use ↑↓ to navigate, Enter to select, Escape to go back[/dim]",
                classes="subtitle",
            ),
            Horizontal(
                Button("← Back", id="back-btn", variant="default"),
                classes="button-row",
            ),
            id="main-container",
        )
        yield Footer()

    @on(OptionList.OptionSelected, "#app-server-menu")
    def on_option_selected(self, event: OptionList.OptionSelected) -> None:
        option_id = event.option_id
        if option_id == "configure":
            cmd = ["uv", "run", "devops", "app-server", "configure"]
            self.app.push_screen(CommandScreen(cmd, "Deploying Infrastructure"))
        elif option_id == "deploy":
            cmd = ["uv", "run", "devops", "app-server", "deploy"]
            self.app.push_screen(CommandScreen(cmd, "Deploying App Server"))
        elif option_id == "status":
            cmd = ["uv", "run", "devops", "app-server", "status"]
            self.app.push_screen(CommandScreen(cmd, "App Server Status"))
        elif option_id == "destroy":
            cmd = ["uv", "run", "devops", "app-server", "destroy", "--force"]
            self.app.push_screen(CommandScreen(cmd, "Destroying App Server"))

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    def action_go_back(self) -> None:
        self.app.pop_screen()


# ============================================================================
# Polling Screen
# ============================================================================


class PollingScreen(Screen[None]):
    """Screen for polling mode management."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(
            Static("[bold]⏱️ Polling Mode[/bold]", classes="title"),
            Static(
                "Deploy EventBridge scheduler for behind-firewall operation",
                classes="subtitle",
            ),
            OptionList(
                Option(
                    "🚀 Deploy       │ Set up polling infrastructure",
                    id="deploy",
                ),
                None,  # Separator
                Option(
                    "💥 Destroy      │ Remove polling infrastructure",
                    id="destroy",
                ),
                id="polling-menu",
            ),
            Static(
                "\n[dim]Use ↑↓ to navigate, Enter to select, Escape to go back[/dim]",
                classes="subtitle",
            ),
            Horizontal(
                Button("← Back", id="back-btn", variant="default"),
                classes="button-row",
            ),
            id="main-container",
        )
        yield Footer()

    @on(OptionList.OptionSelected, "#polling-menu")
    def on_option_selected(self, event: OptionList.OptionSelected) -> None:
        option_id = event.option_id
        if option_id == "deploy":
            self.app.push_screen(PollingDeployScreen())
        elif option_id == "destroy":
            self.app.push_screen(PollingDestroyScreen())

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    def action_go_back(self) -> None:
        self.app.pop_screen()


class PollingDeployScreen(Screen[None]):
    """Screen for deploying polling infrastructure."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield VerticalScroll(
            Container(
                Static("[bold]🚀 Deploy Polling[/bold]", classes="title"),
                Static("Configure EventBridge scheduler", classes="subtitle"),
                # Required
                Static("[bold]Required Configuration[/bold]", classes="section-title"),
                Horizontal(
                    Static("AgentCore ARN:", classes="form-label"),
                    Input(
                        placeholder="arn:aws:bedrock-agentcore:...",
                        id="agentcore-arn",
                        validators=[Length(minimum=10)],
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("API Key:", classes="form-label"),
                    Input(
                        placeholder="ar-...",
                        id="api-key",
                        password=True,
                        validators=[Length(minimum=3)],
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Task Endpoint:", classes="form-label"),
                    Input(
                        placeholder="https://api.example.com/task",
                        id="task-endpoint",
                        validators=[Length(minimum=10)],
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                # Optional
                Static("[bold]Optional Settings[/bold]", classes="section-title"),
                Horizontal(
                    Static("Stack Name:", classes="form-label"),
                    Input(
                        value="arato-agent-polling",
                        id="stack-name",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Schedule:", classes="form-label"),
                    Input(
                        value="rate(5 minutes)",
                        id="schedule",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Polling Interval:", classes="form-label"),
                    Input(
                        value="30",
                        id="polling-interval",
                        classes="form-input",
                    ),
                    Static(" seconds"),
                    classes="form-row",
                ),
                # Buttons
                Horizontal(
                    Button("← Back", id="back-btn", variant="default"),
                    Button("🚀 Deploy", id="deploy-btn", variant="success"),
                    classes="button-row",
                ),
                classes="form-container",
            ),
            id="main-container",
        )
        yield Footer()

    def _validate_required_fields(self) -> bool:
        """Check if required fields are filled."""
        arn = self.query_one("#agentcore-arn", Input).value
        api_key = self.query_one("#api-key", Input).value
        endpoint = self.query_one("#task-endpoint", Input).value
        return bool(arn and api_key and endpoint)

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    @on(Button.Pressed, "#deploy-btn")
    def on_deploy(self) -> None:
        if not self._validate_required_fields():
            self.notify("Please fill in all required fields", severity="error")
            return

        cmd = [
            "uv",
            "run",
            "devops",
            "polling",
            "deploy",
            "--agentcore-arn",
            self.query_one("#agentcore-arn", Input).value,
            "--api-key",
            self.query_one("#api-key", Input).value,
            "--task-endpoint",
            self.query_one("#task-endpoint", Input).value,
            "--stack-name",
            self.query_one("#stack-name", Input).value,
            "--schedule",
            self.query_one("#schedule", Input).value,
            "--polling-interval",
            self.query_one("#polling-interval", Input).value,
        ]
        self.app.push_screen(CommandScreen(cmd, "Deploying Polling Infrastructure"))

    def action_go_back(self) -> None:
        self.app.pop_screen()


class PollingDestroyScreen(Screen[None]):
    """Screen for destroying polling infrastructure."""

    BINDINGS: ClassVar = [("escape", "go_back", "Back")]

    def compose(self) -> ComposeResult:
        yield Header()
        yield VerticalScroll(
            Container(
                Static(
                    "[bold red]💥 Destroy Polling Infrastructure[/bold red]",
                    classes="title",
                ),
                Static(
                    "Remove EventBridge scheduler and related resources",
                    classes="subtitle",
                ),
                # Settings
                Static("[bold]Settings[/bold]", classes="section-title"),
                Horizontal(
                    Static("Stack Name:", classes="form-label"),
                    Input(
                        value="arato-agent-polling",
                        id="stack-name",
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Static("Delete SSM Parameters:", classes="form-label"),
                    Switch(id="delete-parameters", value=False),
                    Static("  Also delete stored credentials"),
                    classes="form-row",
                ),
                # Warning
                Static(
                    "\n[bold red]⚠️ Warning[/bold red]\n"
                    "This will remove the polling infrastructure.\n"
                    "The agent will no longer poll for tasks automatically.",
                    classes="info-box",
                ),
                # Buttons
                Horizontal(
                    Button("← Back", id="back-btn", variant="default"),
                    Button("💥 Destroy", id="destroy-btn", variant="error"),
                    classes="button-row",
                ),
                classes="form-container",
            ),
            id="main-container",
        )
        yield Footer()

    @on(Button.Pressed, "#back-btn")
    def on_back(self) -> None:
        self.app.pop_screen()

    @on(Button.Pressed, "#destroy-btn")
    def on_destroy(self) -> None:
        cmd = [
            "uv",
            "run",
            "devops",
            "polling",
            "destroy",
            "--stack-name",
            self.query_one("#stack-name", Input).value,
            "--force",  # Skip confirmation since we have GUI confirmation
        ]
        if self.query_one("#delete-parameters", Switch).value:
            cmd.append("--delete-parameters")
        self.app.push_screen(CommandScreen(cmd, "Destroying Polling Infrastructure"))

    def action_go_back(self) -> None:
        self.app.pop_screen()


# ============================================================================
# Main App
# ============================================================================


class DevOpsApp(App[None]):
    """Interactive DevOps CLI for Arato Agent."""

    CSS = APP_CSS
    TITLE = "Arato DevOps"
    SUB_TITLE = "Infrastructure Management"
    BINDINGS: ClassVar = [
        ("q", "quit", "Quit"),
        ("escape", "quit", "Quit"),
        ("?", "help", "Help"),
    ]

    def __init__(self):
        super().__init__()
        self.defaults: tuple[str, str | None] = (
            "arato-agent-reports",
            None,
        )

    def on_mount(self) -> None:
        """Load defaults when app starts."""
        self._load_defaults()

    @work(thread=True)
    def _load_defaults(self) -> None:
        """Load AWS account defaults in background."""
        try:
            import boto3

            from constants import (
                DEVOPS_ACCOUNT_CONFIG,
                DEVOPS_DEFAULT_BUCKET_PREFIX,
                DEVOPS_DEFAULT_REGION,
            )

            sts = boto3.client("sts", region_name=DEVOPS_DEFAULT_REGION)
            account_id = sts.get_caller_identity()["Account"]

            if account_id in DEVOPS_ACCOUNT_CONFIG:
                self.defaults = DEVOPS_ACCOUNT_CONFIG[account_id]
            else:
                self.defaults = (
                    f"{DEVOPS_DEFAULT_BUCKET_PREFIX}-{account_id}",
                    None,
                )
        except Exception:
            pass  # Keep defaults

    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(
            Static(LOGO, id="logo"),
            Static(
                "Select an operation to manage your infrastructure",
                classes="subtitle",
            ),
            OptionList(
                Option(
                    "📦 Setup        │ Create S3, CloudFront, Route53, Lambda@Edge",
                    id="setup",
                ),
                Option(
                    "📤 Sync         │ Upload folder to S3 reports bucket",
                    id="sync",
                ),
                None,  # Separator
                Option(
                    "🤖 AgentCore    │ Deploy and manage AgentCore application",
                    id="agentcore",
                ),
                Option(
                    "🖥️  App Server   │ Deploy app server on ECS/Fargate + Aurora",
                    id="app-server",
                ),
                Option(
                    "⏱️  Polling      │ Configure behind-firewall polling mode",
                    id="polling",
                ),
                None,  # Separator
                Option(
                    "❌ Quit         │ Exit the application",
                    id="quit",
                ),
                id="main-menu",
            ),
            Static(
                "\n[dim]Use ↑↓ to navigate, Enter to select, q to quit[/dim]",
                classes="subtitle",
            ),
            id="main-container",
        )
        yield Footer()

    @on(OptionList.OptionSelected, "#main-menu")
    def on_option_selected(self, event: OptionList.OptionSelected) -> None:
        option_id = event.option_id
        if option_id == "setup":
            self.push_screen(SetupScreen(self.defaults))
        elif option_id == "sync":
            self.push_screen(SyncScreen(self.defaults))
        elif option_id == "agentcore":
            self.push_screen(AgentCoreScreen())
        elif option_id == "app-server":
            self.push_screen(AppServerScreen())
        elif option_id == "polling":
            self.push_screen(PollingScreen())
        elif option_id == "quit":
            self.exit()


def run_interactive() -> None:
    """Run the interactive TUI."""
    app = DevOpsApp()
    app.run()


if __name__ == "__main__":
    run_interactive()
