"""Lambda@Edge package for CloudFront authentication."""

__all__ = ["handler", "templates"]
