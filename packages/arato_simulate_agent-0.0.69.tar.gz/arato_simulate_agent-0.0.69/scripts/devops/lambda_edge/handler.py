"""Lambda@Edge handler for Google OAuth authentication and folder access control.

This handler is deployed to CloudFront as a viewer-request function.
Configuration values (GOOGLE_CLIENT_ID, etc.) are injected at deployment time.
"""

import base64
import hashlib
import hmac
import html
import json
import os
import re
import time
import urllib.parse
import urllib.request

import boto3

# Configuration (injected at deployment)
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
SESSION_DURATION = 86400  # 24 hours
COOKIE_NAME = "arato_auth"
SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-in-production")

# Access control configuration (injected at deployment)
# Format: {'all': ['domain1.com', 'email@domain.com'], 'folders': {'uuid': ['domain2.com']}}
ACCESS_CONFIG = {}

# S3 bucket name (injected at deployment)
S3_BUCKET_NAME = ""

# UUID pattern: 8-4-4-4-12 hex characters
UUID_PATTERN = re.compile(
    r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$"
)


def create_signature(data):
    """Create HMAC signature for session data."""
    return hmac.new(SECRET_KEY.encode(), data.encode(), hashlib.sha256).hexdigest()[:16]


def verify_signature(data, signature):
    """Verify HMAC signature."""
    return hmac.compare_digest(create_signature(data), signature)


def parse_cookie(cookie_header):
    """Parse cookie header and extract our auth cookie."""
    if not cookie_header:
        return None

    for cookie in cookie_header.split(";"):
        cookie = cookie.strip()
        if cookie.startswith(f"{COOKIE_NAME}="):
            value = cookie[len(COOKIE_NAME) + 1 :]
            try:
                decoded = base64.urlsafe_b64decode(value).decode()
                parts = decoded.split("|")
                if len(parts) == 3:
                    email, expiry, signature = parts
                    if verify_signature(f"{email}|{expiry}", signature):
                        if int(expiry) > int(time.time()):
                            return email
            except Exception:
                pass
    return None


def create_auth_cookie(email):
    """Create signed authentication cookie."""
    expiry = int(time.time()) + SESSION_DURATION
    data = f"{email}|{expiry}"
    signature = create_signature(data)
    value = base64.urlsafe_b64encode(f"{data}|{signature}".encode()).decode()
    return f"{COOKIE_NAME}={value}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age={SESSION_DURATION}"


def get_google_auth_url(request, cf_domain):
    """Generate Google OAuth authorization URL."""
    redirect_uri = f"https://{cf_domain}/_auth/callback"

    params = {
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid email profile",
        "access_type": "online",
        "prompt": "select_account",
        "state": base64.urlsafe_b64encode(request["uri"].encode()).decode(),
    }

    return "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(
        params
    )


def exchange_code_for_token(code, cf_domain):
    """Exchange authorization code for tokens."""
    redirect_uri = f"https://{cf_domain}/_auth/callback"

    data = urllib.parse.urlencode(
        {
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": redirect_uri,
            "grant_type": "authorization_code",
        }
    ).encode()

    req = urllib.request.Request(
        "https://oauth2.googleapis.com/token",
        data=data,
        method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    with urllib.request.urlopen(req) as response:
        return json.loads(response.read().decode())


def get_user_info(access_token):
    """Get user information from Google."""
    req = urllib.request.Request(
        "https://www.googleapis.com/oauth2/v2/userinfo",
        headers={"Authorization": f"Bearer {access_token}"},
    )

    with urllib.request.urlopen(req) as response:
        return json.loads(response.read().decode())


def extract_uuid_from_path(uri):
    """Extract UUID from path.

    Valid patterns:
    - /{uuid}/...  (uuid at start)
    - /{prefix}_{uuid}/...  (prefix with underscore before uuid)

    Returns None if no valid UUID pattern found.
    """
    if not uri or uri == "/":
        return None

    # Remove leading slash and get first path segment
    path = uri.lstrip("/")
    if not path:
        return None

    first_segment = path.split("/")[0]
    if not first_segment:
        return None

    # Check if segment IS a UUID (pattern 1: /uuid/...)
    if UUID_PATTERN.match(first_segment):
        return first_segment.upper()  # Normalize to uppercase

    # Check if segment ends with _uuid (pattern 2: /prefix_uuid/...)
    if "_" in first_segment:
        # Get the last part after underscore (in case of multiple underscores)
        last_part = first_segment.rsplit("_", 1)[-1]
        if UUID_PATTERN.match(last_part):
            return last_part.upper()  # Normalize to uppercase

    return None


def is_user_authorized(email, uuid):
    """Check if user is authorized to access the folder.

    Authorization rules:
    1. User in 'all' list can access everything
    2. User's domain or exact email in folder's ACL grants access
    """
    if not email or not uuid:
        return False

    email_lower = email.lower()
    domain = email_lower.split("@")[-1]

    # Check global 'all' access
    all_access = ACCESS_CONFIG.get("all", [])
    for entry in all_access:
        entry_lower = entry.lower()
        if "@" in entry:
            # Exact email match
            if email_lower == entry_lower:
                return True
        else:
            # Domain match
            if domain == entry_lower:
                return True

    # Check folder-specific access
    folders = ACCESS_CONFIG.get("folders", {})
    folder_acl = folders.get(uuid, [])
    for entry in folder_acl:
        entry_lower = entry.lower()
        if "@" in entry:
            # Exact email match
            if email_lower == entry_lower:
                return True
        else:
            # Domain match
            if domain == entry_lower:
                return True

    return False


def discover_prefixes_from_s3():
    """Discover folder prefixes from S3 bucket at runtime.

    Returns:
        List of unique prefixes found in folder names (e.g., ['wix', 'superloop'])
    """
    if not S3_BUCKET_NAME:
        return []

    try:
        s3 = boto3.client("s3")
        response = s3.list_objects_v2(
            Bucket=S3_BUCKET_NAME, Delimiter="/", MaxKeys=1000
        )

        prefixes = set()
        for prefix_obj in response.get("CommonPrefixes", []):
            folder_name = prefix_obj["Prefix"].rstrip("/")

            # Check if folder matches {prefix}_{uuid} pattern
            if "_" in folder_name:
                parts = folder_name.rsplit("_", 1)
                if len(parts) == 2:
                    prefix_part, uuid_part = parts
                    if UUID_PATTERN.match(uuid_part):
                        prefixes.add(prefix_part)

        return sorted(prefixes)
    except Exception:
        # Fail gracefully - return empty list if S3 access fails
        return []


def get_accessible_uuids(email):
    """Get list of UUIDs the user can access.

    Returns list of UUIDs (uppercase) the user has access to.
    """
    if not email:
        return []

    email_lower = email.lower()
    domain = email_lower.split("@")[-1]

    accessible = []
    folders = ACCESS_CONFIG.get("folders", {})

    # Check if user has global 'all' access
    has_global_access = False
    all_access = ACCESS_CONFIG.get("all", [])
    for entry in all_access:
        entry_lower = entry.lower()
        if "@" in entry:
            if email_lower == entry_lower:
                has_global_access = True
                break
        else:
            if domain == entry_lower:
                has_global_access = True
                break

    # If global access, return all folder UUIDs
    if has_global_access:
        return list(folders.keys())

    # Otherwise, check each folder's ACL
    for uuid, acl in folders.items():
        for entry in acl:
            entry_lower = entry.lower()
            if "@" in entry:
                if email_lower == entry_lower:
                    accessible.append(uuid)
                    break
            else:
                if domain == entry_lower:
                    accessible.append(uuid)
                    break

    return accessible


def render_no_access_page(email):
    """Render the no access page."""
    from .templates import NO_ACCESS_TEMPLATE

    return NO_ACCESS_TEMPLATE.format(email=html.escape(email))


def render_folder_list_page(email, accessible_uuids, known_prefixes):
    """Render the folder list page."""
    from .templates import FOLDER_LIST_TEMPLATE

    return FOLDER_LIST_TEMPLATE.format(
        email=html.escape(email),
        accessible_uuids=json.dumps(accessible_uuids),
        known_prefixes=json.dumps(known_prefixes),
    )


def render_forbidden_invalid_path():
    """Render the forbidden invalid path page."""
    from .templates import FORBIDDEN_INVALID_PATH_TEMPLATE

    return FORBIDDEN_INVALID_PATH_TEMPLATE


def render_forbidden_no_access(email):
    """Render the forbidden no access page."""
    from .templates import FORBIDDEN_NO_ACCESS_TEMPLATE

    return FORBIDDEN_NO_ACCESS_TEMPLATE.format(email=html.escape(email))


def handler(event, _context):
    """Lambda@Edge viewer-request handler."""
    request = event["Records"][0]["cf"]["request"]
    headers = request["headers"]
    uri = request["uri"]

    # Get the CloudFront domain
    cf_domain = headers.get("host", [{"value": ""}])[0]["value"]

    # Handle OAuth callback (must be accessible before auth check)
    if uri.startswith("/_auth/callback"):
        query = request.get("querystring", "")
        params = urllib.parse.parse_qs(query)

        code = params.get("code", [None])[0]
        state = params.get("state", ["L2luZGV4Lmh0bWw="])[0]  # Default to /index.html

        if not code:
            return {
                "status": "400",
                "statusDescription": "Bad Request",
                "body": "Missing authorization code",
            }

        try:
            # Exchange code for token
            tokens = exchange_code_for_token(code, cf_domain)
            access_token = tokens.get("access_token")

            if not access_token:
                raise Exception("No access token received")

            # Get user info
            user_info = get_user_info(access_token)
            email = user_info.get("email", "")

            # Decode the original URI from state
            try:
                original_uri = base64.urlsafe_b64decode(state).decode()
            except Exception:
                original_uri = "/"

            # Create auth cookie and redirect
            cookie = create_auth_cookie(email)

            return {
                "status": "302",
                "statusDescription": "Found",
                "headers": {
                    "location": [
                        {
                            "key": "Location",
                            "value": f"https://{cf_domain}{original_uri}",
                        }
                    ],
                    "set-cookie": [{"key": "Set-Cookie", "value": cookie}],
                    "cache-control": [{"key": "Cache-Control", "value": "no-store"}],
                },
            }

        except Exception as e:
            return {
                "status": "500",
                "statusDescription": "Internal Server Error",
                "body": f"Authentication failed: {str(e)}",
            }

    # Handle logout (both /logout and /_auth/logout)
    if uri in ("/logout", "/_auth/logout"):
        return {
            "status": "302",
            "statusDescription": "Found",
            "headers": {
                "location": [{"key": "Location", "value": f"https://{cf_domain}/"}],
                "set-cookie": [
                    {
                        "key": "Set-Cookie",
                        "value": f"{COOKIE_NAME}=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT",
                    }
                ],
            },
        }

    # Handle home/list endpoints - show accessible folders
    if uri in ("/", "/list"):
        # Check authentication first
        cookie_header = headers.get("cookie", [{"value": ""}])[0]["value"]
        email = parse_cookie(cookie_header)

        if not email:
            # Not authenticated - redirect to Google OAuth
            auth_url = get_google_auth_url(request, cf_domain)
            return {
                "status": "302",
                "statusDescription": "Found",
                "headers": {
                    "location": [{"key": "Location", "value": auth_url}],
                    "cache-control": [{"key": "Cache-Control", "value": "no-store"}],
                },
            }

        # Get all UUIDs this user can access
        accessible_uuids = get_accessible_uuids(email)

        if not accessible_uuids:
            html = render_no_access_page(email)
            return {
                "status": "200",
                "statusDescription": "OK",
                "headers": {
                    "content-type": [{"key": "Content-Type", "value": "text/html"}],
                    "cache-control": [{"key": "Cache-Control", "value": "no-store"}],
                },
                "body": html,
            }

        # Discover prefixes from S3 at runtime
        known_prefixes = discover_prefixes_from_s3()
        html = render_folder_list_page(email, accessible_uuids, known_prefixes)

        return {
            "status": "200",
            "statusDescription": "OK",
            "headers": {
                "content-type": [{"key": "Content-Type", "value": "text/html"}],
                "cache-control": [{"key": "Cache-Control", "value": "no-store"}],
            },
            "body": html,
        }

    # Extract UUID from path - this determines which folder is being accessed
    uuid = extract_uuid_from_path(uri)

    # If no valid UUID in path, deny access
    if not uuid:
        return {
            "status": "403",
            "statusDescription": "Forbidden",
            "headers": {
                "content-type": [{"key": "Content-Type", "value": "text/html"}]
            },
            "body": render_forbidden_invalid_path(),
        }

    # Check authentication
    cookie_header = headers.get("cookie", [{"value": ""}])[0]["value"]
    email = parse_cookie(cookie_header)

    if not email:
        # Not authenticated, redirect to Google
        auth_url = get_google_auth_url(request, cf_domain)
        return {
            "status": "302",
            "statusDescription": "Found",
            "headers": {
                "location": [{"key": "Location", "value": auth_url}],
                "cache-control": [{"key": "Cache-Control", "value": "no-store"}],
            },
        }

    # Check authorization for this folder
    if not is_user_authorized(email, uuid):
        return {
            "status": "403",
            "statusDescription": "Forbidden",
            "headers": {
                "content-type": [{"key": "Content-Type", "value": "text/html"}]
            },
            "body": render_forbidden_no_access(email),
        }

    # User is authenticated and authorized, allow request
    return request
