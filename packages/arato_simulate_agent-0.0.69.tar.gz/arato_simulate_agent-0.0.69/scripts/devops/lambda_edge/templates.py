"""HTML templates for Lambda@Edge responses."""

NO_ACCESS_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <title>Arato Simulate</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
        }}
        h1 {{ color: #333; }}
        .logout {{
            position: absolute;
            top: 20px;
            right: 20px;
        }}
    </style>
</head>
<body>
    <a href="/logout" class="logout">Logout ({email})</a>
    <h1>Arato Simulate Reports</h1>
    <p>You don't have access to any reports.</p>
</body>
</html>"""


FOLDER_LIST_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <title>Arato Simulate</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        h1 {{ color: #333; }}
        .logout {{
            position: absolute;
            top: 20px;
            right: 20px;
            color: #666;
        }}
        ul {{
            list-style: none;
            padding: 0;
        }}
        li {{
            margin: 10px 0;
            padding: 15px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }}
        a {{
            color: #0066cc;
            text-decoration: none;
            font-size: 16px;
        }}
        a:hover {{ text-decoration: underline; }}
        .folder-name {{ font-weight: 500; }}
        .loading {{
            color: #666;
            font-style: italic;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .spinner {{
            width: 16px;
            height: 16px;
            border: 2px solid #ccc;
            border-top-color: #0066cc;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }}
        @keyframes spin {{
            to {{ transform: rotate(360deg); }}
        }}
    </style>
</head>
<body>
    <a href='/logout' class='logout'>Logout ({email})</a>
    <h1>Arato Simulate Reports</h1>
    <p class='loading' id='loading'>
        <span class='spinner'></span> Loading reports...
    </p>
    <ul id='reports'></ul>

    <script>
        const uuids = {accessible_uuids};
        const prefixes = {known_prefixes};
        const reportsList = document.getElementById('reports');
        const loading = document.getElementById('loading');
        let found = 0;

        async function tryPath(path) {{
            try {{
                const resp = await fetch(path, {{ method: 'HEAD' }});
                return resp.ok;
            }} catch (e) {{
                return false;
            }}
        }}

        async function findFolder(uuid) {{
            // Try each known prefix to find the folder (case-insensitive UUID matching)
            const uuidLower = uuid.toLowerCase();
            const uuidUpper = uuid.toUpperCase();
            for (const prefix of prefixes) {{
                for (const u of [uuid, uuidLower, uuidUpper]) {{
                    const folderName = prefix ? prefix + '_' + u : u;
                    const path = '/' + folderName + '/index.html';
                    if (await tryPath(path)) {{
                        return {{ name: folderName, prefix: prefix || uuid }};
                    }}
                }}
            }}
            return null;
        }}

        async function loadReports() {{
            const results = await Promise.all(uuids.map(findFolder));
            loading.style.display = 'none';

            for (const result of results) {{
                if (result) {{
                    found++;
                    const li = document.createElement('li');
                    const displayName = result.prefix.charAt(0).toUpperCase() + result.prefix.slice(1);
                    li.innerHTML = '<a href="/' + result.name + '/index.html"><span class="folder-name">' + displayName + '</span></a>';
                    reportsList.appendChild(li);
                }}
            }}

            if (found === 0) {{
                reportsList.innerHTML = '<li>No reports found in storage.</li>';
            }}
        }}

        loadReports();
    </script>
</body>
</html>"""


FORBIDDEN_INVALID_PATH_TEMPLATE = """<html>
<body>
    <h1>403 Forbidden</h1>
    <p>Invalid path.</p>
</body>
</html>"""


FORBIDDEN_NO_ACCESS_TEMPLATE = """<html>
<body>
    <h1>403 Forbidden</h1>
    <p>You ({email}) do not have access to this folder.</p>
    <p><a href="/logout">Logout</a></p>
</body>
</html>"""
