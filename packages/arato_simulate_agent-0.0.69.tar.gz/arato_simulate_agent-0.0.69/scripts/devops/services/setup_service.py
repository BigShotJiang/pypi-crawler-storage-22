"""Setup service - wraps the existing setup.py logic.

This module re-exports from the original setup.py for backwards compatibility
while the modular architecture is being built.
"""

# Re-export run_setup from the original module
from scripts.devops.setup import run_setup

__all__ = ["run_setup"]
