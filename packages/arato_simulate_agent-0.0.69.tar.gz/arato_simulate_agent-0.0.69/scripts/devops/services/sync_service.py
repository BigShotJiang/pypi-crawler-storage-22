"""Sync service - wraps the existing sync.py logic.

This module re-exports from the original sync.py for backwards compatibility
while the modular architecture is being built.
"""

# Re-export run_sync from the original module
from scripts.devops.sync import run_sync

__all__ = ["run_sync"]
