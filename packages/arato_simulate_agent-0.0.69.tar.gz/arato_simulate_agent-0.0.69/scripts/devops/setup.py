"""Setup command for reports infrastructure.

Creates and configures:
- S3 bucket for reports
- CloudFront distribution
- Route53 DNS records
- ACM certificate (if custom domain)
- Lambda@Edge for Google OAuth authentication (optional)
"""

import hashlib
import io
import json
import logging
import re
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path

import boto3
import yaml
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


@dataclass
class InfrastructureStatus:
    """Status of infrastructure components."""

    bucket_exists: bool = False
    bucket_name: str = ""
    distribution_exists: bool = False
    distribution_id: str = ""
    distribution_domain: str = ""
    certificate_exists: bool = False
    certificate_arn: str = ""
    route53_record_exists: bool = False
    lambda_edge_exists: bool = False
    lambda_edge_arn: str = ""


def get_account_id() -> str:
    """Get the current AWS account ID."""
    sts = boto3.client("sts")
    return sts.get_caller_identity()["Account"]


def find_hosted_zone(domain: str, region: str) -> str | None:
    """Find Route53 hosted zone ID for a domain.

    Searches for an existing hosted zone that matches the domain.
    Tries exact match first, then parent domain.

    Args:
        domain: Domain name (e.g., reports.arato.io)
        region: AWS region

    Returns:
        Hosted zone ID if found, None otherwise
    """
    route53 = boto3.client("route53", region_name=region)

    # Normalize domain (add trailing dot for Route53)
    search_domains = [domain]
    # Also try parent domain (e.g., arato.io for reports.arato.io)
    parts = domain.split(".")
    if len(parts) > 2:
        parent = ".".join(parts[-2:])
        search_domains.append(parent)

    try:
        paginator = route53.get_paginator("list_hosted_zones")
        for page in paginator.paginate():
            for zone in page["HostedZones"]:
                zone_name = zone["Name"].rstrip(".")
                for search_domain in search_domains:
                    if zone_name == search_domain:
                        zone_id = zone["Id"].replace("/hostedzone/", "")
                        logger.info(f"  Found hosted zone: {zone_name} ({zone_id})")
                        return zone_id
        return None
    except ClientError as e:
        logger.warning(f"Error listing hosted zones: {e}")
        return None


def check_s3_bucket(bucket_name: str, region: str) -> tuple[bool, str]:
    """Check if S3 bucket exists and get its configuration.

    Returns:
        Tuple of (exists, bucket_region)
    """
    s3 = boto3.client("s3", region_name=region)

    try:
        s3.head_bucket(Bucket=bucket_name)
        # Get bucket region
        location_response = s3.get_bucket_location(Bucket=bucket_name)
        bucket_region = location_response.get("LocationConstraint") or "us-east-1"
        return True, bucket_region
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "")
        if error_code in ("404", "NoSuchBucket"):
            return False, ""
        elif error_code == "403":
            logger.warning(f"Bucket {bucket_name} exists but access denied")
            return True, region
        raise


def create_s3_bucket(bucket_name: str, region: str) -> None:
    """Create S3 bucket with proper configuration for static website hosting."""
    s3 = boto3.client("s3", region_name=region)

    logger.info(f"Creating S3 bucket: {bucket_name}")

    # Create bucket with region-specific configuration
    create_args: dict = {"Bucket": bucket_name}
    if region != "us-east-1":
        create_args["CreateBucketConfiguration"] = {"LocationConstraint": region}

    s3.create_bucket(**create_args)

    # Wait for bucket to be available
    waiter = s3.get_waiter("bucket_exists")
    waiter.wait(Bucket=bucket_name)

    # Block public access (CloudFront OAC will handle access)
    s3.put_public_access_block(
        Bucket=bucket_name,
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": True,
            "IgnorePublicAcls": True,
            "BlockPublicPolicy": True,
            "RestrictPublicBuckets": True,
        },
    )

    # Enable static website hosting for proper index.html routing
    s3.put_bucket_website(
        Bucket=bucket_name,
        WebsiteConfiguration={
            "IndexDocument": {"Suffix": "index.html"},
            "ErrorDocument": {"Key": "index.html"},
        },
    )

    logger.info(f"✓ S3 bucket {bucket_name} created")


def check_cloudfront_distribution(
    bucket_name: str, region: str
) -> tuple[bool, str, str]:
    """Check if CloudFront distribution exists for the bucket.

    Returns:
        Tuple of (exists, distribution_id, domain_name)
    """
    cf = boto3.client("cloudfront", region_name=region)

    try:
        response = cf.list_distributions()
        items = response.get("DistributionList", {}).get("Items", [])

        for dist in items:
            origins = dist.get("Origins", {}).get("Items", [])
            for origin in origins:
                domain = origin.get("DomainName", "")
                if bucket_name in domain:
                    return True, dist["Id"], dist["DomainName"]

        return False, "", ""
    except ClientError:
        return False, "", ""


def check_acm_certificate(domain: str, region: str) -> tuple[bool, str]:  # noqa: ARG001
    """Check if ACM certificate exists and is issued for domain.

    Note: ACM certificates for CloudFront must be in us-east-1 and ISSUED status.
    The region parameter is accepted for API consistency but not used.

    Returns:
        Tuple of (exists_and_issued, certificate_arn)
    """
    # CloudFront requires certificates in us-east-1
    acm = boto3.client("acm", region_name="us-east-1")

    try:
        # Only look for ISSUED certificates - PENDING_VALIDATION won't work with CloudFront
        response = acm.list_certificates(CertificateStatuses=["ISSUED"])

        for cert in response.get("CertificateSummaryList", []):
            if cert["DomainName"] == domain or domain in cert.get(
                "SubjectAlternativeNameSummaries", []
            ):
                return True, cert["CertificateArn"]

        # Also check for pending certificates to log helpful info
        pending_response = acm.list_certificates(
            CertificateStatuses=["PENDING_VALIDATION"]
        )
        for cert in pending_response.get("CertificateSummaryList", []):
            if cert["DomainName"] == domain or domain in cert.get(
                "SubjectAlternativeNameSummaries", []
            ):
                logger.warning(
                    f"Certificate for {domain} exists but is PENDING_VALIDATION. "
                    "DNS validation records may need to be created."
                )
                break

        return False, ""
    except ClientError:
        return False, ""


def create_acm_certificate(domain: str) -> str:
    """Create ACM certificate for domain, or return existing pending certificate.

    Note: CloudFront requires certificates in us-east-1.

    Returns:
        Certificate ARN
    """
    acm = boto3.client("acm", region_name="us-east-1")

    # First check if there's already a pending certificate we can use
    try:
        response = acm.list_certificates(CertificateStatuses=["PENDING_VALIDATION"])
        for cert in response.get("CertificateSummaryList", []):
            if cert["DomainName"] == domain or domain in cert.get(
                "SubjectAlternativeNameSummaries", []
            ):
                logger.info(
                    f"Found existing PENDING_VALIDATION certificate: {cert['CertificateArn']}"
                )
                return cert["CertificateArn"]
    except ClientError as exc:
        logger.debug("Failed to list ACM certificates in us-east-1: %s", exc)

    logger.info(f"Creating ACM certificate for {domain}")

    response = acm.request_certificate(
        DomainName=domain,
        ValidationMethod="DNS",
        Options={"CertificateTransparencyLoggingPreference": "ENABLED"},
    )

    cert_arn = response["CertificateArn"]
    logger.info(f"✓ Certificate requested: {cert_arn}")
    logger.info(
        "  NOTE: You need to validate the certificate via DNS before it can be used"
    )

    return cert_arn


def get_certificate_validation_records(cert_arn: str) -> list[dict]:
    """Get DNS validation records for a certificate."""
    acm = boto3.client("acm", region_name="us-east-1")

    response = acm.describe_certificate(CertificateArn=cert_arn)
    domain_validations = response["Certificate"].get("DomainValidationOptions", [])

    records = []
    for validation in domain_validations:
        if "ResourceRecord" in validation:
            records.append(validation["ResourceRecord"])

    return records


def create_route53_validation_records(
    hosted_zone_id: str, cert_arn: str, region: str
) -> None:
    """Create Route53 DNS records for certificate validation."""
    route53 = boto3.client("route53", region_name=region)
    records = get_certificate_validation_records(cert_arn)

    if not records:
        logger.warning("No validation records found for certificate")
        return

    changes = []
    for record in records:
        changes.append(
            {
                "Action": "UPSERT",
                "ResourceRecordSet": {
                    "Name": record["Name"],
                    "Type": record["Type"],
                    "TTL": 300,
                    "ResourceRecords": [{"Value": record["Value"]}],
                },
            }
        )

    route53.change_resource_record_sets(
        HostedZoneId=hosted_zone_id,
        ChangeBatch={"Changes": changes},
    )

    logger.info("✓ DNS validation records created")


def wait_for_certificate(cert_arn: str, timeout: int = 300) -> bool:
    """Wait for certificate to be issued.

    Returns:
        True if certificate was issued, False if timeout
    """
    acm = boto3.client("acm", region_name="us-east-1")

    logger.info("Waiting for certificate validation...")
    start_time = time.time()

    while time.time() - start_time < timeout:
        response = acm.describe_certificate(CertificateArn=cert_arn)
        status = response["Certificate"]["Status"]

        if status == "ISSUED":
            logger.info("✓ Certificate issued")
            return True
        elif status == "FAILED":
            logger.error("Certificate validation failed")
            return False

        time.sleep(10)

    logger.warning(f"Certificate validation timed out after {timeout}s")
    return False


def create_cloudfront_oac(bucket_name: str, region: str) -> str:
    """Create Origin Access Control for CloudFront.

    Returns:
        OAC ID
    """
    cf = boto3.client("cloudfront", region_name=region)
    oac_name = f"oac-{bucket_name}"

    # Check if OAC already exists
    try:
        response = cf.list_origin_access_controls()
        for oac in response.get("OriginAccessControlList", {}).get("Items", []):
            if oac["Name"] == oac_name:
                return oac["Id"]
    except ClientError as exc:
        logger.debug(
            "Failed to list existing CloudFront Origin Access Controls for %s: %s",
            bucket_name,
            exc,
        )

    logger.info(f"Creating Origin Access Control: {oac_name}")

    response = cf.create_origin_access_control(
        OriginAccessControlConfig={
            "Name": oac_name,
            "Description": f"OAC for {bucket_name}",
            "SigningProtocol": "sigv4",
            "SigningBehavior": "always",
            "OriginAccessControlOriginType": "s3",
        }
    )

    return response["OriginAccessControl"]["Id"]


def create_cloudfront_distribution(
    bucket_name: str,
    region: str,
    oac_id: str,
    domain: str | None = None,
    certificate_arn: str | None = None,
    lambda_edge_arn: str | None = None,
) -> tuple[str, str]:
    """Create CloudFront distribution.

    Returns:
        Tuple of (distribution_id, domain_name)
    """
    cf = boto3.client("cloudfront", region_name=region)

    logger.info("Creating CloudFront distribution...")

    # Build origin
    origin_id = f"S3-{bucket_name}"
    origin_domain = f"{bucket_name}.s3.{region}.amazonaws.com"

    distribution_config: dict = {
        "CallerReference": f"arato-reports-{int(time.time())}",
        "Comment": "Arato Agent Reports Distribution",
        "Enabled": True,
        "DefaultRootObject": "index.html",
        "Origins": {
            "Quantity": 1,
            "Items": [
                {
                    "Id": origin_id,
                    "DomainName": origin_domain,
                    "S3OriginConfig": {"OriginAccessIdentity": ""},
                    "OriginAccessControlId": oac_id,
                }
            ],
        },
        "DefaultCacheBehavior": {
            "TargetOriginId": origin_id,
            "ViewerProtocolPolicy": "redirect-to-https",
            "AllowedMethods": {
                "Quantity": 2,
                "Items": ["GET", "HEAD"],
                "CachedMethods": {"Quantity": 2, "Items": ["GET", "HEAD"]},
            },
            "CachePolicyId": "658327ea-f89d-4fab-a63d-7e88639e58f6",  # CachingOptimized
            "Compress": True,
        },
        "CustomErrorResponses": {
            "Quantity": 2,
            "Items": [
                {
                    "ErrorCode": 403,
                    "ResponseCode": "200",
                    "ResponsePagePath": "/index.html",
                    "ErrorCachingMinTTL": 10,
                },
                {
                    "ErrorCode": 404,
                    "ResponseCode": "200",
                    "ResponsePagePath": "/index.html",
                    "ErrorCachingMinTTL": 10,
                },
            ],
        },
        "PriceClass": "PriceClass_100",  # US, Canada, Europe
    }

    # Add custom domain and SSL if provided
    if domain and certificate_arn:
        distribution_config["Aliases"] = {"Quantity": 1, "Items": [domain]}
        distribution_config["ViewerCertificate"] = {
            "ACMCertificateArn": certificate_arn,
            "SSLSupportMethod": "sni-only",
            "MinimumProtocolVersion": "TLSv1.2_2021",
        }
    else:
        distribution_config["ViewerCertificate"] = {
            "CloudFrontDefaultCertificate": True,
        }

    # Add Lambda@Edge if provided
    if lambda_edge_arn:
        distribution_config["DefaultCacheBehavior"]["LambdaFunctionAssociations"] = {
            "Quantity": 1,
            "Items": [
                {
                    "LambdaFunctionARN": lambda_edge_arn,
                    "EventType": "viewer-request",
                    "IncludeBody": False,
                }
            ],
        }

    response = cf.create_distribution(DistributionConfig=distribution_config)
    dist = response["Distribution"]

    logger.info(f"✓ CloudFront distribution created: {dist['Id']}")
    logger.info(f"  Domain: {dist['DomainName']}")

    return dist["Id"], dist["DomainName"]


def update_cloudfront_lambda_edge(
    distribution_id: str,
    lambda_edge_arn: str,
    region: str,
) -> None:
    """Update CloudFront distribution with new Lambda@Edge version."""
    cf = boto3.client("cloudfront", region_name=region)

    # Get current distribution config
    response = cf.get_distribution_config(Id=distribution_id)
    config = response["DistributionConfig"]
    etag = response["ETag"]

    # Update Lambda@Edge association
    config["DefaultCacheBehavior"]["LambdaFunctionAssociations"] = {
        "Quantity": 1,
        "Items": [
            {
                "LambdaFunctionARN": lambda_edge_arn,
                "EventType": "viewer-request",
                "IncludeBody": False,
            }
        ],
    }

    # Update the distribution
    cf.update_distribution(
        Id=distribution_id,
        DistributionConfig=config,
        IfMatch=etag,
    )

    logger.info(
        f"✓ CloudFront distribution updated with new Lambda@Edge: {lambda_edge_arn}"
    )


def update_s3_bucket_policy(
    bucket_name: str, distribution_arn: str, region: str
) -> None:
    """Update S3 bucket policy to allow CloudFront access."""
    s3 = boto3.client("s3", region_name=region)

    policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "AllowCloudFrontServicePrincipal",
                "Effect": "Allow",
                "Principal": {"Service": "cloudfront.amazonaws.com"},
                "Action": "s3:GetObject",
                "Resource": f"arn:aws:s3:::{bucket_name}/*",
                "Condition": {"StringEquals": {"AWS:SourceArn": distribution_arn}},
            }
        ],
    }

    s3.put_bucket_policy(Bucket=bucket_name, Policy=json.dumps(policy))
    logger.info("✓ S3 bucket policy updated for CloudFront access")


def check_route53_record(
    hosted_zone_id: str, domain: str, region: str
) -> tuple[bool, str]:
    """Check if Route53 record exists for domain.

    Returns:
        Tuple of (exists, target_value)
    """
    route53 = boto3.client("route53", region_name=region)

    try:
        response = route53.list_resource_record_sets(
            HostedZoneId=hosted_zone_id,
            StartRecordName=domain,
            StartRecordType="A",
            MaxItems="1",
        )

        for record in response.get("ResourceRecordSets", []):
            if record["Name"].rstrip(".") == domain:
                if "AliasTarget" in record:
                    return True, record["AliasTarget"]["DNSName"]
                elif "ResourceRecords" in record:
                    return True, record["ResourceRecords"][0]["Value"]

        return False, ""
    except ClientError:
        return False, ""


def create_route53_record(
    hosted_zone_id: str,
    domain: str,
    distribution_domain: str,
    region: str,
) -> None:
    """Create Route53 alias record for CloudFront distribution."""
    route53 = boto3.client("route53", region_name=region)

    logger.info(f"Creating Route53 record: {domain} -> {distribution_domain}")

    route53.change_resource_record_sets(
        HostedZoneId=hosted_zone_id,
        ChangeBatch={
            "Changes": [
                {
                    "Action": "UPSERT",
                    "ResourceRecordSet": {
                        "Name": domain,
                        "Type": "A",
                        "AliasTarget": {
                            "HostedZoneId": "Z2FDTNDATAQYW2",  # CloudFront hosted zone ID
                            "DNSName": distribution_domain,
                            "EvaluateTargetHealth": False,
                        },
                    },
                }
            ]
        },
    )

    logger.info(f"✓ Route53 record created: {domain}")


def extract_prefixes_from_folders(bucket_name: str, region: str) -> list[str]:
    """Extract unique prefixes from folder names in S3 bucket.

    Scans the S3 bucket for folders matching pattern: {prefix}_{uuid}/
    Returns sorted list of unique prefixes found.

    Args:
        bucket_name: S3 bucket name
        region: AWS region

    Returns:
        List of unique prefixes (e.g., ['cloudinary', 'hibob', 'wix'])
    """
    s3 = boto3.client("s3", region_name=region)
    prefixes = set()

    # UUID pattern: 8-4-4-4-12 hex characters
    uuid_pattern = re.compile(
        r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$"
    )

    try:
        # List top-level "folders" (common prefixes)
        response = s3.list_objects_v2(Bucket=bucket_name, Delimiter="/", MaxKeys=1000)

        for prefix_obj in response.get("CommonPrefixes", []):
            folder_name = prefix_obj["Prefix"].rstrip("/")

            # Check if folder name matches {prefix}_{uuid} pattern
            if "_" in folder_name:
                parts = folder_name.rsplit("_", 1)
                if len(parts) == 2:
                    prefix_part, uuid_part = parts
                    if uuid_pattern.match(uuid_part):
                        # Valid prefix_uuid pattern
                        prefixes.add(prefix_part)
            # Also check if it's a standalone UUID (no prefix)
            elif uuid_pattern.match(folder_name):
                prefixes.add("")  # Empty string prefix

    except ClientError as e:
        logger.warning(f"Could not list S3 bucket to extract prefixes: {e}")
        return []  # Return empty list on error

    # Return sorted list (empty string last)
    prefix_list = sorted([p for p in prefixes if p] + [p for p in prefixes if not p])
    return prefix_list


def check_lambda_edge_function(function_name: str) -> tuple[bool, str]:
    """Check if Lambda@Edge function exists.

    Note: Lambda@Edge functions must be in us-east-1.

    Returns:
        Tuple of (exists, function_arn)
    """
    lambda_client = boto3.client("lambda", region_name="us-east-1")

    try:
        response = lambda_client.get_function(FunctionName=function_name)
        # Get the latest published version for Lambda@Edge
        versions = lambda_client.list_versions_by_function(FunctionName=function_name)
        versions_list = versions.get("Versions", [])
        if versions_list:
            # Get the latest version (excluding $LATEST)
            published_versions = [v for v in versions_list if v["Version"] != "$LATEST"]
            if published_versions:
                latest = max(published_versions, key=lambda v: int(v["Version"]))
                return True, latest["FunctionArn"]
        return True, response["Configuration"]["FunctionArn"]
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceNotFoundException":
            return False, ""
        raise


def get_lambda_edge_code() -> str:
    """Get the Lambda@Edge function code for Google OAuth authentication.

    Loads handler and templates from external files for better maintainability.
    """
    # Get the lambda_edge directory
    lambda_edge_dir = Path(__file__).parent / "lambda_edge"

    # Read handler code
    handler_path = lambda_edge_dir / "handler.py"
    handler_code = handler_path.read_text()

    # Read templates code
    templates_path = lambda_edge_dir / "templates.py"
    templates_code = templates_path.read_text()

    # Combine handler and templates into a single deployable module
    # The handler imports from .templates, so we need to inline it
    # Remove all template import statements since we're inlining them
    handler_code_clean = handler_code
    for import_line in [
        "from .templates import NO_ACCESS_TEMPLATE",
        "from .templates import FOLDER_LIST_TEMPLATE",
        "from .templates import FORBIDDEN_INVALID_PATH_TEMPLATE",
        "from .templates import FORBIDDEN_NO_ACCESS_TEMPLATE",
    ]:
        handler_code_clean = handler_code_clean.replace(
            import_line, "# Templates inlined above"
        )

    combined_code = f"""# Combined Lambda@Edge code (auto-generated from external files)
# DO NOT EDIT - Changes will be overwritten on next deployment

{templates_code}

# Handler code with templates inlined
{handler_code_clean}
"""

    return combined_code


def create_lambda_edge_function(
    function_name: str,
    google_client_id: str,
    google_client_secret: str,
    access_config: dict,
    bucket_name: str,
) -> str:
    """Create Lambda@Edge function for Google OAuth.

    Note: Lambda@Edge functions must be in us-east-1.

    Args:
        function_name: Name of the Lambda function
        google_client_id: Google OAuth client ID
        google_client_secret: Google OAuth client secret
        access_config: Access control configuration dict with 'all' and 'folders' keys
        bucket_name: S3 bucket name for runtime prefix discovery

    Returns:
        Function ARN (versioned)
    """
    lambda_client = boto3.client("lambda", region_name="us-east-1")
    iam = boto3.client("iam")

    # Create IAM role for Lambda@Edge
    role_name = f"{function_name}-role"

    assume_role_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "Service": ["lambda.amazonaws.com", "edgelambda.amazonaws.com"]
                },
                "Action": "sts:AssumeRole",
            }
        ],
    }

    try:
        iam.get_role(RoleName=role_name)
        logger.info(f"IAM role {role_name} already exists")
    except ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchEntity":
            logger.info(f"Creating IAM role: {role_name}")

            iam.create_role(
                RoleName=role_name,
                AssumeRolePolicyDocument=json.dumps(assume_role_policy),
                Description="Lambda@Edge execution role for Arato reports auth",
            )
            iam.attach_role_policy(
                RoleName=role_name,
                PolicyArn="arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
            )

            # Add S3 read permission for runtime prefix discovery
            s3_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": "s3:ListBucket",
                        "Resource": f"arn:aws:s3:::{bucket_name}",
                    }
                ],
            }
            iam.put_role_policy(
                RoleName=role_name,
                PolicyName="S3ListBucketAccess",
                PolicyDocument=json.dumps(s3_policy),
            )

            # Wait for role to propagate
            time.sleep(10)
        else:
            raise

    role_arn = iam.get_role(RoleName=role_name)["Role"]["Arn"]

    # Create Lambda function
    logger.info(f"Creating Lambda@Edge function: {function_name}")

    secret_key = hashlib.sha256(
        f"{google_client_id}-{function_name}".encode()
    ).hexdigest()[:32]

    code = get_lambda_edge_code()

    # Lambda@Edge doesn't support environment variables, so we need to inject them
    # Use regex with lambda and repr() to safely escape special characters and prevent injection
    code = re.sub(
        r"GOOGLE_CLIENT_ID = os\.environ\.get\(['\"]GOOGLE_CLIENT_ID['\"],\s*['\"]['\"]?\)",
        lambda _m: f"GOOGLE_CLIENT_ID = {repr(google_client_id)}",
        code,
    )
    code = re.sub(
        r"GOOGLE_CLIENT_SECRET = os\.environ\.get\(['\"]GOOGLE_CLIENT_SECRET['\"],\s*['\"]['\"]?\)",
        lambda _m: f"GOOGLE_CLIENT_SECRET = {repr(google_client_secret)}",
        code,
    )
    code = re.sub(
        r"ACCESS_CONFIG = \{\}",
        lambda _m: f"ACCESS_CONFIG = {repr(access_config)}",
        code,
    )
    code = re.sub(
        r"SECRET_KEY = os\.environ\.get\(['\"]SECRET_KEY['\"],\s*['\"]change-me-in-production['\"]?\)",
        lambda _m: f"SECRET_KEY = {repr(secret_key)}",
        code,
    )
    code = re.sub(
        r"S3_BUCKET_NAME = ['\"]['\"]?",
        lambda _m: f"S3_BUCKET_NAME = {repr(bucket_name)}",
        code,
    )

    # Create zip file in memory

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("index.py", code)
    zip_buffer.seek(0)

    try:
        # Try to update existing function
        lambda_client.update_function_code(
            FunctionName=function_name,
            ZipFile=zip_buffer.getvalue(),
        )
        logger.info(f"Updated Lambda function: {function_name}")
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceNotFoundException":
            # Create new function
            lambda_client.create_function(
                FunctionName=function_name,
                Runtime="python3.12",
                Role=role_arn,
                Handler="index.handler",
                Code={"ZipFile": zip_buffer.getvalue()},
                Description="Lambda@Edge function for Google OAuth authentication",
                Timeout=5,
                MemorySize=128,
                Publish=False,
            )
            logger.info(f"Created Lambda function: {function_name}")
        else:
            raise

    # Wait for function to be active
    logger.info("Waiting for Lambda function to become active...")
    waiter = lambda_client.get_waiter("function_active_v2")
    waiter.wait(
        FunctionName=function_name, WaiterConfig={"Delay": 5, "MaxAttempts": 60}
    )
    logger.info("Lambda function is active")

    # Publish a new version (required for Lambda@Edge)
    # Retry loop to handle ResourceConflictException during updates
    max_retries = 10
    response = None
    for attempt in range(max_retries):
        try:
            response = lambda_client.publish_version(
                FunctionName=function_name,
                Description="Lambda@Edge deployment",
            )
            break
        except ClientError as e:
            if (
                e.response["Error"]["Code"] == "ResourceConflictException"
                and attempt < max_retries - 1
            ):
                logger.info(
                    f"Lambda update still in progress, waiting... (attempt {attempt + 1}/{max_retries})"
                )
                time.sleep(5)
            else:
                raise

    if response is None:
        raise RuntimeError("Failed to publish Lambda version after retries")

    version_arn = response["FunctionArn"]
    logger.info(f"✓ Lambda@Edge function published: {version_arn}")

    return version_arn


def run_setup(
    bucket_name: str,
    domain: str | None,
    hosted_zone_id: str | None,
    google_client_id: str | None,
    google_client_secret: str | None,
    access_config_path: str | None,
    region: str,
    stack_name: str,
    dry_run: bool,
    force_update_lambda: bool = False,
) -> None:
    """Run the setup command."""
    logger.info("=" * 60)
    logger.info("Arato Agent Reports Infrastructure Setup")
    logger.info("=" * 60)

    if dry_run:
        logger.info("DRY RUN MODE - No changes will be made")
    logger.info("")

    # Load access control configuration
    access_config: dict = {"all": [], "folders": {}, "prefixes": []}
    if access_config_path:
        config_file = Path(access_config_path)
        if config_file.exists():
            with open(config_file) as f:
                raw_config = yaml.safe_load(f) or {}
            # Normalize the config
            access_config["all"] = raw_config.get("all", [])
            access_config["folders"] = {
                k.upper(): v  # Normalize UUIDs to uppercase
                for k, v in raw_config.get("folders", {}).items()
            }
            logger.info(f"Loaded access config from: {access_config_path}")
            logger.info(f"  Global access: {len(access_config['all'])} entries")
            logger.info(f"  Folder rules: {len(access_config['folders'])} folders")
        else:
            logger.warning(f"Access config file not found: {access_config_path}")

    # Lookup hosted zone if domain provided but zone ID not
    if domain and not hosted_zone_id:
        logger.info(f"Looking up hosted zone for domain: {domain}")
        hosted_zone_id = find_hosted_zone(domain, region)
        if not hosted_zone_id:
            logger.error(
                f"Could not find Route53 hosted zone for domain '{domain}'.\n"
                f"Please create a hosted zone for '{domain}' or its parent domain first,\n"
                f"or specify --hosted-zone-id explicitly."
            )
            raise ValueError(f"No hosted zone found for domain: {domain}")

    if google_client_id and not google_client_secret:
        logger.error(
            "--google-client-secret is required when --google-client-id is specified"
        )
        raise ValueError("Missing google-client-secret")

    account_id = get_account_id()
    logger.info(f"AWS Account: {account_id}")
    logger.info(f"Region: {region}")
    logger.info(f"Bucket: {bucket_name}")
    if domain:
        logger.info(f"Domain: {domain}")
    if google_client_id:
        logger.info("Google OAuth: Enabled")
        if access_config_path:
            logger.info(f"Access config: {access_config_path}")
    logger.info("")

    # Check existing infrastructure
    logger.info("Checking existing infrastructure...")
    status = InfrastructureStatus()

    # Check S3 bucket
    bucket_exists, bucket_region = check_s3_bucket(bucket_name, region)
    status.bucket_exists = bucket_exists
    status.bucket_name = bucket_name

    if bucket_exists:
        logger.info(f"  ✓ S3 bucket exists: {bucket_name} (region: {bucket_region})")
    else:
        logger.info(f"  ✗ S3 bucket does not exist: {bucket_name}")

    # Check CloudFront distribution
    dist_exists, dist_id, dist_domain = check_cloudfront_distribution(
        bucket_name, region
    )
    status.distribution_exists = dist_exists
    status.distribution_id = dist_id
    status.distribution_domain = dist_domain

    if dist_exists:
        logger.info(f"  ✓ CloudFront distribution exists: {dist_id}")
        logger.info(f"    Domain: {dist_domain}")
    else:
        logger.info("  ✗ CloudFront distribution does not exist")

    # Check ACM certificate
    if domain:
        cert_exists, cert_arn = check_acm_certificate(domain, region)
        status.certificate_exists = cert_exists
        status.certificate_arn = cert_arn

        if cert_exists:
            logger.info(f"  ✓ ACM certificate exists for {domain}")
        else:
            logger.info(f"  ✗ ACM certificate does not exist for {domain}")

        # Check Route53 record
        # hosted_zone_id is guaranteed to be set here because we validate above
        assert hosted_zone_id is not None
        record_exists, record_value = check_route53_record(
            hosted_zone_id, domain, region
        )
        status.route53_record_exists = record_exists

        if record_exists:
            logger.info(f"  ✓ Route53 record exists: {domain} -> {record_value}")
        else:
            logger.info(f"  ✗ Route53 record does not exist for {domain}")

    # Check Lambda@Edge
    if google_client_id:
        function_name = f"{stack_name}-auth"
        lambda_exists, lambda_arn = check_lambda_edge_function(function_name)
        status.lambda_edge_exists = lambda_exists
        status.lambda_edge_arn = lambda_arn

        if lambda_exists:
            logger.info(f"  ✓ Lambda@Edge function exists: {function_name}")
        else:
            logger.info(f"  ✗ Lambda@Edge function does not exist: {function_name}")

    logger.info("")

    # Summary of what needs to be created
    actions_needed = []

    if not status.bucket_exists:
        actions_needed.append(f"Create S3 bucket: {bucket_name}")

    if google_client_id and not status.lambda_edge_exists:
        actions_needed.append(f"Create Lambda@Edge function: {stack_name}-auth")
    elif google_client_id and force_update_lambda and status.lambda_edge_exists:
        actions_needed.append(f"Update Lambda@Edge function: {stack_name}-auth")

    if domain and not status.certificate_exists:
        actions_needed.append(f"Create ACM certificate for: {domain}")

    if not status.distribution_exists:
        actions_needed.append("Create CloudFront distribution")
    elif google_client_id and not status.lambda_edge_exists:
        actions_needed.append("Update CloudFront distribution with Lambda@Edge")

    if domain and hosted_zone_id and not status.route53_record_exists:
        actions_needed.append(f"Create Route53 record: {domain}")

    if actions_needed:
        logger.info("Actions needed:")
        for action in actions_needed:
            logger.info(f"  → {action}")
    else:
        logger.info("✓ All infrastructure is already in place")
        return

    if dry_run:
        logger.info("")
        logger.info("Run without --dry-run to create the infrastructure")
        return

    logger.info("")
    logger.info("Creating infrastructure...")
    logger.info("")

    # Step 1: Create S3 bucket
    if not status.bucket_exists:
        create_s3_bucket(bucket_name, region)
        status.bucket_exists = True

    # Step 2: Create or update Lambda@Edge if needed
    if google_client_id and (not status.lambda_edge_exists or force_update_lambda):
        function_name = f"{stack_name}-auth"
        if force_update_lambda and status.lambda_edge_exists:
            logger.info(f"Force updating Lambda@Edge function: {function_name}")
        status.lambda_edge_arn = create_lambda_edge_function(
            function_name=function_name,
            google_client_id=google_client_id,
            google_client_secret=google_client_secret,  # type: ignore - validated above
            access_config=access_config,
            bucket_name=bucket_name,
        )
        status.lambda_edge_exists = True

        # Update CloudFront distribution if it exists (for force updates)
        if (
            force_update_lambda
            and status.distribution_exists
            and status.distribution_id
        ):
            update_cloudfront_lambda_edge(
                distribution_id=status.distribution_id,
                lambda_edge_arn=status.lambda_edge_arn,
                region=region,
            )

    # Step 3: Create ACM certificate if needed
    if domain and not status.certificate_exists:
        status.certificate_arn = create_acm_certificate(domain)
        status.certificate_exists = True

        # Create DNS validation records if hosted zone provided
        if hosted_zone_id:
            # Wait a moment for the validation records to be available
            time.sleep(5)
            create_route53_validation_records(
                hosted_zone_id, status.certificate_arn, region
            )

            # Wait for certificate to be issued
            if not wait_for_certificate(status.certificate_arn, timeout=600):
                logger.warning(
                    "Certificate not yet issued. Proceeding without custom domain."
                )
                status.certificate_exists = False

    # Step 4: Create CloudFront OAC
    oac_id = create_cloudfront_oac(bucket_name, region)

    # Step 5: Create or update CloudFront distribution
    if not status.distribution_exists:
        status.distribution_id, status.distribution_domain = (
            create_cloudfront_distribution(
                bucket_name=bucket_name,
                region=region,
                oac_id=oac_id,
                domain=domain if status.certificate_exists else None,
                certificate_arn=status.certificate_arn
                if status.certificate_exists
                else None,
                lambda_edge_arn=status.lambda_edge_arn
                if status.lambda_edge_exists
                else None,
            )
        )
        status.distribution_exists = True

        # Update S3 bucket policy
        distribution_arn = (
            f"arn:aws:cloudfront::{account_id}:distribution/{status.distribution_id}"
        )
        update_s3_bucket_policy(bucket_name, distribution_arn, region)

    # Step 6: Create Route53 record
    if (
        domain
        and hosted_zone_id
        and not status.route53_record_exists
        and status.distribution_domain
    ):
        create_route53_record(
            hosted_zone_id=hosted_zone_id,
            domain=domain,
            distribution_domain=status.distribution_domain,
            region=region,
        )

    logger.info("")
    logger.info("=" * 60)
    logger.info("✓ Setup Complete")
    logger.info("=" * 60)
    logger.info(f"S3 Bucket: {bucket_name}")
    logger.info(f"CloudFront Distribution: {status.distribution_id}")
    logger.info(f"CloudFront Domain: https://{status.distribution_domain}")
    if domain:
        logger.info(f"Custom Domain: https://{domain}")
    if status.lambda_edge_exists:
        logger.info("Lambda@Edge Auth: Enabled")
    logger.info("")
    logger.info("To sync content, run:")
    logger.info("  uv run devops sync <folder> --invalidate")
