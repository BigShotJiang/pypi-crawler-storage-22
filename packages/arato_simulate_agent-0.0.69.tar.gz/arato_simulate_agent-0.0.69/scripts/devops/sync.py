"""Sync command for uploading report folders to S3.

Syncs a local folder to the reports S3 bucket and optionally
creates a CloudFront invalidation.
"""

import logging
import mimetypes
import os
import time
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


def get_content_type(file_path: str) -> str:
    """Get the content type for a file based on its extension."""
    content_type, _ = mimetypes.guess_type(file_path)

    # Default mappings for common web files
    extension_map = {
        ".html": "text/html",
        ".css": "text/css",
        ".js": "application/javascript",
        ".json": "application/json",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".svg": "image/svg+xml",
        ".ico": "image/x-icon",
        ".webm": "video/webm",
        ".mp4": "video/mp4",
        ".woff": "font/woff",
        ".woff2": "font/woff2",
        ".ttf": "font/ttf",
        ".eot": "application/vnd.ms-fontobject",
        ".md": "text/markdown",
        ".txt": "text/plain",
    }

    ext = Path(file_path).suffix.lower()
    return extension_map.get(ext, content_type or "application/octet-stream")


def get_files_to_sync(folder: Path) -> list[tuple[Path, str]]:
    """Get list of files to sync with their relative paths.

    Returns:
        List of tuples (absolute_path, relative_path)
    """
    files = []

    for root, _, filenames in os.walk(folder):
        for filename in filenames:
            # Skip hidden files and directories
            if filename.startswith("."):
                continue

            abs_path = Path(root) / filename
            rel_path = abs_path.relative_to(folder)
            files.append((abs_path, str(rel_path)))

    return files


def check_bucket_exists(bucket_name: str, region: str) -> bool:
    """Check if S3 bucket exists."""
    s3 = boto3.client("s3", region_name=region)

    try:
        s3.head_bucket(Bucket=bucket_name)
        return True
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "")
        if error_code in ("404", "NoSuchBucket"):
            return False
        elif error_code == "403":
            logger.warning(f"Bucket {bucket_name} exists but access denied")
            return True
        raise


def check_prefix_exists(bucket_name: str, prefix: str, region: str) -> bool:
    """Check if any objects exist under the given S3 prefix."""
    s3 = boto3.client("s3", region_name=region)

    try:
        response = s3.list_objects_v2(
            Bucket=bucket_name,
            Prefix=prefix,
            MaxKeys=1,
        )
        return response.get("KeyCount", 0) > 0
    except ClientError:
        return False


def upload_file(
    s3_client,
    bucket_name: str,
    local_path: Path,
    s3_key: str,
) -> None:
    """Upload a single file to S3."""
    content_type = get_content_type(str(local_path))

    # Determine cache control based on file type
    ext = local_path.suffix.lower()
    if ext in [".html", ".json"]:
        # Don't cache HTML and JSON
        cache_control = "no-cache, no-store, must-revalidate"
    elif ext in [".js", ".css", ".woff", ".woff2", ".ttf"]:
        # Cache static assets for 1 year (with hashed filenames)
        cache_control = "public, max-age=31536000, immutable"
    else:
        # Cache other assets for 1 day
        cache_control = "public, max-age=86400"

    s3_client.upload_file(
        str(local_path),
        bucket_name,
        s3_key,
        ExtraArgs={
            "ContentType": content_type,
            "CacheControl": cache_control,
        },
    )


def sync_folder_to_s3(
    folder: Path,
    bucket_name: str,
    prefix: str,
    region: str,
    dry_run: bool = False,
) -> int:
    """Sync a folder to S3.

    Returns:
        Number of files uploaded
    """
    s3 = boto3.client("s3", region_name=region)
    files = get_files_to_sync(folder)

    if not files:
        logger.warning(f"No files found in {folder}")
        return 0

    logger.info(f"Syncing {len(files)} files to s3://{bucket_name}/{prefix}")

    uploaded = 0
    for abs_path, rel_path in files:
        s3_key = f"{prefix}/{rel_path}" if prefix else rel_path

        if dry_run:
            logger.info(f"  Would upload: {rel_path} -> s3://{bucket_name}/{s3_key}")
        else:
            logger.info(f"  Uploading: {rel_path}")
            upload_file(s3, bucket_name, abs_path, s3_key)

        uploaded += 1

    return uploaded


def get_distribution_for_bucket(bucket_name: str, region: str) -> str | None:
    """Find CloudFront distribution ID for a bucket."""
    cf = boto3.client("cloudfront", region_name=region)

    try:
        response = cf.list_distributions()
        items = response.get("DistributionList", {}).get("Items", [])

        for dist in items:
            origins = dist.get("Origins", {}).get("Items", [])
            for origin in origins:
                domain = origin.get("DomainName", "")
                if bucket_name in domain:
                    return dist["Id"]

        return None
    except ClientError:
        return None


def create_invalidation(
    distribution_id: str,
    paths: list[str],
    region: str,
) -> str:
    """Create CloudFront invalidation.

    Returns:
        Invalidation ID
    """
    cf = boto3.client("cloudfront", region_name=region)

    caller_reference = f"sync-{int(time.time())}"

    response = cf.create_invalidation(
        DistributionId=distribution_id,
        InvalidationBatch={
            "Paths": {
                "Quantity": len(paths),
                "Items": paths,
            },
            "CallerReference": caller_reference,
        },
    )

    return response["Invalidation"]["Id"]


def run_sync(
    folder: str,
    bucket_name: str,
    prefix: str | None,
    invalidate: bool,
    distribution_id: str | None,
    region: str,
    dry_run: bool,
) -> None:
    """Run the sync command."""
    folder_path = Path(folder)

    if not folder_path.exists():
        logger.error(f"Folder does not exist: {folder}")
        raise FileNotFoundError(f"Folder not found: {folder}")

    if not folder_path.is_dir():
        logger.error(f"Path is not a directory: {folder}")
        raise ValueError(f"Not a directory: {folder}")

    # Use folder name as prefix if not specified
    if prefix is None:
        prefix = folder_path.name

    logger.info("=" * 60)
    logger.info("Arato Agent Reports Sync")
    logger.info("=" * 60)

    if dry_run:
        logger.info("DRY RUN MODE - No changes will be made")
    logger.info("")

    logger.info(f"Source folder: {folder_path.absolute()}")
    logger.info(f"Destination: s3://{bucket_name}/{prefix}")
    logger.info("")

    # Check bucket exists
    if not check_bucket_exists(bucket_name, region):
        logger.error(f"Bucket does not exist: {bucket_name}")
        logger.error("Run 'uv run devops setup' first to create the infrastructure")
        raise ValueError(f"Bucket not found: {bucket_name}")

    # Check if prefix already has content (for invalidation)
    prefix_had_content = check_prefix_exists(bucket_name, prefix, region)

    if prefix_had_content:
        logger.info(f"Existing content found at s3://{bucket_name}/{prefix}")
    else:
        logger.info(f"No existing content at s3://{bucket_name}/{prefix}")

    logger.info("")

    # Sync files
    uploaded = sync_folder_to_s3(
        folder=folder_path,
        bucket_name=bucket_name,
        prefix=prefix,
        region=region,
        dry_run=dry_run,
    )

    if dry_run:
        logger.info("")
        logger.info(f"Would upload {uploaded} files")
    else:
        logger.info("")
        logger.info(f"✓ Uploaded {uploaded} files")

    # Create invalidation if requested and content existed
    if invalidate and (prefix_had_content or not dry_run):
        # Get distribution ID if not provided
        if not distribution_id:
            distribution_id = get_distribution_for_bucket(bucket_name, region)

        if not distribution_id:
            logger.warning("Could not find CloudFront distribution for bucket")
            logger.warning("Skipping invalidation")
            return

        # Create invalidation for the synced prefix
        invalidation_path = f"/{prefix}/*"

        if dry_run:
            logger.info(
                f"Would create CloudFront invalidation for: {invalidation_path}"
            )
        else:
            logger.info(f"Creating CloudFront invalidation for: {invalidation_path}")
            invalidation_id = create_invalidation(
                distribution_id=distribution_id,
                paths=[invalidation_path],
                region=region,
            )
            logger.info(f"✓ Invalidation created: {invalidation_id}")

    logger.info("")
    logger.info("=" * 60)
    if dry_run:
        logger.info("DRY RUN COMPLETE")
        logger.info("Run without --dry-run to sync files")
    else:
        logger.info("✓ Sync Complete")

        # Try to get the CloudFront domain
        if not distribution_id:
            distribution_id = get_distribution_for_bucket(bucket_name, region)

        if distribution_id:
            cf = boto3.client("cloudfront", region_name=region)
            try:
                dist = cf.get_distribution(Id=distribution_id)
                domain = dist["Distribution"]["DomainName"]
                aliases = (
                    dist["Distribution"]["DistributionConfig"]
                    .get("Aliases", {})
                    .get("Items", [])
                )

                if aliases:
                    logger.info(f"View at: https://{aliases[0]}/{prefix}/")
                else:
                    logger.info(f"View at: https://{domain}/{prefix}/")
            except ClientError as _exc:
                logger.exception("Failed to fetch CloudFront distribution details")

    logger.info("=" * 60)
