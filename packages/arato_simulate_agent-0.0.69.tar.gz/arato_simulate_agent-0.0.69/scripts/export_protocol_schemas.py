"""Export communication protocol Pydantic models as a single JSON Schema file.

Generates a combined schema from all agent-server protocol types so that
TypeScript equivalents can be auto-generated via json-schema-to-typescript.

Usage:
    uv run export-protocol-schemas
"""

import json
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel

from core.schemas import (
    AgentCommand,
    AgentCommandResponse,
    AgentIdentity,
    AppDiscoveryProgressInfo,
    ArtifactsInfo,
    HITLInterventionInfo,
    OrchestratorProgressInfo,
    PersonaProgressInfo,
    PersonaResult,
    ProgressSnapshot,
    TaskGoal,
    TaskPayload,
    TaskResult,
    TaskStatus,
    TaskUpdate,
    TranscriptTurn,
)

OUTPUT_DIR = (
    Path(__file__).parent.parent.parent
    / "app"
    / "apps"
    / "server"
    / "src"
    / "core"
    / "domain"
    / "generated"
)

# Protocol models to export (BaseModel subclasses)
MODELS: dict[str, type[BaseModel]] = {
    "TaskPayload": TaskPayload,
    "TaskUpdate": TaskUpdate,
    "TaskResult": TaskResult,
    "AgentCommandResponse": AgentCommandResponse,
    "ProgressSnapshot": ProgressSnapshot,
    "OrchestratorProgressInfo": OrchestratorProgressInfo,
    "PersonaProgressInfo": PersonaProgressInfo,
    "AppDiscoveryProgressInfo": AppDiscoveryProgressInfo,
    "TranscriptTurn": TranscriptTurn,
    "PersonaResult": PersonaResult,
    "ArtifactsInfo": ArtifactsInfo,
    "AgentIdentity": AgentIdentity,
    "HITLInterventionInfo": HITLInterventionInfo,
}

# StrEnum types to export as string enums
ENUMS: dict[str, type[StrEnum]] = {
    "TaskStatus": TaskStatus,
    "TaskGoal": TaskGoal,
    "AgentCommand": AgentCommand,
}


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    combined_defs: dict[str, dict] = {}

    # Process each Pydantic model
    for name, model in MODELS.items():
        schema = model.model_json_schema()
        # Collect nested $defs (referenced sub-models/enums)
        defs = schema.pop("$defs", {})
        combined_defs.update(defs)
        # Store the top-level model schema itself as a definition
        combined_defs[name] = schema

    # Add StrEnum types as string enum schemas
    for name, enum_cls in ENUMS.items():
        combined_defs[name] = {
            "type": "string",
            "enum": [e.value for e in enum_cls],
            "description": enum_cls.__doc__ or f"{name} enum",
        }

    # Build the combined schema
    combined_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "description": "Arato agent-server communication protocol types. Auto-generated from Pydantic models.",
        "$defs": combined_defs,
        # Root schema is a no-op — all types live in $defs
        "type": "object",
        "additionalProperties": False,
    }

    out = OUTPUT_DIR / "agent-protocol.schema.json"
    out.write_text(json.dumps(combined_schema, indent=2) + "\n")
    print(f"  {out}")
    print(
        f"\nExported {len(MODELS)} models + {len(ENUMS)} enums to {out.relative_to(OUTPUT_DIR.parent.parent.parent.parent.parent.parent)}"
    )


if __name__ == "__main__":
    main()
