"""Generate JSON Schema files from Pydantic config models.

Produces schema files in config/schemas/ that provide editor
autocompletion and validation for YAML config files via the
Red Hat YAML VS Code extension (or any JSON-Schema-aware editor).

Usage:
    uv run generate-schemas
"""

import json
from pathlib import Path

from pydantic import BaseModel

from core.validation.config_schemas import (
    DomainSchema,
    GroundTruthAgentConfigSchema,
    PersonaSchema,
    RoleSchema,
    ScenarioSchema,
    TestSuiteSchema,
)

SCHEMAS_DIR = Path(__file__).parent.parent / "config" / "schemas"

SCHEMAS: dict[str, type[BaseModel]] = {
    "domain": DomainSchema,
    "scenario": ScenarioSchema,
    "role": RoleSchema,
    "persona": PersonaSchema,
    "ground_truth_agent": GroundTruthAgentConfigSchema,
    "test_suite": TestSuiteSchema,
}


def main() -> None:
    SCHEMAS_DIR.mkdir(parents=True, exist_ok=True)

    for name, model in SCHEMAS.items():
        schema = model.model_json_schema()
        schema["$schema"] = "http://json-schema.org/draft-07/schema#"
        out = SCHEMAS_DIR / f"{name}.schema.json"
        out.write_text(json.dumps(schema, indent=2) + "\n")
        print(f"  {out.relative_to(SCHEMAS_DIR.parent.parent)}")

    print(
        f"\nGenerated {len(SCHEMAS)} schemas in {SCHEMAS_DIR.relative_to(SCHEMAS_DIR.parent.parent)}/"
    )


if __name__ == "__main__":
    main()
