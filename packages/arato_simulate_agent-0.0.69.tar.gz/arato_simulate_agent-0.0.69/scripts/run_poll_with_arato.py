#!/usr/bin/env python3
"""Script to run the agent locally with ARATO API configuration.

This script runs the agent in local mode with pre-configured ARATO API settings
for logging and monitoring.
"""

import asyncio
import json
import os
import sys

from platforms.local.adapter import LocalPlatformAdapter

# ARATO API Configuration
ARATO_API_URL = os.environ.get("ARATO_API_URL", "https://dev.arato.io/api")
ARATO_API_KEY = os.environ.get("ARATO_API_KEY", "")


def main() -> None:
    """Run the agent with ARATO configuration.

    Usage:
        uv run run-poll-with-arato <target_url> [persona_ids] [max_turns]

    Examples:
        uv run run-poll-with-arato https://example.com
        uv run run-poll-with-arato https://example.com nice_user,malicious_user
        uv run run-poll-with-arato https://example.com nice_user:2,malicious_user:1 10
    """
    if len(sys.argv) < 2:
        print(
            "Usage: uv run run-poll-with-arato <target_url> [persona_ids] [max_turns]"
        )
        print("")
        print("Examples:")
        print("  uv run run-poll-with-arato https://example.com")
        print(
            "  uv run run-poll-with-arato https://example.com nice_user,malicious_user"
        )
        print(
            "  uv run run-poll-with-arato https://example.com nice_user:2,malicious_user:1 10"
        )
        print("")
        print("ARATO Configuration:")
        print(f"  API URL: {ARATO_API_URL}")
        sys.exit(1)

    target_url = sys.argv[1].strip()
    persona_ids = None
    max_turns = 10

    if len(sys.argv) >= 3:
        persona_str = sys.argv[2].strip()
        if persona_str:
            persona_ids = [p.strip() for p in persona_str.split(",")]

    if len(sys.argv) >= 4:
        try:
            max_turns = int(sys.argv[3])
        except ValueError:
            print(f"❌ Invalid max_turns value: {sys.argv[3]}")
            sys.exit(1)

    if not target_url:
        print("❌ target_url must be a non-empty string")
        sys.exit(1)

    print("🏠 Running agent locally with ARATO configuration...")
    print(f"   URL: {target_url}")
    print(f"   Personas: {persona_ids or ['nice_user']}")
    print(f"   Max turns: {max_turns}")
    print(f"   ARATO API: {ARATO_API_URL}")
    print()

    try:
        # Initialize local platform adapter
        adapter = LocalPlatformAdapter()

        # Run pipeline with ARATO configuration
        result = asyncio.run(
            adapter.run_pipeline(
                target_url=target_url,
                persona_ids=persona_ids,
                max_turns=max_turns,
                seed_utterance="Hello!",
                arato_api_url=ARATO_API_URL,
                arato_api_key=ARATO_API_KEY,
            )
        )

        print("\n✅ Execution completed!")
        print(f"\nResult: {json.dumps(result, indent=2)}")

        # Check for errors
        if result.get("status") == "error":
            print("\n⚠️  Execution completed with errors. Check logs for details.")
            sys.exit(1)

    except KeyboardInterrupt:
        print("\n\n⚠️  Execution interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Execution failed: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
