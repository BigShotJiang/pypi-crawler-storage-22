#!/usr/bin/env python3
"""
Run a local HTTP server to view the generated report.

Usage:
    uv run serve <session_folder>
"""

import argparse
import logging
import sys
import threading
import webbrowser
from pathlib import Path

from flask import Flask, send_from_directory
from flask_cors import CORS


def main():
    parser = argparse.ArgumentParser(description="Run local report server")
    parser.add_argument(
        "session_folder",
        type=str,
        help="Path to session folder containing report entry point",
    )
    parser.add_argument(
        "--port", type=int, default=8000, help="Port to bind to (default: 8000)"
    )
    parser.add_argument(
        "--sync",
        action="store_true",
        help="Force download of static report UI from S3",
    )
    parser.add_argument(
        "--pr",
        type=str,
        help="PR number to download static report UI from (e.g., 123)",
    )
    parser.add_argument(
        "--local",
        action="store_true",
        help="Serve summary.html instead of the static report UI (skips S3 download)",
    )
    parser.add_argument(
        "--dev",
        action="store_true",
        help="Development mode: Enable CORS and print Vite proxy config. Skips S3 download unless --sync is strictly forced.",
    )

    args = parser.parse_args()

    # Configure logging to show info messages from the downloader
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    session_path = Path(args.session_folder).resolve()

    if not session_path.exists():
        print(f"Error: Session folder not found: {session_path}", file=sys.stderr)
        sys.exit(1)

    # Check if we need to download the static report UI
    # We download if --sync is specified OR if index.html is missing OR if --pr is specified
    # BUT only if --local is NOT specified
    # In --dev mode, we skip automatic download of the UI build unless forced with --sync
    index_file = session_path / "index.html"

    force_download = args.sync or args.pr
    auto_download = not index_file.exists() and not args.dev

    should_download = (force_download or auto_download) and not args.local

    if should_download:
        try:
            # Import inside function to avoid dependency issues if not needed
            from utils.static_site_downloader import download_static_report_ui

            if download_static_report_ui(session_path, pr_number=args.pr):
                print("✅ Static report UI downloaded successfully")
            else:
                print(
                    "❌ Failed to download static report UI - Aborting to prevent serving outdated content.",
                    file=sys.stderr,
                )
                sys.exit(1)
        except Exception as e:
            print(f"❌ Error downloading static report UI: {e}", file=sys.stderr)
            print("Aborting to prevent serving outdated content.", file=sys.stderr)
            sys.exit(1)

    # Always attempt to generate HTML reports if data exists.
    # This is needed because:
    # 1. In --local mode, we serve summary.html
    # 2. In static report mode (default), the React app loads findings_conversations.html in an iframe
    # 3. In --dev mode, the local Vite app needs findings_conversations.html via proxy
    report_data_path = session_path / "report_data.json"
    if report_data_path.exists():
        print(f"Generating HTML reports from {report_data_path}...")
        try:
            from utils.html_report_generator import generate_html_report

            html_content = generate_html_report(report_data_file=str(report_data_path))

            # Generate summary.html (standalone legacy view)
            summary_output = session_path / "summary.html"
            summary_output.write_text(html_content, encoding="utf-8")
            print(f"✅ Generated {summary_output.name}")

            # Generate findings_conversations.html (required for React app iframe)
            iframe_output = session_path / "findings_conversations.html"
            iframe_output.write_text(html_content, encoding="utf-8")
            print(f"✅ Generated {iframe_output.name}")

        except Exception as e:
            print(f"❌ Failed to generate HTML reports: {e}", file=sys.stderr)
    elif args.local or args.dev:
        # Only complain if we explicitly asked for local/dev mode and data is missing
        print(
            f"⚠️ report_data.json not found in {session_path}. Cannot regenerate summary.html or serve data.",
            file=sys.stderr,
        )

    # Setup Flask app to serve the directory
    app = Flask(__name__, static_folder=str(session_path))
    # Allow CORS for all domains only in dev mode to support localhost:5173 (Vite)
    if args.dev:
        CORS(app)

    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve(path):
        if path == "":
            if args.local:
                return send_from_directory(session_path, "summary.html")
            else:
                return send_from_directory(session_path, "index.html")
        return send_from_directory(session_path, path)

    url = f"http://localhost:{args.port}"
    if args.local:
        url = f"{url}/summary.html"

    if args.dev:
        print("\n" + "=" * 60)
        print("🚀  DEV MODE ACTIVE")
        print("=" * 60)
        print(f"Server data API running at: {url}")
        print(f"Serving files from: {session_path}")
    else:
        print(f"Starting server for {session_path} at {url}")
        print("Press Ctrl+C to stop")

        # Open the browser shortly after the server starts to avoid connection refused races
        def _open_browser():
            try:
                webbrowser.open(url)
            except Exception as e:
                print(f"⚠️ Failed to open browser automatically: {e}", file=sys.stderr)

        threading.Timer(0.7, _open_browser).start()

    # Run the server
    try:
        app.run(port=args.port, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("\nServer stopped.")
        sys.exit(0)
    except Exception as e:
        print(f"Error running server: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
