"""CLI commands for running test suites.

Test suites define persona instances (role + persona combinations) from config/.
Each persona instance is a combination of:
- A role (from config/roles/) that defines the testing perspective
- A persona (from config/personas/) that defines the specific behavior

These commands run predefined test suites from config/test_suites/.
"""

import asyncio
import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

from dotenv import load_dotenv

from constants import DEFAULT_MAX_PARALLEL_PERSONAS
from platforms.aws_agentcore.platform_constants import (
    AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS,
)
from platforms.local.adapter import LocalPlatformAdapter
from utils.config_loader import get_available_test_suites, load_test_suite

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)

# Silence verbose browser-use library logging
logging.getLogger("browser_use").setLevel(logging.WARNING)
logging.getLogger("bubus").setLevel(logging.WARNING)

logger = logging.getLogger(__name__)


def run_test_suite_local() -> None:
    """Run a predefined test suite locally.

    Test suites define persona instances (role + persona from config/).

    Usage:
        uv run local-invoke <suite_name>

    Examples:
        uv run local-invoke kayak
        uv run local-invoke hibob
        uv run local-invoke cloudinary

    Available test suites can be listed with:
        uv run local-invoke --list

    Options:
        --list: List all available test suites
        --tests <test_ids>: Run only specific tests from the suite (comma-separated)
        --max-parallel <n>: Override max parallel persona instances (default: 3)
        --target-url <url>: Override the target URL from the suite
    """
    args = sys.argv[1:]

    if not args or args[0] == "--help":
        _print_usage()
        sys.exit(0)

    if args[0] == "--list":
        _list_test_suites()
        sys.exit(0)

    # Parse arguments
    suite_name = args[0]
    test_ids: list[str] | None = None
    max_parallel = DEFAULT_MAX_PARALLEL_PERSONAS
    target_url_override: str | None = None

    i = 1
    while i < len(args):
        if args[i] == "--tests" and i + 1 < len(args):
            test_ids = [t.strip() for t in args[i + 1].split(",")]
            i += 2
        elif args[i] == "--max-parallel" and i + 1 < len(args):
            max_parallel = int(args[i + 1])
            i += 2
        elif args[i] == "--target-url" and i + 1 < len(args):
            target_url_override = args[i + 1]
            i += 2
        else:
            print(f"❌ Unknown argument: {args[i]}")
            _print_usage()
            sys.exit(1)

    # Load test suite
    try:
        suite = load_test_suite(suite_name)
    except FileNotFoundError as e:
        print(f"❌ {e}")
        print(f"\nAvailable test suites: {', '.join(get_available_test_suites())}")
        sys.exit(1)

    # Filter tests if specified
    tests_to_run = suite.tests
    if test_ids:
        tests_to_run = [t for t in suite.tests if t.id in test_ids]
        if not tests_to_run:
            print(f"❌ No tests found matching: {test_ids}")
            print(f"   Available tests: {[t.id for t in suite.tests]}")
            sys.exit(1)

    # Determine target URL (use first URL for display, but pass all URLs to pipeline)
    target_url = target_url_override
    target_urls: list[str] | None = None
    if not target_url:
        if suite.target_urls:
            target_url = suite.target_urls[0]
            # Pass all URLs so personas can randomly select
            if len(suite.target_urls) > 1:
                target_urls = suite.target_urls
        else:
            print(
                f"❌ No target URL specified and suite '{suite_name}' has no default URL"
            )
            sys.exit(1)

    # Build persona instance list from test cases
    # Each test case specifies a persona instance (role + persona combination)
    persona_ids = [test.persona for test in tests_to_run]

    # Ensure target_url is set (type guard for type checker)
    assert target_url is not None, "target_url must be set at this point"

    print(f"🧪 Running test suite: {suite.name}")
    print(f"   Domain: {suite.domain}")
    print(f"   URL: {target_url}")
    if target_urls:
        print(f"   URL pool: {len(target_urls)} URLs (random selection per test)")
    print(f"   Tests: {len(tests_to_run)}")
    print(f"   Persona instances: {persona_ids}")
    print(f"   Max parallel: {max_parallel}")
    print()

    try:
        # Initialize local platform adapter
        adapter = LocalPlatformAdapter()

        # Run pipeline with personas from test suite
        async def run_with_cleanup() -> dict[str, Any]:
            return await adapter.run_pipeline(
                target_url=target_url,
                target_urls=target_urls,
                persona_ids=persona_ids,
                max_parallel=max_parallel,
                domain=suite.domain,
                test_suite=suite,
            )

        # Custom exception handler
        def exception_handler(
            loop: asyncio.AbstractEventLoop, context: dict[str, Any]
        ) -> None:
            exception = context.get("exception")
            if isinstance(exception, RuntimeError) and "Event loop is closed" in str(
                exception
            ):
                return
            loop.default_exception_handler(context)

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.set_exception_handler(exception_handler)

        try:
            result = loop.run_until_complete(run_with_cleanup())

            pending = asyncio.all_tasks(loop)
            for task in pending:
                task.cancel()
            if pending:
                loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True)
                )
        finally:
            loop.close()

        print("\n✅ Test suite completed!")
        print(f"\nResult: {json.dumps(result, indent=2)}")

        if result.get("status") == "error":
            print("\n⚠️  Execution completed with errors. Check logs for details.")
            sys.exit(1)

    except KeyboardInterrupt:
        print("\n\n⚠️  Execution interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Execution failed: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


def _print_usage() -> None:
    """Print usage information."""
    print("Usage: uv run local-invoke <suite_name> [options]")
    print()
    print("Run a predefined test suite from config/test_suites/")
    print()
    print("Arguments:")
    print("  suite_name           Name of the test suite (e.g., kayak, hibob)")
    print()
    print("Options:")
    print("  --list               List all available test suites")
    print("  --tests <ids>        Run only specific tests (comma-separated)")
    print("  --max-parallel <n>   Override max parallel persona instances (default: 3)")
    print("  --target-url <url>   Override the target URL")
    print()
    print("Examples:")
    print("  uv run local-invoke kayak")
    print("  uv run local-invoke hibob --tests employee_time_off,security_test")
    print("  uv run local-invoke cloudinary --max-parallel 5")


def _list_test_suites() -> None:
    """List all available test suites."""
    suites = get_available_test_suites()

    if not suites:
        print("No test suites found in config/test_suites/")
        return

    print("Available test suites:")
    print()

    for suite_name in sorted(suites):
        try:
            suite = load_test_suite(suite_name)
            print(f"  {suite_name}")
            print(f"    Domain: {suite.domain}")
            print(f"    Tests: {len(suite.tests)}")
            if suite.target_urls:
                print(f"    URL: {suite.target_urls[0]}")
            print()
        except Exception as e:
            print(f"  {suite_name} (error loading: {e})")


def run_test_suite_agentcore() -> None:
    """Run a predefined test suite on AWS AgentCore.

    Test suites define persona instances (role + persona from config/).

    Usage:
        uv run agentcore-invoke <suite_name>

    Examples:
        uv run agentcore-invoke kayak
        uv run agentcore-invoke hibob

    Options:
        --list: List all available test suites
        --tests <test_ids>: Run only specific tests (comma-separated)
        --max-parallel <n>: Override max parallel persona instances (default: 25)
        --target-url <url>: Override the target URL from the suite
    """
    args = sys.argv[1:]

    if not args or args[0] == "--help":
        print("Usage: uv run agentcore-invoke <suite_name> [options]")
        print()
        print("Run a predefined test suite on AWS AgentCore")
        print()
        print("Options:")
        print("  --list               List all available test suites")
        print("  --tests <ids>        Run only specific tests (comma-separated)")
        print(
            "  --max-parallel <n>   Override max parallel persona instances (default: 25)"
        )
        print("  --target-url <url>   Override the target URL")
        print("  --pr <number>        Target a PR environment agent (e.g. --pr 130)")
        sys.exit(0)

    if args[0] == "--list":
        _list_test_suites()
        sys.exit(0)

    # Parse arguments
    suite_name = args[0]
    test_ids: list[str] | None = None
    max_parallel = AGENTCORE_DEFAULT_MAX_PARALLEL_PERSONAS
    target_url_override: str | None = None
    pr_number: str | None = None

    i = 1
    while i < len(args):
        if args[i] == "--tests" and i + 1 < len(args):
            test_ids = [t.strip() for t in args[i + 1].split(",")]
            i += 2
        elif args[i] == "--max-parallel" and i + 1 < len(args):
            max_parallel = int(args[i + 1])
            i += 2
        elif args[i] == "--target-url" and i + 1 < len(args):
            target_url_override = args[i + 1]
            i += 2
        elif args[i] == "--pr" and i + 1 < len(args):
            pr_number = args[i + 1]
            i += 2
        else:
            print(f"❌ Unknown argument: {args[i]}")
            sys.exit(1)

    # Load test suite
    try:
        suite = load_test_suite(suite_name)
    except FileNotFoundError as e:
        print(f"❌ {e}")
        print(f"\nAvailable test suites: {', '.join(get_available_test_suites())}")
        sys.exit(1)

    # Filter tests if specified
    tests_to_run = suite.tests
    if test_ids:
        tests_to_run = [t for t in suite.tests if t.id in test_ids]
        if not tests_to_run:
            print(f"❌ No tests found matching: {test_ids}")
            sys.exit(1)

    # Determine target URL
    target_url = target_url_override
    target_urls: list[str] | None = None
    if not target_url:
        if not suite.target_urls:
            print(f"❌ Suite '{suite_name}' has no target URL configured")
            sys.exit(1)
        target_url = suite.target_urls[0]
        # Pass all URLs so personas can randomly select
        if len(suite.target_urls) > 1:
            target_urls = suite.target_urls

    # Build persona instance list from test cases
    persona_ids = [test.persona for test in tests_to_run]

    # Build the payload with unique task_id so each run gets its own S3 folder
    task_id = f"{suite_name}_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}"
    # Use max_turns from test cases (take the max across all tests being run)
    max_turns = max(t.max_turns for t in tests_to_run)
    payload: dict[str, Any] = {
        "target_url": target_url,
        "persona_ids": persona_ids,
        "max_turns": max_turns,
        "max_parallel": max_parallel,
        "domain": suite.domain,
        "test_suite_id": suite_name,
        "org_id": "agentcore-cli",  # Default org_id for standalone invocations
        "task_id": task_id,  # Unique per run to avoid S3 overwriting
    }
    if target_urls:
        payload["target_urls"] = target_urls
    if pr_number:
        payload["agent_name"] = f"arato_pr{pr_number}"

    print(f"🧪 Running test suite on AgentCore: {suite.name}")
    if pr_number:
        print(f"   Target: PR #{pr_number} (arato_pr{pr_number})")
    print(f"   Domain: {suite.domain}")
    print(f"   URL: {target_url}")
    if target_urls:
        print(f"   URL pool: {len(target_urls)} URLs (random selection per test)")
    print(f"   Tests: {len(tests_to_run)}")
    print(f"   Persona instances: {persona_ids}")
    print()

    # Import and call agentcore invoke
    from platforms.aws_agentcore.scripts.agentcore_deploy import invoke_agent

    # Pass payload as JSON string via sys.argv
    original_argv = sys.argv
    sys.argv = ["agentcore-invoke", json.dumps(payload)]

    try:
        invoke_agent()
    finally:
        sys.argv = original_argv
