#!/usr/bin/env python3
"""Script to save browser authentication state for reuse.

This script uses Playwright directly to save browser context state
(cookies, localStorage, sessionStorage) after manual login.

Usage:
    uv run save-auth-state --url https://console.cloudinary.com/app/...
    uv run save-auth-state --url https://app.staircase.ai/dashboard/... --output custom_auth.json
"""

import argparse
import asyncio
from pathlib import Path
from urllib.parse import urlparse

from playwright.async_api import async_playwright


async def save_auth_state(target_url: str, output_path: str) -> None:
    """Save authentication state after manual login.

    Args:
        target_url: URL to navigate to and login
        output_path: Path to save the storage state JSON file
    """
    print("🔐 Browser Authentication State Saver")
    print("=" * 70)
    print(f"Target URL: {target_url}")
    print(f"Output file: {output_path}")
    print("=" * 70)
    print()
    print("A browser window will open. Please:")
    print("1. Complete the login process")
    print("2. Wait until you see your logged-in dashboard")
    print("3. Press ENTER in this terminal to save the authentication state")
    print()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        print(f"🌐 Navigating to {target_url}...")
        await page.goto(target_url, timeout=120_000)

        print()
        print("👉 Please complete the login process in the browser window")
        print("   Press ENTER after you see yourself logged in…")

        # Wait for user confirmation (run in executor to not block async)
        await asyncio.get_event_loop().run_in_executor(None, input)

        # Save the storage state
        print()
        print("💾 Saving authentication state...")
        await context.storage_state(path=output_path)

        print(f"✓ Saved login state to {output_path}")
        print()
        print("You can now use this file with:")
        print("  uv run local-invoke '{")
        print(f'    "target_url": "{target_url}",')
        print(f'    "storage_state": "{output_path}"')
        print("  }}'")
        print()
        print("Or update your invocation to include storage_state parameter.")

        await browser.close()


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Save browser authentication state for reuse"
    )
    parser.add_argument(
        "--url",
        required=True,
        help="URL to navigate to and login (e.g., https://console.cloudinary.com/login)",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Path to save storage state file (default: auto-generated from URL domain)",
    )

    args = parser.parse_args()

    # Auto-generate output path if not provided
    if args.output is None:
        parsed_url = urlparse(args.url)
        domain = parsed_url.netloc or parsed_url.path.split("/")[0]
        safe_domain = domain.replace(":", "_").replace("/", "_")

        # Create auth_states directory if it doesn't exist
        auth_states_dir = Path("auth_states")
        auth_states_dir.mkdir(exist_ok=True)

        args.output = f"auth_states/auth_{safe_domain}.json"
        print(f"📁 Auto-generated output path: {args.output}")

    # Validate output path
    output_path = Path(args.output)
    if output_path.exists():
        response = input(f"⚠️  File {args.output} already exists. Overwrite? [y/N]: ")
        if response.lower() != "y":
            print("Cancelled.")
            return

    asyncio.run(save_auth_state(args.url, args.output))


if __name__ == "__main__":
    main()
