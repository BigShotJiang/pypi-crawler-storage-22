"""
Ground truth cache utilities for skills.

This module handles caching of ground truth data from skills that have
global_ground_truth=True in their metadata. This allows expensive data
extraction operations to be shared across all persona runs in a session.

Key features:
- File-based caching in session folder
- File-based locking to handle concurrent access from multiple PROCESSES
- Automatic expiration and validation
- Polling mechanism for agents waiting on another agent's generation
"""

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Global lock registry for in-process coordination (async)
# Key: skill_name, Value: asyncio.Lock
_skill_locks: dict[str, asyncio.Lock] = {}
_registry_lock = asyncio.Lock()

# Cache file settings
GROUND_TRUTH_CACHE_DIR = ".ground_truth_cache"
CACHE_VERSION = "1.0"

# Lock file settings for cross-process coordination
LOCK_FILE_SUFFIX = ".lock"
LOCK_POLL_INTERVAL = 2.0  # seconds between polls
LOCK_STALE_THRESHOLD = 600.0  # seconds - consider lock stale if older than this


async def _get_skill_lock(skill_name: str) -> asyncio.Lock:
    """
    Get or create an asyncio.Lock for a specific skill.

    This ensures only one agent can generate ground truth for a skill at a time,
    while allowing different skills to run in parallel.

    Args:
        skill_name: Name of the skill

    Returns:
        asyncio.Lock for the skill
    """
    async with _registry_lock:
        if skill_name not in _skill_locks:
            _skill_locks[skill_name] = asyncio.Lock()
        return _skill_locks[skill_name]


def _get_cache_filepath(session_dir: str, skill_name: str) -> Path:
    """
    Get the file path for caching ground truth data.

    Args:
        session_dir: The session directory path (parent of persona directories)
        skill_name: Name of the skill

    Returns:
        Path to the cache file
    """
    # Normalize skill name (convert underscores to hyphens)
    normalized_name = skill_name.replace("_", "-")
    cache_dir = Path(session_dir) / GROUND_TRUTH_CACHE_DIR
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / f"{normalized_name}.json"


def _get_lock_filepath(session_dir: str, skill_name: str) -> Path:
    """
    Get the file path for the cross-process lock file.

    Args:
        session_dir: The session directory path
        skill_name: Name of the skill

    Returns:
        Path to the lock file
    """
    cache_file = _get_cache_filepath(session_dir, skill_name)
    return cache_file.with_suffix(LOCK_FILE_SUFFIX)


def _try_acquire_file_lock(lock_file: Path, agent_id: str) -> bool:
    """
    Try to acquire a file-based lock for cross-process coordination.

    Uses atomic file creation to prevent race conditions.

    Args:
        lock_file: Path to the lock file
        agent_id: Identifier for this agent (for debugging)

    Returns:
        True if lock was acquired, False if another process holds it
    """
    try:
        # Check if lock exists and is stale
        if lock_file.exists():
            lock_age = time.time() - lock_file.stat().st_mtime
            if lock_age > LOCK_STALE_THRESHOLD:
                logger.warning(f"Found stale lock file ({lock_age:.0f}s old), removing")
                lock_file.unlink(missing_ok=True)
            else:
                # Lock is held by another process
                return False

        # Try to create lock file atomically
        # O_CREAT | O_EXCL ensures atomic creation (fails if file exists)
        fd = os.open(str(lock_file), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try:
            # Write lock info for debugging
            lock_info = json.dumps(
                {
                    "agent_id": agent_id,
                    "pid": os.getpid(),
                    "acquired_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                }
            )
            os.write(fd, lock_info.encode("utf-8"))
        finally:
            os.close(fd)

        logger.info(f"Acquired file lock for ground truth generation: {lock_file.name}")
        return True

    except FileExistsError:
        # Another process beat us to it
        return False
    except Exception as e:
        logger.warning(f"Error acquiring file lock: {e}")
        return False


def _release_file_lock(lock_file: Path) -> None:
    """
    Release a file-based lock.

    Args:
        lock_file: Path to the lock file
    """
    try:
        lock_file.unlink(missing_ok=True)
        logger.debug(f"Released file lock: {lock_file.name}")
    except Exception as e:
        logger.warning(f"Error releasing file lock: {e}")


def get_session_dir_from_output_dir(output_dir: str) -> str:
    """
    Extract the session directory from a persona output directory.

    If output_dir is a persona subdirectory (e.g., sessions/conversation_xxx/persona_name),
    return the parent session directory. If it's already the session directory, return it as-is.

    Args:
        output_dir: The output directory path

    Returns:
        The session directory path
    """
    output_path = Path(output_dir)

    # Check if this looks like a persona subdirectory
    # Persona directories are typically children of session directories
    parent = output_path.parent

    # If parent is a session directory (contains 'session' or 'conversation' in name)
    # or if we're already in a session directory, use appropriately
    parent_name = parent.name.lower()
    output_name = output_path.name.lower()

    if (
        "session" in parent_name
        or "conversation" in parent_name
        or "discovery" in parent_name
    ):
        # output_dir is a persona subdirectory, return parent
        return str(parent)
    elif (
        "session" in output_name
        or "conversation" in output_name
        or "discovery" in output_name
    ):
        # output_dir is already a session directory
        return str(output_path)
    else:
        # Can't determine - use parent as safest option
        # This handles cases like sessions/conversation_xxx/malicious_user_01
        return str(parent)


async def load_cached_ground_truth(
    session_dir: str,
    skill_name: str,
) -> list[dict[str, Any]] | None:
    """
    Load cached ground truth data for a skill if it exists.

    Args:
        session_dir: The session directory path
        skill_name: Name of the skill

    Returns:
        List of ground truth entries if cache exists and is valid, None otherwise
    """
    cache_file = _get_cache_filepath(session_dir, skill_name)

    if not cache_file.exists():
        logger.debug(f"No cache found for skill '{skill_name}' at {cache_file}")
        return None

    try:
        # Use file lock for reading
        lock = await _get_skill_lock(skill_name)
        async with lock:
            with open(cache_file, encoding="utf-8") as f:
                cache_data = json.load(f)

            # Validate cache structure
            if cache_data.get("version") != CACHE_VERSION:
                logger.warning(
                    f"Cache version mismatch for skill '{skill_name}', ignoring"
                )
                return None

            if "ground_truth" not in cache_data:
                logger.warning(f"Invalid cache structure for skill '{skill_name}'")
                return None

            ground_truth = cache_data["ground_truth"]
            cached_at = cache_data.get("cached_at", "unknown")
            logger.info(
                f"✓ Loaded cached ground truth for skill '{skill_name}' "
                f"({len(ground_truth)} entries, cached at {cached_at})"
            )
            return ground_truth

    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse cache file for skill '{skill_name}': {e}")
        return None
    except Exception as e:
        logger.warning(f"Failed to load cache for skill '{skill_name}': {e}")
        return None


async def save_ground_truth_cache(
    session_dir: str,
    skill_name: str,
    ground_truth: list[dict[str, Any]],
) -> bool:
    """
    Save ground truth data to cache for a skill.

    Args:
        session_dir: The session directory path
        skill_name: Name of the skill
        ground_truth: List of ground truth entries to cache

    Returns:
        True if saved successfully, False otherwise
    """
    cache_file = _get_cache_filepath(session_dir, skill_name)

    try:
        lock = await _get_skill_lock(skill_name)
        async with lock:
            cache_data = {
                "version": CACHE_VERSION,
                "skill_name": skill_name,
                "cached_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "entry_count": len(ground_truth),
                "ground_truth": ground_truth,
            }

            # Write atomically using temp file
            temp_file = cache_file.with_suffix(".tmp")
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(cache_data, f, indent=2)

            # Rename to final location
            temp_file.rename(cache_file)

            logger.info(
                f"✓ Saved ground truth cache for skill '{skill_name}' "
                f"({len(ground_truth)} entries)"
            )
            return True

    except Exception as e:
        logger.error(f"Failed to save cache for skill '{skill_name}': {e}")
        return False


async def check_and_acquire_generation_lock(
    session_dir: str,
    skill_name: str,
    agent_id: str = "unknown",
    timeout: float = 300.0,
) -> tuple[bool, list[dict[str, Any]] | None]:
    """
    Check for cached ground truth, or acquire lock to generate it.

    This function handles the race condition where multiple agents (PROCESSES)
    might try to generate ground truth simultaneously. It uses FILE-BASED
    locking for cross-process coordination. It ensures:
    1. If cache exists, return it immediately
    2. If another process is generating, poll and wait for completion
    3. If no one is generating, acquire the file lock and signal caller to generate

    Args:
        session_dir: The session directory path
        skill_name: Name of the skill
        agent_id: Identifier for this agent (for debugging)
        timeout: Maximum time to wait for another agent to complete generation

    Returns:
        Tuple of (should_generate, cached_data):
        - (False, data) - Cache exists or was generated by another agent, use data
        - (True, None) - Caller should generate and save the cache
    """
    cache_file = _get_cache_filepath(session_dir, skill_name)
    lock_file = _get_lock_filepath(session_dir, skill_name)

    # First, quick check for existing cache
    if cache_file.exists():
        cached = await load_cached_ground_truth(session_dir, skill_name)
        if cached is not None:
            return (False, cached)

    # Try to acquire file lock
    if _try_acquire_file_lock(lock_file, agent_id):
        # We got the lock - double check cache wasn't created between check and lock
        if cache_file.exists():
            cached = await load_cached_ground_truth(session_dir, skill_name)
            if cached is not None:
                _release_file_lock(lock_file)
                return (False, cached)

        # We hold the lock and should generate
        # Note: Caller must call release_generation_lock when done
        logger.info(
            f"Agent '{agent_id}' will generate global ground truth for skill '{skill_name}'"
        )
        return (True, None)

    # Another process is generating - poll and wait for cache to appear
    logger.info(
        f"Agent '{agent_id}' waiting for another agent to generate ground truth for '{skill_name}'..."
    )

    start_time = time.time()
    while (time.time() - start_time) < timeout:
        # Check if cache appeared
        if cache_file.exists():
            cached = await load_cached_ground_truth(session_dir, skill_name)
            if cached is not None:
                logger.info(
                    f"Agent '{agent_id}' found cached ground truth for '{skill_name}' after waiting"
                )
                return (False, cached)

        # Check if lock was released (other agent might have failed)
        if not lock_file.exists():
            # Try to acquire lock ourselves
            if _try_acquire_file_lock(lock_file, agent_id):
                logger.info(
                    f"Agent '{agent_id}' acquired lock after previous holder released for '{skill_name}'"
                )
                return (True, None)

        # Wait before next poll
        await asyncio.sleep(LOCK_POLL_INTERVAL)

    # Timeout - try to take over
    logger.warning(
        f"Agent '{agent_id}' timed out waiting for ground truth generation for '{skill_name}'"
    )

    # Force acquire by removing stale lock
    _release_file_lock(lock_file)
    if _try_acquire_file_lock(lock_file, agent_id):
        logger.info(
            f"Agent '{agent_id}' took over ground truth generation after timeout"
        )
        return (True, None)

    # Still couldn't get lock - let agent proceed without caching
    return (True, None)


def release_generation_lock(session_dir: str, skill_name: str) -> None:
    """
    Release the file-based generation lock after saving cache.

    Call this after successfully saving the ground truth cache.

    Args:
        session_dir: The session directory path
        skill_name: Name of the skill
    """
    lock_file = _get_lock_filepath(session_dir, skill_name)
    _release_file_lock(lock_file)


class GroundTruthCacheManager:
    """
    Context manager for ground truth cache operations.

    Handles cross-process coordination using file-based locks.

    Usage:
        async with GroundTruthCacheManager(session_dir, skill_name, agent_id) as manager:
            if manager.cached_data is not None:
                # Use cached data
                ground_truth = manager.cached_data
            else:
                # Generate ground truth
                ground_truth = await generate_ground_truth()
                await manager.save(ground_truth)
    """

    def __init__(
        self,
        session_dir: str,
        skill_name: str,
        agent_id: str = "unknown",
        timeout: float = 300.0,
    ):
        """
        Initialize the cache manager.

        Args:
            session_dir: The session directory path
            skill_name: Name of the skill
            agent_id: Identifier for this agent (for debugging/logging)
            timeout: Maximum time to wait for lock
        """
        self.session_dir = session_dir
        self.skill_name = skill_name
        self.agent_id = agent_id
        self.timeout = timeout
        self.cached_data: list[dict[str, Any]] | None = None
        self.should_generate: bool = False
        self._holds_lock: bool = False

    async def __aenter__(self) -> "GroundTruthCacheManager":
        """Enter the context manager."""
        (
            self.should_generate,
            self.cached_data,
        ) = await check_and_acquire_generation_lock(
            self.session_dir,
            self.skill_name,
            self.agent_id,
            self.timeout,
        )
        self._holds_lock = self.should_generate
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit the context manager - release lock if held."""
        if self._holds_lock:
            release_generation_lock(self.session_dir, self.skill_name)
            self._holds_lock = False

    async def save(self, ground_truth: list[dict[str, Any]]) -> bool:
        """
        Save generated ground truth to cache.

        Args:
            ground_truth: The ground truth data to save

        Returns:
            True if saved successfully
        """
        success = await save_ground_truth_cache(
            self.session_dir,
            self.skill_name,
            ground_truth,
        )
        # Release lock after successful save
        if success and self._holds_lock:
            release_generation_lock(self.session_dir, self.skill_name)
            self._holds_lock = False
        return success
