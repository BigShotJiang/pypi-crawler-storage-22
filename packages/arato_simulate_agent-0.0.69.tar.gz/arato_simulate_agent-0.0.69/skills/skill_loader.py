"""
Skill loader for parsing and managing skills.

This module handles loading, parsing, and managing skill definitions that follow
the Agent Skills open standard format (https://agentskills.io/specification).

Skills are directories containing a SKILL.md file with YAML frontmatter and markdown instructions.
Domain-specific skills are indicated via metadata.domain_url in the frontmatter.
"""

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jinja2 import Template

from constants import (
    CATEGORY_ACCURACY,
    CATEGORY_FEATURE,
    CATEGORY_SECURITY,
    CATEGORY_UX,
)
from utils.url_utils import extract_domain_pattern

logger = logging.getLogger(__name__)


@dataclass
class SkillDefinition:
    """
    Represents a parsed skill definition following Agent Skills standard.

    Attributes:
      name: Unique identifier (1-64 chars, lowercase alphanumeric and hyphens only)
      description: Human-readable description (1-1024 chars, describes what and when)
      instructions: Detailed markdown instructions for executing the skill
      license: Optional license information
      compatibility: Optional environment requirements
      metadata: Optional arbitrary key-value metadata
      allowed_tools: Optional pre-approved tools list
      domain_patterns: List of domain patterns extracted from metadata.domain_url
      skill_dir: Path to the skill directory
    """

    name: str
    description: str
    instructions: str
    license: str | None = None
    compatibility: str | None = None
    metadata: dict[str, Any] | None = None
    allowed_tools: str | None = None
    domain_patterns: list[str] | None = None
    skill_dir: Path | None = None

    def has_scripts(self) -> bool:
        """Check if skill has a scripts/ directory."""
        if self.skill_dir is None:
            return False
        return (self.skill_dir / "scripts").exists()

    def has_references(self) -> bool:
        """Check if skill has a references/ directory."""
        if self.skill_dir is None:
            return False
        return (self.skill_dir / "references").exists()

    def has_assets(self) -> bool:
        """Check if skill has an assets/ directory."""
        if self.skill_dir is None:
            return False
        return (self.skill_dir / "assets").exists()

    def get_scripts_dir(self) -> Path | None:
        """Get path to scripts/ directory if it exists."""
        if not self.has_scripts():
            return None
        assert self.skill_dir is not None  # has_scripts() checks this
        return self.skill_dir / "scripts"

    def get_references_dir(self) -> Path | None:
        """Get path to references/ directory if it exists."""
        if not self.has_references():
            return None
        assert self.skill_dir is not None  # has_references() checks this
        return self.skill_dir / "references"

    def get_assets_dir(self) -> Path | None:
        """Get path to assets/ directory if it exists."""
        if not self.has_assets():
            return None
        assert self.skill_dir is not None  # has_assets() checks this
        return self.skill_dir / "assets"

    def matches_domain(self, target_url: str) -> bool:
        """
        Check if this skill applies to the given target URL.

        Global skills (no domain_patterns) match all domains.
        Domain-specific skills match if their domain pattern is in the target URL.

        Args:
          target_url: The URL to check against

        Returns:
          True if skill applies to this URL, False otherwise
        """
        if self.domain_patterns is None or len(self.domain_patterns) == 0:
            # Global skill - matches everything
            return True

        # Extract domain from target URL
        target_patterns = extract_domain_pattern(target_url)

        # Check if any of the skill's domain patterns match the target
        for skill_pattern in self.domain_patterns:
            for target_pattern in target_patterns:
                # Compare base domains (strip *. prefix for comparison)
                skill_base = skill_pattern.lstrip("*.")
                target_base = target_pattern.lstrip("*.")
                if skill_base in target_base or target_base in skill_base:
                    return True

        return False


class SkillLoader:
    """
    Loader for skills following the Agent Skills open standard.

    Skills are directories containing a SKILL.md file with YAML frontmatter:
    ---
    name: skill-name
    description: Brief description (1-1024 chars)
    license: Apache-2.0 (optional)
    compatibility: Required packages (optional)
    metadata:
      domain_url: https://example.com (for domain-specific skills)
      author: your-org (optional)
    allowed-tools: Bash(git:*) Read (optional)
    ---
    # Detailed markdown instructions here...

    Domain-specific skills use metadata.domain_url.
    Skills without domain_url are global and apply to all domains.

    See: https://agentskills.io/specification
    """

    def __init__(self, skills_dir: Path | str | None = None):
        """
        Initialize the skill loader.

        Args:
          skills_dir: Path to directory containing .skill files (defaults to constants.SKILLS_DIR)
        """
        if skills_dir is None:
            from constants import SKILLS_DIR

            skills_dir = SKILLS_DIR
        self.skills_dir = Path(skills_dir)
        if not self.skills_dir.exists():
            logger.warning(f"Skills directory does not exist: {self.skills_dir}")
            self.skills_dir.mkdir(parents=True, exist_ok=True)

    def load_skill(self, skill_dir: Path) -> SkillDefinition | None:
        """
        Load and parse a skill from a directory containing SKILL.md.

        Args:
          skill_dir: Path to the skill directory

        Returns:
          Parsed SkillDefinition or None if parsing fails
        """
        skill_file = skill_dir / "SKILL.md"
        if not skill_file.exists():
            logger.error(f"Skill directory {skill_dir} missing SKILL.md file")
            return None

        try:
            raw_content = skill_file.read_text(encoding="utf-8")

            # Render with Jinja2 to support dynamic constants
            template = Template(raw_content)
            content = template.render(
                CATEGORY_SECURITY=CATEGORY_SECURITY,
                CATEGORY_ACCURACY=CATEGORY_ACCURACY,
                CATEGORY_UX=CATEGORY_UX,
                CATEGORY_FEATURE=CATEGORY_FEATURE,
            )

            # Parse front matter (between --- markers)
            if not content.startswith("---"):
                logger.error(f"Skill file {skill_file} missing front matter")
                return None

            parts = content.split("---", 2)
            if len(parts) < 3:
                logger.error(f"Skill file {skill_file} has invalid format")
                return None

            front_matter = parts[1].strip()
            instructions = parts[2].strip()

            # Parse YAML front matter
            import yaml

            try:
                fm_data = yaml.safe_load(front_matter)
            except yaml.YAMLError as e:
                logger.error(f"Invalid YAML in {skill_file}: {e}")
                return None

            # Required fields validation
            if "name" not in fm_data or "description" not in fm_data:
                logger.error(
                    f"Skill {skill_file} missing required fields (name, description)"
                )
                return None

            name = fm_data["name"]
            description = fm_data["description"]

            # Validate name format (lowercase alphanumeric and hyphens only)
            import re

            if not re.match(r"^[a-z0-9]([a-z0-9-]{0,62}[a-z0-9])?$", name):
                logger.error(
                    f"Skill {skill_file} has invalid name '{name}'. "
                    f"Must be 1-64 chars, lowercase alphanumeric and hyphens only, "
                    f"no leading/trailing hyphens, no consecutive hyphens"
                )
                return None

            # Validate name matches directory
            if skill_dir.name != name:
                logger.warning(
                    f"Skill name '{name}' doesn't match directory '{skill_dir.name}'. "
                    f"This violates Agent Skills standard."
                )

            # Validate description length
            if len(description) == 0 or len(description) > 1024:
                logger.error(
                    f"Skill {skill_file} description must be 1-1024 characters"
                )
                return None

            # Optional fields
            license_info = fm_data.get("license")
            compatibility = fm_data.get("compatibility")
            metadata = fm_data.get("metadata")
            allowed_tools = fm_data.get("allowed-tools")

            # Validate compatibility length
            if compatibility and len(compatibility) > 500:
                logger.error(f"Skill {skill_file} compatibility must be <= 500 chars")
                return None

            # Extract domain_url from metadata for domain-specific skills
            domain_patterns = None
            if metadata:
                if "domain_url" in metadata:
                    domain_url = metadata["domain_url"]
                    domain_patterns = extract_domain_pattern(domain_url)
                    logger.info(
                        f"Loaded domain-specific skill '{name}' for {domain_patterns}"
                    )
                else:
                    logger.info(f"Loaded global skill '{name}'")
            else:
                logger.info(f"Loaded global skill '{name}'")

            return SkillDefinition(
                name=name,
                description=description,
                instructions=instructions,
                license=license_info,
                compatibility=compatibility,
                metadata=metadata,
                allowed_tools=allowed_tools,
                domain_patterns=domain_patterns,
                skill_dir=skill_dir,
            )

        except Exception as e:
            logger.error(f"Failed to load skill {skill_dir}: {e}", exc_info=True)
            return None

    def load_all_skills(self) -> list[SkillDefinition]:
        """
        Load all skills from the skills directory.

        Scans for directories containing SKILL.md files.

        Returns:
          List of successfully parsed SkillDefinition objects
        """
        skills: list[SkillDefinition] = []

        # Find all directories containing SKILL.md
        skill_dirs = [
            d
            for d in self.skills_dir.iterdir()
            if d.is_dir() and (d / "SKILL.md").exists()
        ]

        if not skill_dirs:
            logger.info(
                f"No skill directories with SKILL.md found in {self.skills_dir}"
            )
            return skills

        logger.info(f"Loading {len(skill_dirs)} skills from {self.skills_dir}")

        for skill_dir in skill_dirs:
            skill = self.load_skill(skill_dir)
            if skill:
                skills.append(skill)

        logger.info(f"Successfully loaded {len(skills)} skills")
        return skills

    def load_skills_for_domain(self, target_url: str) -> list[SkillDefinition]:
        """
        Load all skills that apply to the given target URL.

        This includes:
        - Global skills (no URL specified)
        - Domain-specific skills whose URL matches the target

        Args:
          target_url: The URL to match skills against

        Returns:
          List of applicable SkillDefinition objects
        """
        all_skills = self.load_all_skills()
        applicable_skills = [
            skill for skill in all_skills if skill.matches_domain(target_url)
        ]

        logger.info(
            f"Found {len(applicable_skills)} applicable skills for {target_url} "
            f"({len(all_skills) - len(applicable_skills)} filtered out)"
        )

        return applicable_skills

    def generate_xml_context(self, skills: list[SkillDefinition]) -> str:
        """
        Generate XML context for skills following Agent Skills integration guide.

        This creates the recommended <available_skills> XML format for injection
        into agent system prompts.

        Args:
          skills: List of skills to include in context

        Returns:
          XML string with skill metadata
        """
        if not skills:
            return "<available_skills>\n  <!-- No skills available -->\n</available_skills>"

        xml = "<available_skills>\n"
        for skill in skills:
            xml += "  <skill>\n"
            xml += f"    <name>{skill.name}</name>\n"
            xml += f"    <description>{skill.description}</description>\n"
            if skill.skill_dir:
                skill_md_path = skill.skill_dir / "SKILL.md"
                xml += f"    <location>{skill_md_path}</location>\n"
            if skill.metadata:
                xml += "    <metadata>\n"
                for key, value in skill.metadata.items():
                    xml += f"      <{key}>{value}</{key}>\n"
                xml += "    </metadata>\n"
            xml += "  </skill>\n"
        xml += "</available_skills>"

        return xml
