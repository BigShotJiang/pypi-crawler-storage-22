#!/usr/bin/env python3
"""
SkillTool: Browser-use tool for executing skills during conversation.

This module provides the SkillTool class that acts as a first-class browser-use
tool, allowing the agent to invoke domain-specific or global skills during
conversation turns.

Skills are browser-use based capabilities that can perform actions and return
validation results, similar to EvalTool but focused on behavioral validation
and side-effect verification.
"""

import logging
from typing import Any

from browser_use import Agent, Browser

from .skill_loader import SkillDefinition

logger = logging.getLogger(__name__)


class SkillTool:
    """
    Browser-use tool for executing skills.

    This tool enables the agent to execute skills (browser-based capabilities)
    that can navigate, inspect, and validate application state. Skills return
    validation results similar to EvalTool.

    Attributes:
      skills: List of applicable SkillDefinition objects for this session
      browser: Browser instance for executing browser actions
      agent: Agent instance for executing complex multi-step skills
      transcript: The conversation transcript (for context)
      conversation_id: Unique identifier for this conversation
      target_url: URL of the chat interface being tested
    """

    def __init__(
        self,
        skills: list[SkillDefinition],
        browser: Browser,
        transcript: list[Any],
        conversation_id: str = "unknown",
        target_url: str | None = None,
        agent: Agent[Any, Any] | None = None,
    ):
        """
        Initialize the SkillTool.

        Args:
          skills: List of applicable SkillDefinition objects
          browser: Browser instance for executing actions
          transcript: Reference to the conversation transcript list
          conversation_id: Unique identifier for this conversation
          target_url: URL of the chat interface being tested
          agent: Parent agent instance to reuse (CRITICAL: avoids nested agent issues)
        """
        self.skills = skills
        self.browser = browser
        self.transcript = transcript
        self.conversation_id = conversation_id
        self.target_url = target_url
        self.agent = agent

        logger.info(
            f"SkillTool initialized with {len(skills)} skills "
            f"(conversation: {conversation_id})"
        )

    def get_available_skills(self) -> list[dict[str, str]]:
        """
        Get a list of available skills for the agent to see.

        Returns:
          List of dictionaries with skill name and description
        """
        return [
            {"name": skill.name, "description": skill.description}
            for skill in self.skills
        ]

    async def execute_skill(self, skill_name: str) -> dict[str, Any]:
        """
        Execute a specific skill by name.

        This is the main execution method that:
        1. Finds the skill by name
        2. Creates an agent instance with the skill instructions
        3. Executes the skill logic
        4. Returns validation result

        Args:
          skill_name: Name of the skill to execute (accepts both hyphens and underscores)

        Returns:
          Validation result dictionary in EvalResult format
        """
        logger.info(f"🛠️  Executing skill: {skill_name}")

        # Normalize skill name: convert underscores to hyphens for lookup
        # (Agent Skills spec requires hyphens, but LLMs use underscores)
        normalized_name = skill_name.replace("_", "-")

        # Find the skill by normalized name
        skill = next((s for s in self.skills if s.name == normalized_name), None)
        if not skill:
            logger.error(f"Skill not found: {skill_name}")
            return {
                "validation_id": skill_name,
                "result": 0,
                "score": 0,
                "result_explanation": f"Skill '{skill_name}' not found",
                "confidence": 0.0,
            }

        try:
            # Extract context from transcript for the skill
            context = self._extract_context_for_skill(skill)
            enhanced_task = (
                f"{skill.instructions}\n\n## Conversation Context\n{context}"
            )

            logger.info(f"Starting skill execution: {skill_name}")
            logger.info(f"Skill task: {enhanced_task[:200]}...")

            if not self.agent:
                error_msg = "No parent agent provided - cannot execute skill without agent instance"
                logger.error(error_msg)
                return {
                    "validation_id": skill_name,
                    "result": 0,
                    "score": 0,
                    "result_explanation": error_msg,
                    "confidence": 0.0,
                }

            # Use parent agent's add_new_task to inject skill instructions
            # This avoids creating a nested Agent which causes browser-use conflicts
            logger.info("Adding skill as new task to parent agent")
            self.agent.add_new_task(enhanced_task)

            # Execute steps to complete the skill task
            # Run a limited number of steps for the skill
            logger.info("Executing skill steps...")
            history_steps = []
            max_steps = 10  # Reasonable limit for skill validation tasks

            for i in range(max_steps):
                try:
                    logger.info(f"Skill step {i + 1}/{max_steps}...")
                    await self.agent.step()
                    step_info = f"Step {i + 1} completed"
                    history_steps.append(step_info)

                except TimeoutError as timeout_error:
                    # Step timeout - skill might be stuck, stop gracefully
                    logger.warning(f"⏰ Skill step {i + 1} timed out: {timeout_error}")
                    logger.warning("Stopping skill execution due to timeout")
                    break
                except Exception as step_error:
                    # Step errors might indicate task completion or agent stopping naturally
                    logger.info(f"Step {i + 1} stopped: {step_error}")
                    break

            logger.info(f"✓ Skill execution completed after {len(history_steps)} steps")
            history = history_steps

            # Parse the result from agent's final message
            # The agent should return text describing the validation result
            # We'll structure it into a validation result dictionary
            result_text = str(history)
            validation_result: dict[str, Any] = {
                "validation_id": skill_name,
                "result": 1
                if "success" in result_text.lower() or "pass" in result_text.lower()
                else 0,
                "score": 100
                if "success" in result_text.lower() or "pass" in result_text.lower()
                else 50,
                "result_explanation": result_text,
                "confidence": 0.7,
            }

            # Ensure required fields exist
            validation_result.setdefault("validation_id", skill_name)
            validation_result.setdefault("result", 0)
            validation_result.setdefault("score", 0)
            validation_result.setdefault(
                "result_explanation", "No explanation provided"
            )
            validation_result.setdefault("confidence", 0.5)

            logger.info(
                f"✓ Skill '{skill_name}' completed: "
                f"{'PASS' if validation_result['result'] == 1 else 'FAIL'} "
                f"(score: {validation_result['score']})"
            )

            return validation_result

        except Exception as e:
            logger.error(f"Skill execution failed: {e}", exc_info=True)
            return {
                "validation_id": skill_name,
                "result": 0,
                "score": 0,
                "result_explanation": f"Skill execution error: {str(e)}",
                "confidence": 0.0,
            }

    def _extract_context_for_skill(self, skill: SkillDefinition) -> str:
        """
        Extract relevant context from transcript for skill execution.

        Args:
          skill: The skill being executed

        Returns:
          Formatted context string
        """
        # Get last few turns for context
        recent_turns = (
            self.transcript[-6:] if len(self.transcript) >= 6 else self.transcript
        )

        context_parts = []
        for turn in recent_turns:
            role = getattr(turn, "role", "unknown")
            text = getattr(turn, "text", str(turn))
            context_parts.append(f"**{role.title()}**: {text[:200]}...")

        context = "\n\n".join(context_parts)

        # Add target URL if available
        if self.target_url:
            context = f"**Target URL**: {self.target_url}\n\n{context}"

        return context

    async def __call__(self, skill_name: str) -> dict[str, Any]:
        """
        Execute a skill (callable interface).

        This is the entry point when the agent invokes the skill tool.

        Args:
          skill_name: Name of the skill to execute

        Returns:
          Validation result dictionary
        """
        return await self.execute_skill(skill_name)
