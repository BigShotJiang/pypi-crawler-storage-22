"""Tests for app_context_report tool."""

import json

from tools.app_context_report import app_context_report


def test_app_context_report_returns_valid_json() -> None:
    """Test that app_context_report returns valid JSON."""
    result = app_context_report(
        summary="Test summary",
        core_functionality="Test functionality",
        target_audience="Test audience",
        technical_information="Test technical info",
        chat_interface_description="Test chat interface",
    )

    # Should be valid JSON
    parsed = json.loads(result)
    assert isinstance(parsed, dict)


def test_app_context_report_contains_all_fields() -> None:
    """Test that app_context_report includes all expected fields."""
    result = app_context_report(
        summary="Test summary",
        core_functionality="Test functionality",
        target_audience="Test audience",
        technical_information="Test technical info",
        chat_interface_description="Test chat interface",
    )

    parsed = json.loads(result)
    assert "summary" in parsed
    assert "core_functionality" in parsed
    assert "target_audience" in parsed
    assert "technical_information" in parsed
    assert "chat_interface_description" in parsed


def test_app_context_report_preserves_values() -> None:
    """Test that app_context_report preserves input values correctly."""
    summary = "A travel planning application"
    functionality = "Trip planning and booking services"
    audience = "Travelers and tourists"
    technical = "Web-based platform using React"
    chat = "AI-powered chat assistant for customer support"

    result = app_context_report(
        summary=summary,
        core_functionality=functionality,
        target_audience=audience,
        technical_information=technical,
        chat_interface_description=chat,
    )

    parsed = json.loads(result)
    assert parsed["summary"] == summary
    assert parsed["core_functionality"] == functionality
    assert parsed["target_audience"] == audience
    assert parsed["technical_information"] == technical
    assert parsed["chat_interface_description"] == chat


def test_app_context_report_handles_special_characters() -> None:
    """Test that app_context_report handles special characters in input."""
    result = app_context_report(
        summary="Summary with \"quotes\" and 'apostrophes'",
        core_functionality="Functionality with\nnewlines",
        target_audience="Audience with émojis 🎉",
        technical_information="Technical with <html> tags",
        chat_interface_description='Chat with {json: "objects"}',
    )

    # Should be valid JSON despite special characters
    parsed = json.loads(result)
    assert "quotes" in parsed["summary"]
    assert "\n" in parsed["core_functionality"]
    assert "🎉" in parsed["target_audience"]
    assert "<html>" in parsed["technical_information"]
    assert "json" in parsed["chat_interface_description"]


def test_app_context_report_handles_empty_strings() -> None:
    """Test that app_context_report handles empty strings."""
    result = app_context_report(
        summary="",
        core_functionality="",
        target_audience="",
        technical_information="",
        chat_interface_description="",
    )

    parsed = json.loads(result)
    assert parsed["summary"] == ""
    assert parsed["core_functionality"] == ""
    assert parsed["target_audience"] == ""
    assert parsed["technical_information"] == ""
    assert parsed["chat_interface_description"] == ""
