"""
Tests for Arato API logging integration.
"""

from agents.chat_runner import ChatRunner
from tools.arato_logs_api import AratoLogsAPI


class TestAratoLogging:
    """Tests for Arato logging API integration."""

    def test_chat_runner_initialization(self) -> None:
        """Test that ChatRunner can be initialized with parameters."""
        runner = ChatRunner(headless=True)
        assert runner is not None
        assert runner.headless is True

    def test_arato_client_initialization(self) -> None:
        """Test that AratoLogsAPI client can be initialized."""
        api_url = "https://api.arato.ai/test-endpoint/log"
        api_key = "test-api-key-123"

        client = AratoLogsAPI(api_url=api_url, api_key=api_key)

        assert client is not None
        assert client.api_url == api_url
        assert client.api_key == api_key
