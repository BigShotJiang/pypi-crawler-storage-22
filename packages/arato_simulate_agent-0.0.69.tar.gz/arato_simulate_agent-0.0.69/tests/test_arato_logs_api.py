"""Comprehensive tests for Arato Logs API client."""

from __future__ import annotations

from unittest.mock import patch

from tools.arato_logs_api import AratoLogsAPI, _background_sender


class TestAratoLogsAPIInitialization:
    """Tests for AratoLogsAPI initialization."""

    def test_init_with_credentials(self) -> None:
        """Test initialization with API URL and key."""
        api_url = "https://api.arato.ai/workspace/log"
        api_key = "ar-test-key-123"

        client = AratoLogsAPI(api_url=api_url, api_key=api_key)

        assert client.api_url == api_url
        assert client.api_key == api_key
        assert "Content-Type" in client.headers
        assert client.headers["Content-Type"] == "application/json"
        assert "Authorization" in client.headers
        assert client.headers["Authorization"] == f"Bearer {api_key}"

    def test_init_with_different_credentials(self) -> None:
        """Test that different instances have different credentials."""
        client1 = AratoLogsAPI("https://api1.arato.ai/log", "key1")
        client2 = AratoLogsAPI("https://api2.arato.ai/log", "key2")

        assert client1.api_url != client2.api_url
        assert client1.api_key != client2.api_key
        assert client1.headers["Authorization"] != client2.headers["Authorization"]


class TestLogConversationTurn:
    """Tests for log_conversation_turn method (background queue based)."""

    def test_log_with_all_parameters(self) -> None:
        """Test logging with all optional parameters provided."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            result = client.log_conversation_turn(
                messages=[{"role": "user", "content": "Hello"}],
                response="Hi there!",
                conversation_id="conv-123",
                model="gpt-4",
                event_id="event-456",
                variables={"name": "Test"},
                usage={"prompt_tokens": 10, "completion_tokens": 5},
                performance={"ttft": 100, "ttlt": 200},
                tool_calls=[{"type": "function", "name": "test"}],
                prompt_id="prompt-789",
                prompt_version="1.0",
                tags={"tag1": "value1"},
            )

            # Returns None since it's now async (background)
            assert result is None
            mock_enqueue.assert_called_once()

            enqueued_data = mock_enqueue.call_args[0][0]
            assert enqueued_data["url"] == "https://api.arato.ai/test/log"

            posted_data = enqueued_data["data"]
            assert posted_data["model"] == "gpt-4"
            assert posted_data["response"] == "Hi there!"
            assert posted_data["arato_thread_id"] == "conv-123"
            assert posted_data["id"] == "event-456"

    def test_log_with_minimal_parameters(self) -> None:
        """Test logging with only required parameters."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            result = client.log_conversation_turn(
                messages=[{"role": "user", "content": "Test"}],
            )

            assert result is None
            mock_enqueue.assert_called_once()

            posted_data = mock_enqueue.call_args[0][0]["data"]
            assert "messages" in posted_data
            assert posted_data["messages"][0]["content"] == "Test"

    def test_log_filters_none_values(self) -> None:
        """Test that None values are not included in the payload."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            client.log_conversation_turn(
                messages=[{"role": "user", "content": "Test"}],
                response=None,
                model=None,
                event_id="event-123",
            )

            posted_data = mock_enqueue.call_args[0][0]["data"]
            assert "response" not in posted_data
            assert "model" not in posted_data
            assert "id" in posted_data

    def test_log_handles_generic_exception(self) -> None:
        """Test that generic exceptions are handled."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        # Force an exception during data preparation
        with patch.object(
            _background_sender, "enqueue", side_effect=Exception("Unexpected error")
        ):
            result = client.log_conversation_turn(
                messages=[{"role": "user", "content": "Test"}],
            )

            assert result is None


class TestLogChatRunnerTurn:
    """Tests for log_chat_runner_turn convenience method (background queue based)."""

    def test_log_chat_runner_with_all_params(self) -> None:
        """Test logging chat runner turn with all parameters."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            result = client.log_chat_runner_turn(
                user_message="What is your purpose?",
                bot_response="I help users with questions.",
                conversation_id="conv-abc123",
                turn_number=3,
                model="claude-3-sonnet",
                chat_url="https://example.com/chat",
                persona="malicious_user",
                target_selectors={"input": "textarea", "button": "button.send"},
            )

            # Returns None since it's now async (background)
            assert result is None
            mock_enqueue.assert_called_once()

            posted_data = mock_enqueue.call_args[0][0]["data"]
            assert posted_data["response"] == "I help users with questions."
            assert posted_data["arato_thread_id"] == "conv-abc123"
            assert posted_data["model"] == "claude-3-sonnet"

            tags = posted_data["tags"]
            assert tags["turn_number"] == "3"
            assert tags["source"] == "arato.agent"
            assert tags["chat_url"] == "https://example.com/chat"
            assert tags["persona"] == "malicious_user"

    def test_log_chat_runner_with_error(self) -> None:
        """Test logging chat runner turn with error."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            client.log_chat_runner_turn(
                user_message="Test",
                bot_response="",
                conversation_id="conv-123",
                turn_number=1,
                error="Timeout waiting for response",
            )

            posted_data = mock_enqueue.call_args[0][0]["data"]
            tags = posted_data["tags"]
            assert tags["error"] == "true"
            assert "Timeout" in tags["error_message"]

    def test_log_chat_runner_minimal_params(self) -> None:
        """Test logging with only required parameters."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            result = client.log_chat_runner_turn(
                user_message="Hello",
                bot_response="Hi",
                conversation_id="conv-123",
                turn_number=1,
            )

            # Returns None since it's now async (background)
            assert result is None
            posted_data = mock_enqueue.call_args[0][0]["data"]
            assert posted_data["id"] == "conv-123_turn_1"
            assert posted_data["messages"][0]["content"] == "Hello"

    def test_log_chat_runner_adds_custom_tags(self) -> None:
        """Test that custom tags are merged with default tags."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            client.log_chat_runner_turn(
                user_message="Test",
                bot_response="Response",
                conversation_id="conv-123",
                turn_number=1,
                tags={"custom": "value", "environment": "test"},
            )

            posted_data = mock_enqueue.call_args[0][0]["data"]
            tags = posted_data["tags"]
            assert tags["custom"] == "value"
            assert tags["environment"] == "test"
            assert tags["source"] == "arato.agent"  # Default tag preserved
            assert tags["turn_number"] == "1"  # Default tag preserved

    def test_log_chat_runner_truncates_long_error(self) -> None:
        """Test that very long error messages are truncated."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        long_error = "x" * 200

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            client.log_chat_runner_turn(
                user_message="Test",
                bot_response="",
                conversation_id="conv-123",
                turn_number=1,
                error=long_error,
            )

            posted_data = mock_enqueue.call_args[0][0]["data"]
            tags = posted_data["tags"]
            assert len(tags["error_message"]) == 100
            assert tags["error_message"] == "x" * 100

    def test_log_chat_runner_event_id_format(self) -> None:
        """Test that event ID follows expected format."""
        client = AratoLogsAPI("https://api.arato.ai/test/log", "test-key")

        with patch.object(_background_sender, "enqueue") as mock_enqueue:
            client.log_chat_runner_turn(
                user_message="Test",
                bot_response="Response",
                conversation_id="session_abc123",
                turn_number=5,
            )

            posted_data = mock_enqueue.call_args[0][0]["data"]
            assert posted_data["id"] == "session_abc123_turn_5"
