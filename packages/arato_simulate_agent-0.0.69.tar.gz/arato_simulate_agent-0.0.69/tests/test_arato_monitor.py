"""Comprehensive tests for Arato Monitor."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest
import requests

from utils.arato_monitor import AratoMonitor


class TestAratoMonitorSingleton:
    """Tests for AratoMonitor singleton pattern."""

    def test_get_instance_returns_none_when_not_configured(self) -> None:
        """Test that get_instance returns None when ARATO_MONITOR_TOKEN is not set."""
        # Reset singleton
        AratoMonitor._instance = None

        with patch.dict(os.environ, {}, clear=True):
            monitor = AratoMonitor.get_instance()
            assert monitor is None

    def test_get_instance_returns_monitor_when_configured(self) -> None:
        """Test that get_instance returns monitor when ARATO_MONITOR_TOKEN is set."""
        # Reset singleton
        AratoMonitor._instance = None

        with patch.dict(os.environ, {"ARATO_MONITOR_TOKEN": "test-token"}):
            monitor = AratoMonitor.get_instance()
            assert monitor is not None
            assert isinstance(monitor, AratoMonitor)
            assert monitor.api_token == "test-token"

    def test_get_instance_returns_same_instance(self) -> None:
        """Test that get_instance returns the same singleton instance."""
        # Reset singleton
        AratoMonitor._instance = None

        with patch.dict(os.environ, {"ARATO_MONITOR_TOKEN": "test-token"}):
            monitor1 = AratoMonitor.get_instance()
            monitor2 = AratoMonitor.get_instance()
            assert monitor1 is monitor2


class TestAratoMonitorInitialization:
    """Tests for AratoMonitor initialization."""

    def test_init_sets_token_and_headers(self) -> None:
        """Test that initialization sets API token and headers correctly."""
        monitor = AratoMonitor(api_token="test-token")

        assert monitor.api_token == "test-token"
        assert monitor.headers["Content-Type"] == "application/json"
        assert monitor.headers["Authorization"] == "Bearer test-token"


class TestAratoMonitorSend:
    """Tests for AratoMonitor.send method."""

    @pytest.fixture(autouse=True)
    def setup(self) -> None:
        """Reset singleton before each test."""
        AratoMonitor._instance = None

    def test_send_returns_none_when_url_not_configured(self) -> None:
        """Test that send returns None when prompt URL is not configured."""
        monitor = AratoMonitor(api_token="test-token")

        with patch.dict(os.environ, {}, clear=True):
            mock_response = MagicMock()
            mock_response.completion = "Test response"
            mock_response.usage = None

            result = monitor.send(
                prompt_name="test_prompt",
                llm_response=mock_response,
                prompt_content="Test prompt content",
            )

            assert result is None

    def test_send_with_minimal_parameters(self) -> None:
        """Test send with only required parameters."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Test LLM response"
        mock_response.usage = None
        mock_response.model_name = "claude-3-5-sonnet"

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 200

        with patch.dict(
            os.environ, {"ARATO_TEST_PROMPT_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", return_value=mock_http_response) as mock_post:
                result = monitor.send(
                    prompt_name="test_prompt",
                    llm_response=mock_response,
                    prompt_content="Test prompt",
                )

                assert result == mock_http_response
                mock_post.assert_called_once()

                call_args = mock_post.call_args
                assert call_args[0][0] == "https://api.example.com/monitor"
                assert call_args[1]["timeout"] == 5

                payload = call_args[1]["json"]
                assert payload["prompt_id"] == "test_prompt"
                assert payload["response"] == "Test LLM response"
                assert payload["messages"] == [
                    {"role": "user", "content": "Test prompt"}
                ]
                assert payload["model"] == "claude-3-5-sonnet"
                assert payload["event_source"] == "aut"

    def test_send_with_all_parameters(self) -> None:
        """Test send with all optional parameters."""
        monitor = AratoMonitor(api_token="test-token")

        # Create mock LLM response with usage data
        mock_usage = MagicMock()
        mock_usage.output_tokens = 100
        mock_usage.input_tokens = 50
        mock_usage.total_tokens = 150

        mock_response = MagicMock()
        mock_response.completion = "Detailed response"
        mock_response.usage = mock_usage
        mock_response.model_name = "claude-3-opus"

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 200

        latency_stats = {
            "count": 5,
            "avg_latency": 1.5,
            "median_latency": 1.2,
        }

        with patch.dict(
            os.environ, {"ARATO_ANALYSIS_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", return_value=mock_http_response) as mock_post:
                result = monitor.send(
                    prompt_name="analysis",
                    llm_response=mock_response,
                    prompt_content="Analyze this conversation",
                    session_id="session-123",
                    persona_id="malicious_user",
                    target_url="https://example.com",
                    latency_stats=latency_stats,
                )

                assert result == mock_http_response

                payload = mock_post.call_args[1]["json"]
                assert payload["prompt_id"] == "analysis"
                assert payload["response"] == "Detailed response"
                assert payload["messages"] == [
                    {"role": "user", "content": "Analyze this conversation"}
                ]
                assert payload["model"] == "claude-3-opus"

                # Check usage data
                assert payload["usage"]["completion_tokens"] == 100
                assert payload["usage"]["prompt_tokens"] == 50
                assert payload["usage"]["total_tokens"] == 150

                # Check performance data
                assert payload["performance"]["avg_latency_ms"] == 1500
                assert payload["performance"]["median_latency_ms"] == 1200

                # Check tags
                assert payload["tags"]["event_type"] == "analysis"
                assert payload["tags"]["persona_id"] == "malicious_user"
                assert payload["tags"]["url"] == "https://example.com"

    def test_send_constructs_log_id_correctly(self) -> None:
        """Test that log_id (event_id) is constructed correctly."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        mock_response.usage = None
        mock_response.model_name = "claude-3-5-sonnet"

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 200

        with patch.dict(
            os.environ, {"ARATO_TEST_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", return_value=mock_http_response) as mock_post:
                # Test with session_id and persona_id
                monitor.send(
                    prompt_name="test",
                    llm_response=mock_response,
                    prompt_content="Test",
                    session_id="session-123",
                    persona_id="persona-456",
                )
                payload = mock_post.call_args[1]["json"]
                # Should be in format: session_id/persona_id_timestamp
                # where timestamp is YYYYMMDD_HHMMSS (e.g., 20251214_155428)
                assert payload["id"].startswith("session-123/persona-456_")
                # Split by _ to get timestamp parts: [session-123/persona-456, YYYYMMDD, HHMMSS]
                parts = payload["id"].split("_")
                assert len(parts) == 3
                assert len(parts[1]) == 8  # YYYYMMDD
                assert len(parts[2]) == 6  # HHMMSS

    def test_send_handles_http_error(self) -> None:
        """Test that send handles HTTP errors gracefully."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        mock_response.usage = None

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 500
        mock_http_response.text = "Internal Server Error"

        with patch.dict(
            os.environ, {"ARATO_TEST_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", return_value=mock_http_response):
                result = monitor.send(
                    prompt_name="test",
                    llm_response=mock_response,
                    prompt_content="Test",
                )

                assert result is None

    def test_send_handles_timeout(self) -> None:
        """Test that send handles request timeout gracefully."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        mock_response.usage = None

        with patch.dict(
            os.environ, {"ARATO_TEST_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", side_effect=requests.exceptions.Timeout):
                result = monitor.send(
                    prompt_name="test",
                    llm_response=mock_response,
                    prompt_content="Test",
                )

                assert result is None

    def test_send_handles_generic_exception(self) -> None:
        """Test that send handles generic exceptions gracefully."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        mock_response.usage = None

        with patch.dict(
            os.environ, {"ARATO_TEST_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", side_effect=Exception("Network error")):
                result = monitor.send(
                    prompt_name="test",
                    llm_response=mock_response,
                    prompt_content="Test",
                )

                assert result is None

    def test_send_filters_none_values(self) -> None:
        """Test that None values are filtered out of the payload."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        mock_response.usage = None
        mock_response.model_name = "claude-3-5-sonnet"

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 200

        with patch.dict(
            os.environ, {"ARATO_TEST_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", return_value=mock_http_response) as mock_post:
                monitor.send(
                    prompt_name="test",
                    llm_response=mock_response,
                    prompt_content="Test",
                    # All optional parameters are None
                )

                payload = mock_post.call_args[1]["json"]
                # None values should not be in payload
                assert "usage" not in payload
                assert "performance" not in payload

    def test_send_uses_correct_env_var_name(self) -> None:
        """Test that send constructs the environment variable name correctly."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        mock_response.usage = None
        mock_response.model_name = "claude-3-5-sonnet"

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 200

        # Test that 'chat_runner_analysis' converts to 'ARATO_CHAT_RUNNER_ANALYSIS_URL'
        with patch.dict(
            os.environ,
            {"ARATO_CHAT_RUNNER_ANALYSIS_URL": "https://api.example.com/monitor"},
        ):
            with patch("requests.post", return_value=mock_http_response) as mock_post:
                monitor.send(
                    prompt_name="chat_runner_analysis",
                    llm_response=mock_response,
                    prompt_content="Test",
                )

                assert mock_post.called
                assert mock_post.call_args[0][0] == "https://api.example.com/monitor"

    def test_send_without_usage_object(self) -> None:
        """Test send when llm_response has no usage object."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        # No usage attribute
        del mock_response.usage
        mock_response.model_name = "claude-3-5-sonnet"

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 200

        with patch.dict(
            os.environ, {"ARATO_TEST_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", return_value=mock_http_response) as mock_post:
                monitor.send(
                    prompt_name="test",
                    llm_response=mock_response,
                    prompt_content="Test",
                )

                payload = mock_post.call_args[1]["json"]
                assert "usage" not in payload

    def test_send_with_empty_latency_stats(self) -> None:
        """Test send when latency_stats has count=0."""
        monitor = AratoMonitor(api_token="test-token")

        mock_response = MagicMock()
        mock_response.completion = "Response"
        mock_response.usage = None
        mock_response.model_name = "claude-3-5-sonnet"

        mock_http_response = MagicMock(spec=requests.Response)
        mock_http_response.status_code = 200

        latency_stats = {"count": 0}

        with patch.dict(
            os.environ, {"ARATO_TEST_URL": "https://api.example.com/monitor"}
        ):
            with patch("requests.post", return_value=mock_http_response) as mock_post:
                monitor.send(
                    prompt_name="test",
                    llm_response=mock_response,
                    prompt_content="Test",
                    latency_stats=latency_stats,
                )

                payload = mock_post.call_args[1]["json"]
                assert "performance" not in payload


class TestAratoMonitorIntegrationWithoutEnv:
    """Test that the system gracefully handles missing environment variables."""

    @pytest.fixture(autouse=True)
    def setup(self) -> None:
        """Reset singleton before each test."""
        AratoMonitor._instance = None

    def test_get_instance_returns_none_without_token(self) -> None:
        """Test that get_instance returns None when ARATO_MONITOR_TOKEN is not set."""
        with patch.dict(os.environ, {}, clear=True):
            monitor = AratoMonitor.get_instance()
            assert monitor is None

    def test_integration_code_handles_none_monitor(self) -> None:
        """Test that integration code gracefully handles None monitor (no env vars)."""
        with patch.dict(os.environ, {}, clear=True):
            # Simulate what happens in chat_runner.py, report_data_generator.py, summary_generator.py
            monitor = AratoMonitor.get_instance()

            # Monitor should be None when not configured
            assert monitor is None

    def test_send_not_called_without_env_vars(self) -> None:
        """Test that send() is never called when environment variables are missing."""
        with patch.dict(os.environ, {}, clear=True):
            monitor = AratoMonitor.get_instance()

            # Monitor should be None
            assert monitor is None

            # Attempting to call send() on None would raise AttributeError
            # But our integration code checks "if monitor:" first, so this never happens
            # This test documents the expected behavior

    def test_partial_env_configuration(self) -> None:
        """Test behavior when token is set but specific prompt URL is missing."""
        with patch.dict(
            os.environ,
            {
                "ARATO_MONITOR_TOKEN": "test-token",
                # No ARATO_CHAT_RUNNER_ANALYSIS_URL
                # No ARATO_SUMMARY_REPORT_TEMPLATE_URL
                # No ARATO_BEHAVIORAL_SCORE_DESCRIPTION_URL
            },
            clear=True,
        ):
            monitor = AratoMonitor.get_instance()

            # Monitor should exist (token is set)
            assert monitor is not None
            assert monitor.api_token == "test-token"

            # But send() should return None when specific URL is not configured
            mock_response = MagicMock()
            mock_response.completion = "Test response"
            mock_response.usage = None
            mock_response.model_name = "claude-3-5-sonnet"

            result = monitor.send(
                prompt_name="chat_runner_analysis",  # No ARATO_CHAT_RUNNER_ANALYSIS_URL set
                llm_response=mock_response,
                prompt_content="Test prompt",
            )

            # Should return None (URL not configured for this prompt)
            assert result is None

    def test_all_integration_points_safe_without_env(self) -> None:
        """Test that all integration points are safe when no env vars are set."""
        with patch.dict(os.environ, {}, clear=True):
            # Reset singleton
            AratoMonitor._instance = None

            # Simulate chat_runner.py pattern
            monitor = AratoMonitor.get_instance()
            if monitor:
                pytest.fail("chat_runner: Monitor should be None without env vars")

            # Simulate report_data_generator.py pattern
            monitor = AratoMonitor.get_instance()
            if monitor:
                pytest.fail(
                    "report_data_generator: Monitor should be None without env vars"
                )

            # Simulate summary_generator.py pattern
            monitor = AratoMonitor.get_instance()
            if monitor:
                pytest.fail(
                    "summary_generator: Monitor should be None without env vars"
                )

            # All checks passed - system is safe without environment variables
