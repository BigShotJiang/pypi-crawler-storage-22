"""Tests for AWS AgentCore platform adapters.

These tests verify the AWS platform adapter implementations work correctly.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from core.llm import LLMAdapter
from platforms.aws_agentcore.adapter import AWSAgentCorePlatformAdapter
from platforms.aws_agentcore.browser import (
    AgentCoreBrowserManager,
    AgentCoreBrowserSession,
)
from platforms.aws_agentcore.storage import S3StorageAdapter


class TestAWSAdapterInitialization:
    """Tests for AWS adapter initialization."""

    def test_init_with_defaults(self) -> None:
        """Test adapter initialization with default values."""
        adapter = AWSAgentCorePlatformAdapter()
        assert adapter.region is not None
        assert adapter._app is not None

    def test_init_with_custom_region(self) -> None:
        """Test adapter initialization with custom region."""
        adapter = AWSAgentCorePlatformAdapter(region="eu-west-1")
        assert adapter.region == "eu-west-1"

    def test_supports_background_tasks(self) -> None:
        """Test that AWS adapter supports background tasks."""
        adapter = AWSAgentCorePlatformAdapter()
        assert adapter.supports_background_tasks() is True


class TestSessionManagement:
    """Tests for session ID and directory management."""

    def test_resolve_session_id_provided(self) -> None:
        """Test that provided session ID is returned."""
        adapter = AWSAgentCorePlatformAdapter()
        session_id = adapter.resolve_session_id("custom-123")
        assert session_id == "custom-123"

    def test_resolve_session_id_generated(self) -> None:
        """Test that session ID is generated when None."""
        adapter = AWSAgentCorePlatformAdapter()
        session_id = adapter.resolve_session_id(None)
        assert session_id.startswith("session_")
        assert len(session_id) > 20

    def test_get_session_directory(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test session directory creation."""
        monkeypatch.setattr("constants.TMP_SESSIONS_DIR", str(tmp_path))

        adapter = AWSAgentCorePlatformAdapter()
        session_dir = adapter.get_session_directory("test-session")

        assert session_dir.exists()
        assert session_dir.is_dir()


class TestLLMAdapter:
    """Tests for LLM adapter (used by both platforms)."""

    def test_init_default(self) -> None:
        """Test adapter initialization."""
        adapter = LLMAdapter()
        assert adapter._region is None

    def test_init_with_region(self) -> None:
        """Test adapter with custom region."""
        adapter = LLMAdapter(region="us-west-2")
        assert adapter._region == "us-west-2"

    def test_get_default_model_id(self) -> None:
        """Test getting default model ID."""
        adapter = LLMAdapter()
        model_id = adapter.get_default_model_id()
        assert isinstance(model_id, str)
        assert "gemini" in model_id.lower()

    def test_get_available_models(self) -> None:
        """Test getting available models."""
        adapter = LLMAdapter()
        models = adapter.get_available_models()
        assert isinstance(models, dict)
        assert "vertex_haiku" in models
        assert "vertex_sonnet" in models
        assert "bedrock_haiku" in models
        assert "bedrock_sonnet" in models
        assert "gemini_pro" in models
        assert "gemini_flash" in models

    def test_resolve_region_default(self) -> None:
        """Test region resolution with default."""
        adapter = LLMAdapter()
        region = adapter.resolve_region()
        assert region == "us-east-1"

    def test_resolve_region_custom(self) -> None:
        """Test region resolution with custom region."""
        adapter = LLMAdapter(region="eu-central-1")
        region = adapter.resolve_region()
        assert region == "eu-central-1"


class TestAgentCoreBrowserManager:
    """Tests for AgentCore browser manager."""

    def test_init_default(self) -> None:
        """Test browser manager initialization."""
        manager = AgentCoreBrowserManager()
        assert manager.region == "us-east-1"

    def test_init_custom_region(self) -> None:
        """Test browser manager with custom region."""
        manager = AgentCoreBrowserManager(region="us-west-2")
        assert manager.region == "us-west-2"

    def test_setup_browser_kwargs_minimal(self) -> None:
        """Test setup with minimal config."""
        manager = AgentCoreBrowserManager()
        kwargs = manager.setup_browser_kwargs()
        assert isinstance(kwargs, dict)

    def test_setup_browser_kwargs_with_security(self) -> None:
        """Test setup with security disabled."""
        manager = AgentCoreBrowserManager()
        kwargs = manager.setup_browser_kwargs(disable_security=True)
        assert kwargs["disable_security"] is True

    def test_setup_browser_kwargs_with_video(self) -> None:
        """Test setup with video recording."""
        manager = AgentCoreBrowserManager()
        kwargs = manager.setup_browser_kwargs(record_video_dir="/tmp/videos")
        assert kwargs["record_video_dir"] == "/tmp/videos"


class TestAgentCoreBrowserSession:
    """Tests for browser session context manager."""

    def test_init_default(self) -> None:
        """Test session initialization."""
        session = AgentCoreBrowserSession()
        assert session.region == "us-east-1"
        assert session._session_client is None

    def test_init_custom_region(self) -> None:
        """Test session with custom region."""
        session = AgentCoreBrowserSession(region="ap-south-1")
        assert session.region == "ap-south-1"


class TestS3StorageAdapter:
    """Tests for S3 storage adapter."""

    def test_init_defaults(self) -> None:
        """Test adapter initialization with defaults."""
        adapter = S3StorageAdapter()
        assert adapter._bucket_name is None
        assert adapter._region == "us-east-1"

    def test_init_with_bucket(self) -> None:
        """Test adapter with custom bucket."""
        adapter = S3StorageAdapter(bucket_name="my-bucket")
        assert adapter._bucket_name == "my-bucket"

    def test_init_with_region(self) -> None:
        """Test adapter with custom region."""
        adapter = S3StorageAdapter(region="eu-west-1")
        assert adapter._region == "eu-west-1"

    def test_resolve_bucket_name_provided(self) -> None:
        """Test bucket name resolution when provided."""
        adapter = S3StorageAdapter(bucket_name="test-bucket")
        name = adapter._resolve_bucket_name()
        assert name == "test-bucket"

    def test_resolve_bucket_name_generated(self) -> None:
        """Test bucket name generation."""
        adapter = S3StorageAdapter()
        with patch.object(adapter, "_get_account_id", return_value="123456789012"):
            name = adapter._resolve_bucket_name()
            assert "arato-agent-artifacts" in name
            assert "123456789012" in name

    def test_get_storage_location(self) -> None:
        """Test getting storage location."""
        adapter = S3StorageAdapter(bucket_name="test-bucket")
        location = adapter.get_storage_location()
        assert location == "s3://test-bucket"

    def test_sanitize_bucket_component(self) -> None:
        """Test bucket name sanitization."""
        adapter = S3StorageAdapter()
        result = adapter._sanitize_bucket_component("TEST_BUCKET")
        assert result.islower()
        assert "_" not in result

    def test_download_cache_signature(self) -> None:
        """Test download_cache has correct signature."""
        adapter = S3StorageAdapter(bucket_name="test")
        mock_client = MagicMock()
        # Simulate not found with ClientError
        from botocore.exceptions import ClientError

        mock_client.get_object.side_effect = ClientError(
            {"Error": {"Code": "404"}}, "get_object"
        )

        with patch.object(adapter, "_get_s3_client", return_value=mock_client):
            # Should accept domain and cache_key parameters
            result = adapter.download_cache(domain="example.com", cache_key="test.md")
            assert result is None

    def test_upload_cache_signature(self) -> None:
        """Test upload_cache has correct signature."""
        adapter = S3StorageAdapter(bucket_name="test")
        mock_client = MagicMock()

        with patch.object(adapter, "_get_s3_client", return_value=mock_client):
            with patch.object(adapter, "_ensure_bucket_exists"):
                # Should accept domain, content, and cache_key parameters
                result = adapter.upload_cache(
                    domain="example.com", content="test", cache_key="test.md"
                )
                assert result is True


class TestInvokeReturnsCorrectly:
    """Tests for invoke method return values."""

    @pytest.mark.asyncio
    async def test_invoke_returns_started_status(self) -> None:
        """Test that invoke returns correct status."""
        from unittest.mock import AsyncMock

        adapter = AWSAgentCorePlatformAdapter()

        payload = {"target_url": "https://example.com"}
        context = MagicMock()

        # Mock _run_pipeline_async to prevent actual pipeline execution.
        # The invoke method now awaits _run_pipeline_async directly and
        # returns status "completed".
        mock_result = {"personas": [], "summary": "mock"}
        with patch.object(
            adapter,
            "_run_pipeline_async",
            new_callable=AsyncMock,
            return_value=mock_result,
        ):
            result = await adapter.invoke(payload, context)

            assert result["status"] == "completed"
            assert "session_id" in result
            assert result["target_url"] == "https://example.com"
