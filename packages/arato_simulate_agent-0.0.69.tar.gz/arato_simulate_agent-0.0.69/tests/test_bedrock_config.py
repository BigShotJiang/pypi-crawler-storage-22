"""Tests for bedrock_config utilities."""

import os
from pathlib import Path
from unittest.mock import mock_open, patch

import pytest

from utils.bedrock_config import get_agent_id


def test_get_agent_id_from_env() -> None:
    """Test that get_agent_id() reads from environment variable first."""
    with patch.dict(os.environ, {"BEDROCK_AGENTCORE_AGENT_ID": "test-agent-123"}):
        agent_id = get_agent_id()
        assert agent_id == "test-agent-123"


def test_get_agent_id_from_config_file() -> None:
    """Test that get_agent_id() falls back to config file when env var not set."""
    with patch.dict(os.environ, {}, clear=False):
        # Remove the env var if it exists
        os.environ.pop("BEDROCK_AGENTCORE_AGENT_ID", None)

        # Mock the config file content
        mock_config = {
            "default_agent": "test_agent",
            "agents": {
                "test_agent": {
                    "bedrock_agentcore": {"agent_id": "test-agent-from-file"}
                }
            },
        }

        yaml_content = """
default_agent: test_agent
agents:
  test_agent:
    bedrock_agentcore:
      agent_id: test-agent-from-file
"""

        with patch("pathlib.Path.exists", return_value=True):
            with patch("builtins.open", mock_open(read_data=yaml_content)):
                with patch("yaml.safe_load", return_value=mock_config):
                    agent_id = get_agent_id()
                    assert agent_id == "test-agent-from-file"


def test_get_agent_id_missing_config() -> None:
    """Test that get_agent_id() raises ValueError when config is missing."""
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop("BEDROCK_AGENTCORE_AGENT_ID", None)

        with patch.object(Path, "exists", return_value=False):
            with patch("utils.bedrock_config._get_ssm_parameter", return_value=None):
                with pytest.raises(ValueError, match="not found"):
                    get_agent_id()


def test_get_agent_id_env_takes_precedence() -> None:
    """Test that environment variable takes precedence over config file."""
    with patch.dict(
        os.environ, {"BEDROCK_AGENTCORE_AGENT_ID": "env-agent-456"}, clear=False
    ):
        agent_id = get_agent_id()
        # Should use env var, not config file
        assert agent_id == "env-agent-456"


def test_get_agent_id_not_required() -> None:
    """Test that get_agent_id(required=False) returns None when config is missing."""
    with patch.dict(os.environ, {}, clear=False):
        os.environ.pop("BEDROCK_AGENTCORE_AGENT_ID", None)

        with patch.object(Path, "exists", return_value=False):
            with patch("utils.bedrock_config._get_ssm_parameter", return_value=None):
                agent_id = get_agent_id(required=False)
                assert agent_id is None
