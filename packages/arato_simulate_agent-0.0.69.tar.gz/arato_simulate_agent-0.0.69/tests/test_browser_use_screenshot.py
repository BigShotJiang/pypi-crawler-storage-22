"""Unit tests for browser-use screenshot functionality.

This test validates that browser-use's page.screenshot() method works correctly.

Key findings:
- page.screenshot(format="png") returns BASE64-encoded string, not bytes!
- Supported formats: 'jpeg', 'png', 'webp'
- For JPEG, optional quality parameter (0-100)
- Use browser.stop() for clean shutdown (not browser.close() which hangs)
"""

import asyncio
import base64
import logging

import pytest

logger = logging.getLogger(__name__)


@pytest.mark.asyncio
async def test_browser_use_screenshot_api() -> None:
    """Test browser-use screenshot API.

    This test validates that:
    1. Browser can be created and started
    2. browser.new_page() creates a new page
    3. browser.get_current_page() returns the active page
    4. page.screenshot(format='png') returns base64-encoded PNG
    5. browser.stop() cleanly shuts down the browser
    """
    from browser_use import Browser

    # Create browser directly (context manager also hangs on exit)
    browser = Browser(headless=True)

    # Start the browser to initialize CDP connection
    await browser.start()
    logger.info(f"✓ Browser started: {type(browser)}")

    # Create a new page - browser-use requires this
    await browser.new_page("about:blank")
    logger.info("✓ Created new page at about:blank")

    # Get the current page - browser.get_current_page() is the correct API
    page = await browser.get_current_page()

    if page is None:
        pytest.fail("browser.get_current_page() returned None after new_page()")

    logger.info(f"✓ Got page: {type(page)}")

    # Test page.screenshot() - this is what we want to validate
    # Note: browser-use returns base64-encoded string, not bytes!
    assert page is not None  # Type assertion for mypy
    screenshot_data = await asyncio.wait_for(
        page.screenshot(format="png"), timeout=10.0
    )

    # Verify screenshot was captured
    assert screenshot_data is not None, "Screenshot data should not be None"
    assert isinstance(screenshot_data, str), "Screenshot should be base64 string"
    assert len(screenshot_data) > 0, "Screenshot data should not be empty"

    # Decode base64 to verify it's valid PNG
    screenshot_bytes = base64.b64decode(screenshot_data)
    assert screenshot_bytes[:8] == b"\x89PNG\r\n\x1a\n", (
        "Screenshot should be valid PNG format"
    )
    logger.info(
        f"✓ Screenshot captured: {len(screenshot_data)} chars base64, "
        f"{len(screenshot_bytes)} bytes decoded"
    )

    # Clean shutdown using browser.stop() instead of browser.close()
    try:
        await asyncio.wait_for(browser.stop(), timeout=5.0)
        logger.info("✓ Browser stopped cleanly")
    except TimeoutError:
        logger.warning("Browser stop timed out, but test passed")
    except Exception as e:
        logger.warning(f"Error stopping browser: {e}, but test passed")
