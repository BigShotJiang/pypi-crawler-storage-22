"""Comprehensive tests for ChatRunner agent."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agents.chat_runner import ChatRunner
from constants import SUMMARY_FILENAME
from models.conversation_turn import ConversationTurn


class TestChatRunnerInitialization:
    """Tests for ChatRunner initialization."""

    def test_init_with_defaults(self) -> None:
        """Test initialization with default parameters."""
        runner = ChatRunner()
        assert runner.headless is False

    def test_init_with_custom_params(self) -> None:
        """Test initialization with custom parameters."""
        runner = ChatRunner(headless=True)
        assert runner.headless is True


class TestNormalizeMaxTurns:
    """Tests for _normalize_max_turns static method."""

    def test_valid_positive_integer(self) -> None:
        """Test with valid positive integer."""
        assert ChatRunner._normalize_max_turns(10) == 10
        assert ChatRunner._normalize_max_turns(1) == 1
        assert ChatRunner._normalize_max_turns(100) == 100

    def test_string_conversion(self) -> None:
        """Test conversion from string to integer."""
        assert ChatRunner._normalize_max_turns("5") == 5
        assert ChatRunner._normalize_max_turns("42") == 42

    def test_zero_or_negative_values(self) -> None:
        """Test that zero and negative values are forced to 1."""
        assert ChatRunner._normalize_max_turns(0) == 1
        assert ChatRunner._normalize_max_turns(-5) == 1
        assert ChatRunner._normalize_max_turns(-100) == 1

    def test_invalid_string(self) -> None:
        """Test that invalid string returns default."""
        assert ChatRunner._normalize_max_turns("invalid") == 10
        assert ChatRunner._normalize_max_turns("abc") == 10

    def test_none_value(self) -> None:
        """Test that None returns default."""
        assert ChatRunner._normalize_max_turns(None) == 10

    def test_custom_default(self) -> None:
        """Test with custom default value."""
        assert ChatRunner._normalize_max_turns("invalid", default=5) == 5
        assert ChatRunner._normalize_max_turns(None, default=20) == 20


class TestExtractTranscriptFromHistory:
    """Tests for _extract_transcript_from_history method."""

    def test_extract_basic_input_actions(self) -> None:
        """Test extracting user messages from input actions."""
        runner = ChatRunner()

        history = [
            {
                "action": {"name": "input", "text": "Hello, how are you?"},
                "result": {"text": "Navigated"},  # Will be skipped
            },
            {
                "action": {"name": "input", "text": "What is your purpose?"},
                "result": {"text": "Navigated"},  # Will be skipped
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        user_messages = [t for t in transcript if t.role == "user"]
        assert len(user_messages) == 2
        assert user_messages[0].text == "Hello, how are you?"
        assert user_messages[1].text == "What is your purpose?"

    def test_extract_with_responses(self) -> None:
        """Test extracting both user messages and bot responses."""
        runner = ChatRunner()

        history = [
            {
                "action": {"name": "input", "text": "Hello"},
                "result": {"text": "Typed"},  # Will be skipped (navigation message)
            },
            {
                "action": {"name": "extract"},
                "result": {
                    "text": "Hi there! How can I help you today?"
                },  # Long enough to be included
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        user_messages = [t for t in transcript if t.role == "user"]
        assistant_messages = [t for t in transcript if t.role == "assistant"]

        assert len(user_messages) == 1
        assert len(assistant_messages) == 1
        assert "help you" in assistant_messages[0].text

    def test_filter_short_messages(self) -> None:
        """Test that very short messages are filtered."""
        runner = ChatRunner()

        history = [
            {
                "action": {"name": "input", "text": "Hi"},  # Too short
                "result": {"text": "Sent"},
            },
            {
                "action": {"name": "input", "text": "Hello there!"},  # Long enough
                "result": {"text": "Sent"},
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        assert len(transcript) == 1
        assert transcript[0].text == "Hello there!"

    def test_filter_duplicate_messages(self) -> None:
        """Test that duplicate consecutive messages are filtered."""
        runner = ChatRunner()

        history = [
            {
                "action": {"name": "input", "text": "Hello there"},
                "result": {"text": "Sent"},
            },
            {
                "action": {"name": "input", "text": "Hello there"},  # Duplicate
                "result": {"text": "Sent"},
            },
            {
                "action": {"name": "input", "text": "Different message"},
                "result": {"text": "Sent"},
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        assert len(transcript) == 2
        assert transcript[0].text == "Hello there"
        assert transcript[1].text == "Different message"

    def test_handle_send_message_action(self) -> None:
        """Test extraction of send_message tool calls."""
        runner = ChatRunner()

        history = [
            {
                "action": {"name": "send_message", "message": "Test message"},
                "result": {"text": "Sent"},
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        assert len(transcript) == 1
        assert transcript[0].role == "user"
        assert transcript[0].text == "Test message"

    def test_skip_navigation_results(self) -> None:
        """Test that navigation/system messages are skipped."""
        runner = ChatRunner()

        history = [
            {
                "action": {"name": "navigate"},
                "result": {"text": "Navigated to homepage"},
            },
            {
                "action": {"name": "click"},
                "result": {"text": "Clicked button"},
            },
            {
                "action": {"name": "input", "text": "Real message"},
                "result": {"text": "Sent"},
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        # Only the actual user message should be extracted
        user_messages = [t for t in transcript if t.role == "user"]
        assert len(user_messages) == 1
        assert user_messages[0].text == "Real message"

    def test_handle_empty_history(self) -> None:
        """Test extraction from empty history."""
        runner = ChatRunner()
        transcript = runner._extract_transcript_from_history([])
        assert len(transcript) == 0

    def test_handle_malformed_history_items(self) -> None:
        """Test handling of malformed history items."""
        runner = ChatRunner()

        history = [
            {},  # Empty dict
            {"action": {}},  # Missing result
            {"result": {}},  # Missing action
            {
                "action": {"name": "input", "text": "Valid message"},
                "result": {"text": "Sent"},
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        # Only the valid item should be extracted
        assert len(transcript) == 1
        assert transcript[0].text == "Valid message"

    def test_extract_fast_type_and_submit_action(self) -> None:
        """Test extraction of fast_type_and_submit actions (browser-use format)."""
        runner = ChatRunner()

        history = [
            {
                "model_output": {
                    "action": [
                        {
                            "fast_type_and_submit": {
                                "selector": "textarea",
                                "text": "This is a fast typed message",
                                "press_enter": True,
                            }
                        }
                    ]
                },
                "result": [{"extracted_content": "Message sent"}],
            },
            {
                "model_output": {
                    "action": [
                        {
                            "fast_type_and_submit": {
                                "selector": "input",
                                "text": "Another fast typed message",
                                "press_enter": False,
                            }
                        }
                    ]
                },
                "result": [{"extracted_content": "Message sent"}],
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        # Both fast_type_and_submit messages should be extracted
        assert len(transcript) == 2
        assert transcript[0].role == "user"
        assert transcript[0].text == "This is a fast typed message"
        assert transcript[1].role == "user"
        assert transcript[1].text == "Another fast typed message"

    def test_fast_type_and_submit_deduplication(self) -> None:
        """Test that duplicate fast_type_and_submit messages are deduplicated."""
        runner = ChatRunner()

        history = [
            {
                "model_output": {
                    "action": [
                        {
                            "fast_type_and_submit": {
                                "selector": "textarea",
                                "text": "Duplicate message",
                                "press_enter": True,
                            }
                        }
                    ]
                },
                "result": [{"extracted_content": "Sent"}],
            },
            {
                "model_output": {
                    "action": [
                        {
                            "fast_type_and_submit": {
                                "selector": "textarea",
                                "text": "Duplicate message",
                                "press_enter": True,
                            }
                        }
                    ]
                },
                "result": [{"extracted_content": "Sent"}],
            },
        ]

        transcript = runner._extract_transcript_from_history(history)

        # Only one message should be extracted due to deduplication
        assert len(transcript) == 1
        assert transcript[0].text == "Duplicate message"


class TestGenerateSummary:
    """Tests for _generate_summary method."""

    @pytest.mark.asyncio
    async def test_generate_summary_with_persona(self, tmp_path: Path) -> None:
        """Test generating summary with persona analysis."""
        runner = ChatRunner()

        transcript = [
            ConversationTurn(role="user", text="Hello"),
            ConversationTurn(role="assistant", text="Hi there!"),
        ]

        mock_llm = AsyncMock()
        mock_response = MagicMock()
        # Return valid JSON format as expected by the code
        mock_response.completion = """{
            "summary": "Test analysis content",
            "findings": [],
            "recommendations": []
        }"""
        mock_llm.ainvoke.return_value = mock_response

        # Patch in the module where create_chat_model is actually called
        with patch(
            "utils.persona_summary_generator.create_chat_model", return_value=mock_llm
        ):
            await runner._generate_summary(
                output_dir=str(tmp_path),
                persona_id="malicious_user",
                persona_description="Test persona description",
                transcript=transcript,
                final_url="https://example.com",
            )

        summary_file = tmp_path / SUMMARY_FILENAME
        assert summary_file.exists()
        content = summary_file.read_text()
        assert "malicious_user" in content
        assert "analysis" in content.lower()

    @pytest.mark.asyncio
    async def test_generate_basic_summary(self, tmp_path: Path) -> None:
        """Test generating basic summary without persona."""
        runner = ChatRunner()

        transcript = [
            ConversationTurn(role="user", text="Hello"),
            ConversationTurn(role="assistant", text="Hi there!"),
            ConversationTurn(role="user", text="How are you?"),
            ConversationTurn(role="assistant", text="I am doing well!"),
        ]

        await runner._generate_basic_summary(
            output_dir=str(tmp_path),
            transcript=transcript,
            final_url="https://example.com",
        )

        summary_file = tmp_path / "summary.md"
        assert summary_file.exists()
        content = summary_file.read_text()
        assert "Conversation Summary" in content
        assert "https://example.com" in content
        # Note: File uses "**Total Turns**:" not "Total Turns:"
        assert "Total Turns" in content or "Total Messages: 4" in content

    @pytest.mark.asyncio
    async def test_summary_handles_exception(self, tmp_path: Path) -> None:
        """Test that summary generation logs and re-raises exceptions."""
        runner = ChatRunner()

        transcript = [
            ConversationTurn(role="user", text="Test"),
        ]

        mock_llm = AsyncMock()
        mock_llm.ainvoke.side_effect = Exception("API error")

        # Patch in the module where create_chat_model is actually called
        with patch(
            "utils.persona_summary_generator.create_chat_model", return_value=mock_llm
        ):
            # Should log error and re-raise
            with pytest.raises(Exception, match="API error"):
                await runner._generate_summary(
                    output_dir=str(tmp_path),
                    persona_id="test",
                    persona_description="desc",
                    transcript=transcript,
                    final_url="https://example.com",
                )


class TestLoadBindingsFromCode:
    """Tests for _load_bindings_from_code method."""

    @pytest.mark.asyncio
    async def test_load_valid_code(self) -> None:
        """Test loading valid Python code with required functions."""
        runner = ChatRunner()

        code = '''
async def input_text(page, text: str) -> None:
    """Send text to input field."""
    pass

async def await_text_output(page, opts: dict = None) -> str:
    """Wait for and extract bot response."""
    return "Mock response"
'''

        input_fn, output_fn = await runner._load_bindings_from_code(code)

        assert callable(input_fn)
        assert callable(output_fn)

        # Test that the function actually works
        result = await output_fn(None)
        assert result == "Mock response"

    @pytest.mark.asyncio
    async def test_load_code_with_imports(self) -> None:
        """Test loading code that includes imports."""
        runner = ChatRunner()

        code = """
import json

async def input_text(page, text: str) -> None:
    data = json.dumps({"message": text})
    pass

async def await_text_output(page, opts: dict = None) -> str:
    return "Response"
"""

        input_fn, output_fn = await runner._load_bindings_from_code(code)

        assert callable(input_fn)
        assert callable(output_fn)


def _mock_orchestrator():
    """Create a mock ConversationOrchestrator for tests."""
    mock_orch = MagicMock()
    mock_orch.run = AsyncMock(return_value={"success": True})
    mock_orch.transcript = []
    mock_orch.turn_count = 0
    mock_orch.ground_truth_data = []
    mock_orch.chatbot_terminated = False
    mock_orch.user_stopped = False
    mock_orch.timed_out = False
    mock_orch.cumulative_usage = {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "total_cost": 0.0,
    }
    return mock_orch


def _run_conversation_patches(mock_orch_instance=None):
    """Context manager stack for mocking run_conversation dependencies."""
    from contextlib import contextmanager

    @contextmanager
    def _patches():
        mock_browser = AsyncMock()
        orch = mock_orch_instance or _mock_orchestrator()

        with (
            patch(
                "agents.chat_runner.runner.create_browser",
                return_value=mock_browser,
            ),
            patch(
                "agents.chat_runner.conversation_orchestrator.ConversationOrchestrator",
                return_value=orch,
            ) as MockOrchClass,
            patch("agents.chat_runner.runner.create_chat_model"),
            patch("agents.chat_runner.runner.move_run_video"),
            patch(
                "agents.chat_runner.runner.get_config_summary",
                return_value={"persona": "test"},
            ),
        ):
            yield {
                "browser": mock_browser,
                "orchestrator": orch,
                "orchestrator_class": MockOrchClass,
            }

    return _patches()


class TestRunConversationIntegration:
    """Integration tests for run_conversation method."""

    @pytest.mark.asyncio
    async def test_run_conversation_basic(self, tmp_path: Path) -> None:
        """Test basic conversation run."""
        runner = ChatRunner(headless=True)

        with _run_conversation_patches():
            result = await runner.run_conversation(
                target_url="https://example.com",
                seed_utterance="Hello",
                max_turns=5,
                output_dir=str(tmp_path),
            )

        assert result["target_url"] == "https://example.com"
        assert "transcript" in result
        assert "total_turns" in result
        assert "finish_reason" in result

    @pytest.mark.asyncio
    async def test_run_conversation_with_arato_logging(self, tmp_path: Path) -> None:
        """Test conversation with Arato logging enabled."""
        runner = ChatRunner(headless=True)

        with _run_conversation_patches():
            with patch("agents.chat_runner.runner.AratoLogsAPI") as mock_arato:
                await runner.run_conversation(
                    target_url="https://example.com",
                    arato_api_url="https://api.arato.ai/test/log",
                    arato_api_key="test-key",
                    output_dir=str(tmp_path),
                )

                # Verify Arato client was created
                mock_arato.assert_called_once_with(
                    api_url="https://api.arato.ai/test/log",
                    api_key="test-key",
                )

    def test_format_intervention_response(self) -> None:
        """Test that _format_intervention_response formats intervention results correctly."""
        intervention_result = {
            "success": True,
            "state": "completed",
            "learning_summary": "Human completed the login successfully",
            "url_before": "https://example.com/login",
            "url_after": "https://example.com/dashboard",
            "duration_seconds": 30.5,
        }

        formatted_result = ChatRunner._format_intervention_response(
            intervention_result, reason="Need to solve CAPTCHA"
        )

        assert "✅ Human successfully completed the intervention!" in formatted_result
        assert "Reason: Need to solve CAPTCHA" in formatted_result
        assert "You can now continue with your task" in formatted_result


class TestHITLTimeoutRecovery:
    """Tests for HITL timeout recovery behavior with configuration control."""

    @pytest.mark.asyncio
    async def test_hitl_timeout_default_behavior_uses_constants(self) -> None:
        """Test that the default HITL timeout behavior uses the configured constants."""
        # Verify that constants are defined with expected default values
        from constants import HITL_RECOVERY_ENABLED, HITL_RECOVERY_STRATEGY

        assert HITL_RECOVERY_ENABLED is True, (
            "HITL_RECOVERY_ENABLED should default to True"
        )
        assert HITL_RECOVERY_STRATEGY == "continue", (
            "HITL_RECOVERY_STRATEGY should default to 'continue'"
        )

    @pytest.mark.asyncio
    async def test_hitl_timeout_returns_recovery_instructions(self) -> None:
        """Test that HITL timeout provides recovery instructions to agent."""
        # Create timeout result
        timeout_result = {
            "success": False,
            "state": "timeout",
            "message": "Intervention timed out",
            "learning_summary": "Timeout occurred",
        }

        # Use the actual implementation
        result = ChatRunner._format_intervention_response(
            timeout_result, reason="Need to solve CAPTCHA"
        )

        # Verify timeout recovery message is returned
        assert "⏱️  Human intervention timed out" in result
        assert "🔄 RECOVERY STRATEGY (continue):" in result
        assert "Try to continue with the task" in result
        assert "Look for alternative paths" in result
        assert "Document the issue in your summary" in result

    @pytest.mark.asyncio
    async def test_hitl_success_returns_success_message(self) -> None:
        """Test that HITL success returns success message."""
        # Create success result
        success_result = {
            "success": True,
            "state": "completed",
            "learning_summary": "Task completed successfully",
        }

        # Use the actual implementation
        result = ChatRunner._format_intervention_response(
            success_result, reason="Need to solve CAPTCHA"
        )

        # Verify success message
        assert "✅ Human successfully completed the intervention!" in result
        assert "You can now continue with your task" in result

    @pytest.mark.asyncio
    async def test_hitl_error_returns_error_message(self) -> None:
        """Test that HITL error returns error message."""
        # Create error result
        error_result = {
            "success": False,
            "state": "error",
            "message": "Network connection failed",
        }

        # Use the actual implementation
        result = ChatRunner._format_intervention_response(
            error_result, reason="Need to complete login"
        )

        # Verify error message
        assert "❌ Human intervention failed." in result
        assert "Network connection failed" in result
        assert "You may need to try a different approach" in result

    @pytest.mark.asyncio
    async def test_hitl_timeout_with_skip_strategy(self) -> None:
        """Test that HITL timeout with 'skip' strategy provides skip instructions."""
        import agents.chat_runner.runner as chat_runner_module

        # Patch the constant in the chat_runner module
        with patch.object(chat_runner_module, "HITL_RECOVERY_STRATEGY", "skip"):
            timeout_result = {
                "success": False,
                "state": "timeout",
                "message": "Intervention timed out",
            }

            result = ChatRunner._format_intervention_response(
                timeout_result, reason="Need to solve CAPTCHA"
            )

            # Verify skip strategy message
            assert "⏱️  Human intervention timed out" in result
            assert "🔄 RECOVERY STRATEGY (skip):" in result
            assert "Skip the blocked task entirely" in result
            assert "Document the blocker in your summary" in result
            assert "Focus on testing other features" in result

    @pytest.mark.asyncio
    async def test_hitl_timeout_with_recovery_disabled(self) -> None:
        """Test that HITL timeout with recovery disabled stops the agent."""
        import agents.chat_runner.runner as chat_runner_module

        # Patch the recovery enabled constant
        with patch.object(chat_runner_module, "HITL_RECOVERY_ENABLED", False):
            timeout_result = {
                "success": False,
                "state": "timeout",
                "message": "Intervention timed out",
            }

            result = ChatRunner._format_intervention_response(
                timeout_result, reason="Need to solve CAPTCHA"
            )

            # Verify disabled recovery message
            assert "⏱️  Human intervention timed out" in result
            assert "Recovery is disabled. You must stop and cannot continue." in result
            # Should NOT contain recovery instructions
            assert "RECOVERY STRATEGY" not in result


class TestBroadcastIdentity:
    """Tests for broadcast_identity feature."""

    @pytest.mark.asyncio
    async def test_broadcast_identity_with_task_id(self, tmp_path: Path) -> None:
        """Test that broadcast_identity=True with task_id passes params to orchestrator."""
        runner = ChatRunner(headless=True)

        with _run_conversation_patches() as mocks:
            result = await runner.run_conversation(
                target_url="https://example.com",
                output_dir=str(tmp_path),
                max_turns=3,
                broadcast_identity=True,
                task_id="test_task_123",
                persona_instance="malicious_user_01",
            )

            # Verify orchestrator was created with broadcast_identity params
            MockOrchClass = mocks["orchestrator_class"]
            assert MockOrchClass.called
            call_kwargs = MockOrchClass.call_args[1]
            assert call_kwargs["broadcast_identity"] is True
            assert call_kwargs["task_id"] == "test_task_123"

        assert result["target_url"] == "https://example.com"

    @pytest.mark.asyncio
    async def test_broadcast_identity_without_task_id(self, tmp_path: Path) -> None:
        """Test that broadcast_identity=True without task_id still passes to orchestrator."""
        runner = ChatRunner(headless=True)

        with _run_conversation_patches() as mocks:
            result = await runner.run_conversation(
                target_url="https://example.com",
                output_dir=str(tmp_path),
                max_turns=3,
                broadcast_identity=True,
                task_id=None,
            )

            # Verify orchestrator was created with broadcast_identity=True, task_id=None
            MockOrchClass = mocks["orchestrator_class"]
            call_kwargs = MockOrchClass.call_args[1]
            assert call_kwargs["broadcast_identity"] is True
            assert call_kwargs["task_id"] is None

        assert result["target_url"] == "https://example.com"

    @pytest.mark.asyncio
    async def test_broadcast_identity_false_no_instruction(
        self, tmp_path: Path
    ) -> None:
        """Test that broadcast_identity=False passes False to orchestrator."""
        runner = ChatRunner(headless=True)

        with _run_conversation_patches() as mocks:
            result = await runner.run_conversation(
                target_url="https://example.com",
                output_dir=str(tmp_path),
                max_turns=3,
                broadcast_identity=False,
                task_id="test_task_123",
                persona_instance="malicious_user_01",
            )

            # Verify orchestrator was created with broadcast_identity=False
            MockOrchClass = mocks["orchestrator_class"]
            call_kwargs = MockOrchClass.call_args[1]
            assert call_kwargs["broadcast_identity"] is False

        assert result["target_url"] == "https://example.com"
