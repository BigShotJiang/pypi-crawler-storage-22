"""Tests for ConversationTurn model."""

from models.conversation_turn import ConversationTurn


class TestConversationTurn:
    """Tests for ConversationTurn dataclass."""

    def test_create_user_turn(self) -> None:
        """Test creating a user conversation turn."""
        turn = ConversationTurn(role="user", text="Hello, how are you?")
        assert turn.role == "user"
        assert turn.text == "Hello, how are you?"

    def test_create_assistant_turn(self) -> None:
        """Test creating an assistant conversation turn."""
        turn = ConversationTurn(role="assistant", text="I am doing well, thank you!")
        assert turn.role == "assistant"
        assert turn.text == "I am doing well, thank you!"

    def test_equality(self) -> None:
        """Test that two identical turns are equal."""
        turn1 = ConversationTurn(role="user", text="Hello", id="123")
        turn2 = ConversationTurn(role="user", text="Hello", id="123")
        assert turn1 == turn2

    def test_inequality_different_role(self) -> None:
        """Test that turns with different roles are not equal."""
        turn1 = ConversationTurn(role="user", text="Hello", id="123")
        turn2 = ConversationTurn(role="assistant", text="Hello", id="123")
        assert turn1 != turn2

    def test_inequality_different_text(self) -> None:
        """Test that turns with different text are not equal."""
        turn1 = ConversationTurn(role="user", text="Hello", id="123")
        turn2 = ConversationTurn(role="user", text="Hi", id="123")
        assert turn1 != turn2

    def test_string_representation(self) -> None:
        """Test string representation includes role and text."""
        turn = ConversationTurn(role="user", text="Test message")
        str_repr = str(turn)
        assert "user" in str_repr
        assert "Test message" in str_repr

    def test_empty_text(self) -> None:
        """Test creating turn with empty text."""
        turn = ConversationTurn(role="user", text="")
        assert turn.role == "user"
        assert turn.text == ""

    def test_multiline_text(self) -> None:
        """Test creating turn with multiline text."""
        multiline = "Line 1\nLine 2\nLine 3"
        turn = ConversationTurn(role="assistant", text=multiline)
        assert turn.text == multiline
        assert "\n" in turn.text

    def test_special_characters(self) -> None:
        """Test creating turn with special characters."""
        special = "Hello! @#$%^&*() \"quotes\" 'apostrophe' 中文"
        turn = ConversationTurn(role="user", text=special)
        assert turn.text == special
