"""Test copy_discovery_artifacts functionality."""

import tempfile
from pathlib import Path

from utils import copy_discovery_artifacts


def test_copy_discovery_artifacts() -> None:
    """Test that discovery artifacts are copied from domain to session folder."""
    with tempfile.TemporaryDirectory() as domain_dir_str:
        with tempfile.TemporaryDirectory() as session_dir_str:
            domain_dir = Path(domain_dir_str)
            session_dir = Path(session_dir_str)

            # Create test artifacts in domain dir
            (domain_dir / "app_context.json").write_text('{"test": "data"}')
            (domain_dir / "discovery.mp4").write_text("video content")
            screenshots_dir = domain_dir / "screenshots"
            screenshots_dir.mkdir()
            (screenshots_dir / "test1.png").write_text("image1")
            (screenshots_dir / "test2.png").write_text("image2")

            # Copy artifacts
            results = copy_discovery_artifacts(domain_dir, session_dir)

            # Verify results
            assert results["app_context"] is True
            assert results["discovery_video"] is True
            assert results["screenshots"] is True

            # Verify files exist in session directory under domain_settings subfolder
            domain_name = domain_dir.name
            assert (
                session_dir / "domain_settings" / domain_name / "app_context.json"
            ).exists()
            assert (
                session_dir / "domain_settings" / domain_name / "discovery.mp4"
            ).exists()
            assert (
                session_dir
                / "domain_settings"
                / domain_name
                / "screenshots"
                / "test1.png"
            ).exists()
            assert (
                session_dir
                / "domain_settings"
                / domain_name
                / "screenshots"
                / "test2.png"
            ).exists()

            # Verify content is preserved
            assert (
                session_dir / "domain_settings" / domain_name / "app_context.json"
            ).read_text() == '{"test": "data"}'
            assert (
                session_dir / "domain_settings" / domain_name / "discovery.mp4"
            ).read_text() == "video content"


def test_copy_discovery_artifacts_partial() -> None:
    """Test copying when only some artifacts exist."""
    with tempfile.TemporaryDirectory() as domain_dir_str:
        with tempfile.TemporaryDirectory() as session_dir_str:
            domain_dir = Path(domain_dir_str)
            session_dir = Path(session_dir_str)

            # Create only app_context
            (domain_dir / "app_context.json").write_text('{"test": "data"}')

            # Copy artifacts
            results = copy_discovery_artifacts(domain_dir, session_dir)

            # Verify results
            assert results["app_context"] is True
            assert results["discovery_video"] is False
            assert results["screenshots"] is False

            # Verify only app_context exists in domain_settings subfolder
            domain_name = domain_dir.name
            assert (
                session_dir / "domain_settings" / domain_name / "app_context.json"
            ).exists()
            assert not (
                session_dir / "domain_settings" / domain_name / "discovery.mp4"
            ).exists()
            assert not (
                session_dir / "domain_settings" / domain_name / "screenshots"
            ).exists()


def test_copy_discovery_artifacts_empty() -> None:
    """Test copying when no artifacts exist."""
    with tempfile.TemporaryDirectory() as domain_dir_str:
        with tempfile.TemporaryDirectory() as session_dir_str:
            domain_dir = Path(domain_dir_str)
            session_dir = Path(session_dir_str)

            # No artifacts created

            # Copy artifacts
            results = copy_discovery_artifacts(domain_dir, session_dir)

            # Verify all results are False
            assert results["app_context"] is False
            assert results["discovery_video"] is False
            assert results["screenshots"] is False
