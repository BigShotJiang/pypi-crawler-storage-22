"""Integration tests for HITL end-to-end flows."""

import asyncio
from typing import Any
from unittest.mock import AsyncMock, Mock, patch

import pytest

from tools.hitl_intervention import request_human_intervention
from utils.hitl_utils import HITLState


@pytest.mark.asyncio
class TestHITLIntegrationFlows:
    """Test end-to-end HITL integration flows."""

    async def test_agent_requests_intervention_successfully(self) -> None:
        """Test complete flow: agent requests intervention, waits, resumes."""
        # Mock browser manager
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="integration-test-1"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "integration-test-1",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            # Agent requests intervention
            result = await request_human_intervention(
                reason="Integration test captcha", intervention_type="captcha"
            )

            # Verify successful flow
            assert result["success"] is True
            assert result["intervention_id"] == "integration-test-1"
            assert result["state"] == HITLState.COMPLETED.value

            # Verify browser manager was called correctly
            mock_browser_manager.request_intervention.assert_called_once()
            mock_browser_manager.wait_for_intervention_completion.assert_called_once()

    async def test_agent_handles_intervention_timeout(self) -> None:
        """Test complete flow when intervention times out."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="integration-timeout"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=TimeoutError("Timeout occurred")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Integration test timeout",
                intervention_type="login",
                timeout_seconds=30,
            )

            # Verify timeout handling
            assert result["success"] is False
            assert result["state"] == HITLState.TIMEOUT.value
            assert "error" in result
            assert mock_browser_manager.wait_for_intervention_completion.call_count == 1

    async def test_multiple_sequential_interventions(self) -> None:
        """Test multiple interventions in sequence (e.g., login then captcha)."""
        mock_browser_manager = Mock()

        # Setup different responses for each call
        intervention_ids = ["seq-1", "seq-2", "seq-3"]
        mock_browser_manager.request_intervention = AsyncMock(
            side_effect=intervention_ids
        )

        # All complete successfully
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=[
                {"state": HITLState.COMPLETED.value, "intervention_id": "seq-1"},
                {"state": HITLState.COMPLETED.value, "intervention_id": "seq-2"},
                {"state": HITLState.COMPLETED.value, "intervention_id": "seq-3"},
            ]
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            # First intervention: login
            result1 = await request_human_intervention(
                reason="Login form", intervention_type="login"
            )
            assert result1["success"] is True
            assert result1["intervention_id"] == "seq-1"

            # Second intervention: captcha
            result2 = await request_human_intervention(
                reason="Solve captcha", intervention_type="captcha"
            )
            assert result2["success"] is True
            assert result2["intervention_id"] == "seq-2"

            # Third intervention: consent
            result3 = await request_human_intervention(
                reason="Accept terms", intervention_type="consent"
            )
            assert result3["success"] is True
            assert result3["intervention_id"] == "seq-3"

            # Verify all were called
            assert mock_browser_manager.request_intervention.call_count == 3
            assert mock_browser_manager.wait_for_intervention_completion.call_count == 3

    async def test_intervention_with_custom_timeout(self) -> None:
        """Test intervention flow with custom timeout value."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="custom-timeout-id"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "custom-timeout-id",
            }
        )

        custom_timeout = 300  # 5 minutes

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Complex task",
                intervention_type="custom",
                timeout_seconds=custom_timeout,
            )

            assert result["success"] is True

            # Verify custom timeout was passed through
            assert mock_browser_manager.request_intervention.called
            mock_browser_manager.wait_for_intervention_completion.assert_called_once_with(
                intervention_id="custom-timeout-id", timeout_seconds=custom_timeout
            )

    async def test_local_platform_immediate_completion(self) -> None:
        """Test local platform behavior (no intervention ID returned)."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value=""
        )  # Empty ID

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Local platform test", intervention_type="captcha"
            )

            # Should succeed immediately without waiting
            assert result["success"] is True
            assert result["intervention_id"] == ""
            assert (
                "manual" in result["message"].lower()
                or "local" in result["message"].lower()
            )

            # Should NOT call wait_for_intervention_completion
            mock_browser_manager.wait_for_intervention_completion.assert_not_called()


@pytest.mark.asyncio
class TestHITLStateManagement:
    """Test HITL state management and transitions."""

    async def test_state_transition_pending_to_completed(self) -> None:
        """Test state transition from pending to completed."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="state-test-1"
        )

        # Simulate state progression
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "state-test-1",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="State test", intervention_type="captcha"
            )

            assert result["state"] == HITLState.COMPLETED.value
            assert result["success"] is True

    async def test_state_transition_pending_to_timeout(self) -> None:
        """Test state transition from pending to timeout."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="state-test-2"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=TimeoutError("Timeout")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Timeout test", intervention_type="login"
            )

            assert result["state"] == HITLState.TIMEOUT.value
            assert result["success"] is False

    async def test_state_transition_pending_to_error(self) -> None:
        """Test state transition from pending to error."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="state-test-3"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=RuntimeError("Error occurred")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Error test", intervention_type="verification"
            )

            assert result["state"] == HITLState.ERROR.value
            assert result["success"] is False


@pytest.mark.asyncio
class TestHITLErrorRecovery:
    """Test HITL error handling and recovery scenarios."""

    async def test_retry_after_timeout(self) -> None:
        """Test retrying intervention after timeout."""
        mock_browser_manager = Mock()

        # First attempt times out
        mock_browser_manager.request_intervention = AsyncMock(
            side_effect=["retry-test-1", "retry-test-2"]
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=[
                TimeoutError("First attempt timeout"),
                {"state": HITLState.COMPLETED.value, "intervention_id": "retry-test-2"},
            ]
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            # First attempt - timeout
            result1 = await request_human_intervention(
                reason="First try", intervention_type="captcha"
            )
            assert result1["success"] is False
            assert result1["state"] == HITLState.TIMEOUT.value

            # Second attempt - success
            result2 = await request_human_intervention(
                reason="Retry", intervention_type="captcha"
            )
            assert result2["success"] is True
            assert result2["state"] == HITLState.COMPLETED.value

    async def test_error_contains_useful_information(self) -> None:
        """Test that error results contain useful debugging information."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="error-info-test"
        )
        error_message = "Network connection lost"
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=RuntimeError(error_message)
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Error info test", intervention_type="login"
            )

            # Verify error information is preserved
            assert result["success"] is False
            assert "error" in result
            assert error_message in result["error"]
            assert result["intervention_id"] == "error-info-test"


@pytest.mark.asyncio
class TestHITLConcurrency:
    """Test concurrent HITL operations."""

    async def test_concurrent_interventions_from_different_agents(self) -> None:
        """Test multiple agents requesting interventions concurrently."""
        mock_browser_manager = Mock()

        async def mock_request(
            reason: Any,
            intervention_type: Any,  # noqa: ARG001
            timeout_seconds: Any,  # noqa: ARG001
            url_before: Any = None,  # noqa: ARG001
            screenshot_url: Any = None,  # noqa: ARG001
        ) -> str:
            await asyncio.sleep(0.05)
            # Return unique ID based on reason
            return f"concurrent-{reason}"

        async def mock_wait(
            intervention_id: Any,
            timeout_seconds: Any,  # noqa: ARG001
        ) -> dict[str, Any]:
            await asyncio.sleep(0.05)
            return {
                "state": HITLState.COMPLETED.value,
                "intervention_id": intervention_id,
            }

        mock_browser_manager.request_intervention = AsyncMock(side_effect=mock_request)
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=mock_wait
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            # Simulate 3 different agents requesting interventions
            tasks = [
                request_human_intervention(
                    reason=f"Agent {i}", intervention_type="captcha"
                )
                for i in range(3)
            ]

            results = await asyncio.gather(*tasks)

            # All should succeed
            assert len(results) == 3
            for i, result in enumerate(results):
                assert result["success"] is True
                assert result["intervention_id"] == f"concurrent-Agent {i}"

    async def test_intervention_queue_behavior(self) -> None:
        """Test that interventions are handled in order when queued."""
        mock_browser_manager = Mock()
        completed_order = []

        async def mock_request(
            reason: Any,
            intervention_type: Any,  # noqa: ARG001
            timeout_seconds: Any,  # noqa: ARG001
            url_before: Any = None,  # noqa: ARG001
            screenshot_url: Any = None,  # noqa: ARG001
        ) -> str:
            return f"queue-{reason}"

        async def mock_wait(
            intervention_id: Any,
            timeout_seconds: Any,  # noqa: ARG001
        ) -> dict[str, Any]:
            await asyncio.sleep(0.1)  # Simulate async operation
            completed_order.append(intervention_id)
            return {
                "state": HITLState.COMPLETED.value,
                "intervention_id": intervention_id,
            }

        mock_browser_manager.request_intervention = AsyncMock(side_effect=mock_request)
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=mock_wait
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            # Submit 3 interventions sequentially
            results = []
            for i in range(3):
                result = await request_human_intervention(
                    reason=f"{i}", intervention_type="captcha"
                )
                results.append(result)

            # All should succeed in order
            assert len(results) == 3
            assert all(r["success"] for r in results)
            assert completed_order == ["queue-0", "queue-1", "queue-2"]


@pytest.mark.asyncio
class TestHITLPlatformCompatibility:
    """Test HITL behavior across different platforms."""

    async def test_aws_platform_full_hitl_flow(self) -> None:
        """Test full HITL flow on AWS platform (with DCV)."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="aws-intervention-123"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "aws-intervention-123",
                "completed_at": "2024-01-01T12:00:00Z",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="AWS platform test", intervention_type="captcha"
            )

            assert result["success"] is True
            assert result["intervention_id"] == "aws-intervention-123"
            assert "completed_at" in result

    async def test_local_platform_interactive_mode(self) -> None:
        """Test HITL on local platform in interactive mode."""
        mock_browser_manager = Mock()
        # Local platform returns empty intervention ID for immediate handling
        mock_browser_manager.request_intervention = AsyncMock(return_value="")

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Local platform test", intervention_type="login"
            )

            # Should complete immediately without polling
            assert result["success"] is True
            assert result["intervention_id"] == ""
            mock_browser_manager.wait_for_intervention_completion.assert_not_called()

    async def test_platform_specific_timeout_handling(self) -> None:
        """Test that timeout handling works consistently across platforms."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="platform-timeout-test"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=TimeoutError("Platform-specific timeout")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Platform timeout test",
                intervention_type="captcha",
                timeout_seconds=60,
            )

            # Timeout handling should be consistent
            assert result["success"] is False
            assert result["state"] == HITLState.TIMEOUT.value
            assert "error" in result
