"""Tests for HITL intervention tool."""

import asyncio
from typing import Any
from unittest.mock import AsyncMock, Mock, patch

import pytest

from constants import HITL_DEFAULT_TIMEOUT_SECONDS
from tools.hitl_intervention import request_human_intervention
from utils.hitl_utils import HITLState


@pytest.mark.asyncio
class TestRequestHumanIntervention:
    """Test suite for request_human_intervention function."""

    async def test_successful_intervention(self) -> None:
        """Test successful human intervention completion."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-intervention-123"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "test-intervention-123",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test CAPTCHA", intervention_type="captcha"
            )

        assert result["success"] is True
        assert result["intervention_id"] == "test-intervention-123"
        assert result["state"] == HITLState.COMPLETED.value
        assert "intervention" in result["message"].lower()
        # Verify intervention was requested (check call happened, not exact args)
        assert mock_browser_manager.request_intervention.called
        mock_browser_manager.wait_for_intervention_completion.assert_called_once()

    async def test_intervention_timeout(self) -> None:
        """Test intervention timeout scenario."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-timeout-456"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=TimeoutError("Human did not complete intervention in time")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test login", intervention_type="login"
            )

        assert result["success"] is False
        assert result["intervention_id"] == "test-timeout-456"
        assert result["state"] == HITLState.TIMEOUT.value
        assert "timed out" in result["message"].lower()
        assert "error" in result

    async def test_intervention_runtime_error(self) -> None:
        """Test intervention runtime error handling."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-error-789"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=RuntimeError("Intervention encountered error")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test verification", intervention_type="verification"
            )

        assert result["success"] is False
        assert result["intervention_id"] == "test-error-789"
        assert result["state"] == HITLState.ERROR.value
        assert "error" in result["message"].lower()
        assert "error" in result

    async def test_empty_intervention_id(self) -> None:
        """Test handling of empty intervention ID (local non-interactive mode)."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(return_value="")

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test", intervention_type="custom"
            )

        assert result["success"] is True
        assert result["intervention_id"] == ""
        assert (
            "manual intervention" in result["message"].lower()
            or "local platform" in result["message"].lower()
        )
        # Should not call wait_for_intervention_completion when intervention_id is empty
        mock_browser_manager.wait_for_intervention_completion.assert_not_called()

    async def test_custom_timeout(self) -> None:
        """Test intervention with custom timeout value."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-custom-timeout"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "test-custom-timeout",
            }
        )

        custom_timeout = 300  # 5 minutes

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test with custom timeout",
                intervention_type="consent",
                timeout_seconds=custom_timeout,
            )

        assert result["success"] is True
        mock_browser_manager.wait_for_intervention_completion.assert_called_once_with(
            intervention_id="test-custom-timeout", timeout_seconds=custom_timeout
        )

    async def test_default_timeout(self) -> None:
        """Test intervention uses default timeout when not specified."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-default-timeout"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "test-default-timeout",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test default", intervention_type="captcha"
            )

        assert result["success"] is True
        mock_browser_manager.wait_for_intervention_completion.assert_called_once_with(
            intervention_id="test-default-timeout",
            timeout_seconds=HITL_DEFAULT_TIMEOUT_SECONDS,
        )

    async def test_all_intervention_types(self) -> None:
        """Test all supported intervention types."""
        intervention_types = ["captcha", "login", "verification", "consent", "custom"]

        for intervention_type in intervention_types:
            mock_browser_manager = Mock()
            mock_browser_manager.request_intervention = AsyncMock(
                return_value=f"test-{intervention_type}-id"
            )
            mock_browser_manager.wait_for_intervention_completion = AsyncMock(
                return_value={
                    "state": HITLState.COMPLETED.value,
                    "intervention_id": f"test-{intervention_type}-id",
                }
            )

            with patch(
                "tools.hitl_intervention.get_browser_manager",
                return_value=mock_browser_manager,
            ):
                result = await request_human_intervention(
                    reason=f"Test {intervention_type}",
                    intervention_type=intervention_type,
                )

            assert result["success"] is True
            assert result["intervention_id"] == f"test-{intervention_type}-id"
            # Verify intervention was requested
            assert mock_browser_manager.request_intervention.called

    async def test_generic_exception_handling(self) -> None:
        """Test handling of unexpected exceptions."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            side_effect=Exception("Unexpected error occurred")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test exception", intervention_type="custom"
            )

        assert result["success"] is False
        assert result["state"] == HITLState.ERROR.value
        assert "error" in result
        assert "unexpected error" in result["error"].lower()

    async def test_intervention_state_waiting(self) -> None:
        """Test intervention that returns waiting state (edge case)."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-waiting"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.WAITING.value,
                "intervention_id": "test-waiting",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            result = await request_human_intervention(
                reason="Test waiting", intervention_type="captcha"
            )

        # Should still return the state even if it's waiting
        assert result["intervention_id"] == "test-waiting"
        assert result["state"] == HITLState.WAITING.value

    async def test_concurrent_interventions(self) -> None:
        """Test multiple concurrent intervention requests."""
        mock_browser_manager = Mock()

        async def mock_request(
            reason: Any,
            intervention_type: Any,  # noqa: ARG001
            timeout_seconds: Any,  # noqa: ARG001
            url_before: Any = None,  # noqa: ARG001
            screenshot_url: Any = None,  # noqa: ARG001
        ) -> str:
            await asyncio.sleep(0.1)  # Simulate async operation
            return f"intervention-{reason}"

        async def mock_wait(
            intervention_id: Any,
            timeout_seconds: Any,  # noqa: ARG001
        ) -> dict[str, Any]:
            await asyncio.sleep(0.1)  # Simulate async operation
            return {
                "state": HITLState.COMPLETED.value,
                "intervention_id": intervention_id,
            }

        mock_browser_manager.request_intervention = AsyncMock(side_effect=mock_request)
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=mock_wait
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            # Run 3 interventions concurrently
            tasks = [
                request_human_intervention(
                    reason=f"Test {i}", intervention_type="captcha"
                )
                for i in range(3)
            ]
            results = await asyncio.gather(*tasks)

        assert len(results) == 3
        for i, result in enumerate(results):
            assert result["success"] is True
            assert result["intervention_id"] == f"intervention-Test {i}"


@pytest.mark.asyncio
class TestHITLLogging:
    """Test HITL intervention logging behavior."""

    async def test_logs_intervention_request(self, caplog: Any) -> None:
        """Test that intervention requests are logged."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-log-123"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "test-log-123",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            await request_human_intervention(
                reason="Test logging", intervention_type="captcha"
            )

        # Check that logging occurred (actual log format depends on implementation)
        assert any("test-log-123" in record.message for record in caplog.records)

    async def test_logs_intervention_success(self, caplog: Any) -> None:
        """Test that successful interventions are logged."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-success-log"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            return_value={
                "state": HITLState.COMPLETED.value,
                "intervention_id": "test-success-log",
            }
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            await request_human_intervention(
                reason="Test success", intervention_type="login"
            )

        # Verify success is logged
        assert any(
            HITLState.COMPLETED.value in record.message for record in caplog.records
        )

    async def test_logs_intervention_failure(self, caplog: Any) -> None:
        """Test that failed interventions are logged."""
        mock_browser_manager = Mock()
        mock_browser_manager.request_intervention = AsyncMock(
            return_value="test-fail-log"
        )
        mock_browser_manager.wait_for_intervention_completion = AsyncMock(
            side_effect=TimeoutError("Timeout occurred")
        )

        with patch(
            "tools.hitl_intervention.get_browser_manager",
            return_value=mock_browser_manager,
        ):
            await request_human_intervention(
                reason="Test failure", intervention_type="verification"
            )

        # Verify timeout/failure is logged
        assert any("timeout" in record.message.lower() for record in caplog.records)
