"""Tests for HITL service Flask endpoints.

This module tests the Flask API endpoints in hitl_service.py, focusing on the
newly added endpoints in the intervention-preview branch.
"""

from __future__ import annotations

import json
from collections.abc import Generator
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from botocore.exceptions import ClientError
from flask.testing import FlaskClient

# Import the Flask app
from hitl.hitl_service import app


@pytest.fixture
def client() -> Generator[FlaskClient, None, None]:
    """Create a Flask test client."""
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


class TestScreenshotEndpoint:
    """Tests for the /api/screenshots/<path> endpoint."""

    @patch("hitl.hitl_service.boto3.client")
    def test_get_screenshot_success(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test successful screenshot retrieval from S3."""
        # Mock S3 client and response
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        mock_body = MagicMock()
        mock_body.read.return_value = b"\x89PNG\r\n\x1a\n..."  # Fake PNG data
        mock_s3.get_object.return_value = {"Body": mock_body}

        # Test with s3:// prefix
        response = client.get("/api/screenshots/s3://my-bucket/screenshots/test.png")

        assert response.status_code == 200
        assert response.mimetype == "image/png"
        assert response.data == b"\x89PNG\r\n\x1a\n..."
        assert "Cache-Control" in response.headers
        assert "public, max-age=3600" in response.headers["Cache-Control"]

        # Verify S3 call
        mock_s3.get_object.assert_called_once_with(
            Bucket="my-bucket", Key="screenshots/test.png"
        )

    @patch("hitl.hitl_service.boto3.client")
    def test_get_screenshot_without_s3_prefix(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test screenshot retrieval without s3:// prefix."""
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        mock_body = MagicMock()
        mock_body.read.return_value = b"image_data"
        mock_s3.get_object.return_value = {"Body": mock_body}

        response = client.get("/api/screenshots/bucket-name/path/to/image.png")

        assert response.status_code == 200
        mock_s3.get_object.assert_called_once_with(
            Bucket="bucket-name", Key="path/to/image.png"
        )

    @patch("hitl.hitl_service.boto3.client")
    def test_get_screenshot_not_found(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test screenshot not found in S3 (NoSuchKey error)."""
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        # Create a proper ClientError
        error_response = {
            "Error": {
                "Code": "NoSuchKey",
                "Message": "The specified key does not exist.",
            }
        }
        mock_s3.get_object.side_effect = ClientError(error_response, "GetObject")

        response = client.get("/api/screenshots/my-bucket/missing.png")

        assert response.status_code == 404
        data = json.loads(response.data)
        assert data["error"] == "Screenshot not found"

    @patch("hitl.hitl_service.boto3.client")
    def test_get_screenshot_invalid_path_format(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test screenshot with invalid path format (missing bucket or key)."""
        response = client.get("/api/screenshots/invalid-path")

        assert response.status_code == 400
        data = json.loads(response.data)
        assert "Invalid screenshot path format" in data["error"]

    @patch("hitl.hitl_service.boto3.client")
    def test_get_screenshot_s3_error(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test handling of generic S3 errors."""
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        error_response = {"Error": {"Code": "AccessDenied", "Message": "Access denied"}}
        mock_s3.get_object.side_effect = ClientError(error_response, "GetObject")

        response = client.get("/api/screenshots/my-bucket/test.png")

        assert response.status_code == 500
        data = json.loads(response.data)
        assert "error" in data

    @patch("hitl.hitl_service.boto3.client")
    def test_get_screenshot_content_disposition_header(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test that Content-Disposition header includes filename."""
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        mock_body = MagicMock()
        mock_body.read.return_value = b"image"
        mock_s3.get_object.return_value = {"Body": mock_body}

        response = client.get("/api/screenshots/bucket/path/to/my-screenshot.png")

        assert response.status_code == 200
        assert "Content-Disposition" in response.headers
        assert "my-screenshot.png" in response.headers["Content-Disposition"]
        assert "inline" in response.headers["Content-Disposition"]


class TestHealthEndpoint:
    """Tests for the /health endpoint."""

    def test_health_check(self, client: FlaskClient) -> None:
        """Test health check endpoint returns OK."""
        response = client.get("/health")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["status"] == "ok"
        assert data["service"] == "hitl-service"


class TestValidateUrlEndpoint:
    """Tests for the /api/validate-url endpoint."""

    def test_validate_url_valid_https(self, client: FlaskClient) -> None:
        """Test validation of valid HTTPS URL."""
        response = client.post(
            "/api/validate-url", json={"url": "https://example.com/path"}
        )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["valid"] is True
        assert data["url"] == "https://example.com/path"

    def test_validate_url_valid_http(self, client: FlaskClient) -> None:
        """Test validation of valid HTTP URL."""
        response = client.post(
            "/api/validate-url", json={"url": "http://localhost:8080/viewer"}
        )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["valid"] is True

    def test_validate_url_invalid_scheme(self, client: FlaskClient) -> None:
        """Test validation rejects invalid URL schemes."""
        response = client.post("/api/validate-url", json={"url": "ftp://example.com"})

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["valid"] is False
        assert "http or https" in data["error"]

    def test_validate_url_missing_netloc(self, client: FlaskClient) -> None:
        """Test validation rejects URLs without host."""
        response = client.post("/api/validate-url", json={"url": "http://"})

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["valid"] is False
        assert "Invalid URL format" in data["error"]

    def test_validate_url_empty_string(self, client: FlaskClient) -> None:
        """Test validation of empty URL."""
        response = client.post("/api/validate-url", json={"url": ""})

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["valid"] is False

    def test_validate_url_missing_url_field(self, client: FlaskClient) -> None:
        """Test validation when URL field is missing."""
        response = client.post("/api/validate-url", json={})

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["valid"] is False


class TestBrowserSessionsEndpoint:
    """Tests for the /api/browser-sessions endpoint."""

    @patch("hitl.hitl_service.boto3.client")
    def test_list_browser_sessions_success(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test successful listing of browser sessions."""
        mock_bedrock = MagicMock()
        mock_boto_client.return_value = mock_bedrock

        mock_bedrock.list_browser_sessions.return_value = {
            "items": [
                {
                    "sessionId": "session-123",
                    "name": "Test Session",
                    "status": "READY",
                    "createdAt": "2025-11-09T10:00:00Z",
                    "browserIdentifier": "aws.browser.v1",
                }
            ]
        }

        response = client.get("/api/browser-sessions")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert "sessions" in data
        assert len(data["sessions"]) == 1
        assert data["sessions"][0]["session_id"] == "session-123"
        assert data["sessions"][0]["status"] == "READY"

    @patch("hitl.hitl_service.boto3.client")
    def test_list_browser_sessions_empty(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test listing when no sessions are available."""
        mock_bedrock = MagicMock()
        mock_boto_client.return_value = mock_bedrock

        mock_bedrock.list_browser_sessions.return_value = {"items": []}

        response = client.get("/api/browser-sessions")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["sessions"] == []

    @patch("hitl.hitl_service.boto3.client")
    def test_list_browser_sessions_client_error(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test handling of AWS client errors."""
        mock_bedrock = MagicMock()
        mock_boto_client.return_value = mock_bedrock

        error_response = {
            "Error": {"Code": "AccessDeniedException", "Message": "Access denied"}
        }
        mock_bedrock.list_browser_sessions.side_effect = ClientError(
            error_response, "ListBrowserSessions"
        )

        response = client.get("/api/browser-sessions")

        assert response.status_code == 500
        data = json.loads(response.data)
        assert "error" in data


class TestSessionStateEndpoint:
    """Tests for the /api/browser-sessions/<session_id>/state endpoint."""

    @patch("platforms.aws_agentcore.storage.S3StorageAdapter")
    @patch("hitl.hitl_service.boto3.client")
    def test_get_session_state_with_waiting_intervention(
        self,
        mock_boto_client: MagicMock,
        mock_storage_class: MagicMock,
        client: FlaskClient,
    ) -> None:
        """Test getting session state with active intervention."""
        # Mock storage adapter
        mock_storage = MagicMock()
        mock_storage._resolve_bucket_name.return_value = "test-bucket"
        mock_storage_class.return_value = mock_storage

        # Mock S3 client
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        # Mock S3 list response with intervention
        mock_s3.list_objects_v2.return_value = {
            "Contents": [
                {"Key": "hitl_interventions/session-123/intervention-456.json"}
            ]
        }

        # Mock intervention state
        intervention_state = {
            "state": "waiting",
            "agentcore_session_id": "agentcore-session-789",
            "intervention_id": "intervention-456",
            "intervention_type": "captcha",
            "reason": "CAPTCHA required",
            "requested_at": "2025-11-09T10:00:00Z",
            "timeout_seconds": 600,
            "screenshot_url": "s3://bucket/screenshot.png",
            "url_before": "https://example.com",
        }

        mock_body = MagicMock()
        mock_body.read.return_value = json.dumps(intervention_state).encode()
        mock_s3.get_object.return_value = {"Body": mock_body}

        response = client.get("/api/browser-sessions/agentcore-session-789/state")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["hitl_active"] is True
        assert data["hitl_state"] == "waiting"
        assert data["intervention_id"] == "intervention-456"
        assert data["intervention_reason"] == "CAPTCHA required"

    @patch("platforms.aws_agentcore.storage.S3StorageAdapter")
    @patch("hitl.hitl_service.boto3.client")
    def test_get_session_state_no_intervention(
        self,
        mock_boto_client: MagicMock,
        mock_storage_class: MagicMock,
        client: FlaskClient,
    ) -> None:
        """Test getting session state with no active intervention."""
        mock_storage = MagicMock()
        mock_storage._resolve_bucket_name.return_value = "test-bucket"
        mock_storage_class.return_value = mock_storage

        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        mock_s3.list_objects_v2.return_value = {"Contents": []}

        response = client.get("/api/browser-sessions/session-no-intervention/state")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["hitl_active"] is False
        assert data["hitl_state"] == "none"


class TestBrowserContextFunctions:
    """Tests for browser context management functions."""

    def test_set_and_get_browser_context(self) -> None:
        """Test setting and getting browser context."""
        from tools.hitl_intervention import get_browser_context, set_browser_context

        # Test with None
        set_browser_context(None)
        assert get_browser_context() is None

        # Test with mock browser
        mock_browser = MagicMock()
        set_browser_context(mock_browser)
        assert get_browser_context() == mock_browser

        # Test clearing
        set_browser_context(None)
        assert get_browser_context() is None


class TestScreenshotCapture:
    """Tests for screenshot capture with storage upload."""

    @patch("utils.screenshot_utils.get_storage_adapter")
    @patch("utils.screenshot_utils.get_browser_manager")
    async def test_screenshot_capture_and_upload(
        self, mock_get_manager: MagicMock, mock_get_storage: MagicMock
    ) -> None:
        """Test screenshot capture with upload to storage."""
        from utils.screenshot_utils import capture_and_upload_screenshot

        # Mock browser
        mock_browser = MagicMock()

        # Mock browser manager
        mock_manager = MagicMock()
        mock_manager.capture_screenshot = AsyncMock(
            return_value="aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFFPQo="
        )  # Valid base64
        mock_get_manager.return_value = mock_manager

        # Mock storage adapter
        mock_storage = MagicMock()
        mock_storage.upload_screenshot.return_value = "s3://bucket/screenshot.png"
        mock_get_storage.return_value = mock_storage

        # Test HITL screenshot upload
        result = await capture_and_upload_screenshot(
            browser=mock_browser,
            upload_type="hitl",
            session_id="test-session",
            intervention_id="test-intervention",
        )

        assert result == "s3://bucket/screenshot.png"
        assert mock_manager.capture_screenshot.called
        assert mock_storage.upload_screenshot.called

        # Verify screenshot was decoded from base64
        upload_call = mock_storage.upload_screenshot.call_args
        assert "screenshot_bytes" in upload_call.kwargs


class TestResumeSession:
    """Tests for the /api/browser-sessions/<session_id>/resume endpoint."""

    @patch("hitl.hitl_service.boto3.client")
    def test_resume_session_success(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test successful session resume when intervention is waiting."""
        # Mock S3 client
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        # Mock list_objects_v2 response with one waiting intervention
        intervention_data = {
            "state": "waiting",
            "intervention_id": "test-intervention-id",
            "session_id": "internal-session-id",
            "agentcore_session_id": "agentcore-session-123",
            "reason": "Test reason",
            "intervention_type": "custom",
            "requested_at": "2025-11-09T10:00:00+00:00",
            "timeout_seconds": 600,
            "platform": "aws_agentcore",
        }
        mock_s3.list_objects_v2.return_value = {
            "Contents": [
                {
                    "Key": "hitl_interventions/internal-session-id/test-intervention-id.json"
                }
            ]
        }

        # Mock get_object to return the intervention data
        mock_body = MagicMock()
        mock_body.read.return_value = json.dumps(intervention_data).encode("utf-8")
        mock_s3.get_object.return_value = {"Body": mock_body}

        # Mock put_object (for updating the intervention state)
        mock_s3.put_object.return_value = {}

        # Make request
        response = client.post("/api/browser-sessions/agentcore-session-123/resume")

        assert response.status_code == 200
        data = response.get_json()
        assert data["status"] == "resumed"
        assert data["session_id"] == "agentcore-session-123"
        assert data["intervention_id"] == "test-intervention-id"
        assert data["hitl_state"] == "completed"
        assert "resumed_at" in data

        # Verify S3 put_object was called to update the state
        assert mock_s3.put_object.called
        put_call = mock_s3.put_object.call_args
        updated_data = json.loads(put_call.kwargs["Body"])
        assert updated_data["state"] == "completed"
        assert "completed_at" in updated_data

    @patch("hitl.hitl_service.boto3.client")
    def test_resume_session_no_waiting_intervention(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test resume when no waiting intervention exists."""
        # Mock S3 client
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        # Mock list_objects_v2 with no interventions
        mock_s3.list_objects_v2.return_value = {"Contents": []}

        # Make request
        response = client.post("/api/browser-sessions/nonexistent-session/resume")

        assert response.status_code == 404
        data = response.get_json()
        assert "error" in data
        assert "No waiting intervention found" in data["error"]

    @patch("hitl.hitl_service.boto3.client")
    def test_resume_session_wrong_session_id(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test resume with wrong AgentCore session ID."""
        # Mock S3 client
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        # Mock list_objects_v2 response with intervention for different session
        intervention_data = {
            "state": "waiting",
            "intervention_id": "test-intervention-id",
            "session_id": "internal-session-id",
            "agentcore_session_id": "agentcore-session-456",  # Different session
            "reason": "Test reason",
        }
        mock_s3.list_objects_v2.return_value = {
            "Contents": [
                {
                    "Key": "hitl_interventions/internal-session-id/test-intervention-id.json"
                }
            ]
        }

        mock_body = MagicMock()
        mock_body.read.return_value = json.dumps(intervention_data).encode("utf-8")
        mock_s3.get_object.return_value = {"Body": mock_body}

        # Make request with wrong session ID
        response = client.post("/api/browser-sessions/agentcore-session-123/resume")

        assert response.status_code == 404
        data = response.get_json()
        assert "error" in data
        assert "No waiting intervention found" in data["error"]

    @patch("hitl.hitl_service.boto3.client")
    def test_resume_session_s3_error(
        self, mock_boto_client: MagicMock, client: FlaskClient
    ) -> None:
        """Test handling of S3 errors during session resume."""
        # Mock S3 client
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

        # Simulate S3 ClientError
        error_response = {"Error": {"Code": "AccessDenied", "Message": "Access denied"}}
        mock_s3.list_objects_v2.side_effect = ClientError(
            error_response, "ListObjectsV2"
        )

        # Make request
        response = client.post("/api/browser-sessions/agentcore-session-123/resume")

        assert response.status_code == 500
        data = response.get_json()
        assert "error" in data


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
