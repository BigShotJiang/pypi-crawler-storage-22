"""Integration tests for the Arato Agent platform.

These tests run end-to-end scenarios with REAL components to ensure
the system works correctly in realistic conditions.
"""

import json
import logging
import os
import subprocess
import sys
import time
import uuid
from collections.abc import Generator
from datetime import datetime
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
import requests

from constants import (
    REPORT_DATA_FILENAME,
    RUN_VIDEO_FILENAME,
    SUMMARY_FILENAME,
    TRANSCRIPT_FILENAME,
)
from platforms.local.adapter import LocalPlatformAdapter

# Test configuration constants
TEST_AUT_PORT = 5174
TEST_TARGET_URL = f"http://127.0.0.1:{TEST_AUT_PORT}"
TEST_PERSONA_IDS = ["nice"]  # Use only one persona to keep test fast
TEST_MAX_TURNS = 2  # 2 turns for richer artifacts while staying fast
TEST_SEED_UTTERANCE = "Hi"
TEST_AUT_DIR = Path(__file__).parent.parent / "integration_test_aut"
TEST_AUT_STARTUP_TIMEOUT = 30  # seconds
LOGGER = logging.getLogger(__name__)


@pytest.mark.integration
class TestIntegration:
    """Integration tests for the complete agent pipeline with REAL components."""

    @pytest.fixture
    def mock_arato_api(self) -> Generator[MagicMock, None, None]:
        """Mock AratoLogsAPI for testing logging functionality.

        This is the ONLY mock - we mock the external logging API to avoid
        dependencies on external services. Everything else runs for REAL.
        """
        with patch("tools.arato_logs_api.AratoLogsAPI") as mock_api_class:
            mock_instance = MagicMock()
            mock_api_class.return_value = mock_instance
            yield mock_instance

    @pytest.fixture
    def temp_storage_dir(self, tmp_path: Path) -> Path:
        """Temporary directory for test storage."""
        storage_dir = tmp_path / "integration_storage"
        storage_dir.mkdir()
        return storage_dir

    @pytest.fixture(scope="class")
    def aut_server(self) -> Generator[str, None, None]:
        """Start the integration test AUT (Application Under Test) server.

        This fixture:
        1. Starts the Python AUT server
        2. Waits for it to be ready
        3. Yields the server URL
        4. Stops the server after tests complete
        """
        command = [
            sys.executable,
            str(TEST_AUT_DIR / "server.py"),
            "--host",
            "127.0.0.1",
            "--port",
            str(TEST_AUT_PORT),
        ]

        LOGGER.info("Starting AUT server on port %s...", TEST_AUT_PORT)
        process = subprocess.Popen(
            command,
            cwd=TEST_AUT_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Wait for server to be ready
        server_url = TEST_TARGET_URL
        start_time = time.time()
        server_ready = False

        LOGGER.info("Waiting for AUT server to become ready...")

        while time.time() - start_time < TEST_AUT_STARTUP_TIMEOUT:
            try:
                response = requests.get(server_url, timeout=1)
                if response.status_code == 200:
                    server_ready = True
                    LOGGER.info("AUT server ready at %s", server_url)
                    break
            except requests.exceptions.RequestException:
                time.sleep(0.5)

        if not server_ready:
            process.terminate()
            try:
                _, stderr_output = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                _, stderr_output = process.communicate()
            pytest.fail(
                f"AUT server failed to start within {TEST_AUT_STARTUP_TIMEOUT}s"
                f"\nCommand: {' '.join(command)}"
                f"\nStderr:\n{stderr_output}"
            )

        try:
            yield server_url
        finally:
            # Stop the server
            LOGGER.info("Stopping AUT server...")
            process.terminate()
            try:
                _, stderr_output = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                _, stderr_output = process.communicate()
            if stderr_output:
                LOGGER.warning("AUT server stderr:\n%s", stderr_output)
            LOGGER.info("AUT server stopped")

    @pytest.mark.asyncio
    @pytest.mark.slow  # Mark as slow test
    @pytest.mark.integration  # Mark as integration test
    async def test_local_platform_with_chat_app_integration(
        self,
        mock_arato_api: MagicMock,
        temp_storage_dir: Path,
        aut_server: str,
    ) -> None:
        """TRUE integration test running local platform with REAL components.

        This integration test:
        1. Runs the REAL local platform against a local test chat application
        2. Uses REAL browser (Playwright) to interact with the page
        3. Uses REAL LLM (AWS Bedrock) to generate responses
        4. Uses REAL orchestrator and chat runner components
        5. Only mocks the Arato logging API (external service)
        6. Verifies ALL artifacts are created with correct structure
        7. Runs comprehensive quality checks on the results

        WARNING: This test makes REAL browser interactions and AWS Bedrock API calls.
        It will take several seconds to complete and consume AWS credits.
        Requires AWS credentials to be configured (source <(arato aws-creds dev)).
        """
        # Use the AUT server URL with login bypass (skip passcode gate)
        target_url = f"{aut_server}?bypass_login=true"

        # Mock _get_branch_id to force local storage instead of S3
        with patch.object(LocalPlatformAdapter, "_get_branch_id", return_value=None):
            # Initialize local platform adapter (uses AWS Bedrock)
            adapter = LocalPlatformAdapter(
                storage_dir=str(temp_storage_dir),
            )

        # Force headless mode and disable HITL interactivity for integration tests
        env_overrides = {
            "CI": "true",  # Force headless browser mode
            "LOCAL_HITL_INTERACTIVE": "false",  # Disable HITL pause/wait behavior
        }

        # Create output_dir inside temp_storage_dir to ensure all artifacts go there
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = str(temp_storage_dir / f"sessions/conversation_{timestamp}")

        with patch.dict(os.environ, env_overrides):
            # Only mock the Arato API (external service)
            # Everything else runs for REAL!
            with patch(
                "tools.arato_logs_api.AratoLogsAPI", return_value=mock_arato_api
            ):
                LOGGER.info("Starting pipeline run against AUT...")
                LOGGER.info("Pipeline starting with 90s timeout...")
                result = await adapter.run_pipeline(
                    target_url=target_url,
                    persona_ids=TEST_PERSONA_IDS,
                    seed_utterance=TEST_SEED_UTTERANCE,
                    max_turns=TEST_MAX_TURNS,
                    output_dir=output_dir,
                    arato_api_url="https://mock-api.arato.ai/log",
                    arato_api_key="mock-api-key",
                    thread_id="test-thread-123",
                    timeout=90,  # 90 second total timeout for 2-turn conversation
                )
                LOGGER.info("Pipeline completed successfully!")

            # Debug: print the result
            LOGGER.info(
                "=== Integration Test Result ===\n%s", json.dumps(result, indent=2)
            )
            LOGGER.info("Pipeline execution complete")

        # Verify artifacts were created in storage directory
        # The orchestrator should have created a session directory
        session_id = result["session_id"]

        # Check in both possible locations (temp_storage_dir and relative path)
        session_dir_temp = temp_storage_dir / "sessions" / session_id
        session_dir_relative = Path("sessions") / session_id

        # The session should exist in at least one location
        if session_dir_temp.exists():
            session_dir = session_dir_temp
            LOGGER.info("Session directory created in temp storage: %s", session_dir)
        elif session_dir_relative.exists():
            session_dir = session_dir_relative
            LOGGER.info(
                "Session directory created in repository storage: %s", session_dir
            )
        else:
            raise AssertionError(
                f"Session directory not found. "
                f"Looked in {session_dir_temp} and {session_dir_relative}"
            )

        # Run comprehensive quality checks on all results and artifacts
        LOGGER.info("Running comprehensive quality checks on pipeline output...")
        self._run_quality_checks_on_results(
            result, TEST_PERSONA_IDS, target_url, session_dir
        )
        LOGGER.info("All quality checks completed successfully")

    # -------------------------------------------------------------------------
    # Artifact validation helpers
    # -------------------------------------------------------------------------

    def _validate_transcript_file(self, transcript_file: Path) -> list[dict]:
        """Validate transcript.json structure and content.

        transcript.json is saved as a dict by chat_runner/runner.py with
        top-level keys: target_url, persona_id, transcript, total_turns, etc.
        The 'transcript' key contains the list of ConversationTurn dicts.
        """
        assert transcript_file.exists(), f"transcript.json not found: {transcript_file}"

        with open(transcript_file, encoding="utf-8") as f:
            raw = json.load(f)

        # transcript.json is a dict with metadata + 'transcript' list
        assert isinstance(raw, dict), (
            f"transcript.json should be a dict, got {type(raw).__name__}"
        )
        assert "transcript" in raw, "transcript.json missing 'transcript' key"
        assert "target_url" in raw, "transcript.json missing 'target_url'"
        assert "total_turns" in raw, "transcript.json missing 'total_turns'"

        data = raw["transcript"]
        assert isinstance(data, list), (
            f"transcript.json 'transcript' should be a list, got {type(data).__name__}"
        )
        assert len(data) > 0, "transcript.json 'transcript' should not be empty"

        prev_role = None
        for i, turn in enumerate(data):
            # Required fields
            assert "id" in turn, f"Turn {i} missing 'id'"
            assert "role" in turn, f"Turn {i} missing 'role'"
            assert "text" in turn, f"Turn {i} missing 'text'"
            assert "turn_number" in turn, f"Turn {i} missing 'turn_number'"

            # UUID format for id
            try:
                uuid.UUID(turn["id"])
            except ValueError:
                pytest.fail(f"Turn {i} id is not a valid UUID: {turn['id']}")

            # Role validity
            assert turn["role"] in ("user", "assistant"), (
                f"Turn {i} has invalid role: {turn['role']}"
            )

            # Non-empty text
            assert isinstance(turn["text"], str), f"Turn {i} text is not a string"
            assert len(turn["text"].strip()) > 0, f"Turn {i} has empty text"

            # Turn number is int
            assert isinstance(turn["turn_number"], int), (
                f"Turn {i} turn_number is not int: {turn['turn_number']}"
            )

            # Timestamp validation (if present)
            if turn.get("timestamp"):
                try:
                    datetime.fromisoformat(turn["timestamp"].replace("Z", "+00:00"))
                except ValueError:
                    pytest.fail(
                        f"Turn {i} has invalid ISO 8601 timestamp: {turn['timestamp']}"
                    )

            # No two consecutive user messages
            if prev_role == "user" and turn["role"] == "user":
                pytest.fail(f"Turn {i}: two consecutive user messages")

            prev_role = turn["role"]

            LOGGER.info(
                "  Turn %d [%s]: %s...",
                turn["turn_number"],
                turn["role"],
                turn["text"][:80],
            )

        return data

    def _validate_summary_file(self, summary_file: Path) -> dict:
        """Validate summary.json structure.

        Based on PersonaSummary Pydantic model in
        utils/persona_summary_generator.py:118-120.
        """
        assert summary_file.exists(), f"summary.json not found: {summary_file}"

        with open(summary_file, encoding="utf-8") as f:
            data = json.load(f)

        assert isinstance(data, dict), (
            f"summary.json should be a dict, got {type(data).__name__}"
        )

        # Top-level keys from PersonaSummary model
        assert "conversation_metadata" in data, "Missing 'conversation_metadata'"
        assert "analysis" in data, "Missing 'analysis'"

        # Conversation metadata validation
        metadata = data["conversation_metadata"]
        assert isinstance(metadata, dict), "conversation_metadata should be a dict"
        assert "url" in metadata, "Missing metadata.url"
        assert "persona" in metadata, "Missing metadata.persona"
        assert "total_turns" in metadata, "Missing metadata.total_turns"
        assert "total_messages" in metadata, "Missing metadata.total_messages"
        assert isinstance(metadata["total_turns"], int)
        assert isinstance(metadata["total_messages"], int)
        assert metadata["total_messages"] > 0, "total_messages should be > 0"

        # Analysis section validation
        analysis = data["analysis"]
        assert isinstance(analysis, dict), "analysis should be a dict"
        assert "findings" in analysis, "Missing analysis.findings"
        assert isinstance(analysis["findings"], list), "findings should be a list"

        LOGGER.info(
            "  Summary: %d turns, %d messages, %d findings",
            metadata["total_turns"],
            metadata["total_messages"],
            len(analysis["findings"]),
        )

        return data

    def _validate_report_data_file(self, report_data_file: Path) -> dict:
        """Validate report_data.json structure."""
        assert report_data_file.exists(), (
            f"report_data.json not found: {report_data_file}"
        )

        with open(report_data_file, encoding="utf-8") as f:
            data = json.load(f)

        assert isinstance(data, dict), (
            f"report_data.json should be a dict, got {type(data).__name__}"
        )

        # Top-level required keys
        for key in ("key_findings", "conversations", "metadata", "stats"):
            assert key in data, f"Missing top-level key: {key}"

        # Metadata validation
        metadata = data["metadata"]
        assert isinstance(metadata, dict), "metadata should be a dict"
        assert "target_urls" in metadata, "Missing metadata.target_urls"
        assert "timestamp" in metadata, "Missing metadata.timestamp"
        assert "personas" in metadata, "Missing metadata.personas"
        assert "total_personas" in metadata, "Missing metadata.total_personas"
        assert "total_turns" in metadata, "Missing metadata.total_turns"
        assert isinstance(metadata["target_urls"], list)
        assert len(metadata["target_urls"]) > 0, "target_urls should not be empty"
        assert isinstance(metadata["total_personas"], int)
        assert metadata["total_personas"] > 0, "total_personas should be > 0"

        # Conversations validation
        conversations = data["conversations"]
        assert isinstance(conversations, list), "conversations should be a list"
        assert len(conversations) > 0, "conversations should not be empty"
        for conv in conversations:
            assert "persona_id" in conv, "conversation missing persona_id"
            assert "transcript" in conv, "conversation missing transcript"
            assert isinstance(conv["transcript"], list), "transcript should be a list"

        # Key findings and stats validation
        assert isinstance(data["key_findings"], list)
        assert isinstance(data["stats"], dict)

        LOGGER.info(
            "  Report: %d personas, %d conversations, %d key findings",
            metadata["total_personas"],
            len(conversations),
            len(data["key_findings"]),
        )

        return data

    def _validate_stats_file(self, stats_file: Path) -> str:
        """Validate stats.md structure."""
        assert stats_file.exists(), f"stats.md not found: {stats_file}"

        content = stats_file.read_text(encoding="utf-8")
        assert len(content) > 0, "stats.md is empty"

        # Check for expected markdown sections
        assert "# Session Statistics" in content, (
            "Missing '# Session Statistics' header"
        )
        assert "## Overview" in content, "Missing '## Overview' section"
        assert "Total Personas" in content, "Missing 'Total Personas' stat"
        assert "Total Turns" in content, "Missing 'Total Turns' stat"

        LOGGER.info("  stats.md: %d bytes", len(content))

        return content

    def _validate_html_report(self, html_file: Path) -> None:
        """Validate summary.html exists and is non-trivial."""
        assert html_file.exists(), f"summary.html not found: {html_file}"
        size = html_file.stat().st_size
        assert size > 0, "summary.html is empty"
        # HTML report should be at least a few KB
        assert size > 1000, f"summary.html seems too small: {size} bytes"

        LOGGER.info("  summary.html: %d bytes", size)

    def _validate_video_file(self, video_file: Path) -> None:
        """Validate video file exists and is non-empty."""
        assert video_file.exists(), (
            f"Video file not found: {video_file}. "
            "Video recording should not fail in integration tests."
        )
        size = video_file.stat().st_size
        assert size > 0, f"Video file is empty: {video_file}"

        LOGGER.info("  Video: %s (%d bytes)", video_file.name, size)

    # -------------------------------------------------------------------------
    # Main quality check orchestrator
    # -------------------------------------------------------------------------

    def _run_quality_checks_on_results(
        self,
        result: dict[str, Any],
        persona_ids: list[str],
        target_url: str,
        session_dir: Path,
    ) -> None:
        """Run comprehensive quality checks on pipeline results and all artifacts.

        Args:
            result: Pipeline execution result
            persona_ids: List of persona IDs that were run
            target_url: Target URL that was tested
            session_dir: Session directory path (must exist)
        """
        # === 1. Pipeline result structure ===
        LOGGER.info("Checking pipeline result structure...")
        assert result["status"] == "success", f"Pipeline failed: {result}"
        assert "session_id" in result
        assert "personas_run" in result
        assert result["personas_run"] == len(persona_ids)
        assert "results" in result

        # Verify results contain expected personas (by instance name, not persona_id)
        result_keys = list(result["results"].keys())
        assert len(result_keys) == len(persona_ids), (
            f"Expected {len(persona_ids)} personas, got {len(result_keys)}"
        )

        # === 2. Per-persona result validation ===
        for instance_name in result_keys:
            persona_result = result["results"][instance_name]

            assert "target_url" in persona_result
            assert persona_result["target_url"] == target_url
            assert "transcript" in persona_result
            assert "total_turns" in persona_result
            assert isinstance(persona_result["total_turns"], int)
            assert persona_result["total_turns"] >= 0

            transcript = persona_result["transcript"]
            assert isinstance(transcript, list)

            if len(transcript) > 0:
                LOGGER.info(
                    "Result transcript for %s: %d messages",
                    instance_name,
                    len(transcript),
                )
                for message in transcript:
                    assert "role" in message
                    assert "text" in message
                    assert message["role"] in ["user", "assistant"]
                    assert isinstance(message["text"], str)
                    assert len(message["text"].strip()) > 0, "Empty message text"

                assert persona_result["total_turns"] > 0, "No turns recorded"

        # === 3. Session directory must exist ===
        assert session_dir.exists(), f"Session directory not found: {session_dir}"

        # === 4. Per-persona file artifacts ===
        for instance_name in result_keys:
            persona_dir = session_dir / instance_name
            assert persona_dir.exists(), f"Persona directory not found: {persona_dir}"

            LOGGER.info("Validating artifacts for persona '%s'...", instance_name)

            # transcript.json
            LOGGER.info("  Validating transcript.json...")
            self._validate_transcript_file(persona_dir / TRANSCRIPT_FILENAME)

            # summary.json
            LOGGER.info("  Validating summary.json...")
            self._validate_summary_file(persona_dir / SUMMARY_FILENAME)

            # run.mp4
            LOGGER.info("  Validating run.mp4...")
            self._validate_video_file(persona_dir / RUN_VIDEO_FILENAME)

        # === 5. Session-level artifacts ===
        LOGGER.info("Validating session-level artifacts...")

        # report_data.json
        LOGGER.info("Validating report_data.json...")
        self._validate_report_data_file(session_dir / REPORT_DATA_FILENAME)

        # stats.md
        LOGGER.info("Validating stats.md...")
        self._validate_stats_file(session_dir / "stats.md")

        # summary.html
        LOGGER.info("Validating summary.html...")
        self._validate_html_report(session_dir / "summary.html")
