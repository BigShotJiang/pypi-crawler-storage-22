"""Tests for GitHub content loader."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tools.load_github_content import GitHubContentLoader


class TestGitHubContentLoaderInitialization:
    """Tests for GitHubContentLoader initialization."""

    def test_initialization_with_cache_dir(self, tmp_path: Path) -> None:
        """Test initialization with cache directory."""
        loader = GitHubContentLoader(cache_dir=str(tmp_path / "cache"))
        assert loader.cache_dir is not None
        assert loader.cache_dir.exists()
        assert loader.use_storage is True

    def test_initialization_without_cache_dir(self) -> None:
        """Test initialization without cache directory."""
        loader = GitHubContentLoader(cache_dir=None)
        assert loader.cache_dir is None
        assert loader.use_storage is True

    def test_initialization_with_storage_disabled(self) -> None:
        """Test initialization with storage disabled."""
        loader = GitHubContentLoader(use_storage=False)
        assert loader.use_storage is False


class TestParseGitHubURL:
    """Tests for GitHub URL parsing."""

    def test_parse_basic_repo_url(self) -> None:
        """Test parsing basic repo URL."""
        loader = GitHubContentLoader()
        result = loader._parse_github_url("https://github.com/owner/repo")
        assert result == {
            "owner": "owner",
            "repo": "repo",
            "ref": "main",
            "path": "",
        }

    def test_parse_blob_url(self) -> None:
        """Test parsing blob URL with file."""
        loader = GitHubContentLoader()
        result = loader._parse_github_url(
            "https://github.com/owner/repo/blob/main/file.md"
        )
        assert result == {
            "owner": "owner",
            "repo": "repo",
            "ref": "main",
            "path": "file.md",
        }

    def test_parse_tree_url(self) -> None:
        """Test parsing tree URL with directory."""
        loader = GitHubContentLoader()
        result = loader._parse_github_url(
            "https://github.com/owner/repo/tree/develop/src/dir"
        )
        assert result == {
            "owner": "owner",
            "repo": "repo",
            "ref": "develop",
            "path": "src/dir",
        }

    def test_parse_blob_url_with_nested_path(self) -> None:
        """Test parsing blob URL with nested path."""
        loader = GitHubContentLoader()
        result = loader._parse_github_url(
            "https://github.com/owner/repo/blob/feature-branch/docs/guide/api.md"
        )
        assert result == {
            "owner": "owner",
            "repo": "repo",
            "ref": "feature-branch",
            "path": "docs/guide/api.md",
        }

    def test_parse_invalid_url_wrong_domain(self) -> None:
        """Test parsing URL with wrong domain."""
        loader = GitHubContentLoader()
        result = loader._parse_github_url("https://gitlab.com/owner/repo")
        assert result is None

    def test_parse_invalid_url_too_short(self) -> None:
        """Test parsing URL with insufficient parts."""
        loader = GitHubContentLoader()
        result = loader._parse_github_url("https://github.com/owner")
        assert result is None


class TestGetRawURL:
    """Tests for raw URL generation."""

    def test_get_raw_url(self) -> None:
        """Test generating raw URL."""
        loader = GitHubContentLoader()
        url = loader._get_raw_url("owner", "repo", "main", "file.md")
        assert url == "https://raw.githubusercontent.com/owner/repo/main/file.md"

    def test_get_raw_url_with_nested_path(self) -> None:
        """Test generating raw URL with nested path."""
        loader = GitHubContentLoader()
        url = loader._get_raw_url("owner", "repo", "develop", "src/docs/api.md")
        assert (
            url
            == "https://raw.githubusercontent.com/owner/repo/develop/src/docs/api.md"
        )


class TestStorageCacheKey:
    """Tests for storage cache key generation."""

    def test_get_storage_key_basic(self) -> None:
        """Test generating storage key."""
        loader = GitHubContentLoader()
        key = loader._get_storage_key("owner", "repo", "main", "file.md")
        assert key == "github_cache/owner/repo/main/file.md.json"

    def test_get_storage_key_with_path_separators(self) -> None:
        """Test storage key with path separators."""
        loader = GitHubContentLoader()
        key = loader._get_storage_key("owner", "repo", "main", "src/docs/api.md")
        assert key == "github_cache/owner/repo/main/src_docs_api.md.json"

    def test_get_storage_key_with_empty_path(self) -> None:
        """Test storage key with empty path."""
        loader = GitHubContentLoader()
        key = loader._get_storage_key("owner", "repo", "main", "")
        assert key == "github_cache/owner/repo/main/root.json"


class TestStorageCache:
    """Tests for storage caching functionality."""

    @pytest.mark.asyncio
    async def test_check_storage_cache_hit(self) -> None:
        """Test storage cache hit."""
        loader = GitHubContentLoader()
        mock_storage = MagicMock()

        # Mock storage returning valid cached data
        cache_data = {
            "content": "test content",
            "metadata": {
                "sha": "abc123",
                "cached_at": datetime.now(UTC).isoformat(),
            },
        }
        import json

        mock_storage.download_cache.return_value = json.dumps(cache_data)
        loader._storage = mock_storage

        content, metadata = await loader._check_storage_cache(
            "owner", "repo", "main", "file.md"
        )

        assert content == "test content"
        assert metadata is not None
        assert metadata["sha"] == "abc123"
        mock_storage.download_cache.assert_called_once()

    @pytest.mark.asyncio
    async def test_check_storage_cache_miss(self) -> None:
        """Test storage cache miss."""
        loader = GitHubContentLoader()
        mock_storage = MagicMock()
        mock_storage.download_cache.return_value = None
        loader._storage = mock_storage

        content, metadata = await loader._check_storage_cache(
            "owner", "repo", "main", "file.md"
        )

        assert content is None
        assert metadata is None

    @pytest.mark.asyncio
    async def test_check_storage_cache_expired(self) -> None:
        """Test storage cache expiration."""
        loader = GitHubContentLoader()
        mock_storage = MagicMock()

        # Mock storage returning expired cached data
        expired_time = datetime.now(UTC) - timedelta(days=31)
        cache_data = {
            "content": "test content",
            "metadata": {
                "sha": "abc123",
                "cached_at": expired_time.isoformat(),
            },
        }
        import json

        mock_storage.download_cache.return_value = json.dumps(cache_data)
        loader._storage = mock_storage

        content, metadata = await loader._check_storage_cache(
            "owner", "repo", "main", "file.md"
        )

        assert content is None
        assert metadata is None

    @pytest.mark.asyncio
    async def test_check_storage_cache_disabled(self) -> None:
        """Test storage cache when disabled."""
        loader = GitHubContentLoader(use_storage=False)
        content, metadata = await loader._check_storage_cache(
            "owner", "repo", "main", "file.md"
        )
        assert content is None
        assert metadata is None

    @pytest.mark.asyncio
    async def test_save_to_storage_cache(self) -> None:
        """Test saving to storage cache."""
        loader = GitHubContentLoader()
        mock_storage = MagicMock()
        loader._storage = mock_storage

        await loader._save_to_storage_cache(
            "owner", "repo", "main", "file.md", "test content", "abc123"
        )

        mock_storage.upload_cache.assert_called_once()
        call_args = mock_storage.upload_cache.call_args
        assert call_args[0][0] == "owner/repo"  # domain
        # Verify content is JSON with metadata
        import json

        content_data = json.loads(call_args[0][1])
        assert content_data["content"] == "test content"
        assert content_data["metadata"]["sha"] == "abc123"

    @pytest.mark.asyncio
    async def test_save_to_storage_cache_disabled(self) -> None:
        """Test saving to storage cache when disabled."""
        loader = GitHubContentLoader(use_storage=False)
        mock_storage = MagicMock()
        loader._storage = mock_storage

        await loader._save_to_storage_cache(
            "owner", "repo", "main", "file.md", "test content", "abc123"
        )

        mock_storage.upload_cache.assert_not_called()


class TestLoadFile:
    """Tests for loading individual files."""

    @pytest.mark.asyncio
    async def test_load_file_from_storage_cache(self) -> None:
        """Test loading file from storage cache."""
        loader = GitHubContentLoader()

        with patch.object(
            loader,
            "_check_storage_cache",
            return_value=("cached content", {"sha": "abc"}),
        ):
            with patch.object(loader, "_parse_github_url") as mock_parse:
                mock_parse.return_value = {
                    "owner": "owner",
                    "repo": "repo",
                    "ref": "main",
                    "path": "file.md",
                }
                content = await loader.load_file("https://github.com/owner/repo")

        assert content == "cached content"

    @pytest.mark.asyncio
    async def test_load_file_downloads_when_cache_miss(self) -> None:
        """Test loading file downloads when cache misses."""
        loader = GitHubContentLoader(cache_dir=None)  # Disable local cache

        # Mock httpx async client properly
        mock_response = MagicMock()
        mock_response.text = "downloaded content"
        mock_response.raise_for_status = MagicMock()

        mock_httpx_client = AsyncMock()
        mock_httpx_client.__aenter__.return_value = mock_httpx_client
        mock_httpx_client.__aexit__.return_value = None
        mock_httpx_client.get = AsyncMock(return_value=mock_response)

        with patch.object(loader, "_check_storage_cache", return_value=(None, None)):
            with patch.object(loader, "_parse_github_url") as mock_parse:
                mock_parse.return_value = {
                    "owner": "owner",
                    "repo": "repo",
                    "ref": "main",
                    "path": "file.md",
                }
                with patch("httpx.AsyncClient", return_value=mock_httpx_client):
                    content = await loader.load_file(
                        "https://github.com/owner/repo/blob/main/file.md"
                    )

        assert content == "downloaded content"

    @pytest.mark.asyncio
    async def test_load_file_invalid_url(self) -> None:
        """Test loading file with invalid URL."""
        loader = GitHubContentLoader()

        with pytest.raises(ValueError, match="Invalid GitHub URL"):
            await loader.load_file("https://not-github.com/owner/repo")
