"""Tests for local platform implementation."""

import tempfile
from pathlib import Path

from platforms.local.storage import LocalStorageAdapter


class TestLocalStorageAdapter:
    """Tests for local filesystem storage adapter."""

    def test_initialization(self) -> None:
        """Test that storage adapter initializes correctly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            adapter = LocalStorageAdapter(base_dir=tmpdir)
            assert adapter.get_storage_location() == str(Path(tmpdir).absolute())
            assert Path(tmpdir).exists()

    def test_upload_cache(self) -> None:
        """Test uploading content to cache."""
        with tempfile.TemporaryDirectory() as tmpdir:
            adapter = LocalStorageAdapter(base_dir=tmpdir)

            # Upload cache
            success = adapter.upload_cache(
                domain="example.com", content="test content", cache_key="test.md"
            )
            assert success is True

            # Verify file exists
            cache_path = Path(tmpdir) / "cache" / "example.com" / "test.md"
            assert cache_path.exists()
            assert cache_path.read_text() == "test content"

    def test_download_cache_hit(self) -> None:
        """Test downloading cached content."""
        with tempfile.TemporaryDirectory() as tmpdir:
            adapter = LocalStorageAdapter(base_dir=tmpdir)

            # Upload first
            adapter.upload_cache(
                domain="example.com", content="cached data", cache_key="data.txt"
            )

            # Download
            content = adapter.download_cache(domain="example.com", cache_key="data.txt")
            assert content == "cached data"

    def test_download_cache_miss(self) -> None:
        """Test downloading non-existent cache."""
        with tempfile.TemporaryDirectory() as tmpdir:
            adapter = LocalStorageAdapter(base_dir=tmpdir)

            content = adapter.download_cache(
                domain="example.com", cache_key="missing.txt"
            )
            assert content is None

    def test_upload_artifacts(self) -> None:
        """Test uploading artifacts directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            adapter = LocalStorageAdapter(base_dir=tmpdir)

            # Create source directory with files
            source_dir = Path(tmpdir) / "source"
            source_dir.mkdir()
            (source_dir / "file1.txt").write_text("content1")
            (source_dir / "subdir").mkdir()
            (source_dir / "subdir" / "file2.txt").write_text("content2")

            # Upload artifacts
            result = adapter.upload_artifacts(
                directory=str(source_dir), session_id="test_session"
            )

            assert "location" in result
            assert "test_session" in result["location"]
            assert result["file_count"] == "2"

            # Verify files were copied
            location = result["location"]
            assert isinstance(location, str), "location should be a string"
            dest_path = Path(location)
            assert (dest_path / "file1.txt").exists()
            assert (dest_path / "subdir" / "file2.txt").exists()

    def test_upload_cache_with_org_id(self) -> None:
        """Test cache upload with organization ID."""
        with tempfile.TemporaryDirectory() as tmpdir:
            adapter = LocalStorageAdapter(base_dir=tmpdir)

            adapter.upload_cache(
                domain="example.com",
                content="org content",
                cache_key="test.md",
                org_id="org123",
            )

            # Verify org ID is in path
            cache_path = Path(tmpdir) / "cache" / "org123" / "example.com" / "test.md"
            assert cache_path.exists()
            assert cache_path.read_text() == "org content"
