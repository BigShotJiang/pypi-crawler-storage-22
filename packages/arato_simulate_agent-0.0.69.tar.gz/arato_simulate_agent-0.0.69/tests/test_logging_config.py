"""Tests for logging configuration."""

import logging
import tempfile
from pathlib import Path

from utils.logging_config import setup_logging


def test_setup_logging_creates_log_file() -> None:
    """Test that setup_logging creates agent.log file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        session_dir = Path(tmpdir) / "test_session"

        # Setup logging with file output
        setup_logging(session_dir=session_dir)

        # Log a test message
        logger = logging.getLogger("test_logger")
        logger.info("Test message")

        # Verify log file was created
        log_file = session_dir / "agent.log"
        assert log_file.exists(), "agent.log should be created"

        # Verify log content
        log_content = log_file.read_text()
        assert "Test message" in log_content
        assert "test_logger" in log_content


def test_setup_logging_console_only() -> None:
    """Test that setup_logging works without session_dir."""
    # Should not raise any errors
    setup_logging(session_dir=None)

    logger = logging.getLogger("test_console")
    logger.info("Console only message")
