"""
Tests for the autonomous chat system with orchestrator and agents.
"""

import json
from pathlib import Path

import pytest

from agents import SwarmOrchestrator
from agents.app_context_discovery import AppContextDiscoveryAgent
from agents.chat_runner import ChatRunner
from constants import (
    APP_CONTEXT_FILENAME,
    DOMAIN_SETTINGS_DIR,
    HAR_FILENAME,
    TRANSCRIPT_FILENAME,
    VIDEO_SUBDIR_DISCOVERY,
    VIDEO_SUBDIR_RUN,
)
from models.conversation_turn import ConversationTurn
from utils.url_utils import get_domain_from_url

# ============================================================================
# Utility Tests
# ============================================================================


def test_get_domain_from_url() -> None:
    """Test domain extraction from URLs."""
    assert get_domain_from_url("https://example.com/chat") == "example.com"
    assert get_domain_from_url("https://example.com:8080/chat") == "example.com"
    assert get_domain_from_url("https://sub.example.com") == "sub.example.com"
    assert (
        get_domain_from_url("https://f34031b167cd.ngrok-free.app")
        == "f34031b167cd.ngrok-free.app"
    )


# ============================================================================
# App Context Discovery Agent Tests
# ============================================================================


class TestAppContextDiscoveryAgent:
    """Tests for AppContextDiscoveryAgent."""

    @pytest.mark.asyncio
    async def test_initialization(self) -> None:
        """Test agent initialization."""
        agent = AppContextDiscoveryAgent(headless=True)
        assert agent.headless is True

    def test_extract_context_from_history(self) -> None:
        """Test context extraction from agent history."""
        agent = AppContextDiscoveryAgent(headless=True)

        # Test with proper 'done' action containing meaningful content
        history_with_content = [
            {
                "action": {"name": "navigate"},
                "result": {"text": "Navigated to homepage"},
            },
            {
                "action": {"name": "done"},
                "result": {
                    "text": """# Application Context Report

This is an HR management system designed for small businesses.

## Core Features
- Payroll processing
- Benefits administration
- Employee onboarding

The system helps companies manage their workforce efficiently."""
                },
            },
        ]

        report = agent._extract_context_from_history(
            history_with_content, "https://example.com"
        )

        assert len(report) > 200
        assert "HR management system" in report
        assert "Payroll" in report

        # Test with history that has no meaningful content
        history_no_content = [
            {
                "action": {"name": "navigate"},
                "result": {"text": "Navigated to homepage"},
            },
        ]

        report_empty = agent._extract_context_from_history(
            history_no_content, "https://example.com"
        )

        assert report_empty == ""

    def test_save_app_context(self, tmp_path: Path) -> None:
        """Test saving app context report."""
        output_file = tmp_path / APP_CONTEXT_FILENAME

        # Create a sample report
        report = """# Application Context Discovery Report

**Target URL**: https://example.com

## Application Overview
This is a test application for HR management.
"""

        output_file.write_text(report)

        assert output_file.exists()
        content = output_file.read_text()
        assert "Application Context Discovery Report" in content
        assert "HR management" in content


# ============================================================================
# Chat Runner Tests
# ============================================================================


class TestChatRunner:
    """Tests for ChatRunner."""

    @pytest.mark.asyncio
    async def test_initialization(self) -> None:
        """Test runner initialization."""
        runner = ChatRunner(headless=False)
        assert runner.headless is False

    def test_conversation_turn(self) -> None:
        """Test ConversationTurn dataclass."""
        turn = ConversationTurn(role="user", text="Hello")
        assert turn.role == "user"
        assert turn.text == "Hello"

    @pytest.mark.asyncio
    async def test_load_bindings_from_code(self) -> None:
        """Test loading bindings from generated code."""
        runner = ChatRunner()

        code = """
async def input_text(page, text: str) -> None:
    pass

async def await_text_output(page, opts: dict = None) -> str:
    return "test response"
"""

        input_fn, output_fn = await runner._load_bindings_from_code(code)

        assert callable(input_fn)
        assert callable(output_fn)
        # Test that the function actually works
        result = await output_fn(None)
        assert result == "test response"

    def test_normalize_max_turns(self) -> None:
        """Ensure max_turns normalization handles invalid values gracefully."""

        assert ChatRunner._normalize_max_turns(5) == 5
        assert ChatRunner._normalize_max_turns("7") == 7
        assert ChatRunner._normalize_max_turns("invalid") == 10
        assert ChatRunner._normalize_max_turns(0) == 1


# ============================================================================
# Orchestrator Tests
# ============================================================================


class TestOrchestrator:
    """Tests for SwarmOrchestrator."""

    def test_initialization(self) -> None:
        """Test orchestrator initialization with new simplified architecture."""
        orchestrator = SwarmOrchestrator(headless=True)
        assert orchestrator.headless is True
        # New architecture: only app_context_agent and chat_runner
        assert orchestrator.app_context_agent is not None
        assert orchestrator.chat_runner is not None
        # Removed agents: discovery_agent and codegen_agent
        assert not hasattr(orchestrator, "discovery_agent")
        assert not hasattr(orchestrator, "codegen_agent")

    @pytest.mark.asyncio
    async def test_domain_caching_structure(self, tmp_path: Path) -> None:
        """Test that orchestrator creates proper domain cache structure."""
        # This tests the cache lookup logic, not the full run
        _ = SwarmOrchestrator(headless=True)

        url = "https://example.com/chat"
        domain = get_domain_from_url(url)

        # Simulate creating domain_settings structure
        domain_settings_path = tmp_path / DOMAIN_SETTINGS_DIR / domain
        domain_settings_path.mkdir(parents=True, exist_ok=True)

        spec_file = domain_settings_path / "locator_spec.json"
        bindings_file = domain_settings_path / "chat_bindings.py"

        # Create fake cached files
        spec_file.write_text('{"input_selector": "input"}')
        bindings_file.write_text("# cached code")

        assert spec_file.exists()
        assert bindings_file.exists()
        assert domain == "example.com"

    @pytest.mark.asyncio
    async def test_session_folder_creation(self, tmp_path: Path) -> None:
        """Test that orchestrator creates session folders."""
        # Test the session folder naming pattern
        from datetime import datetime

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_folder = tmp_path / f"conversation_{timestamp}"
        session_folder.mkdir(parents=True, exist_ok=True)

        assert session_folder.exists()
        assert "conversation_" in session_folder.name


# ============================================================================
# Integration Workflow Tests
# ============================================================================


class TestIntegrationWorkflow:
    """Tests for the complete pipeline workflow."""

    @pytest.mark.asyncio
    async def test_cache_hit_workflow(self, tmp_path: Path) -> None:
        """Test workflow when cache exists."""
        domain = "example.com"
        domain_settings_path = tmp_path / DOMAIN_SETTINGS_DIR / domain
        domain_settings_path.mkdir(parents=True, exist_ok=True)

        # Create cached files
        spec = {
            "final_url": "https://example.com/chat",
            "input_selector": "textarea",
            "send_selector": "button",
            "message_selector": ".msg",
            "frame_path": [],
            "notes": "Cached",
        }

        spec_file = domain_settings_path / "locator_spec.json"
        spec_file.write_text(json.dumps(spec, indent=2))

        bindings_file = domain_settings_path / "chat_bindings.py"
        bindings_file.write_text("# cached code")

        # Simulate cache hit
        if spec_file.exists() and bindings_file.exists():
            loaded_spec = json.loads(spec_file.read_text())
            loaded_code = bindings_file.read_text()

            assert loaded_spec["input_selector"] == "textarea"
            assert "cached code" in loaded_code

    @pytest.mark.asyncio
    async def test_cache_miss_workflow(self, tmp_path: Path) -> None:
        """Test workflow when no cache exists."""
        domain = "newsite.com"
        # Use relative path instead of absolute to respect tmp_path
        domain_settings_path = tmp_path / "domain_settings" / domain

        # Cache doesn't exist yet
        assert not domain_settings_path.exists()

        # After run, cache would be created
        domain_settings_path.mkdir(parents=True, exist_ok=True)

        # Save new discovery and bindings
        spec_file = domain_settings_path / "locator_spec.json"
        spec_file.write_text('{"input_selector": "input"}')

        bindings_file = domain_settings_path / "chat_bindings.py"
        bindings_file.write_text("# new code")

        assert spec_file.exists()
        assert bindings_file.exists()


# ============================================================================
# File System Tests
# ============================================================================


class TestFileSystem:
    """Tests for file system operations."""

    def test_domain_settings_structure(self, tmp_path: Path) -> None:
        """Test domain_settings folder structure."""
        domain_settings = tmp_path / DOMAIN_SETTINGS_DIR
        domain_settings.mkdir(exist_ok=True)

        example_domain = domain_settings / "example.com"
        example_domain.mkdir(exist_ok=True)

        (example_domain / "locator_spec.json").write_text("{}")
        (example_domain / "chat_bindings.py").write_text("# code")

        assert (example_domain / "locator_spec.json").exists()
        assert (example_domain / "chat_bindings.py").exists()

    def test_session_structure(self, tmp_path: Path) -> None:
        """Test session folder structure."""
        session = tmp_path / "sessions" / "conversation_20251101_120000"
        session.mkdir(parents=True, exist_ok=True)

        # Session contains copies and session-specific files
        (session / "locator_spec.json").write_text("{}")
        (session / "chat_bindings.py").write_text("# code")
        (session / APP_CONTEXT_FILENAME).write_text('{"summary": "test"}')
        (session / "discovery_report.md").write_text("# Report")
        (session / TRANSCRIPT_FILENAME).write_text("[]")

        # Video directories
        (session / "discovery_video").mkdir(exist_ok=True)
        (session / VIDEO_SUBDIR_RUN).mkdir(exist_ok=True)
        (session / VIDEO_SUBDIR_DISCOVERY).mkdir(exist_ok=True)

        # HAR files
        (session / "discovery.har").write_text("{}")
        (session / "conversation.har").write_text("{}")
        (session / HAR_FILENAME).write_text("{}")

        assert (session / APP_CONTEXT_FILENAME).exists()
        assert (session / "discovery_report.md").exists()
        assert (session / TRANSCRIPT_FILENAME).exists()
        assert (session / "discovery.har").exists()
        assert (session / "conversation.har").exists()
        assert (session / HAR_FILENAME).exists()
        assert (session / "discovery_video").is_dir()
        assert (session / VIDEO_SUBDIR_RUN).is_dir()
        assert (session / VIDEO_SUBDIR_DISCOVERY).is_dir()


# ============================================================================
# Argument Parsing Tests
# ============================================================================


class TestArgumentParsing:
    """Tests for command-line argument parsing."""

    def test_single_persona_parsing(self) -> None:
        """Test parsing single persona from --persona flag."""
        test_args = [
            "orchestrator.py",
            "https://example.com",
            "--persona=malicious_user",
        ]

        # Simulate argument parsing
        persona_id = None
        persona_ids = []

        for arg in test_args:
            if arg.startswith("--persona="):
                persona_value = arg.split("=", 1)[1]
                if "," in persona_value:
                    persona_ids = [p.strip() for p in persona_value.split(",")]
                else:
                    persona_id = persona_value

        assert persona_id == "malicious_user"
        assert persona_ids == []

    def test_multiple_personas_parsing(self) -> None:
        """Test parsing multiple personas from --persona flag."""
        test_args = [
            "orchestrator.py",
            "https://example.com",
            "--persona=malicious_user,compliance_user,nice_user",
        ]

        # Simulate argument parsing
        persona_id = None
        persona_ids = []

        for arg in test_args:
            if arg.startswith("--persona="):
                persona_value = arg.split("=", 1)[1]
                if "," in persona_value:
                    persona_ids = [p.strip() for p in persona_value.split(",")]
                else:
                    persona_id = persona_value

        assert persona_id is None
        assert persona_ids == ["malicious_user", "compliance_user", "nice_user"]

    def test_multiple_personas_with_spaces(self) -> None:
        """Test parsing multiple personas with spaces after commas."""
        test_args = [
            "orchestrator.py",
            "https://example.com",
            "--persona=malicious_user, compliance_user, nice_user",
        ]

        # Simulate argument parsing
        persona_id = None
        persona_ids = []

        for arg in test_args:
            if arg.startswith("--persona="):
                persona_value = arg.split("=", 1)[1]
                if "," in persona_value:
                    persona_ids = [p.strip() for p in persona_value.split(",")]
                else:
                    persona_id = persona_value

        assert persona_id is None
        assert persona_ids == ["malicious_user", "compliance_user", "nice_user"]


# ============================================================================
# Goal Parameter Tests
# ============================================================================


class TestGoalParameter:
    """Tests for goal parameter functionality."""

    @pytest.mark.asyncio
    async def test_discover_goal_skips_chat(self, tmp_path: Path) -> None:
        """Test that goal='discover' skips chat runner execution."""
        from unittest.mock import AsyncMock, MagicMock, patch

        orchestrator = SwarmOrchestrator(headless=True)

        # Mock the discovery agent to return context (>50 chars to pass threshold)
        mock_context = "This is a mock app context with enough content to pass the 50 character threshold check."

        # Create a mock httpx client that returns a successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_http_client = AsyncMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=False)
        mock_http_client.get = AsyncMock(return_value=mock_response)

        # Mock storage operations and discovery at module level
        with (
            patch("httpx.AsyncClient", return_value=mock_http_client),
            patch("agents.graph_orchestrator.download_domain_cache") as mock_download,
            patch("agents.graph_orchestrator.upload_domain_cache") as mock_upload,
            patch(
                "agents.graph_orchestrator.upload_session_artifacts"
            ) as mock_artifacts,
            patch(
                "agents.graph_orchestrator.AppContextDiscoveryAgent"
            ) as mock_discovery_agent_cls,
        ):
            mock_download.return_value = mock_context
            mock_upload.return_value = True
            mock_artifacts.return_value = {
                "bucket": "test-bucket",
                "prefix": "test-prefix",
            }

            # Setup discovery mock
            mock_discovery_agent = mock_discovery_agent_cls.return_value
            mock_discovery_agent.discover_app_context = AsyncMock(
                return_value=mock_context
            )

            result = await orchestrator.run_pipeline(
                target_url="https://example.com",
                output_dir=str(tmp_path),
                goal="discover",
            )

            # Verify result structure for discover goal
            assert result["goal"] == "discover"
            assert result["app_context"] == mock_context
            assert result["transcript"] is None
            assert result["total_turns"] == 0

    @pytest.mark.asyncio
    async def test_chat_goal_runs_full_pipeline(self, tmp_path: Path) -> None:
        """Test that goal='chat' runs chat directly."""
        from unittest.mock import AsyncMock, MagicMock, patch

        orchestrator = SwarmOrchestrator(headless=True)

        # Create a mock httpx client that returns a successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_http_client = AsyncMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=False)
        mock_http_client.get = AsyncMock(return_value=mock_response)

        # Mock storage operations and chat runner at module level
        with (
            patch("httpx.AsyncClient", return_value=mock_http_client),
            patch("agents.graph_orchestrator.download_domain_cache") as mock_download,
            patch("agents.graph_orchestrator.upload_domain_cache") as mock_upload,
            patch(
                "agents.graph_orchestrator.upload_session_artifacts"
            ) as mock_artifacts,
            patch("agents.graph_orchestrator.ChatRunner") as mock_chat_runner_cls,
        ):
            mock_download.return_value = None
            mock_upload.return_value = True
            mock_artifacts.return_value = {
                "bucket": "test-bucket",
                "prefix": "test-prefix",
            }

            # Setup chat runner mock
            mock_chat_runner = mock_chat_runner_cls.return_value
            mock_chat_runner.run_conversation = AsyncMock(
                return_value={
                    "transcript": [{"role": "user", "content": "Hello"}],
                    "total_turns": 1,
                }
            )

            result = await orchestrator.run_pipeline(
                target_url="https://example.com",
                output_dir=str(tmp_path),
                goal="chat",
                persona_ids=["nice_user"],
            )

            # Verify discovery was skipped (app_context is None for chat goal)
            assert result["app_context"] is None
            # Verify chat ran
            assert result["transcript"] is not None
            assert result["total_turns"] == 1

    @pytest.mark.asyncio
    async def test_default_goal_runs_full_pipeline(self, tmp_path: Path) -> None:
        """Test that default behavior (no goal specified) runs chat."""
        from unittest.mock import AsyncMock, MagicMock, patch

        orchestrator = SwarmOrchestrator(headless=True)

        # Create a mock httpx client that returns a successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_http_client = AsyncMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=False)
        mock_http_client.get = AsyncMock(return_value=mock_response)

        # Mock storage operations and chat runner at module level
        with (
            patch("httpx.AsyncClient", return_value=mock_http_client),
            patch("agents.graph_orchestrator.download_domain_cache") as mock_download,
            patch("agents.graph_orchestrator.upload_domain_cache") as mock_upload,
            patch(
                "agents.graph_orchestrator.upload_session_artifacts"
            ) as mock_artifacts,
            patch("agents.graph_orchestrator.ChatRunner") as mock_chat_runner_cls,
        ):
            mock_download.return_value = None
            mock_upload.return_value = True
            mock_artifacts.return_value = {
                "bucket": "test-bucket",
                "prefix": "test-prefix",
            }

            # Setup chat runner mock
            mock_chat_runner = mock_chat_runner_cls.return_value
            mock_chat_runner.run_conversation = AsyncMock(
                return_value={
                    "transcript": [{"role": "user", "content": "Hello"}],
                    "total_turns": 1,
                }
            )

            # Don't specify goal - should default to 'chat'
            result = await orchestrator.run_pipeline(
                target_url="https://example.com",
                output_dir=str(tmp_path),
                persona_ids=["nice_user"],
            )

            # Verify discovery was skipped (app_context is None for default chat goal)
            assert result["app_context"] is None
            assert result["transcript"] is not None
            assert result["total_turns"] == 1

    @pytest.mark.asyncio
    async def test_multi_persona_discover_goal(self, tmp_path: Path) -> None:
        """Test that goal='discover' skips chat in multi-persona mode."""
        from unittest.mock import AsyncMock, MagicMock, patch

        orchestrator = SwarmOrchestrator(headless=True)

        # Mock the discovery agent (>50 chars to pass threshold)
        mock_context = "This is a mock app context with enough content to pass the 50 character threshold check."

        # Create a mock httpx client that returns a successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_http_client = AsyncMock()
        mock_http_client.__aenter__ = AsyncMock(return_value=mock_http_client)
        mock_http_client.__aexit__ = AsyncMock(return_value=False)
        mock_http_client.get = AsyncMock(return_value=mock_response)

        # Mock storage operations and discovery at module level
        with (
            patch("httpx.AsyncClient", return_value=mock_http_client),
            patch("agents.graph_orchestrator.download_domain_cache") as mock_download,
            patch("agents.graph_orchestrator.upload_domain_cache") as mock_upload,
            patch(
                "agents.graph_orchestrator.upload_session_artifacts"
            ) as mock_artifacts,
            patch(
                "agents.graph_orchestrator.AppContextDiscoveryAgent"
            ) as mock_discovery_agent_cls,
        ):
            mock_download.return_value = mock_context
            mock_upload.return_value = True
            mock_artifacts.return_value = {
                "bucket": "test-bucket",
                "prefix": "test-prefix",
            }

            # Setup discovery mock
            mock_discovery_agent = mock_discovery_agent_cls.return_value
            mock_discovery_agent.discover_app_context = AsyncMock(
                return_value=mock_context
            )

            result = await orchestrator.run_pipeline(
                target_url="https://example.com",
                output_dir=str(tmp_path),
                persona_ids=["nice_user", "malicious_user"],
                goal="discover",
            )

            # Verify result structure
            assert result["goal"] == "discover"
            assert result["app_context"] == mock_context
            # For discover goal, no personas are run
            assert result.get("personas_run", 0) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
