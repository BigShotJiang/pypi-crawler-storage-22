"""Tests for persona multiplier functionality."""

from agents import expand_persona_list, parse_persona_with_multiplier


def test_parse_persona_with_multiplier_simple() -> None:
    """Test parsing a persona without multiplier."""
    persona_id, count = parse_persona_with_multiplier("malicious_user")
    assert persona_id == "malicious_user"
    assert count == 1


def test_parse_persona_with_multiplier_with_number() -> None:
    """Test parsing a persona with multiplier."""
    persona_id, count = parse_persona_with_multiplier("malicious_user:5")
    assert persona_id == "malicious_user"
    assert count == 5


def test_parse_persona_with_multiplier_with_whitespace() -> None:
    """Test parsing with whitespace."""
    persona_id, count = parse_persona_with_multiplier(" malicious_user : 3 ")
    assert persona_id == "malicious_user"
    assert count == 3


def test_parse_persona_with_multiplier_invalid_number() -> None:
    """Test parsing with invalid number defaults to 1."""
    persona_id, count = parse_persona_with_multiplier("malicious_user:abc")
    assert persona_id == "malicious_user"
    assert count == 1


def test_parse_persona_with_multiplier_negative_number() -> None:
    """Test parsing with negative number defaults to 1."""
    persona_id, count = parse_persona_with_multiplier("malicious_user:-5")
    assert persona_id == "malicious_user"
    assert count == 1


def test_parse_persona_with_multiplier_zero() -> None:
    """Test parsing with zero defaults to 1."""
    persona_id, count = parse_persona_with_multiplier("malicious_user:0")
    assert persona_id == "malicious_user"
    assert count == 1


def test_expand_persona_list_single_no_multiplier() -> None:
    """Test expanding a single persona without multiplier."""
    result = expand_persona_list(["malicious_user"])
    assert result == [("malicious_user", 1)]


def test_expand_persona_list_single_with_multiplier() -> None:
    """Test expanding a single persona with multiplier."""
    result = expand_persona_list(["malicious_user:3"])
    assert result == [
        ("malicious_user", 1),
        ("malicious_user", 2),
        ("malicious_user", 3),
    ]


def test_expand_persona_list_multiple_no_multipliers() -> None:
    """Test expanding multiple personas without multipliers."""
    result = expand_persona_list(["malicious_user", "compliance_user", "nice_user"])
    assert result == [
        ("malicious_user", 1),
        ("compliance_user", 1),
        ("nice_user", 1),
    ]


def test_expand_persona_list_multiple_with_multipliers() -> None:
    """Test expanding multiple personas with different multipliers."""
    result = expand_persona_list(
        ["malicious_user:10", "compliance_user:5", "nice_user"]
    )
    assert len(result) == 16  # 10 + 5 + 1

    # Check malicious_user instances
    malicious_instances = [r for r in result if r[0] == "malicious_user"]
    assert len(malicious_instances) == 10
    assert malicious_instances[0] == ("malicious_user", 1)
    assert malicious_instances[9] == ("malicious_user", 10)

    # Check compliance_user instances
    compliance_instances = [r for r in result if r[0] == "compliance_user"]
    assert len(compliance_instances) == 5
    assert compliance_instances[0] == ("compliance_user", 1)
    assert compliance_instances[4] == ("compliance_user", 5)

    # Check nice_user instance
    nice_instances = [r for r in result if r[0] == "nice_user"]
    assert len(nice_instances) == 1
    assert nice_instances[0] == ("nice_user", 1)


def test_expand_persona_list_mixed() -> None:
    """Test expanding with mixed specifications."""
    result = expand_persona_list(["malicious_user:2", "nice_user", "malicious_user:1"])

    # Total should be 4 (2 + 1 + 1)
    assert len(result) == 4

    # malicious_user should have instances 1, 2, and 3
    malicious_instances = [r for r in result if r[0] == "malicious_user"]
    assert len(malicious_instances) == 3
    assert malicious_instances == [
        ("malicious_user", 1),
        ("malicious_user", 2),
        ("malicious_user", 3),
    ]

    # nice_user should have instance 1
    nice_instances = [r for r in result if r[0] == "nice_user"]
    assert len(nice_instances) == 1
    assert nice_instances[0] == ("nice_user", 1)


def test_expand_persona_list_preserves_order() -> None:
    """Test that expansion preserves the order of specification."""
    result = expand_persona_list(["compliance_user:2", "malicious_user:2"])

    assert result == [
        ("compliance_user", 1),
        ("compliance_user", 2),
        ("malicious_user", 1),
        ("malicious_user", 2),
    ]
