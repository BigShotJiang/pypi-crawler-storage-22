"""Tests for polling client and circuit breaker."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, Mock, patch

import httpx
import pytest

from core.polling.client import CircuitBreaker, TaskPollingClient
from core.schemas import TaskPayload


class TestCircuitBreaker:
    """Test CircuitBreaker for API resilience."""

    def test_initial_state(self) -> None:
        """Test circuit breaker starts in closed state."""
        cb = CircuitBreaker(failure_threshold=3, timeout=60)

        assert cb.state == "closed"
        assert cb.failure_count == 0
        assert cb.last_failure_time is None

    def test_record_success(self) -> None:
        """Test recording successful API calls."""
        cb = CircuitBreaker()
        cb.failure_count = 2
        cb.state = "half-open"

        cb.record_success()

        assert cb.failure_count == 0
        assert cb.state == "closed"

    def test_record_failure_below_threshold(self) -> None:
        """Test recording failures below threshold."""
        cb = CircuitBreaker(failure_threshold=5)

        cb.record_failure()
        assert cb.failure_count == 1
        assert cb.state == "closed"

        cb.record_failure()
        cb.record_failure()
        assert cb.failure_count == 3
        assert cb.state == "closed"

    def test_record_failure_reaches_threshold(self) -> None:
        """Test circuit opens when failure threshold is reached."""
        cb = CircuitBreaker(failure_threshold=3)

        cb.record_failure()
        cb.record_failure()
        cb.record_failure()

        assert cb.failure_count == 3
        assert cb.state == "open"
        assert cb.last_failure_time is not None

    def test_is_open_when_closed(self) -> None:
        """Test is_open returns False when circuit is closed."""
        cb = CircuitBreaker()

        assert not cb.is_open()

    def test_is_open_when_open(self) -> None:
        """Test is_open returns True when circuit is open."""
        cb = CircuitBreaker(failure_threshold=2)
        cb.record_failure()
        cb.record_failure()

        assert cb.is_open()

    def test_is_open_transitions_to_half_open_after_timeout(self) -> None:
        """Test circuit transitions to half-open after timeout."""
        cb = CircuitBreaker(failure_threshold=2, timeout=1)
        cb.record_failure()
        cb.record_failure()

        assert cb.state == "open"
        assert cb.is_open()

        # Simulate timeout by setting last_failure_time in the past
        cb.last_failure_time = datetime.now(UTC) - timedelta(seconds=2)

        # After timeout, should transition to half-open
        is_open = cb.is_open()
        assert not is_open
        assert cb.state == "half-open"


class TestTaskPollingClient:
    """Test TaskPollingClient for task polling operations."""

    def test_client_initialization(self) -> None:
        """Test client initializes with correct parameters."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/v1/tasks",
            api_key="test-key-123",
            agent_name="test-agent",
            agent_platform="test-platform",
            timeout=15.0,
        )

        assert client.task_endpoint == "https://api.example.com/v1/tasks"
        assert client.api_key == "test-key-123"
        assert client.agent_name == "test-agent"
        assert client.agent_platform == "test-platform"

        # Verify headers are set correctly
        assert client.client.headers["Authorization"] == "Bearer test-key-123"
        assert client.client.headers["Content-Type"] == "application/json"
        assert client.client.headers["x-agent-name"] == "test-agent"
        assert client.client.headers["x-agent-platform"] == "test-platform"

    @pytest.mark.asyncio
    async def test_poll_task_success_with_task(self) -> None:
        """Test polling successfully returns a task."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "target_url": "https://example.com",
            "persona_ids": ["malicious_user:1"],
        }

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response

            task = await client.poll_task()

            assert task is not None
            assert isinstance(task, TaskPayload)
            assert str(task.target_url) == "https://example.com/"
            assert task.persona_ids == ["malicious_user:1"]
            mock_get.assert_called_once()

    @pytest.mark.asyncio
    async def test_poll_task_no_tasks_available(self) -> None:
        """Test polling returns None when no tasks available."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        mock_response = Mock()
        mock_response.status_code = 204

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response

            task = await client.poll_task()

            assert task is None

    @pytest.mark.asyncio
    async def test_poll_task_empty_response(self) -> None:
        """Test polling handles empty JSON response."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = None

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response

            task = await client.poll_task()

            assert task is None

    @pytest.mark.asyncio
    async def test_poll_task_circuit_breaker_open(self) -> None:
        """Test polling is blocked when circuit breaker is open."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        # Force circuit breaker open
        client.circuit_breaker.state = "open"
        client.circuit_breaker.last_failure_time = datetime.now(UTC)

        task = await client.poll_task()

        assert task is None

    @pytest.mark.asyncio
    async def test_poll_task_http_error(self) -> None:
        """Test polling handles HTTP errors gracefully and records failure."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.side_effect = httpx.RequestError("Connection failed")

            # Should return None gracefully instead of raising
            result = await client.poll_task()
            assert result is None

            # Circuit breaker should record the failure
            assert client.circuit_breaker.failure_count == 1

    @pytest.mark.asyncio
    async def test_poll_task_timeout_error(self) -> None:
        """Test polling handles timeout errors gracefully."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.side_effect = httpx.ReadTimeout("Request timed out")

            # Should return None gracefully with warning log
            result = await client.poll_task()
            assert result is None

            # Circuit breaker should record the failure
            assert client.circuit_breaker.failure_count == 1

    @pytest.mark.asyncio
    async def test_poll_task_connection_error(self) -> None:
        """Test polling handles connection errors gracefully."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.side_effect = httpx.ConnectError("Connection refused")

            # Should return None gracefully with warning log
            result = await client.poll_task()
            assert result is None

            # Circuit breaker should record the failure
            assert client.circuit_breaker.failure_count == 1

    def test_inject_logging_config(self) -> None:
        """Test injecting logging configuration into task."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/api/task",
            api_key="test-key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        task = TaskPayload.model_validate(
            {"task_id": "abc123", "target_url": "https://example.com"}
        )

        updated_task = client.inject_logging_config(task)

        assert isinstance(updated_task, TaskPayload)
        assert updated_task.arato_api_url == "https://api.example.com/abc123/log"
        assert updated_task.arato_api_key == "test-key"

    def test_inject_logging_config_preserves_existing(self) -> None:
        """Test injection preserves existing logging config."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/api/task",
            api_key="test-key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        task = TaskPayload.model_validate(
            {
                "task_id": "abc123",
                "target_url": "https://example.com",
                "arato_api_url": "https://custom.api.com/xyz/log",
                "arato_api_key": "custom-key",
            }
        )

        updated_task = client.inject_logging_config(task)

        # Should preserve existing values
        assert updated_task.arato_api_url == "https://custom.api.com/xyz/log"
        assert updated_task.arato_api_key == "custom-key"

    def test_inject_logging_config_requires_task_id(self) -> None:
        """Test that inject_logging_config raises error without task_id."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/api/task",
            api_key="test-key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        task = TaskPayload.model_validate({"target_url": "https://example.com"})

        with pytest.raises(ValueError, match="task_id is required"):
            client.inject_logging_config(task)

    def test_derive_log_endpoint(self) -> None:
        """Test log endpoint derivation from task_id."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/api/task",
            api_key="test-key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        # Test with /api/task suffix
        log_endpoint = client.derive_log_endpoint("abc123")
        assert log_endpoint == "https://api.example.com/abc123/log"

        # Test with /task suffix (no /api prefix)
        client2 = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="test-key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )
        log_endpoint2 = client2.derive_log_endpoint("xyz789")
        assert log_endpoint2 == "https://api.example.com/xyz789/log"

    @pytest.mark.asyncio
    async def test_close_client(self) -> None:
        """Test client cleanup."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

        with patch.object(
            client.client, "aclose", new_callable=AsyncMock
        ) as mock_close:
            await client.close()

            mock_close.assert_called_once()


class TestHITLMethods:
    """Test HITL-related methods on TaskPollingClient."""

    def _make_client(self) -> TaskPollingClient:
        return TaskPollingClient(
            task_endpoint="https://api.example.com/api/v1/agent-connect/task",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )

    def test_derive_hitl_endpoint(self) -> None:
        """Test HITL endpoint derivation from task endpoint."""
        client = self._make_client()
        assert (
            client._derive_hitl_endpoint()
            == "https://api.example.com/api/v1/agent-connect/hitl"
        )

    def test_derive_hitl_endpoint_no_task_suffix(self) -> None:
        """Test HITL endpoint fallback when no /task suffix."""
        client = TaskPollingClient(
            task_endpoint="https://api.example.com/custom",
            api_key="key",
            agent_name="test-agent",
            agent_platform="test-platform",
        )
        assert client._derive_hitl_endpoint() == "https://api.example.com/custom/hitl"

    @pytest.mark.asyncio
    async def test_notify_hitl_success(self) -> None:
        """Test successful HITL notification."""
        client = self._make_client()

        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.raise_for_status = Mock()
        mock_response.json.return_value = {
            "intervention_id": "int-123",
            "state": "waiting",
        }

        with patch.object(client.client, "post", new_callable=AsyncMock) as mock_post:
            mock_post.return_value = mock_response

            result = await client.notify_hitl(
                task_id="task-1",
                intervention_type="captcha",
                reason="Need help with CAPTCHA",
                timeout_seconds=300,
            )

            assert result["intervention_id"] == "int-123"
            assert result["state"] == "waiting"
            mock_post.assert_called_once()
            assert client.circuit_breaker.failure_count == 0

    @pytest.mark.asyncio
    async def test_notify_hitl_http_error_records_failure(self) -> None:
        """Test that HTTP errors in notify_hitl record circuit breaker failure."""
        client = self._make_client()

        with patch.object(client.client, "post", new_callable=AsyncMock) as mock_post:
            mock_post.side_effect = httpx.RequestError("Connection failed")

            with pytest.raises(httpx.RequestError):
                await client.notify_hitl(
                    task_id="task-1",
                    intervention_type="login",
                    reason="Need login help",
                    timeout_seconds=600,
                )

            assert client.circuit_breaker.failure_count == 1

    @pytest.mark.asyncio
    async def test_poll_hitl_state_success(self) -> None:
        """Test successful polling of HITL intervention state."""
        client = self._make_client()

        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()
        mock_response.json.return_value = {
            "id": "int-123",
            "state": "completed",
            "completed_at": "2025-01-01T00:00:00Z",
            "url_after": "https://example.com/done",
            "error_message": None,
        }

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response

            result = await client.poll_hitl_state("int-123")

            assert result["state"] == "completed"
            assert result["url_after"] == "https://example.com/done"
            mock_get.assert_called_once()

    @pytest.mark.asyncio
    async def test_poll_hitl_state_http_error_records_failure(self) -> None:
        """Test that HTTP errors in poll_hitl_state record circuit breaker failure."""
        client = self._make_client()

        with patch.object(client.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.side_effect = httpx.RequestError("Connection failed")

            with pytest.raises(httpx.RequestError):
                await client.poll_hitl_state("int-123")

            assert client.circuit_breaker.failure_count == 1

    @pytest.mark.asyncio
    async def test_notify_hitl_timeout_success(self) -> None:
        """Test successful HITL timeout notification."""
        client = self._make_client()

        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.raise_for_status = Mock()

        with patch.object(client.client, "post", new_callable=AsyncMock) as mock_post:
            mock_post.return_value = mock_response

            await client.notify_hitl_timeout("int-123")

            mock_post.assert_called_once()
            assert client.circuit_breaker.failure_count == 0

    @pytest.mark.asyncio
    async def test_notify_hitl_timeout_http_error_records_failure(self) -> None:
        """Test that HTTP errors in notify_hitl_timeout record circuit breaker failure."""
        client = self._make_client()

        with patch.object(client.client, "post", new_callable=AsyncMock) as mock_post:
            mock_post.side_effect = httpx.RequestError("Connection failed")

            with pytest.raises(httpx.RequestError):
                await client.notify_hitl_timeout("int-123")

            assert client.circuit_breaker.failure_count == 1
