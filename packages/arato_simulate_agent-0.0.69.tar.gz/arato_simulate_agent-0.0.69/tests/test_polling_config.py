"""Tests for polling configuration."""

import os
from typing import Any, cast
from unittest.mock import patch

import pytest

from core.polling.config import PollingConfig


class TestPollingConfig:
    """Test PollingConfig dataclass and environment loading."""

    def test_config_creation_with_defaults(self) -> None:
        """Test creating config with required parameters."""
        config = PollingConfig(
            task_endpoint="https://api.example.com/tasks",
            api_key="test-key-123",
        )

        assert config.task_endpoint == "https://api.example.com/tasks"
        assert config.api_key == "test-key-123"
        assert config.polling_interval == 5  # Default value

    def test_config_creation_with_custom_interval(self) -> None:
        """Test creating config with custom polling interval."""
        config = PollingConfig(
            task_endpoint="https://api.example.com/tasks",
            api_key="test-key-123",
            polling_interval=30,
        )

        assert config.polling_interval == 30

    @patch.dict(
        os.environ,
        {
            "ARATO_API_KEY": "env-test-key",
            "ARATO_TASK_ENDPOINT": "https://env.example.com/tasks",
            "ARATO_POLLING_INTERVAL": "15",
        },
    )
    def test_from_env_with_all_variables(self) -> None:
        """Test loading config from environment variables."""
        config = PollingConfig.from_env()

        assert config is not None
        assert config.task_endpoint == "https://env.example.com/tasks"
        assert config.api_key == "env-test-key"
        assert config.polling_interval == 15

    @patch.dict(
        os.environ,
        {
            "ARATO_API_KEY": "env-test-key",
        },
        clear=True,
    )
    def test_from_env_with_defaults(self) -> None:
        """Test loading config with default endpoint and interval."""
        config = PollingConfig.from_env()

        assert config is not None
        assert (
            config.task_endpoint == "http://localhost:3000/api/v1/agent-connect/task"
        )  # Default
        assert config.api_key == "env-test-key"
        assert config.polling_interval == 5  # Default

    @patch.dict(os.environ, {}, clear=True)
    def test_from_env_without_api_key(self) -> None:
        """Test that from_env returns None when API key is missing."""
        config = PollingConfig.from_env()

        assert config is None

    @patch.dict(
        os.environ,
        {
            "ARATO_API_KEY": "test-key",
            "ARATO_POLLING_INTERVAL": "invalid",
        },
    )
    def test_from_env_with_invalid_interval(self) -> None:
        """Test that invalid polling interval raises ValueError."""
        with pytest.raises(ValueError, match="invalid literal for int"):
            PollingConfig.from_env()

    def test_config_immutability(self) -> None:
        """Test that config is a frozen dataclass."""
        from dataclasses import FrozenInstanceError

        config = PollingConfig(
            task_endpoint="https://api.example.com/tasks",
            api_key="test-key",
        )

        with pytest.raises(FrozenInstanceError):
            cast(Any, config).polling_interval = 10
