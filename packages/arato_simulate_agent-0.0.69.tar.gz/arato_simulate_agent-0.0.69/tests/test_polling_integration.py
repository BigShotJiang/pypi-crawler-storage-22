"""Integration test for polling mode with mock task and log servers.

This test verifies the complete polling workflow:
1. Mock task server provides tasks to poll
2. Local polling runner polls and executes tasks
3. Tasks target the integration test AUT application
4. Results are submitted back to mock task server
5. Logs are sent to mock log server
"""

import asyncio
import logging
import os
import subprocess
import sys
import time
from collections.abc import AsyncGenerator, Generator
from pathlib import Path
from typing import Any

import pytest
import requests
from aiohttp import web

from constants import SUMMARY_FILENAME, TRANSCRIPT_FILENAME
from core.polling.config import PollingConfig
from platforms.local.adapter import LocalPlatformAdapter
from platforms.local.polling_runner import LocalPollingRunner

# Test configuration
TEST_AUT_PORT = 5175  # Different port from other integration tests
TEST_TASK_SERVER_PORT = 5176
TEST_LOG_SERVER_PORT = 5177
TEST_TARGET_URL = f"http://127.0.0.1:{TEST_AUT_PORT}"
TEST_TASK_ENDPOINT = f"http://127.0.0.1:{TEST_TASK_SERVER_PORT}/task"
TEST_LOG_ENDPOINT = f"http://127.0.0.1:{TEST_LOG_SERVER_PORT}/log"
TEST_AUT_DIR = Path(__file__).parent.parent / "integration_test_aut"
TEST_AUT_STARTUP_TIMEOUT = 30
TEST_PERSONA_IDS = ["nice_user"]
TEST_MAX_TURNS = 1  # Reduced to 1 for faster, more reliable tests
TEST_POLL_INTERVAL = 1  # Poll every second for fast test

LOGGER = logging.getLogger(__name__)


class MockTaskServer:
    """Mock task server that provides tasks (one-way polling architecture)."""

    def __init__(self) -> None:
        self.tasks_queue: list[dict[str, Any]] = []
        self.poll_count = 0
        self.app = web.Application()
        self.app.router.add_get("/task", self.handle_poll)
        self.runner: web.AppRunner | None = None
        self.site: web.TCPSite | None = None

    async def handle_poll(self, request: web.Request) -> web.Response:
        """Handle task polling requests."""
        self.poll_count += 1
        LOGGER.info(f"[MockTaskServer] Poll request #{self.poll_count}")

        # Check authorization header
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            LOGGER.warning("[MockTaskServer] Missing or invalid Authorization header")
            return web.json_response({"error": "Unauthorized"}, status=401)

        # Return task if available
        if self.tasks_queue:
            task = self.tasks_queue.pop(0)
            task_url = task.get("target_url", "<no target_url>")
            LOGGER.info(f"[MockTaskServer] Returning task: {task_url}")
            return web.json_response(task)

        # No tasks available
        LOGGER.info("[MockTaskServer] No tasks available")
        return web.Response(status=204)

    def add_task(self, task: dict[str, Any]) -> None:
        """Add a task to the queue."""
        self.tasks_queue.append(task)
        target = task.get("target_url", "<invalid task>")
        LOGGER.info(f"[MockTaskServer] Added task to queue: {target}")

    async def start(self) -> None:
        """Start the mock server."""
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        self.site = web.TCPSite(self.runner, "127.0.0.1", TEST_TASK_SERVER_PORT)
        await self.site.start()
        LOGGER.info(f"[MockTaskServer] Started on port {TEST_TASK_SERVER_PORT}")

    async def stop(self) -> None:
        """Stop the mock server."""
        if self.site:
            await self.site.stop()
        if self.runner:
            await self.runner.cleanup()
        LOGGER.info("[MockTaskServer] Stopped")


class MockLogServer:
    """Mock log server that receives real-time logs."""

    def __init__(self) -> None:
        self.received_logs: list[dict[str, Any]] = []
        self.app = web.Application()
        self.app.router.add_post("/log", self.handle_log)
        self.runner: web.AppRunner | None = None
        self.site: web.TCPSite | None = None

    async def handle_log(self, request: web.Request) -> web.Response:
        """Handle log submission."""
        data = await request.json()
        self.received_logs.append(data)
        LOGGER.info(
            f"[MockLogServer] Received log entry "
            f"(level: {data.get('level', 'unknown')})"
        )
        return web.json_response({"status": "received"})

    async def start(self) -> None:
        """Start the mock server."""
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        self.site = web.TCPSite(self.runner, "127.0.0.1", TEST_LOG_SERVER_PORT)
        await self.site.start()
        LOGGER.info(f"[MockLogServer] Started on port {TEST_LOG_SERVER_PORT}")

    async def stop(self) -> None:
        """Stop the mock server."""
        if self.site:
            await self.site.stop()
        if self.runner:
            await self.runner.cleanup()
        LOGGER.info("[MockLogServer] Stopped")


@pytest.fixture(scope="class")
def aut_server() -> Generator[str, None, None]:
    """Start the integration test AUT server on a dedicated port."""
    command = [
        sys.executable,
        str(TEST_AUT_DIR / "server.py"),
        "--host",
        "127.0.0.1",
        "--port",
        str(TEST_AUT_PORT),
    ]

    LOGGER.info(f"Starting AUT server on port {TEST_AUT_PORT}...")
    process = subprocess.Popen(
        command,
        cwd=TEST_AUT_DIR,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
    )

    # Wait for server to be ready
    server_url = TEST_TARGET_URL
    start_time = time.time()
    server_ready = False

    while time.time() - start_time < TEST_AUT_STARTUP_TIMEOUT:
        try:
            response = requests.get(server_url, timeout=1)
            if response.status_code == 200:
                server_ready = True
                LOGGER.info(f"AUT server ready at {server_url}")
                break
        except requests.exceptions.RequestException:
            time.sleep(0.5)

    if not server_ready:
        process.terminate()
        try:
            _, stderr_output = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            _, stderr_output = process.communicate()
        pytest.fail(
            f"AUT server failed to start within {TEST_AUT_STARTUP_TIMEOUT}s\n"
            f"Command: {' '.join(command)}\n"
            f"Stderr:\n{stderr_output}"
        )

    try:
        yield server_url
    finally:
        LOGGER.info("Stopping AUT server...")
        process.terminate()
        try:
            process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.communicate()
        LOGGER.info("AUT server stopped")


@pytest.fixture
async def mock_task_server() -> AsyncGenerator[MockTaskServer, None]:
    """Start and manage mock task server."""
    server = MockTaskServer()
    await server.start()

    # Wait for server to be ready
    for _ in range(10):
        try:
            response = requests.get(
                f"http://127.0.0.1:{TEST_TASK_SERVER_PORT}/task",
                headers={"Authorization": "Bearer test-key"},
                timeout=1,
            )
            if response.status_code in (200, 204, 401):
                break
        except requests.exceptions.RequestException:
            await asyncio.sleep(0.1)

    yield server
    await server.stop()


@pytest.fixture
async def mock_log_server() -> AsyncGenerator[MockLogServer, None]:
    """Start and manage mock log server."""
    server = MockLogServer()
    await server.start()

    # Wait for server to be ready
    for _ in range(10):
        try:
            requests.post(
                f"http://127.0.0.1:{TEST_LOG_SERVER_PORT}/log",
                json={"test": "ping"},
                timeout=1,
            )
            break
        except requests.exceptions.RequestException:
            await asyncio.sleep(0.1)

    yield server
    await server.stop()


class TestPollingIntegration:
    """Integration tests for polling mode with mock servers."""

    @pytest.fixture
    def temp_storage_dir(self, tmp_path: Path) -> Path:
        """Temporary directory for test storage."""
        storage_dir = tmp_path / "polling_integration_storage"
        storage_dir.mkdir()
        return storage_dir

    @pytest.mark.asyncio
    @pytest.mark.slow
    @pytest.mark.integration
    async def test_polling_integration_end_to_end(
        self,
        aut_server: str,
        mock_task_server: MockTaskServer,
        mock_log_server: MockLogServer,
        temp_storage_dir: Path,
    ) -> None:
        """Test complete polling workflow with mock servers and real AUT.

        This integration test verifies:
        1. Mock task server provides task payloads
        2. Polling runner polls for tasks
        3. Tasks are executed against real AUT application
        4. Logs are sent to log server (if configured)
        5. Artifacts are created (transcripts, summaries)

        Note: One-way polling architecture - results stored in S3, not submitted back.
        """
        LOGGER.info("=== Starting Polling Integration Test ===")

        # Disable interactive HITL mode for automated testing
        os.environ["LOCAL_HITL_INTERACTIVE"] = "false"

        # Add a task to the mock server queue
        task_payload = {
            "target_url": TEST_TARGET_URL,
            "persona_ids": TEST_PERSONA_IDS,
            "max_turns": TEST_MAX_TURNS,
            "seed_utterance": "Hello",
            "arato_api_url": TEST_LOG_ENDPOINT,
            "arato_api_key": "test-log-key",
            "step_timeout": 20,  # Aggressive timeout for CI - 20s per step
        }
        mock_task_server.add_task(task_payload)

        # Create polling config for test
        config = PollingConfig(
            task_endpoint=TEST_TASK_ENDPOINT,
            api_key="test-api-key",
            polling_interval=TEST_POLL_INTERVAL,
        )

        # Create polling runner with test configuration
        runner = LocalPollingRunner(config=config)
        # Override adapter to use test storage directory (uses AWS Bedrock)
        runner.adapter = LocalPlatformAdapter(
            storage_dir=str(temp_storage_dir),
        )

        # Poll and execute one task manually
        result: dict[str, Any] | None = None

        async def execute_single_poll() -> None:
            nonlocal result
            task = await runner.client.poll_task()
            if task:
                await runner._execute_task(task)
                # Get the last execution result from the adapter
                # Note: This is a simplified approach since we don't have
                # result submission implemented yet
                result = {"executed": True, "task": task}

        poll_task = asyncio.create_task(execute_single_poll())

        try:
            # Wait for polling task to complete (with timeout)
            # Increased to 300s to account for CI slowness and browser startup
            await asyncio.wait_for(poll_task, timeout=300)
            LOGGER.info("Polling task completed")
        except TimeoutError:
            pytest.fail("Polling task timed out after 300 seconds")
        finally:
            # Clean up environment variable
            os.environ.pop("LOCAL_HITL_INTERACTIVE", None)

        # Verify task was polled
        assert mock_task_server.poll_count >= 1, "Task server should have been polled"
        LOGGER.info(f"✓ Task server was polled {mock_task_server.poll_count} times")

        # Verify task was executed
        assert result is not None, "Task should have been executed"
        assert result["executed"], "Task execution flag should be set"
        LOGGER.info("✓ Task was executed")

        # Verify task matches what we sent
        assert str(result["task"].target_url).rstrip("/") == TEST_TARGET_URL.rstrip("/")
        assert result["task"].persona_ids == TEST_PERSONA_IDS
        LOGGER.info("✓ Task payload matches")

        # Verify artifacts were created in storage directory
        # Find the most recent session directory
        sessions_dir = temp_storage_dir / "sessions"
        if sessions_dir.exists():
            session_dirs = sorted(
                sessions_dir.glob("*"), key=lambda p: p.stat().st_mtime
            )
            if session_dirs:
                session_dir = session_dirs[-1]
                LOGGER.info(f"✓ Session directory created: {session_dir}")

                # Check for transcript and summary files
                transcript_found = False
                summary_found = False
                for file in session_dir.glob("**/*"):
                    if file.is_file():
                        if TRANSCRIPT_FILENAME in file.name:
                            transcript_found = True
                            LOGGER.info(f"✓ Found transcript: {file.name}")
                        if SUMMARY_FILENAME in file.name:
                            summary_found = True
                            LOGGER.info(f"✓ Found summary: {file.name}")

                assert transcript_found, "At least one transcript should be created"
                assert summary_found, "Summary file should be created"
            else:
                LOGGER.warning("No session directories found")
        else:
            LOGGER.warning("Sessions directory does not exist")

        # Verify logs were sent to log server
        # Filter out the test ping that was sent during fixture setup
        real_logs = [
            log for log in mock_log_server.received_logs if log.get("test") != "ping"
        ]
        if len(real_logs) > 0:
            LOGGER.info(f"✓ Received {len(real_logs)} log entries")

            # Verify log entries have expected structure
            sample_log = real_logs[0]
            assert "level" in sample_log or "message" in sample_log, (
                "Log entry should have level or message"
            )
            LOGGER.info("✓ Log entries have correct structure")
        else:
            LOGGER.info("⚠ No logs received (logging may not be configured)")

        LOGGER.info("=== Polling Integration Test Completed Successfully ===")

    @pytest.mark.asyncio
    @pytest.mark.slow
    @pytest.mark.integration
    async def test_polling_no_tasks_available(
        self,
        aut_server: str,
        mock_task_server: MockTaskServer,
        temp_storage_dir: Path,
    ) -> None:
        """Test polling when no tasks are available."""
        LOGGER.info("=== Testing Polling with No Tasks ===")

        # Don't add any tasks to the queue
        config = PollingConfig(
            task_endpoint=TEST_TASK_ENDPOINT,
            api_key="test-api-key",
            polling_interval=TEST_POLL_INTERVAL,
        )

        runner = LocalPollingRunner(config=config)
        runner.adapter = LocalPlatformAdapter(
            storage_dir=str(temp_storage_dir),
        )

        # Run one polling iteration
        task = await runner.client.poll_task()
        if task:
            await runner._execute_task(task)

        # Verify task server was polled
        assert mock_task_server.poll_count >= 1
        LOGGER.info(f"✓ Task server polled {mock_task_server.poll_count} times")

        # One-way polling: results are stored locally, not submitted back
        LOGGER.info("✓ One-way polling completed (results stored locally)")

        LOGGER.info("=== No Tasks Test Completed Successfully ===")

    @pytest.mark.asyncio
    @pytest.mark.slow
    @pytest.mark.integration
    async def test_polling_invalid_task_payload(
        self,
        aut_server: str,
        mock_task_server: MockTaskServer,
        temp_storage_dir: Path,
    ) -> None:
        """Test polling with invalid task payload."""
        LOGGER.info("=== Testing Polling with Invalid Task ===")

        # Add an invalid task (missing required field)
        invalid_task = {
            "persona_ids": ["nice_user"],
            # Missing target_url
        }
        mock_task_server.add_task(invalid_task)

        config = PollingConfig(
            task_endpoint=TEST_TASK_ENDPOINT,
            api_key="test-api-key",
            polling_interval=TEST_POLL_INTERVAL,
        )

        runner = LocalPollingRunner(config=config)
        runner.adapter = LocalPlatformAdapter(
            storage_dir=str(temp_storage_dir),
        )

        # Run one polling iteration
        task = await runner.client.poll_task()
        if task:
            await runner._execute_task(task)

        # Verify task was polled
        assert mock_task_server.poll_count >= 1

        # One-way polling: invalid tasks should be logged as errors but not crash the system
        # Results (including errors) are stored locally, not submitted back
        LOGGER.info("✓ Invalid task handled without crashing")

        LOGGER.info("=== Invalid Task Test Completed Successfully ===")
