"""Tests for polling scheduler deployment and destruction scripts."""

from typing import Any
from unittest.mock import MagicMock, Mock, patch

import pytest
import yaml

from scripts.deploy_polling_scheduler import (
    deploy_cloudformation_stack,
    deploy_ssm_parameters,
    ensure_schedule_enabled,
    get_template_path,
    load_cloudformation_template,
)
from scripts.destroy_polling_scheduler import (
    delete_cloudformation_stack,
    delete_ssm_parameters,
)


def _cloudformation_constructor(
    loader: yaml.SafeLoader, tag_suffix: str, node: yaml.Node
) -> str | dict[str, Any]:
    """
    Constructor for CloudFormation intrinsic functions.

    Returns a string representation that preserves the tag for validation.
    """
    if isinstance(node, yaml.ScalarNode):
        value: str = loader.construct_scalar(node)
        return f"{tag_suffix}:{value}"
    elif isinstance(node, yaml.SequenceNode):
        seq_value: list[Any] = loader.construct_sequence(node)
        return {tag_suffix: seq_value}
    elif isinstance(node, yaml.MappingNode):
        map_value: dict[Any, Any] = loader.construct_mapping(node)
        return {tag_suffix: map_value}
    return str(node)


def _load_cloudformation_yaml(content: str) -> dict[Any, Any]:
    """
    Load CloudFormation YAML with support for intrinsic functions.

    This handles tags like !Ref, !GetAtt, !Sub, etc.
    """
    # Add constructors for common CloudFormation tags
    yaml.SafeLoader.add_multi_constructor("!", _cloudformation_constructor)

    try:
        return yaml.safe_load(content)
    finally:
        # Clean up to avoid affecting other tests
        yaml.SafeLoader.yaml_multi_constructors.pop("!", None)


class TestDeployPollingScheduler:
    """Tests for deploy_polling_scheduler.py."""

    def test_get_template_path_exists(self) -> None:
        """Test that template path points to an existing file."""
        template_path = get_template_path()
        assert template_path.exists()
        assert template_path.name == "polling_infrastructure.yaml"
        assert template_path.parent.name == "templates"

    def test_load_cloudformation_template_success(self) -> None:
        """Test loading CloudFormation template from YAML file."""
        template_content = load_cloudformation_template()
        assert isinstance(template_content, str)
        assert len(template_content) > 0

        # Parse as YAML to verify it's valid
        template = _load_cloudformation_yaml(template_content)
        assert "AWSTemplateFormatVersion" in template
        assert template["AWSTemplateFormatVersion"] == "2010-09-09"

    def test_cloudformation_template_structure(self) -> None:
        """Test CloudFormation template has correct structure."""
        template_content = load_cloudformation_template()
        template = _load_cloudformation_yaml(template_content)

        # Verify template structure
        assert "AWSTemplateFormatVersion" in template
        assert "Description" in template
        assert "Parameters" in template
        assert "Resources" in template
        assert "Outputs" in template

    def test_cloudformation_template_parameters(self) -> None:
        """Test CloudFormation template parameters are correctly defined."""
        template_content = load_cloudformation_template()
        template = _load_cloudformation_yaml(template_content)

        params = template["Parameters"]
        assert "AgentCoreArn" in params
        assert "ScheduleExpression" in params
        assert "ParameterPrefix" in params

        # Verify parameter types
        assert params["AgentCoreArn"]["Type"] == "String"
        assert params["ScheduleExpression"]["Type"] == "String"
        assert params["ParameterPrefix"]["Type"] == "String"

    def test_cloudformation_template_resources(self) -> None:
        """Test CloudFormation template resources are correctly defined."""
        template_content = load_cloudformation_template()
        template = _load_cloudformation_yaml(template_content)

        resources = template["Resources"]

        # Verify Lambda execution role
        assert "PollingLambdaRole" in resources
        role = resources["PollingLambdaRole"]
        assert role["Type"] == "AWS::IAM::Role"

        # Verify Lambda function
        assert "PollingLambdaFunction" in resources
        function = resources["PollingLambdaFunction"]
        assert function["Type"] == "AWS::Lambda::Function"

        # Verify scheduler role
        assert "PollingSchedulerRole" in resources
        scheduler_role = resources["PollingSchedulerRole"]
        assert scheduler_role["Type"] == "AWS::IAM::Role"

        # Verify scheduler
        assert "PollingSchedule" in resources
        schedule = resources["PollingSchedule"]
        assert schedule["Type"] == "AWS::Scheduler::Schedule"

    def test_cloudformation_template_outputs(self) -> None:
        """Test CloudFormation template outputs are correctly defined."""
        template_content = load_cloudformation_template()
        template = _load_cloudformation_yaml(template_content)

        outputs = template["Outputs"]
        assert "ScheduleName" in outputs
        assert "SchedulerRoleArn" in outputs
        assert "LambdaFunctionArn" in outputs
        assert "LambdaFunctionName" in outputs

        outputs = template["Outputs"]
        assert "ScheduleName" in outputs
        assert "SchedulerRoleArn" in outputs

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_deploy_ssm_parameters_success(self, mock_boto_client: Mock) -> None:
        """Test successful SSM parameter deployment."""
        mock_ssm = MagicMock()
        mock_boto_client.return_value = mock_ssm

        deploy_ssm_parameters(
            parameter_prefix="/test/polling",
            api_key="test-api-key",
            task_endpoint="https://api.test.com/tasks",
            polling_interval=30,
            circuit_breaker_threshold=5,
            circuit_breaker_timeout=60,
            region="us-east-1",
        )

        # Verify boto3 client was created with correct region
        mock_boto_client.assert_called_once_with("ssm", region_name="us-east-1")

        # Verify all parameters were created
        assert mock_ssm.put_parameter.call_count == 5

        # Verify parameter calls
        calls = mock_ssm.put_parameter.call_args_list
        param_names = [c.kwargs["Name"] for c in calls]

        assert "/test/polling/api_key" in param_names
        assert "/test/polling/task_endpoint" in param_names
        assert "/test/polling/polling_interval" in param_names
        assert "/test/polling/circuit_breaker_threshold" in param_names
        assert "/test/polling/circuit_breaker_timeout" in param_names

        # Verify api_key is SecureString
        api_key_call = [
            c for c in calls if c.kwargs["Name"] == "/test/polling/api_key"
        ][0]
        assert api_key_call.kwargs["Type"] == "SecureString"
        assert api_key_call.kwargs["Value"] == "test-api-key"
        assert api_key_call.kwargs["Overwrite"] is True

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_deploy_ssm_parameters_with_custom_values(
        self, mock_boto_client: Mock
    ) -> None:
        """Test SSM parameter deployment with custom values."""
        mock_ssm = MagicMock()
        mock_boto_client.return_value = mock_ssm

        deploy_ssm_parameters(
            parameter_prefix="/custom/path",
            api_key="custom-key",
            task_endpoint="https://custom.api.com/tasks",
            polling_interval=60,
            circuit_breaker_threshold=10,
            circuit_breaker_timeout=120,
            region="us-west-2",
        )

        # Verify region
        mock_boto_client.assert_called_once_with("ssm", region_name="us-west-2")

        # Verify custom values
        calls = mock_ssm.put_parameter.call_args_list

        polling_interval_call = [
            c for c in calls if c.kwargs["Name"] == "/custom/path/polling_interval"
        ][0]
        assert polling_interval_call.kwargs["Value"] == "60"

        threshold_call = [
            c
            for c in calls
            if c.kwargs["Name"] == "/custom/path/circuit_breaker_threshold"
        ][0]
        assert threshold_call.kwargs["Value"] == "10"

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_deploy_ssm_parameters_error_handling(self, mock_boto_client: Mock) -> None:
        """Test SSM parameter deployment error handling."""
        mock_ssm = MagicMock()
        mock_ssm.put_parameter.side_effect = Exception("SSM error")
        mock_boto_client.return_value = mock_ssm

        with pytest.raises(Exception, match="SSM error"):
            deploy_ssm_parameters(
                parameter_prefix="/test/polling",
                api_key="test-api-key",
                task_endpoint="https://api.test.com/tasks",
            )

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_deploy_cloudformation_stack_create_new(
        self, mock_boto_client: Mock
    ) -> None:
        """Test CloudFormation stack creation for new stack."""
        mock_cfn = MagicMock()

        # Use real botocore ClientError to exercise production error-parsing
        from botocore.exceptions import ClientError

        mock_cfn.exceptions.ClientError = ClientError

        # Make describe_stacks raise ClientError first time, then return success
        error = ClientError(
            {"Error": {"Code": "ValidationError", "Message": "Stack does not exist"}},
            "DescribeStacks",
        )
        mock_cfn.describe_stacks.side_effect = [
            error,
            {"Stacks": [{"StackStatus": "CREATE_COMPLETE", "Outputs": []}]},
        ]

        mock_boto_client.return_value = mock_cfn

        template_body = "AWSTemplateFormatVersion: 2010-09-09\nResources: {}"

        deploy_cloudformation_stack(
            stack_name="test-stack",
            template_body=template_body,
            agentcore_arn="arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/test",
            schedule_expression="rate(5 minutes)",
            parameter_prefix="/test/polling",
            region="us-east-1",
        )

        # Verify create_stack was called
        mock_cfn.create_stack.assert_called_once()
        call_kwargs = mock_cfn.create_stack.call_args.kwargs
        assert call_kwargs["StackName"] == "test-stack"
        assert call_kwargs["Capabilities"] == ["CAPABILITY_IAM"]
        assert "Parameters" in call_kwargs
        assert len(call_kwargs["Parameters"]) == 3

        # Verify waiter was used
        mock_cfn.get_waiter.assert_called_once_with("stack_create_complete")

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_deploy_cloudformation_stack_update_existing(
        self, mock_boto_client: Mock
    ) -> None:
        """Test CloudFormation stack update for existing stack."""
        mock_cfn = MagicMock()
        mock_cfn.describe_stacks.return_value = {
            "Stacks": [{"StackStatus": "CREATE_COMPLETE", "Outputs": []}]
        }
        mock_boto_client.return_value = mock_cfn

        template_body = "AWSTemplateFormatVersion: 2010-09-09\nResources: {}"

        deploy_cloudformation_stack(
            stack_name="existing-stack",
            template_body=template_body,
            agentcore_arn="arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/test",
            schedule_expression="rate(5 minutes)",
            parameter_prefix="/test/polling",
            region="us-east-1",
        )

        # Verify update_stack was called
        mock_cfn.update_stack.assert_called_once()
        call_kwargs = mock_cfn.update_stack.call_args.kwargs
        assert call_kwargs["StackName"] == "existing-stack"
        assert call_kwargs["Capabilities"] == ["CAPABILITY_IAM"]
        assert "Parameters" in call_kwargs

        # Verify waiter was used
        mock_cfn.get_waiter.assert_called_once_with("stack_update_complete")

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_deploy_cloudformation_stack_no_updates(
        self, mock_boto_client: Mock
    ) -> None:
        """Test CloudFormation stack update when no changes needed."""
        mock_cfn = MagicMock()

        # Use real botocore ClientError to exercise production error-parsing
        from botocore.exceptions import ClientError

        mock_cfn.exceptions.ClientError = ClientError

        mock_cfn.describe_stacks.return_value = {
            "Stacks": [{"StackStatus": "CREATE_COMPLETE", "Outputs": []}]
        }
        # Simulate "No updates are to be performed" error from update_stack
        mock_cfn.update_stack.side_effect = ClientError(
            {
                "Error": {
                    "Code": "ValidationError",
                    "Message": "No updates are to be performed.",
                }
            },
            "UpdateStack",
        )
        mock_boto_client.return_value = mock_cfn

        template_body = "AWSTemplateFormatVersion: 2010-09-09\nResources: {}"

        # Should NOT raise — no-op update is success
        deploy_cloudformation_stack(
            stack_name="existing-stack",
            template_body=template_body,
            agentcore_arn="arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/test",
            schedule_expression="rate(5 minutes)",
            parameter_prefix="/test/polling",
            region="us-east-1",
        )

        # Verify update was attempted but no waiter used
        mock_cfn.update_stack.assert_called_once()
        mock_cfn.get_waiter.assert_not_called()


class TestEnsureScheduleEnabled:
    """Tests for ensure_schedule_enabled."""

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_enables_disabled_schedule(self, mock_boto_client: Mock) -> None:
        """Test that a disabled schedule gets enabled."""
        mock_scheduler = MagicMock()
        mock_scheduler.get_schedule.return_value = {
            "State": "DISABLED",
            "ScheduleExpression": "rate(5 minutes)",
            "FlexibleTimeWindow": {"Mode": "OFF"},
            "Target": {
                "Arn": "arn:aws:lambda:us-east-1:123:function:poller",
                "RoleArn": "arn:aws:iam::123:role/test",
            },
        }
        mock_boto_client.return_value = mock_scheduler

        ensure_schedule_enabled(stack_name="arato-agent-polling", region="us-east-1")

        mock_scheduler.update_schedule.assert_called_once_with(
            Name="arato-agent-polling-polling-schedule",
            ScheduleExpression="rate(5 minutes)",
            FlexibleTimeWindow={"Mode": "OFF"},
            Target={
                "Arn": "arn:aws:lambda:us-east-1:123:function:poller",
                "RoleArn": "arn:aws:iam::123:role/test",
            },
            State="ENABLED",
        )

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_skips_already_enabled(self, mock_boto_client: Mock) -> None:
        """Test that an already-enabled schedule is left alone."""
        mock_scheduler = MagicMock()
        mock_scheduler.get_schedule.return_value = {"State": "ENABLED"}
        mock_boto_client.return_value = mock_scheduler

        ensure_schedule_enabled(stack_name="arato-agent-polling", region="us-east-1")

        mock_scheduler.update_schedule.assert_not_called()

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_handles_missing_schedule(self, mock_boto_client: Mock) -> None:
        """Test that a missing schedule doesn't raise an error."""
        from botocore.exceptions import ClientError

        mock_scheduler = MagicMock()
        mock_scheduler.get_schedule.side_effect = ClientError(
            {
                "Error": {
                    "Code": "ResourceNotFoundException",
                    "Message": "Schedule not found",
                }
            },
            "GetSchedule",
        )
        mock_boto_client.return_value = mock_scheduler

        # Should not raise
        ensure_schedule_enabled(stack_name="arato-agent-polling", region="us-east-1")

        mock_scheduler.update_schedule.assert_not_called()

    @patch("scripts.deploy_polling_scheduler.boto3.client")
    def test_reraises_non_notfound_errors(self, mock_boto_client: Mock) -> None:
        """Test that non-ResourceNotFoundException errors are re-raised."""
        from botocore.exceptions import ClientError

        mock_scheduler = MagicMock()
        mock_scheduler.get_schedule.side_effect = ClientError(
            {"Error": {"Code": "AccessDeniedException", "Message": "Access denied"}},
            "GetSchedule",
        )
        mock_boto_client.return_value = mock_scheduler

        with pytest.raises(ClientError, match="Access denied"):
            ensure_schedule_enabled(
                stack_name="arato-agent-polling", region="us-east-1"
            )


class TestDestroyPollingScheduler:
    """Tests for destroy_polling_scheduler.py."""

    @patch("scripts.destroy_polling_scheduler.boto3.client")
    def test_delete_ssm_parameters_success(self, mock_boto_client: Mock) -> None:
        """Test successful SSM parameter deletion."""
        mock_ssm = MagicMock()
        mock_boto_client.return_value = mock_ssm

        delete_ssm_parameters(
            parameter_prefix="/test/polling",
            region="us-east-1",
        )

        # Verify boto3 client was created
        mock_boto_client.assert_called_once_with("ssm", region_name="us-east-1")

        # Verify all parameters were deleted
        assert mock_ssm.delete_parameter.call_count == 5

        # Verify parameter names
        calls = mock_ssm.delete_parameter.call_args_list
        param_names = [c.kwargs["Name"] for c in calls]

        assert "/test/polling/api_key" in param_names
        assert "/test/polling/task_endpoint" in param_names
        assert "/test/polling/polling_interval" in param_names
        assert "/test/polling/circuit_breaker_threshold" in param_names
        assert "/test/polling/circuit_breaker_timeout" in param_names

    @patch("scripts.destroy_polling_scheduler.boto3.client")
    def test_delete_ssm_parameters_not_found(self, mock_boto_client: Mock) -> None:
        """Test SSM parameter deletion when parameters don't exist."""
        mock_ssm = MagicMock()
        mock_ssm.exceptions.ParameterNotFound = type(
            "ParameterNotFound", (Exception,), {}
        )
        mock_ssm.delete_parameter.side_effect = mock_ssm.exceptions.ParameterNotFound()
        mock_boto_client.return_value = mock_ssm

        # Should not raise exception
        delete_ssm_parameters(
            parameter_prefix="/test/polling",
            region="us-east-1",
        )

        # Verify attempts were made
        assert mock_ssm.delete_parameter.call_count == 5

    @patch("scripts.destroy_polling_scheduler.boto3.client")
    def test_delete_ssm_parameters_partial_failure(
        self, mock_boto_client: Mock
    ) -> None:
        """Test SSM parameter deletion with some failures."""
        mock_ssm = MagicMock()
        mock_ssm.exceptions.ParameterNotFound = type(
            "ParameterNotFound", (Exception,), {}
        )

        # First two succeed, third fails, rest succeed
        mock_ssm.delete_parameter.side_effect = [
            None,  # api_key success
            None,  # task_endpoint success
            Exception("Access denied"),  # polling_interval fails
            None,  # circuit_breaker_threshold success
            None,  # circuit_breaker_timeout success
        ]
        mock_boto_client.return_value = mock_ssm

        # Should not raise exception (logs error but continues)
        delete_ssm_parameters(
            parameter_prefix="/test/polling",
            region="us-east-1",
        )

        # Verify all deletion attempts were made
        assert mock_ssm.delete_parameter.call_count == 5

    @patch("scripts.destroy_polling_scheduler.boto3.client")
    def test_delete_cloudformation_stack_success(self, mock_boto_client: Mock) -> None:
        """Test successful CloudFormation stack deletion."""
        mock_cfn = MagicMock()
        mock_boto_client.return_value = mock_cfn

        delete_cloudformation_stack(
            stack_name="test-stack",
            region="us-east-1",
        )

        # Verify boto3 client was created
        mock_boto_client.assert_called_once_with(
            "cloudformation", region_name="us-east-1"
        )

        # Verify delete_stack was called
        mock_cfn.delete_stack.assert_called_once_with(StackName="test-stack")

        # Verify waiter was used
        mock_cfn.get_waiter.assert_called_once_with("stack_delete_complete")
        mock_waiter = mock_cfn.get_waiter.return_value
        mock_waiter.wait.assert_called_once_with(StackName="test-stack")

    @patch("scripts.destroy_polling_scheduler.boto3.client")
    def test_delete_cloudformation_stack_not_exists(
        self, mock_boto_client: Mock
    ) -> None:
        """Test CloudFormation stack deletion when stack doesn't exist."""
        mock_cfn = MagicMock()

        # Create a proper ClientError mock
        client_error = type("ClientError", (Exception,), {})
        mock_cfn.exceptions.ClientError = client_error

        # Create error with "does not exist" in its string representation
        error = client_error("does not exist")
        mock_cfn.delete_stack.side_effect = error

        mock_boto_client.return_value = mock_cfn

        # Should not raise exception (logs warning)
        delete_cloudformation_stack(
            stack_name="non-existent-stack",
            region="us-east-1",
        )

        mock_cfn.delete_stack.assert_called_once_with(StackName="non-existent-stack")

    @patch("scripts.destroy_polling_scheduler.boto3.client")
    def test_delete_cloudformation_stack_error(self, mock_boto_client: Mock) -> None:
        """Test CloudFormation stack deletion with error."""
        mock_cfn = MagicMock()
        mock_cfn.exceptions.ClientError = type("ClientError", (Exception,), {})

        error = mock_cfn.exceptions.ClientError()
        error.__str__ = lambda self: "Access denied"
        mock_cfn.delete_stack.side_effect = error

        mock_boto_client.return_value = mock_cfn

        # Should raise exception for other errors
        with pytest.raises(mock_cfn.exceptions.ClientError):
            delete_cloudformation_stack(
                stack_name="test-stack",
                region="us-east-1",
            )

    @patch("scripts.destroy_polling_scheduler.boto3.client")
    def test_delete_cloudformation_stack_custom_region(
        self, mock_boto_client: Mock
    ) -> None:
        """Test CloudFormation stack deletion with custom region."""
        mock_cfn = MagicMock()
        mock_cfn.exceptions.ClientError = type("ClientError", (Exception,), {})
        mock_boto_client.return_value = mock_cfn

        delete_cloudformation_stack(
            stack_name="test-stack",
            region="eu-west-1",
        )

        # Verify correct region was used
        mock_boto_client.assert_called_once_with(
            "cloudformation", region_name="eu-west-1"
        )
