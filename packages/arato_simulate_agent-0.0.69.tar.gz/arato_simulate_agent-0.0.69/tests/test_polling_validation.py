"""Tests for polling validation with Pydantic."""

import pytest
from pydantic import ValidationError

from core.schemas import TaskPayload, validate_task


class TestTaskPayload:
    """Test TaskPayload Pydantic model."""

    def test_valid_task_minimal(self) -> None:
        """Test validation with minimal required fields."""
        payload = TaskPayload.model_validate(
            {
                "target_url": "https://example.com",
                "persona_ids": ["malicious_user:1"],
            }
        )

        assert str(payload.target_url) == "https://example.com/"
        assert payload.persona_ids == ["malicious_user:1"]
        assert payload.seed_utterance == "Hello!"  # Default
        assert payload.max_turns == 10  # Default
        assert payload.org_id is None

    def test_valid_task_all_fields(self) -> None:
        """Test validation with all fields specified."""
        payload = TaskPayload.model_validate(
            {
                "target_url": "https://example.com/test",
                "persona_ids": ["malicious_user:2", "nice_user:1"],
                "seed_utterance": "Custom greeting",
                "max_turns": 5,
                "org_id": "org-123",
            }
        )

        assert str(payload.target_url) == "https://example.com/test"
        assert payload.persona_ids == ["malicious_user:2", "nice_user:1"]
        assert payload.seed_utterance == "Custom greeting"
        assert payload.max_turns == 5
        assert payload.org_id == "org-123"

    def test_invalid_url_scheme_http(self) -> None:
        """Test validation accepts http scheme."""
        payload = TaskPayload.model_validate(
            {
                "target_url": "http://localhost:3000",
                "persona_ids": ["nice_user:1"],
            }
        )

        assert str(payload.target_url) == "http://localhost:3000/"

    def test_invalid_url_scheme_ftp(self) -> None:
        """Test validation rejects non-http(s) schemes."""
        with pytest.raises(ValidationError) as exc_info:
            TaskPayload.model_validate(
                {
                    "target_url": "ftp://example.com",
                    "persona_ids": ["malicious_user:1"],
                }
            )

        errors = exc_info.value.errors()
        assert any("target_url" in str(e["loc"]) for e in errors)
        assert any("http" in str(e) for e in errors)

    def test_invalid_url_no_scheme(self) -> None:
        """Test validation rejects URLs without scheme."""
        with pytest.raises(ValidationError) as exc_info:
            TaskPayload.model_validate(
                {
                    "target_url": "example.com",
                    "persona_ids": ["malicious_user:1"],
                }
            )

        errors = exc_info.value.errors()
        assert len(errors) > 0

    def test_invalid_persona_format_missing_count(self) -> None:
        """Test validation accepts persona without count (count is optional)."""
        # Persona format can be just "persona_name" without count
        payload = TaskPayload.model_validate(
            {
                "target_url": "https://example.com",
                "persona_ids": ["malicious_user"],
            }
        )

        assert payload.persona_ids == ["malicious_user"]

    def test_invalid_persona_format_invalid_count(self) -> None:
        """Test validation rejects invalid count format."""
        with pytest.raises(ValidationError) as exc_info:
            TaskPayload.model_validate(
                {
                    "target_url": "https://example.com",
                    "persona_ids": ["malicious_user:invalid"],
                }
            )

        errors = exc_info.value.errors()
        assert len(errors) == 1
        assert "persona_ids" in str(errors[0]["loc"])

    def test_valid_persona_single(self) -> None:
        """Test validation accepts single persona."""
        payload = TaskPayload.model_validate(
            {
                "target_url": "https://example.com",
                "persona_ids": ["malicious_user:1"],
            }
        )

        assert payload.persona_ids == ["malicious_user:1"]

    def test_valid_persona_multiple(self) -> None:
        """Test validation accepts multiple personas."""
        payload = TaskPayload.model_validate(
            {
                "target_url": "https://example.com",
                "persona_ids": ["malicious_user:2", "nice_user:1", "compliance_user:3"],
            }
        )

        assert payload.persona_ids == [
            "malicious_user:2",
            "nice_user:1",
            "compliance_user:3",
        ]

    def test_max_turns_validation(self) -> None:
        """Test max_turns must be positive."""
        with pytest.raises(ValidationError) as exc_info:
            TaskPayload.model_validate(
                {
                    "target_url": "https://example.com",
                    "persona_ids": ["nice_user:1"],
                    "max_turns": 0,
                }
            )

        errors = exc_info.value.errors()
        assert any("max_turns" in str(e["loc"]) for e in errors)

    def test_extra_fields_rejected(self) -> None:
        """Test that extra fields are rejected."""
        with pytest.raises(ValidationError) as exc_info:
            TaskPayload.model_validate(
                {
                    "target_url": "https://example.com",
                    "persona_ids": ["nice_user:1"],
                    "extra_field": "should_fail",
                }
            )

        errors = exc_info.value.errors()
        assert any("extra_field" in str(e) for e in errors)


class TestValidateTask:
    """Test validate_task helper function."""

    def test_validate_task_success(self) -> None:
        """Test validate_task with valid dictionary."""
        task_dict = {
            "target_url": "https://example.com",
            "persona_ids": ["malicious_user:1"],
            "seed_utterance": "Hello",
            "max_turns": 15,
        }

        validated = validate_task(task_dict)

        assert isinstance(validated, TaskPayload)
        assert str(validated.target_url) == "https://example.com/"
        assert validated.persona_ids == ["malicious_user:1"]
        assert validated.max_turns == 15

    def test_validate_task_with_extra_fields(self) -> None:
        """Test validate_task ignores extra fields if configured."""
        task_dict = {
            "target_url": "https://example.com",
            "persona_ids": "nice_user:1",
            "internal_id": "task-123",  # Extra field
            "priority": "high",  # Extra field
        }

        # Should raise because extra fields are forbidden
        with pytest.raises(ValidationError):
            validate_task(task_dict)

    def test_validate_task_invalid_data(self) -> None:
        """Test validate_task raises on invalid data."""
        task_dict = {
            "target_url": "not-a-valid-url",
            "persona_ids": "invalid-format",
        }

        with pytest.raises(ValidationError):
            validate_task(task_dict)

    def test_validate_task_missing_optional_field(self) -> None:
        """Test validate_task works with missing optional fields."""
        task_dict = {
            "target_url": "https://example.com",
            # persona_ids deliberately omitted to test optional behavior
        }

        validated = validate_task(task_dict)
        assert validated.persona_ids is None
        assert str(validated.target_url) == "https://example.com/"
