"""Test progress tracker functionality."""

import json
import tempfile
from pathlib import Path

from utils.progress_tracker import (
    ExecutionStatus,
    OrchestratorPhase,
    ProgressTracker,
)


def test_progress_tracker_basic() -> None:
    """Test basic progress tracker operations."""
    with tempfile.TemporaryDirectory() as tmpdir:
        session_id = "test_session_001"
        org_id = "test_org"

        # Create tracker
        tracker = ProgressTracker(
            session_id=session_id,
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=3,
            org_id=org_id,
        )

        # Check initial state
        assert tracker.orchestrator.status == ExecutionStatus.PENDING
        assert tracker.orchestrator.phase == OrchestratorPhase.INITIALIZING
        assert len(tracker.personas) == 0

        # Update orchestrator to running
        tracker.update_orchestrator(
            status=ExecutionStatus.RUNNING,
            phase=OrchestratorPhase.DISCOVERY,
            last_action="Starting discovery",
        )
        assert tracker.orchestrator.status == ExecutionStatus.RUNNING
        assert tracker.orchestrator.phase == OrchestratorPhase.DISCOVERY

        # Add persona
        tracker.add_persona("malicious_user", "malicious_user_01", total_steps=10)
        assert "malicious_user_01" in tracker.personas
        assert tracker.personas["malicious_user_01"].status == ExecutionStatus.PENDING
        assert tracker.personas["malicious_user_01"].total_steps == 10

        # Update persona
        tracker.update_persona(
            "malicious_user_01",
            status=ExecutionStatus.RUNNING,
            current_step=5,
            last_action="Testing chat interface",
        )
        assert tracker.personas["malicious_user_01"].status == ExecutionStatus.RUNNING
        assert tracker.personas["malicious_user_01"].current_step == 5

        # Check JSON file was created
        progress_file = Path(tmpdir) / "progress.json"
        assert progress_file.exists()

        # Verify JSON structure
        with open(progress_file) as f:
            data = json.load(f)

        assert data["orchestrator"]["phase"] == "discovery"
        assert data["orchestrator"]["status"] == "running"
        assert data["orchestrator"]["org_id"] == "test_org"
        assert data["orchestrator"]["personas"] == {"malicious_user": 1}
        assert "malicious_user_01" in data["personas"]
        assert data["personas"]["malicious_user_01"]["status"] == "running"
        assert data["personas"]["malicious_user_01"]["current_step"] == 5
        assert data["personas"]["malicious_user_01"]["persona_id"] == "malicious_user"
        assert "updated_at" in data


def test_progress_tracker_completion() -> None:
    """Test progress tracker completion flow."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session_002",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
            org_id="test_org",
        )

        # Add and complete a persona
        tracker.add_persona("nice_user", "nice_user_01", total_steps=5)
        tracker.update_persona(
            "nice_user_01",
            status=ExecutionStatus.RUNNING,
            current_step=3,
            transcript_turns=2,
        )
        tracker.update_persona(
            "nice_user_01", status=ExecutionStatus.COMPLETED, current_step=5
        )

        persona = tracker.personas["nice_user_01"]
        assert persona.status == ExecutionStatus.COMPLETED
        assert persona.current_step == 5
        assert persona.completed_at is not None

        # Mark orchestrator complete
        tracker.update_orchestrator(
            status=ExecutionStatus.COMPLETED, phase=OrchestratorPhase.COMPLETE
        )
        assert tracker.orchestrator.status == ExecutionStatus.COMPLETED
        assert tracker.orchestrator.phase == OrchestratorPhase.COMPLETE


def test_progress_tracker_error_handling() -> None:
    """Test progress tracker error handling."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session_003",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
            org_id="test_org",
        )

        # Add persona and mark as failed
        tracker.add_persona("malicious_user", "malicious_user_01", total_steps=10)
        tracker.update_persona(
            "malicious_user_01",
            status=ExecutionStatus.FAILED,
            error="Chat interface not found",
        )

        persona = tracker.personas["malicious_user_01"]
        assert persona.status == ExecutionStatus.FAILED
        assert persona.error == "Chat interface not found"
        assert persona.completed_at is not None  # Failed personas are "completed"

        # Check orchestrator failed counter
        assert tracker.orchestrator.failed_personas == 1


def test_progress_tracker_multiple_personas() -> None:
    """Test progress tracker with multiple personas."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session_004",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=4,
            org_id="test_org",
        )

        # Add multiple personas
        personas = [
            ("malicious_user", "malicious_user_01"),
            ("malicious_user", "malicious_user_02"),
            ("nice_user", "nice_user_01"),
            ("compliance_user", "compliance_user_01"),
        ]

        for persona_id, instance_name in personas:
            tracker.add_persona(persona_id, instance_name, total_steps=5)

        assert len(tracker.personas) == 4

        # Verify persona counts
        assert tracker.orchestrator.personas == {
            "malicious_user": 2,
            "nice_user": 1,
            "compliance_user": 1,
        }

        # Complete some, fail others
        tracker.update_persona(
            "malicious_user_01", status=ExecutionStatus.COMPLETED, current_step=10
        )
        tracker.update_persona(
            "malicious_user_02", status=ExecutionStatus.COMPLETED, current_step=10
        )
        tracker.update_persona(
            "nice_user_01", status=ExecutionStatus.FAILED, error="Timeout"
        )
        tracker.update_persona(
            "compliance_user_01", status=ExecutionStatus.RUNNING, current_step=5
        )

        assert tracker.orchestrator.completed_personas == 2
        assert tracker.orchestrator.failed_personas == 1


if __name__ == "__main__":
    # Run tests
    print("Testing progress tracker...")
    test_progress_tracker_basic()
    print("✓ Basic operations test passed")

    test_progress_tracker_completion()
    print("✓ Completion flow test passed")

    test_progress_tracker_error_handling()
    print("✓ Error handling test passed")

    test_progress_tracker_multiple_personas()
    print("✓ Multiple personas test passed")

    print("\n✅ All progress tracker tests passed!")
