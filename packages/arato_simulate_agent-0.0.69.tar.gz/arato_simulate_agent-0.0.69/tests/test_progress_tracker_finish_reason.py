"""Tests for finish_reason tracking in progress tracker."""

import json
from pathlib import Path
from tempfile import TemporaryDirectory

from utils.progress_tracker import (
    ExecutionStatus,
    FinishReason,
    ProgressTracker,
)


def test_finish_reason_on_completion() -> None:
    """Test that finish_reason is set when persona completes."""
    with TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
        )

        # Add a persona
        tracker.add_persona("nice_user", "nice_user_01", total_steps=10)

        # Complete with reached_max_turns reason
        tracker.update_persona(
            "nice_user_01",
            status=ExecutionStatus.COMPLETED,
            current_step=10,
            finish_reason=FinishReason.REACHED_MAX_TURNS,
        )

        persona = tracker.personas["nice_user_01"]
        assert persona.status == ExecutionStatus.COMPLETED
        assert persona.finish_reason == FinishReason.REACHED_MAX_TURNS
        assert persona.progress.completion_percentage == 100.0


def test_finish_reason_on_early_completion() -> None:
    """Test that completion is 100% even when finishing early."""
    with TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
        )

        # Add a persona with 10 total steps
        tracker.add_persona("malicious_user", "malicious_user_01", total_steps=5)

        # Complete early at step 4 due to timeout
        tracker.update_persona(
            "malicious_user_01",
            status=ExecutionStatus.COMPLETED,
            current_step=4,
            finish_reason=FinishReason.TIMEOUT,
        )

        persona = tracker.personas["malicious_user_01"]
        assert persona.status == ExecutionStatus.COMPLETED
        assert persona.current_step == 4
        assert persona.finish_reason == FinishReason.TIMEOUT
        # Should still show 100% completion
        assert persona.progress.completion_percentage == 100.0


def test_finish_reason_on_failure() -> None:
    """Test that finish_reason is automatically set to ERROR on failure."""
    with TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
        )

        # Add a persona
        tracker.add_persona("compliance_user", "compliance_user_01", total_steps=5)

        # Fail with error
        tracker.update_persona(
            "compliance_user_01",
            status=ExecutionStatus.FAILED,
            error="Something went wrong",
        )

        persona = tracker.personas["compliance_user_01"]
        assert persona.status == ExecutionStatus.FAILED
        # Should auto-set finish reason to ERROR
        assert persona.finish_reason == FinishReason.ERROR
        # Should still show 100% completion (failed counts as finished)
        assert persona.progress.completion_percentage == 100.0


def test_finish_reason_in_progress_json() -> None:
    """Test that finish_reason is included in progress.json output."""
    with TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
        )

        tracker.add_persona("nice_user", "nice_user_01", total_steps=5)
        tracker.update_persona(
            "nice_user_01",
            status=ExecutionStatus.COMPLETED,
            current_step=5,
            finish_reason=FinishReason.AGENT_STOPPED,
        )

        # Read progress.json
        progress_file = Path(tmpdir) / "progress.json"
        with open(progress_file) as f:
            data = json.load(f)

        persona_data = data["personas"]["nice_user_01"]
        assert persona_data["finish_reason"] == "agent_stopped"
        assert persona_data["completion_percentage"] == 100.0


def test_in_progress_capped_at_99_percent() -> None:
    """Test that in-progress personas are capped at 99%."""
    with TemporaryDirectory() as tmpdir:
        tracker = ProgressTracker(
            session_id="test_session",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
        )

        tracker.add_persona("nice_user", "nice_user_01", total_steps=10)

        # Update to 100% of steps but not completed
        tracker.update_persona("nice_user_01", current_step=10)

        persona = tracker.personas["nice_user_01"]
        assert persona.status == ExecutionStatus.PENDING
        # Should be capped at 99% until marked completed
        assert persona.progress.completion_percentage == 99.0

        # Now mark as completed
        tracker.update_persona(
            "nice_user_01",
            status=ExecutionStatus.COMPLETED,
            finish_reason=FinishReason.REACHED_MAX_TURNS,
        )

        # Now should be 100%
        assert persona.progress.completion_percentage == 100.0
