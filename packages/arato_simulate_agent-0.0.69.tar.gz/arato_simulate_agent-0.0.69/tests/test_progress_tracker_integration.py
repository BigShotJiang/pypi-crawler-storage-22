"""Test progress tracker integration with chat runner."""

import inspect
import json
import tempfile
from pathlib import Path

import pytest

from utils.progress_tracker import ExecutionStatus, ProgressTracker


@pytest.mark.asyncio
async def test_progress_tracker_per_turn_updates() -> None:
    """Test that progress tracker updates on each conversation turn."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a progress tracker
        tracker = ProgressTracker(
            session_id="test_session_001",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
            org_id="test_org",
        )

        # Add a persona
        tracker.add_persona("malicious_user", "malicious_user_01", total_steps=5)

        # Simulate conversation turns
        tracker.update_persona(
            instance_name="malicious_user_01",
            status=ExecutionStatus.RUNNING,
            current_step=1,
            transcript_turns=1,
            last_action="Completed turn 1/5",
        )

        # Check progress file after turn 1
        progress_file = Path(tmpdir) / "progress.json"
        assert progress_file.exists()

        with open(progress_file) as f:
            data = json.load(f)

        assert data["personas"]["malicious_user_01"]["current_step"] == 1
        assert data["personas"]["malicious_user_01"]["transcript_turns"] == 1
        assert data["personas"]["malicious_user_01"]["status"] == "running"

        # Simulate turn 2
        tracker.update_persona(
            instance_name="malicious_user_01",
            current_step=2,
            transcript_turns=2,
            last_action="Completed turn 2/5",
        )

        with open(progress_file) as f:
            data = json.load(f)

        assert data["personas"]["malicious_user_01"]["current_step"] == 2
        assert data["personas"]["malicious_user_01"]["transcript_turns"] == 2

        # Simulate turn 3
        tracker.update_persona(
            instance_name="malicious_user_01",
            current_step=3,
            transcript_turns=3,
            last_action="Completed turn 3/5",
        )

        with open(progress_file) as f:
            data = json.load(f)

        assert data["personas"]["malicious_user_01"]["current_step"] == 3
        assert data["personas"]["malicious_user_01"]["transcript_turns"] == 3

        # Complete the conversation
        tracker.update_persona(
            instance_name="malicious_user_01",
            status=ExecutionStatus.COMPLETED,
            current_step=5,
            transcript_turns=5,
            last_action="Conversation completed successfully",
        )

        with open(progress_file) as f:
            data = json.load(f)

        assert data["personas"]["malicious_user_01"]["status"] == "completed"
        assert data["personas"]["malicious_user_01"]["current_step"] == 5
        assert data["personas"]["malicious_user_01"]["transcript_turns"] == 5
        assert data["personas"]["malicious_user_01"]["completed_at"] is not None


@pytest.mark.asyncio
async def test_chat_runner_accepts_progress_tracker() -> None:
    """Test that chat runner accepts progress_tracker parameter."""
    from agents.chat_runner import ChatRunner

    # Verify the run_conversation method signature includes progress_tracker
    runner = ChatRunner(headless=True)
    sig = inspect.signature(runner.run_conversation)

    # Check that progress_tracker is in the parameters
    assert "progress_tracker" in sig.parameters, "progress_tracker parameter missing"

    # Verify it's optional (has default value)
    param = sig.parameters["progress_tracker"]
    assert param.default is None, "progress_tracker should default to None"


@pytest.mark.asyncio
async def test_progress_tracker_completion_tracking() -> None:
    """Test progress completion percentage calculation."""
    import time

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a progress tracker
        tracker = ProgressTracker(
            session_id="test_session_003",
            target_url="https://example.com",
            output_dir=tmpdir,
            total_personas=1,
            org_id="test_org",
        )

        # Add a persona with 5 total steps
        tracker.add_persona("nice_user", "nice_user_01", total_steps=5)
        tracker.update_persona(
            instance_name="nice_user_01", status=ExecutionStatus.RUNNING
        )

        # Simulate 3 turns with timing
        for turn in range(1, 4):
            # Simulate some work
            time.sleep(0.1)

            # Record turn completion
            tracker.record_persona_turn(
                instance_name="nice_user_01",
                turn_number=turn,
                current_step=turn,
            )

        # Check progress file
        progress_file = Path(tmpdir) / "progress.json"
        with open(progress_file) as f:
            data = json.load(f)

        persona_data = data["personas"]["nice_user_01"]

        # Verify progress estimation (flattened by PersonaProgress.to_dict())
        assert persona_data["completion_percentage"] == 60.0  # 3/5 = 60%


if __name__ == "__main__":
    import asyncio

    print("Testing per-turn progress tracking...")
    asyncio.run(test_progress_tracker_per_turn_updates())
    print("✓ Per-turn updates test passed")

    print("\nTesting chat runner integration...")
    asyncio.run(test_chat_runner_accepts_progress_tracker())
    print("✓ Chat runner integration test passed")

    print("\nTesting completion tracking...")
    asyncio.run(test_progress_tracker_completion_tracking())
    print("✓ Completion tracking test passed")

    print("\n✅ All integration tests passed!")
