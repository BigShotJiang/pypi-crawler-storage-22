"""
Test progress tracker S3 upload throttling.
"""

import time
from unittest.mock import MagicMock, patch

import pytest

from utils.progress_tracker import ExecutionStatus, OrchestratorPhase, ProgressTracker


@pytest.fixture
def mock_background_uploader():
    """Mock background uploader for testing."""
    with patch("utils.progress_tracker._background_uploader") as mock:
        mock.enqueue = MagicMock()
        yield mock


def test_upload_throttling(tmpdir, mock_background_uploader):
    """Test that S3 uploads are throttled to once every 10 seconds."""
    # Create progress tracker
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # Initial upload happens immediately (force=True in __init__)
    assert mock_background_uploader.enqueue.call_count == 1

    # Reset call count
    mock_background_uploader.enqueue.reset_mock()

    # Multiple rapid updates should NOT trigger uploads (throttled)
    tracker.update_orchestrator(last_action="Action 1")
    tracker.update_orchestrator(last_action="Action 2")
    tracker.update_orchestrator(last_action="Action 3")

    # No uploads should have happened (throttled)
    assert mock_background_uploader.enqueue.call_count == 0
    assert tracker._pending_s3_upload is True

    # Wait for throttle interval to pass
    time.sleep(11)  # Wait > 10 seconds

    # Next update should trigger upload
    tracker.update_orchestrator(last_action="Action 4")
    assert mock_background_uploader.enqueue.call_count == 1
    assert tracker._pending_s3_upload is False


def test_forced_upload_on_completion(tmpdir, mock_background_uploader):
    """Test that completion/failure forces immediate upload regardless of throttle."""
    # Create progress tracker
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # Reset call count after initial upload
    mock_background_uploader.enqueue.reset_mock()

    # Multiple rapid updates (throttled)
    tracker.update_orchestrator(last_action="Action 1")
    tracker.update_orchestrator(last_action="Action 2")
    assert mock_background_uploader.enqueue.call_count == 0

    # Completion should force immediate upload
    tracker.update_orchestrator(
        status=ExecutionStatus.COMPLETED, phase=OrchestratorPhase.COMPLETE
    )
    assert mock_background_uploader.enqueue.call_count == 1


def test_flush_pending_upload(tmpdir, mock_background_uploader):
    """Test that flush_pending_upload forces upload of pending changes."""
    # Create progress tracker
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # Reset call count after initial upload
    mock_background_uploader.enqueue.reset_mock()

    # Rapid updates (throttled)
    tracker.update_orchestrator(last_action="Action 1")
    tracker.update_orchestrator(last_action="Action 2")
    assert mock_background_uploader.enqueue.call_count == 0
    assert tracker._pending_s3_upload is True

    # Flush should force upload
    tracker.flush_pending_upload()
    assert mock_background_uploader.enqueue.call_count == 1
    assert tracker._pending_s3_upload is False


def test_persona_completion_forces_upload(tmpdir, mock_background_uploader):
    """Test that persona completion forces immediate upload."""
    # Create progress tracker
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # Add persona
    tracker.add_persona("test_persona", "test_persona_01", total_steps=10)

    # Reset call count
    mock_background_uploader.enqueue.reset_mock()

    # Multiple rapid turn updates (throttled)
    tracker.record_persona_turn("test_persona_01", turn_number=1, current_step=1)
    tracker.record_persona_turn("test_persona_01", turn_number=2, current_step=2)
    tracker.record_persona_turn("test_persona_01", turn_number=3, current_step=3)

    # Should be throttled
    assert mock_background_uploader.enqueue.call_count == 0

    # Marking complete should force upload
    tracker.update_persona(
        instance_name="test_persona_01",
        status=ExecutionStatus.COMPLETED,
        current_step=10,
    )
    assert mock_background_uploader.enqueue.call_count == 1


def test_persona_failure_forces_upload(tmpdir, mock_background_uploader):
    """Test that persona failure forces immediate upload."""
    # Create progress tracker
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # Add persona
    tracker.add_persona("test_persona", "test_persona_01", total_steps=10)

    # Reset call count
    mock_background_uploader.enqueue.reset_mock()

    # Marking failed should force upload
    tracker.update_persona(
        instance_name="test_persona_01",
        status=ExecutionStatus.FAILED,
        error="Test error",
    )
    assert mock_background_uploader.enqueue.call_count == 1


# --- Local file write throttling tests ---


def test_schedule_write_throttles_rapid_calls(tmpdir, mock_background_uploader):  # noqa: ARG001
    """Test that _schedule_write only writes once per _write_min_interval."""
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # Count how many times _write_progress is called via patch
    with patch.object(
        tracker, "_write_progress", wraps=tracker._write_progress
    ) as mock_write:
        # Multiple rapid _schedule_write calls should result in at most 1 write
        for _ in range(50):
            tracker._schedule_write()

        assert mock_write.call_count <= 1, (
            f"Expected at most 1 write from rapid _schedule_write calls, got {mock_write.call_count}"
        )


def test_flush_write_writes_when_dirty(tmpdir, mock_background_uploader):  # noqa: ARG001
    """Test that _flush_write writes when dirty, skips when clean."""
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    with patch.object(
        tracker, "_write_progress", wraps=tracker._write_progress
    ) as mock_write:
        # _flush_write with dirty=True should write each time
        tracker._dirty = True
        tracker._flush_write()
        tracker._dirty = True
        tracker._flush_write()
        tracker._dirty = True
        tracker._flush_write()

        assert mock_write.call_count == 3, (
            f"Expected 3 writes from dirty _flush_write calls, got {mock_write.call_count}"
        )

        # Without setting dirty, _flush_write should skip
        tracker._flush_write()
        assert mock_write.call_count == 3, (
            f"Expected no extra write when not dirty, got {mock_write.call_count}"
        )


def test_completion_forces_write_not_throttled(tmpdir, mock_background_uploader):  # noqa: ARG001
    """Test that persona completion uses _flush_write, not throttled _schedule_write."""
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    tracker.add_persona("test_persona", "test_persona_01", total_steps=5)

    # Read progress.json to verify state is written
    import json

    with open(tracker.progress_file) as f:
        data = json.load(f)
    assert "test_persona_01" in data["personas"]
    assert data["personas"]["test_persona_01"]["status"] == "pending"

    # Complete persona - should be written to disk immediately
    tracker.update_persona(
        instance_name="test_persona_01",
        status=ExecutionStatus.COMPLETED,
        current_step=5,
    )

    with open(tracker.progress_file) as f:
        data = json.load(f)
    assert data["personas"]["test_persona_01"]["status"] == "completed"


def test_flush_write_skips_when_not_dirty(tmpdir, mock_background_uploader):  # noqa: ARG001
    """Test that _flush_write skips disk write when _dirty is False."""
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # Simulate a prior write so _last_write_time > 0
    import time

    tracker._last_write_time = time.time()
    tracker._dirty = False

    with patch.object(
        tracker, "_write_progress", wraps=tracker._write_progress
    ) as mock_write:
        # _flush_write should skip because _dirty is False
        tracker._flush_write()
        assert mock_write.call_count == 0

        # Mark dirty, then flush should write
        tracker._dirty = True
        tracker._flush_write()
        assert mock_write.call_count == 1
        assert tracker._dirty is False


def test_schedule_write_sets_dirty_flag(tmpdir, mock_background_uploader):  # noqa: ARG001
    """Test that _schedule_write sets _dirty and respects the throttle interval."""
    tracker = ProgressTracker(
        session_id="test_session",
        target_url="https://example.com",
        output_dir=str(tmpdir),
        total_personas=1,
    )

    # After init, dirty is False
    assert tracker._dirty is False

    # Calling _schedule_write within the throttle window sets dirty but doesn't flush
    import time

    tracker._last_write_time = time.time()  # Pretend we just wrote
    tracker._dirty = False
    tracker._schedule_write()
    assert tracker._dirty is True  # Dirty flag was set
