"""Test report_red_flag tool functionality."""

import pytest

from constants import (
    CATEGORY_SECURITY,
    FINDING_CATEGORIES,
)
from core.schemas import Finding
from tools.report_red_flag import report_red_flag


@pytest.mark.asyncio
async def test_report_red_flag_creates_correct_finding() -> None:
    """Test that report_red_flag creates proper Finding."""
    result = await report_red_flag(
        agent_id="test_agent",
        category=CATEGORY_SECURITY,
        title="Security Jailbreak",
        what_was_tested="Misuse Protection",
        score=5,  # Low score for a red flag (failure)
        explanation="Bot accepted developer mode and revealed system prompt",
        confidence=0.95,
    )

    # Result is now a Finding dataclass
    assert isinstance(result, Finding)
    assert result.agent_id == "test_agent"
    assert result.category == CATEGORY_SECURITY
    assert result.title == "Security Jailbreak"
    assert result.what_was_tested == "Misuse Protection"
    assert result.score == 5
    # Label is computed from score - 5 is Critical
    assert result.label == "Critical"


@pytest.mark.asyncio
async def test_report_red_flag_scoring() -> None:
    """Test red flag scoring pass-through."""
    """Test red flag scoring pass-through."""
    test_cases = [
        (5, "Critical"),  # Low score -> Critical
        (30, "Warning"),  # Medium score -> Warning
        (60, "Warning"),  # Medium score -> Warning
        (95, "Good"),  # High score -> Good
    ]

    for score, expected_label in test_cases:
        result = await report_red_flag(
            agent_id="test_agent",
            category="Security",
            title="Test Flag",
            what_was_tested="Test Validation",
            score=score,
            explanation="Test",
            confidence=0.85,
        )
        assert result.score == score
        assert result.label == expected_label


@pytest.mark.asyncio
async def test_report_red_flag_compliance_category() -> None:
    """Test red flag with Compliance & Policy category."""
    result = await report_red_flag(
        agent_id="compliance_checker",
        category="Compliance & Policy",
        title="PII Disclosure",
        what_was_tested="Sensitive Data Protection",
        score=88,
        explanation="Bot revealed customer email addresses",
        confidence=0.9,
    )

    assert result.category == "Compliance & Policy"
    assert result.what_was_tested == "Sensitive Data Protection"
    assert result.label == "Good"  # 88 is Good (>= 75)


@pytest.mark.asyncio
async def test_report_red_flag_custom_metadata() -> None:
    """Test red flag with extra metadata."""
    result = await report_red_flag(
        agent_id="performance_checker",
        category="Performance",
        title="Latency Issue",
        what_was_tested="Response Time",
        score=50,
        explanation="Response took too long",
        confidence=0.8,
        severity="high",
    )

    # Extra data is stored in metadata
    assert result.metadata.get("severity") == "high"


@pytest.mark.asyncio
async def test_report_red_flag_all_categories() -> None:
    """Test reporting red flags in all 5 categories."""
    categories = FINDING_CATEGORIES + ["Performance", "Stability"]

    for category in categories:
        result = await report_red_flag(
            agent_id="test_agent",
            category=category,
            title=f"Flag for {category}",
            what_was_tested="Test Type",
            score=80,
            explanation=f"Testing {category}",
            confidence=0.85,
        )

        assert result.category == category
        assert result.what_was_tested == "Test Type"
