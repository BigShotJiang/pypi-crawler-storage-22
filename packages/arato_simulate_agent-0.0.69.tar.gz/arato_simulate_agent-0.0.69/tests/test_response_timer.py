#!/usr/bin/env python3
"""Tests for the response timer tool."""

from tools.response_timer import ResponseTimer


class TestResponseTimer:
    """Test suite for ResponseTimer."""

    def test_start_timer(self) -> None:
        """Test starting the timer."""
        timer = ResponseTimer()
        result = timer.start_timer(1)

        assert "✓" in result
        assert "turn 1" in result.lower()
        assert timer._start_time is not None

    def test_stop_timer_without_start(self) -> None:
        """Test stopping timer without starting it first."""
        timer = ResponseTimer()
        result = timer.stop_timer(1)

        assert "❌" in result
        assert "not started" in result.lower()

    def test_complete_measurement(self) -> None:
        """Test a complete start-stop cycle."""
        import time

        timer = ResponseTimer()

        # Start timer
        start_result = timer.start_timer(1)
        assert "✓" in start_result

        # Simulate some delay
        time.sleep(0.1)

        # Stop timer
        stop_result = timer.stop_timer(1)
        assert "✓" in stop_result
        assert "latency measured" in stop_result.lower()

        # Check measurements
        measurements = timer.get_measurements()
        assert len(measurements) == 1
        assert measurements[0]["turn_number"] == 1
        assert measurements[0]["ttlt_seconds"] >= 0.1
        assert measurements[0]["ttlt_seconds"] < 0.2  # Should be close to 0.1s

    def test_multiple_measurements(self) -> None:
        """Test multiple measurement cycles."""
        import time

        timer = ResponseTimer()

        # First turn
        timer.start_timer(1)
        time.sleep(0.05)
        timer.stop_timer(1)

        # Second turn
        timer.start_timer(2)
        time.sleep(0.1)
        timer.stop_timer(2)

        # Third turn
        timer.start_timer(3)
        time.sleep(0.15)
        timer.stop_timer(3)

        measurements = timer.get_measurements()
        assert len(measurements) == 3
        assert measurements[0]["turn_number"] == 1
        assert measurements[1]["turn_number"] == 2
        assert measurements[2]["turn_number"] == 3

    def test_get_statistics(self) -> None:
        """Test statistics calculation."""
        import time

        timer = ResponseTimer()

        # Create measurements with known latencies
        for turn in range(1, 4):
            timer.start_timer(turn)
            time.sleep(0.05 * turn)  # 0.05s, 0.1s, 0.15s
            timer.stop_timer(turn)

        stats = timer.get_statistics()
        assert stats["count"] == 3
        assert stats["min_latency"] >= 0.05
        assert stats["max_latency"] >= 0.15
        assert stats["avg_latency"] >= 0.1
        assert stats["median_latency"] >= 0.1

    def test_empty_statistics(self) -> None:
        """Test statistics with no measurements."""
        timer = ResponseTimer()
        stats = timer.get_statistics()

        assert stats["count"] == 0
        assert stats["min_latency"] is None
        assert stats["max_latency"] is None
        assert stats["avg_latency"] is None
        assert stats["median_latency"] is None

    def test_reset(self) -> None:
        """Test resetting the timer."""
        import time

        timer = ResponseTimer()

        # Make some measurements
        timer.start_timer(1)
        time.sleep(0.05)
        timer.stop_timer(1)

        assert len(timer.get_measurements()) == 1

        # Reset
        timer.reset()

        assert len(timer.get_measurements()) == 0
        assert timer._start_time is None

        stats = timer.get_statistics()
        assert stats["count"] == 0

    def test_timer_state_after_stop(self) -> None:
        """Test that timer is reset after stop."""
        import time

        timer = ResponseTimer()

        timer.start_timer(1)
        time.sleep(0.05)
        timer.stop_timer(1)

        # Timer should be reset
        assert timer._start_time is None

        # Should be able to start again immediately
        result = timer.start_timer(2)
        assert "✓" in result
        assert timer._start_time is not None
