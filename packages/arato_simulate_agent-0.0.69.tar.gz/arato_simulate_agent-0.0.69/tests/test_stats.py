"""Unit tests for statistics utilities."""

from utils.stats import calculate_dynamic_distribution, calculate_latency_statistics


class TestCalculateLatencyStatistics:
    """Test suite for calculate_latency_statistics function."""

    def test_empty_measurements(self) -> None:
        """Test statistics calculation with empty measurements."""
        stats = calculate_latency_statistics([])

        assert stats["count"] == 0
        assert stats["min_latency"] == 0.0
        assert stats["max_latency"] == 0.0
        assert stats["avg_latency"] == 0.0
        assert stats["median_latency"] == 0.0

    def test_single_measurement(self) -> None:
        """Test statistics calculation with single measurement."""
        measurements = [{"latency_seconds": 1.5}]
        stats = calculate_latency_statistics(measurements)

        assert stats["count"] == 1
        assert stats["min_latency"] == 1.5
        assert stats["max_latency"] == 1.5
        assert stats["avg_latency"] == 1.5
        assert stats["median_latency"] == 1.5

    def test_odd_number_measurements(self) -> None:
        """Test statistics calculation with odd number of measurements."""
        measurements = [
            {"latency_seconds": 1.0},
            {"latency_seconds": 2.0},
            {"latency_seconds": 3.0},
        ]
        stats = calculate_latency_statistics(measurements)

        assert stats["count"] == 3
        assert stats["min_latency"] == 1.0
        assert stats["max_latency"] == 3.0
        assert stats["avg_latency"] == 2.0
        assert stats["median_latency"] == 2.0  # Middle value

    def test_even_number_measurements(self) -> None:
        """Test statistics calculation with even number of measurements."""
        measurements = [
            {"latency_seconds": 1.0},
            {"latency_seconds": 2.0},
            {"latency_seconds": 3.0},
            {"latency_seconds": 4.0},
        ]
        stats = calculate_latency_statistics(measurements)

        assert stats["count"] == 4
        assert stats["min_latency"] == 1.0
        assert stats["max_latency"] == 4.0
        assert stats["avg_latency"] == 2.5
        assert stats["median_latency"] == 2.5  # Average of middle two

    def test_rounding(self) -> None:
        """Test that statistics are rounded to 3 decimal places."""
        measurements = [
            {"latency_seconds": 1.123456789},
            {"latency_seconds": 2.987654321},
        ]
        stats = calculate_latency_statistics(measurements)

        # Check rounding to 3 decimal places
        assert stats["min_latency"] == 1.123
        assert stats["max_latency"] == 2.988
        assert stats["avg_latency"] == 2.056
        assert stats["median_latency"] == 2.056


class TestCalculateDynamicDistribution:
    """Test suite for calculate_dynamic_distribution function."""

    def test_dynamic_distribution_nice_buckets(self) -> None:
        """Test distribution buckets are rounded to nice numbers."""
        # range ~ 9660 -> should pick step 1000
        values: list[float | int] = [49, 1000, 2000, 9709]

        dist = calculate_dynamic_distribution(values)
        keys = list(dist.keys())

        # Verify keys are nice labeled ranges
        assert "0-1000" in keys
        assert "1000-2000" in keys
        assert "9000-10000" in keys

        # Verify counts
        assert dist["0-1000"] == 1
        assert dist["1000-2000"] == 1
        assert dist["2000-3000"] == 1
        assert dist["9000-10000"] == 1

    def test_dynamic_distribution_small_numbers(self) -> None:
        """Test distribution calculation with small float values."""
        values = [0.12, 0.25, 0.8]

        dist = calculate_dynamic_distribution(values)
        keys = list(dist.keys())

        # Should contain formatted float ranges
        assert any("." in k for k in keys)

        # Ensure buckets cover the range
        min_key_start = float(keys[0].split("-")[0])
        max_key_end = float(keys[-1].split("-")[1])

        assert min_key_start <= 0.12
        assert max_key_end >= 0.8
