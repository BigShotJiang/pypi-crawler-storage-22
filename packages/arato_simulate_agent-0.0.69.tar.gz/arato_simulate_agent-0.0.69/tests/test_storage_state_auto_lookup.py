"""Test automatic storage_state lookup in ChatRunner."""

from agents.chat_runner import ChatRunner


def test_auto_lookup_storage_state_found() -> None:
    """Test that auto-lookup finds existing auth file."""
    # Create auth_states directory with test file in current directory
    from pathlib import Path

    auth_dir = Path("auth_states")
    auth_dir.mkdir(exist_ok=True)
    auth_file = auth_dir / "auth_example.com.json"
    auth_file.write_text('{"cookies": []}')

    try:
        # Test lookup
        result = ChatRunner._auto_lookup_storage_state("https://example.com/test")

        # Should find the file
        assert result is not None
        assert "auth_example.com.json" in result
    finally:
        # Cleanup
        if auth_file.exists():
            auth_file.unlink()
        if auth_dir.exists() and not list(auth_dir.iterdir()):
            auth_dir.rmdir()


def test_auto_lookup_storage_state_not_found() -> None:
    """Test that auto-lookup returns None when file doesn't exist."""
    result = ChatRunner._auto_lookup_storage_state("https://nonexistent.com/test")
    assert result is None


def test_auto_lookup_storage_state_invalid_url() -> None:
    """Test that auto-lookup handles invalid URLs gracefully."""
    result = ChatRunner._auto_lookup_storage_state("")
    assert result is None


def test_auto_lookup_storage_state_with_port() -> None:
    """Test that auto-lookup handles URLs with ports."""
    # This test documents expected behavior:
    # Domain with port "example.com:8080" becomes "example.com_8080"
    result = ChatRunner._auto_lookup_storage_state("https://example.com:8080/test")
    # Returns None if file doesn't exist, which is expected
    assert result is None


def test_chat_runner_stores_storage_state() -> None:
    """Test that ChatRunner stores storage_state parameter."""
    runner = ChatRunner(headless=True, storage_state="/path/to/auth.json")
    assert runner.storage_state == "/path/to/auth.json"


def test_chat_runner_storage_state_defaults_to_none() -> None:
    """Test that storage_state defaults to None."""
    runner = ChatRunner(headless=True)
    assert runner.storage_state is None
