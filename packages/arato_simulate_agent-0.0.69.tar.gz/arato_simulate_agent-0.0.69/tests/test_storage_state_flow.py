"""Test that storage_state parameter flows through the entire call chain."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from platforms.local.adapter import LocalPlatformAdapter


@pytest.mark.asyncio
async def test_storage_state_flows_through_pipeline() -> None:
    """Test that storage_state parameter flows through the entire call chain."""
    # Create adapter with mocked AWS validation
    with patch(
        "platforms.local.adapter.LocalPlatformAdapter._validate_aws_credentials"
    ):
        adapter = LocalPlatformAdapter(storage_dir="/tmp/test_storage")

        # Mock GraphOrchestrator at the point where it's imported in the adapter
        with patch(
            "agents.graph_orchestrator.GraphOrchestrator"
        ) as mock_orchestrator_class:
            mock_orchestrator_instance = MagicMock()
            mock_orchestrator_instance.run_pipeline = AsyncMock(
                return_value={
                    "status": "completed",
                    "session_id": "test_session",
                    "artifacts": {},
                }
            )
            mock_orchestrator_class.return_value = mock_orchestrator_instance

            # Run pipeline with storage_state
            result = await adapter.run_pipeline(
                target_url="https://example.com", storage_state="/path/to/auth.json"
            )

            # Verify orchestrator was created with storage_state
            mock_orchestrator_class.assert_called_once()
            call_kwargs = mock_orchestrator_class.call_args[1]
            assert call_kwargs["storage_state"] == "/path/to/auth.json"

            # Verify pipeline executed
            assert result["status"] == "completed"


@pytest.mark.asyncio
async def test_storage_state_none_by_default() -> None:
    """Test that storage_state defaults to None."""
    with patch(
        "platforms.local.adapter.LocalPlatformAdapter._validate_aws_credentials"
    ):
        adapter = LocalPlatformAdapter(storage_dir="/tmp/test_storage")

        with patch(
            "agents.graph_orchestrator.GraphOrchestrator"
        ) as mock_orchestrator_class:
            mock_orchestrator_instance = MagicMock()
            mock_orchestrator_instance.run_pipeline = AsyncMock(
                return_value={"status": "completed"}
            )
            mock_orchestrator_class.return_value = mock_orchestrator_instance

            # Run pipeline WITHOUT storage_state
            await adapter.run_pipeline(target_url="https://example.com")

        # Verify orchestrator was created with storage_state=None
        mock_orchestrator_class.assert_called_once()
        call_kwargs = mock_orchestrator_class.call_args[1]
        assert call_kwargs["storage_state"] is None


@pytest.mark.asyncio
async def test_orchestrator_accepts_storage_state_parameter() -> None:
    """Test that orchestrator accepts storage_state in __init__."""
    from agents.graph_orchestrator import GraphOrchestrator

    # Create orchestrator with storage_state
    orchestrator = GraphOrchestrator(headless=True, storage_state="/path/to/auth.json")

    # Verify storage_state was stored
    assert orchestrator.storage_state == "/path/to/auth.json"


@pytest.mark.asyncio
async def test_chat_runner_accepts_storage_state_parameter() -> None:
    """Test that ChatRunner accepts storage_state in __init__."""
    from agents.chat_runner import ChatRunner

    # Create chat runner with storage_state
    runner = ChatRunner(headless=True, storage_state="/path/to/auth.json")

    # Verify storage_state was stored
    assert runner.storage_state == "/path/to/auth.json"
