"""Tests for URL utility functions."""

from utils.url_utils import extract_domain_pattern, get_domain_from_url


class TestGetDomainFromUrl:
    """Test domain extraction for filesystem use."""

    def test_basic_url(self) -> None:
        """Test basic URL extraction."""
        assert get_domain_from_url("https://example.com/chat") == "example.com"

    def test_url_with_port(self) -> None:
        """Test URL with port removal."""
        assert get_domain_from_url("https://example.com:8080/chat") == "example.com"

    def test_subdomain(self) -> None:
        """Test subdomain preservation."""
        assert get_domain_from_url("https://sub.example.com") == "sub.example.com"

    def test_ngrok_url(self) -> None:
        """Test ngrok-style URL."""
        assert (
            get_domain_from_url("https://f34031b167cd.ngrok-free.app")
            == "f34031b167cd.ngrok-free.app"
        )


class TestExtractDomainPattern:
    """Test domain pattern extraction from URLs."""

    def test_basic_url(self) -> None:
        """Test basic URL extraction."""
        assert extract_domain_pattern("https://example.com/path") == [
            "example.com",
            "*.example.com",
        ]

    def test_subdomain_url(self) -> None:
        """Test subdomain URL extraction."""
        assert extract_domain_pattern("http://subdomain.example.com") == [
            "subdomain.example.com",
            "*.subdomain.example.com",
            "*.example.com",
        ]

    def test_github_url(self) -> None:
        """Test GitHub API URL extraction."""
        assert extract_domain_pattern("https://api.github.com/repos") == [
            "api.github.com",
            "*.api.github.com",
            "*.github.com",
        ]

    def test_www_prefix(self) -> None:
        """Test URL with www prefix."""
        assert extract_domain_pattern("https://www.example.com/page") == [
            "example.com",
            "*.example.com",
        ]

    def test_complex_subdomain(self) -> None:
        """Test URL with multiple subdomain levels."""
        assert extract_domain_pattern("https://api.v2.example.com/endpoint") == [
            "api.v2.example.com",
            "*.api.v2.example.com",
            "*.v2.example.com",
            "*.example.com",
        ]

    def test_port_in_url(self) -> None:
        """Test URL with port number."""
        assert extract_domain_pattern("http://example.com:8080/path") == [
            "example.com",
            "*.example.com",
        ]

    def test_lovable_app_url(self) -> None:
        """Test lovable.app URL (real-world example)."""
        assert extract_domain_pattern("https://nimble-chat-logistics.lovable.app/") == [
            "nimble-chat-logistics.lovable.app",
            "*.nimble-chat-logistics.lovable.app",
            "*.lovable.app",
        ]
