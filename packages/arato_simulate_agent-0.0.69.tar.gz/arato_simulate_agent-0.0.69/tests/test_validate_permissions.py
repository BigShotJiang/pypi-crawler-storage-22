"""Tests for the AgentCore permission validator."""

from __future__ import annotations

from typing import Any, cast

from platforms.aws_agentcore.scripts import validate_permissions


def test_build_permissions_policy_contains_required_actions() -> None:
    policy = validate_permissions.build_permissions_policy("test-bucket")

    statements = cast(list[dict[str, Any]], policy["Statement"])
    assert len(statements) == 4

    browser_statement = statements[0]
    s3_statement = statements[1]
    marketplace_statement = statements[2]
    bedrock_statement = statements[3]

    browser_actions = set(cast(list[str], browser_statement["Action"]))
    for action in validate_permissions.REQUIRED_AGENTCORE_ACTIONS:
        assert action in browser_actions

    s3_actions = set(cast(list[str], s3_statement["Action"]))
    for action in validate_permissions.REQUIRED_S3_ACTIONS:
        assert action in s3_actions

    marketplace_actions = set(cast(list[str], marketplace_statement["Action"]))
    for action in validate_permissions.REQUIRED_MARKETPLACE_ACTIONS:
        assert action in marketplace_actions

    bedrock_actions = set(cast(list[str], bedrock_statement["Action"]))
    for action in validate_permissions.REQUIRED_BEDROCK_ACTIONS:
        assert action in bedrock_actions

    resources = cast(list[str], s3_statement["Resource"])
    assert "arn:aws:s3:::test-bucket" in resources
    assert "arn:aws:s3:::test-bucket/*" in resources
