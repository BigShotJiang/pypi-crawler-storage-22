"""App Context Report tool for app context discovery agent.

This tool ensures that app context discovery results are properly formatted
as valid JSON instead of being saved as markdown text.
"""

import json
import logging
from typing import Any, Literal

from utils.config_loader import get_available_domains

logger = logging.getLogger(__name__)

# Valid domain types aligned with config/domains/
VALID_DOMAINS = Literal[
    "travel",
    "hr",
    "customer_success",
    "media",
    "govtech",
    "ecommerce",
    "insurance",
    "tech_support",
]


def app_context_report(
    summary: str,
    core_functionality: str,
    target_audience: str,
    technical_information: str,
    chat_interface_description: str,
    domain: str | None = None,
) -> str:
    """Generate a properly formatted JSON report for app context discovery.

    This tool takes the discovered context information and formats it as valid JSON,
    preventing issues where the agent might output markdown-formatted text instead
    of proper JSON.

    Args:
        summary: A brief overview of the application/website name and purpose
        core_functionality: The main features or services offered
        target_audience: Who is this application designed for
        technical_information: Any important technical details about the company, product, or service
        chat_interface_description: Description of any chat interfaces or support bots present
        domain: The identified domain category for this application. Must be one of:
                - travel: Travel booking, trip planning, flight/hotel services
                - hr: Human resources, people management, payroll systems
                - customer_success: Customer success platforms, support tools
                - media: Media processing, digital assets, content management
                - govtech: Government technology, civic engagement platforms
                - ecommerce: Online shopping, retail, marketplaces
                - insurance: Insurance products, claims processing
                - tech_support: Technical support, troubleshooting platforms

    Returns:
        JSON string with properly formatted app context information

    Example:
        >>> result = app_context_report(
        ...     summary='A travel planning application',
        ...     core_functionality='Trip planning and booking',
        ...     target_audience='Travelers and tourists',
        ...     technical_information='Web-based platform',
        ...     chat_interface_description='AI-powered chat assistant',
        ...     domain='travel'
        ... )
        >>> print(result)
        {"summary": "A travel planning application", "domain": "travel", ...}
    """
    logger.info("Generating app context report with structured JSON output")

    # Get available domains from config
    available_domains = get_available_domains()

    # Validate domain if provided
    domain_validated = None
    if domain:
        domain_lower = domain.lower().strip()
        if domain_lower in available_domains:
            domain_validated = domain_lower
            logger.info(f"Domain validated: {domain_validated}")
        else:
            logger.warning(
                f"Domain '{domain}' is not configured. "
                f"Available domains: {available_domains}"
            )
            # Still include it for reporting but mark as unvalidated
            domain_validated = domain_lower

    # Create the report dictionary
    report: dict[str, Any] = {
        "summary": summary,
        "core_functionality": core_functionality,
        "target_audience": target_audience,
        "technical_information": technical_information,
        "chat_interface_description": chat_interface_description,
        "domain": domain_validated,
        "domain_validated": domain_validated in available_domains
        if domain_validated
        else False,
    }

    # Convert to JSON with proper formatting
    json_output = json.dumps(report, indent=2, ensure_ascii=False)

    logger.info(f"App context report generated ({len(json_output)} characters)")

    return json_output
