"""
Arato Logs API Tool

This tool sends conversation logs to the Arato platform for monitoring and analysis.
It's designed to be used by the chat_runner agent to track chatbot interactions.

Uses a background thread for non-blocking HTTP requests to avoid slowing down
the main conversation loop.
"""

import atexit
import logging
import queue
import threading
from collections.abc import Mapping
from typing import Any

import requests

from utils.scoring import calculate_label, calculate_status

logger = logging.getLogger(__name__)


class _BackgroundSender:
    """Background thread worker for non-blocking HTTP requests."""

    def __init__(self) -> None:
        self._queue: queue.Queue[dict[str, Any] | None] = queue.Queue()
        self._thread: threading.Thread | None = None
        self._started = False
        self._lock = threading.Lock()
        self._disabled_urls: set[str] = (
            set()
        )  # URLs that returned 404 (endpoint not available)

    def start(self) -> None:
        """Start the background sender thread."""
        with self._lock:
            if self._started:
                return
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()
            self._started = True
            atexit.register(self.stop)
            logger.debug("Background Arato sender started")

    def stop(self) -> None:
        """Stop the background sender thread."""
        with self._lock:
            if not self._started:
                return
            self._queue.put(None)  # Sentinel to stop worker
            if self._thread:
                self._thread.join(timeout=5.0)
            self._started = False
            logger.debug("Background Arato sender stopped")

    def enqueue(self, request_data: dict[str, Any]) -> None:
        """Add a request to the background queue."""
        if not self._started:
            self.start()
        self._queue.put(request_data)

    def _worker(self) -> None:
        """Worker thread that processes queued requests."""
        while True:
            try:
                item = self._queue.get(timeout=1.0)
                if item is None:  # Sentinel
                    break
                self._send_request(item)
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Background sender error: {e}")

    def _send_request(self, request_data: dict[str, Any]) -> None:
        """Send a single HTTP request."""
        url = request_data["url"]

        # Skip URLs that previously returned 404 (endpoint not available on this server)
        if url in self._disabled_urls:
            return

        try:
            response = requests.post(
                url,
                headers=request_data["headers"],
                json=request_data["data"],
                timeout=10,
            )
            response.raise_for_status()
            logger.debug(f"Background Arato log sent: {response.status_code}")
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                logger.debug(f"Log endpoint not available (404), disabling: {url}")
                self._disabled_urls.add(url)
            else:
                logger.warning(f"Background Arato request failed: {e}")
        except requests.exceptions.RequestException as e:
            logger.warning(f"Background Arato request failed: {e}")
        except Exception as e:
            logger.error(f"Background Arato unexpected error: {e}")


# Global background sender instance
_background_sender = _BackgroundSender()


class AratoLogsAPI:
    """
    Client for sending logs to the Arato platform.

    This tool integrates with the chat_runner agent to automatically log
    all chatbot interactions, including messages, responses, and metadata.
    """

    def __init__(self, api_url: str, api_key: str):
        """
        Initialize the Arato Logs API client.

        Args:
            api_url: The Arato API endpoint URL (e.g., "https://api.arato.ai/your-workspace/log")
            api_key: The Arato API authentication token
        """
        self.api_url = api_url
        self.api_key = api_key
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }

    def log_conversation_turn(
        self,
        messages: list[dict[str, str]],
        response: str | None = None,
        conversation_id: str | None = None,
        model: str | None = None,
        event_id: str | None = None,
        variables: dict[str, str | dict[str, str]] | None = None,
        usage: Mapping[str, str | int] | None = None,
        performance: Mapping[str, str | int] | None = None,
        tool_calls: list[dict[str, str | dict[str, Any]]] | None = None,
        prompt_id: str | None = None,
        prompt_version: str | None = None,
        tags: dict[str, str] | None = None,
        evals: list[dict[str, Any]] | None = None,
    ) -> requests.Response | None:
        """
        Log a conversation turn to the Arato platform.

        This method is designed to be called after each interaction with the chatbot,
        capturing the full context of the conversation turn including the user message,
        bot response, and associated metadata.

        Args:
            messages: List of message dicts with 'role' and 'content' keys
                     Example: [{"role": "user", "content": "Hello!"}]
            response: The chatbot's response text
            conversation_id: Unique identifier for this conversation session
                           (maps to arato_thread_id - should be the pipeline invocation ID)
            model: Model identifier (e.g., "gpt-4o-mini", "claude-3-sonnet")
            event_id: Unique identifier for this specific event/turn
            variables: Template variables used in the conversation
            usage: Token usage information (e.g., {"prompt_tokens": 20, "completion_tokens": 10})
            performance: Performance metrics (e.g., {"ttft": 1000, "ttlt": 2000})
            tool_calls: List of tool calls made during this turn
            prompt_id: Identifier for the prompt template used
            prompt_version: Version of the prompt template
            tags: Additional tags for filtering/categorization

        Returns:
            Response object from the API call, or None if the request failed
        """
        try:
            # Enrich evals with derived fields (severity, result) based on score
            # This ensures the platform receives consistent derived metrics
            enriched_evals = None
            if evals:
                enriched_evals = []
                for eval_item in evals:
                    # Create a copy to avoid modifying original
                    item = eval_item.copy()

                    # Only if score is present and severity/result are missing/needs calculation
                    if "score" in item:
                        score = item["score"]

                        # Calculate Label using shared logic
                        item["label"] = calculate_label(score)

                        # Calculate Result (1=Pass, 0=Fail)
                        item["result"] = 1 if calculate_status(score) else 0

                    enriched_evals.append(item)

            data: dict[str, Any] = {
                "model": model,
                "messages": messages,
                "response": response,
                "id": event_id,
                "variables": variables,
                "usage": usage,
                "performance": performance,
                "tool_calls": tool_calls,
                "arato_thread_id": conversation_id,
                "prompt_id": prompt_id,
                "prompt_version": prompt_version,
                "tags": tags,
                "validations_response": enriched_evals,
                "event_source": "aut",
            }

            # Remove None values to keep the payload clean
            data = {k: v for k, v in data.items() if v is not None}

            logger.info(
                f"Queuing Arato log (background): conversation_id={conversation_id}, "
                f"event_id={event_id}, messages_count={len(messages)}"
            )

            # Send via background thread to avoid blocking conversation loop
            _background_sender.enqueue(
                {
                    "url": self.api_url,
                    "headers": self.headers,
                    "data": data,
                }
            )

            # Return a dummy success indicator (actual send is async)
            return None

        except Exception as e:
            logger.error(f"Unexpected error preparing Arato log: {e}")
            return None

    def log_chat_runner_turn(
        self,
        user_message: str,
        bot_response: str,
        conversation_id: str,
        turn_number: int,
        model: str | None = None,
        chat_url: str | None = None,
        persona: str | None = None,
        target_selectors: dict[str, str] | None = None,
        error: str | None = None,
        **kwargs: Any,
    ) -> requests.Response | None:
        """
        Convenience method specifically for chat_runner agent interactions.

        This method automatically formats the conversation data in a way that's
        optimal for chat_runner logging, including relevant metadata about the
        chat interface being tested.

        Args:
            user_message: The message sent to the chatbot
            bot_response: The response received from the chatbot
            conversation_id: Pipeline invocation ID (unique per pipeline run)
            turn_number: The turn number in this conversation (1-indexed)
            model: The model being tested (if known)
            chat_url: URL of the chat interface being tested
            persona: The persona being used for testing (e.g., "malicious_user")
            target_selectors: Dict of CSS selectors used (input, button, response)
            error: Error message if the turn failed
            **kwargs: Additional fields to include in the log

        Returns:
            Response object from the API call, or None if the request failed
        """
        messages = [
            {"role": "user", "content": user_message},
        ]

        # Build tags from metadata
        tags: dict[str, str] = {
            "turn_number": str(turn_number),
            "source": "arato.agent",
            "chat_url": chat_url or "unknown",
        }

        if persona:
            tags["persona"] = persona
        if error:
            tags["error"] = "true"
            tags["error_message"] = error[:100]  # Truncate long errors

        # Add any additional tags from kwargs
        if "tags" in kwargs:
            tags.update(kwargs.pop("tags"))

        # Generate event ID
        event_id = f"{conversation_id}_turn_{turn_number}"

        # Accept evals as a kwarg (should be provided by caller)
        evals = kwargs.pop("evals", None)

        return self.log_conversation_turn(
            messages=messages,
            response=bot_response,
            conversation_id=conversation_id,
            model=model,
            event_id=event_id,
            tags=tags,
            evals=evals,
            **kwargs,
        )
