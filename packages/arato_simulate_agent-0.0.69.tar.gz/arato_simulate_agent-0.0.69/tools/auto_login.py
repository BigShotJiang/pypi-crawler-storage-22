#!/usr/bin/env python3
"""
Auto Login Tool: Attempts automatic login using stored credentials with CSS selectors.
"""

import asyncio
import json
import logging
import time
from typing import Any

from browser_use import Browser

from utils.password_manager import load_credentials_for_domain
from utils.timing_logger import log_timing
from utils.url_utils import get_domain_from_url

logger = logging.getLogger(__name__)


async def auto_login_tool(
    browser: Browser,
    target_url: str,
    passwords_file: str | None = None,
    persona_instance: str | None = None,
) -> dict[str, Any]:
    """
    Attempt automatic login using stored credentials for the domain.

    This tool should be used when encountering a login screen. It will:
    1. Check if credentials exist for the domain
    2. Attempt to find username/password fields
    3. Fill in credentials and submit
    4. Return success/failure status

    Args:
        browser: Browser instance from browser-use
        target_url: Current URL to extract domain from
        passwords_file: Optional path to passwords file
        persona_instance: Optional persona instance name for logging

    Returns:
        Dictionary with:
            - success: bool - Whether login was attempted and appeared successful
            - message: str - Status message
            - credentials_found: bool - Whether credentials were found for domain
            - login_attempted: bool - Whether login form was found and filled
    """
    # Start timing
    login_start_time = time.time()

    # Extract domain early for logging (even on failure)
    domain = get_domain_from_url(target_url)

    try:
        # Extract domain from target URL
        logger.info(f"Checking for stored credentials for domain: {domain}")

        # Load credentials for domain
        credentials = load_credentials_for_domain(domain, passwords_file)

        if not credentials:
            return {
                "success": False,
                "message": f"No stored credentials found for domain: {domain}",
                "credentials_found": False,
                "login_attempted": False,
            }

        username, password = credentials
        logger.info(
            f"Found credentials for domain {domain}, attempting login with CSS selectors..."
        )

        # Get the current page to verify it's accessible
        page = await browser.get_current_page()
        if not page:
            logger.error("No current page available")
            return {
                "success": False,
                "message": "No active page available for login",
                "credentials_found": True,
                "login_attempted": False,
            }

        # Check if we're actually on a login page by looking at the page content
        # Use retry logic with longer waits for JavaScript-heavy pages (like Cloudinary)
        page_info = None
        for attempt in range(3):
            try:
                if attempt > 0:
                    logger.info(
                        f"Retry attempt {attempt + 1}/3 - waiting 2 seconds for page to load..."
                    )
                    await asyncio.sleep(2)

                page_content_check = await page.evaluate(
                    """
                    () => {
                        const html = document.documentElement.outerHTML.toLowerCase();
                        const hasPasswordField = document.querySelector('input[type="password"]') !== null;
                        const hasEmailField = document.querySelector('input[type="email"]') !== null ||
                                             document.querySelector('input[name*="email"]') !== null ||
                                             document.querySelector('input[id*="email"]') !== null;
                        const hasLoginText = html.includes('login') || html.includes('sign in');
                        return JSON.stringify({
                            hasPasswordField: hasPasswordField,
                            hasEmailField: hasEmailField,
                            hasLoginText: hasLoginText,
                            url: window.location.href,
                            title: document.title
                        });
                    }
                    """
                )
                page_info = json.loads(page_content_check)

                if page_info.get("hasPasswordField") or page_info.get("hasEmailField"):
                    logger.info(f"Login form detected on attempt {attempt + 1}")
                    break
            except Exception as e:
                logger.warning(
                    f"Could not check page content on attempt {attempt + 1}: {e}"
                )

        if not page_info or (
            not page_info.get("hasPasswordField") and not page_info.get("hasEmailField")
        ):
            logger.info(
                "No login fields found on page after 3 attempts - likely already logged in or not on login page"
            )
            return {
                "success": False,
                "message": "No login form detected on page - user may already be authenticated",
                "credentials_found": True,
                "login_attempted": False,
            }

        # Use CSS selectors to find and fill login form
        try:
            # Wait for the page to fully load and render the form (longer for JavaScript-heavy pages)
            await asyncio.sleep(2)

            # Get CDP session for text insertion
            cdp_session = await browser.get_or_create_cdp_session()

            # Common CSS selectors for username/email fields
            username_selectors = [
                # Specific common patterns
                'input[id="user_session_email"]',  # Cloudinary, Rails-style
                'input[type="email"]',
                'input[id*="email" i]',
                'input[id*="user" i]',
                'input[name*="email" i]',
                'input[name*="user" i]',
                'input[type="text"][name*="email" i]',
                'input[type="text"][name*="user" i]',
                'input[type="text"][id*="email" i]',
                'input[type="text"][id*="user" i]',
                'input[type="text"][placeholder*="email" i]',
                'input[type="text"][placeholder*="user" i]',
                'input[name="username"]',
                'input[name="email"]',
                'input[id="username"]',
                'input[id="email"]',
                'input[autocomplete="email"]',
                'input[autocomplete="username"]',
            ]

            # Common CSS selectors for password fields
            password_selectors = [
                'input[id="user_session_password"]',  # Cloudinary, Rails-style
                'input[type="password"]',
                'input[id*="password" i]',
                'input[name*="password" i]',
            ]

            # Common CSS selectors for submit buttons
            submit_selectors = [
                'button[id="sign-in"]',  # Cloudinary-specific
                'button[type="submit"]',
                'input[type="submit"]',
                'button[id*="login" i]',
                'button[id*="sign-in" i]',
                'button[id*="signin" i]',
                'button[id*="submit" i]',
                'button[class*="login" i]',
                'button[class*="submit" i]',
                'button[class*="sign-in" i]',
            ]

            # Step 1: Fill username field
            username_filled = False
            for selector in username_selectors:
                try:
                    # JavaScript to find and focus the element
                    focus_js = f"""
                        () => {{
                            let el = document.querySelector('{selector}');
                            if (!el || el.offsetParent === null) return JSON.stringify({{success: false}});

                            el.focus();
                            el.click();

                            return JSON.stringify({{
                                success: true,
                                tagName: el.tagName,
                                type: el.type
                            }});
                        }}
                    """

                    result_json = await page.evaluate(focus_js)
                    result = json.loads(result_json)

                    if result.get("success"):
                        logger.info(
                            f"✅ Found username field with selector: {selector}"
                        )

                        # Type username using CDP
                        await cdp_session.cdp_client.send.Input.insertText(
                            params={"text": username}, session_id=cdp_session.session_id
                        )
                        logger.info(f"✅ Filled username: {username}")
                        username_filled = True
                        await asyncio.sleep(0.5)  # Wait for any change detection
                        break

                except Exception:
                    continue

            if not username_filled:
                # Try to get more info about the page to help debugging
                try:
                    page_debug = await page.evaluate(
                        """
                        () => {
                            const inputs = Array.from(document.querySelectorAll('input'));
                            return JSON.stringify({
                                inputCount: inputs.length,
                                inputTypes: inputs.map(i => i.type + (i.id ? '#' + i.id : '') + (i.name ? '[' + i.name + ']' : '')),
                                url: window.location.href
                            });
                        }
                        """
                    )
                    logger.warning(
                        f"Could not find username field. Page debug: {page_debug}"
                    )
                except Exception:
                    logger.warning("Could not find username field")

                return {
                    "success": False,
                    "message": "Could not find username/email field on page",
                    "credentials_found": True,
                    "login_attempted": False,
                }

            # Step 1.5: Check for password field and handle multi-step login if needed
            password_present = False
            for selector in password_selectors:
                try:
                    check_js = f"document.querySelector('{selector}') !== null && document.querySelector('{selector}').offsetParent !== null"
                    if await page.evaluate(check_js):
                        password_present = True
                        break
                except Exception:
                    continue

            if not password_present:
                logger.info(
                    "Password field not visible, attempting multi-step login (clicking Next)..."
                )
                next_selectors = [
                    'button[id*="next" i]',
                    'button[id*="continue" i]',
                    'button[name*="next" i]',
                    'button[name*="continue" i]',
                    'button[class*="next" i]',
                    'button[class*="continue" i]',
                    'input[type="submit"]',
                    'button[type="submit"]',
                    # Fallback to generic submit buttons
                    'button[id*="submit" i]',
                    'button[class*="submit" i]',
                ]

                next_clicked = False
                for selector in next_selectors:
                    try:
                        click_js = f"""
                            () => {{
                                let el = document.querySelector('{selector}');
                                if (!el || el.offsetParent === null) return JSON.stringify({{success: false}});
                                el.click();
                                return JSON.stringify({{success: true}});
                            }}
                        """
                        result_json = await page.evaluate(click_js)
                        result = json.loads(result_json)

                        if result.get("success"):
                            logger.info(
                                f"✅ Clicked Next button with selector: {selector}"
                            )
                            next_clicked = True
                            break
                    except Exception:
                        continue

                if next_clicked:
                    # Wait for password field to appear
                    logger.info("Waiting for password field to appear...")
                    await asyncio.sleep(2)
                    # Optional: Wait loop for password field could be added here

            # Step 2: Fill password field
            password_filled = False
            for selector in password_selectors:
                try:
                    focus_js = f"""
                        () => {{
                            let el = document.querySelector('{selector}');
                            if (!el || el.offsetParent === null) return JSON.stringify({{success: false}});

                            el.focus();
                            el.click();

                            return JSON.stringify({{
                                success: true,
                                tagName: el.tagName,
                                type: el.type
                            }});
                        }}
                    """

                    result_json = await page.evaluate(focus_js)
                    result = json.loads(result_json)

                    if result.get("success"):
                        logger.info(
                            f"✅ Found password field with selector: {selector}"
                        )

                        # Type password using CDP
                        await cdp_session.cdp_client.send.Input.insertText(
                            params={"text": password}, session_id=cdp_session.session_id
                        )
                        logger.info("✅ Filled password")
                        password_filled = True
                        await asyncio.sleep(0.5)
                        break

                except Exception:
                    continue

            if not password_filled:
                logger.warning("Could not find password field")
                return {
                    "success": False,
                    "message": "Could not find password field on page (even after attempting multi-step login)",
                    "credentials_found": True,
                    "login_attempted": False,
                }

            # Step 3: Click submit button
            submit_clicked = False
            for selector in submit_selectors:
                try:
                    click_js = f"""
                        () => {{
                            let el = document.querySelector('{selector}');
                            if (!el) return JSON.stringify({{success: false}});

                            el.click();

                            return JSON.stringify({{success: true}});
                        }}
                    """

                    result_json = await page.evaluate(click_js)
                    result = json.loads(result_json)

                    if result.get("success"):
                        logger.info(
                            f"✅ Clicked submit button with selector: {selector}"
                        )
                        submit_clicked = True
                        break

                except Exception:
                    continue

            if not submit_clicked:
                # Fallback: Press Enter key using CDP
                logger.info("Submit button not found, pressing Enter as fallback")
                try:
                    await cdp_session.cdp_client.send.Input.dispatchKeyEvent(
                        params={
                            "type": "keyDown",
                            "key": "Enter",
                            "code": "Enter",
                            "windowsVirtualKeyCode": 13,
                            "nativeVirtualKeyCode": 13,
                        },
                        session_id=cdp_session.session_id,
                    )
                    await cdp_session.cdp_client.send.Input.dispatchKeyEvent(
                        params={
                            "type": "keyUp",
                            "key": "Enter",
                            "code": "Enter",
                            "windowsVirtualKeyCode": 13,
                            "nativeVirtualKeyCode": 13,
                        },
                        session_id=cdp_session.session_id,
                    )
                    logger.info("✅ Pressed Enter key")
                except Exception as e:
                    logger.error(f"Failed to press Enter: {e}")
                    return {
                        "success": False,
                        "message": "Could not submit login form (no submit button found and Enter failed)",
                        "credentials_found": True,
                        "login_attempted": False,
                    }

            # Wait for login to process
            await asyncio.sleep(2)

            # Check if login was successful
            page = await browser.get_current_page()
            playwright_page = (
                page if hasattr(page, "url") else getattr(page, "page", None)
            )

            if playwright_page and hasattr(playwright_page, "url"):
                current_url: str = str(playwright_page.url)
                page_content = await playwright_page.content()  # type: ignore[union-attr]

                # Check if we navigated away from login page or password field disappeared
                if (
                    "login" not in current_url.lower()
                    or "password" not in page_content.lower()
                ):
                    logger.info(
                        "Login appears successful (navigated away from login page)"
                    )
                    duration = time.time() - login_start_time
                    log_timing(
                        "auto_login",
                        duration,
                        {
                            "result": "success",
                            "domain": domain,
                            "persona": persona_instance or "unknown",
                        },
                    )
                    return {
                        "success": True,
                        "message": f"Successfully logged in with stored credentials for {domain}",
                        "credentials_found": True,
                        "login_attempted": True,
                    }

            logger.warning("Login may have failed or requires additional steps")
            duration = time.time() - login_start_time
            log_timing(
                "auto_login",
                duration,
                {
                    "result": "unclear",
                    "domain": domain,
                    "persona": persona_instance or "unknown",
                },
            )
            return {
                "success": False,
                "message": (
                    "Login attempted but outcome unclear. "
                    "Check the screen: if you see an OTP/2FA/verification code prompt, try auto_otp(). "
                    "If you see a CAPTCHA, request human help."
                ),
                "credentials_found": True,
                "login_attempted": True,
            }

        except Exception as e:
            logger.error(f"Error during CSS selector-based login: {e}")
            return {
                "success": False,
                "message": f"Error during automated login: {str(e)}",
                "credentials_found": True,
                "login_attempted": False,
            }

    except Exception as e:
        logger.error(f"Error during auto-login: {e}")
        duration = time.time() - login_start_time
        result_status = "error"
        log_timing(
            "auto_login",
            duration,
            {
                "result": result_status,
                "domain": domain,
                "persona": persona_instance or "unknown",
            },
        )
        return {
            "success": False,
            "message": f"Error during auto-login: {str(e)}",
            "credentials_found": False,
            "login_attempted": False,
        }
