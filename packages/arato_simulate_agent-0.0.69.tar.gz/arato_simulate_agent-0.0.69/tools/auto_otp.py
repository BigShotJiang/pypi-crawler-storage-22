#!/usr/bin/env python3
"""
Auto OTP Tool: Attempts automatic OTP/2FA entry using stored codes.
"""

import asyncio
import logging
import time
from typing import Any

from browser_use import Browser

from utils.otp_manager import load_otp_for_domain
from utils.timing_logger import log_timing
from utils.url_utils import get_domain_from_url

logger = logging.getLogger(__name__)


async def auto_otp_tool(
    browser: Browser,
    target_url: str,
    otp_file: str | None = None,
    persona_instance: str | None = None,
) -> dict[str, Any]:
    """
    Attempt automatic OTP entry using stored codes for the domain.

    This tool should be used when encountering an OTP/2FA verification screen. It will:
    1. Check if an OTP code exists for the domain
    2. Attempt to find OTP input field(s)
    3. Fill in the code and submit
    4. Return success/failure status

    Args:
        browser: Browser instance from browser-use
        target_url: Current URL to extract domain from
        otp_file: Optional path to OTP codes file
        persona_instance: Optional persona instance name for logging

    Returns:
        Dictionary with:
            - success: bool - Whether OTP was entered and appeared successful
            - message: str - Status message
            - otp_found: bool - Whether OTP code was found for domain
            - otp_attempted: bool - Whether OTP form was found and filled
    """
    # Start timing
    otp_start_time = time.time()

    # Extract domain early for logging (even on failure)
    domain = get_domain_from_url(target_url)

    try:
        # Extract domain from target URL
        logger.info(f"Checking for stored OTP code for domain: {domain}")

        # Load OTP code for domain
        otp_code = load_otp_for_domain(domain, otp_file)

        if not otp_code:
            return {
                "success": False,
                "message": f"No stored OTP code found for domain: {domain}",
                "otp_found": False,
                "otp_attempted": False,
            }

        logger.info(f"Found OTP code for domain {domain}, attempting entry...")

        # Get the current page
        page = await browser.get_current_page()
        if not page:
            logger.error("No current page available")
            return {
                "success": False,
                "message": "No active page available for OTP entry",
                "otp_found": True,
                "otp_attempted": False,
            }

        # Check if we're on an OTP verification page
        otp_info = await page.evaluate(
            """
      () => {
        const html = document.documentElement.outerHTML.toLowerCase();

        // Look for OTP-related text
        const hasOTPText = html.includes('verification') ||
                          html.includes('verify') ||
                          html.includes('otp') ||
                          html.includes('code') ||
                          html.includes('2fa') ||
                          html.includes('two-factor') ||
                          html.includes('authenticator');

        // Look for OTP input patterns
        const otpInputs = document.querySelectorAll('input[type="text"], input[type="tel"], input[type="number"]');
        const hasShortInputs = Array.from(otpInputs).some(i => {
          const maxLen = i.getAttribute('maxlength');
          return maxLen && parseInt(maxLen) <= 6;
        });

        // Look for multiple single-digit inputs (common OTP pattern)
        const singleDigitInputs = Array.from(otpInputs).filter(i => {
          const maxLen = i.getAttribute('maxlength');
          return maxLen === '1';
        });

        return JSON.stringify({
          hasOTPText: hasOTPText,
          hasShortInputs: hasShortInputs,
          singleDigitCount: singleDigitInputs.length,
          totalInputs: otpInputs.length
        });
      }
      """
        )

        import json

        otp_page_info = json.loads(otp_info)
        logger.info(f"OTP page detection: {otp_page_info}")

        # Determine if this looks like an OTP page
        is_otp_page = (
            otp_page_info.get("hasOTPText", False)
            or otp_page_info.get("hasShortInputs", False)
            or otp_page_info.get("singleDigitCount", 0) >= 4
        )

        if not is_otp_page:
            logger.info("Page does not appear to be an OTP verification page")
            return {
                "success": False,
                "message": "Current page does not appear to be an OTP verification page",
                "otp_found": True,
                "otp_attempted": False,
            }

        # Try to fill the OTP
        otp_filled = await _fill_otp_field(page, otp_code)

        if not otp_filled:
            return {
                "success": False,
                "message": "Could not find or fill OTP input field",
                "otp_found": True,
                "otp_attempted": True,
            }

        # Try to submit
        await _submit_otp(page)

        # Wait a moment for the form to process
        await asyncio.sleep(2)

        # Check if we navigated away (success indicator)
        # Get the playwright page object for URL access
        playwright_page = page if hasattr(page, "url") else getattr(page, "page", None)
        new_url = (
            str(playwright_page.url)
            if playwright_page and hasattr(playwright_page, "url")
            else target_url
        )
        url_changed = target_url != new_url

        if url_changed:
            logger.info(f"✅ OTP submitted successfully, navigated to: {new_url}")
            return {
                "success": True,
                "message": f"OTP entered and verified successfully. Navigated to: {new_url}",
                "otp_found": True,
                "otp_attempted": True,
            }
        else:
            # URL didn't change - check for error messages
            has_error = await page.evaluate(
                """
        () => {
          const html = document.documentElement.outerHTML.toLowerCase();
          return html.includes('invalid') ||
                 html.includes('incorrect') ||
                 html.includes('wrong') ||
                 html.includes('expired') ||
                 html.includes('try again');
        }
        """
            )

            if has_error:
                logger.warning(
                    "OTP verification may have failed - error message detected"
                )
                duration = time.time() - otp_start_time
                log_timing(
                    "auto_otp",
                    duration,
                    {
                        "result": "error",
                        "reason": "verification_failed",
                        "domain": domain,
                        "persona": persona_instance,
                    },
                )
                return {
                    "success": False,
                    "message": "OTP entered but verification may have failed (error detected on page)",
                    "otp_found": True,
                    "otp_attempted": True,
                }
            else:
                logger.info("OTP entered, waiting for verification...")
                duration = time.time() - otp_start_time
                log_timing(
                    "auto_otp",
                    duration,
                    {
                        "result": "success",
                        "domain": domain,
                        "persona": persona_instance,
                    },
                )
                return {
                    "success": True,
                    "message": "OTP entered successfully. Verification may be processing.",
                    "otp_found": True,
                    "otp_attempted": True,
                }

    except Exception as e:
        logger.error(f"Error during auto OTP: {e}")
        duration = time.time() - otp_start_time
        result_status = "error"
        log_timing(
            "auto_otp",
            duration,
            {
                "result": result_status,
                "domain": domain,
                "persona": persona_instance or "unknown",
            },
        )
        return {
            "success": False,
            "message": f"Error during OTP entry: {str(e)}",
            "otp_found": False,
            "otp_attempted": False,
        }


async def _fill_otp_field(page: Any, otp_code: str) -> bool:
    """
    Attempt to fill OTP field(s) with various strategies.

    Args:
        page: Playwright page
        otp_code: The OTP code to enter

    Returns:
        True if OTP was filled successfully
    """
    # Strategy 1: Look for single-digit input boxes (6 separate inputs)
    try:
        single_digit_result = await page.evaluate(
            """
      (otpCode) => {
        // Find all inputs that might be single-digit OTP fields
        const inputs = document.querySelectorAll('input[maxlength="1"]');
        if (inputs.length >= 4 && inputs.length <= 8) {
          const digits = otpCode.split('');
          for (let i = 0; i < Math.min(inputs.length, digits.length); i++) {
            inputs[i].value = digits[i];
            inputs[i].dispatchEvent(new Event('input', { bubbles: true }));
            inputs[i].dispatchEvent(new Event('change', { bubbles: true }));
          }
          return { success: true, count: inputs.length };
        }
        return { success: false, count: inputs.length };
      }
      """,
            otp_code,
        )
        if single_digit_result and single_digit_result.get("success"):
            logger.info(
                f"✅ Filled OTP using single-digit input strategy ({single_digit_result.get('count')} inputs)"
            )
            return True
        else:
            logger.debug(
                f"Single-digit strategy: found {single_digit_result.get('count', 0)} inputs (need 4-8)"
            )
    except Exception as e:
        logger.debug(f"Single-digit strategy failed: {e}")

    # Strategy 2: Look for OTP input by common selectors
    # Note: CSS selector `i` flag for case-insensitivity is not widely supported,
    # so we use lowercase and also handle case in JavaScript
    otp_selectors = [
        # Specific ID selectors (common patterns)
        "#verificationCode",
        "#verification-code",
        "#otp",
        "#otpCode",
        "#otp-code",
        "#code",
        "#2fa-code",
        "#twoFactorCode",
        # Attribute selectors (without i flag - handle case in JS)
        'input[name*="otp"]',
        'input[name*="code"]',
        'input[name*="verification"]',
        'input[name*="token"]',
        'input[id*="otp"]',
        'input[id*="code"]',
        'input[id*="verification"]',
        'input[formcontrolname*="verification"]',
        'input[formcontrolname*="code"]',
        'input[placeholder*="code"]',
        'input[placeholder*="digit"]',
        'input[type="tel"]',
        'input[inputmode="numeric"]',
        'input[maxlength="6"]',
        'input[maxlength="4"]',
    ]

    for selector in otp_selectors:
        try:
            filled = await page.evaluate(
                """
        (args) => {
          const [selector, otpCode] = args;
          let input = document.querySelector(selector);

          // If selector didn't match, try case-insensitive matching for ID
          if (!input && selector.startsWith('#')) {
            const idToFind = selector.slice(1).toLowerCase();
            const allInputs = document.querySelectorAll('input');
            for (const inp of allInputs) {
              if (inp.id && inp.id.toLowerCase() === idToFind) {
                input = inp;
                break;
              }
            }
          }

          if (input && input.offsetParent !== null) {
            input.focus();
            input.value = '';  // Clear first

            // Type the code character by character for Angular/React compatibility
            for (let i = 0; i < otpCode.length; i++) {
              input.value += otpCode[i];
              input.dispatchEvent(new Event('input', { bubbles: true }));
            }

            // Final events for framework compatibility
            input.dispatchEvent(new Event('change', { bubbles: true }));
            input.dispatchEvent(new Event('blur', { bubbles: true }));

            // For Angular reactive forms
            if (input.dispatchEvent) {
              input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
            }

            return { success: true, selector: selector, id: input.id };
          }
          return { success: false };
        }
        """,
                [selector, otp_code],
            )
            if filled and filled.get("success"):
                logger.info(
                    f"✅ Filled OTP using selector: {selector} (input id: {filled.get('id')})"
                )
                return True
        except Exception as e:
            logger.debug(f"Selector {selector} failed: {e}")
            continue

    # Strategy 3: Find any visible text/tel/number input
    try:
        generic_result = await page.evaluate(
            """
      (otpCode) => {
        const inputs = document.querySelectorAll('input[type="text"], input[type="tel"], input[type="number"]');
        for (const input of inputs) {
          // Skip hidden inputs
          if (input.offsetParent === null) continue;
          // Skip inputs that already have values (like email/username)
          if (input.value && input.value.length > 0) continue;
          // Skip inputs that seem too long
          const maxLen = input.getAttribute('maxlength');
          if (maxLen && parseInt(maxLen) > 10) continue;

          input.focus();
          input.value = otpCode;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          return true;
        }
        return false;
      }
      """,
            otp_code,
        )
        if generic_result:
            logger.info("✅ Filled OTP using generic input strategy")
            return True
    except Exception as e:
        logger.debug(f"Generic strategy failed: {e}")

    return False


async def _submit_otp(page: Any) -> bool:
    """
    Attempt to submit the OTP form.

    Args:
        page: Playwright page

    Returns:
        True if submit was attempted
    """
    # Wait a moment for the button to become enabled after filling
    await asyncio.sleep(0.5)

    # Strategy 1: Look for verify/submit button
    submit_selectors = [
        'button[type="submit"]',
        'button:has-text("Submit")',
        'button:has-text("Verify")',
        'button:has-text("Continue")',
        'button:has-text("Confirm")',
        'input[type="submit"]',
    ]

    for selector in submit_selectors:
        try:
            clicked = await page.evaluate(
                """
        (selector) => {
          // Handle :has-text pseudo selector
          if (selector.includes(':has-text')) {
            const text = selector.match(/:has-text\\("([^"]+)"\\)/)?.[1];
            if (text) {
              const buttons = document.querySelectorAll('button, input[type="submit"]');
              for (const btn of buttons) {
                if (btn.textContent.toLowerCase().includes(text.toLowerCase()) && !btn.disabled) {
                  btn.click();
                  return { clicked: true, text: btn.textContent.trim() };
                }
              }
            }
            return { clicked: false };
          }

          const btn = document.querySelector(selector);
          if (btn && btn.offsetParent !== null && !btn.disabled) {
            btn.click();
            return { clicked: true, text: btn.textContent?.trim() || 'submit' };
          }
          return { clicked: false, disabled: btn?.disabled };
        }
        """,
                selector,
            )
            if clicked and clicked.get("clicked"):
                logger.info(
                    f"✅ Clicked submit button: '{clicked.get('text')}' using selector: {selector}"
                )
                return True
            elif clicked and clicked.get("disabled"):
                logger.debug(f"Button {selector} found but disabled")
        except Exception as e:
            logger.debug(f"Submit selector {selector} failed: {e}")
            continue

    # Strategy 2: Press Enter on the last focused input
    try:
        await page.keyboard.press("Enter")
        logger.info("✅ Pressed Enter to submit OTP")
        return True
    except Exception as e:
        logger.debug(f"Enter key failed: {e}")

    return False
