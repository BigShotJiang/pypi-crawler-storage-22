#!/usr/bin/env python3
"""
CAPTCHA Solver Tool: Attempts to automatically solve CAPTCHAs using NopeCHA.

This tool should be used before falling back to HITL intervention when encountering CAPTCHAs.
Supports hCaptcha and reCAPTCHA challenges.
"""

import asyncio
import logging
import os
import time
from typing import Any

from browser_use import Browser

from constants import (
    CAPTCHA_SOLVER_CLICK_DELAY,
    CAPTCHA_SOLVER_MAX_ATTEMPTS,
    CAPTCHA_SOLVER_MAX_DYNAMIC_ROUNDS,
    CAPTCHA_SOLVER_POST_SOLVE_DELAY,
)
from utils.timing_logger import log_timing

logger = logging.getLogger(__name__)


async def _extract_challenge_data(
    captcha_cdp_session: Any,
    detected_type: str,
) -> dict[str, Any]:
    """
    Extract challenge data (task text and images) from the CAPTCHA.

    This function extracts fresh challenge data each time it's called,
    which is important for handling consecutive challenges.

    Args:
        captcha_cdp_session: CDP session for the CAPTCHA iframe
        detected_type: Type of CAPTCHA ('hcaptcha' or 'recaptcha')

    Returns:
        Dictionary with:
            - task_text: str - The challenge prompt
            - image_data: list[str] - Image URLs
            - grid_size: int - Number of grid cells
            - is_composite_image: bool - Whether it's a composite image
            - success: bool - Whether extraction succeeded
    """
    task_text = ""
    image_data: list[str] = []
    grid_size = 9
    is_composite_image = False

    # Extract task/prompt text
    try:
        if detected_type == "hcaptcha":
            selectors = [".prompt-text", ".challenge-header", ".task-title"]
        else:
            selectors = [
                ".rc-imageselect-desc-no-canonical",
                ".rc-imageselect-desc",
                ".rc-imageselect-instructions",
            ]

        for selector in selectors:
            try:
                result = await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                    {
                        "expression": f"""
                            (() => {{
                                const el = document.querySelector('{selector}');
                                return el ? el.innerText : null;
                            }})()
                        """,
                        "returnByValue": True,
                    },
                    session_id=captcha_cdp_session.session_id,
                )
                if result.get("result", {}).get("value"):
                    task_text = result["result"]["value"]
                    break
            except Exception:
                continue

        if not task_text:
            task_text = "Please solve the captcha"
        logger.info(f"CAPTCHA task: {task_text}")

    except Exception as e:
        logger.warning(f"Could not extract CAPTCHA task text: {e}")
        task_text = "Please solve the captcha"

    # Extract image URLs
    try:
        if detected_type == "hcaptcha":
            # hCaptcha: get individual tile images
            grid_selectors = [
                ".task-image img",
                ".challenge-answer img",
                ".task-grid img",
            ]
            for selector in grid_selectors:
                try:
                    result = await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                        {
                            "expression": f"""
                                (() => {{
                                    const imgs = document.querySelectorAll('{selector}');
                                    return Array.from(imgs).map(img => img.src).filter(s => s);
                                }})()
                            """,
                            "returnByValue": True,
                        },
                        session_id=captcha_cdp_session.session_id,
                    )
                    urls = result.get("result", {}).get("value", [])
                    if urls and len(urls) > 0:
                        image_data = urls
                        grid_size = len(urls)
                        logger.debug(f"hCaptcha: Found {len(urls)} tile images")
                        break
                except Exception as e:
                    logger.debug(f"Selector {selector} failed: {e}")
                    continue
        else:
            # reCAPTCHA: Extract tile images
            tile_result = await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                {
                    "expression": """
                    (() => {
                        // Get all tile images
                        const tiles = document.querySelectorAll('.rc-image-tile-wrapper img, .rc-imageselect-tile img, td.rc-imageselect-tile img');
                        const tileSrcs = Array.from(tiles).map(img => img.src).filter(s => s);

                        // Try to find payload image (composite)
                        const payloadImg = document.querySelector('.rc-imageselect-payload');
                        let payloadSrc = null;
                        if (payloadImg) {
                            const style = window.getComputedStyle(payloadImg);
                            const bgImage = style.backgroundImage;
                            if (bgImage && bgImage !== 'none') {
                                payloadSrc = bgImage.replace(/^url\\(['"]?/, '').replace(/['"]?\\)$/, '');
                            }
                        }

                        // Check if all tiles have the same src (composite case)
                        const uniqueSrcs = [...new Set(tileSrcs)];

                        return {
                            tileCount: tileSrcs.length,
                            tileSrcs: tileSrcs.slice(0, 16),
                            uniqueSrcCount: uniqueSrcs.length,
                            payloadSrc: payloadSrc,
                            isComposite: uniqueSrcs.length === 1 && tileSrcs.length > 1
                        };
                    })()
                """,
                    "returnByValue": True,
                },
                session_id=captcha_cdp_session.session_id,
            )
            tile_info = tile_result.get("result", {}).get("value", {})
            logger.debug(
                f"reCAPTCHA tile analysis: {tile_info.get('tileCount')} tiles, "
                f"{tile_info.get('uniqueSrcCount')} unique, "
                f"composite={tile_info.get('isComposite')}"
            )

            tile_count = tile_info.get("tileCount", 0)
            tile_srcs = tile_info.get("tileSrcs", [])
            payload_src = tile_info.get("payloadSrc")
            is_composite = tile_info.get("isComposite", False)

            if payload_src:
                image_data = [payload_src]
                is_composite_image = True
                grid_size = 16 if tile_count == 16 else 9
                logger.info(
                    f"reCAPTCHA: Using composite payload image, grid={grid_size}"
                )
            elif is_composite and tile_srcs:
                image_data = [tile_srcs[0]]
                is_composite_image = True
                grid_size = tile_count if tile_count in [9, 16] else 9
                logger.info(
                    f"reCAPTCHA: Using shared tile as composite image, grid={grid_size}"
                )
            elif tile_srcs:
                image_data = tile_srcs
                is_composite_image = False
                grid_size = len(tile_srcs)
                logger.info(
                    f"reCAPTCHA: Using {len(tile_srcs)} individual tile images (1x1 mode)"
                )

    except Exception as e:
        logger.warning(f"Error extracting CAPTCHA images: {e}")

    return {
        "task_text": task_text,
        "image_data": image_data,
        "grid_size": grid_size,
        "is_composite_image": is_composite_image,
        "success": len(image_data) > 0,
    }


async def solve_captcha_tool(
    browser: Browser,
    captcha_type: str | None = None,
    persona_instance: str | None = None,
) -> dict[str, Any]:
    """
    Attempt to automatically solve CAPTCHA challenges using NopeCHA.

    This tool should be called when a CAPTCHA is detected on the page.
    It will:
    1. Detect the CAPTCHA type (hCaptcha or reCAPTCHA)
    2. Send the challenge to NopeCHA API for solving
    3. Click the correct grid cells based on the solution
    4. Submit the challenge

    Args:
        browser: Browser instance from browser-use
        captcha_type: Optional override for CAPTCHA type ('hcaptcha' or 'recaptcha')
        persona_instance: Optional persona instance name for logging

    Returns:
        Dictionary with:
            - success: bool - Whether CAPTCHA was solved
            - message: str - Status message
            - captcha_detected: bool - Whether CAPTCHA was found on page
            - captcha_type: str | None - Type of CAPTCHA detected
            - solve_attempted: bool - Whether solving was attempted
    """
    # Start timing
    captcha_start_time = time.time()

    # Check if nopecha is available
    try:
        import nopecha
    except ImportError:
        logger.warning("nopecha package not installed, CAPTCHA solving unavailable")
        return {
            "success": False,
            "message": "CAPTCHA solving unavailable: nopecha package not installed",
            "captcha_detected": False,
            "captcha_type": None,
            "solve_attempted": False,
        }

    # Check for API key
    api_key = os.environ.get("NOPECHA_API_KEY")
    if not api_key:
        logger.warning("NOPECHA_API_KEY not set, CAPTCHA solving unavailable")
        return {
            "success": False,
            "message": "CAPTCHA solving unavailable: NOPECHA_API_KEY not configured",
            "captcha_detected": False,
            "captcha_type": None,
            "solve_attempted": False,
        }

    nopecha.api_key = api_key

    try:
        page = await browser.get_current_page()
        if not page:
            logger.error("No current page available")
            return {
                "success": False,
                "message": "No active page available for CAPTCHA solving",
                "captcha_detected": False,
                "captcha_type": None,
                "solve_attempted": False,
            }

        # Use browser-use's CDP-based frame access
        # Get all frames including cross-origin iframes (CAPTCHAs are typically in iframes)
        all_frames, target_sessions = await browser.get_all_frames()

        # Detect CAPTCHA type and find challenge frame
        detected_type = captcha_type
        captcha_frame_id = None
        captcha_frame_url = None
        anchor_frame_id = None  # Track anchor frame separately for reCAPTCHA

        for frame_id, frame_info in all_frames.items():
            frame_url = frame_info.get("url", "").lower()

            # hCaptcha challenge detection
            if "hcaptcha.com" in frame_url:
                if not detected_type:
                    detected_type = "hcaptcha"
                if "getcaptcha" in frame_url or "challenge" in frame_url:
                    captcha_frame_id = frame_id
                    captcha_frame_url = frame_url
                    break

            # reCAPTCHA challenge detection
            # IMPORTANT: bframe contains the actual image challenge, anchor is just the checkbox
            if "google.com/recaptcha" in frame_url:
                if not detected_type:
                    detected_type = "recaptcha"
                if "bframe" in frame_url:
                    # This is the challenge frame with the actual images - prioritize this
                    captcha_frame_id = frame_id
                    captcha_frame_url = frame_url
                    logger.debug(f"Found reCAPTCHA bframe (challenge): {frame_url}")
                    break
                elif "anchor" in frame_url:
                    # Just track the anchor frame but don't use it for solving
                    anchor_frame_id = frame_id
                    logger.debug(f"Found reCAPTCHA anchor (checkbox): {frame_url}")

        # For reCAPTCHA: if we only found anchor frame but no bframe, challenge isn't visible yet
        if detected_type == "recaptcha" and not captcha_frame_id and anchor_frame_id:
            logger.info(
                "reCAPTCHA anchor detected but challenge (bframe) not visible yet"
            )
            return {
                "success": False,
                "message": "reCAPTCHA checkbox detected but image challenge not visible. The checkbox may need to be clicked first, or try waiting for the challenge to appear.",
                "captcha_detected": True,
                "captcha_type": "recaptcha",
                "solve_attempted": False,
            }

        if not captcha_frame_id:
            # Check main page for embedded CAPTCHA elements
            captcha_check = await page.evaluate(
                """
                () => {
                    const hasHCaptcha = document.querySelector('.h-captcha, [data-hcaptcha-sitekey]') !== null;
                    const hasRecaptcha = document.querySelector('.g-recaptcha, [data-sitekey]') !== null;
                    return JSON.stringify({
                        hasHCaptcha: hasHCaptcha,
                        hasRecaptcha: hasRecaptcha
                    });
                }
                """
            )

            import json

            captcha_info = json.loads(captcha_check)

            if captcha_info.get("hasHCaptcha") or captcha_info.get("hasRecaptcha"):
                # CAPTCHA element exists but challenge not yet opened
                logger.info("CAPTCHA element detected but challenge not visible")
                return {
                    "success": False,
                    "message": "CAPTCHA element detected but challenge not visible. Try clicking the checkbox first.",
                    "captcha_detected": True,
                    "captcha_type": "hcaptcha"
                    if captcha_info.get("hasHCaptcha")
                    else "recaptcha",
                    "solve_attempted": False,
                }

            logger.info("No CAPTCHA detected on page")
            return {
                "success": False,
                "message": "No CAPTCHA detected on page",
                "captcha_detected": False,
                "captcha_type": None,
                "solve_attempted": False,
            }

        logger.info(
            f"CAPTCHA challenge detected: {detected_type} in frame {captcha_frame_url}"
        )

        # Get CDP session for the CAPTCHA frame to execute JavaScript in its context
        try:
            captcha_cdp_session = await browser.cdp_client_for_frame(captcha_frame_id)
        except Exception as e:
            logger.warning(f"Could not get CDP session for CAPTCHA frame: {e}")
            return {
                "success": False,
                "message": f"CAPTCHA detected but could not access iframe: {e}. Please use HITL intervention.",
                "captcha_detected": True,
                "captcha_type": detected_type,
                "solve_attempted": False,
            }

        # Call NopeCHA API to solve
        # At this point, detected_type is guaranteed to be set because we would have
        # returned early if no CAPTCHA was detected
        assert detected_type is not None, "detected_type should be set by now"

        for attempt in range(CAPTCHA_SOLVER_MAX_ATTEMPTS):
            try:
                logger.info(
                    f"Attempting CAPTCHA solve (attempt {attempt + 1}/{CAPTCHA_SOLVER_MAX_ATTEMPTS})"
                )

                # Extract fresh challenge data for each attempt
                # This is crucial for handling consecutive challenges where
                # a new challenge appears after the first submission
                challenge_data = await _extract_challenge_data(
                    captcha_cdp_session, detected_type
                )

                if not challenge_data["success"]:
                    logger.warning(
                        f"Could not extract CAPTCHA images on attempt {attempt + 1}"
                    )
                    # Wait a moment and try again - the challenge might still be loading
                    await asyncio.sleep(1.0)
                    continue

                task_text = challenge_data["task_text"]
                image_data = challenge_data["image_data"]
                grid_size = challenge_data["grid_size"]
                is_composite_image = challenge_data["is_composite_image"]

                logger.info(
                    f"Challenge data extracted: task='{task_text[:50]}...', "
                    f"images={len(image_data)}, grid={grid_size}, composite={is_composite_image}"
                )

                # Determine grid format for NopeCHA API
                # NopeCHA API requirements for reCAPTCHA:
                # - grid="3x3" or "4x4": Requires ONE composite (uncropped) image
                # - grid="1x1": For individual images shown sequentially
                if detected_type == "recaptcha":
                    if is_composite_image:
                        # We have a single composite image
                        if grid_size == 16:
                            grid_format = "4x4"
                        else:
                            grid_format = "3x3"
                    else:
                        # We have individual tile images - use 1x1 mode
                        grid_format = "1x1"
                else:
                    # hCaptcha doesn't use grid parameter
                    grid_format = None

                # Use Recognition.solve for image-based CAPTCHAs
                # NopeCHA API reference: https://nopecha.com/api-reference/
                # - type: "recaptcha" or "hcaptcha"
                # - task: The challenge instruction text
                # - image_data: Array of Base64-encoded image data or image URLs
                # - grid: Required for reCAPTCHA - "1x1", "3x3", or "4x4"
                solve_kwargs: dict[str, Any] = {
                    "type": detected_type,
                    "task": task_text,
                    # image_data must always be an array (of URLs or base64 strings)
                    "image_data": image_data,
                }

                # Add grid parameter for reCAPTCHA (required per API docs)
                if detected_type == "recaptcha" and grid_format:
                    solve_kwargs["grid"] = grid_format
                    mode = "composite" if is_composite_image else "individual"
                    logger.info(
                        f"reCAPTCHA solve: grid={grid_format}, mode={mode}, images={len(image_data)}, task={task_text[:50]}..."
                    )

                result = nopecha.Recognition.solve(**solve_kwargs)

                if not result:
                    logger.warning("NopeCHA returned empty solution")
                    continue

                logger.info(f"NopeCHA solution: {result}")

                # Extract the click array from the response
                # NopeCHA returns: {'data': [bool, bool, ...], 'metadata': {}} or just [bool, bool, ...]
                if isinstance(result, dict):
                    clicks = result.get("data", [])
                else:
                    clicks = result

                if not clicks or not isinstance(clicks, list):
                    logger.warning(f"Invalid NopeCHA response format: {result}")
                    continue

                # Find the grid element for coordinate calculation using CDP
                # We need to get bounding box via CDP
                grid_selectors = [
                    ".task-grid",
                    ".challenge-container",
                    ".rc-imageselect-table",
                    ".rc-imageselect-target",
                ]

                box = None
                for selector in grid_selectors:
                    try:
                        box_result = (
                            await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                                {
                                    "expression": f"""
                                    (() => {{
                                        const el = document.querySelector('{selector}');
                                        if (!el) return null;
                                        const rect = el.getBoundingClientRect();
                                        return {{
                                            x: rect.x,
                                            y: rect.y,
                                            width: rect.width,
                                            height: rect.height
                                        }};
                                    }})()
                                """,
                                    "returnByValue": True,
                                },
                                session_id=captcha_cdp_session.session_id,
                            )
                        )
                        box = box_result.get("result", {}).get("value")
                        if box:
                            logger.debug(f"Found grid element with selector {selector}")
                            break
                    except Exception as e:
                        logger.debug(f"Grid selector {selector} failed: {e}")
                        continue

                if not box:
                    logger.warning("Could not locate CAPTCHA grid element")
                    continue

                # Calculate grid dimensions
                # Determine grid layout (3x3, 4x4, or 1x9)
                cols = 3
                if grid_size == 16:
                    cols = 4
                elif grid_size == 9:
                    cols = 3

                # Capture current tile images BEFORE clicking (for dynamic tile detection)
                tile_images_before = await _get_tile_images(captcha_cdp_session)
                logger.debug(
                    f"Captured {len(tile_images_before)} tile images before clicking"
                )

                # Click on cells indicated by NopeCHA using CDP
                cells_clicked = 0
                for index, should_click in enumerate(clicks):
                    if should_click:
                        row = index // cols
                        col = index % cols

                        logger.info(f"Clicking cell [{row},{col}] (index {index})")

                        # Use JavaScript to click the cell by index
                        # Try multiple strategies for finding grid cells
                        click_result = (
                            await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                                {
                                    "expression": f"""
                                    (() => {{
                                        // Strategy 1: Try table cells
                                        const cells = document.querySelectorAll('td.rc-imageselect-tile, .task-image');
                                        if (cells.length > {index}) {{
                                            cells[{index}].click();
                                            return true;
                                        }}
                                        // Strategy 2: Try div grid cells
                                        const divCells = document.querySelectorAll('.challenge-item, .task-grid > div');
                                        if (divCells.length > {index}) {{
                                            divCells[{index}].click();
                                            return true;
                                        }}
                                        // Strategy 3: Try clickable images
                                        const imgs = document.querySelectorAll('.rc-imageselect-tile img, .challenge-image img');
                                        if (imgs.length > {index}) {{
                                            imgs[{index}].click();
                                            return true;
                                        }}
                                        return false;
                                    }})()
                                """,
                                    "returnByValue": True,
                                },
                                session_id=captcha_cdp_session.session_id,
                            )
                        )

                        if click_result.get("result", {}).get("value"):
                            cells_clicked += 1
                            await asyncio.sleep(CAPTCHA_SOLVER_CLICK_DELAY)
                        else:
                            logger.warning(f"Could not click cell {index}")

                if cells_clicked == 0:
                    logger.warning("No cells to click in solution")
                    continue

                # Wait a moment for any animation
                await asyncio.sleep(CAPTCHA_SOLVER_POST_SOLVE_DELAY)

                # Click verify/submit button using CDP
                submit_selectors = [
                    "#submit-button",
                    ".button-submit",
                    ".verify-button-holder button",
                    ".rc-button-default",
                    "button[title='Verify']",
                    "button[title='Submit']",
                    ".verify-button",
                    ".check-button",
                ]

                submit_clicked = False
                for selector in submit_selectors:
                    try:
                        click_result = (
                            await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                                {
                                    "expression": f"""
                                    (() => {{
                                        const btn = document.querySelector('{selector}');
                                        if (btn) {{
                                            btn.click();
                                            return true;
                                        }}
                                        return false;
                                    }})()
                                """,
                                    "returnByValue": True,
                                },
                                session_id=captcha_cdp_session.session_id,
                            )
                        )
                        if click_result.get("result", {}).get("value"):
                            submit_clicked = True
                            logger.info(f"Clicked submit button: {selector}")
                            break
                    except Exception:
                        continue

                if not submit_clicked:
                    logger.warning("Could not find submit button, trying Enter key")
                    await page.press("Enter")

                # Wait for CAPTCHA to process
                await asyncio.sleep(1.5)

                # Handle dynamic tile replacements (reCAPTCHA specific)
                # reCAPTCHA may replace clicked tiles with new images that also need to be checked
                if detected_type == "recaptcha":
                    max_dynamic_rounds = CAPTCHA_SOLVER_MAX_DYNAMIC_ROUNDS
                    current_tile_images = tile_images_before

                    for dynamic_round in range(max_dynamic_rounds):
                        # Check if solved first
                        success = await _check_captcha_solved(
                            browser, page, captcha_cdp_session, detected_type
                        )
                        if success:
                            logger.info("✅ CAPTCHA solved successfully!")
                            return {
                                "success": True,
                                "message": "CAPTCHA solved successfully",
                                "captcha_detected": True,
                                "captcha_type": detected_type,
                                "solve_attempted": True,
                            }

                        # Handle any dynamically replaced tiles
                        handled_new_tiles = await _handle_dynamic_tiles(
                            captcha_cdp_session,
                            task_text,
                            current_tile_images,
                            cols,
                        )

                        if not handled_new_tiles:
                            # No new tiles to handle, break out
                            logger.debug("No more dynamic tiles to handle")
                            break

                        # Update tile images for next round
                        current_tile_images = await _get_tile_images(
                            captcha_cdp_session
                        )

                        # Click submit again after handling new tiles
                        await asyncio.sleep(CAPTCHA_SOLVER_POST_SOLVE_DELAY)
                        for selector in submit_selectors:
                            try:
                                click_result = await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                                    {
                                        "expression": f"""
                                        (() => {{
                                            const btn = document.querySelector('{selector}');
                                            if (btn) {{ btn.click(); return true; }}
                                            return false;
                                        }})()
                                        """,
                                        "returnByValue": True,
                                    },
                                    session_id=captcha_cdp_session.session_id,
                                )
                                if click_result.get("result", {}).get("value"):
                                    logger.info(
                                        f"Clicked submit after dynamic tiles: {selector}"
                                    )
                                    break
                            except Exception:
                                continue

                        await asyncio.sleep(1.5)
                        logger.info(f"Dynamic tile round {dynamic_round + 1} completed")

                # Final check if CAPTCHA was solved
                success = await _check_captcha_solved(
                    browser, page, captcha_cdp_session, detected_type or "hcaptcha"
                )

                if success:
                    logger.info("✅ CAPTCHA solved successfully!")
                    duration = time.time() - captcha_start_time
                    log_timing(
                        "captcha_solver",
                        duration,
                        {
                            "result": "success",
                            "captcha_type": detected_type,
                            "persona": persona_instance,
                        },
                    )
                    return {
                        "success": True,
                        "message": "CAPTCHA solved successfully",
                        "captcha_detected": True,
                        "captcha_type": detected_type,
                        "solve_attempted": True,
                    }
                else:
                    logger.info(
                        f"CAPTCHA not solved on attempt {attempt + 1}, may need retry"
                    )

            except Exception as e:
                logger.warning(f"CAPTCHA solve attempt {attempt + 1} failed: {e}")
                continue

        # All attempts exhausted
        logger.warning("All CAPTCHA solve attempts exhausted")
        duration = time.time() - captcha_start_time
        log_timing(
            "captcha_solver",
            duration,
            {
                "result": "failed",
                "reason": "attempts_exhausted",
                "captcha_type": detected_type,
                "persona": persona_instance,
            },
        )
        return {
            "success": False,
            "message": "CAPTCHA solving failed after maximum attempts",
            "captcha_detected": True,
            "captcha_type": detected_type,
            "solve_attempted": True,
        }

    except Exception as e:
        logger.exception(f"Error during CAPTCHA solving: {e}")
        duration = time.time() - captcha_start_time
        log_timing(
            "captcha_solver",
            duration,
            {
                "result": "error",
                "reason": str(e)[:100],
                "persona": persona_instance,
            },
        )
        return {
            "success": False,
            "message": f"CAPTCHA solving error: {e}",
            "captcha_detected": False,
            "captcha_type": None,
            "solve_attempted": False,
        }


async def _get_tile_images(captcha_cdp_session: Any) -> dict[str | int, str]:
    """
    Get current tile images and their positions.

    Returns:
        Dictionary mapping tile index (as string or int) to image src URL
        Note: JavaScript may return keys as strings, so we handle both types.
    """
    try:
        result = await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
            {
                "expression": """
                (() => {
                    const tiles = document.querySelectorAll('td.rc-imageselect-tile img');
                    const tileMap = {};
                    tiles.forEach((img, index) => {
                        if (img.src) {
                            tileMap[index] = img.src;
                        }
                    });
                    return tileMap;
                })()
                """,
                "returnByValue": True,
            },
            session_id=captcha_cdp_session.session_id,
        )
        return result.get("result", {}).get("value", {})
    except Exception as e:
        logger.debug(f"Failed to get tile images: {e}")
        return {}


async def _handle_dynamic_tiles(
    captcha_cdp_session: Any,
    task_text: str,
    previous_tile_images: dict[str | int, str],
    cols: int,
) -> bool:
    """
    Handle reCAPTCHA dynamic tile replacement.

    After clicking tiles and submitting, reCAPTCHA may replace some tiles
    with new images that also need to be checked.

    Args:
        captcha_cdp_session: CDP session for the CAPTCHA iframe
        task_text: The challenge task text
        previous_tile_images: Map of tile index -> image URL before submission
        cols: Number of columns in the grid

    Returns:
        True if new tiles were handled and clicked, False otherwise
    """
    try:
        import nopecha
    except ImportError:
        return False

    # Wait for tile replacement animation
    await asyncio.sleep(1.0)

    # Get current tile images
    current_tiles = await _get_tile_images(captcha_cdp_session)

    if not current_tiles:
        logger.debug("No tiles found for dynamic check")
        return False

    # Find tiles that have NEW images (different from before)
    new_tiles: dict[int, str] = {}
    for index_key, img_url in current_tiles.items():
        # Normalize index to int for comparison
        index = int(index_key) if isinstance(index_key, str) else index_key
        # Check both string and int keys since JS may return either
        prev_url = previous_tile_images.get(index) or previous_tile_images.get(
            str(index)
        )
        if prev_url != img_url:
            new_tiles[index] = img_url
            logger.debug(f"Tile {index} has new image")

    if not new_tiles:
        logger.debug("No tiles were replaced")
        return False

    logger.info(f"🔄 Detected {len(new_tiles)} replaced tiles, solving new images...")

    # Send only the new tile images to NopeCHA
    new_tile_indices = sorted(new_tiles.keys())
    new_tile_images = [new_tiles[idx] for idx in new_tile_indices]

    # NopeCHA 1x1 mode only supports 1-9 images
    # If more than 9 new tiles (e.g., entire 4x4 grid replaced), return False
    # to let the main loop retry with fresh challenge extraction
    if len(new_tile_images) > 9:
        logger.info(
            f"Too many replaced tiles ({len(new_tile_images)}) for 1x1 mode, treating as new challenge"
        )
        return False

    try:
        result = nopecha.Recognition.solve(
            type="recaptcha",
            task=task_text,
            image_data=new_tile_images,
            grid="1x1",
        )

        if not result:
            logger.warning("NopeCHA returned empty solution for new tiles")
            return False

        logger.info(f"NopeCHA solution for new tiles: {result}")

        # Extract clicks array
        if isinstance(result, dict):
            clicks = result.get("data", [])
        else:
            clicks = result

        if not clicks:
            return False

        # Click the new tiles that match
        cells_clicked = 0
        for i, should_click in enumerate(clicks):
            if should_click and i < len(new_tile_indices):
                tile_index = new_tile_indices[i]
                row = tile_index // cols
                col = tile_index % cols
                logger.info(f"Clicking NEW tile [{row},{col}] (index {tile_index})")

                click_result = (
                    await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                        {
                            "expression": f"""
                        (() => {{
                            const cells = document.querySelectorAll('td.rc-imageselect-tile');
                            if (cells.length > {tile_index}) {{
                                cells[{tile_index}].click();
                                return true;
                            }}
                            return false;
                        }})()
                        """,
                            "returnByValue": True,
                        },
                        session_id=captcha_cdp_session.session_id,
                    )
                )

                if click_result.get("result", {}).get("value"):
                    cells_clicked += 1
                    await asyncio.sleep(CAPTCHA_SOLVER_CLICK_DELAY)

        return cells_clicked > 0

    except Exception as e:
        logger.warning(f"Failed to solve new tiles: {e}")
        return False


async def _check_captcha_solved(
    browser: Any,
    page: Any,
    captcha_cdp_session: Any,
    captcha_type: str,
) -> bool:
    """
    Check if the CAPTCHA was solved successfully.

    Args:
        browser: browser-use Browser instance
        page: browser-use Page instance
        captcha_cdp_session: CDP session for the CAPTCHA iframe
        captcha_type: Type of CAPTCHA ('hcaptcha' or 'recaptcha')

    Returns:
        True if CAPTCHA appears to be solved
    """
    try:
        # Check for success indicators on the main page using Page.evaluate
        if captcha_type == "hcaptcha":
            # hCaptcha success indicators
            success_check = await page.evaluate(
                """
                () => {
                    // Check if challenge container is hidden
                    const challenge = document.querySelector('[data-hcaptcha-response]');
                    if (challenge && challenge.value && challenge.value.length > 0) {
                        return 'true';
                    }
                    return 'false';
                }
                """
            )
            if success_check == "true":
                logger.info("hCaptcha response token found - solved!")
                return True

        else:
            # reCAPTCHA success indicators
            success_check = await page.evaluate(
                """
                () => {
                    // Check for response token
                    const response = document.querySelector('#g-recaptcha-response, [name="g-recaptcha-response"]');
                    if (response && response.value && response.value.length > 0) {
                        return 'true';
                    }

                    // Check for success class on checkbox
                    const checkbox = document.querySelector('.recaptcha-checkbox-checked');
                    if (checkbox) {
                        return 'true';
                    }

                    return 'false';
                }
                """
            )
            if success_check == "true":
                logger.info("reCAPTCHA response token or success class found - solved!")
                return True

        # Check if CAPTCHA frames are still present
        await asyncio.sleep(0.5)
        all_frames, _ = await browser.get_all_frames()

        has_captcha_frame = False
        for _frame_id, frame_info in all_frames.items():
            frame_url = frame_info.get("url", "").lower()
            if "hcaptcha.com" in frame_url or "recaptcha" in frame_url:
                # Check if it's still a challenge frame
                if (
                    "getcaptcha" in frame_url
                    or "bframe" in frame_url
                    or "challenge" in frame_url
                ):
                    has_captcha_frame = True
                    break

        if not has_captcha_frame:
            logger.info(
                "CAPTCHA challenge frames no longer present - likely solved or page changed"
            )
            return True

        # Check for error messages in the captcha iframe that indicate we need to retry
        try:
            error_result = await captcha_cdp_session.cdp_client.send.Runtime.evaluate(
                {
                    "expression": """
                        (() => {
                            const error = document.querySelector('.display-error, .rc-imageselect-error-dynamic-more, .rc-imageselect-error-select-more');
                            return error ? error.innerText : '';
                        })()
                    """,
                    "returnByValue": True,
                },
                session_id=captcha_cdp_session.session_id,
            )
            error_text = error_result.get("result", {}).get("value", "")
            if error_text and (
                "try again" in error_text.lower() or "select" in error_text.lower()
            ):
                logger.info(f"CAPTCHA error detected: {error_text}")
                return False
        except Exception:
            pass

        return False

    except Exception as e:
        logger.warning(f"Error checking CAPTCHA status: {e}")
        return False


async def detect_captcha(browser: Any, page: Any) -> dict[str, Any]:
    """
    Detect if there's a CAPTCHA on the current page.

    Args:
        browser: browser-use Browser instance
        page: browser-use Page instance

    Returns:
        Dictionary with:
            - detected: bool - Whether CAPTCHA was detected
            - captcha_type: str | None - Type of CAPTCHA ('hcaptcha' or 'recaptcha')
            - challenge_visible: bool - Whether the challenge is visible (not just checkbox)
    """
    try:
        # Check frames for CAPTCHA iframes using browser-use
        all_frames, _ = await browser.get_all_frames()

        for _frame_id, frame_info in all_frames.items():
            frame_url = frame_info.get("url", "").lower()

            if "hcaptcha.com" in frame_url:
                challenge_visible = (
                    "getcaptcha" in frame_url or "challenge" in frame_url
                )
                return {
                    "detected": True,
                    "captcha_type": "hcaptcha",
                    "challenge_visible": challenge_visible,
                }

            if "google.com/recaptcha" in frame_url:
                challenge_visible = "bframe" in frame_url
                return {
                    "detected": True,
                    "captcha_type": "recaptcha",
                    "challenge_visible": challenge_visible,
                }

        # Check for CAPTCHA elements in main page using Page.evaluate
        captcha_check = await page.evaluate(
            """
            () => {
                const hasHCaptcha = document.querySelector('.h-captcha, [data-hcaptcha-sitekey]') !== null;
                const hasRecaptcha = document.querySelector('.g-recaptcha, [data-sitekey]') !== null;
                return JSON.stringify({
                    hasHCaptcha: hasHCaptcha,
                    hasRecaptcha: hasRecaptcha
                });
            }
            """
        )

        import json

        captcha_info = json.loads(captcha_check)

        if captcha_info.get("hasHCaptcha"):
            return {
                "detected": True,
                "captcha_type": "hcaptcha",
                "challenge_visible": False,
            }

        if captcha_info.get("hasRecaptcha"):
            return {
                "detected": True,
                "captcha_type": "recaptcha",
                "challenge_visible": False,
            }

        return {
            "detected": False,
            "captcha_type": None,
            "challenge_visible": False,
        }

    except Exception as e:
        logger.warning(f"Error detecting CAPTCHA: {e}")
        return {
            "detected": False,
            "captcha_type": None,
            "challenge_visible": False,
        }
