"""
Fast Typing Module - Browser CDP-based text input.

This module provides fast text input using Chrome DevTools Protocol (CDP)
for character-by-character typing bypass and proper event triggering.
Supports Shadow DOM traversal and submit button detection.

Extracted from chat_runner.py for reuse in subagents.
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class TypingResult:
    """Result of fast typing operation."""

    success: bool
    message: str
    fingerprint: str | None = None  # Pre-send fingerprint for change detection
    error: str | None = None


class FastTyper:
    """
    Handles fast text input using CDP for Shadow DOM support.

    Uses browser-use's built-in CDP session to bypass slow character-by-character
    typing and properly trigger React/Vue/Angular onChange handlers.
    """

    def __init__(self, browser_session: Any):
        """
        Initialize the fast typer.

        Args:
            browser_session: The browser-use BrowserSession instance
        """
        self.browser_session = browser_session

    def make_fingerprint(self, content: str) -> str:
        """Create content fingerprint for change detection."""
        content_hash = hashlib.md5(content.encode()).hexdigest()[:16]
        return f"{len(content)}:{content_hash}"

    async def type_and_submit(
        self,
        selector: str,
        text: str,
        press_enter: bool = True,
    ) -> TypingResult:
        """
        Type text into an input field and optionally submit.

        Uses CDP Input.insertText for fast, reliable text input that properly
        triggers framework event handlers (React, Vue, Angular).

        CRITICAL: Captures pre-send fingerprint BEFORE typing for change detection.

        Args:
            selector: CSS selector for the input field
            text: The full text to type into the field
            press_enter: Whether to press Enter after typing (default: True)

        Returns:
            TypingResult with success status, message, and pre-send fingerprint
        """
        pre_send_fingerprint: str | None = None

        try:
            logger.info(f"🔍 Attempting fast_type_and_submit with selector: {selector}")

            # Get the current page actor
            page = await self.browser_session.get_current_page()
            if not page:
                logger.error("❌ No current page available")
                return TypingResult(
                    success=False,
                    message="No current page - cannot use fast typing",
                    error="No current page available",
                )

            logger.info("✅ Got page for fast typing")

            # CRITICAL: Capture page fingerprint BEFORE typing
            # This is essential for change detection in response extraction
            try:
                content, _ = await page._extract_clean_markdown()
                pre_send_fingerprint = self.make_fingerprint(content)
                logger.debug(
                    f"📸 Captured pre-send fingerprint: {pre_send_fingerprint}"
                )
            except Exception as e:
                logger.warning(f"Failed to capture pre-send fingerprint: {e}")
                pre_send_fingerprint = None

            # Use JavaScript to focus element with Shadow DOM support
            set_value_js = f"""
          () => {{
              const selector = {json.dumps(selector)};
              const text = {json.dumps(text)};

              // Recursive shadow DOM traversal for a single selector part
              const findInShadowDOM = (root, sel) => {{
                  if (!root) return null;
                  try {{ let found = root.querySelector(sel); if (found) return found; }} catch(e) {{}}
                  const hosts = root.querySelectorAll('*');
                  for (const host of hosts) {{
                      if (host.shadowRoot) {{
                          const found = findInShadowDOM(host.shadowRoot, sel);
                          if (found) return found;
                      }}
                  }}
                  return null;
              }};

              // Handle >>> shadow DOM piercing combinator
              const findElement = (sel) => {{
                  const parts = sel.split('>>>').map(s => s.trim());
                  let current = document;
                  for (let i = 0; i < parts.length; i++) {{
                      const part = parts[i];
                      let found = null;
                      try {{ found = current.querySelector(part); }} catch(e) {{}}
                      if (!found) found = findInShadowDOM(current, part);
                      if (!found) return null;
                      if (i < parts.length - 1 && found.shadowRoot) {{
                          current = found.shadowRoot;
                      }} else {{
                          current = found;
                      }}
                  }}
                  return current === document ? null : current;
              }};

              let el = findElement(selector);

              if (!el) return JSON.stringify({{success: false, error: 'Element not found'}});

              try {{
                  // Focus the element first
                  el.focus();
                  el.click();

                  // Return the element info so we can type into it via CDP
                  return JSON.stringify({{
                      success: true,
                      focused: true,
                      tagName: el.tagName,
                      type: el.type
                  }});
              }} catch (e) {{
                  return JSON.stringify({{success: false, error: e.message}});
              }}
          }}
      """

            result_json = await page.evaluate(set_value_js)
            result = json.loads(result_json)

            if not result.get("success"):
                error = result.get("error", "Unknown error")
                logger.error(f"❌ Failed to focus element: {error}")
                return TypingResult(
                    success=False,
                    message=f"Failed to focus element: {error}",
                    fingerprint=pre_send_fingerprint,
                    error=error,
                )

            logger.info("✅ Focused element, now typing via CDP...")

            # Type text using CDP Input.insertText
            cdp_session = await self.browser_session.get_or_create_cdp_session()
            await cdp_session.cdp_client.send.Input.insertText(
                params={"text": text}, session_id=cdp_session.session_id
            )

            logger.info(f"✅ Inserted text via CDP: {len(text)} characters")

            # Submit if requested
            if press_enter:
                await asyncio.sleep(0.5)  # Wait for change detection to propagate

                # Try to find and click submit button
                submit_clicked = await self._try_click_submit(page, selector)

                if not submit_clicked:
                    # Fallback: Press Enter using CDP
                    await self._press_enter_via_cdp(cdp_session)

                submit_method = "submit button" if submit_clicked else "Enter"

                # Re-capture fingerprint AFTER submit so the detector baseline
                # includes the user's sent message in the DOM.  Without this,
                # the detector sees the user's message as a "content change" and
                # returns COMPLETE before the chatbot has actually responded.
                post_send_fingerprint = pre_send_fingerprint
                try:
                    await asyncio.sleep(2.0)  # Wait for user message to render in DOM
                    post_content, _ = await page._extract_clean_markdown()
                    post_send_fingerprint = self.make_fingerprint(post_content)
                    logger.debug(
                        f"📸 Post-send fingerprint: {post_send_fingerprint} "
                        f"(was: {pre_send_fingerprint})"
                    )
                except Exception as e:
                    logger.warning(f"Failed to capture post-send fingerprint: {e}")

                return TypingResult(
                    success=True,
                    message=f"✅ Typed '{text[:50]}...' and clicked {submit_method}",
                    fingerprint=post_send_fingerprint,
                )

            return TypingResult(
                success=True,
                message=f"✅ Typed '{text[:50]}...' into field",
                fingerprint=pre_send_fingerprint,
            )

        except Exception as e:
            logger.error(f"❌ Fast typing FAILED: {e}")
            return TypingResult(
                success=False,
                message=f"fast_type_and_submit failed: {str(e)}",
                fingerprint=pre_send_fingerprint,
                error=str(e),
            )

    async def _try_click_submit(self, page: Any, input_selector: str) -> bool:
        """Try to find and click submit button near the input element."""
        click_submit_js = f"""
        () => {{
            const selector = {json.dumps(input_selector)};

            // Recursive shadow DOM traversal for a single selector part
            const findInShadowDOM = (root, sel) => {{
                if (!root) return null;
                try {{ let found = root.querySelector(sel); if (found) return found; }} catch(e) {{}}
                const hosts = root.querySelectorAll('*');
                for (const host of hosts) {{
                    if (host.shadowRoot) {{
                        const found = findInShadowDOM(host.shadowRoot, sel);
                        if (found) return found;
                    }}
                }}
                return null;
            }};

            // Handle >>> shadow DOM piercing combinator
            const findElement = (sel) => {{
                const parts = sel.split('>>>').map(s => s.trim());
                let current = document;
                for (let i = 0; i < parts.length; i++) {{
                    const part = parts[i];
                    let found = null;
                    try {{ found = current.querySelector(part); }} catch(e) {{}}
                    if (!found) found = findInShadowDOM(current, part);
                    if (!found) return null;
                    if (i < parts.length - 1 && found.shadowRoot) {{
                        current = found.shadowRoot;
                    }} else {{
                        current = found;
                    }}
                }}
                return current === document ? null : current;
            }};

            let input = findElement(selector);

            if (!input) return JSON.stringify({{clicked: false, reason: 'Input not found'}});

            // Look for submit button - check parent elements
            let parent = input.parentElement;
            let attempts = 0;
            while (parent && attempts < 5) {{
                // Look for button with type="submit" or common submit patterns
                let submitBtn = parent.querySelector('button[type="submit"]') ||
                               parent.querySelector('button[aria-label*="send" i]') ||
                               parent.querySelector('button[aria-label*="submit" i]') ||
                               parent.querySelector('button.send') ||
                               parent.querySelector('button.submit') ||
                               parent.querySelector('[role="button"][aria-label*="send" i]');

                if (submitBtn && !submitBtn.disabled) {{
                    submitBtn.click();
                    return JSON.stringify({{clicked: true, button: submitBtn.outerHTML.substring(0, 100)}});
                }}

                parent = parent.parentElement;
                attempts++;
            }}

            return JSON.stringify({{clicked: false, reason: 'No enabled submit button found'}});
        }}
    """

        click_result_json = await page.evaluate(click_submit_js)
        click_result = json.loads(click_result_json)

        if click_result.get("clicked"):
            logger.info(
                f"✅ Clicked submit button: {click_result.get('button', '')[:50]}..."
            )
            return True
        else:
            logger.info(
                f"⚠️  Submit button not found ({click_result.get('reason')}), trying Enter key..."
            )
            return False

    async def _press_enter_via_cdp(self, cdp_session: Any) -> None:
        """Press Enter key using CDP dispatchKeyEvent."""
        await cdp_session.cdp_client.send.Input.dispatchKeyEvent(
            params={
                "type": "keyDown",
                "key": "Enter",
                "code": "Enter",
                "windowsVirtualKeyCode": 13,
                "nativeVirtualKeyCode": 13,
            },
            session_id=cdp_session.session_id,
        )
        await cdp_session.cdp_client.send.Input.dispatchKeyEvent(
            params={
                "type": "keyUp",
                "key": "Enter",
                "code": "Enter",
                "windowsVirtualKeyCode": 13,
                "nativeVirtualKeyCode": 13,
            },
            session_id=cdp_session.session_id,
        )
        logger.info("✅ Pressed Enter via CDP as fallback")
