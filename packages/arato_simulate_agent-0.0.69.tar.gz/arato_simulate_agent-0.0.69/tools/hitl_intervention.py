"""HITL (Human-in-the-Loop) intervention tool for browser-use agents.

This tool allows agents to request human intervention when encountering
tasks that require human assistance (e.g., captchas, login forms, etc.).

The tool is platform-agnostic and works with both AWS AgentCore and Local platforms,
using the BrowserManager interface for HITL operations.
"""

import contextvars
import logging
import time
import uuid
from datetime import UTC, datetime
from typing import Any

from browser_use import Browser

from constants import HITL_DEFAULT_TIMEOUT_SECONDS
from core.browser import get_browser_manager
from utils.hitl_learning import generate_intervention_summary
from utils.hitl_utils import HITLInterventionType, HITLState

logger = logging.getLogger(__name__)

# Context variable to hold the browser instance for screenshot capture
_browser_context: contextvars.ContextVar[Browser | None] = contextvars.ContextVar(
    "browser_context", default=None
)

# Context variables for polling task management during HITL
_polling_client_context: contextvars.ContextVar[Any | None] = contextvars.ContextVar(
    "polling_client_context", default=None
)
_task_context: contextvars.ContextVar[Any | None] = contextvars.ContextVar(
    "task_context", default=None
)
_agent_identity_context: contextvars.ContextVar[Any | None] = contextvars.ContextVar(
    "agent_identity_context", default=None
)
_progress_tracker_context: contextvars.ContextVar[Any | None] = contextvars.ContextVar(
    "progress_tracker_context", default=None
)
_persona_instance_context: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "persona_instance_context", default=None
)


def set_browser_context(browser: Browser | None) -> None:
    """Set the browser instance for screenshot capture during interventions.

    This should be called by the agent/controller before running tasks that may
    need human intervention.

    Args:
        browser: Browser instance to use for screenshots, or None to clear
    """
    _browser_context.set(browser)


def get_browser_context() -> Browser | None:
    """Get the current browser instance for screenshot capture.

    Returns:
        Browser instance or None if not set
    """
    return _browser_context.get()


def set_polling_context(
    polling_client: Any | None,
    task: Any | None,
    agent_identity: Any | None = None,
    progress_tracker: Any | None = None,
    persona_instance: str | None = None,
) -> None:
    """Set the polling client, task, agent identity, and progress tracker for HITL status updates.

    This should be called by the orchestrator before running agents that may
    need human intervention.

    Args:
        polling_client: TaskPollingClient instance for status updates, or None to clear
        task: TaskPayload instance for the current task, or None to clear
        agent_identity: AgentIdentity instance for status updates, or None to clear
        progress_tracker: ProgressTracker instance for progress updates, or None to clear
        persona_instance: Persona instance name for progress updates, or None to clear
    """
    _polling_client_context.set(polling_client)
    _task_context.set(task)
    _agent_identity_context.set(agent_identity)
    _progress_tracker_context.set(progress_tracker)
    _persona_instance_context.set(persona_instance)


def get_polling_context() -> tuple[
    Any | None, Any | None, Any | None, Any | None, str | None
]:
    """Get the current polling client, task, agent identity, progress tracker, and persona instance.

    Returns:
        Tuple of (polling_client, task, agent_identity, progress_tracker, persona_instance)
    """
    return (
        _polling_client_context.get(),
        _task_context.get(),
        _agent_identity_context.get(),
        _progress_tracker_context.get(),
        _persona_instance_context.get(),
    )


async def request_human_intervention(
    reason: str,
    intervention_type: str = "custom",
    timeout_seconds: int = HITL_DEFAULT_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    """Request human intervention and wait for completion.

    This function is designed to be used as a custom action/tool in browser-use agents.
    It pauses agent execution and waits for a human to complete a required action.

    The function automatically retrieves the browser manager from the global singleton,
    making it platform-agnostic and easy to use in agent tools.

    Args:
        reason: Human-readable explanation of why intervention is needed
        intervention_type: Type of intervention (captcha, login, verification, consent, custom)
        timeout_seconds: Maximum time to wait for completion (default: 600 seconds)

    Returns:
        Dictionary with intervention result:
            - success: bool - Whether intervention completed successfully
            - intervention_id: str - Unique identifier for this intervention
            - state: str - Final state (completed, timeout, error)
            - message: str - Human-readable result message
            - url_before: str - URL before intervention (optional)
            - url_after: str - URL after intervention (optional)
            - duration_seconds: float - How long intervention took (optional)
            - learning_summary: str - Human-readable summary for agent context (optional)
            - error: str (optional) - Error message if failed

    Raises:
        TimeoutError: If intervention times out
        RuntimeError: If intervention encounters an error

    Example:
        >>> result = await request_human_intervention(
        ...     reason='Please solve the captcha on this page',
        ...     intervention_type='captcha'
        ... )
        >>> if result['success']:
        ...     print('Human completed the captcha, continuing...')
        ...     print(result['learning_summary'])  # What changed during intervention
    """
    logger.info(f"🤚 HITL intervention requested: {reason} (type={intervention_type})")

    # Track start time for duration calculation
    start_time = time.time()

    # Initialize intervention_id to handle error cases before it's assigned
    intervention_id: str = ""

    # Validate and convert intervention type to enum
    try:
        intervention_type_enum = HITLInterventionType(intervention_type)
    except ValueError:
        logger.warning(
            f'Invalid intervention type "{intervention_type}", using "custom"'
        )
        intervention_type_enum = HITLInterventionType.CUSTOM

    # Get browser manager from global singleton
    browser_manager = get_browser_manager()

    # Capture URL before intervention (if browser is available)
    url_before = None
    try:
        url_before = await browser_manager.get_current_url()
    except Exception as e:
        logger.warning(f"⚠️  Could not capture URL before intervention: {e}")

    # Capture screenshot before intervention
    screenshot_url = None
    try:
        browser = get_browser_context()
        if browser is not None:
            logger.info("Capturing screenshot for intervention...")
            from utils.screenshot_utils import capture_and_upload_screenshot

            # Get session ID from browser manager
            session_id = getattr(browser_manager, "_session_id", None) or "unknown"
            temp_intervention_id = str(uuid.uuid4())

            screenshot_url = await capture_and_upload_screenshot(
                browser=browser,
                upload_type="hitl",
                session_id=session_id,
                intervention_id=temp_intervention_id,
            )
        else:
            logger.debug("Browser context not available for screenshot")
    except Exception as e:
        logger.warning(f"Could not capture/upload screenshot: {e}")

    try:
        # Step 1: Request intervention (platform-specific implementation)
        intervention_id = await browser_manager.request_intervention(
            reason=reason,
            intervention_type=intervention_type_enum,
            timeout_seconds=timeout_seconds,
            url_before=url_before,
            screenshot_url=screenshot_url,
        )

        logger.info(f"✓ Intervention requested: ID={intervention_id}")

        # Mark task as WAIT before blocking on intervention
        (
            polling_client,
            task,
            agent_identity,
            progress_tracker,
            persona_instance,
        ) = get_polling_context()
        if polling_client and task and intervention_id:
            try:
                # Build intervention details for progress update
                intervention_details = {
                    "intervention_id": intervention_id,
                    "reason": reason,
                    "intervention_type": intervention_type,
                    "requested_at": datetime.now(UTC).isoformat(),
                    "timeout_seconds": timeout_seconds,
                    "url_before": url_before,
                    "screenshot_url": screenshot_url,
                    "state": "waiting",
                }

                # Update progress tracker if available
                if progress_tracker and persona_instance:
                    logger.info(
                        f"📝 Updating progress for {persona_instance} with HITL intervention"
                    )
                    progress_tracker.update_persona(
                        instance_name=persona_instance,
                        last_action=f"Waiting for HITL: {reason}",
                        hitl_intervention=intervention_details,
                    )

                # Mark task as WAIT
                logger.info(f"📝 Marking task as WAIT (intervention {intervention_id})")
                await polling_client.mark_wait(task, agent_identity)
                logger.info("✓ Task marked as WAIT with intervention details")
            except Exception as e:
                logger.warning(f"Failed to mark task as WAIT: {e}")

        # If no intervention ID returned (e.g., local platform), assume immediate completion
        if not intervention_id:
            logger.info("Local platform detected - intervention handled manually")
            duration_seconds = time.time() - start_time

            # Capture URL after intervention
            url_after = None
            try:
                url_after = await browser_manager.get_current_url()
            except Exception as e:
                logger.debug(f"Could not capture URL after intervention: {e}")

            # Generate learning summary
            summary = generate_intervention_summary(
                intervention_type=intervention_type,
                reason=reason,
                url_before=url_before,
                url_after=url_after,
                duration_seconds=duration_seconds,
                outcome="completed",
            )

            return {
                "success": True,
                "intervention_id": "",
                "state": HITLState.COMPLETED.value,
                "message": "Manual intervention (local platform)",
                "url_before": url_before,
                "url_after": url_after,
                "duration_seconds": duration_seconds,
                "learning_summary": summary,
            }

        # Step 2: Wait for human to complete the intervention
        logger.info(
            f"⏳ Waiting for human to complete intervention {intervention_id}..."
        )

        result = await browser_manager.wait_for_intervention_completion(
            intervention_id=intervention_id,
            timeout_seconds=timeout_seconds,
        )

        state = result.get("state", "unknown")
        duration_seconds = time.time() - start_time

        logger.info(
            f"✓ Intervention {intervention_id} completed with state: {state} (duration: {duration_seconds:.1f}s)"
        )

        # Mark task as ACTIVE after intervention completes (resuming work)
        (
            polling_client,
            task,
            agent_identity,
            progress_tracker,
            persona_instance,
        ) = get_polling_context()
        if polling_client and task and state == HITLState.COMPLETED.value:
            try:
                # Clear HITL intervention from progress tracker
                if progress_tracker and persona_instance:
                    logger.info(
                        f"📝 Clearing HITL intervention from {persona_instance}"
                    )
                    progress_tracker.update_persona(
                        instance_name=persona_instance,
                        last_action=f"Resumed after HITL intervention: {reason}",
                        hitl_intervention=None,  # Clear intervention
                    )

                logger.info(
                    f"📝 Marking task as ACTIVE (resuming after intervention {intervention_id})"
                )
                command_response = await polling_client.mark_active(
                    task, agent_identity
                )
                logger.info(
                    f"✓ Task marked as ACTIVE (command: {command_response.command})"
                )
            except Exception as e:
                logger.warning(f"Failed to mark task as ACTIVE: {e}")

        # Capture URL after intervention
        url_after = None
        try:
            url_after = await browser_manager.get_current_url()
            logger.debug(f"Captured URL after intervention: {url_after}")
        except Exception as e:
            logger.debug(f"Could not capture URL after intervention: {e}")

        # Generate learning summary for the agent
        summary = generate_intervention_summary(
            intervention_type=intervention_type,
            reason=reason,
            url_before=url_before,
            url_after=url_after,
            duration_seconds=duration_seconds,
            outcome=state,
        )

        logger.info(f"📚 Learning summary: {summary}")

        return {
            "success": state == HITLState.COMPLETED.value,
            "intervention_id": intervention_id,
            "state": state,
            "message": f"Intervention {state}",
            "completed_at": result.get("completed_at"),
            "url_before": url_before,
            "url_after": url_after,
            "duration_seconds": duration_seconds,
            "learning_summary": summary,
        }

    except TimeoutError as e:
        error_msg = f"Intervention timed out: {e}"
        logger.error(error_msg)
        duration_seconds = time.time() - start_time

        summary = generate_intervention_summary(
            intervention_type=intervention_type,
            reason=reason,
            url_before=url_before,
            url_after=None,
            duration_seconds=duration_seconds,
            outcome="timeout",
        )

        return {
            "success": False,
            "intervention_id": intervention_id if "intervention_id" in locals() else "",
            "state": HITLState.TIMEOUT.value,
            "message": "Human intervention timed out",
            "error": str(e),
            "url_before": url_before,
            "duration_seconds": duration_seconds,
            "learning_summary": summary,
        }

    except RuntimeError as e:
        error_msg = f"Intervention error: {e}"
        logger.error(error_msg)
        duration_seconds = time.time() - start_time

        summary = generate_intervention_summary(
            intervention_type=intervention_type,
            reason=reason,
            url_before=url_before,
            url_after=None,
            duration_seconds=duration_seconds,
            outcome="error",
        )

        return {
            "success": False,
            "intervention_id": intervention_id if "intervention_id" in locals() else "",
            "state": HITLState.ERROR.value,
            "message": "Intervention encountered an error",
            "error": str(e),
            "url_before": url_before,
            "duration_seconds": duration_seconds,
            "learning_summary": summary,
        }

    except Exception as e:
        error_msg = f"Unexpected error during intervention: {e}"
        logger.exception(error_msg)
        duration_seconds = time.time() - start_time

        summary = generate_intervention_summary(
            intervention_type=intervention_type,
            reason=reason,
            url_before=url_before,
            url_after=None,
            duration_seconds=duration_seconds,
            outcome="error",
        )

        return {
            "success": False,
            "intervention_id": intervention_id if "intervention_id" in locals() else "",
            "state": HITLState.ERROR.value,
            "message": "Unexpected intervention error",
            "error": str(e),
            "url_before": url_before,
            "duration_seconds": duration_seconds,
            "learning_summary": summary,
        }


def get_hitl_intervention_types() -> list[str]:
    """Get list of valid intervention types.

    Returns:
        List of intervention type strings
    """
    return [t.value for t in HITLInterventionType]


__all__ = [
    "request_human_intervention",
    "get_hitl_intervention_types",
    "set_browser_context",
    "get_browser_context",
    "set_polling_context",
    "get_polling_context",
]
