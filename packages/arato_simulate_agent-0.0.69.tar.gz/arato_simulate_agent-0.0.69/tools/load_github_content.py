#!/usr/bin/env python3
"""
Load content from GitHub repositories.
Supports loading individual files or entire directories of markdown/text files.
Caches content with version tracking to avoid unnecessary downloads.
Uses storage adapter for persistent caching across invocations with 30-day expiration.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

import httpx

from core.storage import StorageAdapter, get_storage_adapter

logger = logging.getLogger(__name__)


class GitHubContentLoader:
    """Load content from GitHub repositories with storage adapter caching."""

    def __init__(
        self,
        cache_dir: str | None = None,
        use_storage: bool = True,
        storage_adapter: StorageAdapter | None = None,
    ):
        """
        Initialize GitHub content loader.

        Args:
            cache_dir: Optional directory to cache downloaded content locally
            use_storage: Enable storage adapter caching (default: True)
            storage_adapter: Optional storage adapter instance (uses global if not provided)
        """
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.use_storage = use_storage
        self._storage = storage_adapter or (
            get_storage_adapter() if use_storage else None
        )

    def _get_storage_key(self, owner: str, repo: str, ref: str, path: str) -> str:
        """
        Generate storage key for cached GitHub content.

        Args:
            owner: Repository owner
            repo: Repository name
            ref: Branch/tag/commit
            path: File path within repo

        Returns:
            Storage key for the cached content
        """
        # Sanitize path for storage key
        safe_path = path.replace("/", "_").replace("\\", "_") if path else "root"
        return f"github_cache/{owner}/{repo}/{ref}/{safe_path}.json"

    async def _check_storage_cache(
        self, owner: str, repo: str, ref: str, path: str
    ) -> tuple[str | None, dict[str, str] | None]:
        """
        Check if content exists in storage cache and is not expired.

        Args:
            owner: Repository owner
            repo: Repository name
            ref: Branch/tag/commit
            path: File path within repo

        Returns:
            Tuple of (content, metadata) if found and not expired, otherwise (None, None)
        """
        if not self.use_storage or not self._storage:
            return None, None

        try:
            storage_key = self._get_storage_key(owner, repo, ref, path)
            domain = f"{owner}/{repo}"

            logger.info(f"Checking storage cache: {domain}/{storage_key}")

            # Try to download from storage
            cached_data_str = self._storage.download_cache(domain, storage_key)
            if not cached_data_str:
                logger.info(f"Storage cache miss: {domain}/{storage_key}")
                return None, None

            # Parse cached data
            cached_data = json.loads(cached_data_str)

            # Check if cache is expired (30 days)
            cached_at_str = cached_data.get("metadata", {}).get("cached_at")
            if cached_at_str:
                cached_at = datetime.fromisoformat(cached_at_str)
                age = datetime.now(UTC) - cached_at
                if age > timedelta(days=30):
                    logger.info(
                        f"Storage cache expired (age: {age.days} days, max: 30 days): {storage_key}"
                    )
                    return None, None

                content = cached_data.get("content")
                metadata = cached_data.get("metadata", {})

                logger.info(
                    f"✓ Storage cache hit (age: {age.days} days): {storage_key} ({len(content) if content else 0} chars)"
                )
                return content, metadata

            # No cached_at metadata, treat as valid but log warning
            logger.warning(f"Storage cache has no timestamp: {storage_key}")
            content = cached_data.get("content")
            metadata = cached_data.get("metadata", {})
            return content, metadata

        except Exception as e:
            logger.error(f"Error checking storage cache: {e}", exc_info=True)
            return None, None

    async def _save_to_storage_cache(
        self, owner: str, repo: str, ref: str, path: str, content: str, sha: str | None
    ) -> None:
        """
        Save content to storage cache.

        Args:
            owner: Repository owner
            repo: Repository name
            ref: Branch/tag/commit
            path: File path within repo
            content: Content to cache
            sha: Git SHA of the content
        """
        if not self.use_storage or not self._storage:
            return

        try:
            storage_key = self._get_storage_key(owner, repo, ref, path)
            domain = f"{owner}/{repo}"

            # Package content with metadata
            cache_data = {
                "content": content,
                "metadata": {
                    "sha": sha,
                    "ref": ref,
                    "cached_at": datetime.now(UTC).isoformat(),
                },
            }

            logger.info(f"Saving to storage cache: {domain}/{storage_key}")
            self._storage.upload_cache(
                domain,
                json.dumps(cache_data),
                storage_key,
            )
            logger.info(
                f"✓ Saved to storage cache: {storage_key} ({len(content)} chars, SHA: {sha[:8] if sha else 'none'})"
            )

        except Exception as e:
            logger.error(
                f"Error saving to storage cache: {e}", exc_info=True, stack_info=True
            )

    def _parse_github_url(self, url: str) -> dict[str, str] | None:
        """
        Parse a GitHub URL to extract owner, repo, and path.

        Supports:
        - https://github.com/owner/repo
        - https://github.com/owner/repo/blob/main/file.md
        - https://github.com/owner/repo/tree/main/dir

        Returns:
            Dict with owner, repo, ref (branch), and path, or None if invalid
        """
        parsed = urlparse(url)
        if parsed.netloc != "github.com":
            return None

        parts = [p for p in parsed.path.split("/") if p]
        if len(parts) < 2:
            return None

        owner = parts[0]
        repo = parts[1]
        ref = "main"  # Default branch
        path = ""

        # Handle blob/tree URLs
        if len(parts) > 2:
            if parts[2] in ("blob", "tree"):
                if len(parts) > 3:
                    ref = parts[3]
                if len(parts) > 4:
                    path = "/".join(parts[4:])
            else:
                # Assume it's a path without blob/tree
                path = "/".join(parts[2:])

        return {"owner": owner, "repo": repo, "ref": ref, "path": path}

    def _get_raw_url(self, owner: str, repo: str, ref: str, path: str) -> str:
        """
        Convert GitHub URL to raw content URL.

        Args:
            owner: Repository owner
            repo: Repository name
            ref: Branch/tag/commit
            path: File path within repo

        Returns:
            Raw content URL
        """
        return f"https://raw.githubusercontent.com/{owner}/{repo}/{ref}/{path}"

    def _get_cache_path(
        self, owner: str, repo: str, ref: str, path: str
    ) -> Path | None:
        """
        Get cache file path for content.

        Args:
            owner: Repository owner
            repo: Repository name
            ref: Branch/tag/commit SHA
            path: File path within repo

        Returns:
            Path to cache file, or None if caching disabled
        """
        if not self.cache_dir:
            return None

        # Create safe filename from path
        safe_path = path.replace("/", "_").replace("\\", "_")
        return self.cache_dir / f"{owner}_{repo}_{safe_path}"

    def _get_metadata_path(self, cache_path: Path) -> Path:
        """Get metadata file path for a cached file."""
        return cache_path.with_suffix(cache_path.suffix + ".meta")

    def _save_cache_metadata(self, metadata_path: Path, sha: str, ref: str) -> None:
        """
        Save metadata about cached file.

        Args:
            metadata_path: Path to metadata file
            sha: Git commit SHA of the cached content
            ref: Branch/tag name used
        """
        metadata = {
            "sha": sha,
            "ref": ref,
        }
        metadata_path.write_text(json.dumps(metadata), encoding="utf-8")

    def _load_cache_metadata(self, metadata_path: Path) -> dict[str, str] | None:
        """
        Load metadata about cached file.

        Args:
            metadata_path: Path to metadata file

        Returns:
            Metadata dict with 'sha' and 'ref', or None if not found
        """
        if not metadata_path.exists():
            return None

        try:
            data = json.loads(metadata_path.read_text(encoding="utf-8"))
            return dict(data) if isinstance(data, dict) else None
        except Exception as e:
            logger.warning(f"Failed to read cache metadata: {e}")
            return None

    async def _get_file_sha(
        self, owner: str, repo: str, ref: str, path: str
    ) -> str | None:
        """
        Get the Git SHA of a file from GitHub API.

        Args:
            owner: Repository owner
            repo: Repository name
            ref: Branch/tag/commit
            path: File path within repo

        Returns:
            Git SHA of the file, or None if not found
        """
        api_url = (
            f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={ref}"
        )

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    api_url,
                    headers={"Accept": "application/vnd.github.v3+json"},
                )
                response.raise_for_status()
                data = response.json()
                sha = data.get("sha")
                return str(sha) if sha is not None else None
        except Exception as e:
            logger.warning(f"Failed to get file SHA: {e}")
            return None

    def _is_cache_valid(
        self, cache_path: Path, metadata_path: Path, current_sha: str
    ) -> bool:
        """
        Check if cached file is up-to-date.

        Args:
            cache_path: Path to cached file
            metadata_path: Path to metadata file
            current_sha: Current Git SHA from GitHub

        Returns:
            True if cache is valid and up-to-date
        """
        if not cache_path.exists():
            return False

        metadata = self._load_cache_metadata(metadata_path)
        if not metadata:
            logger.info(f"No metadata found for cache: {cache_path.name}")
            return False

        cached_sha = metadata.get("sha")
        if cached_sha == current_sha:
            logger.info(
                f"Cache is up-to-date: {cache_path.name} (SHA: {current_sha[:8]})"
            )
            return True

        logger.info(
            f"Cache is outdated: {cache_path.name} "
            f"(cached: {cached_sha[:8] if cached_sha else 'none'}, "
            f"current: {current_sha[:8] if current_sha else 'none'})"
        )
        return False

    async def load_file(self, url: str) -> str:
        """
        Load a single file from GitHub with intelligent caching.

        Checks storage cache first (30-day expiration), then local cache, then downloads.
        Only downloads from GitHub if cache is missing or outdated.

        Args:
            url: GitHub URL to the file

        Returns:
            File content as string

        Raises:
            ValueError: If URL is invalid
            httpx.HTTPError: If download fails
        """
        parsed = self._parse_github_url(url)
        if not parsed:
            raise ValueError(f"Invalid GitHub URL: {url}")

        owner = parsed["owner"]
        repo = parsed["repo"]
        ref = parsed["ref"]
        path = parsed["path"]

        # Step 1: Check storage cache first (persistent across invocations)
        storage_content, storage_metadata = await self._check_storage_cache(
            owner, repo, ref, path
        )
        if storage_content:
            logger.info(f"✓ Using storage cached version: {owner}/{repo}/{path}")
            # Also save to local cache for faster subsequent access in this session
            cache_path = self._get_cache_path(owner, repo, ref, path)
            if cache_path:
                cache_path.write_text(storage_content, encoding="utf-8")
                if storage_metadata and storage_metadata.get("sha"):
                    metadata_path = self._get_metadata_path(cache_path)
                    self._save_cache_metadata(
                        metadata_path, storage_metadata["sha"], ref
                    )
            return storage_content

        # Step 2: Check local cache
        cache_path = self._get_cache_path(owner, repo, ref, path)

        # If caching is disabled, download directly
        if not cache_path:
            raw_url = self._get_raw_url(owner, repo, ref, path)
            logger.info(f"Downloading (no cache): {raw_url}")
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(raw_url)
                response.raise_for_status()
                return str(response.text)

        metadata_path = self._get_metadata_path(cache_path)

        # Get current SHA from GitHub to check if local cache is valid
        # Note: We only check SHA if storage cache missed, to minimize API calls
        current_sha = await self._get_file_sha(owner, repo, ref, path)

        # Check if cache is valid and up-to-date
        if current_sha and self._is_cache_valid(cache_path, metadata_path, current_sha):
            logger.info(f"✓ Using cached version: {cache_path.name}")
            return cache_path.read_text(encoding="utf-8")

        # Download from GitHub
        raw_url = self._get_raw_url(owner, repo, ref, path)
        logger.info(f"⬇ Downloading from GitHub: {raw_url}")

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(raw_url)
            response.raise_for_status()
            content = str(response.text)

        # Save to local cache with metadata
        cache_path.write_text(content, encoding="utf-8")
        if current_sha:
            self._save_cache_metadata(metadata_path, current_sha, ref)
            logger.info(f"✓ Cached locally: {cache_path.name} (SHA: {current_sha[:8]})")
        else:
            logger.info(f"✓ Cached locally: {cache_path.name} (no SHA available)")

        # Also save to storage cache for persistence across invocations
        await self._save_to_storage_cache(owner, repo, ref, path, content, current_sha)

        return content

    async def load_repo_files(
        self,
        repo_url: str,
        pattern: str = r".*\.md$",
        max_files: int = 50,
    ) -> dict[str, str]:
        """
        Load multiple files from a GitHub repository.

        Args:
            repo_url: GitHub repository URL
            pattern: Regex pattern to match files (default: markdown files)
            max_files: Maximum number of files to load

        Returns:
            Dict mapping file paths to content

        Raises:
            ValueError: If URL is invalid
            httpx.HTTPError: If download fails
        """
        parsed = self._parse_github_url(repo_url)
        if not parsed:
            raise ValueError(f"Invalid GitHub URL: {repo_url}")

        owner = parsed["owner"]
        repo = parsed["repo"]
        ref = parsed["ref"]
        base_path = parsed["path"]

        # Check storage cache for tree data first
        tree_cache_key = f"tree_{ref}"
        tree_content, tree_metadata = await self._check_storage_cache(
            owner, repo, ref, tree_cache_key
        )

        if tree_content:
            logger.info(f"✓ Using cached repository tree: {owner}/{repo}@{ref}")
            tree_data = json.loads(tree_content)
        else:
            # Get repository tree using GitHub API
            api_url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{ref}?recursive=1"
            logger.info(f"⬇ Fetching repository tree from GitHub: {api_url}")

            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    api_url,
                    headers={"Accept": "application/vnd.github.v3+json"},
                )
                response.raise_for_status()
                tree_data = response.json()

            # Cache the tree data
            tree_json = json.dumps(tree_data)
            await self._save_to_storage_cache(
                owner, repo, ref, tree_cache_key, tree_json, tree_data.get("sha")
            )
            logger.info(f"✓ Cached repository tree: {owner}/{repo}@{ref}")

        # Filter files matching pattern and base path
        pattern_re = re.compile(pattern)
        matching_files = []

        for item in tree_data.get("tree", []):
            if item["type"] != "blob":  # Skip directories
                continue

            path = item["path"]

            # Check if path starts with base_path (if specified)
            if base_path and not path.startswith(base_path):
                continue

            # Check if path matches pattern
            if pattern_re.match(path):
                matching_files.append(path)

        logger.info(
            f"Found {len(matching_files)} files matching pattern in {owner}/{repo}"
        )

        # Limit number of files
        if len(matching_files) > max_files:
            logger.warning(
                f"Too many files ({len(matching_files)}), limiting to {max_files}"
            )
            matching_files = matching_files[:max_files]

        # Load each file
        results: dict[str, str] = {}
        for file_path in matching_files:
            try:
                file_url = f"https://github.com/{owner}/{repo}/blob/{ref}/{file_path}"
                content = await self.load_file(file_url)
                results[file_path] = content
                logger.info(f"✓ Loaded: {file_path} ({len(content)} chars)")
            except Exception as e:
                logger.warning(f"Failed to load {file_path}: {e}")
                continue

        return results


async def load_github_content_tool(
    url: str, pattern: str = r".*\.md$", max_files: int = 50
) -> str:
    """
    Tool for loading content from GitHub repositories.

    Uses storage caching with 30-day expiration to minimize GitHub API calls.
    Downloads from GitHub only if storage cache is missing or expired.
    Also maintains local .cache for faster access within the same session.

    Args:
        url: GitHub URL (repo or specific file)
        pattern: Regex pattern for files to load (default: markdown files)
        max_files: Maximum number of files to load

    Returns:
        Formatted string with loaded content
    """
    loader = GitHubContentLoader(cache_dir=".cache/github", use_storage=True)

    try:
        # Check if URL points to a specific file
        parsed = loader._parse_github_url(url)
        if parsed and parsed["path"] and "." in parsed["path"].split("/")[-1]:
            # Looks like a specific file
            content = await loader.load_file(url)
            return f"# Content from {url}\n\n{content}"
        else:
            # Load multiple files from repo
            files = await loader.load_repo_files(url, pattern, max_files)

            if not files:
                return f"No files found matching pattern '{pattern}' in {url}"

            # Format all files into one string
            result_parts = [f"# Content from GitHub: {url}"]
            result_parts.append(
                f"\n**Loaded {len(files)} files matching pattern: `{pattern}`**\n"
            )

            for file_path, content in files.items():
                result_parts.append(f"\n---\n## File: {file_path}\n\n{content}\n")

            return "\n".join(result_parts)

    except Exception as e:
        logger.error(f"Failed to load GitHub content: {e}")
        return f"Error loading GitHub content: {e}"
