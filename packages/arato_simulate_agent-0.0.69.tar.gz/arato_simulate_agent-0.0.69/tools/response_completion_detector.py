"""
Response Completion Detector - Universal Chatbot Response Detection

This module provides a robust, multi-signal approach to detecting when a chatbot
has finished responding. It uses an escalation strategy from fast/cheap signals
to thorough/expensive analysis.

DETECTION SIGNALS (in order of speed/cost):
1. DOM Stability - Content hash stops changing
2. Streaming Detection - Character count growth rate drops to zero
3. Completion Indicators - Known phrases that signal end of response
4. LLM Vision Analysis - Ask Claude to look at the page and determine state

ESCALATION STRATEGY:
- Level 1 (Fast): DOM stability + completion indicators (~1-3s)
- Level 2 (Medium): Add streaming detection (~5-10s)
- Level 3 (Thorough): LLM vision analysis when DOM is inconclusive (~15-20s)

The detector automatically escalates when uncertain, ensuring reliable detection
across all types of chatbots (fast, slow, streaming, non-streaming).
"""

import asyncio
import base64
import hashlib
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class ChatbotState(Enum):
    """Detected state of the chatbot."""

    IDLE = "idle"  # Not responding, waiting for input
    THINKING = "thinking"  # Processing, showing thinking indicator
    STREAMING = "streaming"  # Actively streaming response
    COMPLETE = "complete"  # Response is complete
    ERROR = "error"  # Error state detected
    UNKNOWN = "unknown"  # Cannot determine state


@dataclass
class DetectionResult:
    """Result from the completion detector."""

    state: ChatbotState
    confidence: float  # 0.0 to 1.0
    content: str | None = None
    signals: dict[str, Any] = field(default_factory=dict)
    detection_time_ms: float = 0.0
    escalation_level: int = 1


@dataclass
class StreamingMetrics:
    """Metrics for detecting streaming responses."""

    content_length: int = 0
    growth_rate: float = 0.0  # chars per second
    last_check_time: float = 0.0
    consecutive_no_growth: int = 0
    growth_history: list[float] = field(default_factory=list)


class ResponseCompletionDetector:
    """
    Universal detector for chatbot response completion.

    Uses multiple signals and an escalation strategy to reliably detect
    when a chatbot has finished responding, regardless of the chatbot's
    behavior (fast, slow, streaming, non-streaming).
    """

    # Configuration constants
    POLL_INTERVAL = 0.3  # Seconds between checks
    STABILITY_CHECKS = 3  # Number of unchanged checks for stability

    # Streaming detection
    MIN_STREAMING_RATE = 5.0  # chars/sec to be considered streaming
    NO_GROWTH_THRESHOLD = 3  # consecutive no-growth checks to consider complete

    # Timeouts per escalation level
    # Note: Wix editor can take 60+ seconds to show chatbot response
    LEVEL_1_TIMEOUT = 30.0  # Fast DOM/network check (increased for slow sites)
    LEVEL_2_TIMEOUT = 45.0  # Add streaming/visual
    LEVEL_3_TIMEOUT = 60.0  # LLM vision analysis

    # Thinking indicators (expanded list)
    THINKING_INDICATORS = [
        # English
        "thinking",
        "typing",
        "processing",
        "loading",
        "generating",
        "please wait",
        "one moment",
        "just a moment",
        "working on it",
        "let me think",
        "analyzing",
        "searching",
        "fetching",
        # UI elements
        "...",
        "…",
        "●●●",
        "○○○",
        "• • •",
        # Site builder specific
        "designing",
        "creating",
        "building",
        "updating",
        "adding",
        "configuring",
        "setting up",
        "preparing",
        "applying",
        # Common UI states
        "connecting",
        "initializing",
        "starting",
    ]

    # Completion indicators
    COMPLETION_INDICATORS = [
        # Note: "?" was removed — it's too broad and matches the user's own
        # questions in the page content, causing false-positive COMPLETE before
        # the chatbot even starts responding.
        # Definitive endings
        "let me know if you",
        "feel free to",
        "hope this helps",
        "is there anything else",
        "can i help you with",
        "what would you like",
        "how can i assist",
        # Action completions
        "done!",
        "complete!",
        "finished!",
        "created!",
        "updated!",
        "successfully",
        "all set",
    ]

    def __init__(
        self,
        browser_session: Any,
        llm: Any | None = None,
    ):
        """
        Initialize the detector.

        Args:
            browser_session: Browser-use BrowserSession instance
            llm: Optional LLM for vision-based detection (Level 3)
        """
        self.browser_session = browser_session
        self.llm = llm
        self._pre_change_fingerprint: str | None = None
        self._streaming_metrics = StreamingMetrics()

    def set_pre_change_fingerprint(self, fingerprint: str) -> None:
        """Set the fingerprint from before the user's message was sent."""
        self._pre_change_fingerprint = fingerprint

    async def wait_for_completion(
        self,
        max_timeout: float = 120.0,
        min_confidence: float = 0.8,
    ) -> DetectionResult:
        """
        Wait for the chatbot to complete its response.

        Uses escalating detection strategies to balance speed and reliability.

        Args:
            max_timeout: Maximum total time to wait
            min_confidence: Minimum confidence level required to return

        Returns:
            DetectionResult with state, confidence, and content
        """
        start_time = time.time()
        current_level = 1
        last_content: str | None = None

        # Reset streaming metrics
        self._streaming_metrics = StreamingMetrics(last_check_time=start_time)

        while time.time() - start_time < max_timeout:
            elapsed = time.time() - start_time

            # Determine current escalation level based on elapsed time
            if elapsed < self.LEVEL_1_TIMEOUT:
                current_level = 1
            elif elapsed < self.LEVEL_2_TIMEOUT:
                current_level = 2
            else:
                current_level = 3

            # Run detection at current level
            result = await self._detect_at_level(current_level, start_time)

            # Track last known content for timeout fallback
            if result.content:
                last_content = result.content

            # Handle ERROR state - retry transient CDP errors, fail on hard errors
            if result.state == ChatbotState.ERROR:
                error_msg = result.signals.get("error", "unknown")
                # CDP ax_tree failures are transient on remote browsers (AgentCore).
                # Retry after a brief delay instead of failing immediately.
                if "CDP" in str(error_msg) or "ax_tree" in str(error_msg):
                    logger.warning(
                        f"⚠️ Transient CDP error, retrying in 3s: {error_msg}"
                    )
                    await asyncio.sleep(3)
                    continue
                logger.error(f"❌ Detection error: {error_msg}")
                return result

            # Check if we have high enough confidence
            if result.confidence >= min_confidence:
                if result.state == ChatbotState.COMPLETE:
                    logger.info(
                        f"✅ Response complete (L{current_level}, "
                        f"{result.confidence:.0%} confidence, {elapsed:.1f}s)"
                    )
                    return result
                elif result.state == ChatbotState.IDLE:
                    # Chatbot never responded - but be patient for slow sites
                    # Only give up after LEVEL_2_TIMEOUT (45s) to handle slow editors
                    if elapsed > self.LEVEL_2_TIMEOUT:
                        logger.warning(f"⚠️ Chatbot appears idle after {elapsed:.1f}s")
                        return result
                    else:
                        logger.debug(
                            f"⏳ Content unchanged, waiting longer ({elapsed:.1f}s < {self.LEVEL_2_TIMEOUT}s)"
                        )

            # Log current state for debugging
            if result.state in (ChatbotState.STREAMING, ChatbotState.THINKING):
                logger.debug(
                    f"⏳ {result.state.value} (L{current_level}, "
                    f"{result.confidence:.0%}, {elapsed:.1f}s)"
                )

            await asyncio.sleep(self.POLL_INTERVAL)

        # Timeout - return best effort result with last known content
        # so the caller can still attempt LLM extraction
        logger.warning(f"⏱️ Detection timeout after {max_timeout}s")
        return DetectionResult(
            state=ChatbotState.UNKNOWN,
            confidence=0.5,
            content=last_content,
            detection_time_ms=(time.time() - start_time) * 1000,
            escalation_level=current_level,
        )

    async def _detect_at_level(
        self,
        level: int,
        start_time: float,
    ) -> DetectionResult:
        """Run detection at the specified escalation level."""
        signals: dict[str, Any] = {}

        try:
            page = await self.browser_session.get_current_page()
            if not page:
                return DetectionResult(
                    state=ChatbotState.ERROR,
                    confidence=1.0,
                    signals={"error": "No active page"},
                )

            # Get current content
            content, _ = await page._extract_clean_markdown()
            current_fingerprint = self._make_fingerprint(content)

            # Level 1: DOM stability + basic checks
            dom_stable, dom_signals = await self._check_dom_stability(
                content, current_fingerprint
            )
            signals.update(dom_signals)

            # Check for thinking indicators
            is_thinking = self._check_thinking_indicators(content)
            signals["is_thinking"] = is_thinking

            if is_thinking:
                return DetectionResult(
                    state=ChatbotState.THINKING,
                    confidence=0.9,
                    content=content,
                    signals=signals,
                    detection_time_ms=(time.time() - start_time) * 1000,
                    escalation_level=level,
                )

            # Always update streaming metrics so they stay current across
            # level transitions (prevents false "growth spurt" when Level 2 starts)
            is_streaming, streaming_signals = self._check_streaming(content)
            signals.update(streaming_signals)

            # Only act on streaming detection at Level 2+
            if level >= 2 and is_streaming:
                return DetectionResult(
                    state=ChatbotState.STREAMING,
                    confidence=0.85,
                    content=content,
                    signals=signals,
                    detection_time_ms=(time.time() - start_time) * 1000,
                    escalation_level=level,
                )

            # Check for completion indicators
            has_completion_indicator = self._check_completion_indicators(content)
            signals["has_completion_indicator"] = has_completion_indicator

            # Determine state based on DOM signals (fast, no LLM needed)
            if dom_stable and not is_thinking:
                # Check if content actually changed from pre-send state
                if (
                    self._pre_change_fingerprint
                    and current_fingerprint == self._pre_change_fingerprint
                ):
                    # Content hasn't changed - still waiting
                    return DetectionResult(
                        state=ChatbotState.IDLE,
                        confidence=0.9,
                        content=content,
                        signals=signals,
                        detection_time_ms=(time.time() - start_time) * 1000,
                        escalation_level=level,
                    )

                # DOM is stable and content changed - likely complete
                confidence = 0.7 if level == 1 else 0.85 if level == 2 else 0.9
                if has_completion_indicator:
                    confidence += 0.1

                return DetectionResult(
                    state=ChatbotState.COMPLETE,
                    confidence=min(confidence, 1.0),
                    content=content,
                    signals=signals,
                    detection_time_ms=(time.time() - start_time) * 1000,
                    escalation_level=level,
                )

            # Level 3: LLM Vision analysis (only when DOM is inconclusive)
            # This is expensive (3-5s per call) so only use as last resort
            if level >= 3 and self.llm:
                llm_result, llm_signals = await self._llm_vision_check(page, content)
                signals.update(llm_signals)

                if llm_result is not None:
                    return DetectionResult(
                        state=llm_result,
                        confidence=0.95,
                        content=content,
                        signals=signals,
                        detection_time_ms=(time.time() - start_time) * 1000,
                        escalation_level=level,
                    )

            # Still changing
            return DetectionResult(
                state=ChatbotState.STREAMING,
                confidence=0.6,
                content=content,
                signals=signals,
                detection_time_ms=(time.time() - start_time) * 1000,
                escalation_level=level,
            )

        except Exception as e:
            logger.error(f"Detection error at level {level}: {e}")
            return DetectionResult(
                state=ChatbotState.ERROR,
                confidence=0.5,
                signals={"error": str(e)},
                detection_time_ms=(time.time() - start_time) * 1000,
                escalation_level=level,
            )

    def _make_fingerprint(self, content: str) -> str:
        """Create a fingerprint from content."""
        content_hash = hashlib.md5(content.encode()).hexdigest()[:16]
        return f"{len(content)}:{content_hash}"

    _last_fingerprint: str | None = None
    _stability_count: int = 0

    async def _check_dom_stability(
        self,
        content: str,
        fingerprint: str,
    ) -> tuple[bool, dict[str, Any]]:
        """Check if DOM content has stabilized."""
        signals: dict[str, Any] = {
            "content_length": len(content),
            "fingerprint": fingerprint,
        }

        if fingerprint == self._last_fingerprint:
            self._stability_count += 1
        else:
            self._stability_count = 0
            self._last_fingerprint = fingerprint

        signals["stability_count"] = self._stability_count
        is_stable = self._stability_count >= self.STABILITY_CHECKS

        return is_stable, signals

    def _check_thinking_indicators(self, content: str) -> bool:
        """Check if content shows thinking/processing indicators."""
        # Check last 300 chars (where indicators typically appear)
        tail = content[-300:].lower() if content else ""

        for indicator in self.THINKING_INDICATORS:
            if indicator in tail:
                # Make sure it's not just part of a longer word
                # and appears near the end
                idx = tail.rfind(indicator)
                if idx >= len(tail) - 100:  # Within last 100 chars
                    return True

        return False

    def _check_completion_indicators(self, content: str) -> bool:
        """Check if content shows completion indicators."""
        tail = content[-500:].lower() if content else ""

        for indicator in self.COMPLETION_INDICATORS:
            if indicator in tail:
                return True

        return False

    def _check_streaming(self, content: str) -> tuple[bool, dict[str, Any]]:
        """Detect if content is actively streaming."""
        current_time = time.time()
        current_length = len(content)

        metrics = self._streaming_metrics
        time_delta = current_time - metrics.last_check_time

        signals: dict[str, Any] = {
            "content_length": current_length,
            "prev_length": metrics.content_length,
        }

        if time_delta > 0 and metrics.content_length > 0:
            growth = current_length - metrics.content_length
            growth_rate = growth / time_delta

            signals["growth_chars"] = growth
            signals["growth_rate"] = growth_rate

            # Track growth history
            metrics.growth_history.append(growth_rate)
            if len(metrics.growth_history) > 10:
                metrics.growth_history.pop(0)

            # Update metrics
            metrics.growth_rate = growth_rate

            if growth <= 0:
                metrics.consecutive_no_growth += 1
            else:
                metrics.consecutive_no_growth = 0

            signals["consecutive_no_growth"] = metrics.consecutive_no_growth

            # Determine if streaming
            is_streaming = (
                growth_rate > self.MIN_STREAMING_RATE
                or metrics.consecutive_no_growth < self.NO_GROWTH_THRESHOLD
            )
        else:
            is_streaming = True  # Assume streaming on first check

        # Update metrics for next check
        metrics.content_length = current_length
        metrics.last_check_time = current_time

        return is_streaming, signals

    async def _llm_vision_check(
        self,
        page: Any,
        content: str,
    ) -> tuple[ChatbotState | None, dict[str, Any]]:
        """Use LLM vision to determine chatbot state."""
        signals: dict[str, Any] = {}

        if not self.llm:
            return None, {"llm_vision": "no_llm_configured"}

        try:
            # Take screenshot for vision
            screenshot = await page.screenshot()
            screenshot_b64 = base64.b64encode(screenshot).decode("utf-8")

            # Prepare vision prompt
            from browser_use.llm.messages import (
                ContentPartImageParam,
                ContentPartTextParam,
                ImageURL,
                SystemMessage,
                UserMessage,
            )

            image_url = ImageURL(url=f"data:image/png;base64,{screenshot_b64}")
            image_part = ContentPartImageParam(type="image_url", image_url=image_url)
            text_part = ContentPartTextParam(
                type="text",
                text="What is the current state of the chatbot? Respond with only: THINKING, STREAMING, COMPLETE, or IDLE",
            )

            messages = [
                SystemMessage(
                    content="""You are analyzing a web page screenshot to determine if a chatbot has finished responding.

Look at the chat interface and determine the chatbot's current state:
- THINKING: The chatbot is showing a loading/thinking indicator (spinning dots, "typing...", progress bar, etc.)
- STREAMING: The chatbot's response is actively being typed/streamed (text appearing character by character)
- COMPLETE: The chatbot's response appears to be finished (full message visible, no loading indicators)
- IDLE: No chatbot response visible, waiting for user input

Respond with ONLY one of: THINKING, STREAMING, COMPLETE, IDLE"""
                ),
                UserMessage(content=[image_part, text_part]),
            ]

            # Call LLM
            response = await self.llm.ainvoke(messages)
            result_text = response.content.strip().upper()

            signals["llm_vision_response"] = result_text

            # Parse response
            state_map = {
                "THINKING": ChatbotState.THINKING,
                "STREAMING": ChatbotState.STREAMING,
                "COMPLETE": ChatbotState.COMPLETE,
                "IDLE": ChatbotState.IDLE,
            }

            for key, state in state_map.items():
                if key in result_text:
                    return state, signals

            return None, signals

        except Exception as e:
            logger.warning(f"LLM vision check failed: {e}")
            signals["llm_vision_error"] = str(e)
            return None, signals


async def wait_for_chatbot_response(
    browser_session: Any,
    llm: Any | None = None,
    pre_change_fingerprint: str | None = None,
    max_timeout: float = 120.0,
    min_confidence: float = 0.8,
) -> DetectionResult:
    """
    Convenience function to wait for a chatbot response to complete.

    Args:
        browser_session: Browser-use BrowserSession instance
        llm: Optional LLM for vision-based detection
        pre_change_fingerprint: Fingerprint from before user's message was sent
        max_timeout: Maximum time to wait
        min_confidence: Minimum confidence required

    Returns:
        DetectionResult with state and content
    """
    detector = ResponseCompletionDetector(browser_session, llm)

    if pre_change_fingerprint:
        detector.set_pre_change_fingerprint(pre_change_fingerprint)

    return await detector.wait_for_completion(max_timeout, min_confidence)
