"""
Response Extraction Module - CRITICAL COMPONENT

This module contains the 4-phase response extraction pipeline extracted from chat_runner.py.
It handles the delicate process of detecting when a chatbot has responded and extracting
the response text from the page.

4-PHASE PIPELINE:
1. Phase 0: Change Detection - Wait for page content to change from pre-send fingerprint
2. Phase 1: Stability Detection - Wait for content to stabilize (3 unchanged checks)
3. Phase 1.5: Waiting Indicator Check - Fast heuristic check for "thinking..." states
4. Phase 2: LLM Extraction - Use LLM to extract the actual response text

DO NOT MODIFY THIS LOGIC WITHOUT EXTENSIVE TESTING!
"""

import asyncio
import hashlib
import logging
import traceback
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from browser_use.llm.messages import SystemMessage, UserMessage

from constants import RESPONSE_EXTRACTION_TIMEOUT

logger = logging.getLogger(__name__)

# Extraction constants - Tiered change detection
CHANGE_TIMEOUT_TIER1 = 10.0  # First tier: fast chatbots should respond by now
CHANGE_TIMEOUT_TIER2 = 20.0  # Second tier: medium-speed chatbots
CHANGE_TIMEOUT_TIER3 = 30.0  # Third tier: slow chatbots, final attempt
STABILITY_THRESHOLD = 3  # Number of unchanged checks required for stability
POLL_INTERVAL = 0.3  # Seconds between stability checks
MAX_EXTRACTION_RETRIES = (
    8  # Number of LLM extraction retries (increased for slow chatbots)
)
RETRY_DELAY = 3.0  # Seconds between retries

# Common waiting indicators
WAITING_INDICATORS = [
    "thinking...",
    "typing...",
    "processing...",
    "loading...",
    "generating...",
    "please wait",
    "one moment",
    "just a moment",
    "working on it",
    "let me think",
    "...",  # Common typing indicator
    # Site builder/editor progress indicators
    "designing",
    "creating",
    "building",
    "updating",
    "adding",
    "configuring",
    "setting up",
    "preparing",
]


@dataclass
class ExtractionResult:
    """Result of response extraction."""

    success: bool
    response_text: str | None = None
    error: str | None = None
    extraction_metadata: dict[str, Any] = field(default_factory=dict)


class ResponseExtractor:
    """
    Handles the extraction of chatbot responses from web pages.

    The extraction process uses a 4-phase pipeline to handle various
    chatbot response patterns including streaming, thinking indicators,
    fast and slow responses.
    """

    def __init__(
        self,
        browser_session: Any,
        llm: Any,
        on_first_token_callback: Callable[[], None] | None = None,
    ):
        """
        Initialize the response extractor.

        Args:
            browser_session: The browser-use BrowserSession instance
            llm: The LLM model for response extraction (Phase 2)
            on_first_token_callback: Optional callback invoked when content first changes
                (i.e., when the chatbot starts responding). Used for TTFT tracking.
        """
        self.browser_session = browser_session
        self.llm = llm
        self._pre_send_fingerprint: str | None = None
        self._on_first_token_callback = on_first_token_callback

    def make_fingerprint(self, content: str) -> str:
        """Create content fingerprint using hash of ENTIRE content.

        Uses MD5 hash + length to detect changes in page content.
        The full content hash is essential because changes may occur
        anywhere in the chat history, not just at the end.

        Args:
            content: Page content (markdown)

        Returns:
            Fingerprint string in format "length:hash"
        """
        content_hash = hashlib.md5(content.encode()).hexdigest()[:16]
        return f"{len(content)}:{content_hash}"

    async def capture_pre_send_fingerprint(self) -> str | None:
        """
        Capture page fingerprint BEFORE typing/sending a message.

        This is CRITICAL because the chatbot may respond before the callback runs.
        The fingerprint must be captured BEFORE the message is sent to ensure
        change detection works correctly.

        Returns:
            The fingerprint string, or None if capture failed
        """
        try:
            page = await self.browser_session.get_current_page()
            if not page:
                logger.warning("No active page for fingerprint capture")
                return None

            content, _ = await page._extract_clean_markdown()
            self._pre_send_fingerprint = self.make_fingerprint(content)
            logger.debug(
                f"📸 Captured pre-send fingerprint: {self._pre_send_fingerprint}"
            )
            return self._pre_send_fingerprint
        except Exception as e:
            logger.warning(f"Failed to capture pre-send fingerprint: {e}")
            self._pre_send_fingerprint = None
            return None

    def set_pre_send_fingerprint(self, fingerprint: str) -> None:
        """Set the pre-send fingerprint (used when captured externally)."""
        self._pre_send_fingerprint = fingerprint

    def clear_pre_send_fingerprint(self) -> None:
        """Clear the pre-send fingerprint after extraction."""
        self._pre_send_fingerprint = None

    async def extract_latest_response(
        self,
        user_message_context: str | None = None,
        last_assistant_text: str | None = None,
        timeout: float = RESPONSE_EXTRACTION_TIMEOUT,
        use_smart_detector: bool = True,
    ) -> ExtractionResult:
        """
        Extract the latest chatbot response from the page.

        Uses the new multi-signal ResponseCompletionDetector for reliable detection
        across all types of chatbots (fast, slow, streaming, non-streaming).

        The detector uses an escalation strategy:
        - Level 1 (Fast): DOM stability + basic network check
        - Level 2 (Medium): Add streaming detection + visual diff
        - Level 3 (Thorough): LLM vision analysis to confirm completion

        Args:
            user_message_context: The user's message that this response is answering.
                Used to help the LLM identify the correct response in chats with history.
            last_assistant_text: Previous assistant response text for deduplication.
            timeout: Maximum time to wait for extraction (default: RESPONSE_EXTRACTION_TIMEOUT)
            use_smart_detector: Use the new multi-signal detector (default: True)

        Returns:
            ExtractionResult with success status and response text
        """
        if use_smart_detector:
            return await self._extract_with_smart_detector(
                user_message_context=user_message_context,
                last_assistant_text=last_assistant_text,
                timeout=timeout,
            )
        else:
            return await self._extract_with_legacy_phases(
                user_message_context=user_message_context,
                last_assistant_text=last_assistant_text,
                timeout=timeout,
            )

    async def _extract_with_smart_detector(
        self,
        user_message_context: str | None = None,
        last_assistant_text: str | None = None,
        timeout: float = RESPONSE_EXTRACTION_TIMEOUT,
    ) -> ExtractionResult:
        """
        Extract response using the new multi-signal completion detector.

        This approach is more reliable than fixed timeouts because it:
        1. Uses multiple signals (DOM, network, visual, streaming rate)
        2. Escalates from fast/cheap to thorough/expensive checks
        3. Uses LLM vision when uncertain
        """
        from tools.response_completion_detector import (
            ChatbotState,
            ResponseCompletionDetector,
            StreamingMetrics,
        )

        extraction_metadata: dict[str, Any] = {}

        # Create detector with LLM for vision-based detection (Level 3)
        detector = ResponseCompletionDetector(
            browser_session=self.browser_session,
            llm=self.llm,
        )

        # Set pre-change fingerprint if available
        if self._pre_send_fingerprint:
            detector.set_pre_change_fingerprint(self._pre_send_fingerprint)
            self._pre_send_fingerprint = None  # Clear for next turn

        # Invoke first token callback on content change detection
        first_token_recorded = False

        def on_content_change() -> None:
            nonlocal first_token_recorded
            if not first_token_recorded and self._on_first_token_callback:
                try:
                    self._on_first_token_callback()
                    first_token_recorded = True
                except Exception as e:
                    logger.debug(f"First token callback failed: {e}")

        # Wait for completion with escalating detection.
        # On Turn 2+, the detector may return COMPLETE prematurely because the
        # user's own typed message changed the page content and the DOM stabilised.
        # If LLM extraction yields a duplicate of the previous response, we update
        # the fingerprint to the current page state and retry detection so the
        # chatbot has time to respond.
        import time as _time

        MAX_DUPLICATE_RETRIES = 2
        remaining_timeout = timeout
        detection_start = _time.time()

        result = None
        for _dup_attempt in range(1 + MAX_DUPLICATE_RETRIES):
            logger.info("🔍 Using smart multi-signal detector...")
            result = await detector.wait_for_completion(
                max_timeout=remaining_timeout,
                min_confidence=0.8,
            )

            extraction_metadata["detector_state"] = result.state.value
            extraction_metadata["detector_confidence"] = result.confidence
            extraction_metadata["detector_level"] = result.escalation_level
            extraction_metadata["detector_signals"] = result.signals

            # Record first token if not already done and content changed
            if not first_token_recorded and result.state != ChatbotState.IDLE:
                on_content_change()

            # Handle terminal states (IDLE, ERROR, THINKING) — no retry
            if result.state == ChatbotState.IDLE:
                logger.warning("⚠️ Chatbot appears idle - may not have responded")
                return ExtractionResult(
                    success=False,
                    error="Chatbot did not respond",
                    extraction_metadata=extraction_metadata,
                )

            if result.state == ChatbotState.ERROR:
                logger.error(
                    f"❌ Detection error: {result.signals.get('error', 'unknown')}"
                )
                return ExtractionResult(
                    success=False,
                    error=f"Detection error: {result.signals.get('error', 'unknown')}",
                    extraction_metadata=extraction_metadata,
                )

            if result.state == ChatbotState.THINKING:
                logger.warning("⚠️ Chatbot still thinking after timeout")
                return ExtractionResult(
                    success=False,
                    error="Chatbot still processing (thinking indicator visible)",
                    extraction_metadata=extraction_metadata,
                )

            if result.state == ChatbotState.STREAMING:
                logger.warning("⚠️ Chatbot still streaming after timeout")
                if result.content:
                    return await self._extract_text_from_content(
                        content=result.content,
                        user_message_context=user_message_context,
                        last_assistant_text=last_assistant_text,
                        extraction_metadata=extraction_metadata,
                    )
                return ExtractionResult(
                    success=False,
                    error="Chatbot still streaming after timeout",
                    extraction_metadata=extraction_metadata,
                )

            if result.state == ChatbotState.COMPLETE:
                if result.content:
                    extraction_result = await self._extract_text_from_content(
                        content=result.content,
                        user_message_context=user_message_context,
                        last_assistant_text=last_assistant_text,
                        extraction_metadata=extraction_metadata,
                    )
                    # If extraction succeeded, return immediately
                    if extraction_result.success:
                        return extraction_result

                    # If the extraction returned a duplicate of the previous response,
                    # the detector likely fired on the user's own message change.
                    # Update the fingerprint to the current page state and retry so
                    # the chatbot has more time to respond.
                    is_duplicate = (
                        extraction_result.error
                        and "matches previous" in extraction_result.error
                    )
                    elapsed = _time.time() - detection_start
                    remaining_timeout = timeout - elapsed

                    if (
                        is_duplicate
                        and _dup_attempt < MAX_DUPLICATE_RETRIES
                        and remaining_timeout > 15
                    ):
                        logger.info(
                            f"🔄 Detector returned COMPLETE but response is a duplicate "
                            f"(attempt {_dup_attempt + 1}/{MAX_DUPLICATE_RETRIES + 1}). "
                            f"Updating fingerprint and retrying detection "
                            f"({remaining_timeout:.0f}s remaining)..."
                        )
                        # Update fingerprint to current page state so the detector
                        # waits for the NEXT content change (the actual chatbot response)
                        if result.content:
                            new_fp = self.make_fingerprint(result.content)
                            detector.set_pre_change_fingerprint(new_fp)
                        # Reset detector streaming metrics for fresh detection
                        detector._streaming_metrics = StreamingMetrics()
                        continue
                    else:
                        return extraction_result
                return ExtractionResult(
                    success=False,
                    error="No content available despite completion state",
                    extraction_metadata=extraction_metadata,
                )

            # Unknown state
            logger.warning(f"⚠️ Unknown detector state: {result.state}")
            if result.content:
                return await self._extract_text_from_content(
                    content=result.content,
                    user_message_context=user_message_context,
                    last_assistant_text=last_assistant_text,
                    extraction_metadata=extraction_metadata,
                )
        return ExtractionResult(
            success=False,
            error=f"Unknown state: {result.state}"
            if result is not None
            else "No detection result",
            extraction_metadata=extraction_metadata,
        )

    async def _extract_text_from_content(
        self,
        content: str,
        user_message_context: str | None,
        last_assistant_text: str | None,
        extraction_metadata: dict[str, Any],
    ) -> ExtractionResult:
        """Extract the response text from page content using LLM."""
        import time

        start_time = time.time()

        prev_context = ""
        if last_assistant_text:
            snippet = last_assistant_text[-200:].replace("\n", " ")
            prev_context = f'\nThe PREVIOUS response (which you should IGNORE) ended with: "{snippet}".'

        user_context = ""
        if user_message_context:
            user_snippet = user_message_context[:200].replace("\n", " ")
            user_context = f'\nThe USER just asked: "{user_snippet}". Find the chatbot response to THIS specific message.'

        system_prompt = f"""You are an expert at extracting information from webpage markdown.
Extract the chatbot/assistant response to the user's most recent message.
Return ONLY the raw text content of the chatbot's response, without any headers, metadata, or explanatory text.
{user_context}{prev_context}

IMPORTANT:
- The chat may have EXISTING HISTORY from previous conversations. Ignore old messages.
- Look for a response that DIRECTLY FOLLOWS and ANSWERS the user's most recent message.
- Look for a response that is DIFFERENT from the previous response.
- "Hmm...", "I thinking...", "I can't..." are VALID responses if they contain content.
- Return the COMPLETE response text, not just a summary."""

        prompt_content = f"<webpage_content>\n{content}\n</webpage_content>"

        extraction_metadata["context_chars"] = len(system_prompt) + len(prompt_content)

        try:
            response = await self.llm.ainvoke(
                [
                    SystemMessage(content=system_prompt),
                    UserMessage(content=prompt_content),
                ]
            )

            extracted_text = response.completion.strip()

            if extracted_text and len(extracted_text) > 10:
                # Check for duplicate
                if (
                    last_assistant_text
                    and extracted_text.strip() == last_assistant_text.strip()
                ):
                    logger.warning("Extracted text matches previous response")
                    return ExtractionResult(
                        success=False,
                        error="Extracted text matches previous response",
                        extraction_metadata=extraction_metadata,
                    )

                logger.info(f"✓ Extracted response: {extracted_text[:100]}...")
                extraction_metadata["extraction_time_ms"] = (
                    time.time() - start_time
                ) * 1000
                return ExtractionResult(
                    success=True,
                    response_text=extracted_text,
                    extraction_metadata=extraction_metadata,
                )
            else:
                logger.warning(
                    f'Extraction returned short/empty text: "{extracted_text}"'
                )
                return ExtractionResult(
                    success=False,
                    error="Extraction returned empty or very short text",
                    extraction_metadata=extraction_metadata,
                )

        except Exception as e:
            logger.error(f"LLM extraction failed: {e}")
            return ExtractionResult(
                success=False,
                error=f"LLM extraction failed: {e}",
                extraction_metadata=extraction_metadata,
            )

    async def _extract_with_legacy_phases(
        self,
        user_message_context: str | None = None,
        last_assistant_text: str | None = None,
        timeout: float = RESPONSE_EXTRACTION_TIMEOUT,
    ) -> ExtractionResult:
        """
        Legacy 4-phase extraction (kept for fallback).

        4-phase strategy:
        Phase 0 (FAST): Wait for content to CHANGE from pre-send fingerprint
        Phase 1 (FAST): Wait for content to STABILIZE (3 unchanged checks)
        Phase 1.5 (FAST): Detect waiting/thinking indicators (NO LLM)
        Phase 2 (ONE-TIME): Call LLM to extract the actual response text

        Args:
            user_message_context: The user's message that this response is answering.
                Used to help the LLM identify the correct response in chats with history.
            last_assistant_text: Previous assistant response text for deduplication.
            timeout: Maximum time to wait for extraction (default: RESPONSE_EXTRACTION_TIMEOUT)

        Returns:
            ExtractionResult with success status and response text
        """
        import time

        start_time = time.time()
        extraction_metadata: dict[str, int] = {}

        # --- PHASE 0: Wait for content to CHANGE ---
        initial_fingerprint = self._pre_send_fingerprint

        if initial_fingerprint:
            logger.debug(f"📸 Using pre-send fingerprint: {initial_fingerprint}")
            # Clear it so it's not reused for the next turn
            self._pre_send_fingerprint = None
        else:
            # Fallback: capture fingerprint now (less reliable but better than nothing)
            logger.debug("⚠️ No pre-send fingerprint available, capturing now")
            try:
                page = await self.browser_session.get_current_page()
                if not page:
                    return ExtractionResult(success=False, error="No active page found")
                initial_content, _ = await page._extract_clean_markdown()
                initial_fingerprint = self.make_fingerprint(initial_content)
            except Exception as e:
                return ExtractionResult(
                    success=False, error=f"Failed to get initial fingerprint: {e}"
                )

        # --- PHASE 0: Tiered change detection (10s x 3 tiers) ---
        # Fast chatbots will break out immediately when content changes.
        # For slow/no-response cases, we escalate through tiers with logging.
        logger.debug("⏳ Phase 0: Waiting for content to change (tiered detection)...")
        change_start = time.time()
        content_changed = False
        current_tier = 1

        while time.time() - change_start < CHANGE_TIMEOUT_TIER3:
            elapsed = time.time() - change_start

            # Check if we've crossed into a new tier (for logging/escalation)
            if current_tier == 1 and elapsed >= CHANGE_TIMEOUT_TIER1:
                current_tier = 2
                logger.debug(
                    f"⏳ Tier 1 ({CHANGE_TIMEOUT_TIER1}s) elapsed with no change, "
                    f"continuing to tier 2..."
                )
            elif current_tier == 2 and elapsed >= CHANGE_TIMEOUT_TIER2:
                current_tier = 3
                logger.warning(
                    f"⏳ Tier 2 ({CHANGE_TIMEOUT_TIER2}s) elapsed with no change, "
                    f"final tier - chatbot may be very slow or unresponsive"
                )

            try:
                page = await self.browser_session.get_current_page()
                if not page:
                    await asyncio.sleep(POLL_INTERVAL)
                    continue

                content, _ = await page._extract_clean_markdown()
                current_fingerprint = self.make_fingerprint(content)

                if current_fingerprint != initial_fingerprint:
                    logger.debug(
                        f"✓ Content changed after {elapsed:.1f}s (tier {current_tier})"
                    )
                    content_changed = True
                    # Invoke first token callback (for TTFT tracking)
                    if self._on_first_token_callback:
                        try:
                            self._on_first_token_callback()
                        except Exception as e:
                            logger.debug(f"First token callback failed: {e}")
                    break

                await asyncio.sleep(POLL_INTERVAL)
            except Exception as e:
                logger.debug(f"Change detection check failed: {e}")
                await asyncio.sleep(POLL_INTERVAL)

        if not content_changed:
            logger.warning(
                f"Content never changed after {CHANGE_TIMEOUT_TIER3}s (all 3 tiers exhausted) "
                f"- chatbot may not have responded"
            )
            return ExtractionResult(
                success=False,
                error="Content never changed - chatbot may not have responded",
            )

        # --- PHASE 1: Wait for content stability (FAST, no LLM) ---
        stable_content, last_content = await self._wait_for_stability(
            start_time, timeout
        )

        # If content didn't stabilize, use last_content for LLM extraction
        # The LLM will return "WAITING" if the response is incomplete
        if not stable_content:
            if last_content:
                stable_content = last_content
            else:
                return ExtractionResult(
                    success=False, error="No content available for extraction"
                )

        # --- PHASE 1.5: Fast "waiting" indicator check (no LLM) ---
        is_waiting, stable_content = await self._check_waiting_indicators(
            stable_content, initial_fingerprint, start_time, timeout
        )

        if is_waiting and not stable_content:
            return ExtractionResult(
                success=False, error="Content never changed from waiting state"
            )

        # At this point, stable_content is guaranteed to be non-None
        if stable_content is None:
            return ExtractionResult(
                success=False, error="No stable content to extract from"
            )

        # --- PHASE 2: Extract response with LLM (with retry logic) ---
        return await self._extract_with_llm(
            stable_content=stable_content,
            user_message_context=user_message_context,
            last_assistant_text=last_assistant_text,
            start_time=start_time,
            timeout=timeout,
            extraction_metadata=extraction_metadata,
        )

    async def _wait_for_stability(
        self,
        start_time: float,
        timeout: float,
        max_stability_wait: float = 15.0,
    ) -> tuple[str | None, str | None]:
        """Wait for page content to stabilize (Phase 1).

        Key insight: For sites like Wix where DOM never fully stabilizes due to
        animations/canvas updates, we should NOT wait forever. Instead:
        1. Try to get stable content within max_stability_wait (default 15s)
        2. If unstable, return the last content anyway - let LLM detect if "WAITING"

        Args:
            start_time: Start time of extraction (for overall timeout)
            timeout: Overall extraction timeout
            max_stability_wait: Max time to wait for stability (default 15s)

        Returns:
            Tuple of (stable_content, last_content_seen).
            stable_content is None if content never stabilized.
            last_content_seen is the most recent content captured (for fallback).
        """
        import time

        last_fingerprint: str | None = None
        stability_count = 0
        stable_content: str | None = None
        last_content: str | None = None  # Track last content for fallback

        logger.debug("⏳ Phase 1: Waiting for content stability...")
        stability_start = time.time()

        # Use the shorter of max_stability_wait or remaining timeout
        effective_timeout = min(
            max_stability_wait, timeout - (time.time() - start_time)
        )

        while time.time() - stability_start < effective_timeout:
            try:
                page = await self.browser_session.get_current_page()
                if not page:
                    logger.warning("No active page found")
                    return None, None

                # Extract markdown content (FAST - no LLM)
                content, _ = await page._extract_clean_markdown()
                last_content = content  # Track for fallback

                # Create fingerprint from content length + hash of entire content
                fingerprint = self.make_fingerprint(content)

                if fingerprint == last_fingerprint:
                    stability_count += 1
                    if stability_count >= STABILITY_THRESHOLD:
                        # Content is stable!
                        stable_content = content
                        logger.info(f"✓ Content stable after {stability_count} checks")
                        break
                else:
                    # Content changed - reset stability counter
                    if last_fingerprint is not None:
                        logger.debug(
                            f"Content changed (len: {len(content)}), resetting stability"
                        )
                    stability_count = 0
                    last_fingerprint = fingerprint

                await asyncio.sleep(POLL_INTERVAL)

            except Exception as e:
                error_str = str(e)
                # Check for fatal CDP session errors - fail fast instead of retrying
                if (
                    "Session with given id not found" in error_str
                    or "-32001" in error_str
                ):
                    logger.error(f"CDP session lost during stability check: {e}")
                    return None, last_content  # Fail fast - session is gone
                logger.error(f"Stability check failed: {e}")
                await asyncio.sleep(POLL_INTERVAL)

        if not stable_content:
            # Content never fully stabilized - but that's OK!
            # For sites like Wix with animations, DOM may NEVER stabilize.
            # Return last_content for caller to try LLM extraction anyway.
            logger.info(
                f"Content never stabilized after {effective_timeout:.0f}s - "
                "will proceed with LLM extraction (chatbot may still be working)"
            )

        return stable_content, last_content

    async def _check_waiting_indicators(
        self,
        stable_content: str,
        initial_fingerprint: str,
        start_time: float,
        timeout: float,
    ) -> tuple[bool, str | None]:
        """Check for waiting/thinking indicators (Phase 1.5).

        Returns (is_waiting, updated_stable_content).
        If is_waiting is True but updated_stable_content is None, extraction should fail.
        """
        import time

        # Check if content ends with a waiting indicator (last 200 chars, lowercased)
        content_tail = stable_content[-200:].lower().strip() if stable_content else ""

        is_waiting_message = False
        for indicator in WAITING_INDICATORS:
            if content_tail.endswith(indicator):
                # Check if this is a short message (just the indicator)
                words_after_indicator = len(content_tail.split())
                if words_after_indicator < 10:  # Very short = likely just waiting
                    is_waiting_message = True
                    logger.debug(
                        f"⏳ Detected waiting indicator '{indicator}' - will re-poll"
                    )
                    break

        if not is_waiting_message:
            return False, stable_content

        # Content is a waiting message - go back to Phase 0 and wait for real change
        logger.info(
            "Detected waiting/thinking message - waiting for actual response..."
        )

        # Update initial fingerprint to current (waiting message) state
        waiting_fingerprint = self.make_fingerprint(stable_content)

        # Reset and wait for ANOTHER change (using tiered approach)
        change_start = time.time()
        current_tier = 1

        while time.time() - change_start < CHANGE_TIMEOUT_TIER3:
            elapsed = time.time() - change_start

            # Log tier transitions
            if current_tier == 1 and elapsed >= CHANGE_TIMEOUT_TIER1:
                current_tier = 2
                logger.debug(
                    f"⏳ Waiting indicator: Tier 1 ({CHANGE_TIMEOUT_TIER1}s) elapsed, "
                    f"continuing to tier 2..."
                )
            elif current_tier == 2 and elapsed >= CHANGE_TIMEOUT_TIER2:
                current_tier = 3
                logger.warning(
                    f"⏳ Waiting indicator: Tier 2 ({CHANGE_TIMEOUT_TIER2}s) elapsed, "
                    f"final tier - response may be very slow"
                )

            try:
                page = await self.browser_session.get_current_page()
                if not page:
                    await asyncio.sleep(POLL_INTERVAL)
                    continue

                content, _ = await page._extract_clean_markdown()
                current_fingerprint = self.make_fingerprint(content)

                if current_fingerprint != waiting_fingerprint:
                    logger.debug(
                        f"✓ Content changed from waiting state after {elapsed:.1f}s (tier {current_tier})"
                    )

                    # Re-run stability check on new content
                    (
                        new_stable_content,
                        new_last_content,
                    ) = await self._wait_for_stability(start_time, timeout)
                    # Use last_content as fallback if not stable
                    return True, new_stable_content or new_last_content

                await asyncio.sleep(POLL_INTERVAL)
            except Exception:
                await asyncio.sleep(POLL_INTERVAL)

        logger.warning(
            f"Content never changed from waiting state after {CHANGE_TIMEOUT_TIER3}s"
        )
        return True, None

    async def _extract_with_llm(
        self,
        stable_content: str,
        user_message_context: str | None,
        last_assistant_text: str | None,
        start_time: float,
        timeout: float,
        extraction_metadata: dict[str, int],
    ) -> ExtractionResult:
        """Extract response using LLM (Phase 2) with retry logic."""
        import time

        for retry_count in range(MAX_EXTRACTION_RETRIES):
            if time.time() - start_time >= timeout:
                logger.warning(f"Timeout reached after {int(timeout)}s")
                return ExtractionResult(
                    success=False, error=f"Timeout after {int(timeout)}s"
                )

            if retry_count > 0:
                logger.info(
                    f"🔄 Retry {retry_count}/{MAX_EXTRACTION_RETRIES}: Waiting {RETRY_DELAY}s for chatbot..."
                )
                await asyncio.sleep(RETRY_DELAY)

                # Re-check for content before retrying extraction
                # Use short stability wait - if content doesn't stabilize, proceed anyway
                logger.debug("Re-checking for content...")
                stable_content_new, last_content_new = await self._wait_for_stability(
                    start_time, timeout, max_stability_wait=5.0
                )  # Quick 5s check
                # Use stable content if available, otherwise use last content
                if stable_content_new:
                    stable_content = stable_content_new
                elif last_content_new:
                    stable_content = last_content_new

            logger.debug(
                f"⏳ Phase 2: Extracting response with LLM (attempt {retry_count + 1})..."
            )

            try:
                prev_context = ""
                if last_assistant_text:
                    # Provide context about previous response to avoid re-extracting it
                    snippet = last_assistant_text[-200:].replace("\n", " ")
                    prev_context = f'\nThe PREVIOUS response (which you should IGNORE) ended with: "{snippet}".'

                # Add user message context to help identify the correct response
                user_context = ""
                if user_message_context:
                    user_snippet = user_message_context[:200].replace("\n", " ")
                    user_context = f'\nThe USER just asked: "{user_snippet}". Find the chatbot response to THIS specific message.'

                system_prompt = f"""You are an expert at extracting information from webpage markdown.
Extract the chatbot/assistant response to the user's most recent message.
Return ONLY the raw text content of the chatbot's response, without any headers, metadata, or explanatory text.
{user_context}{prev_context}

IMPORTANT:
- The chat may have EXISTING HISTORY from previous conversations. Ignore old messages.
- Look for a response that DIRECTLY FOLLOWS and ANSWERS the user's most recent message.
- Look for a response that is DIFFERENT from the previous response.
- "Hmm...", "I thinking...", "I can't..." are VALID responses if they contain content.
- Ignore ONLY pure status messages like "Thinking...", "Processing request...", "Typing...".
- If the response contains both a status message and the final answer, return ONLY the final answer.
- If the response is ONLY a status message, return the string "WAITING".
- If you only find the previous response text, return "WAITING".

IN-PROGRESS RESPONSES (return "WAITING" for these):
- Short responses (under 150 chars) that indicate work is still being done, like:
  "Designing a vibrant layout...", "Creating the header...", "Checking what's installed...",
  "Building your site...", "Updating the page...", "Adding the section...", "Configuring..."
- These are progress updates, NOT final responses. Wait for the actual completed response.
- A COMPLETE response will typically describe what WAS done (past tense) or show the final result."""

                prompt_content = (
                    f"<webpage_content>\n{stable_content}\n</webpage_content>"
                )

                # Calculate total context size for performance analysis
                total_context_chars = len(system_prompt) + len(prompt_content)
                extraction_metadata["context_chars"] = total_context_chars

                logger.debug(
                    f"📏 LLM context size: {total_context_chars:,} chars (system: {len(system_prompt):,}, content: {len(prompt_content):,})"
                )

                response = await self.llm.ainvoke(
                    [
                        SystemMessage(content=system_prompt),
                        UserMessage(content=prompt_content),
                    ]
                )

                extracted_text = response.completion.strip()

                if extracted_text == "WAITING":
                    # Content was stable but chatbot is still "thinking"
                    logger.info(
                        f"LLM returned WAITING - chatbot still processing (attempt {retry_count + 1}/{MAX_EXTRACTION_RETRIES})"
                    )
                    continue  # Retry

                if extracted_text and len(extracted_text) > 20:
                    # Check if extracted text matches previous response
                    if (
                        last_assistant_text
                        and extracted_text.strip() == last_assistant_text.strip()
                    ):
                        logger.info(
                            f"Extracted text matches previous response - retrying (attempt {retry_count + 1}/{MAX_EXTRACTION_RETRIES})"
                        )
                        continue  # Retry

                    logger.info(f"✓ Extracted response: {extracted_text[:100]}...")
                    return ExtractionResult(
                        success=True,
                        response_text=extracted_text,
                        extraction_metadata=extraction_metadata,
                    )
                else:
                    logger.info(
                        f"Extraction returned short/empty text: '{extracted_text}' - retrying (attempt {retry_count + 1}/{MAX_EXTRACTION_RETRIES})"
                    )
                    continue  # Retry

            except Exception as e:
                logger.error(f"LLM extraction failed: {e}")
                logger.debug(traceback.format_exc())
                continue  # Retry on error

        # All retries exhausted
        logger.warning(
            f"Response extraction failed after {MAX_EXTRACTION_RETRIES} attempts over {int(time.time() - start_time)}s"
        )
        return ExtractionResult(
            success=False,
            error=f"Extraction failed after {MAX_EXTRACTION_RETRIES} attempts",
            extraction_metadata=extraction_metadata,
        )
