import logging
from typing import Any

from utils.stats import calculate_dynamic_distribution

logger = logging.getLogger(__name__)


class ResponseLengthTracker:
    """Tracks chatbot response lengths and calculates statistics."""

    def __init__(self) -> None:
        """Initialize the response length tracker."""
        self._measurements: list[dict[str, Any]] = []

    def record_length(self, turn_number: int, response_text: str) -> None:
        """
        Record the length of a chatbot response.

        Args:
            turn_number: The conversation turn number
            response_text: The text of the response
        """
        length = len(response_text)
        measurement = {
            "turn_number": turn_number,
            "length_chars": length,
        }
        self._measurements.append(measurement)
        logger.info(f"📏 Turn {turn_number} response length: {length} chars")

    def get_measurements(self) -> list[dict[str, Any]]:
        """
        Get all recorded length measurements.

        Returns:
            List of measurement dictionaries
        """
        return self._measurements.copy()

    def get_statistics(self) -> dict[str, Any]:
        """
        Calculate statistics from all measurements.

        Returns:
            Dictionary with distribution buckets
        """
        if not self._measurements:
            return {}

        lengths = [m["length_chars"] for m in self._measurements]

        return {
            "count": len(lengths),
            "min_length": min(lengths),
            "max_length": max(lengths),
            "avg_length": sum(lengths) / len(lengths),
            "distribution": calculate_dynamic_distribution(lengths),
        }
