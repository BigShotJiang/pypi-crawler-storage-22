#!/usr/bin/env python3
"""
Response Timer Tool: Measures chatbot response latency.

This tool measures the time between when a message is submitted to a chatbot
(clicking send button or pressing enter) and when the response is extracted
from the UI.
"""

import logging
import time
from typing import Any

from utils.stats import calculate_statistics

logger = logging.getLogger(__name__)


class ResponseTimer:
    """Measures chatbot response latency with start/stop timer functionality."""

    def __init__(self) -> None:
        """Initialize the response timer."""
        self._start_time: float | None = None
        self._first_token_time: float | None = None
        self._measurements: list[dict[str, Any]] = []

    def start_timer(self, turn_number: int) -> str:
        """
        Start timing a chatbot response.

        This should be called IMMEDIATELY AFTER clicking the send button or pressing
        enter to submit a message to the chatbot.

        Args:
            turn_number: The conversation turn number being measured

        Returns:
            Confirmation message
        """
        self._start_time = time.time()
        self._first_token_time = None
        logger.info(f"⏱️  Started timer for turn {turn_number}")
        return f"✓ Timer started for turn {turn_number}"

    def record_first_token(self) -> None:
        """
        Record the timestamp of the first token received.
        Should be called when the first non-waiting content appears.
        """
        if self._start_time is not None and self._first_token_time is None:
            self._first_token_time = time.time()
            logger.info("⏱️  First token recorded")

    def stop_timer(self, turn_number: int, adjustment_seconds: float = 0.0) -> str:
        """
        Stop timing and record the chatbot response latency.

        This should be called IMMEDIATELY AFTER extracting the chatbot's response
        from the UI (after the response is fully visible and captured).

        Args:
            turn_number: The conversation turn number being measured
            adjustment_seconds: Time to subtract from the duration (e.g. stability wait time)

        Returns:
            Measurement result with latency in seconds
        """
        if self._start_time is None:
            error_msg = f"❌ ERROR: Timer was not started for turn {turn_number}"
            logger.error(error_msg)
            return error_msg

        end_time = time.time()
        # Adjust end time if needed (e.g., remove stability wait time)
        actual_end_time = end_time - adjustment_seconds

        ttlt = actual_end_time - self._start_time

        # If first token wasn't recorded, assume it came same time as last (instant)
        # or we missed it. Use ttlt as fallback.
        if self._first_token_time:
            ttft = self._first_token_time - self._start_time
        else:
            ttft = ttlt

        # Record measurement
        measurement = {
            "turn_number": turn_number,
            "ttft_seconds": round(ttft, 3),
            "ttlt_seconds": round(ttlt, 3),
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(end_time)),
        }
        self._measurements.append(measurement)

        logger.info(
            f"⏱️  Turn {turn_number} latency - TTFT: {ttft:.3f}s, TTLT: {ttlt:.3f}s"
        )

        # Reset timer for next measurement
        self._start_time = None
        self._first_token_time = None

        return (
            f"✓ Turn {turn_number} latency measured: TTFT {ttft:.3f}s, TTLT {ttlt:.3f}s\n"
            f"Total measurements: {len(self._measurements)}"
        )

    def get_measurements(self) -> list[dict[str, Any]]:
        """
        Get all recorded latency measurements.

        Returns:
            List of measurement dictionaries with turn_number, latency_seconds, and timestamp
        """
        return self._measurements.copy()

    def get_statistics(self) -> dict[str, Any]:
        """
        Calculate statistics from all measurements.

        Returns:
            Dictionary with min, max, average, median latencies and count for both TTFT and TTLT.
        """
        if not self._measurements:
            return {
                "count": 0,
                "min_latency": None,
                "max_latency": None,
                "avg_latency": None,
                "median_latency": None,
                "min_ttft": None,
                "max_ttft": None,
                "avg_ttft": None,
                "median_ttft": None,
                "min_ttlt": None,
                "max_ttlt": None,
                "avg_ttlt": None,
                "median_ttlt": None,
            }

        # Calculate TTFT stats
        ttft_stats = calculate_statistics(self._measurements, value_key="ttft_seconds")

        # Calculate TTLT stats
        ttlt_stats = calculate_statistics(self._measurements, value_key="ttlt_seconds")

        # Map to stats
        stats = {
            # Legacy keys (mapped to TTLT)
            "count": ttlt_stats["count"],
            "min_latency": ttlt_stats["min"],
            "max_latency": ttlt_stats["max"],
            "avg_latency": ttlt_stats["avg"],
            "median_latency": ttlt_stats["median"],
            # TTFT stats
            "min_ttft": ttft_stats["min"],
            "max_ttft": ttft_stats["max"],
            "avg_ttft": ttft_stats["avg"],
            "median_ttft": ttft_stats["median"],
            # TTLT stats
            "min_ttlt": ttlt_stats["min"],
            "max_ttlt": ttlt_stats["max"],
            "avg_ttlt": ttlt_stats["avg"],
            "median_ttlt": ttlt_stats["median"],
        }

        return stats

    def reset(self) -> None:
        """Reset all measurements and timer state."""
        self._start_time = None
        self._measurements = []
        logger.info("⏱️  Timer reset - all measurements cleared")
