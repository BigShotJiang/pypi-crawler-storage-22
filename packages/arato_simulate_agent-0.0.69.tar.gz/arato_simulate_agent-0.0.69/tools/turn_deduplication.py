"""
Turn Deduplication Module.

Prevents duplicate transcript entries by tracking processed actions
using MD5 hash of message content.

Extracted from chat_runner.py for reuse in subagents.
"""

import hashlib
import logging

logger = logging.getLogger(__name__)


class TurnDeduplicator:
    """
    Prevents duplicate transcript entries.

    Uses MD5 hash of message content to detect duplicates.
    This is important because the agent may retry with the same message,
    and we don't want to record the same turn multiple times.
    """

    def __init__(self):
        """Initialize the deduplicator."""
        # Key: (action_name, message_hash) - message hash ensures uniqueness
        self._processed_actions: set[tuple[str, str]] = set()

    def is_duplicate(self, action_name: str, message: str) -> bool:
        """
        Check if this action/message combination has already been processed.

        Args:
            action_name: Name of the action (e.g., 'fast_type_and_submit')
            message: The message text

        Returns:
            True if this is a duplicate, False otherwise
        """
        message_hash = hashlib.md5(message.encode()).hexdigest()
        dedup_key = (action_name, message_hash)

        if dedup_key in self._processed_actions:
            logger.debug(
                f"⏭️  Skipping duplicate action (message already sent): {message[:50]}..."
            )
            return True

        return False

    def mark_processed(self, action_name: str, message: str) -> None:
        """
        Mark an action/message combination as processed.

        Args:
            action_name: Name of the action (e.g., 'fast_type_and_submit')
            message: The message text
        """
        message_hash = hashlib.md5(message.encode()).hexdigest()
        dedup_key = (action_name, message_hash)
        self._processed_actions.add(dedup_key)
        logger.debug(
            f"✓ Marked as processed: {action_name} with message hash {message_hash[:8]}..."
        )

    def clear(self) -> None:
        """Clear all processed actions."""
        self._processed_actions.clear()
        logger.debug("✓ Cleared all processed actions")

    @property
    def processed_count(self) -> int:
        """Return the number of processed actions."""
        return len(self._processed_actions)
