"""
Aggregated Finding Utility Functions.

Helper functions for creating and manipulating AggregatedFinding instances.
Follows the project pattern of separating data models (core/schemas.py)
from utility functions (utils/).

"""

import re
import uuid
from typing import Any

from core.schemas import AggregatedFinding
from utils.scoring import calculate_label


def create_aggregated_finding(base_finding: dict[str, Any]) -> AggregatedFinding:
    """Create an AggregatedFinding from a base finding dict.

    Args:
        base_finding: The first finding to use as a template

    Returns:
        New AggregatedFinding instance with kf- ID and pattern fields initialized
    """
    return AggregatedFinding(
        category=base_finding.get("category", "Unknown"),
        agent_id=base_finding.get("agent_id", "unknown"),
        title=base_finding.get("title", ""),
        description=base_finding.get("description", ""),
        label=base_finding.get("label", "Warning"),
        score=base_finding.get("score"),
        confidence=base_finding.get("confidence"),
        source="consolidated",
        # Pattern-specific fields are initialized to defaults by Pydantic
    )


def update_from_llm(aggregated: AggregatedFinding, llm_group: dict[str, Any]) -> None:
    """Update AggregatedFinding fields from LLM consolidation response.

    Args:
        aggregated: AggregatedFinding instance to update
        llm_group: LLM response group with consolidated fields
    """
    if "consolidated_title" in llm_group:
        aggregated.title = llm_group["consolidated_title"]
    if "consolidated_category" in llm_group:
        aggregated.category = llm_group["consolidated_category"]
    if "consolidated_description" in llm_group:
        aggregated.description = llm_group["consolidated_description"]
    if "agent_id" in llm_group:
        aggregated.agent_id = llm_group["agent_id"]
    if "consolidated_what_was_tested" in llm_group:
        aggregated.what_was_tested = llm_group["consolidated_what_was_tested"]
    if "consolidated_impact" in llm_group:
        aggregated.impact = llm_group["consolidated_impact"]
    if "consolidated_pattern_explanation" in llm_group:
        aggregated.pattern_explanation = llm_group["consolidated_pattern_explanation"]
    aggregated.assessment = ""


def add_instances(
    aggregated: AggregatedFinding, findings: list[dict[str, Any]]
) -> None:
    """Add multiple instance findings to a consolidated finding.

    Args:
        aggregated: AggregatedFinding instance to update
        findings: List of finding dictionaries to add as instances
    """
    sources = []
    finding_ids = []
    instances = []

    for f in findings:
        if "id" not in f:
            f["id"] = str(uuid.uuid4())

        sources.append(f["source"])
        finding_ids.append(f["id"])

        evidence = f.get("evidence") or {}
        turn_number = (
            evidence.get("turn_number")
            if isinstance(evidence, dict)
            else f.get("turn_number")
        ) or f.get("turn_number")

        level = "turn" if turn_number is not None else "conversation"

        instances.append(
            {
                "source": f["source"],
                "turn": turn_number,
                "level": level,
                "evidence": evidence if isinstance(evidence, dict) else {},
            }
        )

    aggregated.count = len(findings)
    aggregated.finding_ids = finding_ids
    aggregated.instances = instances

    unique_sources = sorted(set(sources))
    aggregated.unique_sources = len(unique_sources)
    aggregated.affected_conversations = len(unique_sources)

    if len(unique_sources) > 1:
        if len(unique_sources) <= 3:
            aggregated.source = ", ".join(unique_sources)
        else:
            aggregated.source = (
                f"{len(unique_sources)} personas ({', '.join(unique_sources[:3])}...)"
            )
    else:
        aggregated.source = unique_sources[0]


def calculate_average_scores(
    aggregated: AggregatedFinding, findings: list[dict[str, Any]]
) -> None:
    """Calculate average score and confidence from instance findings.

    Args:
        aggregated: AggregatedFinding instance to update
        findings: List of finding dictionaries to average
    """
    scores = [f["score"] for f in findings if f.get("score") is not None]
    if scores:
        aggregated.score = int(sum(scores) / len(scores))
        aggregated.label = calculate_label(aggregated.score)

    confidences = [f["confidence"] for f in findings if f.get("confidence") is not None]
    if confidences:
        aggregated.confidence = round(sum(confidences) / len(confidences), 1)


def add_occurrence_stats(
    aggregated: AggregatedFinding, total_conversations: int
) -> None:
    """Add occurrence statistics if pattern is significant.

    Args:
        aggregated: AggregatedFinding instance to update
        total_conversations: Total number of conversations in session
    """
    if total_conversations > 0 and aggregated.unique_sources > 1:
        percentage = round((aggregated.unique_sources / total_conversations) * 100, 1)
        aggregated.affected_percentage = percentage

        if percentage >= 15:
            occurrence_note = (
                f"\n\n**Occurrence**: This issue appeared in "
                f"{aggregated.unique_sources} out of {total_conversations} conversations "
                f"({percentage}%)."
            )
            desc = re.sub(r"\([^)]*\d+(\.\d+)?%[^)]*\)", "", aggregated.description)
            desc = re.sub(r"representing \d+(\.\d+)?% of", "across", desc)
            aggregated.description = desc.strip() + occurrence_note
        else:
            if "systemic" in aggregated.title.lower() and percentage < 15:
                aggregated.title = re.sub(
                    r"\bSystemic\s+", "", aggregated.title, flags=re.IGNORECASE
                ).strip()


def add_severity_escalation(
    aggregated: AggregatedFinding, total_conversations: int
) -> None:
    """Add severity escalation based on occurrence percentage.

    Args:
        aggregated: AggregatedFinding instance to update
        total_conversations: Total number of conversations in session
    """
    if total_conversations > 0 and aggregated.unique_sources > 1:
        percentage = aggregated.affected_percentage or 0

        if aggregated.label == "Warning":
            if percentage >= 40:
                aggregated.escalated_label = "Critical"
                aggregated.escalation_reason = (
                    f"Escalated from Warning to Critical: "
                    f"systemic issue affecting {percentage}% of conversations"
                )
            elif percentage >= 20:
                aggregated.escalated_label = "High Priority"
                aggregated.escalation_reason = (
                    f"Escalated from Warning to High Priority: "
                    f"repeated issue affecting {percentage}% of conversations"
                )


# Backward compatibility aliases
create_key_finding = create_aggregated_finding
"""Deprecated: Use create_aggregated_finding instead."""


__all__ = [
    "create_aggregated_finding",
    "update_from_llm",
    "add_instances",
    "calculate_average_scores",
    "add_occurrence_stats",
    "add_severity_escalation",
    # Backward compatibility
    "create_key_finding",
]
