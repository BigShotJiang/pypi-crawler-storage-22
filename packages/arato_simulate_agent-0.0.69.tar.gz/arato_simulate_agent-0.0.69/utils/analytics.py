"""
Agent Analytics Service

This module provides analytics tracking for agent execution runs.
It consists of two main components:

1. AnalyticsClient - Used by the app to send metrics to the service
2. AnalyticsSender - Adapter architecture for sending metrics to various targets

Current supported targets:
- Google BigQuery
"""

import json
import logging
import math
import os
from abc import ABC, abstractmethod
from datetime import UTC, datetime
from typing import Any

from google.cloud import bigquery

logger = logging.getLogger(__name__)


class AgentRunMetrics:
    """Data model for agent run metrics."""

    def __init__(
        self,
        session_id: str,
        target_url: str,
        start_time: datetime,
        end_time: datetime | None = None,
        num_personas: int = 0,
        num_conversations: int = 0,
        total_tokens: int = 0,
        estimated_cost: float = 0.0,
        avg_response_time: float = 0.0,
        std_response_time: float = 0.0,
        avg_response_length: float = 0.0,
        std_response_length: float = 0.0,
        org_id: str | None = None,
        task_id: str | None = None,
        goal: str = "chat",
        status: str = "running",
        error: str | None = None,
        aes_score: float | None = None,
        stats: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        environment: str = "local",
    ):
        """
        Initialize agent run metrics.

        Args:
            session_id: Unique session identifier
            target_url: Target URL being tested
            start_time: When the agent run started
            end_time: When the agent run completed (None if still running)
            num_personas: Number of personas used in this run
            num_conversations: Number of conversations conducted
            total_tokens: Total number of tokens used
            estimated_cost: Estimated cost in USD
            avg_response_time: Average chatbot response time in seconds
            std_response_time: Standard deviation of response time in seconds
            avg_response_length: Average chatbot response length in characters
            std_response_length: Standard deviation of response length in characters
            org_id: Optional organization ID
            task_id: Optional task ID
            goal: Execution goal ('chat' or 'discover')
            status: Run status ('running', 'completed', 'failed')
            error: Error message if failed
            aes_score: Agent Expertise Score (0-100)
            stats: Additional statistics from the run report
            metadata: Metadata from the run report
            environment: Execution environment (local, agentcore)
        """
        self.session_id = session_id
        self.target_url = target_url
        self.start_time = start_time
        self.end_time = end_time
        self.num_personas = num_personas
        self.num_conversations = num_conversations
        self.total_tokens = total_tokens
        self.estimated_cost = estimated_cost
        self.avg_response_time = avg_response_time
        self.std_response_time = std_response_time
        self.avg_response_length = avg_response_length
        self.std_response_length = std_response_length
        self.org_id = org_id
        self.task_id = task_id
        self.goal = goal
        self.status = status
        self.error = error
        self.aes_score = aes_score
        self.stats = stats or {}
        self.metadata = metadata or {}
        self.environment = environment

    def to_dict(self) -> dict[str, Any]:
        """Convert metrics to dictionary format."""
        data = {
            "session_id": self.session_id,
            "target_url": self.target_url,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "duration_seconds": (
                (self.end_time - self.start_time).total_seconds()
                if self.end_time
                else None
            ),
            "num_personas": self.num_personas,
            "num_conversations": self.num_conversations,
            "total_tokens": self.total_tokens,
            "estimated_cost": self.estimated_cost,
            "avg_response_time": self.avg_response_time,
            "std_response_time": self.std_response_time,
            "avg_response_length": self.avg_response_length,
            "std_response_length": self.std_response_length,
            "org_id": self.org_id,
            "task_id": self.task_id,
            "goal": self.goal,
            "status": self.status,
            "error": self.error,
            "aes_score": self.aes_score,
            # Initialize complex fields to None to avoid 'is not a record' errors
            # These will be populated as JSON strings below if they have data
            "stats": None,
            "metadata": None,
            "environment": None,
        }

        # Serialize nested dictionaries to JSON strings for BigQuery compatibility
        if self.metadata:
            data["metadata"] = json.dumps(self.metadata)

        if self.stats:
            data["stats"] = json.dumps(self.stats)

        # Ensure environment is a string if it's not already
        if self.environment:
            if isinstance(self.environment, str):
                data["environment"] = self.environment
            else:
                data["environment"] = json.dumps(self.environment)

        return data


class AnalyticsSender(ABC):
    """Abstract base class for analytics senders."""

    @abstractmethod
    def send(self, metrics: AgentRunMetrics) -> bool:
        """
        Send metrics to the analytics target.

        Args:
            metrics: Agent run metrics to send

        Returns:
            True if successful, False otherwise
        """
        pass


class BigQuerySender(AnalyticsSender):
    """Send metrics to Google BigQuery."""

    def __init__(
        self,
        project_id: str | None = None,
        dataset_id: str | None = None,
        table_id: str | None = None,
    ):
        """
        Initialize BigQuery sender.

        Args:
            project_id: GCP project ID (defaults to BIGQUERY_PROJECT_ID env var)
            dataset_id: BigQuery dataset ID (defaults to BIGQUERY_DATASET_ID env var)
            table_id: BigQuery table ID (defaults to BIGQUERY_TABLE_ID env var)
        """
        import constants

        self.project_id = project_id or constants.BIGQUERY_PROJECT_ID
        self.dataset_id = dataset_id or constants.BIGQUERY_DATASET_ID
        self.table_id = table_id or constants.BIGQUERY_TABLE_ID

        if not all([self.project_id, self.dataset_id, self.table_id]):
            logger.warning(
                "BigQuery configuration incomplete. Set BIGQUERY_PROJECT_ID, "
                "BIGQUERY_DATASET_ID, and BIGQUERY_TABLE_ID environment variables."
            )
            self._enabled = False
        else:
            self._enabled = True
            logger.info(
                f"BigQuery sender configured: {self.project_id}.{self.dataset_id}.{self.table_id}"
            )

    def send(self, metrics: AgentRunMetrics) -> bool:
        """
        Send metrics to BigQuery.

        Args:
            metrics: Agent run metrics to send

        Returns:
            True if successful, False otherwise
        """
        if not self._enabled:
            logger.debug("BigQuery sender not configured, skipping")
            return False

        try:
            client = bigquery.Client(project=self.project_id)

            # Get table reference to validate it exists and for proper insert
            table_ref = f"{self.project_id}.{self.dataset_id}.{self.table_id}"

            try:
                table = client.get_table(table_ref)
            except Exception as e:
                logger.error(
                    f"BigQuery table not found or not accessible: {table_ref} - {e}"
                )
                return False

            # Convert metrics to BigQuery row format
            row = metrics.to_dict()

            # Insert row into BigQuery using proper table reference
            errors = client.insert_rows_json(table, [row])

            if errors:
                logger.error(f"BigQuery insert errors: {errors}")
                return False

            logger.info(f"✓ Sent metrics to BigQuery: {metrics.session_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to send metrics to BigQuery: {e}")
            return False


class AnalyticsClient:
    """Client for sending agent run metrics."""

    _instance: "AnalyticsClient | None" = None

    @classmethod
    def get_instance(cls) -> "AnalyticsClient":
        """
        Get the global analytics client instance.

        Returns:
            AnalyticsClient instance
        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        """Initialize the analytics client."""
        self._senders: list[AnalyticsSender] = []
        self._enabled = True

        # Auto-configure senders based on environment variables
        self._configure_senders()

    def _configure_senders(self) -> None:
        """Auto-configure analytics senders from environment variables."""
        import constants

        # Check if analytics is disabled
        if not constants.ANALYTICS_ENABLED:
            self._enabled = False
            logger.info("Analytics disabled via environment configuration")
            return

        # Configure BigQuery sender if credentials are available
        # We only configure it if ALL required variables are present
        bq_project = constants.BIGQUERY_PROJECT_ID
        bq_dataset = constants.BIGQUERY_DATASET_ID
        bq_table = constants.BIGQUERY_TABLE_ID

        if bq_project and bq_dataset and bq_table:
            bigquery_sender = BigQuerySender(
                project_id=bq_project,
                dataset_id=bq_dataset,
                table_id=bq_table,
            )
            self._senders.append(bigquery_sender)
            logger.info("✓ BigQuery analytics sender configured")

        if not self._senders:
            logger.info("No analytics senders configured")

    def add_sender(self, sender: AnalyticsSender) -> None:
        """
        Add a custom analytics sender.

        Args:
            sender: Analytics sender to add
        """
        self._senders.append(sender)
        logger.info(f"Added analytics sender: {sender.__class__.__name__}")

    def send_metrics(self, metrics: AgentRunMetrics) -> bool:
        """
        Send metrics to all configured senders.

        Args:
            metrics: Agent run metrics to send

        Returns:
            True if at least one sender succeeded, False otherwise
        """
        if not self._enabled:
            logger.debug("Analytics disabled, skipping metrics send")
            return False

        if not self._senders:
            logger.debug("No analytics senders configured, skipping metrics send")
            return False

        success = False
        for sender in self._senders:
            try:
                if sender.send(metrics):
                    success = True
            except Exception as e:
                logger.error(
                    f"Error sending metrics with {sender.__class__.__name__}: {e}"
                )

        return success

    def track_run_start(
        self,
        session_id: str,
        target_url: str,
        num_personas: int = 1,
        org_id: str | None = None,
        task_id: str | None = None,
        goal: str = "chat",
    ) -> AgentRunMetrics:
        """
        Track the start of an agent run.

        Args:
            session_id: Unique session identifier
            target_url: Target URL being tested
            num_personas: Number of personas to run
            org_id: Optional organization ID
            task_id: Optional task ID
            goal: Execution goal ('chat' or 'discover')

        Returns:
            AgentRunMetrics object to track throughout the run
        """
        # Detect environment
        environment = (
            "agentcore"
            if os.environ.get("BEDROCK_AGENTCORE_AGENT_ID")
            or os.environ.get("BEDROCK_AGENTCORE_MEMORY_ID")
            else "local"
        )

        metrics = AgentRunMetrics(
            session_id=session_id,
            target_url=target_url,
            start_time=datetime.now(UTC),
            num_personas=num_personas,
            org_id=org_id,
            task_id=task_id,
            goal=goal,
            environment=environment,
            status="running",
        )

        # Send start metrics
        self.send_metrics(metrics)
        logger.info(f"📊 Tracking agent run start: {session_id}")

        return metrics

    def track_run_complete(
        self,
        metrics: AgentRunMetrics,
        num_conversations: int = 0,
        total_tokens: int = 0,
        estimated_cost: float = 0.0,
        response_stats: dict[str, float] | None = None,
        status: str = "completed",
        error: str | None = None,
        aes_score: float | None = None,
        stats: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        Track the completion of an agent run.

        Args:
            metrics: Metrics object from track_run_start
            num_conversations: Number of conversations conducted
            total_tokens: Total number of tokens used
            estimated_cost: Estimated cost in USD
            response_stats: Dictionary with response time/length statistics
            status: Final status ('completed' or 'failed')
            error: Error message if failed
            aes_score: Agent Expertise Score (0-100)
            stats: Additional statistics from the run report
            metadata: Metadata from the run report
        """
        metrics.end_time = datetime.now(UTC)
        metrics.num_conversations = num_conversations
        metrics.total_tokens = total_tokens
        metrics.estimated_cost = estimated_cost
        metrics.status = status
        metrics.error = error
        metrics.aes_score = aes_score
        metrics.stats = stats or {}
        metrics.metadata = metadata or {}

        # Extract response statistics if provided
        if response_stats:
            metrics.avg_response_time = response_stats.get("avg_response_time", 0.0)
            metrics.std_response_time = response_stats.get("std_response_time", 0.0)
            metrics.avg_response_length = response_stats.get("avg_response_length", 0.0)
            metrics.std_response_length = response_stats.get("std_response_length", 0.0)

        # Send complete metrics
        self.send_metrics(metrics)
        logger.info(f"📊 Tracking agent run complete: {metrics.session_id} ({status})")


def calculate_response_statistics(
    results: dict[str, Any],
) -> dict[str, float]:
    """
    Calculate response statistics from persona results.

    Args:
        results: Dictionary mapping persona_id to result containing transcript

    Returns:
        Dictionary with avg_response_time, std_response_time, avg_response_length, std_response_length
    """
    all_response_times = []
    all_response_lengths = []

    for _persona_name, result in results.items():
        # Skip if error occurred
        if "error" in result:
            continue

        # Extract metrics from transcript
        transcript = result.get("transcript", [])
        for turn in transcript:
            if isinstance(turn, dict) and turn.get("role") == "assistant":
                # Extract TTFT for response time statistics
                measurements = turn.get("measurements", {})
                if "ttft" in measurements:
                    all_response_times.append(measurements["ttft"])
                elif "latency_seconds" in measurements:
                    all_response_times.append(measurements["latency_seconds"])

                # Extract response length
                text = turn.get("text", "")
                all_response_lengths.append(len(text))

    # Calculate statistics
    stats: dict[str, float] = {
        "avg_response_time": 0.0,
        "std_response_time": 0.0,
        "avg_response_length": 0.0,
        "std_response_length": 0.0,
    }

    # Response time statistics
    if all_response_times:
        avg_time = sum(all_response_times) / len(all_response_times)
        stats["avg_response_time"] = round(avg_time, 3)

        if len(all_response_times) > 1:
            variance = sum((x - avg_time) ** 2 for x in all_response_times) / len(
                all_response_times
            )
            stats["std_response_time"] = round(math.sqrt(variance), 3)

    # Response length statistics
    if all_response_lengths:
        avg_length = sum(all_response_lengths) / len(all_response_lengths)
        stats["avg_response_length"] = round(avg_length, 1)

        if len(all_response_lengths) > 1:
            variance = sum((x - avg_length) ** 2 for x in all_response_lengths) / len(
                all_response_lengths
            )
            stats["std_response_length"] = round(math.sqrt(variance), 1)

    return stats


__all__ = [
    "AnalyticsClient",
    "AnalyticsSender",
    "BigQuerySender",
    "AgentRunMetrics",
    "calculate_response_statistics",
]
