"""
Arato Monitor - Global prompt monitoring with environment-based configuration

This module provides monitoring for LLM prompt invocations across the application.
Monitoring is configured via environment variables:
- ARATO_MONITOR_TOKEN (shared across all prompts)
- ARATO_<PROMPT_NAME>_URL (per-prompt URL, e.g., ARATO_CHAT_RUNNER_ANALYSIS_URL)
"""

import logging
import os
from datetime import UTC, datetime
from typing import Any

import requests

logger = logging.getLogger(__name__)


class AratoMonitor:
    """
    Global prompt monitoring with environment-based configuration.

    Configured via environment variables:
    - ARATO_MONITOR_TOKEN (shared across all prompts)
    - ARATO_<PROMPT_NAME>_URL (per-prompt URL, e.g., ARATO_CHAT_RUNNER_ANALYSIS_URL)

    Example:
      monitor = AratoMonitor.get_instance()
      if monitor:  # Only if configured
        monitor.send(
          prompt_name='chat_runner_analysis',
          llm_result=result,
          log_id=log_id,
          ...
        )
    """

    _instance: "AratoMonitor | None" = None  # Singleton instance

    @classmethod
    def get_instance(cls) -> "AratoMonitor | None":
        """
        Get the global monitor instance.

        Returns None if monitoring not configured.
        Auto-configures from environment variable:
        - ARATO_MONITOR_TOKEN

        Per-prompt URLs are looked up dynamically in send() method.

        Returns:
          AratoMonitor instance if configured, None otherwise
        """
        if cls._instance is None:
            # Auto-lookup token
            api_token = os.getenv("ARATO_MONITOR_TOKEN")

            if not api_token:
                logger.debug("Monitoring not configured (missing ARATO_MONITOR_TOKEN)")
                return None

            logger.info("✓ Monitoring configured with ARATO_MONITOR_TOKEN")
            cls._instance = cls(api_token)

        return cls._instance

    def __init__(self, api_token: str):
        """
        Initialize monitor instance.

        Typically not called directly - use AratoMonitor.get_instance() instead.

        Args:
          api_token: Arato API authentication token (shared across all prompts)
        """
        self.api_token = api_token
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_token}",
        }

    def send(
        self,
        prompt_name: str,
        llm_response: Any,
        prompt_content: str,
        session_id: str | None = None,
        persona_id: str | None = None,
        target_url: str | None = None,
        latency_stats: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
    ) -> requests.Response | None:
        """
        Send monitoring data to Arato for a prompt invocation.

        This method handles all the data extraction and preparation internally.
        The API URL is looked up from environment variable ARATO_<PROMPT_NAME>_URL.

        Args:
          prompt_name: Name of the prompt being monitored (e.g., 'chat_runner_analysis')
          llm_response: The raw LLM response object (with usage, completion, etc.)
          prompt_content: The actual prompt text sent to the LLM
          session_id: Session identifier for tracking
          persona_id: Persona identifier for tagging
          target_url: Target URL for tagging
          latency_stats: Latency statistics dict with avg_latency, median_latency, etc.
          variables: Prompt template variables (from load_prompt kwargs)

        Returns:
          Response object if successful, None if failed
        """
        try:
            # Dynamically look up URL for this prompt
            # Convert prompt_name to uppercase and construct env var name
            # Example: 'chat_runner_analysis' -> 'ARATO_CHAT_RUNNER_ANALYSIS_URL'
            env_var_name = f"ARATO_{prompt_name.upper()}_URL"
            api_url = os.getenv(env_var_name)

            if not api_url:
                logger.debug(
                    f"Monitoring URL not configured for prompt '{prompt_name}' "
                    f"(missing {env_var_name})"
                )
                return None

            # Extract LLM result text (response)
            llm_result = getattr(llm_response, "completion", str(llm_response))

            # Build messages array with prompt content
            messages = [{"role": "user", "content": prompt_content}]

            # Build usage data from response
            usage_data = None
            if hasattr(llm_response, "usage") and llm_response.usage:
                usage_obj = llm_response.usage
                usage_data = {
                    "completion_tokens": getattr(usage_obj, "output_tokens", 0),
                    "prompt_tokens": getattr(usage_obj, "input_tokens", 0),
                    "total_tokens": getattr(usage_obj, "total_tokens", 0),
                }

            # Build performance data from latency stats
            performance_data: dict[str, str | int] | None = None
            if latency_stats and latency_stats.get("count", 0) > 0:
                performance_data = {
                    "avg_latency_ms": int(latency_stats.get("avg_latency", 0) * 1000),
                    "median_latency_ms": int(
                        latency_stats.get("median_latency", 0) * 1000
                    ),
                }

            # Build tags
            tags: dict[str, Any] = {"event_type": "analysis"}
            if persona_id:
                tags["persona_id"] = persona_id
            if target_url:
                tags["url"] = target_url

            # Add environment tag if configured
            env_tag = os.getenv("ARATO_MONITOR_ENV_TAG")
            if env_tag:
                tags["env"] = env_tag

            # Construct arato_thread_id: sessionid-personaid
            if session_id and persona_id:
                arato_thread_id = f"{session_id}-{persona_id}"
            elif persona_id:
                arato_thread_id = persona_id
            else:
                arato_thread_id = "unknown"

            # Construct log_id (event_id) from session, persona, and timestamp
            timestamp_str = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
            if session_id and persona_id:
                log_id = f"{session_id}/{persona_id}_{timestamp_str}"
            elif persona_id:
                log_id = f"{persona_id}_{timestamp_str}"
            else:
                log_id = f"{timestamp_str}"

            # Get model name from response
            model_name = getattr(llm_response, "model_name", "claude-3-5-sonnet")

            logger.info(
                f'Sending monitor for prompt "{prompt_name}" '
                f"(thread_id: {arato_thread_id}, event_id: {log_id})"
            )

            # Build payload matching AratoLogsAPI structure
            payload: dict[str, Any] = {
                "prompt_id": prompt_name,  # Maps to prompt_name
                "messages": messages,  # Prompt as [{role: user, content: ...}]
                "response": llm_result,  # LLM response text
                "id": log_id,  # Event ID
                "model": model_name,
                "event_source": "aut",
            }

            if usage_data:
                payload["usage"] = usage_data
            if performance_data:
                payload["performance"] = performance_data
            if tags:
                payload["tags"] = tags
            if variables:
                # Add prompt_text to variables
                variables_with_prompt = variables.copy()
                variables_with_prompt["prompt_text"] = prompt_content
                payload["variables"] = variables_with_prompt
            else:
                # If no variables provided, just send prompt_text
                payload["variables"] = {"prompt_text": prompt_content}

            # Remove None values to keep payload clean
            payload = {k: v for k, v in payload.items() if v is not None}

            response = requests.post(
                api_url, json=payload, headers=self.headers, timeout=5
            )

            if response.status_code == 200:
                logger.debug(
                    f'✓ Sent monitor for "{prompt_name}" '
                    f"(thread_id: {arato_thread_id}, event_id: {log_id})"
                )
                return response
            else:
                logger.warning(
                    f'Monitor failed for "{prompt_name}": '
                    f"HTTP {response.status_code} - {response.text[:200]}"
                )
                return None

        except requests.exceptions.Timeout:
            logger.warning(f'Monitor timeout for "{prompt_name}"')
            return None
        except Exception as e:
            logger.warning(f'Monitor error for "{prompt_name}": {e}')
            return None
