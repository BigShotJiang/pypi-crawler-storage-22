"""
Auth Profile Loader: Downloads auth profiles from the server and writes
them to the expected file locations for the existing auto_login/auto_otp system.

Usage:
    loaded = load_auth_profiles_for_run(
        task_endpoint="https://app.arato.ai/api/v1/agent-connect/task",
        api_key="ak_...",
        agent_name="arato_agent_12345",
        agent_platform="local",
        task_id="clxxxxxxxxxxxxxxxxx",
    )
"""

from __future__ import annotations

import logging
from pathlib import Path

import requests

logger = logging.getLogger(__name__)

AUTH_STATES_DIR = Path(__file__).parent.parent / "auth_states"
PASSWORDS_FILE = AUTH_STATES_DIR / ".passwords"
OTP_FILE = AUTH_STATES_DIR / ".otp_codes"


def load_auth_profiles_for_run(
    task_endpoint: str,
    api_key: str,
    agent_name: str,
    agent_platform: str,
    task_id: str,
) -> int:
    """Fetch auth profiles from server and write to local auth files.

    The existing auto_login.py reads from .passwords, auto_otp.py reads from
    .otp_codes, and ChatRunner._auto_lookup_storage_state() checks for
    auth_{domain}.json files. This loader bridges the new profile system to
    those existing mechanisms with zero changes to agent code.

    Returns:
        Number of profiles loaded.
    """
    # Derive base URL from task endpoint
    base_url = task_endpoint.rsplit("/api/v1/agent-connect/task", 1)[0]
    url = f"{base_url}/api/v1/agent-connect/auth-profiles/{task_id}"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "x-agent-name": agent_name,
        "x-agent-platform": agent_platform,
    }

    try:
        resp = requests.get(url, headers=headers, timeout=30)
        if resp.status_code == 204 or resp.status_code == 404:
            logger.debug(f"No auth profiles for task {task_id}")
            return 0
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.warning(f"Failed to fetch auth profiles for task {task_id}: {e}")
        return 0

    profiles = data.get("profiles", [])
    if not profiles:
        return 0

    AUTH_STATES_DIR.mkdir(exist_ok=True)
    loaded = 0

    for profile in profiles:
        domain = profile["domain"]
        method = profile["authMethod"]

        if method == "USERNAME_PASSWORD":
            creds = profile.get("credentials")
            if creds and creds.get("username") and creds.get("password"):
                # Append to .passwords file (CSV: domain,username,password)
                with open(PASSWORDS_FILE, "a") as f:
                    f.write(f"{domain},{creds['username']},{creds['password']}\n")
                logger.info(f"Loaded credentials for domain: {domain}")
                loaded += 1

            otp = profile.get("otpCode")
            if otp:
                # Append to .otp_codes file (CSV: domain,otp_code)
                with open(OTP_FILE, "a") as f:
                    f.write(f"{domain},{otp}\n")
                logger.info(f"Loaded OTP code for domain: {domain}")

        elif method == "GOOGLE_LOGIN":
            browser_profile = profile.get("browserProfile")
            if browser_profile:
                # Write storage state JSON to auth_{domain}.json
                safe_domain = domain.replace(":", "_").replace("/", "_")
                output_path = AUTH_STATES_DIR / f"auth_{safe_domain}.json"
                output_path.write_text(browser_profile)
                logger.info(f"Loaded browser profile for domain: {domain}")
                loaded += 1

    logger.info(f"Loaded {loaded} auth profile(s) for task {task_id}")
    return loaded
