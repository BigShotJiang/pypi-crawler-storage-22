"""
Authentication Time Tracker.

Tracks time spent on authentication flows (login, OTP, CAPTCHA, HITL)
to exclude from conversation timeout calculations.

Extracted from chat_runner.py for reuse in orchestrator.
"""

import logging
import time
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class AuthEvent:
    """Record of an authentication event."""

    event_type: str  # 'login', 'otp', 'captcha', 'hitl'
    start_time: float
    end_time: float | None = None
    duration: float = 0.0


class AuthTimeTracker:
    """
    Tracks authentication time to exclude from conversation timeout.

    Login flows (auto_login, OTP, CAPTCHA solving, HITL) should not count
    against the conversation time limit. This prevents premature timeouts
    when authentication takes a long time.
    """

    def __init__(self):
        """Initialize the tracker."""
        self._events: list[AuthEvent] = []
        self._current_event: AuthEvent | None = None
        self._total_auth_time: float = 0.0

    def start_auth(self, event_type: str) -> None:
        """
        Start tracking an authentication event.

        Args:
            event_type: Type of auth event ('login', 'otp', 'captcha', 'hitl')
        """
        if self._current_event:
            # End previous event if still active
            self.end_auth()

        self._current_event = AuthEvent(event_type=event_type, start_time=time.time())
        logger.debug(f"🔐 Started auth event: {event_type}")

    def end_auth(self) -> float:
        """
        End the current authentication event.

        Returns:
            Duration of the auth event in seconds
        """
        if not self._current_event:
            return 0.0

        self._current_event.end_time = time.time()
        self._current_event.duration = (
            self._current_event.end_time - self._current_event.start_time
        )
        self._total_auth_time += self._current_event.duration

        logger.debug(
            f"🔐 Ended auth event: {self._current_event.event_type} "
            f"(duration: {self._current_event.duration:.1f}s, total: {self._total_auth_time:.1f}s)"
        )

        self._events.append(self._current_event)
        duration = self._current_event.duration
        self._current_event = None

        return duration

    @property
    def total_auth_time(self) -> float:
        """Get total authentication time in seconds."""
        # Include current event if still active
        if self._current_event:
            current_duration = time.time() - self._current_event.start_time
            return self._total_auth_time + current_duration
        return self._total_auth_time

    def get_conversation_elapsed(self, total_elapsed: float) -> float:
        """
        Calculate conversation time excluding authentication.

        Args:
            total_elapsed: Total elapsed time since conversation start

        Returns:
            Conversation time (total - auth time)
        """
        return total_elapsed - self.total_auth_time

    @property
    def events(self) -> list[AuthEvent]:
        """Get list of all auth events."""
        return self._events.copy()

    def is_auth_in_progress(self) -> bool:
        """Check if an auth event is currently in progress."""
        return self._current_event is not None

    def get_current_event_type(self) -> str | None:
        """Get the type of current auth event, if any."""
        return self._current_event.event_type if self._current_event else None

    def clear(self) -> None:
        """Clear all tracked events."""
        self._events.clear()
        self._current_event = None
        self._total_auth_time = 0.0
        logger.debug("✓ Cleared auth time tracker")
