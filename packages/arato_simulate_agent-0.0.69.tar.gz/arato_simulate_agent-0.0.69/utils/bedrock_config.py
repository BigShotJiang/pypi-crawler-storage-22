"""Utilities for reading Bedrock AgentCore configuration."""

import os
from pathlib import Path
from typing import Any

import yaml

from constants import SSM_PARAM_AGENTCORE_AGENT_ARN, SSM_PARAM_AGENTCORE_AGENT_ID


def _get_ssm_parameter(name: str, region: str = "us-east-1") -> str | None:
    """Read a single SSM parameter. Returns None on any failure."""
    try:
        import boto3

        ssm = boto3.client("ssm", region_name=region)
        resp = ssm.get_parameter(Name=name)
        return resp["Parameter"]["Value"]
    except Exception:
        return None


def _read_yaml_config() -> dict[str, Any] | None:
    """Read and validate .bedrock_agentcore.yaml, returning the bedrock_agentcore section."""
    config_path = Path(".bedrock_agentcore.yaml")
    if not config_path.exists():
        return None

    with open(config_path) as f:
        config: Any = yaml.safe_load(f)

    if not isinstance(config, dict):
        return None

    default_agent = config.get("default_agent")
    if not isinstance(default_agent, str):
        return None

    agents = config.get("agents")
    if not isinstance(agents, dict) or default_agent not in agents:
        return None

    agent_config = agents[default_agent]
    if not isinstance(agent_config, dict):
        return None

    bedrock_config = agent_config.get("bedrock_agentcore")
    if not isinstance(bedrock_config, dict):
        return None

    return bedrock_config


def get_agent_id(required: bool = True, region: str = "us-east-1") -> str | None:
    """Get agent ID from environment variable, config file, or SSM.

    Fallback chain: env var → .bedrock_agentcore.yaml → SSM Parameter Store.

    Args:
        required: If True, raises ValueError when ID cannot be determined.
                 If False, returns None when ID cannot be determined.
        region: AWS region for SSM lookups.

    Returns:
        Agent ID string (e.g., 'arato_agent-5x1zoK9pSm') or None if not required and not found.

    Raises:
        ValueError: If required=True and agent_id cannot be determined from any source
    """
    # 1. Environment variable (deployed containers)
    agent_id = os.getenv("BEDROCK_AGENTCORE_AGENT_ID")
    if agent_id:
        return agent_id

    # 2. Config file (local development)
    bedrock_config = _read_yaml_config()
    if bedrock_config:
        agent_id_value = bedrock_config.get("agent_id")
        if isinstance(agent_id_value, str):
            return agent_id_value

    # 3. SSM Parameter Store (CI/CD cross-job discovery)
    agent_id = _get_ssm_parameter(SSM_PARAM_AGENTCORE_AGENT_ID, region)
    if agent_id:
        return agent_id

    if not required:
        return None
    raise ValueError(
        "Agent ID not found in BEDROCK_AGENTCORE_AGENT_ID env var, "
        ".bedrock_agentcore.yaml, or SSM"
    )


def get_agent_arn(required: bool = True, region: str = "us-east-1") -> str | None:
    """Get agent runtime ARN from config file or SSM.

    Fallback chain: .bedrock_agentcore.yaml → SSM Parameter Store.

    Args:
        required: If True, raises ValueError when ARN cannot be determined.
                 If False, returns None when ARN cannot be determined.
        region: AWS region for SSM lookups.

    Returns:
        Agent ARN string or None if not required and not found.

    Raises:
        ValueError: If required=True and ARN cannot be determined from any source
    """
    # 1. Config file
    bedrock_config = _read_yaml_config()
    if bedrock_config:
        agent_arn = bedrock_config.get("agent_arn")
        if isinstance(agent_arn, str):
            return agent_arn

    # 2. SSM Parameter Store
    agent_arn = _get_ssm_parameter(SSM_PARAM_AGENTCORE_AGENT_ARN, region)
    if agent_arn:
        return agent_arn

    if not required:
        return None
    raise ValueError("Agent ARN not found in .bedrock_agentcore.yaml or SSM")
