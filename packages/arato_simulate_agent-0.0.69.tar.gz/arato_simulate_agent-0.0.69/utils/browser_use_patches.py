"""Custom patches for browser-use library.

This module provides:
1. Custom screensaver (Arato logo instead of browser-use logo)
2. AWS Bedrock chat adapter optimized for Arato's needs
3. Various timeout and debug patches"""

from dataclasses import dataclass
from os import getenv
from typing import TYPE_CHECKING, Any, TypeVar, cast, overload

from botocore.config import Config
from browser_use.browser.events import BrowserStateRequestEvent
from browser_use.llm.views import ChatInvokeUsage
from cdp_use.cdp.target import TargetID
from pydantic import BaseModel

from constants import BEDROCK_MODEL_ID_SONNET

if TYPE_CHECKING:
    from boto3 import client as AwsClient
    from boto3.session import Session

T = TypeVar("T", bound=BaseModel)


async def _arato_screensaver(
    self: Any, target_id: TargetID, browser_session_label: str
) -> None:
    """
    Injects a centered Arato logo overlay into the target using CDP.
    This is used to visually indicate that the browser is setting up or waiting.
    """
    try:
        # Create temporary session for this target without switching focus
        temp_session = await self.browser_session.get_or_create_cdp_session(
            target_id, focus=False
        )

        # Inject the centered logo script
        script = f"""
            (function(browser_session_label) {{
                // Idempotency check
                if (window.__aratoLogoShown) {{
                    return; // Already shown, don't add another
                }}
                window.__aratoLogoShown = true;

                // Ensure document.body exists before proceeding
                if (!document.body) {{
                    // Try again after DOM is ready
                    window.__aratoLogoShown = false; // Reset flag to retry
                    if (document.readyState === 'loading') {{
                        document.addEventListener('DOMContentLoaded', () => arguments.callee(browser_session_label));
                    }}
                    return;
                }}

                const page_title = `Starting Arato Agent ${{browser_session_label}}...`;
                if (document.title === page_title) {{
                    return;      // already run on this tab, dont run again
                }}
                document.title = page_title;

                // Create the main overlay with flexbox centering
                const loadingOverlay = document.createElement('div');
                loadingOverlay.id = 'arato-loading-overlay';
                loadingOverlay.style.position = 'fixed';
                loadingOverlay.style.top = '0';
                loadingOverlay.style.left = '0';
                loadingOverlay.style.width = '100vw';
                loadingOverlay.style.height = '100vh';
                loadingOverlay.style.background = '#000';
                loadingOverlay.style.zIndex = '99999';
                loadingOverlay.style.display = 'flex';
                loadingOverlay.style.alignItems = 'center';
                loadingOverlay.style.justifyContent = 'center';

                // Create the image element with Arato logo (embedded SVG)
                const img = document.createElement('img');
                img.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTc1IiBoZWlnaHQ9IjE3NSIgdmlld0JveD0iMCAwIDE3NSAxNzUiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxnIGNsaXAtcGF0aD0idXJsKCNjbGlwMF8xXzE4MCkiPgo8cGF0aCBkPSJNNjYuNTcxOSAzOS44MjE4QzkyLjQwNjQgMzkuODIxOCAxMTEuMzY0IDU0LjY5MDYgMTExLjM2NCA3Ny45MjNWMTQwSDg3LjIwMjNWMTEzLjA1Qzc5Ljk1MzggMTI5Ljk2NCA2NS40NTY4IDE0MS44NTkgNDcuNDI4NCAxNDEuODU5QzI4Ljg0MjUgMTQxLjg1OSAxNy44NzY4IDEyOS45NjQgMTcuODc2OCAxMTYuMjFDMTcuODc2OCA5Ny44MDk5IDM3LjM5MiA4Ny4yMTYgNTcuNDY0OCA4Mi43NTUzTDg3LjIwMjMgNzUuODc4NVY3NS4xMzUxQzg3LjIwMjMgNjYuOTU3MyA4MS40NDA3IDU3LjY2NDMgNjYuNzU3OCA1Ny42NjQzQzUzLjkzMzUgNTcuNjY0MyA0My43MTEyIDY2LjIxMzkgNDMuNzExMiA3OC42NjY0SDE5LjU0OTVDMjAuMTA3MSA1NS45OTE2IDM5LjYyMjMgMzkuODIxOCA2Ni41NzE5IDM5LjgyMThaTTU2LjUzNTUgMTIyLjUyOUM3NC4wMDYzIDEyMi41MjkgODcuMjAyMyAxMDIuNjQyIDg3LjIwMjMgODkuMDc0Nkw2Mi4xMTEzIDk3LjYyNDFDNTAuNzczOSAxMDEuMzQxIDQ0LjA4MyAxMDcuNDc1IDQ0LjA4MyAxMTMuNDIyQzQ0LjA4MyAxMTguMDY5IDQ4LjM1NzcgMTIyLjUyOSA1Ni41MzU1IDEyMi41MjlaIiBmaWxsPSIjMzUzNDM0Ii8+CjxwYXRoIGQ9Ik0xMzAuMTY4IDM2LjM1MTJDMTMwLjczIDM1LjA1MDQgMTMyLjM4OCAzNS4wNTA0IDEzMi45NTEgMzYuMzUxMkwxNDQuMjA2IDYyLjM4MTlDMTQ0LjcwMSA2My41Mjg0IDE0My45NTQgNjQuODU5NiAxNDIuODE0IDY0Ljg1OTZIMTIwLjMwNEMxMTkuMTY1IDY0Ljg1OTYgMTE4LjQxNyA2My41Mjg1IDExOC45MTMgNjIuMzgxOUwxMzAuMTY4IDM2LjM1MTJaIiBmaWxsPSIjMzUzNDM0Ii8+CjxyZWN0IHg9IjE0OC4yNDEiIHk9IjM2LjE1MTQiIHdpZHRoPSI3Ljc1ODk2IiBoZWlnaHQ9IjI4LjcwODEiIHJ4PSIxLjU1MTc5IiBmaWxsPSIjMzUzNDM0Ii8+CjwvZz4KPGRlZnM+CjxjbGlwUGF0aCBpZD0iY2xpcDBfMV8xODAiPgo8cmVjdCB3aWR0aD0iMTc1IiBoZWlnaHQ9IjE3NSIgZmlsbD0id2hpdGUiLz4KPC9jbGlwUGF0aD4KPC9kZWZzPgo8L3N2Zz4K';
                img.alt = 'Arato';
                img.style.width = '200px';
                img.style.height = 'auto';
                img.style.opacity = '0.8';

                loadingOverlay.appendChild(img);
                document.body.appendChild(loadingOverlay);

                // Add CSS for smoothness
                const style = document.createElement('style');
                style.textContent = `
                    #arato-loading-overlay img {{
                        user-select: none;
                        pointer-events: none;
                    }}
                `;
                document.head.appendChild(style);
            }})('{browser_session_label}');
        """

        await temp_session.cdp_client.send.Runtime.evaluate(
            params={"expression": script}, session_id=temp_session.session_id
        )

        # Dispatch event
        from browser_use.browser.events import AboutBlankDVDScreensaverShownEvent

        self.event_bus.dispatch(AboutBlankDVDScreensaverShownEvent(target_id=target_id))

    except Exception as e:
        self.logger.error(
            f"[AboutBlankWatchdog] Error injecting Arato logo overlay: {e}"
        )


# ==============================================================================
# ChatAWSBedrockAdapter: AWS Bedrock implementation adapted for Arato's needs
# ==============================================================================


@dataclass
class ChatAWSBedrockAdapter:
    """
    AWS Bedrock chat model adapted for Arato's specific requirements.

    This adapter enhances the browser-use library's ChatAWSBedrock with:
    - Proper schema serialization for complex Pydantic types (unions, discriminated unions, $defs, etc.)
    - SchemaOptimizer integration for consistent schema handling
    - Robust timeout management with ThreadPoolExecutor
    - Enhanced error handling and credential management

    Note: We don't inherit from BaseChatModel to avoid dataclass inheritance issues.
    The type system allows this since we implement the same interface.

    To use this model, you need to either:
    1. Set the following environment variables:
       - AWS_ACCESS_KEY_ID
       - AWS_SECRET_ACCESS_KEY
       - AWS_SESSION_TOKEN (only required when using temporary credentials)
       - AWS_REGION
    2. Or provide a boto3 Session object
    3. Or use AWS SSO authentication
    """

    # Model configuration
    model: str = BEDROCK_MODEL_ID_SONNET
    max_tokens: int | None = 4096
    temperature: float | None = None
    top_p: float | None = None
    seed: int | None = None
    stop_sequences: list[str] | None = None

    # AWS credentials and configuration
    aws_access_key_id: str | None = None
    aws_secret_access_key: str | None = None
    aws_session_token: str | None = None
    aws_region: str | None = None
    aws_sso_auth: bool = False
    session: "Session | None" = None

    # Request parameters (for API compatibility, not currently used)
    request_params: dict[str, Any] | None = None

    @property
    def provider(self) -> str:
        return "aws_bedrock"

    def _get_client(self) -> "AwsClient":  # type: ignore
        """Get the AWS Bedrock client."""
        try:
            from boto3 import client as AwsClient
        except ImportError as e:
            raise ImportError(
                "`boto3` not installed. Please install using `pip install boto3`"
            ) from e

        # Configure timeouts for Bedrock API calls
        # read_timeout: 300s (5 min) - per-read operation timeout
        # connect_timeout: 30s - reasonable time to establish connection
        # Note: We also wrap with asyncio timeout as a safety net
        #
        # IMPORTANT: max_pool_connections=1 prevents connection reuse issues
        # that can cause hanging requests when connections go stale
        boto_config = Config(
            read_timeout=300,  # 5 minutes per read operation
            connect_timeout=30,
            retries={"max_attempts": 2, "mode": "standard"},
            max_pool_connections=1,  # Prevent stale connection reuse
        )

        if self.session:
            return self.session.client("bedrock-runtime", config=boto_config)

        # Get credentials from environment or instance parameters
        access_key = self.aws_access_key_id or getenv("AWS_ACCESS_KEY_ID")
        secret_key = self.aws_secret_access_key or getenv("AWS_SECRET_ACCESS_KEY")
        session_token = self.aws_session_token or getenv("AWS_SESSION_TOKEN")
        region = self.aws_region or getenv("AWS_REGION") or getenv("AWS_DEFAULT_REGION")

        if self.aws_sso_auth:
            return AwsClient(
                service_name="bedrock-runtime",
                region_name=region,
                config=boto_config,
            )
        else:
            if not access_key or not secret_key:
                from browser_use.llm.exceptions import ModelProviderError

                raise ModelProviderError(
                    message="AWS credentials not found. Please set AWS_ACCESS_KEY_ID and "
                    "AWS_SECRET_ACCESS_KEY environment variables or provide a boto3 session.",
                    model=self.name,
                )

            return AwsClient(
                service_name="bedrock-runtime",
                region_name=region,
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                aws_session_token=session_token,
                config=boto_config,
            )

    @property
    def name(self) -> str:
        return str(self.model)

    @property
    def model_name(self) -> str:
        """Model name property required by browser-use event system."""
        return str(self.model)

    def _get_inference_config(self) -> dict[str, Any]:
        """Get the inference configuration for the request."""
        config: dict[str, Any] = {}
        if self.max_tokens is not None:
            config["maxTokens"] = self.max_tokens
        if self.temperature is not None:
            config["temperature"] = self.temperature
        if self.top_p is not None:
            config["topP"] = self.top_p
        if self.stop_sequences is not None:
            config["stopSequences"] = self.stop_sequences
        if self.seed is not None:
            config["seed"] = self.seed
        return config

    def _format_tools_for_request(
        self, output_format: type[BaseModel]
    ) -> list[dict[str, Any]]:
        """Format a Pydantic model as a tool for structured output.

        This uses SchemaOptimizer to properly handle complex Pydantic types including:
        - Discriminated unions (like AgentOutput's current_state field)
        - $defs references
        - Nested objects
        - Optional fields with anyOf
        """
        from browser_use.llm.schema import SchemaOptimizer

        # Use the same schema optimization as ChatAnthropicVertex
        schema = SchemaOptimizer.create_optimized_json_schema(output_format)

        # Remove title from schema if present (Bedrock doesn't need it in parameters)
        if "title" in schema:
            del schema["title"]

        tool_name = f"extract_{output_format.__name__.lower()}"

        return [
            {
                "toolSpec": {
                    "name": tool_name,
                    "description": f"Extract information in the format of {output_format.__name__}",
                    "inputSchema": {"json": schema},
                }
            }
        ]

    def _get_usage(self, response: dict[str, Any]) -> ChatInvokeUsage | None:
        """Extract usage information from the response."""

        if "usage" not in response:
            return None

        usage_data = response["usage"]
        return ChatInvokeUsage(
            prompt_tokens=usage_data.get("inputTokens", 0),
            completion_tokens=usage_data.get("outputTokens", 0),
            total_tokens=usage_data.get("totalTokens", 0),
            prompt_cached_tokens=None,  # Bedrock doesn't provide this
            prompt_cache_creation_tokens=None,
            prompt_image_tokens=None,
        )

    @overload
    async def ainvoke(
        self, messages: list[Any], output_format: None = None, **kwargs: Any
    ) -> Any: ...

    @overload
    async def ainvoke(
        self, messages: list[Any], output_format: type[T], **kwargs: Any
    ) -> Any: ...

    async def ainvoke(
        self, messages: list[Any], output_format: type[T] | None = None, **kwargs: Any
    ) -> Any:
        """
        Invoke the AWS Bedrock model with the given messages.

        Args:
            messages: List of chat messages
            output_format: Optional Pydantic model class for structured output

        Returns:
            Either a string response or an instance of output_format
        """
        from browser_use.llm.aws.serializer import AWSBedrockMessageSerializer
        from browser_use.llm.exceptions import ModelProviderError, ModelRateLimitError
        from browser_use.llm.views import ChatInvokeCompletion

        try:
            from botocore.exceptions import ClientError
        except ImportError as e:
            raise ImportError(
                "`boto3` not installed. Please install using `pip install boto3`"
            ) from e

        bedrock_messages, system_message = (
            AWSBedrockMessageSerializer.serialize_messages(messages)
        )

        try:
            # Prepare the request body
            body: dict[str, Any] = {}

            if system_message:
                body["system"] = system_message

            inference_config = self._get_inference_config()
            if inference_config:
                body["inferenceConfig"] = inference_config

            # Handle structured output via tool calling
            if output_format is not None:
                tools = self._format_tools_for_request(output_format)
                tool_name = tools[0]["toolSpec"]["name"]
                body["toolConfig"] = {
                    "tools": tools,
                    "toolChoice": {"tool": {"name": tool_name}},
                }

            # Make the API call with explicit timeout wrapper
            # We use concurrent.futures for more reliable timeout enforcement
            # because asyncio.to_thread can't interrupt blocked threads
            import logging
            import time
            from concurrent.futures import ThreadPoolExecutor
            from concurrent.futures import TimeoutError as FuturesTimeoutError

            logger = logging.getLogger(__name__)
            start_time = time.time()

            logger.info(f"🔄 Starting Bedrock API call to {self.model}...")

            # Create a fresh client for each call to avoid stale connection issues
            client = self._get_client()

            def _sync_invoke() -> dict[str, Any]:
                return client.converse(
                    modelId=self.model,
                    messages=bedrock_messages,
                    **body,
                )

            # Use ThreadPoolExecutor with timeout for more reliable timeout enforcement
            # The executor timeout will raise even if the thread is blocked
            timeout_seconds = 300.0  # 5 minutes max per API call
            try:
                with ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(_sync_invoke)
                    try:
                        response = future.result(timeout=timeout_seconds)
                    except FuturesTimeoutError as e:
                        elapsed = time.time() - start_time
                        logger.error(
                            f"⏱️ Bedrock API call timed out after {elapsed:.1f}s"
                        )
                        # Cancel the future (won't stop the thread but prevents result retrieval)
                        future.cancel()
                        raise ModelProviderError(
                            message=f"Request timed out after {elapsed:.1f} seconds",
                            status_code=408,
                            model=self.name,
                        ) from e
                elapsed = time.time() - start_time
                logger.info(f"✅ Bedrock API call completed in {elapsed:.1f}s")
            except ModelProviderError:
                raise
            except Exception as e:
                elapsed = time.time() - start_time
                logger.error(f"❌ Bedrock API call failed after {elapsed:.1f}s: {e}")
                raise ModelProviderError(
                    message=str(e),
                    status_code=500,
                    model=self.name,
                ) from e

            usage = self._get_usage(response)

            # Extract the response content
            output = response.get("output", {})
            message = output.get("message", {})
            content_blocks = message.get("content", [])

            if output_format is not None:
                # Look for tool use in the response
                for block in content_blocks:
                    if "toolUse" in block:
                        tool_input = block["toolUse"].get("input", {})
                        try:
                            result = output_format.model_validate(tool_input)
                            return ChatInvokeCompletion(
                                completion=result,
                                usage=usage,
                                stop_reason=response.get("stopReason"),
                            )
                        except Exception as e:
                            raise ModelProviderError(
                                message=f"Failed to validate structured output: {str(e)}",
                                status_code=500,
                                model=self.name,
                            ) from e

                raise ModelProviderError(
                    message="Model did not return structured output as expected",
                    status_code=500,
                    model=self.name,
                )
            else:
                # Extract text response
                text_content = ""
                for block in content_blocks:
                    if "text" in block:
                        text_content += block["text"]

                return ChatInvokeCompletion(
                    completion=text_content,
                    usage=usage,
                    stop_reason=response.get("stopReason"),
                )

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_message = e.response.get("Error", {}).get("Message", str(e))

            if error_code == "ThrottlingException":
                raise ModelRateLimitError(
                    message=f"Rate limit exceeded: {error_message}",
                    status_code=429,
                    model=self.name,
                ) from e

            raise ModelProviderError(
                message=f"AWS Bedrock error: {error_message}",
                status_code=500,
                model=self.name,
            ) from e
        except ModelProviderError:
            # Re-raise ModelProviderError as-is to preserve original status_code/message
            raise
        except Exception as e:
            raise ModelProviderError(
                message=f"Unexpected error: {str(e)}",
                status_code=500,
                model=self.name,
            ) from e


def patch_browser_use_screensaver() -> None:
    """Monkey-patch browser-use to use Arato logo in screensaver."""
    from browser_use.browser.watchdogs.aboutblank_watchdog import AboutBlankWatchdog

    cast(
        Any, AboutBlankWatchdog
    )._show_dvd_screensaver_loading_animation_cdp = _arato_screensaver


def patch_browser_use_debug_messages() -> None:
    """Monkey-patch browser-use to remove debug print statements."""
    try:
        from browser_use.actor import page as page_module

        # Save original evaluate method
        original_evaluate = page_module.Page.evaluate

        # Create wrapper that suppresses debug prints
        async def silent_evaluate(self: Any, *args: Any, **kwargs: Any) -> Any:
            """Wrapper for Page.evaluate that suppresses debug print statements."""
            import io
            from contextlib import redirect_stdout

            # Redirect stdout to suppress print statements
            with redirect_stdout(io.StringIO()):
                return await original_evaluate(self, *args, **kwargs)

        # Replace the method
        cast(Any, page_module.Page).evaluate = silent_evaluate

    except Exception:
        # If patching fails, silently continue (library might have changed)
        pass


def patch_browser_use_timeout() -> None:
    """Monkey-patch browser-use to increase browser startup timeout."""
    try:
        from browser_use.browser.watchdogs.local_browser_watchdog import (
            LocalBrowserWatchdog,
        )

        # Save original method
        original_wait_for_cdp_url = LocalBrowserWatchdog._wait_for_cdp_url

        @staticmethod
        async def _wait_for_cdp_url_patched(port: int, timeout: float = 30) -> str:
            # Increase timeout to 120 seconds to avoid startup timeouts
            # The default is 30s which is often too short for cold starts
            if timeout == 30:
                timeout = 120
            return await original_wait_for_cdp_url(port, timeout)

        cast(Any, LocalBrowserWatchdog)._wait_for_cdp_url = _wait_for_cdp_url_patched
    except Exception:
        pass


def patch_browser_use_profile_warning() -> None:
    """Patch BrowserProfile to avoid false positive warning about storage_state and user_data_dir conflict."""
    try:
        import browser_use.browser.profile as profile_module

        # Get the logger used in profile module
        logger = profile_module.logger

        # Store original warning method
        original_warning = logger.warning

        def patched_warning(msg: object, *args: Any, **kwargs: Any) -> None:
            # Check if this is the specific warning we want to suppress
            msg_str = str(msg)
            if (
                "BrowserSession(...) was passed both storage_state AND user_data_dir"
                in msg_str
            ):
                # Suppress this warning as it's a known false positive on macOS/Linux
                # where temp dirs don't always contain 'tmp' in the path
                return

            # Pass through all other warnings
            original_warning(msg, *args, **kwargs)

        # Apply the patch
        cast(Any, logger).warning = patched_warning
    except Exception:
        pass


def patch_browser_use_dom_timeout() -> None:
    """Monkey-patch browser-use to increase DOM watchdog timeout."""
    try:
        # Increase default timeout from 30s to 120s
        # This is needed for parallel execution where DOM processing can be slow
        field_info = BrowserStateRequestEvent.model_fields.get("event_timeout")
        if field_info:
            field_info.default_factory = None
            field_info.default = 120.0

            # Rebuild the model to apply changes
            BrowserStateRequestEvent.model_rebuild(force=True)
    except Exception:
        pass


def patch_websocket_keepalive_timeout() -> None:
    """Monkey-patch cdp_use CDPClient to increase WebSocket keepalive timeout parameters and add retry logic."""
    try:
        import asyncio
        import json

        import websockets
        from cdp_use.client import CDPClient

        async def patched_start(self: Any) -> None:
            """Start the WebSocket connection with increased keepalive timeouts"""
            if self.ws is not None:
                raise RuntimeError("Client is already started")

            logger = getattr(
                self, "_get_logger", lambda: __import__("logging").getLogger(__name__)
            )()
            logger.info(
                f"Connecting to {self.url} (max frame size: {self.max_ws_frame_size / 1024 / 1024:.0f}MB)"
            )

            # Configure WebSocket connection with significantly increased timeout parameters
            # These values are tuned for complex SPAs like KAYAK that can cause long pauses
            connect_kwargs: dict[str, Any] = {
                "max_size": self.max_ws_frame_size,
                "ping_interval": 20,  # Send ping every 20 seconds
                "ping_timeout": 120,  # Wait up to 120 seconds for pong
                "open_timeout": 60,  # Increase connection timeout
                "close_timeout": 60,  # Increase close timeout
            }
            if self.additional_headers:
                connect_kwargs["additional_headers"] = self.additional_headers

            self.ws = await websockets.connect(self.url, **connect_kwargs)
            self._message_handler_task = asyncio.create_task(self._handle_messages())

        async def _reconnect_ws(self: Any) -> bool:
            """Attempt to reconnect the WebSocket connection.

            Returns True if reconnection was successful, False otherwise.
            """
            logger = __import__("logging").getLogger(__name__)
            try:
                logger.warning(
                    "🔄 CDP WebSocket connection lost, attempting reconnect..."
                )

                # Close existing connection if any
                if self.ws:
                    try:
                        await self.ws.close()
                    except Exception:
                        pass  # Ignore close errors

                # Cancel existing message handler
                if (
                    hasattr(self, "_message_handler_task")
                    and self._message_handler_task
                ):
                    self._message_handler_task.cancel()
                    try:
                        await self._message_handler_task
                    except asyncio.CancelledError:
                        pass

                # Reconnect with same parameters
                connect_kwargs: dict[str, Any] = {
                    "max_size": self.max_ws_frame_size,
                    "ping_interval": 20,
                    "ping_timeout": 120,
                    "open_timeout": 60,
                    "close_timeout": 60,
                }
                if self.additional_headers:
                    connect_kwargs["additional_headers"] = self.additional_headers

                self.ws = await websockets.connect(self.url, **connect_kwargs)
                self._message_handler_task = asyncio.create_task(
                    self._handle_messages()
                )

                logger.info("✅ CDP WebSocket reconnected successfully")
                return True

            except Exception as e:
                logger.error(f"❌ CDP WebSocket reconnection failed: {e}")
                return False

        def _is_ws_closed(ws: Any) -> bool:
            """Check if a WebSocket connection is closed, handling different websocket types.

            Supports both:
            - websockets library: uses .state == State.CLOSED
            - Legacy/other implementations: may use .closed attribute
            """
            from websockets import State

            # Try the modern websockets library approach first (state attribute)
            if hasattr(ws, "state"):
                return ws.state in (State.CLOSED, State.CLOSING)

            # Fall back to .closed for legacy/other implementations
            if hasattr(ws, "closed"):
                return ws.closed

            # If we can't determine, assume it's not closed
            return False

        async def patched_send_raw_with_retry(
            self: Any,
            method: str,
            params: Any = None,
            session_id: str | None = None,
            max_retries: int = 3,
            retry_delay: float = 1.0,
        ) -> dict[str, Any]:
            """Send CDP command with automatic retry on connection errors.

            This wrapper catches transient websocket failures and retries the operation,
            which helps with the "no close frame received or sent" errors on complex SPAs.

            Will retry on transient ConnectionClosedError, but not when the WebSocket
            is permanently closed. Will attempt to reconnect if the connection is lost.
            """
            last_error: Exception | None = None
            reconnect_attempted = False

            for attempt in range(max_retries):
                try:
                    if not self.ws:
                        raise RuntimeError(
                            "Client is not started. Call start() first or use as async context manager."
                        )

                    # Check if WebSocket is closed before attempting to send
                    # If closed and we haven't tried reconnecting yet, attempt reconnection
                    if _is_ws_closed(self.ws):
                        if not reconnect_attempted:
                            reconnect_attempted = True
                            if await _reconnect_ws(self):
                                # Reconnection successful, continue with send
                                pass
                            else:
                                # Reconnection failed, raise error
                                raise websockets.exceptions.ConnectionClosedError(
                                    None, None
                                )
                        else:
                            # Already tried reconnecting, give up
                            raise websockets.exceptions.ConnectionClosedError(
                                None, None
                            )

                    self.msg_id += 1
                    msg: dict[str, Any] = {
                        "id": int(self.msg_id),
                        "method": method,
                        "params": params or {},
                    }

                    if session_id:
                        msg["sessionId"] = session_id

                    # Create a future for this request
                    future: asyncio.Future[dict[str, Any]] = asyncio.Future()
                    self.pending_requests[self.msg_id] = future

                    await self.ws.send(json.dumps(msg))

                    # Wait for the response
                    return await future

                except websockets.exceptions.ConnectionClosed as e:
                    last_error = e
                    logger = __import__("logging").getLogger(__name__)

                    # Check if the connection is permanently closed
                    if self.ws and _is_ws_closed(self.ws):
                        # Try reconnection if we haven't already
                        if not reconnect_attempted:
                            reconnect_attempted = True
                            if await _reconnect_ws(self):
                                # Reconnection successful, retry the operation
                                logger.info(f"Retrying {method} after reconnection...")
                                continue
                        # Reconnection failed or already attempted, propagate error
                        raise

                    # Transient connection issue - retry if we have attempts left
                    if attempt < max_retries - 1:
                        logger.warning(
                            f"CDP connection closed during {method}, retrying ({attempt + 1}/{max_retries}): {e}"
                        )
                        await asyncio.sleep(
                            retry_delay * (attempt + 1)
                        )  # Exponential backoff
                    else:
                        raise

                except asyncio.CancelledError:
                    # Don't retry on cancellation
                    raise

                except Exception as e:
                    last_error = e
                    logger = __import__("logging").getLogger(__name__)

                    # Check for fatal CDP errors that won't recover with retries
                    error_str = str(e)
                    if (
                        "'code': -32001" in error_str
                        or "Session with given id not found" in error_str
                        or "Frame not found" in error_str
                        or "Frame not found for the given storage id" in error_str
                    ):
                        # Session/Frame is gone - fail fast, don't waste time retrying
                        # Reduce log level for frame not found as it happens frequently during navigation/closing
                        if "Frame not found" in error_str:
                            logger.info(
                                f"CDP frame lost during {method}, not retrying: {e}"
                            )
                        else:
                            logger.warning(
                                f"CDP session lost during {method}, not retrying (session gone): {e}"
                            )
                        raise

                    if attempt < max_retries - 1:
                        # Use debug level for transient CDP errors to reduce log noise
                        # These are common and usually resolve on retry
                        logger.debug(
                            f"CDP error during {method}, retrying ({attempt + 1}/{max_retries}): {e}"
                        )
                        await asyncio.sleep(retry_delay * (attempt + 1))
                    else:
                        raise

            # Should not reach here, but raise last error if we do
            if last_error:
                raise last_error
            raise RuntimeError(f"CDP send_raw failed after {max_retries} retries")

        # Apply the patches (type: ignore for monkey patching)
        CDPClient.start = patched_start  # type: ignore[assignment]
        CDPClient.send_raw = patched_send_raw_with_retry  # type: ignore[assignment]
    except Exception:
        # Ignore errors - this is a monkey patch that might not work in all versions
        pass


def patch_browser_use_dom_warning() -> None:
    """Patch BrowserSession logger to suppress DOM build failure warnings and errors.

    These messages are noisy and not actionable - the system falls back to minimal state anyway.
    """
    try:
        import logging
        from typing import Any

        # Patterns to suppress (these are common, transient, and not actionable)
        SUPPRESS_PATTERNS = [
            "DOM build failed: CDP requests failed or timed out: ax_tree",
            "Failed to build DOM tree without highlights: CDP requests failed or timed out: ax_tree",
            "Exception in background task [build_dom_tree]: TimeoutError: CDP requests failed or timed out: ax_tree",
            "CDP request ax_tree failed with exception",
            "Frame with the given frameId is not found",
        ]

        def should_suppress(msg: str) -> bool:
            return any(pattern in msg for pattern in SUPPRESS_PATTERNS)

        # Patch the logger named 'BrowserSession' as seen in logs
        logger = logging.getLogger("BrowserSession")

        # Check if already patched to avoid recursion
        if not getattr(logger, "_is_patched_arato", False):
            original_warning = logger.warning
            original_error = logger.error

            def patched_warning(msg: object, *args: Any, **kwargs: Any) -> None:
                if should_suppress(str(msg)):
                    return
                original_warning(msg, *args, **kwargs)

            def patched_error(msg: object, *args: Any, **kwargs: Any) -> None:
                if should_suppress(str(msg)):
                    return
                original_error(msg, *args, **kwargs)

            logger.warning = patched_warning  # type: ignore[assignment]
            logger.error = patched_error  # type: ignore[assignment]
            logger._is_patched_arato = True  # type: ignore[attr-defined]

    except Exception:
        pass
