"""Lightweight CloudWatch Logs handler for Python's logging module.

Used in AWS Bedrock AgentCore MicroVMs where OTEL has been stripped,
so stdout does not automatically route to CloudWatch.

Usage:
    handler = CloudWatchHandler(log_group="/aws/bedrock-agentcore/runtimes/my-agent")
    logging.getLogger().addHandler(handler)
"""

import atexit
import logging
import sys
import threading
import time
import uuid
from collections import deque

import boto3
from botocore.exceptions import ClientError

# Flush thresholds
_BATCH_SIZE = 50  # max events per PutLogEvents call
_FLUSH_INTERVAL = 5  # seconds between automatic flushes

# Max consecutive flush failures before we start dropping events to avoid
# unbounded memory growth (100 batches * 5s interval = ~8 min of retries).
_MAX_CONSECUTIVE_FAILURES = 100


def _stderr(msg: str) -> None:
    """Write a diagnostic line to stderr (visible in MicroVM journal / local terminal).

    We intentionally avoid using the ``logging`` module here to prevent
    infinite recursion when the CloudWatch handler itself encounters errors.
    """
    try:
        print(f"[CloudWatchHandler] {msg}", file=sys.stderr, flush=True)
    except Exception:
        pass


class CloudWatchHandler(logging.Handler):
    """Non-blocking logging handler that batches and sends to CloudWatch Logs.

    Tracks the *sequenceToken* returned by each successful ``PutLogEvents``
    call and passes it on subsequent calls.  Many CloudWatch environments
    (including AgentCore MicroVMs) still require the token even though the
    API docs call it "optional" in newer SDK versions.  Without tracking it,
    only the very first ``put_log_events`` succeeds and all later calls fail
    with ``InvalidSequenceTokenException`` -- which was previously swallowed
    by a bare ``except``.
    """

    def __init__(
        self,
        log_group: str,
        log_stream: str | None = None,
        region: str | None = None,
    ):
        super().__init__()
        self.log_group = log_group
        self.log_stream = (
            log_stream or f"{time.strftime('%Y/%m/%d')}/{uuid.uuid4().hex[:12]}"
        )

        self._client = (
            boto3.client("logs", region_name=region) if region else boto3.client("logs")
        )
        self._queue: deque[dict] = deque()
        self._lock = threading.Lock()
        self._sequence_token: str | None = None  # tracked across put_log_events calls
        self._consecutive_failures = 0
        self._shutdown = False

        # Create log stream (best-effort)
        self._ensure_stream()

        # Background flush thread
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="cw-log-flush"
        )
        self._thread.start()
        atexit.register(self.flush)

    # ------------------------------------------------------------------
    # Stream management
    # ------------------------------------------------------------------

    def _ensure_stream(self) -> None:
        """Create the log stream, ignoring if it already exists."""
        try:
            self._client.create_log_stream(
                logGroupName=self.log_group,
                logStreamName=self.log_stream,
            )
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code == "ResourceAlreadyExistsException":
                # Stream exists -- fetch its current sequence token so we can
                # continue appending to it.
                self._refresh_sequence_token()
            else:
                _stderr(f"create_log_stream failed ({code}): {e}")

    def _refresh_sequence_token(self) -> None:
        """Fetch the current sequence token from an existing log stream."""
        try:
            resp = self._client.describe_log_streams(
                logGroupName=self.log_group,
                logStreamNamePrefix=self.log_stream,
                limit=1,
            )
            streams = resp.get("logStreams", [])
            if streams:
                self._sequence_token = streams[0].get("uploadSequenceToken")
        except Exception as exc:
            _stderr(f"describe_log_streams failed: {exc}")

    # ------------------------------------------------------------------
    # emit / flush
    # ------------------------------------------------------------------

    def emit(self, record: logging.LogRecord) -> None:
        """Queue a log record (non-blocking)."""
        if self._shutdown:
            return
        try:
            msg = self.format(record)
            event = {
                "timestamp": int(record.created * 1000),
                "message": msg,
            }
            with self._lock:
                self._queue.append(event)
        except Exception:
            self.handleError(record)

    def flush(self) -> None:
        """Send all queued events to CloudWatch immediately."""
        with self._lock:
            events = list(self._queue)
            self._queue.clear()
        if not events:
            return

        # CloudWatch requires chronological order
        events.sort(key=lambda e: e["timestamp"])

        # PutLogEvents accepts max 10,000 events / 1MB -- we chunk by _BATCH_SIZE
        for i in range(0, len(events), _BATCH_SIZE):
            batch = events[i : i + _BATCH_SIZE]
            self._put_batch(batch)

    def _put_batch(self, batch: list[dict], *, _retry: bool = True) -> None:
        """Send a single batch, handling sequence-token errors with one retry."""
        try:
            kwargs: dict = {
                "logGroupName": self.log_group,
                "logStreamName": self.log_stream,
                "logEvents": batch,
            }
            if self._sequence_token is not None:
                kwargs["sequenceToken"] = self._sequence_token

            resp = self._client.put_log_events(**kwargs)

            # Capture the token for the next call.
            self._sequence_token = resp.get("nextSequenceToken")
            self._consecutive_failures = 0

        except ClientError as exc:
            code = exc.response["Error"]["Code"]

            # InvalidSequenceTokenException / DataAlreadyAcceptedException
            # carry the expected token in the error message.  Extract it and
            # retry exactly once.
            if code in (
                "InvalidSequenceTokenException",
                "DataAlreadyAcceptedException",
            ):
                expected = exc.response["Error"].get("expectedSequenceToken")
                if expected is None:
                    # Older SDKs embed it in the message: "... expected sequenceToken is: <token>"
                    msg = exc.response["Error"].get("Message", "")
                    parts = msg.rsplit(":", 1)
                    if len(parts) == 2:
                        expected = parts[1].strip()
                        if expected == "null":
                            expected = None

                self._sequence_token = expected
                if _retry:
                    _stderr(
                        f"Sequence token mismatch ({code}), retrying with "
                        f"token={'<none>' if expected is None else expected[:12] + '...'}"
                    )
                    self._put_batch(batch, _retry=False)
                    return
                else:
                    _stderr(f"Retry also failed with {code}")

            else:
                self._consecutive_failures += 1
                _stderr(
                    f"put_log_events failed ({code}): {exc} "
                    f"[failures={self._consecutive_failures}]"
                )

                # Safety valve: if CloudWatch is unreachable for a long time,
                # stop accumulating events to prevent OOM.
                if self._consecutive_failures >= _MAX_CONSECUTIVE_FAILURES:
                    _stderr(
                        f"Reached {_MAX_CONSECUTIVE_FAILURES} consecutive failures, "
                        "dropping batch to prevent OOM"
                    )

        except Exception as exc:
            self._consecutive_failures += 1
            _stderr(
                f"put_log_events unexpected error: {exc} "
                f"[failures={self._consecutive_failures}]"
            )

    # ------------------------------------------------------------------
    # Background thread / lifecycle
    # ------------------------------------------------------------------

    def _run(self) -> None:
        """Background loop that flushes every _FLUSH_INTERVAL seconds."""
        while not self._shutdown:
            time.sleep(_FLUSH_INTERVAL)
            try:
                self.flush()
            except Exception as exc:
                _stderr(f"flush loop error: {exc}")

    def close(self) -> None:
        """Flush remaining events and stop the background thread."""
        self._shutdown = True
        self.flush()
        super().close()
