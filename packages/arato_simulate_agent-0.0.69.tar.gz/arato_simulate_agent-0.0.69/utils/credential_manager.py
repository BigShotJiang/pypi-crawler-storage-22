"""
Credential Manager: Handles credential expiration detection and refresh for long-running tests.
"""

import asyncio
import logging
import subprocess
from pathlib import Path

from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request

logger = logging.getLogger(__name__)


class CredentialExpiredError(Exception):
    """Raised when credentials have expired and need to be refreshed."""

    pass


class CredentialManager:
    """Manages GCP credentials and handles expiration/refresh during long runs."""

    def __init__(self, pause_file: Path | None = None):
        """
        Initialize credential manager.

        Args:
            pause_file: Path to file that will be created when run is paused
        """
        self.pause_file = pause_file or Path(".arato_paused")
        self._credentials = None
        self._project = None
        self._last_refresh_check = 0
        self._refresh_lock = asyncio.Lock()

    async def validate_and_refresh_credentials(self, force: bool = False) -> bool:
        """
        Validate GCP credentials and refresh if needed.

        Args:
            force: If True, force refresh even if credentials appear valid

        Returns:
            True if credentials are valid, False if refresh is needed

        Raises:
            CredentialExpiredError: If credentials are expired and cannot be refreshed
        """
        async with self._refresh_lock:
            try:
                import google.auth

                # Get credentials
                if not self._credentials or force:
                    credentials, project = google.auth.default()
                    self._project = project

                    # Apply scopes for Workload Identity Federation
                    if hasattr(credentials, "with_scopes"):
                        credentials = credentials.with_scopes(
                            ["https://www.googleapis.com/auth/cloud-platform"]
                        )
                    self._credentials = credentials

                # Check if credentials need refresh
                if self._credentials and not self._credentials.valid:
                    logger.info("🔄 Refreshing GCP credentials...")
                    try:
                        request = Request()
                        # Run refresh in thread pool to avoid blocking
                        await asyncio.to_thread(self._credentials.refresh, request)
                        logger.info("✓ GCP credentials refreshed successfully")
                        return True
                    except RefreshError as e:
                        logger.error(f"❌ GCP credentials refresh failed: {e}")
                        raise CredentialExpiredError(
                            "GCP credentials expired and need reauthentication"
                        ) from e

                return True

            except Exception as e:
                logger.error(f"Error validating credentials: {e}")
                return False

    def is_paused(self) -> bool:
        """Check if run is currently paused."""
        return self.pause_file.exists()

    def pause_run(self) -> None:
        """Pause the run by creating pause file."""
        self.pause_file.write_text("PAUSED")
        logger.info(f"⏸️  Run paused. File created: {self.pause_file}")

    def resume_run(self) -> None:
        """Resume the run by removing pause file."""
        if self.pause_file.exists():
            self.pause_file.unlink()
            logger.info("▶️  Run resumed")

    async def wait_if_paused(self, check_interval: float = 5.0) -> None:
        """
        Wait if run is paused, checking periodically for resume.

        Args:
            check_interval: How often to check for resume (seconds)
        """
        if not self.is_paused():
            return

        logger.warning(
            f"⏸️  Run is PAUSED. Waiting for resume (checking every {check_interval}s)..."
        )
        logger.warning("")
        logger.warning("    To resume:")
        logger.warning("    1. Open a NEW terminal (this one is blocked)")
        logger.warning("    2. Run: gcloud auth application-default login")
        logger.warning(f"    3. Run: rm {self.pause_file}")
        logger.warning("")
        logger.warning("    The run will automatically continue after step 3.")

        while self.is_paused():
            await asyncio.sleep(check_interval)

        logger.info("▶️  Run resumed, continuing...")

        # Validate credentials after resume
        try:
            await self.validate_and_refresh_credentials(force=True)
        except CredentialExpiredError:
            logger.error("❌ Credentials still expired after resume.")
            logger.error(
                "   Please run 'gcloud auth application-default login' in another terminal,"
            )
            logger.error("   then remove the pause file again.")
            self.pause_run()  # Pause again
            await self.wait_if_paused(check_interval)

    @staticmethod
    def trigger_credential_refresh() -> bool:
        """
        Trigger interactive credential refresh using gcloud CLI.

        Returns:
            True if refresh succeeded, False otherwise
        """
        try:
            logger.info("🔐 Opening browser for credential refresh...")
            logger.info("    Running: gcloud auth application-default login")

            result = subprocess.run(
                ["gcloud", "auth", "application-default", "login"],
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )

            if result.returncode == 0:
                logger.info("✓ Credentials refreshed successfully")
                return True
            else:
                logger.error(f"❌ Credential refresh failed: {result.stderr}")
                return False

        except subprocess.TimeoutExpired:
            logger.error("❌ Credential refresh timed out (5 minutes)")
            return False
        except FileNotFoundError:
            logger.error(
                "❌ gcloud CLI not found. Please install: https://cloud.google.com/sdk/docs/install"
            )
            return False
        except Exception as e:
            logger.error(f"❌ Unexpected error during credential refresh: {e}")
            return False


# Global credential manager instance
_credential_manager: CredentialManager | None = None


def get_credential_manager(pause_file: Path | None = None) -> CredentialManager:
    """Get or create global credential manager instance."""
    global _credential_manager
    if _credential_manager is None:
        _credential_manager = CredentialManager(pause_file)
    return _credential_manager


async def check_credentials_periodically(
    interval_minutes: int = 30, credential_manager: CredentialManager | None = None
) -> None:
    """
    Background task to periodically check and refresh credentials.

    Args:
        interval_minutes: How often to check credentials (minutes)
        credential_manager: Optional credential manager instance
    """
    manager = credential_manager or get_credential_manager()

    while True:
        try:
            await asyncio.sleep(interval_minutes * 60)

            # Check if paused
            await manager.wait_if_paused()

            # Validate and refresh if needed
            try:
                await manager.validate_and_refresh_credentials()
            except CredentialExpiredError:
                logger.error(
                    f"""
❌ GCP credentials expired!

The run has been PAUSED automatically. To resume:

1. Open a NEW terminal (this one is blocked by the paused run)

2. Refresh your credentials:
   gcloud auth application-default login

3. Resume the run:
   rm {manager.pause_file}

The system will automatically continue once you remove the pause file.
"""
                )
                manager.pause_run()
                # Wait for manual resume
                await manager.wait_if_paused()

        except Exception as e:
            logger.error(f"Error in credential check task: {e}")
            await asyncio.sleep(60)  # Wait a bit before retrying
