"""
Utility functions for detecting runtime platform.
"""

import os


def is_aws_configuration() -> bool:
    """
    Detect if code is running in AWS AgentCore environment.

    Checks for environment variables that indicate AWS AgentCore or containerized
    AWS execution context.

    Returns:
      True if running on AgentCore, False otherwise
    """
    docker_container = os.getenv("DOCKER_CONTAINER")
    aws_execution_env = os.getenv("AWS_EXECUTION_ENV")
    return bool(docker_container or aws_execution_env)
