"""Common utility functions for file and directory operations."""

import base64
import json
import logging
import os
import shutil
from pathlib import Path
from typing import Any

from constants import (
    APP_CONTEXT_FILENAME,
    DISCOVERY_VIDEO_FILENAME,
    RUN_VIDEO_FILENAME,
    VIDEO_SUBDIR_DISCOVERY,
    VIDEO_SUBDIR_RUN,
)

logger = logging.getLogger(__name__)


def save_json_file(data: dict[str, Any], file_path: Path) -> None:
    """Save dictionary data to a JSON file with proper formatting."""
    with open(file_path, "w") as f:
        json.dump(data, f, indent=2)
    logger.info(f"Saved JSON to: {file_path}")


def save_text_file(
    content: str, file_path: Path | str, encoding: str = "utf-8"
) -> None:
    """Save text content to a file."""

    # Ensure file_path is a Path object
    if not isinstance(file_path, Path):
        file_path = Path(file_path)

    # Resolve to absolute path (strict=False allows non-existent paths)
    file_path = file_path.resolve(strict=False)

    # Create parent directory using os.makedirs for better compatibility
    os.makedirs(file_path.parent, exist_ok=True)

    # Write the file using open() instead of Path.write_text()
    # This avoids macOS temp directory issues with Path operations
    with open(file_path, "w", encoding=encoding) as f:
        f.write(content)

    logger.info(f"Saved text file to: {file_path}")


def move_video_file(
    session_dir: Path, video_subdir_name: str, target_filename: str
) -> bool:
    """
    Move video file from a subdirectory to the session root.

    Args:
        session_dir: Root session directory
        video_subdir_name: Name of subdirectory containing videos
        target_filename: Destination filename in session root

    Returns:
        True if video was moved successfully, False otherwise
    """
    video_dir = session_dir / video_subdir_name
    if not video_dir.exists():
        return False

    video_files = list(video_dir.glob("*.mp4"))
    if not video_files:
        logger.warning(f"No video files found in {video_dir}")
        return False

    source_video = video_files[0]
    target_video = session_dir / target_filename
    shutil.move(str(source_video), str(target_video))
    logger.info(f"✓ Moved video to: {target_video}")

    try:
        video_dir.rmdir()
    except OSError:
        pass

    return True


def move_discovery_video(session_dir: Path) -> bool:
    """Move discovery video to session root."""
    return move_video_file(
        session_dir, VIDEO_SUBDIR_DISCOVERY, DISCOVERY_VIDEO_FILENAME
    )


def move_run_video(session_dir: Path) -> bool:
    """Move run video to session root."""
    return move_video_file(session_dir, VIDEO_SUBDIR_RUN, RUN_VIDEO_FILENAME)


def ensure_directory(directory: Path) -> Path:
    """Ensure directory exists, create if needed."""
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def copy_discovery_artifacts(domain_dir: Path, session_dir: Path) -> dict[str, bool]:
    """
    Copy discovery artifacts from domain cache to session folder.

    This ensures the session folder has all discovery artifacts for consistent access,
    while keeping domain_dir as a cache for future runs.

    Args:
        domain_dir: Domain-specific cache directory (e.g., domain_settings/example.com/)
        session_dir: Session-specific output directory (e.g., sessions/conversation_123/)

    Returns:
        Dictionary indicating which artifacts were copied successfully
    """
    results = {
        "app_context": False,
        "discovery_video": False,
        "screenshots": False,
    }

    # Create domain_settings subfolder structure in session dir
    # Extract domain name from domain_dir path (e.g., "example.com" from "/tmp/domain_settings/example.com/")
    domain_name = domain_dir.name
    domain_session_dir = session_dir / "domain_settings" / domain_name
    domain_session_dir.mkdir(parents=True, exist_ok=True)

    # Copy app_context.json
    app_context_src = domain_dir / APP_CONTEXT_FILENAME
    if app_context_src.exists():
        app_context_dst = domain_session_dir / APP_CONTEXT_FILENAME
        shutil.copyfile(str(app_context_src), str(app_context_dst))
        logger.info(f"✓ Copied {APP_CONTEXT_FILENAME} to session folder")
        results["app_context"] = True

    # Copy discovery.mp4
    discovery_video_src = domain_dir / DISCOVERY_VIDEO_FILENAME
    if discovery_video_src.exists():
        discovery_video_dst = domain_session_dir / DISCOVERY_VIDEO_FILENAME
        shutil.copyfile(str(discovery_video_src), str(discovery_video_dst))
        logger.info(f"✓ Copied {DISCOVERY_VIDEO_FILENAME} to session folder")
        results["discovery_video"] = True

    # Copy screenshots directory
    screenshots_src = domain_dir / "screenshots"
    if screenshots_src.exists() and screenshots_src.is_dir():
        screenshots_dst = domain_session_dir / "screenshots"
        # Explicitly ensure parent directory exists (GitHub CI needs this)
        screenshots_dst.parent.mkdir(parents=True, exist_ok=True)
        if screenshots_dst.exists():
            shutil.rmtree(screenshots_dst)

        try:
            # Use Path objects directly instead of converting to strings
            shutil.copytree(screenshots_src, screenshots_dst, dirs_exist_ok=False)
            screenshot_count = len(list(screenshots_dst.glob("*.png")))
            logger.info(
                f"✓ Copied screenshots directory to session folder ({screenshot_count} files)"
            )
            results["screenshots"] = True
        except shutil.Error as e:
            logger.warning(f"Failed to copy some screenshots: {e}")
            # Even if some failed, mark as True if at least some were copied or just log warning
            # Depending on strictness. Usually copytree raises on first error or collects errors.
            # If it copied *something*, maybe we can still say screenshots=True?
            # But safe default is to just log it. The user just asked to 'Catch shutil.Error'
            results["screenshots"] = False
        except Exception as e:
            logger.warning(f"Unexpected error copying screenshots: {e}")
            results["screenshots"] = False

    return results


def get_local_logo_data_uri(session_dir: Path | str) -> str | None:
    """
    Check for logo.[webp|jpg|png|gif] in the session directory.
    If found, return as base64 data URI.

    Args:
        session_dir: Path to the session directory

    Returns:
        Base64 data URI string or None if not found
    """
    session_path = Path(session_dir) if isinstance(session_dir, str) else session_dir
    # Priority order: svg, webp, png, jpg, gif
    extensions = ["svg", "webp", "png", "jpg", "jpeg", "gif"]

    for ext in extensions:
        # Check for both logo.ext and logo.EXT
        for filename in [f"logo.{ext}", f"logo.{ext.upper()}"]:
            logo_path = session_path / filename
            if logo_path.exists():
                try:
                    logger.info(f"Found local logo file: {logo_path}")
                    with open(logo_path, "rb") as f:
                        data = f.read()
                        encoded = base64.b64encode(data).decode("utf-8")

                        # Determine MIME type
                        mime_type = f"image/{ext}"
                        if ext == "jpg" or ext == "jpeg":
                            mime_type = "image/jpeg"
                        elif ext == "svg":
                            mime_type = "image/svg+xml"

                        return f"data:{mime_type};base64,{encoded}"
                except Exception as e:
                    logger.warning(f"Failed to read local logo file {logo_path}: {e}")

    return None
