"""Utility functions for Finding data model transformations and queries."""

from typing import Any

from constants import (
    DEFAULT_CONFIDENCE_HIGH,
    SCORE_LABEL_CRITICAL,
    SCORE_LABEL_GOOD,
    SCORE_LABEL_WARNING,
    SCORE_THRESHOLD_GOOD,
    SCORE_THRESHOLD_PASS,
)
from core.schemas import Finding


def score_to_label(score: float) -> str:
    """Convert a score (0-100) to its corresponding label.

    Score ranges (from constants.py):
    - 0-9: Critical (score < SCORE_THRESHOLD_PASS)
    - 10-74: Warning (SCORE_THRESHOLD_PASS <= score < SCORE_THRESHOLD_GOOD)
    - 75-100: Good (score >= SCORE_THRESHOLD_GOOD)

    Args:
        score: Quality score from 0-100

    Returns:
        Label string: 'Critical', 'Warning', or 'Good'
    """
    if score >= SCORE_THRESHOLD_GOOD:
        return SCORE_LABEL_GOOD
    elif score >= SCORE_THRESHOLD_PASS:
        return SCORE_LABEL_WARNING
    else:
        return SCORE_LABEL_CRITICAL


def finding_to_dict(finding: Finding) -> dict[str, Any]:
    """Convert Finding to dictionary matching summary.json structure.

    The output format is designed for report generation and JSON serialization.
    It includes the nested 'evidence' and 'evaluation_results' structure
    expected by the UI.

    Args:
        finding: Finding instance to convert

    Returns:
        Dictionary with nested structure for report generation
    """
    # Debug: Check ID before serialization

    # Use Finding.evidence dict if populated (conversation-level findings),
    # otherwise fall back to top-level fields (turn-level findings)
    if finding.evidence and (  # evidence created by validator
        finding.evidence.get("agent_input") or finding.evidence.get("chatbot_response")
    ):
        evidence_dict = {
            "turn_id": finding.evidence.get("turn_id"),
            "turn_number": finding.evidence.get("turn_number"),
            "agent_input": finding.evidence.get("agent_input", ""),
            "chatbot_response": finding.evidence.get("chatbot_response", ""),
        }
    else:
        # Fall back to top-level fields for backward compatibility
        evidence_dict = {
            "turn_id": finding.turn_id,
            "turn_number": finding.turn_number,
            "agent_input": finding.user_message or "",
            "chatbot_response": finding.bot_response or "",
        }

    result: dict[str, Any] = {
        "id": finding.id,
        "agent_id": finding.agent_id,
        "category": finding.category,
        "title": finding.title,
        "what_was_tested": finding.what_was_tested,
        "evidence": evidence_dict,
        "evaluation_results": {
            "score": finding.score,
            "confidence": finding.confidence,
            "explanation": finding.explanation,
        },
        "assessment": finding.assessment,
        "impact": finding.impact,
        "label": finding.label,
    }
    if finding.skill_name:
        result["skill_name"] = finding.skill_name
    if finding.screenshot_path:
        result["screenshot_path"] = finding.screenshot_path
    if finding.bounding_box:
        result["bounding_box"] = finding.bounding_box
    if finding.metadata:
        result["metadata"] = finding.metadata
    if finding.contributing_sources:
        result["contributing_sources"] = finding.contributing_sources
    return result


def finding_from_dict(data: dict[str, Any], source: str | None = None) -> Finding:
    """Create Finding from dictionary (reverse of finding_to_dict).

    Handles both the nested structure (from summary.json) and flat structure.

    Args:
        data: Dictionary containing finding data
        source: Optional source identifier (e.g., "transcript") to mark origin

    Returns:
        Finding instance
    """
    # Handle nested evidence structure
    evidence = data.get("evidence", {})
    turn_id = evidence.get("turn_id") or data.get("turn_id")
    turn_number = evidence.get("turn_number") or data.get("turn_number")
    user_message = evidence.get("agent_input") or data.get("user_message")
    bot_response = evidence.get("chatbot_response") or data.get("bot_response")

    # Handle nested evaluation_results structure
    eval_results = data.get("evaluation_results", {})
    score = eval_results.get("score") or data.get("score", 50)
    confidence = eval_results.get("confidence") or data.get(
        "confidence", DEFAULT_CONFIDENCE_HIGH
    )
    explanation = (
        eval_results.get("explanation")
        or data.get("explanation")
        or data.get("assessment", "")
    )

    # Handle metadata and source marking
    metadata = data.get("metadata", {}).copy()
    if source:
        metadata["_source"] = source

    return Finding(
        id=data.get("id"),
        agent_id=data.get("agent_id", "unknown"),
        category=data["category"],
        title=data["title"],
        what_was_tested=data.get("what_was_tested", ""),
        score=score,
        confidence=confidence,
        explanation=explanation,
        label=data.get("label", ""),
        turn_id=turn_id,
        turn_number=turn_number,
        user_message=user_message,
        bot_response=bot_response,
        assessment=data.get("assessment", ""),
        impact=data.get("impact", ""),
        skill_name=data.get("skill_name"),
        screenshot_path=data.get("screenshot_path"),
        bounding_box=data.get("bounding_box"),
        metadata=metadata,
        contributing_sources=data.get("contributing_sources", []),
    )


def is_critical_finding(finding: Finding) -> bool:
    """Check if this is a critical finding.

    Args:
        finding: Finding instance to check

    Returns:
        True if finding is critical
    """
    return finding.label == SCORE_LABEL_CRITICAL


def is_warning_finding(finding: Finding) -> bool:
    """Check if this is a warning finding.

    Args:
        finding: Finding instance to check

    Returns:
        True if finding is a warning
    """
    return finding.label == SCORE_LABEL_WARNING


def is_good_finding(finding: Finding) -> bool:
    """Check if this is a good/positive finding.

    Args:
        finding: Finding instance to check

    Returns:
        True if finding is good
    """
    return finding.label == SCORE_LABEL_GOOD
