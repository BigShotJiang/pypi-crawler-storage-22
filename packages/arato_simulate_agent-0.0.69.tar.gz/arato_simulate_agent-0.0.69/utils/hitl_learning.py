"""Utilities for learning from HITL (Human-in-the-Loop) interventions.

This module provides functions to generate human-readable summaries of
interventions and detect patterns across multiple interventions.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


def generate_intervention_summary(
    intervention_type: str,
    reason: str,
    url_before: str | None = None,
    url_after: str | None = None,
    duration_seconds: float | None = None,
    outcome: str = "completed",
) -> str:
    """Generate a human-readable summary of a HITL intervention.

    This summary can be injected into the agent's context after an intervention
    to help it understand what happened and adapt its behavior accordingly.

    Args:
        intervention_type: Type of intervention (captcha, login, verification, etc.)
        reason: Why the intervention was needed
        url_before: URL before intervention (optional)
        url_after: URL after intervention (optional)
        duration_seconds: How long the intervention took (optional)
        outcome: Outcome of intervention (completed, timeout, error)

    Returns:
        Human-readable summary string

    Example:
        >>> summary = generate_intervention_summary(
        ...     intervention_type='captcha',
        ...     reason='CAPTCHA challenge detected',
        ...     url_before='https://example.com/login',
        ...     url_after='https://example.com/dashboard',
        ...     duration_seconds=45.3,
        ...     outcome='completed'
        ... )
        >>> print(summary)
        A human completed a CAPTCHA intervention. The page URL changed from
        https://example.com/login to https://example.com/dashboard.
        Duration: 45 seconds. The intervention was successful.
    """
    parts = []

    # Intervention type and outcome
    outcome_text = (
        "successfully completed"
        if outcome == "completed"
        else f"ended with outcome: {outcome}"
    )
    parts.append(f"A human {outcome_text} a {intervention_type.upper()} intervention.")

    # Reason for intervention
    if reason:
        parts.append(f"Reason: {reason}")

    # URL changes (indicates what happened)
    if url_before and url_after:
        if url_before == url_after:
            parts.append(f"The page URL remained: {url_after}")
        else:
            parts.append(
                f"The page URL changed from {url_before} to {url_after}, "
                "indicating the task was completed and the page navigated forward."
            )
    elif url_after:
        parts.append(f"Current page URL: {url_after}")

    # Duration
    if duration_seconds is not None:
        duration_formatted = (
            f"{int(duration_seconds)} seconds"
            if duration_seconds < 60
            else f"{int(duration_seconds / 60)} minutes {int(duration_seconds % 60)} seconds"
        )
        parts.append(f"Duration: {duration_formatted}")

    # Final status
    if outcome == "completed":
        parts.append("You can now continue with your task.")
    elif outcome == "timeout":
        parts.append(
            "The intervention timed out. You may need to try a different approach."
        )
    elif outcome == "error":
        parts.append(
            "An error occurred during intervention. Consider trying again or using an alternative method."
        )

    return " ".join(parts)


def analyze_intervention_patterns(
    interventions: list[dict[str, Any]],
) -> dict[str, Any]:
    """Analyze patterns across multiple interventions.

    This can help identify common blockers, estimate typical durations,
    and inform future agent behavior.

    Args:
        interventions: List of intervention dictionaries with keys:
            - intervention_type: str
            - reason: str
            - url_before: str (optional)
            - url_after: str (optional)
            - duration_seconds: float (optional)
            - outcome: str
            - timestamp: str

    Returns:
        Dictionary with pattern analysis including:
            - most_common_types: List of (type, count) tuples
            - avg_duration_by_type: Dict of type -> avg duration
            - success_rate: Overall success rate (0.0-1.0)
            - common_urls: URLs where interventions often occur

    Example:
        >>> interventions = [
        ...     {'intervention_type': 'captcha', 'outcome': 'completed', 'duration_seconds': 45},
        ...     {'intervention_type': 'captcha', 'outcome': 'completed', 'duration_seconds': 50},
        ...     {'intervention_type': 'login', 'outcome': 'completed', 'duration_seconds': 30}
        ... ]
        >>> patterns = analyze_intervention_patterns(interventions)
        >>> patterns['most_common_types']
        [('captcha', 2), ('login', 1)]
    """
    if not interventions:
        return {
            "most_common_types": [],
            "avg_duration_by_type": {},
            "success_rate": 0.0,
            "common_urls": [],
            "total_interventions": 0,
        }

    # Count by type
    type_counts: dict[str, int] = {}
    type_durations: dict[str, list[float]] = {}
    url_counts: dict[str, int] = {}
    successful_count = 0

    for intervention in interventions:
        # Type counts
        int_type = intervention.get("intervention_type", "unknown")
        type_counts[int_type] = type_counts.get(int_type, 0) + 1

        # Duration tracking
        duration = intervention.get("duration_seconds")
        if duration is not None:
            if int_type not in type_durations:
                type_durations[int_type] = []
            type_durations[int_type].append(duration)

        # URL tracking
        url_before = intervention.get("url_before")
        if url_before:
            url_counts[url_before] = url_counts.get(url_before, 0) + 1

        # Success tracking
        if intervention.get("outcome") == "completed":
            successful_count += 1

    # Sort and format results
    most_common_types = sorted(type_counts.items(), key=lambda x: x[1], reverse=True)

    avg_duration_by_type = {
        int_type: sum(durations) / len(durations)
        for int_type, durations in type_durations.items()
    }

    common_urls = sorted(url_counts.items(), key=lambda x: x[1], reverse=True)[:5]

    success_rate = successful_count / len(interventions) if interventions else 0.0

    return {
        "most_common_types": most_common_types,
        "avg_duration_by_type": avg_duration_by_type,
        "success_rate": success_rate,
        "common_urls": common_urls,
        "total_interventions": len(interventions),
    }


def format_pattern_insights(patterns: dict[str, Any]) -> str:
    """Format pattern analysis into human-readable insights.

    Args:
        patterns: Output from analyze_intervention_patterns()

    Returns:
        Formatted string with key insights

    Example:
        >>> patterns = {
        ...     'most_common_types': [('captcha', 3), ('login', 1)],
        ...     'avg_duration_by_type': {'captcha': 47.5, 'login': 30.0},
        ...     'success_rate': 0.75,
        ...     'total_interventions': 4
        ... }
        >>> print(format_pattern_insights(patterns))
        HITL Intervention Insights:
        - Total interventions: 4
        - Success rate: 75%
        - Most common: CAPTCHA (3 occurrences, avg 48s), LOGIN (1 occurrences, avg 30s)
    """
    if not patterns or patterns["total_interventions"] == 0:
        return "No intervention history available yet."

    lines = ["HITL Intervention Insights:"]
    lines.append(f"- Total interventions: {patterns['total_interventions']}")
    lines.append(f"- Success rate: {patterns['success_rate'] * 100:.0f}%")

    # Most common types with durations
    if patterns["most_common_types"]:
        type_strs = []
        for int_type, count in patterns["most_common_types"][:3]:
            avg_dur = patterns["avg_duration_by_type"].get(int_type)
            if avg_dur:
                type_strs.append(
                    f"{int_type.upper()} ({count} occurrences, avg {avg_dur:.0f}s)"
                )
            else:
                type_strs.append(f"{int_type.upper()} ({count} occurrences)")

        lines.append(f"- Most common: {', '.join(type_strs)}")

    # Common URLs
    if patterns["common_urls"]:
        urls = [f"{url} ({count}x)" for url, count in patterns["common_urls"][:3]]
        lines.append(f"- Common intervention URLs: {', '.join(urls)}")

    return "\n".join(lines)
