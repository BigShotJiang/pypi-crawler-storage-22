"""HITL (Human-in-the-Loop) utilities and state management.

This module provides platform-agnostic utilities for managing
human intervention requests during agent execution.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)


class HITLState(StrEnum):
    """States for human intervention requests."""

    WAITING = "waiting"  # Agent is waiting for human intervention
    COMPLETED = "completed"  # Human has completed the intervention
    TIMEOUT = "timeout"  # Intervention timed out
    ERROR = "error"  # Error occurred during intervention


class HITLInterventionType(StrEnum):
    """Types of human intervention that may be requested."""

    CAPTCHA = "captcha"  # CAPTCHA challenge
    LOGIN = "login"  # Login/authentication required
    VERIFICATION = "verification"  # Email/phone verification
    CONSENT = "consent"  # Cookie consent or terms acceptance
    CUSTOM = "custom"  # Custom intervention (use reason field)


@dataclass
class HITLInterventionRequest:
    """Request for human intervention.

    Attributes:
        intervention_id: Unique identifier for this intervention
        reason: Human-readable explanation of why intervention is needed
        intervention_type: Type of intervention requested
        requested_at: Timestamp when intervention was requested
        session_id: Browser session ID (platform-specific)
        metadata: Additional platform-specific metadata
    """

    intervention_id: str
    reason: str
    intervention_type: HITLInterventionType
    requested_at: datetime
    session_id: str | None = None
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "intervention_id": self.intervention_id,
            "reason": self.reason,
            "intervention_type": self.intervention_type.value,
            "requested_at": self.requested_at.isoformat(),
            "session_id": self.session_id,
            "metadata": self.metadata or {},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HITLInterventionRequest:
        """Create from dictionary."""
        return cls(
            intervention_id=data["intervention_id"],
            reason=data["reason"],
            intervention_type=HITLInterventionType(data["intervention_type"]),
            requested_at=datetime.fromisoformat(data["requested_at"]),
            session_id=data.get("session_id"),
            metadata=data.get("metadata"),
        )


@dataclass
class HITLInterventionResponse:
    """Response after human intervention completes.

    Attributes:
        intervention_id: Unique identifier matching the request
        state: Current state of the intervention
        completed_at: Timestamp when intervention was completed (if completed)
        error_message: Error message if state is ERROR
        metadata: Additional platform-specific metadata
    """

    intervention_id: str
    state: HITLState
    completed_at: datetime | None = None
    error_message: str | None = None
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "intervention_id": self.intervention_id,
            "state": self.state.value,
            "completed_at": self.completed_at.isoformat()
            if self.completed_at
            else None,
            "error_message": self.error_message,
            "metadata": self.metadata or {},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HITLInterventionResponse:
        """Create from dictionary."""
        return cls(
            intervention_id=data["intervention_id"],
            state=HITLState(data["state"]),
            completed_at=(
                datetime.fromisoformat(data["completed_at"])
                if data.get("completed_at")
                else None
            ),
            error_message=data.get("error_message"),
            metadata=data.get("metadata"),
        )


def create_intervention_request(
    intervention_id: str,
    reason: str,
    intervention_type: HITLInterventionType = HITLInterventionType.CUSTOM,
    session_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> HITLInterventionRequest:
    """Create a new intervention request.

    Args:
        intervention_id: Unique identifier for this intervention
        reason: Human-readable explanation
        intervention_type: Type of intervention
        session_id: Optional browser session ID
        metadata: Optional additional metadata

    Returns:
        HITLInterventionRequest instance
    """
    return HITLInterventionRequest(
        intervention_id=intervention_id,
        reason=reason,
        intervention_type=intervention_type,
        requested_at=datetime.now(UTC),
        session_id=session_id,
        metadata=metadata,
    )


def create_intervention_response(
    intervention_id: str,
    state: HITLState,
    error_message: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> HITLInterventionResponse:
    """Create an intervention response.

    Args:
        intervention_id: Unique identifier matching the request
        state: Current state of the intervention
        error_message: Optional error message if state is ERROR
        metadata: Optional additional metadata

    Returns:
        HITLInterventionResponse instance
    """
    return HITLInterventionResponse(
        intervention_id=intervention_id,
        state=state,
        completed_at=datetime.now(UTC) if state == HITLState.COMPLETED else None,
        error_message=error_message,
        metadata=metadata,
    )


def log_intervention_request(request: HITLInterventionRequest) -> None:
    """Log an intervention request for audit trail.

    Args:
        request: The intervention request to log
    """
    logger.info(
        "HITL Intervention Requested: id=%s, type=%s, reason=%s",
        request.intervention_id,
        request.intervention_type.value,
        request.reason,
    )


def log_intervention_response(response: HITLInterventionResponse) -> None:
    """Log an intervention response for audit trail.

    Args:
        response: The intervention response to log
    """
    logger.info(
        "HITL Intervention %s: id=%s, state=%s",
        "Completed" if response.state == HITLState.COMPLETED else "Updated",
        response.intervention_id,
        response.state.value,
    )
    if response.error_message:
        logger.error(
            "HITL Intervention Error: id=%s, error=%s",
            response.intervention_id,
            response.error_message,
        )


__all__ = [
    "HITLState",
    "HITLInterventionType",
    "HITLInterventionRequest",
    "HITLInterventionResponse",
    "create_intervention_request",
    "create_intervention_response",
    "log_intervention_request",
    "log_intervention_response",
]
