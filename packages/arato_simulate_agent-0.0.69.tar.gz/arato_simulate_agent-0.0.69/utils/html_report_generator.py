"""
HTML report generation utility.

This module generates interactive HTML reports from persona testing results
without relying on markdown parsing. It works directly with the structured
data collected during test execution.
"""

import base64
import json
import logging
import os
from typing import Any

from constants import (
    CATEGORY_ACCURACY,
    CATEGORY_FEATURE,
    CATEGORY_SECURITY,
    CATEGORY_UX,
    SCORE_COLOR_CRITICAL,
    SCORE_COLOR_GOOD,
    SCORE_COLOR_WARNING,
)
from utils.file_utils import get_local_logo_data_uri

logger = logging.getLogger(__name__)


def generate_html_report(
    report_data: dict[str, Any] | None = None,
    report_data_file: str | None = None,
    conversations_only: bool = False,
) -> str:
    """
    Generate an interactive HTML report from structured report data.

    Args:
        report_data: Pre-built report data dictionary (from report_data_generator)
        report_data_file: Path to report_data.json file to load
        conversations_only: If True, generate a simplified report showing only
            the header and conversations tab content (no tabs or other content)

    Returns:
        Complete HTML string with embedded React app

    Note:
        Either report_data or report_data_file must be provided.
        If both are provided, report_data takes precedence.
    """
    # Load report data from file if not provided directly
    if report_data is None:
        if report_data_file is None:
            raise ValueError("Either report_data or report_data_file must be provided")

        with open(report_data_file, encoding="utf-8") as f:
            report_data = json.load(f)

    # Check for local logo if report_data_file is provided
    # This check is also performed in report_data_generator.py, but repeats here
    # to support regeneration scenarios (regenerate_html.py) where a logo might
    # have been added manually after report generation
    if report_data_file:
        session_dir = os.path.dirname(report_data_file)
        local_logo = get_local_logo_data_uri(session_dir)
        if local_logo:
            if "metadata" not in report_data:
                report_data["metadata"] = {}
            report_data["metadata"]["favicon_url"] = local_logo
            logger.info(f"Using local logo from {session_dir}")

    # Generate HTML
    html = _generate_html_template(report_data, conversations_only=conversations_only)

    return html


def _format_timestamp(timestamp: str) -> str:
    """Format timestamp string to readable format.

    Args:
        timestamp: Timestamp in format YYYYMMDD_HHMMSS

    Returns:
        Formatted string like "12-08-2024 09:55 AM"
    """
    try:
        from datetime import datetime

        # Parse timestamp like "20251208_095555"
        dt = datetime.strptime(timestamp, "%Y%m%d_%H%M%S")
        # Format as "MM-dd-yyyy hh:mm AM/PM"
        return dt.strftime("%m-%d-%Y %I:%M %p")
    except Exception:
        # Fallback to original if parsing fails
        return timestamp


def _generate_html_template(
    data: dict[str, Any],
    conversations_only: bool = False,
) -> str:
    """Generate complete HTML with embedded data and React app.

    Args:
        data: Report data dictionary
        conversations_only: If True, show only header and conversations content
    """
    # Get metadata - title is now inside it
    metadata = data.get("metadata", {})
    title = metadata.get("title", "Conversational UI Testing Report")

    # Serialize data to JSON, handling special float values (NaN, Infinity)
    # Python's json.dumps doesn't allow NaN/Infinity by default (RFC compliant)
    # But JavaScript needs them as null for safety
    data_json = json.dumps(data, indent=2, allow_nan=False, default=str)

    # Sanitize JSON for embedding in HTML script tag
    # Prevent </script> injection attacks and syntax errors
    data_json = data_json.replace("</script>", "<\\/script>")

    # Load embedded logo SVG
    logo_path = os.path.join(os.path.dirname(__file__), "static", "logo.svg")
    with open(logo_path, encoding="utf-8") as f:
        logo_svg = f.read()

    # Create favicon data URI from SVG
    logo_svg_encoded = base64.b64encode(logo_svg.encode("utf-8")).decode("utf-8")
    favicon_data_uri = f"data:image/svg+xml;base64,{logo_svg_encoded}"

    # Use the same HTML template from generate_html_report.py
    # but with data injected directly rather than parsed from markdown
    html = rf"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>
  <link rel="icon" type="image/svg+xml" href="{favicon_data_uri}">

  <!-- External Dependencies -->
  <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
  <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/ag-grid-community@31.0.0/dist/ag-grid-community.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/marked@11.1.1/marked.min.js"></script>
  <link rel="stylesheet" href="https://unpkg.com/@phosphor-icons/web@2.0.3/src/regular/style.css">

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&display=swap');

    * {{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }}

    body {{
      font-family: 'Public Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #fefdfa;
      color: #4d4d42;
      line-height: 1.6;
    }}

    .container {{
      max-width: 1200px;
      margin: 0 auto;
      padding: 24px;
    }}

    /* Header */
    .header {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 24px 0;
      background: #f5f4f0;
      border-bottom: 1px solid #e5e5e0;
      margin-bottom: 24px;
    }}

    .header-container {{
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
    }}

    .header-left {{
      display: flex;
      align-items: center;
      gap: 16px;
    }}

    .logo {{
      height: 48px;
      min-width: 48px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #6366f1;
      font-size: 24px;
      font-weight: bold;
      overflow: hidden;
    }}

    .logo img {{
      height: 100%;
      width: auto;
      object-fit: contain;
    }}

    .logo i {{
      /* Only show icon if no image */
    }}

    .header-title {{
      display: flex;
      flex-direction: column;
    }}

    .header-title h1 {{
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 4px;
    }}

    .header-tags {{
      display: flex;
      gap: 8px;
      font-size: 12px;
    }}

    .tag {{
      background: #f8f6f1;
      padding: 2px 8px;
      border-radius: 4px;
      font-weight: 500;
    }}

    .header-subtitle {{
      font-size: 13px;
      color: #7a7a70;
      margin-top: 4px;
    }}

    /* Navigation */
    .nav {{
      display: flex;
      gap: 32px;
      border-bottom: 1px solid #e5e5e0;
      margin-bottom: 32px;
    }}

    .nav-item {{
      padding: 12px 0;
      cursor: pointer;
      color: #7a7a70;
      font-weight: 500;
      font-size: 14px;
      border-bottom: 2px solid transparent;
      transition: all 0.2s;
    }}

    .nav-item.active {{
      color: #4d4d42;
      border-bottom-color: #ff6b6b;
    }}

    /* Tooltip */
    .tooltip-container {{
      position: relative;
      display: inline-flex;
      align-items: center;
      margin-left: 8px;
    }}

    .info-icon {{
      color: #9ca3af;
      cursor: help;
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      border: 1px solid #e5e5e0;
      font-size: 10px;
      font-family: serif;
      font-style: italic;
    }}

    .tooltip-content {{
      visibility: hidden;
      width: 250px;
      background-color: #1a1a1a;
      color: #fff;
      text-align: left;
      border-radius: 6px;
      padding: 12px;
      position: absolute;
      z-index: 100;
      bottom: 125%;
      left: 50%;
      margin-left: -125px;
      opacity: 0;
      transition: opacity 0.3s;
      font-size: 12px;
      line-height: 1.5;
      font-weight: normal;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
      border: 1px solid #333;
    }}

    .tooltip-content::after {{
      content: "";
      position: absolute;
      top: 100%;
      left: 50%;
      margin-left: -5px;
      border-width: 5px;
      border-style: solid;
      border-color: #1a1a1a transparent transparent transparent;
    }}

    .tooltip-container:hover .tooltip-content {{
      visibility: visible;
      opacity: 1;
    }}

    /* Main Content Grid - Figma inspired */
    .main-grid {{
      display: grid;
      grid-template-columns: 404px 1fr;
      gap: 64px;
      margin-bottom: 32px;
    }}

    /* Card */
    .card {{
      background: white;
      border-radius: 12px;
      padding: 24px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }}

    .card-title {{
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 16px;
      color: #4d4d42;
    }}

    /* Gauge Chart - Centered with title */
    .gauge-container {{
      text-align: center;
      background: #fffbf4;
      border: 1px solid #e4e4e1;
      border-radius: 12px;
      padding: 32px 0;
      display: flex;
      flex-direction: column;
      gap: 22px;
      align-items: center;
    }}

    .gauge-title {{
      font-size: 20px;
      font-weight: 600;
      color: #4d4d42;
      line-height: 24px;
    }}

    .gauge-title-regular {{
      font-weight: 400;
    }}

    .gauge-chart {{
      width: 100%;
      height: 311px;
      max-width: 313px;
    }}

    .gauge-label {{
      font-size: 14px;
      color: #85837a;
      margin-top: 0;
      padding: 0 32px;
      line-height: 20px;
      max-width: 335px;
    }}

    /* Test Details - Figma inspired */
    .test-details {{
      list-style: none;
      font-size: 14px;
      line-height: 20px;
      color: #6e695e;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }}

    .test-details li {{
      position: relative;
      padding-left: 20px;
    }}

    .test-details li::before {{
      content: "•";
      position: absolute;
      left: 0;
      font-weight: normal;
    }}

    .test-details strong {{
      font-weight: 700;
      color: #6e695e;
    }}

    /* Key Findings - Figma inspired */
    .findings-list {{
      display: flex;
      flex-direction: column;
      gap: 4px;
    }}

    .finding-item {{
      display: flex;
      gap: 12px;
      padding: 6px 0;
      align-items: flex-start;
    }}

    .finding-icon {{
      flex-shrink: 0;
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
    }}

    .finding-icon.red {{
      color: {SCORE_COLOR_CRITICAL};
    }}

    .finding-icon.orange {{
      color: #ea580c;
    }}

    .finding-icon.yellow {{
      color: {SCORE_COLOR_WARNING};
    }}

    .finding-icon.grey {{
      color: #9ca3af;
    }}

    .finding-icon.green {{
      color: {SCORE_COLOR_GOOD};
    }}

    .severity-icon.success {{
      color: #10b981;
    }}

    .severity-icon.warning {{
      color: #f59e0b;
    }}

    .finding-bullet {{
      flex-shrink: 0;
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      color: #6e695e;
      font-weight: bold;
    }}

    .finding-content {{
      flex: 1;
      font-size: 14px;
      line-height: 20px;
      color: #6e695e;
    }}

    .finding-content strong {{
      font-weight: 700;
      color: #4d4d42;
    }}

    /* Score Cards - Figma inspired */
    .score-section {{
      margin-bottom: 32px;
    }}

    .score-grid {{
      display: flex;
      gap: 16px;
      flex-wrap: nowrap;
    }}

    .score-card {{
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 16px;
      background: #f8f6f1;
      border-radius: 4px;
      flex: 1;
      min-width: 160px;
    }}

    .score-card.warning {{
      background: #fff6f2;
    }}

    .score-card-header {{
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
    }}

    .score-value {{
      font-family: 'La Nord', sans-serif;
      font-size: 36px;
      font-weight: 300;
      line-height: 33px;
      color: #4d4d42;
    }}

    .score-icon {{
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }}

    .score-icon.success {{
      color: #10b981;
    }}

    .score-icon.warning {{
      color: #dc2626;
    }}

    .score-label-container {{
      display: flex;
      align-items: center;
      gap: 4px;
    }}

    .score-label {{
      font-size: 14px;
      font-weight: 400;
      line-height: 20px;
      color: #6e695e;
    }}

    .score-info-icon {{
      width: 12px;
      height: 12px;
      color: #85837a;
    }}



    @media (max-width: 1024px) {{
      .main-grid {{
        grid-template-columns: 1fr;
      }}

      .score-grid {{
        grid-template-columns: repeat(2, 1fr);
      }}
    }}

    /* Conversations Tab Styles */
    .conversations-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }}

    .conversation-card {{
      background: white;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.08);
      cursor: pointer;
      transition: all 0.2s;
      border: 1px solid #e5e5e0;
    }}

    .conversation-card:hover {{
      transform: translateX(4px);
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    }}

    .conversation-card-header {{
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
    }}

    /* Floating Logo */
    .floating-logo {{
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 56px;
      height: 56px;
      background: white;
      border-radius: 50%;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
      z-index: 1000;
      padding: 12px;
    }}

    .floating-logo:hover {{
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
    }}

    .floating-logo img {{
      width: 100%;
      height: 100%;
      object-fit: contain;
    }}

    /* Conversation Detail with Side Panel */
    .conversation-detail-layout {{
      display: grid;
      grid-template-columns: 1fr 360px;
      gap: 24px;
      align-items: start;
    }}

    .conversation-detail-main {{
      min-width: 0;
    }}

    .conversation-side-panel {{
      position: sticky;
      top: 24px;
      background: #fafaf8;
      border: 1px solid #e8e6e0;
      border-radius: 12px;
      padding: 24px;
    }}

    .side-panel-title {{
      font-size: 18px;
      font-weight: 600;
      color: #2d2d29;
      margin-bottom: 16px;
    }}

    .side-panel-section {{
      margin-bottom: 20px;
      padding-bottom: 20px;
      border-bottom: 1px solid #e8e6e0;
    }}

    .side-panel-section:last-child {{
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }}

    .side-panel-section-title {{
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      color: #7a7a70;
      margin-bottom: 8px;
      letter-spacing: 0.5px;
    }}

    .side-panel-content {{
      font-size: 14px;
      color: #2d2d29;
      line-height: 1.6;
      white-space: pre-wrap;
    }}

    .side-panel-badge {{
      display: inline-block;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      margin-bottom: 8px;
    }}

    .side-panel-badge.critical {{
      background: #fee2e2;
      color: #dc2626;
    }}

    .side-panel-badge.high {{
      background: #ffedd5;
      color: #ea580c;
    }}

    .side-panel-badge.medium {{
      background: #fef3c7;
      color: #ca8a04;
    }}

    .side-panel-badge.low {{
      background: #dcfce7;
      color: #16a34a;
    }}

    .side-panel-list {{
      list-style: none;
      padding-left: 0;
      margin: 0;
    }}

    .side-panel-list li {{
      padding-left: 16px;
      position: relative;
      margin-bottom: 8px;
      font-size: 13px;
      line-height: 1.5;
    }}

    .side-panel-list li:before {{
      content: '•';
      position: absolute;
      left: 0;
      color: #f97316;
      font-weight: bold;
    }}

    @media (max-width: 1024px) {{
      .conversation-detail-layout {{
        grid-template-columns: 1fr;
      }}

      .conversation-side-panel {{
        position: relative;
        top: 0;
      }}
    }}

    .conversation-avatar {{
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 20px;
      font-weight: 600;
    }}

    .conversation-card-title {{
      font-size: 16px;
      font-weight: 600;
      color: #4d4d42;
    }}

    .conversation-card-meta {{
      font-size: 12px;
      color: #7a7a70;
      margin-top: 4px;
    }}

    /* Chat Bubble Styles */
    .chat-container {{
      max-width: 800px;
      margin: 0 auto;
      padding-bottom: 24px;
    }}

    .chat-message {{
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
      align-items: flex-start;
    }}

    .chat-message.user {{
      flex-direction: row-reverse;
    }}

    .chat-avatar {{
      width: 32px;
      height: 32px;
      border-radius: 50%;
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 12px;
      font-weight: 600;
      background: #4d4d42;
      border: 2px solid #fff;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }}

    .chat-avatar.user {{
      background: #5b21b6;
    }}

    .chat-avatar.assistant {{
      background: #ec4899;
    }}

    .chat-bubble {{
      max-width: 65%;
      padding: 10px 14px;
      border-radius: 16px;
      line-height: 1.5;
      word-wrap: break-word;
      font-size: 14px;
      box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    }}

    .chat-message.user .chat-bubble {{
      background: #ffffff;
      color: #2d2d29;
      border: 1px solid #e5e5e0;
      border-bottom-right-radius: 4px;
    }}

    .chat-message.assistant .chat-bubble {{
      background: #faf9f7;
      color: #2d2d29;
      border: 1px solid #f0f0ed;
      border-bottom-left-radius: 4px;
    }}

    .chat-timestamp {{
      font-size: 11px;
      color: #9a9a8f;
      margin-top: 4px;
      text-align: right;
      font-weight: 400;
    }}

    .chat-message.assistant .chat-timestamp {{
      text-align: left;
    }}

    /* Markdown content styling in chat bubbles */
    .chat-bubble h1,
    .chat-bubble h2,
    .chat-bubble h3,
    .chat-bubble h4,
    .chat-bubble h5,
    .chat-bubble h6 {{
      margin-top: 12px;
      margin-bottom: 8px;
      font-weight: 600;
      line-height: 1.3;
    }}

    .chat-bubble h1:first-child,
    .chat-bubble h2:first-child,
    .chat-bubble h3:first-child,
    .chat-bubble h4:first-child,
    .chat-bubble h5:first-child,
    .chat-bubble h6:first-child {{
      margin-top: 0;
    }}

    .chat-bubble h1 {{ font-size: 1.5em; }}
    .chat-bubble h2 {{ font-size: 1.3em; }}
    .chat-bubble h3 {{ font-size: 1.1em; }}
    .chat-bubble h4 {{ font-size: 1em; }}

    .chat-bubble p {{
      margin-bottom: 8px;
    }}

    .chat-bubble p:last-child {{
      margin-bottom: 0;
    }}

    .chat-bubble ul,
    .chat-bubble ol {{
      margin: 8px 0;
      padding-left: 24px;
    }}

    .chat-bubble li {{
      margin-bottom: 4px;
    }}

    .chat-bubble code {{
      background: #f5f4f0;
      padding: 2px 6px;
      border-radius: 3px;
      font-family: 'Monaco', 'Courier New', monospace;
      font-size: 0.9em;
      color: #d97706;
    }}

    .chat-bubble pre {{
      background: #f5f4f0;
      padding: 12px;
      border-radius: 6px;
      overflow-x: auto;
      margin: 8px 0;
    }}

    .chat-bubble pre code {{
      background: transparent;
      padding: 0;
      color: inherit;
    }}

    .chat-bubble blockquote {{
      border-left: 3px solid #e5e5e0;
      padding-left: 12px;
      margin: 8px 0;
      color: #7a7a70;
      font-style: italic;
    }}

    .chat-bubble a {{
      color: #ff8e53;
      text-decoration: none;
    }}

    .chat-bubble a:hover {{
      text-decoration: underline;
    }}

    .chat-bubble strong {{
      font-weight: 600;
    }}

    .chat-bubble em {{
      font-style: italic;
    }}

    .chat-bubble hr {{
      border: none;
      border-top: 1px solid #e5e5e0;
      margin: 12px 0;
    }}

    /* Collapsible evaluations section */
    .findings-collapsible {{
      cursor: default;
    }}

    .findings-collapsible summary {{
      list-style: none;
    }}

    .findings-collapsible summary::-webkit-details-marker {{
      display: none;
    }}

    .findings-collapsible[open] summary i.ph-caret-right {{
      transform: rotate(90deg);
    }}

    .findings-collapsible summary:hover {{
      background-color: #f0f0ec;
    }}

    /* TLDR content styles */
    .tldr-content ul {{
      margin: 8px 0;
      padding-left: 0;
      list-style: none;
    }}

    .tldr-content li {{
      margin-bottom: 4px;
      padding-left: 0;
    }}

    .tldr-content p {{
      margin: 0 0 8px 0;
    }}

    .tldr-content p:last-child {{
      margin-bottom: 0;
    }}

    .tldr-content strong {{
      color: #1f2937;
    }}

    .chat-bubble table {{
      border-collapse: collapse;
      width: 100%;
      margin: 8px 0;
    }}

    .chat-bubble th,
    .chat-bubble td {{
      border: 1px solid #e5e5e0;
      padding: 8px;
      text-align: left;
    }}

    .chat-bubble th {{
      background: #f5f4f0;
      font-weight: 600;
    }}

    /* Markdown content styling for findings and executive summary */
    .markdown-content {{
      font-size: 14px;
      line-height: 1.6;
      color: #4d4d42;
    }}

    .markdown-content p {{
      margin-bottom: 8px;
    }}

    .markdown-content p:last-child {{
      margin-bottom: 0;
    }}

    .markdown-content ul,
    .markdown-content ol {{
      margin: 8px 0;
      padding-left: 20px;
    }}

    .markdown-content li {{
      margin-bottom: 4px;
    }}

    .markdown-content strong {{
      font-weight: 600;
    }}

    .markdown-content code {{
      background: #f5f4f0;
      padding: 2px 6px;
      border-radius: 3px;
      font-family: 'Monaco', 'Courier New', monospace;
      font-size: 0.9em;
    }}

    /* Video Player */
    .video-player-container {{
      margin-top: 32px;
      background: white;
      border-radius: 12px;
      padding: 24px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }}

    .video-player-container h3 {{
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 16px;
    }}

    .video-player-container video {{
      width: 100%;
      border-radius: 8px;
      background: #000;
    }}
  </style>
</head>
<body>
  <div id="root"></div>

  <script>
    // Report Data (embedded as JavaScript object)
    const REPORT_DATA = {data_json};

    // --- SCORING CONSTANTS ---
    // Extract scoring constants from report_metadata for use throughout the report
    // This centralizes all color/label/threshold decisions in report_data.json
    const SCORING = REPORT_DATA.report_metadata?.scoring || {{}};
    const THRESHOLDS = SCORING.thresholds || {{ good: 75, pass: 20 }};
    const LABELS = SCORING.labels || {{ good: 'Good', warning: 'Warning', critical: 'Critical' }};
    const COLORS = SCORING.colors || {{ good: '#10b981', warning: '#eab308', critical: '#ef4444' }};
    const COLOR_BY_LABEL = SCORING.color_by_label || {{}};
    const COLOR_TYPES = SCORING.color_types || {{
      critical: {{ outer: '#FFE9E5', bg: '#FFD7CF', foreground: '#FF4722', dot: '#FF4722', text: '#FF4722', icon: '🔴', iconClass: 'ph-warning', iconName: 'WarningDiamondLight', priority: 1 }},
      warning: {{ outer: '#FFFBF4', bg: '#FBF5EB', foreground: '#FFCD6D', dot: '#FFCD6D', text: '#FFCD6D', icon: '🟡', iconClass: 'ph-warning-circle', iconName: 'WarningDiamondLight', priority: 2 }},
      good: {{ outer: '#DBECE1', bg: '#B6DBC2', foreground: '#0B7C30', dot: '#0B7C30', text: '#0B7C30', icon: '🟢', iconClass: 'ph-check-circle', iconName: 'OutlineCheckCircleOutline', priority: 3 }}
    }};

    // --- REHYDRATE DATA ---
    // The findings in REPORT_DATA.key_findings now reference finding_ids to avoid data duplication.
    // We rehydrate the 'instances' array on the client side for compatibility with UI components.
    if (REPORT_DATA.all_findings && Array.isArray(REPORT_DATA.all_findings)) {{
      const findingsMap = {{}};
      REPORT_DATA.all_findings.forEach(f => {{
        if (f.id) findingsMap[f.id] = f;
      }});

      if (REPORT_DATA.key_findings) {{
        REPORT_DATA.key_findings.forEach(consolidated => {{
          if (consolidated.finding_ids && Array.isArray(consolidated.finding_ids) && !consolidated.instances) {{
            consolidated.instances = consolidated.finding_ids
              .map(id => findingsMap[id])
              .filter(Boolean)
              .map(original => {{
                // Extract turn from evidence or top-level (matching report_data_generator.py logic)
                const turnNum = original.evidence?.turn_number ?? original.turn_number ?? null;
                // Determine level: "turn" if has valid turn number, "conversation" otherwise
                const level = turnNum != null ? "turn" : "conversation";
                return {{
                  source: original.source,
                  evidence: original.evidence || {{}},
                  explanation: original.evaluation_explanation || "",
                  score: original.score,
                  confidence: original.confidence,
                  persona: original.source,
                  turn: turnNum,
                  level: level
                }};
              }});

            // Restore missing top-level fields from aggregated instances data if needed
            // This is critical because some filters depend on confidence being present
            if (consolidated.confidence === undefined && consolidated.instances.length > 0) {{
               const total = consolidated.instances.reduce((sum, inst) => sum + (inst.confidence || 0), 0);
               consolidated.confidence = total / consolidated.instances.length;
            }}
          }}
        }});
      }}

      // Rehydrate detailed_findings (categories view)
      // If detailed_findings is missing (optimization), generate it from all_findings
      if (!REPORT_DATA.detailed_findings && REPORT_DATA.all_findings) {{
        const categories = {{}};

        REPORT_DATA.all_findings.forEach(finding => {{
           const cat = finding.category || "Uncategorized";
           if (!categories[cat]) categories[cat] = [];
           categories[cat].push(finding);
        }});

        // Sort categories by finding count (desc)
        const sortedCategoryNames = Object.keys(categories).sort((a,b) => categories[b].length - categories[a].length);

        const labelOrder = {{
           [LABELS.critical]: 0,
           [LABELS.warning]: 1,
           [LABELS.good]: 3
        }};

        const getLabelVal = (sev) => labelOrder[sev] !== undefined ? labelOrder[sev] : 5;

        REPORT_DATA.detailed_findings = sortedCategoryNames.map((catName, index) => {{
           const findingsList = categories[catName];

           // Sort findings by label
           findingsList.sort((a, b) => getLabelVal(a.label) - getLabelVal(b.label));

           const maxLabel = findingsList.length > 0 ? findingsList[0].label : "Unknown";

           return {{
              category_id: String(index + 1),
              category_title: catName,
              label: maxLabel,
              findings: findingsList,
              findings_count: findingsList.length
           }};
        }});
      }} else if (REPORT_DATA.detailed_findings) {{
        REPORT_DATA.detailed_findings.forEach(category => {{
          if (category.findings) {{
             category.findings = category.findings.map(item => {{
                const id = item.id || item;
                return findingsMap[id];
             }}).filter(Boolean);
          }}
        }});
      }}
    }}

    // Helper to get consolidated findings (with instances array)
    // Used for: Key Findings tab, Executive Summary
    const getAllFindings = () => {{
        return REPORT_DATA.key_findings || [];
    }};

    // Helper to get unconsolidated findings (one per persona)
    // Used for: Conversations tab, Findings by category tab
    const getAllDetailedFindings = () => {{
        // Use all_findings which contains per-persona unconsolidated findings with turn_number
        return REPORT_DATA.all_findings || [];
    }};

    const {{ useState, useEffect, useRef }} = React;
    const {{ createRoot }} = ReactDOM;

    // Configure marked options
    if (window.marked) {{
      marked.setOptions({{
        breaks: true,
        gfm: true
      }});
    }}

    // Components
    function Header() {{
      const faviconUrl = REPORT_DATA.metadata?.favicon_url;

      return React.createElement('div', {{ className: 'header' }},
        React.createElement('div', {{ className: 'header-container' }},
          React.createElement('div', {{ className: 'header-left' }},
            React.createElement('div', {{ className: 'logo' }},
              faviconUrl
                ? React.createElement('img', {{ src: faviconUrl, alt: 'Site favicon', onError: (e) => {{ e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }} }})
                : null,
              React.createElement('i', {{ className: 'ph ph-lightning', style: {{ display: faviconUrl ? 'none' : 'flex' }} }})
            ),
            React.createElement('div', {{ className: 'header-title' }},
              React.createElement('h1', null, REPORT_DATA.title || 'Conversational UI Testing Report'),
              React.createElement('div', {{ className: 'header-subtitle' }},
                REPORT_DATA.subtitle || ''
              )
            )
          )
        )
      );
    }}

    function Navigation({{ activeTab, setActiveTab }}) {{
      const tabs = ['Executive Summary', 'Findings', 'Conversations'];
      if (REPORT_DATA.test_summary) {{
        tabs.push('Test Summary');
      }}
      if (REPORT_DATA.eu_ai_act_compliance) {{
        tabs.push('EU AI Act Compliance');
      }}

      return React.createElement('div', {{ className: 'nav' }},
        tabs.map(tab =>
          React.createElement('div', {{
            key: tab,
            className: `nav-item ${{activeTab === tab ? 'active' : ''}}`,
            onClick: () => setActiveTab(tab)
          }}, tab)
        )
      );
    }}

    function ResponseLengthChart({{ data }}) {{
      const chartRef = useRef(null);

      useEffect(() => {{
        if (chartRef.current && data) {{
          const chart = echarts.init(chartRef.current);
          const distribution = data.distribution || {{}};
          const categories = Object.keys(distribution);
          const values = Object.values(distribution);

          const option = {{
            tooltip: {{
              trigger: 'axis',
              axisPointer: {{
                type: 'shadow'
              }}
            }},
            grid: {{
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true,
              top: '5%'
            }},
            xAxis: [
              {{
                type: 'category',
                data: categories,
                axisTick: {{
                  alignWithLabel: true
                }},
                axisLabel: {{
                  formatter: function(value) {{
                    const valStr = String(value);
                    if (valStr.includes('-')) {{
                      const parts = valStr.split('-');
                      if (parts.length === 2) return `<${{parts[1]}}`;
                    }}
                    return valStr;
                  }},
                  rotate: 45,
                  interval: 0,
                  fontSize: 10,
                  width: 80,
                  overflow: 'truncate',
                  color: '#6e695e'
                }}
              }}
            ],
            yAxis: [
              {{
                type: 'value',
                axisLabel: {{
                  color: '#6e695e'
                }}
              }}
            ],
            series: [
              {{
                name: 'Responses',
                type: 'bar',
                barWidth: '60%',
                data: values,
                itemStyle: {{
                  color: '#3b82f6',
                  borderRadius: [4, 4, 0, 0]
                }}
              }}
            ]
          }};

          chart.setOption(option);

          const handleResize = () => chart.resize();
          window.addEventListener('resize', handleResize);

          return () => {{
            window.removeEventListener('resize', handleResize);
            chart.dispose();
          }};
        }}
      }}, [data]);

      return React.createElement('div', {{ style: {{ width: '100%', marginTop: '24px', display: 'flex', flexDirection: 'column', alignItems: 'center' }} }},
        React.createElement('p', {{ className: 'gauge-title', style: {{ marginBottom: '16px' }} }}, 'Response Length Distribution (char)'),
        React.createElement('div', {{
          ref: chartRef,
          style: {{ width: '100%', height: '200px' }}
        }})
      );
    }}

    function LatencyChart({{ data }}) {{
      const chartRef = useRef(null);
      const hasData = data && data.distribution && Object.keys(data.distribution).length > 0;

      useEffect(() => {{
        if (chartRef.current && hasData) {{
          const chart = echarts.init(chartRef.current);
          const distribution = data.distribution || {{}};
          const categories = Object.keys(distribution);
          const values = Object.values(distribution);

          const option = {{
            tooltip: {{
              trigger: 'axis',
              axisPointer: {{
                type: 'shadow'
              }}
            }},
            grid: {{
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true,
              top: '5%'
            }},
            xAxis: [
              {{
                type: 'category',
                data: categories,
                axisTick: {{
                  alignWithLabel: true
                }},
                axisLabel: {{
                  formatter: function(value) {{
                    const valStr = String(value);
                    if (valStr.includes('-')) {{
                      const parts = valStr.split('-');
                      if (parts.length === 2) return `<${{parts[1]}}`;
                    }}
                    return valStr;
                  }},
                  rotate: 45,
                  interval: 0,
                  fontSize: 10,
                  width: 80,
                  overflow: 'truncate',
                  color: '#6e695e'
                }}
              }}
            ],
            yAxis: [
              {{
                type: 'value',
                axisLabel: {{
                  color: '#6e695e'
                }}
              }}
            ],
            series: [
              {{
                name: 'Responses',
                type: 'bar',
                barWidth: '60%',
                data: values,
                itemStyle: {{
                  color: '#3b82f6',
                  borderRadius: [4, 4, 0, 0]
                }}
              }}
            ]
          }};

          chart.setOption(option);

          const handleResize = () => chart.resize();
          window.addEventListener('resize', handleResize);

          return () => {{
            window.removeEventListener('resize', handleResize);
            chart.dispose();
          }};
        }}
      }}, [data, hasData]);

      if (!hasData) {{
        return null;
      }}

      return React.createElement('div', {{ style: {{ width: '100%', marginTop: '24px', display: 'flex', flexDirection: 'column', alignItems: 'center' }} }},
        React.createElement('p', {{ className: 'gauge-title', style: {{ marginBottom: '16px' }} }}, 'Response Time Distribution (sec)'),
        React.createElement('div', {{
          ref: chartRef,
          style: {{ width: '100%', height: '200px' }}
        }})
      );
    }}

    function AggregatedMetricsChart({{ metrics, definitions }}) {{
      const chartRef = useRef(null);

      useEffect(() => {{
        // Defensive check: metrics must be an object
        if (chartRef.current && metrics && typeof metrics === 'object') {{
          const chart = echarts.init(chartRef.current);

          // Robust helper to get metric info
          const getMetricInfo = (key) => {{
             if (definitions && definitions[key]) {{
                 return definitions[key];
             }}
             // Robust fallback: remove underscores and Title Case
             const label = key.replace(/_/g, ' ')
                .replace(/\\b\\w/g, l => l.toUpperCase()); // Double escape for Python f-string
             return {{
                 label: label,
                 description: ''
             }};
          }};

          const entries = Object.entries(metrics);
          const indicators = [];
          const values = [];
          let totalScore = 0;
          let count = 0;

          entries.forEach(([key, val]) => {{
            // Skip 'evals' and 'aes_score' from the chart
            if (key === 'evals' || key === 'aes_score') return;

            // Handle various value formats defensively
            let numericVal = 0;

            if (val === null || val === undefined) {{
                numericVal = 0;
            }}
            else if (typeof val === 'object' && 'avg' in val) {{
                numericVal = val.avg;
            }}
            else if (typeof val === 'number') {{
                numericVal = val;
            }}
            else if (typeof val === 'string' && !isNaN(parseFloat(val))) {{
                numericVal = parseFloat(val);
            }}

            // Ensure strictly number
            numericVal = Number(numericVal);
            if (isNaN(numericVal)) numericVal = 0;

            const info = getMetricInfo(key);
            indicators.push({{ name: info.label, max: 100, description: info.description }});
            values.push(Math.round(numericVal));

            totalScore += numericVal;
            count++;
          }});

          // Calculate average for color determination
          const avgScore = count > 0 ? totalScore / count : 0;

          let color = COLORS.critical;
          if (avgScore >= THRESHOLDS.good) color = COLORS.good;
          else if (avgScore >= THRESHOLDS.pass) color = COLORS.warning;

          const option = {{
            tooltip: {{
              trigger: 'item',
              confine: true,
              extraCssText: 'max-width: 400px; white-space: normal; text-align: left;',
              textStyle: {{
                fontSize: 10
              }},
              formatter: function(params) {{
                let res = '<div style="font-weight: bold; margin-bottom: 5px; font-size: 11px;">' + params.name + '</div>';

                indicators.forEach((ind, idx) => {{
                  const val = params.value[idx];
                  res += '<div style="margin-bottom: 8px;">';
                  res += '<span style="font-weight: 500;">' + ind.name + ': </span>';
                  res += '<span style="font-weight: bold;">' + val + '</span>';

                  if (ind.description) {{
                     res += '<br/><span style="font-size: 9px; opacity: 0.8; line-height: 1.2; display: inline-block; margin-top: 1px;">' + ind.description + '</span>';
                  }}
                  res += '</div>';
                }});
                return res;
              }}
            }},
            radar: {{
              indicator: indicators,
              splitNumber: 5,
              splitArea: {{
                areaStyle: {{
                  color: [
                    COLORS.critical + '14',   // 0-20
                    COLORS.critical + '14',   // 20-40
                    COLORS.warning + '14',    // 40-60
                    COLORS.warning + '14',    // 60-80 (High < 75)
                    COLORS.good + '14'        // 80-100 (Good > 75)
                  ],
                  shadowColor: 'rgba(0, 0, 0, 0.1)',
                  shadowBlur: 5
                }}
              }},
              axisName: {{
                color: '#6e695e',
                fontSize: 11
              }}
            }},
            series: [
              {{
                type: 'radar',
                data: [
                  {{
                    value: values,
                    name: 'Quality Metrics',
                    label: {{
                      show: true,
                      formatter: function(params) {{
                        return params.value;
                      }}
                    }},
                    areaStyle: {{
                      color: color,
                      opacity: 0.2
                    }},
                    itemStyle: {{
                      color: color
                    }},
                    lineStyle: {{
                      color: color
                    }}
                  }}
                ]
              }}
            ]
          }};

          chart.setOption(option);

          const handleResize = () => chart.resize();
          window.addEventListener('resize', handleResize);

          return () => {{
            window.removeEventListener('resize', handleResize);
            chart.dispose();
          }};
        }}
      }}, [metrics, definitions]);

      return React.createElement('div', {{ style: {{ width: '100%', marginTop: '24px', display: 'flex', flexDirection: 'column', alignItems: 'center' }} }},
        React.createElement('p', {{ className: 'gauge-title', style: {{ marginBottom: '16px' }} }}, 'Quality Metrics'),
        React.createElement('div', {{
          ref: chartRef,
          style: {{ width: '100%', height: '300px' }}
        }})
      );
    }}


    function GaugeChart({{ value }}) {{
      const chartRef = useRef(null);

      useEffect(() => {{
        if (chartRef.current) {{
          const chart = echarts.init(chartRef.current);

          // Calculate segments - donut chart style like Figma
          const passValue = value;
          const failValue = 100 - value;

          // Determine risk level based on score
          let riskColor = COLORS.critical;
          if (value >= THRESHOLDS.good) {{
            riskColor = COLORS.good;
          }} else if (value >= THRESHOLDS.pass) {{
            riskColor = COLORS.warning;
          }}

          const option = {{
            series: [
              {{
                type: 'pie',
                radius: ['70%', '90%'],
                center: ['50%', '50%'],
                startAngle: 90,
                avoidLabelOverlap: false,
                label: {{ show: false }},
                labelLine: {{ show: false }},
                emphasis: {{
                  scale: false
                }},
                data: [
                  {{
                    value: passValue,
                    itemStyle: {{
                      color: riskColor
                    }}
                  }},
                  {{
                    value: failValue,
                    itemStyle: {{ color: '#e0e0e0' }}
                  }}
                ]
              }}
            ]
          }};

          chart.setOption(option);

          // Handle window resize
          const handleResize = () => chart.resize();
          window.addEventListener('resize', handleResize);

          return () => {{
            window.removeEventListener('resize', handleResize);
            chart.dispose();
          }};
        }}
      }}, [value]);

      // Render donut with centered text
      return React.createElement('div', {{ style: {{ position: 'relative', width: '313px', height: '311px' }} }},
        React.createElement('div', {{ ref: chartRef, style: {{ width: '100%', height: '100%' }} }}),
        React.createElement('div', {{
          style: {{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            textAlign: 'center',
            pointerEvents: 'none'
          }}
        }},
          React.createElement('div', {{
            style: {{
              fontFamily: 'La Nord, sans-serif',
              fontSize: '80px',
              fontWeight: '400',
              lineHeight: '1',
              color: '#4d4d42'
            }}
          }}, `${{Math.round(value)}}%`)
        )
      );
    }}



    function PersonaSuccessMatrix({{ detailed_findings, personas }}) {{
      const chartRef = useRef(null);

      useEffect(() => {{
        if (chartRef.current && detailed_findings && detailed_findings.length > 0 && personas && personas.length > 0) {{
          const chart = echarts.init(chartRef.current);

          // Get unique categories
          const categories = [...new Set(detailed_findings.map(df => df.category_title))];

          // Build matrix data: rows = personas, columns = categories
          const matrixData = [];
          const personaStats = {{}};

          personas.forEach((persona, persona_idx) => {{
            if (persona === 'domain_settings') return; // Skip domain_settings

            personaStats[persona] = {{ totalScore: 0, failures: 0, passes: 0, totalFindings: 0 }};

            categories.forEach((category, categoryIdx) => {{
              // Find all findings for this persona + category
              const categoryFindings = detailed_findings.find(df => df.category_title === category);
              if (!categoryFindings) return;

              categoryFindings.findings.forEach(finding => {{
                const personaInstance = (finding.instances || []).find(inst => inst.persona === persona);
                if (personaInstance) {{
                  const status = (finding.score || 0) >= THRESHOLDS.pass ? 1 : 0; // 1 = pass, 0 = fail
                  const score = finding.score || 0;

                  matrixData.push([categoryIdx, persona_idx, status, score, finding.title, category, persona]);

                  personaStats[persona].totalScore += score;
                  personaStats[persona].totalFindings++;
                  if (status === 1) {{
                    personaStats[persona].passes++;
                  }} else {{
                    personaStats[persona].failures++;
                  }}
                }}
              }});
            }});
          }});

          // Calculate average scores for sorting
          Object.keys(personaStats).forEach(p => {{
            if (personaStats[p].totalFindings > 0) {{
              personaStats[p].avgScore = personaStats[p].totalScore / personaStats[p].totalFindings;
            }} else {{
              personaStats[p].avgScore = 0;
            }}
          }});

          // Sort personas by total score descending
          const sortedPersonas = personas
            .filter(p => p !== 'domain_settings')
            .sort((a, b) => (personaStats[b]?.totalScore || 0) - (personaStats[a]?.totalScore || 0));

          const option = {{
            tooltip: {{
              position: 'top',
              formatter: params => {{
                const [catIdx, persona_idx, status, score, title, category, persona] = params.data;
                const statusText = status === 1 ? '✅ PASS' : '❌ FAIL';
                return `
                  <strong>${{persona}}</strong><br/>
                  Category: ${{category}}<br/>
                  Finding: ${{title}}<br/>
                  Status: ${{statusText}}<br/>
                  Score: ${{score}}
                `;
              }}
            }},
            grid: {{
              left: 200,
              right: 20,
              top: 80,
              bottom: 20
            }},
            xAxis: {{
              type: 'category',
              data: categories,
              splitArea: {{ show: true }},
              axisLabel: {{
                rotate: 45,
                fontSize: 10,
                interval: 0
              }}
            }},
            yAxis: {{
              type: 'category',
              data: sortedPersonas,
              splitArea: {{ show: true }},
              axisLabel: {{
                fontSize: 10,
                width: 180,
                overflow: 'truncate',
                ellipsis: '...'
              }}
            }},
            visualMap: {{
              min: 0,
              max: 1,
              calculable: false,
              orient: 'horizontal',
              left: 'center',
              top: 10,
              text: ['PASS', 'FAIL'],
              inRange: {{
                color: [COLORS.critical, COLORS.good]
              }}
            }},
            series: [{{
              name: 'Persona Success',
              type: 'heatmap',
              data: matrixData.map(d => {{
                const [catIdx, oldPersonaIdx, status, score, title, category, persona] = d;
                const newPersonaIdx = sortedPersonas.indexOf(persona);
                return [catIdx, newPersonaIdx, status];
              }}),
              label: {{
                show: true,
                formatter: params => {{
                  return params.data[2] === 1 ? '✅' : '❌';
                }},
                fontSize: 16
              }},
              emphasis: {{
                itemStyle: {{
                  shadowBlur: 10,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }}
              }}
            }}]
          }};

          chart.setOption(option);

          // Handle window resize
          const handleResize = () => chart.resize();
          window.addEventListener('resize', handleResize);

          return () => {{
            window.removeEventListener('resize', handleResize);
            chart.dispose();
          }};
        }}
      }}, [detailed_findings, personas]);

      return React.createElement('div', {{ ref: chartRef, style: {{ width: '100%', height: '600px', minHeight: '600px' }} }});
    }}

    function TurnByTurnTimeline({{ detailed_findings }}) {{
      const chartRef = useRef(null);

      useEffect(() => {{
        if (chartRef.current && detailed_findings && detailed_findings.length > 0) {{
          const chart = echarts.init(chartRef.current);

          // Collect all findings with turn numbers
          const timelineData = [];
          detailed_findings.forEach(category => {{
            category.findings.forEach(finding => {{
              (finding.instances || []).forEach(instance => {{
                // Skip conversation-level findings (no turn number) - only show turn-level on timeline
                if (instance.level === 'conversation' || instance.turn == null) return;

                const labelValue = {{
                  [LABELS.critical]: 4,
                  [LABELS.warning]: 3,
                  [LABELS.good]: 1
                }}[finding.label] || 1;

                // Business impact colors (timeline doesn't combine with score)
                const businessImpactColor = {{
                  [LABELS.critical]: COLORS.critical,
                  [LABELS.warning]: COLORS.warning,
                  [LABELS.good]: COLORS.good
                }}[finding.label] || COLORS.warning;

                timelineData.push({{
                  turn: instance.turn,
                  label: labelValue,
                  labelName: finding.label,
                  color: businessImpactColor,
                  title: finding.title,
                  category: category.category_title,
                  persona: instance.persona,
                  // result field removed
                  score: finding.score,
                  evidence: instance.evidence
                }});
              }});
            }});
          }});

          // Sort by turn number
          timelineData.sort((a, b) => a.turn - b.turn);

          // Prepare scatter data
          const scatterData = timelineData.map(d => [d.turn, d.label, d]);

          const option = {{
            tooltip: {{
              trigger: 'item',
              formatter: params => {{
                const data = params.data[2];
                const statusEmoji = (data.score || 0) >= THRESHOLDS.pass ? '✅' : '❌';
                return `
                  <strong>Turn ${{data.turn}}: ${{data.title}}</strong><br/>
                  Category: ${{data.category}}<br/>
                  Persona: ${{data.persona}}<br/>
                  Label: ${{data.labelName}}<br/>
                  Result: ${{statusEmoji}} ${{(data.score || 0) >= THRESHOLDS.pass ? 'PASS' : 'FAIL'}}<br/>
                  Score: ${{data.score}}<br/>
                  <br/>
                  <em>Click for details</em>
                `;
              }}
            }},
            grid: {{
              left: 60,
              right: 20,
              top: 40,
              bottom: 60
            }},
            xAxis: {{
              type: 'value',
              name: 'Conversation Turn',
              nameLocation: 'middle',
              nameGap: 35,
              min: 0
            }},
            yAxis: {{
              type: 'value',
              name: 'Severity',
              min: 0,
              max: 4,
              axisLabel: {{
                formatter: v => {{
                  const labels = ['', LABELS.good, '', LABELS.warning, LABELS.critical];
                  return labels[v] || '';
                }}
              }}
            }},
            series: [{{
              type: 'scatter',
              symbolSize: 20,
              data: scatterData,
              itemStyle: {{
                color: params => params.data[2].color
              }}
            }}]
          }};

          chart.setOption(option);

          // Add click handler to show evidence
          const clickHandler = params => {{
            const data = params.data[2];
            alert(`Turn ${{data.turn}}: ${{data.title}}\\n\\n${{data.evidence}}`);
          }};
          chart.on('click', clickHandler);

          // Handle window resize
          const handleResize = () => chart.resize();
          window.addEventListener('resize', handleResize);

          return () => {{
            window.removeEventListener('resize', handleResize);
            chart.off('click', clickHandler);
            chart.dispose();
          }};
        }}
      }}, [detailed_findings]);

      return React.createElement('div', {{ ref: chartRef, style: {{ width: '100%', height: '400px', minHeight: '400px' }} }});
    }}

    function RecommendationPriorityMatrix({{ findings }}) {{
      const chartRef = useRef(null);

      useEffect(() => {{
        if (chartRef.current && findings && findings.length > 0) {{
          const chart = echarts.init(chartRef.current);

          // Map findings to impact/effort quadrants
          // We'll use severity for impact, confidence for effort estimation
          const matrixData = findings.map(f => {{
            // Impact: Critical=4, High=3, Low=1, Info=0
            const impactMap = {{
              [LABELS.critical]: 4,
              [LABELS.warning]: 3,
              [LABELS.good]: 1
            }};
            const impact = impactMap[f.label] || 1;

            // Effort (inverse of confidence): low confidence = high effort
            const effort = 1 - (f.confidence || 0.5);

            // Count affected personas (from category grouping)
            const affectedCount = 1; // Simplified - would need detailed_findings cross-reference

            return {{
              value: [effort, impact, affectedCount * 20],
              title: f.title,
              category: f.category,
              label: f.label,
              confidence: f.confidence,
              score: f.score
            }};
          }});

          const option = {{
            tooltip: {{
              formatter: params => {{
                const {{ title, category, label, confidence, score }} = params.data;
                const effortLevel = params.data.value[0] > 0.5 ? 'High' : 'Low';
                const impactLevel = params.data.value[1] > 2 ? LABELS.warning : LABELS.good;
                return `
                  <strong>${{title}}</strong><br/>
                  Category: ${{category}}<br/>
                  Label: ${{label}}<br/>
                  Status: ${{(score || 0) >= THRESHOLDS.pass ? 'PASS' : 'FAIL'}}<br/>
                  Score: ${{score}}<br/>
                  <br/>
                  <strong>Priority Quadrant:</strong><br/>
                  Impact: ${{impactLevel}}<br/>
                  Effort: ${{effortLevel}}
                `;
              }}
            }},
            grid: {{
              left: 80,
              right: 40,
              top: 40,
              bottom: 80
            }},
            xAxis: {{
              type: 'value',
              name: 'Effort to Fix',
              nameLocation: 'middle',
              nameGap: 40,
              min: 0,
              max: 1,
              axisLabel: {{
                formatter: v => v < 0.5 ? 'Easy' : v > 0.5 ? 'Hard' : 'Medium'
              }},
              splitLine: {{
                show: true,
                lineStyle: {{
                  type: 'dashed'
                }}
              }}
            }},
            yAxis: {{
              type: 'value',
              name: 'Impact',
              min: 0,
              max: 4,
              axisLabel: {{
                formatter: v => {{
                  if (v <= 1) return LABELS.good;
                  if (v <= 3) return LABELS.warning;
                  return LABELS.critical;
                }}
              }},
              splitLine: {{
                show: true,
                lineStyle: {{
                  type: 'dashed'
                }}
              }}
            }},
            visualMap: {{
              show: false,
              dimension: 1,
              min: 0,
              max: 4,
              inRange: {{
                color: [COLORS.good, COLORS.good, COLORS.warning, COLORS.warning, COLORS.critical]
              }}
            }},
            series: [{{
              type: 'scatter',
              symbolSize: d => d[2],
              data: matrixData,
              emphasis: {{
                focus: 'self',
                itemStyle: {{
                  shadowBlur: 10,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }}
              }}
            }}]
          }};

          chart.setOption(option);

          // Handle window resize
          const handleResize = () => chart.resize();
          window.addEventListener('resize', handleResize);

          return () => {{
            window.removeEventListener('resize', handleResize);
            chart.dispose();
          }};
        }}
      }}, [findings]);

      return React.createElement('div', {{ ref: chartRef, style: {{ width: '100%', height: '500px', minHeight: '500px' }} }});
    }}

    function ExecutiveSummary({{ setActiveTab, setSelectedConversation, setHighlightTurn }}) {{
      const {{ detailed_findings, executive_summary, stats, metadata }} = REPORT_DATA;

      // Use CONSOLIDATED findings for Key Findings display (with instances/occurrences)
      // Filter findings to exclude "Trivial Passes" (Good label with passing score)
      const findings = getAllFindings()
        .filter(f => {{
          const isPass = (f.score || 0) >= THRESHOLDS.pass;
          const label = (f.label || LABELS.good).toLowerCase();
          const isTrivial = label === LABELS.good.toLowerCase();
          // Keep if it's a failure OR if it's not a trivial pass
          return !isPass || !isTrivial;
        }});

      // Helper to get color type based on label (not score)
      const getColorType = (finding) => {{
        const label = finding.label?.toLowerCase() || '';
        if (label === LABELS.critical.toLowerCase()) return 'critical';
        if (label === LABELS.warning.toLowerCase()) return 'warning';
        if (label === LABELS.good.toLowerCase()) return 'good';
        return 'warning';
      }};

      // Get UNCONSOLIDATED findings for accurate total count
      // Use same filter as FindingsView: turn-based OR conversation-level Critical
      const detailedFindingsForCount = getAllDetailedFindings()
        .filter(f => {{
          const hasTurnNumber = f.evidence?.turn_number != null;
          const isCritical = getColorType(f) === 'critical';
          // Include if turn-based OR (conversation-level AND critical)
          return hasTurnNumber || isCritical;
        }});

      // Prepare key findings - categorized by color (red/yellow/grey/green)
      // Target: 3 problem findings (red + yellow) + up to 2 green findings
      const keyFindings = React.useMemo(() => {{
        if (!findings || findings.length === 0) return [];

        // Priority score: combines severity (inverse of score) with occurrence rate
        // Higher affected_percentage = more users impacted = higher priority
        // Lower score = more severe = higher priority
        const getPriority = (f) => {{
          const severityFactor = 100 - (f.score || 0);  // 0-100, higher = worse
          const occurrenceFactor = (f.affected_percentage || 0) * 2;  // Scale occurrence impact
          return severityFactor + occurrenceFactor;
        }};

        // Get all red findings (Critical)
        const allReds = findings
          .filter(f => getColorType(f) === 'critical')
          .sort((a, b) => getPriority(b) - getPriority(a));  // Higher priority first

        // Get all yellow findings (Warnings)
        const allYellows = findings
          .filter(f => getColorType(f) === 'warning')
          .sort((a, b) => getPriority(b) - getPriority(a));  // Higher priority first

        // Take up to 2 reds, then fill remaining slots with yellows to reach 3 total
        const TARGET_PROBLEM_FINDINGS = 3;
        const reds = allReds.slice(0, 2).map(f => ({{ ...f, type: 'critical' }}));
        const remainingSlots = TARGET_PROBLEM_FINDINGS - reds.length;
        const yellows = allYellows.slice(0, remainingSlots).map(f => ({{ ...f, type: 'warning' }}));

        // Get green findings (ok- high/critical impact with high score)
        const greens = findings
          .filter(f => getColorType(f) === 'good')
          .sort((a, b) => (b.score || 0) - (a.score || 0))
          .slice(0, 2)
          .map(f => ({{ ...f, type: 'good' }}));

        return [...reds, ...yellows, ...greens];
      }}, [findings]);

      return React.createElement('div', null,
        // Executive Summary Section (if available)
        executive_summary && executive_summary.verdict ? React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px' }} }},
          React.createElement('h2', {{ className: 'card-title' }}, 'Overall Verdict'),
          React.createElement('div', {{ style: {{ padding: '16px', background: '#f8f6f1', borderRadius: '8px', marginBottom: '16px' }} }},
            React.createElement('p', {{ style: {{ fontSize: '16px', fontWeight: '500', color: '#4d4d42' }} }}, executive_summary.verdict)
          )
        ) : null,

        // Main Grid: Gauge + Details
        React.createElement('div', {{ className: 'main-grid' }},
          // Left: Pass Rate Gauge
          React.createElement('div', {{ className: 'gauge-container' }},
            React.createElement('p', {{ className: 'gauge-title', style: {{ display: 'flex', alignItems: 'center', justifyContent: 'center' }} }},
              React.createElement('span', null, 'Pass Rate (%)'),
              React.createElement('div', {{ className: 'tooltip-container' }},
                React.createElement('div', {{ className: 'info-icon' }}, 'i'),
                React.createElement('div', {{ className: 'tooltip-content' }},
                  React.createElement('strong', {{ style: {{ color: 'white' }} }}, 'About Pass Rate: '),
                  'Percentage of conversations with no critical failures. For example, if 8 out of 10 conversations had no critical errors, the pass rate would be 80%.'
                )
              )
            ),
            React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '32px', height: 'auto', minHeight: '470px', alignItems: 'center', width: '100%' }} }},
              React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '16px', alignItems: 'center', paddingTop: '12px', width: '100%' }} }},
                React.createElement(GaugeChart, {{ value: Number(executive_summary.pass_rate) || 0 }}),
                stats?.aggregated_metrics ? React.createElement(AggregatedMetricsChart, {{
                  metrics: stats.aggregated_metrics,
                  definitions: metadata?.metric_definitions
                }}) : null,
                stats?.response_length ? React.createElement(ResponseLengthChart, {{ data: stats.response_length }}) : null,
                stats?.latency ? React.createElement(LatencyChart, {{ data: stats.latency }}) : null
              )
            )
          ),

          // Right: Executive Summary, Score, Test Details
          React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', width: '779px' }} }},
            // Executive Summary - Dynamic content from report data
            executive_summary?.high_level_summary ? React.createElement('div', {{ className: 'score-section' }},
              React.createElement('h2', {{ className: 'card-title' }}, 'Executive Summary'),
              executive_summary.high_level_summary ? React.createElement('div', {{ className: 'findings-list' }},
                // Convert high_level_summary object to array for rendering
                Object.entries(executive_summary.high_level_summary).map(([key, item], index) =>
                  React.createElement('div', {{ key: key, className: 'finding-item' }},
                    React.createElement('div', {{ className: 'finding-bullet' }}, '•'),
                    React.createElement('div', {{ className: 'finding-content' }},
                      React.createElement('strong', null, item.title || key),
                      React.createElement('div', {{
                        className: 'finding-description markdown-content',
                        dangerouslySetInnerHTML: {{ __html: window.marked ? marked.parse(item.description || item || '') : (item.description || item) }}
                      }})
                    )
                  )
                )
              ) : (Array.isArray(executive_summary.behavioral_score_description) ? React.createElement('div', {{ className: 'findings-list' }},
                executive_summary.behavioral_score_description.map((bullet, index) =>
                  React.createElement('div', {{ key: index, className: 'finding-item' }},
                    React.createElement('div', {{ className: 'finding-bullet' }}, '•'),
                    React.createElement('div', {{ className: 'finding-content' }},
                      typeof bullet === 'object' && bullet.title ? React.createElement('div', null,
                        React.createElement('strong', null, bullet.title + ': '),
                        React.createElement('span', {{ style: {{ fontSize: '14px', lineHeight: '1.6', color: '#4d4d42' }} }}, bullet.description)
                      ) : React.createElement('div', {{ style: {{ fontSize: '14px', lineHeight: '1.6', color: '#4d4d42' }} }}, bullet)
                    )
                  )
                )
              ) : React.createElement('p', {{ style: {{ fontSize: '14px', lineHeight: '1.6', color: '#4d4d42' }} }},
                executive_summary.behavioral_score_description
              ))
            ) : null,

            // Test Details
            React.createElement('div', {{ className: 'score-section' }},
              React.createElement('h2', {{ className: 'card-title' }}, 'Test Details'),
              React.createElement('ul', {{ className: 'test-details' }},
                React.createElement('li', null,
                  React.createElement('strong', null, `${{metadata.total_personas}}`),
                  ' Conversations'
                ),
                React.createElement('li', null,
                  React.createElement('strong', null, `${{metadata.total_scenarios}}`),
                  ' Multi-step messages'
                ),
                React.createElement('li', null,
                  React.createElement('strong', null, `${{stats?.aggregated_metrics?.evals?.total_findings || detailedFindingsForCount.length}}`),
                  ' Findings'
                ),
                executive_summary.test_details ? React.createElement('li', null,
                  React.createElement('strong', null, `${{executive_summary.test_details.persona_count}} Personas:`),
                  ' ',
                  executive_summary.test_details.persona_names.slice(0, 5).join(', '),
                  executive_summary.test_details.persona_names.length > 5 ? `, and ${{executive_summary.test_details.persona_names.length - 5}} more` : ''
                ) : null,
                executive_summary.test_details ? React.createElement('li', null,
                  'Tested across ',
                  React.createElement('strong', null, `${{executive_summary.test_details.category_count}} categories`),
                  executive_summary.test_details.category_names.length > 0 ? ` (${{executive_summary.test_details.category_names.slice(0, 5).join(', ')}}` : '',
                  executive_summary.test_details.category_names.length > 5 ? ', ...' : '',
                  executive_summary.test_details.category_names.length > 0 ? ')' : ''
                ) : null
              )
            )
          )
        )
      );
    }}





    function FindingsView({{ onCategoryClick, onNavigateToConversation }}) {{
      // Helper to format persona names - keeps instance numbers for differentiation
      const formatName = (str) => {{
        if (!str) return '';
        // Format underscore-separated persona IDs nicely, preserving instance numbers
        // e.g., "nice_employee_06" -> "Nice Employee 06"
        return str
             .split('_')
             .map(word => word.charAt(0).toUpperCase() + word.slice(1))
             .join(' ');
      }};

      // Helper to get color type based on label (not score)
      const getColorType = (finding) => {{
        const label = finding.label?.toLowerCase() || '';
        if (label === LABELS.critical.toLowerCase()) return 'critical';
        if (label === LABELS.warning.toLowerCase()) return 'warning';
        if (label === LABELS.good.toLowerCase()) return 'good';
        return 'warning';
      }};

      // Use UNCONSOLIDATED findings (same as Conversations tab) for consistent counting
      // Apply same counting logic as Conversations tab:
      // - Turn-based findings (with turn_number): include all
      // - Conversation-level findings (without turn_number): only include Critical
      const allDetailedFindings = getAllDetailedFindings();
      const allFindings = allDetailedFindings
        .filter(f => {{
          const hasTurnNumber = f.evidence?.turn_number != null;
          const isCritical = getColorType(f) === 'critical';
          // Include if turn-based OR (conversation-level AND critical)
          return hasTurnNumber || isCritical;
        }});

      // Prepare key findings for display
      // Uses pre-selected featured_finding_ids from report_data.json (selected by LLM for domain relevance, data quality, etc.)
      // Falls back to client-side selection if featured_finding_ids not available
      const keyFindings = React.useMemo(() => {{
        if (!allFindings || allFindings.length === 0) return [];

        // Check if we have pre-selected featured findings from report_data.json
        const featuredIds = REPORT_DATA.featured_finding_ids || [];

        if (featuredIds.length > 0) {{
          // Use pre-selected findings - look up in CONSOLIDATED key_findings list
          // These are LLM-consolidated findings with count, instances, and occurrence info
          const consolidatedFindings = getAllFindings();
          const featuredFindings = featuredIds
            .slice(0, 5)  // Limit to 5 key findings
            .map(id => consolidatedFindings.find(f => f.id === id))
            .filter(Boolean)
            .map(f => ({{ ...f, type: getColorType(f) }}));

          if (featuredFindings.length > 0) {{
            return featuredFindings;
          }}
        }}

        // Fallback: client-side selection (for backwards compatibility)
        // Target: 4 problem findings (red + yellow)
        // Priority score: heavily weight frequency (unique_sources/affected_conversations)
        const totalConversations = REPORT_DATA.conversations?.length || 1;
        const getPriority = (f) => {{
          const severityFactor = 100 - (f.score || 0);  // 0-100, higher = worse
          // Frequency is the key factor - how many conversations affected
          const affectedConvs = f.affected_conversations || f.unique_sources ||
            (f.instances ? new Set(f.instances.map(i => i.source)).size : 1);
          const frequencyPercent = (affectedConvs / totalConversations) * 100;
          // Weight frequency heavily: a finding in 50% of convos gets +150 points
          const frequencyFactor = frequencyPercent * 3;
          return severityFactor + frequencyFactor;
        }};

        // Get all red findings (Critical) - sorted by frequency first, then severity
        const allReds = allFindings
          .filter(f => getColorType(f) === 'critical')
          .sort((a, b) => getPriority(b) - getPriority(a));

        // Get all yellow findings (Warnings) - frequency is even more important for warnings
        const allYellows = allFindings
          .filter(f => getColorType(f) === 'warning')
          .sort((a, b) => getPriority(b) - getPriority(a));

        // Take up to 2 reds, then fill remaining slots with yellows to reach 3 total
        const TARGET_PROBLEM_FINDINGS = 3;
        const reds = allReds.slice(0, 2).map(f => ({{ ...f, type: 'critical' }}));
        const remainingSlots = TARGET_PROBLEM_FINDINGS - reds.length;
        const yellows = allYellows.slice(0, remainingSlots).map(f => ({{ ...f, type: 'warning' }}));

        return [...reds, ...yellows];
      }}, [allFindings]);

      // Show empty state if no findings available
      if (allFindings.length === 0) {{
        return React.createElement('div', {{ className: 'card', style: {{ padding: '60px 40px', textAlign: 'center' }} }},
          React.createElement('i', {{ className: 'ph ph-chart-line-up', style: {{ fontSize: '64px', color: '#e5e5e0', marginBottom: '16px' }} }}),
          React.createElement('h3', {{ style: {{ fontSize: '20px', fontWeight: '600', marginBottom: '8px', color: '#4d4d42' }} }}, 'No Findings Available'),
          React.createElement('p', {{ style: {{ fontSize: '14px', color: '#7a7a70', maxWidth: '400px', margin: '0 auto' }} }},
            'No detailed findings were generated for this report.'
          )
        );
      }}

      // Group findings by the 4 predefined top-level categories only
      // Categories: Security and Compliance, Information Accuracy, User Experience, Feature Completeness
      const PREDEFINED_CATEGORIES = ['{CATEGORY_SECURITY}', '{CATEGORY_ACCURACY}', '{CATEGORY_UX}', '{CATEGORY_FEATURE}'];
      const categoryMap = {{}};
      // Initialize all predefined categories (even if empty)
      PREDEFINED_CATEGORIES.forEach(cat => {{
        categoryMap[cat] = [];
      }});
      allFindings.forEach(finding => {{
        const rawCategory = finding.category || 'Uncategorized';
        // Only use predefined categories - map unknown to closest or skip
        const normalizedCategory = PREDEFINED_CATEGORIES.includes(rawCategory) ? rawCategory : null;
        if (normalizedCategory) {{
          categoryMap[normalizedCategory].push(finding);
        }}
      }});

      // Calculate aggregated scores per category
      const categoryAggregates = Object.keys(categoryMap).map(categoryName => {{
        // ALWAYS use the normalized findings list (fixes bug where backend category name collisions hid findings)
        const findings = categoryMap[categoryName];
        const scores = findings.map(f => f.score || 0);
        const avgScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

        // Calculate counts using same logic as Conversations:
        // - Turn-based findings (with turn_number): count all colors
        // - Conversation-level findings (without turn_number): only count Critical (red)
        const turnBasedFindings = findings.filter(f => f.evidence?.turn_number != null);
        const conversationLevelFindings = findings.filter(f => f.evidence?.turn_number == null);
        const criticalConversationFindings = conversationLevelFindings.filter(f => getColorType(f) === 'critical');

        // Include critical conversation-level findings in red count
        const redCount = turnBasedFindings.filter(f => getColorType(f) === 'critical').length + criticalConversationFindings.length;
        const yellowCount = turnBasedFindings.filter(f => getColorType(f) === 'warning').length;
        const greenCount = turnBasedFindings.filter(f => getColorType(f) === 'good').length;

        // Total countable findings for pass rate calculation
        const countableFindings = turnBasedFindings.length + criticalConversationFindings.length;

        // Calculate pass rate (green findings / total countable)
        const passRate = countableFindings > 0
          ? Math.round((greenCount / countableFindings) * 100)
          : 0;

        // Calculate risk density (red + yellow findings / total countable)
        const riskDensity = countableFindings > 0
          ? Math.round(((redCount + yellowCount) / countableFindings) * 100)
          : 0;

        // Calculate coverage (we'll use 90% as baseline for now - all dimensions tested)
        const coverage = 90;

        // Calculate consistency (variance in scores)
        const variance = scores.length > 1
          ? Math.sqrt(scores.reduce((sum, score) => sum + Math.pow(score - avgScore, 2), 0) / scores.length)
          : 0;
        const consistency = Math.max(0, 100 - Math.round(variance));

        // Determine label based on color distribution
        const label = redCount > 0 ? LABELS.critical.toLowerCase() : yellowCount > 0 ? LABELS.warning.toLowerCase() : LABELS.good.toLowerCase();

        // Create description based on category name
        const descriptions = {{
          '{CATEGORY_SECURITY}': 'Security issues, RBAC violations, data protection, privacy, jailbreak attempts.',
          '{CATEGORY_ACCURACY}': 'Hallucinations, fabricated data, contradictions, fact-checking issues. Source verification, confidence scoring, citation requirements.',
          '{CATEGORY_UX}': 'Response quality, conversation flow, tone, clarity, helpfulness, boundary enforcement, context awareness.',
          '{CATEGORY_FEATURE}': 'Missing functionality, integration issues, technical limitations, error handling and recovery.'
        }};

        const description = descriptions[categoryName] || 'Testing results and metrics';

        // Count total findings (unconsolidated - each finding is one instance)
        const totalFindings = findings.length;

        return {{
          category_name: categoryName,
          score: Math.round(avgScore),
          label: label,
          findings_count: totalFindings,  // Total findings count (after filtering)
          description: description,
          findings: findings,
          pass_rate: passRate,
          risk_density: riskDensity,
          coverage: coverage,
          consistency: consistency,
          red_count: redCount,
          yellow_count: yellowCount,
          green_count: greenCount
        }};
      }})
      .filter(cat => cat.findings_count > 0)  // Only show categories with findings
      .sort((a, b) => a.category_name.localeCompare(b.category_name));



      const getPassRateColor = (rate) => {{
        if (rate >= THRESHOLDS.good) return COLORS.good;
        if (rate >= THRESHOLDS.pass) return COLORS.warning;
        return COLORS.critical;
      }};

      // Get Key Questions and Key Risks from report data
      const keyQuestions = REPORT_DATA.key_questions || [];
      const keyRisks = REPORT_DATA.key_risks || [];

      // Helper to render a single question/risk item (same style as Key Findings)
      const renderQuestionRiskItem = (item, index) => {{
        const colorType = item.label?.toLowerCase() === 'critical' ? 'critical' :
                         item.label?.toLowerCase() === 'warning' ? 'warning' : 'good';
        const verdictColor = item.verdict === 'PASS' ? COLORS.good :
                            item.verdict === 'FAIL' ? COLORS.critical :
                            item.verdict === 'PARTIAL' ? COLORS.warning : '#7a7a70';
        const verdictIcon = item.verdict === 'PASS' ? 'ph-check-circle' :
                           item.verdict === 'FAIL' ? 'ph-x-circle' :
                           item.verdict === 'PARTIAL' ? 'ph-warning-circle' : 'ph-question';

        return React.createElement('div', {{ key: index, className: 'finding-item' }},
          // Icon (same as Key Findings)
          React.createElement('i', {{
            className: `ph ${{colorType === 'critical' ? 'ph-warning' : colorType === 'warning' ? 'ph-warning-circle' : 'ph-shield-check'}} finding-icon ${{colorType}}`
          }}),
          React.createElement('div', {{ className: 'finding-content' }},
            // Title with verdict badge
            React.createElement('div', {{
              style: {{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '12px' }}
            }},
              React.createElement('strong', null, item.title),
              React.createElement('div', {{
                style: {{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '2px 8px',
                  borderRadius: '12px',
                  backgroundColor: `${{verdictColor}}15`,
                  color: verdictColor,
                  fontSize: '11px',
                  fontWeight: '600',
                  flexShrink: 0
                }}
              }},
                React.createElement('i', {{ className: `ph ${{verdictIcon}}`, style: {{ fontSize: '12px' }} }}),
                item.verdict || 'N/A'
              )
            ),
            // Question/Risk context box (moved before description)
            React.createElement('div', {{
              style: {{
                marginTop: '8px',
                padding: '8px 12px',
                backgroundColor: '#f8f8f6',
                borderRadius: '6px',
                fontSize: '12px',
                color: '#7a7a70'
              }}
            }},
              React.createElement('div', {{ style: {{ fontWeight: '600', marginBottom: '4px', color: '#4d4d42' }} }},
                item.item_type === 'question' ? '❓ Question:' : '⚠️ Risk:'
              ),
              React.createElement('div', {{ style: {{ fontStyle: 'italic' }} }}, item.item_name),
              item.item_priority && React.createElement('div', {{
                style: {{ marginTop: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}
              }},
                'Priority: ',
                React.createElement('span', {{
                  style: {{
                    fontWeight: '600',
                    color: item.item_priority === 'critical' ? COLORS.critical :
                           item.item_priority === 'high' ? COLORS.warning : '#4d4d42'
                  }}
                }}, item.item_priority)
              )
            ),
            // Description with markdown support (renders bullet points)
            React.createElement('div', {{
              className: 'finding-description markdown-content',
              style: {{ marginTop: '12px' }},
              dangerouslySetInnerHTML: {{ __html: window.marked ? marked.parse(item.description || '') : item.description }}
            }}),
            // Stats row (Occurrences style)
            (item.count > 0 || item.unique_sources > 0) && React.createElement('div', {{
              style: {{ marginTop: '12px' }}
            }},
              React.createElement('div', {{
                style: {{ fontSize: '11px', fontWeight: '600', color: '#7a7a70', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}
              }}, `Evidence (${{item.count || 0}} findings):`),
              React.createElement('div', {{
                style: {{ fontSize: '12px', color: '#7a7a70', fontStyle: 'italic' }}
              }}, `Found in ${{item.unique_sources || 0}} out of ${{REPORT_DATA.conversations?.length || 0}} conversations`)
            )
          )
        );
      }};

      return React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '24px' }} }},
        // Main grid (Key Findings + Dimension cards)
        React.createElement('div', {{
          style: {{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '24px',
            alignItems: 'start'
          }}
        }},
        // Left side - Key Findings
        React.createElement('div', {{
          className: 'card',
          style: {{
            position: 'sticky',
            top: '24px',
            padding: '24px'
          }}
        }},
          React.createElement('h2', {{ className: 'card-title' }}, 'Key Findings'),
          React.createElement('div', {{ className: 'findings-list' }},
            keyFindings.map((finding, i) => {{
              const colorType = getColorType(finding);
              return React.createElement('div', {{ key: i, className: 'finding-item' }},
                React.createElement('i', {{
                  className: `ph ${{colorType === 'critical' ? 'ph-warning' : colorType === 'warning' ? 'ph-warning-circle' : colorType === 'good' ? 'ph-shield-check' : 'ph-circle'}} finding-icon ${{colorType}}`
                }}),
                React.createElement('div', {{ className: 'finding-content' }},
                  React.createElement('strong', null, finding.title),
                  React.createElement('div', {{
                    className: 'finding-description markdown-content',
                    dangerouslySetInnerHTML: {{ __html: window.marked ? marked.parse(finding.description || finding.impact || '') : (finding.description || finding.impact) }}
                  }}),

                  // Render links to conversations
                  (finding.instances && finding.instances.length > 1) ? (
                    // Multiple instances - prefer turn-level findings, deduplicate by persona+turn
                    (() => {{
                      // Filter out non-linkable sources like Cross-Conversation Analysis
                      const linkableInstances = finding.instances.filter(inst =>
                        inst.source &&
                        inst.source !== 'Cross-Conversation Analysis' &&
                        inst.source !== 'cross_conversation'
                      );

                      if (linkableInstances.length === 0) {{
                        return null; // No linkable instances
                      }}

                      // Sort instances: turn-level findings first, then conversation-level
                      const sortedInstances = [...linkableInstances].sort((a, b) => {{
                        const aHasTurn = (a.turn != null) || (a.evidence?.turn_number != null);
                        const bHasTurn = (b.turn != null) || (b.evidence?.turn_number != null);
                        if (aHasTurn && !bHasTurn) return -1;
                        if (!aHasTurn && bHasTurn) return 1;
                        return 0;
                      }});

                      // Deduplicate: prefer turn-specific over conversation-level for same source
                      const seenKeys = new Set();
                      const seenSources = new Set(); // Track sources that have turn-specific findings
                      const uniqueInstances = sortedInstances.filter(inst => {{
                        if (!inst.source) return false;
                        const turnNum = inst.turn ?? inst.evidence?.turn_number ?? null;

                        // If this is a turn-specific finding, mark source as having turn data
                        if (turnNum !== null) {{
                          const key = `${{inst.source}}::${{turnNum}}`;
                          if (seenKeys.has(key)) return false;
                          seenKeys.add(key);
                          seenSources.add(inst.source);
                          return true;
                        }} else {{
                          // For conversation-level findings, skip if we already have turn-specific data for this source
                          if (seenSources.has(inst.source)) return false;
                          const key = `${{inst.source}}::conv`;
                          if (seenKeys.has(key)) return false;
                          seenKeys.add(key);
                          return true;
                        }}
                      }});
                      const displayInstances = uniqueInstances.slice(0, 3);
                      // Show remaining count based on unique destinations (not total duplicates)
                      // But also show total occurrence count if there are more occurrences than unique links
                      const remainingUniqueCount = uniqueInstances.length - displayInstances.length;
                      const totalInstanceCount = finding.count || finding.instances.length;

                      return React.createElement('div', {{ style: {{ marginTop: '8px', display: 'flex', flexDirection: 'column', gap: '4px' }} }},
                        React.createElement('div', {{ style: {{ fontSize: '11px', fontWeight: '600', color: '#7a7a70', textTransform: 'uppercase', letterSpacing: '0.5px' }} }},
                          totalInstanceCount > 1 ? `Occurrences (${{totalInstanceCount}}):` : 'Occurrences:'
                        ),
                        displayInstances.map((inst, idx) => {{
                          const turnNum = inst.turn ?? inst.evidence?.turn_number ?? null;
                          // Keep full source name with instance number for clarity
                          const sourceName = formatName(inst.source);
                          const label = turnNum ? `${{sourceName}} (turn ${{turnNum}})` : sourceName;
                          return inst.source && onNavigateToConversation && React.createElement('div', {{
                            key: idx,
                            style: {{
                              cursor: 'pointer',
                              color: '#ff8e53',
                              textDecoration: 'none',
                              fontWeight: '500',
                              fontSize: '12px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '4px',
                              paddingLeft: '8px',
                              borderLeft: '2px solid #ff8e5333'
                            }},
                            onClick: () => {{
                              const conversation = REPORT_DATA.conversations.find(c =>
                                c.persona_id === inst.source
                              );
                              if (conversation) {{
                                onNavigateToConversation(conversation, turnNum, finding);
                              }}
                            }}
                          }},
                            React.createElement('span', null, label)
                          );
                        }}),
                        remainingUniqueCount > 0 && React.createElement('div', {{ style: {{ fontSize: '11px', color: '#7a7a70', paddingLeft: '10px' }} }}, `+${{remainingUniqueCount}} more`),
                        // Frequency line - show how many conversations this finding appeared in
                        (() => {{
                          const totalConversations = REPORT_DATA.conversations?.length || 0;
                          const affectedConversations = finding.affected_conversations || new Set(finding.instances?.map(i => i.source)).size || 1;
                          if (totalConversations > 0) {{
                            return React.createElement('div', {{
                              style: {{ fontSize: '12px', color: '#7a7a70', marginTop: '8px', fontStyle: 'italic' }}
                            }}, `Frequency: ${{affectedConversations}} out of ${{totalConversations}} conversations`);
                          }}
                          return null;
                        }})()
                      );
                    }})()
                  ) : (
                    // Single instance (fallback) - wrap in fragment to include frequency
                    React.createElement(React.Fragment, null,
                      finding.source && onNavigateToConversation && React.createElement('div', {{
                        style: {{
                          marginTop: '8px',
                          cursor: 'pointer',
                          color: '#ff8e53',
                          textDecoration: 'none',
                          fontWeight: '600',
                          fontSize: '13px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px'
                        }},
                        onClick: () => {{
                          const conversation = REPORT_DATA.conversations.find(c =>
                            c.persona_id === finding.source
                          );
                          if (conversation) {{
                            const turn_number = finding.evidence?.turn_number || null;
                            onNavigateToConversation(conversation, turn_number, finding);
                          }}
                        }}
                      }},
                        React.createElement('i', {{ className: 'ph ph-chat-circle-text' }}),
                        React.createElement('span', null, 'View in Conversation')
                      ),
                      // Frequency line for single instance
                      (() => {{
                        const totalConversations = REPORT_DATA.conversations?.length || 0;
                        const affectedConversations = finding.affected_conversations || 1;
                        if (totalConversations > 0) {{
                          return React.createElement('div', {{
                            style: {{ fontSize: '12px', color: '#7a7a70', marginTop: '8px', fontStyle: 'italic' }}
                          }}, `Frequency: ${{affectedConversations}} out of ${{totalConversations}} conversations`);
                        }}
                        return null;
                      }})()
                    )
                  )
                )
              );
            }})
          )
        ),

        // Right side - Dimension cards
        React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '16px' }} }},
          categoryAggregates.map((cat, idx) => {{
            const passRateColor = getPassRateColor(cat.pass_rate);
            return React.createElement('div', {{
              key: idx,
              className: 'card',
              style: {{
                cursor: 'pointer',
                transition: 'all 0.2s',
                padding: '20px',
                border: '1px solid #e5e5e0'
              }},
              onClick: () => onCategoryClick(cat),
              onMouseEnter: (e) => {{
                e.currentTarget.style.transform = 'translateX(4px)';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
              }},
              onMouseLeave: (e) => {{
                e.currentTarget.style.transform = 'translateX(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            }},
              // Title and pass rate
              React.createElement('div', {{
                style: {{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  marginBottom: '12px'
                }}
              }},
                React.createElement('div', null,
                  React.createElement('h3', {{
                    style: {{
                      fontSize: '18px',
                      fontWeight: '600',
                      marginBottom: '4px',
                      color: '#2d2d29'
                    }}
                  }}, cat.category_name),
                  React.createElement('p', {{
                    style: {{
                      fontSize: '13px',
                      color: '#7a7a70',
                      lineHeight: '1.4'
                    }}
                  }}, cat.description)
                )
              ),

              // Metrics row
              React.createElement('div', {{
                style: {{
                  display: 'flex',
                  gap: '20px',
                  marginTop: '16px',
                  paddingTop: '16px',
                  borderTop: '1px solid #f0f0ed',
                  fontSize: '12px'
                }}
              }},
                React.createElement('div', null,
                  React.createElement('div', {{
                    style: {{ color: '#7a7a70', marginBottom: '4px' }}
                  }}, 'Total Findings'),
                  React.createElement('div', {{
                    style: {{ fontWeight: '600', color: '#2d2d29', fontSize: '14px' }}
                  }}, cat.findings_count)
                ),
                cat.red_count > 0 && React.createElement('div', null,
                  React.createElement('div', {{
                    style: {{ color: '#7a7a70', marginBottom: '4px' }}
                  }}, '🔴 ' + LABELS.critical),
                  React.createElement('div', {{
                    style: {{ fontWeight: '600', color: COLORS.critical, fontSize: '14px' }}
                  }}, cat.red_count)
                ),
                cat.yellow_count > 0 && React.createElement('div', null,
                  React.createElement('div', {{
                    style: {{ color: '#7a7a70', marginBottom: '4px' }}
                  }}, '🟡 ' + LABELS.warning),
                  React.createElement('div', {{
                    style: {{ fontWeight: '600', color: COLORS.warning, fontSize: '14px' }}
                  }}, cat.yellow_count)
                ),
                cat.green_count > 0 && React.createElement('div', null,
                  React.createElement('div', {{
                    style: {{ color: '#7a7a70', marginBottom: '4px' }}
                  }}, '🟢 ' + LABELS.good),
                  React.createElement('div', {{
                    style: {{ fontWeight: '600', color: COLORS.good, fontSize: '14px' }}
                  }}, cat.green_count)
                )
              )
            );
          }})
        )
        ), // End of main grid

        // Key Questions Section (if available)
        keyQuestions.length > 0 && React.createElement('div', {{
          className: 'card',
          style: {{ padding: '24px' }}
        }},
          React.createElement('h2', {{ className: 'card-title', style: {{ marginBottom: '16px' }} }},
            React.createElement('i', {{ className: 'ph ph-question', style: {{ marginRight: '8px', color: '#ff8e53' }} }}),
            'Key Questions (',
            keyQuestions.length,
            ')'
          ),
          React.createElement('p', {{
            style: {{ fontSize: '13px', color: '#7a7a70', marginBottom: '20px' }}
          }}, 'Evaluation of test suite questions - how well did the chatbot answer key questions?'),
          React.createElement('div', {{ className: 'findings-list' }},
            keyQuestions.map(renderQuestionRiskItem)
          )
        ),

        // Key Risks Section (if available)
        keyRisks.length > 0 && React.createElement('div', {{
          className: 'card',
          style: {{ padding: '24px' }}
        }},
          React.createElement('h2', {{ className: 'card-title', style: {{ marginBottom: '16px' }} }},
            React.createElement('i', {{ className: 'ph ph-warning-octagon', style: {{ marginRight: '8px', color: COLORS.critical }} }}),
            'Key Risks (',
            keyRisks.length,
            ')'
          ),
          React.createElement('p', {{
            style: {{ fontSize: '13px', color: '#7a7a70', marginBottom: '20px' }}
          }}, 'Assessment of test suite risks - how well did the chatbot mitigate identified risks?'),
          React.createElement('div', {{ className: 'findings-list' }},
            keyRisks.map(renderQuestionRiskItem)
          )
        )
      ); // End of parent container
    }}

    function CategoryDetailView({{ category, onBack, onNavigateToConversation, backButtonText }}) {{
      // Filter: Just sort by score ascending (lowest/worst first)
      const findings = (category.findings || [])
        .sort((a, b) => (a.score || 0) - (b.score || 0));

      const scores = findings.map(f => f.score || 0);
      const avgScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

      // Get color type from finding label for consistent color coding
      const getColorType = (finding) => {{
        const label = finding.label?.toLowerCase() || '';
        if (label === LABELS.critical.toLowerCase()) return 'critical';
        if (label === LABELS.warning.toLowerCase()) return 'warning';
        if (label === LABELS.good.toLowerCase()) return 'good';
        return 'warning';
      }};

      // Get plain business impact color (for badges, not findings)
      const getBusinessImpactColor = (businessImpact) => {{
        const colors = {{
          [LABELS.critical.toLowerCase()]: COLORS.critical,
          [LABELS.warning.toLowerCase()]: COLORS.warning,
          [LABELS.good.toLowerCase()]: COLORS.good
        }};
        return colors[businessImpact?.toLowerCase()] || COLORS.warning;
      }};

      const getScoreColor = (score) => {{
        if (score >= THRESHOLDS.good) return COLORS.good;
        if (score >= THRESHOLDS.pass) return COLORS.warning;
        return COLORS.critical;
      }};

      const getScoreLabel = (score) => {{
        if (score >= THRESHOLDS.good) return LABELS.good;
        if (score >= THRESHOLDS.pass) return LABELS.warning;
        return LABELS.critical;
      }};

      // Calculate color-based breakdown using same logic as Conversations:
      // - Turn-based findings (with turn_number): count all colors
      // - Conversation-level findings (without turn_number): only count Critical (red)
      const turnBasedFindings = findings.filter(f => f.evidence?.turn_number != null);
      const conversationLevelFindings = findings.filter(f => f.evidence?.turn_number == null);
      const criticalConversationFindings = conversationLevelFindings.filter(f => getColorType(f) === 'critical');

      // Include critical conversation-level findings in red count
      const redCount = turnBasedFindings.filter(f => getColorType(f) === 'critical').length + criticalConversationFindings.length;
      const yellowCount = turnBasedFindings.filter(f => getColorType(f) === 'warning').length;
      const greenCount = turnBasedFindings.filter(f => getColorType(f) === 'good').length;

      return React.createElement('div', null,
        // Back button
        React.createElement('div', {{
          style: {{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            marginBottom: '24px',
            cursor: 'pointer',
            color: '#7a7a70'
          }},
          onClick: onBack
        }},
          React.createElement('i', {{ className: 'ph ph-arrow-left' }}),
          React.createElement('span', null, backButtonText || 'Back to All Categories')
        ),

        // Header with category name
        React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px' }} }},
          React.createElement('div', {{
            style: {{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              marginBottom: '16px'
            }}
          }},
            React.createElement('div', {{ style: {{ flex: 1 }} }},
              React.createElement('h2', {{ style: {{ fontSize: '28px', marginBottom: '8px' }} }}, category.category_name)
            )
          ),

          // Key metrics row - REMOVED per user request


          // Color-based breakdown (matches finding card colors)
          React.createElement('div', {{
            style: {{
              marginTop: '20px',
              paddingTop: '20px',
              borderTop: '1px solid #e5e5e0'
            }}
          }},
            React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70', marginBottom: '12px', fontWeight: '600' }} }}, 'Severity Breakdown'),
            React.createElement('div', {{
              style: {{
                display: 'flex',
                gap: '16px',
                flexWrap: 'wrap'
              }}
            }},
              redCount > 0 && React.createElement('div', {{
                style: {{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  fontSize: '14px'
                }}
              }},
                React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, '🔴'),
                React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, redCount),
                React.createElement('span', {{ style: {{ color: '#7a7a70' }} }}, LABELS.critical)
              ),
              yellowCount > 0 && React.createElement('div', {{
                style: {{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  fontSize: '14px'
                }}
              }},
                React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, '🟡'),
                React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, yellowCount),
                React.createElement('span', {{ style: {{ color: '#7a7a70' }} }}, LABELS.warning)
              ),
              greenCount > 0 && React.createElement('div', {{
                style: {{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  fontSize: '14px'
                }}
              }},
                React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, '🟢'),
                React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, greenCount),
                React.createElement('span', {{ style: {{ color: '#7a7a70' }} }}, LABELS.good)
              )
            )
          )
        ),

        // All Findings (show unconsolidated list with accurate count)
        findings.length > 0 && React.createElement('div', {{ className: 'card' }},
          React.createElement('h3', {{ style: {{ fontSize: '18px', fontWeight: '600', marginBottom: '16px' }} }},
            `All Findings (${{findings.length}})`
          ),
          React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '16px' }} }},
            findings.map((finding, i) => {{
              const findingColorType = getColorType(finding);
              const borderColor = findingColorType === 'critical' ? COLORS.critical : findingColorType === 'warning' ? COLORS.warning : COLORS.good;
              return React.createElement('div', {{
                key: i,
                style: {{
                  padding: '16px',
                  borderLeft: `3px solid ${{borderColor}}`,
                  backgroundColor: '#f8f6f1',
                  borderRadius: '4px'
                }}
              }},
                // Finding header
                React.createElement('div', {{
                  style: {{
                    marginBottom: '8px'
                  }}
                }},
                  React.createElement('div', {{ style: {{ fontWeight: '600', fontSize: '16px' }} }}, finding.title)
                ),

                // Finding summary/description
                finding.description && React.createElement('div', {{
                  className: 'markdown-content',
                  style: {{
                    fontSize: '14px',
                    lineHeight: '1.6',
                    color: '#4d4d42',
                    marginBottom: '12px'
                  }},
                  dangerouslySetInnerHTML: {{ __html: window.marked ? marked.parse(finding.description) : finding.description }}
                }}),

                // Finding metadata - use actual label field, not recalculated from score
                React.createElement('div', {{
                  style: {{
                    display: 'flex',
                    gap: '16px',
                    fontSize: '12px',
                    color: '#7a7a70',
                    marginBottom: '8px',
                    flexWrap: 'wrap'
                  }}
                }},
                  React.createElement('span', null,
                    React.createElement('span', {{ style: {{ textTransform: 'uppercase', fontWeight: '600' }} }}, 'Severity: '),
                    React.createElement('span', {{
                      style: {{
                        color: getColorType(finding) === 'critical' ? COLORS.critical : getColorType(finding) === 'warning' ? COLORS.warning : COLORS.good,
                        fontWeight: '600'
                      }}
                    }}, finding.label || LABELS.warning)
                  ),
                  React.createElement('span', null,
                    React.createElement('span', {{ style: {{ textTransform: 'uppercase', fontWeight: '600' }} }}, 'Confidence: '),
                    typeof finding.confidence === 'number' ? (finding.confidence * 100).toFixed(0) + '%' : (finding.confidence || 'N/A')
                  ),
                  finding.instances && React.createElement('span', null,
                    React.createElement('span', {{ style: {{ textTransform: 'uppercase', fontWeight: '600' }} }}, 'Instances: '),
                    Array.isArray(finding.instances) ? finding.instances.length : finding.instances
                  )
                ),

                // Links to conversations (consolidated view)
                (finding.instances && finding.instances.length > 0 && onNavigateToConversation) ? (
                    React.createElement('div', {{
                      style: {{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '4px',
                        marginTop: '4px',
                        width: '100%',
                        flexBasis: '100%'
                      }}
                    }},
                      finding.instances.map((inst, idx) => {{
                        const conversation = REPORT_DATA.conversations.find(c => c.persona_id === inst.persona);
                        const name = conversation ? conversation.persona_name : inst.persona;
                        // Show turn number only for turn-level findings
                        const linkText = inst.level === 'turn' && inst.turn != null
                          ? `View in ${{name}} (Turn ${{inst.turn}})`
                          : `View in ${{name}}`;
                        return React.createElement('span', {{
                          key: idx,
                          style: {{
                            cursor: 'pointer',
                            color: '#ff8e53',
                            textDecoration: 'none',
                            fontWeight: '600',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px',
                            fontSize: '11px'
                          }},
                          onClick: () => {{
                            if (conversation) {{
                              onNavigateToConversation(conversation, inst.turn, finding);
                            }}
                          }}
                        }},
                          React.createElement('i', {{ className: 'ph ph-chat-circle-text' }}),
                          React.createElement('span', null, linkText)
                        );
                      }})
                    )
                  ) : (
                    finding.source && onNavigateToConversation && React.createElement('div', {{
                      style: {{ marginTop: '4px' }}
                    }}, React.createElement('span', {{
                      style: {{
                        cursor: 'pointer',
                        color: '#ff8e53',
                        textDecoration: 'none',
                        fontWeight: '600',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px'
                      }},
                      onClick: () => {{
                        // Find and navigate to the conversation
                        const conversation = REPORT_DATA.conversations.find(c =>
                          c.persona_id === finding.source
                        );
                        if (conversation) {{
                          // Extract turn number from instances array or evidence object
                          const turn_number = (finding.instances && finding.instances.length > 0)
                            ? finding.instances[0].turn
                            : (finding.evidence?.turn_number || null);
                          console.log('Navigating to conversation with turn:', turn_number, 'finding:', finding);
                          onNavigateToConversation(conversation, turn_number, finding);
                        }} else {{
                          console.error('Conversation not found for source:', finding.source);
                        }}
                      }}
                    }},
                      React.createElement('i', {{ className: 'ph ph-chat-circle-text' }}),
                      React.createElement('span', null, 'View in Conversation')
                    ))
                  )
              );
            }})
          )
        )
      );
    }}

    function ConversationsView({{ onConversationClick }}) {{
      const conversations = REPORT_DATA.conversations || [];

      if (conversations.length === 0) {{
        return React.createElement('div', {{ className: 'card' }},
          React.createElement('p', {{ style: {{ textAlign: 'center', color: '#7a7a70' }} }},
            'No conversation data available. Transcripts will appear here after test execution.'
          )
        );
      }}

      // Helper to get color type based on label (not score)
      const getColorType = (finding) => {{
        const label = finding.label?.toLowerCase() || '';
        if (label === LABELS.critical.toLowerCase()) return 'critical';
        if (label === LABELS.warning.toLowerCase()) return 'warning';
        if (label === LABELS.good.toLowerCase()) return 'good';
        return 'warning';
      }};

      return React.createElement('div', null,
        React.createElement('h2', {{ style: {{ fontSize: '24px', marginBottom: '24px' }} }}, 'Conversations'),
        React.createElement('div', {{ className: 'conversations-grid' }},
          conversations.map((conv) => {{
            const initials = conv.persona_name.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
            const turns = Math.floor((conv.transcript || []).length / 2);

            // Get findings for this conversation (use unconsolidated)
            const allFindings = getAllDetailedFindings();
            const convFindings = allFindings.filter(f => f.source === conv.persona_id);

            // Count findings by color
            // Turn-based findings (visible inline) + Critical conversation-level findings
            const findingsWithTurn = convFindings.filter(f => f.evidence?.turn_number != null);
            const conversationLevelFindings = convFindings.filter(f => f.evidence?.turn_number == null);
            const criticalConversationFindings = conversationLevelFindings.filter(f => getColorType(f) === 'critical');

            // Include critical conversation-level findings in red count
            const redCount = findingsWithTurn.filter(f => getColorType(f) === 'critical').length + criticalConversationFindings.length;
            const yellowCount = findingsWithTurn.filter(f => getColorType(f) === 'warning').length;
            const greenCount = findingsWithTurn.filter(f => getColorType(f) === 'good').length;

            // Show findings if there are any countable findings (turn-based OR conversation-level Critical)
            const hasCountableFindings = findingsWithTurn.length > 0 || criticalConversationFindings.length > 0;

            return React.createElement('div', {{
              key: conv.persona_id,
              className: 'conversation-card',
              onClick: () => onConversationClick(conv)
            }},
              React.createElement('div', {{ className: 'conversation-card-header' }},
                React.createElement('div', {{ className: 'conversation-avatar' }}, initials),
                React.createElement('div', {{ style: {{ flex: 1 }} }},
                  React.createElement('div', {{ className: 'conversation-card-title' }}, conv.persona_name),
                  React.createElement('div', {{ className: 'conversation-card-meta' }},
                    `${{turns}} conversation turns`
                  ),
                  // Finding counts by color - show if there are any countable findings
                  hasCountableFindings && React.createElement('div', {{
                    style: {{
                      display: 'flex',
                      gap: '12px',
                      marginTop: '8px',
                      fontSize: '12px',
                      flexWrap: 'wrap'
                    }}
                  }},
                    redCount > 0 && React.createElement('div', {{
                      style: {{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        color: '#7a7a70'
                      }}
                    }},
                      React.createElement('span', null, '\ud83d\udd34'),
                      React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, redCount)
                    ),
                    yellowCount > 0 && React.createElement('div', {{
                      style: {{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        color: '#7a7a70'
                      }}
                    }},
                      React.createElement('span', null, '\ud83d\udfe1'),
                      React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, yellowCount)
                    ),
                    greenCount > 0 && React.createElement('div', {{
                      style: {{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        color: '#7a7a70'
                      }}
                    }},
                      React.createElement('span', null, '\ud83d\udfe2'),
                      React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, greenCount)
                    )
                  )
                )
              )
            );
          }})
        )
      );
    }}

    // Function to detect if text contains markdown
    function isMarkdown(text) {{
      // Check for common markdown patterns
      const markdownPatterns = [
        /^#{1, 6}\s/m,           // Headers
        /\*\*[^*]+\*\*/,        // Bold
        /\*[^*]+\*/,            // Italic
        /__[^_]+__/,            // Bold (underscore)
        /_[^_]+_/,              // Italic (underscore)
        /`[^`]+`/,              // Inline code
        /```[\s\S]*?```/,       // Code blocks
        /^\s*[-*+]\s/m,         // Unordered lists
        /^\s*\d+\.\s/m,         // Ordered lists
        /^\s*>\s/m,             // Blockquotes
        /\[([^\]]+)\]\(([^)]+)\)/, // Links
        /!\[([^\]]*)\]\(([^)]+)\)/, // Images
        /^\s*---\s*$/m,         // Horizontal rules
        /^\|.*\|$/m,            // Tables
      ];

      return markdownPatterns.some(pattern => pattern.test(text));
    }}

    function ConversationDetailView({{ conversation, onBack, highlightTurn, contextFinding, backButtonText, onFindingClick }}) {{
      const transcript = conversation.transcript || [];

      // Detect welcome message: first message is from assistant without a preceding user message
      const hasWelcomeMessage = transcript.length > 0 && transcript[0].role === 'assistant' && (transcript.length === 1 || transcript[1].role === 'user');
      const welcomeOffset = hasWelcomeMessage ? 1 : 0;
      const totalTurns = Math.floor((transcript.length - welcomeOffset) / 2);

      // Helper functions for color coding
      const getScoreColor = (score) => {{
        if (score >= THRESHOLDS.good) return COLORS.good;
        if (score >= THRESHOLDS.pass) return COLORS.warning;
        return COLORS.critical;
      }};

      const getScoreLabel = (score) => {{
        if (score >= THRESHOLDS.good) return LABELS.good;
        if (score >= THRESHOLDS.pass) return LABELS.warning;
        return LABELS.critical;
      }};

      // Helper to get color type based on label (not score)
      const getColorType = (finding) => {{
        const label = finding.label?.toLowerCase() || '';
        if (label === LABELS.critical.toLowerCase()) return 'critical';
        if (label === LABELS.warning.toLowerCase()) return 'warning';
        if (label === LABELS.good.toLowerCase()) return 'good';
        return 'warning';
      }};

      // Get findings for this conversation (use unconsolidated)
      // NOTE: Invalid turn numbers are already filtered out in report_data_generator.py
      const allFindings = getAllDetailedFindings();
      const convFindings = allFindings.filter(f => f.source === conversation.persona_id);

      // Create a map of turn number to findings
      // Use the LLM-provided turn_number from evidence
      const turnToFindings = {{}};
      convFindings.forEach(finding => {{
        const turnNum = finding.evidence?.turn_number;
        if (turnNum) {{
          if (!turnToFindings[turnNum]) {{
            turnToFindings[turnNum] = [];
          }}
          turnToFindings[turnNum].push(finding);
        }}
      }});

      // Count findings by color
      // Turn-based findings (visible inline) + Critical conversation-level findings
      const findingsWithTurn = convFindings.filter(f => f.evidence?.turn_number != null);
      const conversationLevelFindings = convFindings.filter(f => f.evidence?.turn_number == null);
      const criticalConversationFindings = conversationLevelFindings.filter(f => getColorType(f) === 'critical');

      // Include critical conversation-level findings in red count
      const redCount = findingsWithTurn.filter(f => getColorType(f) === 'critical').length + criticalConversationFindings.length;
      const yellowCount = findingsWithTurn.filter(f => getColorType(f) === 'warning').length;
      const greenCount = findingsWithTurn.filter(f => getColorType(f) === 'good').length;

      // Scroll to highlighted turn after render
      React.useEffect(() => {{
        if (highlightTurn !== null && highlightTurn !== undefined) {{
          const element = document.getElementById(`turn-${{highlightTurn}}`);
          if (element) {{
            element.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
          }}
        }}
      }}, [highlightTurn]);

      // Only use split layout for turn-specific findings
      const showSidePanel = contextFinding && contextFinding.evidence?.turn_number != null;
      const mainContent = React.createElement('div', {{ className: showSidePanel ? 'conversation-detail-main' : null }},
        // Back button
        React.createElement('div', {{
          style: {{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            marginBottom: '24px',
            cursor: 'pointer',
            color: '#7a7a70'
          }},
          onClick: onBack
        }},
          React.createElement('i', {{ className: 'ph ph-arrow-left' }}),
          React.createElement('span', null, backButtonText || 'Back to Conversations')
        ),

        // Header
        React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px' }} }},
          React.createElement('h2', {{ style: {{ fontSize: '28px', marginBottom: '8px' }} }}, conversation.persona_name),
          React.createElement('div', {{ style: {{ marginTop: '16px', fontSize: '14px', color: '#7a7a70' }} }},
            `Total turns: ${{totalTurns}}${{hasWelcomeMessage ? ' (includes welcome message)' : ''}}`
          ),

          // Metrics & Validation Footer
          (conversation.stats || convFindings.length > 0) && React.createElement('div', {{
            style: {{
              marginTop: '20px',
              paddingTop: '20px',
              borderTop: '1px solid #e5e5e0',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '24px'
            }}
          }},
            // Metrics Section
            conversation.stats && React.createElement('div', {{ style: {{ flex: '1 1 300px' }} }},
               React.createElement('div', {{ style: {{ fontSize: '11px', color: '#7a7a70', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '12px', fontWeight: '600' }} }}, 'Metrics'),
               React.createElement('div', {{ style: {{ display: 'flex', gap: '8px 16px', flexWrap: 'wrap' }} }},
                 ...[
                    {{ key: 'factuality', label: 'Factuality', suffix: '%' }},
                    {{ key: 'coherence', label: 'Coherence', suffix: '%' }},
                    {{ key: 'tone_adherence', label: 'Tone', suffix: '%' }},
                    {{ key: 'instruction_following', label: 'Instr. Following', suffix: '%' }},
                    {{ key: 'topic_coverage', label: 'Coverage', suffix: '%' }},
                    {{ key: 'context_retention', label: 'Context Retention', suffix: '%' }},
                    {{ key: 'turn_to_resolution', label: 'Resolution', suffix: '%' }}
                 ]
                 .filter(m => conversation.stats && conversation.stats[m.key] && conversation.stats[m.key].score !== undefined && conversation.stats[m.key].score !== null)
                 .map(m => {{
                    const metric = conversation.stats[m.key];
                    const val = metric.score;
                    const explanation = metric.explanation;
                    let color = '#1f2937';
                    if (m.suffix === '%') color = getScoreColor(val);
                    return React.createElement('div', {{ key: m.key, style: {{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px' }} }},
                        React.createElement('span', {{ style: {{ color: '#525252' }} }}, m.label + ':'),
                        React.createElement('span', {{ style: {{ fontWeight: '600', color: color }} }}, val + m.suffix),
                        explanation && React.createElement('div', {{ className: 'tooltip-container' }},
                            React.createElement('i', {{
                                className: 'ph ph-info',
                                style: {{
                                    cursor: 'help',
                                    color: '#9ca3af',
                                    fontSize: '14px',
                                    display: 'flex',
                                    alignItems: 'center'
                                }}
                            }}),
                            React.createElement('div', {{ className: 'tooltip-content', style: {{ width: '200px', bottom: '100%', left: '50%', marginBottom: '8px', transform: 'translateX(-50%)', marginLeft: '0' }} }}, explanation)
                        )
                    );
                 }})
               )
            ),

            // Findings Section - Severity Breakdown (only turn-based findings)
            findingsWithTurn.length > 0 && React.createElement('div', {{ style: {{ flex: '1 1 300px' }} }},
              React.createElement('div', {{ style: {{ fontSize: '11px', color: '#7a7a70', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '12px', fontWeight: '600' }} }}, 'Evaluation Results'),
              React.createElement('div', {{
                style: {{
                  display: 'flex',
                  gap: '16px',
                  flexWrap: 'wrap'
                }}
              }},
                redCount > 0 && React.createElement('div', {{
                  style: {{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    fontSize: '14px'
                  }}
                }},
                  React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, '🔴'),
                  React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, redCount),
                  React.createElement('span', {{ style: {{ color: '#7a7a70' }} }}, LABELS.critical)
                ),
                yellowCount > 0 && React.createElement('div', {{
                  style: {{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    fontSize: '14px'
                  }}
                }},
                  React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, '🟡'),
                  React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, yellowCount),
                  React.createElement('span', {{ style: {{ color: '#7a7a70' }} }}, LABELS.warning)
                ),
                greenCount > 0 && React.createElement('div', {{
                  style: {{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    fontSize: '14px'
                  }}
                }},
                  React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, '🟢'),
                  React.createElement('span', {{ style: {{ fontWeight: '600' }} }}, greenCount),
                  React.createElement('span', {{ style: {{ color: '#7a7a70' }} }}, LABELS.good)
                )
              )
            )
          )
        ),

        // TLDR summary card
        conversation.tldr && React.createElement('div', {{
          className: 'card',
          style: {{
            marginBottom: '24px',
            backgroundColor: '#fafaf8',
            border: '1px solid #e5e5e0'
          }}
        }},
          React.createElement('div', {{
            style: {{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              marginBottom: '12px'
            }}
          }},
            React.createElement('i', {{
              className: 'ph ph-lightning',
              style: {{ fontSize: '18px', color: '#6366f1' }}
            }}),
            React.createElement('h3', {{
              style: {{
                fontSize: '14px',
                fontWeight: '600',
                color: '#4d4d42',
                margin: 0
              }}
            }}, 'Conversation Summary')
          ),
          React.createElement('div', {{
            className: 'tldr-content',
            style: {{
              fontSize: '14px',
              lineHeight: '1.6',
              color: '#525252'
            }},
            dangerouslySetInnerHTML: {{
              __html: window.marked ? marked.parse(conversation.tldr) : conversation.tldr
            }}
          }})
        ),

        // Critical conversation-level findings section (only Critical findings without turn_number)
        (() => {{
          const criticalConvFindings = convFindings.filter(f => f.evidence?.turn_number == null && getColorType(f) === 'critical');
          if (criticalConvFindings.length === 0) return null;

          return React.createElement('div', {{
            className: 'card',
            style: {{
              marginBottom: '24px',
              backgroundColor: '#fef2f2',
              border: '1px solid #fecaca'
            }}
          }},
            React.createElement('div', {{
              style: {{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                marginBottom: '16px'
              }}
            }},
              React.createElement('i', {{
                className: 'ph ph-warning',
                style: {{ fontSize: '18px', color: '#dc2626' }}
              }}),
              React.createElement('h3', {{
                style: {{
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#991b1b',
                  margin: 0
                }}
              }}, 'Critical Findings')
            ),
            React.createElement('div', {{
              style: {{
                display: 'flex',
                flexDirection: 'column',
                gap: '12px'
              }}
            }},
              criticalConvFindings.map((finding, idx) => {{
                const colorType = getColorType(finding);
                const colorMap = COLOR_TYPES;
                const colors = colorMap[colorType] || colorMap.good;

                return React.createElement('div', {{
                  key: idx,
                  style: {{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '12px',
                    padding: '12px',
                    backgroundColor: colors.bg,
                    borderRadius: '8px',
                    border: `1px solid ${{colors.foreground}}`
                  }}
                }},
                  React.createElement('div', {{
                    style: {{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      backgroundColor: colors.dot,
                      marginTop: '6px',
                      flexShrink: 0
                    }}
                  }}),
                  React.createElement('div', {{
                    style: {{ flex: 1 }}
                  }},
                    React.createElement('div', {{
                      style: {{
                        fontWeight: '600',
                        fontSize: '13px',
                        color: '#1f2937',
                        marginBottom: '4px'
                      }}
                    }}, finding.title),
                    finding.assessment && React.createElement('div', {{
                      style: {{
                        fontSize: '13px',
                        color: '#525252',
                        lineHeight: '1.5'
                      }}
                    }}, finding.assessment)
                  ),
                  React.createElement('div', {{
                    style: {{
                      fontSize: '11px',
                      fontWeight: '600',
                      color: colors.text,
                      textTransform: 'uppercase',
                      flexShrink: 0
                    }}
                  }}, finding.label)
                );
              }})
            )
          );
        }})(),

        // Chat messages
        React.createElement('div', {{ className: 'chat-container' }},
          transcript.map((message, index) => {{
            const isUser = message.role === 'user';
            const avatarText = isUser ? 'U' : 'A';
            // Calculate turn number accounting for welcome message offset
            // Welcome message (index 0) = turn 0, first user-assistant pair = turn 1, etc.
            const turn_number = hasWelcomeMessage && index === 0 ? 0 : Math.floor((index - welcomeOffset) / 2) + 1;
            const isHighlighted = highlightTurn !== null && highlightTurn !== undefined && turn_number === parseInt(highlightTurn);
            const turnFindings = turnToFindings[turn_number] || [];
            const hasFinding = turnFindings.length > 0;

            // Create finding indicators element (shown above assistant message)
            // Findings are about the bot's response, so they belong with the assistant message
            const findingIndicators = !isUser && hasFinding && React.createElement('div', {{
              style: {{
                display: 'flex',
                gap: '4px',
                padding: '8px 0',
                flexWrap: 'wrap'
              }}
            }},
              turnFindings.map((finding, fIdx) => {{
                const colorType = getColorType(finding);
                const colorMap = COLOR_TYPES;
                const colors = colorMap[colorType] || colorMap.good;

                return React.createElement('div', {{
                  key: `${{turn_number}}-${{fIdx}}`,
                  style: {{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '4px',
                    padding: '4px 8px',
                    borderRadius: '4px',
                    backgroundColor: colors.bg,
                    border: `1px solid ${{colors.foreground}}`,
                    fontSize: '11px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    color: '#4d4d42'
                  }},
                  title: finding.title || 'View finding details',
                  onClick: (e) => {{
                    e.stopPropagation();
                    console.log('Badge clicked:', {{ turn_number, fIdx, finding_title: finding.title, finding_id: finding.id }});
                    if (onFindingClick) {{
                      onFindingClick(finding);
                    }}
                  }},
                  onMouseEnter: (e) => {{
                    e.currentTarget.style.transform = 'scale(1.05)';
                    e.currentTarget.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
                  }},
                  onMouseLeave: (e) => {{
                    e.currentTarget.style.transform = 'scale(1)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                }},
                  React.createElement('span', {{ style: {{ fontSize: '10px' }} }}, colors.icon),
                  React.createElement('i', {{ className: `ph ${{colors.iconClass}}`, style: {{ fontSize: '12px' }} }})
                );
              }})
            );

            // For assistant messages, highlight the problematic text if a specific finding is selected
            const assistantHasFinding = !isUser && hasFinding;
            let messageContent = message.text;
            let shouldHighlight = false;

            // Only highlight if there's a contextFinding selected and it matches this turn
            if (assistantHasFinding && contextFinding && contextFinding.evidence?.turn_number === turn_number) {{
              const problematicText = contextFinding.evidence?.chatbot_response || '';

              // If we have problematic text and it appears in the message, highlight it
              if (problematicText && messageContent.includes(problematicText)) {{
                shouldHighlight = true;
                const colorType = getColorType(contextFinding);
                const highlightColors = {{
                  critical: {{ bg: '#fee2e2', border: COLORS.critical }},
                  warning: {{ bg: '#fef3c7', border: COLORS.warning }},
                  good: {{ bg: '#d1fae5', border: COLORS.good }}
                }};
                const colors = highlightColors[colorType] || highlightColors.yellow;

                // First parse markdown if applicable
                if (isMarkdown(messageContent) && window.marked) {{
                  messageContent = marked.parse(messageContent);
                }}

                // Then apply highlighting to the (possibly parsed) HTML
                const escapedProblematicText = problematicText.replace(/[.*+?^${{}}()|[\]\\]/g, '\\$&');
                const highlightRegex = new RegExp(escapedProblematicText, 'g');
                messageContent = messageContent.replace(
                  highlightRegex,
                  `<mark style="background-color: ${{colors.bg}}; border: 1px solid ${{colors.foreground}}; padding: 2px 4px; border-radius: 3px;">${{problematicText}}</mark>`
                );
              }}
            }}

            return React.createElement(React.Fragment, {{ key: index }},
              // Show finding indicators above assistant message (findings are about bot responses)
              findingIndicators,

              // Chat message
              React.createElement('div', {{
                id: `turn-${{turn_number}}`,
                className: `chat-message ${{message.role}}`,
                style: isHighlighted ? {{
                  backgroundColor: '#fffbf0',
                  borderLeft: '3px solid #fbbf24',
                  paddingLeft: '12px',
                  marginLeft: '-12px',
                  transition: 'all 0.3s ease'
                }} : {{}}
              }},
                React.createElement('div', {{
                  className: `chat-avatar ${{message.role}}`
                }}, avatarText),
                React.createElement('div', {{ style: {{ flex: 1 }} }},
                  React.createElement('div', {{
                    className: 'chat-bubble',
                    ...(shouldHighlight
                      ? {{ dangerouslySetInnerHTML: {{ __html: messageContent }} }}
                      : (isMarkdown(message.text) && window.marked
                        ? {{ dangerouslySetInnerHTML: {{ __html: marked.parse(message.text) }} }}
                        : {{ children: message.text }}))
                  }}),
                  React.createElement('div', {{
                    className: 'chat-timestamp',
                    style: isHighlighted ? {{ fontWeight: '500', color: '#d97706' }} : {{}}
                  }},
                    `${{message.timestamp ? new Date(message.timestamp).toLocaleTimeString('en-US', {{ hour: 'numeric', minute: '2-digit', hour12: true }}) : 'N/A'}}` + (isHighlighted ? ' 🎯' : '')
                  ),
                // Screenshot section (if available)
                message.screenshot && React.createElement('div', {{
                  style: {{
                    marginTop: '12px',
                    borderRadius: '8px',
                    overflow: 'hidden',
                    border: '1px solid #e5e5e0',
                    backgroundColor: '#fafaf8'
                  }}
                }},
                  React.createElement('img', {{
                    src: `${{conversation.persona_id}}/${{message.screenshot.replace('.png', '_annotated.png')}}`,
                    onError: (e) => {{
                      // Fallback to original screenshot if annotated version doesn't exist
                      e.target.onerror = null; // prevent infinite loop
                      e.target.src = `${{conversation.persona_id}}/${{message.screenshot}}`;
                    }},
                    alt: `Screenshot for turn ${{turn_number}}`,
                    style: {{
                      width: '100%',
                      display: 'block',
                      cursor: 'pointer'
                    }},
                    onClick: (e) => {{
                      // Open screenshot in new tab when clicked
                      window.open(e.target.src, '_blank');
                    }}
                  }}),
                  React.createElement('div', {{
                    style: {{
                      padding: '8px 12px',
                      fontSize: '12px',
                      color: '#7a7a70',
                      backgroundColor: '#fafaf8',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  }},
                    React.createElement('i', {{ className: 'ph ph-image', style: {{ fontSize: '14px' }} }}),
                    React.createElement('span', null, message.screenshot)
                  )
                ),
                // Findings section (supports both new 'findings' and legacy 'validation_responses' keys)
                (() => {{
                  const findings = message.findings || message.validation_responses || [];
                  return findings.length > 0 && React.createElement('details', {{
                    className: 'findings-collapsible',
                    style: {{
                      marginTop: '12px',
                      backgroundColor: '#f8f9fa',
                      borderRadius: '8px',
                      borderLeft: '3px solid #6366f1',
                      overflow: 'hidden'
                    }}
                  }},
                    React.createElement('summary', {{
                      style: {{
                        padding: '12px',
                        cursor: 'pointer',
                        fontWeight: '600',
                        fontSize: '13px',
                        color: '#4d4d42',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        userSelect: 'none',
                        listStyle: 'none'
                      }}
                    }},
                      React.createElement('i', {{ className: 'ph ph-caret-right', style: {{ transition: 'transform 0.2s' }} }}),
                      `Evaluations (${{findings.length}})`
                    ),
                    React.createElement('div', {{
                      className: 'findings',
                      style: {{
                        padding: '0 12px 12px 12px'
                      }}
                    }},
                    findings.map((validation, vIdx) => {{
                      // Extract fields that should not be displayed (internal fields)
                      const excludedFields = new Set(['validation_id', 'result', 'score', 'result_explanation', 'confidence', 'category', 'eval_type', 'red_flag_id', 'severity', 'screenshot_path', 'evaluation_results']);

                      // Use agent name mapping from report data (data-driven)
                      const agentNameMap = REPORT_DATA.agent_name_map || {{}};

                      // Format field name: convert snake_case to Title Case
                      const formatFieldName = (field) => {{
                        // Special case: agent_id becomes "Agent"
                        if (field === 'agent_id') return 'Agent';
                        return field.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                      }};

                      // Format field value with special handling for agent_id
                      const formatFieldValue = (field, value) => {{
                        if (field === 'agent_id' && agentNameMap[value]) {{
                          return agentNameMap[value];
                        }}
                        return value;
                      }};

                      // Get extra fields (excluding standard ones)
                      const extraFields = Object.keys(validation).filter(key => !excludedFields.has(key));

                      return React.createElement('div', {{
                        key: vIdx,
                        style: {{ marginBottom: vIdx < findings.length - 1 ? '16px' : '0' }}
                      }},
                      // Validation header
                      (() => {{
                        const isPass = validation.result === 1 || validation.result === true || (typeof validation.score === 'number' && validation.score >= THRESHOLDS.pass);
                        return React.createElement('div', {{
                          style: {{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            marginBottom: '8px',
                            fontWeight: '600',
                            fontSize: '13px',
                            color: '#4d4d42'
                          }}
                        }},
                          React.createElement('i', {{ className: `ph ${{isPass ? 'ph-check-circle' : 'ph-warning-circle'}}`, style: {{ color: isPass ? COLORS.good : COLORS.critical }} }}),
                          React.createElement('span', null, validation.validation_id || 'Evaluation')
                        );
                      }})(),

                      // Result explanation
                      validation.result_explanation && React.createElement('div', {{
                        style: {{
                          fontSize: '13px',
                          lineHeight: '1.5',
                          color: '#4d4d42',
                          marginBottom: '12px'
                        }}
                      }}, validation.result_explanation),

                      // Screenshot if available
                      validation.screenshot_path && React.createElement('div', {{
                        style: {{ marginTop: '12px', marginBottom: '12px' }}
                      }},
                        React.createElement('div', {{
                          style: {{
                            fontSize: '12px',
                            fontWeight: '600',
                            color: '#4d4d42',
                            marginBottom: '6px'
                          }}
                        }}, '📸 Screenshot Evidence:'),
                        React.createElement('img', {{
                          src: `${{conversation.persona_id}}/${{validation.screenshot_path}}`,
                          alt: 'Evaluation screenshot',
                          style: {{
                            maxWidth: '100%',
                            borderRadius: '6px',
                            border: '1px solid #e5e5e0',
                            cursor: 'zoom-in'
                          }},
                          onClick: (e) => {{
                            // Open screenshot in modal/new window
                            const img = e.target;
                            const modal = document.createElement('div');
                            modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.9);z-index:9999;display:flex;align-items:center;justify-content:center;cursor:zoom-out';
                            const modalImg = document.createElement('img');
                            modalImg.src = img.src;
                            modalImg.style.cssText = 'max-width:90%;max-height:90%;border-radius:8px';
                            modal.appendChild(modalImg);
                            modal.onclick = () => document.body.removeChild(modal);
                            document.body.appendChild(modal);
                          }}
                        }})
                      ),

                      // Extra data fields
                      extraFields.length > 0 && React.createElement('div', {{
                        style: {{
                          marginTop: '12px',
                          padding: '8px',
                          backgroundColor: '#ffffff',
                          borderRadius: '6px',
                          fontSize: '12px'
                        }}
                      }},
                        React.createElement('div', {{
                          style: {{
                            fontWeight: '600',
                            color: '#4d4d42',
                            marginBottom: '6px'
                          }}
                        }}, '📋 Additional Data:'),
                        extraFields.map(field => {{
                          const value = validation[field];
                          // Handle different value types properly
                          let displayValue;
                          if (value === null || value === undefined) {{
                            displayValue = 'N/A';
                          }} else if (Array.isArray(value)) {{
                            displayValue = value.map(v => typeof v === 'object' ? JSON.stringify(v) : String(v)).join(', ');
                          }} else if (typeof value === 'object') {{
                            // For objects, render each key-value pair
                            displayValue = Object.entries(value).map(([k, v]) => `${{k}}: ${{typeof v === 'object' ? JSON.stringify(v) : v}}`).join('; ');
                          }} else {{
                            displayValue = String(value);
                          }}
                          // Apply special formatting for agent_id field
                          const formattedValue = field === 'agent_id' ? formatFieldValue(field, displayValue) : displayValue;
                          return React.createElement('div', {{
                            key: field,
                            style: {{
                              display: 'flex',
                              gap: '6px',
                              marginBottom: '4px',
                              color: '#7a7a70'
                            }}
                          }},
                            React.createElement('span', {{
                              style: {{ fontWeight: '600', minWidth: '120px' }}
                            }}, formatFieldName(field) + ':'),
                            React.createElement('span', null, formattedValue)
                          );
                        }})
                      )
                    );
                  }})
                  )  // Close inner div wrapper
                  );  // Close details element
                }})()
              )
            )
          );
          }})
        ),

        // Video player
        conversation.video_path && React.createElement('div', {{ className: 'video-player-container' }},
          React.createElement('h3', null, 'Session Recording'),
          React.createElement('video', {{
            controls: true,
            style: {{ width: '100%' }}
          }},
            React.createElement('source', {{
              src: conversation.video_path,
              type: 'video/mp4'
            }}),
            'Your browser does not support the video tag.'
          )
        )
      );

      // Use marked library to render markdown
      const renderDescription = (text) => {{
          if (!text) return null;
          if (window.marked) {{
              return React.createElement('div', {{
                  className: 'markdown-content',
                  dangerouslySetInnerHTML: {{ __html: marked.parse(text) }}
              }});
          }}
          // Fallback: Split by lines to handle formatting
          return text.split('\\n').map((line, i) => {{
              // Check for bold syntax **text**
              const parts = line.split(/(\*\*.*?\*\*)/g);
              const renderedLine = parts.map((part, j) => {{
                  if (part.startsWith('**') && part.endsWith('**')) {{
                      return React.createElement('strong', {{ key: j }}, part.slice(2, -2));
                  }}
                  return part;
              }});

              return React.createElement('div', {{ key: i, style: {{ minHeight: '1em' }} }}, renderedLine);
          }});
      }};

      // Only show side panel for turn-specific findings (not conversation-level summaries)
      const hasTurnNumber = contextFinding?.evidence?.turn_number != null;
      const sidePanel = contextFinding && hasTurnNumber && React.createElement('div', {{ className: 'conversation-side-panel' }},
        React.createElement('div', {{ className: 'side-panel-title' }}, 'Analyzing conversation'),

        // Finding Title
        React.createElement('div', {{ className: 'side-panel-section' }},
          React.createElement('div', {{ style: {{ marginBottom: '12px' }} }},
            React.createElement('span', {{ style: {{ fontWeight: '600', fontSize: '15px' }} }}, contextFinding.title)
          ),

          // Score and Business Impact metrics
          React.createElement('div', {{
            style: {{
              display: 'flex',
              gap: '12px',
              alignItems: 'center',
              marginBottom: '8px'
            }}
          }},
            // Score
            React.createElement('div', {{
              style: {{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                fontSize: '13px'
              }}
            }},
              React.createElement('span', {{ style: {{ color: '#7a7a70', fontWeight: '600' }} }}, 'SCORE:'),
              React.createElement('span', {{
                style: {{
                  color: getScoreColor(contextFinding.score || 0),
                  fontWeight: '600',
                  fontSize: '14px'
                }}
              }}, getScoreLabel(contextFinding.score || 0))
            )
          ),

          // Color indicator bar
          React.createElement('div', {{
            style: {{
              height: '3px',
              backgroundColor: getScoreColor(contextFinding.score || 0),
              borderRadius: '2px',
              marginTop: '8px'
            }}
          }})
        ),

        // Category
        contextFinding.category && React.createElement('div', {{ className: 'side-panel-section' }},
          React.createElement('div', {{ className: 'side-panel-section-title' }}, 'Category'),
          React.createElement('div', {{ className: 'side-panel-content' }}, contextFinding.category)
        ),

        // Risk Assessment
        contextFinding.description && React.createElement('div', {{ className: 'side-panel-section' }},
          React.createElement('div', {{ className: 'side-panel-section-title' }}, 'Risk Assessment'),
          React.createElement('div', {{ className: 'side-panel-content' }}, renderDescription(contextFinding.description))
        ),

        // Root Causes (if available in llm_analysis)
        contextFinding.llm_analysis?.root_cause && React.createElement('div', {{ className: 'side-panel-section' }},
          React.createElement('div', {{ className: 'side-panel-section-title' }}, 'Root Causes of Assistant Failure'),
          React.createElement('div', {{ className: 'side-panel-content' }}, contextFinding.llm_analysis.root_cause)
        ),

        // Action Items (if available in llm_analysis)
        contextFinding.llm_analysis?.remediation_steps && React.createElement('div', {{ className: 'side-panel-section' }},
          React.createElement('div', {{ className: 'side-panel-section-title' }}, 'Action Items'),
          React.createElement('ul', {{ className: 'side-panel-list' }},
            ...contextFinding.llm_analysis.remediation_steps.split('\\n').filter(s => s.trim()).map((step, i) =>
              React.createElement('li', {{ key: i }}, step.replace(/^[\\d\\.\\-\\*]\\s*/, ''))
            )
          )
        ),

        // Suggested Evals (if available in llm_analysis)
        contextFinding.llm_analysis?.implementation_notes && React.createElement('div', {{ className: 'side-panel-section' }},
          React.createElement('div', {{ className: 'side-panel-section-title' }}, 'Suggested Evals to Run'),
          React.createElement('div', {{ className: 'side-panel-content', style: {{ fontStyle: 'italic' }} }},
            contextFinding.llm_analysis.implementation_notes
          )
        )
      );

      if (contextFinding) {{
        return React.createElement('div', {{ className: 'conversation-detail-layout' }},
          mainContent,
          sidePanel
        );
      }} else {{
        return mainContent;
      }}
    }}

    function EUAIActComplianceView({{ onNavigateToConversation }}) {{
      const complianceData = REPORT_DATA.eu_ai_act_compliance || {{}};
      const {{ risk_classification, prohibited_systems, high_risk_requirements, transparency_requirements, data_governance, recommendations, summary, metadata }} = complianceData;

      if (!risk_classification) {{
        return React.createElement('div', {{ className: 'card' }},
          React.createElement('p', {{ style: {{ textAlign: 'center', color: '#7a7a70' }} }},
            'EU AI Act compliance data not available.'
          )
        );
      }}

      // Helper to get label color
      const getLabelColor = (label) => {{
        switch (label) {{
          case LABELS.critical: return COLORS.critical;
          case LABELS.warning: return COLORS.warning;
          case LABELS.good: return COLORS.good;
          default: return COLORS.good;
        }}
      }};

      // Helper to get status badge color
      const getStatusColor = (status) => {{
        if (status === 'BANNED' || status === 'NON_COMPLIANT') return COLORS.critical;
        if (status === 'REVIEW_NEEDED' || status === 'PARTIAL') return COLORS.warning;
        if (status === 'NO_CONCERNS' || status === 'COMPLIANT' || status === 'GOOD') return COLORS.good;
        return '#7a7a70';
      }};

      // Helper to get score color
      const getScoreColor = (score) => {{
        if (score >= THRESHOLDS.good) return COLORS.good;
        if (score >= THRESHOLDS.pass) return COLORS.warning;
        return COLORS.critical;
      }};

      return React.createElement('div', null,
        React.createElement('h2', {{ style: {{ fontSize: '24px', marginBottom: '24px' }} }}, 'EU AI Act Compliance Assessment'),

        // Executive Summary Card
        React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px' }} }},
          React.createElement('h3', {{ style: {{ fontSize: '18px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }} }},
            React.createElement('i', {{ className: 'ph ph-shield-check' }}),
            'Overall Risk Classification'
          ),
          React.createElement('div', {{ style: {{ marginBottom: '16px' }} }},
            React.createElement('div', {{ style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '4px' }} }}, 'Classification'),
            React.createElement('div', {{
              style: {{
                fontSize: '24px',
                fontWeight: '600',
                color: getLabelColor(risk_classification.level),
                textTransform: 'uppercase',
                letterSpacing: '0.5px'
              }}
            }}, risk_classification.level.replace(/_/g, ' '))
          ),
          React.createElement('div', {{ style: {{ padding: '16px', background: '#f5f4f0', borderRadius: '8px', marginBottom: '16px' }} }},
            React.createElement('div', {{ style: {{ fontSize: '14px', color: '#4d4d42', lineHeight: '1.6', marginBottom: '8px' }} }},
              risk_classification.description
            )
          ),
          // Recommended Action box
          (() => {{
            const hasRecommendations = recommendations && recommendations.length > 0;
            const bgColor = hasRecommendations ? '#fef3c7' : '#f0fdf4';
            const borderColor = hasRecommendations ? COLORS.warning : COLORS.good;
            const iconColor = hasRecommendations ? COLORS.warning : COLORS.good;
            const iconName = hasRecommendations ? 'ph-warning' : 'ph-check-circle';

            return React.createElement('div', {{ style: {{ padding: '16px', background: bgColor, borderRadius: '8px', border: `1px solid ${{borderColor}}` }} }},
              React.createElement('div', {{ style: {{ display: 'flex', gap: '8px', alignItems: 'flex-start' }} }},
                React.createElement('i', {{ className: `ph ${{iconName}}`, style: {{ color: iconColor, fontSize: '20px', marginTop: '2px' }} }}),
                React.createElement('div', null,
                  React.createElement('div', {{ style: {{ fontWeight: '600', marginBottom: '4px', color: '#4d4d42' }} }}, 'Recommended Action'),
                  React.createElement('div', {{ style: {{ fontSize: '14px', color: '#4d4d42' }} }},
                    hasRecommendations
                      ? 'Review and address the compliance findings listed below'
                      : 'No immediate actions required. System is compliant with EU AI Act requirements.'
                  )
                )
              )
            );
          }})(),
          // Summary text with markdown
          summary && React.createElement('div', {{
            style: {{ marginTop: '16px', padding: '16px', background: '#fff', borderRadius: '8px', border: '1px solid #e5e5e0' }},
            dangerouslySetInnerHTML: {{ __html: marked.parse(summary) }}
          }}),
          React.createElement('div', {{ style: {{ marginTop: '16px', fontSize: '12px', color: '#7a7a70', display: 'flex', gap: '16px' }} }},
            (() => {{
              // Calculate EU AI Act-specific findings count
              const prohibitedCount = prohibited_systems?.indicators?.length || 0;
              const highRiskCount = Object.values(high_risk_requirements || {{}}).reduce((sum, req) => sum + (req.findings?.length || 0), 0);
              const transparencyCount = transparency_requirements?.issues?.length || 0;
              const governanceCount = Object.values(data_governance?.issues_by_category || {{}}).reduce((sum, issues) => sum + (issues?.length || 0), 0);
              const totalEuFindings = prohibitedCount + highRiskCount + transparencyCount + governanceCount;
              const criticalEuFindings = [
                ...(prohibited_systems?.indicators || []),
                ...Object.values(high_risk_requirements || {{}}).flatMap(req => req.findings || []),
                ...(transparency_requirements?.issues || []),
                ...Object.values(data_governance?.issues_by_category || {{}}).flatMap(issues => issues || [])
              ].filter(f => f.label === LABELS.critical).length;

              return React.createElement(React.Fragment, null,
                React.createElement('div', null, `EU AI Act Findings: ${{totalEuFindings}}`),
                totalEuFindings > 0 && React.createElement('div', null, `Critical: ${{criticalEuFindings}}`)
              );
            }})()
          )
        ),

        // Prohibited Systems Card
        prohibited_systems && prohibited_systems.indicators && prohibited_systems.indicators.length > 0 && React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px', borderLeft: '4px solid ' + COLORS.critical }} }},
          React.createElement('h3', {{ style: {{ fontSize: '18px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px', color: COLORS.critical }} }},
            React.createElement('i', {{ className: 'ph ph-x-circle' }}),
            'Prohibited AI Practices (Article 5)'
          ),
          React.createElement('div', {{ style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '16px' }} }},
            `${{prohibited_systems.indicators.length}} potential prohibited practice(s) identified`
          ),
          React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '12px' }} }},
            ...prohibited_systems.indicators.map((indicator, i) =>
              React.createElement('div', {{
                key: i,
                style: {{
                  padding: '16px',
                  background: '#fee2e2',
                  borderRadius: '8px',
                  border: '1px solid ' + COLORS.critical
                }}
              }},
                React.createElement('div', {{ style: {{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '8px' }} }},
                  React.createElement('div', {{ style: {{ fontWeight: '600', color: '#4d4d42' }} }}, indicator.type),
                  React.createElement('div', {{ style: {{ display: 'flex', gap: '8px', alignItems: 'center' }} }},
                    React.createElement('div', {{
                      style: {{
                        padding: '4px 12px',
                        borderRadius: '4px',
                        background: getSeverityColor(indicator.severity) + '20',
                        fontSize: '12px',
                        fontWeight: '600',
                        color: getSeverityColor(indicator.severity)
                      }}
                    }}, indicator.severity),
                    indicator.source && React.createElement('button', {{
                      className: 'action-button',
                      style: {{ fontSize: '12px', padding: '4px 12px' }},
                      onClick: () => {{
                        const conversation = REPORT_DATA.conversations.find(c =>
                          c.persona_id === indicator.source
                        );
                        if (conversation) {{
                          const turn_number = indicator.turn_number || null;
                          // Find the full finding data from the findings array (use unconsolidated)
                          const fullFinding = getAllDetailedFindings().find(f =>
                            f.title === indicator.finding && f.source === indicator.source
                          );
                          // Use full finding if found, otherwise create minimal data
                          const findingData = fullFinding || {{
                            title: indicator.finding,
                            severity: indicator.severity,
                            description: indicator.description,
                            evidence: indicator.evidence,
                            category: indicator.type,
                            summary: indicator.description,
                            score: 0
                          }};
                          onNavigateToConversation(conversation, turn_number, findingData);
                        }}
                      }}
                    }},
                      React.createElement('i', {{ className: 'ph ph-chat-circle-text' }}),
                      React.createElement('span', null, 'View in Conversation')
                    )
                  )
                ),
                React.createElement('div', {{ style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '8px' }} }}, indicator.finding),
                React.createElement('div', {{ style: {{ fontSize: '13px', color: '#7a7a70', marginBottom: '4px' }} }}, indicator.description),
                React.createElement('div', {{ style: {{ fontSize: '12px', color: '#4d4d42', fontWeight: '500' }} }}, indicator.article)
              )
            )
          )
        ),

        // High-Risk Requirements Card
        high_risk_requirements && React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px' }} }},
          React.createElement('h3', {{ style: {{ fontSize: '18px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }} }},
            React.createElement('i', {{ className: 'ph ph-list-checks' }}),
            'High-Risk System Requirements (Articles 9-15)'
          ),
          React.createElement('p', {{ style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '20px', lineHeight: '1.6' }} }},
            'High-risk AI systems must meet stringent requirements for data quality, technical robustness, human oversight, transparency, accuracy, and cybersecurity. These requirements ensure AI systems are safe, reliable, and trustworthy when deployed in sensitive contexts.'
          ),
          React.createElement('div', {{ style: {{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '16px' }} }},
            ...Object.entries(high_risk_requirements).map(([key, data]) => {{
              const actualIssues = data.findings ? data.findings : [];
              return React.createElement('div', {{
                key: key,
                style: {{
                  padding: '16px',
                  background: '#f5f4f0',
                  borderRadius: '8px',
                  border: '1px solid #e5e5e0'
                }}
              }},
                React.createElement('div', {{ style: {{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }} }},
                  React.createElement('div', {{ style: {{ fontSize: '14px', fontWeight: '600', color: '#4d4d42' }} }},
                    key.replace(/_/g, ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
                  ),
                  React.createElement('div', {{
                    style: {{
                      fontSize: '18px',
                      fontWeight: '600',
                      color: getScoreColor(data.score)
                    }}
                  }}, `${{data.score}}/100`)
                ),
                actualIssues.length > 0
                  ? React.createElement('div', {{ style: {{ marginTop: '12px' }} }},
                      React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70', marginBottom: '8px', fontWeight: '600' }} }},
                        `${{actualIssues.length}} issue(s) found:`
                      ),
                      React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '8px' }} }},
                        ...actualIssues.map((finding, idx) => {{
                          const conversation = REPORT_DATA.conversations.find(c => c.persona_id === finding.source);
                          return React.createElement('div', {{
                            key: idx,
                            style: {{
                              padding: '8px',
                              background: '#fff',
                              borderRadius: '6px',
                              border: '1px solid #e5e5e0',
                              fontSize: '11px'
                            }}
                          }},
                            conversation && React.createElement('button', {{
                              onClick: () => {{
                                if (conversation) {{
                                  const turn_number = finding.turn_number || null;
                                  const fullFinding = getAllDetailedFindings().find(f =>
                                    f.title === finding.title && f.source === finding.source
                                  );
                                  const findingData = fullFinding || {{
                                    title: finding.title,
                                    severity: finding.severity,
                                    description: finding.description,
                                    evidence: finding.evidence,
                                    category: key,
                                    summary: finding.description,
                                    score: finding.score || 0
                                  }};
                                  onNavigateToConversation(conversation, turn_number, findingData);
                                }}
                              }},
                              style: {{
                                padding: '4px 8px',
                                background: '#6366f1',
                                color: '#fff',
                                border: 'none',
                                borderRadius: '4px',
                                cursor: 'pointer',
                                fontSize: '11px',
                                marginBottom: '6px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '4px'
                              }}
                            }},
                              React.createElement('i', {{ className: 'ph ph-chat-circle-text' }}),
                              React.createElement('span', null, 'View in Conversation')
                            ),
                            React.createElement('div', {{ style: {{ color: '#4d4d42', fontWeight: '600', marginBottom: '2px' }} }}, finding.title),
                            React.createElement('div', {{ style: {{ color: '#7a7a70', fontSize: '10px' }} }},
                              `Article: ${{finding.article || 'N/A'}} • Severity: ${{finding.severity}}`
                            )
                          );
                        }})
                      )
                    )
                  : React.createElement('div', {{ style: {{ fontSize: '12px', color: '#16a34a', marginTop: '8px', display: 'flex', alignItems: 'center', gap: '4px' }} }},
                      React.createElement('i', {{ className: 'ph ph-check-circle', style: {{ fontSize: '14px' }} }}),
                      'No issues found'
                    )
              );
            }})
          )
        ),

        // Transparency Requirements Card
        transparency_requirements && React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px' }} }},
          React.createElement('h3', {{ style: {{ fontSize: '18px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }} }},
            React.createElement('i', {{ className: 'ph ph-eye' }}),
            'Transparency Requirements (Article 52)'
          ),
          React.createElement('div', {{ style: {{ display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '16px' }} }},
            React.createElement('div', {{ style: {{ flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '4px' }} }}, 'Compliance Score'),
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: getScoreColor(transparency_requirements.score) }} }},
                `${{transparency_requirements.score}}/100`
              )
            ),
            React.createElement('div', {{
              style: {{
                padding: '8px 16px',
                borderRadius: '8px',
                background: getStatusColor(transparency_requirements.status) + '20',
                border: `2px solid ${{getStatusColor(transparency_requirements.status)}}`,
                fontWeight: '600',
                fontSize: '14px',
                color: getStatusColor(transparency_requirements.status)
              }}
            }}, transparency_requirements.status.replace(/_/g, ' '))
          ),
          transparency_requirements.issues && transparency_requirements.issues.length > 0 && React.createElement('div', {{ style: {{ marginTop: '16px' }} }},
            React.createElement('div', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '12px' }} }},
              `${{transparency_requirements.issues.length}} Transparency Issue(s)`
            ),
            React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '8px' }} }},
              ...transparency_requirements.issues.map((issue, i) => {{
                const conversation = REPORT_DATA.conversations.find(c => c.persona_id === issue.source);
                return React.createElement('div', {{
                  key: i,
                  style: {{
                    padding: '12px',
                    background: '#fff',
                    borderRadius: '8px',
                    border: '1px solid #e5e5e0'
                  }}
                }},
                  conversation && React.createElement('button', {{
                    onClick: () => {{
                      if (conversation) {{
                        const turn_number = issue.turn_number || null;
                        const fullFinding = getAllDetailedFindings().find(f =>
                          f.title === issue.finding && f.source === issue.source
                        );
                        const findingData = fullFinding || {{
                          title: issue.finding,
                          severity: issue.severity || 'High',
                          description: issue.requirement,
                          evidence: issue.evidence,
                          category: 'Transparency Requirements',
                          summary: issue.requirement,
                          score: issue.score || 0
                        }};
                        onNavigateToConversation(conversation, turn_number, findingData);
                      }}
                    }},
                    style: {{
                      padding: '6px 12px',
                      background: '#6366f1',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '12px',
                      marginBottom: '8px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  }},
                    React.createElement('i', {{ className: 'ph ph-chat-circle-text' }}),
                    React.createElement('span', null, 'View in Conversation')
                  ),
                  React.createElement('div', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }} }}, issue.finding),
                  React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, issue.requirement)
                );
              }})
            )
          )
        ),

        // Data Governance Card
        data_governance && React.createElement('div', {{ className: 'card', style: {{ marginBottom: '24px' }} }},
          React.createElement('h3', {{ style: {{ fontSize: '18px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }} }},
            React.createElement('i', {{ className: 'ph ph-database' }}),
            'Data Governance (Article 10)'
          ),
          React.createElement('div', {{ style: {{ display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '16px' }} }},
            React.createElement('div', {{ style: {{ flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '4px' }} }}, 'Governance Score'),
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: getScoreColor(data_governance.score) }} }},
                `${{data_governance.score}}/100`
              )
            ),
            React.createElement('div', {{
              style: {{
                padding: '8px 16px',
                borderRadius: '8px',
                background: getStatusColor(data_governance.status) + '20',
                border: `2px solid ${{getStatusColor(data_governance.status)}}`,
                fontWeight: '600',
                fontSize: '14px',
                color: getStatusColor(data_governance.status)
              }}
            }}, data_governance.status)
          ),
          data_governance.issues_by_category && React.createElement('div', {{ style: {{ marginTop: '16px' }} }},
            ...Object.entries(data_governance.issues_by_category).map(([category, issues]) => {{
              const actualIssues = issues;
              return actualIssues.length > 0 && React.createElement('div', {{
                key: category,
                style: {{ marginBottom: '16px' }}
              }},
                React.createElement('div', {{ style: {{ fontSize: '13px', fontWeight: '600', marginBottom: '8px', color: '#4d4d42', textTransform: 'capitalize' }} }},
                  `${{category.replace(/_/g, ' ')}} (${{actualIssues.length}} issue(s))`
                ),
                React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '8px' }} }},
                  ...actualIssues.map((issue, idx) => {{
                    const conversation = REPORT_DATA.conversations.find(c => c.persona_id === issue.source);
                    return React.createElement('div', {{
                      key: idx,
                      style: {{
                        padding: '10px',
                        background: '#fff',
                        borderRadius: '6px',
                        border: '1px solid #e5e5e0',
                        fontSize: '12px'
                      }}
                    }},
                      conversation && React.createElement('button', {{
                        onClick: () => {{
                          if (conversation) {{
                            const turn_number = issue.turn_number || null;
                            const fullFinding = getAllDetailedFindings().find(f =>
                              f.title === issue.finding && f.source === issue.source
                            );
                            const findingData = fullFinding || {{
                              title: issue.finding,
                              severity: issue.severity,
                              description: issue.description || '',
                              evidence: issue.evidence,
                              category: `Data Governance - ${{category}}`,
                              summary: issue.description || issue.finding,
                              score: issue.score || 0
                            }};
                            onNavigateToConversation(conversation, turn_number, findingData);
                          }}
                        }},
                        style: {{
                          padding: '4px 8px',
                          background: '#6366f1',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          fontSize: '11px',
                          marginBottom: '6px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px'
                        }}
                      }},
                        React.createElement('i', {{ className: 'ph ph-chat-circle-text' }}),
                        React.createElement('span', null, 'View in Conversation')
                      ),
                      React.createElement('div', {{ style: {{ color: '#4d4d42', fontWeight: '600', marginBottom: '2px' }} }}, issue.finding),
                      React.createElement('div', {{ style: {{ color: '#7a7a70', fontSize: '10px' }} }}, `Severity: ${{issue.severity}}`)
                    );
                  }})
                )
              );
            }})
          )
        ),

        // Recommendations Card
        recommendations && recommendations.length > 0 && React.createElement('div', {{ className: 'card' }},
          React.createElement('h3', {{ style: {{ fontSize: '18px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }} }},
            React.createElement('i', {{ className: 'ph ph-lightbulb' }}),
            'Compliance Recommendations'
          ),
          React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '16px' }} }},
            ...recommendations.map((rec, i) =>
              React.createElement('div', {{
                key: i,
                style: {{
                  padding: '16px',
                  background: '#f5f4f0',
                  borderRadius: '8px',
                  border: '1px solid #e5e5e0',
                  borderLeft: `4px solid ${{getSeverityColor(rec.priority)}}`
                }}
              }},
                React.createElement('div', {{ style: {{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '8px' }} }},
                  React.createElement('div', {{ style: {{ fontWeight: '600', fontSize: '16px', color: '#4d4d42' }} }}, rec.title),
                  React.createElement('div', {{
                    style: {{
                      padding: '4px 12px',
                      borderRadius: '4px',
                      background: getSeverityColor(rec.priority) + '20',
                      fontSize: '12px',
                      fontWeight: '600',
                      color: getSeverityColor(rec.priority)
                    }}
                  }}, rec.priority)
                ),
                React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70', marginBottom: '8px' }} }},
                  `${{rec.category}} • ${{rec.article}}`
                ),
                React.createElement('div', {{ style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '12px' }} }}, rec.description),
                rec.actions && rec.actions.length > 0 && React.createElement('div', {{ style: {{ marginTop: '12px' }} }},
                  React.createElement('div', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }} }}, 'Action Items:'),
                  React.createElement('ul', {{ style: {{ paddingLeft: '20px', margin: 0 }} }},
                    ...rec.actions.map((action, j) =>
                      React.createElement('li', {{ key: j, style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '4px' }} }}, action)
                    )
                  )
                )
              )
            )
          )
        )
      );
    }}

    function TestSummaryView({{ onNavigateToConversation }}) {{
      const testSummary = REPORT_DATA.test_summary;

      if (!testSummary || !testSummary.tests || testSummary.tests.length === 0) {{
        return React.createElement('div', {{ className: 'card' }},
          React.createElement('p', {{ style: {{ textAlign: 'center', color: '#7a7a70' }} }},
            'Test summary data not available.'
          )
        );
      }}

      const {{ suite_name, suite_domain, suite_application, tests, scenarios }} = testSummary;

      // Helper functions for colors
      const getStatusColor = (status) => {{
        if (status === 'passed') return COLORS.good;
        if (status === 'failed') return COLORS.critical;
        if (status === 'warning') return COLORS.warning;
        return '#7a7a70';
      }};

      const getStatusBgColor = (status) => {{
        if (status === 'passed') return '#2E7D321F';
        if (status === 'failed') return '#C625251F';
        if (status === 'warning') return '#ED6C021F';
        return '#f5f4f0';
      }};

      const getScoreColor = (score) => {{
        if (score >= THRESHOLDS.good) return COLORS.good;
        if (score >= THRESHOLDS.pass) return COLORS.warning;
        return COLORS.critical;
      }};

      // Render a test card
      const renderTestCard = (test) => {{
        const statusIcon = test.status === 'passed' ? 'ph-check-circle' : test.status === 'failed' ? 'ph-x-circle' : 'ph-warning-circle';

        return React.createElement('div', {{
          key: test.test_id,
          className: 'card',
          style: {{ marginBottom: '16px' }}
        }},
          // Header with test name and status
          React.createElement('div', {{
            style: {{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '16px'
            }}
          }},
            React.createElement('div', {{ style: {{ display: 'flex', alignItems: 'center', gap: '12px' }} }},
              React.createElement('i', {{
                className: `ph ${{statusIcon}}`,
                style: {{ fontSize: '24px', color: getStatusColor(test.status) }}
              }}),
              React.createElement('div', null,
                React.createElement('h3', {{ style: {{ fontSize: '18px', fontWeight: '600', margin: 0 }} }}, test.test_name),
                React.createElement('div', {{ style: {{ fontSize: '13px', color: '#7a7a70', marginTop: '4px' }} }},
                  `ID: ${{test.test_id}} • Persona: ${{test.persona_id}}`
                )
              )
            ),
            React.createElement('span', {{
              style: {{
                padding: '6px 12px',
                borderRadius: '16px',
                fontSize: '13px',
                fontWeight: '600',
                textTransform: 'uppercase',
                backgroundColor: getStatusBgColor(test.status),
                color: getStatusColor(test.status)
              }}
            }}, test.status)
          ),

          // Description if available
          test.description && React.createElement('div', {{
            style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '16px', lineHeight: '1.5' }}
          }}, test.description),

          // Findings counts
          React.createElement('div', {{
            style: {{
              display: 'flex',
              gap: '16px',
              marginBottom: '16px',
              padding: '12px',
              background: '#f5f4f0',
              borderRadius: '8px'
            }}
          }},
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: COLORS.critical }} }}, test.critical_count),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Critical')
            ),
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: COLORS.warning }} }}, test.warning_count),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Warnings')
            ),
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: COLORS.good }} }}, test.good_count),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Good')
            ),
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: '#4d4d42' }} }}, test.total_findings),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Total')
            )
          ),

          // Summary
          test.summary && React.createElement('div', {{
            style: {{ marginBottom: '16px' }}
          }},
            React.createElement('h4', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }} }}, 'Summary'),
            React.createElement('div', {{ style: {{ fontSize: '14px', color: '#4d4d42', lineHeight: '1.6' }} }}, test.summary)
          ),

          // Key Findings
          test.key_findings && test.key_findings.length > 0 && React.createElement('div', null,
            React.createElement('h4', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }} }}, 'Key Findings'),
            React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '8px' }} }},
              ...test.key_findings.slice(0, 5).map((finding, idx) =>
                React.createElement('div', {{
                  key: idx,
                  style: {{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '8px',
                    padding: '8px 12px',
                    background: finding.label === 'Critical' ? '#C625251F' : finding.label === 'Warning' ? '#ED6C021F' : '#2E7D321F',
                    borderRadius: '6px',
                    cursor: 'pointer'
                  }},
                  onClick: () => {{
                    // Find the conversation for this test
                    const conversations = REPORT_DATA.conversations || [];
                    const conv = conversations.find(c => c.persona_name === test.persona_id);
                    if (conv && onNavigateToConversation) {{
                      onNavigateToConversation(conv, finding.turn_number, finding);
                    }}
                  }}
                }},
                  React.createElement('span', {{
                    style: {{
                      padding: '2px 6px',
                      borderRadius: '4px',
                      fontSize: '11px',
                      fontWeight: '600',
                      backgroundColor: finding.label === 'Critical' ? COLORS.critical : finding.label === 'Warning' ? COLORS.warning : COLORS.good,
                      color: 'white',
                      flexShrink: 0
                    }}
                  }}, finding.label),
                  React.createElement('span', {{ style: {{ fontSize: '13px', color: '#4d4d42' }} }}, finding.title)
                )
              )
            ),
            test.key_findings.length > 5 && React.createElement('div', {{
              style: {{ fontSize: '13px', color: '#7a7a70', marginTop: '8px', fontStyle: 'italic' }}
            }}, `... and ${{test.key_findings.length - 5}} more findings`)
          )
        );
      }};

      // Render scenario card
      const renderScenarioCard = (scenarioName, scenario) => {{
        const statusIcon = scenario.status === 'passed' ? 'ph-check-circle' : scenario.status === 'failed' ? 'ph-x-circle' : 'ph-warning-circle';

        return React.createElement('div', {{
          key: scenarioName,
          className: 'card',
          style: {{ marginBottom: '16px' }}
        }},
          // Header with scenario name and status
          React.createElement('div', {{
            style: {{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '16px'
            }}
          }},
            React.createElement('div', {{ style: {{ display: 'flex', alignItems: 'center', gap: '12px' }} }},
              React.createElement('i', {{
                className: `ph ${{statusIcon}}`,
                style: {{ fontSize: '24px', color: getStatusColor(scenario.status) }}
              }}),
              React.createElement('h3', {{ style: {{ fontSize: '18px', fontWeight: '600', margin: 0 }} }}, scenarioName)
            ),
            React.createElement('span', {{
              style: {{
                padding: '6px 12px',
                borderRadius: '16px',
                fontSize: '13px',
                fontWeight: '600',
                textTransform: 'uppercase',
                backgroundColor: getStatusBgColor(scenario.status),
                color: getStatusColor(scenario.status)
              }}
            }}, scenario.status)
          ),

          // Stats row
          React.createElement('div', {{
            style: {{
              display: 'flex',
              gap: '16px',
              marginBottom: '16px',
              padding: '12px',
              background: '#f5f4f0',
              borderRadius: '8px'
            }}
          }},
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: '#4d4d42' }} }}, scenario.test_count),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Tests')
            ),
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: COLORS.critical }} }}, scenario.critical_count),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Critical')
            ),
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: COLORS.warning }} }}, scenario.warning_count),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Warnings')
            ),
            React.createElement('div', {{ style: {{ textAlign: 'center', flex: 1 }} }},
              React.createElement('div', {{ style: {{ fontSize: '24px', fontWeight: '600', color: COLORS.good }} }}, scenario.good_count),
              React.createElement('div', {{ style: {{ fontSize: '12px', color: '#7a7a70' }} }}, 'Good')
            )
          ),

          // Summary
          scenario.summary && React.createElement('div', {{
            style: {{ marginBottom: '16px' }}
          }},
            React.createElement('h4', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }} }}, 'Summary'),
            React.createElement('div', {{ style: {{ fontSize: '14px', color: '#4d4d42', lineHeight: '1.6' }} }}, scenario.summary)
          ),

          // Key Findings
          scenario.key_findings && scenario.key_findings.length > 0 && React.createElement('div', null,
            React.createElement('h4', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }} }}, 'Key Findings'),
            React.createElement('div', {{ style: {{ display: 'flex', flexDirection: 'column', gap: '8px' }} }},
              ...scenario.key_findings.slice(0, 5).map((finding, idx) =>
                React.createElement('div', {{
                  key: idx,
                  style: {{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '8px',
                    padding: '8px 12px',
                    background: finding.label === 'Critical' ? '#C625251F' : finding.label === 'Warning' ? '#ED6C021F' : '#2E7D321F',
                    borderRadius: '6px',
                    cursor: 'pointer'
                  }},
                  onClick: () => {{
                    // Try to navigate to the finding's test conversation
                    const conversations = REPORT_DATA.conversations || [];
                    const conv = conversations.find(c => c.persona_name === finding.test_id);
                    if (conv && onNavigateToConversation) {{
                      onNavigateToConversation(conv, finding.turn_number, finding);
                    }}
                  }}
                }},
                  React.createElement('span', {{
                    style: {{
                      padding: '2px 6px',
                      borderRadius: '4px',
                      fontSize: '11px',
                      fontWeight: '600',
                      backgroundColor: finding.label === 'Critical' ? COLORS.critical : finding.label === 'Warning' ? COLORS.warning : COLORS.good,
                      color: 'white',
                      flexShrink: 0
                    }}
                  }}, finding.label),
                  React.createElement('span', {{ style: {{ fontSize: '13px', color: '#4d4d42', flex: 1 }} }}, finding.title),
                  finding.test_id && React.createElement('span', {{
                    style: {{ fontSize: '11px', color: '#7a7a70', fontStyle: 'italic' }}
                  }}, `(${{finding.test_id}})`)
                )
              )
            ),
            scenario.key_findings.length > 5 && React.createElement('div', {{
              style: {{ fontSize: '13px', color: '#7a7a70', marginTop: '8px', fontStyle: 'italic' }}
            }}, `... and ${{scenario.key_findings.length - 5}} more findings`)
          ),

          // Tests that include this scenario
          scenario.tests && scenario.tests.length > 0 && React.createElement('div', {{
            style: {{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #e0ded6' }}
          }},
            React.createElement('h4', {{ style: {{ fontSize: '14px', fontWeight: '600', marginBottom: '8px' }} }}, 'Tests Including This Scenario'),
            React.createElement('div', {{ style: {{ display: 'flex', flexWrap: 'wrap', gap: '8px' }} }},
              ...scenario.tests.map((testId, idx) =>
                React.createElement('span', {{
                  key: idx,
                  style: {{
                    padding: '4px 8px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    background: '#f5f4f0',
                    color: '#4d4d42'
                  }}
                }}, testId)
              )
            )
          )
        );
      }};

      const scenarioEntries = scenarios ? Object.entries(scenarios) : [];

      return React.createElement('div', null,
        // Suite header
        React.createElement('h2', {{ style: {{ fontSize: '24px', marginBottom: '8px' }} }}, suite_name || 'Test Summary'),
        (suite_domain || suite_application) && React.createElement('div', {{
          style: {{ fontSize: '14px', color: '#7a7a70', marginBottom: '24px' }}
        }},
          suite_domain && React.createElement('span', null, `Domain: ${{suite_domain}}`),
          suite_domain && suite_application && React.createElement('span', null, ' • '),
          suite_application && React.createElement('span', null, `Application: ${{suite_application}}`)
        ),

        // Tests section
        React.createElement('div', {{ style: {{ marginBottom: '32px' }} }},
          React.createElement('h3', {{
            style: {{
              fontSize: '18px',
              fontWeight: '600',
              marginBottom: '16px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          }},
            React.createElement('i', {{ className: 'ph ph-list-checks' }}),
            `Tests (${{tests.length}})`
          ),
          ...tests.map(renderTestCard)
        ),

        // Scenarios section
        scenarioEntries.length > 0 && React.createElement('div', null,
          React.createElement('h3', {{
            style: {{
              fontSize: '18px',
              fontWeight: '600',
              marginBottom: '16px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          }},
            React.createElement('i', {{ className: 'ph ph-tree-structure' }}),
            `Scenarios (${{scenarioEntries.length}})`
          ),
          ...scenarioEntries.map(([name, scenario]) => renderScenarioCard(name, scenario))
        )
      );
    }}

    function App() {{
      const [activeTab, setActiveTab] = useState('Executive Summary');
      const [selectedDimension, setSelectedDimension] = useState(null);
      const [selectedConversation, setSelectedConversation] = useState(null);
      const [highlightTurn, setHighlightTurn] = useState(null);
      const [contextFinding, setContextFinding] = useState(null);
      const [navigationHistory, setNavigationHistory] = useState([]);
      const [isEmbed, setIsEmbed] = useState(false);
      const [conversationsOnly, setConversationsOnly] = useState({"true" if conversations_only else "false"});

      // Sync state with browser history on mount and popstate events
      useEffect(() => {{
        // Initialize from URL hash if present
        const initializeFromHash = () => {{
          const hash = window.location.hash.substring(1);
          if (hash) {{
            try {{
              const state = JSON.parse(decodeURIComponent(hash));
              if (state.tab) setActiveTab(state.tab);
              if (state.dimension !== undefined) setSelectedDimension(state.dimension);
              if (state.conversation !== undefined) setSelectedConversation(state.conversation);
              if (state.turn !== undefined) setHighlightTurn(state.turn);
              if (state.finding !== undefined) setContextFinding(state.finding);
              if (state.mode === 'embed') setIsEmbed(true);
              if (state.mode === 'conversations') setConversationsOnly(true);
            }} catch (e) {{
              console.error('Failed to parse hash state:', e);
            }}
          }}
        }};

        // Handle browser back/forward buttons
        const handlePopState = (event) => {{
          if (event.state) {{
            setActiveTab(event.state.tab || 'Executive Summary');
            setSelectedDimension(event.state.dimension || null);
            setSelectedConversation(event.state.conversation || null);
            setHighlightTurn(event.state.turn || null);
            setContextFinding(event.state.finding || null);
          }}
        }};

        initializeFromHash();
        window.addEventListener('popstate', handlePopState);
        return () => window.removeEventListener('popstate', handlePopState);
      }}, []);

      // Navigation state helper - pushes to browser history
      const pushNavigation = (state) => {{
        setNavigationHistory(prev => [...prev, {{
          tab: activeTab,
          dimension: selectedDimension,
          conversation: selectedConversation,
          turn: highlightTurn,
          finding: contextFinding
        }}]);

        // Apply the new state
        if (state.tab) setActiveTab(state.tab);
        if (state.dimension !== undefined) setSelectedDimension(state.dimension);
        if (state.conversation !== undefined) setSelectedConversation(state.conversation);
        if (state.turn !== undefined) setHighlightTurn(state.turn);
        if (state.finding !== undefined) setContextFinding(state.finding);

        // Push to browser history
        const historyState = {{
          tab: state.tab || activeTab,
          dimension: state.dimension !== undefined ? state.dimension : selectedDimension,
          conversation: state.conversation !== undefined ? state.conversation : selectedConversation,
          turn: state.turn !== undefined ? state.turn : highlightTurn,
          finding: state.finding !== undefined ? state.finding : contextFinding
        }};
        window.history.pushState(historyState, '', '#' + encodeURIComponent(JSON.stringify(historyState)));
      }};

      // Update state without adding to navigation history (for finding selection)
      const updateStateInPlace = (state) => {{
        if (state.turn !== undefined) setHighlightTurn(state.turn);
        if (state.finding !== undefined) setContextFinding(state.finding);

        // Replace browser history state without adding new entry
        const historyState = {{
          tab: activeTab,
          dimension: selectedDimension,
          conversation: selectedConversation,
          turn: state.turn !== undefined ? state.turn : highlightTurn,
          finding: state.finding !== undefined ? state.finding : contextFinding
        }};
        window.history.replaceState(historyState, '', '#' + encodeURIComponent(JSON.stringify(historyState)));
      }};

      const goBack = () => {{
        window.history.back();
      }};

      // Compute back button text based on navigation history
      const getBackButtonText = () => {{
        if (navigationHistory.length === 0) {{
          // Default text based on current view
          if (selectedDimension) return 'Back to All Categories';
          if (selectedConversation) return 'Back to Conversations';
          return 'Back';
        }}

        const previous = navigationHistory[navigationHistory.length - 1];

        // If going back to a category detail
        if (previous.dimension) {{
          return `Back to ${{previous.dimension.category_name}}`;
        }}

        // If going back to findings tab
        if (previous.tab === 'Findings' && !previous.dimension) {{
          return 'Back to All Categories';
        }}

        // If going back to conversations list
        if (previous.tab === 'Conversations' && !previous.conversation) {{
          return 'Back to Conversations';
        }}

        // If going back to a specific conversation
        if (previous.conversation) {{
          return `Back to ${{previous.conversation.persona_name}}`;
        }}

        // Default to tab name
        return `Back to ${{previous.tab}}`;
      }};

      // Handler for tab clicks from navigation
      const handleTabChange = (tab) => {{
        pushNavigation({{
          tab: tab,
          dimension: null,
          conversation: null,
          turn: null,
          finding: null
        }});
      }};

      let content;
      if (activeTab === 'Executive Summary') {{
        content = React.createElement(ExecutiveSummary, {{
          setActiveTab: (tab) => pushNavigation({{ tab }}),
          setSelectedConversation: (conv) => {{
            pushNavigation({{
              tab: 'Conversations',
              conversation: conv,
              turn: null,
              finding: null
            }});
          }},
          setHighlightTurn
        }});
      }} else if (activeTab === 'Findings') {{
        if (selectedDimension) {{
          content = React.createElement(CategoryDetailView, {{
            category: selectedDimension,
            onBack: goBack,
            backButtonText: getBackButtonText(),
            onNavigateToConversation: (conversation, turn_number, finding) => {{
              pushNavigation({{
                tab: 'Conversations',
                conversation: conversation,
                turn: turn_number || null,
                finding: finding || null
              }});
            }}
          }});
        }} else {{
          content = React.createElement(FindingsView, {{
            onCategoryClick: (cat) => {{
              pushNavigation({{
                tab: activeTab,
                dimension: cat,
                conversation: null,
                turn: null,
                finding: null
              }});
            }},
            onNavigateToConversation: (conversation, turn_number, finding) => {{
              pushNavigation({{
                tab: 'Conversations',
                conversation: conversation,
                turn: turn_number || null,
                finding: finding || null
              }});
            }}
          }});
        }}
      }} else if (activeTab === 'Conversations') {{
        console.log('Conversations tab - selectedConversation:', selectedConversation ? selectedConversation.persona_id : 'null');
        if (selectedConversation) {{
          console.log('Rendering ConversationDetailView for:', selectedConversation.persona_name, 'turn:', highlightTurn);
          content = React.createElement(ConversationDetailView, {{
            conversation: selectedConversation,
            highlightTurn: highlightTurn,
            contextFinding: contextFinding,
            backButtonText: getBackButtonText(),
            onBack: goBack,
            onFindingClick: (finding) => {{
              const turn_number = finding.evidence?.turn_number;
              updateStateInPlace({{
                turn: turn_number || null,
                finding: finding
              }});
            }}
          }});
        }} else {{
          console.log('Rendering ConversationsView (list)');
          content = React.createElement(ConversationsView, {{
            onConversationClick: (conv) => {{
              pushNavigation({{
                tab: 'Conversations',
                conversation: conv,
                turn: null,
                finding: null
              }});
            }}
          }});
        }}
      }} else if (activeTab === 'EU AI Act Compliance') {{
        content = React.createElement(EUAIActComplianceView, {{
          onNavigateToConversation: (conversation, turn_number, finding) => {{
            pushNavigation({{
              tab: 'Conversations',
              conversation: conversation,
              turn: turn_number || null,
              finding: finding || null
            }});
          }}
        }});
      }} else if (activeTab === 'Test Summary') {{
        content = React.createElement(TestSummaryView, {{
          onNavigateToConversation: (conversation, turn_number, finding) => {{
            pushNavigation({{
              tab: 'Conversations',
              conversation: conversation,
              turn: turn_number || null,
              finding: finding || null
            }});
          }}
        }});
      }}

      // In embed mode (loaded via iframe), return only the content without header/nav
      if (isEmbed) {{
        return React.createElement('div', {{ className: 'container', style: {{ padding: '0 24px' }} }},
          content
        );
      }}

      // In conversations-only mode, show header + conversations content without tabs
      if (conversationsOnly) {{
        // Force conversations content
        let conversationsContent;
        if (selectedConversation) {{
          conversationsContent = React.createElement(ConversationDetailView, {{
            conversation: selectedConversation,
            highlightTurn: highlightTurn,
            contextFinding: contextFinding,
            backButtonText: 'Back to Conversations',
            onBack: () => {{
              setSelectedConversation(null);
              setHighlightTurn(null);
              setContextFinding(null);
            }},
            onFindingClick: (finding) => {{
              const turn_number = finding.evidence?.turn_number;
              updateStateInPlace({{
                turn: turn_number || null,
                finding: finding
              }});
            }}
          }});
        }} else {{
          conversationsContent = React.createElement(ConversationsView, {{
            onConversationClick: (conv) => {{
              setSelectedConversation(conv);
              setHighlightTurn(null);
              setContextFinding(null);
            }}
          }});
        }}

        return React.createElement('div', null,
          React.createElement(Header),
          React.createElement('div', {{ className: 'container' }},
            conversationsContent
          )
        );
      }}

      return React.createElement('div', null,
        React.createElement(Header),
        React.createElement('div', {{ className: 'container' }},
          React.createElement(Navigation, {{ activeTab, setActiveTab: handleTabChange }}),
          content
        ),
        React.createElement('a', {{
          href: 'https://arato.ai',
          target: '_blank',
          rel: 'noopener noreferrer',
          className: 'floating-logo',
          title: 'Powered by Arato'
        }},
          React.createElement('img', {{
            src: "data:image/svg+xml;base64,{logo_svg_encoded}",
            alt: 'Arato Logo'
          }})
        )
      );
    }}

    // Mount React app
    const root = createRoot(document.getElementById('root'));
    root.render(React.createElement(App));
  </script>
</body>
</html>"""

    return html
