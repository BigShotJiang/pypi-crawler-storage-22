"""Logging configuration utility for agent execution.

This module provides a function to set up logging to both console and file.
The file log is saved in the session conversation folder as "agent.log".
"""

import logging
import os
import sys
from pathlib import Path

# Suppress LiteLLM verbose logging BEFORE any imports
os.environ["LITELLM_LOG"] = "ERROR"


def setup_logging(
    session_dir: str | Path | None = None, level: int = logging.INFO
) -> None:
    """Configure logging to output to both console and session file.

    Args:
        session_dir: Path to session directory where agent.log will be created.
                    If None, only console logging is configured.
        level: Logging level (default: INFO)
    """
    # Remove any existing handlers to avoid duplicates
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Create formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(levelname)-8s - [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler (stdout)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # File handler (if session_dir provided)
    if session_dir:
        session_path = Path(session_dir)
        session_path.mkdir(parents=True, exist_ok=True)
        log_file = session_path / "agent.log"

        file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

        root_logger.info(f"📝 Logging to file: {log_file}")

    root_logger.setLevel(level)

    # Silence verbose libraries
    logging.getLogger("browser_use").setLevel(logging.WARNING)
    logging.getLogger("bubus").setLevel(logging.WARNING)

    # Silence verbose application modules
    logging.getLogger("utils.report_data_generator").setLevel(logging.WARNING)
    logging.getLogger("utils.executive_summary").setLevel(logging.WARNING)
    logging.getLogger("utils.timing_logger").setLevel(logging.WARNING)

    # Suppress LiteLLM verbose logging more aggressively
    # LiteLLM uses multiple logger names and namespaces
    logging.getLogger("LiteLLM").setLevel(logging.ERROR)
    logging.getLogger("litellm").setLevel(logging.ERROR)
    logging.getLogger("LiteLLM.Router").setLevel(logging.ERROR)
    logging.getLogger("LiteLLM.Proxy").setLevel(logging.ERROR)

    # Disable LiteLLM's internal logging by setting propagate to False
    for logger_name in ["LiteLLM", "litellm"]:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.ERROR)
        logger.propagate = False

    # Try to disable LiteLLM's verbose mode directly
    try:
        import litellm

        litellm.set_verbose = False
        # Disable success callbacks which generate verbose logs
        if hasattr(litellm, "success_callback"):
            litellm.success_callback = []
    except (ImportError, AttributeError):
        pass  # LiteLLM might not be installed or API changed

    # Also suppress httpx/httpcore which LiteLLM uses for making API calls
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
