#!/usr/bin/env python3
"""
OTP Manager: Utility for loading stored OTP codes for automatic 2FA.
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_OTP_FILE = Path(__file__).parent.parent / "auth_states" / ".otp_codes"


def load_otp_for_domain(domain: str, otp_file: str | None = None) -> str | None:
    """
    Load OTP code for a given domain from the OTP file.

    Args:
        domain: Domain to look up (e.g., 'honeycombinsurance.com')
        otp_file: Optional path to OTP file (defaults to auth_states/.otp_codes)

    Returns:
        OTP code string if found, None otherwise

    File format (CSV):
        domain,otp_code
        honeycombinsurance.com,115566
    """
    if otp_file is None:
        otp_file = str(DEFAULT_OTP_FILE)

    try:
        file_path = Path(otp_file)
        if not file_path.exists():
            logger.debug(f"OTP file not found: {otp_file}")
            return None

        with open(file_path) as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()

                # Skip empty lines and comments
                if not line or line.startswith("#"):
                    continue

                try:
                    parts = line.split(",")
                    if len(parts) != 2:
                        logger.warning(
                            f"Invalid format on line {line_num}: expected 2 fields, got {len(parts)}"
                        )
                        continue

                    file_domain, otp_code = [p.strip() for p in parts]

                    # Match domain (exact match or subdomain)
                    if domain == file_domain or domain.endswith(f".{file_domain}"):
                        logger.info(f"Found OTP code for domain: {domain}")
                        return otp_code

                except ValueError as e:
                    logger.warning(f"Error parsing line {line_num}: {e}")
                    continue

        logger.debug(f"No OTP code found for domain: {domain}")
        return None

    except Exception as e:
        logger.error(f"Error reading OTP file: {e}")
        return None


def domain_has_otp(domain: str, otp_file: str | None = None) -> bool:
    """
    Check if OTP code exists for a given domain.

    Args:
        domain: Domain to check
        otp_file: Optional path to OTP file

    Returns:
        True if OTP code exists for domain
    """
    return load_otp_for_domain(domain, otp_file) is not None
