#!/usr/bin/env python3
"""
Password Manager: Utility for loading stored credentials for automatic login.
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_PASSWORDS_FILE = Path(__file__).parent.parent / "auth_states" / ".passwords"


def load_credentials_for_domain(
    domain: str, passwords_file: str | None = None
) -> tuple[str, str] | None:
    """
    Load username and password for a given domain from the passwords file.

    Args:
        domain: Domain to look up (e.g., 'cloudinary.com')
        passwords_file: Optional path to passwords file (defaults to auth_states/.passwords)

    Returns:
        Tuple of (username, password) if found, None otherwise

    File format (CSV):
        domain,username,password
        cloudinary.com,user@example.com,Pass123!
    """
    if passwords_file is None:
        passwords_file = str(DEFAULT_PASSWORDS_FILE)

    try:
        file_path = Path(passwords_file)
        if not file_path.exists():
            logger.debug(f"Passwords file not found: {passwords_file}")
            return None

        with open(file_path) as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()

                # Skip empty lines and comments
                if not line or line.startswith("#"):
                    continue

                try:
                    parts = line.split(",")
                    if len(parts) != 3:
                        logger.warning(
                            f"Invalid format on line {line_num}: expected 3 fields, got {len(parts)}"
                        )
                        continue

                    file_domain, username, password = [p.strip() for p in parts]

                    # Match domain (exact match or subdomain)
                    if domain == file_domain or domain.endswith(f".{file_domain}"):
                        logger.info(f"Found credentials for domain: {domain}")
                        return (username, password)

                except ValueError as e:
                    logger.warning(f"Error parsing line {line_num}: {e}")
                    continue

        logger.debug(f"No credentials found for domain: {domain}")
        return None

    except Exception as e:
        logger.error(f"Error reading passwords file: {e}")
        return None


def domain_has_credentials(domain: str, passwords_file: str | None = None) -> bool:
    """
    Check if credentials exist for a given domain.

    Args:
        domain: Domain to check
        passwords_file: Optional path to passwords file

    Returns:
        True if credentials exist, False otherwise
    """
    return load_credentials_for_domain(domain, passwords_file) is not None
