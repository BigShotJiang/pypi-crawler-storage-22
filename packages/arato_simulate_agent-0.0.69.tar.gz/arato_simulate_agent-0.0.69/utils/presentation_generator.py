"""
Presentation generator utility using reveal.js.

This module generates standalone HTML presentations from custom report markdown
using reveal.js for proper slide rendering and navigation.
"""

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)


def generate_presentation(
    report_data: dict[str, Any] | None = None,
    report_data_file: str | None = None,
    output_file: str | None = None,
) -> str | None:
    """
    Generate a standalone reveal.js presentation from custom report content.

    Args:
        report_data: Pre-built report data dictionary (from report_data_generator)
        report_data_file: Path to report_data.json file to load
        output_file: Path to write the presentation HTML (optional)

    Returns:
        Complete HTML string with reveal.js presentation, or None if no custom report

    Note:
        Either report_data or report_data_file must be provided.
        If both are provided, report_data takes precedence.
    """
    # Load report data from file if not provided directly
    if report_data is None:
        if report_data_file is None:
            raise ValueError("Either report_data or report_data_file must be provided")

        with open(report_data_file, encoding="utf-8") as f:
            report_data = json.load(f)

    # Check if custom report exists
    custom_report = report_data.get("custom_report")
    if not custom_report:
        logger.info("No custom report found, skipping presentation generation")
        return None

    content = custom_report.get("content", "")
    if not content:
        logger.info("Custom report content is empty, skipping presentation generation")
        return None

    title = custom_report.get("title", "Presentation")
    metadata = report_data.get("metadata", {})
    target_url = metadata.get("target_url", "")

    # Convert Slidev-style markdown to reveal.js markdown
    slides_markdown = _convert_to_reveal_markdown(content)

    # Generate HTML
    html = _generate_reveal_html(title, slides_markdown, target_url)

    # Write to file if output path provided
    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(html)
        logger.info(f"✅ Presentation saved to: {output_file}")

    return html


def _convert_to_reveal_markdown(content: str) -> str:
    """
    Convert Slidev-style markdown to reveal.js compatible markdown.

    Reveal.js uses --- for horizontal slides and -- for vertical slides.
    It also supports data attributes in HTML comments.

    Args:
        content: Slidev-style markdown content

    Returns:
        Reveal.js compatible markdown
    """
    # Strip code block wrapper if present (```yaml ... ```)
    content = content.strip()
    if content.startswith("```yaml"):
        content = content[7:]  # Remove ```yaml
    elif content.startswith("```"):
        content = content[3:]  # Remove ```

    if content.endswith("```"):
        content = content[:-3]  # Remove trailing ```

    content = content.strip()

    lines = content.split("\n")
    output_lines = []
    skip_until_separator = False
    current_layout = "default"

    i = 0
    while i < len(lines):
        line = lines[i]

        # Skip YAML frontmatter blocks (--- at start)
        if line.strip() == "---" and i == 0:
            # Start of headmatter - skip until next ---
            skip_until_separator = True
            i += 1
            continue

        if skip_until_separator:
            if line.strip() == "---":
                skip_until_separator = False
            i += 1
            continue

        # Handle slide separator with layout
        if line.strip() == "---":
            # Check if next line is a layout declaration
            if i + 1 < len(lines) and lines[i + 1].strip().startswith("layout:"):
                layout_line = lines[i + 1].strip()
                current_layout = layout_line.replace("layout:", "").strip().strip("\"'")
                # Add slide separator with data attribute
                output_lines.append("")
                output_lines.append("---")
                output_lines.append(f'<!-- .slide: data-layout="{current_layout}" -->')
                i += 2  # Skip the layout line

                # Skip any additional YAML-like lines (class:, background:, etc.)
                while (
                    i < len(lines)
                    and lines[i].strip()
                    and ":" in lines[i]
                    and not lines[i].strip().startswith("#")
                ):
                    i += 1

                # Skip the closing --- of the YAML block if present
                if i < len(lines) and lines[i].strip() == "---":
                    i += 1

                continue
            else:
                # Plain separator
                output_lines.append("")
                output_lines.append("---")
                output_lines.append("")
                current_layout = "default"
                i += 1
                continue

        # Handle standalone layout: lines (without preceding ---)
        if line.strip().startswith("layout:"):
            current_layout = line.strip().replace("layout:", "").strip().strip("\"'")
            output_lines.append(f'<!-- .slide: data-layout="{current_layout}" -->')
            i += 1
            continue

        # Skip other YAML-like config lines at slide start
        if line.strip() and ":" in line and not line.strip().startswith("#"):
            stripped = line.strip().split(":")[0]
            if stripped in [
                "class",
                "background",
                "transition",
                "theme",
                "title",
                "info",
                "drawings",
            ]:
                i += 1
                continue

        # Handle ::right:: separator for two-cols layout
        if line.strip() == "::right::":
            # Mark transition to right column with a comment
            # reveal.js will handle this via CSS flexbox on the slide
            output_lines.append("")
            output_lines.append("---")
            output_lines.append('<!-- .slide: data-layout="two-cols-right" -->')
            output_lines.append("")
            i += 1
            continue

        # Regular content line
        output_lines.append(line)
        i += 1

    return "\n".join(output_lines)


def _generate_reveal_html(
    title: str,
    slides_markdown: str,
    target_url: str = "",  # noqa: ARG001
) -> str:
    """
    Generate complete reveal.js HTML presentation.

    Args:
        title: Presentation title
        slides_markdown: Markdown content for slides
        target_url: Optional target URL for context (reserved for future use)

    Returns:
        Complete HTML string
    """
    # Escape markdown for embedding in HTML
    # We use a textarea trick to avoid escaping issues
    escaped_markdown = slides_markdown.replace("</script>", "<\\/script>")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>

  <!-- Reveal.js CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/dist/reset.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/dist/reveal.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/dist/theme/white.css">

  <!-- Highlight.js for code -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/plugin/highlight/monokai.css">

  <style>
    :root {{
      --r-heading-color: #1e293b;
      --r-main-color: #334155;
      --r-link-color: #4f46e5;
      --r-background-color: #f8fafc;
    }}

    .reveal {{
      font-family: 'Public Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }}

    .reveal h1, .reveal h2, .reveal h3 {{
      text-transform: none;
      font-weight: 700;
    }}

    .reveal h1 {{
      font-size: 2.2em;
      margin-bottom: 0.5em;
    }}

    .reveal h2 {{
      font-size: 1.6em;
      margin-bottom: 0.4em;
    }}

    .reveal table {{
      margin: 20px auto;
      border-collapse: collapse;
      font-size: 0.7em;
    }}

    .reveal th, .reveal td {{
      padding: 8px 16px;
      border: 1px solid #e2e8f0;
      text-align: left;
    }}

    .reveal th {{
      background: #f1f5f9;
      font-weight: 600;
    }}

    .reveal ul, .reveal ol {{
      text-align: left;
      margin-left: 1em;
    }}

    .reveal li {{
      margin-bottom: 0.5em;
      line-height: 1.4;
    }}

    .reveal blockquote {{
      background: #fefce8;
      border-left: 4px solid #eab308;
      padding: 1em 1.5em;
      margin: 1em 0;
      font-style: italic;
      text-align: left;
      width: 90%;
    }}

    .reveal code {{
      background: #f1f5f9;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 0.85em;
    }}

    /* Layout: Cover */
    .reveal section[data-layout="cover"] {{
      background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
    }}

    .reveal section[data-layout="cover"] h1,
    .reveal section[data-layout="cover"] h2,
    .reveal section[data-layout="cover"] p {{
      color: white;
    }}

    /* Layout: Section */
    .reveal section[data-layout="section"] {{
      background: linear-gradient(135deg, #4f46e5 0%, #6366f1 100%);
      display: flex !important;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
    }}

    .reveal section[data-layout="section"] h1,
    .reveal section[data-layout="section"] h2,
    .reveal section[data-layout="section"] p {{
      color: white;
    }}

    .reveal section[data-layout="section"] h1 {{
      font-size: 2em;
      margin-bottom: 8px;
    }}

    .reveal section[data-layout="section"] p {{
      opacity: 0.9;
      font-size: 1.1em;
    }}

    /* Layout: Fact */
    .reveal section[data-layout="fact"] {{
      background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
      border: 2px solid #22c55e;
      display: flex !important;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
    }}

    .reveal section[data-layout="fact"] h1 {{
      font-size: 4em;
      color: #16a34a;
      margin-bottom: 16px;
    }}

    .reveal section[data-layout="fact"] p {{
      color: #166534;
      font-size: 1.2em;
    }}

    /* Layout: Quote */
    .reveal section[data-layout="quote"] {{
      background: #fefce8;
      border-left: 6px solid #eab308;
      display: flex !important;
      flex-direction: column;
      justify-content: center;
      padding: 40px 48px !important;
    }}

    .reveal section[data-layout="quote"] h1 {{
      font-size: 1.4em;
      font-style: italic;
      line-height: 1.6;
      color: #713f12;
      margin-bottom: 24px;
    }}

    .reveal section[data-layout="quote"] p {{
      color: #92400e;
      font-size: 0.95em;
    }}

    /* Layout: Two-cols (left side) */
    .reveal section[data-layout="two-cols"] {{
      text-align: left;
    }}

    /* Layout: Two-cols-right (right side continues) */
    .reveal section[data-layout="two-cols-right"] {{
      text-align: left;
    }}

    /* Status indicators */
    .reveal .status-good {{ color: #16a34a; }}
    .reveal .status-warning {{ color: #ca8a04; }}
    .reveal .status-critical {{ color: #dc2626; }}

    /* Footer */
    .reveal .slide-footer {{
      position: absolute;
      bottom: 20px;
      left: 20px;
      font-size: 0.5em;
      color: #94a3b8;
    }}

    /* Progress bar */
    .reveal .progress {{
      color: #4f46e5;
    }}

    /* Slide numbers */
    .reveal .slide-number {{
      font-size: 14px;
      color: #64748b;
    }}
  </style>
</head>
<body>
  <div class="reveal">
    <div class="slides">
      <section data-markdown data-separator="^---$" data-separator-vertical="^--$">
        <textarea data-template>
{escaped_markdown}
        </textarea>
      </section>
    </div>
  </div>

  <!-- Reveal.js and plugins -->
  <script src="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/dist/reveal.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/plugin/markdown/markdown.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/plugin/highlight/highlight.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/reveal.js@4.6.1/plugin/notes/notes.js"></script>

  <script>
    Reveal.initialize({{
      hash: true,
      slideNumber: 'c/t',
      showSlideNumber: 'all',
      transition: 'slide',
      backgroundTransition: 'fade',
      center: true,
      width: 1200,
      height: 700,
      margin: 0.1,
      plugins: [RevealMarkdown, RevealHighlight, RevealNotes],

      // Apply data-layout attributes after slides are parsed
      markdown: {{
        smartypants: true
      }}
    }});

    // Apply layout classes based on data-layout attributes
    Reveal.on('ready', function() {{
      document.querySelectorAll('section[data-layout]').forEach(function(slide) {{
        // Layout is already applied via CSS attribute selectors
      }});
    }});
  </script>
</body>
</html>"""

    return html


def generate_presentation_for_session(session_dir: str) -> str | None:
    """
    Generate presentation for a session directory.

    Args:
        session_dir: Path to session directory containing report_data.json

    Returns:
        Path to generated presentation file, or None if no custom report
    """
    report_data_file = os.path.join(session_dir, "report_data.json")

    if not os.path.exists(report_data_file):
        logger.warning(f"No report_data.json found in {session_dir}")
        return None

    output_file = os.path.join(session_dir, "presentation.html")

    html = generate_presentation(
        report_data_file=report_data_file,
        output_file=output_file,
    )

    if html:
        return output_file
    return None
