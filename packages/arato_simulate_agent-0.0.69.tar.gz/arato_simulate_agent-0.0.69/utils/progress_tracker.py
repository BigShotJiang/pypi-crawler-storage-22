"""
Progress tracker for monitoring orchestrator and persona execution state.

This module provides real-time progress tracking by:
1. Maintaining state for orchestrator and each running persona
2. Writing updates to a local JSON file
3. Automatically uploading to platform storage on each update (in background thread)
"""

import atexit
import json
import logging
import queue
import threading
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Any

from constants import (
    ARTIFACT_UPLOAD_INTERVAL_SECONDS,
    REPORT_DATA_FILENAME,
    S3_UPLOAD_INTERVAL_SECONDS,
)
from core.storage import get_storage_adapter

logger = logging.getLogger(__name__)


# Background upload worker for non-blocking S3 uploads
class _BackgroundUploader:
    """Background thread worker for non-blocking S3 progress uploads.

    Uses a queue to batch uploads and avoid blocking the main thread.
    Only keeps the latest progress data - intermediate states are dropped.
    """

    def __init__(self) -> None:
        self._queue: queue.Queue[tuple[str, str, str | None, str | None] | None] = (
            queue.Queue()
        )
        self._thread: threading.Thread | None = None
        self._running = False
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start the background upload worker thread."""
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._running = True
            self._thread = threading.Thread(
                target=self._worker, daemon=True, name="progress-uploader"
            )
            self._thread.start()
            atexit.register(self.stop)

    def stop(self) -> None:
        """Stop the background upload worker and wait for pending uploads."""
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._queue.put(None)  # Sentinel to stop worker
        if self._thread is not None:
            self._thread.join(timeout=5.0)  # Wait max 5 seconds for pending uploads

    def enqueue(
        self,
        progress_file_path: str,
        session_id: str,
        org_id: str | None,
        task_id: str | None,
    ) -> None:
        """Queue a progress upload for background processing.

        Args:
            progress_file_path: Path to the local progress.json file
            session_id: Session identifier
            org_id: Optional organization ID
            task_id: Optional task ID
        """
        self.start()  # Ensure worker is running
        # Clear any pending items and add latest (we only care about latest state)
        try:
            while True:
                self._queue.get_nowait()
        except queue.Empty:
            pass
        self._queue.put((progress_file_path, session_id, org_id, task_id))

    def _worker(self) -> None:
        """Background worker that processes upload queue."""
        storage = get_storage_adapter()
        while self._running:
            try:
                item = self._queue.get(timeout=0.5)
                if item is None:  # Sentinel to stop
                    break
                progress_file_path, session_id, org_id, task_id = item
                try:
                    storage.upload_progress_file(
                        progress_file_path=progress_file_path,
                        session_id=session_id,
                        org_id=org_id,
                        task_id=task_id,
                    )
                    logger.debug(f"Background upload: progress.json for {session_id}")
                except Exception as e:
                    logger.warning(f"Background upload failed: {e}")
            except queue.Empty:
                continue
            except Exception as e:
                logger.warning(f"Background uploader error: {e}")


# Global background uploader instance
_background_uploader = _BackgroundUploader()


class _ArtifactBackgroundUploader:
    """Background thread pool for periodic persona artifact uploads.

    Uploads transcript.json and screenshots from persona directories
    to storage periodically during execution, not just at completion.
    Throttled per-persona to avoid excessive uploads.
    Uses a ThreadPoolExecutor (4 workers) for concurrent uploads at scale.
    """

    def __init__(self) -> None:
        import concurrent.futures

        self._executor: concurrent.futures.ThreadPoolExecutor | None = None
        self._lock = threading.Lock()
        self._last_upload_times: dict[str, float] = {}
        self._running = False

    def start(self) -> None:
        """Start the background artifact upload thread pool."""
        import concurrent.futures

        with self._lock:
            if self._executor is not None:
                return
            self._running = True
            self._executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=4, thread_name_prefix="artifact-uploader"
            )
            atexit.register(self.stop)

    def stop(self) -> None:
        """Stop the background artifact upload thread pool.

        Cancels pending uploads and does not block on in-flight ones.
        Final uploads happen synchronously at pipeline completion, so
        we don't need to wait here (especially at atexit/interpreter exit).
        """
        with self._lock:
            if not self._running:
                return
            self._running = False
            executor = self._executor
            self._executor = None

        if executor:
            executor.shutdown(wait=False, cancel_futures=True)

    def enqueue(
        self,
        persona_dir: str,
        persona_instance: str,
        session_id: str,
        org_id: str | None,
        task_id: str | None,
    ) -> None:
        """Queue persona artifacts for background upload.

        Throttled per persona - only uploads if enough time has elapsed
        since the last upload for this persona.

        Args:
            persona_dir: Path to the persona's output directory
            persona_instance: Persona instance name
            session_id: Session identifier
            org_id: Optional organization ID
            task_id: Optional task ID
        """
        import time

        now = time.time()
        last = self._last_upload_times.get(persona_instance, 0)
        if (now - last) < ARTIFACT_UPLOAD_INTERVAL_SECONDS:
            return  # Throttled

        self.start()  # Ensure pool is running
        self._last_upload_times[persona_instance] = now
        if self._executor:
            self._executor.submit(
                self._upload_one,
                persona_dir,
                persona_instance,
                session_id,
                org_id,
                task_id,
            )

    def _upload_one(
        self,
        persona_dir: str,
        persona_instance: str,
        session_id: str,
        org_id: str | None,
        task_id: str | None,
    ) -> None:
        """Upload artifacts for a single persona (runs in thread pool)."""
        try:
            storage = get_storage_adapter()
            file_urls = storage.upload_persona_artifacts(
                persona_directory=persona_dir,
                persona_instance_name=persona_instance,
                session_id=session_id,
                org_id=org_id,
                task_id=task_id,
            )
            logger.debug(
                f"Background artifact upload: {persona_instance} "
                f"({len(file_urls)} files)"
            )
        except Exception as e:
            logger.warning(
                f"Background artifact upload failed for {persona_instance}: {e}"
            )


# Global artifact background uploader instance
_artifact_uploader = _ArtifactBackgroundUploader()


class ExecutionStatus(StrEnum):
    """Status of a running entity (orchestrator or persona)."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


class OrchestratorPhase(StrEnum):
    """Phases of orchestrator execution."""

    INITIALIZING = "initializing"
    DISCOVERY = "discovery"
    RUNNING_PERSONAS = "running_personas"
    GENERATING_SUMMARY = "generating_summary"
    UPLOADING_ARTIFACTS = "uploading_artifacts"
    COMPLETE = "complete"


class FinishReason(StrEnum):
    """Reason why a persona finished execution."""

    REACHED_MAX_TURNS = "reached_max_turns"  # Completed all requested turns
    AGENT_STOPPED = "agent_stopped"  # Agent decided to stop (natural completion)
    CHATBOT_STOPPED = "chatbot_stopped"  # Chatbot ended conversation (escalation, etc.)
    TIMEOUT = "timeout"  # Timeout limit reached
    USER_STOPPED = "user_stopped"  # User requested stop via UI
    ERROR = "error"  # Failed with error
    UNKNOWN = "unknown"  # Reason not specified


@dataclass
class ResourceUsage:
    """Resource usage metrics."""

    total_api_calls: int = 0
    total_tokens_used: int = 0
    total_screenshots: int = 0
    total_dom_queries: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


@dataclass
class ProgressEstimation:
    """Progress estimation based on current step vs total steps."""

    completion_percentage: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


@dataclass
class PersonaProgress:
    """Progress tracking for a single persona instance."""

    persona_id: str
    instance_name: str
    status: ExecutionStatus
    current_step: int = 0
    total_steps: int = 0
    last_action: str = ""
    error: str | None = None
    started_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    completed_at: str | None = None
    transcript_turns: int = 0
    progress: ProgressEstimation = field(default_factory=ProgressEstimation)
    finish_reason: FinishReason | None = (
        None  # Stored as dict, converted to Pydantic on export
    )
    persona_video: str | None = None  # Relative path to persona run video
    transcript_json: str | None = None  # Relative path to transcript JSON
    summary_json: str | None = None  # Relative path to summary markdown
    screenshots: list[str] = field(default_factory=list)  # Resolved screenshot URLs
    hitl_intervention: dict[str, Any] | None = (
        None  # HITL intervention details if waiting
    )
    browser_session_id: str | None = None  # AgentCore browser session ID (for DCV)
    browser_type: str | None = None  # "agentcore" | "local" | None
    browser_identifier: str | None = (
        None  # AgentCore browser identifier (for DCV API path)
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        data = asdict(self)
        # Flatten progress into top-level completion_percentage
        data["completion_percentage"] = self.progress.completion_percentage
        del data["progress"]
        return data


@dataclass
class AppDiscoveryProgress:
    """Progress tracking for app context discovery."""

    status: ExecutionStatus
    current_step: int = 0
    total_steps: int = 5  # Default max_steps in discover_app_context
    last_action: str = ""
    started_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    completed_at: str | None = None
    error: str | None = None
    app_context_json: str | None = None
    screenshots: list[str] = field(default_factory=list)
    discovery_video: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


@dataclass
class OrchestratorProgress:
    """Progress tracking for the orchestrator."""

    session_id: str
    target_url: str
    status: ExecutionStatus
    phase: OrchestratorPhase
    total_personas: int
    completed_personas: int = 0
    failed_personas: int = 0
    last_action: str = ""
    error: str | None = None
    started_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    completed_at: str | None = None
    goal: str = "chat"
    app_context_cached: bool = False
    personas: dict[str, int] = field(default_factory=dict)
    org_id: str | None = None
    task_id: str | None = None
    run_summary_json: str | None = None  # Relative path to consolidated summary
    # Graph node tracking
    graph_nodes: dict[str, dict[str, Any]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


# Graph node names in execution order
GRAPH_NODE_NAMES = [
    "connectivity_check",
    "session_setup",
    "app_discovery",
    "ground_truth",
    "persona_runner",
    "cross_conversation",
    "summary",
    "artifact_upload",
    "task_completion",
]


@dataclass
class GraphNodeState:
    """State of a single graph node."""

    name: str
    status: str = "pending"  # pending, running, completed, skipped, failed
    started_at: str | None = None
    completed_at: str | None = None
    duration_ms: int | None = None
    error: str | None = None
    # Strands telemetry
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    latency_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


class ProgressTracker:
    """
    Tracks execution progress for orchestrator and personas.

    Writes updates to a local progress.json file and uploads to platform storage
    on each update for real-time monitoring.
    """

    PROGRESS_FILENAME = "progress.json"

    def __init__(
        self,
        session_id: str,
        target_url: str,
        output_dir: str,
        total_personas: int,
        org_id: str | None = None,
        task_id: str | None = None,
        goal: str = "chat",
        polling_client: Any | None = None,
        task: Any | None = None,
    ):
        """
        Initialize progress tracker.

        Args:
            session_id: Unique session identifier
            target_url: Target URL being tested
            output_dir: Directory for progress file
            total_personas: Total number of personas to run
            org_id: Optional organization ID for S3 prefix
            task_id: Optional task ID for S3 prefix
            goal: Execution mode (chat/discover)
            polling_client: Optional polling client for sending updates to external API
            task: Optional task payload for external API updates
        """
        self.session_id = session_id
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.progress_file = self.output_dir / self.PROGRESS_FILENAME
        self.org_id = org_id
        self.task_id = task_id
        self.polling_client = polling_client
        self.task = task
        self.target_url = target_url
        self.storage = get_storage_adapter()

        # S3 upload throttling
        self._last_s3_upload_time: float = 0.0
        self._pending_s3_upload: bool = False

        # Local file write throttling (reduces JSON serialization overhead at scale)
        self._dirty: bool = False
        self._last_write_time: float = 0.0
        self._write_min_interval: float = 1.0  # At most 1 write/sec to progress.json

        # Initialize state
        self.orchestrator = OrchestratorProgress(
            session_id=session_id,
            target_url=target_url,
            status=ExecutionStatus.PENDING,
            phase=OrchestratorPhase.INITIALIZING,
            total_personas=total_personas,
            goal=goal,
            org_id=org_id,
            task_id=task_id,
        )

        # Initialize graph node states for pipeline visualization
        for node_name in GRAPH_NODE_NAMES:
            self.orchestrator.graph_nodes[node_name] = GraphNodeState(
                name=node_name
            ).to_dict()

        self.app_discovery: AppDiscoveryProgress | None = None
        self.personas: dict[str, PersonaProgress] = {}
        self.file_url_mappings: dict[str, str] = {}
        self.stop_requested: bool = False  # Set when server sends stop command

        # Write initial state
        self._write_progress()
        self._upload_progress(force=True)

    def set_file_url_mappings(self, file_urls: dict[str, str]) -> None:
        """Set the file URL mappings from the storage adapter.

        Args:
            file_urls: Dictionary mapping relative file paths to full storage URLs
        """
        self.file_url_mappings = file_urls
        logger.debug(f"Updated file URL mappings with {len(file_urls)} entries")

        # Refresh all persona artifact URLs now that mappings are available
        self._refresh_persona_artifact_urls()

        # Refresh orchestrator artifact URLs as well
        self._refresh_orchestrator_artifact_urls()

    def add_domain_artifact_urls(self, domain_artifacts: dict[str, str]) -> None:
        """Add domain-level artifact URLs to the file mappings.

        Args:
            domain_artifacts: Dictionary mapping domain artifact keys to their full URLs
        """
        if not domain_artifacts:
            return

        # Merge domain artifact URLs with session artifact URLs
        self.file_url_mappings.update(domain_artifacts)
        logger.debug(f"Added {len(domain_artifacts)} domain artifact URLs to mappings")

    def _resolve_file_url(self, relative_path: str | None) -> str | None:
        """Resolve a relative path to its full storage URL using mappings.

        Args:
            relative_path: Relative file path from artifacts

        Returns:
            Full storage URL if found in mappings, otherwise returns relative_path unchanged
        """
        if not relative_path:
            return None

        # Check if we have a mapping for this file
        if relative_path in self.file_url_mappings:
            return self.file_url_mappings[relative_path]

        # If no mapping found, return the relative path as-is (fallback)
        return relative_path

    def _refresh_persona_artifact_urls(self) -> None:
        """Set persona artifact URLs using file mappings (called after upload)."""
        from constants import RUN_VIDEO_FILENAME, SUMMARY_FILENAME, TRANSCRIPT_FILENAME

        for _persona_name, persona in self.personas.items():
            # Construct expected relative paths based on persona instance name
            instance_name = persona.instance_name
            if not instance_name:
                continue

            # Expected relative paths that should match file_url_mappings keys
            expected_video_path = f"{instance_name}/{RUN_VIDEO_FILENAME}"  # e.g. "boundary_user_01/run.mp4"
            expected_transcript_path = f"{instance_name}/{TRANSCRIPT_FILENAME}"  # e.g. "boundary_user_01/transcript.json"
            expected_summary_path = f"{instance_name}/{SUMMARY_FILENAME}"  # e.g. "boundary_user_01/summary.md"

            # Set artifact URLs from file mappings if available
            if expected_video_path in self.file_url_mappings:
                persona.persona_video = self.file_url_mappings[expected_video_path]

            if expected_transcript_path in self.file_url_mappings:
                persona.transcript_json = self.file_url_mappings[
                    expected_transcript_path
                ]

            if expected_summary_path in self.file_url_mappings:
                persona.summary_json = self.file_url_mappings[expected_summary_path]

            # Collect screenshot URLs from file mappings
            prefix = f"{instance_name}/"
            screenshot_urls = [
                url
                for key, url in self.file_url_mappings.items()
                if key.startswith(prefix)
                and key.lower().endswith((".png", ".jpg", ".jpeg"))
                # Defensive: exclude video path even though it shouldn't match image extensions
                and key != expected_video_path
            ]
            if screenshot_urls:
                persona.screenshots = sorted(screenshot_urls)

        logger.debug(
            f"Set artifact URLs for {len(self.personas)} personas using file mappings"
        )

        # Write and upload the updated progress after URL refresh
        self._dirty = True
        self._flush_write()
        self._upload_progress()

    def _refresh_orchestrator_artifact_urls(self) -> None:
        """Set orchestrator artifact URLs using file mappings (called after upload)."""

        # The orchestrator consolidated report is at the root level (not in a persona subdirectory)
        if REPORT_DATA_FILENAME in self.file_url_mappings:
            self.orchestrator.run_summary_json = self.file_url_mappings[
                REPORT_DATA_FILENAME
            ]
            logger.debug(
                f"Updated orchestrator run_summary_json: {self.orchestrator.run_summary_json}"
            )

    def init_app_discovery(self, total_steps: int = 5) -> None:
        """Initialize app discovery tracking.

        Args:
            total_steps: Expected total steps (default: 5, matching agent max_steps)
        """
        self.app_discovery = AppDiscoveryProgress(
            status=ExecutionStatus.PENDING,
            total_steps=total_steps,
        )
        self._write_progress()
        self._upload_progress()

    def update_app_discovery(
        self,
        status: ExecutionStatus | None = None,
        current_step: int | None = None,
        last_action: str | None = None,
        error: str | None = None,
        app_context_json: str | None = None,
        screenshots: list[str] | None = None,
        discovery_video: str | None = None,
    ) -> None:
        """Update app discovery progress.

        Args:
            status: New execution status
            current_step: Current step number
            last_action: Description of last action
            error: Error message if failed
            app_context_json: Discovered application context JSON
            screenshots: List of screenshot filenames captured during discovery
            discovery_video: Relative path to discovery video file
        """
        if not self.app_discovery:
            logger.warning("App discovery not initialized, initializing now")
            self.init_app_discovery()

        if self.app_discovery:
            if status is not None:
                self.app_discovery.status = status
                if status in (ExecutionStatus.COMPLETED, ExecutionStatus.FAILED):
                    self.app_discovery.completed_at = datetime.now(UTC).isoformat()

            if current_step is not None:
                self.app_discovery.current_step = current_step

            if last_action is not None:
                self.app_discovery.last_action = last_action

            if error is not None:
                self.app_discovery.error = error

            if app_context_json is not None:
                self.app_discovery.app_context_json = app_context_json

        if screenshots is not None and self.app_discovery:
            # Resolve screenshot URLs using mappings
            resolved_screenshots = []
            for screenshot in screenshots:
                resolved_url = self._resolve_file_url(screenshot)
                resolved_screenshots.append(resolved_url or screenshot)
            self.app_discovery.screenshots = resolved_screenshots

        if discovery_video is not None and self.app_discovery:
            # Resolve discovery video URL using mappings
            resolved_video_url = self._resolve_file_url(discovery_video)
            self.app_discovery.discovery_video = resolved_video_url or discovery_video

            self._write_progress()
            self._upload_progress()

    def update_orchestrator(
        self,
        status: ExecutionStatus | None = None,
        phase: OrchestratorPhase | None = None,
        last_action: str | None = None,
        error: str | None = None,
        app_context_cached: bool | None = None,
        run_summary_json: str | None = None,
    ) -> None:
        """
        Update orchestrator progress.

        Args:
            status: New execution status
            phase: New execution phase
            last_action: Description of last action taken
            error: Error message if failed
            app_context_cached: Whether app context was cached
            run_summary_json: Relative path to consolidated summary JSON file
        """
        # Track if this is a completing/failing update (should force S3 upload)
        force_upload = False
        # Any status/phase change triggers immediate write (these are infrequent)
        force_write = status is not None or phase is not None

        if status is not None:
            self.orchestrator.status = status
            if status in (ExecutionStatus.COMPLETED, ExecutionStatus.FAILED):
                self.orchestrator.completed_at = datetime.now(UTC).isoformat()
                force_upload = True  # Force upload when orchestrator completes/fails

        if phase is not None:
            self.orchestrator.phase = phase

        if last_action is not None:
            self.orchestrator.last_action = last_action

        if error is not None:
            self.orchestrator.error = error

        if app_context_cached is not None:
            self.orchestrator.app_context_cached = app_context_cached

        if run_summary_json is not None:
            resolved_summary_url = self._resolve_file_url(run_summary_json)
            self.orchestrator.run_summary_json = (
                resolved_summary_url or run_summary_json
            )

        if force_upload or force_write:
            self._dirty = True
            self._flush_write()  # Ensure fresh data for state changes and forced uploads
        else:
            self._schedule_write()
        self._upload_progress(force=force_upload)

    def update_graph_node(
        self,
        node_name: str,
        status: str,
        error: str | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        total_tokens: int | None = None,
        latency_ms: int | None = None,
    ) -> None:
        """
        Update graph node status and Strands telemetry metrics.

        Args:
            node_name: Name of the graph node (e.g., 'connectivity_check')
            status: Node status ('pending', 'running', 'completed', 'skipped', 'failed')
            error: Error message if failed
            input_tokens: Strands accumulated input tokens
            output_tokens: Strands accumulated output tokens
            total_tokens: Strands accumulated total tokens
            latency_ms: Strands accumulated latency in milliseconds
        """
        if node_name not in self.orchestrator.graph_nodes:
            self.orchestrator.graph_nodes[node_name] = GraphNodeState(
                name=node_name
            ).to_dict()

        node = self.orchestrator.graph_nodes[node_name]

        # Track timing when transitioning to running
        if status == "running" and node.get("status") == "pending":
            node["started_at"] = datetime.now(UTC).isoformat()

        node["status"] = status

        # Track completion timing
        if status in ("completed", "skipped", "failed"):
            node["completed_at"] = datetime.now(UTC).isoformat()
            if node.get("started_at"):
                try:
                    start = datetime.fromisoformat(node["started_at"])
                    end = datetime.fromisoformat(node["completed_at"])
                    node["duration_ms"] = int((end - start).total_seconds() * 1000)
                except (ValueError, TypeError):
                    pass

        if error is not None:
            node["error"] = error
        if input_tokens is not None:
            node["input_tokens"] = input_tokens
        if output_tokens is not None:
            node["output_tokens"] = output_tokens
        if total_tokens is not None:
            node["total_tokens"] = total_tokens
        if latency_ms is not None:
            node["latency_ms"] = latency_ms

        self._schedule_write()
        self._upload_progress()

    def add_persona(
        self, persona_id: str, instance_name: str, total_steps: int = 0
    ) -> None:
        """
        Add a persona to track.

        Args:
            persona_id: Base persona identifier
            instance_name: Unique instance name
            total_steps: Expected total steps (if known)
        """
        self.personas[instance_name] = PersonaProgress(
            persona_id=persona_id,
            instance_name=instance_name,
            status=ExecutionStatus.PENDING,
            total_steps=total_steps,
        )

        # Update persona counts
        if persona_id not in self.orchestrator.personas:
            self.orchestrator.personas[persona_id] = 0
        self.orchestrator.personas[persona_id] += 1

        self._dirty = True
        self._flush_write()
        self._upload_progress()

    def update_persona(
        self,
        instance_name: str,
        status: ExecutionStatus | None = None,
        current_step: int | None = None,
        last_action: str | None = None,
        error: str | None = None,
        transcript_turns: int | None = None,
        finish_reason: FinishReason | None = None,
        hitl_intervention: dict[str, Any] | None = None,
        persona_video: str | None = None,
        transcript_json: str | None = None,
        summary_json: str | None = None,
        browser_session_id: str | None = None,
        browser_type: str | None = None,
        browser_identifier: str | None = None,
    ) -> None:
        """
        Update persona progress.

        Args:
            instance_name: Persona instance name
            status: New execution status
            current_step: Current step number
            last_action: Description of last action
            error: Error message if failed
            transcript_turns: Number of conversation turns completed
            finish_reason: Reason why persona finished (if completed/failed)
            hitl_intervention: HITL intervention details if waiting for human
            persona_video: Relative path to persona run video file
            transcript_json: Relative path to persona transcript JSON file
            summary_json: Relative path to persona summary markdown file
        """
        if instance_name not in self.personas:
            logger.warning(f"Persona {instance_name} not found in tracker")
            return

        persona = self.personas[instance_name]

        # Track if this is a completing/failing update (should force S3 upload)
        force_upload = False

        if status is not None:
            persona.status = status
            if status in (ExecutionStatus.COMPLETED, ExecutionStatus.FAILED):
                persona.completed_at = datetime.now(UTC).isoformat()
                force_upload = True  # Force upload when persona completes/fails

                # Update orchestrator counters
                if status == ExecutionStatus.COMPLETED:
                    self.orchestrator.completed_personas += 1
                elif status == ExecutionStatus.FAILED:
                    self.orchestrator.failed_personas += 1

                # Set finish reason if completing/failing
                if finish_reason is not None:
                    persona.finish_reason = finish_reason
                elif status == ExecutionStatus.FAILED and error is not None:
                    persona.finish_reason = FinishReason.ERROR
                elif persona.finish_reason is None:
                    # Default to unknown if not specified
                    persona.finish_reason = FinishReason.UNKNOWN

        if current_step is not None:
            persona.current_step = current_step

        if last_action is not None:
            persona.last_action = last_action

        if error is not None:
            persona.error = error

        if transcript_turns is not None:
            persona.transcript_turns = transcript_turns

        if finish_reason is not None and persona.finish_reason is None:
            persona.finish_reason = finish_reason

        if hitl_intervention is not None:
            persona.hitl_intervention = hitl_intervention

        if persona_video is not None:
            resolved_video_url = self._resolve_file_url(persona_video)
            persona.persona_video = resolved_video_url or persona_video

        if transcript_json is not None:
            resolved_transcript_url = self._resolve_file_url(transcript_json)
            persona.transcript_json = resolved_transcript_url or transcript_json

        if summary_json is not None:
            resolved_summary_url = self._resolve_file_url(summary_json)
            persona.summary_json = resolved_summary_url or summary_json

        if browser_session_id is not None:
            persona.browser_session_id = browser_session_id

        if browser_type is not None:
            persona.browser_type = browser_type

        if browser_identifier is not None:
            persona.browser_identifier = browser_identifier

        # Update progress calculation
        self._update_progress(instance_name)

        # update_persona is called for meaningful state changes (not per-turn),
        # so always write immediately. record_persona_turn handles throttling.
        self._dirty = True
        self._flush_write()
        self._upload_progress(force=force_upload)

    def record_persona_turn(
        self,
        instance_name: str,
        turn_number: int,
        current_step: int,
    ) -> None:
        """
        Record a completed conversation turn.

        This method updates the persona's progress tracking.
        Replaces the previous start/complete pattern with a single call after each turn.

        Args:
            instance_name: Persona instance name
            turn_number: Conversation turn number that was completed
            current_step: Current step in the conversation (usually same as turn_number)
        """
        if instance_name not in self.personas:
            logger.warning(f"Persona {instance_name} not found in tracker")
            return

        persona = self.personas[instance_name]
        now = datetime.now()
        timestamp = now.isoformat()

        # Update persona progress
        persona.current_step = current_step
        persona.transcript_turns = turn_number
        persona.updated_at = timestamp
        persona.last_action = f"Completed turn {turn_number}/{persona.total_steps}"

        # Update progress estimation based on current progress
        self._update_progress(instance_name)

        self._dirty = True
        self._flush_write()
        self._upload_progress()

        # Upload persona artifacts incrementally (transcript + screenshots)
        # The persona directory is at {output_dir}/{instance_name}
        persona_dir = self.output_dir / instance_name
        if persona_dir.exists():
            _artifact_uploader.enqueue(
                persona_dir=str(persona_dir),
                persona_instance=instance_name,
                session_id=self.session_id,
                org_id=self.org_id,
                task_id=self.task_id,
            )

        # Send API update every 2 turns (to avoid excessive API calls)
        if turn_number % 2 == 0 and self.polling_client and self.task:
            import asyncio

            try:
                # Schedule async task to send progress update
                asyncio.create_task(self.send_progress_update_to_api())
            except RuntimeError:
                # No event loop running (e.g., in synchronous context)
                # Skip this update, it will be sent at the end by orchestrator
                logger.debug(
                    f"Could not schedule progress update at turn {turn_number} (no event loop)"
                )

    def _update_progress(self, instance_name: str) -> None:
        """
        Update progress estimation based on current progress.

        Note: total_steps is the maximum possible steps, not necessarily
        the actual steps taken. Personas can finish early due to timeouts,
        natural completion, or other reasons.

        Args:
            instance_name: Persona instance name
        """
        if instance_name not in self.personas:
            return

        persona = self.personas[instance_name]

        # If persona is completed or failed, always show 100%
        if persona.status in (ExecutionStatus.COMPLETED, ExecutionStatus.FAILED):
            persona.progress.completion_percentage = 100.0
            return

        if persona.total_steps == 0:
            return

        # Calculate completion percentage for in-progress personas
        completion_pct = (persona.current_step / persona.total_steps) * 100
        # Cap at 99% until actually completed to avoid confusion
        completion_pct = min(completion_pct, 99.0)
        persona.progress.completion_percentage = round(completion_pct, 2)

    def get_progress(self) -> dict[str, Any]:
        """
        Get current progress state.

        Returns:
            Dictionary with orchestrator, app discovery, and persona progress
        """
        progress_dict = {
            "orchestrator": self.orchestrator.to_dict(),
            "personas": {
                name: persona.to_dict() for name, persona in self.personas.items()
            },
            "updated_at": datetime.now(UTC).isoformat(),
        }

        # Include app_discovery if it exists
        if self.app_discovery:
            progress_dict["app_discovery"] = self.app_discovery.to_dict()

        return progress_dict

    def get_progress_snapshot(self) -> dict[str, Any]:
        """
        Get progress snapshot in format compatible with Pydantic ProgressSnapshot model.

        Returns:
            Dictionary ready for ProgressSnapshot(**data) instantiation
        """
        # Snapshot reads from in-memory state (get_progress()), not from disk,
        # so no need to force a disk write here. This avoids reintroducing
        # high-frequency JSON serialization when called from send_progress_update_to_api.
        progress_data = self.get_progress()
        snapshot = {
            "orchestrator": progress_data["orchestrator"],
            "personas": progress_data["personas"],
            "updated_at": progress_data["updated_at"],
        }
        # Include app_discovery if available
        if "app_discovery" in progress_data:
            snapshot["app_discovery"] = progress_data["app_discovery"]
        return snapshot

    def _schedule_write(self) -> None:
        """Mark progress as dirty and write if throttle interval has elapsed.

        At scale (100+ personas), this avoids writing progress.json hundreds
        of times per second. Callers that need immediate persistence (e.g.
        completion events) should call _flush_write() instead.
        """
        import time

        self._dirty = True
        now = time.time()
        if (now - self._last_write_time) >= self._write_min_interval:
            self._flush_write()

    def _flush_write(self) -> None:
        """Write progress.json to disk if dirty, or unconditionally if not yet written."""
        import time

        if not self._dirty and self._last_write_time > 0:
            return  # Nothing changed since last write
        self._write_progress()
        self._dirty = False
        self._last_write_time = time.time()

    def _write_progress(self) -> None:
        """Write progress to local JSON file."""
        try:
            progress_data = self.get_progress()
            with open(self.progress_file, "w") as f:
                json.dump(progress_data, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to write progress file: {e}")

    def _upload_progress(self, force: bool = False) -> None:
        """Upload only the progress.json file to platform storage (non-blocking).

        This method queues the upload to run in a background thread,
        so it returns immediately without blocking the main execution.
        Full artifact uploads happen at persona completion and session completion.

        Args:
            force: If True, upload immediately regardless of throttle interval.
                   If False (default), upload only if interval has elapsed.
        """
        import time

        current_time = time.time()
        time_since_last_upload = current_time - self._last_s3_upload_time

        # Check if we should upload
        should_upload = force or (time_since_last_upload >= S3_UPLOAD_INTERVAL_SECONDS)

        if should_upload:
            # Queue for background upload (non-blocking)
            _background_uploader.enqueue(
                progress_file_path=str(self.progress_file),
                session_id=self.session_id,
                org_id=self.org_id,
                task_id=self.task_id,
            )
            self._last_s3_upload_time = current_time
            self._pending_s3_upload = False
        else:
            # Mark that we have pending changes not yet uploaded
            self._pending_s3_upload = True
            logger.debug(
                f"S3 upload throttled: {time_since_last_upload:.1f}s since last upload "
                f"(min interval: {S3_UPLOAD_INTERVAL_SECONDS}s)"
            )

    async def send_progress_update_to_api(self) -> None:
        """Send current progress snapshot to external API via polling client.

        This method should be called to push progress updates to the external API
        whenever it's needed (e.g., after per-turn updates).
        """
        if not self.polling_client or not self.task:
            return

        try:
            from core.schemas import (
                AppDiscoveryProgressInfo,
                OrchestratorProgressInfo,
                PersonaProgressInfo,
                ProgressSnapshot,
                TaskResult,
            )

            # Get progress snapshot from tracker
            progress_data = self.get_progress_snapshot()

            # Build ProgressSnapshot
            progress_snapshot = ProgressSnapshot(
                orchestrator=OrchestratorProgressInfo(**progress_data["orchestrator"]),
                app_discovery=(
                    AppDiscoveryProgressInfo(**progress_data["app_discovery"])
                    if "app_discovery" in progress_data
                    and progress_data["app_discovery"]
                    else None
                ),
                personas={
                    name: PersonaProgressInfo(**data)
                    for name, data in progress_data.get("personas", {}).items()
                },
                updated_at=progress_data["updated_at"],
            )

            # Create result with progress
            result = TaskResult(
                session_id=self.session_id,
                target_url=self.target_url,
                progress=progress_snapshot,
            )

            # Send update to API and check for stop command
            from core.schemas import AgentCommand

            response = await self.polling_client.send_progress_update(self.task, result)
            if hasattr(response, "command") and response.command == AgentCommand.STOP:
                logger.warning(
                    f"🛑 Received STOP command from API for session {self.session_id}"
                )
                self.stop_requested = True
            else:
                logger.debug(
                    f"✓ Progress update sent to API for session {self.session_id}"
                )
        except Exception as e:
            logger.debug(f"Failed to send progress update to API: {e}")

    def flush_pending_upload(self) -> None:
        """Force upload of any pending progress changes to S3.

        This method should be called before cleanup or shutdown to ensure
        all progress updates are uploaded to S3, even if the throttle interval
        hasn't elapsed.
        """
        self._flush_write()  # Ensure progress.json is up-to-date before upload
        if self._pending_s3_upload:
            logger.debug("Flushing pending progress upload to S3")
            self._upload_progress(force=True)
