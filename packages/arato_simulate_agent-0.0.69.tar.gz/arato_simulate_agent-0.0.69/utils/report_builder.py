"""
Report Builder - Generates comprehensive reports from test results.

This module provides a thin wrapper around report_data_generator.py for:
1. Generating the report_data.json file
2. Providing access to the structured report data
3. Supporting HTML report generation

This is a deterministic utility - it wraps report_data_generator.py.
The generated report_data.json structure must be EXACTLY as defined in
report_data_generator.py - no creative modifications allowed.
"""

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from utils.report_data_generator import generate_report_data

logger = logging.getLogger(__name__)


@dataclass
class ReportSection:
    """Represents a section in the report.

    This is a lightweight reference to sections in report_data.json.
    """

    title: str
    category: str | None = None
    finding_count: int = 0
    critical_count: int = 0
    warning_count: int = 0
    good_count: int = 0


@dataclass
class ReportResult:
    """Container for generated report data and metadata.

    The report_data field contains the EXACT structure from report_data_generator.py:
    - key_findings: consolidated findings
    - featured_finding_ids: top findings for UI prominence
    - all_findings: unconsolidated findings
    - key_questions: question summaries (if enabled)
    - key_risks: risk summaries (if enabled)
    - conversations: raw conversation data
    - metadata: title, target_urls, timestamp, personas, categories, scoring
    - stats: response_length, latency, aggregated_metrics, finding_stats
    - executive_summary: generated executive summary
    - eu_ai_act_compliance: compliance assessment (if enabled)
    - test_summary: test/scenario summaries (if enabled)
    - custom_report: custom report from prompty (if available)
    """

    session_id: str
    target_url: str
    report_data: dict[str, Any] = field(default_factory=dict)
    report_data_path: Path | None = None
    sections: list[ReportSection] = field(default_factory=list)


async def build_report(
    target_url: str,
    results: dict[str, Any],
    persona_ids: list[str],
    session_dir: str | Path,
    include_eu_ai_act_report: bool = False,
    include_test_summary: bool = False,
    test_suite: Any = None,
    max_parallel: int = 4,
    include_aes_score: bool = False,
) -> ReportResult:
    """Generate a comprehensive report from testing results.

    This function calls report_data_generator.generate_report_data() directly,
    ensuring the EXACT same output format.

    Args:
        target_url: The target URL that was tested
        results: Dictionary mapping persona_id to result dict
        persona_ids: List of persona IDs that were run
        session_dir: Session directory path
        include_eu_ai_act_report: Whether to include EU AI Act compliance assessment
        include_test_summary: Whether to include test/scenario summary generation
        test_suite: Optional TestSuite object for generating per-test/scenario summaries
        max_parallel: Maximum number of parallel LLM calls for finding consolidation
        include_aes_score: Whether to calculate Agent Expertise Score (slow LLM call)

    Returns:
        ReportResult with the generated report data
    """
    session_path = Path(session_dir)
    session_id = session_path.name

    result = ReportResult(
        session_id=session_id,
        target_url=target_url,
    )

    try:
        # Call the existing report_data_generator - NO modifications to its output
        report_data = await generate_report_data(
            target_url=target_url,
            results=results,
            persona_ids=persona_ids,
            session_dir=str(session_path),
            include_eu_ai_act_report=include_eu_ai_act_report,
            include_test_summary=include_test_summary,
            test_suite=test_suite,
            max_parallel=max_parallel,
            include_aes_score=include_aes_score,
        )

        result.report_data = report_data
        result.report_data_path = session_path / "report_data.json"

        # Extract section summaries for quick access
        result.sections = _extract_sections(report_data)

        logger.info(
            f"Report generated: {len(report_data.get('key_findings', []))} key findings, "
            f"{len(result.sections)} sections"
        )

    except Exception as e:
        logger.exception(f"Report generation failed: {e}")
        result.report_data = {"error": str(e)}

    return result


def _extract_sections(report_data: dict[str, Any]) -> list[ReportSection]:
    """Extract section summaries from report_data for quick access.

    Args:
        report_data: The generated report data dictionary

    Returns:
        List of ReportSection objects
    """
    sections: list[ReportSection] = []

    # Get category stats from report_data
    finding_stats = report_data.get("stats", {}).get("finding_stats", {})
    by_category = finding_stats.get("by_category", {})

    for category, stats in by_category.items():
        sections.append(
            ReportSection(
                title=category,
                category=category,
                finding_count=stats.get("total", 0),
                critical_count=stats.get("critical", 0),
                warning_count=stats.get("warning", 0),
                good_count=stats.get("good", 0),
            )
        )

    # Sort by critical count (descending), then warning, then total
    sections.sort(key=lambda s: (-s.critical_count, -s.warning_count, -s.finding_count))

    return sections


def get_executive_summary(result: ReportResult) -> dict[str, Any] | None:
    """Get the executive summary from report data.

    Args:
        result: ReportResult with generated report

    Returns:
        Executive summary dictionary or None
    """
    return result.report_data.get("executive_summary")


def get_key_findings(result: ReportResult) -> list[dict[str, Any]]:
    """Get key findings from report data.

    Args:
        result: ReportResult with generated report

    Returns:
        List of key finding dictionaries
    """
    return result.report_data.get("key_findings", [])


def get_all_findings(result: ReportResult) -> list[dict[str, Any]]:
    """Get all unconsolidated findings from report data.

    Args:
        result: ReportResult with generated report

    Returns:
        List of all finding dictionaries
    """
    return result.report_data.get("all_findings", [])


def get_metadata(result: ReportResult) -> dict[str, Any]:
    """Get report metadata.

    Args:
        result: ReportResult with generated report

    Returns:
        Metadata dictionary
    """
    return result.report_data.get("metadata", {})


def get_stats(result: ReportResult) -> dict[str, Any]:
    """Get report statistics.

    Args:
        result: ReportResult with generated report

    Returns:
        Stats dictionary
    """
    return result.report_data.get("stats", {})


__all__ = [
    "ReportResult",
    "ReportSection",
    "build_report",
    "get_all_findings",
    "get_executive_summary",
    "get_key_findings",
    "get_metadata",
    "get_stats",
]
