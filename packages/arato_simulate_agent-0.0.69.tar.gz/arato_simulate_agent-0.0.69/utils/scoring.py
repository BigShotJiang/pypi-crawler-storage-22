"""
Shared scoring logic for converting raw scores to severity labels and status.
"""

from constants import (
    SCORE_LABEL_CRITICAL,
    SCORE_LABEL_GOOD,
    SCORE_LABEL_WARNING,
    SCORE_THRESHOLD_GOOD,
    SCORE_THRESHOLD_PASS,
)


def normalize_severity_to_label(severity: str) -> str:
    """
    Map legacy severity values to the new label system.

    This handles old data that may use "High", "Medium", "Low" instead of
    the new "Critical", "Warning", "Good" labels.

    Args:
        severity: Legacy severity string (case-insensitive)

    Returns:
        Normalized label (Critical, Warning, or Good)
    """
    mapping = {
        "high": SCORE_LABEL_CRITICAL,
        "medium": SCORE_LABEL_WARNING,
        "low": SCORE_LABEL_GOOD,
        "critical": SCORE_LABEL_CRITICAL,
        "warning": SCORE_LABEL_WARNING,
        "good": SCORE_LABEL_GOOD,
    }
    return mapping.get(severity.lower(), SCORE_LABEL_WARNING)


def calculate_label(score: float | int) -> str:
    """
    Calculate label based on a raw score (0-100).

    Logic:
    - Score >= 75 (Good) -> GOOD label
    - Score >= 20 (Pass) -> WARNING label
    - Score < 20 (Fail) -> CRITICAL label

    Args:
        score: The raw score from 0 to 100

    Returns:
        The label (GOOD, WARNING, CRITICAL)
    """
    if score >= SCORE_THRESHOLD_GOOD:  # >= 75
        return SCORE_LABEL_GOOD
    elif score >= SCORE_THRESHOLD_PASS:  # >= 20
        return SCORE_LABEL_WARNING
    else:  # < 20
        return SCORE_LABEL_CRITICAL


def calculate_status(score: float | int) -> bool:
    """
    Calculate pass/fail status based on a raw score (0-100).

    Logic:
    - Score >= 20 -> Pass (True)
    - Score < 20 -> Fail (False)

    Args:
        score: The raw score from 0 to 100

    Returns:
        True for Pass, False for Fail
    """
    return score >= SCORE_THRESHOLD_PASS
