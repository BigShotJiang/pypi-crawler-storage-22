"""Screenshot capture utilities for agents.

Provides shared functionality for capturing and uploading screenshots
during agent execution (HITL interventions, discovery, etc.).
"""

import base64
import logging
import uuid
from datetime import datetime
from pathlib import Path

from browser_use import Browser

from core.browser import get_browser_manager
from core.storage import get_storage_adapter

logger = logging.getLogger(__name__)


async def capture_and_upload_screenshot(
    browser: Browser,
    upload_type: str,
    description: str | None = None,
    session_id: str | None = None,
    intervention_id: str | None = None,
    domain: str | None = None,
    org_id: str | None = None,
) -> str | None:
    """
    Capture a screenshot from the browser and upload it to storage.

    This function handles the common pattern of:
    1. Capturing screenshot from browser (returns base64)
    2. Decoding base64 to bytes
    3. Uploading to storage with appropriate path/naming

    Args:
        browser: Browser instance to capture screenshot from
        upload_type: Type of upload - either 'hitl' or 'discovery'
        description: Description for discovery screenshots (e.g., 'homepage', 'chat-interface')
        session_id: Session ID for HITL screenshots
        intervention_id: Intervention ID for HITL screenshots
        domain: Domain name for discovery screenshots
        org_id: Organization ID for multi-tenant discovery screenshots

    Returns:
        URL of uploaded screenshot, or None if capture/upload failed

    Raises:
        ValueError: If required parameters for upload_type are missing
    """
    if upload_type not in ("hitl", "discovery"):
        raise ValueError(
            f"Invalid upload_type: {upload_type}. Must be 'hitl' or 'discovery'"
        )

    # Validate required parameters based on upload type
    if upload_type == "hitl":
        if not session_id:
            raise ValueError("session_id is required for HITL screenshot uploads")
        # Generate intervention_id if not provided
        if not intervention_id:
            intervention_id = str(uuid.uuid4())
        # Ensure intervention_id is not None for type checker
        assert intervention_id is not None
    elif upload_type == "discovery":
        if not domain:
            raise ValueError("domain is required for discovery screenshot uploads")
        if not description:
            raise ValueError("description is required for discovery screenshot uploads")

    try:
        # Step 1: Capture screenshot using browser manager
        browser_manager = get_browser_manager()
        screenshot_b64 = await browser_manager.capture_screenshot(browser)

        if not screenshot_b64:
            logger.warning("Failed to capture screenshot - browser page not available")
            return None

        # Step 2: Decode base64 string to bytes
        screenshot_bytes = base64.b64decode(screenshot_b64)

        # Step 3: Upload to storage using appropriate method
        storage_adapter = get_storage_adapter()

        if upload_type == "hitl":
            # For HITL, we know session_id and intervention_id are not None
            assert session_id is not None
            assert intervention_id is not None
            screenshot_url = storage_adapter.upload_screenshot(
                screenshot_bytes=screenshot_bytes,
                session_id=session_id,
                intervention_id=intervention_id,
            )
        else:  # discovery
            # For discovery, we know domain and description are not None
            assert domain is not None
            assert description is not None
            # Create filename with timestamp and sanitized description
            safe_description = description.replace(" ", "_").replace("/", "-")
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{timestamp}_{safe_description}.png"

            screenshot_url = storage_adapter.upload_discovery_screenshot(
                screenshot_bytes=screenshot_bytes,
                domain=domain,
                filename=filename,
                org_id=org_id,
            )

            # Also save screenshot locally to domain cache directory for artifact copying
            # This ensures copy_discovery_artifacts() can find and copy screenshots
            if screenshot_url:
                from constants import DOMAIN_SETTINGS_DIR

                # Construct the local domain cache directory path
                domain_cache_dir = Path(DOMAIN_SETTINGS_DIR) / domain

                # Create screenshots subdirectory if it doesn't exist
                screenshots_dir = domain_cache_dir / "screenshots"
                screenshots_dir.mkdir(parents=True, exist_ok=True)

                # Save screenshot file locally
                screenshot_path = screenshots_dir / filename
                with open(screenshot_path, "wb") as f:
                    f.write(screenshot_bytes)
                logger.info(f"✓ Screenshot also saved locally: {screenshot_path}")

        if screenshot_url:
            logger.info(f"✓ Screenshot uploaded successfully: {screenshot_url}")
        else:
            logger.warning("Failed to upload screenshot to storage")

        return screenshot_url

    except Exception as e:
        logger.exception(f"Error capturing/uploading screenshot: {e}")
        return None
