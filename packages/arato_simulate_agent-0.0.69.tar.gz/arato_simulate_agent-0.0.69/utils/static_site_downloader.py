"""
Utility to download the pre-built static report UI from S3.
"""

import logging
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

from constants import STATIC_REPORT_UI_BUCKET, STATIC_REPORT_UI_PREFIX

logger = logging.getLogger(__name__)


def download_static_report_ui(
    output_dir: str | Path, pr_number: str | int | None = None
) -> bool:
    """
    Download the static report UI from S3 to the specified output directory.

    Args:
        output_dir: The directory where the UI files should be downloaded.
        pr_number: Optional PR number to find the specific bucket (pattern: arato-static-<pr>-*)

    Returns:
        True if download was successful, False otherwise.
    """
    output_path = Path(output_dir)

    try:
        s3 = boto3.client("s3")
        bucket_name = STATIC_REPORT_UI_BUCKET

        if pr_number:
            logger.info(f"Looking for bucket for PR #{pr_number}...")
            # List all buckets and find the one matching the pattern
            try:
                response = s3.list_buckets()
                prefix = f"arato-static-{pr_number}-"
                found_bucket = None
                for bucket in response.get("Buckets", []):
                    if bucket["Name"].startswith(prefix):
                        found_bucket = bucket["Name"]
                        break

                if found_bucket:
                    bucket_name = found_bucket
                    logger.info(f"Found PR bucket: {bucket_name}")
                else:
                    logger.error(f"No bucket found matching prefix: {prefix}")
                    return False
            except ClientError as e:
                logger.error(f"Failed to list buckets to find PR bucket: {e}")
                return False

        # Ensure output directory exists
        output_path.mkdir(parents=True, exist_ok=True)

        logger.info(
            f"Downloading static report UI from s3://{bucket_name}/{STATIC_REPORT_UI_PREFIX} to {output_path} (this may take ~30 seconds)..."
        )

        # List objects in the bucket with the prefix
        paginator = s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=bucket_name, Prefix=STATIC_REPORT_UI_PREFIX)

        file_count = 0

        for page in pages:
            if "Contents" not in page:
                continue

            for obj in page["Contents"]:
                key = obj["Key"]

                # Skip if it's the prefix directory itself
                if (
                    key == STATIC_REPORT_UI_PREFIX
                    or key == STATIC_REPORT_UI_PREFIX + "/"
                ):
                    continue

                # Calculate relative path from the prefix
                relative_key = key[len(STATIC_REPORT_UI_PREFIX) :].lstrip("/")
                if not relative_key:
                    continue

                local_file_path = output_path / relative_key

                # Create parent directories if they don't exist
                local_file_path.parent.mkdir(parents=True, exist_ok=True)

                # Download the file
                logger.debug(f"Downloading {key} to {local_file_path}")
                s3.download_file(bucket_name, key, str(local_file_path))
                file_count += 1

        if file_count == 0:
            logger.warning(
                f"No files found in s3://{bucket_name}/{STATIC_REPORT_UI_PREFIX}"
            )
            return False

        logger.info(f"Successfully downloaded {file_count} files for static report UI")
        return True

    except ClientError as e:
        logger.error(f"Failed to download static report UI from S3: {e}")
        return False
    except Exception as e:
        logger.error(
            f"An unexpected error occurred during static report UI download: {e}"
        )
        return False
