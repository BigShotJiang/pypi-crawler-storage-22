"""Statistical calculation utilities."""

import math
from typing import Any


def calculate_statistics(
    measurements: list[dict[str, float]],
    value_key: str = "latency_seconds",
) -> dict[str, Any]:
    """
    Calculate statistical metrics from measurements.

    Args:
        measurements: List of measurement dicts
        value_key: Key in measurement dict to calculate stats for (default: "latency_seconds")

    Returns:
        Dictionary with count, min, max, avg, and median stats
    """
    if not measurements:
        return {
            "count": 0,
            "min": 0.0,
            "max": 0.0,
            "avg": 0.0,
            "median": 0.0,
            "distribution": {},
        }

    # Filter out measurements that don't have the key
    values = [m[value_key] for m in measurements if value_key in m]

    if not values:
        return {
            "count": 0,
            "min": 0.0,
            "max": 0.0,
            "avg": 0.0,
            "median": 0.0,
            "distribution": {},
        }

    values_sorted = sorted(values)

    stats = {
        "count": len(values),
        "min": round(min(values), 3),
        "max": round(max(values), 3),
        "avg": round(sum(values) / len(values), 3),
    }

    # Calculate median
    n = len(values_sorted)
    if n % 2 == 0:
        stats["median"] = round(
            (values_sorted[n // 2 - 1] + values_sorted[n // 2]) / 2, 3
        )
    else:
        stats["median"] = round(values_sorted[n // 2], 3)

    stats["distribution"] = calculate_dynamic_distribution(values)

    return stats


def calculate_latency_statistics(
    measurements: list[dict[str, float]],
) -> dict[str, Any]:
    """
    Calculate statistical metrics from latency measurements.
    Deprecated: Use calculate_statistics instead.

    Args:
        measurements: List of measurement dicts with 'latency_seconds' keys

    Returns:
        Dictionary with count, min, max, avg, and median latency stats
    """
    stats = calculate_statistics(measurements, value_key="latency_seconds")
    # Map back to legacy keys for compatibility
    return {
        "count": stats["count"],
        "min_latency": stats["min"],
        "max_latency": stats["max"],
        "avg_latency": stats["avg"],
        "median_latency": stats["median"],
        "distribution": stats["distribution"],
    }


def calculate_response_length_statistics(
    measurements: list[dict[str, int]],
) -> dict[str, Any]:
    """
    Calculate statistical metrics from response length measurements.

    Args:
        measurements: List of measurement dicts with 'length_chars' keys

    Returns:
        Dictionary with count, min, max, avg, and distribution stats
    """
    if not measurements:
        return {
            "count": 0,
            "min_length": 0,
            "max_length": 0,
            "avg_length": 0.0,
        }

    lengths = [m["length_chars"] for m in measurements]

    stats = {
        "count": len(lengths),
        "min_length": min(lengths),
        "max_length": max(lengths),
        "avg_length": round(sum(lengths) / len(lengths), 1),
    }

    stats["distribution"] = calculate_dynamic_distribution(lengths)

    return stats


def calculate_dynamic_distribution(
    values: list[float | int], num_buckets: int = 10
) -> dict[str, int]:
    """
    Calculate dynamic distribution buckets based on data range.
    Rounds bucket sizes to "nice" numbers (e.g. 10, 50, 100) and aligns
    boundaries to these numbers for cleaner visualization.

    Args:
        values: List of numerical values
        num_buckets: Approximate number of buckets to create (default: 10)

    Returns:
        Dictionary mapping bucket labels to counts
    """
    if not values:
        return {}

    min_val = min(values)
    max_val = max(values)

    if min_val == max_val:
        return {f"{min_val}": len(values)}

    # Calculate raw bucket size based on requested number of buckets
    val_range = max_val - min_val
    raw_step = val_range / num_buckets

    # Calculate "nice" step size (1, 2, 5 * 10^k)
    # e.g. if raw_step is 96, mag=10, norm=9.6 => step=10 => nice_step=100
    if raw_step == 0:
        mag = 1
    else:
        mag = 10 ** math.floor(math.log10(raw_step))

    norm_step = raw_step / mag

    if norm_step < 1.5:
        step_mult = 1
    elif norm_step < 3.5:
        step_mult = 2
    elif norm_step < 7.5:
        step_mult = 5
    else:
        step_mult = 10

    nice_step = step_mult * mag

    # Align start value to the nice step grid
    # e.g. min=49, step=1000 -> start_val=0
    start_val = math.floor(min_val / nice_step) * nice_step

    # Initialize buckets
    buckets = {}
    bucket_ranges: list[tuple[float, float, str]] = []

    current_start = start_val

    # Generate buckets until we cover the max value
    # We add a safety limit to prevent infinite loops in edge cases
    max_iterations = max(50, num_buckets * 5)

    while current_start < max_val and len(bucket_ranges) < max_iterations:
        current_end = current_start + nice_step

        # Format label cleanly
        if nice_step >= 1 and float(nice_step).is_integer():
            label = f"{int(current_start)}-{int(current_end)}"
        else:
            label = f"{current_start:.2g}-{current_end:.2g}"

        buckets[label] = 0
        bucket_ranges.append((current_start, current_end, label))

        current_start = current_end

    # Fill buckets
    for val in values:
        placed = False
        for i, (start, end, label) in enumerate(bucket_ranges):
            is_last = i == len(bucket_ranges) - 1

            # For the last bucket, we include the upper bound to ensure max_val is included
            # if it falls exactly on the boundary
            if is_last:
                if (
                    start <= val <= end + (nice_step * 0.001)
                ):  # Add slight epsilon for float tolerance
                    buckets[label] += 1
                    placed = True
                    break
            else:
                if start <= val < end:
                    buckets[label] += 1
                    placed = True
                    break

        # Fallback if somehow not placed (e.g. slight float precision issue beyond last bucket)
        if not placed and bucket_ranges:
            # Check if it should belong to last bucket (e.g. very close to max)
            last_start, last_end, last_label = bucket_ranges[-1]
            if val >= last_start:
                buckets[last_label] += 1

    return buckets
