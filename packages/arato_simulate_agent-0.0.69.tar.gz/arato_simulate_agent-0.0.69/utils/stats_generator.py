"""
Session statistics generator.

Generates a stats.md file with performance metrics, conversation statistics,
and findings analysis from agent-timing.log, transcripts, and summaries.
"""

import json
import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from statistics import mean, median, stdev

from constants import SUMMARY_FILENAME, TRANSCRIPT_FILENAME

logger = logging.getLogger(__name__)


@dataclass
class TimingEntry:
    """Parsed entry from agent-timing.log."""

    timestamp: datetime
    operation: str
    duration: float
    turn: int | None = None
    persona: str | None = None
    cpu_s: float = 0.0
    io_s: float = 0.0
    cpu_pct: float = 0.0
    # Browser metrics (new format)
    heap_mb: float | None = None
    dom_nodes: int | None = None
    content_len: int | None = None
    extract_ms: float | None = None
    context_chars: int | None = None


@dataclass
class FindingData:
    """Individual finding for aggregation."""

    agent_id: str
    category: str
    title: str
    label: str
    score: float
    confidence: float
    persona: str
    discrepancy_type: str | None = None


@dataclass
class PersonaStats:
    """Statistics for a single persona run."""

    persona_id: str
    instance_name: str
    total_turns: int = 0
    total_duration_s: float = 0.0
    avg_extraction_time_s: float = 0.0
    first_turn_extraction_s: float = 0.0
    last_turn_extraction_s: float = 0.0
    extraction_times: list[float] = field(default_factory=list)
    ttft_times: list[float] = field(default_factory=list)
    ttlt_times: list[float] = field(default_factory=list)
    response_lengths: list[int] = field(default_factory=list)
    findings_count: int = 0
    critical_count: int = 0
    warning_count: int = 0
    good_count: int = 0


@dataclass
class SessionStats:
    """Aggregate statistics for the entire session."""

    session_id: str
    target_url: str = ""
    start_time: datetime | None = None
    end_time: datetime | None = None
    total_duration_min: float = 0.0
    total_personas: int = 0
    completed_personas: int = 0
    failed_personas: int = 0
    total_turns: int = 0
    total_findings: int = 0
    total_critical: int = 0
    total_warning: int = 0
    total_good: int = 0
    persona_stats: dict[str, PersonaStats] = field(default_factory=dict)
    all_findings: list[FindingData] = field(default_factory=list)


def parse_timing_log(filepath: Path) -> list[TimingEntry]:
    """Parse agent-timing.log and extract timing entries."""
    entries = []

    # Pattern for response_extraction with optional browser metrics
    extraction_pattern = re.compile(
        r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\.f - response_extraction: ([\d.]+)s \| "
        r"turn=(\d+) \| persona=(\S+) \| cpu_s=([\d.]+) \| io_s=([\d.]+) \| cpu_pct=([\d.]+)"
        r"(?:\s*\|\s*heap_mb=([\d.]+))?"
        r"(?:\s*\|\s*dom_nodes=(\d+))?"
        r"(?:\s*\|\s*content_len=(\d+))?"
        r"(?:\s*\|\s*extract_ms=([\d.]+))?"
        r"(?:\s*\|\s*context_chars=(\d+))?"
    )

    # Pattern for other operations
    generic_pattern = re.compile(
        r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\.f - (\w+): ([\d.]+)s"
        r"(?:\s*\|\s*persona=(\S+))?"
        r"(?:\s*\|\s*turn=(\d+))?"
    )

    with open(filepath, encoding="utf-8") as f:
        for line in f:
            if line.startswith("#") or line.startswith("="):
                continue

            # Try extraction pattern first
            match = extraction_pattern.search(line)
            if match:
                entries.append(
                    TimingEntry(
                        timestamp=datetime.strptime(
                            match.group(1), "%Y-%m-%d %H:%M:%S"
                        ),
                        operation="response_extraction",
                        duration=float(match.group(2)),
                        turn=int(match.group(3)),
                        persona=match.group(4),
                        cpu_s=float(match.group(5)),
                        io_s=float(match.group(6)),
                        cpu_pct=float(match.group(7)),
                        heap_mb=float(match.group(8)) if match.group(8) else None,
                        dom_nodes=int(match.group(9)) if match.group(9) else None,
                        content_len=int(match.group(10)) if match.group(10) else None,
                        extract_ms=float(match.group(11)) if match.group(11) else None,
                        context_chars=int(match.group(12)) if match.group(12) else None,
                    )
                )
                continue

            # Try generic pattern
            match = generic_pattern.search(line)
            if match:
                entries.append(
                    TimingEntry(
                        timestamp=datetime.strptime(
                            match.group(1), "%Y-%m-%d %H:%M:%S"
                        ),
                        operation=match.group(2),
                        duration=float(match.group(3)),
                        persona=match.group(4) if match.group(4) else None,
                        turn=int(match.group(5)) if match.group(5) else None,
                    )
                )

    return entries


def load_transcript(transcript_path: Path) -> dict:
    """Load and parse a transcript.json file."""
    if not transcript_path.exists():
        return {}

    with open(transcript_path, encoding="utf-8") as f:
        return json.load(f)


def load_summary(summary_path: Path) -> dict:
    """Load and parse a summary.json file."""
    if not summary_path.exists():
        return {}

    with open(summary_path, encoding="utf-8") as f:
        return json.load(f)


def collect_persona_stats(
    session_dir: Path, timing_entries: list[TimingEntry]
) -> tuple[dict[str, PersonaStats], list[FindingData]]:
    """Collect statistics for each persona from transcripts and timing log.

    Returns:
        Tuple of (persona_stats dict, list of all findings)
    """
    persona_stats: dict[str, PersonaStats] = {}
    all_findings: list[FindingData] = []

    # Group timing entries by persona
    timing_by_persona: dict[str, list[TimingEntry]] = defaultdict(list)
    for entry in timing_entries:
        if entry.persona and entry.operation == "response_extraction":
            timing_by_persona[entry.persona].append(entry)

    # Find all persona directories
    for persona_dir in session_dir.iterdir():
        if not persona_dir.is_dir():
            continue

        instance_name = persona_dir.name

        # Skip non-persona directories
        if instance_name in ["app_context", "run_video", "__pycache__"]:
            continue

        transcript_path = persona_dir / TRANSCRIPT_FILENAME
        summary_path = persona_dir / SUMMARY_FILENAME

        transcript = load_transcript(transcript_path)
        summary = load_summary(summary_path)

        if not transcript:
            continue

        # Extract persona ID from instance name (e.g., "naive_insurance_agent_01" -> "naive")
        persona_id = transcript.get(
            "persona_id",
            instance_name.rsplit("_", 2)[0] if "_" in instance_name else instance_name,
        )

        stats = PersonaStats(persona_id=persona_id, instance_name=instance_name)

        # Collect measurements from transcript
        transcript_items = transcript.get("transcript", [])
        for item in transcript_items:
            if item.get("role") == "assistant":
                stats.total_turns += 1
                measurements = item.get("measurements", {})

                if "ttft" in measurements:
                    stats.ttft_times.append(measurements["ttft"])
                if "ttlt" in measurements:
                    stats.ttlt_times.append(measurements["ttlt"])
                if "length" in measurements:
                    stats.response_lengths.append(measurements["length"])

                # Count findings in this turn
                findings = item.get("evals") or item.get("findings", [])
                for finding in findings:
                    stats.findings_count += 1
                    label = finding.get("label", "").lower()
                    if label == "critical":
                        stats.critical_count += 1
                    elif label == "warning":
                        stats.warning_count += 1
                    elif label == "good":
                        stats.good_count += 1

                    # Collect detailed finding data
                    eval_results = finding.get("evaluation_results", {})
                    metadata = finding.get("metadata", {})
                    all_findings.append(
                        FindingData(
                            agent_id=finding.get("agent_id", "unknown"),
                            category=finding.get("category", "Uncategorized"),
                            title=finding.get("title", ""),
                            label=finding.get("label", "Unknown"),
                            score=float(eval_results.get("score", 0)),
                            confidence=float(eval_results.get("confidence", 0)),
                            persona=instance_name,
                            discrepancy_type=metadata.get("discrepancy_type"),
                        )
                    )

        # Add findings from summary
        if summary:
            analysis = summary.get("analysis", {})
            summary_findings = analysis.get("findings", [])
            for finding in summary_findings:
                # Count all summary-generated findings (these have valid agent_ids now)
                stats.findings_count += 1
                label = finding.get("label", "").lower()
                if label == "critical":
                    stats.critical_count += 1
                elif label == "warning":
                    stats.warning_count += 1
                elif label == "good":
                    stats.good_count += 1

                # Collect detailed finding data
                eval_results = finding.get("evaluation_results", {})
                metadata = finding.get("metadata", {})
                all_findings.append(
                    FindingData(
                        agent_id=finding.get("agent_id", "unknown"),
                        category=finding.get("category", "Uncategorized"),
                        title=finding.get("title", ""),
                        label=finding.get("label", "Unknown"),
                        score=float(eval_results.get("score", 0)),
                        confidence=float(eval_results.get("confidence", 0)),
                        persona=instance_name,
                        discrepancy_type=metadata.get("discrepancy_type"),
                    )
                )

        # Collect extraction times from timing log
        timing_entries_for_persona = timing_by_persona.get(instance_name, [])
        if timing_entries_for_persona:
            sorted_entries = sorted(
                timing_entries_for_persona, key=lambda e: e.turn or 0
            )
            stats.extraction_times = [e.duration for e in sorted_entries]
            stats.total_duration_s = sum(stats.extraction_times)
            stats.avg_extraction_time_s = (
                mean(stats.extraction_times) if stats.extraction_times else 0
            )

            if sorted_entries:
                stats.first_turn_extraction_s = sorted_entries[0].duration
                stats.last_turn_extraction_s = sorted_entries[-1].duration

        persona_stats[instance_name] = stats

    return persona_stats, all_findings


def calculate_distribution(
    values: list[float], percentiles: list[int] | None = None
) -> dict:
    """Calculate distribution statistics for a list of values."""
    if not values:
        return {
            "count": 0,
            "min": 0,
            "max": 0,
            "mean": 0,
            "median": 0,
            "std": 0,
            "percentiles": {},
            "histogram": [],
        }

    percentiles = percentiles or [10, 25, 50, 75, 90, 95, 99]
    sorted_values = sorted(values)

    def percentile(p: int) -> float:
        k = (len(sorted_values) - 1) * p / 100
        f = int(k)
        c = f + 1 if f + 1 < len(sorted_values) else f
        return sorted_values[f] + (sorted_values[c] - sorted_values[f]) * (k - f)

    # Generate histogram bins (10 bins by default)
    histogram = generate_histogram_bins(values, num_bins=10)

    return {
        "count": len(values),
        "min": min(values),
        "max": max(values),
        "mean": mean(values),
        "median": median(values),
        "std": stdev(values) if len(values) > 1 else 0,
        "percentiles": {f"p{p}": percentile(p) for p in percentiles},
        "histogram": histogram,
    }


def generate_histogram_bins(values: list[float], num_bins: int = 10) -> list[dict]:
    """Generate histogram bins for a list of values.

    Returns list of dicts with 'start', 'end', 'count', 'percentage'.
    """
    if not values:
        return []

    min_val = min(values)
    max_val = max(values)

    # Handle edge case where all values are the same
    if min_val == max_val:
        return [
            {
                "start": min_val,
                "end": max_val,
                "count": len(values),
                "percentage": 100.0,
            }
        ]

    bin_width = (max_val - min_val) / num_bins
    bins = []

    for i in range(num_bins):
        bin_start = min_val + i * bin_width
        bin_end = min_val + (i + 1) * bin_width
        # Last bin includes the max value
        if i == num_bins - 1:
            count = sum(1 for v in values if bin_start <= v <= bin_end)
        else:
            count = sum(1 for v in values if bin_start <= v < bin_end)

        bins.append(
            {
                "start": bin_start,
                "end": bin_end,
                "count": count,
                "percentage": count / len(values) * 100,
            }
        )

    return bins


def format_histogram_markdown(
    histogram: list[dict], unit: str = "", precision: int = 2, bar_width: int = 20
) -> list[str]:
    """Format histogram bins as ASCII bar chart in markdown.

    Args:
        histogram: List of bin dicts from generate_histogram_bins
        unit: Unit suffix for values (e.g., 's', ' chars')
        precision: Decimal places for bin ranges
        bar_width: Maximum width of histogram bars in characters

    Returns:
        List of markdown lines for the histogram
    """
    if not histogram:
        return []

    lines = ["", "```"]

    max_count = max(b["count"] for b in histogram)
    max_count = max_count or 1  # Avoid division by zero

    for b in histogram:
        # Format the range
        if precision == 0:
            range_str = f"{int(b['start']):>6} - {int(b['end']):<6}"
        else:
            range_str = f"{b['start']:>{6 + precision}.{precision}f} - {b['end']:<{6 + precision}.{precision}f}"

        # Calculate bar length
        bar_len = int(b["count"] / max_count * bar_width)
        bar = "█" * bar_len

        # Format count and percentage
        count_str = f"{b['count']:>4} ({b['percentage']:>5.1f}%)"

        lines.append(f"{range_str}{unit} |{bar:<{bar_width}} {count_str}")

    lines.append("```")
    lines.append("")

    return lines


def generate_findings_analysis(all_findings: list[FindingData]) -> list[str]:
    """Generate comprehensive findings analysis section.

    Args:
        all_findings: List of all findings from the session

    Returns:
        List of markdown lines for the findings analysis
    """
    lines: list[str] = []

    if not all_findings:
        return lines

    # Score Distribution
    scores = [f.score for f in all_findings]
    dist = calculate_distribution(scores)

    lines.extend(
        [
            "### Finding Score Distribution",
            "",
            f"Quality scores across all findings (n={dist['count']}, 0=worst, 100=best):",
            "",
            "| Metric | Value |",
            "|--------|-------|",
            f"| Min | {dist['min']:.1f} |",
            f"| Max | {dist['max']:.1f} |",
            f"| Mean | {dist['mean']:.1f} |",
            f"| Median | {dist['median']:.1f} |",
            f"| Std Dev | {dist['std']:.1f} |",
            "",
        ]
    )
    lines.extend(format_histogram_markdown(dist["histogram"], precision=0))

    # Confidence Distribution
    confidences = [f.confidence for f in all_findings if f.confidence > 0]
    if confidences:
        conf_dist = calculate_distribution(confidences)
        lines.extend(
            [
                "### Finding Confidence Distribution",
                "",
                f"Confidence levels for findings (n={conf_dist['count']}, 0.0-1.0):",
                "",
                "| Metric | Value |",
                "|--------|-------|",
                f"| Min | {conf_dist['min']:.2f} |",
                f"| Max | {conf_dist['max']:.2f} |",
                f"| Mean | {conf_dist['mean']:.2f} |",
                f"| Median | {conf_dist['median']:.2f} |",
                "",
            ]
        )
        lines.extend(format_histogram_markdown(conf_dist["histogram"], precision=2))

    # Score Distribution by Label
    label_scores: dict[str, list[float]] = defaultdict(list)
    for f in all_findings:
        label_scores[f.label].append(f.score)

    if label_scores:
        lines.extend(
            [
                "### Score Distribution by Label",
                "",
                "| Label | Count | Mean Score | Median | Min | Max |",
                "|-------|-------|------------|--------|-----|-----|",
            ]
        )
        for label in ["Critical", "Warning", "Good"]:
            if label in label_scores:
                scores_for_label = label_scores[label]
                label_dist = calculate_distribution(scores_for_label)
                icon = (
                    "🔴"
                    if label == "Critical"
                    else ("🟡" if label == "Warning" else "🟢")
                )
                lines.append(
                    f"| {icon} {label} | {label_dist['count']} | {label_dist['mean']:.1f} | "
                    f"{label_dist['median']:.1f} | {label_dist['min']:.1f} | {label_dist['max']:.1f} |"
                )
        lines.append("")

    # Findings by Category
    category_counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for f in all_findings:
        category_counts[f.category]["total"] += 1
        category_counts[f.category][f.label.lower()] += 1

    if category_counts:
        lines.extend(
            [
                "### Findings by Category",
                "",
                "| Category | Total | 🔴 Critical | 🟡 Warning | 🟢 Good |",
                "|----------|-------|-------------|------------|---------|",
            ]
        )
        # Sort by total count descending
        sorted_categories = sorted(
            category_counts.items(), key=lambda x: x[1]["total"], reverse=True
        )
        for category, counts in sorted_categories:
            lines.append(
                f"| {category} | {counts['total']} | {counts.get('critical', 0)} | "
                f"{counts.get('warning', 0)} | {counts.get('good', 0)} |"
            )
        lines.append("")

        # Category histogram
        category_totals = [
            (cat, counts["total"]) for cat, counts in sorted_categories[:10]
        ]
        if category_totals:
            lines.extend(["**Top Categories:**", "", "```"])
            max_count = max(c for _, c in category_totals)
            max_count = max_count or 1
            for cat, count in category_totals:
                bar_len = int(count / max_count * 20)
                bar = "█" * bar_len
                lines.append(f"{cat[:30]:<30} |{bar:<20} {count}")
            lines.extend(["```", ""])

    # Findings by Agent
    agent_counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for f in all_findings:
        agent_counts[f.agent_id]["total"] += 1
        agent_counts[f.agent_id][f.label.lower()] += 1

    if agent_counts:
        lines.extend(
            [
                "### Findings by Evaluator Agent",
                "",
                "| Agent ID | Total | 🔴 Critical | 🟡 Warning | 🟢 Good |",
                "|----------|-------|-------------|------------|---------|",
            ]
        )
        sorted_agents = sorted(
            agent_counts.items(), key=lambda x: x[1]["total"], reverse=True
        )
        for agent_id, counts in sorted_agents:
            lines.append(
                f"| {agent_id} | {counts['total']} | {counts.get('critical', 0)} | "
                f"{counts.get('warning', 0)} | {counts.get('good', 0)} |"
            )
        lines.append("")

    # Findings by Persona Type
    persona_type_counts: dict[str, dict[str, int]] = defaultdict(
        lambda: defaultdict(int)
    )
    for f in all_findings:
        # Extract persona type from instance name (e.g., "naive_insurance_agent_01" -> "naive")
        parts = f.persona.split("_")
        persona_type = parts[0] if parts else f.persona
        persona_type_counts[persona_type]["total"] += 1
        persona_type_counts[persona_type][f.label.lower()] += 1

    if persona_type_counts:
        lines.extend(
            [
                "### Findings by Persona Type",
                "",
                "| Persona Type | Total | 🔴 Critical | 🟡 Warning | 🟢 Good | Crit % |",
                "|--------------|-------|-------------|------------|---------|--------|",
            ]
        )
        sorted_persona_types = sorted(
            persona_type_counts.items(), key=lambda x: x[1]["total"], reverse=True
        )
        for persona_type, counts in sorted_persona_types:
            total_for_type = counts["total"] or 1
            crit_pct = counts.get("critical", 0) / total_for_type * 100
            lines.append(
                f"| {persona_type} | {counts['total']} | {counts.get('critical', 0)} | "
                f"{counts.get('warning', 0)} | {counts.get('good', 0)} | {crit_pct:.1f}% |"
            )
        lines.append("")

    # Discrepancy Types (if present)
    discrepancy_counts: dict[str, int] = defaultdict(int)
    for f in all_findings:
        if f.discrepancy_type:
            discrepancy_counts[f.discrepancy_type] += 1

    if discrepancy_counts:
        lines.extend(
            [
                "### Discrepancy Types",
                "",
                "| Type | Count |",
                "|------|-------|",
            ]
        )
        sorted_discrepancies = sorted(
            discrepancy_counts.items(), key=lambda x: x[1], reverse=True
        )
        for disc_type, count in sorted_discrepancies:
            lines.append(f"| {disc_type} | {count} |")
        lines.append("")

    # Most Common Finding Titles
    title_counts: dict[str, dict[str, int | str]] = defaultdict(
        lambda: {"count": 0, "label": ""}
    )
    for f in all_findings:
        title_counts[f.title]["count"] = int(title_counts[f.title]["count"]) + 1
        title_counts[f.title]["label"] = f.label

    if title_counts:
        lines.extend(
            [
                "### Most Common Findings",
                "",
                "| Count | Label | Title |",
                "|-------|-------|-------|",
            ]
        )
        sorted_titles = sorted(
            title_counts.items(), key=lambda x: int(x[1]["count"]), reverse=True
        )[:15]  # Top 15
        for title, info in sorted_titles:
            label = info["label"]
            icon = (
                "🔴" if label == "Critical" else ("🟡" if label == "Warning" else "🟢")
            )
            # Truncate long titles
            display_title = title[:60] + "..." if len(title) > 60 else title
            lines.append(f"| {info['count']} | {icon} | {display_title} |")
        lines.append("")

    # Critical Findings Detail
    critical_findings = [f for f in all_findings if f.label.lower() == "critical"]
    if critical_findings:
        # Group by category
        critical_by_category: dict[str, list[FindingData]] = defaultdict(list)
        for f in critical_findings:
            critical_by_category[f.category].append(f)

        lines.extend(
            [
                "### Critical Findings Breakdown",
                "",
            ]
        )
        sorted_critical_cats = sorted(
            critical_by_category.items(), key=lambda x: len(x[1]), reverse=True
        )
        for category, findings in sorted_critical_cats[:5]:  # Top 5 categories
            lines.append(f"**{category}** ({len(findings)} critical findings):")
            lines.append("")
            # Show unique titles
            unique_titles = {f.title for f in findings}
            for title in list(unique_titles)[:5]:
                lines.append(f"- {title}")
            if len(unique_titles) > 5:
                lines.append(f"- _...and {len(unique_titles) - 5} more_")
            lines.append("")

    return lines


def generate_stats_markdown(session_stats: SessionStats) -> str:
    """Generate the stats.md content."""
    lines = [
        "# Session Statistics",
        "",
        f"**Session ID:** `{session_stats.session_id}`",
        f"**Target URL:** {session_stats.target_url}",
        "",
    ]

    if session_stats.start_time and session_stats.end_time:
        lines.extend(
            [
                f"**Start Time:** {session_stats.start_time.strftime('%Y-%m-%d %H:%M:%S')}",
                f"**End Time:** {session_stats.end_time.strftime('%Y-%m-%d %H:%M:%S')}",
                f"**Total Duration:** {session_stats.total_duration_min:.1f} minutes",
                "",
            ]
        )

    # Overview section
    lines.extend(
        [
            "## Overview",
            "",
            "| Metric | Value |",
            "|--------|-------|",
            f"| Total Personas | {session_stats.total_personas} |",
            f"| Completed | {session_stats.completed_personas} |",
            f"| Failed | {session_stats.failed_personas} |",
            f"| Total Turns | {session_stats.total_turns} |",
            f"| Total Findings | {session_stats.total_findings} |",
            "",
        ]
    )

    # Findings summary
    lines.extend(
        [
            "## Findings Summary",
            "",
            "| Label | Count | Percentage |",
            "|-------|-------|------------|",
        ]
    )

    total = session_stats.total_findings or 1  # Avoid division by zero
    lines.append(
        f"| 🔴 Critical | {session_stats.total_critical} | {session_stats.total_critical / total * 100:.1f}% |"
    )
    lines.append(
        f"| 🟡 Warning | {session_stats.total_warning} | {session_stats.total_warning / total * 100:.1f}% |"
    )
    lines.append(
        f"| 🟢 Good | {session_stats.total_good} | {session_stats.total_good / total * 100:.1f}% |"
    )
    lines.append("")

    # Comprehensive findings analysis
    lines.extend(generate_findings_analysis(session_stats.all_findings))

    # Conversation length distribution
    turn_counts = [
        s.total_turns for s in session_stats.persona_stats.values() if s.total_turns > 0
    ]
    if turn_counts:
        dist = calculate_distribution([float(t) for t in turn_counts])
        lines.extend(
            [
                "## Conversation Length Distribution",
                "",
                f"Number of turns per conversation (n={dist['count']}):",
                "",
                "| Metric | Value |",
                "|--------|-------|",
                f"| Min | {dist['min']:.0f} |",
                f"| Max | {dist['max']:.0f} |",
                f"| Mean | {dist['mean']:.1f} |",
                f"| Median | {dist['median']:.0f} |",
                f"| Std Dev | {dist['std']:.1f} |",
                "",
            ]
        )
        lines.extend(
            format_histogram_markdown(dist["histogram"], unit=" turns", precision=0)
        )

    # Response extraction time distribution
    all_extraction_times = []
    for stats in session_stats.persona_stats.values():
        all_extraction_times.extend(stats.extraction_times)

    if all_extraction_times:
        dist = calculate_distribution(all_extraction_times)
        lines.extend(
            [
                "## Response Extraction Time Distribution",
                "",
                f"Time to extract chatbot response (n={dist['count']}):",
                "",
                "| Metric | Value |",
                "|--------|-------|",
                f"| Min | {dist['min']:.2f}s |",
                f"| Max | {dist['max']:.2f}s |",
                f"| Mean | {dist['mean']:.2f}s |",
                f"| Median | {dist['median']:.2f}s |",
                f"| Std Dev | {dist['std']:.2f}s |",
                f"| P90 | {dist['percentiles']['p90']:.2f}s |",
                f"| P95 | {dist['percentiles']['p95']:.2f}s |",
                f"| P99 | {dist['percentiles']['p99']:.2f}s |",
                "",
            ]
        )
        lines.extend(
            format_histogram_markdown(dist["histogram"], unit="s", precision=2)
        )

    # TTFT and TTLT distributions
    all_ttft = []
    all_ttlt = []
    for stats in session_stats.persona_stats.values():
        all_ttft.extend(stats.ttft_times)
        all_ttlt.extend(stats.ttlt_times)

    if all_ttft:
        dist = calculate_distribution(all_ttft)
        lines.extend(
            [
                "## Time to First Token (TTFT) Distribution",
                "",
                f"Time until first response token appears (n={dist['count']}):",
                "",
                "| Metric | Value |",
                "|--------|-------|",
                f"| Min | {dist['min']:.2f}s |",
                f"| Max | {dist['max']:.2f}s |",
                f"| Mean | {dist['mean']:.2f}s |",
                f"| Median | {dist['median']:.2f}s |",
                f"| P90 | {dist['percentiles']['p90']:.2f}s |",
                "",
            ]
        )
        lines.extend(
            format_histogram_markdown(dist["histogram"], unit="s", precision=2)
        )

    if all_ttlt:
        dist = calculate_distribution(all_ttlt)
        lines.extend(
            [
                "## Time to Last Token (TTLT) Distribution",
                "",
                f"Total response generation time (n={dist['count']}):",
                "",
                "| Metric | Value |",
                "|--------|-------|",
                f"| Min | {dist['min']:.2f}s |",
                f"| Max | {dist['max']:.2f}s |",
                f"| Mean | {dist['mean']:.2f}s |",
                f"| Median | {dist['median']:.2f}s |",
                f"| P90 | {dist['percentiles']['p90']:.2f}s |",
                "",
            ]
        )
        lines.extend(
            format_histogram_markdown(dist["histogram"], unit="s", precision=2)
        )

    # Response length distribution
    all_lengths = []
    for stats in session_stats.persona_stats.values():
        all_lengths.extend(stats.response_lengths)

    if all_lengths:
        dist = calculate_distribution([float(length) for length in all_lengths])
        lines.extend(
            [
                "## Response Length Distribution",
                "",
                f"Character count of chatbot responses (n={dist['count']}):",
                "",
                "| Metric | Value |",
                "|--------|-------|",
                f"| Min | {dist['min']:.0f} chars |",
                f"| Max | {dist['max']:.0f} chars |",
                f"| Mean | {dist['mean']:.0f} chars |",
                f"| Median | {dist['median']:.0f} chars |",
                "",
            ]
        )
        lines.extend(
            format_histogram_markdown(dist["histogram"], unit=" chars", precision=0)
        )

    # Within-run slowdown analysis
    slowdown_ratios = []
    for stats in session_stats.persona_stats.values():
        if stats.first_turn_extraction_s > 0 and stats.last_turn_extraction_s > 0:
            ratio = stats.last_turn_extraction_s / stats.first_turn_extraction_s
            slowdown_ratios.append(
                (
                    stats.instance_name,
                    stats.first_turn_extraction_s,
                    stats.last_turn_extraction_s,
                    ratio,
                )
            )

    if slowdown_ratios:
        lines.extend(
            [
                "## Within-Run Performance Analysis",
                "",
                "Comparison of first turn vs last turn extraction time per persona:",
                "",
                "| Persona | First Turn | Last Turn | Ratio |",
                "|---------|------------|-----------|-------|",
            ]
        )

        slowdown_ratios.sort(key=lambda x: x[3], reverse=True)
        for name, first, last, ratio in slowdown_ratios:
            indicator = "🔴" if ratio > 1.5 else ("🟡" if ratio > 1.2 else "🟢")
            lines.append(
                f"| {indicator} {name} | {first:.2f}s | {last:.2f}s | {ratio:.2f}x |"
            )

        avg_ratio = mean(r[3] for r in slowdown_ratios)
        lines.extend(
            [
                "",
                f"**Average slowdown ratio:** {avg_ratio:.2f}x",
                "",
            ]
        )

        if avg_ratio > 1.5:
            lines.append(
                "⚠️ **Significant within-run slowdown detected** - suggests context/memory buildup"
            )
        elif avg_ratio > 1.2:
            lines.append("🟡 **Moderate within-run slowdown detected**")
        else:
            lines.append("✅ **No significant within-run slowdown**")
        lines.append("")

    # Per-persona summary table
    lines.extend(
        [
            "## Per-Persona Summary",
            "",
            "| Persona | Turns | Avg Extract | Total Time | Findings (C/W/G) |",
            "|---------|-------|-------------|------------|------------------|",
        ]
    )

    for name, stats in sorted(session_stats.persona_stats.items()):
        findings_str = (
            f"{stats.critical_count}/{stats.warning_count}/{stats.good_count}"
        )
        lines.append(
            f"| {name} | {stats.total_turns} | {stats.avg_extraction_time_s:.2f}s | {stats.total_duration_s:.1f}s | {findings_str} |"
        )

    lines.append("")

    # Footer
    lines.extend(
        [
            "---",
            f"*Generated at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*",
        ]
    )

    return "\n".join(lines)


def generate_session_stats(session_dir: str | Path) -> SessionStats:
    """Generate statistics for a session directory.

    Args:
        session_dir: Path to the session directory

    Returns:
        SessionStats object with all collected statistics
    """
    session_path = Path(session_dir)
    session_id = session_path.name

    stats = SessionStats(session_id=session_id)

    # Parse timing log
    timing_log_path = session_path / "agent-timing.log"
    timing_entries: list[TimingEntry] = []
    if timing_log_path.exists():
        timing_entries = parse_timing_log(timing_log_path)

        if timing_entries:
            stats.start_time = min(e.timestamp for e in timing_entries)
            stats.end_time = max(e.timestamp for e in timing_entries)
            stats.total_duration_min = (
                stats.end_time - stats.start_time
            ).total_seconds() / 60

    # Load report_data.json for target URL
    report_data_path = session_path / "report_data.json"
    if report_data_path.exists():
        with open(report_data_path, encoding="utf-8") as f:
            report_data = json.load(f)
            stats.target_url = report_data.get("target_url", "")

    # Collect persona stats and findings
    persona_stats, all_findings = collect_persona_stats(session_path, timing_entries)
    stats.persona_stats = persona_stats
    stats.all_findings = all_findings

    # Aggregate stats
    stats.total_personas = len(stats.persona_stats)
    stats.completed_personas = sum(
        1 for s in stats.persona_stats.values() if s.total_turns > 0
    )
    stats.failed_personas = stats.total_personas - stats.completed_personas

    for persona_stats in stats.persona_stats.values():
        stats.total_turns += persona_stats.total_turns
        stats.total_findings += persona_stats.findings_count
        stats.total_critical += persona_stats.critical_count
        stats.total_warning += persona_stats.warning_count
        stats.total_good += persona_stats.good_count

    return stats


def generate_stats_file(session_dir: str | Path) -> Path:
    """Generate stats.md file for a session.

    Args:
        session_dir: Path to the session directory

    Returns:
        Path to the generated stats.md file
    """
    session_path = Path(session_dir)

    logger.info(f"Generating session statistics for {session_path.name}...")

    # Collect all statistics
    session_stats = generate_session_stats(session_path)

    # Generate markdown
    markdown_content = generate_stats_markdown(session_stats)

    # Write to file
    stats_file = session_path / "stats.md"
    with open(stats_file, "w", encoding="utf-8") as f:
        f.write(markdown_content)

    logger.info(f"✅ Stats saved to {stats_file}")

    return stats_file


if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO)

    if len(sys.argv) < 2:
        print("Usage: python stats_generator.py <session_dir>")
        sys.exit(1)

    session_dir = sys.argv[1]
    generate_stats_file(session_dir)
