"""
Utility for generating consolidated summary reports from persona testing results.

This module provides reusable logic for generating summary reports that can be
used by both the orchestrator (during pipeline execution) and standalone scripts
(for ad-hoc report regeneration).
"""

import json
import logging
import time
from pathlib import Path
from typing import Any

from constants import (
    SUMMARY_FILENAME,
    TRANSCRIPT_FILENAME,
)
from utils.html_report_generator import generate_html_report
from utils.presentation_generator import generate_presentation_for_session
from utils.report_data_generator import generate_report_data
from utils.stats_generator import generate_stats_file
from utils.timing_logger import log_timing

logger = logging.getLogger(__name__)


async def generate_consolidated_summary(
    target_url: str,
    results: dict[str, Any],
    persona_ids: list[str],
    output_dir: str,
    timestamp: str,  # noqa: ARG001 - kept for API compatibility
    format: str = "html",
    include_eu_ai_act_report: bool = False,
    include_test_summary: bool = False,
    test_suite: Any = None,
    max_parallel: int = 4,
    include_aes_score: bool = False,
) -> None:
    """
    Generate a consolidated summary report covering all personas.
    Works for both single and multiple persona runs.

    Args:
        target_url: The target URL that was tested
        results: Dictionary mapping persona_id to result dict with keys:
            - error (str, optional): Error message if persona run failed
            - usage (dict/object, optional): Token usage data with input_tokens,
              output_tokens, total_tokens, total_cost
            - latency_measurements (list, optional): List of latency measurement values
            - total_turns (int, optional): Number of conversation turns
            - latency_stats (dict, optional): Pre-calculated latency statistics
        persona_ids: List of persona IDs that were run
        output_dir: Directory to save the summary (session folder)
        timestamp: Timestamp string for the report
        format: Output format - 'html' (default)
        include_eu_ai_act_report: Whether to include EU AI Act compliance assessment (default: False)
        include_test_summary: Whether to include test/scenario summary generation (default: False)
        test_suite: Optional TestSuite object for generating per-test/scenario summaries
        max_parallel: Maximum number of parallel LLM calls for finding consolidation (default: 4)
        include_aes_score: Whether to calculate Agent Expertise Score (default: False, slow LLM call)

    Raises:
        Exception: If summary generation fails
    """
    output_path = Path(output_dir)

    # Collect data from all persona runs
    persona_summaries = []
    total_input_tokens = 0
    total_output_tokens = 0
    total_tokens_all = 0
    total_cost = 0.0
    personas_with_usage = 0

    # Latency tracking across all personas
    all_latency_measurements = []
    personas_with_latency = 0

    for persona_id in persona_ids:
        result = results.get(persona_id)
        if not result or "error" in result:
            persona_summaries.append(
                {
                    "persona_id": persona_id,
                    "status": "failed",
                    "error": result.get("error", "Unknown error")
                    if result
                    else "No result",
                }
            )
            continue

        # Read individual persona summary/transcript from subdirectory
        persona_dir = output_path / persona_id
        summary_file = persona_dir / SUMMARY_FILENAME
        transcript_file = persona_dir / TRANSCRIPT_FILENAME

        individual_summary = ""
        if summary_file.exists():
            with open(summary_file, encoding="utf-8") as f:
                individual_summary = f.read()

        transcript_data = []
        if transcript_file.exists():
            with open(transcript_file, encoding="utf-8") as f:
                loaded = json.load(f)
                if isinstance(loaded, list):
                    transcript_data = loaded
                else:
                    transcript_data = loaded.get("transcript", [])

        # Collect usage data if available
        usage = result.get("usage")
        if not usage:
            # Try new location in stats
            usage = result.get("stats", {}).get("usage")

        if usage:
            personas_with_usage += 1
            # Handle both dictionary and object formats
            if isinstance(usage, dict):
                total_input_tokens += usage.get("input_tokens", 0)
                total_output_tokens += usage.get("output_tokens", 0)
                total_tokens_all += usage.get("total_tokens", 0)
                total_cost += usage.get("total_cost", 0.0)
            else:
                if hasattr(usage, "input_tokens"):
                    total_input_tokens += usage.input_tokens
                if hasattr(usage, "output_tokens"):
                    total_output_tokens += usage.output_tokens
                if hasattr(usage, "total_tokens"):
                    total_tokens_all += usage.total_tokens
                if hasattr(usage, "total_cost"):
                    total_cost += usage.total_cost

        # Collect latency measurements if available
        latency_measurements = result.get("latency_measurements", [])
        if not latency_measurements:
            # Extract from transcript loaded from disk (more reliable
            # than depending on in-memory result dict)
            transcript_items = transcript_data
            for item in transcript_items:
                if item.get("role") == "assistant" and "measurements" in item:
                    measurements = item["measurements"]
                    if "ttlt" in measurements:
                        latency_measurements.append(
                            {
                                "turn_number": item.get("turn_number"),
                                "latency_seconds": measurements["ttlt"],
                            }
                        )
                    elif "latency" in measurements:
                        latency_measurements.append(
                            {
                                "turn_number": item.get("turn_number"),
                                "latency_seconds": measurements["latency"],
                            }
                        )

        if latency_measurements:
            personas_with_latency += 1
            all_latency_measurements.extend(latency_measurements)

        persona_summaries.append(
            {
                "persona_id": persona_id,
                "status": "success",
                "output_dir": str(persona_dir),
                "total_turns": result.get("total_turns", 0),
                "summary": individual_summary,
                "transcript_length": len(transcript_data),
                "usage": usage,
                "latency_stats": result.get("latency_stats"),
            }
        )

    logger.info("Generating consolidated summary...")

    # NOTE: The legacy LLM call using summary_report_template was removed.
    # It was processing all persona data in one massive call but the response
    # was only used for monitoring. All actual report generation now happens
    # in generate_report_data() which reads from individual summary.json files
    # and uses parallelized finding consolidation.

    # Filter persona_ids to only include successful ones (those with summary.json)
    # Failed personas won't have summary.json so including them causes FileNotFoundError
    successful_persona_ids = [
        pid for pid in persona_ids if results.get(pid) and "error" not in results[pid]
    ]

    if not successful_persona_ids:
        logger.warning(
            "⚠️ No successful persona runs found — skipping report generation"
        )
        raise FileNotFoundError(
            f"No successful persona runs to generate report from. "
            f"All {len(persona_ids)} persona(s) failed."
        )

    if len(successful_persona_ids) < len(persona_ids):
        failed_count = len(persona_ids) - len(successful_persona_ids)
        logger.warning(
            f"⚠️ {failed_count}/{len(persona_ids)} persona(s) failed — "
            f"generating report with {len(successful_persona_ids)} successful persona(s)"
        )

    # Generate structured report data (JSON) from individual persona results
    # This is the single source of truth for both HTML and Markdown reports
    try:
        # Time report data generation (includes LLM calls for finding consolidation, EU AI Act, etc.)
        report_data_start = time.time()
        report_data = await generate_report_data(
            target_url=target_url,
            results=results,
            persona_ids=successful_persona_ids,
            session_dir=str(output_path),
            include_eu_ai_act_report=include_eu_ai_act_report,
            include_test_summary=include_test_summary,
            test_suite=test_suite,
            max_parallel=max_parallel,
            include_aes_score=include_aes_score,
        )
        report_data_duration = time.time() - report_data_start

        log_timing(
            "report_data_generation",
            report_data_duration,
            {
                "num_personas": len(persona_ids),
                "include_eu_ai_act": include_eu_ai_act_report,
                "include_test_summary": include_test_summary,
            },
        )
    except Exception as e:
        logger.error(f"❌ Failed to generate report data: {e}")
        import traceback

        logger.error(traceback.format_exc())
        raise

    # Generate HTML report from structured data
    if format in ["html", "html-only"]:
        try:
            # Time HTML report generation
            html_start = time.time()
            html_content = generate_html_report(report_data=report_data)
            html_path = output_path / "summary.html"
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            html_duration = time.time() - html_start

            log_timing("html_report_generation", html_duration, {})

            logger.info(f"✅ HTML report saved to: {html_path} in {html_duration:.2f}s")
        except Exception as e:
            logger.error(f"❌ Failed to generate HTML report: {e}")
            import traceback

            logger.error(traceback.format_exc())
            raise

        # Generate standalone presentation if custom report content exists
        try:
            pres_start = time.time()
            presentation_file = generate_presentation_for_session(str(output_path))
            pres_duration = time.time() - pres_start

            if presentation_file:
                log_timing("presentation_generation", pres_duration, {})
                logger.info(
                    f"✅ Presentation saved to: {presentation_file} in {pres_duration:.2f}s"
                )
        except Exception as e:
            logger.warning(f"⚠️ Failed to generate presentation: {e}")
            # Non-fatal - don't raise

    # Generate session statistics (stats.md)
    try:
        stats_start = time.time()
        stats_file = generate_stats_file(str(output_path))
        stats_duration = time.time() - stats_start

        log_timing("stats_generation", stats_duration, {})

        logger.info(f"✅ Stats saved to: {stats_file} in {stats_duration:.2f}s")
    except Exception as e:
        logger.warning(f"⚠️ Failed to generate stats.md: {e}")
        # Non-fatal - don't raise
