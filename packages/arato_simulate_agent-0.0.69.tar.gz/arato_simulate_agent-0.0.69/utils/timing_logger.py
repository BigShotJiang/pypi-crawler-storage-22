"""
Timing Logger: Tracks timing for critical agent operations.

This module provides utilities to measure and log timing information
for debugging and optimization of agent performance.

Includes CPU vs I/O breakdown for understanding where time is spent.
"""

import logging
import os
import time
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from browser_use import Browser

logger = logging.getLogger(__name__)


@dataclass
class TimingBreakdown:
    """Breakdown of wall clock time into CPU and I/O components."""

    wall_time: float  # Total elapsed time (seconds)
    cpu_time: float  # CPU time (user + system)
    io_time: float  # I/O wait time (wall - cpu)
    cpu_percent: float  # Percentage of time spent on CPU (0-100)

    def to_dict(self) -> dict[str, float]:
        """Convert to dictionary for logging."""
        return {
            "wall_s": round(self.wall_time, 3),
            "cpu_s": round(self.cpu_time, 3),
            "io_s": round(self.io_time, 3),
            "cpu_pct": round(self.cpu_percent, 1),
        }


@dataclass
class BrowserMetrics:
    """Browser performance metrics for memory and DOM monitoring."""

    js_heap_used_mb: float = 0.0  # JavaScript heap used (MB)
    js_heap_total_mb: float = 0.0  # JavaScript heap total (MB)
    dom_nodes: int = 0  # Number of DOM nodes
    content_length: int = 0  # Length of extracted markdown content (chars)
    extraction_ms: float = 0.0  # Time spent in _extract_clean_markdown (ms)

    def to_dict(self) -> dict[str, float | int]:
        """Convert to dictionary for logging."""
        return {
            "heap_mb": round(self.js_heap_used_mb, 1),
            "dom_nodes": self.dom_nodes,
            "content_len": self.content_length,
            "extract_ms": round(self.extraction_ms, 1),
        }


async def get_browser_metrics(browser: "Browser | None") -> BrowserMetrics | None:
    """Get browser memory and DOM metrics.

    Args:
        browser: browser-use BrowserSession instance

    Returns:
        BrowserMetrics with memory and DOM info, or None if unavailable
    """
    if browser is None:
        return None

    try:
        page = await browser.get_current_page()
        if page is None:
            return None

        # Get JavaScript heap metrics using browser-use's CDP client
        try:
            # Ensure CDP session is established for this page
            session_id = await page.session_id
            cdp_client = browser.cdp_client

            if cdp_client is not None:
                # Enable Performance domain first (required for getMetrics)
                await cdp_client.send.Performance.enable(session_id=session_id)

                # Get Performance metrics via CDP
                metrics_response = await cdp_client.send.Performance.getMetrics(
                    session_id=session_id
                )
                metrics_list = metrics_response.get("metrics", [])
                metrics_dict = {m["name"]: m["value"] for m in metrics_list}

                js_heap_used = metrics_dict.get("JSHeapUsedSize", 0) / (1024 * 1024)
                js_heap_total = metrics_dict.get("JSHeapTotalSize", 0) / (1024 * 1024)
                dom_nodes = int(metrics_dict.get("Nodes", 0))
            else:
                js_heap_used = 0.0
                js_heap_total = 0.0
                dom_nodes = 0
        except Exception:
            # CDP not available
            js_heap_used = 0.0
            js_heap_total = 0.0
            dom_nodes = 0

        # Measure _extract_clean_markdown time
        start_extract = time.time()
        try:
            # Use the internal method that does DOM serialization
            content, _ = await page._extract_clean_markdown()
            content_length = len(content) if content else 0
        except Exception:
            content_length = 0
        extraction_ms = (time.time() - start_extract) * 1000

        return BrowserMetrics(
            js_heap_used_mb=js_heap_used,
            js_heap_total_mb=js_heap_total,
            dom_nodes=dom_nodes,
            content_length=content_length,
            extraction_ms=extraction_ms,
        )
    except Exception as e:
        logger.debug(f"Failed to get browser metrics: {e}")
        return None


def measure_cpu_time() -> tuple[float, float]:
    """Get current process CPU times (user, system).

    Returns:
        Tuple of (user_time, system_time) in seconds
    """
    times = os.times()
    return times.user, times.system


def calculate_timing_breakdown(
    start_wall: float,
    end_wall: float,
    start_cpu: tuple[float, float],
    end_cpu: tuple[float, float],
) -> TimingBreakdown:
    """Calculate timing breakdown from start/end measurements.

    Args:
        start_wall: Wall clock time at start
        end_wall: Wall clock time at end
        start_cpu: (user, system) CPU times at start
        end_cpu: (user, system) CPU times at end

    Returns:
        TimingBreakdown with wall, cpu, io times and cpu percentage
    """
    wall_time = end_wall - start_wall
    cpu_user = end_cpu[0] - start_cpu[0]
    cpu_system = end_cpu[1] - start_cpu[1]
    cpu_time = cpu_user + cpu_system

    # I/O time is everything not spent on CPU
    io_time = max(0.0, wall_time - cpu_time)

    # Calculate CPU percentage (avoid division by zero)
    cpu_percent = (cpu_time / wall_time * 100) if wall_time > 0 else 0.0

    return TimingBreakdown(
        wall_time=wall_time,
        cpu_time=cpu_time,
        io_time=io_time,
        cpu_percent=cpu_percent,
    )


class TimingLogger:
    """Tracks and logs timing information for critical operations."""

    def __init__(self, log_file: Path | str | None = None):
        """
        Initialize timing logger.

        Args:
            log_file: Path to timing log file (default: agent-timing.log in current dir)
        """
        self.log_file = Path(log_file) if log_file else None
        self._timing_logger: logging.Logger | None = None

        if self.log_file:
            self._setup_file_logger()

    def _setup_file_logger(self) -> None:
        """Set up dedicated file logger for timing information."""
        # Write header comment if file doesn't exist
        if self.log_file and not Path(self.log_file).exists():
            header = (
                "# Agent Timing Log - Field Definitions\n"
                "#\n"
                "# This log captures performance metrics for agent operations with CPU/IO breakdown.\n"
                "#\n"
                "# Field Definitions:\n"
                "#   operation:  Name of the operation being timed (e.g., response_extraction, sub_agent_evaluation)\n"
                "#   duration:   Wall clock time in seconds - total elapsed time from start to finish\n"
                "#   turn:       Conversation turn number (starts at 1)\n"
                "#   persona:    Persona instance name (e.g., naive_insurance_agent_01)\n"
                "#   domain:     Domain being tested (e.g., console.cloudinary.com)\n"
                "#   cpu_s:      CPU time in seconds - actual time CPU was executing code (user + system time)\n"
                "#   io_s:       I/O wait time in seconds - time spent waiting for I/O (wall_time - cpu_time)\n"
                "#   cpu_pct:    CPU utilization percentage - (cpu_time / wall_time) * 100\n"
                "#               < 5%: Highly I/O-bound (LLM calls, network, browser automation)\n"
                "#               > 50%: CPU-bound (computation, parsing, data processing)\n"
                "#               > 100%: Multi-core parallelization detected\n"
                "#\n"
                "# Browser Metrics (for response_extraction operations):\n"
                "#   heap_mb:      JavaScript heap memory used (MB) - monitors memory growth\n"
                "#   dom_nodes:    Number of DOM nodes in page - monitors DOM tree growth\n"
                "#   content_len:  Character count of extracted markdown content\n"
                "#   extract_ms:   Time in milliseconds for _extract_clean_markdown() only\n"
                "#   context_chars: Size of context sent to LLM (system_prompt + content)\n"
                "#\n"
                "# Example Entry:\n"
                "#   response_extraction: 10.234s | turn=1 | persona=naive_insurance_agent_01 | cpu_s=0.015 | io_s=10.219 | cpu_pct=0.1\n"
                "#   ↑ This shows a highly I/O-bound operation (0.1% CPU) - most time spent waiting for LLM response\n"
                "#\n"
                "#   response_extraction: 15.4s | turn=5 | persona=... | heap_mb=85.2 | dom_nodes=2500 | content_len=12500 | extract_ms=450 | context_chars=15600\n"
                "#   ↑ Browser metrics help identify if DOM/memory growth causes slowdown; context_chars shows LLM input size\n"
                "#\n"
                "# Analysis Tips:\n"
                "#   - Low cpu_pct (< 5%): Look for opportunities to parallelize I/O operations\n"
                "#   - High cpu_pct (> 50%): Consider caching or algorithm optimization\n"
                "#   - High io_s: Check network latency, API response times, browser automation delays\n"
                "#   - Growing heap_mb/dom_nodes across turns: Browser state accumulation\n"
                "#   - High extract_ms: DOM serialization becoming expensive\n"
                "#\n"
                "================================================================================\n\n"
            )
            try:
                with open(self.log_file, "w", encoding="utf-8") as f:
                    f.write(header)
            except Exception as e:
                logger.warning(f"Could not write timing log header: {e}")

        self._timing_logger = logging.getLogger("agent_timing")
        self._timing_logger.setLevel(logging.INFO)
        self._timing_logger.propagate = False  # Don't propagate to root logger

        # Remove existing handlers to avoid duplicates
        self._timing_logger.handlers.clear()

        # Create file handler
        handler = logging.FileHandler(self.log_file)  # type: ignore
        handler.setLevel(logging.INFO)

        # Simple format: timestamp - operation - duration
        formatter = logging.Formatter(
            "%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S.%f"
        )
        handler.setFormatter(formatter)

        self._timing_logger.addHandler(handler)

    def log_timing(
        self,
        operation: str,
        duration: float,
        metadata: dict[str, Any] | None = None,
        breakdown: TimingBreakdown | None = None,
        browser_metrics: BrowserMetrics | None = None,
    ) -> None:
        """
        Log timing information for an operation.

        Args:
            operation: Name of the operation being timed
            duration: Duration in seconds (wall clock time)
            metadata: Optional additional context (e.g., turn number, persona)
            breakdown: Optional CPU/IO timing breakdown
            browser_metrics: Optional browser memory/DOM metrics
        """
        # Build metadata string
        all_metadata: dict[str, Any] = {}
        if metadata:
            all_metadata.update(metadata)

        # Add breakdown info if available
        if breakdown:
            all_metadata["cpu_s"] = round(breakdown.cpu_time, 3)
            all_metadata["io_s"] = round(breakdown.io_time, 3)
            all_metadata["cpu_pct"] = round(breakdown.cpu_percent, 1)

        # Add browser metrics if available
        if browser_metrics:
            all_metadata["heap_mb"] = round(browser_metrics.js_heap_used_mb, 1)
            all_metadata["dom_nodes"] = browser_metrics.dom_nodes
            all_metadata["content_len"] = browser_metrics.content_length
            all_metadata["extract_ms"] = round(browser_metrics.extraction_ms, 1)

        # Build metadata string with consistent ordering
        metadata_str = ""
        if all_metadata:
            # Define field order for consistent log format
            field_order = [
                "turn",
                "persona",
                "domain",
                "cpu_s",
                "io_s",
                "cpu_pct",
                "heap_mb",
                "dom_nodes",
                "content_len",
                "extract_ms",
                "context_chars",
            ]

            # Add fields in order
            ordered_parts = []
            for key in field_order:
                if key in all_metadata and all_metadata[key] is not None:
                    ordered_parts.append(f"{key}={all_metadata[key]}")

            # Add any remaining fields not in order list
            for key, value in all_metadata.items():
                if key not in field_order and value is not None:
                    ordered_parts.append(f"{key}={value}")

            if ordered_parts:
                metadata_str = " | " + " | ".join(ordered_parts)

        message = f"{operation}: {duration:.3f}s{metadata_str}"

        # Log to file if available
        if self._timing_logger:
            self._timing_logger.info(message)

        # Also log to console with emoji for visibility
        logger.info(f"⏱️  {message}")

    @contextmanager
    def measure(
        self,
        operation: str,
        metadata: dict[str, Any] | None = None,
        include_breakdown: bool = True,
    ):
        """
        Context manager to measure and log operation timing.

        Usage:
            with timing_logger.measure("response_extraction", {"turn": 1}):
                extract_response()

        Args:
            operation: Name of the operation being timed
            metadata: Optional additional context
            include_breakdown: Whether to include CPU/IO breakdown (default: True)
        """
        start_wall = time.time()
        start_cpu = measure_cpu_time() if include_breakdown else (0.0, 0.0)
        try:
            yield
        finally:
            end_wall = time.time()
            duration = end_wall - start_wall

            breakdown = None
            if include_breakdown:
                end_cpu = measure_cpu_time()
                breakdown = calculate_timing_breakdown(
                    start_wall, end_wall, start_cpu, end_cpu
                )

            self.log_timing(operation, duration, metadata, breakdown)


# Global timing logger instance
_timing_logger: TimingLogger | None = None


def get_timing_logger(log_file: Path | str | None = None) -> TimingLogger:
    """Get or create global timing logger instance."""
    global _timing_logger
    if _timing_logger is None:
        _timing_logger = TimingLogger(log_file)
    return _timing_logger


def log_timing(
    operation: str,
    duration: float,
    metadata: dict[str, Any] | None = None,
    breakdown: TimingBreakdown | None = None,
) -> None:
    """
    Convenience function to log timing using global logger.

    Args:
        operation: Name of the operation being timed
        duration: Duration in seconds
        metadata: Optional additional context
        breakdown: Optional CPU/IO timing breakdown
    """
    get_timing_logger().log_timing(operation, duration, metadata, breakdown)


def log_timing_with_breakdown(
    operation: str,
    start_wall: float,
    end_wall: float,
    start_cpu: tuple[float, float],
    end_cpu: tuple[float, float],
    metadata: dict[str, Any] | None = None,
) -> None:
    """
    Log timing with CPU/IO breakdown from pre-captured measurements.

    Use this when you need to capture timing across async boundaries.

    Args:
        operation: Name of the operation being timed
        start_wall: Wall clock time at start
        end_wall: Wall clock time at end
        start_cpu: (user, system) CPU times at start
        end_cpu: (user, system) CPU times at end
        metadata: Optional additional context
    """
    duration = end_wall - start_wall
    breakdown = calculate_timing_breakdown(start_wall, end_wall, start_cpu, end_cpu)
    get_timing_logger().log_timing(operation, duration, metadata, breakdown)


@contextmanager
def measure_time(
    operation: str,
    metadata: dict[str, Any] | None = None,
    include_breakdown: bool = True,
):
    """
    Convenience context manager to measure operation timing with CPU/IO breakdown.

    Usage:
        with measure_time("captcha_solve", {"attempt": 1}):
            solve_captcha()

    Args:
        operation: Name of the operation being timed
        metadata: Optional additional context
        include_breakdown: Whether to include CPU/IO breakdown (default: True)
    """
    start_wall = time.time()
    start_cpu = measure_cpu_time() if include_breakdown else (0.0, 0.0)
    try:
        yield
    finally:
        end_wall = time.time()
        duration = end_wall - start_wall

        breakdown = None
        if include_breakdown:
            end_cpu = measure_cpu_time()
            breakdown = calculate_timing_breakdown(
                start_wall, end_wall, start_cpu, end_cpu
            )

        log_timing(operation, duration, metadata, breakdown)


@asynccontextmanager
async def measure_time_async(
    operation: str,
    **metadata: Any,
):
    """
    Async context manager to measure operation timing with automatic CPU/IO breakdown.

    This is the cleanest API for timing async operations - just wrap your code in this context.

    Usage:
        async with measure_time_async("response_extraction", turn=1, persona="naive_01"):
            result = await extract_response()

    Args:
        operation: Name of the operation being timed
        **metadata: Additional context as keyword arguments (e.g., turn=1, persona="naive")
    """
    start_wall = time.time()
    start_cpu = measure_cpu_time()
    try:
        yield
    finally:
        end_wall = time.time()
        end_cpu = measure_cpu_time()
        duration = end_wall - start_wall
        breakdown = calculate_timing_breakdown(start_wall, end_wall, start_cpu, end_cpu)
        log_timing(operation, duration, metadata, breakdown)


@asynccontextmanager
async def measure_time_with_browser(
    operation: str,
    browser: "Browser | None" = None,
    context_metadata: dict[str, int] | None = None,
    **metadata: Any,
):
    """
    Async context manager to measure operation timing WITH browser metrics.

    Captures browser memory usage, DOM node count, and content extraction time
    to help diagnose performance degradation over conversation turns.

    Usage:
        extraction_metadata = {}
        async with measure_time_with_browser(
            "response_extraction",
            browser=agent.browser_session,
            turn=1,
            persona="naive_01",
            context_metadata=extraction_metadata
        ):
            # extraction_metadata['context_chars'] set inside here
            result = await extract_response()

    Args:
        operation: Name of the operation being timed
        browser: browser-use Browser instance for memory/DOM metrics
        context_metadata: Dict to read context_chars from (populated during operation)
        **metadata: Additional context as keyword arguments
    """
    start_wall = time.time()
    start_cpu = measure_cpu_time()
    try:
        yield
    finally:
        end_wall = time.time()
        end_cpu = measure_cpu_time()
        duration = end_wall - start_wall
        breakdown = calculate_timing_breakdown(start_wall, end_wall, start_cpu, end_cpu)

        # Get browser metrics if browser is provided
        browser_metrics = None
        if browser is not None:
            browser_metrics = await get_browser_metrics(browser)

        # Add context_chars from metadata dict if available
        if context_metadata and "context_chars" in context_metadata:
            metadata = dict(metadata) if metadata else {}
            metadata["context_chars"] = context_metadata["context_chars"]

        get_timing_logger().log_timing(
            operation, duration, metadata, breakdown, browser_metrics
        )
