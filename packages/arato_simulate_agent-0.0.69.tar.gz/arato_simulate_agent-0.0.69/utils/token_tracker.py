"""
Token usage tracking utility.

This module provides centralized token tracking across all LLM invocations
in the application, including browser-use, prompty executions, sub-agents,
and summarizers.

The tracker calculates costs using our own rate constants to avoid
double-counting from different sources that may have their own cost calculations.
"""

import logging
import threading
from dataclasses import dataclass, field
from typing import Any

from constants import (
    TOKEN_COST_PER_MILLION_DEFAULT,
    TOKEN_COST_PER_MILLION_GEMINI_FLASH,
    TOKEN_COST_PER_MILLION_GEMINI_PRO,
    TOKEN_COST_PER_MILLION_HAIKU,
    TOKEN_COST_PER_MILLION_SONNET,
    VERTEX_MODEL_ID_GEMINI_FLASH,
    VERTEX_MODEL_ID_GEMINI_PRO,
    VERTEX_MODEL_ID_HAIKU,
    VERTEX_MODEL_ID_SONNET,
)

logger = logging.getLogger(__name__)


def get_cost_per_million_tokens(model_id: str | None) -> float:
    """Get the cost per million tokens for a given model.

    Args:
        model_id: The model identifier

    Returns:
        Cost in USD per million tokens
    """
    if not model_id:
        return TOKEN_COST_PER_MILLION_DEFAULT

    model_lower = model_id.lower()

    # Match by model name patterns
    if "sonnet" in model_lower:
        return TOKEN_COST_PER_MILLION_SONNET
    elif "haiku" in model_lower:
        return TOKEN_COST_PER_MILLION_HAIKU
    elif "flash" in model_lower:
        return TOKEN_COST_PER_MILLION_GEMINI_FLASH
    elif "gemini" in model_lower and "pro" in model_lower:
        return TOKEN_COST_PER_MILLION_GEMINI_PRO

    # Match exact model IDs
    if model_id in (VERTEX_MODEL_ID_SONNET,):
        return TOKEN_COST_PER_MILLION_SONNET
    elif model_id in (VERTEX_MODEL_ID_HAIKU,):
        return TOKEN_COST_PER_MILLION_HAIKU
    elif model_id in (VERTEX_MODEL_ID_GEMINI_FLASH,):
        return TOKEN_COST_PER_MILLION_GEMINI_FLASH
    elif model_id in (VERTEX_MODEL_ID_GEMINI_PRO,):
        return TOKEN_COST_PER_MILLION_GEMINI_PRO

    return TOKEN_COST_PER_MILLION_DEFAULT


def calculate_cost(total_tokens: int, model_id: str | None = None) -> float:
    """Calculate cost in USD for a given number of tokens.

    Args:
        total_tokens: Total number of tokens used
        model_id: Optional model identifier for accurate pricing

    Returns:
        Cost in USD
    """
    cost_per_million = get_cost_per_million_tokens(model_id)
    return (total_tokens / 1_000_000) * cost_per_million


@dataclass
class TokenUsage:
    """Token usage data for a single LLM invocation."""

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    model_id: str | None = None
    source: str = "unknown"  # Source identifier (browser_use, prompty, sub_agent, etc.)

    @property
    def estimated_cost(self) -> float:
        """Calculate estimated cost for this usage."""
        return calculate_cost(self.total_tokens, self.model_id)


@dataclass
class AggregatedTokenUsage:
    """Aggregated token usage across multiple sources."""

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    estimated_cost: float = 0.0
    by_source: dict[str, "TokenUsage"] = field(default_factory=dict)
    by_model: dict[str, int] = field(default_factory=dict)

    @staticmethod
    def calculate_cost(total_tokens: int, model_id: str | None = None) -> float:
        """Calculate cost in USD for a given number of tokens.

        This is a convenience static method that delegates to the module-level
        calculate_cost function, allowing it to be called from the class.

        Args:
            total_tokens: Total number of tokens used
            model_id: Optional model identifier for accurate pricing

        Returns:
            Cost in USD
        """
        return calculate_cost(total_tokens, model_id)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "estimated_cost": round(self.estimated_cost, 6),
            "by_source": {
                source: {
                    "input_tokens": usage.input_tokens,
                    "output_tokens": usage.output_tokens,
                    "total_tokens": usage.total_tokens,
                }
                for source, usage in self.by_source.items()
            },
            "by_model": dict(self.by_model),
        }


class TokenTracker:
    """Thread-safe token usage tracker for a session.

    Tracks token usage from multiple sources:
    - browser_use: Browser automation agent tokens
    - prompty: Prompt template execution tokens
    - sub_agent: Multi-agent evaluation tokens
    - summarizer: Summary generation tokens
    - discovery: App context discovery tokens

    Usage:
        tracker = TokenTracker()
        tracker.add_usage(TokenUsage(
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
            model_id='claude-sonnet-4-5',
            source='browser_use'
        ))

        # Get aggregated usage
        usage = tracker.get_aggregated_usage()
        print(f"Total tokens: {usage.total_tokens}")
        print(f"Estimated cost: ${usage.estimated_cost:.4f}")
    """

    def __init__(self) -> None:
        """Initialize the token tracker."""
        self._lock = threading.Lock()
        self._usages: list[TokenUsage] = []

    def add_usage(self, usage: TokenUsage) -> None:
        """Add a token usage record.

        Args:
            usage: Token usage to add
        """
        with self._lock:
            self._usages.append(usage)
            logger.debug(
                f"TokenTracker: Added {usage.total_tokens} tokens from {usage.source} "
                f"(model: {usage.model_id})"
            )

    def add_from_dict(
        self,
        usage_dict: dict[str, Any],
        source: str,
        model_id: str | None = None,
    ) -> None:
        """Add token usage from a dictionary.

        Commonly used to add usage from LLM response objects.

        Args:
            usage_dict: Dictionary with token counts
            source: Source identifier
            model_id: Optional model identifier
        """
        if not usage_dict:
            return

        input_tokens = usage_dict.get("input_tokens", 0) or usage_dict.get(
            "prompt_tokens", 0
        )
        output_tokens = usage_dict.get("output_tokens", 0) or usage_dict.get(
            "completion_tokens", 0
        )
        total_tokens = usage_dict.get("total_tokens", 0)

        # Calculate total if not provided
        if not total_tokens and (input_tokens or output_tokens):
            total_tokens = input_tokens + output_tokens

        if total_tokens:
            self.add_usage(
                TokenUsage(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=total_tokens,
                    model_id=model_id,
                    source=source,
                )
            )

    def add_from_browser_use(self, usage_data: Any) -> None:
        """Add token usage from browser-use agent response.

        Args:
            usage_data: Usage object from browser-use (ChatInvokeUsage or similar)
        """
        if not usage_data:
            return

        try:
            input_tokens: int = (
                getattr(usage_data, "input_tokens", None)
                or getattr(usage_data, "prompt_tokens", 0)
                or 0
            )
            output_tokens: int = (
                getattr(usage_data, "output_tokens", None)
                or getattr(usage_data, "completion_tokens", 0)
                or 0
            )
            total_tokens: int = getattr(usage_data, "total_tokens", 0) or 0

            if not total_tokens and (input_tokens or output_tokens):
                total_tokens = input_tokens + output_tokens

            if total_tokens:
                self.add_usage(
                    TokenUsage(
                        input_tokens=input_tokens or 0,
                        output_tokens=output_tokens or 0,
                        total_tokens=total_tokens,
                        source="browser_use",
                    )
                )
        except Exception as e:
            logger.warning(f"Failed to add browser-use usage: {e}")

    def get_aggregated_usage(self) -> AggregatedTokenUsage:
        """Get aggregated token usage across all sources.

        Returns:
            AggregatedTokenUsage with totals and breakdowns
        """
        with self._lock:
            aggregated = AggregatedTokenUsage()

            for usage in self._usages:
                aggregated.input_tokens += usage.input_tokens
                aggregated.output_tokens += usage.output_tokens
                aggregated.total_tokens += usage.total_tokens

                # Calculate cost using our rates (not the source's cost)
                aggregated.estimated_cost += usage.estimated_cost

                # Aggregate by source
                source = usage.source
                if source not in aggregated.by_source:
                    aggregated.by_source[source] = TokenUsage(source=source)

                aggregated.by_source[source].input_tokens += usage.input_tokens
                aggregated.by_source[source].output_tokens += usage.output_tokens
                aggregated.by_source[source].total_tokens += usage.total_tokens

                # Aggregate by model
                model = usage.model_id or "unknown"
                aggregated.by_model[model] = (
                    aggregated.by_model.get(model, 0) + usage.total_tokens
                )

            return aggregated

    def clear(self) -> None:
        """Clear all tracked usage."""
        with self._lock:
            self._usages.clear()
            logger.debug("TokenTracker: Cleared all usage records")


# Thread-local storage for session-scoped trackers
_session_trackers: dict[str, TokenTracker] = {}
_global_lock = threading.Lock()


def get_token_tracker(session_id: str | None = None) -> TokenTracker:
    """Get or create a token tracker for a session.

    Args:
        session_id: Optional session identifier. If None, uses 'default'.

    Returns:
        TokenTracker for the session
    """
    key = session_id or "default"
    with _global_lock:
        if key not in _session_trackers:
            _session_trackers[key] = TokenTracker()
            logger.debug(f"TokenTracker: Created tracker for session {key}")
        return _session_trackers[key]


def clear_token_tracker(session_id: str | None = None) -> None:
    """Clear a session's token tracker.

    Args:
        session_id: Optional session identifier. If None, clears 'default'.
    """
    key = session_id or "default"
    with _global_lock:
        if key in _session_trackers:
            del _session_trackers[key]
            logger.debug(f"TokenTracker: Removed tracker for session {key}")


def clear_all_token_trackers() -> None:
    """Clear all token trackers."""
    with _global_lock:
        _session_trackers.clear()
        logger.debug("TokenTracker: Cleared all session trackers")


__all__ = [
    "TokenUsage",
    "AggregatedTokenUsage",
    "TokenTracker",
    "get_token_tracker",
    "clear_token_tracker",
    "clear_all_token_trackers",
    "calculate_cost",
    "get_cost_per_million_tokens",
]
