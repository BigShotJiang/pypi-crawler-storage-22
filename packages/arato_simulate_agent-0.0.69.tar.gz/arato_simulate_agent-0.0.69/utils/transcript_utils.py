"""Utilities for working with transcript.json files."""

import json
from pathlib import Path

from constants import TRANSCRIPT_FILENAME
from core.schemas import Finding
from utils.finding_utils import finding_from_dict


def extract_evals_from_transcript(
    path: Path,
    finding_ids: set[str] | None = None,
) -> list[Finding]:
    """
    Extract evals (findings) from a transcript.json file.

    All findings are automatically marked with source="transcript" in metadata.

    Args:
        path: Path to directory containing transcript.json.
              TRANSCRIPT_FILENAME constant is automatically appended.
        finding_ids: Optional set of finding IDs to filter by. If provided,
                    only findings with matching IDs will be returned.

    Returns:
        List of Finding objects extracted from turn evals.
        Returns empty list if file doesn't exist or has no transcript.

    Example:
        # Pass persona directory
        findings = extract_evals_from_transcript(Path("session/persona_01"))

        # Filter by IDs
        findings = extract_evals_from_transcript(path, finding_ids={'id1', 'id2'})
    """
    # Build transcript file path
    transcript_file = path / TRANSCRIPT_FILENAME

    if not transcript_file.exists():
        return []

    try:
        with open(transcript_file, encoding="utf-8") as f:
            transcript_data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return []

    transcript = transcript_data.get("transcript", [])
    findings: list[Finding] = []

    for turn in transcript:
        turn_evals = turn.get("evals", [])
        for finding_dict in turn_evals:
            # Filter by ID if requested
            if finding_ids is not None:
                finding_id = finding_dict.get("id")
                if finding_id not in finding_ids:
                    continue

            # Convert dict to Finding object with transcript source
            try:
                finding = finding_from_dict(finding_dict, source="transcript")
                findings.append(finding)
            except (KeyError, TypeError, ValueError):
                # Skip malformed findings
                continue

    return findings
