"""Utility functions for URL parsing and manipulation."""

import re
from urllib.parse import urlparse


def get_domain_from_url(url: str) -> str:
    """Extract domain from URL and sanitize for use as folder name.

    Extracts the hostname from a URL and sanitizes it for safe use as
    a filesystem folder name by removing ports and invalid characters.

    Examples:
        'https://example.com/chat' -> 'example.com'
        'https://example.com:8080/chat' -> 'example.com'
        'https://sub.example.com' -> 'sub.example.com'

    Args:
        url: Full URL to extract domain from

    Returns:
        Sanitized domain string suitable for use as folder name
    """
    parsed = urlparse(url)
    domain = parsed.netloc or parsed.path
    # Remove port numbers
    domain = domain.split(":")[0]
    # Sanitize for filesystem (remove invalid characters)
    domain = re.sub(r"[^\w\-.]", "_", domain)
    return domain


def extract_domain_pattern(url: str) -> list[str]:
    """Extract domain patterns from URL for browser-use allowed_domains.

    Converts a full URL into domain patterns suitable for browser-use's
    allowed_domains parameter. Returns the exact hostname first, followed by
    wildcard patterns for parent domains to allow login redirects.

    Special handling for AWS internal services:
    - EC2 internal DNS (ip-X-X-X-X.ec2.internal) → broad VPC patterns
    - CloudFront (*.cloudfront.net) → service-wide wildcard
    - ELB/ALB (*.elb.amazonaws.com) → service-wide wildcard
    - API Gateway (*.execute-api.*.amazonaws.com) → service-wide wildcard
    - Route53 private zones (*.internal) → broad internal patterns

    Examples:
        'https://example.com/path' -> ['example.com', '*.example.com']
        'http://subdomain.example.com' -> ['subdomain.example.com', '*.subdomain.example.com', '*.example.com']
        'https://console.cloudinary.com' -> ['console.cloudinary.com', '*.console.cloudinary.com', '*.cloudinary.com']
        'http://ip-172-31-24-161.ec2.internal' -> ['ip-172-31-24-161.ec2.internal', '*.ec2.internal', '*.internal']
        'https://d111111abcdef8.cloudfront.net' -> ['d111111abcdef8.cloudfront.net', '*.cloudfront.net']
        'https://my-alb-123.us-east-1.elb.amazonaws.com' -> ['my-alb-123.us-east-1.elb.amazonaws.com', '*.elb.amazonaws.com', '*.amazonaws.com']
        'https://api.internal.myapp.com' -> ['api.internal.myapp.com', '*.internal.myapp.com', '*.myapp.com']

    Args:
        url: Full URL to extract domain from

    Returns:
        List of domain pattern strings from exact match to most general wildcards
    """
    parsed = urlparse(url)
    hostname = parsed.hostname or parsed.netloc

    # Remove 'www.' prefix if present for cleaner matching
    if hostname.startswith("www."):
        hostname = hostname[4:]

    # Split hostname into parts
    parts = hostname.split(".")

    # Always include the exact hostname first
    patterns = [hostname]

    # Check if hostname is an IP address
    import ipaddress

    try:
        ipaddress.ip_address(hostname)
        # It's an IP address, return it as is without wildcards
        return patterns
    except ValueError:
        pass

    # Special handling for EC2 internal DNS (ip-X-X-X-X.ec2.internal)
    if len(parts) >= 3 and parts[0].startswith("ip-") and "ec2" in parts:
        patterns.append("*.ec2.internal")
        patterns.append("*.internal")
        return patterns

    # Special handling for CloudFront distributions (*.cloudfront.net)
    if len(parts) >= 2 and parts[-2] == "cloudfront" and parts[-1] == "net":
        patterns.append("*.cloudfront.net")
        return patterns

    # Special handling for AWS ELB/ALB (*.elb.amazonaws.com)
    if "elb" in parts and "amazonaws" in parts:
        patterns.append("*.elb.amazonaws.com")
        patterns.append("*.amazonaws.com")
        return patterns

    # Special handling for API Gateway (*.execute-api.*.amazonaws.com)
    if "execute-api" in parts and "amazonaws" in parts:
        # Find the position of execute-api
        exec_idx = parts.index("execute-api")
        if exec_idx > 0:
            # Include region-specific pattern
            region_pattern = ".".join(parts[exec_idx - 1 :])
            patterns.append(f"*.{region_pattern}")
        patterns.append("*.execute-api.*.amazonaws.com")
        patterns.append("*.amazonaws.com")
        return patterns

    # Special handling for Route53 private hosted zones (*.internal)
    # These often use .internal TLD for private DNS
    if len(parts) >= 2 and parts[-1] == "internal":
        # Generate patterns for internal domains
        for i in range(len(parts) - 1):
            domain = ".".join(parts[i:])
            patterns.append(f"*.{domain}")
        return patterns

    # Standard behavior: generate wildcard patterns for all levels
    # Stop at the base domain (e.g., example.com) - don't generate TLD-only patterns
    for i in range(
        len(parts) - 1
    ):  # Stop before the last part to avoid TLD-only patterns
        domain = ".".join(parts[i:])
        patterns.append(f"*.{domain}")

    return patterns


__all__ = ["get_domain_from_url", "extract_domain_pattern"]
