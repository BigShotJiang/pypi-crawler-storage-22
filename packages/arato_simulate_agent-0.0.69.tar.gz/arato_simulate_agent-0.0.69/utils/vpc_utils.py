"""Shared utilities for AWS VPC endpoint management across platforms."""

from constants import VPC_REQUIRED_ENDPOINTS


def get_required_vpc_endpoints(region: str) -> list[dict]:
    """Get list of required VPC endpoints for AgentCore with browser.

    Args:
        region: AWS region (e.g., 'us-east-1')

    Returns:
        List of endpoint configurations with full service names and metadata.
    """
    endpoints = []
    for ep in VPC_REQUIRED_ENDPOINTS:
        endpoint = ep.copy()
        endpoint["service"] = f"com.amazonaws.{region}.{ep['service_suffix']}"
        endpoints.append(endpoint)
    return endpoints


def check_existing_endpoints(ec2_client, vpc_id: str, region: str) -> dict:
    """Check which required VPC endpoints already exist.

    Args:
        ec2_client: boto3 EC2 client
        vpc_id: VPC ID to check
        region: AWS region

    Returns:
        Dict mapping service names to endpoint IDs (or None if missing)
    """
    required_endpoints = get_required_vpc_endpoints(region)
    existing_endpoints = ec2_client.describe_vpc_endpoints(
        Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
    )["VpcEndpoints"]

    endpoint_map = {}
    for req in required_endpoints:
        service_name = req["service"]
        # Find matching endpoint
        matching = next(
            (
                ep
                for ep in existing_endpoints
                if ep["ServiceName"] == service_name and ep["State"] != "deleted"
            ),
            None,
        )
        endpoint_map[service_name] = matching["VpcEndpointId"] if matching else None

    return endpoint_map


def check_vpc_dns_settings(ec2_client, vpc_id: str) -> tuple[bool, bool]:
    """Check if VPC has DNS resolution and DNS hostnames enabled.

    Args:
        ec2_client: boto3 EC2 client
        vpc_id: VPC ID to check

    Returns:
        Tuple of (dns_support_enabled, dns_hostnames_enabled)
    """
    dns_support = ec2_client.describe_vpc_attribute(
        VpcId=vpc_id, Attribute="enableDnsSupport"
    )
    dns_hostnames = ec2_client.describe_vpc_attribute(
        VpcId=vpc_id, Attribute="enableDnsHostnames"
    )
    return (
        dns_support["EnableDnsSupport"]["Value"],
        dns_hostnames["EnableDnsHostnames"]["Value"],
    )


def enable_vpc_dns_settings(ec2_client, vpc_id: str) -> None:
    """Enable DNS resolution and DNS hostnames for VPC.

    Args:
        ec2_client: boto3 EC2 client
        vpc_id: VPC ID to modify
    """
    print("  📡 Enabling DNS resolution and DNS hostnames...")
    try:
        ec2_client.modify_vpc_attribute(VpcId=vpc_id, EnableDnsSupport={"Value": True})
        ec2_client.modify_vpc_attribute(
            VpcId=vpc_id, EnableDnsHostnames={"Value": True}
        )
        print("  ✅ DNS settings enabled successfully")
    except Exception as e:
        print(f"  ⚠️  Warning: Failed to enable DNS settings: {e}")
        print("     Please enable DNS resolution and DNS hostnames manually")


def create_vpc_endpoint(
    ec2_client,
    vpc_id: str,
    service_name: str,
    endpoint_type: str,
    subnet_ids: list[str],
    security_group_ids: list[str],
    max_azs: int | None = None,
) -> str:
    """Create a VPC endpoint.

    Args:
        ec2_client: boto3 EC2 client
        vpc_id: VPC ID
        service_name: AWS service name (e.g., com.amazonaws.us-east-1.s3)
        endpoint_type: 'Interface' or 'Gateway'
        subnet_ids: List of subnet IDs
        security_group_ids: List of security group IDs
        max_azs: Maximum number of availability zones (for gateway endpoint limitation)

    Returns:
        VPC endpoint ID
    """
    # Limit subnets if max_azs is specified
    if max_azs and len(subnet_ids) > max_azs:
        print(
            f"    ⚠️  Limiting to {max_azs} subnets (endpoint supports max {max_azs} AZs)"
        )
        subnet_ids = subnet_ids[:max_azs]

    kwargs = {
        "VpcId": vpc_id,
        "ServiceName": service_name,
        "VpcEndpointType": endpoint_type,
    }

    # Interface endpoints need subnets and security groups
    if endpoint_type == "Interface":
        kwargs["SubnetIds"] = subnet_ids
        kwargs["SecurityGroupIds"] = security_group_ids
        kwargs["PrivateDnsEnabled"] = True

    response = ec2_client.create_vpc_endpoint(**kwargs)
    endpoint_id = response["VpcEndpoint"]["VpcEndpointId"]

    # Wait for endpoint to become available
    print(f"    ⏳ Waiting for endpoint {endpoint_id} to become available...")
    waiter = ec2_client.get_waiter("vpc_endpoint_available")
    try:
        waiter.wait(
            VpcEndpointIds=[endpoint_id], WaiterConfig={"Delay": 5, "MaxAttempts": 60}
        )
        print(f"    ✅ Endpoint {endpoint_id} is now available")
    except Exception as e:
        print(f"    ⚠️  Endpoint created but availability check timed out: {e}")
        print("    Proceeding anyway - endpoint may still be initializing")

    return endpoint_id


def validate_target_url(payload: dict) -> bool:
    """Validate target_url format and warn about domain allowlist limitations.

    Browser Tool uses domain-based allowlists that don't match:
    - Raw IP addresses (e.g., 172.31.24.161)
    - EC2 private DNS without subdomain (e.g., ip-172-31-24-161.ec2.internal)

    Recommended formats:
    - Public DNS names (e.g., ec2-X-X-X-X.compute-1.amazonaws.com)
    - Custom domains with subdomains

    Args:
        payload: Invocation payload containing target_url

    Returns:
        True if user wants to proceed, False to cancel
    """
    import ipaddress
    from urllib.parse import urlparse

    target_url = payload.get("target_url", "")
    if not target_url:
        return True

    # Parse URL to extract hostname
    if not target_url.startswith(("http://", "https://")):
        target_url = "http://" + target_url

    try:
        parsed = urlparse(target_url)
        hostname = parsed.hostname
    except Exception:
        # Invalid URL format, let agent runtime handle it
        return True

    if not hostname:
        return True

    # Check if hostname is an IP address
    is_ip = False
    try:
        ipaddress.ip_address(hostname)
        is_ip = True
    except ValueError:
        pass

    # Only warn for raw IP addresses (EC2 private DNS is now supported)
    if is_ip:
        print("\n" + "=" * 80)
        print("⚠️  WARNING: Target URL Format May Cause Navigation Timeout")
        print("=" * 80)

        print(f"\n🔍 Detected raw IP address: {hostname}")
        print("\n❌ Problem:")
        print("   Browser Tool uses domain-based allowlists (e.g., *.example.com)")
        print("   Raw IP addresses cannot be matched with wildcard patterns")
        print("   Result: Navigation will timeout after 15 seconds")

        print("\n✅ Recommended Solutions:")
        print("\n   1. Use EC2 DNS name (private or public):")
        print("      Get EC2 public DNS:")
        print('      AWS_PAGER="" aws ec2 describe-instances \\')
        print("        --filters Name=private-ip-address,Values=<IP> \\")
        print("        --query 'Reservations[0].Instances[0].PublicDnsName' \\")
        print("        --output text")
        print("\n      Get EC2 private DNS:")
        print('      AWS_PAGER="" aws ec2 describe-instances \\')
        print("        --filters Name=private-ip-address,Values=<IP> \\")
        print("        --query 'Reservations[0].Instances[0].PrivateDnsName' \\")
        print("        --output text")
        print("\n   2. Use custom domain:")
        print("      - Route 53 Private Hosted Zone: chat.internal.example.com")
        print("      - Application Load Balancer: chat.yourdomain.com")

        print(
            "\n📖 For detailed alternatives, see the VPC Configuration section in README.md"
        )
        print("=" * 80)

        proceed = (
            input("\n⚠️  Continue with this URL anyway? (will likely timeout) [y/N]: ")
            .strip()
            .lower()
        )
        return proceed == "y"

    return True


def validate_vpc_connectivity(
    ec2_client, agentcore_sg_id: str, target_url: str, region: str = "us-east-1"
) -> None:
    """Validate and configure VPC connectivity for AgentCore browser to reach target.

    Automatically configures security group ingress rules on target EC2 instances
    to allow traffic from AgentCore browser.

    Args:
        ec2_client: boto3 EC2 client
        agentcore_sg_id: Security group ID used by AgentCore runtime
        target_url: Target URL the browser needs to reach
        region: AWS region (default: us-east-1)
    """
    from urllib.parse import urlparse

    print("\n🔒 Validating VPC Connectivity...")

    # Parse target URL
    if not target_url.startswith(("http://", "https://")):
        target_url = "http://" + target_url

    try:
        parsed = urlparse(target_url)
        hostname = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
    except Exception as e:
        print(f"  ⚠️  Could not parse target URL: {e}")
        return

    # Get AgentCore security group details
    try:
        sg_response = ec2_client.describe_security_groups(GroupIds=[agentcore_sg_id])
        sg = sg_response["SecurityGroups"][0]
        sg_name = sg.get("GroupName", "Unknown")
        vpc_id = sg.get("VpcId")

        print(f"\n  📋 AgentCore Security Group: {agentcore_sg_id} ({sg_name})")
        print(f"  🌐 VPC: {vpc_id}")

        # Check outbound rules
        egress_rules = sg.get("IpPermissionsEgress", [])
        has_all_traffic = False
        has_http = False
        has_https = False

        for rule in egress_rules:
            from_port = rule.get("FromPort")
            to_port = rule.get("ToPort")
            ip_protocol = rule.get("IpProtocol", "")

            # Check for all traffic rule
            if ip_protocol == "-1":
                has_all_traffic = True
                break

            # Check for HTTP/HTTPS
            if from_port and to_port:
                if from_port <= 80 <= to_port:
                    has_http = True
                if from_port <= 443 <= to_port:
                    has_https = True

        if has_all_traffic:
            print("  ✅ Outbound: All traffic allowed")
        elif has_http and has_https:
            print("  ✅ Outbound: HTTP (80) and HTTPS (443) allowed")
        else:
            print("  ⚠️  Outbound: Limited rules (may block browser traffic)")
            print(
                "  💡 Recommendation: Add outbound rule for all traffic or at minimum HTTP/HTTPS"
            )

    except Exception as e:
        print(f"  ⚠️  Could not validate security group: {e}")
        return

    # Find target EC2 instance and configure security group
    print("\n  📡 Target Connectivity Configuration:")
    print(f"  🎯 Target: {hostname}:{port}")

    # Try to find target EC2 instance by private DNS
    target_sg_id = None
    if hostname and hostname.endswith(".ec2.internal"):
        print(f"\n  🔍 Searching for EC2 instance with DNS: {hostname}")
        try:
            instances_response = ec2_client.describe_instances(
                Filters=[
                    {"Name": "private-dns-name", "Values": [hostname]},
                    {"Name": "instance-state-name", "Values": ["running"]},
                ]
            )

            if instances_response["Reservations"]:
                instance = instances_response["Reservations"][0]["Instances"][0]
                instance_id = instance["InstanceId"]
                security_groups = instance.get("SecurityGroups", [])

                if security_groups:
                    target_sg_id = security_groups[0]["GroupId"]
                    target_sg_name = security_groups[0]["GroupName"]
                    print(
                        f"  ✅ Found instance: {instance_id} (SG: {target_sg_id} - {target_sg_name})"
                    )

                    # Check if rule already exists
                    sg_details = ec2_client.describe_security_groups(
                        GroupIds=[target_sg_id]
                    )
                    existing_rules = sg_details["SecurityGroups"][0].get(
                        "IpPermissions", []
                    )

                    rule_exists = False
                    for rule in existing_rules:
                        if rule.get("FromPort") == port and rule.get("ToPort") == port:
                            # Check if source group matches
                            for group_pair in rule.get("UserIdGroupPairs", []):
                                if group_pair.get("GroupId") == agentcore_sg_id:
                                    rule_exists = True
                                    break

                    if rule_exists:
                        print(
                            f"  ✅ Security group rule already exists (port {port} from {agentcore_sg_id})"
                        )
                    else:
                        # Add the security group rule
                        print(
                            f"\n  🔧 Adding security group ingress rule to {target_sg_id}..."
                        )
                        print(f"     Protocol: TCP, Port: {port}")
                        print(f"     Source: {agentcore_sg_id} ({sg_name})")

                        try:
                            ec2_client.authorize_security_group_ingress(
                                GroupId=target_sg_id,
                                IpPermissions=[
                                    {
                                        "IpProtocol": "tcp",
                                        "FromPort": port,
                                        "ToPort": port,
                                        "UserIdGroupPairs": [
                                            {
                                                "GroupId": agentcore_sg_id,
                                                "Description": f"AgentCore browser access to port {port}",
                                            }
                                        ],
                                    }
                                ],
                            )
                            print("  ✅ Security group rule added successfully!")
                        except ec2_client.exceptions.ClientError as e:
                            error_code = e.response.get("Error", {}).get("Code")
                            if error_code == "InvalidPermission.Duplicate":
                                print(
                                    "  ℹ️  Security group rule already exists (detected during add)"
                                )
                            else:
                                print(f"  ⚠️  Failed to add security group rule: {e}")
                                print("\n  💡 Manual command if needed:")
                                print("  aws ec2 authorize-security-group-ingress \\")
                                print(f"    --group-id {target_sg_id} \\")
                                print("    --protocol tcp \\")
                                print(f"    --port {port} \\")
                                print(f"    --source-group {agentcore_sg_id} \\")
                                print(f"    --region {region}")

                else:
                    print("  ⚠️  Instance found but has no security groups")
            else:
                print(f"  ⚠️  No running EC2 instance found with DNS: {hostname}")
                print("\n  💡 If target is not an EC2 instance, manually configure:")
                print(f"     - Ensure target allows inbound TCP port {port}")
                print(f"     - From source: {agentcore_sg_id} ({sg_name})")

        except Exception as e:
            print(f"  ⚠️  Error finding target instance: {e}")
    else:
        # Non-EC2 target (CloudFront, ALB, etc.)
        print("  ℹ️  Target is not an EC2 internal DNS")
        print("  💡 For non-EC2 targets (CloudFront, ALB, API Gateway, etc.):")
        print("     - Ensure target is accessible from within the VPC")
        print("     - Check target's security group/firewall rules if applicable")

    print("\n  📋 Additional Checks:")
    print("  ✓ Verify target is running and accessible from within VPC")
    print("  ✓ Check target application is bound to 0.0.0.0 (not 127.0.0.1)")

    print("\n  ✅ VPC connectivity validation complete")
