"""Internal implementation details for EvalSuite"""
