"""Make arcade_evals tests a package to avoid pytest module name collisions."""
