"""Make sdk tests a package to avoid pytest module name collisions."""
