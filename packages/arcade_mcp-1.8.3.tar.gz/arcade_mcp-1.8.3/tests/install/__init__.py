"""Installation tests for arcade-mcp."""
