from typing import Any, cast

from arcade_microsoft_utils.utils import human_friendly_bytes_size, remove_none_values
from msgraph.generated.models.drive import Drive
from msgraph.generated.models.drive_item import DriveItem
from msgraph.generated.models.identity_set import IdentitySet
from msgraph.generated.models.quota import Quota
from msgraph.generated.models.remote_item import RemoteItem


def serialize_drive(drive: Drive) -> dict[str, Any]:
    """Serialize a OneDrive drive object."""
    data = {
        "object_type": "drive",
        "drive_id": drive.id,
        "name": drive.name,
        "drive_type": drive.drive_type,
        "web_url": drive.web_url,
        "owner": serialize_user_identity_set(drive.owner) if drive.owner else None,
        "quota": serialize_drive_quota(drive.quota) if drive.quota else None,
    }

    return cast(dict[str, Any], remove_none_values(data))


def serialize_drive_item(
    item: DriveItem,
    parent_folder_id: str | None = None,
) -> dict[str, Any]:
    """Serialize a OneDrive drive item object."""
    data: dict[str, Any] = {
        "object_type": "drive_item",
        "item_id": item.id,
        "name": item.name,
    }

    if parent_folder_id:
        data["parent_folder_id"] = parent_folder_id

    if item.size:
        data["size"] = {
            "bytes": item.size,
            "formatted": human_friendly_bytes_size(item.size),
        }

    if item.web_url:
        data["web_url"] = item.web_url

    if item.e_tag:
        data["etag"] = item.e_tag

    if item.file and item.file.mime_type:
        data["item_type"] = "file"
        data["file_id"] = item.id
        data["mime_type"] = item.file.mime_type

    if item.folder:
        data["item_type"] = "folder"
        data["folder_id"] = item.id

    if item.remote_item:
        data["remote_item"] = serialize_remote_item(item.remote_item)

    return cast(dict[str, Any], remove_none_values(data))


def serialize_remote_item(remote_item: RemoteItem) -> dict[str, Any]:
    """Serialize a OneDrive remote item object."""
    data: dict[str, Any] = {
        "_info": "This item is shared from a drive other than the one being accessed",
        "name": remote_item.name,
        "web_url": remote_item.web_url,
        "remote_item_id": remote_item.id,
    }

    parent_reference = remote_item.parent_reference
    if parent_reference:
        data["remote_drive_id"] = parent_reference.drive_id
        data["remote_parent_id"] = parent_reference.id

        if parent_reference.share_id:
            data["share_id"] = parent_reference.share_id

    if remote_item.file and remote_item.file.mime_type:
        data["item_type"] = "file"
        data["mime_type"] = remote_item.file.mime_type

    if remote_item.folder:
        data["item_type"] = "folder"

    if isinstance(remote_item.additional_data, dict):
        access_hint = remote_item.additional_data.get("accessHint")
        if access_hint:
            data["access_hint"] = access_hint

    return cast(dict[str, Any], remove_none_values(data))


def serialize_drive_quota(quota: Quota) -> dict[str, Any] | None:
    """Serialize a OneDrive drive quota object."""
    if not quota or not isinstance(quota.total, int) or not isinstance(quota.used, int):
        return None

    percentage_used = "0%"
    if quota.total > 0:
        percentage_used = f"{round((quota.used / quota.total) * 100, 1)}%"

    return {
        "total": {
            "bytes": quota.total,
            "formatted": human_friendly_bytes_size(quota.total),
        },
        "used": {
            "bytes": quota.used,
            "formatted": human_friendly_bytes_size(quota.used),
            "percentage_used": percentage_used,
        },
    }


def serialize_user_identity_set(identity_set: IdentitySet) -> dict[str, Any] | None:
    """Serialize a Microsoft Graph identity set object."""
    if not identity_set.user:
        return None

    user_data: dict[str, Any] = {}

    if identity_set.user.id:
        user_data["user_id"] = identity_set.user.id

    if identity_set.user.display_name:
        user_data["user_display_name"] = identity_set.user.display_name

    if isinstance(identity_set.user.additional_data, dict):
        user_data.update(identity_set.user.additional_data)

    return user_data
