"""TypedDict models for OneDrive tool responses."""

from typing import Any

from typing_extensions import TypedDict

# Re-export WhoAmIResponse for consistency
from arcade_microsoft_onedrive.who_am_i_util import WhoAmIResponse

__all__ = [
    "WhoAmIResponse",
    "DriveOwner",
    "DriveQuotaSize",
    "DriveQuota",
    "DriveData",
    "GetMyDriveResponse",
    "DriveItemSize",
    "DriveItemRemoteItem",
    "DriveItemData",
    "ListItemsResponse",
    "CreateFolderResponse",
    "DeleteItemResponse",
    "MoveItemResponse",
    "CopyItemResponse",
    "GetCopyStatusResponse",
    "CreateShareLinkResponse",
    "SharedDriveItemData",
]


class DriveOwner(TypedDict, total=False):
    """Owner information for a drive."""

    user_id: str
    user_display_name: str


class DriveQuotaSize(TypedDict, total=False):
    """Quota size information."""

    bytes: int
    formatted: str
    percentage_used: str


class DriveQuota(TypedDict, total=False):
    """Drive quota information."""

    total: DriveQuotaSize
    used: DriveQuotaSize


class DriveData(TypedDict, total=False):
    """Serialized OneDrive drive data."""

    object_type: str
    drive_id: str
    name: str
    drive_type: str
    web_url: str
    owner: DriveOwner
    quota: DriveQuota


class GetMyDriveResponse(TypedDict):
    """Response from the get_my_drive tool."""

    drive: DriveData


class DriveItemSize(TypedDict, total=False):
    """Size information for a drive item."""

    bytes: int
    formatted: str


class DriveItemRemoteItem(TypedDict, total=False):
    """Remote item information for shared items."""

    info: str
    name: str
    web_url: str
    remote_item_id: str
    remote_drive_id: str
    remote_parent_id: str
    share_id: str
    item_type: str
    mime_type: str
    access_hint: str


class DriveItemData(TypedDict, total=False):
    """Serialized OneDrive drive item data."""

    object_type: str
    item_id: str
    name: str
    parent_folder_id: str
    size: DriveItemSize
    web_url: str
    etag: str
    item_type: str
    file_id: str
    folder_id: str
    mime_type: str
    remote_item: DriveItemRemoteItem
    children: list[dict[str, Any]]


class SharedDriveItemData(TypedDict, total=False):
    """Serialized OneDrive shared drive item data (includes remote item fields)."""

    object_type: str
    item_id: str
    name: str
    parent_folder_id: str
    size: DriveItemSize
    web_url: str
    etag: str
    item_type: str
    file_id: str
    folder_id: str
    mime_type: str
    remote_item: DriveItemRemoteItem
    remote_drive_id: str
    remote_item_id: str
    access_hint: str


class ListItemsResponse(TypedDict, total=False):
    """Response from tools that list drive items (list_folder_items, search_items, get_shared_with_me)."""

    items: list[DriveItemData]
    count: int
    next_token: str


class CreateFolderResponse(TypedDict):
    """Response from the create_folder tool."""

    item: DriveItemData
    message: str


class DeleteItemResponse(TypedDict):
    """Response from the delete_item tool."""

    status: str
    message: str


class MoveItemResponse(TypedDict):
    """Response from the move_item tool."""

    item: DriveItemData
    message: str


class CopyItemResponse(TypedDict, total=False):
    """Response from the copy_item tool.

    Returns either a completed item with status='completed' or operation details
    if the copy is still in progress.
    """

    status: str
    item: DriveItemData
    operation_url: str
    message: str


class GetCopyStatusResponse(TypedDict, total=False):
    """Response from the get_copy_status tool."""

    status: str
    item: DriveItemData
    message: str


class ShareLinkData(TypedDict, total=False):
    """Share link data returned by the API."""

    id: str
    roles: list[str]
    shareId: str
    expirationDateTime: str
    hasPassword: bool
    link: dict[str, Any]


class CreateShareLinkResponse(TypedDict, total=False):
    """Response from the create_share_link tool."""

    id: str
    roles: list[str]
    shareId: str
    expirationDateTime: str
    hasPassword: bool
    link: dict[str, Any]
    message: str
