from typing import Annotated, Any, cast
from urllib.parse import urlparse

import httpx
from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.drive_utils import (
    _build_copy_payload,
    _fetch_children,
    _get_copy_status_internal,
    _get_drive_item,
    _get_root_item_id,
    _handle_copy_server_error,
    _maybe_raise_locked_error,
    _normalize_copy_name,
    _poll_copy_operation,
)
from arcade_microsoft_utils.word_utils import _get_graph_base_url
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.drives.item.search_with_q.search_with_q_request_builder import (
    SearchWithQRequestBuilder,
)
from msgraph.generated.drives.item.shared_with_me.shared_with_me_request_builder import (
    SharedWithMeRequestBuilder,
)
from msgraph.generated.models.drive_item import DriveItem
from msgraph.generated.models.folder import Folder
from msgraph.generated.models.item_reference import ItemReference

from arcade_microsoft_onedrive.client import get_client
from arcade_microsoft_onedrive.serializers import serialize_drive, serialize_drive_item
from arcade_microsoft_onedrive.tool_responses import (
    CopyItemResponse,
    CreateFolderResponse,
    CreateShareLinkResponse,
    DeleteItemResponse,
    DriveData,
    DriveItemData,
    GetCopyStatusResponse,
    GetMyDriveResponse,
    ListItemsResponse,
    MoveItemResponse,
)


def _extract_next_token(odata_next_link: str | None) -> str | None:
    if not odata_next_link:
        return None
    parsed = urlparse(odata_next_link)
    if parsed.scheme and parsed.netloc:
        return odata_next_link
    return None


async def _get_drive_id(client: Any) -> str:
    drive = await client.me.drive.get()
    if not drive or not drive.id:
        raise ToolExecutionError("Drive not found for the current user.")
    return cast(str, drive.id)


def _serialize_shared_item(item: DriveItem) -> dict[str, Any]:
    data = serialize_drive_item(item)
    if item.remote_item:
        parent_reference = item.remote_item.parent_reference
        if parent_reference:
            if parent_reference.drive_id:
                data["remote_drive_id"] = parent_reference.drive_id
            if parent_reference.id:
                data["remote_item_id"] = parent_reference.id
        if item.remote_item.id:
            data.setdefault("remote_item_id", item.remote_item.id)
        if isinstance(item.remote_item.additional_data, dict):
            access_hint = item.remote_item.additional_data.get("accessHint")
            if access_hint:
                data["access_hint"] = access_hint
    return data


@tool(requires_auth=Microsoft(scopes=["Files.Read"]))
async def get_my_drive(
    context: Context,
) -> Annotated[GetMyDriveResponse, "The OneDrive drive information."]:
    """Get metadata about the user's OneDrive (id, name, quota, owner)."""
    client = get_client(context.get_auth_token_or_empty())
    drive = await client.me.drive.get()
    if not drive:
        raise ToolExecutionError("Drive not found for the current user.")
    return {"drive": cast(DriveData, serialize_drive(drive))}


@tool(requires_auth=Microsoft(scopes=["Files.Read"]))
async def list_folder_items(
    context: Context,
    folder_id: Annotated[
        str | None,
        "The ID of the folder to list items from. If not provided, lists items from the root.",
    ] = None,
    limit: Annotated[int, "The number of items to list. Defaults to 100, max is 500."] = 100,
    next_token: Annotated[
        str | None,
        "The next_token value returned by a previous request.",
    ] = None,
) -> Annotated[ListItemsResponse, "The items from the specified folder or root."]:
    """List files and folders in a OneDrive folder. Lists root if folder_id is omitted."""
    limit = max(1, min(limit, 500))

    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)

    if folder_id:
        folder_id = folder_id.strip()
        if not folder_id:
            raise ToolExecutionError("folder_id must be a non-empty string if provided.")
        target_folder_id = folder_id
    else:
        target_folder_id = await _get_root_item_id(client, drive_id)
        folder_id = None  # Ensure it's None for serialization

    items, continuation = await _fetch_children(
        client=client,
        drive_id=drive_id,
        folder_id=target_folder_id,
        limit=limit,
        next_token=next_token,
    )
    continuation = _extract_next_token(continuation)

    if not items:
        return {"items": [], "count": 0}

    serialized_items = [
        serialize_drive_item(item=item, parent_folder_id=folder_id) for item in items
    ]

    result: dict[str, Any] = {"items": serialized_items, "count": len(serialized_items)}
    if continuation:
        result["next_token"] = continuation
    return cast(ListItemsResponse, result)


@tool(requires_auth=Microsoft(scopes=["Files.Read"]))
async def search_items(
    context: Context,
    keywords: Annotated[str, "Keywords to search for items in OneDrive."],
    limit: Annotated[int, "The number of items to list. Defaults to 50, max is 200."] = 50,
    next_token: Annotated[
        str | None,
        "The next_token value returned by a previous request.",
    ] = None,
) -> Annotated[ListItemsResponse, "Search results from OneDrive."]:
    """Search for files and folders in the user's OneDrive.

    It may take a few seconds to minutes for the search index to update with newly created items.
    """
    keywords = keywords.strip()
    if not keywords:
        raise ToolExecutionError("keywords is required.")

    limit = max(1, min(limit, 200))
    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)
    search_builder = client.drives.by_drive_id(drive_id).search_with_q(keywords)
    if next_token:
        response = await search_builder.with_url(next_token).get()
    else:
        request_configuration = RequestConfiguration(
            query_parameters=SearchWithQRequestBuilder.SearchWithQRequestBuilderGetQueryParameters(
                top=limit,
            )
        )
        response = await search_builder.get(request_configuration)

    if not response or not response.value:
        return {"items": [], "count": 0}

    items = [serialize_drive_item(item=item) for item in response.value]
    continuation = _extract_next_token(response.odata_next_link)

    result: dict[str, Any] = {"items": items, "count": len(items)}
    if continuation:
        result["next_token"] = continuation
    return cast(ListItemsResponse, result)


@tool(requires_auth=Microsoft(scopes=["Files.Read"]))
async def get_shared_with_me(
    context: Context,
    limit: Annotated[int, "The number of items to list. Defaults to 100, max is 500."] = 100,
    next_token: Annotated[
        str | None,
        "The next_token value returned by a previous request.",
    ] = None,
) -> Annotated[ListItemsResponse, "The items shared with the current user."]:
    """List files shared with the current user."""
    limit = max(1, min(limit, 500))
    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)
    shared_builder = client.drives.by_drive_id(drive_id).shared_with_me
    if next_token:
        response = await shared_builder.with_url(next_token).get()
    else:
        request_configuration = RequestConfiguration(
            query_parameters=SharedWithMeRequestBuilder.SharedWithMeRequestBuilderGetQueryParameters(
                top=limit,
            )
        )
        response = await shared_builder.get(request_configuration)

    if not response or not response.value:
        return {"items": [], "count": 0}

    items = [_serialize_shared_item(item) for item in response.value]
    continuation = _extract_next_token(response.odata_next_link)

    result: dict[str, Any] = {"items": items, "count": len(items)}
    if continuation:
        result["next_token"] = continuation
    return cast(ListItemsResponse, result)


@tool(requires_auth=Microsoft(scopes=["Files.ReadWrite"]))
async def create_folder(
    context: Context,
    folder_name: Annotated[str, "The name of the new folder."],
    parent_folder_id: Annotated[
        str | None, "Optional parent folder ID. If omitted, creates in the root."
    ] = None,
) -> Annotated[CreateFolderResponse, "The created folder metadata."]:
    """Create a new folder in OneDrive."""
    folder_name = folder_name.strip()
    if not folder_name:
        raise ToolExecutionError("folder_name is required.")

    drive_item = DriveItem()
    drive_item.name = folder_name
    drive_item.folder = Folder()

    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)
    if parent_folder_id:
        parent_folder_id = parent_folder_id.strip()
        if not parent_folder_id:
            raise ToolExecutionError("parent_folder_id must be a non-empty string.")
        destination_id = parent_folder_id
    else:
        destination_id = await _get_root_item_id(client, drive_id)

    response = (
        await client.drives.by_drive_id(drive_id)
        .items.by_drive_item_id(destination_id)
        .children.post(drive_item)
    )
    if not response:
        raise ToolExecutionError("Failed to create folder. No DriveItem returned.")
    return {
        "item": cast(
            DriveItemData, serialize_drive_item(response, parent_folder_id=parent_folder_id)
        ),
        "message": "Folder successfully created.",
    }


@tool(requires_auth=Microsoft(scopes=["Files.ReadWrite"]))
async def delete_item(
    context: Context,
    item_id: Annotated[str, "The ID of the file or folder to delete."],
) -> Annotated[DeleteItemResponse, "Deletion confirmation."]:
    """Delete a file or folder from OneDrive."""
    item_id = item_id.strip()
    if not item_id:
        raise ToolExecutionError("item_id is required.")

    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)
    await client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id).delete()
    return {"status": "deleted", "message": "Item successfully deleted."}


@tool(requires_auth=Microsoft(scopes=["Files.ReadWrite"]))
async def move_item(
    context: Context,
    item_id: Annotated[str, "The ID of the item to move."],
    new_parent_id: Annotated[str, "The ID of the destination folder."],
) -> Annotated[MoveItemResponse, "The updated item metadata."]:
    """Move a file or folder to a new location in OneDrive."""
    item_id = item_id.strip()
    new_parent_id = new_parent_id.strip()
    if not item_id:
        raise ToolExecutionError("item_id is required.")
    if not new_parent_id:
        raise ToolExecutionError("new_parent_id is required.")

    drive_item = DriveItem()
    drive_item.parent_reference = ItemReference()
    drive_item.parent_reference.id = new_parent_id

    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)
    try:
        response = (
            await client.drives.by_drive_id(drive_id)
            .items.by_drive_item_id(item_id)
            .patch(drive_item)
        )
    except Exception as exc:
        _maybe_raise_locked_error(exc)
        raise
    if not response:
        raise ToolExecutionError("Failed to move item. No DriveItem returned.")
    return {
        "item": cast(DriveItemData, serialize_drive_item(response, parent_folder_id=new_parent_id)),
        "message": "Item successfully moved.",
    }


@tool(requires_auth=Microsoft(scopes=["Files.ReadWrite"]))
async def copy_item(
    context: Context,
    item_id: Annotated[str, "The ID of the item to copy."],
    destination_folder_id: Annotated[
        str | None,
        "Optional destination folder ID. If omitted, the item is copied to the same folder.",
    ] = None,
    new_name: Annotated[str | None, "Optional new name for the copied item."] = None,
) -> Annotated[CopyItemResponse, "Copy status and result."]:
    """Copy a file or folder. Returns a completed item or an operation id."""
    item_id = item_id.strip()
    if not item_id:
        raise ToolExecutionError("item_id is required.")

    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)
    source_item = await _get_drive_item(client, drive_id, item_id)
    normalized_name = _normalize_copy_name(source_item, new_name)
    payload = _build_copy_payload(destination_folder_id, normalized_name)
    url = f"{_get_graph_base_url()}/drives/{drive_id}/items/{item_id}/copy"
    async with httpx.AsyncClient() as http_client:
        response = await http_client.post(
            url,
            headers={
                "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
                "Content-Type": "application/json",
            },
            json=payload or None,
        )
        if response.status_code >= 500:
            await _handle_copy_server_error(
                client=client,
                drive_id=drive_id,
                source_item=source_item,
                destination_folder_id=destination_folder_id,
                normalized_name=normalized_name,
                response=response,
            )
        if response.status_code not in {202, 200}:
            response.raise_for_status()
        operation_url = response.headers.get("Location") or response.headers.get(
            "Operation-Location"
        )

    if not operation_url:
        raise ToolExecutionError("Copy operation did not return a monitor URL.")

    return cast(
        CopyItemResponse,
        await _poll_copy_operation(
            context=context,
            operation_url=operation_url,
            drive_id=drive_id,
            client=client,
            serialize_item=serialize_drive_item,
        ),
    )


@tool(requires_auth=Microsoft(scopes=["Files.Read"]))
async def get_copy_status(
    context: Context,
    operation_url: Annotated[
        str,
        "The full monitor URL returned by copy_item (Location/Operation-Location header).",
    ],
) -> Annotated[GetCopyStatusResponse, "Copy operation status."]:
    """Check status of an async copy operation using the full monitor URL."""
    operation_url = operation_url.strip()
    if not operation_url:
        raise ToolExecutionError("operation_url is required and must be the full monitor URL.")

    status, resource_id, error_message = await _get_copy_status_internal(context, operation_url)
    response: dict[str, Any] = {"status": status}

    if status == "completed" and resource_id:
        client = get_client(context.get_auth_token_or_empty())
        drive_id = await _get_drive_id(client)
        item = await client.drives.by_drive_id(drive_id).items.by_drive_item_id(resource_id).get()
        response["item"] = serialize_drive_item(item) if item else {"item_id": resource_id}
        response["message"] = "Copy operation completed."
    if status == "failed" and error_message:
        response["message"] = error_message

    return cast(GetCopyStatusResponse, response)


@tool(requires_auth=Microsoft(scopes=["Files.ReadWrite"]))
async def create_share_link(
    context: Context,
    item_id: Annotated[str, "The ID of the file or folder to share."],
) -> Annotated[CreateShareLinkResponse, "Sharing link information."]:
    """Create a share link for a OneDrive item."""
    item_id = item_id.strip()
    if not item_id:
        raise ToolExecutionError("item_id is required.")

    client = get_client(context.get_auth_token_or_empty())
    drive_id = await _get_drive_id(client)
    url = f"{_get_graph_base_url()}/drives/{drive_id}/items/{item_id}/createLink"
    async with httpx.AsyncClient() as http_client:
        response = await http_client.post(
            url,
            headers={
                "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
                "Content-Type": "application/json",
            },
            json={"type": "view", "scope": "anonymous"},
        )
        response.raise_for_status()
    payload = response.json()
    if isinstance(payload, dict):
        payload.setdefault("message", "Share link created.")
        return cast(CreateShareLinkResponse, payload)
    return cast(CreateShareLinkResponse, {"link": payload, "message": "Share link created."})
