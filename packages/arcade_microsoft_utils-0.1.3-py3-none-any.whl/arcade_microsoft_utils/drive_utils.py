import asyncio
import os
from pathlib import Path
from typing import Any, Callable, cast
from urllib.parse import urlparse

import httpx
from arcade_mcp_server import Context
from arcade_mcp_server.exceptions import RetryableToolError, ToolExecutionError
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.drives.item.items.item.children.children_request_builder import (
    ChildrenRequestBuilder,
)
from msgraph.generated.models.drive_item import DriveItem

from arcade_microsoft_utils.exceptions import DocumentLockedError, DownloadSizeLimitExceededError


def _get_max_download_bytes(env_var: str, default_mb: int) -> int:
    """Return the maximum download size in bytes.

    Args:
        env_var: Name of the environment variable that overrides the default.
        default_mb: Default limit in megabytes when the env var is unset or invalid.
    """
    raw = os.environ.get(env_var, "")
    if raw.strip():
        try:
            return int(raw) * 1024 * 1024
        except ValueError:
            pass
    return default_mb * 1024 * 1024


def _ensure_download_size_under_limit(
    item: DriveItem,
    env_var: str,
    default_mb: int,
) -> None:
    """Check the drive item's reported size against a configurable download limit.

    Args:
        item: The DriveItem whose size to check.
        env_var: Environment variable name that overrides the default limit.
        default_mb: Default limit in megabytes.

    Raises:
        DownloadSizeLimitExceededError: If the file exceeds the limit.
    """
    file_size = item.size
    if file_size is None:
        return  # size unknown — proceed optimistically
    max_bytes = _get_max_download_bytes(env_var, default_mb)
    if file_size > max_bytes:
        raise DownloadSizeLimitExceededError(
            file_size_mb=file_size / (1024 * 1024),
            limit_mb=max_bytes / (1024 * 1024),
            env_var=env_var,
        )


def _maybe_raise_locked_error(exc: Exception) -> None:
    error_code = None
    message = None

    error_obj = getattr(exc, "error", None)
    if error_obj is not None:
        if isinstance(error_obj, dict):
            error_code = error_obj.get("code")
            message = error_obj.get("message")
        else:
            error_code = getattr(error_obj, "code", None)
            message = getattr(error_obj, "message", None)

    if not message:
        message = str(exc)

    message_lower = message.lower()
    if (error_code == "notAllowed" and "locked" in message_lower) or (
        "resource you are attempting to access is locked" in message_lower
    ):
        raise DocumentLockedError() from exc


def _normalize_next_link(odata_next_link: str | None) -> str | None:
    if not odata_next_link:
        return None
    parsed = urlparse(odata_next_link)
    if parsed.scheme and parsed.netloc:
        return odata_next_link
    return None


async def _get_root_item_id(client: Any, drive_id: str) -> str:
    root_item = await client.drives.by_drive_id(drive_id).root.get()
    if not root_item or not root_item.id:
        raise ToolExecutionError("Root folder not found for the current drive.")
    return cast(str, root_item.id)


async def _get_drive_item(client: Any, drive_id: str, item_id: str) -> DriveItem:
    item = await client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id).get()
    if not item:
        raise ToolExecutionError("Item not found. Verify the item_id.")
    return cast(DriveItem, item)


def _has_extension(name: str) -> bool:
    suffix = Path(name).suffix
    return bool(suffix and suffix != ".")


def _normalize_copy_name(item: DriveItem, new_name: str | None) -> str | None:
    if new_name is None or _has_extension(new_name):
        return new_name

    if not item.name:
        return new_name

    original_suffix = Path(item.name).suffix
    if not original_suffix or original_suffix == ".":
        return new_name

    return f"{new_name}{original_suffix}"


def _build_copy_payload(destination_folder_id: str | None, new_name: str | None) -> dict[str, Any]:
    payload: dict[str, Any] = {}

    if destination_folder_id is not None:
        normalized_destination = destination_folder_id.strip()
        if not normalized_destination:
            raise ToolExecutionError("destination_folder_id must be a non-empty string.")
        payload["parentReference"] = {"id": normalized_destination}

    if new_name is not None:
        normalized_name = new_name.strip()
        if not normalized_name:
            raise ToolExecutionError("new_name must be a non-empty string.")
        payload["name"] = normalized_name

    return payload


async def _fetch_children(
    client: Any,
    drive_id: str,
    folder_id: str,
    limit: int,
    next_token: str | None = None,
) -> tuple[list[DriveItem], str | None]:
    children_builder = (
        client.drives.by_drive_id(drive_id).items.by_drive_item_id(folder_id).children
    )

    if next_token:
        response = await children_builder.with_url(next_token).get()
    else:
        request_configuration = RequestConfiguration(
            query_parameters=ChildrenRequestBuilder.ChildrenRequestBuilderGetQueryParameters(
                top=limit,
            )
        )
        response = await children_builder.get(request_configuration)

    if not response or not response.value:
        return [], None

    return response.value, _normalize_next_link(response.odata_next_link)


async def _name_exists_in_folder(
    client: Any,
    drive_id: str,
    folder_id: str,
    name: str,
    max_items: int = 1000,
) -> bool:
    remaining = max_items
    next_token: str | None = None
    while remaining > 0:
        page_limit = min(200, remaining)
        items, next_token = await _fetch_children(
            client=client,
            drive_id=drive_id,
            folder_id=folder_id,
            limit=page_limit,
            next_token=next_token,
        )
        if not items:
            return False
        for item in items:
            if item.name and item.name == name:
                return True
            remaining -= 1
            if remaining <= 0:
                break
        if not next_token:
            return False
    return False


def _resolve_destination_folder_id(
    source_item: DriveItem, fallback_root_id: str, destination_folder_id: str | None
) -> str:
    if destination_folder_id:
        return destination_folder_id
    parent_reference = source_item.parent_reference
    if parent_reference and parent_reference.id:
        return parent_reference.id
    return fallback_root_id


async def _handle_copy_server_error(
    client: Any,
    drive_id: str,
    source_item: DriveItem,
    destination_folder_id: str | None,
    normalized_name: str | None,
    response: httpx.Response,
) -> None:
    root_id = await _get_root_item_id(client, drive_id)
    destination_id = _resolve_destination_folder_id(
        source_item=source_item,
        fallback_root_id=root_id,
        destination_folder_id=destination_folder_id,
    )
    conflict_name = normalized_name or source_item.name
    if conflict_name and await _name_exists_in_folder(
        client, drive_id, destination_id, conflict_name
    ):
        message = (
            f"A file named '{conflict_name}' already exists in the destination folder. "
            "Provide a different new_name or destination_folder_id."
        )
        raise ToolExecutionError(message)

    message = "Microsoft Graph error: general exception while processing."
    error_body = response.text.strip()
    if error_body:
        message = f"{message} Details: {error_body}"
    raise RetryableToolError(
        message=message,
        developer_message=f"Status: {response.status_code}. Body: {response.text}",
    )


async def _get_copy_status_internal(
    context: Context, operation_url: str
) -> tuple[str, str | None, str | None]:
    parsed = urlparse(operation_url)
    include_auth_header = "tempauth=" not in parsed.query
    if include_auth_header:
        headers = {"Authorization": f"Bearer {context.get_auth_token_or_empty()}"}
    else:
        headers = None

    async with httpx.AsyncClient(follow_redirects=True) as http_client:
        response = await http_client.get(operation_url, headers=headers)
        if response.status_code == 202:
            return "in_progress", None, None
        response.raise_for_status()

    payload = response.json()
    status = payload.get("status")
    if status == "completed":
        return "completed", payload.get("resourceId"), None
    if status == "failed":
        return "failed", None, payload.get("error", {}).get("message")
    return "in_progress", None, None


async def _poll_copy_operation(
    context: Context,
    operation_url: str,
    drive_id: str,
    client: Any,
    serialize_item: Callable[[DriveItem], dict[str, Any]],
) -> dict[str, Any]:
    for _ in range(5):
        status, resource_id, error_message = await _get_copy_status_internal(context, operation_url)
        if status == "completed" and resource_id:
            item = (
                await client.drives.by_drive_id(drive_id).items.by_drive_item_id(resource_id).get()
            )
            if not item:
                return {
                    "status": "completed",
                    "item_id": resource_id,
                    "message": "Item successfully copied.",
                }
            return {
                "status": "completed",
                "item": serialize_item(item),
                "message": "Item successfully copied.",
            }
        if status == "failed":
            return {
                "status": "failed",
                "operation_url": operation_url,
                "message": error_message or "Copy operation failed.",
            }
        await asyncio.sleep(2)

    return {
        "status": "in_progress",
        "operation_url": operation_url,
        "message": "Copy operation still in progress. Use get_copy_status to check later.",
    }
