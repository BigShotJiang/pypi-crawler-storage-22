from arcade_microsoft_utils.client import get_client
from arcade_microsoft_utils.exceptions import (
    ConflictError,
    ConversionError,
    DocumentLockedError,
    DownloadSizeLimitExceededError,
    MicrosoftNonRetryableError,
    MicrosoftToolExecutionError,
    PresentationConversionError,
    SizeLimitExceededError,
    UnsupportedFileTypeError,
    UnsupportedPresentationTypeError,
)

__all__ = [
    "get_client",
    "MicrosoftNonRetryableError",
    "MicrosoftToolExecutionError",
    "UnsupportedFileTypeError",
    "SizeLimitExceededError",
    "ConflictError",
    "ConversionError",
    "DocumentLockedError",
    "UnsupportedPresentationTypeError",
    "PresentationConversionError",
    "DownloadSizeLimitExceededError",
]
