from arcade_mcp_server.exceptions import ToolExecutionError


class MicrosoftToolExecutionError(ToolExecutionError):
    """Base error for Microsoft toolkit failures."""


class MicrosoftNonRetryableError(MicrosoftToolExecutionError):
    """Non-retryable error for Microsoft toolkit failures."""


class UnsupportedFileTypeError(MicrosoftToolExecutionError):
    """Raised when a file is not a supported type."""

    def __init__(self, file_type: str) -> None:
        message = f"Only .docx files are supported. Received: {file_type}."
        super().__init__(message=message, developer_message=message)


class SizeLimitExceededError(MicrosoftToolExecutionError):
    """Raised when an upload exceeds size limits."""

    def __init__(self) -> None:
        message = "The resulting document exceeds the 4MB upload limit. Reduce content and retry."
        super().__init__(message=message, developer_message=message)


class ConflictError(MicrosoftToolExecutionError):
    """Raised when optimistic concurrency detects a conflict."""

    def __init__(self) -> None:
        message = "The document changed since it was downloaded. Re-fetch and retry your update."
        super().__init__(message=message, developer_message=message)


class ConversionError(MicrosoftToolExecutionError):
    """Raised when a document cannot be converted."""

    def __init__(self) -> None:
        message = "Unable to convert the document. Try downloading the file directly."
        super().__init__(message=message, developer_message=message)


class DocumentLockedError(MicrosoftToolExecutionError):
    """Raised when a document is locked for editing."""

    def __init__(self) -> None:
        message = "The document is locked because it is open for editing. Close it and retry."
        super().__init__(message=message, developer_message=message)


class UnsupportedPresentationTypeError(MicrosoftNonRetryableError):
    """Raised when a file is not a PowerPoint presentation."""

    def __init__(self, file_type: str) -> None:
        message = f"Only .pptx files are supported. Received: {file_type}."
        super().__init__(message=message, developer_message=message)


class PresentationConversionError(MicrosoftNonRetryableError):
    """Raised when a presentation cannot be converted to markdown."""

    def __init__(self) -> None:
        message = "Unable to convert the presentation. Try downloading the file directly."
        super().__init__(message=message, developer_message=message)


class DownloadSizeLimitExceededError(MicrosoftNonRetryableError):
    """Raised when a file exceeds the configured download size limit."""

    def __init__(self, file_size_mb: float, limit_mb: float, env_var: str) -> None:
        message = (
            f"The file is {file_size_mb:.1f} MB, which exceeds the "
            f"{limit_mb:.0f} MB download limit. Files this large cannot be read or "
            f"edited through this tool. You can adjust the limit with the "
            f"{env_var} environment variable."
        )
        super().__init__(message=message, developer_message=message)
