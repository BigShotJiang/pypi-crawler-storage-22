from typing import Any, cast

from arcade_microsoft_utils.utils import human_friendly_bytes_size, remove_none_values
from msgraph.generated.models.drive_item import DriveItem

from arcade_microsoft_word.tool_responses import DriveItemData


def serialize_drive_item(item: DriveItem, drive_id: str | None = None) -> DriveItemData:
    """Serialize a OneDrive DriveItem into a friendly dictionary."""
    data: dict[str, Any] = {
        "object_type": "drive_item",
        "item_id": item.id,
        "name": item.name,
    }

    if drive_id:
        data["parent_drive_id"] = drive_id

    if item.size:
        data["size"] = {
            "bytes": item.size,
            "formatted": human_friendly_bytes_size(item.size),
        }

    if item.web_url:
        data["web_url"] = item.web_url

    if item.file and item.file.mime_type:
        data["mime_type"] = item.file.mime_type

    if item.e_tag:
        data["etag"] = item.e_tag

    return cast(DriveItemData, remove_none_values(data))
