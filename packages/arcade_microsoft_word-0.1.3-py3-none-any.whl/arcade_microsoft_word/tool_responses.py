"""TypedDict models for Microsoft Word tool responses."""

from typing_extensions import TypedDict

# Re-export WhoAmIResponse for consistency
from arcade_microsoft_word.who_am_i_util import WhoAmIResponse

__all__ = [
    "WhoAmIResponse",
    "DriveItemSize",
    "DriveItemData",
    "DocumentMetadataResponse",
    "GetDocumentResponse",
]


class DriveItemSize(TypedDict, total=False):
    """Size information for a drive item."""

    bytes: int
    formatted: str


class DriveItemData(TypedDict, total=False):
    """Serialized Word document DriveItem data."""

    object_type: str
    item_id: str
    name: str
    parent_drive_id: str
    size: DriveItemSize
    web_url: str
    mime_type: str
    etag: str


class DocumentMetadataResponse(TypedDict):
    """Response from tools that return Word document metadata (create_document, insert_text_at_end)."""

    item: DriveItemData


class GetDocumentResponse(DocumentMetadataResponse, total=False):
    """Response from the get_document tool. Always includes item metadata; content and content_format are included only when metadata_only is False."""

    content: str
    content_format: str
