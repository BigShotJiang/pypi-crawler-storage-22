from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.word_utils import (
    _build_docx_bytes,
    _build_upload_url,
    _ensure_payload_under_limit,
    _ensure_text_content,
    _get_drive_item,
    _get_user_display_name,
    _normalize_docx_title,
    _require_non_empty,
    _upload_drive_item_content,
)

from arcade_microsoft_word.serializers import serialize_drive_item
from arcade_microsoft_word.tool_responses import DocumentMetadataResponse


# Uses https://learn.microsoft.com/en-us/graph/api/driveitem-put-content
@tool(requires_auth=Microsoft(scopes=["Files.ReadWrite"]))
async def create_document(
    context: Context,
    title: Annotated[
        str, "File name without extension, or with .docx. The .docx extension is normalized."
    ],
    text_content: Annotated[
        str | None,
        "Optional text content to include in the new document. "
        "If omitted, an empty document is created.",
    ] = None,
    folder_id: Annotated[
        str | None,
        "Optional parent folder ID. If omitted, the document is created in the root.",
    ] = None,
    conflict_behavior: Annotated[
        str | None,
        "Optional conflict behavior when a file with the same name exists. "
        "One of: fail, rename, replace.",
    ] = None,
) -> Annotated[DocumentMetadataResponse, "The created Word document metadata."]:
    """Create a new Word document in OneDrive (4MB upload limit). Optionally include text content."""
    title = _normalize_docx_title(title)

    if text_content is not None:
        _ensure_text_content(text_content)

    if folder_id is not None:
        folder_id = _require_non_empty(folder_id, "folder_id")

    author_name = await _get_user_display_name(context)
    doc_bytes = _build_docx_bytes(text_content=text_content, author_name=author_name)
    _ensure_payload_under_limit(doc_bytes)

    url = _build_upload_url(title=title, folder_id=folder_id, conflict_behavior=conflict_behavior)
    response = await _upload_drive_item_content(context, url, doc_bytes)
    item_id = response.get("id")
    if not item_id:
        raise ToolExecutionError("Failed to create document. No DriveItem ID returned.")

    item = await _get_drive_item(context, item_id=item_id)
    return {"item": serialize_drive_item(item=item)}
