from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_microsoft_utils.word_utils import (
    _convert_docx_bytes,
    _download_drive_item_content,
    _ensure_docx_drive_item,
    _ensure_download_size_under_limit,
    _get_drive_item,
    _require_non_empty,
)

from arcade_microsoft_word.serializers import serialize_drive_item
from arcade_microsoft_word.tool_responses import GetDocumentResponse


# Uses https://learn.microsoft.com/en-us/graph/api/driveitem-get
# Uses https://learn.microsoft.com/en-us/graph/api/driveitem-get-content
@tool(requires_auth=Microsoft(scopes=["Files.Read"]))
async def get_document(
    context: Context,
    item_id: Annotated[str, "The ID of the Word document to retrieve."],
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default drive.",
    ] = None,
    metadata_only: Annotated[
        bool,
        "If True, return only the document metadata without downloading the content. "
        "Defaults to False.",
    ] = False,
) -> Annotated[GetDocumentResponse, "The Word document metadata and optionally its content."]:
    """Get a Word document's metadata and content (supports only `.docx`). Returns the document content as Markdown by default, or just metadata when metadata_only is True."""
    item_id = _require_non_empty(item_id, "item_id")
    if drive_id is not None:
        drive_id = _require_non_empty(drive_id, "drive_id")

    item = await _get_drive_item(context, item_id=item_id, drive_id=drive_id)
    _ensure_docx_drive_item(item)

    result: GetDocumentResponse = {"item": serialize_drive_item(item=item, drive_id=drive_id)}

    if not metadata_only:
        _ensure_download_size_under_limit(item)
        doc_bytes = await _download_drive_item_content(context, item_id=item_id, drive_id=drive_id)
        content, content_format = _convert_docx_bytes(doc_bytes)
        result["content"] = content
        result["content_format"] = content_format

    return result
