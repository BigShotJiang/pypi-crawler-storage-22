from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft

from arcade_microsoft_word.client import get_client
from arcade_microsoft_word.who_am_i_util import WhoAmIResponse, build_who_am_i_response


@tool(requires_auth=Microsoft(scopes=["User.Read"]))
async def who_am_i(
    context: Context,
) -> Annotated[
    WhoAmIResponse,
    "Get comprehensive user profile and Microsoft Word environment information.",
]:
    """
    Get information about the current user and their Microsoft Word environment.
    """
    client = get_client(context.get_auth_token_or_empty())
    return await build_who_am_i_response(client)
