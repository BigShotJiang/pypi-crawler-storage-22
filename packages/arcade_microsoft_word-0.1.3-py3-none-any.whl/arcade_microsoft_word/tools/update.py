from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.word_utils import (
    _append_text_to_docx,
    _build_item_url,
    _download_drive_item_content,
    _ensure_docx_drive_item,
    _ensure_download_size_under_limit,
    _ensure_payload_under_limit,
    _ensure_text_content,
    _get_drive_item,
    _get_user_display_name,
    _require_non_empty,
    _upload_drive_item_content,
)

from arcade_microsoft_word.serializers import serialize_drive_item
from arcade_microsoft_word.tool_responses import DocumentMetadataResponse


# Uses https://learn.microsoft.com/en-us/graph/api/driveitem-put-content
@tool(requires_auth=Microsoft(scopes=["Files.ReadWrite"]))
async def insert_text_at_end(
    context: Context,
    item_id: Annotated[str, "The ID of the Word document to update."],
    text_content: Annotated[str, "The text content to append to the document."],
    drive_id: Annotated[
        str | None,
        "Optional drive ID for shared items. If omitted, uses the user's default drive.",
    ] = None,
) -> Annotated[DocumentMetadataResponse, "The updated Word document metadata."]:
    """Append text to the end of a Word document (supports only `.docx`, 4MB limit)."""
    item_id = _require_non_empty(item_id, "item_id")
    _ensure_text_content(text_content)
    if drive_id is not None:
        drive_id = _require_non_empty(drive_id, "drive_id")

    item = await _get_drive_item(context, item_id=item_id, drive_id=drive_id)
    _ensure_docx_drive_item(item)
    _ensure_download_size_under_limit(item)

    etag = getattr(item, "e_tag", None)
    if not etag:
        raise ToolExecutionError(
            "Unable to determine document version. Re-fetch and retry your update."
        )

    author_name = await _get_user_display_name(context)
    doc_bytes = await _download_drive_item_content(context, item_id=item_id, drive_id=drive_id)
    updated_doc_bytes = _append_text_to_docx(doc_bytes, text_content, author_name=author_name)
    _ensure_payload_under_limit(updated_doc_bytes)

    url = f"{_build_item_url(item_id=item_id, drive_id=drive_id)}/content"
    response = await _upload_drive_item_content(context, url, updated_doc_bytes, etag=etag)
    updated_item_id = response.get("id", item_id)

    updated_item = await _get_drive_item(context, item_id=updated_item_id, drive_id=drive_id)
    return {"item": serialize_drive_item(item=updated_item, drive_id=drive_id)}
