"""Toast POS API Tools

This module provides Python tool implementations for interacting with the Toast POS API.
Authentication is handled automatically - users only need to configure TOAST_CLIENT_ID
and TOAST_CLIENT_SECRET. Bearer tokens are fetched fresh for each request.
"""

from typing import Annotated, Any

import httpx
from arcade_tdk import ToolContext, tool

__all__ = [
    "get_order",
    "get_orders_bulk",
    "create_order",
    "void_order",
    "get_applicable_discounts",
    "get_prep_stations",
    "get_prep_station",
    "get_menus",
    "get_menu_metadata",
    "get_restaurant_info",
    "get_restaurants_in_group",
    "get_employees",
    "get_employee",
    "get_shifts",
    "get_jobs",
    "get_time_entries",
    "get_inventory",
    "update_inventory",
    "get_online_ordering_availability",
    "get_cash_entries",
    "get_cash_deposits",
]


def remove_none_values(data: dict[str, Any]) -> dict[str, Any]:
    """Remove None values from a dictionary."""
    return {k: v for k, v in data.items() if v is not None}


# Base URL for Toast API
TOAST_API_BASE = "https://ws-api.toasttab.com"

# Required secrets for all tools
TOAST_AUTH_SECRETS = ["TOAST_CLIENT_ID", "TOAST_CLIENT_SECRET"]


# ============================================================================
# Internal Authentication Helper
# ============================================================================


async def _get_bearer_token(client_id: str, client_secret: str) -> str:
    """Fetch a bearer token from Toast API using client credentials.
    
    This is an internal helper function that handles authentication
    automatically for all tools. Tokens are fetched fresh for each request
    to avoid expiration issues.
    
    Args:
        client_id: The Toast API client identifier
        client_secret: The Toast API client secret
        
    Returns:
        The bearer token string for API authorization
        
    Raises:
        httpx.HTTPStatusError: If authentication fails
    """
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url=f"{TOAST_API_BASE}/authentication/v1/authentication/login",
            headers={"Content-Type": "application/json"},
            json={
                "clientId": client_id,
                "clientSecret": client_secret,
                "userAccessType": "TOAST_MACHINE_CLIENT",
            },
        )
        response.raise_for_status()
        data = response.json()
        return data["token"]["accessToken"]


# ============================================================================
# Orders API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_order(
    context: ToolContext,
    order_guid: Annotated[str, "The unique Toast platform identifier (GUID) for the order."],
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Order details including checks, items, and payments."]:
    """Retrieve detailed information about a single order from Toast POS.

    Returns comprehensive order data including checks, items, payments,
    and other order details for a specific order identified by its GUID.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/orders/v2/orders/{order_guid}",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_orders_bulk(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    business_date: Annotated[str | None, "Business date in YYYYMMDD format."] = None,
    start_date: Annotated[str | None, "Start of date/time range in ISO 8601 format."] = None,
    end_date: Annotated[str | None, "End of date/time range in ISO 8601 format."] = None,
    page_token: Annotated[str | None, "Pagination token from previous response."] = None,
    page_size: Annotated[int | None, "Number of orders per page (max 100)."] = None,
) -> Annotated[dict[str, Any], "Array of orders matching the filter criteria."]:
    """Retrieve multiple orders from Toast POS in bulk.

    Returns an array of orders based on filter criteria such as business date,
    time range, or modification date. Useful for syncing order data or generating reports.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/orders/v2/ordersBulk",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params=remove_none_values({
                "businessDate": business_date,
                "startDate": start_date,
                "endDate": end_date,
                "pageToken": page_token,
                "pageSize": page_size,
            }),
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def create_order(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    order_data: Annotated[dict[str, Any], "Order data including checks, entityType, and other properties."],
) -> Annotated[dict[str, Any], "The created order with assigned GUIDs."]:
    """Create a new order in Toast POS.

    Submits a new order to the Toast platform. The order can include checks,
    menu items, modifiers, and other order details.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url=f"{TOAST_API_BASE}/orders/v2/orders",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
                "Content-Type": "application/json",
            },
            json=order_data,
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def void_order(
    context: ToolContext,
    order_guid: Annotated[str, "The unique Toast platform identifier (GUID) for the order to void."],
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Confirmation of the void operation."]:
    """Void an existing order in Toast POS.

    Marks an order as voided, which cancels the order and removes it from active operations.
    The order record is retained for reporting purposes.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url=f"{TOAST_API_BASE}/orders/v2/orders/{order_guid}/void",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_applicable_discounts(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    discount_request: Annotated[dict[str, Any], "Order context for determining applicable discounts."],
) -> Annotated[dict[str, Any], "List of applicable discounts."]:
    """Retrieve discounts that can be applied to an order.

    Returns a list of discounts that are eligible to be applied to a given order
    or check based on the current order state and restaurant configuration.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url=f"{TOAST_API_BASE}/orders/v2/applicableDiscounts",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
                "Content-Type": "application/json",
            },
            json=discount_request,
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


# ============================================================================
# Kitchen API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_prep_stations(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    page_token: Annotated[str | None, "Pagination token from previous response."] = None,
    last_modified: Annotated[str | None, "Filter by modification date (ISO 8601)."] = None,
) -> Annotated[dict[str, Any], "Array of prep station configurations."]:
    """Retrieve all prep stations configured for a restaurant.

    Returns the configuration for every prep station (kitchen printer or KDS device location)
    that has been created for the specified restaurant.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/kitchen/v1/published/prepStations",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params=remove_none_values({
                "pageToken": page_token,
                "lastModified": last_modified,
            }),
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_prep_station(
    context: ToolContext,
    prep_station_guid: Annotated[str, "The unique Toast platform identifier (GUID) for the prep station."],
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Prep station configuration details."]:
    """Retrieve configuration for a single prep station.

    Returns detailed configuration for a specific prep station (kitchen printer
    or KDS device location) identified by its GUID.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/kitchen/v1/published/prepStations/{prep_station_guid}",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


# ============================================================================
# Menus V3 API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_menus(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    last_modified: Annotated[str | None, "Return only menus modified after this timestamp."] = None,
) -> Annotated[dict[str, Any], "Array of menus with groups, items, and pricing."]:
    """Retrieve all menus for a restaurant.

    Returns a fully resolved set of menus for the specified restaurant location,
    including menu groups, menu items, modifiers, and pricing information.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/menus/v3/menus",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params=remove_none_values({
                "lastModified": last_modified,
            }),
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_menu_metadata(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Menu metadata including last modified timestamp."]:
    """Retrieve the last modified timestamp for restaurant menus.

    Returns metadata about when the menus were last updated. Useful for determining
    if menu data needs to be refreshed without fetching the full menu payload.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/menus/v3/metadata",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


# ============================================================================
# Restaurants API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_restaurant_info(
    context: ToolContext,
    restaurant_guid: Annotated[str, "The Toast GUID of the restaurant."],
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    include_archived: Annotated[bool | None, "Include archived restaurants."] = None,
) -> Annotated[dict[str, Any], "Restaurant configuration details."]:
    """Retrieve detailed configuration information for a restaurant.

    Returns comprehensive restaurant data including name, location, hours, schedules,
    delivery settings, online ordering configuration, and prep times.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/restaurants/v1/restaurants/{restaurant_guid}",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params=remove_none_values({
                "includeArchived": include_archived,
            }),
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_restaurants_in_group(
    context: ToolContext,
    management_group_guid: Annotated[str, "The GUID of the restaurant management group."],
    restaurant_external_id: Annotated[str, "The Toast GUID of one restaurant in the management group."],
) -> Annotated[dict[str, Any], "Array of restaurants in the management group."]:
    """Retrieve all restaurants in a management group.

    Returns an array of restaurant identifiers for all restaurants that belong
    to a specified restaurant management group.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/restaurants/v1/groups/{management_group_guid}/restaurants",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


# ============================================================================
# Labor API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_employees(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Array of employees at the restaurant."]:
    """Retrieve all employees for a restaurant.

    Returns a list of all employees configured at the restaurant, including their
    basic information, job assignments, and wage settings.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/labor/v1/employees",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_employee(
    context: ToolContext,
    employee_id: Annotated[str, "The unique Toast identifier for the employee."],
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Employee details including job assignments and wages."]:
    """Retrieve detailed information about a single employee.

    Returns comprehensive details about a specific employee including their
    personal information, job assignments, and wage configurations.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/labor/v1/employees/{employee_id}",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_shifts(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    start_date: Annotated[str | None, "Filter shifts starting on or after this date (YYYY-MM-DD)."] = None,
    end_date: Annotated[str | None, "Filter shifts ending on or before this date (YYYY-MM-DD)."] = None,
) -> Annotated[dict[str, Any], "Array of scheduled shifts."]:
    """Retrieve scheduled shifts for a restaurant.

    Returns shift data for employees at the restaurant, filtered by date range.
    Useful for scheduling and labor management.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/labor/v1/shifts",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params=remove_none_values({
                "startDate": start_date,
                "endDate": end_date,
            }),
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_jobs(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Array of job types at the restaurant."]:
    """Retrieve all job types configured for a restaurant.

    Returns a list of job roles defined for the restaurant, such as Server, Cook, Manager, etc.
    These jobs are used to define employee positions and wages.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/labor/v1/jobs",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_time_entries(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    start_date: Annotated[str | None, "Filter entries starting on or after this date (YYYY-MM-DD)."] = None,
    end_date: Annotated[str | None, "Filter entries ending on or before this date (YYYY-MM-DD)."] = None,
) -> Annotated[dict[str, Any], "Array of time entries (clock-in/clock-out records)."]:
    """Retrieve time entries (clock-in/clock-out records) for a restaurant.

    Returns time tracking records for employees, useful for payroll processing
    and labor cost analysis.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/labor/v1/timeEntries",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params=remove_none_values({
                "startDate": start_date,
                "endDate": end_date,
            }),
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


# ============================================================================
# Stock API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_inventory(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    status: Annotated[str | None, "Filter by status: IN_STOCK, OUT_OF_STOCK, or QUANTITY."] = None,
) -> Annotated[dict[str, Any], "Array of inventory items with stock status."]:
    """Retrieve inventory status for menu items at a restaurant.

    Returns the current inventory status for menu items, including quantity on hand
    and whether items are marked as out of stock.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/stock/v1/inventory",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params=remove_none_values({
                "status": status,
            }),
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def update_inventory(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    inventory_updates: Annotated[list[dict[str, Any]], "Array of inventory update objects with menuItemGuid and status."],
) -> Annotated[dict[str, Any], "Confirmation of the inventory update."]:
    """Update inventory status for menu items at a restaurant.

    Allows you to update the stock status or quantity for one or more menu items.
    Useful for marking items as out of stock or adjusting quantity levels.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.put(
            url=f"{TOAST_API_BASE}/stock/v1/inventory/update",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
                "Content-Type": "application/json",
            },
            json=inventory_updates,
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


# ============================================================================
# Restaurant Availability API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_online_ordering_availability(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
) -> Annotated[dict[str, Any], "Online ordering availability status and schedule."]:
    """Retrieve online ordering availability for a restaurant.

    Returns information about whether a restaurant is currently accepting online orders,
    including hours and any temporary closures or busy periods.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/restaurant-availability/v1/availability",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


# ============================================================================
# Cash Management API
# ============================================================================


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_cash_entries(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    business_date: Annotated[str, "The business date in YYYYMMDD format (e.g., 20240115)."],
) -> Annotated[dict[str, Any], "Array of cash entry records for the specified date."]:
    """Retrieve cash entries for a restaurant on a specific business date.

    Returns information about cash added to or removed from cash drawers,
    including cash-in, cash-out, pay-outs, tip-outs, no-sale events, and
    drawer close-out records. Each entry includes the amount, reason,
    type, and associated employees.

    Cash entry types include:
    - CASH_IN: Cash added to drawer
    - CASH_OUT: Cash removed and stored elsewhere
    - PAY_OUT: Cash removed for restaurant expenses
    - TIP_OUT: Cash removed to distribute tips
    - NO_SALE: Drawer opened with no cash change
    - CLOSE_OUT_EXACT/OVERAGE/SHORTAGE: Drawer closing records
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/cashmgmt/v1/entries",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params={"businessDate": business_date},
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}


@tool(requires_secrets=TOAST_AUTH_SECRETS)
async def get_cash_deposits(
    context: ToolContext,
    restaurant_external_id: Annotated[str, "The Toast platform GUID for the restaurant."],
    business_date: Annotated[str, "The business date in YYYYMMDD format (e.g., 20240115)."],
) -> Annotated[dict[str, Any], "Array of deposit records for the specified date."]:
    """Retrieve cash deposits for a restaurant on a specific business date.

    Returns information about cash removed from the restaurant to be
    deposited at a bank or other financial institution. Each deposit
    record includes the amount, date, and the employee who created it.
    """
    token = await _get_bearer_token(
        context.get_secret("TOAST_CLIENT_ID"),
        context.get_secret("TOAST_CLIENT_SECRET"),
    )
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url=f"{TOAST_API_BASE}/cashmgmt/v1/deposits",
            headers={
                "Authorization": f"Bearer {token}",
                "Toast-Restaurant-External-ID": restaurant_external_id,
            },
            params={"businessDate": business_date},
        )
        response.raise_for_status()
        try:
            return {"response_json": response.json()}
        except Exception:
            return {"response_text": response.text}
