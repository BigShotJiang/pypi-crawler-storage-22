# arcana_sdk (reserved)

This package name is reserved by Arcana.

Do **not** install from TestPyPI/PyPI.

Install from Arcana's package index, e.g.:

pip3 install arcana_sdk --extra-index-url https://<API_KEY>@api.app.arcana.io/api/v1/sdk/simple/



