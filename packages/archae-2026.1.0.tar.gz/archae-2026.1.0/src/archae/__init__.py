"""Archae explodes archives."""
