from __future__ import annotations

import asyncio
import fnmatch
import importlib.util
import json
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import click

from architect.backends import (
    ClaudeCodeBackend,
    CodexBackend,
    CodexSDKBackend,
    ResilientBackend,
    RetryPolicy,
)
from architect.config import ArchitectConfig, BackendName, load_config, save_config
from architect.specialists import (
    CoderAgent,
    CriticAgent,
    DocumenterAgent,
    PlannerAgent,
    SpecialistAgent,
    SupervisorAgent,
    TesterAgent,
)
from architect.state import GitNotesStore, PatchStackManager
from architect.state.git_notes import ArchitectStateError
from architect.supervisor import Supervisor


@dataclass(slots=True)
class Runtime:
    repo_root: Path
    config_path: Path
    config: ArchitectConfig
    state: GitNotesStore
    patches: PatchStackManager
    supervisor: Supervisor


def _module_available(module_name: str) -> bool:
    return importlib.util.find_spec(module_name) is not None


def _node_runner(repo_root: Path) -> str:
    if (repo_root / "pnpm-lock.yaml").exists():
        return "pnpm"
    if (repo_root / "yarn.lock").exists():
        return "yarn"
    return "npm"


def _node_run_command(runner: str, script_name: str) -> str:
    if runner == "yarn":
        return f"yarn {script_name}"
    return f"{runner} run {script_name}"


def _apply_detected_defaults(config: ArchitectConfig, repo_root: Path) -> None:
    if (repo_root / "package.json").exists():
        package_json = json.loads((repo_root / "package.json").read_text(encoding="utf-8"))
        scripts = package_json.get("scripts", {})
        if not isinstance(scripts, dict):
            scripts = {}
        runner = _node_runner(repo_root)
        config.project.language = "javascript"
        config.workflow.auto_test = "test" in scripts
        config.workflow.auto_lint = "lint" in scripts
        if "test" in scripts:
            config.project.test_command = _node_run_command(runner, "test")
        if "lint" in scripts:
            config.project.lint_command = _node_run_command(runner, "lint")
        if "typecheck" in scripts:
            config.project.type_check_command = _node_run_command(runner, "typecheck")
        elif "check" in scripts:
            config.project.type_check_command = _node_run_command(runner, "check")
        else:
            config.project.type_check_command = ""
        config.guardrails.require_tests_for = ["**/*.js", "**/*.jsx", "**/*.ts", "**/*.tsx"]
        return

    if (repo_root / "go.mod").exists():
        config.project.language = "go"
        config.workflow.auto_test = True
        config.workflow.auto_lint = True
        config.project.test_command = "go test ./..."
        config.project.lint_command = "go vet ./..."
        config.project.type_check_command = "go test ./..."
        config.guardrails.require_tests_for = ["**/*.go"]
        return

    if (repo_root / "Cargo.toml").exists():
        config.project.language = "rust"
        config.workflow.auto_test = True
        config.workflow.auto_lint = True
        config.project.test_command = "cargo test"
        config.project.lint_command = "cargo check --all-targets --all-features"
        config.project.type_check_command = "cargo check --all-targets --all-features"
        config.guardrails.require_tests_for = ["**/*.rs"]
        return

    has_python_markers = any(
        (repo_root / marker).exists()
        for marker in (
            "pyproject.toml",
            "requirements.txt",
            "requirements-dev.txt",
            "setup.py",
            "setup.cfg",
        )
    )
    if not has_python_markers:
        return

    config.project.language = "python"
    if shutil.which("uv"):
        config.project.test_command = "uv run --extra dev pytest -q"
        config.project.lint_command = "uv run --extra dev ruff check src tests"
        config.project.type_check_command = "python -m compileall src tests"
        config.workflow.auto_test = True
        config.workflow.auto_lint = True
    else:
        config.project.test_command = "python -m pytest -q"
        config.project.lint_command = "python -m compileall src tests"
        config.project.type_check_command = "python -m compileall src tests"
        config.workflow.auto_test = _module_available("pytest")
        config.workflow.auto_lint = True
    config.guardrails.require_tests_for = ["**/*.py"]


def _resolve_config_path(repo_root: Path, config_value: str) -> Path:
    config_path = Path(config_value)
    if not config_path.is_absolute():
        config_path = repo_root / config_path
    return config_path.resolve()


def _build_single_backend(
    backend_name: BackendName, repo_root: Path, state: GitNotesStore
) -> CodexBackend | ClaudeCodeBackend | CodexSDKBackend:
    def event_hook(event: dict[str, Any]) -> None:
        _record_backend_event(state, event)

    if backend_name == "auto":
        return CodexSDKBackend(working_directory=repo_root)
    if backend_name == "codex_sdk":
        return CodexSDKBackend(working_directory=repo_root)
    if backend_name == "codex":
        return CodexBackend(working_directory=repo_root, event_hook=event_hook)
    return ClaudeCodeBackend(working_directory=repo_root)


def _record_backend_event(state: GitNotesStore, event: dict[str, Any]) -> None:
    metrics = state.get_metrics()
    events = metrics.get("backend_events", [])
    if not isinstance(events, list):
        events = []
    event_payload = dict(event)
    event_payload["at"] = datetime.now(UTC).replace(microsecond=0).isoformat()
    events.append(event_payload)
    metrics["backend_events"] = events[-200:]

    if event.get("event") == "backend_retry":
        metrics["backend_retry_count"] = int(metrics.get("backend_retry_count", 0)) + 1
    if event.get("event") == "backend_fallback_success":
        metrics["backend_fallback_count"] = int(metrics.get("backend_fallback_count", 0)) + 1

    state.set_metrics(metrics)


def _build_backend(
    config: ArchitectConfig, repo_root: Path, state: GitNotesStore
) -> ResilientBackend:
    primary_name = config.backend.primary
    fallback_name = config.backend.fallback
    primary_backend = _build_single_backend(primary_name, repo_root, state)
    fallback_backend = _build_single_backend(fallback_name, repo_root, state)
    policy = RetryPolicy(
        max_retries=max(0, int(config.backend.max_retries)),
        backoff_seconds=max(0.0, float(config.backend.retry_backoff_seconds)),
        timeout_seconds=max(5.0, float(config.backend.timeout_seconds)),
    )
    return ResilientBackend(
        primary_name=primary_name,
        primary_backend=primary_backend,
        fallback_name=fallback_name,
        fallback_backend=fallback_backend,
        retry_policy=policy,
        event_hook=lambda event: _record_backend_event(state, event),
    )


def _build_specialists(
    backend: ResilientBackend, config: ArchitectConfig
) -> dict[str, SpecialistAgent]:
    return {
        "planner": PlannerAgent(backend, model=config.agents.specialist_model),
        "coder": CoderAgent(backend, model=config.agents.specialist_model),
        "tester": TesterAgent(backend, model=config.agents.specialist_model),
        "critic": CriticAgent(backend, model=config.agents.specialist_model),
        "documenter": DocumenterAgent(backend, model=config.agents.specialist_model),
    }


def _load_runtime(repo_root: Path, config_path: Path) -> Runtime:
    config = load_config(config_path)
    state = GitNotesStore(
        repo_root,
        backend_mode=config.state.backend,
        branch_ref=config.state.branch_ref,
    )
    patches = PatchStackManager(repo_root, state_store=state)
    backend = _build_backend(config, repo_root, state)
    supervisor_agent = SupervisorAgent(backend, model=config.agents.supervisor_model)
    supervisor = Supervisor(
        state_store=state,
        patch_manager=patches,
        specialists=_build_specialists(backend, config),
        supervisor_agent=supervisor_agent,
        config=config,
        repo_root=repo_root,
    )
    return Runtime(
        repo_root=repo_root,
        config_path=config_path,
        config=config,
        state=state,
        patches=patches,
        supervisor=supervisor,
    )


def _record_patch_metric(state: GitNotesStore, metric_key: str, patch_hash: str) -> None:
    metrics = state.get_metrics()
    values = metrics.get(metric_key, [])
    if not isinstance(values, list):
        values = []
    if patch_hash not in values:
        values.append(patch_hash)
    metrics[metric_key] = values
    state.set_metrics(metrics)


def _matches_forbidden_path(path: str, patterns: list[str]) -> str | None:
    normalized = path.replace("\\", "/")
    for pattern in patterns:
        if fnmatch.fnmatch(normalized, pattern):
            return pattern
    return None


def _ensure_patch_allowed(patch_files: list[str], config: ArchitectConfig) -> None:
    for file_path in patch_files:
        matched = _matches_forbidden_path(file_path, config.guardrails.forbidden_paths)
        if matched:
            raise click.ClickException(
                f"Patch touches forbidden path '{file_path}' (matched guardrail '{matched}')."
            )


def _patch_metadata(state: GitNotesStore, commit_hash: str) -> dict[str, Any]:
    metrics = state.get_metrics()
    stack = metrics.get("patch_stack", [])
    if not isinstance(stack, list):
        return {}
    for item in stack:
        if isinstance(item, dict) and item.get("commit_hash") == commit_hash:
            return item
    return {}


def _session_commit_scope(state: GitNotesStore) -> set[str]:
    context = state.get_context()
    run_id = context.get("current_run_id")
    session = context.get("session", {})
    commit_hashes: set[str] = set()
    if isinstance(session, dict):
        patch_stack = session.get("patch_stack", [])
        if isinstance(patch_stack, list):
            for item in patch_stack:
                if isinstance(item, dict):
                    commit_hash = item.get("commit_hash")
                    if isinstance(commit_hash, str):
                        commit_hashes.add(commit_hash)
    if commit_hashes:
        return commit_hashes

    metrics = state.get_metrics()
    patch_stack = metrics.get("patch_stack", [])
    if isinstance(patch_stack, list):
        for item in patch_stack:
            if not isinstance(item, dict):
                continue
            if run_id and item.get("run_id") != run_id:
                continue
            commit_hash = item.get("commit_hash")
            if isinstance(commit_hash, str):
                commit_hashes.add(commit_hash)
    return commit_hashes


@click.group()
def cli() -> None:
    """Architect CLI."""


@cli.command("init")
@click.option(
    "--backend",
    type=click.Choice(["auto", "codex", "codex_sdk", "claude"]),
    default=None,
)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def init_command(backend: str | None, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    config_path = _resolve_config_path(repo_root, config_value)
    is_new_config = not config_path.exists()
    config = load_config(config_path)
    if is_new_config:
        _apply_detected_defaults(config, repo_root)
    if backend:
        config.backend.primary = backend  # type: ignore[assignment]
    save_config(config_path, config)

    (repo_root / ".architect").mkdir(parents=True, exist_ok=True)

    state = GitNotesStore(
        repo_root,
        backend_mode=config.state.backend,
        branch_ref=config.state.branch_ref,
    )
    patches = PatchStackManager(repo_root, state_store=state)
    if not state.get_context():
        state.set_context(
            {
                "goal": "",
                "phase": "idle",
                "status": "ready",
                "active_branch": patches.current_branch(),
                "paused": False,
                "session": {
                    "run_id": None,
                    "phase_history": [],
                    "patch_stack": [],
                },
            }
        )

    click.echo(f"Initialized Architect in {repo_root}")
    click.echo(f"Config: {config_path}")
    click.echo(f"Backend: {config.backend.primary}")
    click.echo(
        f"State backend: {state.backend_mode}"
    )


@cli.command("run")
@click.argument("goal")
@click.option("--resume-run", is_flag=True, default=False)
@click.option("--max-parallel-tasks", type=int, default=None)
@click.option("--autonomous/--manual", "autonomous", default=True)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def run_command(
    goal: str,
    resume_run: bool,
    max_parallel_tasks: int | None,
    autonomous: bool,
    config_value: str,
) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    if max_parallel_tasks is not None:
        runtime.config.workflow.max_parallel_tasks = max(1, int(max_parallel_tasks))
    if not autonomous:
        runtime.config.workflow.task_max_attempts = 1
        runtime.config.workflow.max_conflict_cycles = 0

    try:
        summary = asyncio.run(runtime.supervisor.run(goal, resume=resume_run))
    except (RuntimeError, ArchitectStateError) as exc:
        raise click.ClickException(str(exc)) from exc

    click.echo(f"Goal complete: {summary.goal}")
    click.echo(f"Run ID: {summary.run_id}")
    click.echo(f"Tasks: {summary.completed_tasks}/{summary.total_tasks}")
    if summary.checkpoint_id:
        click.echo(f"Checkpoint: {summary.checkpoint_id}")


@cli.command("pause")
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def pause_command(config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    runtime.supervisor.pause()
    click.echo("Workflow paused.")


@cli.command("resume")
@click.option("--from-checkpoint", "checkpoint_id", default=None)
@click.option("--goal", "goal_override", default=None)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def resume_command(checkpoint_id: str | None, goal_override: str | None, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))

    if checkpoint_id:
        try:
            branch_name = runtime.patches.rollback(checkpoint_id)
        except ArchitectStateError as exc:
            raise click.ClickException(str(exc)) from exc
        click.echo(f"Restored checkpoint on branch: {branch_name}")

    runtime.supervisor.resume()
    context = runtime.state.get_context()
    goal = goal_override or str(context.get("goal") or "").strip()
    if not goal:
        click.echo("Workflow resumed.")
        return

    try:
        summary = asyncio.run(runtime.supervisor.run(goal, resume=True))
    except (RuntimeError, ArchitectStateError) as exc:
        raise click.ClickException(str(exc)) from exc

    click.echo(f"Goal complete: {summary.goal}")
    click.echo(f"Run ID: {summary.run_id}")
    click.echo(f"Tasks: {summary.completed_tasks}/{summary.total_tasks}")
    if summary.checkpoint_id:
        click.echo(f"Checkpoint: {summary.checkpoint_id}")


@cli.command("status")
@click.option("--verbose", is_flag=True, default=False)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def status_command(verbose: bool, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    payload = runtime.supervisor.status(verbose=verbose)
    click.echo(json.dumps(payload, ensure_ascii=False, indent=2))


@cli.command("review")
@click.option("--patch", "patch_ref", default=None)
@click.option("--all", "include_all", is_flag=True, default=False)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def review_command(patch_ref: str | None, include_all: bool, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    scope = None if include_all else (_session_commit_scope(runtime.state) or None)
    patches = runtime.patches.list_patches(commit_hashes=scope)
    if not patches:
        click.echo("No patches available.")
        return

    if patch_ref:
        patch = runtime.patches.resolve_patch(patch_ref, commit_hashes=scope)
        if patch is None:
            raise click.ClickException(f"Patch not found: {patch_ref}")
        description = runtime.patches.describe_patch(patch.patch_id)
        payload = {
            "patch": patch.to_dict(),
            "metadata": _patch_metadata(runtime.state, patch.commit_hash),
            "summary": description,
        }
        click.echo(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    for patch in patches:
        click.echo(f"{patch.patch_id} {patch.commit_hash[:10]} {patch.status:<9} {patch.subject}")


@cli.command("accept")
@click.argument("patch_ref")
@click.option("--all", "include_all", is_flag=True, default=False)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def accept_command(patch_ref: str, include_all: bool, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    scope = None if include_all else (_session_commit_scope(runtime.state) or None)
    patch = runtime.patches.resolve_patch(patch_ref, commit_hashes=scope)
    if patch is None:
        raise click.ClickException(f"Patch not found: {patch_ref}")

    patch_files = runtime.patches.changed_files_for_commit(patch.commit_hash)
    _ensure_patch_allowed(patch_files, runtime.config)

    finalization = runtime.patches.finalize_accepted_patch(
        patch,
        strategy=runtime.config.workflow.branch_strategy,
    )
    runtime.patches.update_patch_status(
        patch.commit_hash,
        "accepted",
        note=f"Finalized via {finalization.get('strategy')}",
    )
    runtime.patches.update_patch_metadata(
        patch.commit_hash,
        {"finalization": finalization},
    )
    _record_patch_metric(runtime.state, "accepted_patches", patch.commit_hash)
    runtime.state.add_decision(
        {
            "id": f"dec-accept-{patch.commit_hash[:8]}",
            "topic": "patch_lifecycle",
            "decided_by": "user",
            "approved_by": "supervisor",
            "decision": f"Accepted patch {patch.patch_id}",
            "rationale": (
                "Patch passed review and guardrail validation and was "
                f"finalized with {finalization.get('strategy')} strategy."
            ),
            "metadata": {"finalization": finalization},
            "created_at": datetime.now(UTC).replace(microsecond=0).isoformat(),
        }
    )
    click.echo(
        f"Accepted {patch.patch_id} ({patch.commit_hash[:10]}), "
        f"tag={finalization.get('tag')}"
    )


@cli.command("reject")
@click.argument("patch_ref")
@click.option("--all", "include_all", is_flag=True, default=False)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def reject_command(patch_ref: str, include_all: bool, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    scope = None if include_all else (_session_commit_scope(runtime.state) or None)
    try:
        patch = runtime.patches.reject_patch(patch_ref, commit_hashes=scope)
    except ArchitectStateError as exc:
        raise click.ClickException(str(exc)) from exc

    _record_patch_metric(runtime.state, "rejected_patches", patch.commit_hash)
    tasks = runtime.state.get_tasks()
    existing_attempts = [
        int(task.get("retry_attempt", 0))
        for task in tasks
        if isinstance(task, dict) and task.get("origin_commit") == patch.commit_hash
    ]
    retry_attempt = max(existing_attempts, default=0) + 1
    retry_task_id = f"task-retry-{patch.commit_hash[:8]}-{retry_attempt:02d}"
    if not any(
        isinstance(task, dict)
        and task.get("id") == retry_task_id
        and str(task.get("status", "pending")) in {"pending", "in_progress", "failed"}
        for task in tasks
    ):
        tasks.append(
            {
                "id": retry_task_id,
                "type": "implement",
                "assigned_to": "coder",
                "description": (
                    f"Retry rejected patch {patch.patch_id} ({patch.commit_hash[:10]}). "
                    "Re-implement with corrections."
                ),
                "status": "pending",
                "depends_on": [],
                "created_at": datetime.now(UTC).replace(microsecond=0).isoformat(),
                "attempt": 0,
                "origin_patch_id": patch.patch_id,
                "origin_commit": patch.commit_hash,
                "retry_attempt": retry_attempt,
            }
        )
        runtime.state.set_tasks(tasks)

    runtime.state.add_decision(
        {
            "id": f"dec-reject-{patch.commit_hash[:8]}",
            "topic": "patch_lifecycle",
            "decided_by": "user",
            "approved_by": "supervisor",
            "decision": f"Rejected patch {patch.patch_id}",
            "rationale": "Patch removed from stack via reject workflow and queued for retry.",
            "metadata": {
                "retry_task_id": retry_task_id,
                "retry_attempt": retry_attempt,
            },
            "created_at": datetime.now(UTC).replace(microsecond=0).isoformat(),
        }
    )
    click.echo(
        f"Rejected {patch.patch_id} ({patch.commit_hash[:10]}). "
        f"Queued retry task: {retry_task_id}"
    )


@cli.command("modify")
@click.argument("patch_ref")
@click.option("--all", "include_all", is_flag=True, default=False)
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def modify_command(patch_ref: str, include_all: bool, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    scope = None if include_all else (_session_commit_scope(runtime.state) or None)
    patch = runtime.patches.resolve_patch(patch_ref, commit_hashes=scope)
    if patch is None:
        raise click.ClickException(f"Patch not found: {patch_ref}")

    branch_name = None
    if (
        runtime.patches.git_enabled
        and runtime.config.workflow.branch_strategy == "auxiliary_branches"
    ):
        branch_name = (
            f"architect/amend-{patch.patch_id}-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
        )
        runtime.patches.create_branch(branch_name, start_point=patch.commit_hash)

    tasks = runtime.state.get_tasks()
    task_id = f"task-modify-{patch.commit_hash[:8]}"
    should_append = not any(
        isinstance(task, dict)
        and task.get("id") == task_id
        and str(task.get("status", "pending")) in {"pending", "in_progress", "failed"}
        for task in tasks
    )
    if should_append:
        tasks.append(
            {
                "id": task_id,
                "type": "implement",
                "assigned_to": "coder",
                "description": f"Amend patch {patch.patch_id} ({patch.commit_hash[:10]}).",
                "status": "pending",
                "depends_on": [],
                "created_at": datetime.now(UTC).replace(microsecond=0).isoformat(),
                "attempt": 0,
                "origin_patch_id": patch.patch_id,
                "origin_commit": patch.commit_hash,
            }
        )
        runtime.state.set_tasks(tasks)

    runtime.patches.update_patch_status(patch.commit_hash, "modified")
    runtime.state.add_decision(
        {
            "id": f"dec-modify-{patch.commit_hash[:8]}",
            "topic": "patch_modification",
            "decided_by": "user",
            "approved_by": "supervisor",
            "decision": f"Modify patch {patch.patch_id}",
            "rationale": "Manual patch modification requested.",
            "created_at": datetime.now(UTC).replace(microsecond=0).isoformat(),
        }
    )

    context = runtime.state.get_context()
    context["phase"] = "implementation"
    context["status"] = "in_progress"
    if branch_name:
        context["active_branch"] = branch_name
    runtime.state.set_context(context)

    message = f"Marked {patch.patch_id} for modification."
    if branch_name:
        message += f" Amendment branch: {branch_name}"
    else:
        message += " Branch strategy: single_branch_queue."
    click.echo(message)


@cli.command("rollback")
@click.argument("checkpoint_id")
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def rollback_command(checkpoint_id: str, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    try:
        branch_name = runtime.patches.rollback(checkpoint_id)
    except ArchitectStateError as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(f"Checked out rollback branch: {branch_name}")


@cli.command("checkpoints")
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def checkpoints_command(config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    runtime = _load_runtime(repo_root, _resolve_config_path(repo_root, config_value))
    checkpoints = runtime.patches.list_checkpoints()
    if not checkpoints:
        click.echo("No checkpoints found.")
        return
    for checkpoint in checkpoints:
        click.echo(checkpoint)


@cli.command("backend")
@click.argument("backend_name", type=click.Choice(["auto", "codex", "codex_sdk", "claude"]))
@click.option("--config", "config_value", default="architect.toml", show_default=True)
def backend_command(backend_name: str, config_value: str) -> None:
    repo_root = Path.cwd().resolve()
    config_path = _resolve_config_path(repo_root, config_value)
    config = load_config(config_path)
    config.backend.primary = backend_name  # type: ignore[assignment]
    save_config(config_path, config)
    click.echo(f"Primary backend set to {backend_name}")
