from archeo.core.forward.resampler.interface import ImportanceSamplingData
