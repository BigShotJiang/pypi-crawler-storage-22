import logging
from dataclasses import dataclass

import numpy as np
import pandas as pd
from tqdm import tqdm

from archeo.core.forward.resampler.assume_independence import ISDataAssumeIndependence
from archeo.core.forward.resampler.generic import ISDataGeneric
from archeo.schema import Interface
from archeo.utils.helper import pre_release
from archeo.utils.parallel import multithread_run


local_logger = logging.getLogger(__name__)


@dataclass
class ImportanceSamplingData(Interface, ISDataGeneric, ISDataAssumeIndependence):
    """Importance sampling data for all resamplers"""

    assume_parameter_independence: bool = False

    @pre_release
    def get_likelihood_samples(self, random_state=42, ztol=1e-8) -> np.ndarray:
        """Get samples for likelihood function"""

        if self.assume_parameter_independence:
            return self.get_likelihood_samples_1d(random_state=random_state, ztol=ztol)

        return self.get_likelihood_samples_dd(random_state=random_state, ztol=ztol)

    @pre_release
    def get_bayes_factor(self, bootstrapping: bool = False, ztol=1e-8) -> float:
        """Compute the Bayes factor between two models

        NOTE: In this implementation, the likelihood function remains untouched.
        So that the Bayes factor is computed as the ratio of the new prior to the old prior.
        Details please check importance sampling.
        """

        if self.assume_parameter_independence:
            return self.get_bayes_factor_1d(bootstrapping=bootstrapping, ztol=ztol)

        return self.get_bayes_factor_dd(bootstrapping=bootstrapping, ztol=ztol)

    @pre_release
    def sample_bayes_factor(
        self,
        n: int,
        ztol=1e-8,
        is_parallel: bool = False,
        n_threads: int | None = None,
    ) -> list[float]:
        """Sample the Bayes factor for the importance sampling"""

        if self.assume_parameter_independence:
            if is_parallel:
                return multithread_run(
                    func=self.get_bayes_factor_1d,
                    input_kwargs=[{"bootstrapping": True, "ztol": ztol} for _ in range(n)],
                    n_threads=n_threads,
                )
            return [self.get_bayes_factor_1d(bootstrapping=True, ztol=ztol) for _ in tqdm(range(n))]

        if is_parallel:
            return multithread_run(
                func=self.get_bayes_factor_dd,
                input_kwargs=[{"bootstrapping": True, "ztol": ztol} for _ in range(n)],
                n_threads=n_threads,
            )
        return [self.get_bayes_factor_dd(bootstrapping=True, ztol=ztol) for _ in tqdm(range(n))]

    @pre_release
    def get_reweighted_samples(self, ztol=1e-8, random_state=42) -> pd.DataFrame:
        """Get the reweighted samples for the importance sampling"""

        if self.assume_parameter_independence:
            return self.get_reweighted_samples_1d(ztol=ztol, random_state=random_state)

        return self.get_reweighted_samples_dd(ztol=ztol, random_state=random_state)
