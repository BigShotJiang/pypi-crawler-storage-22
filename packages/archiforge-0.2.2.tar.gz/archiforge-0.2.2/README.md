# 🛠️ Archiforge

**The smartest way to forge your next project.**

Archiforge is a powerful CLI tool designed to automate the creation of project structures. No more repetitive folder creation—just forge and code!

## ✨ Features

- **🚀 Instant Scaffolding:** Generate Python, Flask, and JS projects in seconds.
- **🧠 Smart Templates:** Uses Jinja2 for dynamic file content.
- **📊 Progress Tracking:** Beautiful CLI with progress bars and colors.
- **⚓ Git Integration:** Automatic repository initialization.
- **📂 Custom Blueprints:** Easily add your own project structures.

## 📦 Installation

```bash
pip install archiforge
```
اسم المشروع: Archiforge الهدف: أداة واجهة أوامر (CLI) شاملة لإدارة دورة حياة تطوير البرمجيات (SDLC) لمشاريع بايثون وفلاسك.

الميزات الأساسية (الأوامر):

create: إنشاء هيكل المشروع من قوالب (Blueprints)، وإعداد بيئة افتراضية (venv) تلقائياً.

run: التشغيل الذكي للمشروع بناءً على نوعه (بايثون عادي أو فلاسك).

install: تثبيت المكتبات وتحديث ملف requirements.txt في خطوة واحدة.

test & lint: التأكد من صحة الكود وتنسيقه حسب معايير PEP 8 باستخدام pytest و Black.

clean: تنظيف ملفات الكاش ومخلفات التشغيل لضمان بيئة نظيفة.

info: لوحة بيانات تعرض إحصائيات دقيقة (عدد الملفات، أسطر الكود الصافية، المكتبات).

doc: إنشاء وتعديل ملفات التوثيق (README.md) بشكل احترافي.

git-sync: أتمتة عملية الحفظ والرفع إلى GitHub (Add, Commit, Push).

التقنيات المستخدمة: Python, Click, Jinja2, YAML, Subprocess.

بكل سرور! هذا الجدول يمثل "كتيب التشغيل" لأداتك Archiforge، وهو يلخص كافة الأوامر التي قمنا ببنائها لتغطية دورة حياة المشروع بالكامل:

📋 دليل أوامر Archiforge
الأمر	الوظيفة	متى تستخدمه؟
archiforge create	إنشاء مشروع جديد من القوالب مع إعداد الـ venv	عند الرغبة في بدء فكرة برمجية جديدة من الصفر.
archiforge run	التشغيل الذكي للمشروع (يكتشف الملف الأساسي تلقائياً)	عندما تريد رؤية كودك وهو يعمل فعلياً.
archiforge install [Library]	تثبيت مكتبة وتحديث ملف الـ requirements.txt فوراً	عند الحاجة لإضافة أدوات خارجية (مثل requests أو pandas).
archiforge test	تشغيل اختبارات الوحدة (Unit Tests) باستخدام pytest	قبل اعتماد أي تعديل برمجى للتأكد من سلامة الكود.
archiforge lint --fix	تنسيق وتجميل الكود تلقائياً حسب معايير PEP 8	لجعل الكود نظيفاً، مرتباً، واحترافياً.
archiforge clean	مسح ملفات الكاش (pycache) ومخلفات الاختبارات	عند حدوث أخطاء غريبة في الاستيراد (Import Errors).
archiforge info	عرض إحصائيات دقيقة عن حجم المشروع وأسطر الكود	عندما تريد تقييم حجم العمل المنجز في مشروعك.
archiforge doc	إنشاء أو فتح ملف التوثيق README.md	لشرح فكرة المشروع وتوثيق طريقة عمله للآخرين.
archiforge git-sync	تنفيذ (Add, Commit, Push) في خطوة واحدة	لحفظ كودك ورفعه على GitHub بضغطة زر.
archiforge list	عرض قائمة بجميع القوالب (Blueprints) المتوفرة	لمعرفة اللغات أو أطر العمل التي تدعمها الأداة حالياً.
💡 نصيحة للمستقبل:
يمكنك دائماً الوصول لهذا الدليل من داخل الأداة نفسها عبر كتابة:

PowerShell
archiforge --help
أو للحصول على تفاصيل عن أمر محدد:

PowerShell
archiforge [order_name] --help
بهذا الجدول، أصبحت تملك "خريطة الكنز" الخاصة بمشروعك! هل هناك أي تعديل أو إضافة تود إجراءها على أحد هذه الأوامر؟ 🚀✨