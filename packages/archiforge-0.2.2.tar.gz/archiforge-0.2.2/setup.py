from setuptools import setup, find_packages

setup(
    name="archiforge",
    version="0.2.2",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
    "click",
    "jinja2",
    "pyyaml",
    "colorama",
    "tqdm",  # أضف هذا السطر
],
    entry_points={
        "console_scripts": [
            "archiforge=archiforge.cli.main:cli",
        ],
    },
    author="Abdal",
    description="A powerful multi-language project generator CLI",
)
