# {{ name }}

Created by: **{{ author }}**
Description: {{ description }}

## Installation
```bash
pip install -r requirements.txt
