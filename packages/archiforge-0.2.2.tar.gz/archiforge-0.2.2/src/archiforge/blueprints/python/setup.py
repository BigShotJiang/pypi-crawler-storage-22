from setuptools import setup, find_packages

setup(
    name="{{ name }}",
    version="0.1.0",
    author="{{ author }}",
    description="{{ description }}",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[],
)
