def hello():
    print("Hello from {{ name }}! Created by {{ author }}.")


if __name__ == "__main__":
    hello()
