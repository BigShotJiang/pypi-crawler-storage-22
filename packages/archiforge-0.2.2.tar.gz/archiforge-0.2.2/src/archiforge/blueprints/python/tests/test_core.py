# محتوى ملف test_core.py
def test_sample():
    assert True  # اختبار بسيط يتأكد أن نظام الاختبار يعمل
