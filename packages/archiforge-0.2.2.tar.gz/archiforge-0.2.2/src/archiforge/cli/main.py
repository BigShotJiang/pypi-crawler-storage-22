import os
import subprocess
import time
from pathlib import Path
import click
import yaml
from jinja2 import Environment, FileSystemLoader
from tqdm import tqdm
from archiforge.core.engine import ForgeEngine

# في أعلى الملف بعد الاستيرادات
def style_status(message, status="info"):
    colors = {"info": "cyan", "success": "green", "warning": "yellow", "error": "red"}
    icon = {"info": "ℹ️", "success": "✅", "warning": "⚠️", "error": "❌"}
    return click.style(f"{icon[status]} {message}", fg=colors[status])

# مثال لاستخدامها داخل دالة create:
# click.echo(style_status("Project forged successfully!", "success"))

CONFIG_FILE = Path.home() / ".archiforge_config.yaml"


def load_config():
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}
    return {}


@click.group()
@click.version_option(version="0.2.2", prog_name="Archiforge") # أضف هذا السطر فقط
def cli():
    """Archiforge: أداة قوية لإنشاء وهيكلة المشاريع برمجياً."""
    pass


@cli.command()
@click.option("--author", prompt="Default Author Name")
def configure(author):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        yaml.dump({"default_author": author}, f)
    click.secho(f"✅ Default author saved!", fg="green")


@cli.command(name="list")
def list_blueprints():
    current_file = Path(__file__).resolve()
    blueprints_path = current_file.parent.parent / "blueprints"
    click.secho("\n📂 Available Blueprints in Archiforge:", fg="bright_cyan", bold=True)
    click.echo("=" * 40)
    if not blueprints_path.exists():
        return
    blueprints = [d.name for d in blueprints_path.iterdir() if d.is_dir()]
    for bp in blueprints:
        files_count = sum([len(files) for r, d, files in os.walk(blueprints_path / bp)])
        click.echo(
            f"  🔹 {click.style(bp.ljust(15), fg='green', bold=True)} ({files_count} files/folders)"
        )
    click.echo("=" * 40)


@cli.command()
@click.option('--name', prompt='Project name')
@click.option('--lang', type=click.Choice(['python', 'flask', 'javascript']), default='python')
@click.option('--code', is_flag=True)
def create(name, lang, code):
    """إنشاء مشروع جديد والتأكد من وجود المجلد والملفات."""
    output_path = Path.cwd() / name
    
    # 1. إنشاء المجلد الفعلي فوراً (هذا ما كان ينقصنا)
    try:
        output_path.mkdir(parents=True, exist_ok=True)
        click.echo(click.style(f"📁 Directory created at: {output_path}", fg="cyan"))
    except Exception as e:
        click.secho(f"❌ Failed to create directory: {e}", fg="red")
        return

    # 2. إعداد بيانات المحرك
    # التأكد من أن المسار يشير إلى القالب المحدد (javascript مثلاً)
    base_blueprints = Path(__file__).resolve().parent.parent / "blueprints"
    target_template = base_blueprints / lang
    # تعديل البيانات لتطابق توقعات المحرك
    context_data = {
        "name": name,           # الاسم الذي نستخدمه نحن
        "project_name": name    # الاسم الذي يطلبه المحرك (لحل الخطأ الأخير)
    }

    # استدعاء المحرك بالبيانات المحدثة
    try:
        engine = ForgeEngine(
            template_path=target_template,
            output_path=output_path,
            context=context_data
        )
        
        # تنفيذ عملية البناء
        engine.forge()
        
        # التأكد من النجاح
        if any(output_path.iterdir()):
            click.secho(f"✅ Success! {name} has been forged with all files.", fg="green", bold=True)

    except Exception as e:
        # هذا الجزء هو ما كان ينقص الـ try
        click.secho(f"❌ An error occurred: {e}", fg="red")    # 3. تشغيل المحرك
    
        
        # كود تشخيصي: طباعة كل الدوال المتاحة في المحرك لديك
        methods = [method for method in dir(engine) if callable(getattr(engine, method)) and not method.startswith("__")]
        click.echo(f"🤖 Engine methods found: {methods}")

        # محاولة استدعاء الدالة الصحيحة (أضفنا 'forge' و 'build' للقائمة)
        found_method = False
        for method_name in ['render', 'copy_template', 'run', 'forge', 'build']:
            if hasattr(engine, method_name):
                getattr(engine, method_name)()
                found_method = True
                break
            
        if not found_method:
            click.secho("❌ Error: Could not find a working method (render/run/forge) in ForgeEngine.", fg="red")
            return

        # نتحقق إذا تم نسخ أي شيء
        if any(output_path.iterdir()):
            click.secho(f"✅ Success! {name} has been forged with its files.", fg="green", bold=True)
        else:
            click.secho(f"⚠️ Warning: Engine executed but directory is still empty.", fg="yellow")
            
    except Exception as e:
        click.secho(f"❌ Engine Error: {e}", fg="red")
    # 4. فتح في VS Code
    if code:
        subprocess.run(["code", str(output_path)], shell=True)@cli.command()
        
        
@cli.command()
def run():
    current_dir = Path.cwd()
    
    # 1. مشروع JavaScript
    if (current_dir / "package.json").exists():
        click.secho("📦 JavaScript project detected...", fg="yellow")
        subprocess.run(["npm", "start"], shell=True)
        
    # 2. مشروع Flask
    elif (current_dir / "run.py").exists():
        click.secho("🔥 Flask project detected...", fg="green")
        subprocess.run(["python", "run.py"])
        
    # 3. مشروع Python Script (جديد)
    elif (current_dir / "src" / "main.py").exists():
        click.secho("🐍 Python script detected...", fg="blue")
        subprocess.run(["python", "src/main.py"])
        
    else:
        click.secho("❌ No runnable entry point found.", fg="red")
@cli.command()
@click.argument("package")
def install(package):
    """تثبيت مكتبة وإضافتها تلقائياً لملف requirements.txt."""
    output_path = Path.cwd()
    req_file = output_path / "requirements.txt"

    click.echo(f"⏳ Installing {click.style(package, fg='cyan')}...")

    # 1. تنفيذ عملية التثبيت الفعلية
    try:
        result = subprocess.run(
            ["pip", "install", package], capture_output=True, text=True
        )

        if result.returncode == 0:
            click.secho(f"✅ {package} installed successfully!", fg="green")

            # 2. تحديث ملف requirements.txt تلقائياً
            if req_file.exists():
                with open(req_file, "r+", encoding="utf-8") as f:
                    content = f.read()
                    if package not in content:
                        # إضافة سطر جديد إذا لم يكن موجوداً
                        f.write(f"\n{package}")
                        click.secho(
                            f"📝 Added '{package}' to requirements.txt", fg="blue"
                        )
            else:
                # إنشاء الملف إذا لم يكن موجوداً
                with open(req_file, "w", encoding="utf-8") as f:
                    f.write(package)
                click.secho(
                    f"📄 Created requirements.txt and added '{package}'", fg="blue"
                )
        else:
            click.secho(f"❌ Error installing package: {result.stderr}", fg="red")

    except Exception as e:
        click.echo(f"❌ Unexpected error: {e}")


@cli.command()
def test():
    """تشغيل الاختبارات التلقائية للمشروع."""
    current_dir = Path.cwd()

    # التأكد من وجود pytest
    click.echo(
        f"🔍 Checking for tests in {click.style(current_dir.name, fg='cyan')}..."
    )

    try:
        # تشغيل pytest مباشرة
        # نستخدم -v ليعطينا تفاصيل أكثر عن الاختبارات
        result = subprocess.run(["pytest", "-v"], cwd=current_dir)

        if result.returncode == 0:
            click.secho(
                "\n✅ All tests passed! Your code is solid.", fg="green", bold=True
            )
        elif result.returncode == 5:  # كود 5 يعني لم يتم العثور على اختبارات
            click.secho(
                "\n⚠️  No tests found. Create a 'tests/' folder to start testing!",
                fg="yellow",
            )
        else:
            click.secho(
                "\n❌ Some tests failed. Check the output above.", fg="red", bold=True
            )

    except FileNotFoundError:
        click.secho(
            "❌ 'pytest' is not installed. Run 'archiforge install pytest' first!",
            fg="red",
        )


@cli.command()
@click.option(
    "--fix", is_flag=True, help="Fix formatting issues automatically using Black"
)
def lint(fix):
    """فحص وتنسيق جودة الكود (PEP 8)."""
    current_dir = Path.cwd()

    if fix:
        click.echo(click.style("✨ Formatting code with Black...", fg="cyan"))
        # تشغيل Black لتعديل الملفات تلقائياً
        subprocess.run(["black", "."], cwd=current_dir)
        click.secho("✅ Code formatting complete!", fg="green")
    else:
        click.echo(click.style("🔍 Checking code quality with Flake8...", fg="yellow"))
        # تشغيل Flake8 للفحص فقط دون تعديل
        result = subprocess.run(["flake8", "."], cwd=current_dir)

        if result.returncode == 0:
            click.secho(
                "⭐ Perfect! Your code follows PEP 8 standards.", fg="green", bold=True
            )
        else:
            click.secho(
                "⚠️  Found some style issues. Use 'archiforge lint --fix' to fix them.",
                fg="yellow",
            )
    """تشغيل الاختبارات التلقائية للمشروع."""
    current_dir = Path.cwd()

    # التأكد من وجود pytest
    click.echo(
        f"🔍 Checking for tests in {click.style(current_dir.name, fg='cyan')}..."
    )

    try:
        # تشغيل pytest مباشرة
        # نستخدم -v ليعطينا تفاصيل أكثر عن الاختبارات
        result = subprocess.run(["pytest", "-v"], cwd=current_dir)

        if result.returncode == 0:
            click.secho(
                "\n✅ All tests passed! Your code is solid.", fg="green", bold=True
            )
        elif result.returncode == 5:  # كود 5 يعني لم يتم العثور على اختبارات
            click.secho(
                "\n⚠️  No tests found. Create a 'tests/' folder to start testing!",
                fg="yellow",
            )
        else:
            click.secho(
                "\n❌ Some tests failed. Check the output above.", fg="red", bold=True
            )

    except FileNotFoundError:
        click.secho(
            "❌ 'pytest' is not installed. Run 'archiforge install pytest' first!",
            fg="red",
        )


@cli.command()
def clean():
    """تنظيف ملفات الكاش المؤقتة ومخلفات الاختبارات."""
    current_dir = Path.cwd()
    click.echo(
        f"🧹 Cleaning up cache files in {click.style(current_dir.name, fg='cyan')}..."
    )

    # حذف مجلدات pycache و .pytest_cache
    deleted_count = 0
    patterns = ["**/__pycache__", "**/.pytest_cache", "**/*.pyc"]

    for pattern in patterns:
        for path in current_dir.glob(pattern):
            if path.is_dir():
                import shutil

                shutil.rmtree(path)
            else:
                path.unlink()
            deleted_count += 1

    click.secho(f"✅ Cleaned {deleted_count} items. System is fresh now!", fg="green")


@cli.command()
def info():
    """عرض معلومات تفصيلية ودقيقة عن المشروع (باستثناء المكتبات الخارجية)."""
    path = Path.cwd()
    click.secho(f"\n📊 Project Dashboard: {path.name}", fg="bright_magenta", bold=True)
    click.echo("-" * 40)
    
    # قائمة المجلدات التي نريد تجاهلها (المكتبات والكاش)
    ignored_dirs = {'venv', '.git', '__pycache__', '.pytest_cache', 'node_modules'}
    
    py_files = []
    total_lines = 0
    
    # البحث عن ملفات بايثون مع استثناء المجلدات المتجاهلة
    for p in path.rglob("*.py"):
        # التحقق من أن الملف ليس بداخل أي مجلد من القائمة المتجاهلة
        if not any(ignored in p.parts for ignored in ignored_dirs):
            py_files.append(p)
            try:
                with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                    total_lines += len(f.readlines())
            except Exception:
                continue

    # فحص المكتبات المطلوبة في المشروع
    req_file = path / "requirements.txt"
    libs_count = 0
    if req_file.exists():
        # قراءة الأسطر غير الفارغة والتي لا تبدأ بـ #
        libs = [line for line in req_file.read_text().splitlines() if line.strip() and not line.startswith('#')]
        libs_count = len(libs)

    # عرض النتائج بشكل منظم
    click.echo(f"📂 {click.style('Location:', fg='yellow')} {path}")
    click.echo(f"🐍 {click.style('Source Files:', fg='yellow')} {len(py_files)} (.py files)")
    click.echo(f"📝 {click.style('Net Lines of Code:', fg='yellow')} {total_lines}")
    click.echo(f"📦 {click.style('Project Dependencies:', fg='yellow')} {libs_count} libraries")
    
    # حالة البيئة الافتراضية
    if (path / "venv").exists():
        click.secho("✅ Virtual Environment (venv) detected.", fg="green")
    else:
        click.secho("⚠️  No venv found in this directory.", fg="yellow")
    
    click.echo("-" * 40)    
    
@cli.command()
@click.option('--m', prompt='Commit message', help='Message for the git commit')
def git_sync(m):
    """مزامنة المشروع مع GitHub (Add, Commit, Push) في خطوة واحدة."""
    path = Path.cwd()
    
    # التأكد من أن المجلد هو مستودع Git
    if not (path / ".git").exists():
        if click.confirm("📂 This folder is not a Git repo. Initialize it?"):
            subprocess.run(["git", "init"])
            click.secho("✅ Git repository initialized.", fg="green")
        else:
            return

    try:
        click.echo("🔄 Syncing with GitHub...")
        
        # 1. Git Add
        subprocess.run(["git", "add", "."], check=True)
        
        # 2. Git Commit
        subprocess.run(["git", "commit", "-m", m], check=True)
        
        # 3. Git Push
        # ملاحظة: يفترض أنك قمت بربط المستودع بـ Remote سابقاً
        result = subprocess.run(["git", "push"], capture_output=True, text=True)
        
        if result.returncode == 0:
            click.secho("🚀 Project synced successfully to GitHub!", fg="green", bold=True)
        else:
            click.secho(f"⚠️  Push failed. You might need to set up a remote: 'git remote add origin <url>'", fg="yellow")
            click.echo(result.stderr)
            
    except Exception as e:
        click.echo(f"❌ Git error: {e}")
        
@cli.command()
def doc():
    """إنشاء أو فتح توثيق المشروع (README.md)."""
    path = Path.cwd()
    readme_path = path / "README.md"
    
    if not readme_path.exists():
        click.echo("📝 README.md not found. Generating a professional template...")
        
        # قالب توثيق احترافي
        content = f"""# {path.name}

    ## 🚀 Description
    {path.name} is a project generated and managed by Archiforge.

    ## 🛠️ Installation
    ```bash
    archiforge install -r requirements.txt
    📈 Usage
    To run the project:
    archiforge run
    🧪 Testing
    archiforge test
    Generated by Archiforge """ 
    with open(readme_path, "w", encoding="utf-8") as f: f.write(content)
    click.secho("✅ README.md has been generated!", fg="green")
    # فتح الملف للمراجعة سواء كان موجوداً أو تم إنشاؤه للتو
    click.echo(f"📖 Opening {click.style('README.md', fg='cyan')} for review...")
    subprocess.run(['code', str(readme_path)], shell=True)

@cli.command()
def info():
    """عرض معلومات سريعة عن المشروع الحالي."""
    path = Path.cwd()
    files = list(path.rglob('*'))
    file_count = len([f for f in files if f.is_file()])
    dir_count = len([d for d in files if d.is_dir()])
    
    click.echo(click.style(f"📊 Project: {path.name}", fg="cyan", bold=True))
    click.echo(f"📁 Directories: {dir_count}")
    click.echo(f"📄 Files: {file_count}")

@cli.command()
def doc():
    """توليد ملف README.md احترافي بناءً على محتوى المشروع."""
    path = Path.cwd()
    project_name = path.name
    readme_path = path / "README.md"
    
    # تحديد التقنيات المستخدمة
    tech_stack = []
    if (path / "package.json").exists(): tech_stack.append("JavaScript/Node.js")
    if (path / "run.py").exists(): tech_stack.append("Flask Framework")
    if (path / "requirements.txt").exists(): tech_stack.append("Python Ecosystem")

    # بناء المحتوى
    doc_content = f"""# 🚀 {project_name}

## 📝 Description
This project was automatically generated and documented by **Archiforge**.

## 🛠️ Tech Stack
{chr(10).join([f'- {tech}' for tech in tech_stack])}

## 📂 Project Structure
```text
{project_name}/
"""
    # إضافة هيكل المجلدات بشكل مبسط
    for item in sorted(path.glob('*')):
        if item.name not in ['.git', 'venv', '__pycache__', 'node_modules']:
            doc_content += f"├── {item.name}\n"
    
    doc_content += "```\n\n## ⚡ How to Run\n"
    if "JavaScript/Node.js" in tech_stack:
        doc_content += "```bash\nnpm install\nnpm start\n```\n"
    else:
        doc_content += "```bash\npip install -r requirements.txt\npython run.py # or src/main.py\n```\n"

    # حفظ الملف
    with open(readme_path, "w", encoding="utf-8") as f:
        f.write(doc_content)
    
    click.secho(f"✨ Documentation generated successfully in {readme_path.name}!", fg="green", bold=True)


@cli.command()
def ship():
    """تجهيز المشروع للنشر عن طريق توليد ملفات Docker."""
    path = Path.cwd()
    
    # 1. حالة مشروع Flask
    if (path / "run.py").exists():
        docker_content = """FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "run.py"]"""
        
    # 2. حالة مشروع JavaScript/Node
    elif (path / "package.json").exists():
        docker_content = """FROM node:16
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]"""
    
    else:
        click.secho("❌ Could not detect project type for Dockerization.", fg="red")
        return

    # حفظ ملف Dockerfile
    with open(path / "Dockerfile", "w") as f:
        f.write(docker_content)
        
    # إضافة ملف .dockerignore بسيط
    with open(path / ".dockerignore", "w") as f:
        f.write("venv/\nnode_modules/\n__pycache__/\n.git/")

    click.secho("🐋 Dockerfile and .dockerignore generated! Your project is ready to sail.", fg="blue", bold=True)


@cli.command()
def setup():
    """تثبيت كافة الاعتمادات (Dependencies) للمشروع الحالي تلقائياً."""
    path = Path.cwd()
    
    if (path / "package.json").exists():
        click.echo("📦 Installing Node modules...")
        subprocess.run(["npm", "install"], shell=True)
        
    elif (path / "requirements.txt").exists():
        click.echo("🐍 Installing Python packages...")
        subprocess.run(["pip", "install", "-r", "requirements.txt"])
        
    click.secho("✨ Environment is all set up!", fg="green")


@cli.command()
def test():
    """تشغيل الاختبارات للمشروع الحالي (Python/Flask/JS)."""
    path = Path.cwd()
    
    # 1. حالة بايثون أو فلاسك
    if (path / "requirements.txt").exists():
        click.secho("🧪 Running Python tests via pytest...", fg="yellow")
        # إنشاء ملف اختبار تجريبي إذا كان مجلد tests فارغاً
        test_file = path / "tests" / "test_basic.py"
        if not test_file.exists():
            test_file.parent.mkdir(exist_ok=True)
            with open(test_file, "w") as f:
                f.write("def test_example():\n    assert 1 == 1")
        
        subprocess.run(["pytest"])

    # 2. حالة جافا سكريبت
    elif (path / "package.json").exists():
        click.secho("🧪 Running JavaScript tests via npm test...", fg="yellow")
        subprocess.run(["npm", "test"], shell=True)
        
    else:
        click.secho("❌ No test suite detected.", fg="red")

@cli.command()
def test():
    """تشغيل الاختبارات وتنظيف الكاش المؤقت."""
    path = Path.cwd()
    
    # تنظيف ملفات __pycache__ لتجنب أخطاء mismatch
    for cache in path.rglob("__pycache__"):
        import shutil
        shutil.rmtree(cache, ignore_errors=True)

    if (path / "requirements.txt").exists():
        click.secho("🧪 Running Python tests...", fg="yellow")
        # تأكد من أننا نختبر المجلد الحالي فقط باستخدام .
        subprocess.run(["pytest", "."])
    # ... بقية الكود

    
if __name__ == "__main__":
    cli()
