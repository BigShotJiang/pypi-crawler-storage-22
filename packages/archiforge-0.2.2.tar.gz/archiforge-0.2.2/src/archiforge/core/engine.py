import os
import yaml
import subprocess
from jinja2 import Template


class ForgeEngine:
    def __init__(self, template_path, output_path, context):
        """
        template_path: مسار مجلد القالب
        output_path: مسار المشروع الجديد المراد إنشاؤه
        context: البيانات (الاسم، المؤلف، الوصف)
        """
        self.template_path = template_path
        self.output_path = output_path
        self.context = context

    def load_structure(self):
        """تحميل ومعالجة ملف structure.yaml كقالب Jinja2 أولاً"""
        yaml_file = os.path.join(self.template_path, "structure.yaml")
        if not os.path.exists(yaml_file):
            raise FileNotFoundError(f"Missing structure.yaml in {self.template_path}")

        with open(yaml_file, "r", encoding="utf-8") as f:
            raw_yaml = f.read()

        # السحر هنا: معالجة الـ YAML نفسه كقالب قبل تحويله لبيانات
        rendered_yaml = Template(raw_yaml).render(self.context)
        return yaml.safe_load(rendered_yaml)

    def forge(self):
        """الوظيفة الأساسية لبناء المشروع"""
        structure = self.load_structure()

        # التأكد من إنشاء المجلد الرئيسي للمشروع أولاً
        if not os.path.exists(self.output_path):
            os.makedirs(self.output_path, exist_ok=True)
            print(f"🏗️  Created project root: {self.output_path}")

        # 1. إنشاء المجلدات الفرعية المذكورة في القالب
        for folder in structure.get("directories", []):
            rendered_folder = Template(folder).render(self.context)
            path = os.path.join(self.output_path, rendered_folder)
            os.makedirs(path, exist_ok=True)
            print(f"📁 Created directory: {path}")

        # 2. إنشاء الملفات وتعبئة محتواها
        for file_info in structure.get("files", []):
            rendered_path = Template(file_info["path"]).render(self.context)
            rendered_content = Template(file_info["content"]).render(self.context)

            full_path = os.path.join(self.output_path, rendered_path)

            # التأكد من وجود المجلد الأب للملف (في حال كان ملفاً عميقاً)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            with open(full_path, "w", encoding="utf-8") as f:
                f.write(rendered_content)
            print(f"📄 Created file: {full_path}")

        # 3. تنفيذ أوامر ما بعد البناء
        self.run_post_commands(structure.get("post_commands", []))

        print(
            f"\n✅ Archiforge: Project '{self.context['project_name']}' forged successfully!"
        )

    def run_post_commands(self, commands):
        """تنفيذ أوامر مثل git init أو npm install"""
        if not commands:
            return

        original_dir = os.getcwd()
        os.chdir(self.output_path)

        for cmd in commands:
            rendered_cmd = Template(cmd).render(self.context)
            print(f"⚡ Running: {rendered_cmd}...")
            try:
                subprocess.run(rendered_cmd, shell=True, check=True)
            except subprocess.CalledProcessError as e:
                print(f"⚠️  Command failed: {e}")

        os.chdir(original_dir)
