"""Protobuf definitions for gRPC error handling tests."""
