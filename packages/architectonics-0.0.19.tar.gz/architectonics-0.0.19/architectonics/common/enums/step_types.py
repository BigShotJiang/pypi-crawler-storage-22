from enum import Enum


class StepTypes(int, Enum):
    TEXT_STEP = 1
    VIDEO_STEP = 2
