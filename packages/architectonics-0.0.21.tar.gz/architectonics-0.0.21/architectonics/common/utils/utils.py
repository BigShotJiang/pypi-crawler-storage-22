import datetime


def get_current_datetime():
    return datetime.datetime.utcnow()
