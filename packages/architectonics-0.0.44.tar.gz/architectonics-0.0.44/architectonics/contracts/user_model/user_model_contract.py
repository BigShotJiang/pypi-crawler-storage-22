from architectonics.common.enums.step_type import StepType
from pydantic import BaseModel


class UserModelContract(BaseModel):
    id: str
    first_name: str
    last_name: str
    email: str
