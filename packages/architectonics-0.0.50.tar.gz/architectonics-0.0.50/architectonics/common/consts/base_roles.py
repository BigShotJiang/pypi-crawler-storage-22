from enum import Enum


class RolesDict(str, Enum):
    SUPER_ADMIN = "SuperAdmin"
    TEACHER = "Teacher"
    STUDENT = "Student"
