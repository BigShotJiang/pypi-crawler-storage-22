from enum import Enum


class StepType(int, Enum):
    TEXT_STEP = 1
    VIDEO_STEP = 2
    ANNOTATION_STEP = 3
    ANNOTATION_VALIDATION_STEP = 4
    AI_QUESTION_STEP = 5
