from pydantic import BaseModel

from architectonics.common.enums.step_type import StepType


class UserModelContract(BaseModel):
    id: str
    first_name: str
    last_name: str
    email: str
