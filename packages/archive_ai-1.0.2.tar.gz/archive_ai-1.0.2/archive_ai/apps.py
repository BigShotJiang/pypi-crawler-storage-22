from django.apps import AppConfig

class ArchiveAiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'archive_ai'

    def ready(self):
        import archive_ai.signals
