#!/usr/bin/python
# coding: utf-8
from archivebox_api.archivebox_mcp import archivebox_mcp

if __name__ == "__main__":
    archivebox_mcp()
