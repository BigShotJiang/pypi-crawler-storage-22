---
name: archivebox-authentication
description: ArchiveBox authentication tools.
---

### Overview
This skill provides authentication tools for ArchiveBox.

### Key Tools
PROMPT_USER: Use the available tools for authentication as needed.
