ARCSECOND_API_URL_DEV = "http://localhost:8000"
ARCSECOND_API_URL_PROD = "https://api.arcsecond.io"

ARCSECOND_WWW_URL_DEV = "http://localhost:8080"
ARCSECOND_WWW_URL_PROD = "https://www.arcsecond.io"

API_AUTH_PATH_VERIFY = "auth/key/verify"
API_AUTH_PATH_VERIFY_PORTAL = "auth/key/verify-organisation"
