# from .main import install, status, stop
from .local import setup