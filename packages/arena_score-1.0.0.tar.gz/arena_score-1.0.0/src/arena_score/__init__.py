"""
ARENA Score - Adaptive Review and Evaluation using Novel Aggregation Score

A novel client evaluation and weighted aggregation algorithm for Federated Learning.

Key Features:
- Adaptive client evaluation using ΔAcc, CS, and SN metrics
- Robust aggregation with anomaly detection
- Gradient recycling for missing clients
- Model agnostic design
"""

from arena_score.score import compute_arena_score, compute_adaptive_weights
from arena_score.client import ARENAScoreClient
from arena_score.server import ARENAScoreServer
from arena_score.aggregator import run_arena_score
from arena_score.utils import (
    compute_cosine_similarity,
    compute_spectral_norm,
    compute_kl_divergence,
    flatten_weights,
    unflatten_weights
)

__version__ = "1.0.0"
__author__ = "Ronit Mehta"
__email__ = "ronit26mehta@gmail.com"

__all__ = [
    # Core classes
    "ARENAScoreClient",
    "ARENAScoreServer",
    # Main function
    "run_arena_score",
    # Score computation
    "compute_arena_score",
    "compute_adaptive_weights",
    # Utilities
    "compute_cosine_similarity",
    "compute_spectral_norm",
    "compute_kl_divergence",
    "flatten_weights",
    "unflatten_weights",
    # Version
    "__version__",
]
