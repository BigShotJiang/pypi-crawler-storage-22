"""
ARENA Score Aggregator

Main federated learning loop using ARENA Score aggregation.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Any, Protocol

from arena_score.client import ARENAScoreClient
from arena_score.server import ARENAScoreServer


class ModelProtocol(Protocol):
    """Protocol defining the required model interface."""
    
    def get_weights(self) -> Dict[str, np.ndarray]: ...
    def set_weights(self, weights: Dict[str, np.ndarray]) -> None: ...
    def predict(self, X: np.ndarray) -> np.ndarray: ...
    def predict_proba(self, X: np.ndarray) -> np.ndarray: ...
    def copy(self) -> 'ModelProtocol': ...


def run_arena_score(
    global_model: ModelProtocol,
    clients: List[ARENAScoreClient],
    n_rounds: int = 10,
    eval_data: Optional[Tuple[np.ndarray, np.ndarray]] = None,
    server_config: Optional[Dict[str, Any]] = None,
    verbose: bool = True
) -> Dict[str, Any]:
    """
    Run ARENA Score federated learning algorithm.
    
    This is the main entry point for running federated learning with
    ARENA Score aggregation.
    
    Args:
        global_model: Global model to train (must implement ModelProtocol)
        clients: List of ARENAScoreClient instances
        n_rounds: Number of communication rounds (default: 10)
        eval_data: Optional (X_test, y_test) tuple for evaluation
        server_config: Optional server configuration dictionary with keys:
            - alpha_0, alpha_min: Accuracy weight parameters
            - gamma_0, gamma_min: Cosine similarity weight parameters
            - eta: Spectral norm coefficient
            - lambda_decay: Decay rate
            - s_min: Minimum score threshold
            - anomaly_threshold: CS anomaly threshold
            - kl_threshold: KL divergence threshold
            - enable_gradient_recycling: Enable gradient recycling
        verbose: Print progress (default: True)
    
    Returns:
        Training history dictionary with keys:
        - round: List of round numbers
        - train_loss: Average training loss per round
        - train_accuracy: Average training accuracy per round
        - test_accuracy: Test accuracy per round (if eval_data provided)
        - test_loss: Test loss per round (if eval_data provided)
        - arena_scores: ARENA scores per round
        - alpha_t, gamma_t: Adaptive weights per round
        - mean_delta_acc, mean_cosine_sim, mean_spectral_norm: Mean metrics
        - valid_clients_ratio: Ratio of non-anomalous clients
    
    Example:
        >>> from arena_score import ARENAScoreClient, run_arena_score
        >>> 
        >>> # Create clients
        >>> clients = [
        ...     ARENAScoreClient(i, model.copy(), X[i], y[i])
        ...     for i in range(n_clients)
        ... ]
        >>> 
        >>> # Run ARENA Score FL
        >>> history = run_arena_score(
        ...     global_model=model,
        ...     clients=clients,
        ...     n_rounds=10,
        ...     eval_data=(X_test, y_test)
        ... )
        >>> 
        >>> print(f"Final accuracy: {history['test_accuracy'][-1]:.4f}")
    """
    # Initialize server
    config = server_config or {}
    server = ARENAScoreServer(global_model, **config)
    
    # Initialize history
    history: Dict[str, List[Any]] = {
        'round': [],
        'train_loss': [],
        'train_accuracy': [],
        'test_accuracy': [],
        'test_loss': [],
        'arena_scores': [],
        'alpha_t': [],
        'gamma_t': [],
        'mean_delta_acc': [],
        'mean_cosine_sim': [],
        'mean_spectral_norm': [],
        'valid_clients_ratio': []
    }
    
    for round_num in range(n_rounds):
        global_weights = server.get_global_weights()
        
        # Collect client updates
        client_weights: List[Dict[str, np.ndarray]] = []
        client_metrics: List[Dict[str, Any]] = []
        client_samples: List[int] = []
        client_ids: List[int] = []
        
        for client in clients:
            weights, metrics, n_samples = client.local_train(global_weights)
            client_weights.append(weights)
            client_metrics.append(metrics)
            client_samples.append(n_samples)
            client_ids.append(client.client_id)
        
        # ARENA Score aggregation
        _, agg_info = server.aggregate(
            client_weights, client_metrics, client_samples, client_ids
        )
        
        # Record metrics
        avg_loss = float(np.mean([m['avg_loss'] for m in client_metrics]))
        avg_acc = float(np.mean([m['accuracy'] for m in client_metrics]))
        
        history['round'].append(round_num + 1)
        history['train_loss'].append(avg_loss)
        history['train_accuracy'].append(avg_acc)
        history['arena_scores'].append(agg_info['scores'])
        history['alpha_t'].append(agg_info['alpha_t'])
        history['gamma_t'].append(agg_info['gamma_t'])
        history['mean_delta_acc'].append(float(np.mean([m['delta_acc'] for m in client_metrics])))
        history['mean_cosine_sim'].append(float(np.mean([m['cosine_sim'] for m in client_metrics])))
        history['mean_spectral_norm'].append(float(np.mean([m['spectral_norm'] for m in client_metrics])))
        history['valid_clients_ratio'].append(agg_info['valid_clients'] / agg_info['total_clients'])
        
        # Evaluate on test data
        if eval_data is not None:
            X_test, y_test = eval_data
            test_pred = global_model.predict(X_test)
            test_proba = global_model.predict_proba(X_test)
            test_acc = float(np.mean(test_pred == y_test))
            test_loss = float(-np.mean(
                y_test * np.log(np.clip(test_proba, 1e-7, 1-1e-7)) +
                (1 - y_test) * np.log(np.clip(1 - test_proba, 1e-7, 1-1e-7))
            ))
            history['test_accuracy'].append(test_acc)
            history['test_loss'].append(test_loss)
            
            if verbose:
                print(f"Round {round_num + 1}/{n_rounds}: "
                      f"Train Acc={avg_acc:.4f}, Test Acc={test_acc:.4f}, "
                      f"Valid Clients={agg_info['valid_clients']}/{agg_info['total_clients']}")
        elif verbose:
            print(f"Round {round_num + 1}/{n_rounds}: "
                  f"Train Acc={avg_acc:.4f}, "
                  f"Valid Clients={agg_info['valid_clients']}/{agg_info['total_clients']}")
    
    return history
