"""
ARENA Score Client

Client implementation for ARENA Score federated learning.
Performs local training and computes ARENA metrics for server evaluation.
"""

import numpy as np
from typing import Dict, Tuple, Any, Optional, Protocol


class ModelProtocol(Protocol):
    """Protocol defining the required model interface."""
    
    def get_weights(self) -> Dict[str, np.ndarray]: ...
    def set_weights(self, weights: Dict[str, np.ndarray]) -> None: ...
    def forward(self, X: np.ndarray) -> np.ndarray: ...
    def backward(self, X: np.ndarray, y: np.ndarray, y_pred: np.ndarray) -> Dict[str, np.ndarray]: ...
    def update_weights(self, gradients: Dict[str, np.ndarray]) -> None: ...
    def predict(self, X: np.ndarray) -> np.ndarray: ...
    def predict_proba(self, X: np.ndarray) -> np.ndarray: ...
    def copy(self) -> 'ModelProtocol': ...


class ARENAScoreClient:
    """
    ARENA Score Client with adaptive evaluation metrics.
    
    This client performs local training and computes the metrics needed
    for ARENA Score evaluation:
    - ΔAcc (delta accuracy): Accuracy improvement after local training
    - CS (cosine similarity): Alignment with global update direction
    - SN (spectral norm): Weight matrix regularization
    - KL divergence: Distribution shift detection
    
    Args:
        client_id: Unique identifier for this client
        model: Model implementing the ModelProtocol interface
        X: Training data features
        y: Training data labels
        local_epochs: Number of local training epochs (default: 1)
        batch_size: Batch size for training (default: 32)
        eta: Spectral norm coefficient (default: 0.5)
    
    Example:
        >>> client = ARENAScoreClient(
        ...     client_id=0,
        ...     model=my_model,
        ...     X=X_train,
        ...     y=y_train,
        ...     local_epochs=5
        ... )
        >>> weights, metrics, n_samples = client.local_train(global_weights)
    """
    
    def __init__(
        self,
        client_id: int,
        model: ModelProtocol,
        X: np.ndarray,
        y: np.ndarray,
        local_epochs: int = 1,
        batch_size: int = 32,
        eta: float = 0.5
    ):
        self.client_id = client_id
        self.model = model
        self.X = X
        self.y = y
        self.local_epochs = local_epochs
        self.batch_size = batch_size
        self.eta = eta
        self.n_samples = len(X)
        
        # Track previous state for ΔAcc and CS computation
        self.prev_accuracy: Optional[float] = None
        self.prev_weights: Optional[Dict[str, np.ndarray]] = None
    
    def local_train(
        self,
        global_weights: Dict[str, np.ndarray]
    ) -> Tuple[Dict[str, np.ndarray], Dict[str, Any], int]:
        """
        Perform local training and compute ARENA metrics.
        
        Args:
            global_weights: Current global model weights
        
        Returns:
            Tuple of:
            - updated_weights: New model weights after local training
            - metrics: Dict containing accuracy, delta_acc, cosine_sim, 
                      spectral_norm, kl_divergence, f1, etc.
            - n_samples: Number of local training samples
        
        Example:
            >>> weights, metrics, n = client.local_train(server.get_global_weights())
            >>> print(f"Delta Acc: {metrics['delta_acc']:.4f}")
            >>> print(f"Cosine Sim: {metrics['cosine_sim']:.4f}")
        """
        from arena_score.utils import (
            compute_spectral_norm, 
            flatten_weights,
            compute_kl_divergence
        )
        
        # Store previous weights for CS computation
        if self.prev_weights is None:
            self.prev_weights = {k: v.copy() for k, v in global_weights.items()}
        
        # Set model to global weights and compute initial metrics
        self.model.set_weights(global_weights)
        initial_preds = self.model.predict_proba(self.X)
        initial_accuracy = self._compute_accuracy(self.model.predict(self.X), self.y)
        
        # Local training
        total_loss = 0.0
        n_batches = 0
        accumulated_grads: Optional[Dict[str, np.ndarray]] = None
        
        for epoch in range(self.local_epochs):
            indices = np.random.permutation(len(self.X))
            
            for start_idx in range(0, len(self.X), self.batch_size):
                end_idx = min(start_idx + self.batch_size, len(self.X))
                batch_indices = indices[start_idx:end_idx]
                
                X_batch = self.X[batch_indices]
                y_batch = self.y[batch_indices]
                
                # Forward pass
                y_pred = self.model.forward(X_batch)
                loss = self._compute_loss(y_batch, y_pred)
                total_loss += loss
                n_batches += 1
                
                # Backward pass
                gradients = self.model.backward(X_batch, y_batch, y_pred)
                
                # Accumulate gradients for analysis
                if accumulated_grads is None:
                    accumulated_grads = {k: v.copy() for k, v in gradients.items()}
                else:
                    for k in gradients:
                        accumulated_grads[k] += gradients[k]
                
                # Update weights
                self.model.update_weights(gradients)
        
        # Get final weights and predictions
        final_weights = self.model.get_weights()
        final_preds = self.model.predict_proba(self.X)
        final_predictions = self.model.predict(self.X)
        final_accuracy = self._compute_accuracy(final_predictions, self.y)
        
        # ===== Compute ARENA Metrics =====
        
        # 1. Delta Accuracy (ΔAcc)
        delta_acc = final_accuracy - initial_accuracy
        
        # 2. Cosine Similarity (CS) - between update and global gradient direction
        update_flat = flatten_weights(final_weights) - flatten_weights(global_weights)
        global_flat = flatten_weights(global_weights) - flatten_weights(self.prev_weights)
        
        if np.linalg.norm(global_flat) > 1e-8:
            cosine_sim = float(np.dot(update_flat, global_flat) / 
                              (np.linalg.norm(update_flat) * np.linalg.norm(global_flat) + 1e-8))
        else:
            cosine_sim = 1.0  # First round or no previous update
        
        # 3. Spectral Norm (SN)
        spectral_norm = compute_spectral_norm(final_weights)
        
        # 4. KL Divergence - detect distribution drift
        kl_divergence = compute_kl_divergence(final_preds, initial_preds)
        
        # 5. Flag potentially corrupted clients
        is_potentially_corrupted = final_accuracy < 0.5 or delta_acc < -0.1
        
        # Compute F1 score
        f1 = self._compute_f1(final_predictions, self.y)
        
        # Store current state for next round
        self.prev_accuracy = final_accuracy
        self.prev_weights = {k: v.copy() for k, v in final_weights.items()}
        
        metrics = {
            'accuracy': final_accuracy,
            'loss': self._compute_loss(self.y, final_preds),
            'avg_loss': total_loss / n_batches if n_batches > 0 else 0,
            'delta_acc': delta_acc,
            'cosine_sim': cosine_sim,
            'spectral_norm': spectral_norm,
            'kl_divergence': kl_divergence,
            'is_potentially_corrupted': is_potentially_corrupted,
            'f1': f1,
            'accumulated_grads': accumulated_grads
        }
        
        return final_weights, metrics, self.n_samples
    
    def _compute_accuracy(self, y_pred: np.ndarray, y_true: np.ndarray) -> float:
        """Compute accuracy."""
        return float(np.mean(y_pred == y_true))
    
    def _compute_loss(self, y_true: np.ndarray, y_pred: np.ndarray, eps: float = 1e-7) -> float:
        """Compute binary cross-entropy loss."""
        y_pred = np.clip(y_pred, eps, 1 - eps)
        return float(-np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred)))
    
    def _compute_f1(self, y_pred: np.ndarray, y_true: np.ndarray) -> float:
        """Compute F1 score."""
        tp = np.sum((y_pred == 1) & (y_true == 1))
        fp = np.sum((y_pred == 1) & (y_true == 0))
        fn = np.sum((y_pred == 0) & (y_true == 1))
        
        precision = tp / (tp + fp + 1e-8)
        recall = tp / (tp + fn + 1e-8)
        f1 = 2 * precision * recall / (precision + recall + 1e-8)
        
        return float(f1)
