"""
ARENA Score Computation Module

Implements the core ARENA Score formula from the research paper:
S_j = α(t) × max(0, ΔAcc_j) + γ(t) × CS_j + η × SN_j/(1 + SN_j)

Where:
- ΔAcc: Local accuracy improvement
- CS: Cosine similarity between client update and global direction
- SN: Spectral norm regularization = log(1 + σ_max(W_j))
- α(t), γ(t): Adaptive time-varying weights
"""

import numpy as np
from typing import Tuple


def compute_adaptive_weights(
    t: int,
    alpha_0: float = 0.7,
    alpha_min: float = 0.3,
    gamma_0: float = 0.3,
    gamma_min: float = 0.5,
    lambda_decay: float = 0.1
) -> Tuple[float, float]:
    """
    Compute time-varying adaptive weights α(t) and γ(t).
    
    From the paper:
    - α(t) = α_min + (α_0 - α_min) × exp(-λt)
    - γ(t) = γ_min + (γ_0 - γ_min) × (1 - exp(-λt))
    
    Args:
        t: Current communication round (0-indexed)
        alpha_0: Initial accuracy weight (default: 0.7)
        alpha_min: Minimum accuracy weight (default: 0.3)
        gamma_0: Initial cosine similarity weight (default: 0.3)
        gamma_min: Minimum cosine similarity weight (default: 0.5)
        lambda_decay: Decay rate (default: 0.1)
    
    Returns:
        Tuple of (alpha_t, gamma_t)
    
    Example:
        >>> alpha_t, gamma_t = compute_adaptive_weights(t=5)
        >>> print(f"Round 5: α={alpha_t:.3f}, γ={gamma_t:.3f}")
    """
    decay_factor = np.exp(-lambda_decay * t)
    
    alpha_t = alpha_min + (alpha_0 - alpha_min) * decay_factor
    gamma_t = gamma_min + (gamma_0 - gamma_min) * (1 - decay_factor)
    
    return float(alpha_t), float(gamma_t)


def compute_arena_score(
    delta_acc: float,
    cosine_sim: float,
    spectral_norm: float,
    alpha_t: float,
    gamma_t: float,
    eta: float = 0.5,
    is_potentially_corrupted: bool = False
) -> float:
    """
    Compute ARENA Score for a client update.
    
    Formula:
    S_j = α(t) × max(0, ΔAcc_j) + γ(t) × CS_j + η × SN_j/(1 + SN_j)
    
    Key improvements:
    - Heavily penalizes negative delta_acc (indicates corrupted training)
    - Normalizes CS to [0, 1] range
    - Applies 90% penalty for potentially corrupted clients
    
    Args:
        delta_acc: Accuracy improvement (final - initial accuracy)
        cosine_sim: Cosine similarity between update and global direction [-1, 1]
        spectral_norm: Spectral norm value log(1 + σ_max)
        alpha_t: Current adaptive weight for accuracy
        gamma_t: Current adaptive weight for cosine similarity
        eta: Spectral norm coefficient (default: 0.5)
        is_potentially_corrupted: Flag for suspected corrupted client
    
    Returns:
        ARENA score (non-negative float)
    
    Example:
        >>> score = compute_arena_score(
        ...     delta_acc=0.05,
        ...     cosine_sim=0.8,
        ...     spectral_norm=2.5,
        ...     alpha_t=0.5,
        ...     gamma_t=0.4
        ... )
        >>> print(f"ARENA Score: {score:.2f}")
    """
    # Accuracy contribution - PENALIZE negative delta_acc heavily
    if delta_acc >= 0:
        acc_term = alpha_t * delta_acc
    else:
        # Negative improvement = likely corrupted, apply strong penalty
        acc_term = alpha_t * delta_acc * 2.0  # Double the penalty
    
    # Cosine similarity contribution (normalized to [0, 1] from [-1, 1])
    cs_normalized = (cosine_sim + 1) / 2  # Map [-1, 1] to [0, 1]
    cs_term = gamma_t * cs_normalized
    
    # Spectral norm contribution (normalized)
    sn_term = eta * (spectral_norm / (1 + spectral_norm))
    
    # Total score (scaled to reasonable range)
    score = 100 * (acc_term + cs_term + sn_term)
    
    # Apply additional penalty for potentially corrupted clients
    if is_potentially_corrupted:
        score *= 0.1  # Reduce score by 90%
    
    return max(0.0, float(score))  # Ensure non-negative score


def detect_anomaly(
    cosine_sim: float,
    kl_divergence: float = 0.0,
    is_potentially_corrupted: bool = False,
    anomaly_threshold: float = -0.5,
    kl_threshold: float = 0.5
) -> bool:
    """
    Detect anomalous client update using multiple criteria.
    
    From the paper (lines 17-18):
    - KL divergence thresholds
    - CS < -0.5 threshold
    
    Args:
        cosine_sim: Cosine similarity value
        kl_divergence: KL divergence between predictions (default: 0.0)
        is_potentially_corrupted: Pre-computed corruption flag
        anomaly_threshold: CS threshold (default: -0.5)
        kl_threshold: KL divergence threshold (default: 0.5)
    
    Returns:
        True if anomaly detected, False otherwise
    
    Example:
        >>> is_anomaly = detect_anomaly(cosine_sim=-0.7, kl_divergence=0.3)
        >>> print(f"Anomaly: {is_anomaly}")  # True (CS < -0.5)
    """
    cs_anomaly = cosine_sim < anomaly_threshold
    kl_anomaly = kl_divergence > kl_threshold
    
    return cs_anomaly or kl_anomaly or is_potentially_corrupted
