"""
ARENA Score Server

Server implementation for ARENA Score federated learning.
Performs adaptive weighted aggregation with anomaly detection.
"""

import numpy as np
from typing import Dict, List, Tuple, Any, Optional, Protocol


class ModelProtocol(Protocol):
    """Protocol defining the required model interface."""
    
    def get_weights(self) -> Dict[str, np.ndarray]: ...
    def set_weights(self, weights: Dict[str, np.ndarray]) -> None: ...
    def copy(self) -> 'ModelProtocol': ...


class ARENAScoreServer:
    """
    ARENA Score Server with adaptive weighted aggregation.
    
    Implements the ARENA Score aggregation formula:
    S_j = α(t) × max(0, ΔAcc_j) + γ(t) × CS_j + η × SN_j/(1 + SN_j)
    
    With time-varying weights:
    - α(t) = α_min + (α_0 - α_min) × exp(-λt)
    - γ(t) = γ_min + (γ_0 - γ_min) × (1 - exp(-λt))
    
    Args:
        global_model: The global model to aggregate updates into
        alpha_0: Initial accuracy weight (default: 0.7)
        alpha_min: Minimum accuracy weight (default: 0.3)
        gamma_0: Initial cosine similarity weight (default: 0.3)
        gamma_min: Minimum cosine similarity weight (default: 0.5)
        eta: Spectral norm coefficient (default: 0.5)
        lambda_decay: Decay rate for adaptive weights (default: 0.1)
        s_min: Minimum score threshold (default: 0)
        anomaly_threshold: CS threshold for anomaly detection (default: -0.5)
        kl_threshold: KL divergence threshold (default: 0.5)
        enable_gradient_recycling: Enable gradient recycling (default: True)
    
    Example:
        >>> server = ARENAScoreServer(
        ...     global_model=my_model,
        ...     alpha_0=0.7,
        ...     eta=0.5
        ... )
        >>> aggregated, info = server.aggregate(client_weights, client_metrics, ...)
    """
    
    def __init__(
        self,
        global_model: ModelProtocol,
        alpha_0: float = 0.7,
        alpha_min: float = 0.3,
        gamma_0: float = 0.3,
        gamma_min: float = 0.5,
        eta: float = 0.5,
        lambda_decay: float = 0.1,
        s_min: float = 0,
        anomaly_threshold: float = -0.5,
        kl_threshold: float = 0.5,
        enable_gradient_recycling: bool = True
    ):
        self.global_model = global_model
        self.alpha_0 = alpha_0
        self.alpha_min = alpha_min
        self.gamma_0 = gamma_0
        self.gamma_min = gamma_min
        self.eta = eta
        self.lambda_decay = lambda_decay
        self.s_min = s_min
        self.anomaly_threshold = anomaly_threshold
        self.kl_threshold = kl_threshold
        self.enable_gradient_recycling = enable_gradient_recycling
        
        # Gradient recycling storage
        self.gradient_cache: Dict[int, Dict[str, np.ndarray]] = {}
        self.current_round = 0
    
    def _compute_adaptive_weights(self, t: int) -> Tuple[float, float]:
        """
        Compute time-varying α(t) and γ(t).
        
        Returns:
            Tuple of (alpha_t, gamma_t)
        """
        from arena_score.score import compute_adaptive_weights
        return compute_adaptive_weights(
            t,
            self.alpha_0, self.alpha_min,
            self.gamma_0, self.gamma_min,
            self.lambda_decay
        )
    
    def _compute_arena_score(
        self,
        delta_acc: float,
        cosine_sim: float,
        spectral_norm: float,
        alpha_t: float,
        gamma_t: float,
        is_potentially_corrupted: bool = False
    ) -> float:
        """Compute ARENA score for a client update."""
        from arena_score.score import compute_arena_score
        return compute_arena_score(
            delta_acc, cosine_sim, spectral_norm,
            alpha_t, gamma_t, self.eta,
            is_potentially_corrupted
        )
    
    def _detect_anomaly(
        self,
        cosine_sim: float,
        kl_divergence: float = 0.0,
        is_potentially_corrupted: bool = False
    ) -> bool:
        """
        Detect anomalous update using multiple criteria.
        
        From the paper:
        - CS < -0.5 threshold
        - KL divergence thresholds
        """
        from arena_score.score import detect_anomaly
        return detect_anomaly(
            cosine_sim, kl_divergence,
            is_potentially_corrupted,
            self.anomaly_threshold, self.kl_threshold
        )
    
    def aggregate(
        self,
        client_weights: List[Dict[str, np.ndarray]],
        client_metrics: List[Dict[str, Any]],
        client_samples: List[int],
        client_ids: List[int],
        participating_clients: Optional[List[int]] = None
    ) -> Tuple[Dict[str, np.ndarray], Dict[str, Any]]:
        """
        Aggregate client updates using ARENA scoring.
        
        Args:
            client_weights: List of weight dictionaries from clients
            client_metrics: List of metric dictionaries from clients
            client_samples: Number of samples per client
            client_ids: Client identifiers
            participating_clients: Optional list of participating client IDs
        
        Returns:
            Tuple of:
            - aggregated_weights: New global model weights
            - aggregation_info: Dict with scores, selected clients, etc.
        
        Example:
            >>> aggregated, info = server.aggregate(
            ...     client_weights, client_metrics, client_samples, client_ids
            ... )
            >>> print(f"Mean score: {info['mean_score']:.2f}")
            >>> print(f"Valid clients: {info['valid_clients']}/{info['total_clients']}")
        """
        self.current_round += 1
        alpha_t, gamma_t = self._compute_adaptive_weights(self.current_round)
        
        # Compute ARENA scores for each client
        scores = []
        is_anomaly = []
        
        for metrics in client_metrics:
            kl_div = metrics.get('kl_divergence', 0.0)
            is_corrupted = metrics.get('is_potentially_corrupted', False)
            
            score = self._compute_arena_score(
                metrics['delta_acc'],
                metrics['cosine_sim'],
                metrics['spectral_norm'],
                alpha_t, gamma_t,
                is_potentially_corrupted=is_corrupted
            )
            
            # Check for anomaly
            anomaly = self._detect_anomaly(
                metrics['cosine_sim'],
                kl_divergence=kl_div,
                is_potentially_corrupted=is_corrupted
            )
            
            if anomaly:
                score = 0.0  # Set score to 0 for anomalous updates
            
            scores.append(score)
            is_anomaly.append(anomaly)
        
        scores = np.array(scores)
        
        # Filter clients by minimum score threshold
        valid_mask = (scores >= self.s_min) & (~np.array(is_anomaly))
        
        # Fallback: if no clients pass, use all non-anomalous
        if not np.any(valid_mask):
            valid_mask = ~np.array(is_anomaly)
        
        # Final fallback: use all clients
        if not np.any(valid_mask):
            valid_mask = np.ones(len(scores), dtype=bool)
        
        # Normalize scores for weighting
        valid_scores = np.where(valid_mask, scores, 0)
        total_score = np.sum(valid_scores)
        
        if total_score > 0:
            weights_normalized = valid_scores / total_score
        else:
            # Fall back to sample-based weighting
            total_samples = sum(n for n, v in zip(client_samples, valid_mask) if v)
            weights_normalized = np.array([
                n / total_samples if v else 0
                for n, v in zip(client_samples, valid_mask)
            ])
        
        # Aggregate weights
        aggregated: Dict[str, np.ndarray] = {}
        for key in client_weights[0]:
            aggregated[key] = np.zeros_like(client_weights[0][key])
        
        for w_client, weight in zip(client_weights, weights_normalized):
            for key in w_client:
                aggregated[key] += w_client[key] * weight
        
        # Gradient recycling: cache gradients for clients
        if self.enable_gradient_recycling:
            for client_id, metrics in zip(client_ids, client_metrics):
                if 'accumulated_grads' in metrics and metrics['accumulated_grads'] is not None:
                    self.gradient_cache[client_id] = metrics['accumulated_grads']
        
        # Update global model
        self.global_model.set_weights(aggregated)
        
        aggregation_info = {
            'round': self.current_round,
            'alpha_t': alpha_t,
            'gamma_t': gamma_t,
            'scores': scores.tolist(),
            'weights_normalized': weights_normalized.tolist(),
            'is_anomaly': is_anomaly,
            'valid_clients': int(np.sum(valid_mask)),
            'total_clients': len(scores),
            'mean_score': float(np.mean(scores)),
            'std_score': float(np.std(scores))
        }
        
        return aggregated, aggregation_info
    
    def get_global_weights(self) -> Dict[str, np.ndarray]:
        """Get current global model weights."""
        return self.global_model.get_weights()
    
    def get_recycled_gradient(self, client_id: int) -> Optional[Dict[str, np.ndarray]]:
        """Get cached gradient for a missing client."""
        return self.gradient_cache.get(client_id)
    
    def reset(self) -> None:
        """Reset server state for a new training run."""
        self.current_round = 0
        self.gradient_cache.clear()
