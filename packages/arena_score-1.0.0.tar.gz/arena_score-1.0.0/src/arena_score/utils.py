"""
ARENA Score Utility Functions

Helper functions for weight manipulation, similarity computation,
and anomaly detection metrics.
"""

import numpy as np
from typing import Dict

# Try Numba for acceleration
try:
    from numba import jit
    HAS_NUMBA = True
except ImportError:
    HAS_NUMBA = False
    def jit(*args, **kwargs):
        """Fallback decorator when Numba is not available."""
        def decorator(func):
            return func
        return decorator


@jit(nopython=True, cache=True)
def _compute_cosine_similarity_numba(a: np.ndarray, b: np.ndarray) -> float:
    """Numba-optimized cosine similarity computation."""
    dot = np.dot(a, b)
    norm_a = np.sqrt(np.dot(a, a))
    norm_b = np.sqrt(np.dot(b, b))
    if norm_a < 1e-8 or norm_b < 1e-8:
        return 0.0
    return dot / (norm_a * norm_b)


def compute_cosine_similarity(
    weights_a: Dict[str, np.ndarray],
    weights_b: Dict[str, np.ndarray]
) -> float:
    """
    Compute cosine similarity between two weight dictionaries.
    
    Args:
        weights_a: First weight dictionary
        weights_b: Second weight dictionary
    
    Returns:
        Cosine similarity in range [-1, 1]
    
    Example:
        >>> cs = compute_cosine_similarity(model_a.get_weights(), model_b.get_weights())
        >>> print(f"Similarity: {cs:.4f}")
    """
    flat_a = flatten_weights(weights_a)
    flat_b = flatten_weights(weights_b)
    
    if HAS_NUMBA:
        return float(_compute_cosine_similarity_numba(flat_a, flat_b))
    
    # Fallback pure numpy implementation
    dot = np.dot(flat_a, flat_b)
    norm_a = np.linalg.norm(flat_a)
    norm_b = np.linalg.norm(flat_b)
    
    if norm_a < 1e-8 or norm_b < 1e-8:
        return 0.0
    
    return float(dot / (norm_a * norm_b))


def compute_spectral_norm(weights: Dict[str, np.ndarray]) -> float:
    """
    Compute spectral norm regularization term.
    
    Formula: SN_j = log(1 + σ_max(W_j))
    
    Where σ_max is the maximum singular value of the weight matrix.
    
    Args:
        weights: Dictionary of weight arrays
    
    Returns:
        Spectral norm value
    
    Example:
        >>> sn = compute_spectral_norm(model.get_weights())
        >>> print(f"Spectral Norm: {sn:.4f}")
    """
    max_singular = 0.0
    
    for key, w in weights.items():
        if len(w.shape) == 2:
            # Compute largest singular value for 2D matrices
            try:
                s = np.linalg.svd(w, compute_uv=False)
                max_singular = max(max_singular, s[0])
            except np.linalg.LinAlgError:
                max_singular = max(max_singular, np.max(np.abs(w)))
        else:
            max_singular = max(max_singular, np.max(np.abs(w)))
    
    return float(np.log(1 + max_singular))


def compute_kl_divergence(
    p: np.ndarray,
    q: np.ndarray,
    eps: float = 1e-8
) -> float:
    """
    Compute KL divergence between two probability distributions.
    
    Used for anomaly detection as per the paper (lines 17-18).
    
    Args:
        p: Prediction distribution after local training
        q: Prediction distribution before training (from global model)
        eps: Small epsilon for numerical stability
    
    Returns:
        KL divergence value (higher = more divergent = potentially corrupted)
    
    Example:
        >>> kl = compute_kl_divergence(new_preds, old_preds)
        >>> if kl > 0.5:
        ...     print("Potential anomaly detected")
    """
    p = np.clip(p, eps, 1 - eps)
    q = np.clip(q, eps, 1 - eps)
    
    # For binary classification, compute symmetric KL divergence
    kl_pq = np.mean(p * np.log(p / q) + (1 - p) * np.log((1 - p) / (1 - q)))
    
    return float(kl_pq)


def flatten_weights(weights: Dict[str, np.ndarray]) -> np.ndarray:
    """
    Flatten all weights into a single vector.
    
    Args:
        weights: Dictionary of weight arrays
    
    Returns:
        1D numpy array containing all flattened weights
    
    Example:
        >>> flat = flatten_weights(model.get_weights())
        >>> print(f"Total parameters: {len(flat)}")
    """
    return np.concatenate([w.flatten() for w in weights.values()])


def unflatten_weights(
    flat: np.ndarray,
    template: Dict[str, np.ndarray]
) -> Dict[str, np.ndarray]:
    """
    Unflatten vector back to weight dictionary.
    
    Args:
        flat: 1D array of flattened weights
        template: Template dictionary with correct shapes
    
    Returns:
        Weight dictionary with original shapes
    
    Example:
        >>> flat = flatten_weights(weights)
        >>> restored = unflatten_weights(flat, weights)
    """
    result = {}
    idx = 0
    
    for key, w in template.items():
        size = w.size
        result[key] = flat[idx:idx + size].reshape(w.shape)
        idx += size
    
    return result


def compute_weight_distance(
    weights_a: Dict[str, np.ndarray],
    weights_b: Dict[str, np.ndarray]
) -> float:
    """
    Compute L2 distance between two weight dictionaries.
    
    Args:
        weights_a: First weight dictionary
        weights_b: Second weight dictionary
    
    Returns:
        L2 distance (Euclidean norm of difference)
    
    Example:
        >>> dist = compute_weight_distance(w1, w2)
        >>> print(f"Weight distance: {dist:.4f}")
    """
    total_dist = 0.0
    
    for key in weights_a:
        if key in weights_b:
            diff = weights_a[key].flatten() - weights_b[key].flatten()
            total_dist += np.sum(diff ** 2)
    
    return float(np.sqrt(total_dist))
