# argpy 🕳️🧩

Biblioteca Python para criar ARGs (Alternate Reality Games).

## Instalação
```bash
pip install argpy
