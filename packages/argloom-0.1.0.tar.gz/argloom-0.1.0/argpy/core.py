class ARG:
    def __init__(self, name: str):
        self.name = name
        self.puzzles = []
        self.events = []

    def add_puzzle(self, puzzle):
        self.puzzles.append(puzzle)

    def add_event(self, event):
        self.events.append(event)

    def start(self):
        return f"ARG '{self.name}' iniciado com {len(self.puzzles)} puzzles."
