import base64

class Cipher:
    @staticmethod
    def encode_base64(text: str) -> str:
        return base64.b64encode(text.encode()).decode()

    @staticmethod
    def decode_base64(text: str) -> str:
        return base64.b64decode(text.encode()).decode()
