from datetime import datetime

class Event:
    def __init__(self, name: str, trigger_time: datetime):
        self.name = name
        self.trigger_time = trigger_time

    def is_active(self) -> bool:
        return datetime.now() >= self.trigger_time
