class Puzzle:
    def __init__(self, title: str, solution: str):
        self.title = title
        self.solution = solution

    def check(self, answer: str) -> bool:
        return answer.strip().lower() == self.solution.strip().lower()
