__all__ = [
    "check_resource_name",
]


from tugboat.analyzers.kubernetes import check_resource_name
