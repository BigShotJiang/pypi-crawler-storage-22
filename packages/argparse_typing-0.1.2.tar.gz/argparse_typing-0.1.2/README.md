# argparse-typing

This is a fork of Python's standard library module `argparse.pyi`.

## License Information

This project contains code from two sources:

1. **Original Python module** - Licensed under the PSF License Agreement
   (see [LICENSE.PSF.txt](https://github.com/MagIlyasDOMA/argparse-typing/blob/main/LICENSE.PSF.txt))
   Copyright (c) 2001-2025 Python Software Foundation

2. **Modifications and additions** - Licensed under the BSD 3-Clause License
   (see [LICENSE](https://github.com/MagIlyasDOMA/argparse-typing/blob/main/LICENSE))
   Copyright (c) 2026 Маг Ильяс DOMA (MagIlyasDOMA)

The original PSF-licensed code remains under the PSF license. All new code
and modifications are under the BSD license. You may use this package under
either license or both, depending on which parts of the code you are using.

## Original Source
The original module can be found in the [CPython repository](https://github.com/python/cpython).