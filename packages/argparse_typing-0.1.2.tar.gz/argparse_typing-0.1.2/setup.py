#!/usr/bin/env python
from setuptools import setup
from pathlib import Path

# Чтение README.md
def readme():
    readme_path = Path(__file__).parent / "README.md"
    if readme_path.exists():
        return readme_path.read_text(encoding="utf-8")
    return ""

# Чтение requirements для dev
def requirements(filename):
    req_path = Path(__file__).parent / filename
    if req_path.exists():
        return req_path.read_text().splitlines()
    return []

# Очистка старых сборок (опционально)
import shutil
import os
def clean():
    dirs_to_clean = ['build', 'dist', '*.egg-info']
    for dir_pattern in dirs_to_clean:
        if os.path.exists(dir_pattern):
            shutil.rmtree(dir_pattern)

clean()

setup(
    name="argparse-typing",
    version="0.1.2",
    description="Type stubs for argparse with dual PSF and BSD license",
    long_description=readme(),
    long_description_content_type="text/markdown",
    author="Маг Ильяс DOMA (MagIlyasDOMA)",
    license="BSD",
    python_requires=">=3.9",
    keywords=["argparse", "type-stubs", "typing", "cli"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: BSD License",
        "License :: OSI Approved :: Python Software Foundation License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Typing :: Stubs Only",
    ],
    install_requires=[
        "typing-extensions>=4.0.0",
    ],
    extras_require={
        "dev": requirements('dev_requirements.txt'),
    },
    project_urls={
        "Homepage": "https://github.com/MagIlyasDOMA/argparse-typing",
        "Repository": "https://github.com/MagIlyasDOMA/argparse-typing.git",
    },
    # Для стабов лучше использовать package_data
    packages=[],  # Пустой список, так как это стабы
    package_data={
        "": ["*.pyi", "py.typed"],
    },
    # Или если файлы в корне:
    py_modules=["argparse"],  # Для .py файлов
    data_files=[('', ['argparse.pyi', 'py.typed'])],
    zip_safe=False,
)