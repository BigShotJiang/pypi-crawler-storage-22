"""Argus - Vision AI dataset toolkit."""

__version__ = "1.5.1"
