"""Entry point for python -m argus."""

from argus.cli import app

if __name__ == "__main__":
    app()
