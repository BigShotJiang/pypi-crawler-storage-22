# Argus 👁️
**Anti-Tamper Log Evidence Tool**

Argus is a Python library and CLI that proves whether data was altered after creation.
It generates cryptographic receipts for logs and files, **designed for** audits, forensics, and dispute resolution.

---

## 🚫 What Argus is NOT
- ❌ **Not a prevention system**: It does not stop attacks.
- ❌ **Not a logging stack**: It does not replace ELK, Datadog, or CloudWatch.
- ❌ **Not for everyone**.

> **If you’ve never had to prove logs in a dispute, you probably don’t need this.**

---

## 📦 Installation
```bash
pip install argus-seal
```
**Note**: The package is named `argus-seal` on PyPI, but the command and module are simply `argus`.

No extra dependencies. Just pure, fast forensic integrity.

---

## ⚡ Quick Start

### 1. Python (Embed)
```python
from argus import seal

# 1. Your normal logs
logs = [{"user": "alice", "amt": 50}, {"user": "bob", "amt": 30}]

# 2. Add the receipt (The Sidecar)
evidence = seal(data=logs, schema="FINANCIAL_V1")
```

### 2. Advanced API (Merkle Proofs)
Stateless verification for microservices.
```python
from argus import verify, verify_proof, extract_proof, init_project

# 1. Full Verification (Auto-detects format)
is_valid = verify(evidence)

# 2. Extract Proof (Specific Item)
proof = extract_proof(evidence, index=0)

# 3. Stateless Verification (Pure Math)
# Verify just that single log against the root hash
is_valid = verify_proof(
    data=logs[0], 
    proof=proof["proof"], 
    root=evidence["seal"]["root_hash"]
)

# 4. Programmatic Init
init_project()
```

### 3. CLI (Batch / Ops)
```bash
# Seal (Generate Evidence)
$ argus seal ./logs/access.log -o proof.json

# Verify (Audit)
$ argus verify --receipt proof.json
```

---

## 🎯 When should you use Argus?
1.  **Regulated environments** (GDPR / SOX / ISO 27001).
2.  **Audit-heavy SaaS** or security operations.
3.  **Legal or forensic disputes** involving logs.

---

## 📚 Documentation
*   📜 [**Technical Spec**](docs/SPEC.md) – The full 88-byte seal and protocol standard.
*   ⚖️ [**Legal Model**](docs/LEGAL.md) – Evidence & liability boundaries.
*   🏗️ [**Deployment Patterns**](docs/DEPLOYMENT.md) – Production architecture.
*   💼 [**Business Rationale**](docs/WHY.md) – ROI and risk mitigation.
*   🗺️ [**Roadmap**](docs/ROADMAP.md) – Future evolution.

---

## 🤝 Community
*   [Contributing Guide](docs/CONTRIBUTING.md)
*   [Changelog](docs/CHANGELOG.md)

---

**Argus is not about truth.**
**It’s about enforcing the cost of lies.**
