# Top-level API (The "Hall" Interface)
from .api import (
    seal, 
    verify, 
    verify_proof, 
    extract_proof, 
    init_project, 
    load_data
)

# Core Structures (For Power Users who want to peek into the "Kitchen")
from .core.merkle import ArgusMerkleTree
from .core.envelope import ArgusSeal

# explicit export list
__all__ = [
    "seal", 
    "verify", 
    "verify_proof", 
    "extract_proof", 
    "init_project", 
    "load_data",
    "ArgusMerkleTree", 
    "ArgusSeal"
]

try:
    from importlib.metadata import version, PackageNotFoundError
    __version__ = version("argus-seal")
except ImportError:
    # Backport for Python < 3.8
    try:
        from importlib_metadata import version, PackageNotFoundError
        __version__ = version("argus-seal")
    except ImportError:
         __version__ = "0.0.0-unknown"
except PackageNotFoundError:
    __version__ = "0.0.0-unknown"
