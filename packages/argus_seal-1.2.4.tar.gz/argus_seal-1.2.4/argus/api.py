from typing import List, Dict, Union, Optional
from argus.core.merkle import ArgusMerkleTree
from argus.core.envelope import ArgusSeal
import base64
import time

def seal(data: Union[List[Dict], List[str], bytes], 
         schema: str = "GENERIC", 
         secret: Optional[str] = None,
         detached: bool = False) -> Dict:
    """
    High-level API to seal data.
    
    Args:
        data: List of log entries (dicts/strings) or raw bytes.
        schema: Schema identifier (e.g. "FINANCIAL_V1").
        secret: Optional secret for HMAC/Salting (not yet fully implemented in PoC).
        detached: If True, the return value will not contain the original data.
        
    Returns:
        Dict: The Evidence Package containing the Seal and (optionally) the Data.
    """
    # 1. Normalize Data
    # If list of dicts/strings, use Merkle Tree
    if isinstance(data, list):
        # We need to serialize them for the Merkle Tree
        # For simplicity in this API, we assume the user passes ready-to-use data
        # or we serialize dicts to canonical JSON strings.
        import json
        processed_logs = []
        original_logs = []
        
        for item in data:
            if isinstance(item, dict):
                # Canonical JSON
                s_item = json.dumps(item, sort_keys=True, separators=(',', ':'))
                processed_logs.append(s_item)
                original_logs.append(item) # Keep original structure for return
            else:
                processed_logs.append(str(item))
                original_logs.append(item)
                
        tree = ArgusMerkleTree(processed_logs)
        root = tree.get_root()
        count = len(data)
        
    else:
        # Single binary blob / Dict
        if isinstance(data, dict):
             import json
             processed_logs = [json.dumps(data, sort_keys=True, separators=(',', ':'))]
             original_logs = [data]
        else:
             processed_logs = [data]
             original_logs = [data]
        tree = ArgusMerkleTree(processed_logs)
        root = tree.get_root()
        count = 1

    # 2. Create Seal (The 88 Bytes)
    # SchemaID logic: simple hash of the string for now
    import hashlib
    schema_id = hashlib.sha256(schema.encode()).digest()
    
    # We create a "Seal" object just to get the binary format if needed, 
    # but the JSON return usually splits headers.
    
    timestamp = int(time.time() * 1_000_000_000)

    # 3. Generate Individual Proofs (Full Receipt Mode)
    receipts_list = []
    import base64
    
    for i in range(count):
        proof = tree.get_proof(i)
        original_item = original_logs[i]
        
        if detached:
            log_stored = None
        elif isinstance(original_item, bytes):
            log_stored = f"base64:{base64.b64encode(original_item).decode('utf-8')}"
        else:
            log_stored = original_item
            
        receipts_list.append({
            "index": i,
            "log": log_stored,
            "receipt": proof
        })
    
    evidence = {
        "seal": {
            "magic": "ARGS",
            "version": "v1.1",
            "schema": schema,
            "timestamp_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(timestamp / 1e9)),
            "timestamp_int": timestamp,
            "root_hash": root,
            "count": count,
            "detached": detached
        },
        "data": None if detached else original_logs,
        "receipts": receipts_list
    }
    
    return evidence

def verify(receipt: Dict, data: Optional[Union[List, bytes]] = None) -> bool:
    """
    Verifies an evidence package.
    
    Args:
        receipt: The Argus receipt/evidence dictionary.
        data: The original data (required if receipt is detached).
    """
    # 1. Normalize Receipt Input (Polymorphic Behavior)
    receipt_data = None
    sealed_root = None

    if isinstance(receipt, str):
        # Case A: Only the Root Hash provided
        sealed_root = receipt
        # Data must be provided externally
        if data is None:
            return False
        receipt_data = data
        
    elif isinstance(receipt, dict):
        # Case B: Full Receipt (Start with standard assumption)
        sealed_root = receipt.get("seal", {}).get("root_hash")
        receipt_data = receipt.get("data")
        
        # Case C: Just the Seal Object (e.g. receipt['seal'])
        if not sealed_root:
            # Maybe the user passed the inner seal dict directly?
            sealed_root = receipt.get("root_hash")
        
        # Determine Data Source
        if receipt_data is None:
            if data is None:
                return False
            receipt_data = data
            
    if not sealed_root:
        return False
        
    # 2. Recompute Root
    # Use the same logic as seal
    processed_logs = []
    
    # If data passed as list of dicts/strings matches the API 'seal' input format
    if isinstance(receipt_data, list):
         for item in receipt_data:
            if isinstance(item, dict):
                import json
                s_item = json.dumps(item, sort_keys=True, separators=(',', ':'))
                processed_logs.append(s_item)
            else:
                processed_logs.append(str(item))
                
         tree = ArgusMerkleTree(processed_logs)
         calc_root = tree.get_root()
         
    else:
         # Binary/Single Item
         # Note: If CLI passes file content, it might be bytes or list of bytes
         # Need consistent handling.
         processed_logs = [receipt_data]
         tree = ArgusMerkleTree(processed_logs)
         calc_root = tree.get_root()
    
    return calc_root == sealed_root

from argus.core.verify import verify_receipt

def verify_proof(data: Union[str, bytes], proof: Dict, root: Optional[str] = None) -> bool:
    """
    Verifies a specific Merkle Proof (individual receipt) against a root.
    
    Args:
        data: The original log entry.
        proof: The proof dictionary (contains 'path', 'batch_ref', 'index').
        root: Optional trusted root. If None, uses 'batch_ref' from proof.
    """
    if root is None:
        root = proof.get("batch_ref")
        
    if not root:
        return False
        
    # Serialize data if needed (consistent with CLI)
    import json
    if isinstance(data, (dict, list)):
        log_data = json.dumps(data, sort_keys=True, separators=(',', ':')).encode('utf-8')
    elif isinstance(data, str):
        log_data = data.encode('utf-8')
    else:
        log_data = data
        
    return verify_receipt(log_data, proof['path'], root)

def extract_proof(receipt: Dict, index: int) -> Dict:
    """
    Extracts a single proof from a Master Receipt.
    
    Args:
        receipt: The Master Receipt dictionary.
        index: The index of the log to extract.
        
    Returns:
        Dict: An individual evidence package {'data': ..., 'proof': ...}
    """
    receipts_list = receipt.get("receipts", [])
    target = next((r for r in receipts_list if r["index"] == index), None)
    
    if not target:
        raise ValueError(f"Log index {index} not found in receipt.")
        
    root_hash = receipt.get("seal", {}).get("root_hash") or receipt.get("root_hash")
    target_log = target["log"]
    
    # Handle Base64 encoded logs in receipt
    import json
    if isinstance(target_log, str) and target_log.startswith("base64:"):
         # We keep it as is for the export, or decode?
         # CLI behavior: tries to decode if it's a JSON string, else keeps as is.
         pass
         
    # Try to parse if it's a JSON string
    try:
         if isinstance(target_log, str) and not target_log.startswith("base64:"):
            target_log_obj = json.loads(target_log)
         else:
            target_log_obj = target_log
    except:
         target_log_obj = target_log

    return {
        "argos_spec": "v1.0",
        "data": target_log_obj.get("payload", target_log_obj) if isinstance(target_log_obj, dict) else target_log_obj,
        "proof": {
            "batch_ref": root_hash,
            "path": target["receipt"],
            "index": target["index"],
            "schema_id": target_log_obj.get("header", {}).get("schema_id") if isinstance(target_log_obj, dict) else None
        }
    }

# -----------------------------------------------------------------------------
# Utilities & Parity
# -----------------------------------------------------------------------------
import os
import json
from argus.utils.serializer import read_logs_from_file

def load_data(source: str, schema_config: Optional[Dict] = None) -> List[Union[str, bytes]]:
    """
    Smart loads data from a file, directory, or JSON list file.
    Matches CLI 'read_logs_from_file' behavior.
    
    Args:
        source: Path to a file or directory.
        schema_config: Optional schema configuration (for filtering/enveloping).
        
    Returns:
        List of serialized canonical strings or bytes.
    """
    return read_logs_from_file(source, schema_config=schema_config)

def init_project(path: str = ".", config: Optional[Dict] = None, force: bool = False) -> str:
    """
    Initializes an Argus project by creating a configuration file.
    
    Args:
        path: Directory to initialize (default: current directory).
        config: Custom configuration dictionary (optional).
        force: If True, overwrite existing config file.
        
    Returns:
        str: Path to the created config file.
    """
    default_config = {
        "version": "1.0",
        "algorithm": "sha256",
        "input_pattern": "./logs/*.json",
        "output_receipts": "./receipts.json",
        "output_root": "./root.txt",
        "ordered": False,  # False = Set-Based (Sorts Leaves), True = Sequence-Based (Input Order)
        "schema": {
            "version": "v1.0",
            "fields": []  # Empty means "All Fields" (Backward Compatibility)
        }
    }
    
    if config:
        default_config.update(config)
        
    target_file = os.path.join(path, "argus.config.json")
    
    if os.path.exists(target_file) and not force:
        raise FileExistsError(f"{target_file} already exists. Use force=True to overwrite.")

    with open(target_file, "w") as f:
        json.dump(default_config, f, indent=2)
        
    return target_file
