import argparse
import sys
import os
import json
import base64
from argus.utils.serializer import read_logs_from_file
from argus.core.merkle import ArgusMerkleTree
from argus.core.verify import verify_receipt


class Color:
    GREEN = '\033[92m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

    @staticmethod
    def style(text, *styles):
        if not sys.stdout.isatty():
            return text
        return "".join(styles) + text + Color.RESET

def init(args):
    """
    Initializes an Argus project by creating a configuration file.
    """
    config = {
        "version": "1.0",
        "algorithm": "sha256",
        "input_pattern": "./logs/*.json",
        "output_receipts": "./receipts.json",
        "output_root": "./root.txt",
        "ordered": False,  # False = Set-Based (Sorts Leaves), True = Sequence-Based (Input Order)
        "schema": {
            "version": "v1.0",
            "fields": []  # Empty means "All Fields" (Backward Compatibility)
        }
    }
    
    target_file = "argus.config.json"
    if os.path.exists(target_file) and not args.force:
        print(f"Error: {target_file} already exists. Use -f to overwrite.", file=sys.stderr)
        sys.exit(1)

    with open(target_file, "w") as f:
        json.dump(config, f, indent=2)

    if not args.quiet:
        print(f"Initialized Argus project: {target_file}")

def issue(args):
    try:
        # Schema Loading
        schema_config = None
        ordered_mode = False # Default to Unordered (Set-Based)

        if os.path.exists("argus.config.json"):
            with open("argus.config.json", "r") as f:
                config = json.load(f)
                schema_config = config.get("schema")
                ordered_mode = config.get("ordered", False)

        # CLI Override
        if getattr(args, "ordered", False):
            ordered_mode = True

        # Support generic inputs: Files, Folders, JSON Logs
        logs = read_logs_from_file(args.log_file, schema_config=schema_config)
        
        # Initialize Tree with chosen algorithm
        # Set-Based (Unordered) -> sort_leaves=True
        # Sequence-Based (Ordered) -> sort_leaves=False
        sort_leaves = not ordered_mode
        tree = ArgusMerkleTree(logs, algorithm=args.algo, sort_leaves=sort_leaves)
        root = tree.get_root()

        # Generate receipt
        receipts = {
            "root_hash": root,
            "logs_count": len(logs),
            "version": "1.0",
            "algorithm": args.algo,
            "receipts": []
        }

        # Progress logic
        iterator = range(len(logs))
        if sys.stdout.isatty() and not args.quiet:
            print(f"Generating Receipts for {len(logs)} items...", file=sys.stderr)

        for i in iterator:
            proof = tree.get_proof(i)
            
            # Serialize Log Content (Handle Binary)
            original_log = logs[i]
            if args.detached:
                log_stored = None
            elif isinstance(original_log, bytes):
                # Encode binary as Base64 for JSON storage
                log_stored = f"base64:{base64.b64encode(original_log).decode('utf-8')}"
            else:
                log_stored = original_log

            receipts["receipts"].append({
                "index": i,
                "log": log_stored,
                "receipt": proof
            })

        # Save outputs
        with open(args.output_receipt, "w") as f:
            json.dump(receipts, f, indent=2, ensure_ascii=False)
        
        with open(args.output_root, "w") as f:
            f.write(root)

        if not args.quiet:
            # Colorized Success Message
            status = Color.style("Success!", Color.GREEN, Color.BOLD)
            root_display = Color.style(root, Color.BOLD)
            print(f"{status} Root Hash: {root_display}")

    except Exception as e:
        if args.json:
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def export_receipt(args):
    try:
        # Load Master Receipt
        with open(args.receipt, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        target_index = args.index
        receipts = data.get("receipts", [])
        
        # Find the receipt
        target = next((r for r in receipts if r["index"] == target_index), None)
        if not target:
            raise ValueError(f"Log index {target_index} not found.")

        # Get root hash
        root_hash = None
        if args.root:
            if os.path.exists(args.root):
                 with open(args.root, "r") as f:
                    root_hash = f.read().strip()
            else:
                 root_hash = args.root
        
        if not root_hash:
            root_hash = data.get("root_hash")

        algo = data.get("algorithm", "sha256")

        # Construct Individual Receipt (Standard Customer Receipt)
        # Parse data if it is a stringified JSON (Legacy/String mode)
        target_log = target["log"]
        try:
             # If target_log is a JSON string/Envelope, load it
             if isinstance(target_log, str) and not target_log.startswith("base64:"):
                target_log_obj = json.loads(target_log)
             else:
                target_log_obj = target_log
        except:
             target_log_obj = target_log

        # Map to Standard Structure
        individual_receipt = {
            "argos_spec": "v1.0",
            "data": target_log_obj.get("payload", target_log_obj) if isinstance(target_log_obj, dict) else target_log_obj,
            "proof": {
                "batch_ref": root_hash, # Usually anchor ref, but using Root for now
                "path": target["receipt"],
                "index": target["index"],
                "schema_id": target_log_obj.get("header", {}).get("schema_id") if isinstance(target_log_obj, dict) else None
            }
        }

        # Output
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(individual_receipt, f, indent=2, ensure_ascii=False)
        
        if args.json:
            print(json.dumps({"status": "exported", "file": args.out}))

    except Exception as e:
        if args.json:
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def verify_cmd(args):
    try:
        # Load Receipt
        with open(args.receipt, "r", encoding="utf-8") as f:
            receipt_data = json.load(f)
        
        algo = receipt_data.get("algorithm", "sha256")
        
        # Auto-detect Receipt Type
        if "receipts" in receipt_data:
            # Type 1: Master Receipt
            receipts_list = receipt_data["receipts"]
            # Verify FIRST item for simple command (or loop all? Usually just verification of specific receipt)
            # For CLI usability, we verify ALL in the list? Or just the first one?
            # Original behavior verified index 0.
            # To be robust, let's verify ALL.
            targets = receipts_list
        
        elif "proof" in receipt_data:
            # Type 2: Individual Receipt (Exported Evidence)
            # Format: { "data": ..., "proof": { "path": ... } }
            targets = [{
                "log": receipt_data["data"],
                "receipt": receipt_data["proof"]["path"],
                "index": receipt_data["proof"].get("index")
            }]
        
        else:
            raise ValueError("Unknown receipt format.")

        # Load Root
        root = None
        if args.root:
            if os.path.exists(args.root):
                 with open(args.root, "r") as f:
                    root = f.read().strip()
            else:
                 root = args.root
        
        if not root:
            root = receipt_data.get("root_hash")
        
        # Fallback for Individual Receipts
        if not root and "proof" in receipt_data:
            root = receipt_data["proof"].get("batch_ref")
            
        if not root:
             raise ValueError("Root hash not found. Provide --root argument.")
        else:
            # If verification is running against INTERNAL root (no --root provided), warn the user.
            if not args.root and not args.quiet and not args.json:
                warn_msg = Color.style("WARNING: Verifying against embedded root. For legal proof, provide external anchor with --root.", Color.RED)
                print(warn_msg, file=sys.stderr)

        # Load External Data for Detached Verification
        external_logs = None
        if args.data:
            external_logs = read_logs_from_file(args.data) # Re-use the smart loader

        # Verify Loop
        for item in targets:
            log_content = item["log"]
            proof_path = item["receipt"]
            index = item.get("index", 0) # Default to 0?

            # Handle Detached Mode
            if log_content is None:
                if not external_logs:
                    raise ValueError(f"Receipt is detached (Index {index}). Provide --data.")
                
                # We need to find the matching log. 
                # If master receipt list, index matches list index?
                # If exported receipt, it has "index" field.
                if index < len(external_logs):
                    log_content = external_logs[index]
                else:
                     raise ValueError(f"Data index out of range: {index}")

            # Decode Binary if needed
            if isinstance(log_content, str) and log_content.startswith("base64:"):
                # Decode base64
                b64_str = log_content.split("base64:", 1)[1]
                log_data = base64.b64decode(b64_str)
            else:
                log_data = log_content

            # Canonical Serialization for JSON objects
            if isinstance(log_data, (dict, list)):
                log_data = json.dumps(log_data, sort_keys=True, separators=(',', ':')).encode('utf-8')
            elif isinstance(log_data, str):
                log_data = log_data.encode('utf-8')

            if not verify_receipt(log_data, proof_path, root, algorithm=algo):
                if args.json:
                    print(json.dumps({"valid": False, "index": item.get("index")}))
                else:
                    print(f"[{Color.style('FAIL', Color.RED, Color.BOLD)}] Tamper Detected (Index: {item.get('index')})", file=sys.stderr)
                sys.exit(1)

        if args.json:
            print(json.dumps({"valid": True}))
            sys.exit(0)
        else:
            print(f"[{Color.style('PASS', Color.GREEN, Color.BOLD)}] Integrity Verified")
            sys.exit(0)

    except Exception as e:
        if args.json:
            print(json.dumps({"error": str(e), "valid": False}))
        else:
            print(f"[{Color.style('ERROR', Color.RED)}] {e}", file=sys.stderr)
        sys.exit(1)


CUSTOM_HELP_TEXT = """
Argus: Anti-Tamper Log Evidence Tool
"The standard for forensic data integrity."

Usage:
    argus [OPTIONS] COMMAND [ARGS]...

Commands:
    seal    Seal logs/files and generate forensic evidence.
    verify  Verify the integrity of a seal against a root.
    export  Extract a specific receipt for third-party audit.
    init    Initialize a workspace config.

Quick Reference:
    1. Seal (Create Evidence):
       $ argus seal ./logs/access.log -o evidence.json

    2. Verify (Audit):
       $ argus verify --receipt evidence.json

Options:
    -h, --help  Show this help message.
    --json      Output machine-readable JSON.
    -q, --quiet Suppress status messages.
"""

def main():
    if "-h" in sys.argv or "--help" in sys.argv:
        if len(sys.argv) == 2:
            print(CUSTOM_HELP_TEXT)
            sys.exit(0)

    # Parent parser for global arguments
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("--json", action="store_true", help="Output JSON")
    parent_parser.add_argument("-q", "--quiet", action="store_true", help="Quiet mode")

    # Main parser
    parser = argparse.ArgumentParser(description="Argus", add_help=False)
    subparsers = parser.add_subparsers(dest="command")

    # Init
    init_parser = subparsers.add_parser("init", parents=[parent_parser])
    init_parser.add_argument("-f", "--force", action="store_true", help="Overwrite existing config")
    init_parser.set_defaults(func=init)

    # Issue & Seal (Alias)
    for cmd in ["issue", "seal"]:
        issue_parser = subparsers.add_parser(cmd, parents=[parent_parser])
        issue_parser.add_argument("log_file", help="Input file or directory")
        issue_parser.add_argument("-o", "--out", dest="output_receipt", default="receipts.json")
        issue_parser.add_argument("-r", "--root-out", dest="output_root", default="root.txt")
        issue_parser.add_argument("--algo", default="sha256", choices=["sha256"])
        issue_parser.add_argument("--ordered", action="store_true", help="Enforce input order (Sequence-Based)")
        issue_parser.add_argument("--detached", action="store_true", help="Do not embed data in receipt (Detached Mode)")
        issue_parser.set_defaults(func=issue)

    # Verify
    verify_parser = subparsers.add_parser("verify", parents=[parent_parser])
    verify_parser.add_argument("--receipt", required=True)
    verify_parser.add_argument("--root", required=False)
    verify_parser.add_argument("--data", required=False, help="Original data file/dir for detached verification")
    verify_parser.set_defaults(func=verify_cmd)

    # Export & Export-Proof
    for cmd in ["export", "export-proof"]:
        export_parser = subparsers.add_parser(cmd, parents=[parent_parser])
        export_parser.add_argument("--receipt", required=True, default="receipts.json")
        export_parser.add_argument("--index", required=True, type=int)
        export_parser.add_argument("-o", "--out", required=True)
        export_parser.add_argument("--root", required=False)
        export_parser.set_defaults(func=export_receipt)

    # Parse arguments strictly
    args = parser.parse_args()
    
    if args.command is None:
        print(CUSTOM_HELP_TEXT)
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()