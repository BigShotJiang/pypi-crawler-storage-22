import struct
import time
from typing import Optional
import hashlib

class ArgusSeal:
    """
    Argus Digital Seal (v1.1)
    The 88-byte binary header for forensic evidence.
    Reference: SPEC.md Section 3
    """
    MAGIC = b'ARGS'
    VERSION = 0x01010000  # v1.1.0

    def __init__(self, 
                 payload: bytes, 
                 schema_id: bytes, 
                 timestamp: int = None,
                 version: int = VERSION,
                 flags: int = 0,
                 algo_id: int = 1): # Default 1 (SHA-256)
        
        self.payload = payload
        self.schema_id = schema_id 
        # Time Anchor: Unix Epoch (High 32) + Monotonic Counter (Low 32)
        # Note: Scoped per-stream to prevent distributed concurrency issues.
        self.timestamp = timestamp if timestamp is not None else int(time.time() * 1_000_000_000)
        self.version = version
        self.flags = flags # Compliance Modes: Redaction (Bit 1), Ordering (Bit 0)
        self.algo_id = algo_id
        self.reserved = b'\x00\x00\x00'

        if len(self.schema_id) != 32:
            raise ValueError(f"Schema ID must be 32 bytes, got {len(self.schema_id)}")

    @property
    def merkle_root(self) -> bytes:
        """
        Calculates the Merkle Root of the Payload.
        """
        # TODO: Use algo_id to select hasher. For now, hardcoded Keccak as per MVP.
        return hashlib.sha256(hashlib.sha256(self.payload).digest()).digest()

    def pack(self) -> bytes:
        """
        Serializes the envelope to the v1.1 standard binary format.
        """
        root = self.merkle_root
        
        # Struct Format v1.1 (88 Bytes):
        # 4s : Magic (4)
        # I  : Version (4)
        # 32s: SchemaID (32)
        # Q  : Timestamp (8)
        # 32s: MerkleRoot (32)
        # I  : Flags (4)
        # B  : AlgoID (1)
        # 3s : Reserved (3)
        fmt = ">4sI32sQ32sIB3s"
        
        header = struct.pack(fmt, 
                             self.MAGIC, 
                             self.version, 
                             self.schema_id, 
                             self.timestamp, 
                             root, 
                             self.flags,
                             self.algo_id,
                             self.reserved)
        
        return header + self.payload

    @property
    def is_ordered(self) -> bool:
        """Bit 0: Ordered (1) vs Unordered (0)"""
        return bool(self.flags & 1)

    @is_ordered.setter
    def is_ordered(self, value: bool):
        if value:
            self.flags |= 1
        else:
            self.flags &= ~1

    @property
    def is_masked(self) -> bool:
        """Bit 1: Masked/Salted (1) vs Plain (0)"""
        return bool(self.flags & 2)

    @is_masked.setter
    def is_masked(self, value: bool):
        if value:
            self.flags |= 2
        else:
            self.flags &= ~2

    @property
    def is_compressed(self) -> bool:
        """Bit 2: Compressed (1) vs Raw (0)"""
        return bool(self.flags & 4)

    @is_compressed.setter
    def is_compressed(self, value: bool):
        if value:
            self.flags |= 4
        else:
            self.flags &= ~4

    @classmethod
    def unpack(cls, data: bytes) -> 'ArgusSeal':
        """
        Deserializes a v1.1 binary envelope.
        """
        if len(data) < 88:
            raise ValueError("Data too short to be Argus Envelope")

        fmt = ">4sI32sQ32sIB3s"
        magic, version, schema_id, timestamp, root, flags, algo_id, reserved = struct.unpack(fmt, data[:88])

        if magic != cls.MAGIC:
            raise ValueError("Invalid Magic Bytes")

        payload = data[88:] # No signature parsing here (Detached)

        # Verify Integrity
        calc_root = hashlib.sha256(hashlib.sha256(payload).digest()).digest()
        if calc_root != root:
             raise ValueError("Integrity Check Failed: Payload does not match Header Merkle Root")

        return cls(payload, schema_id, timestamp, version, flags, algo_id)
