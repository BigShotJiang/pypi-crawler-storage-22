from argus.utils.hasher import Hasher
from typing import List, Dict


class ArgusMerkleTree:
    def __init__(self, logs: List[str], algorithm: str = "sha256", sort_leaves: bool = True):
        """
        Initialize the Merkle Tree with a list of log entries.
        
        Args:
            logs: A list of log strings.
            algorithm: Hash algorithm to use ('sha256').
            sort_leaves: If True (default), sort leaves (Set-Based). 
                         If False, preserve input order (Sequence-Based).
        """
        if not logs:
            raise ValueError("Logs cannot be empty")

        self.logs = logs
        self.algorithm = algorithm
        self.sort_leaves = sort_leaves
        self.hasher = Hasher(algorithm)

        # Leaf nodes: hash(hash(log))
        self.leaves = [self._hash_leaf(log) for log in logs]
        self.tree = self._build_tree(self.leaves)

    def _hash_leaf(self, data: str) -> str:
        # Double hash to prevent second preimage attacks
        # H(H(x))
        if isinstance(data, str):
            data_bytes = data.encode('utf-8')
        else:
            data_bytes = data
            
        return self.hasher.hash(self.hasher.hash(data_bytes).encode('utf-8'))

    def _build_tree(self, leaves: List[str]) -> List[List[str]]:
        """
        Generates a Merkle Tree.
        """
        if not leaves:
            return []
        
        # Sort leaves if requested (Mode A: Unordered)
        # Otherwise keep order (Mode B: Ordered)
        if self.sort_leaves:
            leaves_sorted = sorted(leaves)
        else:
            leaves_sorted = list(leaves)

        tree = [leaves_sorted]
        while len(tree[-1]) > 1:
            layer = tree[-1]
            new_layer = []
            for i in range(0, len(layer), 2):
                if i + 1 < len(layer):
                    # Combine and hash
                    combined = layer[i] + layer[i+1]
                    new_layer.append(self.hasher.hash(combined.encode('utf-8')))
                else:
                    # Odd number, carry over
                    new_layer.append(layer[i])
            tree.append(new_layer)
        return tree

    def get_root(self) -> str:
        """
        Returns the Merkle Root (the value to be anchored).
        """
        return self.tree[-1][0] if self.tree else None

    def get_proof(self, log_index: int) -> List[Dict[str, str]]:
        # Find the leaf node corresponding to the log
        # Since we sorted the leaves, the index might have changed
        # We need to find the sorted position of the target log
        original_log = self.logs[log_index]
        target_hash = self._hash_leaf(original_log)
        
        try:
            # Use tree[0] which contains the actual sorted leaves used in the tree
            current_idx = self.tree[0].index(target_hash)
        except ValueError:
            raise ValueError("Log not found in tree")

        proof = []
        for layer in self.tree[:-1]: # Don't include root layer
            is_right_child = (current_idx % 2 == 1)
            sibling_idx = current_idx - 1 if is_right_child else current_idx + 1

            if sibling_idx < len(layer):
                proof.append({
                    "position": "left" if is_right_child else "right",
                    "hash": layer[sibling_idx]
                })
            
            # Move up to next layer
            current_idx //= 2
            
        return proof
