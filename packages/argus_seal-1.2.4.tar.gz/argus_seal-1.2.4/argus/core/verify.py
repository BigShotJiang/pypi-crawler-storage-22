from typing import List, Dict, Union
from argus.utils.hasher import Hasher

def verify_receipt(log_data: Union[str, bytes], receipt_path: List[Dict[str, str]], root_hash: str, algorithm: str = "sha256") -> bool:
    """
    Verifies a Merkle Proof path against a Root Hash.
    
    Args:
        log_data: The content of the leaf node (string or bytes).
        receipt_path: List of sibling hashes [{'position': 'left|right', 'hash': '...'}]
        root_hash: The trusted root hash to match against.
        algorithm: Hash algorithm to use ('sha256').
        
    Returns:
        bool: True if the calculated root matches the provided root_hash.
    """
    hasher = Hasher(algorithm)

    # 1. Re-calculate Leaf Hash
    # Double hash to match tree construction: H(H(x))
    if isinstance(log_data, str):
        data_bytes = log_data.encode('utf-8')
    else:
        data_bytes = log_data
        
    current_hash = hasher.hash(hasher.hash(data_bytes).encode('utf-8'))

    # 2. Traverse the path
    for sibling in receipt_path:
        sibling_hash = sibling['hash']
        position = sibling['position']

        if position == 'left':
            combined = sibling_hash + current_hash
        else:
            combined = current_hash + sibling_hash
        
        current_hash = hasher.hash(combined.encode('utf-8'))

    # 3. Compare with Root
    return current_hash == root_hash
