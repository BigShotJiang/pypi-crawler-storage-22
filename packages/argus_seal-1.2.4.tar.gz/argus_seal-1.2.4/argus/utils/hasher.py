import hashlib

class Hasher:
    """
    Strategy pattern for hashing algorithms.
    Supported: 'sha256' (default)
    """
    def __init__(self, algorithm: str = "sha256"):
        self.algo = algorithm.lower()

    def hash(self, data: bytes) -> str:
        """
        Hashes the byte data using the configured algorithm.
        Returns hex string.
        """
        if self.algo == "sha256":
            return hashlib.sha256(data).hexdigest()
        else:
            # Fallback or error for unknown algorithms
            # For now, we strictly support sha256 as per 1.2.0 spec
            if self.algo == "keccak256":
                 raise ValueError("Keccak256 is deprecated in v1.2.0. Use sha256.")
            raise ValueError(f"Unsupported algorithm: {self.algo}")
