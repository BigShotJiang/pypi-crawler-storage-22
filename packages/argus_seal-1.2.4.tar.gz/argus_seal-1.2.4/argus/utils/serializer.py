import json
import hashlib
import os
from typing import List, Union

def calculate_schema_hash(schema_config: dict) -> str:
    """
    Calculates the hash of the schema configuration (The Rule Book).
    """
    canonical_schema = json.dumps(schema_config, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(canonical_schema.encode('utf-8')).hexdigest()

def load_input_data(target_path: str, schema_config: dict = None) -> List[Union[str, bytes]]:
    """
    Smart Loader with Envelope Support:
    - If JSON List & Schema provided: Wraps data in Argus Envelope.
    - If Directory/Binary: Returns raw bytes (Schema ignored for now).
    """
    if os.path.isdir(target_path):
        # Directory Mode (Binary)
        # Walk directory, sort filenames to ensure deterministic ordering
        file_contents = []
        # Walk deterministically
        for root, dirs, files in os.walk(target_path):
            dirs.sort() # Sort subdirs in-place
            for filename in sorted(files):
                full_path = os.path.join(root, filename)
                with open(full_path, "rb") as f:
                    file_contents.append(f.read())
        
        if not file_contents:
            raise ValueError(f"Directory is empty: {target_path}")
        return file_contents

    elif os.path.isfile(target_path):
        # File Mode
        # 1. Try to read as JSON List (Legacy Log Mode)
        try:
            with open(target_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            if isinstance(data, list):
                # JSON Logic
                # Sort by timestamp if present (Best effort stability)
                try:
                    data.sort(key=lambda x: x.get("timestamp", "") if isinstance(x, dict) else x)
                except:
                    pass # Ensure stability if keys missing
                
                if schema_config:
                    # Calculate Schema Hash (The "Rule Seal")
                    schema_hash = calculate_schema_hash(schema_config)
                    fields_to_keep = schema_config.get("fields", [])
                    
                    # Envelope Header (Layer 3)
                    header_template = {
                        "version": "v1.0",
                        "schema_id": schema_hash,
                        # "timestamp": Added dynamically per item if present, or current time? 
                        # For now, let's look for a timestamp in the data, or omit if not found?
                        # Or maybe the log ITSELF has a timestamp.
                    }
                else:
                    fields_to_keep = None
                    header_template = None

                serialized_logs = []
                import time
                current_time = int(time.time())

                for item in data:
                    # 1. Filter Fields (Selective Disclosure)
                    if fields_to_keep:
                        filtered_item = {k: item[k] for k in fields_to_keep if k in item}
                    else:
                        filtered_item = item
                    
                    # 2. Envelope Construction (Layer 3)
                    if header_template:
                        # Try to find timestamp in the log, otherwise use sealing time
                        # Ideally, the log's own timestamp is the truth.
                        log_time = item.get("timestamp", item.get("time", current_time))
                        try:
                             log_time = int(log_time)
                        except:
                             log_time = current_time

                        header = header_template.copy()
                        header["timestamp"] = log_time

                        envelope = {
                            "header": header,
                            "payload": filtered_item
                        }
                        item_to_serialize = envelope
                    else:
                        item_to_serialize = filtered_item # Backward compat

                    # 3. Canonical Serialization
                    # The "Canned Goods" Rule:
                    # 1. Sort Keys (Deterministic)
                    # 2. No Whitespace (Compact)
                    serialized_logs.append(
                        json.dumps(item_to_serialize, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
                    )
                return serialized_logs

        except (json.JSONDecodeError, UnicodeDecodeError):
            # Not a JSON list, or binary file.
            pass

        # 2. Binary Mode (Single File)
        with open(target_path, "rb") as f:
            return [f.read()]

    else:
        raise ValueError(f"Invalid path: {target_path}")

# Wrapper for backward compatibility if needed (or refactor CLI to use load_input_data)
read_logs_from_file = load_input_data
