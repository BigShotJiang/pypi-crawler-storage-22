try:
    from importlib.metadata import version, PackageNotFoundError
except ImportError:
    from importlib_metadata import version, PackageNotFoundError

try:
    __version__ = version("argus-seal")
except PackageNotFoundError:
    __version__ = "0.0.0-unknown"

def seal(data, schema):
    return f"Sealing {data} with {schema}... (Coming Soon)"
