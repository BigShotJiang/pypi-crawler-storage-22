# Changelog

All notable changes to the **Argus Protocol** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - The "Constitution" Release - 2026-01-28

### 🚀 The Definition of Truth
This release freezes the **88-Byte Binary Layout** and the **4 Universal Schemas**.
Argus is no longer just a tool; it is a **Standard**.

### ✨ Added
-   **88-Byte Fixed Envelope**: The "Digital Constitution" defined in `SPEC.md` Section 2.2.
    -   Magic (4B), Version (4B), SchemaID (32B), Time (8B), Root (32B), Flags (4B), Algo (1B), Reserved (3B).
-   **Universal Basis Vectors (A/B/C/D)**:
    -   `Type A`: Value Invariant (Equality).
    -   `Type B`: Identity Invariant (Mapping).
    -   `Type C`: Sequence Invariant (Chaining).
    -   `Type D`: Structure Invariant (Topology).
-   **Protocol Suite**:
    -   **Canonicalization**: RFC 8785 (JCS) enforcement.
    -   **Domain Separation**: One-byte prefixes (`\x01` - `\x04`) to prevent type confusion.
    -   **API Standard**: `GET /argos/v1/proof/{id}`.
-   **The Democratization of Verification**:
    -   Added "Date Sovereignty" philosophy to `SPEC.md`.

### 🛠️ Changed
-   **Architecture**: Moved from "Sorted Merkle Tree" (v1.0) to "Hybrid Ordered/Unordered Tree" controlled by `Flags` bit 0.
-   **Signature Model**: Switched to **Detached Signatures** for the 88-byte header to maintain fixed geometry.

### 🔒 Security
-   **Kerckhoffs's Principle**: Open Source philosophy codified in `README.md`.
-   **Oracle Problem Admitted**: Explicitly documented the need for Hardware Signing to solve GIGO.

---

## [1.0.0] - Initial Prototype - 2026-01-27
-   Basic Merkle Tree implementation (Python).
-   JSON-based logic.
-   Proof-of-Concept CLI.
