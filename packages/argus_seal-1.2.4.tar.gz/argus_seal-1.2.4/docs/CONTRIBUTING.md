# Contributing to Argus

**"We Verify Everything."**

Argus is an Open Standard. We welcome contributions from anyone who believes in the democratization of truth.

## 📜 The Core Principles
1.  **No Magic**: Every line of code must be verifyable.
2.  **No Bloat**: The 88-Byte Constitution is sacred. Do not suggest adding bytes to the header unless you can prove it is mathematically necessary.
3.  **No Retroactivity**: Backwards compatibility is a hard requirement.

## 🛠️ Development Setup
1.  Fork the repository.
2.  Install dependencies: `pip install -e .`
3.  Run tests: `pytest`

## 🧪 Testing Standard
-   Every PR must include a new Test Vector (`tests/vectors/`) if it touches the Core Logic.
-   We maintain 100% logic coverage on `argus/core/`.

## 🛡️ Security Policy
If you find a vulnerability, do NOT open a public issue. Email security@argos.io (fictional) immediately. We follow Responsible Disclosure.

**Join the revolution.**
