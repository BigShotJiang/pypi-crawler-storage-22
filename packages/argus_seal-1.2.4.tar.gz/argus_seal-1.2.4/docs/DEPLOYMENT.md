# Production Patterns (Real-World Usage)

By default, the CLI embeds data in the receipt for easy testing. In production, you split them.

## Pattern A: Detached Proofs (Default for Enterprise)
*   **Data**: Stored in your existing DB / S3 (Private).
*   **Proof**: Stored in WORM / Public Ledger (Public/Shared).

```bash
# Generate detached proof (Receipt does not contain the log text)
$ argus seal ./logs/ -o proof.json --detached

# Verify by providing the original data
$ argus verify --receipt proof.json --data ./logs/
```

## Pattern B: Selective Disclosure
*   **Scenario**: You have a 1GB log file. The court needs proof for **one specific transaction**.
*   **Action**: You export *just* that index.
*   **Result**: The Merkle Branch proves it belongs to the 1GB file without revealing the other 999MB.

## Pattern C: Cloud Automation (S3)
1.  **Trigger**: S3 Object Create Event.
2.  **Lambda**: Runs `argus seal --detached`.
3.  **Storage**: Saves `proof.json` to a separate "Audit Bucket" with Object Lock habilitated.
