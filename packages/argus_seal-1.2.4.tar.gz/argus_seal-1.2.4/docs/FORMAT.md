# The 88-Byte Digital Seal

The core of Argus is the **Argus Digital Seal**, a rigid, binary header that acts as the "Wax Seal" of the digital age.

## Binary Structure
```binary
[ Magic(4) | Version(4) | Schema(32) | Time(8) | Root(32) | Flags(4) | Algo(1) | Pad(3) ]
```

| Offset | Field | Type | Description |
| :--- | :--- | :--- | :--- |
| 0 | `Magic` | `char[4]` | File Identification (`ARGS`). |
| 4 | `Version` | `uint32` | Format Version (v1.1). |
| 8 | `SchemaID` | `bytes32` | **Context**: Binds seal to a specific compliance domain. |
| 40 | `Timestamp` | `uint64` | **Time**: Unix Epoch + Monotonic Counter (Unique per stream). |
| 48 | `Root` | `bytes32` | **Integrity**: The Merkle Root of the data batch. |
| 80 | `Flags` | `uint32` | **Mode**: Encodes redaction, ordering, or compliance modes. |
| 84 | `AlgoID` | `uint8` | **Hash**: Algorithm identifier (e.g., 0x01 = Keccak256). |
| 85 | `Reserved` | `bytes3` | **Pad**: Analysis alignment padding. |

## Efficiency
*   **Size**: 88 Bytes.
*   **Scale**: You can seal **1 billion events** with only **88GB** of storage overhead (assuming 1 seal per event). Batch sealing reduces this to negligible size.
*   **Alignment**: Designed to fit within two 64-byte cache lines for high-performance verification.
