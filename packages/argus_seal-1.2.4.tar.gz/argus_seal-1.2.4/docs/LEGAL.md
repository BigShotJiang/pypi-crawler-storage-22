# Legal & Security Model

> Argus is not a shield. It is a trap.

## 1. The Security Logic
### The Formula for Truth
> `Receipt` + `Anchor` = `Proof`

*   **Receipt (Internal)**: Proves that *Row 42* belongs to *File X* (Mathematical Consistency).
*   **Anchor (External)**: Proves that *File X* existed at *Time T* and hasn't changed (Temporal Existence).
*   **Warning**: A receipt without an external anchor (WORM, Blockchain, Public Log) is just a claim. **Always anchor the Root Hash.**

### The Cost of Lies
Argus does not make files immutable—that is impossible. It makes lying **expensive**.
To fake a log, an attacker must:
1.  Re-generate the Merkle Tree (Easy).
2.  Hack the WORM storage to replace the Root Hash (Hard).
3.  Do this for *every* downstream system that engaged with the Hash (Impossible).

## 2. Admissibility
Courts do not trust software; they trust reproducible mathematics. Argus uses NIST-standard algorithms:
*   **SHA-256 / Keccak-256**: For Hashing.
*   **Ed25519**: For Signatures (Optional).

## 3. Liability Protection
Argus separates **Individual Responsibility** from **System Failure**.
*   **PASS**: The individual is exonerated. The math proves they followed procedure.
*   **FAIL**: The system is compromised. The liability shifts from the person to the infrastructure.
