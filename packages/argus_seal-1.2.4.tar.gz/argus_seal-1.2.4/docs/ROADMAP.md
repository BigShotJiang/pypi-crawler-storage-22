# Argus Roadmap 🗺️

> "The Evolution of Responsibility Transfer."

This roadmap outlines the progression of Argus from a **Developer Tool** to **Critical Infrastructure**.
It is structured not by "Features", but by **"Whose Liability is Protected?"**

---

## Phase 1: Individual Protection (v1.0) ✅
**Goal:** Protect the Developer. ("I didn't break it.")
- [x] **Reference Client:** Python CLI (`argus`)
- [x] **Protocol Spec:** `SPEC.md` (Forensic Logic)
- [x] **Universal Input:** Logs, Files, Directories
- [x] **UX:** Anchor-Agnostic, Unix-compliant sidecar

---

## Phase 2: Team Protection (v1.1) ✅
**Goal:** Protect the Operations Team. ("The system maintained integrity.")
- [x] **Ordered Merkle Tree:** Implemented via `Flags [Bit 0]` for sequence proof.
- [x] **88-Byte Seal:** Fixed Binary Layout for storage efficiency.
- [x] **Universal Schemas:** Type A/B/C/D for specific compliance domains.
- [x] **High-Level API:** `argus.seal()` one-liner for easy integration.

---

## Phase 3: Corporate Protection (v1.2 - v2.0) 🚀
**Goal:** Protect the Enterprise. ("The organization is compliant.")
> **Target Market**: Mid-tier Fintech, Audit-heavy SaaS, Regulated Data Processors.

### Priority 1: The Engine (Infrastructure)
- [ ] **Native Port (Rust):** `argus-rs`.
    -   **Why:** To serve as a high-performance sidecar agent (>100k TPS).
    -   **Result:** "Not a toy. Infrastructure."

### Priority 2: The Audit (Liability Defense)
- [ ] **Forensic Analyzer:** `argus replay-verify`.
    -   **Why:** Automated verification of gigabytes of logs during legal discovery.
    -   **Result:** Legal Automation. "The machine clears the company."

### Priority 3: Origin Assurance (Optional Hardening)
- [ ] **Hardware Signing:** HSM/YubiKey Support.
    -   **Why:** To solve the Oracle Problem ("The private key never touched RAM").
    -   **Result:** Non-Repudiation Upgrade.

---

## Phase 4: Social Protection (Future) 🌍
**Goal:** "Argus Inside". Infiltrate the Ecosystem.
> **Strategy**: Do not build new platforms. Embed into existing power structures.

- [ ] **CI/CD Controller:** `argus-action` (Supply Chain Security).
- [ ] **Kubernetes Admission:** Container Seal Verification.
- [ ] **S3 Object Lock Integration:** Automated Cloud Anchoring.
- [ ] **Enterprise SDKs:** Legacy Java/Go wrappers.

---

## Go-To-Market Strategy
1.  **Bottom-Up**: Developers use Phase 1/2 to cover their own ass.
2.  **Middle-Out**: DevOps teams adopt Standard Schemas (Phase 2) to solve internal blame games.
3.  **Top-Down**: CISO/Legal mandate Phase 3 to automate expensive audits.

**Argus is not about proving you are right.**
**It is about ensuring that if you lie, it costs you.**
