# Argus Evidence Standard (Technical Spec)

> "Argus is not about truth. It’s about enforcing the cost of lies."

## 1. Overview
Argus is a **high-performance, tamper-evident logging library** designed for legal and audit compliance. It fits into existing enterprise pipelines to cryptographically seal records, ensuring that any modification—whether by a hacker or a rogue administrator—is mathematically detectable and legally provable.

### 1.1 The Business Value
*   **Liability Shield**: Proves "Concept of Non-Repudiation" for logs. If the seal is broken, the organization is flagged. If valid, the organization proves "integrity since creation."
*   **Audit Velocity**: Replaces manual sampling with automated cryptographic verification (`O(1)` verification cost per batch).
*   **Forensic Readiness**: Generates admissible artifacts immediately upon data creation.

---

## 2. The Evidence Workflow
Argus replaces complex distinct systems with a single 3-step evidence chain.

1.  **Data Generation**: The App/Server generates a log entry (Financial, Ops, or Security).
2.  **The Seal (88 Bytes)**: Argus wraps the log in a standardized binary header containing the timestamp and Merkle Root.
3.  **Legal Evidence**: The result is only valid if the **Seal Root** is anchored in an external WORM, Blockchain, or Public Ledger.
    *   **Formula**: `Receipt` (Internal) + `Anchor` (External) = `Proof` (Legal).

---

## 3. The Digital Seal (Standard Binding)
The core of Argus is the **Argus Digital Seal**, a fixed 88-byte binary header. It is the "wax seal" of the digital age.

**Format**: Big-Endian (`>`)
**Total Size**: 88 Bytes

| Offset | Field | Type | Utility |
| :--- | :--- | :--- | :--- |
| 0 | `Magic` | `char[4]` | File Identification (`ARGS`) |
| 4 | `Version` | `uint32` | Format Version (v1.1) |
| 8 | `SchemaID` | `bytes32` | **Context anchor**: Binds seal to compliance domain. |
| 40 | `Timestamp` | `uint64` | **Time anchor**: Unix Epoch + Monotonic Counter.* |
| 48 | `Root` | `bytes32` | **Integrity anchor** (Merkle Root) |
| 80 | `Flags` | `uint32` | **Compliance Modes**: Redaction, Ordering, Jurisdiction. |
| 84 | `AlgoID` | `uint8` | Hash Algorithm |
| 85 | `Reserved` | `bytes3` | Padding |

> * **Note on Timestamp**: The monotonic counter is scoped **per sealing instance** (stream) to guarantee total ordering within a single evidence chain, preventing distributed concurrency issues.

> **Efficiency**: 1 billion logs can be sealed with only 88GB of overhead.

---

## 4. Data Categories (Targeted Compliance)
Argus defines 4 pragmatic schema types tailored to specific compliance verticals.

### Type A: Financial (The Money Moves)
*   **Target**: Banks, Fintech, Payment Gateways.
*   **Use Case**: Transaction Logs, Ledger Entries.
*   **Requirement**: Strict Value Equality. "Did $50 move or $500?"

### Type B: Forensic Assets (The Digital Smoking Gun)
*   **Target**: Legal Firms, Law Enforcement, IP Protection.
*   **Use Case**: Contracts, Seized Hard Drive Images, CCTV Footage.
*   **Requirement**: Data Identity. "Is this the exact PDF signed on Jan 1st?"

### Type C: Operational Logs (The Admin Trail)
*   **Target**: DevOps, Cloud Providers, System Admins.
*   **Use Case**: `access.log`, `bash_history`, Kubernetes Audit Logs.
*   **Requirement**: Sequence & Completeness. "Did admin delete line 402?"

### Type D: Security Topology (The Infrastructure State)
*   **Target**: CISO, Governance Risk Compliance (GRC).
*   **Use Case**: IAM Policies, Firewall Rules, S3 Bucket Configurations.
*   **Requirement**: Structural Integrity. "Was the port open at 10:00 AM?"

---

## 5. Dispute Resolution (The Kill Switch)
Argus is designed for the moment of conflict.

**Scenario**: A client claims they never authorized a transaction.
**Action**:
1.  **Extraction**: The institution pulls the sealed log (`receipt.json`).
2.  **Verification**: The auditor runs `argus verify`.
3.  **Result**:
    *   **PASS**: The log matches the Immutable Root anchored in WORM storage. The client is lying.
    *   **FAIL**: The internal database does not match the anchor. The institution has been compromised or is lying.

**Conclusion**: Mathematical asymmetry favors the holder of the valid seal.

> **Note**: Argus does not assign intent or liability. It establishes cryptographic consistency or inconsistency. It generates neutral evidence for human adjudication.

---

## 6. Verification (CLI)
No GUI. No Apps. Just raw, incontestable output.

```bash
$ argus verify --receipt proof.json
# [PASS] Integrity Verified
# [INFO] Sealed: 2026-01-29T10:00:00Z
# [INFO] Schema: Financial_v1
```

---

## 7. Conformance
Any tool exporting 88-byte headers matching this spec is **Argus Compliant**.

---

## Appendix A: Mathematical Basis
*Technical details for implementation.*

### A.1 Why 88 Bytes?
1.  **Cache Line Alignment**: 88 bytes fits comfortably within two standard 64-byte cache lines.
2.  **Process Efficiency**: The structure consists of exactly **11 x 64-bit words**, allowing for aligned memory access and zero-copy parsing on modern PDFs.
3.  **Network MTU**: Occupies <10% of a standard Ethernet packet MTU (1500 bytes), preventing fragmentation.

### A.2 Merkle Logic
Uses pure SHA-256 / Keccak-256. Leaf construction enforces `H(H(Data))` to prevent second-preimage attacks.

### A.3 The Oracle Limitation
Argus guarantees **Process Integrity**, not **Truth**. Garbage In = Secured Garbage Out. Hardware signing (Phase 3) solves this.
