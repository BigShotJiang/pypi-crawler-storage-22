import json
import hashlib
from eth_hash.auto import keccak
from argus.core.merkle import ArgusMerkleTree

# Helper to match the logic in core (Manual Double Hash for validation)
def keccak_double_hash(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    h1 = keccak(data)
    h2 = keccak(h1).hex()
    return h2

def generate_vectors():
    print("Generating Test Vectors...")
    
    test_cases = [
        {
            "id": "single_node",
            "description": "Merkle Tree with a single leaf",
            "input": ["hello"]
        },
        {
            "id": "two_nodes",
            "description": "Merkle Tree with two leaves (sorted)",
            "input": ["a", "b"]
        },
        {
            "id": "three_nodes",
            "description": "Merkle Tree with three leaves (odd number handling)",
            "input": ["a", "b", "c"]
        },
        {
            "id": "duplicates",
            "description": "Merkle Tree with duplicate inputs (should remain duplicates but sorted)",
            "input": ["a", "a", "b"]
        },
        {
            "id": "real_logs",
            "description": "Realistic log data",
            "input": [
                '{"event": "login", "user": "alice", "time": 1700000000}',
                '{"event": "transfer", "amount": 100, "user": "bob", "time": 1700000001}'
            ]
        }
    ]

    output_vectors = []

    for case in test_cases:
        tree = ArgusMerkleTree(case['input'], algorithm="keccak256")
        root = tree.get_root()
        
        # Calculate expected leaves manually for verify
        input_data = case['input']
        # Argus sorts leaves, but serializer/merkle logic takes inputs -> normalize -> sort
        # In current merkle, it sorts the H(H(x)) leaves? No, looking at code:
        # self.leaves = [self._hash_leaf(log) for log in logs]
        # self.tree = self._build_tree(self.leaves) --> Inside _build_tree: leaves = sorted(leaves)
        
        # So we expect the root to be deterministic based on the sorted values of the LEAF HASHES.
        
        # Generate proofs for verification test
        proofs = []
        for i, val in enumerate(case['input']):
            # Note: get_proof takes index of ORIGINAL input list
            p = tree.get_proof(i) 
            proofs.append({
                "target_input": val,
                "proof": p
            })

        vector = {
            "id": case['id'],
            "description": case['description'],
            "input_raw": case['input'],
            "algorithm": "keccak256",
            "expected_root": root,
            "proofs": proofs
        }
        output_vectors.append(vector)

    with open("tests/test_vectors.json", "w") as f:
        json.dump(output_vectors, f, indent=2)
    
    print(f"Generated {len(output_vectors)} vectors in tests/test_vectors.json")

if __name__ == "__main__":
    generate_vectors()
