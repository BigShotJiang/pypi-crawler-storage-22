from argus.core.envelope import ArgusEnvelope
import pytest

def test_flags_constitution():
    payload = b"test"
    schema_id = bytes([0]*32)
    
    # 1. Default State (All False)
    env = ArgusEnvelope(payload, schema_id)
    assert env.flags == 0
    assert not env.is_ordered
    assert not env.is_masked
    assert not env.is_compressed

    # 2. Toggle Ordered (Bit 0)
    env.is_ordered = True
    assert env.flags == 1
    assert env.is_ordered
    
    # Toggle Back
    env.is_ordered = False
    assert env.flags == 0

    # 3. Toggle Masked (Bit 1)
    env.is_masked = True
    assert env.flags == 2
    assert env.is_masked
    assert not env.is_ordered

    # 4. Mixed State (Ordered + Masked + Compressed)
    env.is_ordered = True
    env.is_compressed = True
    # Flags = 1 (Ordered) + 2 (Masked) + 4 (Compressed) = 7
    assert env.flags == 7
    assert env.is_ordered
    assert env.is_masked
    assert env.is_compressed

    # 5. AlgoID Check (v1.1)
    assert env.algo_id == 2 # Default Keccak

    # 6. Pack and Unpack Persistence
    packed = env.pack()
    unpacked = ArgusEnvelope.unpack(packed)
    
    assert unpacked.flags == 7
    assert unpacked.is_ordered
    assert unpacked.is_masked
    assert unpacked.is_compressed
    assert unpacked.algo_id == 2
    
    print("Flags Constitution Verified.")

if __name__ == "__main__":
    test_flags_constitution()
