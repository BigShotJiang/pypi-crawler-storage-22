import pytest
import json
import os
from argus.core.merkle import ArgusMerkleTree
from argus.core.verify import verify_receipt

# Load test vectors
VECTOR_FILE = os.path.join(os.path.dirname(__file__), "test_vectors.json")
with open(VECTOR_FILE) as f:
    TEST_VECTORS = json.load(f)

@pytest.mark.parametrize("case", TEST_VECTORS)
def test_merkle_root_computation(case):
    """
    Verify that the Merkle Root matches the expected value from the test vector.
    """
    tree = ArgusMerkleTree(case['input_raw'], algorithm=case['algorithm'])
    assert tree.get_root() == case['expected_root']

@pytest.mark.parametrize("case", TEST_VECTORS)
def test_proof_verification(case):
    """
    Verify that the proofs generated match the vector and verify correctly.
    """
    tree = ArgusMerkleTree(case['input_raw'], algorithm=case['algorithm'])
    
    for proof_case in case['proofs']:
        target_input = proof_case['target_input']
        
        # 1. Regenerate proof from tree -> Should match vector logic
        # Note: In a real scenario, we might just use the vector's proof to test the VERIFIER.
        # Here we test both generation consistency and verification.
        
        # Determine index of this input manually for test
        # Note: ArgusMerkleTree needs index in ORIGINAL list
        idx = case['input_raw'].index(target_input)
        generated_proof = tree.get_proof(idx)
        
        # 2. Verify the proof using core.verify
        is_valid = verify_receipt(
            target_input, 
            generated_proof, 
            case['expected_root'], 
            algorithm=case['algorithm']
        )
        assert is_valid is True

def test_empty_input():
    with pytest.raises(ValueError):
        ArgusMerkleTree([])

def test_single_leaf_hash():
    """
    Unit test for the double-hashing leaf logic.
    Leaf = Keccak(Keccak(Data))
    """
    from argus.utils.hasher import Hasher
    hasher = Hasher("keccak256")
    data = "test"
    
    # Expected: H(H("test"))
    inner = hasher.hash(data.encode('utf-8'))
    expected = hasher.hash(inner.encode('utf-8'))
    
    tree = ArgusMerkleTree(["test"])
    # Argus stores leaf hashes in .leaves
    assert tree.leaves[0] == expected
