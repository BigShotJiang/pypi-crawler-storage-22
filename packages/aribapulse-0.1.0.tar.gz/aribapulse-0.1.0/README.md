README.md (short but solid)
# aribapulse

Open-source toolkit for **SAP Ariba + Procure-to-Pay (P2P)** analytics:
- process mining (variants, lead times, bottlenecks)
- ESG scoring hooks
- GenAI-ready insights generation
- CLI included

## Install
```bash
pip install aribapulse
```

# Quickstart (CLI)

```
Create events.json:

[
  {"case_id":"PO-1","event_type":"PO_CREATED","ts":"2026-02-06T10:00:00Z"},
  {"case_id":"PO-1","event_type":"PAYMENT_SENT","ts":"2026-02-07T12:00:00Z"}
]
```

# Run:

- aribapulse analyze-events events.json

# Notes

- Ariba APIs vary by tenant/config. AribaClient is a clean skeleton you can extend per your API setup.



### MIT License

Copyright (c) 2026 Jagadeesh Vasanthada

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
