# aribapulse

**aribapulse** is an open-source Python library for **Procure-to-Pay (P2P) analytics**, **process mining**, and **AI-ready procurement insights**, designed for modern **SAP Ariba and Cloud ERP environments**.

It enables procurement, finance, and engineering teams to **understand real execution paths**, **detect bottlenecks**, **evaluate ESG risk**, and **generate decision-ready insights** from transactional procurement data.

---

##  Why aribapulse?

Enterprise procurement platforms generate massive volumes of transactional data, yet organizations often lack **clear visibility into how procurement processes actually execute**.

**aribapulse bridges this gap** by combining:

- Process mining (what truly happens vs. designed workflows)
- Procure-to-Pay execution analytics
- ESG & sustainability scoring hooks
- Generative-AI–ready insight generation
-  Extensible SAP Ariba integration skeleton

All delivered as a **lightweight, vendor-neutral, open-source Python package**.

---

##  Key Features

###  Procure-to-Pay (P2P) Event Modeling
- Standardized P2P lifecycle events
- Case-based tracking (POs, invoices, suppliers)
- Works with logs from SAP Ariba, ERP exports, or data lakes

###  Process Mining & Bottleneck Detection
- Identify top execution variants
- Measure lead times between process stages
- Detect approval delays, invoice exceptions, and rework
- Transparent, explainable analytics (no black-box ML)

###  ESG & Sustainability Analytics (Extensible)
- Simple ESG scoring per supplier or category
- Supports sustainability, compliance, and sourcing risk analysis
- Designed to integrate with external ESG data providers

###  Generative-AI–Ready Insights
- Converts analytics into structured, narrative insights
- Provider-agnostic (no hard dependency on OpenAI, Vertex, etc.)
- Ideal for dashboards, executive summaries, or chatbots

###  Command-Line Interface (CLI)
- Analyze event logs directly from JSON
- Generate insights without writing Python code
- Useful for analysts, architects, and platform teams

---

##  Installation

Install from PyPI:

```bash
pip install aribapulse
```
### Requirements

- Python 3.9+

### Core Concepts

```
{
  "case_id": "PO-100045",
  "event_type": "INVOICE_APPROVED",
  "ts": "2026-02-06T10:15:00Z",
  "supplier_id": "SUP-7781",
  "amount": 12000,
  "currency": "USD"
}
```
### Case ID

- A case represents a complete procurement execution (PO, invoice, or composite business key).

##  Quick Start (CLI)

### Step 1: Create an event log (events.json)

```
[
  {
    "case_id": "PO-1",
    "event_type": "PO_CREATED",
    "ts": "2026-02-01T09:00:00Z"
  },
  {
    "case_id": "PO-1",
    "event_type": "PAYMENT_SENT",
    "ts": "2026-02-02T14:00:00Z"
  },
  {
    "case_id": "PO-2",
    "event_type": "PO_CREATED",
    "ts": "2026-02-01T09:30:00Z"
  },
  {
    "case_id": "PO-2",
    "event_type": "PAYMENT_SENT",
    "ts": "2026-02-05T11:00:00Z"
  }
]
```
## Step 2: Run analysis

```
aribapulse analyze-events events.json
```

## Step 3: Output

- Top process variants

- Bottleneck cases

- Executive-style insight summary

### Programmatic Usage

### Process Mining

```
from aribapulse.process_mining.mining import variants, lead_time
from aribapulse.p2p.events import P2PEvent

events = [P2PEvent.model_validate(e) for e in raw_events]

top_variants = variants(events)
lead_times = lead_time(events, "PO_CREATED", "PAYMENT_SENT")
```

### ESG Scoring
```
from aribapulse.esg.scoring import simple_esg_score

score = simple_esg_score(
    supplier_id="SUP-7781",
    factors={
        "co2_intensity": 0.7,
        "labor_risk": 0.8,
        "compliance": 0.9
    }
)
```
### GenAI-Ready Insights

```
from aribapulse.genai.insights import build_procurement_insights

insights = build_procurement_insights(
    top_variants=top_variants,
    slow_cases=[],
    esg_flags=[]
)
```
### SAP Ariba Integration (Extensible)

from aribapulse.ariba.client import AribaClient
from aribapulse.config import AribaConfig

config = AribaConfig.from_env()
client = AribaClient(config)
```
- SAP Ariba APIs vary by tenant and configuration.
- This library intentionally avoids hard-coding proprietary endpoints.

### Architecture Philosophy

- Vendor-neutral and extensible

- Explainable analytics (no opaque ML)

- Composable building blocks

- Production-friendly and testable

- Designed for enterprise-scale data

### Testing
```
pytest
```
- Tests focus on correctness of analytics and process mining primitives.

### Roadmap

- CSV and BigQuery ingestion helpers

- Advanced process mining (conformance, loops, rework)

- Supplier risk dashboards

- ESG benchmark integrations

- Optional LLM adapters (Vertex AI, OpenAI, Azure)

### Contributing

#### Contributions are welcome:

- New analytics modules

- ERP adapters (S/4HANA, Coupa, Oracle)

- Documentation improvements

- Sanitized real-world datasets

- Please open an issue or submit a pull request.

### License

```
MIT License

Copyright (c) 2026 Jagadeesh Vasanthada

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```


