from pydantic import BaseModel, Field
from .exceptions import ConfigurationError


class AribaConfig(BaseModel):
    base_url: str = Field(..., description="Base URL for the API endpoint")
    token: str = Field(..., description="Bearer token or API token")

    @classmethod
    def from_env(cls) -> "AribaConfig":
        import os

        base_url = os.getenv("ARIBA_BASE_URL", "").strip()
        token = os.getenv("ARIBA_TOKEN", "").strip()

        if not base_url or not token:
            raise ConfigurationError(
                "Missing ARIBA_BASE_URL or ARIBA_TOKEN environment variables."
            )
        return cls(base_url=base_url, token=token)

