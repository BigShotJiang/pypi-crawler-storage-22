class AribaPulseError(Exception):
    """Base exception for aribapulse."""


class ConfigurationError(AribaPulseError):
    """Raised when configuration is missing/invalid."""


class ApiError(AribaPulseError):
    """Raised for HTTP/API errors."""

