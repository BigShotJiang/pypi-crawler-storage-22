from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import datetime


EventType = Literal[
    "PO_CREATED",
    "PO_APPROVED",
    "GOODS_RECEIPT",
    "INVOICE_RECEIVED",
    "INVOICE_APPROVED",
    "PAYMENT_SENT",
]


class P2PEvent(BaseModel):
    case_id: str = Field(..., description="Process instance ID (e.g., PO number or composite key)")
    event_type: EventType
    ts: datetime
    supplier_id: Optional[str] = None
    amount: Optional[float] = None
    currency: Optional[str] = None
    metadata: dict = Field(default_factory=dict)

