from __future__ import annotations
from datetime import datetime, timezone


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def parse_iso8601(dt: str) -> datetime:
    # Handles common ISO strings; expects timezone or 'Z'
    # Example: 2026-02-06T10:00:00Z
    dt = dt.strip().replace("Z", "+00:00")
    return datetime.fromisoformat(dt)

