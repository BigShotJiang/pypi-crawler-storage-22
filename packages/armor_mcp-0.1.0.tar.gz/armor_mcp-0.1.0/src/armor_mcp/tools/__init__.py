"""MCP Tools for AnomalyArmor.

Tools are defined in server.py for simplicity.
This module exists for future modularization if needed.
"""
