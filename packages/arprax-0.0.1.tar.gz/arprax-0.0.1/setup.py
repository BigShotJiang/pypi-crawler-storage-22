from setuptools import setup

setup(
    name="arprax",
    version="0.0.1",
    author="Arprax Lab",
    author_email="lab@arprax.com",
    description="The official Arprax namespace package.",
    packages=[], 
)