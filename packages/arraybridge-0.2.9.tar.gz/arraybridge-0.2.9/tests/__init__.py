"""Tests for arraybridge package."""
