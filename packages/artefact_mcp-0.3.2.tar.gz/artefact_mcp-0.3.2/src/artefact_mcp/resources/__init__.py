"""Static methodology resources."""
