"""MCP tool implementations."""
