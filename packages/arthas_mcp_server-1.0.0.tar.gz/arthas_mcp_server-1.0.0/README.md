# Arthas MCP Server

通用的 Arthas 代理 MCP Server，支持多实例管理。

## 功能特性

- 支持多个 Arthas 实例管理
- 统一的命令执行接口
- 安全的 Token 认证
- 环境变量配置支持
- 完整的审计日志

## 安装

```bash
pip install arthas-mcp-server
```

## 配置

在用户目录下创建配置文件 `~/.arthas-mcp/config.json`：

```json
{
  "instances": [
    {
      "name": "shop-frontend-daily",
      "url": "https://your-domain.com/internal/arthas",
      "token": "${ARTHAS_TOKEN_DAILY}",
      "description": "Shop Frontend Daily Environment"
    }
  ]
}
```

支持环境变量替换，格式为 `${ENV_VAR_NAME}`。

## 使用方法

### 1. 启动 MCP Server

```bash
arthas-mcp
```

### 2. 在 Claude Desktop 中配置

编辑 `~/Library/Application Support/Claude/claude_desktop_config.json`：

```json
{
  "mcpServers": {
    "arthas": {
      "command": "arthas-mcp"
    }
  }
}
```

### 3. 可用工具

- `arthas_list_instances`: 列出所有配置的 Arthas 实例
- `arthas_execute`: 在指定实例上执行 Arthas 命令

## 示例

```
列出所有实例：
arthas_list_instances

执行命令：
arthas_execute(
  instance_name="shop-frontend-daily",
  command="dashboard",
  operator="claude"
)
```

## 支持的 Arthas 命令

- dashboard: 系统实时数据面板
- thread: 线程信息
- jvm: JVM 信息
- memory: 内存信息
- watch: 方法执行观测
- trace: 方法调用路径追踪
- stack: 方法调用堆栈
- tt: 时间隧道记录
- monitor: 方法执行监控
- jad: 反编译类
- sc: 查找类
- sm: 查找方法

## 许可证

MIT License
