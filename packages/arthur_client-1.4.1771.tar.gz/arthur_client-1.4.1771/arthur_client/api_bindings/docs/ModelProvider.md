# ModelProvider


## Enum

* `ANTHROPIC` (value: `'anthropic'`)

* `OPENAI` (value: `'openai'`)

* `GEMINI` (value: `'gemini'`)

* `BEDROCK` (value: `'bedrock'`)

* `VERTEX_AI` (value: `'vertex_ai'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


