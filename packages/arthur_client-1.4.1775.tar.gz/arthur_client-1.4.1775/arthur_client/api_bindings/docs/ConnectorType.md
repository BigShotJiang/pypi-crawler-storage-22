# ConnectorType


## Enum

* `SHIELD` (value: `'shield'`)

* `S3` (value: `'S3'`)

* `GCS` (value: `'GCS'`)

* `BIGQUERY` (value: `'BigQuery'`)

* `ENGINE_INTERNAL` (value: `'engine_internal'`)

* `ODBC` (value: `'odbc'`)

* `SNOWFLAKE` (value: `'snowflake'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


