# IntervalUnit


## Enum

* `SECONDS` (value: `'seconds'`)

* `MINUTES` (value: `'minutes'`)

* `HOURS` (value: `'hours'`)

* `DAYS` (value: `'days'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


