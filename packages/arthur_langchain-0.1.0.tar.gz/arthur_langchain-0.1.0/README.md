# Arthur LangChain Tools 🤖⚡

Trade perpetual futures with any LangChain agent. Built on [Arthur DEX](https://arthurdex.com) - the exchange for AI agents.

## Installation

```bash
pip install arthur-langchain
```

## Quick Start

```python
from arthur_langchain import ArthurToolkit
from langchain_openai import ChatOpenAI
from langchain.agents import create_react_agent, AgentExecutor
from langchain import hub

# Initialize toolkit with your credentials
toolkit = ArthurToolkit(
    account_id="your_account_id",
    api_key="ed25519:your_api_key",
    secret_key="ed25519:your_secret_key"
)

# Create an agent with trading capabilities
llm = ChatOpenAI(model="gpt-4")
prompt = hub.pull("hwchase17/react")
agent = create_react_agent(llm, toolkit.get_tools(), prompt)
executor = AgentExecutor(agent=agent, tools=toolkit.get_tools(), verbose=True)

# Let your agent trade!
executor.invoke({"input": "Buy 0.01 BTC if the price is under $100k"})
```

## Tools Included

### 🔄 ArthurTradeTool
Execute market and limit orders.

```python
# Market buy
agent.invoke({"input": "Buy 0.5 ETH at market price"})

# Limit sell
agent.invoke({"input": "Place a limit sell for 1 SOL at $150"})
```

### 📊 ArthurPortfolioTool
Check positions, balance, and P&L.

```python
agent.invoke({"input": "What are my current positions and P&L?"})
agent.invoke({"input": "How much margin do I have available?"})
```

### 📈 ArthurMarketTool
Get prices, orderbook, and funding rates.

```python
agent.invoke({"input": "What's the current BTC price?"})
agent.invoke({"input": "Show me the ETH orderbook"})
agent.invoke({"input": "What's the funding rate on SOL?"})
```

### 📋 ArthurOrdersTool
Manage open orders.

```python
agent.invoke({"input": "List my open orders"})
agent.invoke({"input": "Cancel all my orders"})
```

## Example: Trading Agent

Here's a complete trading agent that follows a simple strategy:

```python
from arthur_langchain import ArthurToolkit
from langchain_openai import ChatOpenAI
from langchain.agents import create_react_agent, AgentExecutor
from langchain_core.prompts import PromptTemplate

# Setup
toolkit = ArthurToolkit(
    account_id="your_account_id",
    api_key="ed25519:your_api_key",
    secret_key="ed25519:your_secret_key"
)

llm = ChatOpenAI(model="gpt-4", temperature=0)

# Custom trading prompt
prompt = PromptTemplate.from_template("""You are a crypto trading agent with access to Arthur DEX.

Your trading rules:
1. Never risk more than 10% of portfolio on a single trade
2. Always check current price before trading
3. Set reasonable position sizes

Available tools:
{tools}

Tool names: {tool_names}

Question: {input}

Think step by step:
{agent_scratchpad}
""")

agent = create_react_agent(llm, toolkit.get_tools(), prompt)
executor = AgentExecutor(agent=agent, tools=toolkit.get_tools(), verbose=True)

# Run the agent
result = executor.invoke({
    "input": "Check if BTC is under $95k. If so, buy $100 worth."
})
print(result)
```

## Example: CrewAI Integration

```python
from crewai import Agent, Task, Crew
from arthur_langchain import ArthurToolkit

toolkit = ArthurToolkit(
    account_id="your_account_id",
    api_key="ed25519:your_api_key",
    secret_key="ed25519:your_secret_key"
)

trader = Agent(
    role="Crypto Trader",
    goal="Execute profitable trades on Arthur DEX",
    backstory="Expert perpetual futures trader",
    tools=toolkit.get_tools(),
    verbose=True
)

task = Task(
    description="Analyze BTC market and decide whether to open a position",
    agent=trader
)

crew = Crew(agents=[trader], tasks=[task])
result = crew.kickoff()
```

## Supported Markets

80+ perpetual futures including:
- **Majors**: BTC, ETH, SOL, BNB
- **L2s**: ARB, OP, MATIC
- **DeFi**: UNI, AAVE, LINK, MKR
- **Memes**: DOGE, SHIB, PEPE, WIF
- **AI**: FET, RNDR, TAO

## Getting Credentials

1. Go to [Arthur DEX](https://arthurdex.com)
2. Connect your wallet
3. Generate API keys in Settings

Or use the Arthur SDK directly:
```python
from arthur_sdk import Arthur
client = Arthur.create_account()  # Creates new account
print(client.account_id, client.api_key, client.secret_key)
```

## Links

- 🌐 [Arthur DEX](https://arthurdex.com)
- 📦 [Arthur SDK](https://pypi.org/project/arthur-sdk/)
- 🐦 [@Arthur_Orderly](https://twitter.com/Arthur_Orderly)
- 💬 [Discord](https://discord.gg/orderly)

## License

MIT
