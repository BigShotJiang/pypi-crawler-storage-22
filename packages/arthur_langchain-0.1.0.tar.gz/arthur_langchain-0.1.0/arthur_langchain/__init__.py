"""
Arthur LangChain Tools - Trade perpetuals with any LangChain agent

Usage:
    from arthur_langchain import ArthurToolkit
    
    toolkit = ArthurToolkit(
        account_id="your_account_id",
        api_key="your_api_key",
        secret_key="your_secret_key"
    )
    
    # Get all tools for your agent
    tools = toolkit.get_tools()
    
    # Or use individual tools
    from arthur_langchain import ArthurTradeTool, ArthurPortfolioTool, ArthurMarketTool
"""

from .toolkit import ArthurToolkit
from .tools import (
    ArthurTradeTool,
    ArthurPortfolioTool,
    ArthurMarketTool,
    ArthurOrdersTool,
)

__version__ = "0.1.0"
__all__ = [
    "ArthurToolkit",
    "ArthurTradeTool",
    "ArthurPortfolioTool",
    "ArthurMarketTool",
    "ArthurOrdersTool",
]
