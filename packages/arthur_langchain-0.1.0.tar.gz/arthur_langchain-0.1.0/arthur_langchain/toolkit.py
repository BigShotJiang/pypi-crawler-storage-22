"""
Arthur Toolkit - Bundle all Arthur tools for LangChain agents
"""

from typing import List, Optional
from .tools import ArthurTradeTool, ArthurPortfolioTool, ArthurMarketTool, ArthurOrdersTool

try:
    from langchain_core.tools import BaseTool
except ImportError:
    from langchain.tools import BaseTool


class ArthurToolkit:
    """
    Toolkit for Arthur DEX integration with LangChain.
    
    Provides tools for:
    - Trading (market/limit orders)
    - Portfolio management (positions, balance)
    - Market data (prices, orderbook, funding)
    - Order management (list, cancel)
    
    Usage:
        from arthur_langchain import ArthurToolkit
        
        toolkit = ArthurToolkit(
            account_id="your_account_id",
            api_key="your_api_key",
            secret_key="your_secret_key"
        )
        
        # Use with any LangChain agent
        agent = create_react_agent(llm, toolkit.get_tools())
    """
    
    def __init__(
        self,
        account_id: str,
        api_key: str,
        secret_key: str,
        testnet: bool = False,
    ):
        """
        Initialize Arthur toolkit.
        
        Args:
            account_id: Your Orderly account ID
            api_key: Your API key (ed25519 format)
            secret_key: Your secret key (ed25519 format)
            testnet: Use testnet instead of mainnet
        """
        # Import Arthur SDK
        try:
            from arthur_sdk import Arthur
        except ImportError:
            raise ImportError(
                "arthur-sdk not installed. Install with: pip install arthur-sdk"
            )
        
        # Initialize client
        self.client = Arthur(
            account_id=account_id,
            api_key=api_key,
            secret_key=secret_key,
            testnet=testnet,
        )
        
        # Initialize tools with client
        self._tools = [
            ArthurTradeTool(client=self.client),
            ArthurPortfolioTool(client=self.client),
            ArthurMarketTool(client=self.client),
            ArthurOrdersTool(client=self.client),
        ]
    
    def get_tools(self) -> List[BaseTool]:
        """
        Get all Arthur tools for use with LangChain agents.
        
        Returns:
            List of LangChain tools
        """
        return self._tools
    
    def get_trade_tool(self) -> ArthurTradeTool:
        """Get just the trading tool."""
        return self._tools[0]
    
    def get_portfolio_tool(self) -> ArthurPortfolioTool:
        """Get just the portfolio tool."""
        return self._tools[1]
    
    def get_market_tool(self) -> ArthurMarketTool:
        """Get just the market data tool."""
        return self._tools[2]
    
    def get_orders_tool(self) -> ArthurOrdersTool:
        """Get just the orders tool."""
        return self._tools[3]
