"""
Arthur DEX Tools for LangChain

Each tool wraps Arthur SDK functionality for use by LangChain agents.
"""

from typing import Optional, Type, Any
from pydantic import BaseModel, Field

try:
    from langchain_core.tools import BaseTool
    from langchain_core.callbacks import CallbackManagerForToolRun
except ImportError:
    from langchain.tools import BaseTool
    from langchain.callbacks.manager import CallbackManagerForToolRun


class TradeInput(BaseModel):
    """Input for trading."""
    symbol: str = Field(description="Trading pair symbol, e.g., 'BTC', 'ETH', 'SOL'")
    side: str = Field(description="Trade side: 'buy' or 'sell'")
    size: float = Field(description="Amount to trade in base currency")
    order_type: str = Field(default="market", description="Order type: 'market' or 'limit'")
    price: Optional[float] = Field(default=None, description="Limit price (required for limit orders)")


class PortfolioInput(BaseModel):
    """Input for portfolio queries."""
    query_type: str = Field(
        default="all",
        description="What to query: 'all', 'positions', 'balance', or specific symbol like 'BTC'"
    )


class MarketInput(BaseModel):
    """Input for market data."""
    symbol: str = Field(description="Symbol to get data for, e.g., 'BTC', 'ETH'")
    data_type: str = Field(
        default="price",
        description="Type of data: 'price', 'orderbook', 'funding', or 'info'"
    )


class OrdersInput(BaseModel):
    """Input for order management."""
    action: str = Field(description="Action: 'list', 'cancel', or 'cancel_all'")
    order_id: Optional[str] = Field(default=None, description="Order ID for cancel action")
    symbol: Optional[str] = Field(default=None, description="Symbol to filter orders")


class ArthurTradeTool(BaseTool):
    """
    Tool for executing trades on Arthur DEX.
    
    Supports market and limit orders for perpetual futures.
    Minimum order size is $10 notional value.
    """
    
    name: str = "arthur_trade"
    description: str = """Execute trades on Arthur DEX perpetual futures.
    
Use this tool to buy or sell crypto perpetuals. Supports:
- Market orders (instant execution at current price)
- Limit orders (execute at specified price or better)

Available symbols: BTC, ETH, SOL, ARB, OP, DOGE, and 80+ more perpetuals.

Examples:
- Buy 0.01 BTC at market: symbol='BTC', side='buy', size=0.01
- Sell 1 ETH with limit: symbol='ETH', side='sell', size=1, order_type='limit', price=2500
"""
    args_schema: Type[BaseModel] = TradeInput
    client: Any = None
    
    def _run(
        self,
        symbol: str,
        side: str,
        size: float,
        order_type: str = "market",
        price: Optional[float] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Execute a trade."""
        if not self.client:
            return "Error: Arthur client not initialized"
        
        try:
            symbol = symbol.upper()
            side = side.lower()
            
            if order_type == "market":
                if side == "buy":
                    order = self.client.buy(symbol, size=size)
                else:
                    order = self.client.sell(symbol, size=size)
            else:
                if price is None:
                    return "Error: Price required for limit orders"
                if side == "buy":
                    order = self.client.limit_buy(symbol, price=price, size=size)
                else:
                    order = self.client.limit_sell(symbol, price=price, size=size)
            
            return f"✅ Order executed: {side.upper()} {size} {symbol} | Order ID: {order.order_id}"
            
        except Exception as e:
            return f"❌ Trade failed: {str(e)}"


class ArthurPortfolioTool(BaseTool):
    """
    Tool for checking portfolio, positions, and account balance.
    """
    
    name: str = "arthur_portfolio"
    description: str = """Check your Arthur DEX portfolio, positions, and balance.

Use this to:
- View all open positions and their P&L
- Check account balance and available margin
- Get position details for a specific symbol

Examples:
- View all positions: query_type='positions'
- Check balance: query_type='balance'
- Get BTC position: query_type='BTC'
"""
    args_schema: Type[BaseModel] = PortfolioInput
    client: Any = None
    
    def _run(
        self,
        query_type: str = "all",
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Query portfolio information."""
        if not self.client:
            return "Error: Arthur client not initialized"
        
        try:
            result = []
            
            if query_type in ["all", "balance"]:
                balance = self.client.balance()
                result.append(f"💰 Balance: ${balance.total_balance:.2f} | Available: ${balance.free_collateral:.2f}")
            
            if query_type in ["all", "positions"]:
                positions = self.client.positions()
                if positions:
                    result.append("\n📊 Open Positions:")
                    for p in positions:
                        pnl_emoji = "🟢" if p.unrealized_pnl >= 0 else "🔴"
                        result.append(
                            f"  {p.symbol}: {p.side} {p.size} @ ${p.entry_price:.2f} | "
                            f"PnL: {pnl_emoji} ${p.unrealized_pnl:.2f}"
                        )
                else:
                    result.append("\n📊 No open positions")
            
            if query_type not in ["all", "balance", "positions"]:
                # Query specific symbol
                symbol = query_type.upper()
                positions = self.client.positions()
                found = False
                for p in positions:
                    if symbol in p.symbol:
                        pnl_emoji = "🟢" if p.unrealized_pnl >= 0 else "🔴"
                        result.append(
                            f"📊 {p.symbol}: {p.side} {p.size} @ ${p.entry_price:.2f} | "
                            f"PnL: {pnl_emoji} ${p.unrealized_pnl:.2f} | "
                            f"Liq: ${p.liquidation_price:.2f}"
                        )
                        found = True
                if not found:
                    result.append(f"No position found for {symbol}")
            
            return "\n".join(result) if result else "No data available"
            
        except Exception as e:
            return f"❌ Portfolio query failed: {str(e)}"


class ArthurMarketTool(BaseTool):
    """
    Tool for getting market data - prices, orderbook, funding rates.
    """
    
    name: str = "arthur_market"
    description: str = """Get market data from Arthur DEX.

Use this to:
- Get current price of any perpetual
- View orderbook depth
- Check funding rates
- Get market info (tick sizes, limits)

Examples:
- Get BTC price: symbol='BTC', data_type='price'
- Check ETH funding: symbol='ETH', data_type='funding'
"""
    args_schema: Type[BaseModel] = MarketInput
    client: Any = None
    
    def _run(
        self,
        symbol: str,
        data_type: str = "price",
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Get market data."""
        if not self.client:
            return "Error: Arthur client not initialized"
        
        try:
            symbol = symbol.upper()
            
            if data_type == "price":
                ticker = self.client.ticker(symbol)
                return (
                    f"📈 {symbol} Price: ${ticker.last_price:,.2f} | "
                    f"24h: {ticker.price_change_24h:+.2f}% | "
                    f"Vol: ${ticker.volume_24h:,.0f}"
                )
            
            elif data_type == "orderbook":
                ob = self.client.orderbook(symbol, depth=5)
                result = [f"📖 {symbol} Orderbook:"]
                result.append("  Asks (sells):")
                for ask in ob.asks[:5]:
                    result.append(f"    ${ask.price:.2f} - {ask.size}")
                result.append("  Bids (buys):")
                for bid in ob.bids[:5]:
                    result.append(f"    ${bid.price:.2f} - {bid.size}")
                return "\n".join(result)
            
            elif data_type == "funding":
                ticker = self.client.ticker(symbol)
                funding = getattr(ticker, 'funding_rate', 0) * 100
                return f"💸 {symbol} Funding Rate: {funding:.4f}%"
            
            elif data_type == "info":
                info = self.client.market_info(symbol)
                return (
                    f"ℹ️ {symbol} Info:\n"
                    f"  Min size: {info.min_size}\n"
                    f"  Tick size: {info.tick_size}\n"
                    f"  Min notional: ${info.min_notional}"
                )
            
            else:
                return f"Unknown data type: {data_type}. Use: price, orderbook, funding, info"
                
        except Exception as e:
            return f"❌ Market data failed: {str(e)}"


class ArthurOrdersTool(BaseTool):
    """
    Tool for managing open orders.
    """
    
    name: str = "arthur_orders"
    description: str = """Manage your open orders on Arthur DEX.

Use this to:
- List all open orders
- Cancel a specific order
- Cancel all orders

Examples:
- List orders: action='list'
- Cancel order: action='cancel', order_id='12345'
- Cancel all: action='cancel_all'
"""
    args_schema: Type[BaseModel] = OrdersInput
    client: Any = None
    
    def _run(
        self,
        action: str,
        order_id: Optional[str] = None,
        symbol: Optional[str] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Manage orders."""
        if not self.client:
            return "Error: Arthur client not initialized"
        
        try:
            if action == "list":
                orders = self.client.orders()
                if symbol:
                    orders = [o for o in orders if symbol.upper() in o.symbol]
                
                if not orders:
                    return "📋 No open orders"
                
                result = ["📋 Open Orders:"]
                for o in orders:
                    result.append(
                        f"  {o.order_id}: {o.side} {o.size} {o.symbol} @ ${o.price}"
                    )
                return "\n".join(result)
            
            elif action == "cancel":
                if not order_id:
                    return "Error: order_id required for cancel"
                self.client.cancel(order_id)
                return f"✅ Order {order_id} cancelled"
            
            elif action == "cancel_all":
                count = self.client.cancel_all(symbol)
                return f"✅ Cancelled {count} orders"
            
            else:
                return f"Unknown action: {action}. Use: list, cancel, cancel_all"
                
        except Exception as e:
            return f"❌ Order action failed: {str(e)}"
