# CLAUDE.md

## Project overview

artificer-dispatcher — polls task queues, dispatches agent subprocesses, exposes an HTTP API for agents. Python 3.13+, uses `uv` for dependency management.

## Commands

- Run: `artificer-dispatcher`, `python -m artificer_dispatcher`, or `python main.py`
- Tests: `.venv/bin/pytest`
- Install dev deps: `uv pip install -e ".[dev]"`

## Project structure

- Config: `pyproject.toml` under `[tool.artificer-dispatcher]`
- Entry point: `artificer_dispatcher/cli.py` → `main()`
- Console script: `artificer-dispatcher` (defined in `[project.scripts]`)

## Conventions

- Keep `README.md` in sync when adding/changing CLI flags, endpoints, config options, or backend adapters
- Backend adapters implement the `TaskAdapter` protocol in `artificer_dispatcher/adapters/base.py`
- Agent adapters implement the `AgentAdapter` protocol
