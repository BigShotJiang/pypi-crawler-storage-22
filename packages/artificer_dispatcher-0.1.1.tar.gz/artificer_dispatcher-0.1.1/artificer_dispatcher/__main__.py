from artificer_dispatcher.cli import main

main()
