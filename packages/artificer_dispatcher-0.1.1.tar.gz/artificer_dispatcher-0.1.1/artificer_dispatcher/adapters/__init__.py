from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from artificer_dispatcher.config import AppConfig, PlankaCredentials

from artificer_dispatcher.adapters.base import TaskAdapter


def create_adapter(
    config: AppConfig,
    credentials: PlankaCredentials | None = None,
) -> TaskAdapter:
    backend = config.backend
    if backend.type == "planka":
        from artificer_dispatcher.adapters.planka import PlankaAdapter

        if credentials is None:
            from artificer_dispatcher.config import PlankaCredentials

            credentials = PlankaCredentials.from_env()
        return PlankaAdapter(backend, credentials)
    elif backend.type == "json":
        from artificer_dispatcher.adapters.json_file import JsonFileAdapter

        return JsonFileAdapter(backend.url)
    else:
        raise ValueError(f"Unknown backend type: {backend.type!r}")
