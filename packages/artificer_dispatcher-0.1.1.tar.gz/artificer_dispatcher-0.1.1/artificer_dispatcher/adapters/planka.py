from __future__ import annotations

import logging
from collections.abc import Sequence
from typing import TYPE_CHECKING

from plankapy.v2 import Planka

from artificer_dispatcher.adapters.base import Task, TaskComment

if TYPE_CHECKING:
    from artificer_dispatcher.config import BackendConfig, PlankaCredentials

log = logging.getLogger(__name__)


def _parse_queue(queue_name: str) -> tuple[str, str, str]:
    """Parse a dotted queue name into (project, board, list)."""
    parts = queue_name.split(".")
    if len(parts) != 3:
        raise ValueError(
            f"Planka queue name must be 'project.board.list', got: {queue_name!r}"
        )
    return parts[0], parts[1], parts[2]


class PlankaAdapter:
    def __init__(self, config: BackendConfig, credentials: PlankaCredentials) -> None:
        auth_type = "token" if credentials.token else "password"
        log.debug("Connecting to Planka at %s (auth: %s)", config.url, auth_type)

        self._planka = Planka(config.url)
        if credentials.token:
            self._planka.login(api_key=credentials.token)
        else:
            self._planka.login(username=credentials.username, password=credentials.password)

        self._project_cache: dict[str, object] = {}
        self._board_cache: dict[tuple[str, str], object] = {}
        self._card_cache: dict[str, object] = {}
        log.debug("Planka adapter initialized")

    def _resolve_board(self, project_name: str, board_name: str):
        key = (project_name, board_name)
        if key not in self._board_cache:
            if project_name not in self._project_cache:
                log.debug("Resolving project=%r", project_name)
                project = self._planka.projects[{"name": project_name}].dpop()
                if project is None:
                    raise ValueError(f"Project not found: {project_name!r}")
                log.debug("Found project: %s (id=%s)", project.name, project.id)
                self._project_cache[project_name] = project
                # Eagerly cache all boards to avoid dpop() consuming the collection
                for board in project.boards:
                    bkey = (project_name, board.name)
                    log.debug("Cached board: %s (id=%s)", board.name, board.id)
                    self._board_cache[bkey] = board
            if key not in self._board_cache:
                raise ValueError(f"Board not found: {board_name!r} in project {project_name!r}")
        return self._board_cache[key]

    def _resolve_list(self, queue_name: str):
        project_name, board_name, list_name = _parse_queue(queue_name)
        board = self._resolve_board(project_name, board_name)
        log.debug("Resolving list=%r on board=%r", list_name, board_name)
        lst = board.lists[{"name": list_name}].dpop()
        if lst is None:
            raise KeyError(f"List not found: {list_name!r} on board {board_name!r}")
        log.debug("Found list: %s (id=%s)", lst.name, lst.id)
        return board, lst

    def _find_card(self, task_id: str):
        log.debug("Looking up card id=%s", task_id)
        if task_id in self._card_cache:
            card = self._card_cache[task_id]
            log.debug("Found card in cache: %s (id=%s)", card.name, card.id)
            return card
        # Search across cached boards
        for board in self._board_cache.values():
            card = board.cards[task_id]
            if card is not None:
                log.debug("Found card: %s (id=%s)", card.name, card.id)
                self._card_cache[task_id] = card
                return card
        raise KeyError(f"Card not found: {task_id}")

    def get_ready_tasks(self, queue_names: Sequence[str]) -> list[Task]:
        log.debug("Polling queues: %s", queue_names)
        tasks = []
        for queue_name in queue_names:
            try:
                _, lst = self._resolve_list(queue_name)
            except (KeyError, ValueError) as e:
                log.debug("Skipping queue %r: %s", queue_name, e)
                continue
            cards = list(lst.cards)
            log.debug("Queue %r: found %d cards", queue_name, len(cards))
            for card in cards:
                self._card_cache[card.id] = card
                tasks.append(self._card_to_task(card, source_queue=queue_name))
        log.debug("Total ready tasks: %d", len(tasks))
        return tasks

    def get_task(self, task_id: str) -> Task:
        card = self._find_card(task_id)
        return self._card_to_task(card)

    def move_task(self, task_id: str, target_queue: str) -> None:
        log.debug("Moving task %s -> %r", task_id, target_queue)
        card = self._find_card(task_id)
        _, target_list = self._resolve_list(target_queue)
        card.move(target_list)
        log.debug("Moved task %s to %r", task_id, target_queue)

    def add_comment(self, task_id: str, text: str) -> None:
        log.debug("Adding comment to task %s: %r", task_id, text[:80])
        card = self._find_card(task_id)
        card.comment(text)

    def update_task(
        self,
        task_id: str,
        *,
        assignees: list[str] | None = None,
        name: str | None = None,
        description: str | None = None,
        labels: list[str] | None = None,
    ) -> None:
        card = self._find_card(task_id)

        if name is not None:
            log.debug("Updating name of task %s to %r", task_id, name)
            card.update(name=name)

        if description is not None:
            log.debug("Updating description of task %s", task_id)
            card.update(description=description)

        if assignees is not None:
            desired_users = [self._resolve_user(u) for u in assignees]
            current_members = {m.id for m in card.members}
            desired_ids = {u.id for u in desired_users}
            for user in desired_users:
                if user.id not in current_members:
                    log.debug("Adding member %s to task %s", user.name, task_id)
                    card.add_member(user)
            for member in card.members:
                if member.id not in desired_ids:
                    log.debug("Removing member %s from task %s", member.name, task_id)
                    card.remove_member(member)

        if labels is not None:
            board_labels = {lbl.name: lbl for lbl in card.board.labels}
            desired_labels = []
            for label_name in labels:
                if label_name not in board_labels:
                    raise ValueError(f"Label not found: {label_name!r}")
                desired_labels.append(board_labels[label_name])
            current_label_ids = {lbl.id for lbl in card.labels}
            desired_label_ids = {lbl.id for lbl in desired_labels}
            for lbl in desired_labels:
                if lbl.id not in current_label_ids:
                    log.debug("Adding label %s to task %s", lbl.name, task_id)
                    card.add_label(lbl)
            for lbl in card.labels:
                if lbl.id not in desired_label_ids:
                    log.debug("Removing label %s from task %s", lbl.name, task_id)
                    card.remove_label(lbl)

    def _resolve_user(self, username: str):
        """Resolve a username string to a plankapy User object.

        The special value ``"me"`` resolves to the currently authenticated user.
        """
        if username == "me":
            return self._planka.me
        for user in self._planka.users:
            if user.name == username or user.username == username:
                return user
        raise ValueError(f"User not found: {username!r}")

    def create_task(self, queue_name: str, name: str, description: str = "") -> Task:
        log.debug("Creating task %r on queue %r", name, queue_name)
        _, lst = self._resolve_list(queue_name)
        card = lst.create_card(name=name, description=description or None)
        self._card_cache[card.id] = card
        log.debug("Created card %s (id=%s) on %r", card.name, card.id, queue_name)
        return self._card_to_task(card, source_queue=queue_name)

    def _card_to_task(self, card, source_queue: str = "") -> Task:
        description = card.description or ""
        checklist_lines = []
        for t in card.tasks:
            mark = "x" if t.is_completed else " "
            checklist_lines.append(f"- [{mark}] {t.name}")
        if checklist_lines:
            suffix = "\n\n## Checklist\n" + "\n".join(checklist_lines)
            description = (description + suffix) if description else suffix.lstrip("\n")
        comments = [
            TaskComment(
                author=c.user.name,
                text=c.text,
                created_at=str(c.created_at) if c.created_at else "",
            )
            for c in card.comments
        ]
        return Task(
            id=card.id,
            name=card.name,
            description=description,
            url=card.url or "",
            source_queue=source_queue,
            labels=[label.name for label in card.labels],
            assignees=[user.name for user in card.members],
            comments=comments,
        )
