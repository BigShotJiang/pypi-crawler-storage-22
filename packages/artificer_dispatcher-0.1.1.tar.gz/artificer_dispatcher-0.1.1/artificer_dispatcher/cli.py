from __future__ import annotations

import argparse
import asyncio
import logging
import sys


def setup_logging(debug: bool = False) -> None:
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,
    )


async def run(port_override: int | None = None) -> None:
    import uvicorn

    from artificer_dispatcher.adapters import create_adapter
    from artificer_dispatcher.config import load_config
    from artificer_dispatcher.http_api import create_app as create_rest_app
    from artificer_dispatcher.router import Router

    config = load_config()
    if port_override is not None:
        config.api_port = port_override

    adapter = create_adapter(config)

    router = Router(config, adapter)
    rest_app = create_rest_app(adapter, router)

    uvicorn_config = uvicorn.Config(
        rest_app,
        host=config.api_host,
        port=config.api_port,
        log_level="info",
    )
    server = uvicorn.Server(uvicorn_config)

    loop = asyncio.get_running_loop()
    server_future = loop.run_in_executor(None, server.run)

    router_task = asyncio.create_task(router.run())

    log = logging.getLogger(__name__)
    log.info(
        "Started: HTTP API on %s:%d, polling every %ds",
        config.api_host,
        config.api_port,
        config.poll_interval,
    )

    done, pending = await asyncio.wait(
        [server_future, router_task],
        return_when=asyncio.FIRST_COMPLETED,
    )

    for task in pending:
        task.cancel()
    for task in done:
        if task.exception():
            log.error("Task failed: %s", task.exception())


def main() -> None:
    parser = argparse.ArgumentParser(description="artificer-dispatcher")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument(
        "--port", type=int, default=None, help="Override the API port"
    )
    args = parser.parse_args()

    from dotenv import load_dotenv

    load_dotenv()
    setup_logging(debug=args.debug)
    try:
        asyncio.run(run(port_override=args.port))
    except KeyboardInterrupt:
        logging.getLogger(__name__).info("Interrupted, exiting")
