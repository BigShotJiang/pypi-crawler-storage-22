from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class RouteConfig:
    queue_name: str
    command: str
    args: list[str] = field(default_factory=list)
    in_progress_queue: str = "In Progress"
    timeout: int | None = None  # timeout in seconds, None = no timeout

    def format_command(
        self,
        task_id: str,
        task_name: str,
        task_url: str = "",
    ) -> list[str]:
        replacements = {
            "{task_id}": task_id,
            "{task_name}": task_name,
            "{task_url}": task_url,
        }
        formatted_args = []
        for arg in self.args:
            for placeholder, value in replacements.items():
                arg = arg.replace(placeholder, value)
            formatted_args.append(arg)
        return [self.command, *formatted_args]


@dataclass
class BackendConfig:
    type: str
    url: str


@dataclass
class AppConfig:
    poll_interval: int
    max_concurrent_agents: int
    api_host: str
    api_port: int
    backend: BackendConfig
    routes: list[RouteConfig]
    default_agent_timeout: int | None = None  # default timeout in seconds, None = no timeout

    @property
    def ready_queue_names(self) -> list[str]:
        return [r.queue_name for r in self.routes]

    def route_for_queue(self, queue_name: str) -> RouteConfig | None:
        for route in self.routes:
            if route.queue_name == queue_name:
                return route
        return None


@dataclass
class PlankaCredentials:
    token: str | None = None
    username: str | None = None
    password: str | None = None

    @classmethod
    def from_env(cls) -> PlankaCredentials:
        token = os.environ.get("PLANKA_TOKEN")
        if token:
            return cls(token=token)
        username = os.environ.get("PLANKA_USER")
        password = os.environ.get("PLANKA_PASSWORD")
        if username and password:
            return cls(username=username, password=password)
        raise EnvironmentError(
            "Set PLANKA_TOKEN or both PLANKA_USER and PLANKA_PASSWORD"
        )


def load_config(path: str | Path = "pyproject.toml") -> AppConfig:
    path = Path(path)
    with open(path, "rb") as f:
        data = tomllib.load(f)

    section = data["tool"]["artificer-dispatcher"]

    backend_data = section["backend"]
    backend = BackendConfig(
        type=backend_data["type"],
        url=backend_data["url"],
    )

    routing_data = section.get("routing")
    if not routing_data:
        raise ValueError("No routing config found in [tool.artificer-dispatcher.routing]")

    routes = []
    for queue_name, route_data in routing_data.items():
        routes.append(
            RouteConfig(
                queue_name=queue_name,
                command=route_data["command"],
                args=route_data.get("args", []),
                in_progress_queue=route_data.get("in_progress_queue", "In Progress"),
                timeout=route_data.get("timeout"),
            )
        )

    return AppConfig(
        poll_interval=section.get("poll_interval", 30),
        max_concurrent_agents=section.get("max_concurrent_agents", 3),
        api_host=section.get("api_host", "127.0.0.1"),
        api_port=section.get("api_port", 8000),
        backend=backend,
        routes=routes,
        default_agent_timeout=section.get("default_agent_timeout"),
    )
