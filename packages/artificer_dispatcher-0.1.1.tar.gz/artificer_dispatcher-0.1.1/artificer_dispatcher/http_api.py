from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from artificer_dispatcher.adapters.base import TaskAdapter
from artificer_dispatcher.task_operations import (
    _add_comment,
    _create_task,
    _get_task_details,
    _move_task,
    _update_task,
)

if TYPE_CHECKING:
    from artificer_dispatcher.router import Router


def create_app(adapter: TaskAdapter, router: Router | None = None) -> Starlette:

    async def get_task_details(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            result = _get_task_details(adapter, task_id)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result)

    async def add_comment(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        comment = body.get("comment")
        if not comment:
            return JSONResponse(
                {"error": "Missing required field: comment"}, status_code=400
            )
        try:
            result = _add_comment(adapter, task_id, comment)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse({"message": result})

    async def move_task(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        target_queue = body.get("target_queue")
        if not target_queue:
            return JSONResponse(
                {"error": "Missing required field: target_queue"}, status_code=400
            )
        try:
            result = _move_task(adapter, task_id, target_queue)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse({"message": result})

    async def create_task(request: Request) -> JSONResponse:
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        missing = [
            f for f in ("queue_name", "name", "description") if not body.get(f)
        ]
        if missing:
            return JSONResponse(
                {"error": f"Missing required fields: {', '.join(missing)}"},
                status_code=400,
            )
        try:
            result = _create_task(
                adapter, body["queue_name"], body["name"], body["description"]
            )
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result, status_code=201)

    async def update_task(request: Request) -> JSONResponse:
        task_id = request.path_params["task_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON body"}, status_code=400)
        UPDATABLE_FIELDS = {"assignees", "name", "description", "labels"}
        kwargs = {k: v for k, v in body.items() if k in UPDATABLE_FIELDS}
        if not kwargs:
            return JSONResponse(
                {"error": "No updatable fields provided"}, status_code=400
            )
        try:
            result = _update_task(adapter, task_id, **kwargs)
        except KeyError as e:
            return JSONResponse({"error": str(e)}, status_code=404)
        except (ValueError, TypeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        return JSONResponse(result)

    async def status(request: Request) -> JSONResponse:
        if router is None:
            return JSONResponse({"error": "Router not available"}, status_code=503)
        return JSONResponse(router.get_status())

    routes = [
        Route("/status", status, methods=["GET"]),
        Route("/tasks/{task_id}/comments", add_comment, methods=["POST"]),
        Route("/tasks/{task_id}/move", move_task, methods=["POST"]),
        Route("/tasks/{task_id}", update_task, methods=["PATCH"]),
        Route("/tasks/{task_id}", get_task_details, methods=["GET"]),
        Route("/tasks", create_task, methods=["POST"]),
    ]

    return Starlette(routes=routes)
