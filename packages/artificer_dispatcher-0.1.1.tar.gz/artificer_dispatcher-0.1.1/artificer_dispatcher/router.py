from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from artificer_dispatcher.agents.claude import ClaudeAgentAdapter
from artificer_dispatcher.agents.default import DefaultAgentAdapter

if TYPE_CHECKING:
    from artificer_dispatcher.adapters.base import Task, TaskAdapter
    from artificer_dispatcher.agents.base import AgentAdapter
    from artificer_dispatcher.config import AppConfig

log = logging.getLogger(__name__)


@dataclass
class AgentProcess:
    task_id: str
    process: asyncio.subprocess.Process
    command: str = ""
    session_id: str | None = None
    started_at: float = field(default_factory=time.time)


class Router:
    def __init__(self, config: AppConfig, adapter: TaskAdapter) -> None:
        self._config = config
        self._adapter = adapter
        self._active: dict[str, AgentProcess] = {}
        self._seen_ids: set[str] = set()
        self._monitor_tasks: dict[str, asyncio.Task] = {}
        # Agent adapters for different agent types
        self._default_adapter = DefaultAgentAdapter()
        self._claude_adapter = ClaudeAgentAdapter()

    @property
    def available_slots(self) -> int:
        return self._config.max_concurrent_agents - len(self._active)

    def _adapter_for_command(self, command: str) -> AgentAdapter:
        """Select the appropriate agent adapter based on command."""
        if command == "claude":
            return self._claude_adapter
        return self._default_adapter

    def get_status(self) -> dict:
        now = time.time()
        agents = []
        for agent in self._active.values():
            agent_adapter = self._adapter_for_command(agent.command)
            status = {
                "task_id": agent.task_id,
                "pid": agent.process.pid,
                "command": agent.command,
                "running_for_seconds": round(now - agent.started_at),
            }
            # Add adapter-specific status extras
            status.update(agent_adapter.get_status_extras(agent))
            agents.append(status)
        return {
            "active_agents": agents,
            "available_slots": self.available_slots,
            "max_concurrent_agents": self._config.max_concurrent_agents,
        }

    async def run(self) -> None:
        log.info(
            "Router started: polling every %ds, max %d agents",
            self._config.poll_interval,
            self._config.max_concurrent_agents,
        )
        try:
            while True:
                try:
                    await self._poll_once()
                except asyncio.CancelledError:
                    raise
                except Exception:
                    log.exception("Poll failed")
                await asyncio.sleep(self._config.poll_interval)
        except asyncio.CancelledError:
            log.info("Router cancelled, shutting down")
            await self._shutdown()

    async def _poll_once(self) -> None:
        if self.available_slots <= 0:
            log.debug("No available slots, skipping poll")
            return

        tasks = self._adapter.get_ready_tasks(self._config.ready_queue_names)

        for task in tasks:
            if self.available_slots <= 0:
                break
            if task.id in self._seen_ids or task.id in self._active:
                continue
            await self._spawn_agent(task)

    async def _spawn_agent(self, task: Task) -> None:
        route = self._config.route_for_queue(task.source_queue)
        if route is None:
            log.warning("No route for queue %r, skipping task %s", task.source_queue, task.id)
            return

        self._adapter.move_task(task.id, route.in_progress_queue)
        try:
            self._adapter.update_task(task.id, assignees=["me"])
            log.info("Moved and assigned task %s to %r", task.id, route.in_progress_queue)
        except Exception:
            log.warning("Moved task %s but assignment failed", task.id, exc_info=True)

        cmd = route.format_command(
            task_id=task.id,
            task_name=task.name,
            task_url=task.url,
        )

        # Select adapter and augment command with agent-specific flags
        agent_adapter = self._adapter_for_command(route.command)
        cmd = agent_adapter.augment_command(cmd, route)

        try:
            cmd_str = " ".join(cmd)
            comment = agent_adapter.format_spawn_comment(cmd_str)
            self._adapter.add_comment(task.id, comment)
        except Exception:
            log.warning("Failed to add spawn comment for task %s", task.id, exc_info=True)

        log.info("Spawning agent for task %s: %s", task.id, cmd)
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        # Determine timeout: route-specific > default > None
        timeout = route.timeout
        if timeout is None:
            timeout = self._config.default_agent_timeout

        agent = AgentProcess(task_id=task.id, process=process, command=route.command)
        self._active[task.id] = agent
        self._seen_ids.add(task.id)

        monitor = asyncio.create_task(self._monitor_agent(task, process, timeout))
        self._monitor_tasks[task.id] = monitor

    async def _monitor_agent(self, task: Task, process: asyncio.subprocess.Process, timeout: int | None = None) -> None:
        agent = self._active.get(task.id)
        timed_out = False
        error_snippet = ""

        async def read_stdout():
            """Read stdout line by line and let adapter process it."""
            if agent and process.stdout:
                agent_adapter = self._adapter_for_command(agent.command)
                try:
                    async for raw_line in process.stdout:
                        line = raw_line.decode(errors="replace").strip()
                        agent_adapter.process_stdout_line(line, agent, task, self._adapter)
                except asyncio.CancelledError:
                    pass  # Stdout reader cancelled, likely due to timeout

        try:
            # Run stdout reading concurrently with process waiting
            stdout_task = asyncio.create_task(read_stdout())

            # Wait for process with optional timeout
            if timeout is not None:
                try:
                    await asyncio.wait_for(process.wait(), timeout=timeout)
                except TimeoutError:
                    timed_out = True
                    log.warning("Agent for task %s timed out after %d seconds", task.id, timeout)
                    process.terminate()
                    try:
                        await asyncio.wait_for(process.wait(), timeout=5)
                    except TimeoutError:
                        log.warning("Agent for task %s did not terminate gracefully, killing", task.id)
                        process.kill()
                        await process.wait()
            else:
                await process.wait()

            # Wait for stdout reading to complete (it should finish quickly after process exits)
            try:
                await asyncio.wait_for(stdout_task, timeout=5)
            except TimeoutError:
                log.warning("Stdout reading for task %s did not finish, cancelling", task.id)
                stdout_task.cancel()

            rc = process.returncode
            log.info("Agent for task %s exited with code %d", task.id, rc)

            if not timed_out and rc != 0:
                stderr = b""
                if process.stderr:
                    stderr = await process.stderr.read()
                error_snippet = stderr.decode(errors="replace")[:500] if stderr else "no stderr"
                log.warning("Agent stderr for task %s: %s", task.id, error_snippet)
        except asyncio.CancelledError:
            log.info("Monitor cancelled for task %s, terminating process", task.id)
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=5)
            except TimeoutError:
                process.kill()
                await process.wait()
        finally:
            try:
                if agent:
                    agent_adapter = self._adapter_for_command(agent.command)
                    comment = agent_adapter.format_exit_comment(
                        agent, timed_out, timeout, error_snippet, ""
                    )
                    self._adapter.add_comment(task.id, comment)
            except Exception:
                log.warning("Failed to add exit comment for task %s", task.id, exc_info=True)
            self._active.pop(task.id, None)
            self._monitor_tasks.pop(task.id, None)
            self._seen_ids.discard(task.id)

    async def _shutdown(self) -> None:
        for monitor in list(self._monitor_tasks.values()):
            monitor.cancel()
        if self._monitor_tasks:
            await asyncio.gather(*self._monitor_tasks.values(), return_exceptions=True)
        log.info("Router shut down, all agents terminated")
