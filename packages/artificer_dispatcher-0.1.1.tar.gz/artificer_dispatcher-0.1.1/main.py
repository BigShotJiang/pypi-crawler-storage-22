from artificer_dispatcher.cli import main

if __name__ == "__main__":
    main()
