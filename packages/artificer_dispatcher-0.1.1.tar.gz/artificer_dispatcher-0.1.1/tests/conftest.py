from __future__ import annotations

import json

import pytest

from artificer_dispatcher.adapters.base import Task
from artificer_dispatcher.adapters.json_file import JsonFileAdapter
from artificer_dispatcher.config import AppConfig, BackendConfig, RouteConfig


@pytest.fixture
def sample_config(tmp_path) -> AppConfig:
    json_path = tmp_path / "board.json"
    return AppConfig(
        poll_interval=1,
        max_concurrent_agents=2,
        api_host="127.0.0.1",
        api_port=9999,
        backend=BackendConfig(
            type="json",
            url=str(json_path),
        ),
        routes=[
            RouteConfig(queue_name="Bugs", command="echo", args=["bug", "{task_id}"]),
            RouteConfig(queue_name="Features", command="echo", args=["feature", "{task_id}"]),
        ],
    )


@pytest.fixture
def json_board_data() -> dict:
    return {
        "queues": {
            "Bugs": [
                {
                    "id": "1",
                    "name": "Fix login crash",
                    "description": "App crashes on login",
                    "labels": ["urgent"],
                    "assignees": ["alice"],
                    "comments": [
                        {"author": "bob", "text": "Reproduced on staging", "created_at": "2025-01-01T00:00:00Z"}
                    ],
                    "tasks": [
                        {"name": "Write test", "is_completed": False},
                        {"name": "Fix code", "is_completed": False},
                    ],
                },
                {
                    "id": "2",
                    "name": "Fix timeout error",
                    "description": "API times out after 30s",
                    "labels": [],
                    "assignees": [],
                    "comments": [],
                    "tasks": [],
                },
            ],
            "Features": [
                {
                    "id": "3",
                    "name": "Add dark mode",
                    "description": "Support dark theme",
                    "labels": ["enhancement"],
                    "assignees": ["charlie"],
                    "comments": [],
                    "tasks": [],
                },
            ],
            "In Progress": [],
            "Done": [],
        }
    }


@pytest.fixture
def json_adapter(tmp_path, json_board_data) -> JsonFileAdapter:
    path = tmp_path / "board.json"
    path.write_text(json.dumps(json_board_data))
    return JsonFileAdapter(path)


@pytest.fixture
def sample_tasks() -> list[Task]:
    return [
        Task(id="1", name="Fix login crash", description="App crashes on login", source_queue="Bugs", labels=["urgent"], assignees=["alice"]),
        Task(id="2", name="Fix timeout error", description="API times out after 30s", source_queue="Bugs"),
        Task(id="3", name="Add dark mode", description="Support dark theme", source_queue="Features", labels=["enhancement"], assignees=["charlie"]),
    ]
