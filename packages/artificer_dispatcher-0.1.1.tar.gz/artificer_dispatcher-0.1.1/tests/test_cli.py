from __future__ import annotations

import logging
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from artificer_dispatcher.cli import main, run, setup_logging
from artificer_dispatcher.config import AppConfig, BackendConfig, RouteConfig


def _make_config(api_port: int = 8000) -> AppConfig:
    return AppConfig(
        poll_interval=30,
        max_concurrent_agents=3,
        api_host="127.0.0.1",
        api_port=api_port,
        backend=BackendConfig(type="json", url="/tmp/board.json"),
        routes=[RouteConfig(queue_name="Bugs", command="echo", args=["bug"])],
    )


class TestSetupLogging:
    def _reset_logging(self):
        root = logging.getLogger()
        for handler in root.handlers[:]:
            root.removeHandler(handler)
        root.setLevel(logging.WARNING)

    def test_debug_mode(self):
        self._reset_logging()
        setup_logging(debug=True)
        assert logging.getLogger().level == logging.DEBUG

    def test_info_mode(self):
        self._reset_logging()
        setup_logging(debug=False)
        assert logging.getLogger().level == logging.INFO

    def test_default_is_info(self):
        self._reset_logging()
        setup_logging()
        assert logging.getLogger().level == logging.INFO


class TestMainArgParsing:
    def test_no_args(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["artificer-dispatcher"])
        with (
            patch("dotenv.load_dotenv") as mock_dotenv,
            patch("artificer_dispatcher.cli.setup_logging") as mock_logging,
            patch("asyncio.run") as mock_asyncio_run,
        ):
            main()
            mock_dotenv.assert_called_once()
            mock_logging.assert_called_once_with(debug=False)
            mock_asyncio_run.assert_called_once()
            # Verify the coroutine arg is run() with port_override=None
            coro = mock_asyncio_run.call_args[0][0]
            coro.close()

    def test_debug_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["artificer-dispatcher", "--debug"])
        with (
            patch("dotenv.load_dotenv"),
            patch("artificer_dispatcher.cli.setup_logging") as mock_logging,
            patch("asyncio.run") as mock_asyncio_run,
        ):
            main()
            mock_logging.assert_called_once_with(debug=True)
            coro = mock_asyncio_run.call_args[0][0]
            coro.close()

    def test_port_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["artificer-dispatcher", "--port", "9090"])
        with (
            patch("dotenv.load_dotenv"),
            patch("artificer_dispatcher.cli.setup_logging"),
            patch("asyncio.run") as mock_asyncio_run,
        ):
            main()
            mock_asyncio_run.assert_called_once()
            coro = mock_asyncio_run.call_args[0][0]
            coro.close()

    def test_debug_and_port_flags(self, monkeypatch):
        monkeypatch.setattr(
            "sys.argv", ["artificer-dispatcher", "--debug", "--port", "9090"]
        )
        with (
            patch("dotenv.load_dotenv"),
            patch("artificer_dispatcher.cli.setup_logging") as mock_logging,
            patch("asyncio.run") as mock_asyncio_run,
        ):
            main()
            mock_logging.assert_called_once_with(debug=True)
            mock_asyncio_run.assert_called_once()
            coro = mock_asyncio_run.call_args[0][0]
            coro.close()

    def test_keyboard_interrupt_handled(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["artificer-dispatcher"])
        with (
            patch("dotenv.load_dotenv"),
            patch("artificer_dispatcher.cli.setup_logging"),
            patch("asyncio.run", side_effect=KeyboardInterrupt),
        ):
            # Should not raise
            main()

    def test_no_args_defaults_port_to_none(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["artificer-dispatcher"])
        captured_port = {}

        original_run = run

        async def fake_run(port_override=None):
            captured_port["value"] = port_override

        with (
            patch("dotenv.load_dotenv"),
            patch("artificer_dispatcher.cli.setup_logging"),
            patch("artificer_dispatcher.cli.run", side_effect=fake_run) as mock_run,
            patch("asyncio.run") as mock_asyncio_run,
        ):
            # Make asyncio.run actually invoke the coroutine
            def run_coro(coro):
                import asyncio

                loop = asyncio.new_event_loop()
                try:
                    loop.run_until_complete(coro)
                finally:
                    loop.close()

            mock_asyncio_run.side_effect = run_coro
            main()
            assert captured_port["value"] is None


class TestRunPortOverride:
    @pytest.mark.asyncio
    async def test_run_with_port_override(self):
        config = _make_config(api_port=8000)

        with (
            patch(
                "artificer_dispatcher.config.load_config", return_value=config
            ),
            patch("artificer_dispatcher.adapters.create_adapter") as mock_adapter,
            patch("artificer_dispatcher.router.Router") as mock_router_cls,
            patch(
                "artificer_dispatcher.http_api.create_app"
            ) as mock_create_app,
            patch("uvicorn.Config") as mock_uvicorn_config,
            patch("uvicorn.Server") as mock_uvicorn_server,
        ):
            mock_server = MagicMock()
            mock_server.run = MagicMock(return_value=None)
            mock_uvicorn_server.return_value = mock_server

            mock_router_instance = MagicMock()
            mock_router_instance.run = AsyncMock(return_value=None)
            mock_router_cls.return_value = mock_router_instance

            await run(port_override=9090)

            # Verify port was overridden on the config
            assert config.api_port == 9090
            # Verify uvicorn.Config was called with the overridden port
            mock_uvicorn_config.assert_called_once_with(
                mock_create_app.return_value,
                host="127.0.0.1",
                port=9090,
                log_level="info",
            )

    @pytest.mark.asyncio
    async def test_run_without_port_override(self):
        config = _make_config(api_port=8000)

        with (
            patch(
                "artificer_dispatcher.config.load_config", return_value=config
            ),
            patch("artificer_dispatcher.adapters.create_adapter"),
            patch("artificer_dispatcher.router.Router") as mock_router_cls,
            patch(
                "artificer_dispatcher.http_api.create_app"
            ) as mock_create_app,
            patch("uvicorn.Config") as mock_uvicorn_config,
            patch("uvicorn.Server") as mock_uvicorn_server,
        ):
            mock_server = MagicMock()
            mock_server.run = MagicMock(return_value=None)
            mock_uvicorn_server.return_value = mock_server

            mock_router_instance = MagicMock()
            mock_router_instance.run = AsyncMock(return_value=None)
            mock_router_cls.return_value = mock_router_instance

            await run()

            # Verify port stayed at the config default
            assert config.api_port == 8000
            mock_uvicorn_config.assert_called_once_with(
                mock_create_app.return_value,
                host="127.0.0.1",
                port=8000,
                log_level="info",
            )

    @pytest.mark.asyncio
    async def test_run_with_none_port_override(self):
        config = _make_config(api_port=8000)

        with (
            patch(
                "artificer_dispatcher.config.load_config", return_value=config
            ),
            patch("artificer_dispatcher.adapters.create_adapter"),
            patch("artificer_dispatcher.router.Router") as mock_router_cls,
            patch("artificer_dispatcher.http_api.create_app"),
            patch("uvicorn.Config") as mock_uvicorn_config,
            patch("uvicorn.Server") as mock_uvicorn_server,
        ):
            mock_server = MagicMock()
            mock_server.run = MagicMock(return_value=None)
            mock_uvicorn_server.return_value = mock_server

            mock_router_instance = MagicMock()
            mock_router_instance.run = AsyncMock(return_value=None)
            mock_router_cls.return_value = mock_router_instance

            await run(port_override=None)

            # Verify port stayed at config default
            assert config.api_port == 8000
