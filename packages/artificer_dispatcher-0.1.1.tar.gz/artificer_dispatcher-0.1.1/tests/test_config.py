from __future__ import annotations

import textwrap

import pytest

from artificer_dispatcher.config import (
    AppConfig,
    PlankaCredentials,
    RouteConfig,
    load_config,
)


def _write_toml(tmp_path, content: str):
    path = tmp_path / "pyproject.toml"
    path.write_text(textwrap.dedent(content))
    return path


class TestLoadConfig:
    def test_load_config_minimal(self, tmp_path):
        path = _write_toml(tmp_path, """\
            [tool.artificer-dispatcher]

            [tool.artificer-dispatcher.backend]
            type = "json"
            url = "/tmp/board.json"

            [tool.artificer-dispatcher.routing."Bugs"]
            command = "echo"
            args = ["bug"]
        """)
        config = load_config(path)
        assert config.backend.type == "json"
        assert config.backend.url == "/tmp/board.json"
        assert len(config.routes) == 1
        assert config.routes[0].queue_name == "Bugs"

    def test_load_config_defaults(self, tmp_path):
        path = _write_toml(tmp_path, """\
            [tool.artificer-dispatcher]

            [tool.artificer-dispatcher.backend]
            type = "json"
            url = "/tmp/board.json"

            [tool.artificer-dispatcher.routing."Bugs"]
            command = "echo"
        """)
        config = load_config(path)
        assert config.poll_interval == 30
        assert config.max_concurrent_agents == 3
        assert config.api_host == "127.0.0.1"
        assert config.api_port == 8000
        assert config.routes[0].in_progress_queue == "In Progress"
        assert config.default_agent_timeout is None
        assert config.routes[0].timeout is None

    def test_load_config_with_default_timeout(self, tmp_path):
        path = _write_toml(tmp_path, """\
            [tool.artificer-dispatcher]
            default_agent_timeout = 300

            [tool.artificer-dispatcher.backend]
            type = "json"
            url = "/tmp/board.json"

            [tool.artificer-dispatcher.routing."Bugs"]
            command = "echo"
            args = ["bug"]
        """)
        config = load_config(path)
        assert config.default_agent_timeout == 300

    def test_load_config_with_route_specific_timeout(self, tmp_path):
        path = _write_toml(tmp_path, """\
            [tool.artificer-dispatcher]
            default_agent_timeout = 300

            [tool.artificer-dispatcher.backend]
            type = "json"
            url = "/tmp/board.json"

            [tool.artificer-dispatcher.routing."Bugs"]
            command = "echo"
            args = ["bug"]
            timeout = 60

            [tool.artificer-dispatcher.routing."Features"]
            command = "echo"
            args = ["feat"]
            timeout = 120
        """)
        config = load_config(path)
        assert config.default_agent_timeout == 300

        bugs_route = config.route_for_queue("Bugs")
        assert bugs_route is not None
        assert bugs_route.timeout == 60

        features_route = config.route_for_queue("Features")
        assert features_route is not None
        assert features_route.timeout == 120

    def test_load_config_missing_routing(self, tmp_path):
        path = _write_toml(tmp_path, """\
            [tool.artificer-dispatcher]

            [tool.artificer-dispatcher.backend]
            type = "json"
            url = "/tmp/board.json"
        """)
        with pytest.raises(ValueError, match="No routing config"):
            load_config(path)

    def test_load_config_missing_backend(self, tmp_path):
        path = _write_toml(tmp_path, """\
            [tool.artificer-dispatcher]

            [tool.artificer-dispatcher.routing."Bugs"]
            command = "echo"
        """)
        with pytest.raises(KeyError):
            load_config(path)


class TestRouteConfig:
    def test_format_command(self):
        route = RouteConfig(
            queue_name="Bugs",
            command="claude",
            args=["-p", "Fix bug #{task_id}: {task_name}"],
        )
        result = route.format_command(
            task_id="42",
            task_name="Login crash",
            task_url="http://example.com/cards/42",
            
        )
        assert result == [
            "claude",
            "-p",
            "Fix bug #42: Login crash",
        ]


class TestAppConfig:
    def test_ready_queue_names(self):
        config = AppConfig(
            poll_interval=30,
            max_concurrent_agents=3,
            api_host="127.0.0.1",
            api_port=8000,
            backend=_dummy_backend(),
            routes=[
                RouteConfig(queue_name="Bugs", command="echo"),
                RouteConfig(queue_name="Features", command="echo"),
            ],
        )
        assert config.ready_queue_names == ["Bugs", "Features"]

    def test_route_for_queue(self):
        route_bugs = RouteConfig(queue_name="Bugs", command="echo", args=["bug"])
        route_features = RouteConfig(queue_name="Features", command="echo", args=["feat"])
        config = AppConfig(
            poll_interval=30,
            max_concurrent_agents=3,
            api_host="127.0.0.1",
            api_port=8000,
            backend=_dummy_backend(),
            routes=[route_bugs, route_features],
        )
        assert config.route_for_queue("Bugs") is route_bugs
        assert config.route_for_queue("Features") is route_features
        assert config.route_for_queue("Unknown") is None


class TestResearchRouteConfig:
    def test_research_route_parsed_from_config(self, tmp_path):
        """Test that the Research route is parsed correctly from pyproject.toml."""
        path = _write_toml(tmp_path, """\
            [tool.artificer-dispatcher]

            [tool.artificer-dispatcher.backend]
            type = "json"
            url = "/tmp/board.json"

            [tool.artificer-dispatcher.routing."Artificer Dispatcher.Research.Todo"]
            command = "claude"
            args = ["--agent", "research", "-p", "Work on task {task_id}: {task_name}."]
            in_progress_queue = "Artificer Dispatcher.Research.In Progress"
        """)
        config = load_config(path)

        research_route = config.route_for_queue("Artificer Dispatcher.Research.Todo")
        assert research_route is not None
        assert research_route.command == "claude"
        assert research_route.args == ["--agent", "research", "-p", "Work on task {task_id}: {task_name}."]
        assert research_route.in_progress_queue == "Artificer Dispatcher.Research.In Progress"

    def test_research_route_command_formatting(self):
        """Test that the Research route formats commands correctly."""
        route = RouteConfig(
            queue_name="Artificer Dispatcher.Research.Todo",
            command="claude",
            args=["--agent", "research", "-p", "Work on task {task_id}: {task_name}."],
            in_progress_queue="Artificer Dispatcher.Research.In Progress",
        )
        result = route.format_command(
            task_id="123",
            task_name="Investigate API performance",
            task_url="http://example.com/cards/123",
        )
        assert result == [
            "claude",
            "--agent",
            "research",
            "-p",
            "Work on task 123: Investigate API performance.",
        ]

class TestPlankaCredentials:
    def test_from_env_token(self, monkeypatch):
        monkeypatch.setenv("PLANKA_TOKEN", "my-token")
        monkeypatch.delenv("PLANKA_USER", raising=False)
        monkeypatch.delenv("PLANKA_PASSWORD", raising=False)
        creds = PlankaCredentials.from_env()
        assert creds.token == "my-token"
        assert creds.username is None

    def test_from_env_password(self, monkeypatch):
        monkeypatch.delenv("PLANKA_TOKEN", raising=False)
        monkeypatch.setenv("PLANKA_USER", "admin")
        monkeypatch.setenv("PLANKA_PASSWORD", "secret")
        creds = PlankaCredentials.from_env()
        assert creds.token is None
        assert creds.username == "admin"
        assert creds.password == "secret"

    def test_from_env_missing(self, monkeypatch):
        monkeypatch.delenv("PLANKA_TOKEN", raising=False)
        monkeypatch.delenv("PLANKA_USER", raising=False)
        monkeypatch.delenv("PLANKA_PASSWORD", raising=False)
        with pytest.raises(EnvironmentError):
            PlankaCredentials.from_env()


def _dummy_backend():
    from artificer_dispatcher.config import BackendConfig
    return BackendConfig(type="json", url="/tmp/board.json")
