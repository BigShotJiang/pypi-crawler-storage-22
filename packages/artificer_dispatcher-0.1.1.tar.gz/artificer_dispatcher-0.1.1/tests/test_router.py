from __future__ import annotations

import asyncio
import json

import pytest

from artificer_dispatcher.adapters.json_file import JsonFileAdapter
from artificer_dispatcher.config import AppConfig, BackendConfig, RouteConfig
from artificer_dispatcher.router import Router


def _make_config(json_path: str, max_concurrent: int = 2) -> AppConfig:
    return AppConfig(
        poll_interval=1,
        max_concurrent_agents=max_concurrent,
        api_host="127.0.0.1",
        api_port=9999,
        backend=BackendConfig(type="json", url=json_path),
        routes=[
            RouteConfig(queue_name="Bugs", command="true", args=[], in_progress_queue="In Progress"),
            RouteConfig(queue_name="Features", command="echo", args=["{task_id}", "{task_name}"], in_progress_queue="In Progress"),
        ],
    )


def _make_board(tmp_path, board_data: dict | None = None) -> tuple[str, JsonFileAdapter]:
    if board_data is None:
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "1", "name": "Bug one", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                    {"id": "2", "name": "Bug two", "description": "d2", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "Features": [
                    {"id": "3", "name": "Feat one", "description": "d3", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
    path = tmp_path / "board.json"
    path.write_text(json.dumps(board_data))
    return str(path), JsonFileAdapter(path)


async def _wait_and_cleanup(router: Router) -> None:
    """Wait for all active agent processes to finish and clean up."""
    agents = list(router._active.values())
    for agent in agents:
        await agent.process.wait()
    # Let monitor tasks run to clean up _active
    monitors = list(router._monitor_tasks.values())
    if monitors:
        await asyncio.gather(*monitors, return_exceptions=True)


async def _kill_and_cleanup(router: Router) -> None:
    """Terminate all active agent processes and clean up."""
    for agent in list(router._active.values()):
        agent.process.kill()
    for agent in list(router._active.values()):
        await agent.process.wait()
    monitors = list(router._monitor_tasks.values())
    if monitors:
        await asyncio.gather(*monitors, return_exceptions=True)


@pytest.mark.asyncio
class TestPollPicksUpTasks:
    async def test_picks_up_ready_tasks(self, tmp_path):
        json_path, adapter = _make_board(tmp_path)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=3,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress"),
                RouteConfig(queue_name="Features", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )
        router = Router(config, adapter)

        await router._poll_once()

        assert len(router._active) == 3
        assert set(router._active.keys()) == {"1", "2", "3"}

        await _kill_and_cleanup(router)

    async def test_skips_seen_tasks(self, tmp_path):
        json_path, adapter = _make_board(tmp_path)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=3,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress"),
                RouteConfig(queue_name="Features", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )
        router = Router(config, adapter)
        router._seen_ids.add("1")

        await router._poll_once()

        assert "1" not in router._active
        assert "2" in router._active
        assert "3" in router._active

        await _kill_and_cleanup(router)

    async def test_respects_concurrency_limit(self, tmp_path):
        json_path, adapter = _make_board(tmp_path)
        config = _make_config(json_path, max_concurrent=1)
        router = Router(config, adapter)

        await router._poll_once()

        assert len(router._active) == 1

        await _wait_and_cleanup(router)

    async def test_skips_when_no_slots(self, tmp_path):
        json_path, adapter = _make_board(tmp_path)
        config = _make_config(json_path, max_concurrent=1)
        router = Router(config, adapter)

        await router._poll_once()
        first_seen = set(router._seen_ids)

        await router._poll_once()
        # No new tasks picked up - same seen set (or one more if slot freed)
        assert len(router._active) <= 1

        await _wait_and_cleanup(router)


@pytest.mark.asyncio
class TestSpawnAgent:
    async def test_moves_to_in_progress_before_exec(self, tmp_path):
        json_path, adapter = _make_board(tmp_path)
        config = _make_config(json_path)
        router = Router(config, adapter)

        await router._poll_once()

        data = json.loads((tmp_path / "board.json").read_text())
        bug_ids = [t["id"] for t in data["queues"]["Bugs"]]
        ip_ids = [t["id"] for t in data["queues"]["In Progress"]]
        assert "1" not in bug_ids
        assert "1" in ip_ids

        await _wait_and_cleanup(router)

    async def test_formats_command_correctly(self, tmp_path):
        board_data = {
            "queues": {
                "Features": [
                    {"id": "10", "name": "Dark mode", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "Bugs": [],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = _make_config(json_path)
        router = Router(config, adapter)

        await router._poll_once()

        # Wait for the monitor task to complete
        monitor = router._monitor_tasks["10"]
        await monitor

        # Read the board to verify the spawn comment has the formatted command
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "10"), None)
        assert task is not None
        # Verify command was formatted with task_id and task_name
        spawn_comment = next((c["text"] for c in task["comments"] if "Spawning agent" in c["text"]), "")
        assert "10 Dark mode" in spawn_comment



@pytest.mark.asyncio
class TestMonitorAgent:
    async def test_cleans_up_on_completion(self, tmp_path):
        json_path, adapter = _make_board(tmp_path)
        config = _make_config(json_path, max_concurrent=1)
        router = Router(config, adapter)

        await router._poll_once()
        assert len(router._active) == 1
        tid = next(iter(router._active))

        monitor = router._monitor_tasks[tid]
        await monitor

        assert tid not in router._active
        assert tid not in router._monitor_tasks
        assert tid not in router._seen_ids

    async def test_timeout_terminates_agent(self, tmp_path):
        """Test that agents exceeding route timeout are terminated."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "timeout-test", "name": "Long task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=2,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress", timeout=1),
            ],
        )
        router = Router(config, adapter)

        await router._poll_once()
        assert "timeout-test" in router._active

        monitor = router._monitor_tasks["timeout-test"]
        await monitor

        # Agent should be cleaned up after timeout
        assert "timeout-test" not in router._active

        # Check that a timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "timeout-test"), None)
        assert task is not None
        assert any("timed out" in c["text"].lower() for c in task["comments"])

    async def test_default_timeout_applies(self, tmp_path):
        """Test that default_agent_timeout applies when route timeout is not specified."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "default-timeout-test", "name": "Task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=2,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
            default_agent_timeout=1,
        )
        router = Router(config, adapter)

        await router._poll_once()
        assert "default-timeout-test" in router._active

        monitor = router._monitor_tasks["default-timeout-test"]
        await monitor

        # Agent should be cleaned up after default timeout
        assert "default-timeout-test" not in router._active

        # Check that a timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "default-timeout-test"), None)
        assert task is not None
        assert any("timed out" in c["text"].lower() for c in task["comments"])

    async def test_route_timeout_overrides_default(self, tmp_path):
        """Test that route-specific timeout overrides default timeout."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "override-test", "name": "Task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=2,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                # Route timeout of 1s should override default of 100s
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress", timeout=1),
            ],
            default_agent_timeout=100,
        )
        router = Router(config, adapter)

        await router._poll_once()
        assert "override-test" in router._active

        monitor = router._monitor_tasks["override-test"]
        await monitor

        # Agent should be cleaned up after route timeout (1s), not default timeout (100s)
        assert "override-test" not in router._active

        # Check that a timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "override-test"), None)
        assert task is not None
        assert any("timed out" in c["text"].lower() for c in task["comments"])

    async def test_no_timeout_when_not_configured(self, tmp_path):
        """Test that agents run without timeout when not configured."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "no-timeout-test", "name": "Task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=2,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                # No timeout specified, and no default_agent_timeout
                RouteConfig(queue_name="Bugs", command="true", args=[], in_progress_queue="In Progress"),
            ],
        )
        router = Router(config, adapter)

        await router._poll_once()
        assert "no-timeout-test" in router._active

        monitor = router._monitor_tasks["no-timeout-test"]
        await monitor

        # Agent should complete normally
        assert "no-timeout-test" not in router._active

        # Check that no timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "no-timeout-test"), None)
        assert task is not None
        assert not any("timed out" in c["text"].lower() for c in task["comments"])


@pytest.mark.asyncio
class TestAgentAdapterSelection:
    """Tests for agent adapter selection and behavior."""

    async def test_claude_adapter_selected_for_claude_commands(self, tmp_path):
        """Verify ClaudeAgentAdapter is used for claude commands."""
        board_data = {
            "queues": {
                "Claude Tasks": [
                    {"id": "claude-1", "name": "Claude task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=1,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Claude Tasks", command="claude", args=["--agent", "test"], in_progress_queue="In Progress"),
            ],
        )
        router = Router(config, adapter)

        await router._poll_once()

        # Verify the agent is running
        assert "claude-1" in router._active
        agent = router._active["claude-1"]

        # Verify ClaudeAgentAdapter was used (check for injected flags)
        # The command should have -p, --output-format, stream-json, --verbose
        assert agent.command == "claude"

        # Kill and cleanup
        await _kill_and_cleanup(router)

        # Verify spawn comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "claude-1"), None)
        assert task is not None
        assert any("Spawning agent with command" in c["text"] for c in task["comments"])
        # Verify stream-json flags were injected
        spawn_comment = next((c["text"] for c in task["comments"] if "Spawning agent" in c["text"]), "")
        assert "--output-format stream-json" in spawn_comment
        assert "-p" in spawn_comment or "--print" in spawn_comment

    async def test_default_adapter_for_other_commands(self, tmp_path):
        """Verify DefaultAgentAdapter is used for non-claude commands."""
        board_data = {
            "queues": {
                "Scripts": [
                    {"id": "script-1", "name": "Script task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=1,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Scripts", command="echo", args=["test"], in_progress_queue="In Progress"),
            ],
        )
        router = Router(config, adapter)

        await router._poll_once()

        # Verify the agent is running
        assert "script-1" in router._active
        agent = router._active["script-1"]

        # Verify DefaultAgentAdapter was used (command not modified with Claude flags)
        assert agent.command == "echo"

        # Wait for completion
        await _wait_and_cleanup(router)

        # Verify spawn comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "script-1"), None)
        assert task is not None
        assert any("Spawning agent with command" in c["text"] for c in task["comments"])
        # Verify stream-json flags were NOT injected
        spawn_comment = next((c["text"] for c in task["comments"] if "Spawning agent" in c["text"]), "")
        assert "--output-format" not in spawn_comment
        assert "stream-json" not in spawn_comment

    async def test_status_includes_session_id_for_claude(self, tmp_path):
        """Verify status endpoint includes session_id for Claude agents."""
        board_data = {
            "queues": {
                "Claude Tasks": [
                    {"id": "claude-status", "name": "Claude task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=1,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Claude Tasks", command="claude", args=["test"], in_progress_queue="In Progress"),
            ],
        )
        router = Router(config, adapter)

        await router._poll_once()

        # Manually set a session_id to test status
        agent = router._active["claude-status"]
        agent.session_id = "test-session-123"

        # Get status
        status = router.get_status()

        # Verify session_id is in status
        assert len(status["active_agents"]) == 1
        agent_status = status["active_agents"][0]
        assert agent_status["session_id"] == "test-session-123"
        assert agent_status["command"] == "claude"

        await _kill_and_cleanup(router)

    async def test_status_excludes_session_id_for_non_claude(self, tmp_path):
        """Verify status endpoint does not include session_id for non-Claude agents."""
        board_data = {
            "queues": {
                "Scripts": [
                    {"id": "script-status", "name": "Script task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = _make_board(tmp_path, board_data)
        config = AppConfig(
            poll_interval=1,
            max_concurrent_agents=1,
            api_host="127.0.0.1",
            api_port=9999,
            backend=BackendConfig(type="json", url=json_path),
            routes=[
                RouteConfig(queue_name="Scripts", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )
        router = Router(config, adapter)

        await router._poll_once()

        # Get status
        status = router.get_status()

        # Verify session_id is NOT in status
        assert len(status["active_agents"]) == 1
        agent_status = status["active_agents"][0]
        assert "session_id" not in agent_status
        assert agent_status["command"] == "sleep"

        await _kill_and_cleanup(router)
