# =========================
# main.py
# =========================

import random
import sys
import json
import os
import subprocess
import random
import readline  # For command history and tab completion
import subprocess
import sys
from importlib import resources
from pathlib import Path

# ---------- FILE PATH ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data.json")
BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA_FILE = BASE_DIR / "data.json"
DATA_FILE = Path(
    os.getenv(
        "ARUNCODE_TERM_DATA",
        Path.home() / ".aruncode_term" / "data.json",
    )
)
PACKAGE_NAME = __package__ or "ArunCode_Term"


def _read_packaged_accounts():
    try:
        packaged_path = resources.files(PACKAGE_NAME).joinpath("data.json")
        if packaged_path.is_file():
            return packaged_path.read_text(encoding="utf-8")
        packaged_path = resources.files(PACKAGE_NAME).joinpath("Data", "user_data.json")
        if packaged_path.is_file():
            return packaged_path.read_text(encoding="utf-8")
    except ModuleNotFoundError:
        return None
    return None


# ---------- DATA ----------
def load_accounts():
    if not DATA_FILE.exists():
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        if DEFAULT_DATA_FILE.exists():
            DATA_FILE.write_text(DEFAULT_DATA_FILE.read_text(), encoding="utf-8")
        else:
            packaged_accounts = _read_packaged_accounts()
            if packaged_accounts is not None:
                DATA_FILE.write_text(packaged_accounts, encoding="utf-8")
            else:
                DATA_FILE.write_text("[]", encoding="utf-8")
    try:
        return json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []


def save_accounts(accounts):
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    DATA_FILE.write_text(json.dumps(accounts, indent=4), encoding="utf-8")

# ---------- TERMINAL ----------
def terminal(user):

    hostname = "ArunCode.com"

    # Current directory reference (starts at root)
    cwd = user["fs"]
    path_stack = ["~"]

    # Store file contents
    if "file_contents" not in user:
        user["file_contents"] = {}

    # ---------- Readline Setup ----------
    def completer(text, state):
        # Autocomplete folders and files in cwd
        options = [i for i in list(cwd["folders"].keys()) + cwd["files"] if i.startswith(text)]
        if state < len(options):
            return options[state]
        else:
            return None

    readline.set_completer(completer)
    readline.parse_and_bind("tab: complete")
@@ -223,85 +268,81 @@ def terminal(user):
            # ---------- unknown ----------
            else:
                print(f"{command}: command not found")

    except KeyboardInterrupt:
        print("\nReturning to main menu...")


# ---------- MAIN ----------
def main():

    while True:
        try:
            print("\n1) Login")
            print("2) Create Account")
            print("3) Guest")
            print("4) Exit")

            choice = input(">>> ")

            # ---------- LOGIN ----------
            if choice == "1":
                u = input("user: ")
                p = input("pass: ")

                with open(DATA_FILE, "r") as f:
                    accounts = json.load(f)
                accounts = load_accounts()

                user = next(
                    (a for a in accounts if a["username"] == u and a["password"] == p),
                    None
                )

                if user:
                    terminal(user)
                    with open(DATA_FILE, "w") as f:
                        json.dump(accounts, f, indent=4)
                    save_accounts(accounts)
                else:
                    print("ERROR: Invalid credentials")

            # ---------- CREATE ----------
            elif choice == "2":
                u = input("Choose Username: ")
                p = input("Choose Password: ")
                t = input("User Type: ")

                with open(DATA_FILE, "r") as f:
                    accounts = json.load(f)
                accounts = load_accounts()

                if any(a["username"] == u for a in accounts):
                    print("ERROR: Username exists")
                else:
                    accounts.append({
                        "username": u,
                        "password": p,
                        "sudo": "False",
                        "usertype": t,
                        "fs": {"files": [], "folders": {}}
                    })
                    with open(DATA_FILE, "w") as f:
                        json.dump(accounts, f, indent=4)
                    save_accounts(accounts)
                    print("Account created")

            # ---------- GUEST ----------
            elif choice == "3":
                guest = {
                    "username": "guest" + str(random.randint(1000, 9999)),
                    "sudo": "False",
                    "usertype": "Guest",
                    "fs": {"files": [], "folders": {}}
                }
                terminal(guest)

            # ---------- EXIT ----------
            elif choice == "4":
                sys.exit()

        except KeyboardInterrupt:
            print("\nExiting...")
            sys.exit()


# ---------- ENTRY ----------
if __name__ == "__main__":
    main()
