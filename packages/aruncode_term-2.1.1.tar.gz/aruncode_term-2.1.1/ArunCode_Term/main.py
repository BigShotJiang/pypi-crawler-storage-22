import random
import sys
import json
import os
import readline
from pathlib import Path
from importlib import resources

# ---------- CONFIGURATION ----------
BASE_DIR = Path(__file__).resolve().parent
# Priority: ENV Var > Home Dir > Local Folder
DATA_FILE = Path(os.getenv("ARUNCODE_TERM_DATA", Path.home() / ".aruncode_term" / "data.json"))
PACKAGE_NAME = __package__ or "ArunCode_Term"

def _read_packaged_accounts():
    """Attempts to read default data from the installed package resources."""
    try:
        for filename in ["data.json", "Data/user_data.json"]:
            packaged_path = resources.files(PACKAGE_NAME).joinpath(filename)
            if packaged_path.is_file():
                return packaged_path.read_text(encoding="utf-8")
    except (ModuleNotFoundError, Exception):
        return None
    return None

def load_accounts():
    """Loads accounts from the filesystem, initializing with defaults if missing."""
    if not DATA_FILE.exists():
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        # Try local default first, then packaged resource, then empty list
        local_default = BASE_DIR / "data.json"
        if local_default.exists():
            DATA_FILE.write_text(local_default.read_text(), encoding="utf-8")
        else:
            packaged = _read_packaged_accounts()
            DATA_FILE.write_text(packaged if packaged else "[]", encoding="utf-8")
    
    try:
        return json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []

def save_accounts(accounts):
    """Saves the current accounts list to the designated data file."""
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    DATA_FILE.write_text(json.dumps(accounts, indent=4), encoding="utf-8")

# ---------- TERMINAL LOGIC ----------
def terminal(user):
    print(f"Welcome to ArunCode Terminal, {user['username']}!")
    cwd = user["fs"]
    
    # Readline Setup for Tab Completion
    def completer(text, state):
        options = [i for i in list(cwd.get("folders", {}).keys()) + cwd.get("files", []) if i.startswith(text)]
        return options[state] if state < len(options) else None

    readline.set_completer(completer)
    readline.parse_and_bind("tab: complete")

    while True:
        try:
            prompt = f"{user['username']}@ArunCode:~ $ "
            cmd_input = input(prompt).strip()
            if not cmd_input: continue
            
            parts = cmd_input.split()
            command = parts[0]

            if command == "exit":
                break
            elif command == "ls":
                items = list(cwd["folders"].keys()) + cwd["files"]
                print("  ".join(items) if items else "(empty)")
            elif command == "whoami":
                print(f"User: {user['username']}\nType: {user['usertype']}\nSudo: {user['sudo']}")
            else:
                print(f"{command}: command not found")

        except KeyboardInterrupt:
            print("\nReturning to main menu...")
            break

# ---------- MAIN INTERFACE ----------
def main():
    while True:
        try:
            print("\n1) Login\n2) Create Account\n3) Guest\n4) Exit")
            choice = input(">>> ").strip()

            if choice == "1":
                u = input("user: ")
                p = input("pass: ")
                accounts = load_accounts()
                user = next((a for a in accounts if a["username"] == u and a["password"] == p), None)
                
                if user:
                    terminal(user)
                    save_accounts(accounts) # Save changes after terminal session
                else:
                    print("ERROR: Invalid credentials")

            elif choice == "2":
                u = input("Choose Username: ")
                p = input("Choose Password: ")
                t = input("User Type: ")
                accounts = load_accounts()

                if any(a["username"] == u for a in accounts):
                    print("ERROR: Username exists")
                else:
                    accounts.append({
                        "username": u, "password": p, "sudo": "False",
                        "usertype": t, "fs": {"files": [], "folders": {}}
                    })
                    save_accounts(accounts)
                    print("Account created!")

            elif choice == "3":
                guest = {
                    "username": f"guest{random.randint(1000, 9999)}",
                    "sudo": "False", "usertype": "Guest",
                    "fs": {"files": [], "folders": {}}
                }
                terminal(guest)

            elif choice == "4":
                sys.exit()

        except KeyboardInterrupt:
            print("\nExiting...")
            sys.exit()

if __name__ == "__main__":
    main()
