"""ArunCode Terminal (local-only simulated shell)."""
import base64
import random
import sys
import json
import os
import readline
import shlex
from datetime import datetime, timezone
import platform
from pathlib import Path
# Local location for saving accounts/cache
DATA_FILE = Path(os.getenv("ARUNCODE_TERM_DATA", Path.home() / ".aruncode_term" / "data.json"))
SEED_DATA_FILE = Path(__file__).resolve().parent / "Data" / "user_data.json"

def blue(text):
    return f"\033[34m{str(text)}\033[0m"


def yellow(text):
    return f"\033[33m{str(text)}\033[0m"

def _read_accounts_file(path: Path):
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _normalize_accounts(accounts):
    normalized = []
    for item in accounts:
        if not isinstance(item, dict):
            continue
        username = item.get("username")
        password = item.get("password")
        if isinstance(username, str) and isinstance(password, str):
            normalized.append(item)
    return normalized


def _merge_accounts(seed_accounts, local_accounts):
    merged_by_username = {}
    for account in seed_accounts:
        merged_by_username[account["username"]] = account
    for account in local_accounts:
        merged_by_username[account["username"]] = account
    return list(merged_by_username.values())

def load_accounts():
    """Loads accounts from local cache (and optional bundled seed)."""
    seed_accounts = _normalize_accounts(_read_accounts_file(SEED_DATA_FILE))
    local_accounts = _normalize_accounts(_read_accounts_file(DATA_FILE)) if DATA_FILE.exists() else []
    accounts = _merge_accounts(seed_accounts, local_accounts)

    # Ensure first-run still gets the bundled users.
    if seed_accounts and not DATA_FILE.exists():
        save_accounts(accounts)

    return accounts

def save_accounts(accounts, *, push_remote=False):
    """Saves the current accounts list to the local filesystem."""
    try:
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        DATA_FILE.write_text(json.dumps(accounts, indent=4), encoding="utf-8")
    except Exception as e:
        print(f"Error saving data: {e}")
        return None

# ---------- TERMINAL LOGIC ----------
def terminal(user):
    print(f"\nWelcome to ArunCode Terminal, {user['username']}!")
    root = user.get("fs", {"files": [], "folders": {}})
    cwd = root
    path_parts = []
    commands = [
        "help",
        "exit",
        "clear",
        "history",
        "pwd",
        "cd",
        "ls",
        "tree",
        "mkdir",
        "rmdir",
        "touch",
        "rm",
        "cp",
        "mv",
        "cat",
        "head",
        "tail",
        "grep",
        "echo",
        "whoami",
        "id",
        "uname",
        "date",
        "which",
        "man",
        "sudo",
        "apt",
        "apt-get",
        "update",
        "upgrade",
        "pip",
        "pip3",
        "python",
        "python3",
    ]

    file_contents = user.get("file_contents")
    if not isinstance(file_contents, dict):
        file_contents = {}
        user["file_contents"] = file_contents

    packages = user.get("packages")
    if not isinstance(packages, list):
        packages = []
        user["packages"] = packages

    python_packages = user.get("python_packages")
    if not isinstance(python_packages, list):
        python_packages = []
        user["python_packages"] = python_packages

    history = []

    def _get_installed_packages():
        return {p for p in packages if isinstance(p, str)}

    def _set_installed_packages(pkgs):
        packages[:] = sorted(pkgs)

    def _get_python_packages():
        return {p for p in python_packages if isinstance(p, str)}

    def _set_python_packages(pkgs):
        python_packages[:] = sorted(pkgs)

    def _pip_available():
        installed = _get_installed_packages()
        return any(p in installed for p in ("pip", "python3-pip", "pip3"))

    def _fs_walk_files(node, prefix_parts):
        files = []
        for fname in node.get("files", []) or []:
            if isinstance(fname, str):
                files.append("/".join(prefix_parts + [fname]) if prefix_parts else fname)
        for dname, dnode in (node.get("folders", {}) or {}).items():
            if isinstance(dname, str) and isinstance(dnode, dict):
                files.extend(_fs_walk_files(dnode, prefix_parts + [dname]))
        return files

    def _migrate_file_contents():
        # Seed JSON historically stored bare filenames even when nested in folders.
        # If keys are missing paths, map them to the first matching file found in fs.
        all_files = _fs_walk_files(root, [])
        by_basename = {}
        for p in all_files:
            base = p.split("/")[-1]
            by_basename.setdefault(base, []).append(p)

        updates = {}
        removes = []
        for k, v in file_contents.items():
            if not isinstance(k, str):
                continue
            if "/" in k:
                continue
            matches = by_basename.get(k, [])
            if len(matches) == 1:
                updates[matches[0]] = v
                removes.append(k)

        for old in removes:
            file_contents.pop(old, None)
        file_contents.update(updates)

    _migrate_file_contents()

    def _cwd_prompt():
        return "~" if not path_parts else "~/" + "/".join(path_parts)

    def _get_dir_from_parts(parts):
        node = root
        for part in parts:
            folders = node.get("folders", {})
            nxt = folders.get(part)
            if not isinstance(nxt, dict):
                return None
            node = nxt
        return node

    def _cd(target):
        nonlocal cwd, path_parts
        if target in (None, "", "~", "/"):
            path_parts = []
            cwd = root
            return

        parts = []
        if target.startswith("/"):
            # Treat "/" as the root of the simulated filesystem.
            parts = [p for p in target.split("/") if p]
            new_parts = []
        else:
            parts = [p for p in target.split("/") if p]
            new_parts = path_parts.copy()

        for part in parts:
            if part == ".":
                continue
            if part == "..":
                if new_parts:
                    new_parts.pop()
                continue
            new_parts.append(part)

        new_cwd = _get_dir_from_parts(new_parts)
        if new_cwd is None:
            print(f"cd: no such file or directory: {target}")
            return

        path_parts = new_parts
        cwd = new_cwd

    def _is_sudo_user():
        return str(user.get("sudo", "False")).lower() == "true"

    def _resolve_path(path, *, expect_dir=False):
        # Returns (parent_node, name, node_or_none, resolved_parts)
        if path in (None, "", "~", "/"):
            return (None, "", root, [],)

        is_abs = path.startswith("/")
        parts = [p for p in path.split("/") if p]
        cur_parts = [] if is_abs else path_parts.copy()

        for part in parts[:-1]:
            if part == ".":
                continue
            if part == "..":
                if cur_parts:
                    cur_parts.pop()
                continue
            cur_parts.append(part)

        parent = _get_dir_from_parts(cur_parts)
        if parent is None:
            return (None, "", None, cur_parts)

        name = parts[-1] if parts else ""
        if name in (".", ""):
            return (None, "", parent, cur_parts)
        if name == "..":
            cur_parts.pop() if cur_parts else None
            parent2 = _get_dir_from_parts(cur_parts)
            return (None, "", parent2, cur_parts)

        folders = parent.get("folders", {}) or {}
        node = folders.get(name)
        if expect_dir and not isinstance(node, dict):
            node = None
        return (parent, name, node, cur_parts + [name])

    def _join_parts(parts):
        return "/".join(parts) if parts else ""

    def _list_dir(node):
        folders = sorted([k for k in (node.get("folders", {}) or {}).keys() if isinstance(k, str)])
        files = sorted([f for f in (node.get("files", []) or []) if isinstance(f, str)])
        return folders, files

    def _print_tree(start_node, label="."):
        print(label)

        def walk(node, prefix):
            folders, files = _list_dir(node)
            entries = [(name, "dir") for name in folders] + [(name, "file") for name in files]
            for i, (name, kind) in enumerate(entries):
                last = i == len(entries) - 1
                connector = "└── " if last else "├── "
                print(prefix + connector + (name + "/" if kind == "dir" else name))

                if kind == "dir":
                    child = (node.get("folders", {}) or {}).get(name)
                    if isinstance(child, dict):
                        walk(child, prefix + ("    " if last else "│   "))

        walk(start_node, "")

    def _get_file_content(rel_path):
        return str(file_contents.get(rel_path, ""))

    def _set_file_content(rel_path, content):
        file_contents[rel_path] = content

    def _ensure_file_entry(node, filename):
        files = node.get("files")
        if not isinstance(files, list):
            node["files"] = []
            files = node["files"]
        if filename not in files:
            files.append(filename)

    def _remove_file_entry(node, filename):
        files = node.get("files")
        if isinstance(files, list) and filename in files:
            files.remove(filename)

    def _print_help():
        print("Available commands:")
        print("  " + "  ".join(sorted(commands)))
        print("Notes:")
        print("  - This is a simulated shell. It does not execute real system commands.")
        print("  - Use `sudo apt update|upgrade|install <pkg>` (or `sudo update`/`sudo upgrade`).")
        print("  - Install pip with `sudo apt install pip`, then use `pip install <pkg>`.")
    
    # Readline Setup for Tab Completion
    def completer(text, state):
        entries = list(cwd.get("folders", {}).keys()) + (cwd.get("files", []) or [])
        options = [i for i in (commands + entries) if isinstance(i, str) and i.startswith(text)]
        return options[state] if state < len(options) else None

    readline.set_completer(completer)
    readline.parse_and_bind("tab: complete")

    while True:
        try:
            prompt = f"{user['username']}@ArunCode:{_cwd_prompt()} $ "
            cmd_input = input(prompt).strip()
            if not cmd_input: continue

            try:
                parts = shlex.split(cmd_input)
            except ValueError as e:
                print(f"parse error: {e}")
                continue
            if not parts:
                continue

            command = parts[0]
            history.append(cmd_input)

            sudo_mode = False
            if command == "sudo":
                if len(parts) == 1:
                    print("usage: sudo <command>")
                    continue
                if not _is_sudo_user():
                    print(f"{user['username']} is not in the sudoers file. This incident will be reported.")
                    continue
                sudo_mode = True
                parts = parts[1:]
                command = parts[0]

            if command in ("update", "upgrade"):
                parts = ["apt", command]
                command = "apt"

            if command == "exit":
                print("Logging out...")
                break
            elif command == "help":
                _print_help()
                continue
            elif command == "clear":
                print("\n" * 80)
                continue
            elif command == "history":
                for i, line in enumerate(history, 1):
                    print(f"{i}  {line}")
                continue
            elif command == "pwd":
                print("/" if not path_parts else "/" + "/".join(path_parts))
                continue
            elif command == "cd":
                _cd(parts[1] if len(parts) > 1 else None)
                continue
            elif command == "ls":
                folders, files = _list_dir(cwd)
                items = folders + files
                print("  ".join(items) if items else "(empty)")
                continue
            elif command == "tree":
                target = parts[1] if len(parts) > 1 else None
                if target:
                    parent, leaf, node, resolved = _resolve_path(target, expect_dir=True)
                    if node is None:
                        print(f"tree: {target}: No such directory")
                        continue
                    _print_tree(node, ".")
                else:
                    _print_tree(cwd, ".")
                continue
            elif command == "mkdir":
                if len(parts) < 2:
                    print("mkdir: missing operand")
                    continue
                name = parts[1]
                parent, leaf, node, resolved = _resolve_path(name, expect_dir=False)
                if parent is None:
                    print(f"mkdir: cannot create directory '{name}': No such file or directory")
                    continue
                if leaf in (".", "..", ""):
                    print(f"mkdir: invalid directory name: {name}")
                    continue
                folders = parent.get("folders")
                if not isinstance(folders, dict):
                    parent["folders"] = {}
                    folders = parent["folders"]
                if leaf in folders:
                    print(f"mkdir: cannot create directory '{leaf}': File exists")
                    continue
                folders[leaf] = {"files": [], "folders": {}}
                continue
            elif command == "rmdir":
                if len(parts) < 2:
                    print("rmdir: missing operand")
                    continue
                target = parts[1]
                parent, leaf, node, resolved = _resolve_path(target, expect_dir=True)
                if parent is None or node is None:
                    print(f"rmdir: failed to remove '{target}': No such file or directory")
                    continue
                folders, files = _list_dir(node)
                if folders or files:
                    print(f"rmdir: failed to remove '{leaf}': Directory not empty")
                    continue
                (parent.get("folders", {}) or {}).pop(leaf, None)
                continue
            elif command == "touch":
                if len(parts) < 2:
                    print("touch: missing file operand")
                    continue
                target = parts[1]
                parent, leaf, node, resolved = _resolve_path(target, expect_dir=False)
                if parent is None:
                    print(f"touch: cannot touch '{target}': No such file or directory")
                    continue
                # if a folder exists with this name, disallow
                if isinstance((parent.get("folders", {}) or {}).get(leaf), dict):
                    print(f"touch: cannot touch '{leaf}': Is a directory")
                    continue
                _ensure_file_entry(parent, leaf)
                rel = _join_parts(resolved)
                file_contents.setdefault(rel, "")
                continue
            elif command == "rm":
                if len(parts) < 2:
                    print("rm: missing operand")
                    continue
                target = parts[1]
                parent, leaf, node, resolved = _resolve_path(target, expect_dir=False)
                if parent is None:
                    print(f"rm: cannot remove '{target}': No such file or directory")
                    continue
                if isinstance((parent.get("folders", {}) or {}).get(leaf), dict):
                    print(f"rm: cannot remove '{leaf}': Is a directory")
                    continue
                if leaf not in (parent.get("files", []) or []):
                    print(f"rm: cannot remove '{leaf}': No such file")
                    continue
                _remove_file_entry(parent, leaf)
                rel = _join_parts(resolved)
                file_contents.pop(rel, None)
                continue
            elif command in ("cp", "mv"):
                if len(parts) < 3:
                    print(f"{command}: missing file operand")
                    continue
                src = parts[1]
                dest = parts[2]

                src_parent, src_leaf, src_node, src_resolved = _resolve_path(src, expect_dir=False)
                if src_parent is None:
                    print(f"{command}: cannot stat '{src}': No such file or directory")
                    continue
                if isinstance((src_parent.get("folders", {}) or {}).get(src_leaf), dict):
                    print(f"{command}: cannot stat '{src_leaf}': Is a directory")
                    continue
                if src_leaf not in (src_parent.get("files", []) or []):
                    print(f"{command}: cannot stat '{src_leaf}': No such file")
                    continue

                src_rel = _join_parts(src_resolved)
                content = _get_file_content(src_rel)

                dest_parent, dest_leaf, dest_node, dest_resolved = _resolve_path(dest, expect_dir=False)
                if isinstance(dest_node, dict):
                    dest_dir = dest_node
                    dest_filename = src_leaf
                    dest_rel = _join_parts(dest_resolved + [dest_filename])
                else:
                    if dest_parent is None:
                        print(f"{command}: cannot create regular file '{dest}': No such file or directory")
                        continue
                    if dest_leaf in (".", "..", ""):
                        print(f"{command}: invalid destination: {dest}")
                        continue
                    if isinstance((dest_parent.get("folders", {}) or {}).get(dest_leaf), dict):
                        print(f"{command}: cannot overwrite directory '{dest_leaf}'")
                        continue
                    dest_dir = dest_parent
                    dest_filename = dest_leaf
                    dest_rel = _join_parts(dest_resolved)

                if src_rel == dest_rel:
                    continue

                _ensure_file_entry(dest_dir, dest_filename)
                _set_file_content(dest_rel, content)

                if command == "mv":
                    _remove_file_entry(src_parent, src_leaf)
                    file_contents.pop(src_rel, None)
                continue
            elif command == "cat":
                if len(parts) < 2:
                    print("cat: missing file operand")
                    continue
                target = parts[1]
                parent, leaf, node, resolved = _resolve_path(target, expect_dir=False)
                if parent is None:
                    print(f"cat: {target}: No such file or directory")
                    continue
                if isinstance((parent.get("folders", {}) or {}).get(leaf), dict):
                    print(f"cat: {leaf}: Is a directory")
                    continue
                if leaf not in (parent.get("files", []) or []):
                    print(f"cat: {leaf}: No such file")
                    continue
                rel = _join_parts(resolved)
                print(_get_file_content(rel), end="" if _get_file_content(rel).endswith("\n") else "\n")
                continue
            elif command in ("head", "tail"):
                n = 10
                idx = 1
                if len(parts) >= 4 and parts[1] == "-n":
                    try:
                        n = int(parts[2])
                    except ValueError:
                        print(f"{command}: invalid number of lines: {parts[2]}")
                        continue
                    idx = 3
                if len(parts) <= idx:
                    print(f"{command}: missing file operand")
                    continue
                target = parts[idx]
                parent, leaf, node, resolved = _resolve_path(target, expect_dir=False)
                if parent is None:
                    print(f"{command}: cannot open '{target}': No such file or directory")
                    continue
                if isinstance((parent.get("folders", {}) or {}).get(leaf), dict):
                    print(f"{command}: error reading '{leaf}': Is a directory")
                    continue
                if leaf not in (parent.get("files", []) or []):
                    print(f"{command}: cannot open '{leaf}': No such file")
                    continue

                rel = _join_parts(resolved)
                content = _get_file_content(rel)
                lines = content.splitlines(True)
                out = lines[: max(n, 0)] if command == "head" else lines[-max(n, 0) :] if n != 0 else []
                if out:
                    print("".join(out), end="" if out[-1].endswith("\n") else "\n")
                continue
            elif command == "grep":
                show_numbers = False
                idx = 1
                if len(parts) >= 2 and parts[1] == "-n":
                    show_numbers = True
                    idx = 2
                if len(parts) <= idx + 1:
                    print("usage: grep [-n] <pattern> <file>")
                    continue
                pattern = parts[idx]
                target = parts[idx + 1]

                parent, leaf, node, resolved = _resolve_path(target, expect_dir=False)
                if parent is None:
                    print(f"grep: {target}: No such file or directory")
                    continue
                if isinstance((parent.get("folders", {}) or {}).get(leaf), dict):
                    print(f"grep: {leaf}: Is a directory")
                    continue
                if leaf not in (parent.get("files", []) or []):
                    print(f"grep: {leaf}: No such file")
                    continue

                rel = _join_parts(resolved)
                for i, line in enumerate(_get_file_content(rel).splitlines(), 1):
                    if pattern in line:
                        print(f"{i}:{line}" if show_numbers else line)
                continue
            elif command == "echo":
                if len(parts) == 1:
                    print()
                    continue
                # Minimal redirection support: echo ... > file  /  echo ... >> file
                if len(parts) >= 4 and parts[-2] in (">", ">>"):
                    op = parts[-2]
                    target = parts[-1]
                    msg = " ".join(parts[1:-2])
                    parent, leaf, node, resolved = _resolve_path(target, expect_dir=False)
                    if parent is None:
                        print(f"echo: {target}: No such file or directory")
                        continue
                    if isinstance((parent.get("folders", {}) or {}).get(leaf), dict):
                        print(f"echo: {leaf}: Is a directory")
                        continue
                    _ensure_file_entry(parent, leaf)
                    rel = _join_parts(resolved)
                    if op == ">>":
                        _set_file_content(rel, _get_file_content(rel) + msg + "\n")
                    else:
                        _set_file_content(rel, msg + "\n")
                else:
                    print(" ".join(parts[1:]))
                continue
            elif command == "whoami":
                print(f"User: {user['username']}\nType: {user['usertype']}\nSudo: {user.get('sudo', 'False')}")
                continue
            elif command == "id":
                login = "".join(ch for ch in user.get("username", "user") if ch.isalnum()).lower() or "user"
                groups = [f"1000({login})"]
                if _is_sudo_user():
                    groups.append("27(sudo)")
                print(f"uid=1000({login}) gid=1000({login}) groups=" + ",".join(groups))
                continue
            elif command == "uname":
                print(platform.system().lower() if len(parts) == 1 else platform.platform())
                continue
            elif command == "date":
                now = datetime.now(timezone.utc).astimezone()
                print(now.strftime("%a %b %d %H:%M:%S %Z %Y"))
                continue
            elif command == "which":
                if len(parts) < 2:
                    print("which: missing operand")
                    continue
                target = parts[1]
                if target in ("pip", "pip3") and not _pip_available():
                    continue
                if target in commands:
                    print(f"/usr/bin/{target}")
                continue
            elif command == "man":
                if len(parts) < 2:
                    print("man: missing operand")
                    continue
                print(f"No manual entry for {parts[1]}")
                continue
            elif command in ("apt", "apt-get"):
                if len(parts) < 2:
                    print("apt: missing action (try: update, upgrade, install, list)")
                    continue
                action = parts[1]

                if action in ("update", "upgrade"):
                    if not sudo_mode:
                        print("apt: permission denied (try running with sudo)")
                        continue
                    if action == "update":
                        print("Hit:1 http://archive.ubuntu.com/ubuntu noble InRelease")
                        print("Reading package lists... Done")
                    else:
                        print("Reading package lists... Done")
                        print("Building dependency tree... Done")
                        print("0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.")
                    continue

                if action == "install":
                    if not sudo_mode:
                        print("apt: permission denied (try running with sudo)")
                        continue
                    pkgs = [p for p in parts[2:] if not p.startswith("-")]
                    if not pkgs:
                        print("apt install: missing package name")
                        continue
                    installed = _get_installed_packages()
                    print("Reading package lists... Done")
                    print("Building dependency tree... Done")
                    for pkg in pkgs:
                        installed.add(pkg)
                        print(f"Selecting previously unselected package {pkg}.")
                        print(f"Setting up {pkg} (simulated) ...")
                    _set_installed_packages(installed)
                    continue

                if action == "remove":
                    if not sudo_mode:
                        print("apt: permission denied (try running with sudo)")
                        continue
                    pkgs = [p for p in parts[2:] if not p.startswith("-")]
                    if not pkgs:
                        print("apt remove: missing package name")
                        continue
                    installed = _get_installed_packages()
                    print("Reading package lists... Done")
                    print("Building dependency tree... Done")
                    for pkg in pkgs:
                        if pkg in installed:
                            installed.remove(pkg)
                            print(f"Removing {pkg} (simulated) ...")
                        else:
                            print(f"Package '{pkg}' is not installed, so not removed")
                    _set_installed_packages(installed)
                    continue

                if action == "list":
                    if len(parts) >= 3 and parts[2] == "--installed":
                        installed = sorted(_get_installed_packages())
                        for pkg in installed:
                            print(f"{pkg}/now 1.0 amd64 [installed]")
                        continue
                    print("usage: apt list --installed")
                    continue

                print(f"apt: unknown action '{action}'")
                continue
            elif command in ("pip", "pip3"):
                if not _pip_available():
                    print(f"{command}: command not found")
                    continue
                if len(parts) == 1:
                    print("usage: pip <command> [options]")
                    continue
                sub = parts[1]
                if sub in ("-V", "--version"):
                    print(f"pip 1.0 (simulated) from /usr/lib/python/site-packages/pip (python {sys.version.split()[0]})")
                    continue
                if sub == "install":
                    pkgs = [p for p in parts[2:] if not p.startswith("-")]
                    if not pkgs:
                        print("ERROR: You must give at least one requirement to install")
                        continue
                    installed = _get_python_packages()
                    for pkg in pkgs:
                        installed.add(pkg)
                        print(f"Collecting {pkg}")
                        print(f"Successfully installed {pkg}")
                    _set_python_packages(installed)
                    continue
                if sub == "list":
                    pkgs = sorted(_get_python_packages())
                    print("Package    Version")
                    print("---------- -------")
                    for pkg in pkgs:
                        print(f"{pkg:<10} 1.0")
                    continue
                print(f"pip: unknown command '{sub}'")
                continue
            elif command in ("python", "python3"):
                if len(parts) >= 2 and parts[1] in ("-V", "--version"):
                    print(f"Python {sys.version.split()[0]}")
                    continue
                print(f"{command}: interactive mode not supported in this simulator (try `{command} --version`)")
                continue

            print(f"{command}: command not found")

        except KeyboardInterrupt:
            print("\nReturning to main menu...")
            break

# ---------- MAIN INTERFACE ----------
def main():
    # Load accounts once at startup
    accounts = load_accounts()

    while True:
        try:
            print("\n--- ArunCode Terminal ---")
            print("1) Login")
            print("2) Create Account")
            print("3) Guest")
            print("4) Exit")
            choice = input(">>> ").strip()

            if choice == "1":
                u = input("user: ")
                p = input("pass: ")
                user = next((a for a in accounts if a["username"] == u and a["password"] == p), None)
                
                if user:
                    terminal(user)
                    save_accounts(accounts, push_remote=False)
                else:
                    print("ERROR: Invalid credentials")

            elif choice == "2":
                email = input("Email: ")
                username = input("Choose Username: ").strip()
                password = input("Choose Password: ").strip()
                usertype = "User"
                sudo = "n"

                if not username or not password:
                    print("ERROR: Username and password required")
                    continue

                if any(a.get("username") == username for a in accounts if isinstance(a, dict)):
                    print("ERROR: Username exists")
                    continue
                
                print(yellow("Please Email (chandrasekarana@student.rcdsb.on.ca) This:"))
                print(blue(f"Email : {email}\nUsername : {username}\nPassword : {password}"))

            elif choice == "3":
                guest = {
                    "username": f"guest{random.randint(1000, 9999)}",
                    "sudo": "False", "usertype": "Guest",
                    "fs": {"files": [], "folders": {}}
                }
                terminal(guest)

            elif choice == "4":
                print("Goodbye!")
                sys.exit()

        except KeyboardInterrupt:
            print("\nExiting...")
            sys.exit()

if __name__ == "__main__":
    main()
