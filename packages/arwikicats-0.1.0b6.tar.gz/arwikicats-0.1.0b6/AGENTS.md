# Agent Instructions for ArWikiCats

For comprehensive agent instructions, please refer to [`.github/copilot-instructions.md`](.github/copilot-instructions.md).

This file exists for compatibility with various AI agent tools that look for `AGENTS.md` at the repository root.
