"""
Core processing logic for label resolution.
This package contains the main entry points and utilities for
coordinating different resolvers to translate category labels.
"""
