"""
New category processing modules for the ArWikiCats project.
This package contains experimental or recently added modules for
handling suffixes, time-based callbacks, and sports matching.
"""
