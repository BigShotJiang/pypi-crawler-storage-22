pre_defined_results = {
    "sports people": "رياضيون",
    "sports events": "أحداث رياضية",
    "sports venues": "ملاعب رياضية",
    "womens sports": "رياضات نسائية",
    "womens sports clubs and teams": "أندية وفرق رياضية نسائية",
    "sports clubs and teams": "أندية وفرق رياضية",
}
