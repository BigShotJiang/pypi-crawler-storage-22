SPORTS_FORMATTED_DATA_NATS_AND_NAMES = {
    "womens {en} open ({en_sport})": "بطولة {ar} المفتوحة {sport_team} للسيدات",
    "{en} open ({en_sport})": "بطولة {ar} المفتوحة {sport_team}",
    "{en} open {en_sport}": "بطولة {ar} المفتوحة {sport_team}",
    "womens {en} open {en_sport}": "بطولة {ar} المفتوحة {sport_team} للسيدات",
}
