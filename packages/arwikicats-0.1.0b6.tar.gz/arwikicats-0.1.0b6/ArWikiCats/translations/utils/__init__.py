from .json_dir import open_json_file

__all__ = [
    "open_json_file",
]
