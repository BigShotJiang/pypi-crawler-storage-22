"""Setup script for ARX SDK Python extension."""

import re
import shutil
import subprocess
from pathlib import Path

from setuptools import setup
from setuptools.command.build import build


# Extract version from __init__.py without importing it
# (avoids circular dependency with C++ extension)
def get_version():
    init_file = Path(__file__).parent / "arx_x5_sdk" / "__init__.py"
    version_match = re.search(
        r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]', init_file.read_text(), re.MULTILINE
    )
    if version_match:
        return version_match.group(1)
    raise RuntimeError("Unable to find version string.")


__version__ = get_version()


class BuildArxSDK(build):
    """Build the ARX SDK extension using CMake."""

    def run(self):
        import sys
        import sysconfig

        this_dir = Path(__file__).parent.absolute()
        build_dir = this_dir / "build"
        build_dir.mkdir(exist_ok=True)

        # Pass Python executable and paths to CMake to force it to use the correct Python
        python_include = sysconfig.get_path("include")
        python_lib = sysconfig.get_config_var("LIBDIR")
        python_version = f"{sys.version_info.major}.{sys.version_info.minor}"

        # Use shutil.which to get full paths (addresses Bandit B607)
        cmake_path = shutil.which("cmake")
        make_path = shutil.which("make")
        if not cmake_path:
            raise RuntimeError("Could not find 'cmake' in PATH")
        if not make_path:
            raise RuntimeError("Could not find 'make' in PATH")

        # CMake will find pybind11 via find_package(pybind11 REQUIRED)
        # We don't need to import pybind11 in Python - CMake handles it
        # Try to find pybind11's location to help CMake, but don't fail if we can't
        cmake_prefix_path = None
        pybind11_dir = None
        try:
            import pybind11

            pybind11_path = Path(pybind11.__file__).parent
            # Try to find pybind11 CMake files
            pybind11_cmake_path = pybind11_path.parent / "share" / "cmake" / "pybind11"
            if not pybind11_cmake_path.exists():
                pybind11_cmake_path = pybind11_path / "share" / "cmake" / "pybind11"
            if pybind11_cmake_path.exists():
                pybind11_dir = str(pybind11_cmake_path)
            cmake_prefix_path = str(pybind11_path.parent)
        except ImportError:
            # pybind11 not importable, but CMake might still find it
            # This is OK - CMake's find_package will handle it
            pass

        # Prepare package directory for CMake to install into
        build_lib = (
            Path(self.build_lib)
            if hasattr(self, "build_lib")
            else this_dir / "build" / "lib"
        )
        pkg_dir = (build_lib / "arx_x5_sdk").absolute()
        pkg_dir.mkdir(parents=True, exist_ok=True)

        cmake_args = [
            cmake_path,
            "..",
            f"-DCMAKE_INSTALL_PREFIX={pkg_dir.absolute()}",  # Install directly to build directory
            f"-DPYTHON_EXECUTABLE={sys.executable}",
            f"-DPython3_EXECUTABLE={sys.executable}",
            f"-DPython3_INCLUDE_DIR={python_include}",
            f"-DPython3_LIBRARY_DIR={python_lib}",
            f"-DPython3_VERSION={python_version}",
            "-DPYBIND11_FINDPYTHON=OFF",
        ]

        # Add pybind11 hints if we found them
        if pybind11_dir:
            cmake_args.append(f"-Dpybind11_DIR={pybind11_dir}")
        if cmake_prefix_path:
            cmake_args.append(f"-DCMAKE_PREFIX_PATH={cmake_prefix_path}")

        subprocess.check_call(cmake_args, cwd=build_dir)
        subprocess.check_call([make_path], cwd=build_dir)
        subprocess.check_call([make_path, "install"], cwd=build_dir)

        super().run()

        # Copy bundled libkdl_parser dependency
        kdl_parser_src = this_dir / "lib" / "external" / "libkdl_parser.so.1d"
        if not kdl_parser_src.exists():
            raise RuntimeError(
                f"Missing bundled dependency: {kdl_parser_src}\n"
                "This file should be included in the repository."
            )
        shutil.copy2(kdl_parser_src, pkg_dir)

        # Set RPATH=$ORIGIN so libarx_x5_src.so finds bundled dependencies
        patchelf_path = shutil.which("patchelf")
        if not patchelf_path:
            raise RuntimeError(
                "patchelf is required to build this package.\n"
                "Install it with: sudo apt install patchelf"
            )

        arx_lib = pkg_dir / "libarx_x5_src.so"
        subprocess.check_call(
            [patchelf_path, "--set-rpath", "$ORIGIN", str(arx_lib)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


setup(
    name="arx-x5-sdk",
    version=__version__,
    author="Remi Cadene, UMA",
    description="ARX X5 Robot Arm Python SDK",
    long_description="Python bindings for ARX X5 robot arm SDK",
    packages=["arx_x5_sdk"],
    package_dir={"arx_x5_sdk": "arx_x5_sdk"},
    package_data={"arx_x5_sdk": ["urdf/*.urdf"]},
    cmdclass={"build": BuildArxSDK},
    zip_safe=False,
    python_requires=">=3.10",
    install_requires=["pybind11>=2.10.0"],
)
