# Backend configuration for Terraform state
# Actual values provided via .tfbackend file during terraform init
terraform {
  backend "s3" {
    # bucket         = "<provided via .tfbackend>"
    # key            = "<provided via .tfbackend>"
    # region         = "<provided via .tfbackend>"
    # dynamodb_table = "<provided via .tfbackend>"
    # encrypt        = "<provided via .tfbackend>"
  }
}
