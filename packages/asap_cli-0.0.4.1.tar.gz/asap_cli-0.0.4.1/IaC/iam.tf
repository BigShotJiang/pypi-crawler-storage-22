# ################################################################################
# # IAM Role LakeFormation
# ################################################################################


# ################################################################################
# # IAM Roles IFCL Team
# ################################################################################

# # Individual IAM role for lambda task orchestrator
# module "sof_iam_lftn_ifcl_task_orchestrator" {
#   source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

#   create_role                   = true
#   role_requires_mfa             = false
#   trusted_role_actions          = ["sts:AssumeRole"]
#   role_name                     = "${local.prefix}-lmb-ifcl-task-orchestrator-role"
#   role_description              = "IAM role of the task orchestration lambda function for ifcl team."
#   # role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
#   custom_role_policy_arns = [
#     "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
#     "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
#     "arn:aws:iam::aws:policy/AWSXRayDaemonWriteAccess"
#   ]
#   trusted_role_services  = ["lambda.amazonaws.com"]
#   allow_self_assume_role = false

#   inline_policy_statements = {
#     DynamoDBAccess = {
#       sid    = "DynamoDBAccess"
#       effect = "Allow"
#       actions = [
#         "dynamodb:DescribeTable",
#         "dynamodb:GetItem",
#         "dynamodb:GetRecords",
#         "dynamodb:GetShardIterator",
#         "dynamodb:PutItem",
#         "dynamodb:Query",
#         "dynamodb:UpdateItem"
#       ]
#       resources = ["arn:aws:dynamodb:${local.region}:${local.accountid}:table/*"]
#     },
#     CloudWatchLogsAccess = {
#       sid    = "CloudWatchLogsAccess"
#       effect = "Allow"
#       actions = [
#         "logs:CreateLogGroup",
#         "logs:CreateLogStream",
#         "logs:PutLogEvents",
#         "cloudwatch:PutMetricData"
#       ]
#       resources = ["*"]
#     },
#     SSMAccess = {
#       sid    = "SSMAccess"
#       effect = "Allow"
#       actions = [
#         "ssm:DescribeParameters",
#         "ssm:GetParameter",
#         "ssm:GetParameterHistory",
#         "ssm:GetParameters"
#       ]
#       resources = [
#         "arn:aws:ssm:${local.region}:${local.accountid}:parameter/${var.platform_code}/*",
#         "arn:aws:ssm:${local.region}:${local.accountid}:parameter/SOF/*"
#       ]
#     },
#     SecretsAccess = {
#       sid    = "SecretsAccess"
#       effect = "Allow"
#       actions = [
#         "secretsmanager:GetSecretValue"
#       ]
#       resources = [
#         "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/${var.platform_code}/*",
#         "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/SOF/*"
#       ]
#     },
#     WorkflowControlTable = {
#       sid    = "WorkflowControlTable"
#       effect = "Allow"
#       actions = [
#         "dynamodb:BatchGetItem",
#         "dynamodb:BatchWriteItem",
#         "dynamodb:ConditionCheckItem",
#         "dynamodb:DeleteItem",
#         "dynamodb:DescribeTable",
#         "dynamodb:GetItem",
#         "dynamodb:GetRecords",
#         "dynamodb:GetShardIterator",
#         "dynamodb:PutItem",
#         "dynamodb:Query",
#         "dynamodb:Scan",
#         "dynamodb:UpdateItem"
#       ]
#       resources = ["arn:aws:dynamodb:${local.region}:${local.accountid}:table/sof-workflow-control"]
#     },
#     GlueJobRun = {
#       sid = "GlueJobRun"
#       actions = [
#         "glue:StartJobRun",
#         "glue:GetJobRun",
#         "glue:BatchStopJobRun"
#       ],
#       effect    = "Allow",
#       resources = ["arn:aws:glue:${local.region}:${local.accountid}:job/*"]
#     },
#     S3Access = {
#       sid = "S3Access"
#       actions = [
#         "s3:GetObject"
#       ],
#       effect    = "Allow",
#       resources = ["${module.storage.artifacts_bucket_arn}/*"]
#     },
#     S3Permissions = {
#       sid    = "S3Permissions"
#       effect = "Allow"
#       actions = [
#         "s3:GetObject",
#         "s3:PutObject",
#         "s3:ListBucket",
#         "s3:ListAllMyBuckets"
#       ]
#       resources = ["${module.storage.artifacts_bucket_arn}/*",
#         "${module.storage.analytics_bucket_arn}/*",
#         "${module.storage.raw_bucket_arn}/*",
#         "${module.storage.raw_bucket_arn}/*",
#         "${module.storage.artifacts_bucket_arn}",
#         "${module.storage.analytics_bucket_arn}",
#         "${module.storage.raw_bucket_arn}",
#         "${module.storage.raw_bucket_arn}"
#       ]
#     },
#     S3DeletePermissions = {
#       sid    = "S3DeletePermissions"
#       effect = "Allow"
#       actions = [
#         "s3:DeleteObject",
#       ]
#       resources = ["${module.storage.artifacts_bucket_arn}/step_functions/*"]
#     },
#     KMSAccess = {
#       sid    = "KMSAccess"
#       effect = "Allow"
#       actions = [
#         "kms:ReEncrypt*",
#         "kms:GenerateDataKey*",
#         "kms:Encrypt",
#         "kms:DescribeKey",
#         "kms:Decrypt",
#         "kms:CreateGrant"
#       ]
#       resources = ["arn:aws:kms:${local.region}:${local.accountid}:key/*"]
#     },
#     # NEW: EventBridge permissions for receiving events
#     EventBridgeAccess = {
#       sid    = "EventBridgeAccess"
#       effect = "Allow"
#       actions = [
#         "events:PutEvents",
#         "events:DescribeRule",
#         "events:ListTargetsByRule"
#       ]
#       resources = [
#         "arn:aws:events:${local.region}:${local.accountid}:event-bus/default",
#         "arn:aws:events:${local.region}:${local.accountid}:rule/*"
#       ]
#     }
#     RedshiftDescribeAccess = {
#       sid    = "RedshiftDescribeAccess"
#       effect = "Allow"
#       actions = [
#         "redshift-data:DescribeStatement"
#       ]
#       resources = ["*"]
#     },
#     RedshiftExecuteAccess = {
#       sid    = "RedshiftExecuteAccess"
#       effect = "Allow"
#       actions = [
#         "redshift-data:BatchExecuteStatement",
#         "redshift-data:ExecuteStatement"
#       ]
#       resources = [
#         "arn:aws:redshift-serverless:${local.region}:${local.accountid}:workgroup/*",
#         "arn:aws:redshift:${local.region}:${local.accountid}:cluster/*"
#       ]
#     }
#   }
# }


# # Individual IAM role for sfn task executor
# module "sof_iam_sfn_ifcl_task_executor" {
#   source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

#   create_role                   = true
#   role_requires_mfa             = false
#   trusted_role_actions          = ["sts:AssumeRole"]
#   role_name                     = "${local.prefix}-stp-ifcl-task-executor-role"
#   role_description              = "IAM role for the task executor step function used by team ifcl."
#   #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
#   custom_role_policy_arns       = []
#   trusted_role_services         = ["states.${local.region}.amazonaws.com"]
#   allow_self_assume_role        = false

#   inline_policy_statements = {
#     AllowLambdaInvoke = {
#       sid       = "AllowLambdaInvoke"
#       effect    = "Allow"
#       actions   = ["lambda:InvokeFunction"]
#       resources = ["arn:aws:lambda:${local.region}:${local.accountid}:function:*"]
#     },
#     AllowStepFunctionsExecution = {
#       sid       = "AllowStepFunctionsExecution"
#       effect    = "Allow"
#       actions   = ["states:StartExecution"]
#       resources = ["arn:aws:states:${local.region}:${local.accountid}:stateMachine:*"]
#     },
#     AllowEventBridgeHandling = {
#       sid       = "AllowEventBridgeHandling"
#       effect    = "Allow"
#       actions   = ["events:PutRule", "events:PutTargets"]
#       resources = ["arn:aws:events:${local.region}:${local.accountid}:rule/*"]
#     }
#   }
# }
# ###### ERASE below ######
# # Individual IAM role for lambda pipeline executor
# module "sof_iam_lftn_ifcl_pipeline_executor" {
#   source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

#   create_role                   = true
#   role_requires_mfa             = false
#   trusted_role_actions          = ["sts:AssumeRole"]
#   role_name                     = "${local.prefix}-lmb-ifcl-workflow-executor-role"
#   role_description              = "IAM role for the workflow executor lambda function used by team ifcl."
#   #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
#   custom_role_policy_arns = [
#     "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
#     "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
#     "arn:aws:iam::aws:policy/AWSXRayDaemonWriteAccess"
#   ]
#   trusted_role_services  = ["lambda.amazonaws.com"]
#   allow_self_assume_role = false

#   inline_policy_statements = {
#     DynamoDBAccess = {
#       sid    = "DynamoDBAccess"
#       effect = "Allow"
#       actions = [
#         "dynamodb:DescribeTable",
#         "dynamodb:GetItem",
#         "dynamodb:GetRecords",
#         "dynamodb:GetShardIterator",
#         "dynamodb:PutItem",
#         "dynamodb:Query",
#         "dynamodb:UpdateItem"
#       ]
#       resources = ["arn:aws:dynamodb:${local.region}:${local.accountid}:table/*"]
#     },
#     CloudWatchLogsAccess = {
#       sid    = "CloudWatchLogsAccess"
#       effect = "Allow"
#       actions = [
#         "logs:CreateLogGroup",
#         "logs:CreateLogStream",
#         "logs:PutLogEvents",
#         "cloudwatch:PutMetricData"
#       ]
#       resources = ["*"]
#     },
#     SSMAccess = {
#       sid    = "SSMAccess"
#       effect = "Allow"
#       actions = [
#         "ssm:DescribeParameters",
#         "ssm:GetParameter",
#         "ssm:GetParameterHistory",
#         "ssm:GetParameters"
#       ]
#       resources = [
#         "arn:aws:ssm:${local.region}:${local.accountid}:parameter/${var.platform_code}/*",
#         "arn:aws:ssm:${local.region}:${local.accountid}:parameter/SOF/*"
#       ]
#     },
#     WorkflowControlTable = {
#       sid    = "WorkflowControlTable"
#       effect = "Allow"
#       actions = [
#         "dynamodb:BatchGetItem",
#         "dynamodb:BatchWriteItem",
#         "dynamodb:ConditionCheckItem",
#         "dynamodb:DeleteItem",
#         "dynamodb:DescribeTable",
#         "dynamodb:GetItem",
#         "dynamodb:GetRecords",
#         "dynamodb:GetShardIterator",
#         "dynamodb:PutItem",
#         "dynamodb:Query",
#         "dynamodb:Scan",
#         "dynamodb:UpdateItem"
#       ]
#       resources = ["arn:aws:dynamodb:${local.region}:${local.accountid}:table/sof-workflow-control"]
#     },
#     GlueJobRun = {
#       sid = "GlueJobRun"
#       actions = [
#         "glue:StartJobRun",
#         "glue:GetJobRun"
#       ],
#       effect    = "Allow",
#       resources = ["arn:aws:glue:${local.region}:${local.accountid}:job/*"]
#     },
#     S3Access = {
#       sid = "S3Access"
#       actions = [
#         "s3:GetObject"
#       ],
#       effect    = "Allow",
#       resources = ["${module.storage.artifacts_bucket_arn}/*"]
#     },
#     S3Permissions = {
#       sid    = "S3Permissions"
#       effect = "Allow"
#       actions = [
#         "s3:GetObject",
#         "s3:PutObject",
#         "s3:ListBucket",
#         "s3:ListAllMyBuckets"
#       ]
#       resources = ["${module.storage.artifacts_bucket_arn}/*",
#         "${module.storage.analytics_bucket_arn}/*",
#         "${module.storage.raw_bucket_arn}/*",
#         "${module.storage.stage_bucket_arn}/*",
#         "${module.storage.artifacts_bucket_arn}",
#         "${module.storage.analytics_bucket_arn}",
#         "${module.storage.raw_bucket_arn}",
#         "${module.storage.stage_bucket_arn}"
#       ]
#     },
#     S3DeletePermissions = {
#       sid    = "S3DeletePermissions"
#       effect = "Allow"
#       actions = [
#         "s3:DeleteObject",
#       ]
#       resources = ["${module.storage.artifacts_bucket_arn}/step_functions/*"]
#     }
#   }
# }

# # Define IAM roles for IFCL team Glue data processor default job
# module "sof_iam_ifcl_glue_data_processor_default_job" {
#   source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

#   create_role                   = true
#   role_requires_mfa             = false
#   trusted_role_actions          = ["sts:AssumeRole"]
#   role_name                     = "${local.prefix}-glu-ifcl-data-processor-default-job-role"
#   role_description              = "IAM role for data processor default glue job used by team ifcl."
#   #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
#   custom_role_policy_arns       = []
#   trusted_role_services         = ["glue.amazonaws.com"]
#   allow_self_assume_role        = false

#   inline_policy_statements = {
#     AllowVpcEndpointAccess = {
#       sid     = "AllowVpcEndpointAccess"
#       effect  = "Allow"
#       actions = ["s3:GetObject", "s3:ListBucket"]
#       resources = [
#         module.storage.artifacts_bucket_arn,
#         module.storage.analytics_bucket_arn,
#         module.storage.raw_bucket_arn,
#         module.storage.stage_bucket_arn,
#         module.storage.redshifttmp_bucket_arn
#       ]
#     },
#     AllowGlueAccess = {
#       sid    = "AllowGlueAccess"
#       effect = "Allow"
#       actions = [
#         "glue:UpdateTable",
#         "glue:UpdateJob",
#         "glue:UpdateConnection",
#         "glue:StartJobRun",
#         "glue:ListJobs",
#         "glue:GetTables",
#         "glue:GetTable",
#         "glue:GetJobRuns",
#         "glue:GetJobRun",
#         "glue:GetJob",
#         "glue:GetDatabases",
#         "glue:GetDatabase",
#         "glue:GetConnection",
#         "glue:BatchDeletePartition",
#         "glue:BatchCreatePartition",
#         "glue:GetPartitions",
#         "glue:GetStatement"
#       ]
#       resources = [
#         "arn:aws:glue:${local.region}:${local.accountid}:catalog",
#         "arn:aws:glue:${local.region}:${local.accountid}:database/*",
#         "arn:aws:glue:${local.region}:${local.accountid}:table/*"
#       ]
#     },
#     VPCGlue = {
#       sid    = "VPCGlue"
#       effect = "Allow"
#       actions = [
#         "glue:GetConnection"
#       ]
#       resources = ["*"]
#     },
#     VPCAccess = {
#       sid       = "VPCAccess"
#       effect    = "Allow"
#       actions   = ["ec2:*"]
#       resources = ["*"]
#     },
#     CloudWatchLogsPermissions = {
#       sid       = "CloudWatchLogsPermissions"
#       effect    = "Allow"
#       actions   = ["logs:*", "cloudwatch:PutMetricData"]
#       resources = ["*"]
#     },
#     S3Permissions = {
#       sid    = "S3Permissions"
#       effect = "Allow"
#       actions = [
#         "s3:GetObject",
#         "s3:PutObject",
#         "s3:ListBucket",
#         "s3:ListAllMyBuckets"
#       ]
#       resources = ["${module.storage.artifacts_bucket_arn}/*",
#         "${module.storage.analytics_bucket_arn}/*",
#         "${module.storage.raw_bucket_arn}/*",
#         "${module.storage.stage_bucket_arn}/*",
#         "${module.storage.redshifttmp_bucket_arn}/*",
#         "${module.storage.artifacts_bucket_arn}",
#         "${module.storage.analytics_bucket_arn}",
#         "${module.storage.raw_bucket_arn}",
#         "${module.storage.stage_bucket_arn}",
#         "${module.storage.redshifttmp_bucket_arn}"
#       ]
#     },
#     S3DeleteObjects = {
#       sid    = "S3DeleteObjects"
#       effect = "Allow"
#       actions = [
#         "s3:DeleteObject"
#       ]
#       resources = ["${module.storage.analytics_bucket_arn}/*",
#         "${module.storage.raw_bucket_arn}/*",
#         "${module.storage.stage_bucket_arn}/*"
#       ]
#     },
#     KMSAccess = {
#       sid    = "KMSAccess"
#       effect = "Allow"
#       actions = [
#         "kms:ReEncrypt*",
#         "kms:GenerateDataKey*",
#         "kms:Encrypt",
#         "kms:DescribeKey",
#         "kms:Decrypt",
#         "kms:CreateGrant"
#       ]
#       resources = ["arn:aws:kms:${local.region}:${local.accountid}:key/*"]
#     },
#     SSMAccess = {
#       sid     = "SSMAccess"
#       effect  = "Allow"
#       actions = ["ssm:GetParameter"]
#       resources = [
#         "arn:aws:ssm:${local.region}:${local.accountid}:parameter/${var.platform_code}/*",
#         "arn:aws:ssm:${local.region}:${local.accountid}:parameter/SOF/*"
#       ]
#     },
#     SecretsAccess = {
#       sid    = "SecretsAccess"
#       effect = "Allow"
#       actions = [
#         "secretsmanager:GetSecretValue"
#       ]
#       resources = [
#         "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/${var.platform_code}/*",
#         "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/SOF/*"
#       ]
#     },
#     RedshiftServerlessCredentialsAccess = {
#       sid    = "RedshiftServerlessCredentialsAccess"
#       effect = "Allow"
#       actions = [
#         "redshift-serverless:GetCredentials"
#       ]
#       resources = [
#         "arn:aws:redshift-serverless:${local.region}:${local.accountid}:workgroup/*"
#       ]
#     },
#     RedshiftCredentialsAccess = {
#       sid    = "RedshiftCredentialsAccess"
#       effect = "Allow"
#       actions = [
#         "redshift:GetClusterCredentials"
#       ]
#       resources = [
#         "arn:aws:redshift:${local.region}:${local.accountid}:cluster/*"
#       ]
#     },
#     GlueTagNotebookResource = {
#       sid    = "GlueTagNotebookResourceAccess"
#       effect = "Allow"
#       actions = [
#         "glue:TagResource"
#       ]
#       resources = [
#         "arn:aws:glue:${local.region}:${local.accountid}:session/*"
#       ]
#     },
#     GlueLetUseRolInNotebooks = {
#       sid    = "GlueLetUseRolInNotebooks"
#       effect = "Allow"
#       actions = [
#         "iam:PassRole"
#       ]
#       resources = [
#         "arn:aws:iam::${local.accountid}:role/${local.prefix}-glu-ifcl-data-processor-default-job-role"
#       ]
#     }
#   }
# }