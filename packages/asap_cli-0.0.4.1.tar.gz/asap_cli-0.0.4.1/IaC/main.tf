data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

locals {
  region    = data.aws_region.current.name
  accountid = data.aws_caller_identity.current.account_id
  prefix    = "${var.platform_code}-${var.organization_code}-${var.environment_code}"
  teams_with_data_ops = merge(
    var.teams,
    {
      "${var.dataops_team}" = {
        team_code = var.dataops_team
        admin     = true
      }
    }
  )
  global_ssm_parameters = {
    # TODO: JFAR - Temporary ssm parameters, we need to remove this once new ssm parameters standard are fully integrated on sof-base, sof-data
    "/SOF/Globals/App/Name" = {
      description = "App Name"
      type        = "String"
      value       = var.platform_code
      tier        = "Standard"
    },
    "/SOF/Globals/Logger/LogLevel" = {
      description = "Default Log Level"
      type        = "String"
      value       = "INFO"
      tier        = "Standard"
    },
    "/SOF/Globals/Region" = {
      description = "AWS Region"
      type        = "String"
      value       = local.region
      tier        = "Standard"
    },
    "/SOF/Globals/AccountId" = {
      description = "AWS Account Id"
      type        = "String"
      value       = local.accountid
      tier        = "Standard"
    },
    "/SOF/Globals/Environment" = {
      description = "Workload Environment"
      type        = "String"
      value       = var.environment_code
      tier        = "Standard"
    }
  }
}

module "global_ssmparameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.global_ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}

###################################
# Foundational modules deployment #
###################################

module "configuration" {
  source                      = "./modules/foundation/configuration"
  deletion_protection_enabled = var.deletion_protection # Enable deletion protection for the DynamoDB tables

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code

  sqs_kms_master_key_id    = var.sqs_kms_master_key_id
  ddb_kms_key              = var.ddb_kms_key
  enable_cmk_appmanagement = var.enable_cmk_appmanagement
}

module "observability" {
  source                      = "./modules/foundation/observability"
  deletion_protection_enabled = var.deletion_protection  # Enable deletion protection for the DynamoDB tables
  force_destroy               = !var.deletion_protection # Force destroy S3 buckets if deletion protection is not enabled

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code

  raw_bucket_name       = module.storage.raw_bucket_name
  analytics_bucket_name = module.storage.analytics_bucket_name
  stage_bucket_name     = module.storage.stage_bucket_name

  iam_lftn_fact_service_cost_role_arn   = module.team_lakeformation[var.dataops_team].iam_lftn_fact_service_cost_role_arn
  sqs_kms_master_key_id                 = var.sqs_kms_master_key_id
  ddb_kms_key                           = var.ddb_kms_key
  kinesis_kms_key                       = var.kinesis_kms_key
  enable_cmk_appmanagement              = var.enable_cmk_appmanagement
  execution_history_pitr_period_in_days = var.execution_history_pitr_period_in_days
}

module "artifacts" {
  source        = "./modules/foundation/artifacts"
  force_destroy = !var.deletion_protection

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code

  # lambda layers
  sofbase_layer_path      = var.sofbase_layer_path
  sofbase_layer_runtimes  = var.sof_base_lambda_runtimes
  pydantic_layer_path     = var.pydantic_layer_path
  pydantic_layer_runtimes = var.pydantic_lambda_runtimes


  # glue libraries paths
  glue_sofdata_library_path           = var.glue_sofdata_library_path
  glue_sofbase_library_path           = var.glue_sofbase_library_path
  glue_jmespath_library_path          = var.glue_jmespath_library_path
  glue_typing_extensions_library_path = var.glue_typing_extensions_library_path
  glue_powertools_library_path        = var.glue_powertools_library_path
}

###############################
# Workload modules deployment #
###############################
# storage module 
module "storage" {
  source        = "./modules/workload/storage"
  force_destroy = !var.deletion_protection # Force destroy buckets if deletion protection is not enabled

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code

  s3_kms_key_arn = var.s3_kms_key_arn
}
## TODO define another module or put here lakeformation resources 
module "asap_iam_lakeformation_role" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

  create_role          = true
  role_requires_mfa    = false
  trusted_role_actions = ["sts:AssumeRole"]
  role_name            = "${local.prefix}-lfn-lakeformation-role"
  role_description     = "IAM role for Lake Formation data access."
  #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY

  # Trust policy - allowing Glue and Lake Formation services
  trusted_role_services = [
    "lakeformation.amazonaws.com"
  ]
  allow_self_assume_role = false

  inline_policy_statements = {
    S3ObjectLevelPermissions = {
      sid    = "S3ObjectLevelPermissions"
      effect = "Allow"
      actions = [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ]
      resources = [
        "${module.storage.raw_bucket_arn}/*",
        "${module.storage.stage_bucket_arn}/*",
        "${module.storage.analytics_bucket_arn}/*"
      ]
    },
    S3BucketLevelPermissions = {
      sid    = "S3BucketLevelPermissions"
      effect = "Allow"
      actions = [
        "s3:ListBucket"
      ]
      resources = [
        module.storage.raw_bucket_arn,
        module.storage.stage_bucket_arn,
        module.storage.analytics_bucket_arn
      ]
    },
    BucketListPermissions = {
      sid    = "BucketListPermissions"
      effect = "Allow"
      actions = [
        "s3:ListAllMyBuckets"
      ]
      resources = [
        "arn:aws:s3:::*"
      ]
    },
    # KMSPermissions = {
    #   sid    = "KMSAccess"
    #   effect = "Allow"
    #   actions = [
    #     "kms:ReEncrypt*",
    #     "kms:GenerateDataKey*",
    #     "kms:Encrypt",
    #     "kms:DescribeKey",
    #     "kms:Decrypt",
    #     "kms:CreateGrant"
    #   ]
    #   resources = ["*"]
    # }
  }
}

resource "aws_lakeformation_resource" "raw_datalake_location" {
  arn      = module.storage.raw_bucket_arn
  role_arn = module.asap_iam_lakeformation_role.iam_role_arn
}
resource "aws_lakeformation_resource" "stage_datalake_location" {
  arn      = module.storage.stage_bucket_arn
  role_arn = module.asap_iam_lakeformation_role.iam_role_arn
}
resource "aws_lakeformation_resource" "analytics_datalake_location" {
  arn      = module.storage.analytics_bucket_arn
  role_arn = module.asap_iam_lakeformation_role.iam_role_arn
}

# data "aws_lakeformation_data_lake_settings" "current" {}

resource "aws_lakeformation_lf_tag" "team_tag" {
  key    = "Team"
  values = [for team_key, team_config in local.teams_with_data_ops : team_config.team_code]
  # Ensure tag updates happen before dependent resources
  lifecycle {
    create_before_destroy = true
  }

  catalog_id = data.aws_caller_identity.current.account_id
  depends_on = [module.asap_iam_lakeformation_role]
}


###########################
# Team modules deployment #
###########################

# lakeformation, catalog and iam team resources
# This module creates Lake Formation resources for each team defined in the `teams` variable.
module "team_lakeformation" {
  source   = "./modules/team/lakeformation"
  for_each = local.teams_with_data_ops

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code
  team_code         = each.value.team_code
  team_admin        = each.value.admin

  raw_bucket_arn            = module.storage.raw_bucket_arn
  stage_bucket_arn          = module.storage.stage_bucket_arn
  analytics_bucket_arn      = module.storage.analytics_bucket_arn
  redshifttmp_bucket_arn    = module.storage.redshifttmp_bucket_arn
  athena_results_bucket_arn = module.storage.athena_results_bucket_arn

  artifacts_bucket_arn = module.artifacts.artifacts_bucket_arn

  depends_on = [
    aws_lakeformation_lf_tag.team_tag,
    aws_lakeformation_resource.raw_datalake_location,
    aws_lakeformation_resource.stage_datalake_location,
    aws_lakeformation_resource.analytics_datalake_location,
    module.asap_iam_lakeformation_role
  ]
}

# Despliegue de Modulo de Orquestacion de Tareas
module "team_orchestration" {
  source   = "./modules/team/orchestration"
  for_each = local.teams_with_data_ops

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code
  team_code         = each.value.team_code

  aws_powertools_arn                    = var.aws_powertools_arn
  iam_lambda_task_orchestrator_role_arn = module.team_lakeformation[each.key].lftn_task_orchestrator_role_arn
  sof_iam_sfn_task_executor_role_arn    = module.team_lakeformation[each.key].sfn_task_executor_role_arn
  s3_artifacts_bucket_name              = module.artifacts.artifacts_bucket_name
  subnet_ids                            = var.subnet_ids
  lambda_runtime                        = var.lambda_runtime
  sg_id                                 = var.sg_ids
  pydantic_arn                          = module.artifacts.pydantic_arn
  sofbase_arn                           = module.artifacts.sofbase_arn
}

# Despliegue de Modulo de Procesamiento de Datos
module "team_processing" {
  source   = "./modules/team/processing"
  for_each = local.teams_with_data_ops

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code
  team_code         = each.value.team_code

  iam_glue_job_role_arn = module.team_lakeformation[each.key].glue_data_processor_default_job_role_arn

  s3_artifacts_bucket_name = module.artifacts.artifacts_bucket_name
  subnet_ids               = var.subnet_ids
  glue_kms_key_arn         = var.glue_kms_key_arn
  sg_ids                   = var.sg_ids

  # glue library paths
  glue_sofdata_library_key           = module.artifacts.glue_sofdata_library_key
  glue_sofbase_library_key           = module.artifacts.glue_sofbase_library_key
  glue_jmespath_library_key          = module.artifacts.glue_jmespath_library_key
  glue_typing_extensions_library_key = module.artifacts.glue_typing_extensions_library_key
  glue_powertools_library_key        = module.artifacts.glue_powertools_library_key
}

module "team_consumption" {
  source   = "./modules/team/consumption"
  for_each = local.teams_with_data_ops

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code
  team_code         = each.value.team_code

  athena_results_bucket_name        = module.storage.athena_results_bucket_name
  athena_pyspark_workgroup_role_arn = module.team_lakeformation[each.key].athena_pyspark_workgroup_role_arn

  force_destroy = !var.deletion_protection # Force destroy if deletion protection is not enabled
}

# Despliegue de Modulo de Triggering de Tareas

# module "team_triggering" {
#   source   = "./modules/team/triggering"
#   for_each = local.teams_with_data_ops

#   lambda_pipeline_executor_name         = "${local.prefix}-lmb-${each.value.name}-workflow-executor"
#   iam_lambda_pipeline_executor_role_arn = each.value.lambda_pipeline_executor_role_arn
#   lambda_runtime                        = var.lambda_runtime
#   pydantic_arn                          = module.artifacts.pydantic_arn
#   sofbase_arn                           = module.artifacts.sofbase_arn
#   subnet_ids                            = var.subnet_ids
#   app_name                              = var.platform_code
#   sg_id                                 = var.sg_ids
#   depends_on                            = [module.storage, module.artifacts]
# }