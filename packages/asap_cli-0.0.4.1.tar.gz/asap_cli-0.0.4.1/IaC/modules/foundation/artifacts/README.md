# libraries construct

This module creates the resources for the libraries components of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "libraries" {
  source = "./modules/libraries"
}
```
<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_s3_artifacts"></a> [s3\_artifacts](#module\_s3\_artifacts) | git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git | fc09cc6fb779b262ce1bee5334e85808a107d8a3 |
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_lambda_layer_version.lambda_pydantic_layer](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_layer_version) | resource |
| [aws_lambda_layer_version.lambda_sofbase_layer](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_layer_version) | resource |
| [aws_s3_object.glue_jmespath_library](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_s3_object.glue_powertools_library](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_s3_object.glue_sofbase_library](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_s3_object.glue_sofdata_library](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_s3_object.glue_typing_extensions_library](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_s3_object.s3_pydantic_lambda_layer](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_s3_object.s3_sofbase_lambda_layer](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_force_destroy"></a> [force\_destroy](#input\_force\_destroy) | Whether to force destroy the S3 buckets and its contents | `bool` | `false` | no |
| <a name="input_glue_jmespath_library_path"></a> [glue\_jmespath\_library\_path](#input\_glue\_jmespath\_library\_path) | .whl file path for the jmespath layer | `string` | n/a | yes |
| <a name="input_glue_powertools_library_path"></a> [glue\_powertools\_library\_path](#input\_glue\_powertools\_library\_path) | .whl file path for the powertools layer | `string` | n/a | yes |
| <a name="input_glue_sofbase_library_path"></a> [glue\_sofbase\_library\_path](#input\_glue\_sofbase\_library\_path) | .whl file path for the sofbase layer | `string` | n/a | yes |
| <a name="input_glue_sofdata_library_path"></a> [glue\_sofdata\_library\_path](#input\_glue\_sofdata\_library\_path) | .whl file path for the sofdata layer | `string` | n/a | yes |
| <a name="input_glue_typing_extensions_library_path"></a> [glue\_typing\_extensions\_library\_path](#input\_glue\_typing\_extensions\_library\_path) | .whl file path for the typing\_extensions layer | `string` | n/a | yes |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_pydantic_layer_path"></a> [pydantic\_layer\_path](#input\_pydantic\_layer\_path) | .zip file path for the Pydantic layer | `string` | n/a | yes |
| <a name="input_pydantic_layer_runtimes"></a> [pydantic\_layer\_runtimes](#input\_pydantic\_layer\_runtimes) | Compatible runtimes for the Pydantic layer | `list(string)` | n/a | yes |
| <a name="input_sofbase_layer_path"></a> [sofbase\_layer\_path](#input\_sofbase\_layer\_path) | .zip file path for the Sofbase layer | `string` | n/a | yes |
| <a name="input_sofbase_layer_runtimes"></a> [sofbase\_layer\_runtimes](#input\_sofbase\_layer\_runtimes) | Runtime for the Lambda function | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_artifacts_bucket_arn"></a> [artifacts\_bucket\_arn](#output\_artifacts\_bucket\_arn) | n/a |
| <a name="output_artifacts_bucket_name"></a> [artifacts\_bucket\_name](#output\_artifacts\_bucket\_name) | Nombre del bucket ARTIFACTS |
| <a name="output_glue_jmespath_library_key"></a> [glue\_jmespath\_library\_key](#output\_glue\_jmespath\_library\_key) | S3 key for the JMESPath library for Glue |
| <a name="output_glue_powertools_library_key"></a> [glue\_powertools\_library\_key](#output\_glue\_powertools\_library\_key) | S3 key for the AWS Lambda Powertools library for Glue |
| <a name="output_glue_sofbase_library_key"></a> [glue\_sofbase\_library\_key](#output\_glue\_sofbase\_library\_key) | S3 key for the SOF base library for Glue |
| <a name="output_glue_sofdata_library_key"></a> [glue\_sofdata\_library\_key](#output\_glue\_sofdata\_library\_key) | S3 key for the SOF data library for Glue |
| <a name="output_glue_typing_extensions_library_key"></a> [glue\_typing\_extensions\_library\_key](#output\_glue\_typing\_extensions\_library\_key) | S3 key for the Typing Extensions library for Glue |
| <a name="output_pydantic_arn"></a> [pydantic\_arn](#output\_pydantic\_arn) | ARN of the Pydantic Lambda layer |
| <a name="output_sofbase_arn"></a> [sofbase\_arn](#output\_sofbase\_arn) | ARN of the SOF base Lambda layer |
<!-- END_TF_DOCS -->