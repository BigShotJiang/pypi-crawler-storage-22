####################
# libraries module #
####################
# Stores and manages deployable code and assets of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "fart" # Foundation Artifacts
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}"
}

###########################
# S3 bucket for artifacts #
###########################

module "s3_artifacts" {
  source               = "git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git?ref=fc09cc6fb779b262ce1bee5334e85808a107d8a3"
  bucket               = "${local.resource_prefix}-s3-artifacts-bucket-${local.accountid}"
  attach_public_policy = false
  force_destroy = var.force_destroy
}


#######################
# Libraries artifacts #
#######################


# Pydantic lambda layer
resource "aws_s3_object" "s3_pydantic_lambda_layer" {
  bucket      = module.s3_artifacts.s3_bucket_id
  key         = "code-artifacts/lambda-assets/lambda-layers/${basename(var.pydantic_layer_path)}"
  source      = var.pydantic_layer_path
  source_hash = filemd5(var.pydantic_layer_path)
}

resource "aws_lambda_layer_version" "lambda_pydantic_layer" {
  layer_name          = "${local.resource_prefix}-pydantic-layer"
  description         = "${local.resource_prefix}-pydantic-layer"
  compatible_runtimes = var.pydantic_layer_runtimes
  s3_bucket           = module.s3_artifacts.s3_bucket_id
  s3_key              = aws_s3_object.s3_pydantic_lambda_layer.key
  source_code_hash    = filebase64sha256(var.pydantic_layer_path)
}

# Sofbase lambda layer
resource "aws_s3_object" "s3_sofbase_lambda_layer" {
  bucket = module.s3_artifacts.s3_bucket_id
  key    = "code-artifacts/lambda-assets/lambda-layers/${basename(var.sofbase_layer_path)}"
  source = var.sofbase_layer_path
  etag   = filemd5(var.sofbase_layer_path)
}

resource "aws_lambda_layer_version" "lambda_sofbase_layer" {
  layer_name          = "${local.resource_prefix}-sofbase-layer"
  description         = "${local.resource_prefix}-sofbase-layer"
  compatible_runtimes = var.sofbase_layer_runtimes
  s3_bucket           = module.s3_artifacts.s3_bucket_id
  s3_key              = aws_s3_object.s3_sofbase_lambda_layer.key
  source_code_hash    = filebase64sha256(var.sofbase_layer_path)
}

# Glue processor required wheels
# sof data library
resource "aws_s3_object" "glue_sofdata_library" {
  bucket = module.s3_artifacts.s3_bucket_id
  key    = "code-artifacts/glue-assets/glue-wheels/${basename(var.glue_sofdata_library_path)}"
  source = var.glue_sofdata_library_path
  etag   = filemd5(var.glue_sofdata_library_path)
}
resource "aws_s3_object" "glue_sofbase_library" {
  bucket = module.s3_artifacts.s3_bucket_id
  key    = "code-artifacts/glue-assets/glue-wheels/${basename(var.glue_sofbase_library_path)}"
  source = var.glue_sofbase_library_path
  etag   = filemd5(var.glue_sofbase_library_path)
}
resource "aws_s3_object" "glue_jmespath_library" {
  bucket = module.s3_artifacts.s3_bucket_id
  key    = "code-artifacts/glue-assets/glue-wheels/${basename(var.glue_jmespath_library_path)}"
  source = var.glue_jmespath_library_path
  etag   = filemd5(var.glue_jmespath_library_path)
}
resource "aws_s3_object" "glue_powertools_library" {
  bucket = module.s3_artifacts.s3_bucket_id
  key    = "code-artifacts/glue-assets/glue-wheels/${basename(var.glue_powertools_library_path)}"
  source = var.glue_powertools_library_path
  etag   = filemd5(var.glue_powertools_library_path)
}
resource "aws_s3_object" "glue_typing_extensions_library" {
  bucket = module.s3_artifacts.s3_bucket_id
  key    = "code-artifacts/glue-assets/glue-wheels/${basename(var.glue_typing_extensions_library_path)}"
  source = var.glue_typing_extensions_library_path
  etag   = filemd5(var.glue_typing_extensions_library_path)
}

##################
# SSM Parameters #
##################
locals {
    ssm_parameters = {
    "/${local.param_prefix}/S3/ArtifactsBucket/Name" = {
      description = "Artifacts Bucket Name"
      type        = "String"
      value       = module.s3_artifacts.s3_bucket_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/ArtifactsBucket/Arn" = {
      description = "Artifacts Bucket ARN"
      type        = "String"
      value       = module.s3_artifacts.s3_bucket_arn
      tier        = "Standard"
    },
    # TODO: JFAR - Temporary ssm parameters, we need to remove this once new ssm parameters standard are fully integrated on sof-base, sof-data
    "/${var.platform_code}/Foundation/S3/ArtifactsBucket/Arn" = {
      description = "Artifacts S3 Bucket Arn"
      type        = "String"
      value       = module.s3_artifacts.s3_bucket_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/ArtifactsBucket/Name" = {
      description = "Artifacts S3 Bucket Name"
      type        = "String"
      value       = module.s3_artifacts.s3_bucket_id
      tier        = "Standard"
    }
  }
}

module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}