output "artifacts_bucket_name" {
  description = "Nombre del bucket ARTIFACTS"
  value       = module.s3_artifacts.s3_bucket_id
}

output "artifacts_bucket_arn" {
  value = module.s3_artifacts.s3_bucket_arn
}

output "pydantic_arn" {
  description = "ARN of the Pydantic Lambda layer"
  value       = aws_lambda_layer_version.lambda_pydantic_layer.arn
}

output "sofbase_arn" {
  description = "ARN of the SOF base Lambda layer"
  value       = aws_lambda_layer_version.lambda_sofbase_layer.arn
}
output "glue_jmespath_library_key" {
  description = "S3 key for the JMESPath library for Glue"
  value       = aws_s3_object.glue_jmespath_library.key
}
output "glue_sofdata_library_key" {
  description = "S3 key for the SOF data library for Glue"
  value       = aws_s3_object.glue_sofdata_library.key
}
output "glue_sofbase_library_key" {
  description = "S3 key for the SOF base library for Glue"
  value       = aws_s3_object.glue_sofbase_library.key
}
output "glue_powertools_library_key" {
  description = "S3 key for the AWS Lambda Powertools library for Glue"
  value       = aws_s3_object.glue_powertools_library.key
}
output "glue_typing_extensions_library_key" {
  description = "S3 key for the Typing Extensions library for Glue"
  value       = aws_s3_object.glue_typing_extensions_library.key
}