variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "force_destroy" {
  description = "Whether to force destroy the S3 buckets and its contents"
  type        = bool
  default     = false
}

variable "sofbase_layer_runtimes" {
  description = "Runtime for the Lambda function"
  type        = list(string)
}

variable "pydantic_layer_runtimes" {
  description = "Compatible runtimes for the Pydantic layer"
  type        = list(string)
}

# lambda layers paths

variable "sofbase_layer_path" {
  description = ".zip file path for the Sofbase layer"
  type        = string
  validation {
    condition     = can(regex("\\.zip$", var.sofbase_layer_path))
    error_message = "The 'sofbase_layer_path' must be a valid .zip file path."
  }

}
variable "pydantic_layer_path" {
  description = ".zip file path for the Pydantic layer"
  type        = string
  validation {
    condition     = can(regex("\\.zip$", var.pydantic_layer_path))
    error_message = "The 'pydantic_layer_path' must be a valid .zip file path."
  }
}
# glue libraries paths
variable "glue_sofdata_library_path" {
  description = ".whl file path for the sofdata layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_sofdata_library_path))
    error_message = "The 'glue_sofdata_library_path' must be a valid .whl file path."
  }
}
variable "glue_sofbase_library_path" {
  description = ".whl file path for the sofbase layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_sofbase_library_path))
    error_message = "The 'glue_sofbase_library_path' must be a valid .whl file path."
  }
}
variable "glue_jmespath_library_path" {
  description = ".whl file path for the jmespath layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_jmespath_library_path))
    error_message = "The 'glue_jmespath_library_path' must be a valid .whl file path."
  }

}
variable "glue_powertools_library_path" {
  description = ".whl file path for the powertools layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_powertools_library_path))
    error_message = "The 'glue_powertools_library_path' must be a valid .whl file path."
  }

}
variable "glue_typing_extensions_library_path" {
  description = ".whl file path for the typing_extensions layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_typing_extensions_library_path))
    error_message = "The 'glue_typing_extensions_library_path' must be a valid .whl file path."
  }
}