# Configuration construct

This module creates the resources for the configuration components of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "configuration" {
  source = "./terraform/modules/appmanagement"

  # Required variables
  ddb_name_prefix             = "your-prefix"
  enable_cmk_appmanagement    = true
  deletion_protection_enabled  = true
  sqs_name_prefix             = "your-sqs-prefix"
  kinesis_name_prefix         = "your-kinesis-prefix"
  ddb_kms_key                 = "your-kms-key"
  sqs_kms_master_key_id       = "your-sqs-kms-key"
  kinesis_kms_key             = "your-kinesis-kms-key"
}
```
<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ddb_appmanagement_capacity_config_table"></a> [ddb\_appmanagement\_capacity\_config\_table](#module\_ddb\_appmanagement\_capacity\_config\_table) | git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git | e47cf5f0d2636bd5018b4a65e988295d5360cbb6 |
| <a name="module_ddb_appmanagement_checkpoint_control_table"></a> [ddb\_appmanagement\_checkpoint\_control\_table](#module\_ddb\_appmanagement\_checkpoint\_control\_table) | git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git | e47cf5f0d2636bd5018b4a65e988295d5360cbb6 |
| <a name="module_ddb_appmanagement_data_products_table"></a> [ddb\_appmanagement\_data\_products\_table](#module\_ddb\_appmanagement\_data\_products\_table) | git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git | e47cf5f0d2636bd5018b4a65e988295d5360cbb6 |
| <a name="module_ddb_appmanagement_pipeline_registry_table"></a> [ddb\_appmanagement\_pipeline\_registry\_table](#module\_ddb\_appmanagement\_pipeline\_registry\_table) | git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git | e47cf5f0d2636bd5018b4a65e988295d5360cbb6 |
| <a name="module_sqs_appmanagement_objects_queue"></a> [sqs\_appmanagement\_objects\_queue](#module\_sqs\_appmanagement\_objects\_queue) | git::https://github.com/terraform-aws-modules/terraform-aws-sqs.git | debb3cbca57ace668e0b79d9708c7308bc591d44 |
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_sqs_queue.objects_dlq](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sqs_queue) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_ddb_kms_key"></a> [ddb\_kms\_key](#input\_ddb\_kms\_key) | KMS Key for DynamoDB | `string` | n/a | yes |
| <a name="input_deletion_protection_enabled"></a> [deletion\_protection\_enabled](#input\_deletion\_protection\_enabled) | Enable deletion protection for the Dynamodb table | `bool` | `true` | no |
| <a name="input_enable_cmk_appmanagement"></a> [enable\_cmk\_appmanagement](#input\_enable\_cmk\_appmanagement) | Enable CMK for App Management resources | `bool` | `false` | no |
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_sqs_kms_master_key_id"></a> [sqs\_kms\_master\_key\_id](#input\_sqs\_kms\_master\_key\_id) | KMS Key ID for SQS | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ddb_appmanagement_capacity_config_table_arn"></a> [ddb\_appmanagement\_capacity\_config\_table\_arn](#output\_ddb\_appmanagement\_capacity\_config\_table\_arn) | n/a |
| <a name="output_ddb_appmanagement_capacity_config_table_name"></a> [ddb\_appmanagement\_capacity\_config\_table\_name](#output\_ddb\_appmanagement\_capacity\_config\_table\_name) | n/a |
| <a name="output_ddb_appmanagement_checkpoint_control_table_arn"></a> [ddb\_appmanagement\_checkpoint\_control\_table\_arn](#output\_ddb\_appmanagement\_checkpoint\_control\_table\_arn) | n/a |
| <a name="output_ddb_appmanagement_checkpoint_control_table_name"></a> [ddb\_appmanagement\_checkpoint\_control\_table\_name](#output\_ddb\_appmanagement\_checkpoint\_control\_table\_name) | n/a |
| <a name="output_ddb_appmanagement_data_products_table_arn"></a> [ddb\_appmanagement\_data\_products\_table\_arn](#output\_ddb\_appmanagement\_data\_products\_table\_arn) | n/a |
| <a name="output_ddb_appmanagement_data_products_table_name"></a> [ddb\_appmanagement\_data\_products\_table\_name](#output\_ddb\_appmanagement\_data\_products\_table\_name) | n/a |
| <a name="output_sqs_appmanagement_objects_dlq_arn"></a> [sqs\_appmanagement\_objects\_dlq\_arn](#output\_sqs\_appmanagement\_objects\_dlq\_arn) | n/a |
| <a name="output_sqs_appmanagement_objects_queue_arn"></a> [sqs\_appmanagement\_objects\_queue\_arn](#output\_sqs\_appmanagement\_objects\_queue\_arn) | n/a |
<!-- END_TF_DOCS -->