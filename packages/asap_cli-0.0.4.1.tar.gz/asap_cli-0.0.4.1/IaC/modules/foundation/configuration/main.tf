########################
# configuration module #
########################
# Manages shared configuration tables of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "fcnf" # Foundation Configuration
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}"
  # Use CMK for non-andv environments, AMK for andv
  use_cmk = var.enable_cmk_appmanagement == true

  # DynamoDB encryption settings
  # Always encrypted, but uses AMK for andv, CMK for others
  dynamodb_server_side_encryption_enabled = true
  dynamodb_kms_key_arn                    = local.use_cmk ? var.ddb_kms_key : null

  # SQS encryption settings
  # Always encrypted, but uses AMK for andv, CMK for others
  sqs_kms_master_key_id = local.use_cmk ? var.sqs_kms_master_key_id : "alias/aws/sqs"
}

###################
# DynamoDB Tables #
###################

module "ddb_appmanagement_pipeline_registry_table" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git?ref=e47cf5f0d2636bd5018b4a65e988295d5360cbb6"

  deletion_protection_enabled = var.deletion_protection_enabled

  name           = "${local.resource_prefix}-appmanagement-pipeline-registry"
  billing_mode   = "PROVISIONED"
  read_capacity  = 5
  write_capacity = 5
  hash_key       = "name"
  attributes = [
    {
      name = "name"
      type = "S"
    }
  ]
  # Conditional encryption - always enabled, but AMK vs CMK
  server_side_encryption_enabled     = true
  server_side_encryption_kms_key_arn = local.dynamodb_kms_key_arn
}

module "ddb_appmanagement_data_products_table" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git?ref=e47cf5f0d2636bd5018b4a65e988295d5360cbb6"

  deletion_protection_enabled = var.deletion_protection_enabled

  name         = "${local.resource_prefix}-appmanagement-data-products"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "id"
  attributes = [
    {
      name = "id"
      type = "S"
    },
    {
      name = "data_product_name"
      type = "S"
    },
    {
      name = "last_updated_timestamp"
      type = "S"
    }
  ]
  global_secondary_indexes = [
    {
      name            = "data_product_name-last_updated_timestamp-index"
      hash_key        = "data_product_name"
      range_key       = "last_updated_timestamp"
      projection_type = "ALL"
      #read_capacity      = 5
      #write_capacity     = 5
    }
  ]
  # Conditional encryption - always enabled, but AMK vs CMK
  server_side_encryption_enabled     = true
  server_side_encryption_kms_key_arn = local.dynamodb_kms_key_arn
}

module "ddb_appmanagement_capacity_config_table" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git?ref=e47cf5f0d2636bd5018b4a65e988295d5360cbb6"

  deletion_protection_enabled = var.deletion_protection_enabled

  name           = "${local.resource_prefix}-appmanagement-capacity-config"
  billing_mode   = "PROVISIONED"
  read_capacity  = 5
  write_capacity = 5
  hash_key       = "id"
  attributes = [
    {
      name = "id"
      type = "S"
    }
  ]
  # Conditional encryption - always enabled, but AMK vs CMK
  server_side_encryption_enabled     = true
  server_side_encryption_kms_key_arn = local.dynamodb_kms_key_arn
}

module "ddb_appmanagement_checkpoint_control_table" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git?ref=e47cf5f0d2636bd5018b4a65e988295d5360cbb6"

  deletion_protection_enabled = var.deletion_protection_enabled
  name                        = "${local.resource_prefix}-appmanagement-checkpoint-control"
  billing_mode                = "PROVISIONED"
  read_capacity               = 5
  write_capacity              = 5
  hash_key                    = "CheckpointId"
  attributes = [
    {
      name = "CheckpointId"
      type = "S"
    }
  ]
  # Conditional encryption - always enabled, but AMK vs CMK
  server_side_encryption_enabled     = true
  server_side_encryption_kms_key_arn = local.dynamodb_kms_key_arn
}

##############
# sqs queues #
##############

resource "aws_sqs_queue" "objects_dlq" {

  name                       = "${local.resource_prefix}-s3-objects-dlq"
  delay_seconds              = 0
  message_retention_seconds  = 1209600 # 14 days
  visibility_timeout_seconds = 30
  max_message_size           = 262144
  # Conditional encryption - AMK for andv, CMK for others
  kms_master_key_id = local.sqs_kms_master_key_id
}

module "sqs_appmanagement_objects_queue" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-sqs.git?ref=debb3cbca57ace668e0b79d9708c7308bc591d44"

  name                        = "${local.resource_prefix}-s3-objects-queue"
  delay_seconds               = 0
  message_retention_seconds   = 345600 # 4 days
  visibility_timeout_seconds  = 30
  fifo_queue                  = false
  content_based_deduplication = false
  max_message_size            = 262144
  # Conditional encryption - AMK for andv, CMK for others
  kms_master_key_id = local.sqs_kms_master_key_id
  redrive_policy = {
    deadLetterTargetArn = aws_sqs_queue.objects_dlq.arn
    maxReceiveCount     = 5
  }
  depends_on = [aws_sqs_queue.objects_dlq]
}
##################
# SSM Parameters #
##################
locals {
  ssm_parameters = {
    "/${local.param_prefix}/DDB/PipelineRegistry/TableName" = {
      description = "Pipeline Registry DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_appmanagement_pipeline_registry_table.dynamodb_table_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/PipelineRegistry/TableArn" = {
      description = "Pipeline Registry DynamoDB Table Arn"
      type        = "String"
      value       = module.ddb_appmanagement_pipeline_registry_table.dynamodb_table_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/DataProducts/TableName" = {
      description = "Data Products DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_appmanagement_data_products_table.dynamodb_table_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/DataProducts/TableArn" = {
      description = "Pipeline Registry DynamoDB Table Arn"
      type        = "String"
      value       = module.ddb_appmanagement_data_products_table.dynamodb_table_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/DataProducts/TableName" = {
      description = "Capacity Config DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_appmanagement_capacity_config_table.dynamodb_table_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/DataProducts/TableArn" = {
      description = "Capacity Config DynamoDB Table Arn"
      type        = "String"
      value       = module.ddb_appmanagement_capacity_config_table.dynamodb_table_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/DataProducts/TableName" = {
      description = "Checkpoint control DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_appmanagement_checkpoint_control_table.dynamodb_table_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/DataProducts/TableArn" = {
      description = "Checkpoint control DynamoDB Table Arn"
      type        = "String"
      value       = module.ddb_appmanagement_checkpoint_control_table.dynamodb_table_arn
      tier        = "Standard"
    }
    # TODO: JFAR - Temporary ssm parameters, we need to remove this once new ssm parameters standard are fully integrated on sof-base, sof-data
    "/${var.platform_code}/Foundation/DDB/PipelineRegistry/TableArn" = {
      description = "Pipeline Registry DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_appmanagement_pipeline_registry_table.dynamodb_table_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/DDB/PipelineRegistry/TableName" = {
      description = "Pipeline Registry DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_appmanagement_pipeline_registry_table.dynamodb_table_id
      tier        = "Standard"
    }
  }
}

module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}