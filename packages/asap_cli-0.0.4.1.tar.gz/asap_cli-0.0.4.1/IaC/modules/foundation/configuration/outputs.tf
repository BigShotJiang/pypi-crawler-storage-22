output "ddb_appmanagement_data_products_table_name" {
  value = module.ddb_appmanagement_data_products_table.dynamodb_table_id
}

output "ddb_appmanagement_data_products_table_arn" {
  value = module.ddb_appmanagement_data_products_table.dynamodb_table_arn
}

output "ddb_appmanagement_capacity_config_table_arn" {
  value = module.ddb_appmanagement_capacity_config_table.dynamodb_table_arn
}

output "ddb_appmanagement_capacity_config_table_name" {
  value = module.ddb_appmanagement_capacity_config_table.dynamodb_table_id
}

output "ddb_appmanagement_checkpoint_control_table_arn" {
  value = module.ddb_appmanagement_checkpoint_control_table.dynamodb_table_arn
}

output "ddb_appmanagement_checkpoint_control_table_name" {
  value = module.ddb_appmanagement_checkpoint_control_table.dynamodb_table_id
}

output "sqs_appmanagement_objects_dlq_arn" {
  value = aws_sqs_queue.objects_dlq.arn
}
# output "sqs_appmanagement_dlq_arn" {
#   value = aws_sqs_queue.dlq.arn
# }

output "sqs_appmanagement_objects_queue_arn" {
  value = module.sqs_appmanagement_objects_queue.queue_arn
}
