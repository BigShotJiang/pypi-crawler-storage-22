# Observability construct

This module creates the resources for the observability components of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "observability" {
  source = "./modules/appmanagement"
}
```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ddb_pipeline_execution_history_table"></a> [ddb\_pipeline\_execution\_history\_table](#module\_ddb\_pipeline\_execution\_history\_table) | git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git | v4.4.0 |
| <a name="module_execution_history_kinesis_stream"></a> [execution\_history\_kinesis\_stream](#module\_execution\_history\_kinesis\_stream) | git::https://github.com/cloudposse/terraform-aws-kinesis-stream.git | 10ab08bfa423080071920baf526e7c8a7f1df9e4 |
| <a name="module_iam_firehose_delivery_stream_role"></a> [iam\_firehose\_delivery\_stream\_role](#module\_iam\_firehose\_delivery\_stream\_role) | git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role | 304c8b5bbe99a1b17e1d24c96a4a384f108caced |
| <a name="module_lftn_fact_service_cost"></a> [lftn\_fact\_service\_cost](#module\_lftn\_fact\_service\_cost) | git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git | 84dfbfddf9483bc56afa0aff516177c03652f0c7 |
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_dynamodb_kinesis_streaming_destination.execution_history_destination](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_kinesis_streaming_destination) | resource |
| [aws_kinesis_firehose_delivery_stream.execution_history_destination](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kinesis_firehose_delivery_stream) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_analytics_bucket_name"></a> [analytics\_bucket\_name](#input\_analytics\_bucket\_name) | S3 bucket Name for analytics data | `string` | n/a | yes |
| <a name="input_ddb_kms_key"></a> [ddb\_kms\_key](#input\_ddb\_kms\_key) | KMS Key for DynamoDB | `string` | n/a | yes |
| <a name="input_deletion_protection_enabled"></a> [deletion\_protection\_enabled](#input\_deletion\_protection\_enabled) | Enable deletion protection for the Dynamodb table | `bool` | `true` | no |
| <a name="input_enable_cmk_appmanagement"></a> [enable\_cmk\_appmanagement](#input\_enable\_cmk\_appmanagement) | Enable CMK for App Management resources | `bool` | `false` | no |
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_execution_history_pitr_period_in_days"></a> [execution\_history\_pitr\_period\_in\_days](#input\_execution\_history\_pitr\_period\_in\_days) | Point in time recovery period in days for execution history table. Set to null to disable. | `number` | `null` | no |
| <a name="input_force_destroy"></a> [force\_destroy](#input\_force\_destroy) | Whether to force destroy the S3 buckets and its contents | `bool` | `false` | no |
| <a name="input_iam_lftn_fact_service_cost_role_arn"></a> [iam\_lftn\_fact\_service\_cost\_role\_arn](#input\_iam\_lftn\_fact\_service\_cost\_role\_arn) | iam\_lftn\_fact\_service\_cost\_role\_arn | `string` | n/a | yes |
| <a name="input_kinesis_kms_key"></a> [kinesis\_kms\_key](#input\_kinesis\_kms\_key) | KMS Key id for Kinesis | `string` | n/a | yes |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_raw_bucket_name"></a> [raw\_bucket\_name](#input\_raw\_bucket\_name) | S3 bucket Name for raw data | `string` | n/a | yes |
| <a name="input_sqs_kms_master_key_id"></a> [sqs\_kms\_master\_key\_id](#input\_sqs\_kms\_master\_key\_id) | KMS Key ID for SQS | `string` | n/a | yes |
| <a name="input_stage_bucket_name"></a> [stage\_bucket\_name](#input\_stage\_bucket\_name) | S3 bucket Name for stage data | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ddb_pipeline_execution_history_table_arn"></a> [ddb\_pipeline\_execution\_history\_table\_arn](#output\_ddb\_pipeline\_execution\_history\_table\_arn) | n/a |
| <a name="output_ddb_pipeline_execution_history_table_name"></a> [ddb\_pipeline\_execution\_history\_table\_name](#output\_ddb\_pipeline\_execution\_history\_table\_name) | n/a |
<!-- END_TF_DOCS -->