"""Utils Module shared between lambdas"""
import logging
import os
import boto3
import time


def read_from_ssm(parameter_name, logger, ssm_client):
    """Method to read parameters from ssm"""
    # ssm_client = boto3.client('ssm', region_name=REGION)
    try:
        response = ssm_client.get_parameter(
            Name=parameter_name,
            WithDecryption=True
        )
        return response['Parameter']['Value']
    except Exception as ssm_exception:
        logger.error(f"SSM Exception: {ssm_exception}")
        raise GenericSsmError('Error Calling SSM Service')
    

def send_notification(sns_arn, subject, message, logger, sns_client):
    """Method to send notifications to SNS"""
    # sns_client = boto3.client('sns', region_name=REGION)
    try:
        response = sns_client.publish(
            TargetArn=sns_arn,
            Subject=subject,
            Message=message
        )
        logger.info(f"Published the message to SNS topic. {response}")
        return response
    except Exception as sns_exception:
        logger.error(f"SNS Exception: {sns_exception}")
        raise GenericSnsError('Error Calling SNS Service') from sns_exception

def get_cost_report(ce_client, start_date, end_date, granularity, services_list, cost_allocation_tag, logger):
    """Method to request a Cost Explorer report"""

    grouping_definition = [
        {'Type': 'DIMENSION', 'Key': 'SERVICE'}
    ]
    
    # Handle request with cost allocation tag
    if cost_allocation_tag:
        grouping_definition.append({'Type': 'TAG', 'Key': cost_allocation_tag})

    try:
        response = ce_client.get_cost_and_usage(
            TimePeriod={
                'Start': start_date,
                'End': end_date
            },
            Granularity=granularity,
            Metrics=['UnblendedCost', 'UsageQuantity'],
            Filter={'Dimensions': {'Key': 'SERVICE', 'Values': services_list}},
            GroupBy=grouping_definition,
        )
        return response['ResultsByTime']
    
    except Exception as ce_exception:
        logger.error(f"Cost Explorer Exception: {ce_exception}")
        raise GenericCostExplorerError('Error Calling Cost Explorer Service') from ce_exception


def upload_to_s3(s3_client, bucket_name, object_key, data, logger):
    try: 
        s3_client.put_object(
            Body=data,
            Bucket=bucket_name,
            Key=object_key
        )
    except Exception as s3_exception:
        logger.error(f"S3 Exception: {s3_exception}")
        raise GenericS3Error('Error Calling S3 Service') from s3_exception

def init_logger(object_name):
    """Method to init logger object"""
    logging.basicConfig()
    logger = logging.getLogger()
    log_level = os.getenv('LOG_LEVEL', 'INFO')
    logger.setLevel(getattr(logging, log_level))
    logger.info('Loading Function %s', str(object_name))
    return logger

class GenericCostExplorerError(Exception):
    """Exception class for cost explore errors"""


class GenericSnsError(Exception):
    """Exception class for SNS errors"""


class GenericS3Error(Exception):
    """Exception class for S3 errors"""

class GenericSsmError(Exception):
    """Exception class for ssm errors"""