# pylint: disable=E0401

"""Module with lambda code to extract costs report from Cost Explorer."""
import logging
import os
import boto3
import time
from datetime import datetime, date, timedelta, timezone
import awswrangler as wr
import pandas as pd
from io import BytesIO
from commons import read_from_ssm, get_cost_report, upload_to_s3, init_logger, send_notification

# Logging Definition
logger = init_logger(__name__)

# Env Variables

BUCKET_NAME= os.getenv('BUCKET_NAME')
DEFAULT_TIME_FORMAT = '%Y-%m-%d'
REGION = boto3.session.Session().region_name

# Boto3 clients
session = boto3.Session(region_name=REGION)
ssm_client = session.client(service_name='ssm')
ce_client = session.client(service_name='ce')

###########
# HANDLER #
###########
def lambda_handler(event, context):
    """Lambda handler method"""
    pipeline = event.get('pipeline')
    start_date = event["execution_args"].get('startDate')
    end_date = event["execution_args"].get('endDate')
    cost_allocation_tag = event["execution_args"].get('costAllocationTag')
    approach = event["execution_args"].get('approach', "PREVIOUS_MONTH")
    database_name = event["execution_args"].get('database_name', "sample_db")
    table_name = event["execution_args"].get('table_name', "fact_service_cost")
    bucket_path = event["execution_args"].get('bucket_path', f"/{database_name}/{table_name}/")
    partition_column = 'year_month'
    granularity = "MONTHLY"

    logger.info(REGION)
    logger.info(f'Starting {pipeline} processing event: {event}')
    logger.info(f'Configuration parameters - start_date: {start_date}, end_date: {end_date}, approach: {approach}, bucket_path: {bucket_path}')
    logger.info(f'Using partition_column: {partition_column}, granularity: {granularity}')
    try:

        ##### Retrieve Services included in the report
        # services_list = read_from_ssm(SSM_PARAM_NAME, logger, ssm_client).split(',')
        services_list = ['AWS Glue','AWS Lambda','Amazon DynamoDB','AWS Step Functions','Amazon Elastic Compute Cloud - Compute','Amazon Simple Storage Service','AWS DataSync','Amazon Simple Notification Service','AWS Secrets Manager','Amazon Redshift']
        logger.info(f'Retrieved {len(services_list)} services from SSM parameter', )

        ##### Execute Cost Report Extraction
        generate_cost_report(
            start_date=start_date,
            end_date=end_date,
            approach=approach,
            # validation_date_pattern=validation_date_pattern,
            ce_client=ce_client,
            boto3_session = session,
            services_list=services_list,
            cost_allocation_tag=cost_allocation_tag,
            granularity=granularity,
            bucket_path=bucket_path,
            bucket_name=BUCKET_NAME,
            partition_column=partition_column,
            database_name=database_name,
            table_name=table_name,
            logger=logger
            )
    
    except (GenerateCostReportError) as ex:
        msg_exception = "Error executing lambda:" + str(ex)
        msg_exception = str(msg_exception)[0:50]
        logger.error("ERROR: %s ", str(ex))
        logger.info(msg_exception)
        # send_notification(SNS_ERROR_ARN,
        #                   f"Error executing lambda {context.function_name}",
        #                   f"Lambda Function Name: {context.function_name}\n{msg_exception}"
        #                   , logger)
        raise ex
    return "success"

#############
# Utilities #
#############

def generate_cost_report(start_date, end_date, approach, ce_client, boto3_session, services_list, cost_allocation_tag, granularity, bucket_path, bucket_name, partition_column, database_name, table_name, logger):
    """
    Description:
        Generate a monthly cost report from AWS Cost Explorer, create a Parquet table, and upload it to an S3 bucket with partitioning.

    Args:
        start_date (str): The start date of the month in the format YYYY-MM-DD.
        end_date (str): The end date of the month in the format YYYY-MM-DD.
        approach (str): The approach to use for calculating the start and end dates. Either 'PREVIOUS_MONTH' or 'CUSTOM_DATES'. 
        ce_client (botocore.client.CostExplorer): A Cost Explorer client object.
        s3_client (botocore.client.S3): An S3 client object.
        services_list (list): A list of service names to include in the cost report.
        cost_allocation_tag (str): The cost allocation tag to use for grouping the report.
        granularity (str): Granularity used by the report api call
        table_name (str): The name of the table_name to be used as the prefix for the S3 object key.
        bucket_name (str): The name of the S3 bucket to store the Parquet file.
        partition_column (str): The column name to use for partitioning the Parquet file.
        logger: Logger instance

    Returns:
        None

    Raises:
        GenerateCostReportError: If the process fail raise a custom error
    """
    try:
        # Generate extraction dates
        logger.info(f'Calculating date range with approach: {approach}')
        first_day_range, last_day_range = get_dates(start_date=start_date, end_date=end_date, approach=approach)
        logger.info(f'Extracting report for -> start_date: {first_day_range} and end_date: {last_day_range}')

        # Extracting data from Cost Explorer
        logger.info(f'Calling Cost Explorer API with granularity: {granularity}')
        logger.info(f'Services to include: {len(services_list)}')
        logger.info(f'Using cost allocation tag: {cost_allocation_tag}')
        result = get_cost_report(ce_client, first_day_range, last_day_range, granularity, services_list, cost_allocation_tag, logger)
        logger.info(f'Received Cost Explorer response with {len(result)} results')

        # Create pyarrow table and parquet format
        logger.info('Processing Cost Explorer response')
        table = process_cost_explorer_response(result)
        logger.info(f'Created DataFrame with shape: {str(table.shape)}')

        # Write parquet partitioned to S3 bucket
        logger.info(f'Writing data to S3 bucket: {bucket_name}, table_name: {table_name}')
        write_data_to_s3_parquet(table, bucket_name, bucket_path, database_name, table_name, partition_column, boto3_session)
        logger.info('Successfully wrote data to S3')

    except Exception as ex:
        logger.error('Failed to generate cost report: %s', str(ex))
        raise GenerateCostReportError(f'Unable to Generate Cost Report: {str(ex)}, for the services: {services_list} between dates {first_day_range} and {last_day_range}')

def get_dates(approach, start_date=None, end_date=None):
    """
    Returns the start and end dates for a monthly or daily process.
    All dates are in YYYY-MM-DD format.

    Args:
        approach (str): The approach to use for calculating the dates. 
                       Either 'PREVIOUS_MONTH', 'PREVIOUS_DAY', 'CURRENT_MONTH' or 'CUSTOM_DATES'.
        start_date (str, optional): The start date in YYYY-MM-DD format.
        end_date (str, optional): The end date in YYYY-MM-DD format.

    Returns:
        tuple: A tuple containing the start and end dates as strings in YYYY-MM-DD format.

    Raises:
        ValueError:
            If the input dates are not in YYYY-MM-DD format,
            If the start date is after the end date,
            If dates are not provided when required.
    """
    today = date.today()
    
    if approach == 'PREVIOUS_MONTH':
        # Use today's date for previous month calculations
        today
        if start_date or end_date:
            print("Warning: start_date and end_date are ignored when using 'PREVIOUS_MONTH' approach")
        result_start = (today.replace(day=1) - timedelta(days=1)).replace(day=1)
        result_end = today.replace(day=1)
    elif approach == 'CURRENT_MONTH':
        # Use today's date for current month calculations
        today
        if start_date or end_date:
            print("Warning: start_date and end_date are ignored when using 'CURRENT_MONTH' approach")
        result_start = today.replace(day=1)
        result_end = today
    elif approach == 'PREVIOUS_DAY':
        # Use today's date for previous day calculations
        today
        if start_date or end_date:
            print("Warning: start_date and end_date are ignored when using 'PREVIOUS_DAY' approach")
        result_start = today - timedelta(days=1)
        result_end = today
    elif approach == 'CUSTOM_DATES':
        if not start_date or not end_date:
            raise ValueError("Both start_date and end_date are required when using 'CUSTOM_DATES' approach")
            
        try:
            # Parse the input dates
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            raise ValueError("Invalid date format. Please provide dates in YYYY-MM-DD format")

        # Ensure the start date is before the end date
        if start_date > end_date:
            raise ValueError("Start date must be before the end date.")
        result_start = start_date
        result_end = end_date

    else:
        raise ValueError("Invalid approach. Please provide either 'PREVIOUS_MONTH', 'PREVIOUS_DAY', or 'CUSTOM_DATES'.")

    return result_start.strftime('%Y-%m-%d'), result_end.strftime('%Y-%m-%d')

def extract_year_month(date_string):
    """
    Description:
        Extract the year and month components from a date string.

    Args:
        date_string (str): A date string in the format 'YYYY-MM-DD'.

    Returns:
        str: A string representing the year and month in the format 'YYYY-MM'.

    Raises:
        ValueError: If the input date string is not in the expected format 'YYYY-MM-DD'.
        TypeError: If the input is not a string.
    """
    try:
        # Check if the input is a string
        if not isinstance(date_string, str):
            raise TypeError("Input must be a string")

        # Convert the string to a datetime object
        date_object = datetime.strptime(date_string, "%Y-%m-%d")

        # Extract year and month
        year = date_object.year
        month = date_object.month

        # Return year and month as a string
        return f"{year}-{month:02d}"
    except ValueError as e:
        raise ValueError(f"Invalid date format. Expected format: 'YYYY-MM-DD'. Error: {str(e)}")

def process_cost_explorer_response(cost_explorer_response):
    """
    Process the cost explorer response data and create a Pandas DataFrame.

    Args:
        cost_explorer_response (list): A list of dictionaries containing cost explorer data.

    Returns:
        pandas.DataFrame: A Pandas DataFrame containing the processed cost explorer data.
    """
    try:
        data = []
        result_count = len(cost_explorer_response)
        logger.info(f"Processing {result_count} results from Cost Explorer")
        default_tag = "N/A"
        
        for result in cost_explorer_response:
            # date = result["TimePeriod"].get("Start")
            year_month = extract_year_month(result["TimePeriod"].get("Start"))
            
            for group in result['Groups']:
                keys = group['Keys']
                service = keys[0]
                cost_allocation_tag = keys[1] if len(keys) > 1 else default_tag
                cost = group['Metrics']['UnblendedCost']['Amount']
                data.append((service, cost_allocation_tag, cost, year_month))

        df = pd.DataFrame(data, columns=['service', 'cost_allocation_tag', 'cost', 'year_month'])
        logger.info(f"Created DataFrame with {len(df)} rows and {len(df.columns)} columns")
        return df
    
    except Exception as ex:
        logger.error(f"Error processing Cost Explorer response: {str(ex)}")
        raise ProcessCostExplorerResponse(f'Unable to Create table: {str(ex)}')

def write_data_to_s3_parquet(df, bucket_name, bucket_path, database_name, table_name, partition_column, boto3_session):
    """
    Write a Pandas DataFrame to an S3 bucket in Parquet format, partitioned by the specified column.

    Args:
        df (pandas.DataFrame): The Pandas DataFrame to be written to S3.
        bucket_name (str): The name of the S3 bucket to write the data to.
        bucket_path (str): The name of the bucket path/folder in the S3 bucket.
        partition_column (str): The name of the column to use for partitioning the data.
        logger (logging.Logger): A logger object for logging purposes.

    Returns:
        None
    """
    try:
        logger.info(f"Writing DataFrame to S3 bucket {bucket_name}/{bucket_path} partitioned by {partition_column}")
        logger.info(f"DataFrame shape: {df.shape}")
        logger.info(f"Partition values: {df[partition_column].unique()}")
        
        wr.s3.to_parquet(
            df=df,
            path=f"s3://{bucket_name}/{bucket_path}",
            dataset=True,
            partition_cols=[partition_column],
            mode="overwrite_partitions",
            boto3_session = boto3_session,
            database=database_name,
            table=table_name
        )
        logger.info("Successfully wrote data to S3")
    except Exception as ex:
        logger.error(f"Error writing data to S3: {str(ex)}")
        raise WriteDataToS3Parquet(f'Unable to upload the data to s3: {str(ex)}')

class GenerateCostReportError(Exception):
    """Exception class for custom Generate Cost Report errors"""

class WriteDataToS3Parquet(Exception):
    """Exception class for Write data to s3 errors"""

class ProcessCostExplorerResponse(Exception):
    """Exception class for cost explorer response parsing errors"""
