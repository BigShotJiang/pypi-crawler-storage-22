########################
# observability module #
########################
# This module creates the resources for the observability components of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "fobs" # Foundation Observability
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}"


  # Use CMK for non-andv environments, AMK for andv
  use_cmk = var.enable_cmk_appmanagement == true

  # DynamoDB encryption settings
  # Always encrypted, but uses AMK for andv, CMK for others
  dynamodb_server_side_encryption_enabled = true
  dynamodb_kms_key_arn                    = local.use_cmk ? var.ddb_kms_key : null

  # SQS encryption settings
  # Always encrypted, but uses AMK for andv, CMK for others
  sqs_kms_master_key_id = local.use_cmk ? var.sqs_kms_master_key_id : "alias/aws/sqs"

  # Kinesis encryption settings
  # Always encrypted, but uses AMK for andv, CMK for others
  kinesis_encryption_type = "KMS"
  kinesis_kms_key_id      = local.use_cmk ? var.kinesis_kms_key : "alias/aws/kinesis"

}

# DynamoDB table for App Management Pipeline Execution History
module "ddb_pipeline_execution_history_table" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-dynamodb-table.git?ref=v4.4.0"

  deletion_protection_enabled = var.deletion_protection_enabled

  name         = "${local.resource_prefix}-pipeline-execution-history"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "id"
  attributes = [
    {
      name = "id"
      type = "S"
    },
    {
      name = "data_product_name"
      type = "S"
    },
    {
      name = "last_updated_timestamp"
      type = "S"
    }
  ]
  global_secondary_indexes = [
    {
      name            = "data_product_name-last_updated_timestamp-index"
      hash_key        = "data_product_name"
      range_key       = "last_updated_timestamp"
      projection_type = "ALL"
      #read_capacity      = 5
      #write_capacity     = 5
    }
  ]
  # Conditional encryption - always enabled, but AMK vs CMK
  server_side_encryption_enabled     = true
  server_side_encryption_kms_key_arn = local.dynamodb_kms_key_arn

  # PITR Configuration
  point_in_time_recovery_enabled = var.execution_history_pitr_period_in_days != null
  point_in_time_recovery_period_in_days = var.execution_history_pitr_period_in_days

  # TTL Configuration
  ttl_enabled = true
  ttl_attribute_name = "ttl"

  # Stream configuration
  # stream_enabled = true
  # stream_view_type = "NEW_IMAGE"
}
###########
# Kinesis #
###########

module "execution_history_kinesis_stream" {
  source = "git::https://github.com/cloudposse/terraform-aws-kinesis-stream.git?ref=10ab08bfa423080071920baf526e7c8a7f1df9e4"

  name = "${local.resource_prefix}-execution-history-events-stream"
  stream_mode      = "ON_DEMAND"
  retention_period = 24
  shard_level_metrics = [
    "IncomingBytes",
    "OutgoingBytes",
    "IncomingRecords",
    "OutgoingRecords"
  ]
  # Conditional encryption - AMK for andv, CMK for others
  encryption_type           = local.kinesis_encryption_type
  kms_key_id                = local.kinesis_kms_key_id
  enforce_consumer_deletion = true
}
resource "aws_dynamodb_kinesis_streaming_destination" "execution_history_destination" {
  stream_arn                               = module.execution_history_kinesis_stream.stream_arn
  table_name                               = module.ddb_pipeline_execution_history_table.dynamodb_table_id
  approximate_creation_date_time_precision = "MICROSECOND"
}
resource "aws_kinesis_firehose_delivery_stream" "execution_history_destination" {
  name        = "${local.resource_prefix}-execution-history-events-firehose"
  destination = "extended_s3"

  kinesis_source_configuration {
    kinesis_stream_arn = module.execution_history_kinesis_stream.stream_arn
    role_arn           = module.iam_firehose_delivery_stream_role.iam_role_arn
  }
  

  extended_s3_configuration {
    role_arn   = module.iam_firehose_delivery_stream_role.iam_role_arn
    bucket_arn = "arn:aws:s3:::${var.raw_bucket_name}"
    prefix              = "dl_analytics_daop/pipeline-execution-history/data/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/"
    error_output_prefix = "dl_analytics_daop/pipeline-execution-history/errors/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/!{firehose:error-output-type}/"
    buffering_size = 5
    buffering_interval = 300
    compression_format = "UNCOMPRESSED"
    # kms_key_arn = ""
    # cloudwatch_logging_options {}
    processing_configuration {
      enabled = true
      processors {
        type = "AppendDelimiterToRecord"
      }
    }
    file_extension = ".json"
    # s3_backup_mode = ""
    # s3_backup_configuration {}
    # dynamic_partitioning_configuration {
    #   enabled = true
    #   retry_duration = 300
    # }

    # data_format_conversion_configuration {}

    # processing_configuration {}
  }
}
module "iam_firehose_delivery_stream_role" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

  create_role          = true
  role_requires_mfa    = false
  trusted_role_actions = ["sts:AssumeRole"]
  role_name            = "${local.resource_prefix}-execution-history-events-firehose-role"
  role_description     = "IAM role for Kinesis Firehose to deliver data to S3"
  # role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
  trusted_role_services  = ["firehose.amazonaws.com"]
  allow_self_assume_role = false

  inline_policy_statements = {
    s3platformanalytics = {
      sid    = "s3platformanalytics"
      effect = "Allow"
      actions = [
        "s3:AbortMultipartUpload",
        "s3:GetBucketLocation",
        "s3:GetObject",
        "s3:ListBucket",
        "s3:ListBucketMultipartUploads",
        "s3:PutObject"
      ]
      resources = [
        "arn:aws:s3:::${var.raw_bucket_name}",
        "arn:aws:s3:::${var.raw_bucket_name}/*"	
      ]
    }
    KinesisDataStream = {
      sid    = "KinesisDataStream"
      effect = "Allow"
      actions = [
        "kinesis:DescribeStream",
        "kinesis:GetShardIterator",
        "kinesis:GetRecords",
        "kinesis:ListShards"
      ]
      resources = [
        module.execution_history_kinesis_stream.stream_arn
      ]
    }
    # KMSPermissions = {
    #   sid    = "KMSPermissions"
    #   effect = "Allow"
    #   actions = [
    #     "kms:Decrypt",
    #     "kms:GenerateDataKey"
    #   ]
    #   resources = [
    #     "arn:aws:kms:region:account-id:key/key-id"  
    #   ]
    #   conditions = [
    #     {
    #       test     = "StringEquals"
    #       variable = "kms:ViaService"
    #       values   = ["s3.${local.region}.amazonaws.com"]
    #     },
    #     {
    #       test     = "StringLike"
    #       variable = "kms:EncryptionContext:aws:s3:arn"
    #       values   = ["${module.execution_history_kinesis_stream.stream_arn}/*"]
    #     }
    #   ]
    # },
  }
}

# ##########################
# # lftn_fact_service_cost #
# ##########################

module "lftn_fact_service_cost" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=84dfbfddf9483bc56afa0aff516177c03652f0c7"

  function_name          = "${local.resource_prefix}-lmb-fact-service-cost"
  handler                = "index.lambda_handler"
  runtime                = "python3.11"
  publish                = true
  create_role            = false
  lambda_role            = var.iam_lftn_fact_service_cost_role_arn
  source_path            = "${path.module}/code/lambda/fact_service_cost/"
  environment_variables  = {
    BUCKET_NAME   = var.analytics_bucket_name
  }
  memory_size = 1000
  timeout     = 120
  layers      = ["arn:aws:lambda:us-east-1:336392948345:layer:AWSSDKPandas-Python311:22"]
}
##################
# SSM Parameters #
##################
locals {
  ssm_parameters = {
    "/${local.param_prefix}/DDB/PipelineExecutionHistory/TableName" = {
      description = "Pipeline Execution History DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_pipeline_execution_history_table.dynamodb_table_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/DDB/PipelineExecutionHistory/TableArn" = {
      description = "Pipeline Execution History DynamoDB Table Arn"
      type        = "String"
      value       = module.ddb_pipeline_execution_history_table.dynamodb_table_arn
      tier        = "Standard"
    },
    # TODO: JFAR - Temporary ssm parameters, we need to remove this once new ssm parameters standard are fully integrated on sof-base, sof-data
    "/${var.platform_code}/Config/DDB/PipelineExecutionHistory/TTL" = {
      description = "Pipeline Registry DynamoDB Table Name"
      type        = "String"
      value       = "800"
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/DDB/PipelineExecutionHistory/TableName" = {
      description = "Pipeline Execution History DynamoDB Table Name"
      type        = "String"
      value       = module.ddb_pipeline_execution_history_table.dynamodb_table_id
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/DDB/PipelineExecutionHistory/TableArn" = {
      description = "Pipeline Execution History DynamoDB Table Arn"
      type        = "String"
      value       = module.ddb_pipeline_execution_history_table.dynamodb_table_arn
      tier        = "Standard"
    }
  }
}

module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}