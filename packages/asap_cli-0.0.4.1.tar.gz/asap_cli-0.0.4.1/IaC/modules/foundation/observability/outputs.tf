output "ddb_pipeline_execution_history_table_name" {
  value = module.ddb_pipeline_execution_history_table.dynamodb_table_id
}

output "ddb_pipeline_execution_history_table_arn" {
  value = module.ddb_pipeline_execution_history_table.dynamodb_table_arn
}

# output "kinesis_appmanangement_stream_arn" {
#   value = module.appmanangement_kinesis_stream.stream_arn
# }