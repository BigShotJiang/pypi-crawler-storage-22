variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}
variable "deletion_protection_enabled" {
  description = "Enable deletion protection for the Dynamodb table"
  type        = bool
  default     = true
}
variable "raw_bucket_name" {
  description = "S3 bucket Name for raw data"
  type        = string
}
variable "analytics_bucket_name" {
  description = "S3 bucket Name for analytics data"
  type       = string
}
variable "stage_bucket_name" {
  description = "S3 bucket Name for stage data"
  type       = string
}

variable "iam_lftn_fact_service_cost_role_arn" {
  description = "iam_lftn_fact_service_cost_role_arn"
  type = string
}

variable "execution_history_pitr_period_in_days" {
  description = "Point in time recovery period in days for execution history table. Set to null to disable."
  type        = number
  default     = null

  validation {
    condition     = var.execution_history_pitr_period_in_days == null || (var.execution_history_pitr_period_in_days >= 1 && var.execution_history_pitr_period_in_days <= 35)
    error_message = "The 'execution_history_pitr_period_in_days' must be between 1 and 35, or null to disable."
  }  
}

variable "force_destroy" {
  description = "Whether to force destroy the S3 buckets and its contents"
  type        = bool
  default     = false
}

variable "sqs_kms_master_key_id" {
  description = "KMS Key ID for SQS"
  type        = string
}

variable "ddb_kms_key" {
  description = "KMS Key for DynamoDB"
  type        = string
}

variable "kinesis_kms_key" {
  description = "KMS Key id for Kinesis"
  type        = string
}

variable "enable_cmk_appmanagement" {
  description = "Enable CMK for App Management resources"
  type        = bool
  default     = false
}