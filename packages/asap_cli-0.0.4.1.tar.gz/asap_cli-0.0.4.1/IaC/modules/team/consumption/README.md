# Consumption construct

Enables access to data products of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "team_consumption" {
  source   = "./modules/team/consumption"
  for_each = var.teams

  platform_code     = "asap"
  organization_code = "<your_organization>"
  environment_code  = "<environment>"
  team_code         = each.value.team_code

  athena_results_bucket_name        = "<your_s3_bucket>"
  athena_pyspark_workgroup_role_arn = "arn:aws:iam::<account-id>:role/<role-name>"

  force_destroy = true # Force destroy buckets if deletion protection is not enabled
}
```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_athena_workgroup.athena_sql_workgroup](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/athena_workgroup) | resource |
| [aws_athena_workgroup.pyspark_workgroup](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/athena_workgroup) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_athena_pyspark_workgroup_role_arn"></a> [athena\_pyspark\_workgroup\_role\_arn](#input\_athena\_pyspark\_workgroup\_role\_arn) | ARN of the IAM role used for Athena PySpark workgroup | `string` | n/a | yes |
| <a name="input_athena_results_bucket_name"></a> [athena\_results\_bucket\_name](#input\_athena\_results\_bucket\_name) | Name of the S3 bucket for Athena results | `string` | n/a | yes |
| <a name="input_bytes_scanned_cutoff_per_query"></a> [bytes\_scanned\_cutoff\_per\_query](#input\_bytes\_scanned\_cutoff\_per\_query) | Maximum bytes scanned per query in Athena workgroup | `number` | `null` | no |
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_force_destroy"></a> [force\_destroy](#input\_force\_destroy) | Whether to force destroy resources | `bool` | `false` | no |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_team_admin"></a> [team\_admin](#input\_team\_admin) | Whether the team is admin or not | `bool` | `false` | no |
| <a name="input_team_code"></a> [team\_code](#input\_team\_code) | code for the team | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_athena_pyspark_workgroup_arn"></a> [aws\_athena\_pyspark\_workgroup\_arn](#output\_aws\_athena\_pyspark\_workgroup\_arn) | ARN of the Athena pyspark workgroup |
| <a name="output_aws_athena_sql_workgroup_arn"></a> [aws\_athena\_sql\_workgroup\_arn](#output\_aws\_athena\_sql\_workgroup\_arn) | ARN of the Athena sql workgroup |
<!-- END_TF_DOCS -->