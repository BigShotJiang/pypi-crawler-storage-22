
########################
# Lakeformation module #
########################
# Applies data access controls using Lake Formation and data catalog of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "tcns" # Team Lakeformation
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}-${var.team_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}/${var.team_code}"
}


# Athena sql workgroup
resource "aws_athena_workgroup" "athena_sql_workgroup" {
  name = "${local.resource_prefix}-athena-sql-workgroup"
  description = "Workgroup for SQL queries in ${local.resource_prefix}"

  configuration {
    enforce_workgroup_configuration    = true
    publish_cloudwatch_metrics_enabled = true
    bytes_scanned_cutoff_per_query     = var.bytes_scanned_cutoff_per_query

    engine_version {
      selected_engine_version = "AUTO"
    }

    result_configuration {
      output_location = "s3://${var.athena_results_bucket_name}/${var.team_code}/athena-results/"

      # encryption_configuration {
      #   encryption_option = "SSE_KMS"
      #   kms_key_arn       = aws_kms_key.example.arn
      # }
    }
  }
  force_destroy = var.force_destroy
}

# Athena pyspark workgroup
resource "aws_athena_workgroup" "pyspark_workgroup" {
  name = "${local.resource_prefix}-athena-pyspark-workgroup"
  description = "Workgroup for PySpark jobs in ${local.resource_prefix}"

  configuration {
    enforce_workgroup_configuration    = true
    publish_cloudwatch_metrics_enabled = true
    bytes_scanned_cutoff_per_query = var.bytes_scanned_cutoff_per_query

    engine_version {
      selected_engine_version = "PySpark engine version 3"
    }

    execution_role = var.athena_pyspark_workgroup_role_arn

    result_configuration {
      output_location = "s3://${var.athena_results_bucket_name}/${var.team_code}/athena-results/"

      # encryption_configuration {
      #   encryption_option = "SSE_KMS"
      #   kms_key_arn       = aws_kms_key.example.arn
      # }
    }
  }
  force_destroy = var.force_destroy
}
##################
# SSM Parameters #
##################
locals {
  ssm_parameters = {}
}

module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}