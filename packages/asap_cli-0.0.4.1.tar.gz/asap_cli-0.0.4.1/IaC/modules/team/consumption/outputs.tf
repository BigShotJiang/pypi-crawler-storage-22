output "aws_athena_sql_workgroup_arn" {
  description = "ARN of the Athena sql workgroup"
  value       = aws_athena_workgroup.athena_sql_workgroup.arn
}
output "aws_athena_pyspark_workgroup_arn" {
  description = "ARN of the Athena pyspark workgroup"
  value       = aws_athena_workgroup.pyspark_workgroup.arn
}