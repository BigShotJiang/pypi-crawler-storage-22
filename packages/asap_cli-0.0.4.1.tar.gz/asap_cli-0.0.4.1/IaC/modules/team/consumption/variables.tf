variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "team_code" {
  description = "code for the team"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.team_code)) &&
      length(var.team_code) >= 1 &&
      length(var.team_code) <= 4
    )
    error_message = "The 'team_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "team_admin" {
  description = "Whether the team is admin or not"
  type        = bool
  default     = false
}

variable "athena_results_bucket_name" {
  description = "Name of the S3 bucket for Athena results"
  type        = string
}

variable "bytes_scanned_cutoff_per_query" {
  description = "Maximum bytes scanned per query in Athena workgroup"
  type        = number
  default     = null # 1 GB
}

variable "force_destroy" {
  description = "Whether to force destroy resources"
  type        = bool
  default     = false
}
variable "athena_pyspark_workgroup_role_arn" {
  description = "ARN of the IAM role used for Athena PySpark workgroup"
  type        = string  
}
# variable "tag_key" {
#   description = "Name for the Lake Formation team tags"
#   type        = string
# }
# variable "tag_values" {
#   description = "Values for the Lake Formation team tags"
#   type        = list(string)  
#}