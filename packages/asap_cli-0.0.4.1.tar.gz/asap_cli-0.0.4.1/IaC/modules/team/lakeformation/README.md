# Observability construct

This module creates the resources for the observability components of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "observability" {
  source = "./modules/appmanagement"
}
```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_iam_athena_pyspark_workgroup_role"></a> [iam\_athena\_pyspark\_workgroup\_role](#module\_iam\_athena\_pyspark\_workgroup\_role) | git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role | 304c8b5bbe99a1b17e1d24c96a4a384f108caced |
| <a name="module_iam_glue_data_processor_default_job"></a> [iam\_glue\_data\_processor\_default\_job](#module\_iam\_glue\_data\_processor\_default\_job) | git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role | 304c8b5bbe99a1b17e1d24c96a4a384f108caced |
| <a name="module_iam_lftn_fact_service_cost_role"></a> [iam\_lftn\_fact\_service\_cost\_role](#module\_iam\_lftn\_fact\_service\_cost\_role) | git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role | 304c8b5bbe99a1b17e1d24c96a4a384f108caced |
| <a name="module_iam_lftn_task_orchestrator"></a> [iam\_lftn\_task\_orchestrator](#module\_iam\_lftn\_task\_orchestrator) | git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role | 304c8b5bbe99a1b17e1d24c96a4a384f108caced |
| <a name="module_iam_sfn_task_executor"></a> [iam\_sfn\_task\_executor](#module\_iam\_sfn\_task\_executor) | git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role | 304c8b5bbe99a1b17e1d24c96a4a384f108caced |
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_glue_catalog_database.team_database_analytics](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/glue_catalog_database) | resource |
| [aws_glue_catalog_database.team_database_raw](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/glue_catalog_database) | resource |
| [aws_glue_catalog_database.team_database_stg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/glue_catalog_database) | resource |
| [aws_lakeformation_permissions.athena_pyspark_workgroup_default_db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.athena_pyspark_workgroup_default_db_tables](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.athena_pyspark_workgroup_team_lf_tag](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.athena_pyspark_workgroup_team_lf_tag_db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.athena_pyspark_workgroup_team_lf_tag_table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.glue_data_processor_default_db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.glue_data_processor_default_db_tables](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.glue_data_processor_team_lf_tag](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.glue_data_processor_team_lf_tag_db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.glue_data_processor_team_lf_tag_table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.lftn_data_processor_default_db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.lftn_data_processor_default_db_tables](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.lftn_data_processor_team_lf_tag](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.lftn_data_processor_team_lf_tag_db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_permissions.lftn_data_processor_team_lf_tag_table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_permissions) | resource |
| [aws_lakeformation_resource_lf_tags.permission_analytics](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_resource_lf_tags) | resource |
| [aws_lakeformation_resource_lf_tags.permission_raw](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_resource_lf_tags) | resource |
| [aws_lakeformation_resource_lf_tags.permission_stg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lakeformation_resource_lf_tags) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_analytics_bucket_arn"></a> [analytics\_bucket\_arn](#input\_analytics\_bucket\_arn) | ARN of the analytics S3 bucket | `string` | n/a | yes |
| <a name="input_artifacts_bucket_arn"></a> [artifacts\_bucket\_arn](#input\_artifacts\_bucket\_arn) | ARN of the artifacts S3 bucket | `string` | n/a | yes |
| <a name="input_athena_results_bucket_arn"></a> [athena\_results\_bucket\_arn](#input\_athena\_results\_bucket\_arn) | ARN of the Athena results S3 bucket | `string` | n/a | yes |
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_raw_bucket_arn"></a> [raw\_bucket\_arn](#input\_raw\_bucket\_arn) | ARN of the raw S3 bucket | `string` | n/a | yes |
| <a name="input_redshifttmp_bucket_arn"></a> [redshifttmp\_bucket\_arn](#input\_redshifttmp\_bucket\_arn) | ARN of the artifacts S3 bucket | `string` | n/a | yes |
| <a name="input_stage_bucket_arn"></a> [stage\_bucket\_arn](#input\_stage\_bucket\_arn) | ARN of the stage S3 bucket | `string` | n/a | yes |
| <a name="input_team_admin"></a> [team\_admin](#input\_team\_admin) | Whether the team is admin or not | `bool` | `false` | no |
| <a name="input_team_code"></a> [team\_code](#input\_team\_code) | code for the team | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_athena_pyspark_workgroup_role_arn"></a> [athena\_pyspark\_workgroup\_role\_arn](#output\_athena\_pyspark\_workgroup\_role\_arn) | ARN of the IAM role used for Athena pyspark workgroup |
| <a name="output_glue_data_processor_default_job_role_arn"></a> [glue\_data\_processor\_default\_job\_role\_arn](#output\_glue\_data\_processor\_default\_job\_role\_arn) | ARN of the IAM role used for Glue data processor default job |
| <a name="output_iam_lftn_fact_service_cost_role_arn"></a> [iam\_lftn\_fact\_service\_cost\_role\_arn](#output\_iam\_lftn\_fact\_service\_cost\_role\_arn) | ARN of the IAM role used for Admin team lambda fact\_serivce\_cost |
| <a name="output_lftn_task_orchestrator_role_arn"></a> [lftn\_task\_orchestrator\_role\_arn](#output\_lftn\_task\_orchestrator\_role\_arn) | ARN of the IAM role used for Lake Formation task orchestrator |
| <a name="output_sfn_task_executor_role_arn"></a> [sfn\_task\_executor\_role\_arn](#output\_sfn\_task\_executor\_role\_arn) | ARN of the IAM role used for Step Functions task executor |
<!-- END_TF_DOCS -->