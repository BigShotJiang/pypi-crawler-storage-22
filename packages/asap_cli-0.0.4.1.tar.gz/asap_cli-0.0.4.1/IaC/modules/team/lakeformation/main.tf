
########################
# Lakeformation module #
########################
# Applies data access controls using Lake Formation and data catalog of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "tlkf" # Team Lakeformation
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}-${var.team_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}/${var.team_code}"
}


#######################################
# Team scoped Lakeformation resources #
#######################################

##### IAM Roles for Teams #####
# IAM role for team lambda task orchestrator
module "iam_lftn_task_orchestrator" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

  create_role          = true
  role_requires_mfa    = false
  trusted_role_actions = ["sts:AssumeRole"]
  role_name            = "${local.resource_prefix}-lmb-task-orchestrator-role"
  role_description     = "IAM role of the task orchestration lambda function for ${var.team_code} team."
  # role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
  custom_role_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
    "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
    "arn:aws:iam::aws:policy/AWSXRayDaemonWriteAccess"
  ]
  trusted_role_services  = ["lambda.amazonaws.com"]
  allow_self_assume_role = false

  inline_policy_statements = {
    DynamoDBAccess = {
      sid    = "DynamoDBAccess"
      effect = "Allow"
      actions = [
        "dynamodb:DescribeTable",
        "dynamodb:GetItem",
        "dynamodb:GetRecords",
        "dynamodb:GetShardIterator",
        "dynamodb:PutItem",
        "dynamodb:Query",
        "dynamodb:UpdateItem"
      ]
      resources = ["arn:aws:dynamodb:${local.region}:${local.accountid}:table/*"]
    },
    CloudWatchLogsAccess = {
      sid    = "CloudWatchLogsAccess"
      effect = "Allow"
      actions = [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "cloudwatch:PutMetricData"
      ]
      resources = ["*"]
    },
    SSMAccess = {
      sid    = "SSMAccess"
      effect = "Allow"
      actions = [
        "ssm:DescribeParameters",
        "ssm:GetParameter",
        "ssm:GetParameterHistory",
        "ssm:GetParameters"
      ]
      resources = [
        "arn:aws:ssm:${local.region}:${local.accountid}:parameter/${var.platform_code}/*",
        "arn:aws:ssm:${local.region}:${local.accountid}:parameter/SOF/*"
      ]
    },
    SecretsAccess = {
      sid    = "SecretsAccess"
      effect = "Allow"
      actions = [
        "secretsmanager:GetSecretValue"
      ]
      resources = [
        "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/${var.platform_code}/*",
        "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/SOF/*"
      ]
    },
    WorkflowControlTable = {
      sid    = "WorkflowControlTable"
      effect = "Allow"
      actions = [
        "dynamodb:BatchGetItem",
        "dynamodb:BatchWriteItem",
        "dynamodb:ConditionCheckItem",
        "dynamodb:DeleteItem",
        "dynamodb:DescribeTable",
        "dynamodb:GetItem",
        "dynamodb:GetRecords",
        "dynamodb:GetShardIterator",
        "dynamodb:PutItem",
        "dynamodb:Query",
        "dynamodb:Scan",
        "dynamodb:UpdateItem"
      ]
      resources = ["arn:aws:dynamodb:${local.region}:${local.accountid}:table/sof-workflow-control"]
    },
    GlueJobRun = {
      sid = "GlueJobRun"
      actions = [
        "glue:StartJobRun",
        "glue:GetJobRun",
        "glue:BatchStopJobRun"
      ],
      effect    = "Allow",
      resources = ["arn:aws:glue:${local.region}:${local.accountid}:job/*"]
    },
    S3ArtifactsPermissions = {
      sid = "S3ArtifactsAccess"
      actions = [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      effect    = "Allow",
      resources = ["${var.artifacts_bucket_arn}/*","${var.artifacts_bucket_arn}"]
    },
    S3DataPermissions = {
      sid    = "S3Permissions"
      effect = "Allow"
      actions = [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket",
        "s3:ListAllMyBuckets"
      ]
      resources = [
        "${var.analytics_bucket_arn}/*",
        "${var.raw_bucket_arn}/*",
        "${var.stage_bucket_arn}/*",
        "${var.analytics_bucket_arn}",
        "${var.raw_bucket_arn}",
        "${var.stage_bucket_arn}"
      ]
    },
    KMSAccess = {
      sid    = "KMSAccess"
      effect = "Allow"
      actions = [
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:Encrypt",
        "kms:DescribeKey",
        "kms:Decrypt",
        "kms:CreateGrant"
      ]
      resources = ["arn:aws:kms:${local.region}:${local.accountid}:key/*"]
    },
    # NEW: EventBridge permissions for receiving events
    EventBridgeAccess = {
      sid    = "EventBridgeAccess"
      effect = "Allow"
      actions = [
        "events:PutEvents",
        "events:DescribeRule",
        "events:ListTargetsByRule"
      ]
      resources = [
        "arn:aws:events:${local.region}:${local.accountid}:event-bus/default",
        "arn:aws:events:${local.region}:${local.accountid}:rule/*"
      ]
    }
    RedshiftDescribeAccess = {
      sid    = "RedshiftDescribeAccess"
      effect = "Allow"
      actions = [
        "redshift-data:DescribeStatement"
      ]
      resources = ["*"]
    },
    RedshiftExecuteAccess = {
      sid    = "RedshiftExecuteAccess"
      effect = "Allow"
      actions = [
        "redshift-data:BatchExecuteStatement",
        "redshift-data:ExecuteStatement"
      ]
      resources = [
        "arn:aws:redshift-serverless:${local.region}:${local.accountid}:workgroup/*",
        "arn:aws:redshift:${local.region}:${local.accountid}:cluster/*"
      ]
    }
  }
}

# IAM role for team sfn task executor
module "iam_sfn_task_executor" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

  create_role          = true
  role_requires_mfa    = false
  trusted_role_actions = ["sts:AssumeRole"]
  role_name            = "${local.resource_prefix}-sfn-task-executor-role"
  role_description     = "IAM role for the task executor step function used by team ${var.team_code}."
  #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
  custom_role_policy_arns = []
  trusted_role_services   = ["states.${local.region}.amazonaws.com"]
  allow_self_assume_role  = false

  inline_policy_statements = {
    AllowLambdaInvoke = {
      sid       = "AllowLambdaInvoke"
      effect    = "Allow"
      actions   = ["lambda:InvokeFunction"]
      resources = ["arn:aws:lambda:${local.region}:${local.accountid}:function:*"]
    },
    AllowStepFunctionsExecution = {
      sid       = "AllowStepFunctionsExecution"
      effect    = "Allow"
      actions   = ["states:StartExecution"]
      resources = ["arn:aws:states:${local.region}:${local.accountid}:stateMachine:*"]
    },
    AllowEventBridgeHandling = {
      sid       = "AllowEventBridgeHandling"
      effect    = "Allow"
      actions   = ["events:PutRule", "events:PutTargets"]
      resources = ["arn:aws:events:${local.region}:${local.accountid}:rule/*"]
    }
  }
}

# IAM roles for team Glue data processor default job
module "iam_glue_data_processor_default_job" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

  create_role          = true
  role_requires_mfa    = false
  trusted_role_actions = ["sts:AssumeRole"]
  role_name            = "${local.resource_prefix}-glu-data-processor-default-job-role"
  role_description     = "IAM role for data processor default glue job used by team ${var.team_code}."
  #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
  custom_role_policy_arns = []
  trusted_role_services   = ["glue.amazonaws.com"]
  allow_self_assume_role  = false

  inline_policy_statements = {
    AllowGlueAccess = {
      sid    = "AllowGlueAccess"
      effect = "Allow"
      actions = [
        "glue:UpdateTable",
        "glue:UpdateJob",
        "glue:UpdateConnection",
        "glue:StartJobRun",
        "glue:ListJobs",
        "glue:GetTables",
        "glue:GetTable",
        "glue:GetJobRuns",
        "glue:GetJobRun",
        "glue:GetJob",
        "glue:GetDatabases",
        "glue:GetDatabase",
        "glue:GetConnection",
        "glue:BatchDeletePartition",
        "glue:BatchCreatePartition",
        "glue:GetPartitions",
        "glue:GetStatement"
      ]
      resources = [
        "arn:aws:glue:${local.region}:${local.accountid}:catalog",
        "arn:aws:glue:${local.region}:${local.accountid}:database/*",
        "arn:aws:glue:${local.region}:${local.accountid}:table/*"
      ]
    },
    VPCGlue = {
      sid    = "VPCGlue"
      effect = "Allow"
      actions = [
        "glue:GetConnection",
        "ec2:*"
      ]
      resources = ["*"]
    },
    CloudWatchLogsPermissions = {
      sid       = "CloudWatchLogsPermissions"
      effect    = "Allow"
      actions   = ["logs:*", "cloudwatch:PutMetricData"]
      resources = ["*"]
    },
    S3Permissions = {
      sid    = "S3Permissions"
      effect = "Allow"
      actions = [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket",
        "s3:ListAllMyBuckets"
      ]
      resources = ["${var.artifacts_bucket_arn}/*",
        "${var.analytics_bucket_arn}/*",
        "${var.raw_bucket_arn}/*",
        "${var.stage_bucket_arn}/*",
        "${var.redshifttmp_bucket_arn}/*",
        "${var.artifacts_bucket_arn}",
        "${var.analytics_bucket_arn}",
        "${var.raw_bucket_arn}",
        "${var.stage_bucket_arn}",
        "${var.redshifttmp_bucket_arn}"
      ]
    },
    S3DeleteObjects = {
      sid    = "S3DeleteObjects"
      effect = "Allow"
      actions = [
        "s3:DeleteObject"
      ]
      resources = ["${var.analytics_bucket_arn}/*",
        "${var.raw_bucket_arn}/*",
        "${var.stage_bucket_arn}/*"
      ]
    },
    KMSAccess = {
      sid    = "KMSAccess"
      effect = "Allow"
      actions = [
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:Encrypt",
        "kms:DescribeKey",
        "kms:Decrypt",
        "kms:CreateGrant"
      ]
      resources = ["arn:aws:kms:${local.region}:${local.accountid}:key/*"]
    },
    SSMAccess = {
      sid     = "SSMAccess"
      effect  = "Allow"
      actions = ["ssm:GetParameter"]
      resources = [
        "arn:aws:ssm:${local.region}:${local.accountid}:parameter/${var.platform_code}/*",
        "arn:aws:ssm:${local.region}:${local.accountid}:parameter/SOF/*"
      ]
    },
    SecretsAccess = {
      sid    = "SecretsAccess"
      effect = "Allow"
      actions = [
        "secretsmanager:GetSecretValue"
      ]
      resources = [
        "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/${var.platform_code}/*",
        "arn:aws:secretsmanager:${local.region}:${local.accountid}:secret:/SOF/*"
      ]
    },
    RedshiftServerlessCredentialsAccess = {
      sid    = "RedshiftServerlessCredentialsAccess"
      effect = "Allow"
      actions = [
        "redshift-serverless:GetCredentials"
      ]
      resources = [
        "arn:aws:redshift-serverless:${local.region}:${local.accountid}:workgroup/*"
      ]
    },
    RedshiftCredentialsAccess = {
      sid    = "RedshiftCredentialsAccess"
      effect = "Allow"
      actions = [
        "redshift:GetClusterCredentials"
      ]
      resources = [
        "arn:aws:redshift:${local.region}:${local.accountid}:cluster/*"
      ]
    },
    GlueTagNotebookResource = {
      sid    = "GlueTagNotebookResourceAccess"
      effect = "Allow"
      actions = [
        "glue:TagResource"
      ]
      resources = [
        "arn:aws:glue:${local.region}:${local.accountid}:session/*"
      ]
    },
    GlueLetUseRolInNotebooks = {
      sid    = "GlueLetUseRolInNotebooks"
      effect = "Allow"
      actions = [
        "iam:PassRole"
      ]
      resources = [
        "arn:aws:iam::${local.accountid}:role/${local.resource_prefix}-glu-data-processor-default-job-role"
      ]
    }
  }
}
# IAM roles for team Athena PySpark workgroup
module "iam_athena_pyspark_workgroup_role" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

  create_role          = true
  role_requires_mfa    = false
  trusted_role_actions = ["sts:AssumeRole"]
  role_name            = "${local.resource_prefix}-athena-pyspark-workgroup-role"
  role_description     = "IAM role for athena pyspark workgroup used by team ${var.team_code}."
  #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
  custom_role_policy_arns = []
  trusted_role_services   = ["athena.amazonaws.com"]
  allow_self_assume_role  = false

  inline_policy_statements = {
    AllowWorkgroupAccess = {
      sid    = "AllowWorkgroupAccess"
      effect = "Allow"
      actions = [
        "athena:GetWorkGroup",
        "athena:TerminateSession",
        "athena:GetSession",
        "athena:GetSessionStatus",
        "athena:ListSessions",
        "athena:StartCalculationExecution",
        "athena:GetCalculationExecutionCode",
        "athena:StopCalculationExecution",
        "athena:ListCalculationExecutions",
        "athena:GetCalculationExecution",
        "athena:GetCalculationExecutionStatus",
        "athena:ListExecutors",
        "athena:ExportNotebook",
        "athena:UpdateNotebook"
      ],
      resources = [
        "arn:aws:athena:${local.region}:${local.accountid}:workgroup/${var.platform_code}-${var.organization_code}-${var.environment_code}*"
      ]
    },
    AllowGlueAccess = {
      sid    = "AllowGlueAccess"
      effect = "Allow"
      actions = [
        "glue:GetTables",
        "glue:GetTable",
        "glue:GetDatabases",
        "glue:GetDatabase"
      ]
      resources = [
        "arn:aws:glue:${local.region}:${local.accountid}:catalog",
        "arn:aws:glue:${local.region}:${local.accountid}:database/${aws_glue_catalog_database.team_database_raw.name}",
        "arn:aws:glue:${local.region}:${local.accountid}:table/${aws_glue_catalog_database.team_database_raw.name}/*",
        "arn:aws:glue:${local.region}:${local.accountid}:database/${aws_glue_catalog_database.team_database_stg.name}",
        "arn:aws:glue:${local.region}:${local.accountid}:table/${aws_glue_catalog_database.team_database_stg.name}/*",
        "arn:aws:glue:${local.region}:${local.accountid}:database/${aws_glue_catalog_database.team_database_analytics.name}",
        "arn:aws:glue:${local.region}:${local.accountid}:table/${aws_glue_catalog_database.team_database_analytics.name}/*",
      ]
    },
    CloudWatchLogsPermissions = {
      sid       = "CloudWatchLogsPermissions"
      effect    = "Allow"
      actions   = [
        "logs:CreateLogStream",
        "logs:DescribeLogStreams",
        "logs:CreateLogGroup",
        "logs:PutLogEvents",
        "logs:DescribeLogGroups"
      ]
      resources = [
        "arn:aws:logs:${local.region}:${local.accountid}:log-group:/aws-athena:*",
        "arn:aws:logs:${local.region}:${local.accountid}:log-group:/aws-athena*:log-stream:*"
      ]
    },
    CloudWatchMetricsPermissions = {
      sid       = "CloudWatchMetricsPermissions"
      effect    = "Allow"
      actions   = [
        "cloudwatch:PutMetricData"
      ]
      resources = [
        "*"
      ]
      conditions = [
        {
          test     = "StringEquals"
          variable = "cloudwatch:namespace"
          values   = ["AmazonAthenaForApacheSpark"]
        }
      ]
    },
    S3Permissions = {
      sid    = "S3Permissions"
      effect = "Allow"
      actions = [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket",
        "s3:ListAllMyBuckets"
      ]
      resources = ["${var.artifacts_bucket_arn}/*",
        "${var.analytics_bucket_arn}/*",
        "${var.raw_bucket_arn}/*",
        "${var.stage_bucket_arn}/*",
        "${var.redshifttmp_bucket_arn}/*",
        "${var.athena_results_bucket_arn}/*",
        "${var.artifacts_bucket_arn}",
        "${var.analytics_bucket_arn}",
        "${var.raw_bucket_arn}",
        "${var.stage_bucket_arn}",
        "${var.redshifttmp_bucket_arn}",
        "${var.athena_results_bucket_arn}"
      ]
    },
    KMSAccess = {
      sid    = "KMSAccess"
      effect = "Allow"
      actions = [
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:Encrypt",
        "kms:DescribeKey",
        "kms:Decrypt",
        "kms:CreateGrant"
      ]
      resources = ["arn:aws:kms:${local.region}:${local.accountid}:key/*"]
    }
  }
}
# ADMIN ONLY role for cost explorer lambda
module "iam_lftn_fact_service_cost_role" {
  count = var.team_admin ? 1 : 0
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-iam.git//modules/iam-assumable-role?ref=304c8b5bbe99a1b17e1d24c96a4a384f108caced"

  create_role          = true
  role_requires_mfa    = false
  trusted_role_actions = ["sts:AssumeRole"]
  role_name            = "${local.resource_prefix}-lmb-fact-service-cost-role"
  role_description     = "IAM role for lambda fact_service_cost table creation for team daop."
  #  role_permissions_boundary_arn = var.ARN_PERMISSION_BOUNDARY
  custom_role_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
    "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
    "arn:aws:iam::aws:policy/AWSXRayDaemonWriteAccess"
  ]
  trusted_role_services   = ["lambda.amazonaws.com"]
  allow_self_assume_role  = false

  inline_policy_statements = {
    CloudWatchLogsAccess = {
      sid    = "CloudWatchLogsAccess"
      effect = "Allow"
      actions = [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "cloudwatch:PutMetricData"
      ]
      resources = ["*"]
    },
    AllowGlueAccess = {
      sid    = "AllowGlueAccess"
      effect = "Allow"
      actions = [
        "glue:UpdateTable",
        "glue:GetTables",
        "glue:GetTable",
        "glue:GetDatabases",
        "glue:GetDatabase",
        "glue:BatchDeletePartition",
        "glue:BatchCreatePartition",
        "glue:GetPartitions"
      ]
      resources = [
        "arn:aws:glue:${local.region}:${local.accountid}:catalog",
        "arn:aws:glue:${local.region}:${local.accountid}:database/*",
        "arn:aws:glue:${local.region}:${local.accountid}:table/*"
      ]
    },
    S3Permissions = {
      sid    = "S3Permissions"
      effect = "Allow"
      actions = [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket",
        "s3:ListAllMyBuckets"
      ]
      resources = [
        "${var.analytics_bucket_arn}/*",
        "${var.raw_bucket_arn}/*",
        "${var.stage_bucket_arn}/*",
        "${var.analytics_bucket_arn}",
        "${var.raw_bucket_arn}",
        "${var.stage_bucket_arn}"
      ]
    },
    S3DeleteObjects = {
      sid    = "S3DeleteObjects"
      effect = "Allow"
      actions = [
        "s3:DeleteObject"
      ]
      resources = [
        "${var.analytics_bucket_arn}/*",
        "${var.raw_bucket_arn}/*",
        "${var.stage_bucket_arn}/*"
      ]
    },
    SSMAccess = {
      sid    = "SSMAccess"
      effect = "Allow"
      actions = [
        "ssm:DescribeParameters",
        "ssm:GetParameter",
        "ssm:GetParameterHistory",
        "ssm:GetParameters"
      ]
      resources = [
        "arn:aws:ssm:${local.region}:${local.accountid}:parameter/${var.platform_code}/*",
        "arn:aws:ssm:${local.region}:${local.accountid}:parameter/SOF/*"
      ]
    }
    CEAccess = {
      sid    = "CEAccess"
      effect = "Allow"
      actions = [
        "ce:GetCostAndUsage"
      ]
      resources = [
        "arn:aws:ce:${local.region}:${local.accountid}:/GetCostAndUsage"
      ]
    }
    # KMSAccess = {
    #   sid    = "KMSAccess"
    #   effect = "Allow"
    #   actions = [
    #     "kms:ReEncrypt*",
    #     "kms:GenerateDataKey*",
    #     "kms:Encrypt",
    #     "kms:DescribeKey",
    #     "kms:Decrypt",
    #     "kms:CreateGrant"
    #   ]
    #   resources = ["arn:aws:kms:${local.region}:${local.accountid}:key/*"]
    # }    
  }
}
##### Lakeformation permissions for Teams #####
# Permissions for the Glue Data Processor role
resource "aws_lakeformation_permissions" "glue_data_processor_default_db" {
  principal   = module.iam_glue_data_processor_default_job.iam_role_arn
  permissions = ["DESCRIBE"]

  database {
    name = "default"
  }
}

resource "aws_lakeformation_permissions" "glue_data_processor_default_db_tables" {
  principal   = module.iam_glue_data_processor_default_job.iam_role_arn
  permissions = ["SELECT", "DESCRIBE", "ALTER", "DROP", "INSERT", "DELETE"]

  table {
    database_name = "default"
    wildcard      = true
  }
}

resource "aws_lakeformation_permissions" "glue_data_processor_team_lf_tag" {
  principal   = module.iam_glue_data_processor_default_job.iam_role_arn
  permissions = ["DESCRIBE"]

  lf_tag {
    key    = "Team"
    values = [var.team_code]
  }
}

resource "aws_lakeformation_permissions" "glue_data_processor_team_lf_tag_table" {

  principal   = module.iam_glue_data_processor_default_job.iam_role_arn
  permissions = ["SELECT", "INSERT", "DELETE", "ALTER", "DESCRIBE"]

  lf_tag_policy {
    resource_type = "TABLE"

    expression {
      key    = "Team"
      values = [var.team_code]
    }
  }
  # Wait for the LF tag permissions to be granted first
  depends_on = [
    aws_lakeformation_permissions.glue_data_processor_team_lf_tag
  ]
}

resource "aws_lakeformation_permissions" "glue_data_processor_team_lf_tag_db" {

  principal   = module.iam_glue_data_processor_default_job.iam_role_arn
  permissions = ["DESCRIBE"]

  lf_tag_policy {
    resource_type = "DATABASE"

    expression {
      key    = "Team"
      values = [var.team_code]
    }
  }
  depends_on = [
    aws_lakeformation_permissions.glue_data_processor_team_lf_tag
  ]
}
# Permissions for Pyspark Athena workgroup role
resource "aws_lakeformation_permissions" "athena_pyspark_workgroup_default_db" {
  principal   = module.iam_athena_pyspark_workgroup_role.iam_role_arn
  permissions = ["DESCRIBE"]

  database {
    name = "default"
  }
}

resource "aws_lakeformation_permissions" "athena_pyspark_workgroup_default_db_tables" {
  principal   = module.iam_athena_pyspark_workgroup_role.iam_role_arn
  permissions = ["SELECT", "DESCRIBE", "ALTER", "DROP", "INSERT", "DELETE"]

  table {
    database_name = "default"
    wildcard      = true
  }
}

resource "aws_lakeformation_permissions" "athena_pyspark_workgroup_team_lf_tag" {
  principal   = module.iam_athena_pyspark_workgroup_role.iam_role_arn
  permissions = ["DESCRIBE"]

  lf_tag {
    key    = "Team"
    values = [var.team_code]
  }
}

resource "aws_lakeformation_permissions" "athena_pyspark_workgroup_team_lf_tag_table" {

  principal   = module.iam_athena_pyspark_workgroup_role.iam_role_arn
  permissions = ["SELECT", "INSERT", "DELETE", "ALTER", "DESCRIBE"]

  lf_tag_policy {
    resource_type = "TABLE"

    expression {
      key    = "Team"
      values = [var.team_code]
    }
  }
  # Wait for the LF tag permissions to be granted first
  depends_on = [
    aws_lakeformation_permissions.athena_pyspark_workgroup_team_lf_tag
  ]
}

resource "aws_lakeformation_permissions" "athena_pyspark_workgroup_team_lf_tag_db" {

  principal   = module.iam_athena_pyspark_workgroup_role.iam_role_arn
  permissions = ["DESCRIBE"]

  lf_tag_policy {
    resource_type = "DATABASE"

    expression {
      key    = "Team"
      values = [var.team_code]
    }
  }
  depends_on = [
    aws_lakeformation_permissions.athena_pyspark_workgroup_team_lf_tag
  ]
}
# Permissions for Admin Lambda Role
resource "aws_lakeformation_permissions" "lftn_data_processor_default_db" {
  count = var.team_admin ? 1 : 0
  principal   = module.iam_lftn_fact_service_cost_role[0].iam_role_arn
  permissions = ["DESCRIBE"]

  database {
    name = "default"
  }
}

resource "aws_lakeformation_permissions" "lftn_data_processor_default_db_tables" {
  count = var.team_admin ? 1 : 0
  principal   = module.iam_lftn_fact_service_cost_role[0].iam_role_arn
  permissions = ["SELECT", "DESCRIBE", "ALTER", "DROP", "INSERT", "DELETE"]

  table {
    database_name = "default"
    wildcard      = true
  }
}

resource "aws_lakeformation_permissions" "lftn_data_processor_team_lf_tag" {
  count = var.team_admin ? 1 : 0
  principal   = module.iam_lftn_fact_service_cost_role[0].iam_role_arn
  permissions = ["DESCRIBE"]

  lf_tag {
    key    = "Team"
    values = [var.team_code]
  }
}

resource "aws_lakeformation_permissions" "lftn_data_processor_team_lf_tag_table" {
  count = var.team_admin ? 1 : 0
  principal   = module.iam_lftn_fact_service_cost_role[0].iam_role_arn
  permissions = ["SELECT", "INSERT", "DELETE", "ALTER", "DESCRIBE"]

  lf_tag_policy {
    resource_type = "TABLE"

    expression {
      key    = "Team"
      values = [var.team_code]
    }
  }
  # Wait for the LF tag permissions to be granted first
  depends_on = [
    aws_lakeformation_permissions.lftn_data_processor_team_lf_tag
  ]
}

resource "aws_lakeformation_permissions" "lftn_data_processor_team_lf_tag_db" {
  count = var.team_admin ? 1 : 0

  principal   = module.iam_lftn_fact_service_cost_role[0].iam_role_arn
  permissions = ["DESCRIBE"]

  lf_tag_policy {
    resource_type = "DATABASE"

    expression {
      key    = "Team"
      values = [var.team_code]
    }
  }
  depends_on = [
    aws_lakeformation_permissions.lftn_data_processor_team_lf_tag
  ]
}
#### DATABASE CREATION AND TAG ASSOCIATION #####

## 1 DATABASE CREATION
resource "aws_glue_catalog_database" "team_database_raw" {
  name        = "dl_raw_${var.team_code}"
  description = "This is the raw database for team ${var.team_code}"
}

resource "aws_glue_catalog_database" "team_database_stg" {
  name        = "dl_stage_${var.team_code}"
  description = "This is the stg database for team ${var.team_code}"
}

resource "aws_glue_catalog_database" "team_database_analytics" {
  name        = "dl_analytics_${var.team_code}"
  description = "This is the analytics database for team ${var.team_code}"
}


## ASSIGN LAKEFORMATION TAGS TO DATABASES
resource "aws_lakeformation_resource_lf_tags" "permission_raw" {
  database {
    name = aws_glue_catalog_database.team_database_raw.name
  }

  lf_tag {
    key   = "Team"
    value = var.team_code
  }
}

resource "aws_lakeformation_resource_lf_tags" "permission_stg" {
  database {
    name = aws_glue_catalog_database.team_database_stg.name
  }

  lf_tag {
    key   = "Team"
    value = var.team_code
  }
}

resource "aws_lakeformation_resource_lf_tags" "permission_analytics" {
  database {
    name = aws_glue_catalog_database.team_database_analytics.name
  }

  lf_tag {
    key   = "Team"
    value = var.team_code
  }
}
##################
# SSM Parameters #
##################
locals {
  ssm_parameters = {
    "/${local.param_prefix}/IAM/lftn_task_orchestrator/RoleArn" = {
      description = "Team ${var.team_code} Task Orchestrator Lambda Function IAM Role Arn"
      type        = "String"
      value       = module.iam_lftn_task_orchestrator.iam_role_arn
      tier        = "Standard"
    }
    "/${local.param_prefix}/IAM/sfn_task_executor/RoleArn" = {
      description = "Team ${var.team_code} Task Executor Step Function IAM Role Arn"
      type        = "String"
      value       = module.iam_sfn_task_executor.iam_role_arn
      tier        = "Standard"
    }
    "/${local.param_prefix}/IAM/glue_data_processor_default_job/RoleArn" = {
      description = "Team ${var.team_code} Glue Data Processor Default Job IAM Role Arn"
      type        = "String"
      value       = module.iam_glue_data_processor_default_job.iam_role_arn
      tier        = "Standard"
    }
    "/${local.param_prefix}/IAM/athena_pyspark_workgroup/RoleArn" = {
      description = "Team ${var.team_code} Athena Pyspark workgroup IAM Role Arn"
      type        = "String"
      value       = module.iam_athena_pyspark_workgroup_role.iam_role_arn
      tier        = "Standard"
    }
    "/${local.param_prefix}/GLUE/Database/Raw" = {
      description = "Team ${var.team_code} Glue Raw Database Name"
      type        = "String"
      value       = aws_glue_catalog_database.team_database_raw.name
      tier        = "Standard"
    }
    "/${local.param_prefix}/GLUE/Database/Stage" = {
      description = "Team ${var.team_code} Glue Stage Database Name"
      type        = "String"
      value       = aws_glue_catalog_database.team_database_stg.name
      tier        = "Standard"
    }
    "/${local.param_prefix}/GLUE/Database/Analytics" = {
      description = "Team ${var.team_code} Glue Analytics Database Name"
      type        = "String"
      value       = aws_glue_catalog_database.team_database_analytics.name
      tier        = "Standard"
    }
  }
}

module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}