output "glue_data_processor_default_job_role_arn" {
  description = "ARN of the IAM role used for Glue data processor default job"
  value       = module.iam_glue_data_processor_default_job.iam_role_arn
}
output "sfn_task_executor_role_arn" {
  description = " ARN of the IAM role used for Step Functions task executor"
  value       = module.iam_sfn_task_executor.iam_role_arn
}
output "lftn_task_orchestrator_role_arn" {
  description = "ARN of the IAM role used for Lake Formation task orchestrator"
  value       = module.iam_lftn_task_orchestrator.iam_role_arn
}
output "iam_lftn_fact_service_cost_role_arn" {
  description = "ARN of the IAM role used for Admin team lambda fact_serivce_cost"
  value       = length(module.iam_lftn_fact_service_cost_role) > 0 ? module.iam_lftn_fact_service_cost_role[0].iam_role_arn : null

}
output "athena_pyspark_workgroup_role_arn" {
  description = "ARN of the IAM role used for Athena pyspark workgroup"
  value       = module.iam_athena_pyspark_workgroup_role.iam_role_arn
}