# Orchestration construct

Coordinates processing steps of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "team_orchestration" {
  source   = "./modules/team/orchestration"
  for_each = var.teams

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code
  team_code         = each.value.team_code

  aws_powertools_arn                    = var.aws_powertools_arn
  iam_lambda_task_orchestrator_role_arn = module.team_lakeformation[each.key].lftn_task_orchestrator_role_arn
  sof_iam_sfn_task_executor_role_arn    = module.team_lakeformation[each.key].sfn_task_executor_role_arn
  s3_artifacts_bucket_name              = module.artifacts.artifacts_bucket_name
  subnet_ids                            = var.subnet_ids
  lambda_runtime                        = var.lambda_runtime
  sg_id                                 = var.sg_ids
  pydantic_arn                          = module.artifacts.pydantic_arn
  sofbase_arn                           = module.artifacts.sofbase_arn
}
```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_lftn_orch_sfn_generator"></a> [lftn\_orch\_sfn\_generator](#module\_lftn\_orch\_sfn\_generator) | git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git | 84dfbfddf9483bc56afa0aff516177c03652f0c7 |
| <a name="module_lftn_orch_task_orchestrator"></a> [lftn\_orch\_task\_orchestrator](#module\_lftn\_orch\_task\_orchestrator) | git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git | 84dfbfddf9483bc56afa0aff516177c03652f0c7 |
| <a name="module_sfn_orch_task_executor"></a> [sfn\_orch\_task\_executor](#module\_sfn\_orch\_task\_executor) | git::https://github.com/terraform-aws-modules/terraform-aws-step-functions.git | 3690011bcde4448cfa9f013cd0714ce9bf39bea4 |
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_powertools_arn"></a> [aws\_powertools\_arn](#input\_aws\_powertools\_arn) | ARN of the AWS Lambda Powertools layer | `string` | n/a | yes |
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_iam_lambda_task_orchestrator_role_arn"></a> [iam\_lambda\_task\_orchestrator\_role\_arn](#input\_iam\_lambda\_task\_orchestrator\_role\_arn) | n/a | `string` | n/a | yes |
| <a name="input_lambda_runtime"></a> [lambda\_runtime](#input\_lambda\_runtime) | Lambda runtime | `string` | n/a | yes |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_pydantic_arn"></a> [pydantic\_arn](#input\_pydantic\_arn) | ARN of the Pydantic layer | `string` | n/a | yes |
| <a name="input_s3_artifacts_bucket_name"></a> [s3\_artifacts\_bucket\_name](#input\_s3\_artifacts\_bucket\_name) | Name of the artifacts S3 bucket | `string` | n/a | yes |
| <a name="input_sg_id"></a> [sg\_id](#input\_sg\_id) | Security group ID for the Lambda function | `list(string)` | n/a | yes |
| <a name="input_sof_iam_sfn_task_executor_role_arn"></a> [sof\_iam\_sfn\_task\_executor\_role\_arn](#input\_sof\_iam\_sfn\_task\_executor\_role\_arn) | n/a | `string` | n/a | yes |
| <a name="input_sofbase_arn"></a> [sofbase\_arn](#input\_sofbase\_arn) | ARN of the SOF base layer | `string` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | List of subnet IDs for the Lambda function | `list(string)` | n/a | yes |
| <a name="input_team_admin"></a> [team\_admin](#input\_team\_admin) | Whether the team is admin or not | `bool` | `false` | no |
| <a name="input_team_code"></a> [team\_code](#input\_team\_code) | code for the team | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_lftn_orch_sfn_generator_arn"></a> [lftn\_orch\_sfn\_generator\_arn](#output\_lftn\_orch\_sfn\_generator\_arn) | n/a |
| <a name="output_lftn_orch_sfn_generator_name"></a> [lftn\_orch\_sfn\_generator\_name](#output\_lftn\_orch\_sfn\_generator\_name) | n/a |
| <a name="output_lftn_orch_task_orchestrator_arn"></a> [lftn\_orch\_task\_orchestrator\_arn](#output\_lftn\_orch\_task\_orchestrator\_arn) | n/a |
| <a name="output_lftn_orch_task_orchestrator_name"></a> [lftn\_orch\_task\_orchestrator\_name](#output\_lftn\_orch\_task\_orchestrator\_name) | n/a |
| <a name="output_sfn_orch_task_executor_arn"></a> [sfn\_orch\_task\_executor\_arn](#output\_sfn\_orch\_task\_executor\_arn) | n/a |
| <a name="output_sfn_orch_task_executor_name"></a> [sfn\_orch\_task\_executor\_name](#output\_sfn\_orch\_task\_executor\_name) | n/a |
<!-- END_TF_DOCS -->