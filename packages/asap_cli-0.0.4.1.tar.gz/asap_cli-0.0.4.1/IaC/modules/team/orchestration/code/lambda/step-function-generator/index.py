import os
from typing import Any

import boto3
from aws_lambda_powertools.utilities.typing import LambdaContext
from sofbase.common.logger import LoggingService
from sofbase.stepfunctions.python_generator.generator import StepFunctionsGenerator

logger = LoggingService().initialize_logger()


def lambda_handler(event: dict[Any, Any], lambda_context: LambdaContext) -> Any:

    s3_client = boto3.client("s3")
    ssm_client = boto3.client("ssm")
    sts_client = boto3.client("sts")

    account_id = sts_client.get_caller_identity()["Account"]
    session = boto3.session.Session()
    region = session.region_name

    parameter = ssm_client.get_parameter(Name="/sof/S3/Artifacts", WithDecryption=True)
    bucket_name = parameter["Parameter"]["Value"]

    os.chdir("/tmp")

    try:
        workflow_file = s3_client.get_object(
            Bucket=bucket_name, Key=f'step_functions/landing/{event["workflow_file"]}'
        )
        with open(f'/tmp/{event["workflow_file"]}', "wb") as f:
            f.write(workflow_file["Body"].read())
    except Exception as e:
        raise e

    generator = StepFunctionsGenerator()
    generator.environment = "dev"
    generator.orchestration_lambda = "sof-base-task-orchestrator"
    generator.workflow_file = f'/tmp/{event["workflow_file"]}'
    generator.output_file = f'/tmp/{event["output_file"]}'
    generator.aws_account_number = account_id
    generator.aws_account_region = region
    generator.generate_step_functions_json()

    try:
        generated_files = os.listdir("/tmp/")
        for file in generated_files:
            if file == event["output_file"]:
                print(f"Uploading {file}")
                s3_client.upload_file(f"/tmp/{file}", bucket_name, f"step_functions/output/{file}")

        copy_source = {
            "Bucket": bucket_name,
            "Key": f'step_functions/landing/{event["workflow_file"]}',
        }
        s3_client.copy_object(
            Bucket=bucket_name, CopySource=copy_source, Key=f"step_functions/processed/{file}"
        )
        s3_client.delete_object(
            Bucket=bucket_name, Key=f'step_functions/landing/{event["workflow_file"]}'
        )
    except Exception as e:
        raise e

    return {"statusCode": 200, "body": "ok"}
