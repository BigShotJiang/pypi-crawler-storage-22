from typing import Any

from aws_lambda_powertools.utilities.typing import LambdaContext
from sofbase.common.logger import LoggingService
from sofbase.services.orchestration_manager import OrchestrationManager

logger = LoggingService().initialize_logger()


def lambda_handler(event: dict[Any, Any], lambda_context: LambdaContext) -> Any:

    om = OrchestrationManager()
    return om.handle_event(event=event, lambda_context=lambda_context)
