########################
# Orchestration Module #
########################
# Coordinates processing steps of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "torc" # Team Orchestration
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}-${var.team_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}/${var.team_code}"
}

module "lftn_orch_task_orchestrator" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=84dfbfddf9483bc56afa0aff516177c03652f0c7"

  function_name          = "${local.resource_prefix}-lmb-task-orchestrator"
  handler                = "index.lambda_handler"
  runtime                = var.lambda_runtime
  publish                = true
  create_role            = false
  lambda_role            = var.iam_lambda_task_orchestrator_role_arn
  source_path            = "${path.module}/code/lambda/task-orchestrator/index.py"
  vpc_subnet_ids         = var.subnet_ids
  vpc_security_group_ids = var.sg_id
  environment_variables = {
    SOF_APP_NAME = var.platform_code
  }
  memory_size = 256
  timeout     = 60
  layers      = [var.pydantic_arn, var.sofbase_arn, var.aws_powertools_arn]
}

module "lftn_orch_sfn_generator" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=84dfbfddf9483bc56afa0aff516177c03652f0c7"

  function_name          = "${local.resource_prefix}-lmb-sfn-generator"
  handler                = "index.lambda_handler"
  runtime                = var.lambda_runtime
  publish                = true
  create_role            = false
  lambda_role            = var.iam_lambda_task_orchestrator_role_arn
  source_path            = "${path.module}/code/lambda/step-function-generator/index.py"
  vpc_subnet_ids         = var.subnet_ids
  vpc_security_group_ids = var.sg_id
  environment_variables = {
    SOF_APP_NAME = var.platform_code
  }
  memory_size = 256
  timeout     = 60
  layers      = [var.pydantic_arn, var.sofbase_arn, var.aws_powertools_arn]
}


####################
# Step Functions
####################

module "sfn_orch_task_executor" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-step-functions.git?ref=3690011bcde4448cfa9f013cd0714ce9bf39bea4"

  name = "${local.resource_prefix}-stp-task-executor"
  definition = templatefile("${path.module}/code/stepfunction/TaskExecutor/TaskExecutor.json", {
    task_orchestrator_fn_name = "${module.lftn_orch_task_orchestrator.lambda_function_name}:$LATEST"
  })
  publish           = true
  create_role       = false
  use_existing_role = true
  role_arn          = var.sof_iam_sfn_task_executor_role_arn
}

##################
# SSM Parameters #
##################
locals {
  ssm_parameters = {
    "/${local.param_prefix}/Lambda/TaskOrchestrator/LambdaName" = {
      description = "Team ${var.team_code} Task Orchestrator Lambda Function Name"
      type        = "String"
      value       = module.lftn_orch_task_orchestrator.lambda_function_name
      tier        = "Standard"
    },
    "/${local.param_prefix}/Lambda/TaskOrchestrator/Arn" = {
      description = "Team ${var.team_code} Task Orchestrator Lambda Function ARN"
      type        = "String"
      value       = module.lftn_orch_task_orchestrator.lambda_function_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/SFN/TaskExecutor/Name" = {
      description = "Team ${var.team_code} Task Executor Step Function Name"
      type        = "String"
      value       = module.sfn_orch_task_executor.state_machine_name
      tier        = "Standard"
    },
    "/${local.param_prefix}/SFN/TaskExecutor/Arn" = {
      description = "Team ${var.team_code} Task Executor Step Function ARN"
      type        = "String"
      value       = module.sfn_orch_task_executor.state_machine_arn
      tier        = "Standard"
    }
    # TODO: JFAR - Temporary ssm parameters, we need to remove this once new ssm parameters standard are fully integrated on sof-base, sof-data
    "/${var.platform_code}/Foundation/${var.team_code}/Lambda/TaskOrchestrator/Arn" = {
      description = "Team ${var.team_code} Task Orchestrator Lambda Arn"
      type        = "String"
      value       = module.lftn_orch_task_orchestrator.lambda_function_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/${var.team_code}/Lambda/TaskOrchestrator/LambdaName" = {
      description = "Team ${var.team_code} Task Orchestrator Lambda Name"
      type        = "String"
      value       = module.lftn_orch_task_orchestrator.lambda_function_name
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/${var.team_code}/SFN/TaskExecutor/Arn" = {
      description = "Team ${var.team_code} Task Executor Step Function Arn"
      type        = "String"
      value       = module.sfn_orch_task_executor.state_machine_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/${var.team_code}/SFN/TaskExecutor/Name" = {
      description = "Team ${var.team_code} Task Executor Step Function Name"
      type        = "String"
      value       = module.sfn_orch_task_executor.state_machine_name
      tier        = "Standard"
    }
  }
}

module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}
