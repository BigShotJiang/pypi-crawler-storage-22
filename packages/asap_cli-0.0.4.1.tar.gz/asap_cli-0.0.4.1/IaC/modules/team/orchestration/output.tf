output "lftn_orch_task_orchestrator_arn" {
  value = module.lftn_orch_task_orchestrator.lambda_function_arn
}
output "lftn_orch_task_orchestrator_name" {
  value = module.lftn_orch_task_orchestrator.lambda_function_name
}

output "lftn_orch_sfn_generator_arn" {
  value = module.lftn_orch_sfn_generator.lambda_function_arn
}

output "lftn_orch_sfn_generator_name" {
  value = module.lftn_orch_sfn_generator.lambda_function_name
}

output "sfn_orch_task_executor_arn" {
  value = module.sfn_orch_task_executor.state_machine_arn
}
output "sfn_orch_task_executor_name" {
  value = module.sfn_orch_task_executor.state_machine_name
}

# output "lambda_sofbase_layer_arn" {
#   value = aws_lambda_layer_version.lambda_sofbase_layer.arn
# }

# output "lambda_pydantic_layer_arn" {
#   value = aws_lambda_layer_version.lambda_pydantic_layer.arn
# }