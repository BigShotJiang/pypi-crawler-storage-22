variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}
variable "team_code" {
  description = "code for the team"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.team_code)) &&
      length(var.team_code) >= 1 &&
      length(var.team_code) <= 4
    )
    error_message = "The 'team_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "team_admin" {
  description = "Whether the team is admin or not"
  type        = bool
  default     = false
}

# variable "lambda_task_orchestrator_name" {
#   description = "Name of the Lambda function for task orchestrator"
#   type        = string
#   default     = "lftn-orch-task-orchestrator"
# }
# variable "lambda_sfn_generator_name" {
#   description = "Name of the Lambda function for step function generator"
#   type        = string
#   default     = "lftn-orch-sfn-generator"
# }
# variable "lambda_pipeline_executor_name" {
#   description = "Name of the Lambda function for pipeline executor"
#   type        = string
#   default     = "lftn-orch-pipeline-executor"
# }
# variable "lambda_layer_sofbase_name" {
#   description = "Name of the Lambda layer for SOF base"
#   type        = string
#   #default     = "lftn-orch-sof-base-layer"
# }
# variable "sof_base_lambda_runtimes" {
#   description = "Runtime for the Lambda function"
#   type        = list(string)
#   #default     = "python3.9"
# }
# variable "lambda_layer_pydantic_name" {
#   description = "Name of the Lambda layer for Pydantic"
#   type        = string
#   #default     = "lftn-orch-pydantic-layer"
# }
# variable "pydantic_lambda_runtimes" {
#   description = "Compatible runtimes for the Pydantic layer"
#   type        = list(string)
#   #default     = ["python3.9"]  
# }
# variable "sfn_task_executor_name" {
#   description = "Name of the Step Function task executor"
#   type        = string
#   #default     = "lftn-orch-task-executor"

# }

variable "lambda_runtime" {
  description = "Lambda runtime"
  type        = string
}

variable "iam_lambda_task_orchestrator_role_arn" {
  type = string
}

variable "sof_iam_sfn_task_executor_role_arn" {
  type = string
}

variable "subnet_ids" {
  description = "List of subnet IDs for the Lambda function"
  type        = list(string)
}

variable "s3_artifacts_bucket_name" {
  description = "Name of the artifacts S3 bucket"
  type        = string

}

variable "sg_id" {
  description = "Security group ID for the Lambda function"
  type        = list(string)

}

variable "pydantic_arn" {
  type        = string
  description = "ARN of the Pydantic layer"

}

variable "sofbase_arn" {
  type        = string
  description = "ARN of the SOF base layer"

}

variable "aws_powertools_arn" {
  type        = string
  description = "ARN of the AWS Lambda Powertools layer"
}