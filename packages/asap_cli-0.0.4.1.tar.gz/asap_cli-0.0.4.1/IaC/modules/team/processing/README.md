# Processing construct

This module creates the resources for the Processing components of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "team_processing" {
  source   = "./modules/team/processing"
  for_each = var.teams

  platform_code     = var.platform_code
  organization_code = var.organization_code
  environment_code  = var.environment_code
  team_code         = each.value.team_code

  iam_glue_job_role_arn = module.team_lakeformation[each.key].glue_data_processor_default_job_role_arn

  s3_artifacts_bucket_name = module.artifacts.artifacts_bucket_name
  subnet_ids               = var.subnet_ids
  glue_kms_key_arn         = var.glue_kms_key_arn
  sg_ids                   = var.sg_ids

  # glue library paths
  glue_sofdata_library_key           = module.artifacts.glue_sofdata_library_key
  glue_sofbase_library_key           = module.artifacts.glue_sofbase_library_key
  glue_jmespath_library_key          = module.artifacts.glue_jmespath_library_key
  glue_typing_extensions_library_key = module.artifacts.glue_typing_extensions_library_key
  glue_powertools_library_key        = module.artifacts.glue_powertools_library_key
}
```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_sof_glue_spark_job"></a> [sof\_glue\_spark\_job](#module\_sof\_glue\_spark\_job) | git::https://github.com/cloudposse/terraform-aws-glue.git//modules/glue-job | e04ac37bd44efcf29ad0a8fc94149bccc9162a6d |
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_glue_connection.sof_glue_connection](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/glue_connection) | resource |
| [aws_glue_security_configuration.glue_security](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/glue_security_configuration) | resource |
| [aws_s3_object.script](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [aws_subnet.glue_subnets](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnet) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_glue_jmespath_library_key"></a> [glue\_jmespath\_library\_key](#input\_glue\_jmespath\_library\_key) | .whl file s3 path for the jmespath layer | `string` | n/a | yes |
| <a name="input_glue_kms_key_arn"></a> [glue\_kms\_key\_arn](#input\_glue\_kms\_key\_arn) | n/a | `string` | n/a | yes |
| <a name="input_glue_powertools_library_key"></a> [glue\_powertools\_library\_key](#input\_glue\_powertools\_library\_key) | .whl file s3 path for the powertools layer | `string` | n/a | yes |
| <a name="input_glue_sofbase_library_key"></a> [glue\_sofbase\_library\_key](#input\_glue\_sofbase\_library\_key) | .whl file s3 path for the sofbase layer | `string` | n/a | yes |
| <a name="input_glue_sofdata_library_key"></a> [glue\_sofdata\_library\_key](#input\_glue\_sofdata\_library\_key) | .whl file s3 path for the sofdata layer | `string` | n/a | yes |
| <a name="input_glue_typing_extensions_library_key"></a> [glue\_typing\_extensions\_library\_key](#input\_glue\_typing\_extensions\_library\_key) | .whl file s3 path for the typing\_extensions layer | `string` | n/a | yes |
| <a name="input_iam_glue_job_role_arn"></a> [iam\_glue\_job\_role\_arn](#input\_iam\_glue\_job\_role\_arn) | n/a | `string` | n/a | yes |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_s3_artifacts_bucket_name"></a> [s3\_artifacts\_bucket\_name](#input\_s3\_artifacts\_bucket\_name) | n/a | `string` | n/a | yes |
| <a name="input_sg_ids"></a> [sg\_ids](#input\_sg\_ids) | n/a | `list(string)` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | n/a | `list(string)` | n/a | yes |
| <a name="input_team_admin"></a> [team\_admin](#input\_team\_admin) | Whether the team is admin or not | `bool` | `false` | no |
| <a name="input_team_code"></a> [team\_code](#input\_team\_code) | code for the team | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_glue_security_config_name"></a> [glue\_security\_config\_name](#output\_glue\_security\_config\_name) | Glue Security Configuration Name |
| <a name="output_glue_spark_job_arn"></a> [glue\_spark\_job\_arn](#output\_glue\_spark\_job\_arn) | Glue Spark Job ARN |
| <a name="output_glue_spark_job_id"></a> [glue\_spark\_job\_id](#output\_glue\_spark\_job\_id) | Glue Spark Job ID |
| <a name="output_glue_spark_job_name"></a> [glue\_spark\_job\_name](#output\_glue\_spark\_job\_name) | Glue Spark Job Name |
<!-- END_TF_DOCS -->