# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Glue Processor Main Code. 

Only invokes the GlueMain class to process a given transformation. 

Parameters:
    WORKFLOW_NAME : name of the step functions workflow invoking this job.
    STEP_NAME : name of the step inside step fucntions workflow, invoking this job.
    RULES_PATH : path in the artifacts bucket where config file 
             (<RULES_PATH>/<WORKFLOW_NAME>/<STEP_NAME>.json) lives
    START_DT : start date passed as execution parameter to the main step functions workflow. 
    END_DT : end date passed as execution parameter to the main step functions workflow.
"""

import sys
from typing import Any

from awsglue.utils import getResolvedOptions
from sof_data.glue.glueprocessorjob.glue_main import GlueMain
from sofbase.common.logger import LoggingService

driver_log = LoggingService().initialize_logger()


def get_glue_args(
    *, mandatory_fields: list[str], default_optional_args: dict[str, Any]
) -> dict[str, Any]:
    """
    This is a wrapper of the glue function getResolvedOptions to take care of the following case :
    * Handling optional arguments and/or mandatory arguments
    * Optional arguments with default value

    Arguments:
        mandatory_fields {list} -- list of mandatory fields for the job
        default_optional_args {dict} -- dict for optional fields with their default value

    Returns:
        dict -- given args with default value of optional args not filled
    """
    # The glue args are available in sys.argv with an extra '--'
    supplied = set([i[2:].split("=")[0] for i in sys.argv])
    overrided_optional_fields_key = list(
        (supplied).intersection([i for i in default_optional_args])
    )

    args = getResolvedOptions(sys.argv, mandatory_fields + overrided_optional_fields_key)

    # Overwrite default value if optional args are provided
    default_optional_args.update(args)

    return default_optional_args


mandatory_fields = [
    "WORKFLOW_NAME",
    "STEP_NAME",
    "RULES_PATH",
    "START_DT",
    "END_DT",
    "DYNAMIC_RULES",
]
default_optional_args = {
    "EXTRAS": "{}",
    "LOG_VARIABLES": "{}",
    "START_HOUR": "",
    "END_HOUR": "",
    "START_DTTM": "",
    "END_DTTM": "",
}
# Retrieve args
args = get_glue_args(mandatory_fields=mandatory_fields, default_optional_args=default_optional_args)

processor = GlueMain(args=args, driver_log=driver_log)
processor.process()
