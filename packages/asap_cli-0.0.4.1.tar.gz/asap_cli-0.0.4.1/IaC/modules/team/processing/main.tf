###########################
#    Processing Module    # 
###########################
# Performs data transformation and enrichment of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "tprc" # Team Processing
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}-${var.team_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}/${var.team_code}"

  # Use AMK only for andv environment, CMK for all others
  use_amk = var.glue_kms_key_arn == null

  # S3 encryption configuration
  s3_encryption_mode = local.use_amk ? "SSE-S3" : "SSE-KMS"
  s3_kms_key_arn     = local.use_amk ? null : var.glue_kms_key_arn

  # # CloudWatch encryption configuration
  # cloudwatch_encryption_mode = local.use_amk ? "DISABLED" : "SSE-KMS"
  # cloudwatch_kms_key_arn     = local.use_amk ? null : var.glue_kms_key_arn
  # CloudWatch encryption configuration
  cloudwatch_encryption_mode = "DISABLED"
  cloudwatch_kms_key_arn     = null

  # Job bookmarks encryption configuration
  job_bookmarks_encryption_mode = local.use_amk ? "DISABLED" : "CSE-KMS"
  job_bookmarks_kms_key_arn     = local.use_amk ? null : var.glue_kms_key_arn

  # Glue Job base default arguments that apply to all environments
  base_default_arguments = {
    "--enable-s3-parquet-optimized-committer" = "true"
    "--enable-metrics"                        = "true"
    "--job-bookmark-option"                   = "job-bookmark-disable"
    "--enable-job-insights"                   = "true"
    "--enable-spark-ui"                       = "true"
    "--enable-auto-scaling"                   = "true"
    "--enable-continuous-cloudwatch-log"      = "true"
    "--enable-glue-datacatalog"               = "true"
    "--job-language"                          = "python"
  }
  # Environment-specific arguments
  environment_specific_arguments = var.glue_kms_key_arn == null ? {
    # ANDV environment - no encryption arguments
    "--TempDir"               = "s3://${var.s3_artifacts_bucket_name}/glue-assets/glue-temp/"
    "--spark-event-logs-path" = "s3://${var.s3_artifacts_bucket_name}/glue-assets/spark-events/${local.resource_prefix}-glu-data-processor-default-job/"
    # "--encryption-type"       = "sse-s3"
    } : {
    # All other environments - with KMS encryption
    "--TempDir"               = "s3://${var.s3_artifacts_bucket_name}/glue-assets/glue-temp/"
    "--spark-event-logs-path" = "s3://${var.s3_artifacts_bucket_name}/glue-assets/spark-events/${local.resource_prefix}-glu-data-processor-default-job/"
    # "--enable-s3-sse-encryption" = "true"
    # "--encryption-type"          = "sse-kms"
    # "--s3-encryption-kms-key-id" = var.glue_kms_key_arn
  }
  # Python libraries (consistent across environments)
  python_libraries = {
    "--extra-py-files" = join(",", [
      "s3://${var.s3_artifacts_bucket_name}/${var.glue_sofdata_library_key}",
      "s3://${var.s3_artifacts_bucket_name}/${var.glue_sofbase_library_key}",
      "s3://${var.s3_artifacts_bucket_name}/${var.glue_jmespath_library_key}",
      "s3://${var.s3_artifacts_bucket_name}/${var.glue_powertools_library_key}",
      "s3://${var.s3_artifacts_bucket_name}/${var.glue_typing_extensions_library_key}"
    ])
  }

  # Final merged default arguments
  final_default_arguments = merge(
    local.base_default_arguments,
    local.environment_specific_arguments,
    local.python_libraries
  )
}

resource "aws_glue_security_configuration" "glue_security" {
  name = "${local.resource_prefix}-glu-security-config"

  encryption_configuration {
    s3_encryption {
      s3_encryption_mode = local.s3_encryption_mode
      kms_key_arn        = local.s3_kms_key_arn
    }

    cloudwatch_encryption {
      cloudwatch_encryption_mode = local.cloudwatch_encryption_mode
      kms_key_arn                = local.cloudwatch_kms_key_arn
    }

    job_bookmarks_encryption {
      job_bookmarks_encryption_mode = local.job_bookmarks_encryption_mode
      kms_key_arn                   = local.job_bookmarks_kms_key_arn
    }
  }
}

################################################################################
# Glue Connection
################################################################################

data "aws_subnet" "glue_subnets" {
  for_each = toset(var.subnet_ids)
  id       = each.value
}

resource "aws_glue_connection" "sof_glue_connection" {
  for_each = data.aws_subnet.glue_subnets

  name                  = "${local.resource_prefix}-glu-connection-${substr(each.value.availability_zone, -1, 1)}"
  description           = "glue network connection"
  connection_type       = "NETWORK"
  connection_properties = {}

  physical_connection_requirements {
    availability_zone      = each.value.availability_zone
    security_group_id_list = var.sg_ids
    subnet_id              = each.value.id

  }

  tags = {
    AZ       = each.value.availability_zone
    SubnetId = each.value.id
  }
}

################################################################################
# Glue Script
################################################################################
resource "aws_s3_object" "script" {
  bucket = var.s3_artifacts_bucket_name
  key    = "code-artifacts/glue-assets/glue-scripts/${local.resource_prefix}-glu-data-processor-default-job/glue-processor-job.py"
  source = "${path.module}/code/glue/glue-processor-job.py"
  etag   = filemd5("${path.module}/code/glue/glue-processor-job.py")
  acl    = "private"
}


################################################################################
# Glue Job
################################################################################

module "sof_glue_spark_job" {
  source = "git::https://github.com/cloudposse/terraform-aws-glue.git//modules/glue-job?ref=e04ac37bd44efcf29ad0a8fc94149bccc9162a6d"

  name              = "${local.resource_prefix}-glu-data-processor-default-job"
  role_arn          = var.iam_glue_job_role_arn
  job_description   = "Glue Job that runs glue-processor-job.py Python script"
  glue_version      = "5.0"
  worker_type       = "G.1X"
  number_of_workers = 2
  max_retries       = 0
  job_name          = "${local.resource_prefix}-glu-data-processor-default-job"
  timeout           = 300
  execution_property = {
    max_concurrent_runs = 300
  }
  command = {
    name            = "glueetl"
    script_location = "s3://${var.s3_artifacts_bucket_name}/${aws_s3_object.script.key}"
    python_version  = "3"
  }
  default_arguments = local.final_default_arguments

  #description = "Trabajo de ejemplo para procesamiento spark"
  #max_capacity = 10
  security_configuration = aws_glue_security_configuration.glue_security.name
  connections            = [for conn in aws_glue_connection.sof_glue_connection : conn.name]
  depends_on             = [aws_glue_connection.sof_glue_connection]
}
##################
# SSM Parameters #
##################
locals {
  ssm_parameters = {
    "/${local.param_prefix}/Glue/Job/GlueDataProcessor/Default/Name" = {
      description = "Team ${var.team_code} Default GlueProcessor Job for Proserve Team"
      type        = "String"
      value       = module.sof_glue_spark_job.name
      tier        = "Standard"
    },
    # TODO: JFAR - Temporary ssm parameters, we need to remove this once new ssm parameters standard are fully integrated on sof-base, sof-data
    "/${var.platform_code}/Foundations/${var.team_code}/Glue/Job/GlueDataProcessor/Default/Name" = {
      description = "Team ${var.team_code} Glue Data Processor Job Name"
      type        = "String"
      value       = module.sof_glue_spark_job.name
      tier        = "Standard"
    }
  }
}

module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}