output "glue_security_config_name" {
  value       = aws_glue_security_configuration.glue_security.name
  description = "Glue Security Configuration Name"
}

# output "glue_security_config_arn" {
#  value = aws_glue_security_configuration.glue_security.encryption_configuration
#  description = "Glue Security Configuration ARN"
# }

# output "glue_connection_name" {
#   value       = module.sof_glue_connection.name
#   description = "Glue Connection Name"
# }

# output "glue_connection_arn" {
#   value       = module.sof_glue_connection.arn
#   description = "Glue Connection ARN"
# }

# output "glue_connection_id" {
#   value       = module.sof_glue_connection.id
#   description = "Glue Connection ID"
# }

output "glue_spark_job_id" {
  value       = module.sof_glue_spark_job.id
  description = "Glue Spark Job ID"
}

output "glue_spark_job_name" {
  value       = module.sof_glue_spark_job.name
  description = "Glue Spark Job Name"
}

output "glue_spark_job_arn" {
  value       = module.sof_glue_spark_job.arn
  description = "Glue Spark Job ARN"
}

