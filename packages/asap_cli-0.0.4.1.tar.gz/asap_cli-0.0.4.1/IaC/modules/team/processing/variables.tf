variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}
variable "team_code" {
  description = "code for the team"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.team_code)) &&
      length(var.team_code) >= 1 &&
      length(var.team_code) <= 4
    )
    error_message = "The 'team_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "team_admin" {
  description = "Whether the team is admin or not"
  type        = bool
  default     = false
}
variable "sg_ids" {
  type = list(string)
}

variable "subnet_ids" {
  type = list(string)
}

variable "s3_artifacts_bucket_name" {
  type = string
}

variable "iam_glue_job_role_arn" {
  type = string
}

variable "glue_kms_key_arn" {
  type = string
}

# glue libraries paths
variable "glue_sofdata_library_key" {
  description = ".whl file s3 path for the sofdata layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_sofdata_library_key))
    error_message = "The 'glue_sofdata_library_key' must be a valid .whl file path."
  }
}
variable "glue_sofbase_library_key" {
  description = ".whl file s3 path for the sofbase layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_sofbase_library_key))
    error_message = "The 'glue_sofbase_library_key' must be a valid .whl file path."
  }
}
variable "glue_jmespath_library_key" {
  description = ".whl file s3 path for the jmespath layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_jmespath_library_key))
    error_message = "The 'glue_jmespath_library_key' must be a valid .whl file path."
  }

}
variable "glue_powertools_library_key" {
  description = ".whl file s3 path for the powertools layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_powertools_library_key))
    error_message = "The 'glue_powertools_library_key' must be a valid .whl file path."
  }

}
variable "glue_typing_extensions_library_key" {
  description = ".whl file s3 path for the typing_extensions layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_typing_extensions_library_key))
    error_message = "The 'glue_typing_extensions_library_key' must be a valid .whl file path."
  }
}