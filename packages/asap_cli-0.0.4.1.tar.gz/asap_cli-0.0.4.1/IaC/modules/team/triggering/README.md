# triggering construct

Manages data pipeline triggers based on rules and schedules of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "triggering" {
  source = "./modules/appmanagement"
}
```

## Requirements

- Terraform 0.12 or later
- AWS Provider

## Providers

- aws

## Modules

This module uses the following external modules:

## Resources

This module creates the following resources:


## Inputs

| Name                          | Description                                   | Type   | Default | Required |
|-------------------------------|-----------------------------------------------|--------|---------|----------|


## Outputs

| Name                                   | Description                                   |
|----------------------------------------|-----------------------------------------------|
