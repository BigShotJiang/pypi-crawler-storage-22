###########################
#    triggering Module    # 
###########################
# Manages data pipeline triggers based on rules and schedules of ASAP.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "ttrg" # Team triggering
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}-${var.team_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}/${var.team_code}"
}

module "lftn_trig_pipeline_executor" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-lambda.git?ref=84dfbfddf9483bc56afa0aff516177c03652f0c7"

  function_name          = var.lambda_pipeline_executor_name
  handler                = "index.lambda_handler"
  runtime                = var.lambda_runtime
  publish                = true
  create_role            = false
  lambda_role            = var.iam_lambda_pipeline_executor_role_arn
  source_path            = "${path.module}/code/lambda/pipeline-executor/index.py"
  vpc_subnet_ids         = var.subnet_ids
  vpc_security_group_ids = var.sg_id
  environment_variables = {
    SOF_APP_NAME = var.platform_code
  }
  memory_size = 256
  timeout     = 60
  layers      = [var.pydantic_arn, var.sofbase_arn]
}