output "lambda_pipeline_executor_arn" {
  value = module.lftn_trig_pipeline_executor.lambda_function_arn

}

output "lambda_pipeline_executor_name" {
  value = module.lftn_trig_pipeline_executor.lambda_function_name
}