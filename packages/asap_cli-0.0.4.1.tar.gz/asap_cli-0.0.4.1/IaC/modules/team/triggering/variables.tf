variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "team_code" {
  description = "code for the team"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.team_code)) &&
      length(var.team_code) >= 1 &&
      length(var.team_code) <= 4
    )
    error_message = "The 'team_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "team_admin" {
  description = "Whether the team is admin or not"
  type        = bool
  default     = false
}

variable "lambda_pipeline_executor_name" {
  description = "Name of the Lambda function that executes the pipeline"
  type        = string
}

variable "lambda_runtime" {
  type = string
}

variable "iam_lambda_pipeline_executor_role_arn" {
  description = "ARN of the IAM role for the Lambda function"
  type        = string

}

variable "pydantic_arn" {
  description = "ARN of the Pydantic Lambda layer"
  type        = string

}

variable "sofbase_arn" {
  description = "ARN of the SOF Base Lambda layer"
  type        = string

}
variable "subnet_ids" {
  description = "List of subnet IDs for the Lambda function"
  type        = list(string)
}

variable "sg_id" {
  description = "Security group ID for the Lambda function"
  type        = list(string)
}

variable "app_name" {
  description = "Name of the application"
  type        = string

}