# Datawharehouse construct

This module creates the resources for the Datawharehouse components of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "Datawharehouse" {
  source = "./modules/appmanagement"
}
```
