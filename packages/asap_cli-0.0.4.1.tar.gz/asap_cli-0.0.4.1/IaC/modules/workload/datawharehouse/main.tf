###############################
#    Datawharehouse Module    # 
###############################
# This module creates the resources for the Data Warehouse components of ASAP.