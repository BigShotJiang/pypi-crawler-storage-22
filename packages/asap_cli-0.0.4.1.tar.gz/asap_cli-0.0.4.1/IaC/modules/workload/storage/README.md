# storage construct

This module creates the resources for the storage components of Amazon Scalable Analytics Platform (ASAP).

## Usage

To use this module, include it in your Terraform configuration as follows:

```hcl
module "storage" {
  source = "./modules/appmanagement"
}
```
<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_s3_analytics"></a> [s3\_analytics](#module\_s3\_analytics) | git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git | fc09cc6fb779b262ce1bee5334e85808a107d8a3 |
| <a name="module_s3_athena_results"></a> [s3\_athena\_results](#module\_s3\_athena\_results) | git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git | fc09cc6fb779b262ce1bee5334e85808a107d8a3 |
| <a name="module_s3_landing"></a> [s3\_landing](#module\_s3\_landing) | git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git | fc09cc6fb779b262ce1bee5334e85808a107d8a3 |
| <a name="module_s3_raw"></a> [s3\_raw](#module\_s3\_raw) | git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git | fc09cc6fb779b262ce1bee5334e85808a107d8a3 |
| <a name="module_s3_redshifttmp"></a> [s3\_redshifttmp](#module\_s3\_redshifttmp) | git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git | fc09cc6fb779b262ce1bee5334e85808a107d8a3 |
| <a name="module_s3_stage"></a> [s3\_stage](#module\_s3\_stage) | git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git | fc09cc6fb779b262ce1bee5334e85808a107d8a3 |
| <a name="module_ssm_parameters"></a> [ssm\_parameters](#module\_ssm\_parameters) | git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git | 28784d318fcb1d5b632e38a4c1f567dd138fcd83 |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment_code"></a> [environment\_code](#input\_environment\_code) | environment code | `string` | n/a | yes |
| <a name="input_force_destroy"></a> [force\_destroy](#input\_force\_destroy) | Whether to force destroy the S3 buckets and its contents | `bool` | `false` | no |
| <a name="input_organization_code"></a> [organization\_code](#input\_organization\_code) | organization code | `string` | n/a | yes |
| <a name="input_platform_code"></a> [platform\_code](#input\_platform\_code) | Platform code | `string` | `"asap"` | no |
| <a name="input_s3_kms_key_arn"></a> [s3\_kms\_key\_arn](#input\_s3\_kms\_key\_arn) | ARN of the KMS key for S3 encryption | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_analytics_bucket_arn"></a> [analytics\_bucket\_arn](#output\_analytics\_bucket\_arn) | n/a |
| <a name="output_analytics_bucket_name"></a> [analytics\_bucket\_name](#output\_analytics\_bucket\_name) | Nombre del bucket ANALYTICS |
| <a name="output_athena_results_bucket_arn"></a> [athena\_results\_bucket\_arn](#output\_athena\_results\_bucket\_arn) | n/a |
| <a name="output_athena_results_bucket_name"></a> [athena\_results\_bucket\_name](#output\_athena\_results\_bucket\_name) | Nombre del bucket ATHENA RESULTS |
| <a name="output_landing_bucket_arn"></a> [landing\_bucket\_arn](#output\_landing\_bucket\_arn) | n/a |
| <a name="output_landing_bucket_name"></a> [landing\_bucket\_name](#output\_landing\_bucket\_name) | n/a |
| <a name="output_raw_bucket_arn"></a> [raw\_bucket\_arn](#output\_raw\_bucket\_arn) | n/a |
| <a name="output_raw_bucket_name"></a> [raw\_bucket\_name](#output\_raw\_bucket\_name) | Nombre del bucket RAW |
| <a name="output_redshifttmp_bucket_arn"></a> [redshifttmp\_bucket\_arn](#output\_redshifttmp\_bucket\_arn) | n/a |
| <a name="output_stage_bucket_arn"></a> [stage\_bucket\_arn](#output\_stage\_bucket\_arn) | n/a |
| <a name="output_stage_bucket_name"></a> [stage\_bucket\_name](#output\_stage\_bucket\_name) | Nombre del bucket STAGE |
<!-- END_TF_DOCS -->