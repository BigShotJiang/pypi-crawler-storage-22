##################
# Storage module #
##################
# Defines the object storage structure for raw, stage and analytics data.
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}
locals {
  region          = data.aws_region.current.name
  accountid       = data.aws_caller_identity.current.account_id
  construct_code  = "wdlk" # Workload datalake storage
  resource_prefix = "${var.platform_code}-${var.organization_code}-${var.environment_code}-${local.construct_code}"
  param_prefix    = "${var.platform_code}/${var.organization_code}/${var.environment_code}/${local.construct_code}"

  # Use AMK when KMS key is null, CMK when provided
  use_amk = var.s3_kms_key_arn == null

  # S3 encryption configuration with switched logic
  s3_server_side_encryption_configuration = {
    rule = local.use_amk ? {
      # AMK case: AES256
      apply_server_side_encryption_by_default = {
        sse_algorithm = "AES256"
      }
      bucket_key_enabled = false
      } : {
      # CMK case: aws:kms
      apply_server_side_encryption_by_default = {
        sse_algorithm     = "aws:kms"
        kms_master_key_id = var.s3_kms_key_arn
      }
      bucket_key_enabled = true
    }
  }
}

####################
# Datalake buckets #
####################
# Bucket para RAW
module "s3_raw" {
  source                               = "git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git?ref=fc09cc6fb779b262ce1bee5334e85808a107d8a3"
  bucket                               = "${local.resource_prefix}-s3-raw-bucket-${local.accountid}"
  server_side_encryption_configuration = local.s3_server_side_encryption_configuration
  attach_public_policy                 = false

  tags = {
    EncryptionType = local.use_amk ? "AMK" : "CMK"
  }
  force_destroy = var.force_destroy
}

# Bucket para STAGE
module "s3_stage" {
  source                               = "git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git?ref=fc09cc6fb779b262ce1bee5334e85808a107d8a3"
  bucket                               = "${local.resource_prefix}-s3-stage-bucket-${local.accountid}"
  server_side_encryption_configuration = local.s3_server_side_encryption_configuration
  attach_public_policy                 = false

  tags = {
    EncryptionType = local.use_amk ? "AMK" : "CMK"
  }
  force_destroy = var.force_destroy
}
# Bucket para ANALYTICS
module "s3_analytics" {
  source                               = "git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git?ref=fc09cc6fb779b262ce1bee5334e85808a107d8a3"
  bucket                               = "${local.resource_prefix}-s3-analytics-bucket-${local.accountid}"
  server_side_encryption_configuration = local.s3_server_side_encryption_configuration
  attach_public_policy                 = false

  tags = {
    EncryptionType = local.use_amk ? "AMK" : "CMK"
  }
  force_destroy = var.force_destroy
}
#################
# Other buckets #
#################

# Bucket para ATHENA RESULTS
module "s3_athena_results" {
  source                               = "git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git?ref=fc09cc6fb779b262ce1bee5334e85808a107d8a3"
  bucket                               = "${local.resource_prefix}-s3-athena-results-bucket-${local.accountid}"
  server_side_encryption_configuration = local.s3_server_side_encryption_configuration
  attach_public_policy                 = false

  tags = {
    EncryptionType = local.use_amk ? "AMK" : "CMK"
  }
  force_destroy = var.force_destroy
}

module "s3_landing" {
  source                               = "git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git?ref=fc09cc6fb779b262ce1bee5334e85808a107d8a3"
  bucket                               = "${local.resource_prefix}-s3-landing-bucket-${local.accountid}"
  server_side_encryption_configuration = local.s3_server_side_encryption_configuration
  attach_public_policy                 = false

  tags = {
    EncryptionType = local.use_amk ? "AMK" : "CMK"
  }
  force_destroy = var.force_destroy
}

module "s3_redshifttmp" {
  source                               = "git::https://github.com/terraform-aws-modules/terraform-aws-s3-bucket.git?ref=fc09cc6fb779b262ce1bee5334e85808a107d8a3"
  bucket                               = "${local.resource_prefix}-s3-redshifttmp-bucket-${local.accountid}"
  server_side_encryption_configuration = local.s3_server_side_encryption_configuration
  attach_public_policy                 = false

  tags = {
    EncryptionType = local.use_amk ? "AMK" : "CMK"
  }
  force_destroy = var.force_destroy
}

##################
# SSM Parameters #
##################
locals {
  ssm_parameters = {
    # Storage SSM Parameters
    "/${local.param_prefix}/S3/RawBucket/Name" = {
      description = "Raw Bucket Name"
      type        = "String"
      value       = module.s3_raw.s3_bucket_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/StageBucket/Name" = {
      description = "Stage Bucket Name"
      type        = "String"
      value       = module.s3_stage.s3_bucket_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/AnalyticsBucket/Name" = {
      description = "Analytics Bucket Name"
      type        = "String"
      value       = module.s3_analytics.s3_bucket_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/AthenaResultsBucket/Name" = {
      description = "Athena Results Bucket Name"
      type        = "String"
      value       = module.s3_athena_results.s3_bucket_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/Streams/Name" = {
      description = "Landing Bucket Name"
      type        = "String"
      value       = module.s3_landing.s3_bucket_id
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/RawBucket/Arn" = {
      description = "Raw Bucket ARN"
      type        = "String"
      value       = module.s3_raw.s3_bucket_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/StageBucket/Arn" = {
      description = "Stage Bucket ARN"
      type        = "String"
      value       = module.s3_stage.s3_bucket_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/AnalyticsBucket/Arn" = {
      description = "Stage Bucket ARN"
      type        = "String"
      value       = module.s3_analytics.s3_bucket_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/Streams/Arn" = {
      description = "Landing Bucket Arn"
      type        = "String"
      value       = module.s3_landing.s3_bucket_arn
      tier        = "Standard"
    },
    "/${local.param_prefix}/S3/AthenaResultsBucket/Arn" = {
      description = "Athena Results Bucket Name"
      type        = "String"
      value       = module.s3_athena_results.s3_bucket_arn
      tier        = "Standard"
    },
    # TODO: JFAR - Temporary ssm parameters, we need to remove this once new ssm parameters standard are fully integrated on sof-base, sof-data
    "/${var.platform_code}/Foundation/S3/AnalyticsBucket/Arn" = {
      description = "Analytics S3 Bucket Arn"
      type        = "String"
      value       = module.s3_analytics.s3_bucket_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/AnalyticsBucket/Name" = {
      description = "Analytics S3 Bucket Name"
      type        = "String"
      value       = module.s3_analytics.s3_bucket_id
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/AthenaResultsBucket/Arn" = {
      description = "Athena Results S3 Bucket Arn"
      type        = "String"
      value       = module.s3_athena_results.s3_bucket_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/AthenaResultsBucket/Name" = {
      description = "Athena Results S3 Bucket Name"
      type        = "String"
      value       = module.s3_athena_results.s3_bucket_id
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/RawBucket/Arn" = {
      description = "Raw S3 Bucket Arn"
      type        = "String"
      value       = module.s3_raw.s3_bucket_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/RawBucket/Name" = {
      description = "Raw S3 Bucket Name"
      type        = "String"
      value       = module.s3_raw.s3_bucket_id
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/RedshifttmpBucket/Arn" = {
      description = "Redshift tmp S3 Bucket Arn"
      type        = "String"
      value       = module.s3_redshifttmp.s3_bucket_arn
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/RedshifttmpBucket/Name" = {
      description = "Redshift tmp S3 Bucket Name"
      type        = "String"
      value       = module.s3_redshifttmp.s3_bucket_id
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/StageBucket/Name" = {
      description = "Stage S3 Bucket Name"
      type        = "String"
      value       = module.s3_stage.s3_bucket_id
      tier        = "Standard"
    }
    "/${var.platform_code}/Foundation/S3/StageBucket/Arn" = {
      description = "Stage S3 Bucket Arn"
      type        = "String"
      value       = module.s3_stage.s3_bucket_arn
      tier        = "Standard"
    }
  }
}
module "ssm_parameters" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ssm-parameter.git?ref=28784d318fcb1d5b632e38a4c1f567dd138fcd83"

  for_each = local.ssm_parameters

  name            = each.key
  value           = try(each.value.value, null)
  values          = try(each.value.values, [])
  type            = try(each.value.type, null)
  secure_type     = try(each.value.secure_type, null)
  description     = try(each.value.description, null)
  tier            = try(each.value.tier, null)
  key_id          = try(each.value.key_id, null)
  allowed_pattern = try(each.value.allowed_pattern, null)
  data_type       = try(each.value.data_type, null)
}