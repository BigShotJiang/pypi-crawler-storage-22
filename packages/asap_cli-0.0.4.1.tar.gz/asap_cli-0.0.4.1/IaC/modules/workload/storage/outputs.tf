output "raw_bucket_name" {
  description = "Nombre del bucket RAW"
  value       = module.s3_raw.s3_bucket_id
}

output "raw_bucket_arn" {
  value = module.s3_raw.s3_bucket_arn
}

output "stage_bucket_name" {
  description = "Nombre del bucket STAGE"
  value       = module.s3_stage.s3_bucket_id
}

output "stage_bucket_arn" {
  value = module.s3_stage.s3_bucket_arn
}

output "redshifttmp_bucket_arn" {
  value = module.s3_redshifttmp.s3_bucket_arn
}

output "analytics_bucket_name" {
  description = "Nombre del bucket ANALYTICS"
  value       = module.s3_analytics.s3_bucket_id
}

output "analytics_bucket_arn" {
  value = module.s3_analytics.s3_bucket_arn
}

output "athena_results_bucket_name" {
  description = "Nombre del bucket ATHENA RESULTS"
  value       = module.s3_athena_results.s3_bucket_id
}

output "athena_results_bucket_arn" {
  value = module.s3_athena_results.s3_bucket_arn
}

output "landing_bucket_name" {
  value = module.s3_landing.s3_bucket_id
}

output "landing_bucket_arn" {
  value = module.s3_landing.s3_bucket_arn
}