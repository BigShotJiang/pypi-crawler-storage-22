variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "force_destroy" {
  description = "Whether to force destroy the S3 buckets and its contents"
  type        = bool
  default     = false
}

variable "s3_kms_key_arn" {
  description = "ARN of the KMS key for S3 encryption"
  type        = string
}