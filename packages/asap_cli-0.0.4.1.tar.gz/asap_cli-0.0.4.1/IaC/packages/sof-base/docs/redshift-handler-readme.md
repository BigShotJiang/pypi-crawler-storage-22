# Redshift Execution Tasks

This document reflects the use of the redshift handler component in the SOF framework. Ths component allows a data pipeline to execute redshift ETL tasks. 

In this document you will find: 

1. [How to use it with examples.](#how-to-use-it-with-examples) 
2. [Json config parameters guide.](#json-config-parameters-guide) 

## How to use it with examples

in this repository there is a folder "samples/functional-workflows/demo-redshift-workflow" with a sample ETL pipeline simulating a data warehouse workload. 
The sample flow we model with this pipeline is the following: 

![sample](img/sample-flow.png)

in this sample flow we want to load data coming from a datalake to a datawarehouse in redshift, and in redshift we want to model a transformation flow that 
first fills a fact_table from a stg_table, and then calculates an aggregated table from the fact table. 
  
the pipeline workflow execution looks like this: 

![pipeline sample](img/pipeline-exec.png)

it process 1 sample fact tables (sales)
in the folder "samples/functional-workflows/source-files" there are files simulating data comming to the raw layer in the datalake, and 
in the folder "samples/functional-workflows/table-ddls/redshift" there are DDL sentences to create tables in a redshift cluster used by the workflow. 

The folder "samples/functional-workflows/demo-redshift-workflow" contains all the files related to the pipeline: 

![pipeline sample](img/pipeline-files.png)

every step in the pipeline is composed by 2 files, a json configuration file and an etl business rule file ( sql file ). 
here we will explain different configuration options that you can deliver using this job. 
The job is a generic job that receives as parameter a step name, so each config/rules file combination needs to be named with the step name. 
Let's review an example. 

The first step in the pipeline ( etl_step_1_raw_sales ) is widely explained in the file "packages/sof-data/src/python/sof_data/doc/glue-processor-readme.md", 
and is using the glue job to export data to a redshift stage table. 
In the scope of this document, we will explain the second step "etl_step_2_model_fact_sales". 

### Redshift Task Execution

The redshift task is executed as part of the serverless orchestration framework ( SOF ) as shown in this graphic: 

![redshift execution](img/redshift-execution.png)

the step functions task executor invokes the component "lambda task orchestrator" that executes internally the "Redshift Handler" component. 

Let's review the input sent to the lambda in an execution:

![execution params](img/input-params.png)

for this lambda invocation, it is expected that the json and rules files lives in a s3 artifactory bucket, 
and the name of the bucket is extracted from a SSM parameter called "/{APP_NAME}/Foundation/S3/ArtifactsBucket/Name". 

Lets review each relevant redshift execution parameter: 

| Parameter        | Sample Value               | Description                                               |
|------------------|----------------------------|-----------------------------------------------------------|
| `"rules_path"`   | `rules`                    | In the artifactory bucket, this is the path where the config and rules files lives.                              |
| `"workflow_name"`| `demo-redshift-workflow`            | in the rules path, this is the name of the folder containing all the pipeline related files                                   |
| `"task_id"`    | `etl_step_2_model_fact_sales`  | Name of the ETL step. there must be in the workflow folder a couple of json and rules files that reflects the step.                                       |
| `"start_date"`     | `2025-02-02`               | Start date for the workflow execution. This parameter is passed normally by the orchestrator component of the framework. Can be invoked on demand for data reprocessing                    |
| `"end_date"`       | `2025-02-03`               | End date for the workflow execution . This parameter is passed normally by the orchestrator component of the framework. Can be invoked on demand for data reprocessing                    |

this execution lauches a glue job, that is going to look for a couple of files in s3: 

s3://<artifactory_bucket>/rules/demo-redshift-workflow/etl_step_2_model_fact_sales.json
s3://<artifactory_bucket>/rules/demo-redshift-workflow/etl_step_2_model_fact_sales.sql

from this files the component will understand how needs to behave depending on the configuration. let´s review some configuration samples:


### Case 1: Executing a simple redshift sql command. 

This is the first option to execute a redshift query. you can configure a job that reads from a stagin zone in refshift and save in a transformation or model
layer in the same or another database in redshift. 

```json
{    
    "ProcessingFramework": {
         "Type": "RedshiftDataProcessor",
        "Parameters": {
            "REDSHIFT_CONFIG_SECRET_NAME_SSM":"/secret/redshift/connection1",
            "REDSHIFT_DATABASE": "sales_db"
        }
    },
    "InputProperties": {
        "SOURCE_DATABASE": "sales_db.public"
    },
    "OutputProperties": {
        "TARGET_DATABASE":"sales_db.public",
        "TARGET_TABLE_NAME":"customer_tmp"
    }    
}
```

The "ProcessingFramework" section will contain all the parameters related with the execution engine, in this case, redshift. 
we can configure parameters like the secret name that holds the redshift connection configuration, and the processor type (RedshiftDataProcessor). 
This processor type is not directly used by the job, but is used by the orchestration engine. 


Then there is the "InputProperties" section, were all the properties related with reading a procesing data are configured. 
in this case, only source database property is required. this property will be replaced in execution time in the rules file, in this example, 
of sql type ( by default). this is the content of the sql business rule transformation file: 

```sql
 MERGE INTO $TARGET_DATABASE.$TARGET_TABLE AS t
 USING (
     SELECT 
           customer_id,
           customer_name,
           customer_phone
     FROM $SOURCE_DATABASE.customer_stg
  ) AS u
 ON t.customer_id = u.customer_id
 WHEN MATCHED THEN UPDATE SET 
     t.customer_name = u.customer_name, 
     t.customer_phone = u.customer_phone
 WHEN NOT MATCHED THEN INSERT *
```

this variable replacement with wildcards starting with $ is because database names can be different depending on the customer AWS accounts ( dev, qa, prod)
depending on the naming standars. So in this example, the job will execute this sql using redshift engine.  
a common use case in redshift is to execute upsert or merge sentences, like in the sample. 

### Case 1.1: what if I need to use different source databases?

You can configure more than 1 source database. Let´s supose the following sql content: 

```sql
SELECT
  CAST(location_id AS INTEGER) as location_id,
  location_name
FROM
  $SOURCE_DATABASE.location
  UNION
  $SOURCE_DATABASE_1.other_location
```

in this case you will need to configure the json section like this: 

```json
"InputProperties": {
        "SOURCE_DATABASE": "db_sales_raw",
        "SOURCE_DATABASE_1": "other_db_sales_raw"
    },
```

### Case 2: using multiple sql sentences

you can use multiple sql sentences in the same redshift execution. in that case, you need to separate the sentences by ";". 
Lets review an example for a content of a sql file with multiple sentences: 

```sql
 -- deleting data before lading
delete from $SOURCE_DATABASE.fact_sales
where sales_dt between '$START_DATE' and '$END_DATE';

-- loading fact sales with some business rules
insert into $SOURCE_DATABASE.fact_sales
SELECT
  invoice_id,
  location_id,
  product_id,
  sales_value,
  sales_cost,
  (sales_value - sales_cost) AS sales_revenue,
  sales_dt
FROM
  $SOURCE_DATABASE.stg_sales
  WHERE
  sales_dt between '$START_DATE' and '$END_DATE';

-- deleting agg tabble before loading
delete from $SOURCE_DATABASE.agg_fact_sales
where sales_dt between '$START_DATE' and '$END_DATE';

-- loading agg sales with some business rules
insert into $SOURCE_DATABASE.agg_fact_sales
select
    concat('location', location_id) as location_name,
    concat('product', product_id) as product_name,
    'happy' as sentiment_classification,
    sum(sales_value) as sales_value,
    sum(sales_cost) as sales_cost,
    sum(sales_revenue) as sales_revenue,
    sales_dt
from $SOURCE_DATABASE.fact_sales s
 WHERE
  s.sales_dt between '$START_DATE' and '$END_DATE'
  group by 1,2,3,7
```

in this case the idea is that all the SQLs can execute opperations to finally save in a target table, but technically could be any sql. 
there is a special case, where we can create stored procedures. 
in that case the separator is "END;$$", that identifies the end of a procedure. 


### Case 3:  working with extra query parameters different than dates

in this sample, you can build your sql transformation query like this: 

```sql
SELECT
  CAST(invoice_id AS INTEGER) as invoice_id,
  CAST(location_id AS INTEGER) as location_id,
  CAST(product_id AS INTEGER) as product_id,
  sales_value,
  sales_cost,
  dt as sales_dt,
  country
FROM
  $SOURCE_DATABASE.sales_by_country
  WHERE
  $TIME_CONDITION
  and country = '$COUNTRY'
```

Note that in this case you are using the "COUNTRY' wildcard in the query.  This wildcard can be passed in execution time, 
in the "additional properties" secton when invoking a pipeline. the redshift query will receive an "extras" dictionary
like this: 

```shell
'{"country":"country1"}'
```

the framework will replace wildcard variables in the transformation sql file. 


### Apendix: using a redshift config secret

the redshift credentials attached to a redshift step are holded in a redshift secret that you can configure like this: 

```json
                "REDSHIFT_CONFIG_SECRET_NAME":"redshift-connections/database-config1",
                "REDSHIFT_DATABASE": "dev" 
```

In this case, you need to specify a secret name created previously in  AWS Secrets service, that hold the redshift configuration, 
as well as the redshift table to expor the data, and the database where the table lives. 

the secret configuration looks like this: 

![secret sample](img/secret.png)

Note that the secret doesn't contains the user password. This is because by default, the component uses redshift IAM
authentication, where the glue job role needs the corresponding permissions to read credentials from redshift. 

| Key                            | Description                                                  |
| ------------------------------ | ------------------------------------------------------------ |
| REDSHIFT_ENDPOINT              | Redshift endpoint url                    |
| REDSHIFT_TEMP_BUCKET              | bucket necessary to export data before copying to redshift. This process is automated by the spark-redshift library                  |
| REDSHIFT_ETL_USER              | User to connect to redshift                    |
| REDSHIFT_REGION              | region where the cluster is deployed                   |

You can also use a native Redshift secret , using the option from the AWS console while creating the secret, selecting the redshift cluster, 
and it will populate the secret payload with the cluster related data. It will create a secret structure a little different, with some predefined keys. 
In this case, the user and password are mandatory fields when creating the secret. 


## Json Config Parameters Guide

this is the complete list of parameters that can be configured in the glue processor job, in each config section: 

## ProcessingFramework

| Key                            | Default Value          | Description                                                  |
| ------------------------------ | ---------------------- | ------------------------------------------------------------ |
| Type                           | RedshiftDataProcessor      | The type of processing framework used. ( used by orchestration framework)                     |
| REDSHIFT_CONFIG_SECRET_NAME_SSM                           | ""      | secret name holding the redshift credentals for the step                   |
| REDSHIFT_DATABASE                           | ""      | default database where the redshift connection will start                  |


## InputProperties

| Key                              | Default Value        | Description                                                  |
| -------------------------------- | -------------------- | ------------------------------------------------------------ |
| SOURCE_DATABASE                  | ""                   | The name of the source database ( or databases ) in the glue catalog. In case you need more than one source database, you can configure like SOURCE_DATABASE_1, SOURCE_DATABASE_2... etc                             |

## OutputProperties

| Key                              | Default Value          | Description                                                  |
| -------------------------------- | ---------------------- | ------------------------------------------------------------ |
| TARGET_TABLE_NAME                | ""                     | The name of the target table where the data will be written                               |
| TARGET_DATABASE                  | ""                     | The name of the target database where the data will be written                           |
