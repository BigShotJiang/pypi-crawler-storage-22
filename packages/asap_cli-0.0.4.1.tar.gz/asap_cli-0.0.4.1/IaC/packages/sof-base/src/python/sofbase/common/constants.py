from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

import boto3

if TYPE_CHECKING:
    from mypy_boto3_ssm import SSMClient

ssm_client: "SSMClient" = boto3.client("ssm")


class StringEnum(str, Enum):
    def __repr__(self) -> str:
        return str.__repr__(self.value)

    def __str__(self) -> str:
        return str(self.value)


class SOFGlobalConstantsNamespace:
    def __init__(
        self,
    ) -> None:
        """
        Servleress Orchestration Framework Global Constants Namespace
        """
        self._APP_NAME: str | None = None
        self._LOG_LEVEL: str | None = None
        self._AWS_REGION: str | None = None
        self._AWS_ACCOUNT_ID: str | None = None

    @property
    def APP_NAME(self) -> str:
        if self._APP_NAME is None:
            ssm_param = ssm_client.get_parameter(Name="/SOF/Globals/App/Name", WithDecryption=True)
            ssm_value = ssm_param["Parameter"]["Value"]
            self._APP_NAME = ssm_value
        return self._APP_NAME

    @property
    def LOG_LEVEL(self) -> str:
        if self._LOG_LEVEL is None:
            ssm_param = ssm_client.get_parameter(
                Name="/SOF/Globals/Logger/LogLevel", WithDecryption=True
            )
            ssm_value = ssm_param["Parameter"]["Value"]
            self._LOG_LEVEL = ssm_value
        return self._LOG_LEVEL

    @property
    def AWS_REGION(self) -> str:
        if self._AWS_REGION is None:
            ssm_param = ssm_client.get_parameter(Name="/SOF/Globals/Region", WithDecryption=True)
            ssm_value = ssm_param["Parameter"]["Value"]
            self._AWS_REGION = ssm_value
        return self._AWS_REGION

    @property
    def AWS_ACCOUNT_ID(self) -> str:
        if self._AWS_ACCOUNT_ID is None:
            ssm_param = ssm_client.get_parameter(Name="/SOF/Globals/AccountId", WithDecryption=True)
            ssm_value = ssm_param["Parameter"]["Value"]
            self._AWS_ACCOUNT_ID = ssm_value
        return self._AWS_ACCOUNT_ID


class TaskType(StringEnum):
    SUB_WORKFLOW = "SubWorkflow"
    DATA_PROCESSOR = "DataProcessor"
    DATA_VALIDATOR = "DataValidator"
    NOTIFICATION_TASK = "NotificationTask"
    DATA_INGESTION = "DataIngestion"


class SubTaskType(StringEnum):
    STEP_FUNCTIONS_PROCESSOR = "StepFunctionsProcessor"
    DUMMY_DATA_PROCESSOR = "DummyDataProcessor"
    GLUE_DATA_PROCESSOR = "GlueDataProcessor"
    REDSHIFT_DATA_PROCESSOR = "RedshiftDataProcessor"
    EMR_DATA_PROCESSOR = "EMRDataProcessor"
    EMR_SERVERLESS_DATA_PROCESSOR = "EMRServerlessDataProcessor"
    REDSHIFT_SERVERLESS_DATA_PROCESSOR = "RedshiftServerlessDataProcessor"
    ATHENA_DATA_PROCESSOR = "AthenaDataProcessor"


class PipelineStatus(StringEnum):
    """Pipeline Status"""

    PIPELINE_STARTED = "PIPELINE_STARTED"
    PIPELINE_RUNNING = "PIPELINE_RUNNING"
    PIPELINE_COMPLETED = "PIPELINE_COMPLETED"
    PIPELINE_FAILED = "PIPELINE_FAILED"


class TaskStatus(StringEnum):
    """Task Status"""

    NOT_STARTED = "NOT_STARTED"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    WAITING = "WAITING"
    SKIPPED = "SKIPPED"
    ABORTED = "ABORTED"


class ExecutionType(StringEnum):
    HANDLE_WORKFLOW_ERROR = "handle-workflow-error"
    HANDLE_WORKFLOW_SUCCESS = "handle-workflow-success"
    HANDLE_WORKFLOW_ABORT = "handle-workflow-abort"
    HANDLE_WORKFLOW_PREPARATION = "handle-workflow-preparation"
    INVOKE_TASK = "invoke"
    CHECK_STATUS = "status"
    HANDLE_TASK_SUCCESS = "handle-success"
    HANDLE_TASK_ERROR = "handle-error"


class DateFormat(StringEnum):
    """Constante to Manage the Date String Representation
    datetime.now(timezone.utc).isoformat(sep=sep, timespec=timespec)

    This is specially used to format dates in the pipeline
    execution history metadata table and in metadata manager class.
    """

    SEPARATOR = "T"
    TIMESPEC = "seconds"


@dataclass(frozen=True)
class OtherConstants:
    A = "A"
    B = "B"
    C = "C"
