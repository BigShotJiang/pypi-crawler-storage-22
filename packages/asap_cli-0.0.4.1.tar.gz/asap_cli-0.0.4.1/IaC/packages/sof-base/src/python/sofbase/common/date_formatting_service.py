from datetime import datetime
from typing import Any

from sofbase.common.logger import LoggingService
from sofbase.common.models.task import TaskPayload

logger = LoggingService().initialize_logger()


class DateFormattingService:
    def process_dates(self, *, payload: dict[str, Any]) -> TaskPayload:
        """process dates in the payload to normalize them according to the specified date format

        Parameters
        ----------
        payload : dict
            Payload containing the event data.

        Returns
        -------
        TaskPayload
            Returns the TaskPayload with formatted dates.

        Raises
        ------
        Exception
            Raises an exception if an error occurs during date formatting.
        """

        logger.info("Formatting Dates", extra=payload)

        task_payload = TaskPayload(**payload)

        date_format = task_payload.task.parent.execution_input.date_format
        dttm_format = task_payload.task.parent.execution_input.dttm_format
        start_date = task_payload.task.parent.execution_input.start_date
        end_date = task_payload.task.parent.execution_input.end_date
        start_dttm = task_payload.task.parent.execution_input.start_dttm
        end_dttm = task_payload.task.parent.execution_input.end_dttm

        if start_date:
            if not end_date:
                end_date = start_date
            try:
                date_obj = datetime.strptime(start_date, date_format)
                # normalize start date to YYYY-MM-DD format
                task_payload.task.parent.execution_input.start_date = date_obj.strftime("%Y-%m-%d")
            except ValueError:
                raise Exception("Error: Start Date string doesn't match the provided format")

            try:
                date_obj = datetime.strptime(end_date, date_format)
                # normalize end date to YYYY-MM-DD format
                task_payload.task.parent.execution_input.end_date = date_obj.strftime("%Y-%m-%d")
            except ValueError:
                raise Exception("Error: End Date string doesn't match the provided format")

            return task_payload
        elif start_dttm and end_dttm:
            try:
                date_obj = datetime.strptime(start_dttm, dttm_format)
                # normalize start datetime to YYYY-MM-DD HH:MM:SS format
                task_payload.task.parent.execution_input.start_dttm = date_obj.strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
                task_payload.task.parent.execution_input.start_date = date_obj.strftime("%Y-%m-%d")
                task_payload.task.parent.execution_input.start_hour = date_obj.strftime("%H")

            except ValueError:
                raise Exception("Error: Start Datetime string doesn't match the provided format")

            try:
                date_obj = datetime.strptime(end_dttm, dttm_format)
                # normalize end datetime to YYYY-MM-DD HH:MM:SS format
                task_payload.task.parent.execution_input.end_dttm = date_obj.strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
                task_payload.task.parent.execution_input.end_date = date_obj.strftime("%Y-%m-%d")
                task_payload.task.parent.execution_input.end_hour = date_obj.strftime("%H")
            except ValueError:
                raise Exception("Error: End Datetime string doesn't match the provided format")

            return task_payload
        else:
            raise Exception("Error: Start Date/Datetime or End Date/Datetime must be provided")
