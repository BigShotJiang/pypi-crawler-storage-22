class AnySofError(Exception):
    """AnySofError"""

    pass


class TaskConfigFileNotFoundError(Exception):
    """TaskConfig JSON File Not Found in Rules Path"""

    pass


class TaskRulesFileNotFoundError(Exception):
    """Task Rule File Not Found in Rules Path"""

    pass


class TaskConfigParseError(Exception):
    """TaskConfig JSON Parsing (validation) Error"""

    pass


class SQLFileConfigurationError(Exception):
    """SQLFileConfigurationError"""

    pass


class RedshiftDataProcessorNotFoundError(Exception):
    """RedshiftDataProcessorNotFoundError EntityNotFoundException"""

    pass


class RedshiftDataProcessorExecutionError(Exception):
    """RedshiftDataProcessorExecutionError Execution Error"""

    pass


class GlueDataProcessorNotFoundError(Exception):
    """GlueDataProcessorNotFoundError EntityNotFoundException"""

    pass
