from aws_lambda_powertools import Logger
from sofbase.common.constants import SOFGlobalConstantsNamespace

SOF = SOFGlobalConstantsNamespace()


class LoggingService:
    def initialize_logger(
        self, *, log_level: str | int | None = None, service: None | str = None
    ) -> Logger:

        if log_level is None:
            log_level = SOF.LOG_LEVEL
        logger = Logger(level=log_level, service=service)
        logger.setLevel(log_level)
        return logger

    @staticmethod
    def get_logger(*, log_level: str | int | None = None, service: None | str = None) -> Logger:
        if log_level is None:
            log_level = SOF.LOG_LEVEL
        logger = Logger(level=log_level, service=service)
        logger.setLevel(log_level)
        return logger
