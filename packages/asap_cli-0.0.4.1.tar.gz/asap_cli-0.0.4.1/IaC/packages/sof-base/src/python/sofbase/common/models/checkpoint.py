from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field, field_serializer
from sofbase.common.constants import DateFormat


class Checkpoint(BaseModel):
    model_config = ConfigDict(extra="forbid")
    starting_level: str | None = None
    skip_tasks: list[str]


class CheckpointControlItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    original_workflow_input: dict = Field(description="Original Execution Iput")
    data_domain_name: str = Field(description="Data Domain Name")
    data_product_name: str = Field(description="Data Product Name Name")
    data_domain_product: str = Field(description="Data Domain and Product concat")
    workflow_name: str = Field(description="Workflow Name")
    checkpoint_id: str = Field(description="Checkpoint id")
    creation_timestamp: datetime
    last_updated_timestamp: datetime
    checkpoint: Checkpoint
    ttl: Decimal

    @field_serializer("creation_timestamp")
    def serialize_creation_timestamp(self, value: datetime) -> str:
        return value.isoformat(sep=DateFormat.SEPARATOR, timespec=DateFormat.TIMESPEC)

    @field_serializer("last_updated_timestamp")
    def serialize_last_updated_timestamp(self, value: datetime) -> str:
        return value.isoformat(sep=DateFormat.SEPARATOR, timespec=DateFormat.TIMESPEC)
