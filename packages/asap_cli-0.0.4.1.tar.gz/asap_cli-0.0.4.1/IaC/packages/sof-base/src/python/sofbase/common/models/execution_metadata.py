from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, field_serializer
from sofbase.common.constants import (
    DateFormat,
    PipelineStatus,
    SubTaskType,
    TaskStatus,
    TaskType,
)


class TaskHistoryItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    task_id: None | str = None
    task_type: None | TaskType = None
    sub_task_type: None | SubTaskType = None
    status: TaskStatus
    task_issue_comment: str | None = None
    extra: None | dict = None
    timestamp: datetime
    parent_execution_id: str

    @field_serializer("timestamp")
    def serialize_timestamp(self, value: datetime) -> str:
        return value.isoformat(sep=DateFormat.SEPARATOR, timespec=DateFormat.TIMESPEC)


class PipelineExecutionMetadata(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    active: bool
    pipeline_input: dict
    data_domain_name: str
    data_sub_domain: str
    team_name: str
    data_product_name: str
    data_domain_product: str
    comment: None | str = None
    duration_in_seconds: Decimal | None = None
    execution_start_date: str
    task_history: list[TaskHistoryItem]
    pipeline: str
    status: PipelineStatus
    start_timestamp: datetime
    last_updated_timestamp: datetime
    status_last_updated_timestamp: str
    success: bool | None = None
    issue_comment: str | None = None
    extra_metadata: None | dict = None
    ttl: Decimal
    version: int

    @field_serializer("start_timestamp")
    def serialize_start_timestamp(self, value: datetime) -> str:
        return value.isoformat(sep=DateFormat.SEPARATOR, timespec=DateFormat.TIMESPEC)

    @field_serializer("last_updated_timestamp")
    def serialize_last_updated_timestamp(self, value: datetime) -> str:
        return value.isoformat(sep=DateFormat.SEPARATOR, timespec=DateFormat.TIMESPEC)
