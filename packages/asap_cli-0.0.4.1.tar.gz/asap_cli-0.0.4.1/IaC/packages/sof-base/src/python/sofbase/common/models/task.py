from datetime import datetime
from decimal import Decimal
from typing import Any, Literal, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    computed_field,
    field_serializer,
    model_validator,
)
from sofbase.common.constants import SubTaskType, TaskStatus, TaskType
from sofbase.common.models.workflow_input import WorkflowInput

GlueWorkerTypes = Literal["G.025X", "G.1X", "G.2X", "G.4X", "G.8X", "Standard", "Z.2X"]


class TaskParameters(BaseModel):
    model_config = ConfigDict(extra="ignore")
    task_id: str = Field(description="The task (step) Identifier")


class DataProcessingParameters(TaskParameters):

    workflow_name: str = Field(description="Workflow that orchestrates this task")
    task_name: str | None = Field(
        default=None,
        description="Task Name (Eg. Glue Job Name, Lambda Name, Sfn Name, Sagemaker Job Name)",
    )
    task_run_id: str | None = Field(
        default=None, description="Task Execution/Run Id (Eg. Glue Job Run Id)"
    )
    task_executor_wait_time_seconds: int = Field(default=20, gt=1, lt=8000)
    timeout_mins: int = Field(
        default=30, gt=0, description="Timeout in minutes for the task execution"
    )
    capacity_config: dict | None = None


class StepFunctionExecution(BaseModel):
    execution_id: str
    execution_input: WorkflowInput
    start_time: datetime
    role_arn: str
    redrive_count: int
    execution_name: str

    @field_serializer("start_time")
    def serialize_date(self, value: datetime) -> str:
        return str(value)

    @computed_field  # type: ignore
    @property
    def workflow_name(self) -> str:
        return str(self.execution_id.split(":")[6])


class Task(BaseModel):
    task_type: None | TaskType = None
    sub_task_type: None | SubTaskType = None
    status: TaskStatus = TaskStatus.NOT_STARTED
    error_type: str | None = Field(default=None, description="Error Type")
    error_cause: str | None = Field(default=None, description="Error Cause")
    error_extra: dict[str, Any] | None = None
    processor_result: dict[str, str | Decimal] | None = None
    parameters: DataProcessingParameters
    parent: StepFunctionExecution
    level_index: int = Field(description="Task Level Index")
    thread_index: int = Field(description="Task Thread Index")
    task_index: int = Field(description="Task Index inside a Thread")
    data_domain_name: str | None = Field(default="default", description="Data Domain Name")
    data_product_name: str | None = Field(default="default", description="Data Product Name")
    data_sub_domain: str | None = Field(default="default", description="Data subdomain Name")
    team_name: str | None = Field(default="default", description="Team Name")
    execution_environment: str = Field(description="Execution Environment")

    @model_validator(mode="after")
    def check_parameters(self) -> Self:
        parameters = self.parameters
        if not isinstance(parameters, DataProcessingParameters):
            raise ValueError("Parameters must be of type: DataProcessingParameters")

        return self


class TaskPayload(BaseModel):
    execution_id: str
    task: Task
    start_time: datetime
    role_arn: str
    redrive_count: int
    execution_name: str

    @field_serializer("start_time")
    def serialize_date(self, value: datetime) -> str:
        return str(value)
