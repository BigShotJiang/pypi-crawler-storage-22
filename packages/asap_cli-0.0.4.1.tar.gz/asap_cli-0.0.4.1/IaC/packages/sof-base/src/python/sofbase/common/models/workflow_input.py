from pydantic import BaseModel, Field, model_validator


class WorkflowInput(BaseModel):

    rules_path: str = Field(description="Data Domain Name")
    start_date: str | None = Field(default=None, description="Start Date")
    start_dttm: str | None = Field(default=None, description="Start DateTime")
    end_date: str | None = Field(default=None, description="End Date")
    end_dttm: str | None = Field(default=None, description="End DateTime")
    start_hour: str | None = Field(default=None, description="Start hour to process")
    end_hour: str | None = Field(default=None, description="End hour to process")
    additional_properties: dict | None = None
    main_execution_id: str = Field(description="Main Execution Id")
    execution_level: int = Field(description="Execution Level")
    # TODO: CGG - WOW - Review that execution depth and Workflow of Workflows continues to work correctly.
    execution_depth: int = Field(default=0, description="Execution Depth")
    dynamic_rules: bool = Field(
        default=False,
        description="if true, rules are read from folder structure in artifacts bucket, when the workflow name contains dots, they are replaced by slashes",
    )
    date_format: str = Field(
        default="%Y-%m-%d",
        description="Date format to use for start and end date",
    )
    dttm_format: str = Field(
        default="%Y-%m-%d %H:%M:%S",
        description="Dttm format to use for start and end dttm",
    )

    @model_validator(mode="after")
    def check_start_fields(self) -> "WorkflowInput":
        if self.start_date is None and self.start_dttm is None:
            raise ValueError("At least one of start_date or start_dttm must be provided")
        return self
