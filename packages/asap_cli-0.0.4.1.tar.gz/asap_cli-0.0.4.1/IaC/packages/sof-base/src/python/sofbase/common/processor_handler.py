from abc import ABC, abstractmethod
from typing import Any

from sofbase.common.models.task import TaskPayload


class TaskProcessorHandler(ABC):
    """
    Data Processor Interface. Concrete DataProcessor should implement a
    task processing strategy.
    """

    # TODO: DIEGO - Medium: Config File can be None? Some Processor Handlers don't need config files (subworkflows)
    def __init__(
        self,
        *,
        log_level: str = "INFO",
        config_file: dict,
    ) -> None:

        self.log_level = log_level
        self.config_file = config_file
        # TODO: DIEGO - Low: Manage exception if Config File is invalid (None?) or contains Incorrect Schema

    @abstractmethod
    def invoke_task(self, *, payload: dict[str, Any]) -> TaskPayload:
        pass

    @abstractmethod
    def get_task_status(self, *, payload: dict[str, Any]) -> TaskPayload:
        pass
