from typing import Any

from sofbase.common.constants import SubTaskType
from sofbase.common.logger import LoggingService
from sofbase.common.models.task import TaskPayload
from sofbase.common.processor_handler import TaskProcessorHandler
from sofbase.processor_handler.dummy import DummyDataProcessorHandler
from sofbase.processor_handler.glue import GlueDataProcessorHandler
from sofbase.processor_handler.redshift import RedshiftDataProcessorHandler
from sofbase.processor_handler.step_functions import StepFunctionsTaskProcessorHandler

logger = LoggingService().initialize_logger()


class TaskProcessingService:
    def select_processing_strategy(
        self, *, payload: dict[str, Any], config_file: dict
    ) -> TaskProcessorHandler:
        """Selects the correct Task Processing Strategy

        Parameters
        ----------
        payload : dict
            Payload containing the event data.

        Returns
        -------
        TaskProcessor
            Returns the concrete TaskProcessor strategy.

        Raises
        ------
        Exception
            Raises an exception if no conrete strategy can be found.
        """

        logger.info("Selecting Processing Strategy", extra=payload)

        task_payload = TaskPayload(**payload)

        sub_task_type_value = None

        if task_payload.task.sub_task_type is not None:
            sub_task_type_value = task_payload.task.sub_task_type.value

        if sub_task_type_value == SubTaskType.GLUE_DATA_PROCESSOR.value:
            logger.info(
                {
                    "operation": "strategy_processor_selection",
                    "selected_strategy": SubTaskType.GLUE_DATA_PROCESSOR,
                },
                extra=payload,
            )
            return GlueDataProcessorHandler(config_file=config_file)
        if sub_task_type_value == SubTaskType.DUMMY_DATA_PROCESSOR.value:
            logger.info(
                {
                    "operation": "strategy_processor_selection",
                    "selected_strategy": SubTaskType.DUMMY_DATA_PROCESSOR,
                },
                extra=payload,
            )
            return DummyDataProcessorHandler(config_file=config_file)
        if sub_task_type_value == SubTaskType.STEP_FUNCTIONS_PROCESSOR.value:
            logger.info(
                {
                    "operation": "strategy_processor_selection",
                    "selected_strategy": SubTaskType.STEP_FUNCTIONS_PROCESSOR,
                },
                extra=payload,
            )
            return StepFunctionsTaskProcessorHandler(config_file=config_file)
        if sub_task_type_value == SubTaskType.REDSHIFT_DATA_PROCESSOR.value:
            logger.info(
                {
                    "operation": "strategy_processor_selection",
                    "selected_strategy": SubTaskType.REDSHIFT_DATA_PROCESSOR,
                },
                extra=payload,
            )
            return RedshiftDataProcessorHandler(config_file=config_file)

        if sub_task_type_value is None:
            raise Exception("sub_task_type_value is None")

        raise Exception("No valid data processing sub task type")
