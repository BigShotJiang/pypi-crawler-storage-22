# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import itertools
import json
from datetime import datetime, timedelta
from decimal import Decimal
from typing import TYPE_CHECKING, Any, List

import boto3
from sofbase.common.constants import DateFormat
from sofbase.common.exceptions import (
    SQLFileConfigurationError,
    TaskConfigFileNotFoundError,
    TaskRulesFileNotFoundError,
)

if TYPE_CHECKING:
    from mypy_boto3_dynamodb import DynamoDBClient
    from mypy_boto3_s3 import S3Client, S3ServiceResource
    from mypy_boto3_secretsmanager import SecretsManagerClient
    from mypy_boto3_ssm import SSMClient

ssm_client: "SSMClient" = boto3.client("ssm")
s3_client: "S3Client" = boto3.client("s3")
s3_resource: "S3ServiceResource" = boto3.resource("s3")
dynamo_client: "DynamoDBClient" = boto3.client("dynamodb")
secrets_client: "SecretsManagerClient" = boto3.client("secretsmanager")
dynamodb = boto3.resource("dynamodb")


class GeneralEncoder(json.JSONEncoder):
    """
    General Encoder to serialize Decimal objects.
    """

    def default(self, o: Any) -> str | Any:
        if isinstance(o, Decimal):
            return str(o)
        if isinstance(o, datetime):
            return o.isoformat(sep=DateFormat.SEPARATOR, timespec=DateFormat.TIMESPEC)
        return super().default(o)


class DecimalEncoder(json.JSONEncoder):
    """
    Decimal Encoder to serialize Decimal objects.
    """

    def default(self, o: Any) -> str | Any:
        if isinstance(o, Decimal):
            return str(o)
        return super().default(o)


def get_json_config_file(
    *,
    rules_path: str,
    workflow_name: str,
    task_id: str,
    artifacts_bucket: str,
    dynamic_mode: bool,
) -> dict[str, Any]:
    """
    Method to obatin JSON configuration file with parameters that are used in data transformations

    Parameters
    ----------
    rules_path: str - path in s3 artifacts bucket where the rules json file lives
    workflow_name: str - name of the workflow name, normally step functions workflow
    task_id: str - name of the step in the step functions workflow
    artifacts_bucket: str - name of the artifacts bucket

    Returns
    -------
    config file content from s3 location.

    """
    try:
        if dynamic_mode:
            workflow_name = workflow_name.replace(".", "/")
        s3_key = f"{rules_path}/{workflow_name}/{task_id}.json"
        obj = s3_client.get_object(Bucket=artifacts_bucket, Key=s3_key)
        config_file: dict[str, Any] = json.loads(obj["Body"].read().decode("utf-8"))
        return config_file

    except s3_client.exceptions.NoSuchKey as e:

        raise TaskConfigFileNotFoundError(
            f"{task_id}.sql not found in {rules_path}/{workflow_name}, {e}"
        )


def get_rules_file_content(
    *, rules_path: str, workflow_name: str, task_id: str, artifacts_bucket: str, dynamic_mode: bool
) -> str:
    """

    It returns a rules file content string stored in Artifactory Bucket
    ( sql or custom python code )

    Parameters
    ----------
    None

    Returns
    -------
    rules file content from s3 location.

    """
    try:
        if dynamic_mode:
            workflow_name = workflow_name.replace(".", "/")
        file_key = f"{rules_path}/{workflow_name}/{task_id}.sql"
        s3_object_sql = s3_resource.Object(artifacts_bucket, file_key)
        s3_string_sql = s3_object_sql.get()["Body"].read().decode("utf-8")
        s3_string_sql = s3_string_sql.replace("\t", "    ")
        if "$SOURCE_DATABASE" not in s3_string_sql:
            raise SQLFileConfigurationError(
                f"SQL file {task_id}.sql does not contain $SOURCE_DATABASE variable in {file_key}"
            )
        return s3_string_sql
    except s3_resource.meta.client.exceptions.NoSuchKey:
        try:
            if dynamic_mode:
                workflow_name = workflow_name.replace(".", "/")
            file_key = f"{rules_path}/{workflow_name}/{task_id}.py"
            python_object = s3_resource.Object(artifacts_bucket, file_key)
            python_object_content = python_object.get()["Body"].read().decode("utf-8")
            return python_object_content
        except s3_resource.meta.client.exceptions.NoSuchKey as e:
            raise TaskRulesFileNotFoundError(
                f"{task_id}.sql|py not found in {rules_path}/{workflow_name}, {e}"
            )


def replace_variables(
    *,
    start_dt: str,
    end_dt: str,
    file_content: str,
    sources_dictionary: dict,
    extras_dictionary: dict,
    time_condition: str,
    target_database: str = "",
    target_table: str = "",
    start_hour: str = "",
    end_hour: str = "",
    start_dttm: str = "",
    end_dttm: str = "",
) -> str:
    """
    It replaces given parameters in a content file.
    for example in a SQL file it will replace some wildcards like $START_DATE

    Parameters
    ----------
    start_dt: str - initial date for data processing
    end_dt: str - final date for data processing
    sources_dictionary: dict -  dictionary with the list of source databases involved in the query.
          example: {'SOURCE_DATABASE': 'test_sales_raw', 'SOURCE_DATABASE_1': 'test_sales_raw2'}
    time_condition: str - perdicate of the sql query for time related fields

    Returns
    ----------
    file content replaced

    """
    # Replace variables in sql query
    sql: str = file_content
    sql = sql.replace("$START_DATE", start_dt)
    sql = sql.replace("$END_DATE", end_dt)
    start_date_split = start_dt.split("-")
    start_year_str = start_date_split[0]
    start_month_str = start_date_split[1]
    start_day_str = start_date_split[2]

    end_date_split = end_dt.split("-")
    end_year_str = end_date_split[0]
    end_month_str = end_date_split[1]
    end_day_str = end_date_split[2]
    sql = sql.replace("$START_YEAR", start_year_str)
    sql = sql.replace("$START_MONTH", start_month_str)
    sql = sql.replace("$START_DAY", start_day_str)
    sql = sql.replace("$END_YEAR", end_year_str)
    sql = sql.replace("$END_MONTH", end_month_str)
    sql = sql.replace("$END_DAY", end_day_str)
    sql = sql.replace("$START_HOUR", start_hour)
    sql = sql.replace("$END_HOUR", end_hour)
    sql = sql.replace("$START_DTTM", start_dttm)
    sql = sql.replace("$END_DTTM", end_dttm)

    if time_condition:
        sql = sql.replace("$TIME_CONDITION", time_condition)
    # sources database replacement
    for value in sources_dictionary.keys():
        if value == "SOURCE_DATABASE":
            sql = sql.replace("$SOURCE_DATABASE.", sources_dictionary[value] + ".")
        else:
            sql = sql.replace(
                "$SOURCE_DATABASE_" + value.split("_")[-1] + ".", sources_dictionary[value] + "."
            )
    # extras replacement
    for value in extras_dictionary.keys():
        sql = sql.replace("$" + str(value).upper(), extras_dictionary[value])
    # target database replacement
    sql = sql.replace("$TARGET_DATABASE", target_database)
    sql = sql.replace("$TARGET_TABLE", target_table)
    return sql


def get_source_tables(*, file_content: str, sources_dictionary: dict) -> list[str]:
    """
    It gets a list with the source tables involved in a given sql query.

    Parameters
    ----------
    file_content: str - sql file to look for "$SOURCE_DATABASE" marks
    sources_dictionary: dict - dictionary with the list of source databases involved in the query.
            example: {'SOURCE_DATABASE': 'test_sales_raw', 'SOURCE_DATABASE_1': 'test_sales_raw2'}

    Returns
    ----------
    list with source tables resolved

    """
    tables = []
    lines = file_content.splitlines()
    for line in lines:
        line = line.replace("\n", "")
        words_in_line = line.split(" ")
        for word in words_in_line:
            final_word = word.strip()
            if final_word.startswith("$SOURCE_DATABASE"):
                source_database = sources_dictionary.get(final_word.split(".")[0].replace("$", ""))
                table = final_word.split(".")[1]
                tables.append(str(source_database) + "." + table)
    tables = eliminate_duplicates(tables)
    return tables


def eliminate_duplicates(list_to_verify: list[str]) -> list[str]:
    """
    method to eliminate string duplicates in a list

    Parameters
    ----------
    list_to_verify: list[str] - list provided to eliminate duplicates

    Returns
    ----------
    list of strings with no duplicated elements

    """
    return list(dict.fromkeys(list_to_verify))


def construct_query_predicate(
    *,
    table_name: str,
    date_format: str,
    start_date: str,
    end_date: str,
    partition_dt_field: str,
    partition_year_field: str,
    partition_month_field: str,
    partition_day_field: str,
    extra_parameters: dict,
    target_partitions: str,
) -> str:
    """
    method to construct query predicate given some time fields and table name

    Parameters
    ----------
    table_name: str - table for which the query predicate is created
    date_format: str - format of the dates in python format involved in
        the query predicate ( ej: Y%-m%-d% )
    start_date: str - start date of the query
    end_date: str - end date of the query
    partition_dt_field: str - name of the date partition field if exists
    partition_year_field: str - name of the year partition field if exists
    partition_month_field: str - name of the month partition field if exists
    partition_day_field: str - name of the day partition field if exists

    Returns
    ----------
    string containing the query predicate

    """
    predicate = " from " + table_name
    if (
        partition_dt_field != ""
        or partition_year_field != ""
        or partition_month_field != ""
        or partition_day_field != ""
    ):
        predicate += " where " + get_time_condition(
            date_format=date_format,
            start_date=start_date,
            end_date=end_date,
            partition_dt_field=partition_dt_field,
            partition_year_field=partition_year_field,
            partition_month_field=partition_month_field,
            partition_day_field=partition_day_field,
        )
    # adding extra parameters to the predicate ( by now only supporting string values )
    if target_partitions != "":
        for partition in target_partitions.split(","):  # type: ignore
            for key in extra_parameters.keys():
                if partition.lower() == key.lower():
                    predicate += " AND " + partition.lower() + " = '" + extra_parameters[key] + "'"

    return predicate


def get_time_condition(
    *,
    date_format: str,
    start_date: str,
    end_date: str,
    partition_dt_field: str,
    partition_year_field: str,
    partition_month_field: str,
    partition_day_field: str,
) -> str:
    """
    method to get time conditions based on date ranges

    Parameters
    ----------
    date_format: str - format of the dates in python format involved in
        the query predicate ( ej: Y%-m%-d% )
    start_date: str - start date of the query
    end_date: str - end date of the query
    partition_dt_field: str - name of the date partition field if exists
    partition_year_field: str - name of the year partition field if exists
    partition_month_field: str - name of the month partition field if exists
    partition_day_field: str - name of the day partition field if exists

    Returns
    ----------
    string containing the time condition based on given time field parameters

    """
    condition = "( "
    parameter_dates = get_date_range(
        date_format=date_format, start_date=start_date, end_date=end_date
    )
    dates_to_process = eliminate_duplicates(parameter_dates)
    if partition_year_field != "" or partition_month_field != "" or partition_day_field != "":
        conditions_array = []
        for date in dates_to_process:
            year = date.split("-")[0]
            month = date.split("-")[1]
            day = date.split("-")[2]
            inner_condition = "( "
            if partition_year_field != "":
                inner_condition += partition_year_field + " = '" + year + "' AND "
            if partition_month_field != "":
                inner_condition += partition_month_field + " = '" + month + "' AND "
            if partition_day_field != "":
                inner_condition += partition_day_field + " = '" + day + "' AND "
            inner_condition = replace_last_occurrence(
                text=inner_condition, old="' AND ", new="' ) OR "
            )
            conditions_array.append(inner_condition)
        conditions_array = eliminate_duplicates(conditions_array)
        for inner_condition in conditions_array:
            condition += inner_condition

    elif partition_dt_field != "":
        for date in dates_to_process:
            condition += "( " + partition_dt_field + " = '" + date + "' ) OR "
    else:
        return ""  # no time condition
    condition = condition[:-3]
    condition += ")"
    return condition


def replace_last_occurrence(*, text: str, old: str, new: str) -> str:
    """
    method to replace last occurence in string

    Parameters
    ----------
    text:str
    old:str
    new:str

    Returns
    ----------
    string with the replaced result

    """
    index = text.rfind(old)  # Find the last occurrence
    if index == -1:
        return text  # If not found, return the original string
    return text[:index] + new + text[index + len(old) :]


def get_date_range(*, date_format: str, start_date: str, end_date: str) -> list[str]:
    """
    method to get date ranges

    Parameters
    ----------
    date_format: str - format of the dates in python format involved in the
        query predicate ( ej: Y%-m%-d% )
    start_date: str - start date of the query
    end_date: str - end date of the query

    Returns
    ----------
    list with the dates between the start and end dates received as parameters

    """
    dates = []
    start_date = datetime.strptime(start_date, date_format)  # type: ignore
    end_date = datetime.strptime(end_date, date_format)  # type: ignore
    for n in range(int((end_date - start_date).days) + 1):  # type: ignore
        generated_date = start_date + timedelta(n)  # type: ignore
        generated_date_str = generated_date.strftime(date_format)
        dates.append(generated_date_str)
    return dates


def return_ssm_param(*, ssm_key: str) -> str:
    """
    Returns the value of an SSM para,meter stored in Parameter Store

    Parameters
    ----------
    ssm_key :str - name of the ssm parameter to query its value

    Returns
    ----------
    str: the value of the ssm parameter in the aws account

    """

    ssm_param = ssm_client.get_parameter(Name=ssm_key, WithDecryption=True)
    ssm_value = ssm_param["Parameter"]["Value"]
    return ssm_value


def return_secret_value(*, secret_key: str) -> Any:
    """
    Fetches a secret value from AWS Secrets Manager.

    Parameters
    ----------
    secret_key :str - name of the secret parameter to query its value

    Returns
    ----------
    the value of the secret parameter in the aws account

    """
    response = secrets_client.get_secret_value(SecretId=secret_key)
    # Check if the secret is in plain text or JSON
    if "SecretString" in response:
        return json.loads(response["SecretString"])
    else:
        return response["SecretBinary"]


def return_secret_arn(*, secret_key: str) -> Any:
    """
    Fetches a secret arn from AWS Secrets Manager given secret name.

    Parameters
    ----------
    secret_key :str - name of the secret parameter to query its ARN

    Returns
    ----------
    the value of the secret ARN

    """
    response = secrets_client.get_secret_value(SecretId=secret_key)
    return response["ARN"]


def get_record_from_dynamodb(
    *,
    table_name: str,
    partition_key: str,
    partition_value: str,
    sort_key_name: str | None = None,
    sort_key_value: str | None = None,
    consistent_read: bool = True,
) -> dict[str, Any]:
    """
    Retrieves a record from DynamoDB using the specified table name,
        partition key, and partition value.

    Parameters
    ----------
    table_name : str
        DynamoDB Table Name
    partition_key : str
        Partition Key Name
    partition_value : str
        Partition Value
    sort_key_name : str
        Sort Key Name
    sort_key_value : str
        Sort Key Value
    consistent_read : True|False, defaults to True
        Determines the read consistency model: If set to true, then
        the operation uses strongly consistent reads; otherwise, the operation
        uses eventually consistent reads.


    Returns
    -------
    dict
        A dictionary containing the record content, or an empty
        dictionary if the record is not found.

    Raises
    -------
    ClientError if keys names are incorrect
    ResourceNotFoundException if table_name is not found
    """

    table = dynamodb.Table(table_name)
    response = table.get_item(
        Key={partition_key: partition_value},
        ConsistentRead=consistent_read,
    )

    try:
        return response["Item"]
    except KeyError:
        return {}


def combination(*, word: str) -> List[str]:
    """
    It creates a list with all the combiantion of upper and lower letter for typos
    in booleans variables inside configuration JSON file

    Parameters
    ----------
    word :str -  word to get possible combinations

    Returns
    ----------
    str: list with the all possible combinations

    """

    result = map("".join, itertools.product(*((c.lower(), c.upper()) for c in word)))
    return list(result)


def to_camel_case(*, snake_str: str) -> str:
    """
    It converts a snake case string into a camel case string

    Parameters
    ----------
    snake_str :str -  snake case word

    Returns
    ----------
    str: camel case word converted

    """
    return "".join(x.capitalize() for x in snake_str.lower().split("_"))
