from typing import Any

from sofbase.common.constants import TaskStatus
from sofbase.common.logger import LoggingService
from sofbase.common.models.task import TaskPayload
from sofbase.common.processor_handler import TaskProcessorHandler

logger = LoggingService().initialize_logger()


class AthenaDataProcessorHandler(TaskProcessorHandler):

    def invoke_task(self, *, payload: dict[str, Any]) -> TaskPayload:

        task_payload = TaskPayload(**payload)

        logger.info("Starting AthenaDataProcessor Invoke with event", extra=payload)

        task_payload.task.status = TaskStatus.RUNNING

        logger.info(
            "Finished AthenaDataProcessor Invoke with event", extra=task_payload.model_dump()
        )

        return task_payload

    def get_task_status(self, *, payload: dict[str, Any]) -> TaskPayload:
        """Docstring for get_task_status

        :param self: Description
        :type self:
        :param payload: Description
        :type payload:"""

        task_payload = TaskPayload(**payload)

        logger.info("Starting AthenaDataProcessor Invoke with event", extra=payload)

        task_payload.task.status = TaskStatus.SUCCEEDED

        logger.info(
            "Finished AthenaDataProcessor Invoke with event", extra=task_payload.model_dump()
        )

        return task_payload
