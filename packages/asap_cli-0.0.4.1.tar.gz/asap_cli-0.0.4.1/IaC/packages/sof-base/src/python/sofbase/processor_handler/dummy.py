import uuid
from decimal import Decimal
from typing import Any

from sofbase.common.constants import TaskStatus
from sofbase.common.exceptions import AnySofError
from sofbase.common.logger import LoggingService
from sofbase.common.models.task import TaskPayload
from sofbase.common.processor_handler import TaskProcessorHandler

logger = LoggingService().initialize_logger()


class DummyDataProcessorHandler(TaskProcessorHandler):

    def invoke_task(self, *, payload: dict[str, Any]) -> TaskPayload:

        task_payload = TaskPayload(**payload)

        logger.info("Starting DummyDataProcessor Invoke with event", extra=payload)

        task_payload.task.status = TaskStatus.RUNNING
        task_payload.task.parameters.task_name = "Dummy_job_name_added_during_invoke"
        task_payload.task.parameters.task_run_id = "dummy_run_id_123456789"

        logger.info(
            "Finished DummyDataProcessor Invoke with event:", extra=task_payload.model_dump()
        )

        return task_payload

    def get_task_status(self, *, payload: dict[str, Any]) -> TaskPayload:
        """Docstring for get_task_status

        :param self: Description
        :type self:
        :param payload: Description
        :type payload:"""

        task_payload = TaskPayload(**payload)

        logger.info(
            {
                "operation": "dummy_get_task_status",
                "payload_dict": payload,
                "task_payload": task_payload,
            }
        )

        task_payload.task.status = TaskStatus.SUCCEEDED

        task_payload.task.processor_result = {
            "dpu_seconds_dummy": Decimal(float(123.1)).quantize((Decimal("1.000"))),
            "execution_time_dummy": Decimal(float(60.1)).quantize((Decimal("1.000"))),
            "worker_type_dummy": "G.2X",
        }

        if task_payload.task.parent.execution_input.additional_properties is not None:
            always_fail = task_payload.task.parent.execution_input.additional_properties.get(
                "always_fail", None
            )

            logger.error(
                "Error in DummyDataProcessor Invoke with event", extra=task_payload.model_dump()
            )
            logger.error(always_fail)

            if always_fail is True and task_payload.task.parameters.task_id == "dummy_taskX":
                task_payload.task.status = TaskStatus.FAILED
                task_payload.task.error_type = "DummyDataProcessorError"
                task_payload.task.error_cause = "Dummy Task Error caused by AlwaysFailError"

                error_extra = {
                    "failedDummyTaskName": task_payload.task.parameters.task_name,
                }

                error_extra["failedDummyRunLogGroupName"] = f"DummyLogGroupName-{str(uuid.uuid4())}"

                task_payload.task.error_extra = error_extra

            if always_fail is False and task_payload.task.parameters.task_id == "dummy_taskX":
                raise AnySofError("If something can go wrong, it will go wrong")

        logger.info(
            "Finished DummyDataProcessor Invoke with event", extra=task_payload.model_dump()
        )

        return task_payload
