from typing import Any

from sofbase.common.constants import TaskStatus
from sofbase.common.logger import LoggingService
from sofbase.common.processor_handler import TaskPayload, TaskProcessorHandler

logger = LoggingService().initialize_logger()


class EMRDataProcessorHandler(TaskProcessorHandler):

    def invoke_task(self, *, payload: dict[str, Any]) -> TaskPayload:

        task_payload = TaskPayload(**payload)

        logger.info("Starting EMRDataProcessor Invoke with event", extra=payload)

        task_payload.task.status = TaskStatus.RUNNING

        logger.info("Finished EMRDataProcessor Invoke with event", extra=task_payload.model_dump())

        return task_payload

    def get_task_status(self, *, payload: dict[str, Any]) -> TaskPayload:

        task_payload = TaskPayload(**payload)

        logger.info("Starting EMRDataProcessor Invoke with event", extra=payload)

        task_payload.task.status = TaskStatus.SUCCEEDED

        logger.info("Finished EMRDataProcessor Invoke with event", extra=task_payload.model_dump())

        return task_payload
