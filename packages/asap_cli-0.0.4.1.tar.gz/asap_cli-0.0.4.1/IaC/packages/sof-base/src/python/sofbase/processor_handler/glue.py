import json
from decimal import Decimal
from typing import Any

import boto3
from sofbase.common.constants import SOFGlobalConstantsNamespace, TaskStatus
from sofbase.common.exceptions import GlueDataProcessorNotFoundError
from sofbase.common.logger import LoggingService
from sofbase.common.models.task import DataProcessingParameters, TaskPayload
from sofbase.common.processor_handler import TaskProcessorHandler
from sofbase.common.utils.commons import return_ssm_param

glue_client = boto3.client("glue")
s3_client = boto3.client("s3")
ssm_client = boto3.client("ssm")


SOF = SOFGlobalConstantsNamespace()
logger = LoggingService().initialize_logger(service="GlueDataProcessorHandler")


class GlueDataProcessorHandler(TaskProcessorHandler):

    def invoke_task(self, *, payload: dict[str, Any]) -> TaskPayload:

        task_payload = TaskPayload(**payload)

        logger.info(
            {
                "operation": "PreGlueDataProcessorHandlerInvoke",
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_payload": task_payload.model_dump(),
                "payload": payload,
            }
        )

        if isinstance(task_payload.task.parameters, DataProcessingParameters):

            try:
                result = self.start_glue_job(task_payload=task_payload)
            except glue_client.exceptions.EntityNotFoundException as e:

                logger.error(
                    {
                        "operation": "StartGlueDataProcessorHandlerInvoke",
                        "error_type": "GlueDataProcessorNotFoundError",
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_payload": task_payload.model_dump(),
                        "payload": payload,
                    }
                )

                raise GlueDataProcessorNotFoundError(
                    (
                        "GlueDataProcessorNotFoundError for "
                        f"Task Id: {task_payload.task.parameters.task_id}"
                        f"Rules Path: {task_payload.task.parent.execution_input.rules_path}, {e}"
                    )
                )

            task_payload.task.parameters = result
            task_payload.task.status = TaskStatus.STARTING

        else:
            logger.error(
                {
                    "error_type": "GlueProcessorWrongParametersError",
                    "task_payload": task_payload.model_dump(),
                    "payload": payload,
                }
            )
            raise Exception("GlueProcessorWrongParametersError")

        logger.info(
            {
                "operation": "PostGlueDataProcessorHandlerInvoke",
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_payload": task_payload.model_dump(),
                "payload": payload,
            }
        )

        return task_payload

    def get_task_status(self, *, payload: dict[str, Any]) -> TaskPayload:

        task_payload = TaskPayload(**payload)

        logger.info(
            {
                "operation": "PreGlueDataProcessorHandlerGetStatus",
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_payload": task_payload.model_dump(),
                "payload": payload,
            }
        )

        if isinstance(task_payload.task.parameters, DataProcessingParameters):

            # TODO: CGG - GLUEH - Medium - Exceptions: Add Custom Exception
            if task_payload.task.parameters.task_name is None:
                logger.error(
                    {
                        "error_type": "NoneTaskNameError",
                        "task_payload": task_payload.model_dump(),
                        "payload": payload,
                    }
                )
                raise Exception(f"Trying to get Status from a null job name {task_payload}")

            if task_payload.task.parameters.task_run_id is not None:
                glue_job_current_status = glue_client.get_job_run(
                    JobName=task_payload.task.parameters.task_name,
                    RunId=task_payload.task.parameters.task_run_id,
                )

                if glue_job_current_status["JobRun"]["JobRunState"] == "RUNNING":
                    task_payload.task.status = TaskStatus.RUNNING
                elif glue_job_current_status["JobRun"]["JobRunState"] == "SUCCEEDED":
                    task_payload.task.status = TaskStatus.SUCCEEDED
                elif glue_job_current_status["JobRun"]["JobRunState"] == "STARTING":
                    task_payload.task.status = TaskStatus.STARTING
                elif glue_job_current_status["JobRun"]["JobRunState"] == "WAITING":
                    task_payload.task.status = TaskStatus.WAITING
                else:
                    task_payload.task.status = TaskStatus.FAILED

            else:
                logger.error(
                    {
                        "error_type": "NoneTaskRunIdError",
                        "task_payload": task_payload.model_dump(),
                        "payload": payload,
                    }
                )
                raise Exception("Trying to check job status with a None job type id")

            if task_payload.task.status == TaskStatus.FAILED:

                task_payload.task.error_type = "GlueDataProcessorError"
                task_payload.task.error_cause = glue_job_current_status["JobRun"].get(
                    "ErrorMessage", ""
                )

                job_run_log_group = glue_job_current_status["JobRun"].get("LogGroupName", None)

                error_extra = {
                    "failedGlueJobName": task_payload.task.parameters.task_name,
                }

                if job_run_log_group is not None:
                    error_extra["failedGlueJobRunLogGroupName"] = job_run_log_group

                task_payload.task.error_extra = error_extra

        else:
            logger.error(
                {
                    "error_type": "GlueProcessorWrongParametersError",
                    "task_payload": task_payload.model_dump(),
                    "payload": payload,
                }
            )
            # TODO: CGG - GLUEH - Exceptions: Add Custom Exception
            raise Exception("GlueProcessor Needs DataProcessingParameters")

        dpu_seconds = glue_job_current_status["JobRun"].get("DPUSeconds", None)
        max_capacity = glue_job_current_status["JobRun"]["MaxCapacity"]
        execution_time_secs = glue_job_current_status["JobRun"]["ExecutionTime"]
        processor_result = {
            "execution_time_secs": execution_time_secs,
            "max_capacity": Decimal(max_capacity).quantize((Decimal("1.0"))),
        }

        if dpu_seconds is not None:
            processor_result["dpu_seconds"] = Decimal(dpu_seconds).quantize((Decimal("1.000")))
        else:
            processor_result["dpu_seconds"] = Decimal(max_capacity * execution_time_secs).quantize(
                (Decimal("1.000"))
            )

        task_payload.task.processor_result = processor_result

        logger.info(
            {
                "operation": "PostGlueDataProcessorHandlerGetStatus",
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_payload": task_payload.model_dump(),
                "payload": payload,
            }
        )

        return task_payload

    def start_glue_job(
        self,
        *,
        task_payload: TaskPayload,
    ) -> DataProcessingParameters:

        logger.info(
            {
                "operation": "PreGlueDataProcessorHandlerStartJob",
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_payload": task_payload.model_dump(),
                "task_config_file": self.config_file,
            }
        )

        glue_parameters = task_payload.task.parent.execution_input
        glue_task_parameters = task_payload.task.parameters

        number_of_workers, worker_type, executor_cores, timeout = self.get_capacity_config(
            glue_parameters=glue_task_parameters, config_file=self.config_file
        )

        glue_job_arguments = {
            "--WORKFLOW_NAME": glue_task_parameters.workflow_name,
            "--STEP_NAME": glue_task_parameters.task_id,
            "--RULES_PATH": glue_parameters.rules_path,
            "--START_DT": glue_parameters.start_date,
            "--END_DT": glue_parameters.end_date,
            "--DYNAMIC_RULES": str(glue_parameters.dynamic_rules).lower(),
        }

        if glue_parameters.start_dttm:
            glue_job_arguments["--START_DTTM"] = glue_parameters.start_dttm
        if glue_parameters.end_dttm:
            glue_job_arguments["--END_DTTM"] = glue_parameters.end_dttm
        if glue_parameters.start_hour:
            glue_job_arguments["--START_HOUR"] = glue_parameters.start_hour
        if glue_parameters.end_hour:
            glue_job_arguments["--END_HOUR"] = glue_parameters.end_hour
        if executor_cores:
            glue_job_arguments["--executor-cores"] = str(executor_cores)

        if (
            self.config_file["ProcessingFramework"]["Parameters"].get(
                "GLUE_CATALOG_WAREHOUSE_S3_BUCKET_SSM_PARAMETER", None
            )
            is not None
            and len(
                self.config_file["ProcessingFramework"]["Parameters"][
                    "GLUE_CATALOG_WAREHOUSE_S3_BUCKET_SSM_PARAMETER"
                ]
            )
            > 0
        ):
            glue_job_arguments["--conf"] = (
                "spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions"
            )
            glue_job_arguments["--datalake-formats"] = "iceberg"

        if glue_parameters.additional_properties:
            # TODO: CGG - GLUEH - High: Let's review together the usage of Additional Properties (it has more then EXTRAS)
            glue_job_arguments["--EXTRAS"] = json.dumps(glue_parameters.additional_properties)

        external_variables = {
            "workflow_execution_id": glue_parameters.main_execution_id,
            "level_index": task_payload.task.level_index,
            "thread_index": task_payload.task.thread_index,
            "task_index": task_payload.task.task_index,
        }
        glue_job_arguments["--LOG_VARIABLES"] = json.dumps(external_variables)
        glue_job_to_invoke = return_ssm_param(
            ssm_key=self.config_file["ProcessingFramework"]["Parameters"]["JOB_NAME_SSM_PARAM"]
        )
        job_response = glue_client.start_job_run(
            JobName=glue_job_to_invoke,
            Arguments=glue_job_arguments,
            WorkerType=worker_type,  # type: ignore
            NumberOfWorkers=int(number_of_workers),
            Timeout=timeout,
        )

        glue_task_parameters.task_name = glue_job_to_invoke
        glue_task_parameters.task_run_id = job_response["JobRunId"]

        logger.info(
            {
                "operation": "PostGlueDataProcessorHandlerStartJob",
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_payload": task_payload.model_dump(),
                "task_config_file": self.config_file,
                "glue_job_name": glue_task_parameters.task_name,
                "glue_job_run_id": glue_task_parameters.task_run_id,
                "task_id": glue_task_parameters.task_id,
            }
        )

        return glue_task_parameters

    def get_capacity_config(
        self, glue_parameters: DataProcessingParameters, config_file: dict[str, Any]
    ) -> tuple[int, str, int, int]:
        """
        it expects:
        1. from dynamodb pipeline registry table, a dictionary like:
        {
            capacity_config: {
                  "etl_step_1": {"SPARK_NUM_WORKERS": 2, "GLUE_WORKER_TYPE": "G.2X", "SPARK_EXECUTOR_CORES": 2, "SPARK_JOB_TIMEOUT": 120}
            }
        }
        if not found, it takes from the json config file for the step:
        {
            "ProcessingFramework": {
                "Parameters": {
                    "SPARK_NUM_WORKERS": 2,
                    "GLUE_WORKER_TYPE": "G.2X",
                    "SPARK_EXECUTOR_CORES": 2,
                    "SPARK_JOB_TIMEOUT": 120
                }
            }
        }
        if not found, it defaults to:
        {
            "number_of_workers": 2,
            "worker_type": "G.2X",
            "executor_cores": None
        Returns the number of workers, worker type, and executor cores for the Glue job from the input configuration.
        """
        default_number_of_workers = 2
        default_worker_type_str = "G.2X"
        default_executor_cores = 2
        default_timeout = 120
        if (
            glue_parameters.capacity_config is not None
            and glue_parameters.capacity_config.get(glue_parameters.task_id) is not None
        ):
            capacity_config_for_task = glue_parameters.capacity_config[glue_parameters.task_id]
            number_of_workers = capacity_config_for_task.get(
                "SPARK_NUM_WORKERS", default_number_of_workers
            )
            worker_type = capacity_config_for_task.get("GLUE_WORKER_TYPE", default_worker_type_str)
            executor_cores = capacity_config_for_task.get(
                "SPARK_EXECUTOR_CORES", default_executor_cores
            )
            timeout = capacity_config_for_task.get("SPARK_JOB_TIMEOUT", default_timeout)

        else:

            parameters = config_file.get("ProcessingFramework", {}).get("Parameters", {})
            number_of_workers = parameters.get("SPARK_NUM_WORKERS", default_number_of_workers)
            worker_type = parameters.get("GLUE_WORKER_TYPE", default_worker_type_str)
            executor_cores = parameters.get("SPARK_EXECUTOR_CORES", default_executor_cores)
            timeout = parameters.get("SPARK_JOB_TIMEOUT", default_timeout)
        return number_of_workers, worker_type, executor_cores, timeout
