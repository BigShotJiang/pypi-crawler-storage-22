from typing import Any

import boto3
from sofbase.common.constants import SOFGlobalConstantsNamespace, TaskStatus
from sofbase.common.exceptions import (
    RedshiftDataProcessorNotFoundError,  # Ensure this is the correct import path
)
from sofbase.common.exceptions import RedshiftDataProcessorExecutionError
from sofbase.common.logger import LoggingService
from sofbase.common.models.task import DataProcessingParameters, TaskPayload
from sofbase.common.models.workflow_input import WorkflowInput
from sofbase.common.processor_handler import TaskProcessorHandler
from sofbase.common.utils.commons import (
    get_rules_file_content,
    replace_variables,
    return_secret_arn,
    return_secret_value,
    return_ssm_param,
)

redshift_client = boto3.client("redshift-data")  # type: ignore
s3_client = boto3.client("s3")  # type: ignore
ssm_client = boto3.client("ssm")  # type: ignore
session = boto3.session.Session()

SOF = SOFGlobalConstantsNamespace()
logger = LoggingService().initialize_logger()


class RedshiftCredentials:
    """Parameters class for redshift credentials"""

    def __init__(self, *, engine_id: str, engine_type: str, secret_arn: str, db_name: str) -> None:
        self.engine_id = engine_id
        self.engine_type = engine_type
        self.secret_arn = secret_arn
        self.db_name = db_name


class RedshiftDataProcessorHandler(TaskProcessorHandler):

    def invoke_task(self, *, payload: dict[str, Any]) -> TaskPayload:
        """
        Initiates a Redshift data processing task.

        Parameters:
        payload (dict[str, Any]): A dictionary containing task parameters from step functions call.

        Returns:
        TaskPayload: An object representing the task payload.

        Raises:
        RedshiftDataProcessorNotFoundError: If an error occurs during query execution.
        """

        task_payload = TaskPayload(**payload)

        logger.info("Starting RedshiftDataProcessor Invoke with event", extra=payload)

        if isinstance(task_payload.task.parameters, DataProcessingParameters):

            try:
                result = self.start_redshift_job(
                    redshift_parameters=task_payload.task.parameters,
                    redshift_workflow_parameters=task_payload.task.parent.execution_input,
                )
            except Exception as e:

                emessage = (
                    "RedshiftDataProcessor error executing query for "
                    f"Task Id: {task_payload.task.parameters.task_id}"
                    f"Rules Path: {task_payload.task.parent.execution_input.rules_path}, {e}"
                )

                raise RedshiftDataProcessorNotFoundError(emessage)

            task_payload.task.parameters = result
            task_payload.task.status = TaskStatus.STARTING

        else:
            raise Exception("RedshiftProcessor Needs Dataprocessing Parameters")

        logger.info(
            {
                "operation": "task_invoke_redshift_processor",
                "name": "invoke",
                "execution_id": task_payload.execution_id,
                "execution_name": task_payload.execution_name,
            },
        )

        logger.info(
            "Finished RedshiftDataProcessor Invoke with event", extra=task_payload.model_dump()
        )

        return task_payload

    def get_task_status(self, *, payload: dict[str, Any]) -> TaskPayload:
        """
        Retrieves the status of a Redshift data processing task.

        Parameters:
        payload (dict[str, Any]): A dictionary containing task details.

        Returns:
        TaskPayload: An object representing the task payload.

        Raises:
        Exception: If the task name is null or if the task run ID is None.
        """
        task_payload = TaskPayload(**payload)

        logger.info(
            "Starting RedshiftDataProcessor Get status of Glue Job with event", extra=payload
        )

        if isinstance(task_payload.task.parameters, DataProcessingParameters):

            if task_payload.task.parameters.task_name is None:
                raise Exception(f"Trying to get Status from a null job name {task_payload}")

            task_timeout = task_payload.task.parameters.timeout_mins

            if task_payload.task.parameters.task_run_id is not None:
                try:
                    task_payload = self.check_status(
                        task_payload=task_payload,
                        timeout_in_minutes=task_timeout,
                    )
                except RedshiftDataProcessorExecutionError as e:  # STATUS FAILED
                    task_payload.task.error_type = "RedshiftDataProcessorError"
                    task_payload.task.error_cause = str(e)

                    error_extra = {
                        "failedRedshiftJobName": task_payload.task.parameters.task_id,
                    }

                    task_payload.task.error_extra = error_extra
                    raise e

                if task_payload.task.status == "STARTED":
                    task_payload.task.status = TaskStatus.RUNNING
                elif task_payload.task.status == "FINISHED":
                    task_payload.task.status = TaskStatus.SUCCEEDED
                elif task_payload.task.status == ("SUBMITTED", "PICKED"):
                    task_payload.task.status = TaskStatus.STARTING
                else:
                    task_payload.task.status = TaskStatus.FAILED

            else:
                raise Exception("Trying to check job status with a None job type id")

            if task_payload.task.status == TaskStatus.FAILED:
                logger.info(
                    {
                        "operation": "task_get_redshift_job_status",
                        "name": "get_redshift_job_status",
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "level_index": task_payload.task.level_index,
                        "thread_index": task_payload.task.thread_index,
                        "task_index": task_payload.task.task_index,
                        "task_id": task_payload.task.parameters.task_id,
                        "execution_id": task_payload.task.parameters.task_run_id,
                        "error_detail": task_payload.task.error_extra or {},
                    },
                )
                task_payload.task.error_type = "RedshiftDataProcessorError"
                error_extra = task_payload.task.error_extra or {}
                task_payload.task.error_cause = error_extra.get("Error", "Unknown error")

        else:
            raise Exception("RedshiftProcessor Needs Redshift Parameters")

        logger.info(
            {
                "operation": "task_get_redshift_job_status",
                "name": "get_redshift_job_status",
                "execution_id": task_payload.execution_id,
                "execution_name": task_payload.execution_name,
            },
        )

        logger.info(
            "Finishing RedshiftDataProcessor Get status of Redshift Job with event",
            extra=task_payload.model_dump(),
        )

        return task_payload

    def start_redshift_job(
        self,
        *,
        redshift_parameters: DataProcessingParameters,
        redshift_workflow_parameters: WorkflowInput,
    ) -> DataProcessingParameters:
        """
        Starts a Redshift job using provided parameters using boto3 API calls
        and returns the updated parameters.
        This function retrieves the SQL query from a rules file, replaces variables in the query,
        and executes the query using the Redshift Data API.
        It also retrieves the Redshift credentials from AWS Secrets Manager and uses them to execute the query.
        The function handles both serverless and provisioned Redshift clusters.
        It also handles the case where the SQL query contains multiple statements separated by semicolons.

        Parameters:
        redshift_parameters (DataProcessingParameters): An object containing Redshift job parameters.

        Returns:
        DataProcessingParameters: An object with updated job parameters.
        """

        artifacts_bucket = return_ssm_param(
            ssm_key=f"/{SOF.APP_NAME}/Foundation/S3/ArtifactsBucket/Name"
        )

        logger.info(
            {
                "operation": "get_json_config_file",
                "subtask": "file_response",
                "conf_file": self.config_file,
                "redshift_parameters": redshift_parameters.model_dump(),
            },
        )
        redshift_secret_name = return_ssm_param(
            ssm_key=self.config_file["ProcessingFramework"]["Parameters"][
                "REDSHIFT_CONFIG_SECRET_NAME_SSM"
            ]
        )
        sql_query = get_rules_file_content(
            rules_path=redshift_workflow_parameters.rules_path,
            workflow_name=redshift_parameters.workflow_name,
            task_id=redshift_parameters.task_id,
            artifacts_bucket=artifacts_bucket,
            dynamic_mode=redshift_workflow_parameters.dynamic_rules,
        )
        sql_query = replace_variables(
            start_dt=redshift_workflow_parameters.start_date or "",
            end_dt=redshift_workflow_parameters.end_date or "",
            file_content=sql_query,
            sources_dictionary=self.fill_source_tables_dictionary(),
            extras_dictionary=redshift_workflow_parameters.additional_properties or {},
            time_condition="",
            target_database=self.config_file.get("OutputProperties", {}).get("TARGET_DATABASE", ""),
            target_table=self.config_file.get("OutputProperties", {}).get("TARGET_TABLE", ""),
            start_hour=redshift_workflow_parameters.start_hour or "",
            end_hour=redshift_workflow_parameters.end_hour or "",
            start_dttm=redshift_workflow_parameters.start_dttm or "",
            end_dttm=redshift_workflow_parameters.end_dttm or "",
        )
        print(f"SQL Query: {sql_query}")
        database_name = self.config_file["ProcessingFramework"]["Parameters"]["REDSHIFT_DATABASE"]
        credentials = self.get_secret_credentials(
            secret_name=redshift_secret_name, database_name=database_name
        )
        result = self.execute_redshift_query(
            sql_query=sql_query,
            credentials=credentials,
            redshift_client=redshift_client,
        )

        redshift_parameters.task_name = "RedshiftDataProcessorHandler"
        redshift_parameters.task_run_id = result["Id"]

        logger.info(
            {
                "operation": "task_invoke_redshift_job",
                "redshift_job_name": redshift_parameters.task_name,
                "redshift_job_run_id": redshift_parameters.task_run_id,
                "task_id": redshift_parameters.task_id,
            },
        )

        return redshift_parameters

    def fill_source_tables_dictionary(self) -> dict:
        """
        It fills a dictionary ( self.sources_dictionary) with a list of source databases and its resolved values
        from the configuration file.

        Parameters
        ----------
        None

        returns
        ----------
        dictionary filled

        """
        sources_dictionary = {}
        source_keys = [
            key
            for key in self.config_file["InputProperties"].keys()
            if key.startswith("SOURCE_DATABASE")
        ]
        source_values = [
            self.config_file["InputProperties"].get(key)
            for key in self.config_file["InputProperties"].keys()
            if key.startswith("SOURCE_DATABASE")
        ]
        for index, value in enumerate(source_keys, start=0):
            sources_dictionary[source_keys[index]] = source_values[index]
        return sources_dictionary

    def execute_redshift_query(
        self, *, sql_query: str, credentials: Any, redshift_client: Any
    ) -> dict:
        """
        Executes a Redshift query using the boto3 redshift data API. Supports both serverless and provisioned clusters.
        Handles multiple queries separated by semicolons.
        If the query contains a semicolon, it splits the query into multiple queries and executes them in batch mode.
        If the query does not contain a semicolon, it executes the query directly.
        If the query is a stored procedure, it executes it using the appropriate method

        Parameters:
        sql_query (str): The SQL query to execute.
        credentials (Any): Credentials required for the query.
        redshift_client (Any): The Redshift client.

        Returns:
        dict: The result of the query execution.
        """
        if ";" in sql_query:
            sql_queries = self.split_queries(sql_query=sql_query)
            if credentials.engine_type == "serverless":
                result = redshift_client.batch_execute_statement(
                    WorkgroupName=credentials.engine_id,
                    Database=credentials.db_name,
                    SecretArn=credentials.secret_arn,
                    Sqls=sql_queries,
                )
            elif credentials.engine_type == "provisioned":
                result = redshift_client.batch_execute_statement(
                    ClusterIdentifier=credentials.engine_id,
                    Database=credentials.db_name,
                    SecretArn=credentials.secret_arn,
                    Sqls=sql_queries,
                )
        else:
            if credentials.engine_type == "serverless":
                result = redshift_client.execute_statement(
                    WorkgroupName=credentials.engine_id,
                    SecretArn=credentials.secret_arn,
                    Database=credentials.db_name,
                    Sql=sql_query,
                )
            elif credentials.engine_type == "provisioned":
                result = redshift_client.execute_statement(
                    ClusterIdentifier=credentials.engine_id,
                    SecretArn=credentials.secret_arn,
                    Database=credentials.db_name,
                    Sql=sql_query,
                )

        return result

    def split_queries(self, *, sql_query: str) -> list[str]:
        """
        Splits a SQL query into individual queries.
        The function looks for semicolons to identify the end of each query.
        If a stored procedure is detected, it handles it separately.
        The function returns a list of individual queries.

        Parameters:
        sql_query (str): The SQL query to split.

        Returns:
        list[str]: A list of individual queries.
        """
        final_queries = []
        while ";" in sql_query or "CREATE OR REPLACE PROCEDURE" in sql_query:
            if sql_query.strip().startswith("CREATE OR REPLACE PROCEDURE"):
                string_splitted = sql_query.split("END;$$", 1)
                query = string_splitted[0] + " END;$$"
            else:
                string_splitted = sql_query.split(";", 1)
                query = string_splitted[0]
            sql_query = string_splitted[1]
            if len(query.strip()) > 0:
                final_queries.append(query)
        if len(sql_query.strip()) > 0:
            final_queries.append(sql_query)
        return final_queries

    def check_status(self, *, task_payload: TaskPayload, timeout_in_minutes: int) -> TaskPayload:
        """
        Checks the status of a Redshift query.
        If the query exceeds the specified timeout, it cancels the query and raises an error.
        If the query fails, it returns a failed status.
        The function returns the status of the query.
        The function uses the Redshift Data API to describe the statement and check its status.

        Parameters:
        task_payload (TaskPayload): task object with the ID of the query.
        timeout_in_minutes (int): The timeout in minutes.

        Returns:
        Task Payload: task object with updated status of the query.
        """
        query_id = task_payload.task.parameters.task_run_id
        desc = redshift_client.describe_statement(Id=query_id)
        status = desc["Status"]
        execution_in_nanoseconds = int(desc["Duration"])
        execution_in_minutes = (execution_in_nanoseconds / 1000000000) / 60
        execution_in_seconds = execution_in_nanoseconds / 1000000000

        logger.info("Timeout in minutes: %s ", str(timeout_in_minutes))
        logger.info("Execution in minutes: %s ", str(execution_in_minutes))
        logger.info("Execution in seconds: %s ", str(execution_in_seconds))
        if 0 < int(timeout_in_minutes) < int(execution_in_minutes):
            redshift_client.cancel_statement(Id=query_id)
            raise RedshiftDataProcessorExecutionError(f"SQL aborted by timeout : {query_id}")
        if status.upper() == "FAILED":
            logger.info(f'SQL query failed: {query_id} : {desc["Error"]}')
        task_payload.task.status = status.strip('"')
        task_payload.task.error_extra = desc

        processor_result = {"execution_time_secs": str(execution_in_seconds)}
        task_payload.task.processor_result = processor_result  # type: ignore

        return task_payload

    def get_secret_credentials(
        self, *, secret_name: str, database_name: str
    ) -> RedshiftCredentials:
        """
        Retrieves secret credentials for Redshift.
        This function uses AWS Secrets Manager to get the secret ARN and secret value.
        It then determines the engine ID and type based on the secret value.
        The function returns a RedshiftCredentials object containing the engine ID, type, secret ARN, and database name.
        The function handles both serverless and provisioned Redshift clusters.

        Parameters:
        secret_name (str): The name of the secret.
        database_name (str): The name of the database.

        Returns:
        RedshiftCredentials: An object containing Redshift credentials.
        """
        secret_arn = return_secret_arn(secret_key=secret_name)
        secret_json = return_secret_value(secret_key=secret_name)
        engine_id = ""
        engine_type = ""
        try:
            engine_id = secret_json["dbClusterIdentifier"]
            engine_type = "provisioned"
        except KeyError:
            engine_id = secret_json["host"].split(".")[0]
            engine_type = "serverless"

        credentials = RedshiftCredentials(
            engine_id=engine_id,
            engine_type=engine_type,
            secret_arn=secret_arn,
            db_name=database_name,
        )
        return credentials
