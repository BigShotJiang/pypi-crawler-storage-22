import json
import uuid
from copy import deepcopy
from typing import TYPE_CHECKING, Any

import boto3
from sofbase.common.constants import SOFGlobalConstantsNamespace, TaskStatus
from sofbase.common.logger import LoggingService
from sofbase.common.models.task import TaskPayload
from sofbase.common.processor_handler import TaskProcessorHandler

logger = LoggingService().initialize_logger(service="StepFunctionsTaskProcessorHandler")

if TYPE_CHECKING:
    from mypy_boto3_dynamodb import DynamoDBClient
    from mypy_boto3_s3 import S3Client
    from mypy_boto3_secretsmanager import SecretsManagerClient
    from mypy_boto3_ssm import SSMClient
    from mypy_boto3_stepfunctions import SFNClient

ssm_client: "SSMClient" = boto3.client("ssm")
s3_client: "S3Client" = boto3.client("s3")
dynamo_client: "DynamoDBClient" = boto3.client("dynamodb")
secrets_client: "SecretsManagerClient" = boto3.client("secretsmanager")
sfn_client: "SFNClient" = boto3.client("stepfunctions")


SOF = SOFGlobalConstantsNamespace()


class StepFunctionsTaskProcessorHandler(TaskProcessorHandler):

    def invoke_task(self, *, payload: dict[str, Any]) -> TaskPayload:

        task_payload = TaskPayload(**payload)

        # TODO: CGG - SFN - Medium: Refine StepFunctionTaskProcessor Log
        logger.info(
            {
                "operation": "PreInvokeTaskStepFunctionsTaskProcessorHandler",
                "name": "invoke",
                "payload": payload,
                "task_payload": task_payload.model_dump(),
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
            },
        )

        sfn_prefix = f"arn:aws:states:{SOF.AWS_REGION}:{SOF.AWS_ACCOUNT_ID}:stateMachine"
        sfn_arn = f"{sfn_prefix}:{task_payload.task.parameters.task_id}"

        # TODO: CGG - SFN - Low: Build Name Using Parent Execution Name - Must be less than 80 chars.
        child_exec_name = str(uuid.uuid4())

        execution_depth = task_payload.task.parent.execution_input.execution_depth
        task_payload.task.parent.execution_input.execution_depth = execution_depth + 1

        subworkflow_input = deepcopy(task_payload.task.parent.execution_input.model_dump())
        updated_additional_props = subworkflow_input.get("additional_properties", None)

        # TODO: CGG - SFN - Very High: Deep Test and Add Exceptions + Debug (GlueProcessor)
        # TODO: CGG - SFN - Very High: Deep Test and Add Exceptions + Debug (RedshiftProcessor)
        # TODO: CGG - SFN - Very High: Deep Test and Add Exceptions + Debug (Subworkflows)
        if updated_additional_props is not None and isinstance(updated_additional_props, dict):
            parent_checkpoint_definition = updated_additional_props.get("checkpoint", None)
            if parent_checkpoint_definition is not None and isinstance(
                parent_checkpoint_definition, dict
            ):
                subworkflow_checkpoint = self.get_subworkflow_checkpoints(
                    parent_additional_properties=updated_additional_props,
                    subworkflow_name=task_payload.task.parameters.task_id,
                )
                if subworkflow_checkpoint is not None:
                    updated_additional_props["checkpoint"] = subworkflow_checkpoint
                    subworkflow_input["additional_properties"] = updated_additional_props
                else:
                    updated_additional_props.pop("checkpoint", None)
                    if bool(updated_additional_props):
                        subworkflow_input["additional_properties"] = updated_additional_props
                    else:
                        subworkflow_input["additional_properties"] = None
            else:
                pass
                # TODO: CGG - SFN - Medium: Add Log
        else:
            pass
            # TODO: CGG - SFN - Medium: Add Log

        logger.info(
            {
                "operation": "PreSubWorkFlowStartExecution",
                "note": f"Starting Subworkflow {sfn_arn}",
                "parent_original_input": task_payload.task.parent.execution_input,
                "subworkflow_input": subworkflow_input,
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
            }
        )

        start_respone = sfn_client.start_execution(
            stateMachineArn=sfn_arn,
            name=child_exec_name,
            input=json.dumps(subworkflow_input),
        )

        logger.info(
            {
                "operation": "PostSubWorkFlowStartExecution",
                "note": f"Starting Subworkflow {sfn_arn}",
                "parent_original_input": task_payload.task.parent.execution_input,
                "subworkflow_input": subworkflow_input,
                "start_respone": start_respone,
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
            }
        )

        task_payload.task.status = TaskStatus.RUNNING
        task_payload.task.parameters.task_name = task_payload.task.parameters.task_id
        task_payload.task.parameters.task_run_id = start_respone["executionArn"]
        task_payload.task.status = TaskStatus.RUNNING

        logger.info(
            {
                "operation": "PostInvokeTaskStepFunctionsTaskProcessorHandler",
                "name": "invoke",
                "payload": payload,
                "task_payload": task_payload.model_dump(),
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
            },
        )
        return task_payload

    def get_task_status(self, *, payload: dict[str, Any]) -> TaskPayload:
        """Docstring for get_task_status

        :param self: Description
        :type self:
        :param payload: Description
        :type payload:"""

        task_payload = TaskPayload(**payload)

        logger.info(
            {
                "operation": "GetStatus_StepFunctionsTaskProcessor",
                "name": "invoke",
                "payload": payload,
                "task_payload": task_payload.model_dump(),
            },
        )

        if task_payload.task.parameters.task_run_id is None:
            raise Exception("Trying to Check status of a None Execution Id")

        sfn_exec_response = sfn_client.describe_execution(
            executionArn=task_payload.task.parameters.task_run_id
        )

        logger.info(
            {
                "operation": "sfn_exec_response",
                "response": sfn_exec_response,
                "task_payload": task_payload.model_dump(),
            },
        )

        if sfn_exec_response["status"] == "SUCCEEDED":
            task_payload.task.status = TaskStatus.SUCCEEDED
        elif sfn_exec_response["status"] == "RUNNING":
            task_payload.task.status = TaskStatus.RUNNING
        else:
            task_payload.task.status = TaskStatus.FAILED

            cause = sfn_exec_response.get("cause", None)
            if cause is not None:

                error = sfn_exec_response.get("error", "StepFunctionsGenericError")
                task_payload.task.error_type = error
                task_payload.task.error_cause = cause
            else:
                # TODO: CGG - SFN - High: Refine this Generic Errors
                task_payload.task.error_type = "StepFunctionsGenericError"
                task_payload.task.error_cause = "StepFunction Generic Error Cause"

        # TODO: CGG - SFN - Low: Manage other status: ["FAILED", "TIMED_OUT", "ABORTED", "PENDING_REDRIVE"]

        task_payload.task.processor_result = {
            "stepfunctions": "step function task processor result"
        }

        logger.info(
            "Finished GetStatus_StepFunctionsTaskProcessor Invoke with event",
            extra=task_payload.model_dump(),
        )

        return task_payload

    def get_subworkflow_checkpoints(
        self, *, parent_additional_properties: dict, subworkflow_name: str
    ) -> dict | None:

        response = None
        if not isinstance(parent_additional_properties, dict):
            raise Exception("Additional Properties Must Be Instance of Dict")

        root_checkpoints = parent_additional_properties.get("checkpoint", None)

        if root_checkpoints is not None:
            subworkflow_checkpoints = root_checkpoints.get("subworkflow_checkpoints", None)
            if subworkflow_checkpoints is not None and isinstance(subworkflow_checkpoints, list):
                for checkpoint_definition in subworkflow_checkpoints:
                    if isinstance(checkpoint_definition, dict):
                        sub_checkpoint = checkpoint_definition.get(subworkflow_name, None)
                        if sub_checkpoint is not None and isinstance(sub_checkpoint, dict):
                            response = sub_checkpoint
                        elif sub_checkpoint is not None and not isinstance(sub_checkpoint, dict):
                            print(
                                f"warning: subworkflow checkpoint entry {sub_checkpoint}, {subworkflow_name} that is not instance of dict - verify schema"
                            )
                            # TODO: CGG - SFN -  Low: Add Logger
                    else:
                        print(
                            "warning: subworkflow checkpoint definition that is not instance of dict - verify schema"
                        )
                        # TODO: CGG - SFN -  Low: Add Logger
            else:
                print(f"Root original subworkflow checkpoints is None or is not instance of list")
                # TODO: CGG - SFN - Low: Add Logger
        else:
            print(f"Root Original Checkpoint is None. It has no checkpoints")
            # TODO: CGG - SFN - Low: Add Logger

        return response
