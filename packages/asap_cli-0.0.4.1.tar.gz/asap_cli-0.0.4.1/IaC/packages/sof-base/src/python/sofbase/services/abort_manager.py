"""
This module has the ExecutionMetadataManager. This class manages
the execution metadata in the Pipeline Execution History Table (DynamoDB)
and in the Pipeline Registry Table (DynamoDB).
"""

import boto3
from aws_lambda_powertools import Logger
from sofbase.common.constants import (
    SOFGlobalConstantsNamespace,
    SubTaskType,
    TaskStatus,
)
from sofbase.common.logger import LoggingService
from sofbase.common.models.execution_metadata import (
    PipelineExecutionMetadata,
    TaskHistoryItem,
)
from sofbase.common.utils.commons import return_ssm_param
from sofbase.services.metadata_manager import ExecutionMetadataManager

SOF = SOFGlobalConstantsNamespace()


class ExecutionAbortManager:
    """
    Manages the Execution Abort proceess for a given execution ID.
    This class is responsible for aborting all processes that are currently running
    for the given execution ID by checking the Pipeline Execution History (PEH)
    """

    def __init__(
        self,
        *,
        execution_arn: str,
        logger: Logger | None = None,
        peh_table_name_ssm: str = f"/{SOF.APP_NAME}/Foundation/DDB/PipelineExecutionHistory/TableName",
    ) -> None:
        if logger is None:
            logger = LoggingService().initialize_logger()

        self.logger = logger
        self.dynamodb = boto3.resource("dynamodb")

        peh_table_name_ssm = return_ssm_param(ssm_key=peh_table_name_ssm)
        self.peh_table = self.dynamodb.Table(peh_table_name_ssm)

        self.execution_id = execution_arn.split(":")[-1]

        self.logger.info({"operation": "init_abort_manager", "execution_id": self.execution_id})

    def abort_processes_if_running(self) -> None:
        """
        Aborts all processes that are currently running for the given execution ID.
        This method checks the Pipeline Execution History (PEH) for tasks that are in the
        STARTING state and attempts to cancel them.
        If the PEH record is not found, it logs a warning and returns without taking action.

        Args:
            None

        Returns:
            None
        """

        emm = ExecutionMetadataManager(logger=self.logger, execution_id=None)
        peh_rec = emm.get_peh_record(peh_id=self.execution_id)
        if peh_rec is None:
            self.logger.warning(
                {
                    "operation": "abort_processes_if_running",
                    "message": "Pipeline Execution History record not found",
                    "execution_id": self.execution_id,
                }
            )
            return
        record = PipelineExecutionMetadata(**peh_rec)
        for task_record in record.task_history:
            if task_record.status == TaskStatus.STARTING:
                self.process_task_cancelation(
                    task_record=task_record, task_history=record.task_history
                )

        return None

    def process_task_cancelation(
        self, *, task_record: TaskHistoryItem, task_history: list[TaskHistoryItem]
    ) -> None:
        """
        Processes the cancellation of a task by checking its status in the task history.
        If the task is already completed (SUCCEEDED or FAILED), it logs a message indicating
        that no action is needed. If the task is still in progress, it calls the `cancel_task`
        method to cancel the task.
        Args:
            task_record (TaskHistoryItem): The task record to process for cancellation.
            task_history (list[TaskHistoryItem]): The list of all task history items.
        Returns:
            None
        """
        close_task = None
        for task_in_list in task_history:
            if task_in_list.status in [TaskStatus.SUCCEEDED, TaskStatus.FAILED]:
                if task_in_list.task_id == task_record.task_id:
                    close_task = task_in_list
        if close_task is None:
            self.cancel_task(task=task_record)
        else:
            self.logger.info(
                {
                    "operation": "process_task_cancelation",
                    "task_id": task_record.task_id,
                    "message": "Task already completed, no action taken",
                }
            )

    def cancel_task(self, *, task: TaskHistoryItem) -> None:
        """
        Cancels a task based on its sub-task type. If the task is a Glue Data Processor or
        Redshift Data Processor, it attempts to cancel the corresponding job or query.
        Args:
            task (TaskHistoryItem): The task to cancel.
        Returns:
            None
        """
        if task.sub_task_type == SubTaskType.GLUE_DATA_PROCESSOR:
            glue_run_id = task.extra.get("task_run_id") if isinstance(task.extra, dict) else ""
            glue_job_name = task.extra.get("task_name") if isinstance(task.extra, dict) else ""
            glue_job_name = (
                glue_job_name
                if isinstance(glue_job_name, str) and glue_job_name is not None
                else ""
            )

            if isinstance(glue_run_id, str) and glue_run_id:
                self.cancel_glue_job(task_run_id=glue_run_id, task_name=glue_job_name)
            else:
                self.logger.warning(
                    {
                        "operation": "cancel_task",
                        "message": "Invalid or missing Glue run ID, cannot cancel job",
                        "task_run_id": glue_run_id,
                    }
                )
        if task.sub_task_type == SubTaskType.REDSHIFT_DATA_PROCESSOR:
            redshift_run_id = task.extra.get("task_run_id") if isinstance(task.extra, dict) else ""
            self.logger.info(
                {
                    "operation": "cancel_task",
                    "task_run_id": (
                        task.extra.get("task_run_id") if isinstance(task.extra, dict) else None
                    ),
                    "sub_task_type": task.sub_task_type,
                    "message": "Cancelling Redshift Data Processor task",
                }
            )
            if isinstance(redshift_run_id, str) and redshift_run_id:
                self.cancel_redshift_query(task_run_id=redshift_run_id)
            else:
                self.logger.warning(
                    {
                        "operation": "cancel_task",
                        "message": "Invalid or missing Redshift run ID, cannot cancel query",
                        "task_run_id": redshift_run_id,
                    }
                )

    def cancel_glue_job(self, *, task_run_id: str, task_name: str) -> None:
        """
        Cancel a running AWS Glue job by its task run ID and task name.

        Args:
            task_run_id (str): The ID of the Glue job run to cancel
            task_name (str): The name of the Glue job to cancel

        Returns:
            None
        """

        glue_client = boto3.client("glue")

        glue_job_current_status = glue_client.get_job_run(
            JobName=task_name,
            RunId=task_run_id,
        )

        current_status = glue_job_current_status["JobRun"]["JobRunState"]
        if current_status in ["STARTING", "RUNNING", "WAITING"]:
            # Cancel the job run
            glue_client.batch_stop_job_run(JobName=task_name, JobRunIds=[task_run_id])
            self.logger.info(f"Successfully requested cancellation of job run {task_run_id}")
        else:
            self.logger.info(f"Job run {task_run_id} is not running. state: {current_status}")
            return None

    def cancel_redshift_query(self, *, task_run_id: str) -> None:
        """
        Cancel a Redshift query if it's currently running.

        Args:
            task_run_id (str): The ID of the task run associated with the query to cancel.

        Returns:
            None
        """
        # Get the Redshift Data API client
        redshift_data_client = boto3.client("redshift-data")

        # Check if the query is still running
        response = redshift_data_client.describe_statement(Id=task_run_id)
        status = response.get("Status")

        # Only cancel if the query is in a running state
        if status in ["SUBMITTED", "PICKED", "STARTED"]:
            self.logger.info(f"Cancelling Redshift query {task_run_id} ")
            redshift_data_client.cancel_statement(Id=task_run_id)
            self.logger.info(f"Successfully requested cancellation of query {task_run_id}")
        else:
            self.logger.info(
                f"Query {task_run_id} is not running (status: {status}), no need to cancel"
            )
