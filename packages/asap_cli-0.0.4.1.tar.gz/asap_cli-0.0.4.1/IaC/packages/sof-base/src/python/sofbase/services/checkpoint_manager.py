"""
This module has the ExecutionMetadataManager. This class manages
the execution metadata in the Pipeline Execution History Table (DynamoDB)
and in the Pipeline Registry Table (DynamoDB).
"""

import uuid

import boto3
from aws_lambda_powertools import Logger
from sofbase.common.constants import DateFormat, SOFGlobalConstantsNamespace
from sofbase.common.logger import LoggingService
from sofbase.common.utils.commons import return_ssm_param

SOF = SOFGlobalConstantsNamespace()
PIPELINE_STATUS_ACTIVE = "ACTIVE"


def is_empty(arg: str | None) -> bool:
    return (arg is None) or (len(arg) == 0)


class CheckpointManager:
    """
    Manages the life cycle of checkpoint items for workflow re-drives
    """

    def __init__(
        self,
        *,
        checkpoint_id: str | None = None,
        logger: Logger | None = None,
        sep: str = DateFormat.SEPARATOR,
        timespec: str = DateFormat.TIMESPEC,
        checkpoint_control_table_name_ssm: str = f"/{SOF.APP_NAME}/Foundation/DDB/CheckpointControl/TableName",
        checkpoint_table_ttl_ssm: str = f"/{SOF.APP_NAME}/Config/DDB/CheckpointControl/TTL",
    ) -> None:
        """Init checkpoint manager"""

        if logger is None:
            logger = LoggingService().initialize_logger()

        self.sep = sep
        self.timespec = timespec
        self.logger = logger
        self.dynamodb = boto3.resource("dynamodb")
        # TODO: CGG - CHECKPOINT - Medium: Manage Notifications
        self.sns = boto3.client("sns")

        if checkpoint_id:
            self.checkpoint_id = checkpoint_id
        else:
            self.checkpoint_id = str(uuid.uuid4())

        checkpoint_control_table_name = return_ssm_param(ssm_key=checkpoint_control_table_name_ssm)
        self.checkpoint_table = self.dynamodb.Table(checkpoint_control_table_name)

        self.logger.info(
            {
                "operation": "init_checkpoint_manager",
                "execution_id": self.checkpoint_id,
            }
        )

        try:
            ttl_str = return_ssm_param(ssm_key=checkpoint_table_ttl_ssm)
            ttl = int(ttl_str)
            self.logger.info(
                {
                    "operation": "getting_ttl",
                    "checkpoint_table_ttl_ssm": checkpoint_table_ttl_ssm,
                    "ttl": ttl,
                }
            )
        except Exception as e:
            self.logger.warning(e)
            self.logger.warning(
                f"Issue getting or casting TTL from SSM Param: {checkpoint_table_ttl_ssm}"
            )
            ttl = 800

        self.checkpoint_item_ttl = ttl
