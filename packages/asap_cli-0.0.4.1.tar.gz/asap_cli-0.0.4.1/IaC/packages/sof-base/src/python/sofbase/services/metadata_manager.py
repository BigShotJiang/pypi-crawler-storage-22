"""
This module has the ExecutionMetadataManager. This class manages
the execution metadata in the Pipeline Execution History Table (DynamoDB)
and in the Pipeline Registry Table (DynamoDB).
"""

import logging
import time
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

import boto3
from aws_lambda_powertools import Logger
from sofbase.common.constants import (
    DateFormat,
    PipelineStatus,
    SOFGlobalConstantsNamespace,
    SubTaskType,
    TaskStatus,
    TaskType,
)
from sofbase.common.logger import LoggingService
from sofbase.common.models.execution_metadata import (
    PipelineExecutionMetadata,
    TaskHistoryItem,
)
from sofbase.common.utils.commons import return_ssm_param

SOF = SOFGlobalConstantsNamespace()
PIPELINE_STATUS_ACTIVE = "ACTIVE"


def is_empty(arg: str | None) -> bool:
    return (arg is None) or (len(arg) == 0)


# TODO: CGG - EMM - High: Add integration tests for main flows.
# TODO: CGG - EMM - Medium: Manage correctly this exceptions. Custom Exceptions?
# TODO: CGG - EMM - Medium: Add Support for Local Time Zone.
class ExecutionMetadataManager:
    """
    Manages the Execution Metadata in the Pipelines and Pipelines Execution Tables.
    """

    def __init__(
        self,
        *,
        execution_id: str | None = None,
        logger: Logger | None = None,
        sep: str = DateFormat.SEPARATOR,
        timespec: str = DateFormat.TIMESPEC,
        pipe_registry_table_name_ssm: str = f"/{SOF.APP_NAME}/Foundation/DDB/PipelineRegistry/TableName",
        peh_table_name_ssm: str = f"/{SOF.APP_NAME}/Foundation/DDB/PipelineExecutionHistory/TableName",
        peh_table_ttl_ssm: str = f"/{SOF.APP_NAME}/Config/DDB/PipelineExecutionHistory/TTL",
    ) -> None:
        """Manages the Execution Metadata in the Pipelines and Pipelines Execution Tables.

        Parameters
        ----------
        execution_id : str | None, optional
            Execution Id to Manage the Execution Metadata, by default None
        logger : Logger | None, optional
            Logger, by default None
        sep : str, optional
            ISO Date Format Separator, by default DateFormat.SEPARATOR
        timespec : str, optional
            ISO Date Format The optional argument timespec specifies the number of additional
            terms of the time to include. Valid options are 'auto', 'hours',
            'minutes', 'seconds', , by default DateFormat.TIMESPEC
        pipe_registry_table_name_ssm : str, optional
            Pipeline Registry Table Name SSM Parameter,
            by default "/SOF_APP_NAME/Foundation/DDB/PipelineRegistry/TableName"
        peh_table_name_ssm : str, optional
            Pipeline Execution History Table Name SSM Parameter,
            by default "/SOF_APP_NAME/Foundation/DDB/PipelineExecutionHistory/TableName"
        peh_table_ttl_ssm : str, optional
            Pipeline Execution History Table TTL Value (str) SSM Parameter,
            by default "/SOF_APP_NAME/Config/DDB/PipelineExecutionHistory/TTL"

        Returns
        -------
        None

        Raises
        ------
        Exception("Can't initilize Execution Metadata Manager with None pipeline_name")
        """

        if logger is None:
            logger = LoggingService().initialize_logger(
                log_level=logging.INFO, service="MetadataManager"
            )

        self.sep = sep
        self.timespec = timespec
        self.logger = logger
        self.dynamodb = boto3.resource("dynamodb")
        # TODO: CGG - EMM - Medium: Manage Notifications
        self.sns = boto3.client("sns")

        if execution_id:
            self.execution_id = execution_id
        else:
            self.execution_id = str(uuid.uuid4())

        pipe_registry_table_name_ssm = return_ssm_param(ssm_key=pipe_registry_table_name_ssm)
        peh_table_name_ssm = return_ssm_param(ssm_key=peh_table_name_ssm)

        self.pipelines_table = self.dynamodb.Table(pipe_registry_table_name_ssm)
        self.peh_table = self.dynamodb.Table(peh_table_name_ssm)

        self.logger.info(
            {
                "operation": "init_execution_manager",
                "main_execution_id": self.execution_id,
            }
        )

        try:
            ttl_str = return_ssm_param(ssm_key=peh_table_ttl_ssm)
            ttl = int(ttl_str)
            self.logger.info(
                {
                    "operation": "getting_ttl",
                    "peh_table_ttl_ssm": peh_table_ttl_ssm,
                    "main_execution_id": self.execution_id,
                    "ttl": ttl,
                }
            )
        except Exception as e:
            self.logger.warning(e)
            self.logger.warning(f"Issue getting or casting TTL from SSM Param: {peh_table_ttl_ssm}")
            ttl = 800

        self.peh_ttl = ttl

    def start_pipeline_execution(
        self,
        *,
        pipeline_name: str,
        data_domain_name: str,
        data_product_name: str,
        team_name: str,
        data_sub_domain: str,
        pipeline_input: dict,
        comment: None | str = None,
    ) -> str:
        """Starts a pipeline execution and records its metadata in the pipeline execution
        history metadata table.

        Parameters
        ----------
        pipeline_name : str
            Pipeline Name (Should be a valid name stored in Pipeline Registry Table)
        data_domain_name: str
            Data Domain Name
        data_product_name: str
            Data Product Name
        team_name: str
            Team Name
        data_sub_domain: str
            data subdomain Name
        pipeline_input: dict
            Original Pipeline Input Event
        comment : None | str, optional
            Additional comment to annotate the pipeline execution metadata.

        Returns
        -------
        str

            Excution_Id (str) of Pipeline Execution


        Raises
        ------
        Exception
            Raises an Exception if tring to update a execution that is in inactive state or
            when trying to update an execution with a None execution id.
        """

        self.logger.info(
            {
                "operation": "start_pipeline_execution",
                "pipeline_name": pipeline_name,
                "data_domain_name": data_domain_name,
                "data_product_name": data_product_name,
                "team_name": team_name,
                "data_sub_domain": data_sub_domain,
                "main_execution_id": self.execution_id,
                "pipeline_input": pipeline_input,
                "comment": comment,
            }
        )

        if pipeline_name is None or (len(pipeline_name) == 0):
            raise Exception("Trying tp start execution with a None or Empty pipeline_name")

        if not self.check_pipeline(pipeline_name=pipeline_name):
            self.logger.error(
                {
                    "operation": "start_start_pipeline_execution",
                    "sub_operation": "check_pipeline",
                    "pipeline_name": pipeline_name,
                    "main_execution_id": self.execution_id,
                    "data_domain_name": data_domain_name,
                    "data_product_name": data_product_name,
                    "team_name": team_name,
                    "data_sub_domain": data_sub_domain,
                    "pipeline_input": pipeline_input,
                    "comment": comment,
                }
            )
            self.logger.error(f"Pipeline doesn't exist or inactive : {pipeline_name}")
            raise Exception("Pipeline doesn't exist or inactive. Can't start execution.")

        current_time = datetime.now(timezone.utc)
        utc_time_iso = current_time.isoformat(sep=self.sep, timespec=self.timespec)
        local_date_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        item: dict[str, Decimal | int | bool | str | dict | list[dict]] = {}

        # Add extra fields
        item["id"] = self.execution_id
        item["version"] = 1
        item["pipeline"] = pipeline_name
        item["data_domain_name"] = data_domain_name
        item["data_product_name"] = data_product_name
        item["team_name"] = team_name
        item["data_sub_domain"] = data_sub_domain
        item["data_domain_product"] = f"{data_domain_name}#{data_product_name}"

        item["pipeline_input"] = pipeline_input
        item["active"] = True
        item["task_history"] = []
        item["execution_start_date"] = local_date_iso
        item["status"] = PipelineStatus.PIPELINE_STARTED

        if comment:
            item["comment"] = comment
        else:
            item["comment"] = f"Pipeline: {pipeline_name} has started execution"

        item["start_timestamp"] = utc_time_iso
        item["last_updated_timestamp"] = utc_time_iso
        item["status_last_updated_timestamp"] = PipelineStatus.PIPELINE_STARTED + "#" + utc_time_iso

        if self.peh_ttl > 0:
            ttl_date = datetime.today() + timedelta(days=self.peh_ttl)
            expiry_ttl = int(time.mktime(ttl_date.timetuple()))
            item["ttl"] = expiry_ttl

        self.logger.info(
            {
                "operation": "start_pipeline_execution",
                "sub_operation": "persist_item",
                "main_execution_id": self.execution_id,
                "item": item,
            }
        )
        try:
            self.peh_table.put_item(
                Item=item,
                ExpressionAttributeNames={"#ID": "id"},
                ConditionExpression="attribute_not_exists(#ID)",
            )
        except self.dynamodb.meta.client.exceptions.ConditionalCheckFailedException as e:
            self.logger.error(f"Pipeline Execution Id Already Exists - Can't start execution, {e}")
            raise e

        return self.execution_id

    def update_pipeline_task_execution(
        self,
        *,
        parent_execution_id: str,
        task_id: str,
        status: TaskStatus,
        task_type: None | TaskType = None,
        sub_task_type: None | SubTaskType = None,
        extra: dict[str, Any] | None = None,
        task_issue_comment: str | None = None,
    ) -> bool:
        """Updates the Task (and Pipeline) Execution Metadata in
        the Pipeline Execution history Table. It also adds additional entry
        to the task_history list in DynamoDB.

        Parameters
        ----------
        parent_execution_id: str
            The strict parent execution_id of task_id
        task_id : str
            Task Id
        status : TaskStatus
            Task Status.
        task_type : None | TaskType, optional
            Task Type, by default None
        sub_task_type : None | SubTaskType, optional
            Sub Task Type, by default None
        extra : dict[str, Any] | None, optional
            Extra (custom) dictionary to append to the task execution metadata, by default None
        task_issue_comment : str | None, optional
            Task Issue Comment (Custom Message), by default None

        Returns
        -------
        True if update was successful, otherwise it raises Exceptions


        Raises
        ------
        Exception
            Exception("Trying to update Pipeline Execution with a None or Empty execution_id")
        Exception
            raise Exception("Trying to update a Task with an invalid Task Status")
        ValueError
            ValueError("Pipeline execution is not active, is delered or expired")
        """

        self.logger.info(
            {
                "operation": "start_update_pipeline_task_execution",
                "main_execution_id": self.execution_id,
                "task_id": task_id,
                "status": status,
                "extra": extra,
                "task_issue_comment": task_issue_comment,
            }
        )

        peh_id = self.execution_id

        if is_empty(peh_id):
            raise Exception("Trying to update Pipeline Execution with a None or Empty execution_id")

        peh_rec = self.get_peh_record(peh_id=peh_id)

        record = PipelineExecutionMetadata(**peh_rec)  # type: ignore

        self.logger.info(
            {
                "operation": "update_pipeline_task_execution",
                "sub_operation": "retrieved_execution_metadata_record",
                "record": record,
                "main_execution_id": self.execution_id,
            }
        )

        if peh_rec:
            is_active = record.active
        else:
            is_active = False

        if is_active is False:
            raise ValueError("Pipeline execution is not active, is delered or expired")

        record.last_updated_timestamp
        version = record.version

        current_time = datetime.now(timezone.utc)
        utc_time_iso = current_time.isoformat(sep=self.sep, timespec=self.timespec)
        duration_sec = (current_time - record.start_timestamp).total_seconds()

        # Updating a Task
        if status in [
            TaskStatus.STARTING,
            TaskStatus.RUNNING,
            TaskStatus.SUCCEEDED,
            TaskStatus.FAILED,
            TaskStatus.SKIPPED,
        ]:

            expr_names = {
                "#H": "task_history",
                "#St": "status",
                "#V": "version",
                "#LUT": "last_updated_timestamp",
                "#STT": "status_last_updated_timestamp",
                "#A": "active",
                "#V": "version",
                "#S": "success",
                "#D": "duration_in_seconds",
            }

            if task_issue_comment == "":
                task_issue_comment = None

            task_history_list = [
                TaskHistoryItem(
                    parent_execution_id=parent_execution_id,
                    task_id=task_id,
                    status=status,
                    task_type=task_type,
                    sub_task_type=sub_task_type,
                    extra=extra,
                    timestamp=current_time,
                    task_issue_comment=task_issue_comment,
                ).model_dump(exclude_none=True)
            ]

            expr_values = {
                ":H": task_history_list,
                ":St": PipelineStatus.PIPELINE_RUNNING,
                ":LUT": utc_time_iso,
                ":STT": PipelineStatus.PIPELINE_RUNNING + "#" + utc_time_iso,
                ":INC": 1,
                ":A": True,
                ":S": False,
                ":V": version,
                ":D": Decimal(str(duration_sec)),
            }

            update_expr = (
                "SET #H = list_append(#H, :H), #S = :S, #V = :V + :INC,"
                "#LUT = :LUT, #A = :A, #St = :St, #D = :D,"
                "#STT = :STT"
            )

            self.logger.info(
                {
                    "operation": "update_pipeline_task_execution",
                    "sub_operation": "trying_update_peh_table_item",
                    "operation": "update_pipeline_task_execution",
                    "main_execution_id": self.execution_id,
                    "task_id": task_id,
                    "status": status,
                    "extra": extra,
                    "task_issue_comment": task_issue_comment,
                    "update_expr": update_expr,
                    "expr_values": expr_values,
                }
            )

            self.peh_table.update_item(
                Key={"id": peh_id},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=expr_values,
                ExpressionAttributeNames=expr_names,
                ReturnValues="UPDATED_NEW",
            )

            self.logger.info(
                {
                    "operation": "update_pipeline_task_execution",
                    "sub_operation": "updated_peh_table_item",
                    "main_execution_id": self.execution_id,
                    "task_id": task_id,
                    "status": status,
                    "extra": extra,
                    "task_issue_comment": task_issue_comment,
                    "update_expr": update_expr,
                    "expr_values": expr_values,
                }
            )

        else:
            raise Exception("Trying to update a Task with an invalid Task Status")
        return True

    def update_pipeline_execution(
        self,
        *,
        status: PipelineStatus,
        extra_metadata: dict[str, Any] | None = None,
        issue_comment: str | None = None,
    ) -> bool:
        """Update pipeline execution metadata. This function ONLY updates
        the pipeline execution metadata, it doesn't update the Task Excution History Items.
        It updates pipeline_history in DynamoDB, not task_history.

        Parameters
        ----------
        status : PipelineStatus
            Pipeline Status
        extra_metadata : dict[str, Any] | None, optional
            Extra dict to append to the Pipeline History Metadata Item, by default None
        issue_comment : str | None, optional
            Issue comment to append to the Pipeline History List (pipeline_history), by default None

        Returns
        -------
        bool
            True if update was successful, otherwise it raises Exceptions

        Raises
        ------
        Exception
            Exception("Trying to update Pipeline Execution with a None execution_id")
        ValueError
            ValueError("Pipeline execution is not active, is delered or expired")
        Exception
            Exception("Trying to update pipelines execution history with an invalid status")
        """

        self.logger.info(
            {
                "operation": "start_update_pipeline_execution",
                "status": status,
                "extra_metadata": extra_metadata,
                "issue_comment": issue_comment,
                "main_execution_id": self.execution_id,
            }
        )

        peh_id = self.execution_id

        if peh_id is None:
            raise Exception("Trying to update Pipeline Execution with a None execution_id")

        peh_rec = self.get_peh_record(peh_id=peh_id)

        record = PipelineExecutionMetadata(**peh_rec)  # type: ignore

        pipeline_name = record.pipeline

        self.logger.info(
            {
                "operation": "update_pipeline_execution",
                "suboperation": "retrieved_execution_metadata_record",
                "record": record,
                "main_execution_id": self.execution_id,
            }
        )

        if peh_rec:
            is_active = record.active
        else:
            is_active = False

        if is_active is False:
            raise ValueError("Pipeline execution is not active, is delered or expired")

        record.last_updated_timestamp
        version = record.version

        current_time = datetime.now(timezone.utc)
        utc_time_iso = current_time.isoformat(sep=self.sep, timespec=self.timespec)
        local_date_iso = current_time.strftime("%Y-%m-%d")
        duration_sec = (current_time - record.start_timestamp).total_seconds()

        if status in [
            PipelineStatus.PIPELINE_STARTED,
            PipelineStatus.PIPELINE_RUNNING,
            PipelineStatus.PIPELINE_COMPLETED,
            PipelineStatus.PIPELINE_FAILED,
        ]:
            expr_names = {
                "#St": "status",
                "#V": "version",
                "#LUT": "last_updated_timestamp",
                "#STT": "status_last_updated_timestamp",
                "#A": "active",
                "#V": "version",
                "#S": "success",
                "#D": "duration_in_seconds",
            }

            active = True
            if status in [
                PipelineStatus.PIPELINE_COMPLETED,
                PipelineStatus.PIPELINE_FAILED,
            ]:
                active = False

            expr_values = {
                ":St": status,
                ":LUT": utc_time_iso,
                ":STT": status + "#" + utc_time_iso,
                ":INC": 1,
                ":A": active,
                ":S": status == PipelineStatus.PIPELINE_COMPLETED,
                ":V": version,
                ":D": Decimal(str(duration_sec)),
            }

            update_expr = (
                "SET #S = :S, #V = :V + :INC, "
                "#LUT = :LUT, #A = :A, #St = :St, #D = :D,"
                "#STT = :STT"
            )

            if not is_empty(issue_comment):
                expr_names["#C"] = "issue_comment"
                expr_values[":C"] = issue_comment
                update_expr += ", #C = :C"

            if extra_metadata is not None:
                expr_names["#EM"] = "extra_metadata"
                expr_values[":EM"] = extra_metadata
                update_expr += ", #EM = :EM"

            self.logger.info(
                {
                    "operation": "update_pipeline_execution",
                    "sub_operation": "update_peh_table_item",
                    "update_expr": update_expr,
                    "expr_values": expr_values,
                    "status": status,
                    "extra_metadata": extra_metadata,
                    "issue_comment": issue_comment,
                    "main_execution_id": self.execution_id,
                }
            )

            self.peh_table.update_item(
                Key={"id": peh_id},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=expr_values,
                ExpressionAttributeNames=expr_names,
                ReturnValues="UPDATED_NEW",
            )

            # Update Pipelines Registry Table with Last Execution Metadata
            if status in [
                PipelineStatus.PIPELINE_COMPLETED,
                PipelineStatus.PIPELINE_FAILED,
            ]:

                pipeline_item = self.pipelines_table.get_item(
                    Key={"name": pipeline_name},
                    ConsistentRead=True,
                    AttributesToGet=["name", "version"],
                )["Item"]
                pipeline_version = pipeline_item["version"]

                pipeline_expr_names = {
                    "#V": "version",
                    "#U": "last_updated_timestamp",
                    "#P": "last_execution_id",
                    "#D": "last_execution_date",
                    "#E": "last_execution_timestamp",
                    "#S": "last_execution_status",
                    "#X": "last_execution_duration_in_seconds",
                }

                pipeline_expr_values = {
                    ":V": pipeline_version,
                    ":INC": 1,
                    ":S": status,
                    ":P": self.execution_id,
                    ":D": local_date_iso,
                    ":E": utc_time_iso,
                    ":U": utc_time_iso,
                    ":X": Decimal(str(duration_sec)),
                }

                pipeline_update_expr = (
                    "SET #P = :P, #V = :V + :INC, #S = :S, #D = :D, #X = :X, #E = :E, #U = :U"
                )

                self.logger.info(
                    {
                        "operation": "update_pipeline_execution",
                        "sub_operation": "update_pipeline_registry_table_item",
                        "pipeline_expr_names": pipeline_expr_names,
                        "pipeline_expr_values": pipeline_expr_values,
                        "extra_metadata": extra_metadata,
                        "issue_comment": issue_comment,
                        "main_execution_id": self.execution_id,
                    }
                )

                self.pipelines_table.update_item(
                    Key={"name": pipeline_name},
                    UpdateExpression=pipeline_update_expr,
                    ExpressionAttributeValues=pipeline_expr_values,
                    ExpressionAttributeNames=pipeline_expr_names,
                    ReturnValues="UPDATED_NEW",
                )
        else:
            raise Exception("Trying to update pipelines execution history with an invalid status")

        return True

    def get_peh_record(self, *, peh_id: str) -> dict[str, Any] | None:
        """Retrieves the pipeline execution metadata record for a specific execution_id (peh_id)

        Parameters
        ----------
        peh_id : str
            execution_id (peh_id)

        Returns
        -------
        dict[str, Any] | None
            Pipeline execution metadata record (dict) or None if not found.
        """

        result = self.peh_table.get_item(Key={"id": peh_id}, ConsistentRead=True)

        self.logger.info(
            {
                "operation": "get_peh_record",
                "peh_id": peh_id,
                "main_execution_id": self.execution_id,
                "result": result,
            }
        )

        if "Item" in result:
            return result["Item"]
        else:
            return None

    def get_pipeline_registry_record(self, *, pipeline_name: str) -> dict[str, Any] | None:
        """Retrieves the pipeline registry record for a specific pipeline_name

        Parameters
        ----------
        pipeline_name : str

        Returns
        -------
        dict[str, Any] | None
            Pipeline Registry Record (dict) or None if not found.
        """

        result = self.pipelines_table.get_item(Key={"name": pipeline_name}, ConsistentRead=True)

        self.logger.info(
            {
                "operation": "get_pipeline_registry_record",
                "pipeline_name": pipeline_name,
                "main_execution_id": self.execution_id,
                "result": result,
            }
        )

        if "Item" in result:
            return result["Item"]
        else:
            return None

    def add_pipeline_registry_record(
        self,
        *,
        pipeline_name: str,
        active: str = "ACTIVE",
        version: int = 1,
    ) -> None:

        item: dict[str, Decimal | int | bool | str] = {
            "name": pipeline_name,
            "status": active,
            "version": version,
        }

        try:
            self.pipelines_table.put_item(
                Item=item,
                ExpressionAttributeNames={"#N": "name"},
                ConditionExpression="attribute_not_exists(#N)",
            )
        except self.dynamodb.meta.client.exceptions.ConditionalCheckFailedException as e:
            self.logger.error(f"Pipeline Name Already Exists - Can't add to pipeline registry, {e}")
            raise e

    def delete_pipeline_registry_record(
        self,
        *,
        pipeline_name: str,
    ) -> None:
        try:
            self.pipelines_table.delete_item(Key={"name": pipeline_name})
        except Exception as e:
            # TODO: CGG - EMM - Low: Manage precise exceptions
            self.logger.error(f"Error deleting pipeline registry record: {pipeline_name}, {e}")
            raise e

        pass

    def check_pipeline(self, *, pipeline_name: str) -> bool:
        """Check if pipeline exists and is active

        Parameters
        ----------
        pipeline_name : str
            Pipeline Name

        Returns
        -------
        bool
            True if pipeline exists and is active
            False if pipeline doesnt exist or if it's inactive.
        """

        # TODO: CGG - EMM - High: Unhandled exception when item doesn't exist. Double check.
        result = self.pipelines_table.get_item(
            Key={"name": pipeline_name}, ConsistentRead=True, AttributesToGet=["name", "status"]
        )

        self.logger.info(
            {
                "operation": "check_pipeline",
                "pipeline_name": pipeline_name,
                "main_execution_id": self.execution_id,
                "result": result,
            }
        )

        if "Item" in result:  # Pipeline found, check status
            status = result["Item"]["status"]
            is_active = status == PIPELINE_STATUS_ACTIVE
        else:  # Pipeline not found
            is_active = False

        return is_active

    def delete_execution_id(self, *, execution_id: str) -> None:
        """Deletes a execution metadata record by execution_id

        Parameters
        ----------
        execution_id : str
            execution_id to delete

        Returns
        -------
        None
        """

        self.peh_table.delete_item(
            Key={"id": execution_id},
        )
