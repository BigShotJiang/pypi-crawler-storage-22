import json
import logging
from decimal import Decimal
from typing import Any

from aws_lambda_powertools.utilities.typing import LambdaContext
from sofbase.common.constants import (
    ExecutionType,
    PipelineStatus,
    SOFGlobalConstantsNamespace,
    SubTaskType,
    TaskStatus,
    TaskType,
)
from sofbase.common.date_formatting_service import DateFormattingService
from sofbase.common.logger import LoggingService
from sofbase.common.models.task import Task, TaskPayload
from sofbase.common.models.workflow_input import WorkflowInput
from sofbase.common.task_processing_service import TaskProcessingService
from sofbase.common.utils.commons import (
    GeneralEncoder,
    get_json_config_file,
    return_ssm_param,
)
from sofbase.services.abort_manager import ExecutionAbortManager
from sofbase.services.metadata_manager import ExecutionMetadataManager

SOF = SOFGlobalConstantsNamespace()
logger = LoggingService().initialize_logger(log_level=logging.INFO, service="OrchestrationManager")


# TODO: CGG - ORCH - Low: Review Task Orchestrator Lambda Timeout!
class OrchestrationManager:
    """
    Orchestration Manager
    """

    def __init__(
        self,
    ) -> None:
        """
        OrchestrationManager Definition
        """

    def handle_event(self, *, event: dict[Any, Any], lambda_context: LambdaContext) -> Any:
        logger.info(
            {
                "service": "OrchestrationManager",
                "operation": "StartHandleEvent",
                "event": event,
                "lambda_contex": lambda_context,
            }
        )

        execution_type = event.get("execution_type", None)
        if execution_type is None:
            raise Exception("Execution type can't be None")

        if execution_type == ExecutionType.HANDLE_WORKFLOW_ABORT:

            logger.info(
                {
                    "service": "OrchestrationManager",
                    "operation": "HandleWorkflowAbort",
                    "event": event,
                    "lambda_contex": lambda_context,
                }
            )
            abort_manager = ExecutionAbortManager(
                execution_arn=event["executionArn"],
                logger=logger,
            )
            abort_manager.abort_processes_if_running()
        elif execution_type == ExecutionType.HANDLE_WORKFLOW_PREPARATION:

            logger.info(
                {
                    "service": "OrchestrationManager",
                    "operation": "HandleWorkflowPreparation",
                    "event": event,
                    "lambda_contex": lambda_context,
                }
            )
            workflow_name = event["payload"]["workflow_name"]
            emm = ExecutionMetadataManager(execution_id=event["payload"]["main_execution_id"])
            registry_record = emm.get_pipeline_registry_record(pipeline_name=workflow_name)
            if registry_record is None:
                raise Exception(
                    f"Pipeline registry record not found for workflow {workflow_name}. "
                    "Please ensure the workflow is registered in the pipeline registry dynamodb table"
                )
            data_domain = registry_record.get("data_domain", "default")
            data_product = registry_record.get("data_product", "default")
            team_name = registry_record.get("team", "default")
            data_sub_domain = registry_record.get("data_sub_domain", "default")

            workflow_input = WorkflowInput(**event["payload"]["workflow_execution_input"])

            emm.start_pipeline_execution(
                pipeline_name=event["payload"]["workflow_name"],
                data_domain_name=data_domain,
                data_product_name=data_product,
                team_name=team_name,
                data_sub_domain=data_sub_domain,
                pipeline_input=workflow_input.model_dump(mode="json"),
                comment=f"Executed in preparation step for workflow {workflow_name}",
            )
        elif execution_type == ExecutionType.HANDLE_WORKFLOW_ERROR:

            logger.info(
                {
                    "service": "OrchestrationManager",
                    "operation": "PreParseHandleWorkflowError",
                    "event": event,
                    "lambda_contex": lambda_context,
                }
            )

            cause_string = event["payload"]["Cause"]
            child_cause = json.loads(cause_string)
            input = json.loads(child_cause["Input"])
            leaf_cause = json.loads(child_cause["Cause"])

            if "errorCause" in leaf_cause:
                try:
                    leaf_cause["errorCause"] = json.loads(leaf_cause["errorCause"])
                except json.JSONDecodeError:
                    pass  # Cause is a simple string, not a dict

            child_cause["Cause"] = leaf_cause

            # Propagate child errors (errorType) up to the root.
            child_cause["Error"] = leaf_cause["errorType"]

            failed_task = Task(**input)

            logger.info(
                {
                    "service": "OrchestrationManager",
                    "operation": "PostParseHandleWorkflowError",
                    "main_execution_id": failed_task.parent.execution_input.main_execution_id,
                    "task_id": failed_task.parameters.task_id,
                    "child_cause": child_cause,
                    "workflow_name": failed_task.parameters.workflow_name,
                    "event": event,
                    "lambda_contex": lambda_context,
                }
            )

            execution_depth = failed_task.parent.execution_input.execution_depth
            if execution_depth == 0:

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "UpdatingMainPipelineWithFailure",
                        "main_execution_id": failed_task.parent.execution_input.main_execution_id,
                        "task_id": failed_task.parameters.task_id,
                        "workflow_name": failed_task.parameters.workflow_name,
                        "child_cause": child_cause,
                        "lambda_contex": lambda_context,
                        "event": event,
                    }
                )

                emm = ExecutionMetadataManager(
                    execution_id=failed_task.parent.execution_input.main_execution_id
                )

                emm.update_pipeline_execution(
                    status=PipelineStatus.PIPELINE_FAILED, extra_metadata=event
                )
            else:

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "SubWorkflowFailed",
                        "main_execution_id": failed_task.parent.execution_input.main_execution_id,
                        "task_id": failed_task.parameters.task_id,
                        "workflow_name": failed_task.parameters.workflow_name,
                        "cause": child_cause,
                        "lambda_contex": lambda_context,
                        "cause.input": input,
                        "event": event,
                    }
                )

            return child_cause

        elif execution_type == ExecutionType.HANDLE_WORKFLOW_SUCCESS:

            logger.info(
                {
                    "service": "OrchestrationManager",
                    "operation": "HandleWorkflowSucccess",
                    "main_execution_id": event["payload"][0]["main_execution_id"],
                    "event": event,
                    "lambda_contex": lambda_context,
                }
            )
            # TODO - CGG - WOW - Fix Execution Depth and Workflow of Workflows.
            execution_depth = event["payload"][0].get("execution_depth", 0)
            if execution_depth == 0:

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "UpdatingMainPipelineWithSuccess",
                        "main_execution_id": event["payload"][0]["main_execution_id"],
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                emm = ExecutionMetadataManager(
                    execution_id=event["payload"][0]["main_execution_id"]
                )
                emm.update_pipeline_execution(
                    status=PipelineStatus.PIPELINE_COMPLETED, extra_metadata=event
                )

            return ExecutionType.HANDLE_WORKFLOW_SUCCESS
        else:  # is a task

            # TODO: CGG - ORCH - High: Skip this initial block if there is a Checkpoint? (Review with Diego)

            task_payload = TaskPayload(**event["payload"])
            emm = ExecutionMetadataManager(
                execution_id=task_payload.task.parent.execution_input.main_execution_id,
            )
            registry_record = emm.get_pipeline_registry_record(
                pipeline_name=task_payload.task.parameters.workflow_name
            )
            if registry_record is None:
                raise Exception(
                    f"Pipeline registry record not found for workflow {task_payload.task.parameters.workflow_name}. "
                    "Please ensure the workflow is registered in the pipeline registry dynamodb table"
                )
            data_domain = registry_record.get("data_domain", "default")
            data_product = registry_record.get("data_product", "default")
            team_name = registry_record.get("team", "default")
            data_sub_domain = registry_record.get("data_sub_domain", "default")
            cost_center = registry_record.get("cost_center", "default")
            task_payload.task.data_domain_name = data_domain
            task_payload.task.data_product_name = data_product
            task_payload.task.team_name = team_name
            task_payload.task.data_sub_domain = data_sub_domain

            task_payload.task.parameters.capacity_config = registry_record.get(
                "capacity_config", {}
            )

            checkpoint = self.contains_checkpoint(
                task_payload=task_payload, execution_type=execution_type
            )

            artifacts_bucket = return_ssm_param(
                ssm_key=f"/{SOF.APP_NAME}/Foundation/S3/ArtifactsBucket/Name"
            )

            logger.info(
                {
                    "service": "OrchestrationManager",
                    "operation": "StartTaskHandler",
                    "orchestration_execution_type": execution_type,
                    "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                    "task_contains_checkpoint": checkpoint,
                    "task_id": task_payload.task.parameters.task_id,
                    "workflow_name": task_payload.task.parameters.workflow_name,
                    "task_payload": task_payload.model_dump(mode="json"),
                    "event": event,
                    "lambda_contex": lambda_context,
                }
            )

            config_file = {}
            if task_payload.task.task_type == TaskType.SUB_WORKFLOW:

                # It's a Sub StepFunction Task
                task_payload.task.sub_task_type = SubTaskType.STEP_FUNCTIONS_PROCESSOR

            else:  # It's a simple task

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "ReadingTaskConfigFile",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_contains_checkpoint": checkpoint,
                        "task_id": task_payload.task.parameters.task_id,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                config_file = get_json_config_file(
                    rules_path=task_payload.task.parent.execution_input.rules_path,
                    workflow_name=task_payload.task.parameters.workflow_name,
                    task_id=task_payload.task.parameters.task_id,
                    artifacts_bucket=artifacts_bucket,
                    dynamic_mode=task_payload.task.parent.execution_input.dynamic_rules,
                )

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "LoadingTaskConfigFile",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_config_file": config_file,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                task_payload.task.sub_task_type = SubTaskType(
                    config_file["ProcessingFramework"]["Type"]
                )

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "SubTaskTypeIdentification",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

            dateformat_service = DateFormattingService()
            task_payload = dateformat_service.process_dates(payload=task_payload.model_dump())

            service = TaskProcessingService()
            processor = service.select_processing_strategy(
                payload=task_payload.model_dump(), config_file=config_file
            )

            # Common Extra Entries
            extra: dict[str, str | int | dict[str, str | Decimal]] = {
                "cost_center": cost_center,
                "message": f"Extra metadata for task id: {task_payload.task.parameters.task_id}",
            }

            if event["execution_type"] == ExecutionType.INVOKE_TASK:

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PreInvokeTask",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                if checkpoint:
                    task_payload.task.status = TaskStatus.SKIPPED
                else:
                    task_payload = processor.invoke_task(payload=task_payload.model_dump())

                if task_payload.task.parameters.task_run_id is not None:
                    extra["task_run_id"] = task_payload.task.parameters.task_run_id
                if task_payload.task.parameters.task_name is not None:
                    extra["task_name"] = task_payload.task.parameters.task_name

                if task_payload.task.processor_result is not None:
                    extra["processor_result"] = task_payload.task.processor_result

                emm.update_pipeline_task_execution(
                    parent_execution_id=task_payload.task.parent.execution_id,
                    task_id=task_payload.task.parameters.task_id,
                    status=task_payload.task.status,
                    task_type=task_payload.task.task_type,
                    sub_task_type=task_payload.task.sub_task_type,
                    extra=extra,
                )

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PostInvokeTask",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "task_status": task_payload.task.status,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                return task_payload.model_dump(mode="json")

            elif event["execution_type"] == ExecutionType.CHECK_STATUS:

                # Works ok
                # raise Exception("just any exception error")
                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PreCheckStatus",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "task_status": task_payload.task.status,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                if checkpoint:
                    task_payload.task.status = TaskStatus.SKIPPED
                else:
                    task_payload = processor.get_task_status(payload=event["payload"])

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PostCheckStatus",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "task_status": task_payload.task.status,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                return json.loads(json.dumps(task_payload.model_dump(), cls=GeneralEncoder))

            elif event["execution_type"] == ExecutionType.HANDLE_TASK_SUCCESS:

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PreHandleTaskSuccess",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                if task_payload.task.parameters.task_run_id is not None:
                    extra["task_run_id"] = task_payload.task.parameters.task_run_id

                if task_payload.task.processor_result is not None:
                    extra["processor_result"] = task_payload.task.processor_result

                emm.update_pipeline_task_execution(
                    parent_execution_id=task_payload.task.parent.execution_id,
                    task_id=task_payload.task.parameters.task_id,
                    status=task_payload.task.status,
                    task_type=task_payload.task.task_type,
                    sub_task_type=task_payload.task.sub_task_type,
                    extra=extra,
                )

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PostHandleTaskSuccess",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "task_status": task_payload.task.status,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                return "handle-success ok"

            elif event["execution_type"] == ExecutionType.HANDLE_TASK_ERROR:

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PreHandleTaskError",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                task_payload = processor.get_task_status(payload=event["payload"])

                if task_payload.task.parameters.task_run_id is not None:
                    extra["task_run_id"] = task_payload.task.parameters.task_run_id

                if task_payload.task.processor_result is not None:
                    extra["processor_result"] = task_payload.task.processor_result

                emm.update_pipeline_task_execution(
                    parent_execution_id=task_payload.task.parent.execution_id,
                    task_id=task_payload.task.parameters.task_id,
                    status=task_payload.task.status,
                    task_type=task_payload.task.task_type,
                    sub_task_type=task_payload.task.sub_task_type,
                    extra=extra,
                )

                # WARN: errorType and errorCause keys are referenced in Task Executor StepFunctions.
                error_cause: dict[str, Any] = {
                    "errorMessage": (
                        f"Task {task_payload.task.parameters.task_id}"
                        f" of type {task_payload.task.sub_task_type} failed"
                    ),
                    "errorType": task_payload.task.error_type,
                    "errorCause": task_payload.task.error_cause,
                    "failedTaskId": task_payload.task.parameters.task_id,
                    "failedProcessorType": task_payload.task.sub_task_type,
                    "failedTaskRunId": task_payload.task.parameters.task_run_id,
                    "taskOrchestratorLambdaLogGroupName": lambda_context.log_group_name,
                }

                if task_payload.task.error_extra is not None:
                    error_cause["processorErrorExtraInfo"] = task_payload.task.error_extra

                error: dict[str, Any] = {
                    "errorType": task_payload.task.error_type,
                    "errorCause": error_cause,
                }

                logger.info(
                    {
                        "service": "OrchestrationManager",
                        "operation": "PostHandleTaskError",
                        "orchestration_execution_type": execution_type,
                        "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                        "task_id": task_payload.task.parameters.task_id,
                        "sub_task_type": task_payload.task.sub_task_type,
                        "workflow_name": task_payload.task.parameters.workflow_name,
                        "task_payload": task_payload.model_dump(mode="json"),
                        "error": error,
                        "event": event,
                        "lambda_contex": lambda_context,
                    }
                )

                return json.loads(json.dumps(error, cls=GeneralEncoder))

            return "invalid execution type"

    def contains_checkpoint(self, *, task_payload: TaskPayload, execution_type: str) -> bool:
        """Returns True if the task or task level contains a checkpoint mark and should be skipped.
            False otherwise.


        Parameters
        ----------
        task_payload : TaskPayload
            Task Payload

        Returns
        -------
        bool
            Returns True if the task or task level contains a checkpoint mark and should be skipped.
            False otherwise.
        """
        logger.info(
            {
                "service": "OrchestrationManager",
                "operation": "StartValidateCheckpoint",
                "orchestration_execution_type": execution_type,
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_id": task_payload.task.parameters.task_id,
                "sub_task_type": task_payload.task.sub_task_type,
                "workflow_name": task_payload.task.parameters.workflow_name,
                "task_payload": task_payload.model_dump(mode="json"),
            }
        )

        skip_task = False
        skip_type = "NotSkippingTask"

        if task_payload.task.parent.execution_input.additional_properties is not None:
            checkpoint = task_payload.task.parent.execution_input.additional_properties.get(
                "checkpoint", None
            )
            if checkpoint is not None:
                checkpoint_level = checkpoint.get("startAtLevel", None)
                tasks_to_skip = checkpoint.get("skipTasks", None)
                # TODO: CGG - ORCH - Low: Add total levels of workflow to notify overflow
                # Case: Checkpoint_Level > workflow total levels
                if checkpoint_level is not None and isinstance(checkpoint_level, int):
                    if task_payload.task.level_index < checkpoint_level:
                        skip_task = True
                        skip_type = "FoundCheckpointAtLevel"
                elif not isinstance(checkpoint_level, int):
                    logger.warning(
                        {
                            "service": "OrchestrationManager",
                            "warn": "received checkpoint level with invalid data or type (should be int)",
                            "received_type": type(checkpoint_level),
                            "task_payload": task_payload.model_dump(mode="json"),
                        }
                    )
                if tasks_to_skip is not None and isinstance(tasks_to_skip, list):
                    if task_payload.task.parameters.task_id in tasks_to_skip:
                        skip_task = True
                        skip_type = "FoundTaskCheckpoint"

                elif not isinstance(tasks_to_skip, list):
                    logger.warning(
                        {
                            "service": "OrchestrationManager",
                            "warn": "received checkpoint tasks with invalid data or type (should a be list).",
                            "received_type": type(tasks_to_skip),
                            "task_payload": task_payload.model_dump(mode="json"),
                        }
                    )
                else:
                    logger.warning(
                        {
                            "service": "OrchestrationManager",
                            "warn": "Workflow Input has checkpoint, but skipTasks is None",
                            "task_payload": task_payload.model_dump(mode="json"),
                        }
                    )

        logger.info(
            {
                "service": "OrchestrationManager",
                "operation": "PostValidateCheckpoint",
                "orchestration_execution_type": execution_type,
                "skipping_task": skip_task,
                "skip_type": skip_type,
                "main_execution_id": task_payload.task.parent.execution_input.main_execution_id,
                "task_id": task_payload.task.parameters.task_id,
                "sub_task_type": task_payload.task.sub_task_type,
                "workflow_name": task_payload.task.parameters.workflow_name,
                "task_payload": task_payload.model_dump(mode="json"),
            }
        )

        return skip_task

    def handle_event2(
        self, *, execution_type: str, payload: dict[Any, Any], lambda_context: LambdaContext
    ) -> Any:

        result = None
        match execution_type:
            case ExecutionType.HANDLE_WORKFLOW_SUCCESS:
                result = self.handle_workflow_success(
                    payload=payload, lambda_context=lambda_context
                )
            case ExecutionType.HANDLE_TASK_ERROR:
                result = self.handle_workflow_error(payload=payload, lambda_context=lambda_context)
            case _:
                print("Execution Type Not Supported")

        return result

    def handle_workflow_success(
        self, *, payload: dict[Any, Any], lambda_context: LambdaContext
    ) -> Any:

        print(f"Handling {ExecutionType.HANDLE_WORKFLOW_SUCCESS}")

        return {}

    def handle_workflow_error(
        self, *, payload: dict[Any, Any], lambda_context: LambdaContext
    ) -> Any:

        print(f"Handling {ExecutionType.HANDLE_TASK_ERROR}")

        return {}
