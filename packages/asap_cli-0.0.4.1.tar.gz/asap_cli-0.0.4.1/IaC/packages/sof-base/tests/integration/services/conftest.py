import uuid
from typing import Any, Generator

import pytest
from sofbase.services.metadata_manager import ExecutionMetadataManager


@pytest.fixture(scope="function")
def emm() -> Generator[ExecutionMetadataManager, Any, None]:
    execution_id = str(uuid.uuid4())
    emm = ExecutionMetadataManager(execution_id=execution_id)

    yield emm
    print(f"Tearing down {execution_id}")
    emm.delete_execution_id(execution_id=execution_id)


@pytest.fixture(scope="module")
def pipeline_name() -> Generator[str, Any, None]:
    pipeline_name = f"test-integration-metadata-manager-{str(uuid.uuid4())}"
    emm = ExecutionMetadataManager()
    emm.add_pipeline_registry_record(pipeline_name=pipeline_name)
    yield pipeline_name
    print(f"Tearing down {pipeline_name} registry record")
    emm.delete_pipeline_registry_record(pipeline_name=pipeline_name)


@pytest.fixture(scope="module")
def task_payload_dummy_task1() -> dict[str, Any]:
    task_payload: dict[str, Any] = {
        "execution_id": "arn:aws:states:us-east-1:123456789123:execution:asap-aws-dev-torc-dwap-stp-task-executor:cce645e4-642d-461b-8d8f-a4f4982ff92c",
        "start_time": "2025-08-13T01:04:55.915Z",
        "task": {
            "task_type": "DataProcessor",
            "status": "NOT_STARTED",
            "parameters": {
                "task_id": "dummy_task11",
                "task_executor_wait_time_seconds": 3,
                "timeout": 12,
                "end_date": "2025-08-13",
                "workflow_name": "test-big-demo-workflow",
                "rules_path": "rules",
                "additional_properties": None,
                "main_execution_id": "dwap.test-big-demo-workflow-20250813_010411",
                "start_date": "2025-08-13",
            },
            "parent": {
                "execution_id": "arn:aws:states:us-east-1:123456789123:execution:test-big-demo-workflow:dwap.test-big-demo-workflow-20250813_010411",
                "start_time": "2025-08-13T01:04:13.909Z",
                "execution_input": {
                    "rules_path": "rules",
                    "start_date": "2025-08-13",
                    "end_date": "2025-08-13",
                    "additional_properties": None,
                    "main_execution_id": "dwap.test-big-demo-workflow-20250813_010411",
                    "execution_level": 1,
                },
                "role_arn": "arn:aws:iam::123456789123:role/asap-aws-dev-tlkf-dwap-sfn-task-executor-role",
                "redrive_count": 0,
                "execution_name": "dwap.test-big-demo-workflow-20250813_010411",
            },
            "level_index": 1,
            "thread_index": 1,
            "task_index": 3,
            "execution_environment": "dev",
        },
        "role_arn": "arn:aws:iam::123456789123:role/asap-aws-dev-tlkf-dwap-sfn-task-executor-role",
        "redrive_count": 0,
        "execution_name": "cce645e4-642d-461b-8d8f-a4f4982ff92c",
    }
    return task_payload
