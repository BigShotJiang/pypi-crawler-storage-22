from sofbase.common.constants import SOFGlobalConstantsNamespace
from sofbase.common.logger import LoggingService
from sofbase.services.abort_manager import ExecutionAbortManager

SOF = SOFGlobalConstantsNamespace()


def main() -> None:

    logger = LoggingService().initialize_logger(log_level="INFO", service="AbortManager")
    abort_manager = ExecutionAbortManager(
        execution_arn="arn:aws:states:us-east-1:049618906732:execution:test-glue-workflow:test-glue-workflow-20250529_230249",
        logger=logger,
    )
    abort_manager.abort_processes_if_running()


if __name__ == "__main__":
    main()
