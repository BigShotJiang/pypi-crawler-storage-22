import json
import os
from decimal import Decimal

import boto3
from sofbase.common.constants import PipelineStatus, SubTaskType, TaskStatus, TaskType
from sofbase.common.models.execution_metadata import PipelineExecutionMetadata
from sofbase.common.utils.commons import DecimalEncoder
from sofbase.services.metadata_manager import ExecutionMetadataManager

os.environ["AWS_PROFILE"] = "default"
os.environ["AWS_DEFAULT_REGION"] = "us-east-1"
os.environ["REGION"] = "us-east-1"
boto3.setup_default_session(profile_name=os.environ["AWS_PROFILE"])


def test_happy_path(emm: ExecutionMetadataManager, pipeline_name: str) -> None:
    """Tests that execution metadata manager works for a successful
    pipeline execution. It leverages the ExecutionMetadataManager
    fixture from conftest.py.

    Parameters
    ----------
    emm : ExecutionMetadataManager
        ExecutionMetadataManager (Fixture Input)

    """

    data_domain_name = "DATA_DOMAIN_1"
    data_sub_domain = "DATA_SUB_DOMAIN_1"
    data_product_name = "DATA_PRODUCT_A"
    team_name = "test_team1"

    pipeline_input = {"event_key1": "A", "event_key2": "B"}
    extra = {
        "cost_center": "cost_center_1",
        "duration_in_seconds": 0,
        "message": "Step_ID_001 Any message",
    }

    execution_id = emm.start_pipeline_execution(
        pipeline_name=pipeline_name,
        data_domain_name=data_domain_name,
        data_product_name=data_product_name,
        pipeline_input=pipeline_input,
        team_name=team_name,
        data_sub_domain=data_sub_domain,
    )

    # Updating Task1 Running
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id,
        task_id="Task1",
        status=TaskStatus.RUNNING,
        task_type=TaskType("DataProcessor"),
        sub_task_type=SubTaskType.GLUE_DATA_PROCESSOR,
        extra=extra,
    )

    # Updating Task1 Completed
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id, task_id="Task1", status=TaskStatus.SUCCEEDED, extra=extra
    )

    # Updating Task2 without extra
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id,
        task_id="Task2",
        status=TaskStatus.RUNNING,
    )

    # Updating Task2 Completed
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id, task_id="Task2", status=TaskStatus.SUCCEEDED, extra=extra
    )

    pipe_extra = {
        "cost_center": "cost_center_1",
        "duration_in_seconds": 0,
        "message": "Step_ID_001 Any message",
    }

    # Updating Pipeline as Completed
    emm.update_pipeline_execution(
        status=PipelineStatus.PIPELINE_COMPLETED, extra_metadata=pipe_extra
    )

    item = emm.get_peh_record(peh_id=emm.execution_id)
    print(json.dumps(item, indent=2, cls=DecimalEncoder))

    if item is not None:
        result = PipelineExecutionMetadata(**item)
        assert len(result.task_history) == 4
        assert result.active is False
        assert result.success is True
        assert isinstance(result.duration_in_seconds, Decimal)

        task_extra = result.task_history[0].extra

        if task_extra is None:
            raise Exception("Task  Shouldn't be None")
        assert task_extra["cost_center"] == extra["cost_center"]

        if result.extra_metadata is None:
            raise Exception("Extra Metadata Shouldn't be None")
        assert result.extra_metadata["cost_center"] == pipe_extra["cost_center"]
    else:
        raise Exception("Item is None when it should't be")


def test_failure_path(emm: ExecutionMetadataManager, pipeline_name: str) -> None:
    """Tests that execution metadata manager works for a failed
    pipeline execution. It leverages the ExecutionMetadataManager
    fixture from conftest.py.

    Parameters
    ----------
    emm : ExecutionMetadataManager
        ExecutionMetadataManager (Fixture Input)

    """

    data_domain_name = "DATA_DOMAIN_1"
    data_sub_domain = "DATA_SUB_DOMAIN_1"
    data_product_name = "DATA_PRODUCT_A"
    team_name = "test_team1"

    pipeline_input = {"event_key1": "A", "event_key2": "B"}
    extra = {
        "cost_center": "cost_center_1",
        "duration_in_seconds": 0,
        "message": "Step_ID_001 Any message",
    }

    execution_id = emm.start_pipeline_execution(
        pipeline_name=pipeline_name,
        data_domain_name=data_domain_name,
        data_product_name=data_product_name,
        pipeline_input=pipeline_input,
        team_name=team_name,
        data_sub_domain=data_sub_domain,
    )

    # Updating Task1 Running
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id,
        task_id="Task1",
        status=TaskStatus.RUNNING,
        task_type=TaskType("DataProcessor"),
        sub_task_type=SubTaskType.GLUE_DATA_PROCESSOR,
        extra=extra,
    )

    # Updating Task1 Completed
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id, task_id="Task1", status=TaskStatus.SUCCEEDED, extra=extra
    )

    # Updating Task2 without extra
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id,
        task_id="Task2",
        status=TaskStatus.RUNNING,
    )

    # Updating Task2 Completed
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id, task_id="Task2", status=TaskStatus.FAILED, extra=extra
    )

    pipe_extra = {
        "cost_center": "cost_center_1",
        "duration_in_seconds": 0,
        "message": "Step_ID_001 Any message",
    }

    # Updating Pipeline as Completed
    emm.update_pipeline_execution(status=PipelineStatus.PIPELINE_FAILED, extra_metadata=pipe_extra)

    item = emm.get_peh_record(peh_id=emm.execution_id)
    print(json.dumps(item, indent=2, cls=DecimalEncoder))

    if item is not None:
        result = PipelineExecutionMetadata(**item)
        assert len(result.task_history) == 4
        assert result.active is False
        assert result.success is False
        assert isinstance(result.duration_in_seconds, Decimal)

        task_extra = result.task_history[0].extra

        if task_extra is None:
            raise Exception("Task  Shouldn't be None")
        assert task_extra["cost_center"] == extra["cost_center"]

        if result.extra_metadata is None:
            raise Exception("Extra Metadata Shouldn't be None")
        assert result.extra_metadata["cost_center"] == pipe_extra["cost_center"]
    else:
        raise Exception("Item is None when it should't be")


# @pytest.mark.filterwarnings("ignore::DeprecationWarning")
def test_active_pipeline(emm: ExecutionMetadataManager, pipeline_name: str) -> None:
    """Tests that execution metadata manager leaves a
    execution metadata item in active state after a single
    task update.

    Parameters
    ----------
    emm : ExecutionMetadataManager
        ExecutionMetadataManager (Fixture Input)

    """

    data_domain_name = "DATA_DOMAIN_1"
    data_sub_domain = "DATA_SUB_DOMAIN_1"
    data_product_name = "DATA_PRODUCT_A"
    team_name = "test_team1"

    pipeline_input = {"event_key1": "A", "event_key2": "B"}
    extra = {
        "cost_center": "cost_center_1",
        "duration_in_seconds": 0,
        "message": "Step_ID_001 Any message",
    }

    execution_id = emm.start_pipeline_execution(
        pipeline_name=pipeline_name,
        data_domain_name=data_domain_name,
        data_product_name=data_product_name,
        pipeline_input=pipeline_input,
        team_name=team_name,
        data_sub_domain=data_sub_domain,
    )

    # Updating Task1 Running
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id,
        task_id="Task1",
        status=TaskStatus.RUNNING,
        task_type=TaskType("DataProcessor"),
        sub_task_type=SubTaskType.GLUE_DATA_PROCESSOR,
        extra=extra,
    )

    # Updating Task1 Completed
    emm.update_pipeline_task_execution(
        parent_execution_id=execution_id, task_id="Task1", status=TaskStatus.SUCCEEDED, extra=extra
    )

    item = emm.get_peh_record(peh_id=emm.execution_id)
    print(json.dumps(item, indent=2, cls=DecimalEncoder))

    if item is not None:
        result = PipelineExecutionMetadata(**item)
        assert len(result.task_history) == 2
        assert result.active is True
        assert result.success is False
        assert result.duration_in_seconds is not None

        task_extra = result.task_history[0].extra

        if task_extra is None:
            raise Exception("Task Shouldn't be None")
        assert task_extra["cost_center"] == extra["cost_center"]

        assert result.extra_metadata is None

    else:
        raise Exception("Item is None when it should't be")
