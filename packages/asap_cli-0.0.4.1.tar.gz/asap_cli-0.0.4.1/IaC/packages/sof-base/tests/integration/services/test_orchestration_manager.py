import os
from typing import Any

import boto3
import pytest
from sofbase.common.constants import ExecutionType
from sofbase.common.models.task import TaskPayload
from sofbase.services.orchestration_manager import OrchestrationManager

os.environ["AWS_PROFILE"] = "default"
os.environ["AWS_DEFAULT_REGION"] = "us-east-1"
os.environ["REGION"] = "us-east-1"
boto3.setup_default_session(profile_name=os.environ["AWS_PROFILE"])


@pytest.mark.parametrize(
    "additional_properties, expected",
    [
        (
            {"checkpoint": {"startAtLevel": 3}},
            True,
        ),
        (
            {"checkpoint": {"startAtLevel": 2, "skipTasks": ["dummy_task1"]}},
            True,
        ),
        (
            {"checkpoint": {"skipTasks": ["dummy_task1", "dummy_task10", "dummy_task11"]}},
            True,
        ),
        (
            {"checkpoint": {"skipTasks": ["dummy_task11"]}},
            True,
        ),
        (
            {"checkpoint": {"skipTasks": []}},
            False,
        ),
        (
            {"checkpoint": {}},
            False,
        ),
        (
            None,
            False,
        ),
    ],
)
def test_contains_checkpoint(
    task_payload_dummy_task1: dict[str, Any], additional_properties: dict | None, expected: bool
) -> None:
    """Tests that Orchestration Manager Correctly validates checkpoints.
    It leverages the  fixture from conftest.py.

    Parameters
    ----------
    task_payload_dummy_task1 :  dict[str, Any]
        fixture from conftest.py
        A valid sofbase.common.models.task.TaskPayload dict

    """
    om = OrchestrationManager()
    task_payload = TaskPayload(**task_payload_dummy_task1)
    task_payload.task.parent.execution_input.additional_properties = additional_properties
    checkpoint = om.contains_checkpoint(
        task_payload=task_payload, execution_type=ExecutionType.INVOKE_TASK
    )
    assert checkpoint == expected
