from time import sleep

from aws_lambda_powertools.utilities.typing import LambdaContext
from sofbase.services.orchestration_manager import OrchestrationManager


def main() -> None:

    test_dynamodb_execution_id = "main_id"

    invoke_payload = {
        "execution_id": "1:2:3:4:5:6:7",
        "start_time": "2025-04-25T19:48:30.696Z",
        "task": {
            "task_type": "DataProcessor",
            "status": "NOT_STARTED",
            "parameters": {
                "task_id": "etl_step_1_raw_sales",
                "task_executor_wait_time_seconds": 20,
                "timeout": 12,
                "start_dttm": "2025-04-25T19:48:30.466Z",
                "end_dttm": "2025-04-25T21:48:30.466Z",
                "dttm_format": "%Y-%m-%dT%H:%M:%S.%fZ",
                "workflow_name": "demo-redshift-workflow",
                "rules_path": "rules",
                "main_execution_id": test_dynamodb_execution_id,
            },
            "parent": {
                "execution_id": "1:2:3:4:5:6:7",
                "start_time": "2025-04-25T19:48:30.466Z",
                "execution_input": {
                    "rules_path": "rules",
                    "start_dttm": "2025-04-25T19:48:30.466Z",
                    "end_dttm": "2025-04-25T21:48:30.466Z",
                    "dttm_format": "%Y-%m-%dT%H:%M:%S.%fZ",
                    "additional_properties": {"always_fail": False},
                    "main_execution_id": test_dynamodb_execution_id,
                    "execution_level": 1,
                },
                "role_arn": "arnrole",
                "redrive_count": 0,
                "execution_name": "execution_name",
            },
            "level_index": 3,
            "thread_index": 1,
            "task_index": 3,
            "execution_environment": "dev",
        },
        "role_arn": "some_role_arn",
        "redrive_count": 0,
        "execution_name": "execution_name",
    }

    om = OrchestrationManager()
    event = {
        "execution_type": "invoke",
        "payload": invoke_payload,
    }
    lambda_context = LambdaContext()
    result = om.handle_event(event=event, lambda_context=lambda_context)
    print("Result Invoke Operation:", result)
    print("Async job id:", result["task"]["parameters"]["task_run_id"])

    # wait async query being executed
    print("wait async query being executed 20 seconds...............")
    sleep(20)

    status_payload = {
        "execution_id": "1:2:3:4:5:6:7",
        "task": {
            "task_type": "DataProcessor",
            "sub_task_type": "GlueDataProcessor",
            "status": "RUNNING",
            "error_type": "null",
            "error_cause": "null",
            "error_extra": {},
            "processor_result": {},
            "parameters": {
                "task_id": "etl_step_1_raw_sales",
                "rules_path": "rules",
                "start_dttm": "2025-04-25T19:48:30.466Z",
                "end_dttm": "2025-04-25T21:48:30.466Z",
                "dttm_format": "%Y-%m-%dT%H:%M:%S.%fZ",
                "workflow_name": "demo-redshift-workflow",
                "task_name": "wandvwlhf-gljo-dwcl-data-processor-default-job",
                "task_run_id": result["task"]["parameters"]["task_run_id"],
                "task_executor_wait_time_seconds": 20,
                "additional_properties": {"always_fail": False},
                "main_execution_id": test_dynamodb_execution_id,
            },
            "parent": {
                "execution_id": "1:2:3:4:5:6:7",
                "execution_input": {
                    "rules_path": "rules",
                    "start_dttm": "2025-04-25T19:48:30.466Z",
                    "end_dttm": "2025-04-25T21:48:30.466Z",
                    "dttm_format": "%Y-%m-%dT%H:%M:%S.%fZ",
                    "additional_properties": {"always_fail": False},
                    "main_execution_id": test_dynamodb_execution_id,
                    "execution_level": 1,
                },
                "start_time": "2025-04-29 00:39:19.420000+00:00",
                "role_arn": "arn:aws:iam::11111111:role/StepFunctionsAdminRole",
                "redrive_count": 0,
                "execution_name": "execution_name_1",
                "workflow_name": "demo-redshift-workflow",
            },
            "level_index": 3,
            "thread_index": 1,
            "task_index": 3,
            "data_domain_name": "DATA_DOMAIN_X",
            "data_product_name": "DATA_PRODUCT_1",
            "execution_environment": "dev",
        },
        "start_time": "2025-04-29 00:39:19.630000+00:00",
        "role_arn": "arn:aws:iam::11111111:role/sof-orch-step-functions-role",
        "redrive_count": 0,
        "execution_name": "execution_name_1",
    }

    event = {
        "execution_type": "status",
        "payload": status_payload,
    }
    lambda_context = LambdaContext()
    result = om.handle_event(event=event, lambda_context=lambda_context)

    print("Result Status Operation:", result)
    print("Task Status :", result["task"]["status"])


if __name__ == "__main__":
    main()
