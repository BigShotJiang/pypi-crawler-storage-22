from time import sleep

from aws_lambda_powertools.utilities.typing import LambdaContext
from sofbase.common.models.task import TaskStatus
from sofbase.services.orchestration_manager import OrchestrationManager


def main() -> None:

    test_dynamodb_execution_id = "main_id"

    invoke_payload = {
        "execution_id": "1:2:3:4:5:6:7",
        "start_time": "2025-04-25T19:48:30.696Z",
        "task": {
            "task_type": "DataProcessor",
            "status": "NOT_STARTED",
            "parameters": {
                "task_id": "etl_step_2_model_fact_sales",
                "task_executor_wait_time_seconds": 20,
                "timeout": 12,
                "start_date": "2025-01-20",
                "end_date": "2025-01-21",
                "workflow_name": "demo-redshift-workflow",
                "rules_path": "rules",
                "main_execution_id": test_dynamodb_execution_id,
            },
            "parent": {
                "execution_id": "1:2:3:4:5:6:7",
                "start_time": "2025-04-25T19:48:30.466Z",
                "execution_input": {
                    "rules_path": "rules",
                    "start_date": "2025-01-20",
                    "end_date": "2025-01-21",
                    "additional_properties": {"always_fail": False},
                    "main_execution_id": test_dynamodb_execution_id,
                    "execution_level": 1,
                },
                "role_arn": "arnrole",
                "redrive_count": 0,
                "execution_name": "execution_name",
            },
            "level_index": 3,
            "thread_index": 1,
            "task_index": 3,
            "execution_environment": "dev",
        },
        "role_arn": "some_role_arn",
        "redrive_count": 0,
        "execution_name": "execution_name",
    }

    om = OrchestrationManager()
    event = {
        "execution_type": "invoke",
        "payload": invoke_payload,
    }
    lambda_context = LambdaContext()
    result = om.handle_event(event=event, lambda_context=lambda_context)
    print("Result Invoke Operation:", result)

    # wait async query being executed
    print("wait async query being executed 15 seconds...............")
    sleep(15)

    status_payload = {
        "execution_id": "1:2:3:4:5:6:7",
        "task": {
            "task_type": "DataProcessor",
            "sub_task_type": "GlueDataProcessor",
            "status": "RUNNING",
            "error_type": "null",
            "error_cause": "null",
            "error_extra": {},
            "processor_result": {},
            "parameters": {
                "task_id": "etl_step_2_model_fact_sales",
                "rules_path": "rules",
                "start_date": "2025-01-20",
                "end_date": "2025-01-21",
                "workflow_name": "demo-redshift-workflow",
                "task_name": "redshift-processor",
                "task_run_id": result["task"]["parameters"]["task_run_id"],
                "task_executor_wait_time_seconds": 20,
                "additional_properties": {"always_fail": False},
                "main_execution_id": test_dynamodb_execution_id,
            },
            "parent": {
                "execution_id": "1:2:3:4:5:6:7",
                "execution_input": {
                    "rules_path": "rules",
                    "start_date": "2025-01-19",
                    "end_date": "2025-01-25",
                    "additional_properties": {"always_fail": False},
                    "main_execution_id": test_dynamodb_execution_id,
                    "execution_level": 1,
                },
                "start_time": "2025-04-29 00:39:19.420000+00:00",
                "role_arn": "arn:aws:iam::11111111:role/StepFunctionsAdminRole",
                "redrive_count": 0,
                "execution_name": "execution_name_1",
                "workflow_name": "demo-redshift-workflow",
            },
            "level_index": 3,
            "thread_index": 1,
            "task_index": 3,
            "execution_environment": "dev",
        },
        "start_time": "2025-04-29 00:39:19.630000+00:00",
        "role_arn": "arn:aws:iam::11111111:role/sof-orch-step-functions-role",
        "redrive_count": 0,
        "execution_name": "execution_name_1",
    }

    event = {
        "execution_type": "status",
        "payload": status_payload,
    }
    lambda_context = LambdaContext()
    result = om.handle_event(event=event, lambda_context=lambda_context)

    print("Result Status Operation:", result)

    assert result["task"]["status"] == TaskStatus.SUCCEEDED
    print("Task Status :", result["task"]["status"])


if __name__ == "__main__":
    main()
