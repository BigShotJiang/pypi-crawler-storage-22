from time import sleep

from sofbase.common.constants import SOFGlobalConstantsNamespace
from sofbase.common.models.task import TaskStatus
from sofbase.common.utils.commons import get_json_config_file, return_ssm_param
from sofbase.processor_handler.redshift import RedshiftDataProcessorHandler

SOF = SOFGlobalConstantsNamespace()


def main() -> None:

    artifacts_bucket = return_ssm_param(
        ssm_key=f"/{SOF.APP_NAME}/Foundation/S3/ArtifactsBucket/Name"
    )
    print("Artifacts Bucket:", artifacts_bucket)

    invoke_payload: dict = {
        "execution_id": "1:2:3:4:5:6:7",
        "start_time": "2025-04-25T19:48:30.696Z",
        "task": {
            "task_type": "DataProcessor",
            "status": "NOT_STARTED",
            "parameters": {
                "task_id": "etl_step_2_model_fact_sales_test",
                "task_executor_wait_time_seconds": 20,
                "timeout": 12,
                "start_date": "2025-01-20",
                "end_date": "2025-01-21",
                "workflow_name": "demo-redshift-workflow",
                "rules_path": "rules",
                "main_execution_id": "main_id",
            },
            "parent": {
                "execution_id": "1:2:3:4:5:6:7",
                "start_time": "2025-04-25T19:48:30.466Z",
                "execution_input": {
                    "rules_path": "rules",
                    "start_date": "2025-01-20",
                    "end_date": "2025-01-21",
                    "additional_properties": {"always_fail": False},
                    "main_execution_id": "main_id",
                    "execution_level": 1,
                },
                "role_arn": "arnrole",
                "redrive_count": 0,
                "execution_name": "execution_name",
            },
            "level_index": 3,
            "thread_index": 1,
            "task_index": 3,
            "data_domain_name": "DATA_DOMAIN_X",
            "data_product_name": "DATA_PRODUCT_1",
            "execution_environment": "dev",
        },
        "role_arn": "some_role_arn",
        "redrive_count": 0,
        "execution_name": "execution_name",
    }

    config_file = get_json_config_file(
        rules_path=invoke_payload["task"]["parameters"]["rules_path"],
        workflow_name=invoke_payload["task"]["parameters"]["workflow_name"],
        task_id=invoke_payload["task"]["parameters"]["task_id"],
        artifacts_bucket=artifacts_bucket,
    )

    handler = RedshiftDataProcessorHandler(config_file=config_file)

    result = handler.invoke_task(payload=invoke_payload)
    print("Valid Payload Result:", result)
    print("Task Async ID:", result.task.parameters.task_run_id)
    # wait async query being executed
    sleep(15)

    status_payload = {
        "execution_id": "1:2:3:4:5:6:7",
        "task": {
            "task_type": "DataProcessor",
            "sub_task_type": "GlueDataProcessor",
            "status": "RUNNING",
            "error_type": "null",
            "error_cause": "null",
            "error_extra": {},
            "processor_result": {},
            "parameters": {
                "task_id": "etl_step_2_model_fact_sales_test",
                "rules_path": "rules",
                "start_date": "2025-01-20",
                "end_date": "2025-01-21",
                "workflow_name": "demo-redshift-workflow",
                "task_name": "redshift-processor",
                "task_run_id": result.task.parameters.task_run_id,
                "task_executor_wait_time_seconds": 20,
                "additional_properties": {"always_fail": False},
                "main_execution_id": "main_id",
            },
            "parent": {
                "execution_id": "1:2:3:4:5:6:7",
                "execution_input": {
                    "rules_path": "rules",
                    "start_date": "2025-01-19",
                    "end_date": "2025-01-25",
                    "additional_properties": {"always_fail": False},
                    "main_execution_id": "main_id",
                    "execution_level": 1,
                },
                "start_time": "2025-04-29 00:39:19.420000+00:00",
                "role_arn": "arn:aws:iam::11111111:role/StepFunctionsAdminRole",
                "redrive_count": 0,
                "execution_name": "execution_name_1",
                "workflow_name": "simple-demo-workflow",
            },
            "level_index": 3,
            "thread_index": 1,
            "task_index": 3,
            "data_domain_name": "DATA_DOMAIN_X",
            "data_product_name": "DATA_PRODUCT_1",
            "execution_environment": "dev",
        },
        "start_time": "2025-04-29 00:39:19.630000+00:00",
        "role_arn": "arn:aws:iam::1111111:role/sof-orch-step-functions-role",
        "redrive_count": 0,
        "execution_name": "execution_name_1",
    }
    result = handler.get_task_status(payload=status_payload)

    print("Task Status :", result.task.status)
    print("Task Error :", result.task.error_cause)
    print("Task Time :", str(result.task.processor_result))
    assert result.task.status == TaskStatus.SUCCEEDED


if __name__ == "__main__":
    main()
