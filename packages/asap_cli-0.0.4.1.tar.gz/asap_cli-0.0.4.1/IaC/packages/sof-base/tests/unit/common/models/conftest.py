from typing import Any

import pytest


@pytest.fixture(scope="module")
def execution_metadata_dict() -> dict[str, Any]:
    data: dict[str, Any] = {
        "id": "DATA_DOMAIN_1-DATA_PRODUCT_A-2025-04-02 21:55:53.820429+00:00",
        "active": False,
        "team_name": "team_name_1",
        "comment": "Pipeline: demo-workflow-datadomain1 has started execution",
        "data_domain_name": "DATA_DOMAIN_1",
        "data_sub_domain": "DATA_SUB_DOMAIN_1",
        "data_domain_product": "DATA_DOMAIN_1#DATA_PRODUCT_A",
        "data_product_name": "DATA_PRODUCT_A",
        "duration_in_seconds": 1.324908,
        "execution_start_date": "2025-04-02",
        "extra_metadata": {"cost_center": "cost_center_1", "message": "Any extra message message"},
        "issue_comment": "Failed with Job Id: 12323536364",
        "last_updated_timestamp": "2025-04-02T21:57:06+00:00",
        "pipeline": "demo-workflow-datadomain1",
        "pipeline_input": {"event_key1": "A", "event_key2": "B"},
        "start_timestamp": "2025-04-02T21:57:05+00:00",
        "status": "PIPELINE_FAILED",
        "status_last_updated_timestamp": "PIPELINE_FAILED#2025-04-02T21:57:06+00:00",
        "success": False,
        "task_history": [
            {
                "extra": {
                    "cost_center": "cost_center_1",
                    "duration_in_seconds": 0,
                    "message": "Step_ID_001 Any message",
                },
                "parent_execution_id": "DATA_DOMAIN_1-DATA_PRODUCT_A-2025-04-02 21:55:53.820429+00:00",
                "status": "STARTING",
                "sub_task_type": "GlueDataProcessor",
                "task_id": "Task1",
                "task_type": "DataProcessor",
                "timestamp": "2025-04-02T21:57:05+00:00",
            },
            {
                "extra": {
                    "cost_center": "cost_center_1",
                    "duration_in_seconds": 0,
                    "message": "Step_ID_001 Any message",
                },
                "parent_execution_id": "DATA_DOMAIN_1-DATA_PRODUCT_A-2025-04-02 21:55:53.820429+00:00",
                "status": "SUCCEEDED",
                "task_id": "Task1",
                "timestamp": "2025-04-02T21:57:05+00:00",
            },
            {
                "parent_execution_id": "DATA_DOMAIN_1-DATA_PRODUCT_A-2025-04-02 21:55:53.820429+00:00",
                "status": "RUNNING",
                "task_id": "Task2",
                "timestamp": "2025-04-02T21:57:05+00:00",
            },
            {
                "extra": {
                    "cost_center": "cost_center_1",
                    "duration_in_seconds": 0,
                    "message": "Step_ID_001 Any message",
                },
                "parent_execution_id": "DATA_DOMAIN_1-DATA_PRODUCT_A-2025-04-02 21:55:53.820429+00:00",
                "status": "FAILED",
                "task_id": "Task2",
                "task_issue_comment": "Task Failed because of ABCDE",
                "timestamp": "2025-04-02T21:57:06+00:00",
            },
        ],
        "ttl": 1812751025,
        "version": 6,
    }
    return data
