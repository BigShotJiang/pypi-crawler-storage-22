from decimal import Decimal

import pytest
from sofbase.common.models.execution_metadata import PipelineExecutionMetadata


@pytest.mark.models
def test_execution_metadata_ttl(execution_metadata_dict: dict) -> None:

    record = PipelineExecutionMetadata(**execution_metadata_dict)
    record_dict = record.model_dump()
    assert isinstance(record_dict["ttl"], Decimal)


@pytest.mark.models
def test_execution_metadata_version(execution_metadata_dict: dict) -> None:

    record = PipelineExecutionMetadata(**execution_metadata_dict)
    record_dict = record.model_dump()
    assert isinstance(record_dict["version"], int)


@pytest.mark.models
def test_execution_metadata_duration_in_seconds(execution_metadata_dict: dict) -> None:

    record = PipelineExecutionMetadata(**execution_metadata_dict)
    record_dict = record.model_dump()
    assert isinstance(record_dict["duration_in_seconds"], Decimal)


@pytest.mark.models
def test_execution_metadata_last_updated_timestamp(execution_metadata_dict: dict) -> None:

    record = PipelineExecutionMetadata(**execution_metadata_dict)
    record_dict = record.model_dump()
    assert isinstance(record_dict["last_updated_timestamp"], str)


@pytest.mark.models
def test_execution_metadata_active(execution_metadata_dict: dict) -> None:

    record = PipelineExecutionMetadata(**execution_metadata_dict)
    record_dict = record.model_dump()
    assert isinstance(record_dict["active"], bool)


@pytest.mark.models
def test_execution_metadata_success(execution_metadata_dict: dict) -> None:

    record = PipelineExecutionMetadata(**execution_metadata_dict)
    record_dict = record.model_dump()
    assert isinstance(record_dict["success"], bool)
