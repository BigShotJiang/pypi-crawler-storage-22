from typing import Any

from sofbase.common.models.task import DataProcessingParameters, TaskPayload

# TODO: CGG - TESTS - High: Add all TaskPayload Combinations

global_input_payload: dict[Any, Any] = {
    "execution_id": "arn:aws:states:us-east-1:123456789123:execution:asap-aws-dev-torc-dwap-stp-task-executor:cce645e4-642d-461b-8d8f-a4f4982ff92c",
    "start_time": "2025-08-13T01:04:55.915Z",
    "task": {
        "task_type": "DataProcessor",
        "status": "NOT_STARTED",
        "parameters": {
            "task_id": "dummy_task11",
            "task_executor_wait_time_seconds": 3,
            "timeout": 12,
            "end_date": "2025-08-13",
            "workflow_name": "test-big-demo-workflow",
            "rules_path": "rules",
            "additional_properties": None,
            "main_execution_id": "dwap.test-big-demo-workflow-20250813_010411",
            "start_date": "2025-08-13",
        },
        "parent": {
            "execution_id": "arn:aws:states:us-east-1:123456789123:execution:test-big-demo-workflow:dwap.test-big-demo-workflow-20250813_010411",
            "start_time": "2025-08-13T01:04:13.909Z",
            "execution_input": {
                "rules_path": "rules",
                "start_date": "2025-08-13",
                "end_date": "2025-08-13",
                "additional_properties": None,
                "main_execution_id": "dwap.test-big-demo-workflow-20250813_010411",
                "execution_level": 1,
            },
            "role_arn": "arn:aws:iam::123456789123:role/asap-aws-dev-tlkf-dwap-sfn-task-executor-role",
            "redrive_count": 0,
            "execution_name": "dwap.test-big-demo-workflow-20250813_010411",
        },
        "level_index": 1,
        "thread_index": 1,
        "task_index": 3,
        "execution_environment": "dev",
    },
    "role_arn": "arn:aws:iam::123456789123:role/asap-aws-dev-tlkf-dwap-sfn-task-executor-role",
    "redrive_count": 0,
    "execution_name": "cce645e4-642d-461b-8d8f-a4f4982ff92c",
}


def test_full_orchestration_stepfunction_parameters() -> None:
    input_payload: dict[Any, Any] = {
        "execution_id": "arn:aws:states:us-east-1:123456789123:execution:asap-aws-dev-torc-dwap-stp-task-executor:cce645e4-642d-461b-8d8f-a4f4982ff92c",
        "start_time": "2025-08-13T01:04:55.915Z",
        "task": {
            "task_type": "DataProcessor",
            "status": "NOT_STARTED",
            "parameters": {
                "task_id": "dummy_task11",
                "task_executor_wait_time_seconds": 3,
                "timeout": 12,
                "end_date": "2025-08-13",
                "workflow_name": "test-big-demo-workflow",
                "rules_path": "rules",
                "additional_properties": None,
                "main_execution_id": "dwap.test-big-demo-workflow-20250813_010411",
                "start_date": "2025-08-13",
            },
            "parent": {
                "execution_id": "arn:aws:states:us-east-1:123456789123:execution:test-big-demo-workflow:dwap.test-big-demo-workflow-20250813_010411",
                "start_time": "2025-08-13T01:04:13.909Z",
                "execution_input": {
                    "rules_path": "rules",
                    "start_date": "2025-08-13",
                    "end_date": "2025-08-13",
                    "additional_properties": None,
                    "main_execution_id": "dwap.test-big-demo-workflow-20250813_010411",
                    "execution_level": 1,
                },
                "role_arn": "arn:aws:iam::123456789123:role/asap-aws-dev-tlkf-dwap-sfn-task-executor-role",
                "redrive_count": 0,
                "execution_name": "dwap.test-big-demo-workflow-20250813_010411",
            },
            "level_index": 1,
            "thread_index": 1,
            "task_index": 3,
            "execution_environment": "dev",
        },
        "role_arn": "arn:aws:iam::123456789123:role/asap-aws-dev-tlkf-dwap-sfn-task-executor-role",
        "redrive_count": 0,
        "execution_name": "cce645e4-642d-461b-8d8f-a4f4982ff92c",
    }

    payload = TaskPayload(**input_payload)

    assert isinstance(payload.task.parameters, DataProcessingParameters)
