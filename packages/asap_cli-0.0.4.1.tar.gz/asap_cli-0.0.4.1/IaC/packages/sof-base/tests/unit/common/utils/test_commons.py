# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

import pytest
from sofbase.common.utils.commons import (
    construct_query_predicate,
    get_date_range,
    get_source_tables,
    get_time_condition,
    replace_variables,
)


@pytest.mark.parametrize(
    "date_format, start_date, end_date, expected",
    [
        (
            "%Y-%m-%d",
            "2025-01-01",
            "2025-01-04",
            ["2025-01-01", "2025-01-02", "2025-01-03", "2025-01-04"],
        ),
        (
            "%Y-%m-%d",
            "2024-12-29",
            "2025-01-02",
            ["2024-12-29", "2024-12-30", "2024-12-31", "2025-01-01", "2025-01-02"],
        ),
    ],
)
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.commons
def test_get_date_range(
    date_format: str, start_date: str, end_date: str, expected: List[str]
) -> None:
    result = get_date_range(date_format=date_format, start_date=start_date, end_date=end_date)
    assert result == expected


@pytest.mark.parametrize(
    "date_format, start_date, end_date, partition_dt_field, partition_year_field, partition_month_field, partition_day_field, expected",
    [
        (
            "%Y-%m-%d",
            "2025-01-31",
            "2025-02-02",
            "",
            "year",
            "month",
            "day",
            "( ( year = '2025' AND month = '01' AND day = '31' ) OR ( year = '2025' AND month = '02' AND day = '01' ) OR ( year = '2025' AND month = '02' AND day = '02' ) )",
        ),
        (
            "%Y-%m-%d",
            "2025-01-31",
            "2025-02-02",
            "",
            "year",
            "month",
            "",
            "( ( year = '2025' AND month = '01' ) OR ( year = '2025' AND month = '02' ) )",
        ),
        (
            "%Y-%m-%d",
            "2025-01-31",
            "2025-02-02",
            "",
            "year",
            "",
            "",
            "( ( year = '2025' ) )",
        ),
        (
            "%Y-%m-%d",
            "2025-01-31",
            "2025-02-02",
            "date",
            "",
            "",
            "",
            "( ( date = '2025-01-31' ) OR ( date = '2025-02-01' ) OR ( date = '2025-02-02' ) )",
        ),
        ("%Y-%m-%d", "2025-01-01", "2025-01-02", "", "", "", "", ""),
    ],
)
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.commons
def test_get_time_condition(
    date_format: str,
    start_date: str,
    end_date: str,
    partition_dt_field: str,
    partition_year_field: str,
    partition_month_field: str,
    partition_day_field: str,
    expected: str,
) -> None:
    result = get_time_condition(
        date_format=date_format,
        start_date=start_date,
        end_date=end_date,
        partition_dt_field=partition_dt_field,
        partition_year_field=partition_year_field,
        partition_month_field=partition_month_field,
        partition_day_field=partition_day_field,
    )
    assert result == expected


@pytest.mark.parametrize(
    "table_name, date_format, start_date, end_date, partition_dt_field, partition_year_field, partition_month_field, partition_day_field, extra_parameters,target_partitions, expected",
    [
        (
            "my_table",
            "%Y-%m-%d",
            "2025-01-01",
            "2025-01-02",
            "date",
            "",
            "",
            "",
            {},
            "",
            " from my_table where ( ( date = '2025-01-01' ) OR ( date = '2025-01-02' ) )",
        ),
        (
            "my_table",
            "%Y-%m-%d",
            "2025-01-01",
            "2025-01-02",
            "",
            "year",
            "month",
            "day",
            {},
            "",
            " from my_table where ( ( year = '2025' AND month = '01' AND day = '01' ) OR ( year = '2025' AND month = '01' AND day = '02' ) )",
        ),
        (
            "my_table",
            "%Y-%m-%d",
            "2025-01-01",
            "2025-01-02",
            "",
            "",
            "",
            "",
            {},
            "",
            " from my_table",
        ),
        (
            "my_table",
            "%Y-%m-%d",
            "2025-01-01",
            "2025-01-02",
            "date",
            "",
            "",
            "",
            {"country": "USA"},
            "sales_dt,country",
            " from my_table where ( ( date = '2025-01-01' ) OR ( date = '2025-01-02' ) ) AND country = 'USA'",
        ),
    ],
)
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.commons
def test_construct_query_predicate(
    table_name: str,
    date_format: str,
    start_date: str,
    end_date: str,
    partition_dt_field: str,
    partition_year_field: str,
    partition_month_field: str,
    partition_day_field: str,
    extra_parameters: dict,
    target_partitions: str,
    expected: str,
) -> None:
    result = construct_query_predicate(
        table_name=table_name,
        date_format=date_format,
        start_date=start_date,
        end_date=end_date,
        partition_dt_field=partition_dt_field,
        partition_year_field=partition_year_field,
        partition_month_field=partition_month_field,
        partition_day_field=partition_day_field,
        extra_parameters=extra_parameters,
        target_partitions=target_partitions,
    )
    assert result == expected


@pytest.mark.parametrize(
    "file_content, sources_dictionary, expected",
    [
        (
            "SELECT * FROM $SOURCE_DATABASE.sales\nJOIN $SOURCE_DATABASE_1.customers ON sales.customer_id = customers.id",
            {"SOURCE_DATABASE": "test_sales_raw", "SOURCE_DATABASE_1": "test_sales_raw2"},
            ["test_sales_raw.sales", "test_sales_raw2.customers"],
        ),
        (
            "SELECT * FROM $SOURCE_DATABASE.sales\nJOIN $SOURCE_DATABASE.customers ON sales.customer_id = customers.id",
            {"SOURCE_DATABASE": "test_sales_raw"},
            ["test_sales_raw.sales", "test_sales_raw.customers"],
        ),
        ("SELECT * FROM some_table", {"SOURCE_DATABASE": "test_sales_raw"}, []),
    ],
)
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.commons
def test_get_source_tables(
    file_content: str, sources_dictionary: dict, expected: List[str]
) -> None:
    result = get_source_tables(file_content=file_content, sources_dictionary=sources_dictionary)
    assert result == expected


@pytest.mark.parametrize(
    "start_dt, end_dt, file_content, sources_dictionary, extras_dictionary, time_condition, target_database, target_table, expected",
    [
        (
            "2025-01-01",
            "2025-01-02",
            "SELECT * FROM $SOURCE_DATABASE.sales WHERE $TIME_CONDITION",
            {"SOURCE_DATABASE": "test_sales_raw"},
            {},
            "( date = '2025-01-01' OR date = '2025-01-02' )",
            "target_db",
            "target_table",
            "SELECT * FROM test_sales_raw.sales WHERE ( date = '2025-01-01' OR date = '2025-01-02' )",
        ),
        (
            "2025-01-01",
            "2025-01-02",
            "SELECT * FROM $SOURCE_DATABASE.sales",
            {"SOURCE_DATABASE": "test_sales_raw"},
            {},
            "",
            "target_db",
            "target_table",
            "SELECT * FROM test_sales_raw.sales",
        ),
        (
            "2025-01-01",
            "2025-01-02",
            "SELECT * FROM $SOURCE_DATABASE.sales WHERE $TIME_CONDITION",
            {"SOURCE_DATABASE": "test_sales_raw"},
            {},
            "( date = '2025-01-01' OR date = '2025-01-02' )",
            "",
            "",
            "SELECT * FROM test_sales_raw.sales WHERE ( date = '2025-01-01' OR date = '2025-01-02' )",
        ),
        (
            "2025-01-01",
            "2025-01-02",
            "SELECT * FROM $SOURCE_DATABASE.sales WHERE $TIME_CONDITION and country = '$COUNTRY'",
            {"SOURCE_DATABASE": "test_sales_raw"},
            {"country": "USA"},
            "( date = '2025-01-01' OR date = '2025-01-02' )",
            "",
            "",
            "SELECT * FROM test_sales_raw.sales WHERE ( date = '2025-01-01' OR date = '2025-01-02' ) and country = 'USA'",
        ),
    ],
)
@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.commons
def test_replace_variables(
    start_dt: str,
    end_dt: str,
    file_content: str,
    sources_dictionary: dict,
    extras_dictionary: dict,
    time_condition: str,
    target_database: str,
    target_table: str,
    expected: str,
) -> None:
    result = replace_variables(
        start_dt=start_dt,
        end_dt=end_dt,
        file_content=file_content,
        sources_dictionary=sources_dictionary,
        extras_dictionary=extras_dictionary,
        time_condition=time_condition,
        target_database=target_database,
        target_table=target_table,
    )

    assert result == expected
