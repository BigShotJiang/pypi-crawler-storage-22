#!/usr/bin/env python

from setuptools import find_packages, setup

if __name__ == "__main__":
    setup(
        packages=find_packages(),
        package_data={
            "sof_data.glue.glueprocessorjob.config": ["default_values.json"],
        },
    )
