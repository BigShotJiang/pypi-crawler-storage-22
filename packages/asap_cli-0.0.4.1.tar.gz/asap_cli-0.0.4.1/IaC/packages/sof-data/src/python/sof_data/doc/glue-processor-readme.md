# Glue Processor Job

This job is part of the serverless orchestration framework, and is a generic component to process and write spark dataframes using an AWS glue job. 

In this document you will find: 

1. [How to use it with examples.](#how-to-use-it-with-examples) 
2. [Json config parameters guide.](#json-config-parameters-guide) 
3. [Architecture guide.](#architecture-guide) 
4. [External Job Configuration guide.](#external-job-configuration-guide) 

## How to use it with examples

in this repository there is a folder "samples/functional-workflows/demo-workflow" with an entire ETL pipeline simulating a data lakehouse workload, 
simulating a medalion architecture. The example use case is a sales use case for a retail company. 
the pipeline workflow execution looks like this: 

![pipeline sample](img/pipeline-exec.png)

it has 3 dimentional tables ( location, customer, product ) and 2 fact tables (sales, survey)
in the folder "samples/functional-workflows/source-files" there are files simulating data comming to the raw layer in the datalake, and 
in the folder "samples/functional-workflows/table-ddls" there are DDL sentences to create tables in glue catalog from every datalake table used
in the workflow. 

The following folder contains all the files related to the pipeline: 

![pipeline sample](img/pipeline-files.png)

every step in the pipeline is composed by 2 files, a json configuration file and an etl business rule file ( can be a sql file, or a python code file). 
here we will explain different scenarios, from the most common to the most specialized ones, on operations that you can deliver using this job. 
The job is a generic job that receives as parameter a step name, so each config/rules file combination needs to be named with the step name. 
Let's review an example. 

### Job Execution

The glue job is deployed as part of the serverless orchestration framework ( SOF )
for details on how to install the component outside the SOF, refer to the external job configuration guide section. 

once installed, a pipeline's step execution example would be like this: 

```sh
aws glue start-job-run --region us-east-1 --job-name glue-processor-job \
  --arguments '{
            "--RULES_PATH": "rules",
            "--WORKFLOW_NAME": "demo-workflow",
            "--STEP_NAME": "etl_step_1_raw_location",
            "--START_DT": "2025-03-02",
            "--END_DT": "2025-03-03"
  }' \
  --worker-type G.1X \
  --number-of-workers 2
  ```

in this glue invocation, it is expected that the json and rules files lives in a s3 artifactory bucket, 
and the name of the bucket is extracted from a SSM parameter called "/{APP_NAME}/Foundation/S3/ArtifactsBucket/Name". 

Lets review each execution parameter: 

| Parameter        | Sample Value               | Description                                               |
|------------------|----------------------------|-----------------------------------------------------------|
| `--RULES_PATH`   | `rules`                    | In the artifactory bucket, this is the path where the config and rules files lives.                              |
| `--WORKFLOW_NAME`| `demo-workflow`            | in the rules path, this is the name of the folder containing all the pipeline related files                                   |
| `--STEP_NAME`    | `etl_step_1_raw_location`  | Name of the ETL step. there must be in the workflow folder a couple of json and rules files that reflects the step.                                       |
| `--START_DT`     | `2025-02-02`               | Start date for the workflow execution. This parameter is passed normally by the orchestrator component of the framework. Can be invoked on demand for data reprocessing                    |
| `--END_DT`       | `2025-02-03`               | End date for the workflow execution . This parameter is passed normally by the orchestrator component of the framework. Can be invoked on demand for data reprocessing                    |

this execution lauches a glue job, that is going to look for a couple of files in s3: 

s3://<artifactory_bucket>/rules/demo-workflow/etl_step_1_raw_location.json
s3://<artifactory_bucket>/rules/demo-workflow/etl_step_1_raw_location.(sql|py)

from this files will understand how needs to behave depending on the configuration. let´s review some configuration samples:

### Case 1: moving data from a s3 datalake zone to another. 

This is the most common case in a batch lakehouse architecture. This artifact by default assumes that  
all data in the data lakehouse is catalogued in the glue catalog in form of tables. 
let's suppose that you want to move and transform data from the datalake raw zone to the stage zone
to do a first level of cleansing. In this case you could configure the json file like this: 

```json
{    
    "ProcessingFramework": {
        "Type": "GlueDataProcessor",
        "Parameters": {
            "JOB_NAME": "glue-processor-job",
            "SPARK_PARTITIONS_NUMBER": 3
        }
    },
    "InputProperties": {
        "SOURCE_DATABASE": "db_sales_raw"
    },
    "OutputProperties": {
        "TARGET_DATABASE":"db_sales_stg",
        "TARGET_TABLE_NAME":"location_stg"
    }    
}
```

The "ProcessingFramework" section will contain all the parameters related with the execution engine, in this case, glue. 
we can configure parameters like the glue job name (in this case the glue processor job) and the processor type (GlueDataProcesssor). 
This info is not directly used by the job, but is used by the orchestration engine. 

After that, you can configure spark specific parameters like the number of desired write partitions, that will derive in the desired number
of putput files after writing in s3 in the target zone in the datalake. 

Then ther is the "InputProperties" section, were all the properties related with reading a procesing data are configured. 
in this case, only source database property is required. this property will be replaced in execution time in the rules file, in this example, 
of sql type ( by default). this is the content of the sql business rule transformation file: 

```sql
SELECT
  CAST(location_id AS INTEGER) as location_id,
  location_name
FROM
  $SOURCE_DATABASE.location
```

in this case is doing a very basic rule transformation, that is convertig a string to integer via CAST sql function. 
this variable replacement is because database names can be different depending on the customer AWS accounts ( dev, qa, prod)
depending on the naming standars. 

So in this example, the job will execute this sql using spark sql against the glue catalog, and will generate a spark dataframe. 

comming back to the configuraton file, there is the "OutputProperties" section, with the target table definition. 
the glue job can save information in one target table. This configuration will 
write the resulting dataframe on the target table, and saving it to s3 datalake zone. 

With this, you can designe complex sql transformations that will be executed by spark engine. 

### Case 1.1: what if I need to use different source databases?

You can configure more than 1 source database. Let´s supose the following sql content: 

```sql
SELECT
  CAST(location_id AS INTEGER) as location_id,
  location_name
FROM
  $SOURCE_DATABASE.location
  UNION
  $SOURCE_DATABASE_1.other_location
```

in this case you will need to configure the json section like this: 

```json
"InputProperties": {
        "SOURCE_DATABASE": "db_sales_raw",
        "SOURCE_DATABASE_1": "other_db_sales_raw"
    },
```

### Case 2: read from csv tables with header

there are some special cases reading data from the glue catalog. one of them is when you need to read a glue catalog table
from spark that has is a csv table, and the csv files in s3 holds a header. 
In this case, you need to configure the input like this: 

```json
 "InputProperties": {
        "SOURCE_DATABASE": "db_sales_raw",
        "SOURCE_PROCESS_CSV_HEADERS":"true"
    },
```
The glue job will take care on validate tanle configurations and read tables according. Without this, 
the header will be read as a record in the table, which wiil cause table schema problems. 


### Case 3: export from datalake to redshift after saving in datalake

maybe you can have a use case where you need to export a datalake table to redshift ( not using redshift expectrum). 
Normally to serve results to a BI layer. in that case, you can configure the output properties like this: 

```json
 "OutputProperties": {
        "TARGET_DATABASE":"db_sales_analytics",
        "TARGET_TABLE_NAME":"dim_location",
        "ExportProperties": [
            {
                "REDSHIFT_CONFIG_SECRET_NAME":"redshift-connections/database-config1",
                "REDSHIFT_OUTPUT_TABLE": "public.rs_dim_location",
                "REDSHIFT_DATABASE": "dev"
            }
        ]
    }   
```

In this case, you need to specify a secret name created previously in  AWS Secrets service, that hold the redshift configuration, 
as well as the redshift table to expor the data, and the database where the table lives. 

the secret configuration looks like this: 

![secret sample](img/secret.png)

Note that the secret doesn't contains the user password. This is because by default, the component uses redshift IAM
authentication, where the glue job role needs the corresponding permissions to read credentials from redshift. 

| Key                            | Description                                                  |
| ------------------------------ | ------------------------------------------------------------ |
| REDSHIFT_ENDPOINT              | Redshift endpoint url                    |
| REDSHIFT_TEMP_BUCKET              | bucket necessary to export data before copying to redshift. This process is automated by the spark-redshift library                  |
| REDSHIFT_ETL_USER              | User to connect to redshift                    |
| REDSHIFT_REGION              | region where the cluster is deployed                   |

You can also use a native Redshift secret , using the option from the AWS console while creating the secret, selecting the redshift cluster, 
and it will populate the secret payload with the cluster related data. It will create a secret structure a little different, with some predefined keys. 
In this case, the user and password are mandatory fields when creating the secret. 
in order to use in the glue job, you need to add 2 additional keys: 

| Key                            | Description                                                  |
| ------------------------------ | ------------------------------------------------------------ |
| region              | region where the cluster is deployed                   |
| tempbucket              | bucket necessary to export data before copying to redshift. This process is automated by the spark-redshift library                  |

the rest of the keys are generated when creating the native secret. 


### Case 3.1: exporting to redshift using redshift credentials

In case you don't want to use IAM authentication, you can use the user password based authentucantion. 
In that case you need to specify the Auth type like this: 

```json
 "ExportProperties": [
            {
                "REDSHIFT_CONFIG_SECRET_NAME":"redshift-connections/database-config2",
                "REDSHIFT_AUTH_TYPE":"USER_PASSWORD",
                "REDSHIFT_OUTPUT_TABLE": "public.rs_product",
                "REDSHIFT_DATABASE": "dev"
            }
        ]     
```

In this case you will need to add the key "REDSHIFT_ETL_PASSWORD" to the redshift secret, with the corresponding password
for the etl user. 

### Case 3.2: export directly to redshift

there are some cases where you will need exporting to redshift without saving data into the datalake. 
For that use case you can delete the target datalake table config properties, and you need to specify that the 
dataframe writer implementation we will use in this case is "redshift_writer". 

```json
"OutputProperties": {
        "WRITER_IMPLEMENTATION": "redshift_writer",
        "ExportProperties": [
            {
                "REDSHIFT_CONFIG_SECRET_NAME":"redshift-connections/database-config",
                "REDSHIFT_OUTPUT_TABLE": "public.rs_location",
                "REDSHIFT_DATABASE": "dev"
            }
        ]    
    }   
``` 

### understansding "WRITER_IMPLEMENTATION" and "PROCESSOR_IMPLEMENTATION" properties. 

Behind the scenes the framework uses "processors" and "writers" to handle spark dataframes using the factory software pattern.  
For all the detail, please visit the architecture guide section on this document. 

briefly, a processor reads and transforms a spark dataframe, and a writer writes the dataframe into a destination. 
by default, the default processor is of type "sql_processor" and the default writer is 
"glue_catalog_writer. if you want to overwrite this behaviour, you will need to specify the 
implementation explicitly. In the previous example it is "WRITER_IMPLEMENTATION": "redshift_writer". 


### Case 4. write to s3 directly

This is another write use case. Suposse that you need to export data to s3 , without writing in a specific zone in the datalake. 
in this case you can specify a "s3_direct_writer", defining the necessary parameters that define the place where the data 
will be saved directly in s3: 

```json
 "OutputProperties": {
        "TARGET_S3_BUCKET_SSM_PARAMETER": "/sof/Foundation/S3/StageBucket/Name",
        "TARGET_S3_PATH": "demo",
        "WRITER_IMPLEMENTATION": "s3_direct_writer"
    }    
```

### Case 5. working with partitioned tables by date

a common case in a data lakehouse is to use partitioned tables, for example for a fact table in a star model, 
that is normally partitioned by date ( or time based partitions ). 
If you need to read a partitioned table, you need to guarrantee that the table in the glue catalog
has the last partition information fresh and synchronized with s3, otherwhise the process will not read the new s3 partitions. 

You can do it externally, but if you want the glue job to enforce this verification, you can configure 
the property "SOURCE_LOAD_PARTITIONS_IN_CATALOG" to true: 

```json
"InputProperties": {
    "SOURCE_DATABASE": "db_sales_raw",
    "SOURCE_LOAD_PARTITIONS_IN_CATALOG": "true"
},
"OutputProperties": {
    "TARGET_DATABASE":"db_sales_stg",
    "TARGET_TABLE_NAME":"sales_stg",
    "TARGET_PARTITIONS":"sales_dt",
    "ExportProperties": [
        {
            "REDSHIFT_CONFIG_SECRET_NAME":"redshift-connections/database-config1",
            "REDSHIFT_OUTPUT_TABLE": "public.rs_sales",
            "REDSHIFT_DATABASE": "dev"
        }
    ]
}    
```

with this mechanism the resulting dataframe will contain only the date related data partitions. 

In the previous example, you also would want to write to a partitioned table in the datalake. 
and possibly having that table exported to redshift. 

In that case you need to specify the table partition fieds separated by "," in the property "TARGET_PARTITIONS". 
The framework will take care of handling all the logic to write date partitions in the datalake and 
in redshift, based on the START_DATE and END_DATE glue job execution parameters. 

in this case, you can use the execution parameters "START_DATE" and "END_DATE" as wildcards in the sql rule file definition. 
for instance: 

```sql
SELECT
  invoice_id,
  location_id,
  product_id,
  sales_value,
  sales_cost,
  (sales_value - sales_cost) AS sales_revenue,
  sales_dt
FROM
  $SOURCE_DATABASE.sales_stg
  WHERE
  sales_dt between '$START_DATE' and '$END_DATE'
```

if you have tables partitioned by other combination time ( eg. by year, month, day), you can use instead the wildcard
"$TIME_CONDITION" and the framework will calculate the partitions based on the same START_DATE and END_DATE execution parameters. 
for instance: 

```sql
SELECT
  CAST(invoice_id AS INTEGER) as invoice_id,
  CAST(location_id AS INTEGER) as location_id,
  CAST(product_id AS INTEGER) as product_id,
  sales_value,
  sales_cost,
  sales_dt
FROM
  $SOURCE_DATABASE.sales
  WHERE
  $TIME_CONDITION
```

### Case 5.1. working with partitioned tables by other fields different that dates

Let's suppose you have a table that is partitioned by sales_dt and country in the target table, and the source table
is partitioned by dt and country. 

In this case, this would be the a config example: 

```json
  "InputProperties": {
        "SOURCE_DATABASE": "test_sales_raw",
        "SOURCE_LOAD_PARTITIONS_IN_CATALOG": "true",
        "SOURCE_PARTITIONS":"dt,country"
    },
    "OutputProperties": {
        "TARGET_DATABASE":"test_sales_raw",
        "TARGET_TABLE_NAME":"sales_by_country_stg",
        "TARGET_PARTITIONS":"sales_dt,country"
    }
```

in this sample, you can build your sql transformation query like this: 

```sql
SELECT
  CAST(invoice_id AS INTEGER) as invoice_id,
  CAST(location_id AS INTEGER) as location_id,
  CAST(product_id AS INTEGER) as product_id,
  sales_value,
  sales_cost,
  dt as sales_dt,
  country
FROM
  $SOURCE_DATABASE.sales_by_country
  WHERE
  $TIME_CONDITION
  and country = '$COUNTRY'
```

Note that in this case you are using the "COUNTRY' wildcard in the query.  This wildcard can be passed in execution time, like this: 
( calling from local environment )

```shell
python3 /home/hadoop/workspace/code/sof/sof-foundation/foundation/code/glue/glue-processor-job.py \
  --WORKFLOW_NAME=demo-workflow \
  --STEP_NAME=etl_step_1_raw_sales_by_country \
  --RULES_PATH=rules \
  --START_DT=2025-02-03 \
  --END_DT=2025-02-03 \
  --EXTRAS='{"country":"country1"}'
```

if in the "EXTRAS" parameter it find an argument that mateches with "TARGET_PARTITIONS" or "SOURCE_PARTITIONS" config property, it will handle the logic to 
use this field as a partition field in filters ( eg. exporting to redshift the correct partition ). 
If not, the "EXTRAS" parameter can be used only to replace wildcard variables in the transformation sql file. 

### Case 6. reading/writing from/to iceberg tables

Open Table formats like Apache Iceberg are good alternatives to add ACID capabilities to a traditional datalake. 
this component supports Iceberg operations out of the box. 

In Iceberg you can do traditional partitioning writing, or you can use an upsert approach. 

let's review the following use case that needs to read and write data into an iceberg table, 
following traditional partitioning approach: 

```json
"ProcessingFramework": {
        "Type": "GlueDataProcessor",
        "Parameters": {
            "JOB_NAME": "glue-processor-job",
            "GLUE_CATALOG_WAREHOUSE_S3_BUCKET_SSM_PARAMETER":"/sof/Foundation/S3/RawBucket/Name",
            "GLUE_CATALOG_WAREHOUSE_S3_PATH": "demo"
        }
    },
    "InputProperties": {
        "SOURCE_DATABASE": "test_sales_raw",
        "SOURCE_READ_ICEBERG_TABLES":"true"
    },
    "OutputProperties": {
        "TARGET_DATABASE":"test_sales_raw",
        "TARGET_TABLE_NAME":"customer_stg",
        "WRITER_IMPLEMENTATION": "iceberg_writer"
    }    
```

First, spark needs some specific configuration when interacting with an iceberg catalog, and specially integrated with the glue catalog. 

one of the required properties is to specify an s3 path called the "warehouse calalog" where iceberg will write some metadata files. 

for this reason we will need to configure properties "GLUE_CATALOG_WAREHOUSE_S3_BUCKET_SSM_PARAMETER" and "GLUE_CATALOG_WAREHOUSE_S3_PATH"
to reflect this path. 

Second, if you want to read iceberg tables, table names need to be prefixed with the iceberg catalog name. 
from the config prospective , you can configure the property "SOURCE_READ_ICEBERG_TABLES" to true. 
The component will take care on determining which tables in the read process are icberg tables and name
the table accordingly. 

Third, when you want to write the processed dataframe in the traditional "insert overwrite" approach but using iceberg, 
you can do it specifying the writer implementation as "iceberg_writer". 

If the target tabe contains partitions, iceberg will take care on writing the partitioned data from the dataframe in the
corresponding partitions, using a "hidden partition" strategy based in metadata files, noth the folders approach used traditionally. 

Note: this use case is only for "insert overwrite" approach. 

### Case 6.1 using merge/update/delete in iceberg tables

The most benefit of using iceberg is the capacity to mix data by primary key, normaly known as "MERGE" or "UPSERT" approach in sql. 
also you want to use updates and deletes based in key and not in partitions. for this, you can define in the SQL transforation file
sentences lik this: 

```sql
 MERGE INTO $TARGET_DATABASE.$TARGET_TABLE AS t
 USING (
     SELECT 
           customer_id,
           customer_name,
           customer_phone
     FROM $SOURCE_DATABASE.customer_stg
  ) AS u
 ON t.customer_id = u.customer_id
 WHEN MATCHED THEN UPDATE SET 
     t.customer_name = u.customer_name, 
     t.customer_phone = u.customer_phone
 WHEN NOT MATCHED THEN INSERT *
```

Note that this is a read write operation at the same time, son instead of using "processor" and "writer" we use a concept called 
"updater" that can be configured in the property "PROCESSOR_IMPLEMENTATION". in this case, the configuration of the job would be: 

```json
  "InputProperties": {
        "SOURCE_DATABASE": "test_sales_raw",
        "SOURCE_READ_ICEBERG_TABLES":"true",
        "PROCESSOR_IMPLEMENTATION":"iceberg_updater"
    },
    "OutputProperties": {
        "TARGET_DATABASE":"test_sales_model",
        "TARGET_TABLE_NAME":"dim_customer"
    }    
```
in this case, it will execute the configured merge operation over the defined ouput table. 
the same applies for an update or a delete based on primary key. 


### Case 7. using custom pyspark code

In some very specific use cases, transformation rules can't be modeled using spark sql, so 
we can configure to use custom pyspark code to execute read and transform step. 

instead to define a sql file, in this case the rules file is a .py file ( python file )
than must to implement a specific method signature line this: 

```python
def process(*, spark_session: SparkSession, input_properties: dict) -> DataFrame:
```

It means, the code needs to implement a "process" method, that receives a spark session as parameter, as well as
a group of custom input properties, and needs to return a spark dataframe. 

Consider the following configuration example: 

```json
{    
    "ProcessingFramework": {
        "Type": "GlueDataProcessor",
        "Parameters": {
            "JOB_NAME": "glue-processor-job"
        }
    },
    "InputProperties": {
        "PROCESSOR_IMPLEMENTATION": "custom_code_processor",
        "CUSTOM_CODE_PROPERTIES": {
            "S3_SENTIMENT_DATA_SOURCE_PATH":"s3://sample-bucket/demo/satisfaction_survey/",
            "INFERENCE_ENDPOINT":"www.sentiment-inferences.com/survey"
        }
    },
    "OutputProperties": {
        "TARGET_DATABASE":"test_sales_model",
        "TARGET_TABLE_NAME":"fact_survey"
    } 
}
```

the first step is to configure the processor implementation as "custom_code_processor". 

Then, you can configure "CUSTOM_CODE_PROPERTIES", that is a dictionary with aleatory properties used by the custom code. 

This example has 2 custom properties, for example if you want to identify sentiment analysis for a string field in every record from 
spark dataframe , and for every record needs to invoke an inference endpoint, you could model a UDF or using the spark map
function to do the custom processing. 

In this case the code will be responsible of applying best spark programming practices to not to degrade the app performance. 


### Case 8. using spark execution custom properties

You can define spark custom properties in pipeline configuration registry table, or in json config file of each task. 
The first approach helps when you have different configurations between environments. 

The second approach is better if you have a predictable workload in all environments. 

This is a sample of a record in dynamodb registry table, with capacity configured: 

```json
{
 "name": "demo-redshift-workflow",
 "capacity_config": {
  "etl_step_1_raw_sales": {
   "GLUE_WORKER_TYPE": "G.1X",
   "SPARK_NUM_WORKERS": 4
  }
 },
 "status": "ACTIVE",
 "type": "TRANSFORMATION",
 "version": 1
}
```
as this record is for each pipeline, you can add many tasks in the "capacity_config" section. 

this is a sample to do in the json config file of the task: 

```json
{    
    "ProcessingFramework": {
        "Type": "GlueDataProcessor",
        "Parameters": {
            "JOB_NAME_SSM_PARAM": "/sof/Foundations/proserve/Glue/Job/GlueDataProcessor/Default/Name",
            "GLUE_WORKER_TYPE": "G.4X",
            "SPARK_NUM_WORKERS": 3,
            "SPARK_JOB_TIMEOUT": 60  
        }
    },
    "InputProperties": {
        "SOURCE_DATABASE": "test_sales_raw",
        "SOURCE_LOAD_PARTITIONS_IN_CATALOG": "true"
    }
    ....
}
```
if none of them are configured, it will take the default values. ( check next section for more details). 

## Json Config Parameters Guide

this is the complete list of parameters that can be configured in the glue processor job, in each config section: 

## ProcessingFramework

| Key                            | Default Value          | Description                                                  |
| ------------------------------ | ---------------------- | ------------------------------------------------------------ |
| Type                           | GlueDataProcessor      | The type of processing framework used. ( used by orchestration framework)                     |
| JOB_NAME                       | glue-processor-job     | The name of the Glue job. ( used by orchestration framework)                                     |
| SPARK_PARTITIONS_NUMBER        | 0                      | The number of write Spark partitions that redundates in the number of write files in s3                           |
| GLUE_CATALOG_WAREHOUSE_NAME    | glue_catalog           | The name of the Glue catalog warehouse when using iceberg.                   |
| GLUE_CATALOG_WAREHOUSE_S3_BUCKET_SSM_PARAMETER | ""                  | The SSM parameter for the Glue catalog warehouse S3 bucket when using iceberg  |
| GLUE_CATALOG_WAREHOUSE_S3_PATH | demo                   | The S3 path for the Glue catalog warehouse when using iceberg            |
| SPARK_NUM_WORKERS | 2                   | number of workers for the spark glue job           |
| GLUE_WORKER_TYPE | G2.X                   | glue job worker type ( each worker typer has a different ammount of ram and VCPUs)            |
| SPARK_EXECUTOR_CORES | <depends on the worker type>  | inside a worker, how many vcores are assigned to a spark executor           |
| SPARK_JOB_TIMEOUT | 120 minutes                   | Timeout for the glue job          |


## InputProperties

| Key                              | Default Value        | Description                                                  |
| -------------------------------- | -------------------- | ------------------------------------------------------------ |
| SOURCE_DATABASE                  | ""                   | The name of the source database ( or databases ) in the glue catalog. In case you need more than one source database, you can configure like SOURCE_DATABASE_1, SOURCE_DATABASE_2... etc                             |
| SOURCE_LOAD_PARTITIONS_IN_CATALOG| false                | Whether to load partitions in the glue catalog for a partitioned table.                 |
| SOURCE_PROCESS_CSV_HEADERS       | false                | Whether to process CSV headers in source tables                            |
| SOURCE_READ_ICEBERG_TABLES       | false                | Whether to read Iceberg tables in source tables                             |
| PROCESSOR_IMPLEMENTATION         | sql_processor        | The implementation name of the processor component. other value can be "custom_code_processor" and "iceberg_updater"                    |
| CUSTOM_CODE_PROPERTIES           | {}                   | Custom code properties passed to a custom code processor job                               |
| DEFAULT_DATE_FORMAT              | %Y-%m-%d             | The default date format how the execution parameter dates fields are handled ( START_DATE, END_DATE)                                 |

## OutputProperties

| Key                              | Default Value          | Description                                                  |
| -------------------------------- | ---------------------- | ------------------------------------------------------------ |
| TARGET_S3_BUCKET_SSM_PARAMETER   | ""                     | The SSM parameter for the target S3 bucket in case of using "s3_direct_writer" implementation.                |
| TARGET_S3_PATH                   | ""                     | The S3 path for the target data in case of using "s3_direct_writer" implementation.                           |
| TARGET_TABLE_NAME                | ""                     | The name of the target table where the data will be written                               |
| TARGET_DATABASE                  | ""                     | The name of the target database where the data will be written                           |
| TARGET_WRITE_METHOD              | insert_into            | The method used to write to the target table when using glue catalog writer. the other option is "save_as_table". this is related with the spark method used to write to the catalog. check this [save table link](https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.DataFrameWriter.saveAsTable.html)  and this [insert into link](https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.DataFrameWriter.insertInto.html#pyspark.sql.DataFrameWriter.insertInto) for more details                      |
| TARGET_WRITE_MODE                | overwrite              | The write mode for the target write when using "s3_direct_writer" or "glue_catalog_writer(default)". other values can be "append"                           |
| TARGET_DATA_FORMAT               | parquet                | The data format for the target when using "s3_direct_writer". other value could be "csv" for instance                             |
| TARGET_DATA_COMPRESSION          | snappy                 | The data compression for the target when using "s3_direct_writer"                       |
| TARGET_PARTITIONS                | ""                     | A list of comma separated target partition fields, in order as appears in the partition table definition. ( eg, year,month,day)                              |
| DATE_PARTITION_IDENTIFIER        | dt                     | The identifier for a date partition in the target partition fields                        |
| YEAR_PARTITION_IDENTIFIER        | year                   | The identifier for a year partition in the target partition fields                      |
| MONTH_PARTITION_IDENTIFIER        | month                  | The identifier for a month partition in the target partition fields                       |
| DAY_PARTITION_IDENTIFIER         | day                    | The identifier for a day partition in the target partition fields                          |
| WRITER_IMPLEMENTATION            | glue_catalog_writer    | The writer implementation code name. other options can be "s3_direct_writer", "redshift_writer", "iceberg_writer"                        |

## ExportProperties

redshift export properties are: 

| Key                              | Default Value   | Description                                                  |
| -------------------------------- | --------------- | ------------------------------------------------------------ |
| REDSHIFT_CONFIG_SECRET_NAME      | ""              | The AWS secret name for the Redshift configuration.              |
| REDSHIFT_OUTPUT_TABLE            | ""              | The output table for Redshift in case of export                             |
| REDSHIFT_DATABASE                | ""              | The database for Redshift in case of export                               |
| REDSHIFT_TEMP_FORMAT             | CSV GZIP        | The temporary format to write the dataframe in redshift temp bucket before copying to redshift                         |
| REDSHIFT_AUTH_TYPE               | IAM             | The authentication type for Redshift. other option is "USER_PASSWORD"                       |
| REDSHIFT_DT_FIELD                | ""              | The date field for Redshift in case the exported data is in a partitioned table by date                             |
| REDSHIFT_DAY_FIELD                | ""              | The day field for Redshift in case the exported data is in a partitioned table by day                             |
| REDSHIFT_MONTH_FIELD                | ""              | The month field for Redshift in case the exported data is in a partitioned table by month                             |
| REDSHIFT_YEAR_FIELD                | ""              | The year field for Redshift in case the exported data is in a partitioned table by year                             |


## Architecture Guide

This component is part of the python package called "sof_data" in this repo. 

the code for this component is in the folder packages/sof-data/src/python/sof_data/glue/glueprocessorjob. 

the main class of the component is in the file glue_main.py. 

This is a high level class diagram retaled with the component structure: 

![class diagram](img/architecture.png)


### components explanation

| Component                            | Description                                                  |
| ------------------------------ | ------------------------------------------------------------ |
| glue main script              | this is the script referenced directly by a pyspark glue job. It will invoke the GlueMainClass and pass execution parameters.                    |
| GlueMain class            | Class in charge of orchestrating the flow between Processors, Writers and Updaters. I creates a config handler object to be used in the rest of the app classes.                  |
| ConfigHandler class              | Class that holds all the properties required to the app to work. It has the responsability to read the json config file of the job from s3, and fill the internal properties dictonary                 |
| (Processor/Writer/Updater)Factory class              | Classes implementing a factory pattern, so the user can configure implementations in json config file.                   |
| Processor class              | Interface representing a processor in the framework. a processor class needs to implement the "process_data" method, that must return a spark dataframe.                  |
| Writer class              | Interface representing a writer in the framework. a writer class needs to implement the "write_data" method, that receives a spark dataframe and writes it to a destination                 |
| Updater class              | Interface representing a updater in the framework. a updater class needs to implement the "process_update" method. It executes basically a (merge|update|delete) operation by primary key. as is a read write operation, the method doesn't receive or return any parameter.                  |
| SQLProcessor class              | Class that reads and process data from the glue catalog.                   |
| CustomCodeProcessor class              | class that reads and process a spark dataframe using custom python code                 |
| GlueCatalogWriter class              | Class that takes a dataframe and writes it to a glue catalog table                  |
| S3DirectWriter class              | Class that takes a dataframe and writes it to a s3 path                 |
| RedshiftWriter class              | Class that takes a dataframe and writes it to a redshift endpoint                |
| IcebergWriter class              | Class that takes a dataframe and writes it to an iceberg table in insert_overwrite mode                 |
| IcebergUpdater class              | Class that process a (merge|update|delete) operation using spark sql over an iceberg table              |
| SQLhandler class              | helper class to parse sql syntax                  |
| Constants class              | class containing constant values in execution environment                 |

## External Job Configuration guide

if you want to use this component in a glue job outside the SOF framework, you need to import and invoke the GlueMain class. 
This is an example: 

```python
import sys
from typing import Any

from awsglue.utils import getResolvedOptions
from sof_data.glue.glueprocessorjob.glue_main import GlueMain
from sofbase.common.logger import LoggingService

driver_log = LoggingService().initialize_logger()

args: dict[str, Any] = getResolvedOptions(
    sys.argv,
    ["WORKFLOW_NAME", "STEP_NAME", "RULES_PATH", "START_DT", "END_DT"],
)

processor = GlueMain(args, driver_log)
processor.process()
```

The five execution parameters shown are mandatory. 

You can pack the sof-data and sof-base packages from this repo in a python weel file (.whl), and reference this packages in the pythonPath property in the glue job: 

```sh
"pythonPath": "s3://artifacts-bucket/glue-wheel/sof_data-1.0-py3-none-any.whl,s3://artifacts-bucket/glue-wheel/sof_base-1.0-py3-none-any.whl,s3://artifacts-bucket/glue-wheel/aws_lambda_powertools-3.1.0-py3-none-any.whl,s3://artifacts-bucket/glue-wheel/jmespath-1.0.1-py3-none-any.whl,s3://artifacts-bucket/glue-wheel/typing_extensions-4.12.2-py3-none-any.whl"
```

Note tha other python libraries are required for the job execution. Those are: 

- aws_lambda_powertools
- jmespath
- typing_extensions