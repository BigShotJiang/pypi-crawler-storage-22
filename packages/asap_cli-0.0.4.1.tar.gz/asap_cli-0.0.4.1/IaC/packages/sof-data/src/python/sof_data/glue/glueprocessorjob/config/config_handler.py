# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
from typing import TYPE_CHECKING, Any

import boto3
import pkg_resources
from aws_lambda_powertools import Logger
from awsglue.context import GlueContext
from sof_data.glue.glueprocessorjob.constants import Constants
from sofbase.common.utils.commons import (
    combination,
    get_json_config_file,
    get_rules_file_content,
    return_secret_value,
    return_ssm_param,
)

if TYPE_CHECKING:
    from mypy_boto3_s3 import S3Client, S3ServiceResource


class ConfigHandler:
    """
    A class representing a Config Handler object, wich fills and holds all the job properties at runtime, reading
    the properties from a json config file in s3 , and the received ones in execution time.
    This class can be invoked in any point of the job code to get active properties.

    Arguments
    ----------
        args : execution job properties
        spark : glue spark context
        log : logger object
        parameters : dictionary holding all the final parameter values
    """

    def __init__(
        self,
        *,
        args: dict,
        spark: Any,
        log: Any,
        driver_log: Logger,
        glue_context: GlueContext,
    ) -> None:
        self.spark = spark
        self.glue_context = glue_context
        self.log = log
        self.driver_log = driver_log
        self.workflow_name = args["WORKFLOW_NAME"]  # type: ignore
        self.task_id = args["STEP_NAME"]  # type: ignore
        self.rules_path = args["RULES_PATH"]  # type: ignore
        self.dynamic_rules = args["DYNAMIC_RULES"] == "true"  # type: ignore
        self.start_dt = args["START_DT"]  # type: ignore
        self.end_dt = args["END_DT"]  # type: ignore
        self.start_hour = args.get("START_HOUR", "")  # type: ignore
        self.end_hour = args.get("END_HOUR", "")  # type: ignore
        self.start_dttm = args.get("START_DTTM", "")  # type: ignore
        self.end_dttm = args.get("END_DTTM", "")  # type: ignore
        self.extras_dictionary = args.get("EXTRAS", "{}")  # type: ignore
        self.extras_dictionary = json.loads(self.extras_dictionary)
        self.variables_to_log = args.get("LOG_VARIABLES", "{}")  # type: ignore
        self.variables_to_log = json.loads(self.variables_to_log)

        self.artifacts_bucket = return_ssm_param(
            ssm_key=Constants.ARTIFACTS_BUCKET_SSM_PARAM_NAME
        )  # type: ignore
        log.info(f"Obtained Artifacts Bucket Name: {self.artifacts_bucket}")  # type: ignore
        log.info(f"Extras Dictionary: {self.extras_dictionary}")  # type: ignore
        self._s3_client: "S3Client" = boto3.client("s3")  # type: ignore
        self._s3_resource: "S3ServiceResource" = boto3.resource("s3")  # type: ignore
        self.sources_dictionary: dict[str, Any] = {}
        resource_stream = pkg_resources.resource_stream(__name__, "default_values.json")
        self._default_config_values = json.load(resource_stream)
        self.parameters = self.get_json_config_file()
        print("PARAMS" + str(self.parameters))
        self.rules_file_content = self.get_rules_file_content()
        print("SQL:" + str(self.rules_file_content))
        self.set_config_file()

    def get_json_config_file(self) -> dict[str, Any]:
        """
        Method to obatin JSON configuration file with parameters that are used in data transformations

        Parameters
        ----------
        None

        Returns
        -------
        config file content from s3 location.

        """
        return get_json_config_file(
            artifacts_bucket=self.artifacts_bucket,
            rules_path=self.rules_path,
            workflow_name=self.workflow_name,
            task_id=self.task_id,
            dynamic_mode=self.dynamic_rules,
        )

    def get_rules_file_content(self) -> str:
        """

        It returns an SQL query string stored in Artifactory Bucket

        Parameters
        ----------
        None

        Returns
        -------
        rules file content from s3 location.

        """
        return get_rules_file_content(
            artifacts_bucket=self.artifacts_bucket,
            rules_path=self.rules_path,
            workflow_name=self.workflow_name,
            task_id=self.task_id,
            dynamic_mode=self.dynamic_rules,
        )

    def set_config_file(self) -> None:
        """
        It fills the self.parameters dictionary object mixing the properties from
        the s3 config file with the default config properties.
        It calculates also some s3 bucket names given a SSM parameter.

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        # It returns default values in case JSON did not contain them
        boolean_true_cases = combination(word="true")
        boolean_false_cases = combination(word="false")
        # 1. Set default values for Keys that are not included in Config JSON file
        default_config_values_dict: dict[str, Any] = {}
        properties_dict: dict[str, Any] = {}
        self.fill_dictionary_from_nested_json(
            data=self._default_config_values, dictionary=default_config_values_dict
        )
        self.fill_dictionary_from_nested_json(data=self.parameters, dictionary=properties_dict)
        self.parameters = properties_dict
        self._default_config_values = default_config_values_dict

        # mix parameters between 2 dictionaries ( default values and parameters from json file)
        self.combine_dictionaries(
            source_dict=self._default_config_values, target_dict=self.parameters
        )
        # 2. Set booleans string to Python booleans
        for key, value in self.parameters.items():
            if value in boolean_true_cases:
                self.parameters[key] = True

            if value in boolean_false_cases:
                self.parameters[key] = False
        # 3. Obtain S3 values from SSM Parameter Store
        self.fill_ssm_parameter_files()
        self.fill_source_tables_dictionary()
        self.fill_date_parameters()

    def combine_dictionaries(self, *, source_dict: dict, target_dict: dict) -> None:
        """

        It combines 2 dictionaries overwriting parameters in target dictionary coming from source dictionary

        Parameters
        ----------
        source_dict: dict
        target_dict: dict

        returns
        ----------
        None

        """
        for key in source_dict.keys():
            if key not in target_dict.keys():
                target_dict[key] = source_dict[key]

    def configure_spark_properties(self) -> None:
        """

        It configures spark default config values for the executed job

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        # Set Spark, Glue and Job contexts
        print("Setting Spark Properties")
        self.spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")  # type: ignore
        self.spark.conf.set("spark.sql.parser.quotedRegexColumnNames", "true")  # type: ignore
        self.spark.conf.set("spark.sql.crossJoin.enabled", "true")  # type: ignore
        self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")  # type: ignore
        self.spark.conf.set("spark.sql.legacy.allowNonEmptyLocationInCTAS", "true")  # type: ignore
        self.spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")  # type: ignore
        self.spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")  # type: ignore
        self.spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")  # type: ignore
        self.spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")  # type: ignore
        self.spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")  # type: ignore
        if self.parameters["SOURCE_READ_ICEBERG_TABLES"]:
            if self.parameters["GLUE_CATALOG_WAREHOUSE_S3_BUCKET_SSM_PARAMETER"] == "":
                raise Exception(Constants.ERROR_ICEBERG_CATALOG_MANDATORY)
            glue_catalog = self.parameters["GLUE_CATALOG_WAREHOUSE_NAME"]
            self.spark.conf.set(f"spark.sql.catalog.{glue_catalog}", "org.apache.iceberg.spark.SparkCatalog")  # type: ignore
            self.spark.conf.set(f"spark.sql.catalog.{glue_catalog}.warehouse", self.parameters["GLUE_CATALOG_WAREHOUSE_S3_LOCATION"])  # type: ignore
            self.spark.conf.set(f"spark.sql.catalog.{glue_catalog}.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog")  # type: ignore
            self.spark.conf.set(f"spark.sql.catalog.{glue_catalog}.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")  # type: ignore

    def fill_dictionary_from_nested_json(self, *, data: Any, dictionary: dict) -> None:
        """
        It is a recursive method to convert the nested json properties file into
          a plain python dictionary.

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, (dict, list)) and str(key) != "CUSTOM_CODE_PROPERTIES":
                    self.fill_dictionary_from_nested_json(data=value, dictionary=dictionary)
                else:
                    # Process leaf node
                    dictionary[key] = value
        elif isinstance(data, list):
            for item in data:
                self.fill_dictionary_from_nested_json(data=item, dictionary=dictionary)
        else:
            # This case shouldn't normally be reached in a well-formed JSON
            self.log.info(f"Unexpected data type: {data}")

    def fill_source_tables_dictionary(self) -> None:
        """
        It fills a dictionary ( self.sources_dictionary) with a list of source databases and its resolved values
        from the configuration file.

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        source_keys = [key for key in self.parameters.keys() if key.startswith("SOURCE_DATABASE")]
        source_values = [
            self.parameters.get(key)
            for key in self.parameters.keys()
            if key.startswith("SOURCE_DATABASE")
        ]
        for index, value in enumerate(source_keys, start=0):
            self.sources_dictionary[source_keys[index]] = source_values[index]
        return None

    def fill_ssm_parameter_files(self) -> None:
        """
        It fills parameters comming from ssm and secrets configurations into the config holder object

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        for key in self.parameters.copy().keys():  # type: ignore
            # fill s3 parameters when found a s3 ssm parameter
            suffix = "_S3_BUCKET_SSM_PARAMETER"
            if suffix in key:
                ssm_key = self.parameters[key]
                if ssm_key != "":
                    s3_bucket_name = return_ssm_param(ssm_key=ssm_key)
                    s3_key_prefix = key[: -len(suffix)]
                    location_key = s3_key_prefix + "_S3_LOCATION"
                    self.parameters[location_key] = (  # type: ignore
                        s3_bucket_name + "/" + self.parameters[s3_key_prefix + "_S3_PATH"]
                    )
            # fill redshift parameters when found a redshift ssm parameter
            if "REDSHIFT_CONFIG_SECRET_NAME" in key:
                secret_key = self.parameters[key]
                if key.endswith("_SSM"):
                    ssm_keysecret_key = secret_key
                    secret_key = return_ssm_param(ssm_key=ssm_keysecret_key)
                if secret_key != "":
                    redshift_config_dict = return_secret_value(secret_key=secret_key)
                    # support for simple redshift config
                    if "REDSHIFT_ENDPOINT" in redshift_config_dict:
                        for redshift_key in redshift_config_dict.keys():
                            self.parameters[redshift_key] = redshift_config_dict[redshift_key]  # type: ignore
                            if (
                                "PASSWORD".lower() not in redshift_key.lower()
                                and "USER".lower() not in redshift_key.lower()
                            ):
                                self.log.info(
                                    f"Redshift Parameter: {redshift_key} = {redshift_config_dict[redshift_key]}"
                                )
                    # support for redshift native secret
                    elif "host" in redshift_config_dict:
                        self.parameters["REDSHIFT_ENDPOINT"] = (
                            f'{redshift_config_dict["host"]}:{redshift_config_dict["port"]}/{self.parameters["REDSHIFT_DATABASE"]}'
                        )
                        self.parameters["REDSHIFT_ETL_USER"] = redshift_config_dict["username"]
                        self.parameters["REDSHIFT_REGION"] = redshift_config_dict["region"]
                        self.parameters["REDSHIFT_TEMP_BUCKET"] = redshift_config_dict["tempbucket"]
                        self.parameters["REDSHIFT_ETL_PASSWORD"] = redshift_config_dict["password"]

        return None

    def fill_date_parameters(self) -> None:
        """
        It fills parameters comming from date configurations into the config holder object.
        if only target partitions are defined, they are used as source partitions in the sql variable
        replacement.

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        if (
            self.parameters["SOURCE_PARTITIONS"] == ""
            and self.parameters["TARGET_PARTITIONS"] != ""
        ):
            self.parameters["SOURCE_PARTITIONS"] = self.parameters["TARGET_PARTITIONS"]  # type: ignore
        if self.parameters["TARGET_PARTITIONS"] != "":
            for partition in self.parameters["TARGET_PARTITIONS"].split(","):  # type: ignore
                self.assign_date_field_parameter(
                    field_group="TARGET", field_type="DATE", partition_field=partition
                )
                self.assign_date_field_parameter(
                    field_group="TARGET", field_type="YEAR", partition_field=partition
                )
                self.assign_date_field_parameter(
                    field_group="TARGET", field_type="MONTH", partition_field=partition
                )
                self.assign_date_field_parameter(
                    field_group="TARGET", field_type="DAY", partition_field=partition
                )
        if self.parameters["SOURCE_PARTITIONS"] != "":
            for partition in self.parameters["SOURCE_PARTITIONS"].split(","):  # type: ignore
                self.assign_date_field_parameter(
                    field_group="SOURCE", field_type="DATE", partition_field=partition
                )
                self.assign_date_field_parameter(
                    field_group="SOURCE", field_type="YEAR", partition_field=partition
                )
                self.assign_date_field_parameter(
                    field_group="SOURCE", field_type="MONTH", partition_field=partition
                )
                self.assign_date_field_parameter(
                    field_group="SOURCE", field_type="DAY", partition_field=partition
                )
        return None

    def assign_date_field_parameter(
        self, *, field_group: str, field_type: str, partition_field: str
    ) -> None:
        """
        It fills parameters comming from date configurations into the config holder object

        Parameters
        ----------
        field_group : str - field group to process (SOURCE, TARGET)
        field_type : str - field type to process (DATE, YEAR, MONTH, DAY)
        partition_field: str - name of the partition field

        returns
        ----------
        None

        """
        if (
            "_" + self.parameters[field_type + "_PARTITION_IDENTIFIER"] in partition_field  # type: ignore
            or self.parameters[field_type + "_PARTITION_IDENTIFIER"] + "_" in partition_field  # type: ignore
            or self.parameters[field_type + "_PARTITION_IDENTIFIER"] == partition_field
        ):
            self.parameters[field_group + "_" + field_type + "_PARTITION_FIELD"] = partition_field  # type: ignore
        return None
