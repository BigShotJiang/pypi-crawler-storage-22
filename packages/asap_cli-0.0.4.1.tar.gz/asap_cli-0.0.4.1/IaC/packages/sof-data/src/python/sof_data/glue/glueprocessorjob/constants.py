# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from sofbase.common.constants import SOFGlobalConstantsNamespace

SOF = SOFGlobalConstantsNamespace()


class Constants:
    """
    A class containing application constant values

    """

    ARTIFACTS_BUCKET_SSM_PARAM_NAME = f"/{SOF.APP_NAME}/Foundation/S3/ArtifactsBucket/Name"
    PROCESSORS_BASE_PACKAGE = "sof_data.glue.glueprocessorjob.processors"
    UPDATERS_BASE_PACKAGE = "sof_data.glue.glueprocessorjob.updaters"
    WRITERS_BASE_PACKAGE = "sof_data.glue.glueprocessorjob.writers"

    # ERROR MESSAGES

    ERROR_READ_SQL_FILE = "Error reading SQL file"
    ERROR_RULES_FILE_NOT_FOUND = "Rules file not found at"
    ERROR_UPDATER_SENTENCE_WRONG = (
        "sentence doesn't start with expected keyword (merge|update|delete)"
    )
    ERROR_ICEBERG_UPDATER_CONFIG = "target table is not iceberg, but iceberg updater configured"
    ERROR_ICEBERG_CATALOG_MANDATORY = "property GLUE_CATALOG_WAREHOUSE_S3_BUCKET_SSM_PARAMETER mandatory when reading iceberg tables"

    ERROR_ICEBERG_WRITER_CONFIG = "target table is not iceberg, but iceberg writer configured"
    ERROR_REDSHIFT_CONFIG = "Redshift endpoint not configured properly. review secret configuration"
    ERROR_REDSHIFT_EXPORT = "Unable to export data in Redshift Table"

    ERROR_CUSTOM_CODE_EXECUTION = "Error occurred while executing code of "

    ERROR_LOAD_PROCESSOR = "Cannot load processor type "
    ERROR_LOAD_UPDATER = "Cannot load updater type "
    ERROR_LOAD_WRITER = "Cannot load writer type "

    ERROR_INIT_GLUE_JOB = "Error initializing glue job "
    ERROR_EXEC_GLUE_JOB = "Error executing glue job "
