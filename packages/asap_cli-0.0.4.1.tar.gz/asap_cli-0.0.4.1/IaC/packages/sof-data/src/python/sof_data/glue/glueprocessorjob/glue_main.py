# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json

from aws_lambda_powertools import Logger
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.processors.processor_factory import ProcessorFactory
from sof_data.glue.glueprocessorjob.updaters.updater_factory import UpdaterFactory
from sof_data.glue.glueprocessorjob.writers.writer_factory import WriterFactory


class GlueMain:
    """
    A class that is invoked from the main glue job code, and orchestrates
    all the processing and writing process.
    starts and ends the glue job unsing its context.

    """

    def __init__(self, *, args: dict, driver_log: Logger) -> None:
        sc = SparkContext.getOrCreate()
        self._glueContext = GlueContext(sc)  # type: ignore
        sc.setLogLevel("INFO")
        self._log = self._glueContext.get_logger()  # type: ignore
        self._spark = self._glueContext.spark_session  # type: ignore
        self._job = Job(self._glueContext)  # type: ignore
        self.driver_log = driver_log
        try:
            self._config_handler = ConfigHandler(
                args=args,
                spark=self._spark,
                log=self._log,
                driver_log=driver_log,
                glue_context=self._glueContext,
            )
            return None
        except Exception as x:
            error_message = f"{Constants.ERROR_INIT_GLUE_JOB}. ERROR : " + str(x)
            log_variables = args.get("LOG_VARIABLES", "{}")  # type: ignore
            log_variables = json.loads(log_variables)
            self._log.error(error_message)
            error_message = error_message.replace("\r", "")
            error_message = error_message.replace("\n", " ")
            self.driver_log.error(
                {
                    "operation": "glue_job_processor_initialize",
                    "workflow_name": args["WORKFLOW_NAME"],
                    "task_id": args["STEP_NAME"],
                    "error_message": error_message,
                    "external_variables": log_variables,
                }
            )
            raise SOFGlueExecution(error_message)

    def process(self) -> None:
        """
        this method orchestrates the main flow of the glue job, starting the job,
        processing a spark dataframe and saving the resulting dataframe in a
        destination.

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        try:
            self._config_handler.configure_spark_properties()
            self._job.init(self._config_handler.task_id)  # type: ignore
            self.log_variables()

            if (
                "_updater" not in self._config_handler.parameters["PROCESSOR_IMPLEMENTATION"]  # type: ignore
            ):
                processor = ProcessorFactory.get_processor(config_handler=self._config_handler)
                df = processor.process_data()

                writer = WriterFactory.get_writer(config_handler=self._config_handler)
                writer.write_data(dataframe=df)
            else:
                UpdaterFactory.get_updater(config_handler=self._config_handler).process_update()
            if (
                self._config_handler.parameters["REDSHIFT_ENDPOINT"] != ""  # type: ignore
                and self._config_handler.parameters["WRITER_IMPLEMENTATION"] != "redshift_writer"  # type: ignore
            ):
                # if has an endpoint configured and imlmenentation is not redshift writer means
                # that additionally to output to a datalake folder, is exporting to redshift.
                self._config_handler.parameters["WRITER_IMPLEMENTATION"] = "redshift_writer"  # type: ignore
                writer = WriterFactory.get_writer(config_handler=self._config_handler)
                writer.write_data(dataframe=df)

            self._job.commit()  # type: ignore
            return None

        except Exception as x:
            error_message = f"{Constants.ERROR_EXEC_GLUE_JOB}. ERROR : " + str(x)
            self._log.error(error_message)
            error_message = error_message.replace("\r", "")
            error_message = error_message.replace("\n", " ")
            self.driver_log.error(
                {
                    "operation": "glue_job_processor_execution",
                    "workflow_name": self._config_handler.workflow_name,
                    "task_id": self._config_handler.task_id,
                    "error_message": error_message,
                    "external_variables": self._config_handler.variables_to_log,
                }
            )

            raise SOFGlueExecution(error_message)

    def log_variables(self) -> None:
        """
        It logs some input variables for the job execution.

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        self.driver_log.info(
            {
                "operation": "driver",
                "name": "starting_glue_job",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "rules_path": self._config_handler.rules_path,
                "start_date": self._config_handler.start_dt,
                "end_date": self._config_handler.end_dt,
                "external_variables": self._config_handler.variables_to_log,
            }
        )
        params_to_log = self._config_handler.parameters.copy()
        params_to_log.pop("REDSHIFT_ETL_PASSWORD", None)
        self._log.info(f"Starting Glue Job with Config File: {params_to_log}")
        return None


class SOFGlueExecution(Exception):
    pass
