# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import importlib.util

from pyspark.sql import DataFrame
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.processors.processor import Processor


class CustomCodeProcessor(Processor):
    """
    A class representing a custom code processor object.
    this class process a spark datframe using a given custom python code

    Attributes
    ----------
    config_handler : ConfigHandler  -  object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler):
        super().__init__(config_handler=config_handler)

    def process_data(self) -> DataFrame:
        """
        It performs a data processing using a custom pyspar code

        Parameters
        ----------
        None

        Returns
        -------
        dataframe :DataFrame -  The spark dataframe processed

        """
        try:
            python_file_content = self._config_handler.rules_file_content
            inputs = self._config_handler.parameters["CUSTOM_CODE_PROPERTIES"]

            text_file = open("/tmp/utils.py", "w")
            text_file.write(python_file_content)
            text_file.close()

            # Load the utils module dynamically
            spec = importlib.util.spec_from_file_location("utils", "/tmp/utils.py")
            utils = importlib.util.module_from_spec(spec)  # type: ignore
            spec.loader.exec_module(utils)  # type: ignore
            self._config_handler.driver_log.info(
                {
                    "operation": "read_and_transform",
                    "name": "custom_code_processor",
                    "workflow_name": self._config_handler.workflow_name,
                    "task_id": self._config_handler.task_id,
                    "external_variables": self._config_handler.variables_to_log,
                }
            )

            # Call the function from utils.py
            dataframe = utils.process(
                spark_session=self._config_handler.spark, input_properties=inputs
            )
            return dataframe

        except Exception as e:
            raise Exception(
                f"{Constants.ERROR_CUSTOM_CODE_EXECUTION} '{self._config_handler.task_id}': {str(e)}"
            ) from e
