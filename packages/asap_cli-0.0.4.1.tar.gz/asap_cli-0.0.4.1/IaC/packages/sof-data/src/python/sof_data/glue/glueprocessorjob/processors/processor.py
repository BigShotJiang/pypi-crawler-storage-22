# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from abc import ABC, abstractmethod

from pyspark.sql import DataFrame
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler


class Processor(ABC):  # Abstract Class
    """
    An interface representing a Processor object.
    This interface must be implemented by any processor in the processors module

    Attributes
    ----------
    config_handler: ConfigHandler - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler) -> None:
        self._config_handler = config_handler

    @abstractmethod
    def process_data(self) -> DataFrame:  # Abstract Method
        """
        creates a spark dataframe and apply transformations if required, and returns the
        final dataframe.

        Parameters
        ----------
        None

        returns
        ----------
        dataframe: DataFrame - The spark dataframe processed

        """
        pass
