# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import importlib

from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.processors.processor import Processor
from sofbase.common.utils.commons import to_camel_case


class ProcessorFactory:
    """
    A class representing a ProcessorFactory object
    this class actually implements the Factory pattern that uses a singleton pattern to
    hold all the processors created by configuration in the job execution.

    If a processor doesn't exist in the created processors list, it instantiates it dinamically
    and is added to the processors list.

    Attributes
    ----------
    processors : list of processors created in the job execution

    """

    _processors: dict[str, Processor] = {}

    @staticmethod
    def get_processor(*, config_handler: ConfigHandler) -> Processor:
        """
        It returns a processor instance using singleton pattern

        Parameters
        ----------
        config_handler: ConfigHandler  -  object holding all the app properties

        returns
        ----------
        Processor - processor instance returned by the factory

        """
        processor_type = config_handler.parameters["PROCESSOR_IMPLEMENTATION"]
        if processor_type in ProcessorFactory._processors:
            return ProcessorFactory._processors[processor_type]

        module_name = f"{processor_type}"
        try:
            module = importlib.import_module(f"{Constants.PROCESSORS_BASE_PACKAGE}.{module_name}")
            processor_class = getattr(module, to_camel_case(snake_str=processor_type))
            processor_instance = processor_class(config_handler=config_handler)
            ProcessorFactory._processors[processor_type] = processor_instance
            return processor_instance
        except (ImportError, AttributeError) as e:
            raise ImportError(f"{Constants.ERROR_LOAD_PROCESSOR} {processor_type}: {e}")
