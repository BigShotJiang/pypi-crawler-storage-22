# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import TYPE_CHECKING

import boto3

if TYPE_CHECKING:
    from mypy_boto3_glue import GlueClient

from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sofbase.common.utils.commons import (
    get_source_tables,
    get_time_condition,
    replace_variables,
)


class SqlHandler:
    """
    A helper class with methods to handle sql file transformations

    Attributes
    ----------
    config_handler: ConfigHandler  - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler):
        self._config_handler = config_handler
        self._glue_client: "GlueClient" = boto3.client("glue")

    def replace_variables(self) -> str:
        """
        It replaces given parameters in a content file.
        for example in a SQL file it will replace some wildcards like $START_DATE

        Parameters
        ----------
        start_dt: str - start date variable to replace
        end_dt: str - end date variable to replace
        start_hour: str - start hour variable to replace
        end_hour: str - end hour variables to replace
        start_dttm: str - start datetime variable to replace
        end_dttm: str - end datetime variable to replace

        Returns
        -------
        file content replaced

        """
        time_condition = get_time_condition(
            date_format=self._config_handler.parameters["DEFAULT_DATE_FORMAT"],
            start_date=self._config_handler.start_dt,
            end_date=self._config_handler.end_dt,
            partition_dt_field=self._config_handler.parameters["SOURCE_DATE_PARTITION_FIELD"],
            partition_year_field=self._config_handler.parameters["SOURCE_YEAR_PARTITION_FIELD"],
            partition_month_field=self._config_handler.parameters["SOURCE_MONTH_PARTITION_FIELD"],
            partition_day_field=self._config_handler.parameters["SOURCE_DAY_PARTITION_FIELD"],
        )
        return replace_variables(
            file_content=self._config_handler.rules_file_content,
            start_dt=self._config_handler.start_dt,
            end_dt=self._config_handler.end_dt,
            sources_dictionary=self._config_handler.sources_dictionary,
            extras_dictionary=self._config_handler.extras_dictionary or {},
            time_condition=time_condition,
            target_database=self._config_handler.parameters["TARGET_DATABASE"],
            target_table=self._config_handler.parameters["TARGET_TABLE_NAME"],
            start_hour=self._config_handler.start_hour,
            end_hour=self._config_handler.end_hour,
            start_dttm=self._config_handler.start_dttm,
            end_dttm=self._config_handler.end_dttm,
        )

    def load_partitions_in_sources(self) -> None:
        """
        It performs a MSCK REPAIR TABLE command in the glue catalog, before running a query.

        Parameters
        ----------
        None

        Returns
        -------
        None

        """
        spark = self._config_handler.spark
        source_tables = self.get_source_tables()
        for source_table in source_tables:
            database_name = source_table.split(".")[0]
            table_name = source_table.split(".")[1]
            if self.is_table_partitioned(database_name=database_name, table_name=table_name):
                spark.sql("MSCK REPAIR TABLE " + source_table)
                spark.catalog.refreshTable(source_table)
                self._config_handler.log.info("Partitions Loaded for:" + source_table)
            else:
                self._config_handler.log.info(
                    "Table is not partitioned, no partitions loaded for:" + source_table
                )
        return None

    def process_csv_headers(self, *, sql: str) -> str:
        """
        It creates views for all tables found as csv with header and replaces its names in sql.
        This is because spark doesn't recognize the skip header count property from hive/athena
        for tables pointing to csv files with header. This is a workararound, since prefered path
        is to publish csv files without header.

        Parameters
        ----------
        sql:str sql to replace table names that has csv with header in the glue catalog

        Returns
        -------
        sql transformed

        """
        source_tables = self.get_source_tables()
        for source_table in source_tables:
            database_name = source_table.split(".")[0]
            table_name = source_table.split(".")[1]
            if self.is_table_csv_with_header(database_name=database_name, table_name=table_name):
                dynamic_frame = self._config_handler.glue_context.create_dynamic_frame.from_catalog(
                    database=database_name, table_name=table_name
                )
                temp_table_name = "cfw_" + table_name
                dynamic_frame.toDF().createOrReplaceTempView(temp_table_name)
                sql = sql.replace(source_table, temp_table_name)
        return sql

    def process_iceberg_table_names(self, *, sql: str) -> str:
        """
        It adds the prefix "glue_catalog" or the configured glue catalog name to iceberg table names in order to be queried by
        spark sql.

        Parameters
        ----------
        sql:str sql to replace table names

        Returns
        -------
        sql transformed

        """
        source_tables = self.get_source_tables()
        for source_table in source_tables:
            database_name = source_table.split(".")[0]
            table_name = source_table.split(".")[1]
            if self.is_table_iceberg_table(database_name=database_name, table_name=table_name):
                catalog_name = self._config_handler.parameters["GLUE_CATALOG_WAREHOUSE_NAME"]
                temp_table_name = f"{catalog_name}.{database_name}.{table_name}"
                sql = sql.replace(source_table, temp_table_name)
        return sql

    def get_source_tables(self) -> list[str]:
        """
        It gets a list with the source tables involved in a given sql query.

        Parameters
        ----------
        None

        Returns
        -------
        str - list with source tables resolved

        """
        return get_source_tables(
            file_content=self._config_handler.rules_file_content,
            sources_dictionary=self._config_handler.sources_dictionary,
        )

    def is_table_csv_with_header(self, *, database_name: str, table_name: str) -> bool:
        """
        verifies if a table is a csv table with header in the glue catalog

        Parameters
        ----------
        database_name: str - database name to validate
        table_name: str - table name to validate

        Returns
        -------
        boolean with the result validation

        """
        glue_client = self._glue_client
        response = glue_client.get_table(DatabaseName=database_name, Name=table_name)
        table_has_header = False
        if "skip.header.line.count" in response["Table"]["Parameters"]:
            try:
                header_count = int(response["Table"]["Parameters"]["skip.header.line.count"])
                table_has_header = header_count > 0
            except (ValueError, TypeError):
                table_has_header = False
        is_csv_table = (
            response["Table"]["StorageDescriptor"]["InputFormat"]
            == "org.apache.hadoop.mapred.TextInputFormat"
        )
        return table_has_header and is_csv_table

    def is_table_partitioned(self, *, database_name: str, table_name: str) -> bool:
        """
        verifies if a table is partitioned in the glue catalog

        Parameters
        ----------
        database_name: str - database name to validate
        table_name: str - table name to validate

        Returns
        -------
        boolean with the result validation

        """
        glue_client = self._glue_client
        response = glue_client.get_table(DatabaseName=database_name, Name=table_name)
        if "PartitionKeys" in response["Table"] and len(response["Table"]["PartitionKeys"]) > 0:
            return True
        else:
            return False

    def is_table_iceberg_table(self, *, database_name: str, table_name: str) -> bool:
        """
        verifies if a table is an iceberg table

        Parameters
        ----------
        database_name: str - database name to validate
        table_name: str - table name to validate

        Returns
        -------
        boolean with the result validation

        """
        glue_client = self._glue_client
        response = glue_client.get_table(DatabaseName=database_name, Name=table_name)
        return str(response["Table"]["Parameters"].get("table_type")).lower() == "iceberg"
