# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pyspark.sql import DataFrame
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.processors.processor import Processor
from sof_data.glue.glueprocessorjob.processors.sql_handler import SqlHandler


class SqlProcessor(Processor):
    """
    A class representing a sql processor object.
    this class process a spark datframe using spark sql, and connecting with glue catalog tables

    Attributes
    ----------
    config_handler: ConfigHandler  - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler):
        super().__init__(config_handler=config_handler)
        self._sql_handler = SqlHandler(config_handler=config_handler)

    def process_data(self) -> DataFrame:
        """
        It performs a SQL query in Spark SQL with the data located in s3 using glue catalog

        Parameters
        ----------
        None

        Returns
        -------
        dataframe :DataFrame -  The spark dataframe processed

        """

        sql = self._sql_handler.replace_variables()
        self._config_handler.log.info(f"SQL QUERY:{sql}")
        if self._config_handler.parameters["SOURCE_LOAD_PARTITIONS_IN_CATALOG"]:
            self._sql_handler.load_partitions_in_sources()
        if self._config_handler.parameters["SOURCE_PROCESS_CSV_HEADERS"]:
            sql = self._sql_handler.process_csv_headers(sql=sql)
        if self._config_handler.parameters["SOURCE_READ_ICEBERG_TABLES"]:
            sql = self._sql_handler.process_iceberg_table_names(sql=sql)
        self._config_handler.driver_log.info(
            {
                "operation": "read_and_transform",
                "name": "sql_processor",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "sql_transformation": sql,
                "external_variables": self._config_handler.variables_to_log,
            }
        )

        result: DataFrame = self._config_handler.spark.sql(sql)
        return result
