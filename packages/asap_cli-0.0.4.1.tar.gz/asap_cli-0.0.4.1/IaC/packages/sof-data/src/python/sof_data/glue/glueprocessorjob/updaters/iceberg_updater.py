# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.processors.sql_handler import SqlHandler
from sof_data.glue.glueprocessorjob.updaters.updater import Updater


class IcebergUpdater(Updater):
    """
    A class representing an iceberg updater object.
    this class executes a merge , update or delete sentence using iceberg

    Attributes
    ----------
    config_handler: ConfigHandler  - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler):
        super().__init__(config_handler=config_handler)
        self._sql_handler = SqlHandler(config_handler=config_handler)

    def process_update(self) -> None:
        """
        It performs a SQL (merge , update or delete)  sentence using iceberg
        using spark sql

        Parameters
        ----------
        None

        Returns
        -------
        dataframe :DataFrame -  The spark dataframe processed

        """

        sql = self._sql_handler.replace_variables()
        if (
            not sql.lower().strip().startswith("merge")
            and not sql.lower().strip().startswith("update")
            and not sql.lower().strip().startswith("delete")
        ):
            raise Exception(Constants.ERROR_UPDATER_SENTENCE_WRONG)

        if self._config_handler.parameters["SOURCE_PROCESS_CSV_HEADERS"]:
            sql = self._sql_handler.process_csv_headers(sql=sql)
        if self._config_handler.parameters["SOURCE_READ_ICEBERG_TABLES"]:
            sql = self._sql_handler.process_iceberg_table_names(sql=sql)
        database_name = self._config_handler.parameters["TARGET_DATABASE"]
        table_name = self._config_handler.parameters["TARGET_TABLE_NAME"]
        if self._sql_handler.is_table_iceberg_table(
            database_name=database_name, table_name=table_name
        ):
            catalog_name = self._config_handler.parameters["GLUE_CATALOG_WAREHOUSE_NAME"]
            sql = sql.replace(
                f"{database_name}.{table_name}", f"{catalog_name}.{database_name}.{table_name}"
            )
        else:
            raise Exception(Constants.ERROR_ICEBERG_UPDATER_CONFIG)

        self._config_handler.log.info(f"SQL QUERY:{sql}")
        self._config_handler.driver_log.info(
            {
                "operation": "merge_update_delete",
                "name": "iceberg_updater",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "sql_transformation": sql,
                "external_variables": self._config_handler.variables_to_log,
            }
        )

        self._config_handler.spark.sql(sql)
        return None
