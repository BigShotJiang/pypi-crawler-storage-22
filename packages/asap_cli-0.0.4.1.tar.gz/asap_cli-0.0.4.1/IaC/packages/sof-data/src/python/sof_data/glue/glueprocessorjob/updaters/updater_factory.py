# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import importlib

from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.updaters.updater import Updater
from sofbase.common.utils.commons import to_camel_case


class UpdaterFactory:
    """
    A class representing a UpdaterFactory object
    this class actually implements the Factory pattern that uses a singleton pattern to
    hold all the updaters created by configuration in the job execution.

    If a updater doesn't exist in the created updater list, it instantiates it dinamically
    and is added to the updaters list.

    Attributes
    ----------
    updaters : list of updaters created in the job execution

    """

    _updaters: dict[str, Updater] = {}

    @staticmethod
    def get_updater(*, config_handler: ConfigHandler) -> Updater:
        """
        It returns a updater instance using singleton pattern

        Parameters
        ----------
        config_handler: ConfigHandler  -  object holding all the app properties

        returns
        ----------
        updater - updater instance returned by the factory

        """
        updater_type = config_handler.parameters["PROCESSOR_IMPLEMENTATION"]
        if updater_type in UpdaterFactory._updaters:
            return UpdaterFactory._updaters[updater_type]

        module_name = f"{updater_type}"
        try:
            module = importlib.import_module(f"{Constants.UPDATERS_BASE_PACKAGE}.{module_name}")
            updater_class = getattr(module, to_camel_case(snake_str=updater_type))
            updater_instance = updater_class(config_handler=config_handler)
            UpdaterFactory._updaters[updater_type] = updater_instance
            return updater_instance
        except (ImportError, AttributeError) as e:
            raise ImportError(f"{Constants.ERROR_LOAD_UPDATER} {updater_type}: {e}")
