# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pyspark.sql import DataFrame
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.writers.s3_direct_writer import S3DirectWriter
from sof_data.glue.glueprocessorjob.writers.writer import Writer


class GlueCatalogWriter(Writer):
    """
    A class representing a Glue Catalog Writer object.
    This class can save a spark dataframe in a glue catalog table

    Attributes
    ----------
    config_handler: ConfigHandler - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler):
        super().__init__(config_handler=config_handler)

    def write_data(self, *, dataframe: DataFrame) -> None:
        """
        writes the given dataframe in a glue catalog table.
        default method is insertInto. it overwriets partitions automatically.
        saveAsTable drops and recreates tables, so it can be used only on kill and fill
        tables.

        Parameters
        ----------
        dataframe: DataFrame -  The spark dataframe to write

        Returns
        ----------
        None

        """
        # create location if not exist
        parameters = self._config_handler.parameters
        self._config_handler.driver_log.info(
            {
                "operation": "write",
                "name": "glue_catalog_writer",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "target_database": parameters["TARGET_DATABASE"],
                "target_table_name": parameters["TARGET_TABLE_NAME"],
                "external_variables": self._config_handler.variables_to_log,
            }
        )
        if parameters["TARGET_WRITE_METHOD"] == "insert_into":
            s3_dao = S3DirectWriter(config_handler=self._config_handler)
            s3_dao.create_folder_if_not_exists()

        self._config_handler.log.info("writing as table")  # type: ignore
        if parameters["SPARK_PARTITIONS_NUMBER"] > 0:
            dataframe = dataframe.coalesce(parameters["SPARK_PARTITIONS_NUMBER"])
            self._config_handler.log.info(
                "Aplying coalesce with value: " + str(parameters["SPARK_PARTITIONS_NUMBER"])
            )

        if parameters["TARGET_WRITE_METHOD"] == "insert_into":
            dataframe.write.format(parameters["TARGET_DATA_FORMAT"]).insertInto(
                f"{parameters['TARGET_DATABASE']}.{parameters['TARGET_TABLE_NAME']}",
                overwrite=parameters["TARGET_WRITE_MODE"] == "overwrite",
            )
        elif parameters["TARGET_WRITE_METHOD"] == "save_as_table":
            dataframe.write.mode(parameters["TARGET_WRITE_MODE"]).partitionBy(
                parameters["TARGET_PARTITIONS"]
            ).saveAsTable(f"{parameters['TARGET_DATABASE']}.{parameters['TARGET_TABLE_NAME']}")
        return None
