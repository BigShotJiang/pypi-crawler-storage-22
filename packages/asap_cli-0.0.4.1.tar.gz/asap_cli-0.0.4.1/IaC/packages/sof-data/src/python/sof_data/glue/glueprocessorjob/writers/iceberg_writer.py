# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pyspark.sql import DataFrame
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.processors.sql_handler import SqlHandler
from sof_data.glue.glueprocessorjob.writers.writer import Writer


class IcebergWriter(Writer):
    """
    A class representing an object that knows how to write in an iceberg table ( insert into overwrite mode)
    This class can insert a spark dataframe in an iceberg table

    Attributes
    ----------
    config_handler: ConfigHandler - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler):
        super().__init__(config_handler=config_handler)
        self._sql_handler = SqlHandler(config_handler=config_handler)

    def write_data(self, *, dataframe: DataFrame) -> None:
        parameters = self._config_handler.parameters
        self._config_handler.driver_log.info(
            {
                "operation": "write",
                "name": "iceberg_writer",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "target_database": parameters["TARGET_DATABASE"],
                "target_table_name": parameters["TARGET_TABLE_NAME"],
                "external_variables": self._config_handler.variables_to_log,
            }
        )
        self._config_handler.log.info("writing as iceberg table")  # type: ignore
        if parameters["SPARK_PARTITIONS_NUMBER"] > 0:
            dataframe = dataframe.coalesce(parameters["SPARK_PARTITIONS_NUMBER"])
            self._config_handler.log.info(
                "Aplying coalesce with value: " + str(parameters["SPARK_PARTITIONS_NUMBER"])
            )

        database_name = parameters["TARGET_DATABASE"]
        table_name = parameters["TARGET_TABLE_NAME"]
        if self._sql_handler.is_table_iceberg_table(
            database_name=database_name, table_name=table_name
        ):
            catalog_name = self._config_handler.parameters["GLUE_CATALOG_WAREHOUSE_NAME"]
            dataframe.writeTo(f"{catalog_name}.{database_name}.{table_name}").overwritePartitions()
        else:
            raise Exception(Constants.ERROR_ICEBERG_WRITER_CONFIG)
