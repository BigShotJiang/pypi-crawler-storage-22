# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import DataFrame
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.writers.writer import Writer
from sofbase.common.utils.commons import construct_query_predicate


class RedshiftWriter(Writer):
    """
    A class representing an object that knows how to write a dataframe in a redshift cluster
    This class can save a spark dataframe in a redshift table.

    Attributes
    ----------
    config_handler: ConfigHandler  - object containing all the job properties

    """

    def write_data(self, *, dataframe: DataFrame) -> None:
        """
        writes the given dataframe to a redshift cluster

        Parameters
        ----------
        dataframe : DataFrame - The spark dataframe to write

        Returns
        -------
        None

        """

        if self._config_handler.parameters["REDSHIFT_ENDPOINT"] == "":
            raise Exception(Constants.ERROR_REDSHIFT_CONFIG)

        result_dynamic_frame = DynamicFrame.fromDF(
            dataframe, self._config_handler.glue_context, "result_dynamic_frame"
        )
        partition_dt_field = self._config_handler.parameters["TARGET_DATE_PARTITION_FIELD"]
        partition_year_field = self._config_handler.parameters["TARGET_YEAR_PARTITION_FIELD"]
        partition_month_field = self._config_handler.parameters["TARGET_MONTH_PARTITION_FIELD"]
        partition_day_field = self._config_handler.parameters["TARGET_DAY_PARTITION_FIELD"]
        redshift_dt_field = self._config_handler.parameters["REDSHIFT_DT_FIELD"]
        redshift_day_field = self._config_handler.parameters["REDSHIFT_DAY_FIELD"]
        redshift_month_field = self._config_handler.parameters["REDSHIFT_MONTH_FIELD"]
        redshift_year_field = self._config_handler.parameters["REDSHIFT_YEAR_FIELD"]
        sql_delete_redshift = "delete " + construct_query_predicate(
            table_name=self._config_handler.parameters["REDSHIFT_OUTPUT_TABLE"],
            date_format=self._config_handler.parameters["DEFAULT_DATE_FORMAT"],
            start_date=self._config_handler.start_dt,
            end_date=self._config_handler.end_dt,
            partition_dt_field=partition_dt_field,
            partition_year_field=partition_year_field,
            partition_month_field=partition_month_field,
            partition_day_field=partition_day_field,
            extra_parameters=self._config_handler.extras_dictionary,
            target_partitions=self._config_handler.parameters["TARGET_PARTITIONS"],
        )

        if redshift_dt_field != "":
            sql_delete_redshift = sql_delete_redshift.replace(
                f" {partition_dt_field} = ", f" {redshift_dt_field} = "
            )
        if redshift_day_field != "":
            sql_delete_redshift = sql_delete_redshift.replace(
                f" {partition_day_field} = ", f" {redshift_day_field} = "
            )
        if redshift_month_field != "":
            sql_delete_redshift = sql_delete_redshift.replace(
                f" {partition_month_field} = ", f" {redshift_month_field} = "
            )
        if redshift_year_field != "":
            sql_delete_redshift = sql_delete_redshift.replace(
                f" {partition_year_field} = ", f" {redshift_year_field} = "
            )
        self._config_handler.log.info("PREACTIONS SQL::" + sql_delete_redshift)
        self._config_handler.driver_log.info(
            {
                "operation": "delete",
                "name": "redshift_writer",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "sentence": sql_delete_redshift,
                "endpoint": self._config_handler.parameters["REDSHIFT_ENDPOINT"],
                "external_variables": self._config_handler.variables_to_log,
            }
        )
        self._config_handler.driver_log.info(
            {
                "operation": "write",
                "name": "redshift_writer",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "table": self._config_handler.parameters["REDSHIFT_OUTPUT_TABLE"],
                "endpoint": self._config_handler.parameters["REDSHIFT_ENDPOINT"],
                "external_variables": self._config_handler.variables_to_log,
            }
        )
        redshift_url = "jdbc:redshift:"
        if self._config_handler.parameters["REDSHIFT_AUTH_TYPE"] == "IAM":
            redshift_url += "iam:"
        redshift_url += "//" + self._config_handler.parameters["REDSHIFT_ENDPOINT"]

        self._config_handler.log.info(
            "REDSHIFT DATABASE::" + self._config_handler.parameters["REDSHIFT_DATABASE"]
        )
        conn_options = {
            # IAM - based JDBC URL # IAM url uses the glue job Role to access redshift.
            "url": redshift_url,
            "database": self._config_handler.parameters["REDSHIFT_DATABASE"],
            "dbtable": self._config_handler.parameters["REDSHIFT_OUTPUT_TABLE"],
            "redshiftTmpDir": "s3://"
            + self._config_handler.parameters["REDSHIFT_TEMP_BUCKET"]
            + "/",
            "DbUser": self._config_handler.parameters[
                "REDSHIFT_ETL_USER"
            ],  # required for IAM - based JDBC URL
            "preactions": sql_delete_redshift,
            "tempdir_region": self._config_handler.parameters["REDSHIFT_REGION"],
            "tempformat": self._config_handler.parameters["REDSHIFT_TEMP_FORMAT"],
        }
        if self._config_handler.parameters["REDSHIFT_AUTH_TYPE"] == "USER_PASSWORD":
            conn_options["user"] = self._config_handler.parameters["REDSHIFT_ETL_USER"]
            conn_options["password"] = self._config_handler.parameters["REDSHIFT_ETL_PASSWORD"]

        try:
            self._config_handler.glue_context.write_dynamic_frame.from_options(
                frame=result_dynamic_frame,
                connection_type="redshift",
                connection_options=conn_options,
            )

        except Exception as x:
            err = f"{Constants.ERROR_REDSHIFT_EXPORT}. ERROR : " + str(x)
            self._config_handler.log.error(err)
            raise x
