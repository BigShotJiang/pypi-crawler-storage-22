# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import TYPE_CHECKING

import boto3
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.writers.writer import Writer

if TYPE_CHECKING:
    from mypy_boto3_glue import GlueClient
    from mypy_boto3_s3 import S3Client


class S3DirectWriter(Writer):
    """
    A class representing an object that knows how to write a dataframe directly to s3
    This class can save a spark dataframe in s3 bucket

    Attributes
    ----------
    config_handler: ConfigHandler  - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler) -> None:
        super().__init__(config_handler=config_handler)
        self._s3: "S3Client" = boto3.client("s3")  # type: ignore
        self._glue: "GlueClient" = boto3.client("glue")  # type: ignore

    def write_data(self, *, dataframe) -> None:  # type: ignore
        """
        writes the given dataframe in s3 bucket

        Parameters
        ----------
        dataframe : DataFrame - The spark dataframe to write

        Returns
        -------
        None

        """

        parameters = self._config_handler.parameters
        self._config_handler.driver_log.info(
            {
                "operation": "write",
                "name": "s3_direct_writer",
                "workflow_name": self._config_handler.workflow_name,
                "task_id": self._config_handler.task_id,
                "target_s3_location": parameters["TARGET_S3_LOCATION"],
                "target_table_name": parameters["TARGET_TABLE_NAME"],
                "external_variables": self._config_handler.variables_to_log,
            }
        )
        target_s3_path = (
            f"s3://{parameters['TARGET_S3_LOCATION']}/{parameters['TARGET_TABLE_NAME']}/"
        )
        if parameters["SPARK_PARTITIONS_NUMBER"] > 0:
            dataframe = dataframe.coalesce(parameters["SPARK_PARTITIONS_NUMBER"])
        if len(parameters["TARGET_PARTITIONS"]) > 0:
            (
                dataframe.write.partitionBy(parameters["TARGET_PARTITIONS"])  # type: ignore
                .mode(parameters["TARGET_WRITE_MODE"])
                .format(parameters["TARGET_DATA_FORMAT"])
                .option("compression", parameters["TARGET_DATA_COMPRESSION"])
                .option("path", f"{target_s3_path}")
                .option("maxRecordsPerFile", 1000000)
                .save()
            )
        else:
            (
                dataframe.write.mode(parameters["TARGET_WRITE_MODE"])  # type: ignore
                .format(parameters["TARGET_DATA_FORMAT"])
                .option("compression", parameters["TARGET_DATA_COMPRESSION"])
                .option("path", f"{target_s3_path}")
                .option("maxRecordsPerFile", 1000000)
                .save()
            )

    def create_folder_if_not_exists(self) -> None:
        """
        creates an s3 location extracted from glue catalog if not exists.
        is used for kill and fill tables, because spark doesn't create the location if not exists.
        only creates the location for partitioned tables.

        Parameters
        ----------
        None

        returns
        ----------
        None

        """
        parameters = self._config_handler.parameters
        database_name = parameters["TARGET_DATABASE"]
        table_name = parameters["TARGET_TABLE_NAME"]
        if database_name and table_name:
            # Fetch the table metadata
            response = self._glue.get_table(DatabaseName=database_name, Name=table_name)
            table = response["Table"]
            # only if table is not partitioned
            if not ("PartitionKeys" in table and table["PartitionKeys"]):
                table_location = table["StorageDescriptor"]["Location"]
                # Extract the bucket name and prefix from the S3 location
                s3_uri = table_location.replace("s3://", "")
                bucket, prefix = s3_uri.split("/", 1)
                # Check if the prefix exists in the bucket
                resp = self._s3.list_objects(
                    Bucket=bucket, Prefix=prefix + "/", Delimiter="/", MaxKeys=1
                )
                if "Contents" in resp:
                    self._config_handler.log.info(f"S3 location {table_location} already exists.")
                else:
                    # Create a placeholder object to represent the prefix
                    self._s3.put_object(Bucket=bucket, Key=prefix)
                    self._config_handler.log.info(f"S3 location {table_location} created.")

        else:
            self._config_handler.log.info(
                "TARGET_DATABASE or TARGET_TABLE_NAME parameters not configured correctly"
            )
