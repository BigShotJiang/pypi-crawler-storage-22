# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from abc import ABC, abstractmethod

from pyspark.sql import DataFrame
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler


class Writer(ABC):  # Abstract Class
    """
    An interface representing a Writer object.
    This interface must be implemented by any writer in the writers module

    Attributes
    ----------
    config_handler: ConfigHandler - object containing all the job properties

    """

    def __init__(self, *, config_handler: ConfigHandler):
        self._config_handler = config_handler

    @abstractmethod
    def write_data(self, *, dataframe: DataFrame) -> None:  # Abstract Method
        """
        writes the given dataframe in any destination

        Parameters
        ----------
        dataframe: DataFrame - The spark dataframe to write

        returns
        ----------
        None

        """
        pass
