# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import importlib

from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.constants import Constants
from sof_data.glue.glueprocessorjob.writers.writer import Writer
from sofbase.common.utils.commons import to_camel_case


class WriterFactory:
    """
    A class representing a WriterFactory object
    this class actually implements the Factory pattern that uses a singleton pattern to
    hold all the processors created by configuration in the job execution.

    If a writer doesn't exist in the created writers list, it instantiates it dinamically
    and is added to the writers list.

    Attributes
    ----------
    _writers : list of writers created in the job execution

    """

    _writers: dict[str, Writer] = {}

    @staticmethod
    def get_writer(*, config_handler: ConfigHandler) -> Writer:
        """
        It returns a writer instance using singleton pattern

        Parameters
        ----------
        config_handler: ConfigHandler  -  object holding all the app properties

        returns
        ----------
        Writer - writer instance returned by the factory

        """
        writer_type = config_handler.parameters["WRITER_IMPLEMENTATION"]
        if writer_type in WriterFactory._writers:
            return WriterFactory._writers[writer_type]

        module_name = f"{writer_type}"
        try:
            module = importlib.import_module(f"{Constants.WRITERS_BASE_PACKAGE}.{module_name}")
            writer_class = getattr(module, to_camel_case(snake_str=writer_type))
            writer_instance = writer_class(config_handler=config_handler)
            WriterFactory._writers[writer_type] = writer_instance
            return writer_instance
        except (ImportError, AttributeError) as e:
            raise ImportError(f"{Constants.ERROR_LOAD_WRITER} {writer_type}: {e}")
