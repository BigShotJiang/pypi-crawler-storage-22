# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.configs
def test_json_config_parameters(config_handler: ConfigHandler) -> None:
    assert config_handler.parameters["JOB_NAME"] == "glue-processor-job"
    assert config_handler.parameters["PROCESSOR_IMPLEMENTATION"] == "sql_processor"


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.configs
def test_default_config_parameters(config_handler: ConfigHandler) -> None:
    assert config_handler.parameters["SOURCE_DATABASE"] == "db_sales"
    assert config_handler.parameters["TARGET_DATABASE"] == "test_sales_raw"


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.configs
def test_execution_parameters(config_handler: ConfigHandler) -> None:
    assert config_handler.artifacts_bucket == "/sof/ArtifactsBucket/Name"
    assert config_handler.workflow_name == "test_workflow"


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.configs
def test_combine_dictionaries(config_handler: ConfigHandler) -> None:
    source_dict = {"a": 1, "b": 2}
    target_dict = {"b": 3, "c": 4}
    config_handler.combine_dictionaries(source_dict=source_dict, target_dict=target_dict)
    assert target_dict == {"b": 3, "c": 4, "a": 1}


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.configs
def test_fill_dictionary_from_nested_json(config_handler: ConfigHandler) -> None:
    nested_json = {"a": {"b": 1, "c": 2}, "d": 4}
    result_dict: dict[str, int] = {}
    config_handler.fill_dictionary_from_nested_json(data=nested_json, dictionary=result_dict)
    assert result_dict == {"b": 1, "c": 2, "d": 4}


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.configs
def test_fill_source_tables_dictionary(config_handler: ConfigHandler) -> None:
    assert config_handler.sources_dictionary == {
        "SOURCE_DATABASE": "db_sales",
        "SOURCE_DATABASE_1": "db_sales_1",
    }
