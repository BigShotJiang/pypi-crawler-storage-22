# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from unittest.mock import MagicMock, patch

import pytest
from aws_lambda_powertools import Logger
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler

# Mocked JSON config file content
MOCKED_JSON_CONFIG = {
    "ProcessingFramework": {
        "Type": "GlueDataProcessor",
        "Parameters": {"JOB_NAME": "glue-processor-job", "SPARK_PARTITIONS_NUMBER": 3},
    },
    "InputProperties": {"SOURCE_DATABASE": "db_sales", "SOURCE_DATABASE_1": "db_sales_1"},
    "OutputProperties": {"TARGET_DATABASE": "test_sales_raw", "TARGET_TABLE_NAME": "location_stg"},
}

# Mocked JSON config file content
MOCKED_SQL_FILE_CONTENT = (
    "SELECT * FROM $SOURCE_DATABASE.test_table UNION $SOURCE_DATABASE_1.test_table_1"
)

# Mocked SSM param
MOCKED_SSM_PARAM_VALUE = "/sof/ArtifactsBucket/Name"


@pytest.fixture
@patch(
    "sof_data.glue.glueprocessorjob.config.config_handler.ConfigHandler.get_json_config_file",
    return_value=MOCKED_JSON_CONFIG,
)
@patch(
    "sof_data.glue.glueprocessorjob.config.config_handler.ConfigHandler.get_rules_file_content",
    return_value=MOCKED_SQL_FILE_CONTENT,
)
# @patch("sofbase.common.utils.commons.return_ssm_param", return_value=MOCKED_SSM_PARAM_VALUE)
@patch(
    "sof_data.glue.glueprocessorjob.config.config_handler.return_ssm_param",
    return_value=MOCKED_SSM_PARAM_VALUE,
)
def config_handler(
    mock_get_json_config_file: MagicMock,
    mock_get_rules_file_content: MagicMock,
    mock_return_ssm_param: MagicMock,
) -> ConfigHandler:
    mock_args = {
        "WORKFLOW_NAME": "test_workflow",
        "STEP_NAME": "test_step",
        "RULES_PATH": "test_rules_path",
        "START_DT": "2021-01-01",
        "END_DT": "2021-12-31",
    }
    mock_spark = None
    mock_log = MagicMock()
    mock_driver_log = Logger()
    mock_glue_context = MagicMock()
    handler = ConfigHandler(
        args=mock_args,
        spark=mock_spark,
        log=mock_log,
        driver_log=mock_driver_log,
        glue_context=mock_glue_context,
    )
    return handler
