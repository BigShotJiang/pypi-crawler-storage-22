# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from pyspark.sql import DataFrame, SparkSession
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.processors.processor_factory import ProcessorFactory

code_string = """
from pyspark.sql import DataFrame, Row, SparkSession

def process(*, spark_session: SparkSession, input_properties: dict) -> DataFrame:
    input_name = input_properties.get("name")
    data = [Row(name=input_name, age=30), Row(name="Juan", age=25)]
    df = spark_session.createDataFrame(data)
    return df
"""


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.processor
def test_custom_code_processor(config_handler: ConfigHandler) -> None:
    config_handler.parameters["PROCESSOR_IMPLEMENTATION"] = "custom_code_processor"
    config_handler.parameters["CUSTOM_CODE_PROPERTIES"] = {"name": "Diego"}
    config_handler.spark = (
        SparkSession.builder.master("local").appName("SimpleDataFrameExample").getOrCreate()
    )
    config_handler.rules_file_content = code_string
    processor = ProcessorFactory.get_processor(config_handler=config_handler)
    df = processor.process_data()
    df.show()
    assert isinstance(df, DataFrame)
    collected_data = df.collect()
    assert collected_data[0].name == "Diego"
