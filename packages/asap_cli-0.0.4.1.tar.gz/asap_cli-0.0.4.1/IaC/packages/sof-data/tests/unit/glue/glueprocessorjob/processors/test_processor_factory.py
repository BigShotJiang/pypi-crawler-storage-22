# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.processors.custom_code_processor import (
    CustomCodeProcessor,
)
from sof_data.glue.glueprocessorjob.processors.processor_factory import ProcessorFactory
from sof_data.glue.glueprocessorjob.processors.sql_processor import SqlProcessor


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.factory
def test_get_processor(config_handler: ConfigHandler) -> None:
    assert config_handler.parameters["PROCESSOR_IMPLEMENTATION"] == "sql_processor"
    processor = ProcessorFactory.get_processor(config_handler=config_handler)
    assert isinstance(processor, SqlProcessor)
    assert isinstance(processor, CustomCodeProcessor) is False


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.factory
def test_instantiate_other_processor(config_handler: ConfigHandler) -> None:
    config_handler.parameters["PROCESSOR_IMPLEMENTATION"] = "custom_code_processor"
    processor = ProcessorFactory.get_processor(config_handler=config_handler)
    assert isinstance(processor, CustomCodeProcessor)
    assert isinstance(processor, SqlProcessor) is False
