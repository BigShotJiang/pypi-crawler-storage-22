# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.updaters.iceberg_updater import IcebergUpdater
from sof_data.glue.glueprocessorjob.updaters.updater_factory import UpdaterFactory
from sof_data.glue.glueprocessorjob.writers.glue_catalog_writer import GlueCatalogWriter


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.factory
def test_instantiate_other_writer(config_handler: ConfigHandler) -> None:
    config_handler.parameters["PROCESSOR_IMPLEMENTATION"] = "iceberg_updater"
    updater = UpdaterFactory.get_updater(config_handler=config_handler)
    assert isinstance(updater, IcebergUpdater)
    assert isinstance(updater, GlueCatalogWriter) is False
