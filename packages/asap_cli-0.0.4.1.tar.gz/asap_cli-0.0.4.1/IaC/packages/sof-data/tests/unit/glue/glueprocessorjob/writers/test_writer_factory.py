# Copyright 2024 Amazon Web Services
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from sof_data.glue.glueprocessorjob.config.config_handler import ConfigHandler
from sof_data.glue.glueprocessorjob.writers.glue_catalog_writer import GlueCatalogWriter
from sof_data.glue.glueprocessorjob.writers.redshift_writer import RedshiftWriter
from sof_data.glue.glueprocessorjob.writers.writer_factory import WriterFactory


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.factory
def test_get_writer(config_handler: ConfigHandler) -> None:
    assert config_handler.parameters["WRITER_IMPLEMENTATION"] == "glue_catalog_writer"
    writer = WriterFactory.get_writer(config_handler=config_handler)
    assert isinstance(writer, GlueCatalogWriter)
    assert isinstance(writer, RedshiftWriter) is False


@pytest.mark.filterwarnings("ignore::DeprecationWarning")
@pytest.mark.factory
def test_instantiate_other_writer(config_handler: ConfigHandler) -> None:
    config_handler.parameters["WRITER_IMPLEMENTATION"] = "redshift_writer"
    writer = WriterFactory.get_writer(config_handler=config_handler)
    assert isinstance(writer, RedshiftWriter)
    assert isinstance(writer, GlueCatalogWriter) is False
