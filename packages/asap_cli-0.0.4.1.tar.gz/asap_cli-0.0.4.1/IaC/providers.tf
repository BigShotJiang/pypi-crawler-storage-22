provider "aws" {
  region = "us-east-1"

  default_tags {
    tags = merge(
      {
        Platform_code     = var.platform_code
        Organization_code = var.organization_code
        Environment_code  = var.environment_code
        CreatedBy         = var.creator
        OwnedBy           = var.owner
      }
    )
  }
}