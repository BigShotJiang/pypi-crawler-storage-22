import json
import os
from typing import Any

from aws_lambda_powertools import Logger
from aws_lambda_powertools.logging import formatter


class CustomFormatter(formatter.LambdaPowertoolsFormatter):
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.remove_keys(["location", "timestamp", "service"])


# Initialize the logger with the custom formatter
log_level = os.environ.get("LOG_LEVEL", "DEBUG")
logger = Logger(service="SfnGenerator", logger_formatter=CustomFormatter())
logger.setLevel(log_level)

DEFAULT_WAIT_TIME_SECONDS = "20"
DEFAULT_TASK_TIMEOUT_MINS = "12"


# TODO: CGG - SFNGEN - High: Add CONTINUE_IF_FAIL Flag
# TODO: CGG - SFNGEN - Very High: Use SSM parameters for Orchestration Lambda and Task Executor
# TODO: CGG - SFNGEN - High: Add Total Levels and Total Branch Tasks to Step Function
# TODO: CGG - SFNGEN - High: Add Better Logger


# TODO: CGG - SFNGEN - Low: TaskPayload.Task.Status is Not Changing in Parent Data Workflow (It only transitions inside TaskExecutor)
# this impacts usability and experience in Root Parent Data Workflow (it stays as NOT_STARTED all the time)
class StepFunctionsGenerator:

    def __init__(self) -> None:
        self.environment: str = ""
        self.orchestration_lambda: str = ""
        self.task_executor_name: str = ""
        self.workflow_file: str = ""
        self.output_file: str = ""
        self.aws_account_number: str = ""
        self.aws_account_region: str = ""
        self.workflow_template: str = ""
        self.level_template: str = ""
        self.thread_template: str = ""
        self.task: str = ""
        self.workflow_description: str = "A description of my state machine"
        self.encoding: str = "utf-8"
        return None

    def generate_step_functions_json(self) -> None:

        with open(self.workflow_file, encoding=self.encoding) as json_file:
            workflow_definition = json.load(json_file)

        workflow_levels = workflow_definition.get("LEVELS", None)
        workflow_description = workflow_definition.get("DESCRIPTION", None)
        if workflow_definition is not None:
            print(workflow_description)
            self.workflow_description = workflow_description

        if workflow_levels is None:
            logger.error("No levels found in workflow definition")
            raise ValueError("No levels found in workflow definition")

        self.load_templates()
        workflow_body = self.generate_step_functions_body(workflow_levels)

        orchestration_lambda_arn = self.assemble_lambda_arn(self.orchestration_lambda)
        workflow_body = workflow_body.replace(
            "<<ORCHESTRATION_LAMBDA_ARN>>", orchestration_lambda_arn
        )
        workflow_body = workflow_body.replace("<<WORKFLOW_DESCRIPTION>>", self.workflow_description)
        print(workflow_body)

        # Split into folder, filename, extension
        dir_name, file_name = os.path.split(self.workflow_file)
        self.output_file = os.path.join(dir_name, f"output-{file_name}")
        self.write_result(workflow_body, self.output_file)

        # json_object = json.loads(workflow_body)
        # print(json.dumps(json_object, indent=2))

    def load_templates(self) -> None:
        """method for loading templates"""
        self.workflow_template = self.read_template("workflow")
        self.level_template = self.read_template("level")
        self.thread_template = self.read_template("thread")
        self.task = self.read_template("task")
        # self.task_executor_template = self.read_template("task_executor")
        # self.step_functions_sync_template = self.read_template("step_stepfunctions_sync")

    def read_template(self, template: str) -> str:
        """method to read templates"""
        try:
            with open(
                os.path.dirname(__file__) + "/templates/" + template + ".json",
                "r",
                encoding=self.encoding,
            ) as file:
                data = file.read()
                return data

        except Exception as err:
            logger.error("Error reading template file: " + str(type(err)))
            raise err

    def generate_step_functions_body(self, workflow_levels: list[dict]) -> str:
        """method to generate step functions body"""
        levels = self.process_levels(workflow_levels)
        workflow_body = self.workflow_template.replace("<<LEVELS>>", ",".join(levels))
        return workflow_body

    def process_levels(self, workflow_levels: list[dict[str, Any]]) -> list[str]:
        """method to process levels"""
        levels = []
        for level_index, level in enumerate(workflow_levels, start=1):
            logger.debug(f"Processing Level: {level_index}")
            level_body = self.level_template.replace("{LEVEL_ID}", str(level_index))
            if level_index != len(workflow_levels):
                level_body = level_body.replace(
                    "{NEXT_LEVEL_BLOCK}", '"Next":"Level_' + str(level_index + 1) + '"'
                )
            else:
                level_body = level_body.replace("{NEXT_LEVEL_BLOCK}", '"End": true')

            threads = level.get("THREADS", None)
            if threads is None:
                logger.error("No threads found in level definition")
                raise Exception("Trying to Process a Level without Threads")
            thread_bodies = self.process_threads(threads, level_index)
            level_body = level_body.replace("<<THREADS>>", ",".join(thread_bodies))
            levels.append(level_body)

        return levels

    def process_threads(self, threads: list[dict[str, Any]], level_index: int) -> list[str]:
        logger.debug(f"Processing Threads for level_index: {level_index}")
        # logger.debug(f"Type of Threads {type(threads[0])}")
        """method to process threads"""
        thread_bodies = []
        for thread_index, thread in enumerate(threads, start=1):

            tasks = thread.get("TASKS", None)
            if tasks is None:
                logger.error("No tasks found in thread definition")
                raise Exception("Trying to Process a thread without tasks")

            first_task_id = tasks[0].get("TASK_ID")
            thread_body = self.thread_template.replace("{STARTING_TASK_ID}", first_task_id)
            task_bodies = self.process_tasks(tasks, level_index, thread_index)
            thread_body = thread_body.replace("<<THREAD_STEPS>>", ",".join(task_bodies))
            thread_bodies.append(thread_body)
        return thread_bodies

    def process_tasks(self, tasks: list[dict], level_index: int, thread_index: int) -> list[str]:
        logger.debug(
            f"Processing Steps {tasks} level_index: {level_index} and thread_index {thread_index}"
        )
        """method to process steps"""
        task_bodies = []

        for task_index, task in enumerate(tasks, start=1):
            logger.debug(f"StepProcessing -> L:{level_index} T: {thread_index} S: {task_index} ")
            task_body = self.process_task(
                task,
                level_index,
                thread_index,
                task_index,
            )
            task_body = task_body.replace("{LEVEL_ID}", str(level_index))
            task_body = task_body.replace("{THREAD_ID}", str(thread_index))

            if task_index != len(tasks):
                next_task_index = task_index  # Task Index Started at 1
                next_task = tasks[next_task_index]
                next_task_name = str(next_task.get("TASK_ID"))
                task_body = task_body.replace("{NEXT_TASK_ID}", '"Next": "' + next_task_name + '"')
            else:
                task_body = task_body.replace("{NEXT_TASK_ID}", '"End": true ')

            task_bodies.append(task_body)
        return task_bodies

    def process_task(
        self, task: dict[str, Any], level_index: int, thread_index: int, task_index: int
    ) -> str:
        """method to process step lambda async"""
        logger.debug(f"ProcessTask: Processing task: {task.get('TASK_ID')}")
        task_id = task.get("TASK_ID", None)
        if task_id is None:
            logger.error("Task ID is None")
            raise Exception(f"Task ID is None for level: {level_index} and thread: {thread_index}")

        task_type = task.get("TASK_TYPE", None)
        logger.debug(task_type)
        if task_type is None:
            logger.debug("ProcessTask: TaskType is None")
            task_body = self.task.replace("{TASK_TYPE}", "DataProcessor")
        elif task_type == "SubWorkflow":
            task_body = self.task.replace("{TASK_TYPE}", "SubWorkflow")
            logger.debug(f"SubWorkflow: {task_body}")
        else:
            logger.error(f"Task type not supported: {task_type}")
            raise Exception("Task type not supported")

        task_body = task_body.replace("{TASK_ID}", str(task_id))
        task_body = task_body.replace("{ENVIRONMENT}", self.environment)
        task_body = task_body.replace("{LEVEL_INDEX}", str(level_index))
        task_body = task_body.replace("{THREAD_INDEX}", str(thread_index))
        task_body = task_body.replace("{TASK_INDEX}", str(task_index))

        task_wait_time_secs = task.get("TASK_EXECUTOR_WAIT_TIME_SECONDS", DEFAULT_WAIT_TIME_SECONDS)
        task_body = task_body.replace("{TASK_EXECUTOR_WAIT_TIME_SECONDS}", task_wait_time_secs)

        task_timeout_mins = task.get("TASK_TIMEOUT_MINS", DEFAULT_TASK_TIMEOUT_MINS)
        task_body = task_body.replace("{TASK_TIMEOUT_MINS}", task_timeout_mins)

        task_body = task_body.replace(
            "{TASK_EXECUTOR_SF_ARN}", self.assemble_stepfunctions_arn(self.task_executor_name)
        )
        return task_body

    def write_result(self, content: str, file: str) -> None:
        """method to write result to a file"""
        try:
            file_out = open(file, "w", encoding="utf-8")
            file_out.write(json.dumps(json.loads(content), indent=2))
            file_out.close()
        except Exception as err:
            logger.error("Error writing on output file: " + str(type(err)))
            raise err

    def assemble_lambda_arn(self, name: str) -> str:
        """method to assemble lambda ARN"""
        return (
            "arn:aws:lambda:"
            + self.aws_account_region
            + ":"
            + self.aws_account_number
            + ":function:"
            + name
        )

    def assemble_stepfunctions_arn(self, name: str) -> str:
        """method to assemble step functions arn"""
        return (
            "arn:aws:states:"
            + self.aws_account_region
            + ":"
            + self.aws_account_number
            + ":stateMachine:"
            + name
        )
