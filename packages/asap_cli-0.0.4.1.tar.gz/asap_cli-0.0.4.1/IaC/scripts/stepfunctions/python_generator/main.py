import argparse

from generator import StepFunctionsGenerator


def main():
    args = parse_arguments()
    generator = StepFunctionsGenerator()

    generator.environment = args.environment
    generator.orchestration_lambda = args.orchestration_lambda
    generator.task_executor_name = args.task_executor_name
    generator.workflow_file = args.workflow_file
    generator.aws_account_number = args.account_number
    generator.aws_account_region = args.account_region
    generator.generate_step_functions_json()


def parse_arguments():
    parser = argparse.ArgumentParser(prog="StepFunctionsGenerator")
    parser.add_argument("-env", "--environment", help="deploy environment (dev,test,prod)")
    parser.add_argument("-wf", "--workflow_file", help="worflow file with pipeline definition")
    parser.add_argument("-of", "--output_file", help="step functions generated code file")
    parser.add_argument("-ln", "--task_executor_name", help="task_executor step functions name")
    parser.add_argument("-te", "--orchestration_lambda", help="orchestration lambda name")
    parser.add_argument("-an", "--account_number", help="aws account number")
    parser.add_argument("-ar", "--account_region", help="aws account region")
    # parser.print_help()
    return parser.parse_args()


main()
