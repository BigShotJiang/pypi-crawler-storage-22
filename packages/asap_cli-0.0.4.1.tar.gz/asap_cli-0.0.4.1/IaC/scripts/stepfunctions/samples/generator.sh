python3 ../python_generator/main.py \
--environment dev \
--workflow_file $1 \
--orchestration_lambda sof-orch-task-orchestrator \
--task_executor_name sof-orch-task-executor \
--account_number 113304814880 \
--account_region us-east-1
