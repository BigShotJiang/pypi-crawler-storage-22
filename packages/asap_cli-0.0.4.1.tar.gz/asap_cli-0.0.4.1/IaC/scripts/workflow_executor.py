import argparse
import json
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING

import boto3
from dateutil.relativedelta import relativedelta
from sofbase.common.logger import LoggingService
from sofbase.services.orchestration_manager import ExecutionMetadataManager

if TYPE_CHECKING:
    from mypy_boto3_dynamodb import DynamoDBClient
    from mypy_boto3_s3 import S3Client
    from mypy_boto3_secretsmanager import SecretsManagerClient
    from mypy_boto3_ssm import SSMClient
    from mypy_boto3_stepfunctions import SFNClient

ssm_client: "SSMClient" = boto3.client("ssm")
s3_client: "S3Client" = boto3.client("s3")
dynamo_client: "DynamoDBClient" = boto3.client("dynamodb")
secrets_client: "SecretsManagerClient" = boto3.client("secretsmanager")
sfn_client: "SFNClient" = boto3.client("stepfunctions")

sep = "T"
timespec = "seconds"
data_domain = "Appsflyer"
data_product = "InstallsReport"
current_time = datetime.now(timezone.utc)
execution_id_suffix = f"{data_domain}-{data_product}-{current_time.strftime('%Y-%m-%d-%H%M%S')}"


# Successful Workflows
# workflow_name = "test-big-demo-workflow"
# workflow_name = "test-workflow"
# workflow_name = "test-2level-workflow"
# workflow_name = "test-3level-workflow"

# Failing Workflows
# workflow_name = "f-test-workflow"
# workflow_name = "f-test-2level-workflow"


logger = LoggingService().initialize_logger(log_level="ERROR")


def lambda_pipeline_executor(workflow_name: str, order_date: str, always_fail: str) -> None:

    odate = datetime.strptime(order_date, "%Y-%m-%d").date()
    odate.strftime("%Y-%m-%d")

    state_machine_arn = f"arn:aws:states:us-east-1:113304814880:stateMachine:{workflow_name}"

    # Unique Execution Id Across All Workflow Executions.
    eid = str(uuid.uuid4())[-12:]
    main_execution_id = f"{workflow_name}-{current_time.strftime('%Y-%m-%d-%H%M%S')}"

    emm = ExecutionMetadataManager(logger=logger, execution_id=main_execution_id)

    prr = emm.get_pipeline_registry_record(pipeline_name=workflow_name)

    default_delta = {"days": 0, "months": 0, "hours": 0}
    sd = default_delta
    ed = default_delta
    no_deltas = {"days": 0, "hours": 0, "months": 0}
    if prr is not None:
        sd = prr.get("relativedelta_start_date", no_deltas)
        ed = prr.get("relativedelta_end_date", no_deltas)

    start_date_dt = odate + relativedelta(
        days=int(sd["days"]), months=int(sd["months"]), hours=int(sd["hours"])
    )
    end_date_dt = odate + relativedelta(
        days=int(ed["days"]), months=int(ed["months"]), hours=int(ed["hours"])
    )

    print("*" * 20)
    print("Workflow Input")

    checkpoint: dict[str, int | list[str] | dict[str, int | list[str]]] | None = None

    # checkpoint = {
    #     "startAtLevel": 3,
    # }

    # checkpoint = {"startAtLevel": 3, "skipTasks": ["dummy_task9", "dummy_task10"]}

    # checkpoint = {
    #     "subworkflows_checkpoints": [
    #         {
    #             "test-2level-workflow": {
    #                 "startAtLevel": 3,
    #                 "skipTasks": ["Q", "W", "E"],
    #                 "subworkflow_checkpoints": [
    #                     {"commonWorkflow": {"startAtLevel": 3, "skipTasks": ["1", "2", "3"]}},
    #                 ],
    #             }
    #         },
    #         {
    #             "workflow2": {
    #                 "startAtLevel": 3,
    #                 "skipTasks": ["X", "Y", "Z"],
    #                 "subworkflow_checkpoints": [
    #                     {"commonWorkflow": {"startAtLevel": 3, "skipTasks": ["3", "4", "5"]}},
    #                 ],
    #             },
    #         },
    #     ],
    # }

    # checkpoint = {
    #     "subworkflow_checkpoints": [
    #         {
    #             "test-2level-workflow": {
    #                 "subworkflow_checkpoints": [
    #                     {
    #                         "test-workflow": {
    #                             "skipTasks": [
    #                                 "dummy_task2",
    #                             ]
    #                         }
    #                     },
    #                 ],
    #             }
    #         },
    #     ],
    # }

    # TODO: CGG - SCRIPTS - Documentation: Checkpoints - If you have multiple subworkflow in a root workflow. And you need to pass checkpoints to the subworkflows, all must have the same checkpoints.
    workflow_execution_input = {
        "rules_path": "rules",
        "start_date": start_date_dt.strftime("%Y-%m-%d"),
        "order_date": odate.strftime("%Y-%m-%d"),
        "end_date": end_date_dt.strftime("%Y-%m-%d"),
        # "additional_properties": {"checkpoint": {"startAtLevel": 3, "skipTasks": ["A", "B", "C"]}},
        # "additional_properties": {"checkpoint": {"skipTasks": ["dummy_task1", "dummy_task2"]}},
        # "additional_properties": {
        #     "checkpoint": {"startAtLevel": 3, "skipTasks": ["dummy_task9", "dummy_task10"]}
        # },
        # "additional_properties": {
        #     "checkpoint": {"basedOnExecutionId": "test-big-demo-workflow-2025-05-12-164522"}
        # },
        # "additional_properties": {"checkpoint": {"skipTasks": ["dummy_task2"]}},
        # "additional_properties": None,
        "additional_properties": {"checkpoint": checkpoint},
        "main_execution_id": main_execution_id,
        # "execution_depth": 0,
    }

    print(json.dumps(workflow_execution_input, indent=2))

    emm.start_pipeline_execution(
        pipeline_name=workflow_name,
        data_domain_name=data_domain,
        data_product_name=data_product,
        pipeline_input=workflow_execution_input,
        comment=f"Executed via CLI (Test Script). Comment for workflow {workflow_name}",
    )

    start_respone = sfn_client.start_execution(
        stateMachineArn=state_machine_arn,
        name=main_execution_id,
        input=json.dumps(workflow_execution_input),
    )

    print("*" * 20)
    print(f"Execution Name: {main_execution_id}")
    print(f"Execution ARN: {start_respone['executionArn']}")
    print(f"Execution Start Date: {start_respone['startDate']}")
    print("*" * 20)

    # print(json.dumps(start_respone, indent=2, cls=GeneralEncoder))


if __name__ == "__main__":

    parser = argparse.ArgumentParser(prog="PipelineExecutor")
    parser.add_argument("-w", "--workflow_name", help="Workflow Name")
    parser.add_argument("-d", "--order_date", help="Order Date")
    parser.add_argument("-f", "--always_fail", help="always_fail")
    args = parser.parse_args()

    if args.order_date is None:
        args.order_date = datetime.now().strftime("%Y-%m-%d")

    print(args)
    lambda_pipeline_executor(args.workflow_name, args.order_date, args.always_fail)
