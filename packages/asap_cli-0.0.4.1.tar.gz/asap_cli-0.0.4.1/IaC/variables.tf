#####################
# General Variables # 
#####################

variable "platform_code" {
  description = "Platform code"
  type        = string
  default     = "asap"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.platform_code)) &&
      length(var.platform_code) >= 1 &&
      length(var.platform_code) <= 4
    )
    error_message = "The 'platform_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "organization_code" {
  description = "organization code"
  type        = string
  default     = "org"

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.organization_code)) &&
      length(var.organization_code) >= 1 &&
      length(var.organization_code) <= 4
    )
    error_message = "The 'organization_code' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "environment_code" {
  description = "environment code"
  type        = string
  default     = "sand"

  validation {
    condition = (
      contains(["sand", "dev", "test", "prod"], var.environment_code) &&
      can(regex("^[a-z0-9]+$", var.environment_code)) &&
      length(var.environment_code) >= 1 &&
      length(var.environment_code) <= 4
    )
    error_message = "The 'environment_code' variable must be one of [sand, dev, test, prod], contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

variable "owner" {
  description = "owner of resource"
  type        = string
}

variable "creator" {
  description = "creator of resource"
  type        = string
}

variable "deletion_protection" {
  description = "wheter to enable deletion protection for data related resources"
  type        = bool
  default     = true
}

variable "teams" {
  description = "Map of teams with their configurations"
  type = map(object({
    team_code = string
    admin     = optional(bool, false)
  }))
  default = {}
}

variable "dataops_team" {
  description = "DataOps team code"
  type        = string

  validation {
    condition = (
      can(regex("^[a-z0-9]+$", var.dataops_team)) &&
      length(var.dataops_team) >= 1 &&
      length(var.dataops_team) <= 4
    )
    error_message = "The 'dataops_team' can contain only lowercase alphanumeric characters, and be 1 to 4 characters long."
  }
}

########################
# Networking Variables #
########################
variable "vpc_id" {
  type = string
}

variable "subnet_ids" {
  type = list(string)
}

variable "sg_ids" {
  type    = list(string)
  default = null
}
##############################
# Variables Common Libraries #
##############################

variable "lambda_runtime" {
  type = string
}

# Lambda Libraries Variables

variable "sof_base_lambda_runtimes" {
  description = "Compatible runtimes for the sof_base Lambda layer"
  type        = list(string)
  default     = ["python3.11"]
}

variable "pydantic_lambda_runtimes" {
  description = "Compatible runtimes for the Pydantic Lambda layer"
  type        = list(string)
  default     = ["python3.11"]
}

# Glue Libraries Variables


########################
# Encription Variables #
########################

variable "enable_cmk_appmanagement" {
  description = "Enable CMK for App Management resources"
  type        = bool
  default     = false
}

variable "s3_kms_key_arn" {
  description = "ARN of the KMS key for S3 encryption"
  type        = string
  #default     = null
}

variable "sqs_kms_master_key_id" {
  description = "KMS Key id for SQS"
  type        = string
}

variable "ddb_kms_key" {
  description = "KMS Key id for DynamoDB"
  type        = string
}

variable "kinesis_kms_key" {
  description = "KMS Key id for Kinesis"
  type        = string
}
variable "glue_kms_key_arn" {
  type = string
}
variable "aws_powertools_arn" {
  type        = string
  description = "ARN of the AWS Lambda Powertools layer"
}

# lambda layers paths

variable "sofbase_layer_path" {
  description = ".zip file path for the Sofbase layer"
  type        = string
  validation {
    condition     = can(regex("\\.zip$", var.sofbase_layer_path))
    error_message = "The 'sofbase_layer_path' must be a valid .zip file path."
  }

}
variable "pydantic_layer_path" {
  description = ".zip file path for the Pydantic layer"
  type        = string
  validation {
    condition     = can(regex("\\.zip$", var.pydantic_layer_path))
    error_message = "The 'pydantic_layer_path' must be a valid .zip file path."
  }
}
# glue libraries paths
variable "glue_sofdata_library_path" {
  description = ".whl file path for the sofdata layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_sofdata_library_path))
    error_message = "The 'glue_sofdata_library_path' must be a valid .whl file path."
  }
}
variable "glue_sofbase_library_path" {
  description = ".whl file path for the sofbase layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_sofbase_library_path))
    error_message = "The 'glue_sofbase_library_path' must be a valid .whl file path."
  }
}
variable "glue_jmespath_library_path" {
  description = ".whl file path for the jmespath layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_jmespath_library_path))
    error_message = "The 'glue_jmespath_library_path' must be a valid .whl file path."
  }

}
variable "glue_powertools_library_path" {
  description = ".whl file path for the powertools layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_powertools_library_path))
    error_message = "The 'glue_powertools_library_path' must be a valid .whl file path."
  }

}
variable "glue_typing_extensions_library_path" {
  description = ".whl file path for the typing_extensions layer"
  type        = string
  validation {
    condition     = can(regex("\\.whl$", var.glue_typing_extensions_library_path))
    error_message = "The 'glue_typing_extensions_library_path' must be a valid .whl file path."
  }
}
variable "execution_history_pitr_period_in_days" {
  description = "Point in time recovery period in days for execution history table. Set to null to disable."
  type        = number
  default     = null

  validation {
    condition     = var.execution_history_pitr_period_in_days == null || (var.execution_history_pitr_period_in_days >= 1 && var.execution_history_pitr_period_in_days <= 35)
    error_message = "The 'execution_history_pitr_period_in_days' must be between 1 and 35, or null to disable."
  }
}