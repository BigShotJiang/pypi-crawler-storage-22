from strands import Agent, tool
from strands.hooks import (
    HookProvider, 
    BeforeInvocationEvent, 
    AfterInvocationEvent,
    BeforeToolCallEvent, 
    AfterToolCallEvent,
    BeforeModelCallEvent,
    AfterModelCallEvent
)

# --- Your Animation Functions ---
def toggle_thinking(active: bool, message: str = ""):
    if active:
        print(f"\n🧠 [ANIMATION START]: {message}")
    else:
        print(f"✅ [ANIMATION STOP]")

# --- Corrected Hook Provider ---
class RealTimeUIHook(HookProvider):
    def register_hooks(self, registry):
        registry.add_callback(BeforeModelCallEvent, self.on_model_start)
        registry.add_callback(AfterModelCallEvent, self.on_model_end)
        registry.add_callback(BeforeToolCallEvent, self.on_tool_start)
        registry.add_callback(AfterToolCallEvent, self.on_tool_end)

    def on_model_start(self, event):
        toggle_thinking(True, "Reasoning...")

    def on_model_end(self, event):
        toggle_thinking(False)

    def on_tool_start(self, event: BeforeToolCallEvent):
        toggle_thinking(False)
        # FIX: Access .tool_use instead of .tool_call
        tool_name = getattr(event.tool_use, 'name', 'Unknown Tool')
        tool_args = getattr(event.tool_use, 'input', '{}')
        print(f"🛠️ [SYSTEM]: Executing {tool_name} with args: {tool_args}")

    def on_tool_end(self, event: AfterToolCallEvent):
        # FIX: Access .tool_output.content
        result = "Success"
        if hasattr(event, 'tool_output'):
            result = event.tool_output.content
        
        print(f"📥 [SYSTEM]: Tool Result: {result}")
        toggle_thinking(True, "Analyzing result...")

# --- Tool and Agent Setup ---
@tool
def calculate_metrics(data_points: list[int]):
    """Calculates the sum of a list of numbers."""
    return str(sum(data_points))

agent = Agent(
    tools=[calculate_metrics],
    hooks=[RealTimeUIHook()]
)

# Execute
try:
    response = agent("Sum these numbers: 10, 20, 30")
    print(f"\n🤖 Agent: {response}")
except Exception as e:
    print(f"\n❌ Final Error Check: {e}")