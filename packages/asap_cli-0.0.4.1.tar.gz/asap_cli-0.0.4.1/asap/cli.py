import typer
import sys
import os

# Add the parent directory to Python path so we can import utils
parent_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, parent_dir)

app = typer.Typer(help="🚀 ASAP CLI Tool")

# Direct import and registration
try:
    from asap.agent.main import register
    register(app)
except Exception as e:
    print(f"Warning: Could not load agent command: {e}")

# Register deploy commands
try:
    from asap.deploy.main import register as register_deploy
    register_deploy(app)
except Exception as e:
    print(f"Warning: Could not load deploy commands: {e}")

# Register operation commands    
try:
    from asap.operation.main import register as register_operation
    register_operation(app)
except Exception as e:
    print(f"Warning: Could not load deploy commands: {e}")

def main():
    app()
