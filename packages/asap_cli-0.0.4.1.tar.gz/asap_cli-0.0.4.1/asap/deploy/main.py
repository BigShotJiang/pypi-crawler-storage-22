import typer

text = """
🚀 Initialize, setup ASAP project

COMMANDS: 

[project] Initialize ASAP project
[config] Initialize config ASAP Project
[check_prereq] Check prerequisites for ASAP projectexit
[create_vpc_endpoints] Create VPC endpoints
[terraform_setup] Terraform initial setup 
[terraform_deploy] Deploy Terraform
[git_init] Init the git repository
"""

def register(app: typer.Typer):
    """Register start commands with the main app"""
    start_app = typer.Typer(help=text)
    app.add_typer(start_app, name="start")

    @start_app.command("project")
    def start_project_command():
        """
        🚀 Initialize a new ASAP project with configuration setup
        """
        from asap.deploy.onboarding.utils.start_project import start_project
        from asap.deploy.onboarding.utils.check_prerequisites import check_prerequisites
        from asap.deploy.onboarding.utils.vpc_endpoints import create_vpc_endpoints
        from asap.deploy.onboarding.utils.setup_terraform import setup_iac
        from asap.deploy.onboarding.utils.deploy_terraform import deploy_terraform
        from asap.deploy.onboarding.utils.setup_lakeformation import setup_lakeformation
        from asap.deploy.onboarding.utils.git_init import init_git
        
        # TODO Get owner and creator as variable in input for the user
        start_project()
        if not check_prerequisites():
            return
        if not create_vpc_endpoints():
            return
        if not setup_lakeformation():
            return
        if not setup_iac():
            return
        if not deploy_terraform():
            return
        
        init_git()


    @start_app.command("config")
    def config_project_command():
        """
        🤖 Start config asap project
        """
        from asap.deploy.onboarding.utils.start_project import start_project

        start_project()

        pass      

    @start_app.command("check_prereq")
    def start_project_command():
        """
        🔎 Check prerequisites to start with the deployment
        """
        from asap.deploy.onboarding.utils.check_prerequisites import check_prerequisites
        

        check_prerequisites()
        return
    
    @start_app.command("create_vpc_endpoints")
    def start_project_command():
        """
        ⚙️⚙️ Build VPC, subnets, SG and endpoints
        """
        from asap.deploy.onboarding.utils.vpc_endpoints import create_vpc_endpoints
        

        create_vpc_endpoints()
        return
    
    @start_app.command("setup_lakeformation")
    def start_project_command():
        """
        ⚙️⚙️ Setup lakeformation and create default database in glue
        """
        from asap.deploy.onboarding.utils.setup_lakeformation import setup_lakeformation
        

        setup_lakeformation()
        return
    
    @start_app.command("terraform_setup")
    def start_project_command():
        """
        ⚙️⚙️ Setup terraform tvars and tfbackend
        """
        from asap.deploy.onboarding.utils.setup_terraform import setup_iac
        

        setup_iac()
        return
    
    @start_app.command("terraform_deploy")
    def start_project_command():
        """
        📠📠 Deploy terraform template 
        """
        from asap.deploy.onboarding.utils.deploy_terraform import deploy_terraform
        

        deploy_terraform()
        return
    
    @start_app.command("git_init")
    def start_project_command():
        """
        ⚙️⚙️ Init the git project
        """
        from asap.deploy.onboarding.utils.git_init import init_git
        

        init_git()
        return
    
    @start_app.command("data_engineer_repo")
    def start_project_command():
        """
        ⚙️⚙️ Create data engineer repo
        """
        from asap.deploy.onboarding.utils.DE_REPO.config_de_repo import start_de_project
        from asap.deploy.onboarding.utils.git_init import init_git
        
        start_de_project()
        init_git()
        
        return