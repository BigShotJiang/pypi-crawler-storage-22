import shutil
from pathlib import Path

def copy_docs_folder_to_project_root(project_root: str) -> None:
    """
    Copy the entire docs folder to the target project root.
    
    Args:
        project_root: Path to the target project root directory
    """
    # Get the CLI package directory
    cli_package_dir = Path(__file__).parent
    
    # Source docs folder
    docs_source = cli_package_dir / "docs"
    
    # Target location
    target_docs = Path(project_root) / "docs"
    
    # Check if source exists
    if not docs_source.exists():
        raise FileNotFoundError(f"Docs folder not found at {docs_source}")
    
    # Copy the entire directory
    if target_docs.exists():
        shutil.rmtree(target_docs)  # Remove existing docs folder
    
    shutil.copytree(docs_source, target_docs)
    