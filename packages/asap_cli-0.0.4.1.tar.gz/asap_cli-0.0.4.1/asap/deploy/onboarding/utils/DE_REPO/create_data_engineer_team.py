import os
import shutil
from pathlib import Path

# Colors for pretty logs
RESET = '\033[0m'
BOLD = '\033[1m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
YELLOW = '\033[93m'
RED = '\033[0;31m'

def log_info(msg): print(f"{CYAN}[INFO]{RESET} {msg}")
def log_success(msg): print(f"{GREEN}[SUCCESS]{RESET} {msg}")
def log_warn(msg): print(f"{YELLOW}[WARN]{RESET} {msg}")
def log_error(msg): print(f"{RED}[ERROR]{RESET} {msg}")


class CreateFoldersDE:

    def __init__(self):
        pass

    @staticmethod
    def __copy_docs():
        """
        Copy the entire docs folder from the CLI package to the current project root.
        The target will be <current_directory>/docs
        """
        import asap
    
        # Get the asap package location and go up to repository root
        asap_package_path = Path(asap.__file__).parent
        repo_root = asap_package_path.parent  # This goes from asap/ to asap-cli/
        docs_source = repo_root / "docs"
        
        if not docs_source.exists():
            raise FileNotFoundError(f"Docs folder not found at {docs_source}")
        
        # Target directory (current working directory + docs)
        current_dir = Path(os.getcwd())
        target_docs = current_dir / "docs/"
        
        # Copy the entire directory
        if target_docs.exists():
            shutil.rmtree(target_docs) 
        
        shutil.copytree(docs_source, target_docs)
        
        
    
    @staticmethod
    def __get_examples_dir():
        """Locate the examples directory in the asap package"""
        try:
            # Try to import asap to find package location
            import asap
            asap_package_dir = os.path.dirname(asap.__file__)
            examples_dir = os.path.join(
                asap_package_dir,
                'deploy',
                'onboarding',
                'utils',
                'DE_REPO',
                'examples'
            )
            return examples_dir
        except ImportError:
            # Fallback to relative path from current file
            # Since this file is in DE_REPO/, examples is a sibling directory
            current_dir = os.path.dirname(os.path.abspath(__file__))
            examples_dir = os.path.join(current_dir, 'examples')
            return os.path.normpath(examples_dir)

    @staticmethod
    def __copy_examples(examples_dir):
        """Copy example files from package to project folders"""
        try:
            log_info("📁 Copying example files from package...")
            
            # Define source and destination mappings with nested structure
            copies = [
                {
                    'src': os.path.join(examples_dir, 'step_functions', 'test_workflow.json'),
                    'dst': os.path.join(os.getcwd(), 'pipelines', 'test_workflow', 'step_function', 'test_workflow.json'),
                    'desc': 'pipelines/test_workflow/step_function/test_workflow.json'
                },
                {
                    'src': os.path.join(examples_dir, 'transformations', 'test_workflow'),
                    'dst': os.path.join(os.getcwd(), 'pipelines', 'test_workflow', 'transformations'),
                    'desc': 'pipelines/test_workflow/transformations'
                }
            ]
            
            for item in copies:
                src_path = item['src']
                dst_path = item['dst']
                
                if not os.path.exists(src_path):
                    log_warn(f"⚠️  Source not found: {item['desc']}")
                    continue
                
                # Copy file or directory
                if os.path.isdir(src_path):
                    if os.path.exists(dst_path):
                        shutil.rmtree(dst_path)
                    shutil.copytree(src_path, dst_path)
                    log_success(f"✅ Copied directory: {item['desc']}")
                else:
                    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                    shutil.copy2(src_path, dst_path)
                    log_success(f"✅ Copied file: {item['desc']}")
            
            return True
            
        except Exception as e:
            log_error(f"Failed to copy example files: {str(e)}")
            return False


    def create_project_structure(self):
        """Create project folders and README file"""
        try:
            log_info("🚀 Starting project setup...")
            
            # Create nested folder structure: pipelines/test_workflow/step_function
            # and pipelines/test_workflow/transformations
            nested_folders = [
                os.path.join('pipelines', 'test_workflow', 'step_function'),
                os.path.join('pipelines', 'test_workflow', 'transformations')
            ]
            
            for folder in nested_folders:
                os.makedirs(folder, exist_ok=True)
                log_success(f"✅ Created folder: {folder}")
            
            self.__copy_docs()
            
            log_success("✅ Created docs files")
            
            # Get examples directory
            examples_dir = self.__get_examples_dir()
            
            if not os.path.exists(examples_dir):
                log_warn(f"⚠️  Examples directory not found: {examples_dir}")
                log_warn("⚠️  Skipping example file copy")
            else:
                log_info(f"Found examples directory: {examples_dir}")
                self.__copy_examples(examples_dir)
            
            log_success("🎉 Setup complete!")
            
            return True
            
        except Exception as e:
            log_error(f"Failed to create project structure: {str(e)}")
            return False
    


