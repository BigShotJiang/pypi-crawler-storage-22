SELECT
  CAST(product_id AS INTEGER) as product_id,
  product_name
FROM
    $SOURCE_DATABASE.product_raw