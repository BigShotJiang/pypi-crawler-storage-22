SELECT
  product_id,
  upper(product_name) as product_name
FROM
  $SOURCE_DATABASE.product_stg
