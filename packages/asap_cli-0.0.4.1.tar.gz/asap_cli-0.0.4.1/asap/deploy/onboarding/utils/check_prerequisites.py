import typer
import json
import os
import subprocess
from typing import Optional

# ANSI color codes (matching existing CLI style)
RESET = '\033[0m'
BOLD = '\033[1m'
GRAY = '\033[90m'
ORANGE = '\033[38;5;208m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
WHITE = '\033[97m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
RED = '\033[0;31m'

def print_prerequisites_banner():
    """Print the prerequisites check banner"""
    print("\n")
    
    # Header box
    print(f"{ORANGE}┌──────────────────────────────────────────────────────────────────────┐{RESET}")
    print(f"{ORANGE}│{RESET} {ORANGE}{BOLD}PREREQUISITES CHECK{RESET}                                              {ORANGE}│{RESET}")
    print(f"{ORANGE}│{RESET}                                                                      {ORANGE}│{RESET}")
    print(f"{ORANGE}│{RESET} Let's verify your system meets the requirements                     {ORANGE}│{RESET}")
    print(f"{ORANGE}└──────────────────────────────────────────────────────────────────────┘{RESET}")
    print()

def load_config() -> dict:
    """Load configuration from config.json file"""
    config_path = "config.json"
    
    if not os.path.exists(config_path):
        raise Exception(f"Configuration file {config_path} not found. Please run project initialization first.")
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        raise Exception(f"Failed to load configuration: {str(e)}")

def run_prerequisites_check(account_id: str) -> bool:
    """Execute the prerequisites check bash script with live logging and colored prefixes"""
    script_path = os.path.join(
        os.path.dirname(__file__),
        "..", "bash", "prerequisites", "check_prer.sh"
    )
    
    if not os.path.exists(script_path):
        raise Exception(f"Prerequisites check script not found at: {script_path}")
    
    try:
        print(f"{CYAN}🔍 Running system prerequisites check...{RESET}\n")
        
        # Run process with live streaming
        process = subprocess.Popen(
            ["bash", script_path, account_id],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,   # merge stderr into stdout
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        for line in process.stdout:
            line_stripped = line.strip()
            if not line_stripped:
                continue

            # Colorize output
            if "error" in line_stripped.lower() or "fail" in line_stripped.lower():
                print(f"{RED}[ERROR]{RESET} {line_stripped}")
            elif "warning" in line_stripped.lower() or "warn" in line_stripped.lower():
                print(f"{YELLOW}[WARN]{RESET} {line_stripped}")
            else:
                print(f"{CYAN}[INFO]{RESET} {line_stripped}")
        
        process.wait(timeout=60)

        # After process finishes, parse the JSON report
        json_report_path = "prereq-report.json"
        if not os.path.exists(json_report_path):
            raise Exception(f"Prerequisites report file {json_report_path} was not created by the script")
        
        with open(json_report_path, "r", encoding="utf-8") as f:
            report_data = json.load(f)
        
        # Check results
        all_passed = True
        for check in report_data:
            if check.get("result") == "FAIL":
                all_passed = False
                break
        
        return all_passed

    except subprocess.TimeoutExpired:
        raise Exception("Prerequisites check timed out after 60 seconds")
    except Exception as e:
        raise Exception(f"Failed to execute prerequisites check: {str(e)}")

def check_prerequisites() -> bool:
    """Main function to check prerequisites"""
    try:
        print_prerequisites_banner()
        
        # Load configuration
        config_data = load_config()
        account_id = config_data.get("account_id")
        
        if not account_id:
            raise Exception("AWS Account ID not found in configuration")
        
        print(f"{YELLOW}📋 Configuration loaded:{RESET}")
        print(f"   Account ID: {account_id}")
        print(f"   Region: {config_data.get('region', 'N/A')}")
        print(f"   Project Name: {config_data.get('project_name', 'N/A')}")
        
        # Ask for confirmation
        if not typer.confirm(f"\n{CYAN}Proceed with prerequisites check?{RESET}"):
            print(f"{YELLOW}Prerequisites check cancelled.{RESET}")
            return False
        
        # Run the check
        success = run_prerequisites_check(account_id)
        
        if success:
            print(f"\n{GREEN}✅ Prerequisites check completed successfully!{RESET}")
            print(f"{CYAN}You're ready to proceed with the next steps.{RESET}")
        else:
            print(f"\n{RED}❌ Prerequisites check failed!{RESET}")
            print(f"{YELLOW}Please address the issues above before continuing.{RESET}")
        
        return success
        
    except Exception as e:
        print(f"\n{RED}❌ Error during prerequisites check: {str(e)}{RESET}")
        return False