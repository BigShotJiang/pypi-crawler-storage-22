import os
import json
import subprocess
import shutil
from importlib import resources
from datetime import datetime

# Colors for pretty logs
RESET = '\033[0m'
BOLD = '\033[1m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
YELLOW = '\033[93m'
RED = '\033[0;31m'

def log_info(msg): print(f"{CYAN}[INFO]{RESET} {msg}")
def log_success(msg): print(f"{GREEN}[SUCCESS]{RESET} {msg}")
def log_warn(msg): print(f"{YELLOW}[WARN]{RESET} {msg}")
def log_error(msg): print(f"{RED}[ERROR]{RESET} {msg}")


def load_config(config_path="config.json") -> dict:
    if not os.path.exists(config_path):
        raise Exception(f"Config file not found: {config_path}")
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def execute_bash_script(script_name: str, description: str, args: list = None) -> bool:
    """
    Generic function to execute bash scripts with proper error handling and logging
    
    Args:
        script_name: Name of the bash script file
        description: Human-readable description of what the script does
        args: Optional list of arguments to pass to the script
    
    Returns:
        bool: True if script executed successfully, False otherwise
    """
    script_path = os.path.join(
        os.path.dirname(__file__), "..", "bash", "create", script_name
    )

    if not os.path.exists(script_path):
        raise Exception(f"Bash script not found: {script_path}")

    log_info(f"🚀 {description}...")

    # Prepare command with optional arguments
    cmd = ["bash", script_path]
    if args:
        cmd.extend(args)

    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )

        # Stream output in real-time
        for line in process.stdout:
            print(line.strip())
        
        process.wait()

        if process.returncode == 0:
            log_success(f"{description} completed successfully")
            return True
        else:
            raise Exception(f"{description} failed with exit code: {process.returncode}")

    except subprocess.SubprocessError as e:
        raise Exception(f"Failed to execute {script_name}: {str(e)}")


def copy_iac_to_terraform(terraform_dir):
    """Copy IaC files from package to terraform directory"""
    try:
        log_info("📁 Copying IaC files from package to terraform directory...")
        
        # Get the package's IaC directory using modern importlib approach
        try:
            # Try to locate the IaC directory relative to the asap package
            import asap
            asap_package_dir = os.path.dirname(asap.__file__)
            package_iac_dir = os.path.join(os.path.dirname(asap_package_dir), 'IaC')
        except ImportError:
            # Fallback to relative path from current file
            current_dir = os.path.dirname(os.path.abspath(__file__))
            package_iac_dir = os.path.join(current_dir, '..', '..', '..', '..', 'IaC')
            package_iac_dir = os.path.normpath(package_iac_dir)
        
        if not os.path.exists(package_iac_dir):
            log_error(f"IaC directory not found in package: {package_iac_dir}")
            return False
            
        # Copy all contents from package IaC to terraform directory
        for item in os.listdir(package_iac_dir):
            if item.startswith('.'):  # Skip hidden files like .DS_Store
                continue
                
            src_path = os.path.join(package_iac_dir, item)
            dst_path = os.path.join(terraform_dir, item)
            
            if os.path.isdir(src_path):
                if os.path.exists(dst_path):
                    shutil.rmtree(dst_path)
                shutil.copytree(src_path, dst_path)
                log_info(f"Copied directory: {item}")
            else:
                shutil.copy2(src_path, dst_path)
                log_info(f"Copied file: {item}")
        
        log_success("✅ IaC files copied successfully")
        return True
        
    except Exception as e:
        log_error(f"Failed to copy IaC files: {str(e)}")
        return False


def deploy_terraform():
    """Deploy Terraform infrastructure using the deploy_terraform.sh script"""
    log_info("🚀 Starting Terraform deployment...")

    try:
        # Validate config exists
        config = load_config()
        project_name = config.get("project_name")
        
        if not project_name:
            log_error("project_name not found in config.json")
            return False

        log_info(f"Deploying Terraform for project: {project_name}")

        # Check if terraform directory exists
        terraform_dir = os.path.join(os.getcwd(), "terraform")
        if not os.path.exists(terraform_dir):
            log_error("Terraform directory not found. Please run setup_terraform.py first")
            return False

        # Copy IaC files to terraform directory
        if not copy_iac_to_terraform(terraform_dir):
            return False

        # Validate required Terraform files exist
        backend_config = os.path.join(terraform_dir, f"{project_name}.tfbackend")
        var_file = os.path.join(terraform_dir, f"{project_name}.tfvars")
        
        if not os.path.exists(backend_config):
            log_error(f"Backend config file not found: {backend_config}")
            return False
            
        if not os.path.exists(var_file):
            log_error(f"Variables file not found: {var_file}")
            return False

        log_info(f"Found backend config: {backend_config}")
        log_info(f"Found variables file: {var_file}")

        # Execute the deployment script
        execute_bash_script(
            "deploy_terraform.sh",
            "Deploying Terraform infrastructure"
        )

        log_success("✅ Terraform deployment completed successfully!")
        return True
        
    except Exception as e:
        log_error("Terraform deployment failed")
        log_error(f"Error: {str(e)}")
        return False


if __name__ == "__main__":
    try:
        deploy_terraform()
    except Exception as e:
        log_error(str(e))
        exit(1)