import os
import json
import subprocess
import typer

# ANSI color codes (matching existing CLI style)
RESET = '\033[0m'
BOLD = '\033[1m'
GRAY = '\033[90m'
ORANGE = '\033[38;5;208m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
WHITE = '\033[97m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
RED = '\033[0;31m'


def print_git_banner(project_name: str, dataops_team: str):
    """Print a banner after successfully initializing the Git repository."""
    print("\n")
    print(f"{GREEN}┌────────────────────────────────────────────────────────────────────────────┐{RESET}")
    print(f"{GREEN}│{RESET} {BOLD}✅ GIT REPOSITORY INITIALIZED SUCCESSFULLY{RESET}                                     {GREEN}│{RESET}")
    print(f"{GREEN}│{RESET}                                                                      {GREEN}│{RESET}")
    print(f"{GREEN}│{RESET} 📦 Project: {CYAN}{project_name}{RESET}")
    print(f"{GREEN}│{RESET} 👩‍💻 DataOps Team: {CYAN}{dataops_team}{RESET}")
    print(f"{GREEN}│{RESET} 🚀 Ready to push your first commit to remote or start development.   {GREEN}│{RESET}")
    print(f"{GREEN}└────────────────────────────────────────────────────────────────────────────┘{RESET}")
    print("\n")

def init_git_repo_from_config(config_path: str, remote_url: str = None, default_branch: str = "main") -> None:
    """
    Initializes a Git repository in the current working directory using metadata from a config.json file.

    Args:
        config_path (str): Path to config.json containing 'project_name' and 'dataops_team'.
        remote_url (str, optional): Remote repository URL to add as 'origin'.
        default_branch (str, optional): Default branch name. Defaults to 'main'.
    """

    # 1️⃣ Load project metadata from config.json
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"❌ Config file not found: {config_path}")

    with open(config_path, "r") as f:
        config = json.load(f)

    project_name = config.get("project_name")
    dataops_team = config.get("dataops_team")
    dataeng_team = config.get("dataeng_team")

    # Accept either dataops_team or dataeng_team
    team = dataops_team or dataeng_team

    if not project_name or not team:
        raise ValueError("❌ Config file must include 'project_name' and either 'dataops_team' or 'dataeng_team' keys.")

    # Use 'team' variable for the rest of your code
    dataops_team = team

    # 2️⃣ Set repo path to current directory
    repo_path = os.getcwd()

    # 3️⃣ Initialize Git repository
    subprocess.run(["git", "init", "-b", default_branch], check=True)

    # 4️⃣ Create .gitignore (Python + Terraform best practices)
    gitignore_content = """
    # --- Python ---
    __pycache__/
    *.pyc
    *.pyo
    *.pyd
    *.egg-info/
    venv/
    .env
    .env.*
    *.log

    # --- Jupyter ---
    .ipynb_checkpoints

    # --- Terraform ---
    .terraform/
    *.tfstate
    *.tfstate.*
    *.tfvars
    .terraform.lock.hcl
    crash.log

    # --- OS / Editor ---
    .DS_Store
    *.swp
    *.swo
    .idea/
    .vscode/
    """
    
    gitignore_path = os.path.join(repo_path, ".gitignore")
    if not os.path.exists(gitignore_path):  # don't overwrite if already exists
        with open(gitignore_path, "w") as f:
            f.write(gitignore_content.strip())

    # 5️⃣ Stage and commit everything
    subprocess.run(["git", "add", "."], check=True)
    commit_message = f"First deploy {project_name} for {dataops_team}"
    subprocess.run(["git", "commit", "-m", commit_message], check=True)

    # 6️⃣ Add remote if provided
    if remote_url:
        subprocess.run(["git", "remote", "add", "origin", remote_url], check=True)

    # 7️⃣ Final success message
    print_git_banner(project_name,dataops_team)

    

def init_git():
    """Initialize a Git repository in the current directory using config.json."""
    config_path = "config.json"

    # Ask user for optional remote URL
    remote_url = typer.prompt(
        f"{CYAN}Enter remote repository URL (press Enter to skip){RESET}",
        default="",
        show_default=False
    ).strip() or None

    try:
        init_git_repo_from_config(config_path=config_path, remote_url=remote_url)
    except Exception as e:
        print(f"{RED}❌ Git initialization failed: {str(e)}{RESET}")


# 🧪 Example usage:
# init_git_repo_from_config("config.json")
# init_git_repo_from_config("config.json", remote_url="https://github.com/org/repo.git")
