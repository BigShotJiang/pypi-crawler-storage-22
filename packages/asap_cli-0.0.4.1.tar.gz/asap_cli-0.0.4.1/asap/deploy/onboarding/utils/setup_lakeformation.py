import typer
import json
import os
import subprocess
from typing import Optional

# ANSI color codes (matching existing CLI style)
RESET = '\033[0m'
BOLD = '\033[1m'
GRAY = '\033[90m'
ORANGE = '\033[38;5;208m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
WHITE = '\033[97m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
RED = '\033[0;31m'

def print_lakeformation_banner():
    """Print the Lake Formation setup banner"""
    print("\n")
    
    # Header box
    print(f"{ORANGE}┌──────────────────────────────────────────────────────────────────────┐{RESET}")
    print(f"{ORANGE}│{RESET} {ORANGE}{BOLD}LAKE FORMATION SETUP{RESET}                                             {ORANGE}│{RESET}")
    print(f"{ORANGE}│{RESET}                                                                      {ORANGE}│{RESET}")
    print(f"{ORANGE}│{RESET} Setting up Lake Formation permissions for your role                 {ORANGE}│{RESET}")
    print(f"{ORANGE}└──────────────────────────────────────────────────────────────────────┘{RESET}")
    print()

def load_config() -> dict:
    """Load configuration from config.json file"""
    config_path = "config.json"
    
    if not os.path.exists(config_path):
        raise Exception(f"Configuration file {config_path} not found. Please run project initialization first.")
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        raise Exception(f"Failed to load configuration: {str(e)}")

def run_lakeformation_setup(role_name: str) -> bool:
    """Execute the Lake Formation setup bash script with live logging and colored prefixes"""
    script_path = os.path.join(
        os.path.dirname(__file__),
        "..", "bash", "prerequisites", "lakeformation_prer.sh"
    )
    
    if not os.path.exists(script_path):
        raise Exception(f"Lake Formation setup script not found at: {script_path}")
    
    try:
        print(f"{CYAN}🔐 Setting up Lake Formation permissions...{RESET}\n")
        
        # Run process with live streaming
        process = subprocess.Popen(
            ["bash", script_path, role_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,   # merge stderr into stdout
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        for line in process.stdout:
            line_stripped = line.strip()
            if not line_stripped:
                continue

            # Colorize output
            if "error" in line_stripped.lower() or "❌" in line_stripped:
                print(f"{RED}[ERROR]{RESET} {line_stripped}")
            elif "warning" in line_stripped.lower() or "⚠️" in line_stripped:
                print(f"{YELLOW}[WARN]{RESET} {line_stripped}")
            elif "✅" in line_stripped or "successfully" in line_stripped.lower():
                print(f"{GREEN}[SUCCESS]{RESET} {line_stripped}")
            else:
                print(f"{CYAN}[INFO]{RESET} {line_stripped}")
        
        process.wait(timeout=120)
        
        # Check return code
        if process.returncode == 0:
            return True
        else:
            raise Exception(f"Lake Formation setup script failed with exit code {process.returncode}")

    except subprocess.TimeoutExpired:
        raise Exception("Lake Formation setup timed out after 120 seconds")
    except Exception as e:
        raise Exception(f"Failed to execute Lake Formation setup: {str(e)}")

def setup_lakeformation(role_name: Optional[str] = None) -> bool:
    """Main function to setup Lake Formation permissions"""
    try:
        print_lakeformation_banner()
        
        # Load configuration
        config_data = load_config()
        
        print(f"{YELLOW}📋 Configuration loaded:{RESET}")
        print(f"   Account ID: {config_data.get('account_id', 'N/A')}")
        print(f"   Region: {config_data.get('region', 'N/A')}")
        print(f"   Project Name: {config_data.get('project_name', 'N/A')}")
        
        # Get role name if not provided
        if not role_name:
            role_name = typer.prompt(f"\n{CYAN}Enter the IAM role name for Lake Formation permissions{RESET}")
        
        print(f"\n{YELLOW}Target Role: {role_name}{RESET}")
        
        # Ask for confirmation
        if not typer.confirm(f"\n{CYAN}Proceed with Lake Formation setup?{RESET}"):
            print(f"{YELLOW}Lake Formation setup cancelled.{RESET}")
            return False
        
        # Run the setup
        success = run_lakeformation_setup(role_name)
        
        if success:
            print(f"\n{GREEN}✅ Lake Formation setup completed successfully!{RESET}")
            print(f"{CYAN}Permissions have been granted to role: {role_name}{RESET}")
        else:
            print(f"\n{RED}❌ Lake Formation setup failed!{RESET}")
            print(f"{YELLOW}Please check the errors above and try again.{RESET}")
        
        return success
        
    except Exception as e:
        print(f"\n{RED}❌ Error during Lake Formation setup: {str(e)}{RESET}")
        return False