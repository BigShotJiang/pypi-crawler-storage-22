import os
import json
import subprocess
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from datetime import datetime

# Colors for pretty logs
RESET = '\033[0m'
BOLD = '\033[1m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
YELLOW = '\033[93m'
RED = '\033[0;31m'

def log_info(msg): print(f"{CYAN}[INFO]{RESET} {msg}")
def log_success(msg): print(f"{GREEN}[SUCCESS]{RESET} {msg}")
def log_warn(msg): print(f"{YELLOW}[WARN]{RESET} {msg}")
def log_error(msg): print(f"{RED}[ERROR]{RESET} {msg}")


def get_vpc_id_by_name(vpc_name: str, region: str) -> str:
    """Get VPC ID by VPC name tag"""
    try:
        ec2 = boto3.client('ec2', region_name=region)
        response = ec2.describe_vpcs(
            Filters=[
                {'Name': 'tag:Name', 'Values': [vpc_name]},
                {'Name': 'state', 'Values': ['available']}
            ]
        )
        
        if not response['Vpcs']:
            raise Exception(f"VPC with name '{vpc_name}' not found in region {region}")
            
        if len(response['Vpcs']) > 1:
            log_warn(f"Multiple VPCs found with name '{vpc_name}', using the first one")
            
        return response['Vpcs'][0]['VpcId']
        
    except NoCredentialsError:
        raise Exception("AWS credentials not configured. Please run 'aws configure'")
    except ClientError as e:
        raise Exception(f"AWS API error while fetching VPC ID: {e}")


def get_subnet_ids_by_name(subnet_name: str, region: str, vpc_id: str) -> list:
    """Get subnet IDs by subnet name pattern (supports multiple subnets with similar names)"""
    try:
        ec2 = boto3.client('ec2', region_name=region)
        response = ec2.describe_subnets(
            Filters=[
                {'Name': 'tag:Name', 'Values': [f"{subnet_name}*"]},  # Pattern match
                {'Name': 'vpc-id', 'Values': [vpc_id]},
                {'Name': 'state', 'Values': ['available']}
            ]
        )
        
        if not response['Subnets']:
            # Try exact match if pattern doesn't work
            response = ec2.describe_subnets(
                Filters=[
                    {'Name': 'tag:Name', 'Values': [subnet_name]},
                    {'Name': 'vpc-id', 'Values': [vpc_id]},
                    {'Name': 'state', 'Values': ['available']}
                ]
            )
            
        if not response['Subnets']:
            raise Exception(f"No subnets found with name pattern '{subnet_name}' in VPC {vpc_id}")
            
        subnet_ids = [subnet['SubnetId'] for subnet in response['Subnets']]
        log_info(f"Found {len(subnet_ids)} subnet(s): {', '.join(subnet_ids)}")
        return subnet_ids
        
    except NoCredentialsError:
        raise Exception("AWS credentials not configured. Please run 'aws configure'")
    except ClientError as e:
        raise Exception(f"AWS API error while fetching subnet IDs: {e}")


def get_sg_id_by_name(sg_name: str, region: str, vpc_id: str) -> str:
    """Get Security Group ID by security group name"""
    try:
        ec2 = boto3.client('ec2', region_name=region)
        response = ec2.describe_security_groups(
            Filters=[
                {'Name': 'tag:Name', 'Values': [sg_name]},
                {'Name': 'vpc-id', 'Values': [vpc_id]}
            ]
        )
        
        if not response['SecurityGroups']:
            # Try by group-name if tag search fails
            response = ec2.describe_security_groups(
                Filters=[
                    {'Name': 'group-name', 'Values': [sg_name]},
                    {'Name': 'vpc-id', 'Values': [vpc_id]}
                ]
            )
            
        if not response['SecurityGroups']:
            raise Exception(f"Security Group with name '{sg_name}' not found in VPC {vpc_id}")
            
        if len(response['SecurityGroups']) > 1:
            log_warn(f"Multiple security groups found with name '{sg_name}', using the first one")
            
        return response['SecurityGroups'][0]['GroupId']
        
    except NoCredentialsError:
        raise Exception("AWS credentials not configured. Please run 'aws configure'")
    except ClientError as e:
        raise Exception(f"AWS API error while fetching security group ID: {e}")


def load_config(config_path="config.json") -> dict:
    if not os.path.exists(config_path):
        raise Exception(f"Config file not found: {config_path}")
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def execute_bash_script(script_name: str, description: str, args: list = None) -> bool:
    """
    Generic function to execute bash scripts with proper error handling and logging
    
    Args:
        script_name: Name of the bash script file
        description: Human-readable description of what the script does
        args: Optional list of arguments to pass to the script
    
    Returns:
        bool: True if script executed successfully, False otherwise
    """
    script_path = os.path.join(
        os.path.dirname(__file__), "..", "bash", "create", script_name
    )

    if not os.path.exists(script_path):
        raise Exception(f"Bash script not found: {script_path}")

    log_info(f"🚀 {description}...")

    # Prepare command with optional arguments
    cmd = ["bash", script_path]
    if args:
        cmd.extend(args)

    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )

        # Stream output in real-time
        for line in process.stdout:
            print(line.strip())
        
        process.wait()

        if process.returncode == 0:
            log_success(f"{description} completed successfully")
            return True
        else:
            raise Exception(f"{description} failed with exit code: {process.returncode}")

    except subprocess.SubprocessError as e:
        raise Exception(f"Failed to execute {script_name}: {str(e)}")


def create_s3_bucket(project_name: str, account_id: str, region: str):
    bucket_name = f"{project_name.lower()}-{account_id}"

    execute_bash_script(
        "s3_bucket_backend.sh",
        f"Creating Terraform backend S3 bucket: {bucket_name}",
        [bucket_name, region]
    )

    return bucket_name


def create_dynamodb_state_lock_table(project_name: str, account_id: str, region: str) -> str:
    """
    Create DynamoDB table for Terraform state locking

    Args:
        project_name: Project identifier
        account_id: AWS account ID
        region: AWS region

    Returns:
        str: DynamoDB table name
    """
    table_name = f"{project_name.lower()}-{account_id}-tfstate-lock"

    try:
        dynamodb = boto3.client('dynamodb', region_name=region)

        # Check if table already exists
        try:
            dynamodb.describe_table(TableName=table_name)
            log_warn(f"DynamoDB table already exists: {table_name}")
            return table_name
        except dynamodb.exceptions.ResourceNotFoundException:
            # Table doesn't exist, create it
            log_info(f"Creating DynamoDB state lock table: {table_name}")

            dynamodb.create_table(
                TableName=table_name,
                KeySchema=[
                    {'AttributeName': 'LockID', 'KeyType': 'HASH'}
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'LockID', 'AttributeType': 'S'}
                ],
                BillingMode='PAY_PER_REQUEST',
                Tags=[
                    {'Key': 'Purpose', 'Value': 'Terraform State Locking'},
                    {'Key': 'Project', 'Value': project_name},
                    {'Key': 'ManagedBy', 'Value': 'ASAP-CLI'}
                ]
            )

            # Wait for table to be active
            log_info("Waiting for DynamoDB table to become active...")
            waiter = dynamodb.get_waiter('table_exists')
            waiter.wait(
                TableName=table_name,
                WaiterConfig={'Delay': 2, 'MaxAttempts': 30}
            )

            log_success(f"DynamoDB state lock table created: {table_name}")
            return table_name

    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'ResourceInUseException':
            log_warn(f"Table is being created or already exists: {table_name}")
            return table_name
        else:
            raise Exception(f"Failed to create DynamoDB table: {e}")
    except NoCredentialsError:
        raise Exception("AWS credentials not configured. Please run 'aws configure'")


def build_python_libraries():
    """Build both external and custom Python libraries"""
    log_info("📦 Building Python libraries...")
    
    # Build external libraries
    execute_bash_script(
        "build_external_python_libraries.sh",
        "Building external Python libraries"
    )
    
    # Build custom libraries  
    execute_bash_script(
        "build_custom_python_libraries.sh", 
        "Building custom Python libraries"
    )


import os
import json

def create_terraform_files(project_name: str, bucket_name: str, region: str, vpc_id: str, subnet_ids: list, sg_id: str):
    # ──────────────────────────────
    # Load team info from config.json
    # ──────────────────────────────
    config_path = os.path.join(os.getcwd(), "config.json")
    if not os.path.exists(config_path):
        raise FileNotFoundError("config.json not found in current directory")

    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)

    dataops_team = config.get("dataops_team", "default_team")

    # ──────────────────────────────
    # Prepare terraform directories
    # ──────────────────────────────
    tf_dir = os.path.join(os.getcwd(), "terraform")
    os.makedirs(tf_dir, exist_ok=True)

    tfbackend_path = os.path.join(tf_dir, f"{project_name}.tfbackend")
    tfvars_path = os.path.join(tf_dir, f"{project_name}.tfvars")

    # ──────────────────────────────
    # Write backend file
    # ──────────────────────────────
    dynamodb_table = f"{project_name.lower()}-{config['account_id']}-tfstate-lock"

    with open(tfbackend_path, "w", encoding="utf-8") as f:
        f.write(f"""bucket         = "{bucket_name}"
key            = "single-account/base.tfstate"
region         = "{region}"
dynamodb_table = "{dynamodb_table}"
encrypt        = true
""")

    # ──────────────────────────────
    # Format subnet list for Terraform
    # ──────────────────────────────
    subnet_list = '["' + '","'.join(subnet_ids) + '"]'

    # ──────────────────────────────
    # Write tfvars file
    # ──────────────────────────────
    
    # All the sections related to KMS is PENDING
    # TODO ADD CREATOR AND OWNER AS VARIABLE
    tfvars_content = f"""vpc_id     = "{vpc_id}"
subnet_ids = {subnet_list}
sg_ids     = ["{sg_id}"]

organization_code = "aws"
environment_code  = "dev"
platform_code     = "asap"

deletion_protection = false
creator             = "nobody@amazon.com"
owner               = "nobody@amazon.com"

aws_powertools_arn       = "arn:aws:lambda:us-east-1:017000801446:layer:AWSLambdaPowertoolsPythonV3-python311-x86_64:6"
sofbase_layer_path       = "dist/sof-base/sof-base-1.0.zip"
sof_base_lambda_runtimes = ["python3.11"]
pydantic_layer_path      = "dist/pydantic/pydantic-2.9.2.zip"
pydantic_lambda_runtimes = ["python3.11"]
lambda_runtime           = "python3.11"

glue_sofdata_library_path           = "dist/sof-data/sof-data-1.0-py3-none-any.whl"
glue_sofbase_library_path           = "dist/sof-base/sof-base-1.0-py3-none-any.whl"
glue_jmespath_library_path          = "dist/jmespath/jmespath-1.0.1-py3-none-any.whl"
glue_typing_extensions_library_path = "dist/typing_extensions/typing_extensions-4.12.2-py3-none-any.whl"
glue_powertools_library_path        = "dist/aws_lambda_powertools/aws_lambda_powertools-3.1.0-py3-none-any.whl"

enable_cmk_appmanagement              = false
sqs_kms_master_key_id                 = null
ddb_kms_key                           = null
glue_kms_key_arn                      = null
s3_kms_key_arn                        = null
kinesis_kms_key                       = ""
execution_history_pitr_period_in_days = 7

teams = {{
{dataops_team} = {{ team_code = "{dataops_team}" }}
}}
                        """

    with open(tfvars_path, "w", encoding="utf-8") as f:
        f.write(tfvars_content)

    # ──────────────────────────────
    # Logs
    # ──────────────────────────────
    log_success(f"Terraform backend file created: {tfbackend_path}")
    log_success(f"Terraform variables file created: {tfvars_path}")
    log_info(f"Using VPC: {vpc_id}")
    log_info(f"Using subnets: {', '.join(subnet_ids)}")
    log_info(f"Using security group: {sg_id}")
    log_info(f"Using team: {dataops_team}")



def setup_iac():
    log_info("🚀 Starting IaC setup...")

    try:
        config = load_config()
        account_id = config["account_id"]
        region = config["region"]
        project_name = config["project_name"]
        
        # Load resource names from config (should be set by vpc_endpoints.py)
        vpc_name = config.get("vpc_name")
        subnet_name = config.get("subnet_name") 
        sg_name = config.get("sg_name")

        if not vpc_name or not subnet_name or not sg_name:
            log_error("Resource names not found in config.json. Please run VPC endpoints setup first: 'asap start create_vpc_endpoints'")
            return False

        log_info(f"Using config → Account: {account_id}, Region: {region}, Project: {project_name}")
        log_info(f"AWS Resources → VPC: {vpc_name}, Subnet: {subnet_name}, SG: {sg_name}")

        # Create S3 bucket for backend
        log_info("📦 Creating S3 backend bucket...")
        bucket_name = create_s3_bucket(project_name, account_id, region)

        # Create DynamoDB table for state locking
        log_info("🔐 Creating DynamoDB state lock table...")
        dynamodb_table = create_dynamodb_state_lock_table(project_name, account_id, region)

        # Lookup real AWS resource IDs
        log_info("🔍 Looking up AWS resource IDs...")
        try:
            vpc_id = get_vpc_id_by_name(vpc_name, region)
            log_success(f"Found VPC: {vpc_id}")
            
            subnet_ids = get_subnet_ids_by_name(subnet_name, region, vpc_id)
            log_success(f"Found {len(subnet_ids)} subnet(s)")
            
            sg_id = get_sg_id_by_name(sg_name, region, vpc_id)
            log_success(f"Found security group: {sg_id}")
            
        except Exception as lookup_error:
            log_error("Failed to lookup AWS resources")
            log_error(f"Make sure your AWS resources exist and you have proper permissions")
            log_error(f"Details: {str(lookup_error)}")
            return False

        # Create Terraform files with real IDs
        log_info("📝 Creating Terraform configuration files...")
        create_terraform_files(project_name, bucket_name, region, vpc_id, subnet_ids, sg_id)

        # Build Python libraries
        log_info("🔧 Building Python libraries...")
        build_python_libraries()

        log_success("✅ IaC setup complete!")
        return True
        
    except Exception as e:
        log_error("Terraform setup failed")
        log_error(f"Error: {str(e)}")
        return False


if __name__ == "__main__":
    try:
        setup_iac()
    except Exception as e:
        log_error(str(e))
        exit(1)
