import typer
import json
import os
import subprocess
from typing import Optional
from datetime import datetime

# ANSI color codes (matching existing CLI style)
RESET = '\033[0m'
BOLD = '\033[1m'
GRAY = '\033[90m'
ORANGE = '\033[38;5;208m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
WHITE = '\033[97m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
RED = '\033[0;31m'


def print_vpc_endpoints_banner():
    """Print the VPC endpoints setup banner"""
    print("\n")

    # Header box
    print(f"{ORANGE}┌───────────────────────────────────────────────┐{RESET}")
    print(f"{ORANGE}│{RESET} {ORANGE}{BOLD}VPC ENDPOINTS SETUP{RESET}                           {ORANGE}│{RESET}")
    print(f"{ORANGE}│{RESET} Setting up VPC, subnets, security groups, and VPC endpoints {ORANGE}│{RESET}")
    print(f"{ORANGE}└───────────────────────────────────────────────┘{RESET}")
    print()


def load_config() -> dict:
    """Load configuration from config.json file"""
    config_path = "config.json"

    if not os.path.exists(config_path):
        raise Exception(f"Configuration file {config_path} not found. Please run project initialization first.")

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        raise Exception(f"Failed to load configuration: {str(e)}")


def update_config(new_data: dict):
    """Update config.json with new values while preserving existing keys"""
    config_path = "config.json"
    config = load_config()

    # Merge new values
    config.update(new_data)
    config["updated_at"] = datetime.utcnow().isoformat()

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
        print(f"{GREEN}[SUCCESS]{RESET} Configuration updated in {config_path}")
    except Exception as e:
        print(f"{RED}[ERROR]{RESET} Failed to update configuration: {str(e)}")


def run_vpc_endpoints_setup(region: str, account_id: str, vpc_name: str, subnet_name: str, sg_name: str) -> bool:
    """Execute the VPC endpoints setup bash script with live logging and colored prefixes"""
    script_path = os.path.join(
        os.path.dirname(__file__),
        "..", "bash", "create", "vpc_endpoints.sh"
    )

    if not os.path.exists(script_path):
        raise Exception(f"VPC endpoints setup script not found at: {script_path}")

    try:
        print(f"{CYAN}🚀 Setting up VPC and endpoints...{RESET}\n")

        process = subprocess.Popen(
            ["bash", script_path, region, account_id, vpc_name, subnet_name, sg_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,   # merge stderr into stdout
            text=True,
            bufsize=1,                  # line-buffered
            universal_newlines=True
        )

        # Stream output line by line with colored prefixes
        for line in process.stdout:
            line_stripped = line.strip()

            if not line_stripped:
                continue

            if "error" in line_stripped.lower() or "failed" in line_stripped.lower():
                print(f"{RED}[ERROR]{RESET} {line_stripped}")
            elif "warning" in line_stripped.lower() or "deprecated" in line_stripped.lower():
                print(f"{YELLOW}[WARN]{RESET} {line_stripped}")
            else:
                print(f"{CYAN}[INFO]{RESET} {line_stripped}")

        process.wait()

        return process.returncode == 0

    except subprocess.TimeoutExpired:
        raise Exception("VPC endpoints setup timed out after 5 minutes")
    except Exception as e:
        raise Exception(f"Failed to execute VPC endpoints setup: {str(e)}")


def create_vpc_endpoints() -> bool:
    """Main function to create VPC endpoints"""
    try:
        print_vpc_endpoints_banner()

        # Load configuration
        config_data = load_config()
        account_id = config_data.get("account_id")
        region = config_data.get("region")
        project_name = config_data.get("project_name", "asap-project")

        if not account_id:
            raise Exception("AWS Account ID not found in configuration")

        if not region:
            raise Exception("AWS Region not found in configuration")

        print(f"{YELLOW}📋 Configuration loaded:{RESET}")
        print(f"   Account ID: {account_id}")
        print(f"   Region: {region}")
        print(f"   Project Name: {project_name}")

        # Get resource names (with defaults based on project name)
        vpc_name = typer.prompt(f"\n{CYAN}VPC Name{RESET}", default=f"{project_name}-vpc")
        subnet_name = typer.prompt(f"{CYAN}Subnet Name{RESET}", default=f"{project_name}-subnet")
        sg_name = typer.prompt(f"{CYAN}Security Group Name{RESET}", default=f"{project_name}-sg")

        print(f"\n{YELLOW}📋 Resources to create:{RESET}")
        print(f"   VPC: {vpc_name}")
        print(f"   Subnet: {subnet_name}")
        print(f"   Security Group: {sg_name}")
        print(f"   VPC Endpoints: SSM, Glue, STS, States, S3, DynamoDB")

        # Ask for confirmation
        if not typer.confirm(f"\n{CYAN}Proceed with VPC endpoints setup?{RESET}"):
            print(f"{YELLOW}VPC endpoints setup cancelled.{RESET}")
            return False

        # Run the setup
        success = run_vpc_endpoints_setup(region, account_id, vpc_name, subnet_name, sg_name)

        if success:
            print(f"\n{GREEN}✅ VPC endpoints setup completed successfully!{RESET}")
            print(f"{CYAN}Your AWS infrastructure is ready.{RESET}")

            # Save resources in config.json
            update_config({
                "vpc_name": vpc_name,
                "subnet_name": subnet_name,
                "sg_name": sg_name
            })

        else:
            print(f"\n{RED}❌ VPC endpoints setup failed!{RESET}")
            print(f"{YELLOW}Please check the errors above and try again.{RESET}")

        return success

    except Exception as e:
        print(f"\n{RED}❌ Error during VPC endpoints setup: {str(e)}{RESET}")
        return False
