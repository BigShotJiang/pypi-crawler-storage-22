import typer


# Colors for pretty logs
RESET = '\033[0m'
BOLD = '\033[1m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
YELLOW = '\033[93m'
RED = '\033[0;31m'

def log_info(msg): print(f"{CYAN}[INFO]{RESET} {msg}")
def log_success(msg): print(f"{GREEN}[SUCCESS]{RESET} {msg}")
def log_warn(msg): print(f"{YELLOW}[WARN]{RESET} {msg}")
def log_error(msg): print(f"{RED}[ERROR]{RESET} {msg}")

text = """
🚀 ASAP operations commands

COMMANDS: 

[pipeline_registry] Registry pipeline
[run_pipeline] Execute pipeline
[register_ddl] Register table in the datalake
"""

def register(app: typer.Typer): 
    """Register start commands with the main app"""
    operation_app = typer.Typer(help=text)
    app.add_typer(operation_app, name="operation") 

    @operation_app.command("pipeline_registry")
    def pipeline_registry_command():
        """
        🔎 Registry a pipeline in the ASAP framework
        """
        from asap.operation.pipelines.utils.pipeline_registry import PipelineRegistry
        from asap.operation.pipelines.utils.put_dynamo_item import PipelineRegistrySetup
        
        registry = PipelineRegistry()
        dynamo_pipeline_registry = PipelineRegistrySetup()

        registry.run()
        dynamo_pipeline_registry.run(registry.workflow_name)
        
    @operation_app.command("run_pipeline")
    def run_pipeline_command():
        """
        🏎 Execute pipeline
        """
        from asap.operation.pipelines.utils.execute_workflow import WorkflowRunner
        
        
        runner = WorkflowRunner()
        
        
        # Beautiful styled input
        answer = input(f"{BOLD}{CYAN}Enter the pipeline name:{RESET} ")
        print(f"{GREEN}✓{RESET} You entered: {BOLD}{answer}{RESET}")

        execution_level = input(f"{BOLD}{CYAN}Enter the execution level (1,2..):{RESET} ")
        
        runner.run(answer, execution_level=execution_level)

    @operation_app.command("register_ddl")
    def register_ddl_command():
        """
        📘 Register table in the datalake with DDL
        """
        from asap.operation.pipelines.utils.DDLRegister import AthenaDDLExecutor

        pipeline_name = input(f"{BOLD}{CYAN}Enter the pipeline name:{RESET} ")
        print(f"{GREEN}✓{RESET} You entered: {BOLD}{pipeline_name}{RESET}")
        file_name = input(f"{BOLD}{CYAN}Enter the file name:{RESET} ")
        print(f"{GREEN}✓{RESET} You entered: {BOLD}{file_name}{RESET}")
        target_database = input(f"{BOLD}{CYAN}Enter the target database name:{RESET} ")
        print(f"{GREEN}✓{RESET} You entered: {BOLD}{target_database}{RESET}")

        executor_ddl = AthenaDDLExecutor(pipeline_name, file_name, target_database)

        executor_ddl.run()


        
         

        