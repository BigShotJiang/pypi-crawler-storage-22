import boto3
import time
import json
from pathlib import Path
from typing import Optional
import sys



class Colors:
    """ANSI color codes for terminal output"""
    GREEN = '\033[0;32m'
    RED = '\033[0;31m'
    YELLOW = '\033[1;33m'
    CYAN = '\033[0;36m'
    NC = '\033[0m'

class AthenaDDLExecutor:
    def __init__(self, pipeline_name, file_name, database):
        """
        Initialize Athena DDL executor
        
        Args:
            pipeline_name: Name of the pipeline we want to create the table.
            file_name: Name of the file containing the DDL, include .sql.
        """
        self.project_root = Path.cwd()
        config_file = self.project_root / "config.json"
        region = self._load_config(config_file)
        self.client = boto3.client('athena', region_name=region)
        self.database = database
        self.ddl_file_path = self.project_root / "pipelines" / pipeline_name / "DDL" / file_name
        self.ssm_client =  boto3.client('ssm')
        
    def _get_ssm_parameter(self, parameter_name: str) -> Optional[str]:
        """
        Retrieve SSM parameter value using boto3
        
        Args:
            parameter_name: SSM parameter path
            
        Returns:
            Parameter value or None if failed
        """
        try:
            response = self.ssm_client.get_parameter(Name=parameter_name)
            return response['Parameter']['Value']
        except Exception as e:
            print(f"{Colors.RED}Failed to retrieve SSM parameter: {parameter_name}{Colors.NC}", file=sys.stderr)
            print(f"{Colors.RED}Error: {str(e)}{Colors.NC}", file=sys.stderr)
            return None
    
    def execute_ddl_file(self, ddl_file_path):
        """
        Read and execute DDL from a file
        
        Args:
            ddl_file_path: Path to DDL file
            
        Returns:
            Query execution ID
        """
        with open(ddl_file_path, 'r') as f:
            ddl_statement = f.read()
        
        return self.execute_ddl(ddl_statement)

    def execute_ddl(self, ddl_statement):
        """
        Execute DDL statement in Athena
        
        Args:
            ddl_statement: DDL SQL statement
            
        Returns:
            Query execution ID
        """
        print(f"Executing DDL:\n{ddl_statement[:200]}...")
        
        output_bucket_name = self._get_ssm_parameter("/asap/Foundation/S3/AthenaResultsBucket/Name")

        output_location = f"s3://{output_bucket_name}/"

        response = self.client.start_query_execution(
            QueryString=ddl_statement,
            QueryExecutionContext={'Database': self.database},
            ResultConfiguration={'OutputLocation': output_location}
        )
        
        query_execution_id = response['QueryExecutionId']
        print(f"Query execution ID: {query_execution_id}")
        
        return query_execution_id
    
    @staticmethod
    def _load_config(config_file: str):
        """Load region from config.json"""
        
        
        if not config_file.exists():
            print(f"{Colors.RED}Error: config.json not found in current directory{Colors.NC}")
            return False
        
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            
            region = config.get('region')
            if not region:
                print(f"{Colors.RED}Error: region not found or empty in config.json{Colors.NC}")
                
                
            
            return region
            
        except json.JSONDecodeError as e:
            print(f"{Colors.RED}Error: Failed to parse config.json - {e}{Colors.NC}")
            return 
    
    
    def wait_for_query(self, query_execution_id, max_wait_seconds=300):
        """
        Wait for query to complete
        
        Args:
            query_execution_id: Query execution ID
            max_wait_seconds: Maximum time to wait
            
        Returns:
            Final query state
        """
        elapsed = 0
        while elapsed < max_wait_seconds:
            response = self.client.get_query_execution(
                QueryExecutionId=query_execution_id
            )
            
            state = response['QueryExecution']['Status']['State']
            
            if state in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
                if state == 'SUCCEEDED':
                    print("✓ Query succeeded!")
                else:
                    reason = response['QueryExecution']['Status'].get('StateChangeReason', 'Unknown')
                    print(f"✗ Query {state.lower()}: {reason}")
                return state
            
            print(f"Query state: {state}... waiting")
            time.sleep(2)
            elapsed += 2
        
        raise TimeoutError(f"Query did not complete within {max_wait_seconds} seconds")
    
    def run(self):
        # Execute DDL from file
        try:
            query_id = self.execute_ddl_file(self.ddl_file_path)
            final_state = self.wait_for_query(query_id)
            
            if final_state == 'SUCCEEDED':
                print(f"Iceberg table {self.ddl_file_path} created successfully!")
            else:
                print(f"Failed to create table: {self.ddl_file_path}")
                
        except Exception as e:
            print(f"Error: {str(e)}")


# Example usage
if __name__ == "__main__":
    # Configuration
    DATABASE = 'my_database'
    OUTPUT_LOCATION = 's3://my-bucket/athena-results/'
    DDL_FILE = 'create_iceberg_table.sql'
    REGION = 'us-east-1'
    
    # Initialize executor
    executor = AthenaDDLExecutor(
        database=DATABASE,
        output_location=OUTPUT_LOCATION,
        region=REGION
    )
    
    # Execute DDL from file
    try:
        query_id = executor.execute_ddl_file(DDL_FILE)
        final_state = executor.wait_for_query(query_id)
        
        if final_state == 'SUCCEEDED':
            print("Iceberg table created successfully!")
        else:
            print("Failed to create table")
            
    except Exception as e:
        print(f"Error: {str(e)}")