import json
import boto3
from datetime import datetime
from pathlib import Path
from typing import Optional
import sys


class Colors:
    """ANSI color codes for terminal output"""
    GREEN = '\033[0;32m'
    RED = '\033[0;31m'
    YELLOW = '\033[1;33m'
    CYAN = '\033[0;36m'
    NC = '\033[0m'


class WorkflowRunner:
    """Simple class to execute Step Functions workflows"""
    
    def __init__(self):
        """Initialize AWS clients"""
        self.ssm_client = boto3.client('ssm')
        self.sfn_client = boto3.client('stepfunctions')
        
        self.project_root = Path.cwd()
        self.team_name: Optional[str] = None
        self.account_id: Optional[str] = None
        self.region: Optional[str] = None
    
    def _get_ssm_parameter(self, parameter_name: str) -> Optional[str]:
        """
        Retrieve SSM parameter value using boto3
        
        Args:
            parameter_name: SSM parameter path
            
        Returns:
            Parameter value or None if failed
        """
        try:
            response = self.ssm_client.get_parameter(Name=parameter_name)
            return response['Parameter']['Value']
        except Exception as e:
            print(f"{Colors.RED}Failed to retrieve SSM parameter: {parameter_name}{Colors.NC}", file=sys.stderr)
            print(f"{Colors.RED}Error: {str(e)}{Colors.NC}", file=sys.stderr)
            return None
    
    def _load_config(self) -> bool:
        """Load team_name from config.json"""
        config_file = self.project_root / 'config.json'
        
        if not config_file.exists():
            print(f"{Colors.RED}Error: config.json not found in current directory{Colors.NC}")
            return False
        
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            
            self.team_name = config.get('dataeng_team')
            if not self.team_name:
                print(f"{Colors.RED}Error: dataops_team not found or empty in config.json{Colors.NC}")
                return False
            
            return True
            
        except json.JSONDecodeError as e:
            print(f"{Colors.RED}Error: Failed to parse config.json - {e}{Colors.NC}")
            return False
    
    def _retrieve_ssm_parameters(self) -> bool:
        """Retrieve required SSM parameters"""
        print(f"{Colors.CYAN}### SSM Parameters read ###{Colors.NC}")
        
        self.account_id = self._get_ssm_parameter('/SOF/Globals/AccountId')
        self.region = self._get_ssm_parameter('/SOF/Globals/Region')
        
        if not self.account_id or not self.region:
            return False
        
        print(f"ACCOUNT_ID: {self.account_id}")
        print(f"REGION: {self.region}")
        return True
    
    def run(self, workflow_name: str, 
            start_date: Optional[str] = None, 
            end_date: Optional[str] = None,
            execution_level: Optional[int] = 1,
            interactive: bool = True) -> bool:
        """
        Execute a Step Functions workflow
        
        Args:
            workflow_name: Name of the workflow to execute
            start_date: Start date in YYYY-MM-DD format (defaults to today)
            end_date: End date in YYYY-MM-DD format (defaults to today)
            interactive: Whether to prompt for confirmation (default: True)
            
        Returns:
            True if execution started successfully, False otherwise
            
        Example:
            runner = WorkflowRunner()
            runner.run('test-glue-workflow')
        """
        # Load config to get team_name
        if not self._load_config():
            return False
        
        # Get SSM parameters
        if not self._retrieve_ssm_parameters():
            return False
        
        # Set dates
        if not start_date:
            start_date = datetime.utcnow().strftime('%Y-%m-%d')
        if not end_date:
            end_date = datetime.utcnow().strftime('%Y-%m-%d')
        
        # Display actions
        print(f"\n{Colors.CYAN}### Actions to perform ###{Colors.NC}")
        print(f"* Execute step functions {workflow_name}")
        
        # Confirmation prompt
        if interactive:
            answer = input("\nDo you want to continue? (yes to continue): ")
            if answer.lower() != 'yes':
                print("Exiting...")
                return False
        
        # Calculate execution ID
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        execution_id = f"{self.team_name}.{workflow_name}-{timestamp}"
        
        # Prepare input parameters
        input_parameters = {
            "rules_path": "rules",
            "start_date": start_date,
            "end_date": end_date,
            "additional_properties": None,
            "main_execution_id": execution_id,
            "execution_level": execution_level
        }
        
        # Build state machine ARN
        state_machine_arn = f"arn:aws:states:{self.region}:{self.account_id}:stateMachine:{workflow_name}"
        
        # Invoke Step Function
        try:
            response = self.sfn_client.start_execution(
                stateMachineArn=state_machine_arn,
                input=json.dumps(input_parameters),
                name=execution_id
            )
            
            print(f"{Colors.GREEN}Step Function {workflow_name} invoked successfully.{Colors.NC}")
            print(f"{Colors.GREEN}Response: {json.dumps(response, default=str, indent=2)}{Colors.NC}")
            print(f"\nStep Functions execution started for workflow: {workflow_name} with execution ID: {execution_id}")
            return True
            
        except Exception as e:
            print(f"{Colors.RED}Failed to invoke Step Function {workflow_name}.{Colors.NC}")
            print(f"{Colors.RED}Error: {str(e)}{Colors.NC}")
            return False


# Example usage
if __name__ == '__main__':
    # Simple usage example
    runner = WorkflowRunner()
    
    # Execute with just workflow name
    runner.run('test-glue-workflow')
    
    # Or with all parameters
    # runner.run(
    #     workflow_name='my-workflow',
    #     start_date='2025-01-01',
    #     end_date='2025-01-31',
    #     interactive=False
    # )