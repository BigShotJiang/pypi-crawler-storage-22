import os
import json
import subprocess
import boto3
from pathlib import Path
from botocore.exceptions import ClientError, NoCredentialsError

# Colors for pretty logs
RESET = '\033[0m'
BOLD = '\033[1m'
CYAN = '\033[96m'
GREEN = '\033[0;32m'
YELLOW = '\033[93m'
RED = '\033[0;31m'

def log_info(msg): print(f"{CYAN}[INFO]{RESET} {msg}")
def log_success(msg): print(f"{GREEN}[SUCCESS]{RESET} {msg}")
def log_warn(msg): print(f"{YELLOW}[WARN]{RESET} {msg}")
def log_error(msg): print(f"{RED}[ERROR]{RESET} {msg}")


class PipelineRegistryError(Exception):
    """Custom exception for pipeline registry operations"""
    pass


class PipelineRegistry:
    """
    Pipeline registry class for managing workflow pipeline generation.
    Handles workflow validation, account access checking, and sample generation.
    """
    
    def __init__(self, base_path=None, project_root=None):
        """
        Initialize the pipeline registry with base path
        
        Args:
            base_path: Base path for the CLI tool (where scripts are located)
            project_root: Root path of the project created by this CLI (where pipelines are)
        """
        if base_path is None:
            # Get the directory where this script is located
            script_dir = Path(__file__).parent.parent
            self.base_path = script_dir
        else:
            self.base_path = Path(base_path)
        
        # Set project root - this is where the CLI created the project
        if project_root is None:
            # Default to current working directory (where user runs the CLI)
            self.project_root = Path.cwd()
        else:
            self.project_root = Path(project_root)
        
        self.bash_script_path = self.base_path / "bash" / "generate_sample.sh"


        
        
    
    def get_workflow_name(self):
        """
        Interactively ask the user for workflow name.
        Returns the workflow name entered by the user.
        """
        log_info("Pipeline Registry - Workflow Setup")
        print("-" * 40)
        
        self.workflow_name = input("Enter workflow name: ").strip()
        
        if not self.workflow_name:
            raise PipelineRegistryError("Workflow name cannot be empty")
        
        log_info(f"Workflow name entered: {self.workflow_name}")
        return self.workflow_name
    
    def validate_workflow_directory(self, workflow_name):
        """
        Check if the workflow directory exists in {project_root}/pipeline/{workflow_name}.
        Raises PipelineRegistryError if directory doesn't exist.
        """
        # Build path relative to project root, not CLI root
        workflow_dir = self.project_root / "pipelines" / workflow_name

        log_info(f"Checking if workflow directory exists: {workflow_dir}")
        log_info(f"Absolute path: {workflow_dir.absolute()}")
        
        if not workflow_dir.exists():
            raise PipelineRegistryError(
                f"Workflow directory does not exist: {workflow_dir}\n"
                f"Please create the directory structure: {self.project_root}/pipelines/{workflow_name}/"
            )
        
        if not workflow_dir.is_dir():
            raise PipelineRegistryError(
                f"Path exists but is not a directory: {workflow_dir}"
            )
        
        log_success(f"Workflow directory found: {workflow_dir}")
        return workflow_dir
    
    def get_account_id_from_config(self):
        """
        Read config.json from workflow directory and extract account_id.
        Returns the account_id from the configuration file.
        """
        config_file = self.project_root / "config.json" 
        
        log_info(f"Reading configuration from: {config_file}")
        
        if not config_file.exists():
            raise PipelineRegistryError(
                f"config.json not found in workflow directory: {config_file}"
            )
        
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            
            if 'account_id' not in config:
                raise PipelineRegistryError(
                    "account_id not found in config.json. "
                    "Please ensure config.json contains 'account_id' field."
                )
            
            account_id = config['account_id']
            log_success(f"Account ID found in config: {account_id}")
            return account_id
            
        except json.JSONDecodeError as e:
            raise PipelineRegistryError(f"Invalid JSON in config.json: {e}")
        except Exception as e:
            raise PipelineRegistryError(f"Error reading config.json: {e}")
    
    def check_user_account_access(self, expected_account_id):
        """
        Check if the user has access to the specified AWS account.
        Verifies current AWS credentials match the expected account ID.
        """
        log_info("Checking AWS account access...")
        
        try:
            sts_client = boto3.client('sts')
            identity = sts_client.get_caller_identity()
            current_account_id = identity['Account']
            
            log_info(f"Current AWS account: {current_account_id}")
            log_info(f"Expected account: {expected_account_id}")
            
            if current_account_id != expected_account_id:
                raise PipelineRegistryError(
                    f"Account mismatch!\n"
                    f"Current AWS account: {current_account_id}\n"
                    f"Expected account: {expected_account_id}\n"
                    f"Please configure AWS CLI with credentials for account {expected_account_id}"
                )
            
            log_success(f"Account access verified for: {current_account_id}")
            return True
            
        except NoCredentialsError:
            raise PipelineRegistryError(
                "AWS credentials not configured. Please run 'aws configure'"
            )
        except ClientError as e:
            raise PipelineRegistryError(f"AWS API error while checking account access: {e}")
        except Exception as e:
            raise PipelineRegistryError(f"Error checking account access: {e}")
        
    @staticmethod
    def __execute_bash_script(script_name: str, description: str, args: list = None) -> bool:
        """
        Generic function to execute bash scripts with proper error handling and logging
        
        Args:
            script_name: Name of the bash script file
            description: Human-readable description of what the script does
            args: Optional list of arguments to pass to the script
        
        Returns:
            bool: True if script executed successfully, False otherwise
        """
        script_path = os.path.join(
            os.path.dirname(__file__), "..", "bash", script_name
        )

        if not os.path.exists(script_path):
            raise Exception(f"Bash script not found: {script_path}")

        log_info(f"🚀 {description}...")

        # Prepare command with optional arguments
        cmd = ["bash", script_path]
        if args:
            cmd.extend(args)

        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )

            # Stream output in real-time
            for line in process.stdout:
                print(line.strip())
            
            process.wait()

            if process.returncode == 0:
                log_success(f"{description} completed successfully")
                return True
            else:
                raise Exception(f"{description} failed with exit code: {process.returncode}")

        except subprocess.SubprocessError as e:
            raise Exception(f"Failed to execute {script_name}: {str(e)}")

        
    def generate_sample(self, workflow_name):
        """
        Call the bash script generate_sample.sh with the workflow name parameter.
        Executes the sample generation process.
        """
        log_info("Starting sample generation...")

        return self.__execute_bash_script(
        script_name="generate_sample.sh",
        description="Sample generation",
        args=["--workflow_name", workflow_name]
            )
        
        
       

    def run(self):
        """
        Main orchestration method that runs the complete pipeline process.
        Coordinates all validation and generation steps.
        """
        try:
            # Step 1: Get workflow name from user
            workflow_name = self.get_workflow_name()
            
            # Step 2: Validate workflow directory exists
            workflow_dir = self.validate_workflow_directory(workflow_name)
            
            # Step 3: Read account_id from config.json
            account_id = self.get_account_id_from_config()
            
            # Step 4: Check user has access to the account
            self.check_user_account_access(account_id)
            
            # Step 5: Generate sample
            self.generate_sample(workflow_name)
            
            log_success("Pipeline registry process completed successfully!")
            
        except PipelineRegistryError as e:
            log_error(f"Pipeline Registry Error: {e}")
            raise
        except KeyboardInterrupt:
            log_warn("Process interrupted by user")
            raise
        except Exception as e:
            log_error(f"Unexpected error: {e}")
            raise PipelineRegistryError(f"Unexpected error: {e}")


if __name__ == "__main__":
    # Option 1: Use current working directory (default)
    registry = PipelineRegistry()
    registry.run()
    
    # Option 2: Specify project root explicitly
    # registry = PipelineRegistry(project_root="/path/to/created/project")
    # registry.run()