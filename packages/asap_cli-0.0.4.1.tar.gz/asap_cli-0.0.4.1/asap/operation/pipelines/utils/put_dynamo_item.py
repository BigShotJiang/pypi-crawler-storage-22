import json
import boto3
from pathlib import Path
from typing import Optional
import sys


class Colors:
    """ANSI color codes for terminal output"""
    GREEN = '\033[0;32m'
    RED = '\033[0;31m'
    YELLOW = '\033[1;33m'
    CYAN = '\033[0;36m'
    NC = '\033[0m'


class PipelineRegistrySetup:
    """Class to setup and register pipelines in DynamoDB"""
    
    def __init__(self):
        """Initialize AWS clients"""
        self.ssm_client = boto3.client('ssm')
        self.dynamodb_client = boto3.client('dynamodb')
        
        # self.workflow_name = workflow_name
        #self.script_dir = Path(__file__).parent.resolve()
        self.project_root = Path.cwd()
        
        
        self.app_name: Optional[str] = None
        self.team_name: Optional[str] = None
        self.environment: Optional[str] = None
        self.organization: Optional[str] = "aws"
        #self.workflow_name: Optional[str] = None
        self.account_id: Optional[str] = None
        self.region: Optional[str] = None
        self.dynamodb_table_name: Optional[str] = None
    
    def _get_ssm_parameter(self, parameter_name: str) -> Optional[str]:
        """
        Retrieve SSM parameter value using boto3
        
        Args:
            parameter_name: SSM parameter path
            
        Returns:
            Parameter value or None if failed
        """
        try:
            response = self.ssm_client.get_parameter(Name=parameter_name)
            return response['Parameter']['Value']
        except Exception as e:
            print(f"{Colors.RED}Failed to retrieve SSM parameter: {parameter_name}{Colors.NC}", file=sys.stderr)
            print(f"{Colors.RED}Error: {str(e)}{Colors.NC}", file=sys.stderr)
            return None
        
    
    def _load_config(self) -> bool:
        """Load team_name from config.json"""
        config_file = self.project_root / 'config.json'
        
        if not config_file.exists():
            print(f"{Colors.RED}Error: config.json not found in current directory{Colors.NC}")
            return False
        
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            
            self.team_name = config.get('dataeng_team')
            if not self.team_name:
                print(f"{Colors.RED}Error: dataops_team not found or empty in config.json{Colors.NC}")
                return False
            
            # self.organization = config.get("organization")
            # if not self.organization:
            #     print(f"{Colors.RED}Error: organization not found or empty in config.json{Colors.NC}")
            #     return False
            
            
            return True
            
        except json.JSONDecodeError as e:
            print(f"{Colors.RED}Error: Failed to parse config.json - {e}{Colors.NC}")
            return False
    
    def _retrieve_ssm_parameters(self) -> bool:
        """Retrieve all required SSM parameters"""
        print(f"{Colors.CYAN}### Retrieving SSM Parameters ###{Colors.NC}")
        
        self._load_config()

        # Get global parameters
        self.account_id = self._get_ssm_parameter('/SOF/Globals/AccountId')
        self.region = self._get_ssm_parameter('/SOF/Globals/Region')
        
        # Get application-specific parameters
        self.app_name = self._get_ssm_parameter('/SOF/Globals/App/Name')


        
        self.environment = self._get_ssm_parameter('/SOF/Globals/Environment')
        #self.organization = self._get_ssm_parameter('/SOF/Organization')
        
        
        # Check if all required parameters were retrieved
        if not all([
            self.account_id,
            self.region,
            self.app_name,
            self.team_name,
            self.environment,
            self.organization
        ]):
            print(f"{Colors.RED}Failed to retrieve all required SSM parameters{Colors.NC}")
            return False
        
        # Get DynamoDB table name
        dynamodb_param = f'/{self.app_name}/{self.organization}/{self.environment}/fcnf/DDB/PipelineRegistry/TableName'
        self.dynamodb_table_name = self._get_ssm_parameter(dynamodb_param)
        
        if not self.dynamodb_table_name:
            print(f"{Colors.RED}Failed to retrieve DynamoDB table name{Colors.NC}")
            return False
        
        # Print retrieved parameters
        print(f"\n{Colors.CYAN}### SSM Parameters read ###{Colors.NC}")
        print(f"ACCOUNT_ID: {self.account_id}")
        print(f"REGION: {self.region}")
        print(f"APP_NAME: {self.app_name}")
        print(f"TEAM_NAME: {self.team_name}")
        print(f"ENVIRONMENT: {self.environment}")
        print(f"ORGANIZATION: {self.organization}")
        print(f"DYNAMODB_PIPELINE_REGISTRY_TABLE_NAME: {self.dynamodb_table_name}")
        
        return True
    
    def _insert_into_dynamodb(self, json_file: Path) -> bool:
        """
        Insert item into DynamoDB table
        
        Args:
            json_file: Path to JSON file containing the item
            
        Returns:
            True if successful, False otherwise
        """
        # Check if the JSON file exists
        if not json_file.exists():
            print(f"{Colors.RED}JSON file does not exist: {json_file}{Colors.NC}")
            return False
        
        # Read the JSON file
        try:
            with open(json_file, 'r') as f:
                item = json.load(f)
        except Exception as e:
            print(f"{Colors.RED}Error reading JSON file: {e}{Colors.NC}")
            return False
        
        # Insert the record into DynamoDB
        try:
            self.dynamodb_client.put_item(
                TableName=self.dynamodb_table_name,
                Item=item
            )
            print(f"{Colors.GREEN}Record inserted successfully.{Colors.NC}")
            return True
        except Exception as e:
            print(f"{Colors.RED}Failed to insert record.{Colors.NC}")
            print(f"{Colors.RED}Error: {str(e)}{Colors.NC}")
            return False
    
    def run(self, workflow_name: str, interactive: bool = True) -> bool:
        """
        Execute the pipeline registry setup
        
        Args:
            interactive: Whether to prompt for confirmation (default: True)
            
        Returns:
            True if setup completed successfully, False otherwise
            
        Example:
            setup = PipelineRegistrySetup()
            setup.run()
        """
        # Get all SSM parameters
        if not self._retrieve_ssm_parameters():
            return False
        
        # Display actions
        print(f"\n{Colors.CYAN}### Actions to perform ###{Colors.NC}")
        print(f"* Insert pipeline record {workflow_name} into {self.dynamodb_table_name}")
        
        # Confirmation prompt
        if interactive:
            answer = input("\nDo you want to continue? (yes to continue): ")
            if answer.lower() != 'yes':
                print("Exiting...")
                return False
        
        # Insert into DynamoDB
        json_file = self.project_root / "pipelines" / workflow_name / "registry" / f'{workflow_name}-pipeline-registry.json'
        success = self._insert_into_dynamodb(json_file)
        
        return success


# Example usage
if __name__ == '__main__':
    # Simple usage example
    setup = PipelineRegistrySetup()
    
    # Execute the setup
    success = setup.run()
    
    if not success:
        sys.exit(1)