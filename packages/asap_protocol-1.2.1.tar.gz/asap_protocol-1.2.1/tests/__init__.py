"""ASAP protocol test suite."""
