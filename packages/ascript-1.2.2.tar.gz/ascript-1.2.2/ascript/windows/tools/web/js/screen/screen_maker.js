


function add_point_maker(){

}

function add_rect_maker(){
    
}