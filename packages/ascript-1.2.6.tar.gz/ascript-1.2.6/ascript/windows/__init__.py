import os
import sys

# 获取当前 windows 目录的路径
_current_dir = os.path.dirname(os.path.abspath(__file__))

# 关键：将 windows 目录加入搜索路径
# 这样其下的子模块 license 就能直接 import 旁边的 pyarmor_runtime_000000
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)


from ascript.windows.screen.ocr import rapidocr_hook
import rapidocr

# 检查 rapidocr 模块是否已经有了 find 属性
# 如果没有，说明还没挂钩（hook），则执行注入
if not hasattr(rapidocr, 'find'):
    rapidocr_hook.install()
    # print("RapidOCR Hook 注入成功")
else:
    # print("RapidOCR 已经注入过，跳过本次操作")
    pass