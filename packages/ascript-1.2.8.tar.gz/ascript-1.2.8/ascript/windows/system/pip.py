import subprocess
import sys
import re
import time
import urllib.request
from importlib.metadata import version, PackageNotFoundError


class Pip:
    """
    Python 包管理工具类，具备自动择源功能。
    """
    # 备选镜像源列表
    MIRRORS = {
        "tsinghua": "https://pypi.tuna.tsinghua.edu.cn/simple",
        "aliyun": "https://mirrors.aliyun.com/pypi/simple/",
        "pypi": "https://pypi.org/simple"
    }

    @staticmethod
    def _get_best_index() -> str:
        """
        测试各个镜像源的响应时间，返回最快的源。
        """
        best_url = Pip.MIRRORS["tsinghua"]  # 默认兜底
        min_time = float('inf')

        for name, url in Pip.MIRRORS.items():
            try:
                # 仅请求头部，测试连接延迟，超时设为 1 秒
                start = time.time()
                with urllib.request.urlopen(url, timeout=1.0) as response:
                    if response.getcode() == 200:
                        duration = time.time() - start
                        if duration < min_time:
                            min_time = duration
                            best_url = url
            except Exception:
                continue
        return best_url

    @staticmethod
    def is_installed(package_spec: str) -> bool:
        package_name = re.split(r'[<>=!]', package_spec)[0].strip()
        try:
            version(package_name)
            return True
        except PackageNotFoundError:
            return False

    @staticmethod
    def install(package_spec: str, upgrade: bool = False, index_url: str = None) -> bool:
        """
        安装包。如果 index_url 为 None，则自动寻找最快源。
        """
        # 自动择源逻辑
        target_index = index_url if index_url else Pip._get_best_index()

        command = [sys.executable, "-m", "pip", "install", package_spec]

        if target_index:
            command.extend(["-i", target_index])
            if target_index.startswith("http://"):
                host = target_index.split("/")[2].split(":")[0]
                command.extend(["--trusted-host", host])

        if upgrade:
            command.append("--upgrade")

        try:
            subprocess.check_call(command)
            return True
        except subprocess.CalledProcessError:
            return False

    @staticmethod
    def ensure(package_spec: str, index_url: str = None) -> bool:
        if Pip.is_installed(package_spec):
            return True
        return Pip.install(package_spec, index_url=index_url)

    @staticmethod
    def remove(package_name: str) -> bool:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "uninstall", package_name, "-y"])
            return True
        except subprocess.CalledProcessError:
            return False