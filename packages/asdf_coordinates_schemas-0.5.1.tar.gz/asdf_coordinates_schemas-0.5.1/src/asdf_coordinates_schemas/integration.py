import importlib.resources as importlib_resources
from pathlib import Path

from asdf.resource import DirectoryResourceMapping

import asdf_coordinates_schemas


def get_resource_mappings():
    resources_root = importlib_resources.files(asdf_coordinates_schemas) / "resources"
    if not resources_root.is_dir():
        # In an editable install, the resources directory will exist off the
        # repository root:
        resources_root = Path(__file__).absolute().parent.parent.parent / "resources"
        if not resources_root.is_dir():
            raise RuntimeError("Missing resources directory")

    return [
        DirectoryResourceMapping(
            resources_root / "schemas",
            "http://astropy.org/schemas/astropy/coordinates/",
            recursive=True,
        ),
        DirectoryResourceMapping(
            resources_root / "manifests",
            "asdf://asdf-format.org/astronomy/coordinates/manifests/",
        ),
    ]
