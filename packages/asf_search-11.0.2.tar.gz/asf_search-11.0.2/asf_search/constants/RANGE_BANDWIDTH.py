# Nisar Sensor Bandwidths
## L-SAR
BW_20 = "20"
BW_40 = "40"
BW_20_5 = "20+5"
BW_40_5 = "40+5"
BW_77 = "77"
BW_5 = "5"
BW_5_5 = "5+5"

## S-SAR
BW_10 = "10"
BW_25 = "25"
BW_37 = "37"
BW_75 = "75"
