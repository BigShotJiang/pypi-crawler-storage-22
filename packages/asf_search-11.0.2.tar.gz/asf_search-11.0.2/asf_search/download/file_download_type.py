from enum import Enum


class FileDownloadType(Enum):
    DEFAULT_FILE = 1
    ADDITIONAL_FILES = 2
    ALL_FILES = 3
