<h1 align="center">
    <strong>asgi-types</strong>
</h1>
<p align="center">
    <a href="https://github.com/Kludex/asgi-types" target="_blank">
        <img src="https://img.shields.io/github/last-commit/Kludex/asgi-types" alt="Latest Commit">
    </a>
        <img src="https://img.shields.io/github/workflow/status/Kludex/asgi-types/Test">
        <img src="https://img.shields.io/codecov/c/github/Kludex/asgi-types">
    <br />
    <a href="https://pypi.org/project/asgi-types" target="_blank">
        <img src="https://img.shields.io/pypi/v/asgi-types" alt="Package version">
    </a>
    <img src="https://img.shields.io/pypi/pyversions/asgi-types">
    <img src="https://img.shields.io/github/license/Kludex/asgi-types">
</p>

## Installation

```bash
pip install asgi-types
```

## License

This project is licensed under the terms of the MIT license.
