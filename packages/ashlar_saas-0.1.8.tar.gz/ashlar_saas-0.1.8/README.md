# Ashlar-SaaS

A SaaS structure for Django

# Usage
Add the user model to your settings:
```python
AUTH_USER_MODEL = 'account.User'
```

Add this to your MIDDLEWARE, after `django.contrib.auth.middleware.AuthenticationMiddleware`:
```python
[
    'account.middleware.TenantMiddleware',
]
```
