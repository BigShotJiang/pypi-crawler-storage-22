from django.apps import AppConfig

class AccountConfig(AppConfig):
    name = 'account'

    def ready(self):
        # pylint: disable=import-outside-toplevel
        from account import signals
        _ = signals
