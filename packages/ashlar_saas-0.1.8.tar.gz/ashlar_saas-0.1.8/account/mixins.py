from django.contrib.auth.mixins import UserPassesTestMixin
from django.core.exceptions import PermissionDenied


class TenantOwnerRequiredMixin(UserPassesTestMixin):
    """
    Mixin die controleert of de gebruiker de 'owner' rol heeft
    binnen de op dat moment actieve organisatie (request.org).
    """

    def test_func(self):
        active_org = getattr(self.request, 'organization', None)
        if not active_org:
            return False

        return self.request.user.is_authenticated and self.request.user.is_owner_of(active_org)

    def handle_no_permission(self):
        if not self.request.user.is_authenticated:
            return super().handle_no_permission()

        raise PermissionDenied("Je hebt geen eigenaarsrechten voor deze organisatie.")
