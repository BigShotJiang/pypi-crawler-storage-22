from django import template

register = template.Library()


@register.filter
def is_owner(user, organization):
    """
    Checkt of een gebruiker de 'owner' rol heeft voor een specifieke organisatie.
    Gebruik: {% if user|is_owner:request.org %}
    """
    if not user or user.is_anonymous or not organization:
        return False

    # Dit roept de methode aan die in je User model staat (uit je diff)
    if hasattr(user, 'is_owner_of'):
        return user.is_owner_of(organization)
    return False

@register.filter
def is_admin(user, organization):
    """
    Checkt of een gebruiker de 'owner' rol heeft voor een specifieke organisatie.
    Gebruik: {% if user|is_owner:request.org %}
    """
    if not user or user.is_anonymous or not organization:
        return False

    # Dit roept de methode aan die in je User model staat (uit je diff)
    if hasattr(user, 'is_owner_of'):
        return user.is_owner_of(organization)
    if hasattr(user, 'is_admin_of'):
        return user.is_admin_of(organization)
    return False
