from django.urls import path
from django.contrib.auth import views as auth_views
from .views import CustomLoginView, RegisterView, UserProfileView, CompanySettingsView, SelectOrganizationView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('select-organization/', SelectOrganizationView.as_view(), name='select_organization'),
    path('profile/', UserProfileView.as_view(), name='user_profile'),
    path('settings/organization/', CompanySettingsView.as_view(), name='company_settings'),
]
