"""
Ashr Labs Python SDK

A Python client library for interacting with the Ashr Labs API.
"""

from .client import AshrLabsClient
from .exceptions import (
    AshrLabsError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    ServerError,
)
from .models import (
    User,
    Tenant,
    Session,
    Dataset,
    Run,
    Request,
    APIKey,
)
from .run_builder import RunBuilder, TestBuilder

__version__ = "0.1.0"
__all__ = [
    # Client
    "AshrLabsClient",
    # Exceptions
    "AshrLabsError",
    "AuthenticationError",
    "AuthorizationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    # Models
    "User",
    "Tenant",
    "Session",
    "Dataset",
    "Run",
    "Request",
    "APIKey",
    # Builders
    "RunBuilder",
    "TestBuilder",
]
