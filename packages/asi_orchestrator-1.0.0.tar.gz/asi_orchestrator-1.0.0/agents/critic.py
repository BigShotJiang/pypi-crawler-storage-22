
class CriticAgent:
    async def critique(self, text):
        return "Critique output"
