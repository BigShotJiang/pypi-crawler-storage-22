
class PlannerAgent:
    async def create_plan(self, query):
        return "Step 1: Analyze\nStep 2: Reason\nStep 3: Summarize"
