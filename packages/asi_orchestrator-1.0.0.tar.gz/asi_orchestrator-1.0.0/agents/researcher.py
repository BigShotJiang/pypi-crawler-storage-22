
class ResearchAgent:
    async def research(self, plan):
        return "Research based on plan"
