
class ApprovalManager:
    def __init__(self):
        self.queue = []

    def request(self, stage, payload):
        item = {"stage": stage, "payload": payload, "status": "pending"}
        self.queue.append(item)
        return item

    def approve(self, index):
        self.queue[index]["status"] = "approved"

    def reject(self, index):
        self.queue[index]["status"] = "rejected"

    def pending(self):
        return [q for q in self.queue if q["status"] == "pending"]
