
class SafeOrchestrator:
    def __init__(self, agents, tools, memory, approvals):
        self.agents = agents
        self.tools = tools
        self.memory = memory
        self.approvals = approvals

    async def run(self, query):
        plan = await self.agents["planner"].create_plan(query)
        yield self.approvals.request("plan", plan)

        research = await self.agents["researcher"].research(plan)
        yield self.approvals.request("research", research)

        for step in plan.split("\n"):
            yield self.tools.request_intent("execute", step)
            yield self.tools.request_preview(step)
            yield self.tools.request_execute(step)

        critique = await self.agents["critic"].critique(research)
        yield self.approvals.request("critique", critique)

        verify = await self.agents["verifier"].verify(research, critique)
        yield self.approvals.request("verify", verify)

        yield self.memory.propose_write(query, verify)
