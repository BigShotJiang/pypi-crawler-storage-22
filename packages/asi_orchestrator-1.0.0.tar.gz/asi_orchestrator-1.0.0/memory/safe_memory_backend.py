
class SafeMemoryBackend:
    def __init__(self):
        self.data = []

    def propose_write(self, query, answer):
        return {"query": query, "answer": answer}

    def write(self, approved_payload):
        self.data.append(approved_payload)
