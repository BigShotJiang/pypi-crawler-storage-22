
class SafeToolExecutor:
    def request_intent(self, tool, args):
        return {"tool": tool, "args": args}

    def request_preview(self, args):
        return {"preview": args}

    def request_execute(self, args):
        return {"execute": args}
