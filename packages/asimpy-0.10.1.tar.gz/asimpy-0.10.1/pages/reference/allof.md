::: asimpy.allof
