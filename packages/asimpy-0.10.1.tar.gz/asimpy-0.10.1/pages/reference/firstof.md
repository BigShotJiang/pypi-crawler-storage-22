::: asimpy.firstof
