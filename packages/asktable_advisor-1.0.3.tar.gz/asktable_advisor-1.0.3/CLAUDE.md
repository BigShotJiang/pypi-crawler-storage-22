# CLAUDE.md

This file provides guidance to Claude Code when working with code in this repository.

## Project Overview

**AskTable Advisor** 是一个对话式 AI Agent，专为 AskTable 演示场景构建设计。

### 核心定位

这是一个**智能场景构建助手**，而不是通用框架+示例的架构。

用户只需用自然语言描述需求（如"创建一个电商平台场景"），Agent 自动：
1. 理解场景需求（通过对话询问细节）
2. 设计数据库结构（调用 LLM 生成 Schema）
3. 生成虚拟数据（调用 LLM 生成真实感数据）
4. 创建 AskTable 资源（datasource, bot, chat 等）
5. 配置权限管理（可选）

### 关键特性

- **对话式交互**：多轮对话，Agent 主动询问必要信息
- **AI 驱动**：使用阿里云百炼 qwen3-max 模型（通过 Anthropic 兼容接口）
- **工具调用**：Agent 使用 Tool Use 执行各种操作
- **场景管理**：查看、创建、完善 AskTable 演示场景

## Development Commands

### 环境设置

```bash
# 安装依赖
pip install -e .

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件，填入 API keys
```

### 运行 Agent

```bash
# 启动对话式 Agent
python -m asktable_advisor
```

### 代码质量

```bash
# 代码格式化
black asktable_advisor/
ruff check --fix asktable_advisor/

# 类型检查
mypy asktable_advisor/
```

## Architecture

### 项目结构

```
asktable_advisor/
├── __init__.py
├── __main__.py              # CLI 入口（对话界面）
├── config.py                # 配置管理（Pydantic Settings）
│
├── agent/                   # AI Agent 核心
│   ├── advisor.py           # 主 Agent 类（对话管理 + 工具执行）
│   ├── llm_client.py        # LLM 客户端（qwen3-max via Anthropic SDK）
│   ├── tools.py             # Agent 工具定义（Tool Use schema）
│   └── prompts.py           # System prompts（Agent 知识和指令）
│
├── asktable/                # AskTable API 封装
│   ├── client.py            # AskTable 客户端（封装 SDK）
│   ├── inspector.py         # 项目检查器（读取现有资源）
│   └── resources/           # 资源管理模块（占位）
│
├── database/                # 数据库管理
│   ├── manager.py           # 数据库连接管理（SQLAlchemy）
│   ├── schema_generator.py  # Schema 生成器（使用 LLM）
│   └── data_generator.py    # 数据生成器（使用 LLM）
│
└── utils/                   # 工具函数
    └── console.py           # Rich console 封装
```

### 核心组件

#### 1. AdvisorAgent (`agent/advisor.py`)

主 Agent 类，负责：
- **对话管理**：维护对话历史，处理多轮交互
- **LLM 调用**：通过 LLMClient 与 qwen3-max 交互
- **工具执行**：根据 LLM 的 tool use 调用执行具体操作
- **状态管理**：跟踪对话状态和上下文

工作流程：
1. 接收用户消息
2. 调用 LLM（附带 system prompt 和 tools）
3. 如果 LLM 返回 tool use，执行工具并返回结果给 LLM
4. 如果 LLM 返回文本响应，返回给用户
5. 循环直到完成任务

#### 2. LLMClient (`agent/llm_client.py`)

LLM 客户端，负责：
- 使用 Anthropic SDK 与阿里云百炼交互
- 支持 Tool Use（function calling）
- 处理消息格式转换
- 提取工具调用和文本响应

配置：
- Base URL: `https://dashscope.aliyuncs.com/apps/anthropic`
- Model: `qwen3-max`
- API Key: 阿里云 DashScope API Key

#### 3. Agent Tools (`agent/tools.py`)

定义 Agent 可用的工具，符合 Anthropic Tool Use 规范：
- `inspect_asktable_project` - 检查项目现有资源
- `design_database_schema` - LLM 设计数据库结构
- `generate_sample_data` - LLM 生成虚拟数据
- `execute_sql` - 执行 SQL 语句
- `create_asktable_datasource` - 创建数据源
- `create_asktable_bot` - 创建 Bot
- `create_asktable_chat` - 创建 Chat
- `enhance_bot` - 增强现有 Bot
- `create_permissions` - 配置权限（占位符）
- `ask_user` - 向用户询问问题

#### 4. Schema & Data Generators (`database/`)

**SchemaGenerator**：
- 根据场景描述调用 LLM 生成数据库表结构
- 返回 SQL DDL 语句（CREATE TABLE）
- 包含最佳实践（主键、外键、索引、时间戳等）

**DataGenerator**：
- 根据 Schema 调用 LLM 生成虚拟数据
- 返回 SQL INSERT 语句
- 确保数据真实感和关联正确性

#### 5. AskTable Client & Inspector (`asktable/`)

**AskTableClient**：
- 封装 AskTable SDK
- 提供统一的 API 接口（datasource, bot, chat 操作）
- 处理错误和日志

**AskTableInspector**：
- 读取项目现有资源
- 识别场景（datasource + bots + chats）
- 提供优化建议

### 配置管理

使用 `pydantic-settings` 从环境变量加载配置：

```python
class AdvisorSettings(BaseSettings):
    # AskTable API
    asktable_api_key: str
    asktable_api_base: str = "https://api.asktable.com"

    # LLM API（阿里云百炼）
    anthropic_base_url: str = "https://dashscope.aliyuncs.com/apps/anthropic"
    anthropic_api_key: str

    # Agent
    agent_model: str = "qwen3-max"
    agent_temperature: float = 0.7
    agent_max_tokens: int = 4096

    # MySQL
    mysql_host: str
    mysql_port: int = 3306
    mysql_user: str
    mysql_password: str
    mysql_database: str = "asktable_advisor"
```

### 依赖说明

- `anthropic`: Anthropic SDK（用于调用 qwen3-max via 兼容接口）
- `asktable`: AskTable Python SDK
- `sqlalchemy`: ORM 和数据库连接管理
- `pymysql`: MySQL 驱动
- `pydantic-settings`: 类型安全的配置管理
- `rich`: 美化命令行输出

## Important Notes

### LLM API 集成

- 使用阿里云百炼提供的 Anthropic 兼容接口
- Base URL: `https://dashscope.aliyuncs.com/apps/anthropic`
- 模型: `qwen3-max`
- API Key: DashScope API Key（不是 Anthropic 官方 key）

### Tool Use 流程

1. Agent 发送消息到 LLM，附带 tools 定义
2. LLM 返回 tool_use blocks
3. Agent 执行工具，获取结果
4. Agent 将 tool_result 返回给 LLM
5. LLM 处理结果，可能继续调用工具或返回最终响应

### 对话管理

- 使用 `conversation_history: List[MessageParam]` 维护对话
- 每轮包含：user message → assistant response (可能含 tool use) → tool results
- System prompt 在每次 LLM 调用时提供

### 扩展新工具

要添加新工具：
1. 在 `agent/tools.py` 中定义工具 schema
2. 在 `agent/advisor.py` 的 `_execute_tool()` 中添加处理逻辑
3. 实现工具的具体功能（如 `_tool_xxx()`）

### 数据库操作

- 使用 SQLAlchemy 管理连接
- 支持事务和错误回滚
- 连接池配置可调（pool_size, max_overflow）

## CLI Usage

```bash
# 启动对话
python -m asktable_advisor

# 交互示例
你: 创建一个电商场景
Advisor: 好的！让我了解一下...
         [Agent 询问细节]
你: B2C 零售，包含订单、商品、用户
Advisor: 收到！开始创建...
         [Agent 执行工具，显示进度]
         🎉 场景创建完成！
```

## Testing

目前测试框架尚未完整实现。可以通过：
1. 直接运行 Agent 进行集成测试
2. 测试各个组件的连接性

## Future Enhancements

1. **权限管理**：完整实现 Role 和 Policy 配置
2. **Report/Canvas**：支持创建可视化报告和画布
3. **ATS 测试**：集成自动化测试套件
4. **流式输出**：实现 LLM streaming for better UX
5. **对话历史持久化**：保存和恢复对话
6. **多租户支持**：支持多个 AskTable 项目

## Notes for AI Assistants

当你需要修改代码时：
- 理解 Agent 是对话式的，所有操作通过 tool use 完成
- LLM 调用使用阿里云百炼，不是 Anthropic 官方 API
- 工具执行结果需要返回给 LLM，不是直接返回用户
- 保持 system prompt 的完整性和专业性
- 确保错误处理和日志记录完善
