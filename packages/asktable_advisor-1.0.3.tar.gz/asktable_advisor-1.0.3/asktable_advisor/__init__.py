"""
AskTable Advisor - AI Agent for AskTable scenario building.

A conversational AI agent that helps users quickly create and manage
high-quality AskTable demo projects.
"""

from .__version__ import __version__, __version_info__
from .config import AdvisorSettings, get_settings
from .agent.advisor import AdvisorAgent

__all__ = [
    "__version__",
    "__version_info__",
    "AdvisorSettings",
    "get_settings",
    "AdvisorAgent",
]
