"""Command-line interface for AskTable Advisor."""

import logging
import sys

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

from .agent.advisor import AdvisorAgent
from .config import get_settings

# Setup console
console = Console()


def setup_logging(log_level: str = "WARNING") -> None:
    """
    Setup logging configuration.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    # Convert string to logging level
    numeric_level = getattr(logging, log_level.upper(), logging.WARNING)

    logging.basicConfig(
        level=numeric_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler("asktable_advisor.log"),
            logging.StreamHandler(sys.stderr),
        ],
        force=True,  # Override any existing configuration
    )


def print_welcome() -> None:
    """Print welcome message."""
    welcome_text = """
# 🤖 AskTable Advisor v1.0

你好！我是 AskTable Advisor，你的 AskTable 场景构建助手。

## 我能帮你：
- 🎨 **创建新场景**：告诉我场景名称（如"电商平台"、"在线教育"），我会自动设计并构建完整的演示项目
- 📊 **查看现有场景**：检查你的 AskTable 项目中已有的资源
- ✨ **完善场景**：优化现有场景，添加更多功能

## 使用方式：
直接用自然语言告诉我你想做什么！例如：
- "创建一个在线教育平台的演示场景"
- "看看我现在有哪些场景"
- "给电商 Bot 添加更多示例问题"

输入 **exit** 或 **quit** 退出。

开始对话吧！
"""
    console.print(Panel(Markdown(welcome_text), border_style="cyan"))


def run_chat_loop(agent: AdvisorAgent) -> None:
    """
    Run the main chat loop.

    Args:
        agent: Advisor agent instance
    """
    while True:
        try:
            # Get user input
            user_input = Prompt.ask("\n[bold cyan]你[/bold cyan]").strip()

            # Check for exit commands
            if user_input.lower() in ["exit", "quit", "退出", "再见"]:
                console.print("\n[dim]再见！如有需要随时回来 👋[/dim]\n")
                break

            # Skip empty input
            if not user_input:
                continue

            # Process with agent
            console.print("\n[bold green]Advisor[/bold green]: ", end="")

            try:
                response = agent.chat(user_input)
                console.print(response)

            except Exception as e:
                console.print(f"\n[red]错误：{str(e)}[/red]")
                logging.error(f"Error processing message: {e}", exc_info=True)

        except KeyboardInterrupt:
            console.print("\n\n[dim]检测到 Ctrl+C，退出程序...[/dim]\n")
            break

        except EOFError:
            console.print("\n\n[dim]输入结束，退出程序...[/dim]\n")
            break


def test_connections(agent: AdvisorAgent) -> bool:
    """
    Test all connections.

    Args:
        agent: Advisor agent instance

    Returns:
        True if all connections successful
    """
    console.print("\n[cyan]正在测试连接...[/cyan]\n")

    results = agent.test_connections()

    all_ok = True
    for service, ok in results.items():
        status = "[green]✓[/green]" if ok else "[red]✗[/red]"
        console.print(f"{status} {service.upper()} 连接")
        all_ok = all_ok and ok

    console.print()

    if not all_ok:
        console.print(
            "[yellow]警告：部分服务连接失败，某些功能可能无法使用[/yellow]\n"
        )

    return all_ok


def main() -> None:
    """Main entry point for CLI."""
    try:
        # Load settings
        settings = get_settings()

        # Setup logging with configured level
        setup_logging(settings.log_level)

        # Print welcome
        print_welcome()

        # Initialize agent
        console.print("[dim]正在初始化 Advisor Agent...[/dim]")
        agent = AdvisorAgent(settings)

        # Test connections
        test_connections(agent)

        # Start chat loop
        console.print("[dim]准备就绪！开始对话：[/dim]\n")
        run_chat_loop(agent)

    except KeyboardInterrupt:
        console.print("\n\n[dim]程序被中断[/dim]\n")
        sys.exit(0)

    except Exception as e:
        console.print(f"\n[red bold]错误：{str(e)}[/red bold]\n")
        logging.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
