"""LLM client for AskTable Advisor using Aliyun Bailian (qwen3-max)."""

import logging
from typing import Any, Dict, List, Optional, Union

from anthropic import Anthropic
from anthropic.types import (
    Message,
    MessageParam,
    ToolUseBlock,
    TextBlock,
    ContentBlock,
)

from ..config import AdvisorSettings

logger = logging.getLogger(__name__)


class LLMClient:
    """
    LLM client for the Advisor Agent.

    Uses Anthropic SDK with Aliyun Bailian backend (qwen3-max model).
    Supports Tool Use (function calling) for agent operations.
    """

    def __init__(self, settings: AdvisorSettings):
        """
        Initialize LLM client.

        Args:
            settings: Application settings with API credentials
        """
        self.settings = settings

        # Initialize Anthropic client with Aliyun Bailian endpoint
        self.client = Anthropic(
            api_key=settings.advisor_anthropic_api_key,
            base_url=settings.advisor_anthropic_base_url,
            timeout=60.0,  # Set 60 second timeout to avoid streaming requirement
        )

        self.model = settings.agent_model
        self.temperature = settings.agent_temperature
        self.max_tokens = settings.agent_max_tokens

        logger.info(
            f"LLM client initialized: model={self.model}, "
            f"base_url={settings.advisor_anthropic_base_url}"
        )

    def create_message(
        self,
        messages: List[MessageParam],
        system: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        stream: bool = False,
    ) -> Message:
        """
        Create a message with the LLM.

        Args:
            messages: Conversation history (user/assistant messages)
            system: System prompt (optional)
            tools: Available tools for function calling (optional)
            stream: Whether to stream the response (default: False)

        Returns:
            Message object with LLM response
        """
        try:
            params = {
                "model": self.model,
                "messages": messages,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
            }

            if system:
                params["system"] = system

            if tools:
                params["tools"] = tools

            logger.debug(f"Creating message with {len(messages)} messages")

            if stream:
                # Streaming not implemented yet
                # TODO: Implement streaming response handling
                logger.warning("Streaming not yet implemented, falling back to non-streaming")

            # Set explicit timeout to avoid streaming requirement for large max_tokens
            response = self.client.messages.create(**params, timeout=60.0)

            logger.debug(
                f"Received response: "
                f"stop_reason={response.stop_reason}, "
                f"usage={response.usage}"
            )

            return response

        except Exception as e:
            logger.error(f"Error creating message: {e}")
            raise

    def extract_text(self, message: Message) -> str:
        """
        Extract text content from a message.

        Args:
            message: Message object from LLM

        Returns:
            Concatenated text from all text blocks
        """
        text_parts = []
        for block in message.content:
            if isinstance(block, TextBlock):
                text_parts.append(block.text)
        return "\n".join(text_parts)

    def extract_tool_uses(self, message: Message) -> List[ToolUseBlock]:
        """
        Extract tool use blocks from a message.

        Args:
            message: Message object from LLM

        Returns:
            List of tool use blocks
        """
        tool_uses = []
        for block in message.content:
            if isinstance(block, ToolUseBlock):
                tool_uses.append(block)
        return tool_uses

    def has_tool_use(self, message: Message) -> bool:
        """
        Check if message contains tool use.

        Args:
            message: Message object from LLM

        Returns:
            True if message contains at least one tool use block
        """
        return any(isinstance(block, ToolUseBlock) for block in message.content)

    def format_tool_result(
        self,
        tool_use_id: str,
        content: Union[str, Dict[str, Any]],
        is_error: bool = False,
    ) -> Dict[str, Any]:
        """
        Format tool execution result for sending back to LLM.

        Args:
            tool_use_id: ID of the tool use block
            content: Result content (string or dict)
            is_error: Whether this is an error result

        Returns:
            Formatted tool result message
        """
        if isinstance(content, dict):
            import json
            content_str = json.dumps(content, ensure_ascii=False, indent=2)
        else:
            content_str = str(content)

        return {
            "type": "tool_result",
            "tool_use_id": tool_use_id,
            "content": content_str,
            "is_error": is_error,
        }

    def test_connection(self) -> bool:
        """
        Test LLM API connection.

        Returns:
            True if connection successful, False otherwise
        """
        try:
            response = self.create_message(
                messages=[{"role": "user", "content": "Hello"}],
                system="You are a test assistant. Reply with 'OK'.",
            )
            return response.stop_reason in ["end_turn", "stop_sequence"]
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False
