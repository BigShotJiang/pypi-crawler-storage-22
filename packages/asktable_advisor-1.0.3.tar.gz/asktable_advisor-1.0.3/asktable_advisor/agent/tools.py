"""Tool definitions for AskTable Advisor Agent."""

from typing import Any, Dict, List

# Tool definitions following Anthropic's Tool Use specification
# https://docs.anthropic.com/claude/docs/tool-use


def get_tools() -> List[Dict[str, Any]]:
    """
    Get all available tools for the Advisor Agent.

    Returns:
        List of tool definitions
    """
    return [
        {
            "name": "inspect_asktable_project",
            "description": (
                "检查用户的 AskTable 项目，获取所有现有资源。"
                "返回项目中的 datasources、bots、chats、roles、policies 等资源列表。"
                "用于了解项目当前状态，查看已有场景。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "detailed": {
                        "type": "boolean",
                        "description": "是否返回详细信息（包括每个资源的完整配置）",
                        "default": False,
                    }
                },
                "required": [],
            },
        },
        {
            "name": "design_database_schema",
            "description": (
                "根据场景描述，自动设计数据库表结构。"
                "分析业务需求，确定需要的表、字段、数据类型、主键、外键关系等。"
                "返回 SQL DDL 语句（CREATE TABLE 语句）。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "scenario_name": {
                        "type": "string",
                        "description": "场景名称，如'电商平台'、'在线教育'、'CRM 系统'",
                    },
                    "scenario_description": {
                        "type": "string",
                        "description": "场景的详细描述，包括核心业务、主要功能等",
                    },
                    "requirements": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "具体的业务需求列表，如'需要订单管理'、'需要用户等级'",
                    },
                    "scale_info": {
                        "type": "object",
                        "description": "数据规模信息",
                        "properties": {
                            "user_count": {"type": "integer", "description": "预期用户数"},
                            "order_count": {"type": "integer", "description": "预期订单数"},
                            "other": {"type": "string", "description": "其他规模信息"},
                        },
                    },
                },
                "required": ["scenario_name", "scenario_description"],
            },
        },
        {
            "name": "generate_sample_data",
            "description": (
                "为给定的数据库表结构生成真实感的虚拟数据。"
                "使用 LLM 生成符合业务逻辑、数据关联正确的示例数据。"
                "返回 SQL INSERT 语句。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "schema_sql": {
                        "type": "string",
                        "description": "数据库表结构的 SQL DDL 语句",
                    },
                    "scenario_context": {
                        "type": "string",
                        "description": "场景上下文，帮助生成更真实的数据",
                    },
                    "data_volume": {
                        "type": "object",
                        "description": "每个表需要生成的数据量",
                        "additionalProperties": {"type": "integer"},
                    },
                },
                "required": ["schema_sql", "data_volume"],
            },
        },
        {
            "name": "execute_sql",
            "description": (
                "在数据库中执行 SQL 语句。"
                "可用于创建表结构（DDL）或插入数据（DML）。"
                "执行前会显示将要执行的 SQL 预览。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "sql": {
                        "type": "string",
                        "description": "要执行的 SQL 语句",
                    },
                    "description": {
                        "type": "string",
                        "description": "对这个 SQL 操作的描述，如'创建用户表'、'插入订单数据'",
                    },
                },
                "required": ["sql", "description"],
            },
        },
        {
            "name": "create_asktable_datasource",
            "description": (
                "在 AskTable 中创建数据源（Datasource）。"
                "连接到指定的数据库，使其可以被 Bot 查询和分析。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "数据源名称，如'电商演示数据库'",
                    },
                    "description": {
                        "type": "string",
                        "description": "数据源描述",
                    },
                    "database_name": {
                        "type": "string",
                        "description": "要连接的数据库名称",
                    },
                },
                "required": ["name", "database_name"],
            },
        },
        {
            "name": "create_asktable_bot",
            "description": (
                "在 AskTable 中创建智能 Bot。"
                "配置 Bot 的业务知识、系统指令、示例问题等。"
                "Bot 可以回答用户关于数据的问题，执行数据分析。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Bot 名称，如'电商数据分析师'、'教育平台分析助手'",
                    },
                    "description": {
                        "type": "string",
                        "description": "Bot 描述",
                    },
                    "datasource_id": {
                        "type": "string",
                        "description": "关联的数据源 ID",
                    },
                    "instructions": {
                        "type": "string",
                        "description": "Bot 的系统指令，定义其角色、能力、分析方式",
                    },
                    "sample_questions": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "示例问题列表，展示 Bot 能回答的典型问题",
                    },
                },
                "required": ["name", "datasource_id", "instructions"],
            },
        },
        {
            "name": "enhance_bot",
            "description": (
                "增强现有的 Bot。"
                "可以添加更多示例问题、优化系统指令、更新业务知识等。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "bot_id": {
                        "type": "string",
                        "description": "要增强的 Bot ID",
                    },
                    "action": {
                        "type": "string",
                        "enum": ["add_questions", "update_instructions", "optimize"],
                        "description": "增强动作类型",
                    },
                    "content": {
                        "type": "object",
                        "description": "根据 action 类型提供的内容",
                        "properties": {
                            "questions": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "要添加的示例问题（action=add_questions 时）",
                            },
                            "instructions": {
                                "type": "string",
                                "description": "更新的系统指令（action=update_instructions 时）",
                            },
                        },
                    },
                },
                "required": ["bot_id", "action"],
            },
        },
        {
            "name": "create_asktable_chat",
            "description": (
                "在 AskTable 中创建演示对话（Chat）。"
                "预制一些典型的业务问题和分析场景，方便演示和测试。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Chat 名称，如'电商场景演示'",
                    },
                    "bot_id": {
                        "type": "string",
                        "description": "关联的 Bot ID",
                    },
                    "initial_messages": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "预制的问题列表",
                    },
                },
                "required": ["name", "bot_id"],
            },
        },
        {
            "name": "create_permissions",
            "description": (
                "创建权限配置（Roles 和 Policies）。"
                "定义不同角色（如管理员、分析师、普通用户）的数据访问权限。"
                "配置行级、列级的数据访问控制。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "datasource_id": {
                        "type": "string",
                        "description": "关联的数据源 ID",
                    },
                    "roles": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {"type": "string"},
                                "description": {"type": "string"},
                            },
                        },
                        "description": "角色定义列表",
                    },
                    "policies": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "role_name": {"type": "string"},
                                "table": {"type": "string"},
                                "rules": {"type": "object"},
                            },
                        },
                        "description": "权限策略列表",
                    },
                },
                "required": ["datasource_id", "roles"],
            },
        },
        {
            "name": "ask_user",
            "description": (
                "向用户询问问题以获取更多信息。"
                "当需要用户确认、选择或提供额外细节时使用此工具。"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "question": {
                        "type": "string",
                        "description": "要问用户的问题",
                    },
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "可选的选项列表（如果是多选题）",
                    },
                },
                "required": ["question"],
            },
        },
    ]


def get_tool_by_name(name: str) -> Dict[str, Any]:
    """
    Get a specific tool definition by name.

    Args:
        name: Tool name

    Returns:
        Tool definition dict, or None if not found
    """
    tools = get_tools()
    for tool in tools:
        if tool["name"] == name:
            return tool
    return None
