"""AskTable project inspector for analyzing existing resources."""

import logging
from typing import Any, Dict, List

from .client import AskTableClient

logger = logging.getLogger(__name__)


class AskTableInspector:
    """
    Inspector for analyzing AskTable projects.

    Reads and organizes information about existing datasources, bots, chats, etc.
    """

    def __init__(self, client: AskTableClient):
        """
        Initialize inspector.

        Args:
            client: AskTable client instance
        """
        self.client = client

    def inspect_project(self, detailed: bool = False) -> Dict[str, Any]:
        """
        Inspect the entire AskTable project.

        Args:
            detailed: If True, include full configuration for each resource

        Returns:
            Dict containing organized project information
        """
        logger.info("Inspecting AskTable project...")

        project_info = {
            "datasources": self._inspect_datasources(detailed),
            "bots": self._inspect_bots(detailed),
            "chats": self._inspect_chats(detailed),
            "summary": {},
        }

        # Add summary statistics
        project_info["summary"] = {
            "total_datasources": len(project_info["datasources"]),
            "total_bots": len(project_info["bots"]),
            "total_chats": len(project_info["chats"]),
        }

        logger.info(
            f"Project inspection complete: "
            f"{project_info['summary']['total_datasources']} datasources, "
            f"{project_info['summary']['total_bots']} bots, "
            f"{project_info['summary']['total_chats']} chats"
        )

        return project_info

    def _inspect_datasources(self, detailed: bool) -> List[Dict[str, Any]]:
        """Inspect all datasources."""
        datasources = self.client.list_datasources()

        if not detailed:
            # Return simplified view
            return [
                {
                    "id": ds.get("id"),
                    "name": ds.get("name"),
                    "engine": ds.get("engine"),
                    "database": ds.get("access_config", {}).get("db"),
                }
                for ds in datasources
            ]

        return datasources

    def _inspect_bots(self, detailed: bool) -> List[Dict[str, Any]]:
        """Inspect all bots."""
        bots = self.client.list_bots()

        if not detailed:
            # Return simplified view
            return [
                {
                    "id": bot.get("id"),
                    "name": bot.get("name"),
                    "datasource_ids": bot.get("datasource_ids", []),
                    "sample_question_count": len(bot.get("sample_questions", [])),
                }
                for bot in bots
            ]

        return bots

    def _inspect_chats(self, detailed: bool) -> List[Dict[str, Any]]:
        """Inspect all chats."""
        chats = self.client.list_chats()

        if not detailed:
            # Return simplified view
            return [
                {
                    "id": chat.get("id"),
                    "name": chat.get("name"),
                    "bot_id": chat.get("bot_id"),
                }
                for chat in chats
            ]

        return chats

    def identify_scenarios(self) -> List[Dict[str, Any]]:
        """
        Identify distinct scenarios in the project.

        A scenario is typically a datasource + associated bots + chats.

        Returns:
            List of identified scenarios
        """
        datasources = self.client.list_datasources()
        bots = self.client.list_bots()
        chats = self.client.list_chats()

        scenarios = []

        for ds in datasources:
            ds_id = ds.get("id")

            # Find bots using this datasource
            related_bots = [
                bot for bot in bots
                if ds_id in bot.get("datasource_ids", [])
            ]

            # Find chats for these bots
            related_chats = []
            for bot in related_bots:
                bot_id = bot.get("id")
                bot_chats = [
                    chat for chat in chats
                    if chat.get("bot_id") == bot_id
                ]
                related_chats.extend(bot_chats)

            scenario = {
                "datasource": {
                    "id": ds.get("id"),
                    "name": ds.get("name"),
                    "engine": ds.get("engine"),
                },
                "bots": [
                    {
                        "id": bot.get("id"),
                        "name": bot.get("name"),
                        "sample_question_count": len(bot.get("sample_questions", [])),
                    }
                    for bot in related_bots
                ],
                "chats": [
                    {
                        "id": chat.get("id"),
                        "name": chat.get("name"),
                    }
                    for chat in related_chats
                ],
            }

            scenarios.append(scenario)

        logger.info(f"Identified {len(scenarios)} scenarios")
        return scenarios

    def get_optimization_suggestions(self) -> List[str]:
        """
        Analyze project and provide optimization suggestions.

        Returns:
            List of suggestion strings
        """
        suggestions = []

        datasources = self.client.list_datasources()
        bots = self.client.list_bots()

        # Check for datasources without bots
        for ds in datasources:
            ds_id = ds.get("id")
            has_bots = any(
                ds_id in bot.get("datasource_ids", [])
                for bot in bots
            )
            if not has_bots:
                suggestions.append(
                    f"数据源 '{ds.get('name')}' 没有关联的 Bot，建议创建一个 Bot 来使用这个数据源"
                )

        # Check for bots with few sample questions
        for bot in bots:
            question_count = len(bot.get("sample_questions", []))
            if question_count < 10:
                suggestions.append(
                    f"Bot '{bot.get('name')}' 只有 {question_count} 个示例问题，"
                    f"建议添加更多（推荐 15-25 个）"
                )

        return suggestions
