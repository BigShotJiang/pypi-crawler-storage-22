"""Configuration management for AskTable Advisor AI Agent."""

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class AdvisorSettings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # AskTable API Configuration
    asktable_api_key: str = Field(..., description="AskTable API key")
    asktable_api_base: str = Field(
        default="https://api.asktable.com",
        description="AskTable API base URL",
    )

    # LLM API Configuration (Aliyun Bailian - qwen3-max)
    advisor_anthropic_base_url: str = Field(
        default="https://dashscope.aliyuncs.com/apps/anthropic",
        description="Anthropic-compatible API base URL (Aliyun Bailian)",
    )
    advisor_anthropic_api_key: str = Field(
        ...,
        description="DashScope API key for Aliyun Bailian",
    )

    # Agent Configuration
    agent_model: str = Field(
        default="qwen3-max",
        description="LLM model to use for the advisor agent",
    )
    agent_temperature: float = Field(
        default=0.7,
        description="Temperature for LLM responses (0.0-1.0)",
    )
    agent_max_tokens: int = Field(
        default=4096,
        description="Maximum tokens for LLM responses",
    )

    # Logging Configuration
    log_level: str = Field(
        default="WARNING",
        description="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
    )

    # MySQL Database Configuration
    mysql_host: str = Field(..., description="MySQL host")
    mysql_port: int = Field(default=3306, description="MySQL port")
    mysql_user: str = Field(..., description="MySQL username")
    mysql_password: str = Field(..., description="MySQL password")
    mysql_database: str = Field(
        default="asktable_advisor",
        description="MySQL database name",
    )

    # Optional: Database connection pool settings
    mysql_pool_size: int = Field(
        default=5,
        description="Database connection pool size",
    )
    mysql_max_overflow: int = Field(
        default=10,
        description="Maximum overflow connections",
    )

    @property
    def mysql_url(self) -> str:
        """Generate SQLAlchemy database URL."""
        return (
            f"mysql+pymysql://{self.mysql_user}:{self.mysql_password}"
            f"@{self.mysql_host}:{self.mysql_port}/{self.mysql_database}"
        )


def get_settings() -> AdvisorSettings:
    """Load and return application settings."""
    return AdvisorSettings()
