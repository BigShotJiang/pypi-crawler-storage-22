"""Database data generator using LLM."""

import logging
from typing import Dict, Any, Optional

from ..agent.llm_client import LLMClient

logger = logging.getLogger(__name__)


class DataGenerator:
    """
    Generate realistic sample data using LLM.

    Creates INSERT statements with business-logic-aware data.
    """

    def __init__(self, llm_client: LLMClient):
        """
        Initialize data generator.

        Args:
            llm_client: LLM client for AI-powered generation
        """
        self.llm_client = llm_client

    def generate_data(
        self,
        schema_sql: str,
        scenario_context: str,
        data_volume: Dict[str, int],
    ) -> str:
        """
        Generate sample data for database tables.

        Args:
            schema_sql: Database schema (CREATE TABLE statements)
            scenario_context: Business context for generating realistic data
            data_volume: Dict mapping table names to desired row counts

        Returns:
            SQL INSERT statements
        """
        logger.info(f"Generating sample data for {len(data_volume)} tables")

        # Build prompt for data generation
        prompt = self._build_data_prompt(
            schema_sql,
            scenario_context,
            data_volume,
        )

        # Call LLM to generate data
        try:
            response = self.llm_client.create_message(
                messages=[{"role": "user", "content": prompt}],
                system=self._get_data_system_prompt(),
            )

            sql = self.llm_client.extract_text(response)

            # Extract SQL from markdown if needed
            sql = self._extract_sql_from_markdown(sql)

            logger.info("Sample data generated successfully")
            return sql

        except Exception as e:
            logger.error(f"Failed to generate data: {e}")
            raise

    def _build_data_prompt(
        self,
        schema_sql: str,
        scenario_context: str,
        data_volume: Dict[str, int],
    ) -> str:
        """Build prompt for data generation."""
        prompt = f"""请为以下数据库表结构生成真实感的示例数据：

场景上下文：
{scenario_context}

表结构：
```sql
{schema_sql}
```

数据量要求：
"""

        for table, count in data_volume.items():
            prompt += f"- {table} 表：生成 {count} 条数据\n"

        prompt += """
生成要求：
1. 数据要符合业务逻辑和真实场景
2. 确保外键关系正确（引用的 ID 必须存在）
3. 姓名、地址、商品名等使用真实感的中文内容
4. 数值数据要有合理的分布（不要全部相同）
5. 时间数据要分布在合理的时间范围内
6. 使用批量 INSERT 语句（每条语句插入多行）

只返回 INSERT INTO 语句，不要包含其他解释。
注意：先插入父表数据，再插入子表数据（按外键依赖顺序）。
"""

        return prompt

    def _get_data_system_prompt(self) -> str:
        """Get system prompt for data generation."""
        return """你是一位数据生成专家，擅长创建真实感、符合业务逻辑的示例数据。

你的特点：
- 生成的数据具有真实性和多样性
- 严格遵守外键约束和业务规则
- 理解各种业务场景的数据特征
- 确保数据分布合理（符合真实业务规律）

生成策略：
1. 姓名：使用常见的中文姓名，多样化
2. 日期：分布在合理的时间范围，考虑业务周期
3. 金额：符合业务场景（如订单金额有大有小）
4. 状态：不同状态合理分布（如订单状态：待付款、已付款、已发货等）
5. 关联数据：确保外键 ID 正确关联（如订单的 user_id 必须是真实存在的用户）

请根据表结构和业务场景，生成高质量的示例数据。
"""

    def _extract_sql_from_markdown(self, text: str) -> str:
        """Extract SQL from markdown code blocks."""
        if "```sql" in text:
            start = text.find("```sql") + 6
            end = text.find("```", start)
            if end > start:
                return text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            if end > start:
                return text[start:end].strip()

        return text.strip()
