"""Database manager for AskTable Advisor."""

import logging
from typing import Optional, List

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker, Session

from ..config import AdvisorSettings

logger = logging.getLogger(__name__)


class DatabaseManager:
    """
    Database connection and operation manager.

    Handles MySQL database connections, SQL execution, and database creation.
    """

    def __init__(self, settings: AdvisorSettings):
        """
        Initialize database manager.

        Args:
            settings: Application settings with database credentials
        """
        self.settings = settings
        self._engine: Optional[Engine] = None
        self._session_maker: Optional[sessionmaker] = None

        logger.info(
            f"Database manager initialized: "
            f"{settings.mysql_host}:{settings.mysql_port}/{settings.mysql_database}"
        )

    @property
    def engine(self) -> Engine:
        """Get or create database engine."""
        if self._engine is None:
            self._engine = create_engine(
                self.settings.mysql_url,
                pool_pre_ping=True,
                pool_size=self.settings.mysql_pool_size,
                max_overflow=self.settings.mysql_max_overflow,
                echo=False,
            )
        return self._engine

    @property
    def session_maker(self) -> sessionmaker:
        """Get or create session maker."""
        if self._session_maker is None:
            self._session_maker = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine,
            )
        return self._session_maker

    def get_session(self) -> Session:
        """Create a new database session."""
        return self.session_maker()

    def test_connection(self) -> bool:
        """
        Test database connection.

        Returns:
            True if connection successful, False otherwise
        """
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text("SELECT 1"))
                result.fetchone()
            logger.info("Database connection successful")
            return True
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return False

    def create_database(self, database_name: Optional[str] = None) -> None:
        """
        Create database if it doesn't exist.

        Args:
            database_name: Database name (default: use settings)
        """
        db_name = database_name or self.settings.mysql_database

        # Create engine without database selection
        engine_without_db = create_engine(
            f"mysql+pymysql://{self.settings.mysql_user}:{self.settings.mysql_password}"
            f"@{self.settings.mysql_host}:{self.settings.mysql_port}",
            pool_pre_ping=True,
        )

        try:
            with engine_without_db.connect() as conn:
                # Use CREATE DATABASE with proper MySQL syntax
                conn.execute(
                    text(f"CREATE DATABASE IF NOT EXISTS `{db_name}` "
                         f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
                )
                conn.commit()
            logger.info(f"Database '{db_name}' ready")
        except Exception as e:
            logger.error(f"Failed to create database: {e}")
            raise
        finally:
            engine_without_db.dispose()

    def execute_sql(self, sql: str, description: Optional[str] = None) -> int:
        """
        Execute SQL statements.

        Args:
            sql: SQL content (may contain multiple statements separated by ;)
            description: Optional description of the SQL operation

        Returns:
            Number of statements executed
        """
        if description:
            logger.info(f"Executing SQL: {description}")

        with self.get_session() as session:
            try:
                # Split by semicolon and filter empty statements
                statements = [
                    s.strip()
                    for s in sql.split(";")
                    if s.strip() and not s.strip().startswith("--")
                ]

                for statement in statements:
                    session.execute(text(statement))

                session.commit()
                logger.info(f"Successfully executed {len(statements)} SQL statements")
                return len(statements)

            except Exception as e:
                session.rollback()
                logger.error(f"SQL execution failed: {e}")
                logger.error(f"Failed SQL:\n{sql[:500]}...")  # Log first 500 chars
                raise

    def execute_sql_statements(self, statements: List[str]) -> int:
        """
        Execute a list of SQL statements.

        Args:
            statements: List of SQL statements

        Returns:
            Number of statements executed
        """
        with self.get_session() as session:
            try:
                for statement in statements:
                    if statement.strip():
                        session.execute(text(statement))

                session.commit()
                logger.info(f"Successfully executed {len(statements)} SQL statements")
                return len(statements)

            except Exception as e:
                session.rollback()
                logger.error(f"SQL execution failed: {e}")
                raise

    def database_exists(self, database_name: Optional[str] = None) -> bool:
        """
        Check if database exists.

        Args:
            database_name: Database name (default: use settings)

        Returns:
            True if database exists
        """
        db_name = database_name or self.settings.mysql_database

        engine_without_db = create_engine(
            f"mysql+pymysql://{self.settings.mysql_user}:{self.settings.mysql_password}"
            f"@{self.settings.mysql_host}:{self.settings.mysql_port}",
            pool_pre_ping=True,
        )

        try:
            with engine_without_db.connect() as conn:
                result = conn.execute(
                    text("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA "
                         "WHERE SCHEMA_NAME = :db_name"),
                    {"db_name": db_name}
                )
                exists = result.fetchone() is not None
                return exists
        finally:
            engine_without_db.dispose()

    def list_tables(self, database_name: Optional[str] = None) -> List[str]:
        """
        List all tables in the database.

        Args:
            database_name: Database name (default: use settings)

        Returns:
            List of table names
        """
        db_name = database_name or self.settings.mysql_database

        with self.engine.connect() as conn:
            result = conn.execute(
                text(f"SHOW TABLES FROM `{db_name}`")
            )
            tables = [row[0] for row in result.fetchall()]
            return tables

    def close(self) -> None:
        """Close database connections."""
        if self._engine:
            self._engine.dispose()
            logger.info("Database connections closed")
