"""Database schema generator using LLM."""

import logging
from typing import Dict, List, Any, Optional

from ..agent.llm_client import LLMClient

logger = logging.getLogger(__name__)


class SchemaGenerator:
    """
    Generate database schema using LLM.

    Analyzes business scenarios and creates appropriate table structures.
    """

    def __init__(self, llm_client: LLMClient):
        """
        Initialize schema generator.

        Args:
            llm_client: LLM client for AI-powered generation
        """
        self.llm_client = llm_client

    def generate_schema(
        self,
        scenario_name: str,
        scenario_description: str,
        requirements: Optional[List[str]] = None,
        scale_info: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generate database schema SQL for a scenario.

        Args:
            scenario_name: Name of the scenario
            scenario_description: Detailed scenario description
            requirements: List of specific requirements
            scale_info: Information about data scale

        Returns:
            SQL DDL statements (CREATE TABLE)
        """
        logger.info(f"Generating schema for scenario: {scenario_name}")

        # Build prompt for schema generation
        prompt = self._build_schema_prompt(
            scenario_name,
            scenario_description,
            requirements,
            scale_info,
        )

        # Call LLM to generate schema
        try:
            response = self.llm_client.create_message(
                messages=[{"role": "user", "content": prompt}],
                system=self._get_schema_system_prompt(),
            )

            sql = self.llm_client.extract_text(response)

            # Extract SQL from markdown code blocks if present
            sql = self._extract_sql_from_markdown(sql)

            logger.info(f"Schema generated successfully")
            return sql

        except Exception as e:
            logger.error(f"Failed to generate schema: {e}")
            raise

    def _build_schema_prompt(
        self,
        scenario_name: str,
        scenario_description: str,
        requirements: Optional[List[str]],
        scale_info: Optional[Dict[str, Any]],
    ) -> str:
        """Build prompt for schema generation."""
        prompt = f"""请为以下业务场景设计 MySQL 数据库表结构：

场景名称：{scenario_name}
场景描述：{scenario_description}
"""

        if requirements:
            prompt += f"\n具体需求：\n"
            for req in requirements:
                prompt += f"- {req}\n"

        if scale_info:
            prompt += f"\n数据规模：\n"
            for key, value in scale_info.items():
                prompt += f"- {key}: {value}\n"

        prompt += """
请生成完整的 CREATE TABLE 语句。要求：
1. 每个表都要有主键（id INT AUTO_INCREMENT PRIMARY KEY）
2. 正确设置外键关系（使用 FOREIGN KEY）
3. 包含 created_at 和 updated_at 时间戳字段
4. 选择合适的数据类型（INT、VARCHAR、DECIMAL、DATETIME 等）
5. 添加必要的索引
6. 使用 InnoDB 引擎
7. 字符集使用 utf8mb4

只返回 SQL 语句，不要包含其他解释文字。
"""

        return prompt

    def _get_schema_system_prompt(self) -> str:
        """Get system prompt for schema generation."""
        return """你是一位经验丰富的数据库设计专家。

你精通：
- 各种业务场景的数据建模（电商、CRM、教育、医疗等）
- MySQL 数据库设计最佳实践
- 数据库规范化原则（1NF、2NF、3NF）
- 性能优化（索引设计、查询优化）

设计原则：
1. 表结构清晰、字段命名规范
2. 正确建立表关系（一对一、一对多、多对多）
3. 适当冗余以提升查询性能
4. 考虑数据一致性和完整性
5. 为常用查询添加索引

请根据业务场景，设计合理、规范的数据库表结构。
"""

    def _extract_sql_from_markdown(self, text: str) -> str:
        """Extract SQL from markdown code blocks."""
        # Check if text contains markdown SQL code block
        if "```sql" in text:
            start = text.find("```sql") + 6
            end = text.find("```", start)
            if end > start:
                return text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            if end > start:
                return text[start:end].strip()

        return text.strip()
