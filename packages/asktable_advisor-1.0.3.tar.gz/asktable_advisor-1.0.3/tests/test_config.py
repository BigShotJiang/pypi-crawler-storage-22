"""Tests for configuration management."""

import pytest
from asktable_tutorial.config import Settings


def test_settings_from_env(monkeypatch):
    """Test settings loaded from environment variables."""
    monkeypatch.setenv("ASKTABLE_API_KEY", "test_key")
    monkeypatch.setenv("MYSQL_HOST", "localhost")
    monkeypatch.setenv("MYSQL_USER", "test_user")
    monkeypatch.setenv("MYSQL_PASSWORD", "test_pass")

    settings = Settings()

    assert settings.asktable_api_key == "test_key"
    assert settings.mysql_host == "localhost"
    assert settings.mysql_user == "test_user"
    assert settings.mysql_password == "test_pass"


def test_mysql_url_generation(monkeypatch):
    """Test MySQL URL generation."""
    monkeypatch.setenv("ASKTABLE_API_KEY", "test_key")
    monkeypatch.setenv("MYSQL_HOST", "localhost")
    monkeypatch.setenv("MYSQL_PORT", "3306")
    monkeypatch.setenv("MYSQL_USER", "test_user")
    monkeypatch.setenv("MYSQL_PASSWORD", "test_pass")
    monkeypatch.setenv("MYSQL_DATABASE", "test_db")

    settings = Settings()

    expected_url = "mysql+pymysql://test_user:test_pass@localhost:3306/test_db"
    assert settings.mysql_url == expected_url


def test_default_values(monkeypatch):
    """Test default configuration values."""
    monkeypatch.setenv("ASKTABLE_API_KEY", "test_key")
    monkeypatch.setenv("MYSQL_HOST", "localhost")
    monkeypatch.setenv("MYSQL_USER", "test_user")
    monkeypatch.setenv("MYSQL_PASSWORD", "test_pass")

    settings = Settings()

    assert settings.asktable_api_base == "https://api.asktable.com"
    assert settings.mysql_port == 3306
    assert settings.mysql_database == "asktable_tutorial"
