"""Tests for scenario definitions."""

from asktable_tutorial.scenarios import EcommerceScenario, EnterpriseScenario


def test_ecommerce_scenario():
    """Test e-commerce scenario definition."""
    scenario = EcommerceScenario()

    assert scenario.get_name() == "电商数据分析"
    assert len(scenario.get_tables()) == 7
    assert len(scenario.get_sample_questions()) > 0
    assert len(scenario.get_report_queries()) > 0
    assert len(scenario.get_canvas_widgets()) > 0
    assert "users" in scenario.get_tables()
    assert "orders" in scenario.get_tables()


def test_enterprise_scenario():
    """Test enterprise scenario definition."""
    scenario = EnterpriseScenario()

    assert scenario.get_name() == "企业业务分析"
    assert len(scenario.get_tables()) == 7
    assert len(scenario.get_sample_questions()) > 0
    assert len(scenario.get_report_queries()) > 0
    assert len(scenario.get_canvas_widgets()) > 0
    assert "employees" in scenario.get_tables()
    assert "sales_orders" in scenario.get_tables()


def test_scenario_sample_questions():
    """Test that scenarios have meaningful sample questions."""
    ecommerce = EcommerceScenario()
    enterprise = EnterpriseScenario()

    for question in ecommerce.get_sample_questions():
        assert len(question) > 0
        assert isinstance(question, str)

    for question in enterprise.get_sample_questions():
        assert len(question) > 0
        assert isinstance(question, str)


def test_scenario_report_queries():
    """Test that report queries have required fields."""
    ecommerce = EcommerceScenario()
    enterprise = EnterpriseScenario()

    for query in ecommerce.get_report_queries():
        assert "title" in query
        assert "query" in query
        assert len(query["query"]) > 0

    for query in enterprise.get_report_queries():
        assert "title" in query
        assert "query" in query
        assert len(query["query"]) > 0


def test_scenario_canvas_widgets():
    """Test that canvas widgets have required fields."""
    ecommerce = EcommerceScenario()

    for widget in ecommerce.get_canvas_widgets():
        assert "type" in widget
        assert "title" in widget
        assert widget["type"] in ["kpi", "chart", "table"]
