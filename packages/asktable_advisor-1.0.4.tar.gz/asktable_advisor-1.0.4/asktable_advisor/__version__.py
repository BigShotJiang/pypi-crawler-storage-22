"""Version information for asktable-advisor."""

__version__ = "1.0.4"
__version_info__ = tuple(int(x) for x in __version__.split("."))
