"""Main Advisor Agent with conversational AI and tool execution."""

import json
import logging
from typing import Any, Dict, List, Optional

from anthropic.types import Message, MessageParam

from ..config import AdvisorSettings
from ..asktable.client import AskTableClient
from ..asktable.inspector import AskTableInspector
from ..asktable.api_schema import get_api_schema
from ..database.manager import DatabaseManager
from ..database.schema_generator import SchemaGenerator
from ..database.data_generator import DataGenerator
from .llm_client import LLMClient
from .tools import get_tools
from .prompts import get_system_prompt

logger = logging.getLogger(__name__)


class AdvisorAgent:
    """
    AskTable Advisor AI Agent.

    Conversational agent that helps users create and manage AskTable scenarios.
    """

    def __init__(self, settings: AdvisorSettings):
        """
        Initialize Advisor Agent.

        Args:
            settings: Application settings
        """
        self.settings = settings

        # Initialize components
        self.llm_client = LLMClient(settings)
        self.db_manager = DatabaseManager(settings)
        self.asktable_client = AskTableClient(
            api_key=settings.asktable_api_key,
            base_url=settings.asktable_api_base,
        )
        self.asktable_inspector = AskTableInspector(self.asktable_client)
        self.api_schema = get_api_schema(settings.asktable_api_base)

        # Generators
        self.schema_generator = SchemaGenerator(self.llm_client)
        self.data_generator = DataGenerator(self.llm_client)

        # Conversation state
        self.conversation_history: List[MessageParam] = []
        self.system_prompt = get_system_prompt()
        self.tools = get_tools()

        logger.info("Advisor Agent initialized")

    def chat(self, user_message: str) -> str:
        """
        Process user message and return response.

        Args:
            user_message: User's input message

        Returns:
            Agent's response text
        """
        # Add user message to history
        self.conversation_history.append({
            "role": "user",
            "content": user_message,
        })

        # Process with LLM and tools
        response_text = self._process_turn()

        return response_text

    def _process_turn(self) -> str:
        """Process one conversation turn with potential tool use."""
        max_iterations = 10  # Prevent infinite loops
        iteration = 0

        while iteration < max_iterations:
            iteration += 1

            # Call LLM
            response = self.llm_client.create_message(
                messages=self.conversation_history,
                system=self.system_prompt,
                tools=self.tools,
            )

            # Check if LLM wants to use tools
            if self.llm_client.has_tool_use(response):
                # Execute tools and continue
                self._execute_tools(response)
            else:
                # LLM has final response
                response_text = self.llm_client.extract_text(response)

                # Add assistant response to history
                self.conversation_history.append({
                    "role": "assistant",
                    "content": response_text,
                })

                return response_text

        # Max iterations reached
        error_msg = "对话迭代次数过多，请重新开始"
        logger.warning(f"Max iterations reached in conversation")
        return error_msg

    def _execute_tools(self, message: Message) -> None:
        """
        Execute tools requested by LLM.

        Args:
            message: LLM message containing tool use blocks
        """
        # Add assistant message with tool use to history
        self.conversation_history.append({
            "role": "assistant",
            "content": message.content,
        })

        # Extract and execute each tool
        tool_uses = self.llm_client.extract_tool_uses(message)

        for tool_use in tool_uses:
            tool_name = tool_use.name
            tool_input = tool_use.input
            tool_use_id = tool_use.id

            logger.info(f"Executing tool: {tool_name}")

            try:
                # Execute tool
                result = self._execute_tool(tool_name, tool_input)

                # Format result
                tool_result = self.llm_client.format_tool_result(
                    tool_use_id=tool_use_id,
                    content=result,
                    is_error=False,
                )

            except Exception as e:
                logger.error(f"Tool execution failed: {e}")
                tool_result = self.llm_client.format_tool_result(
                    tool_use_id=tool_use_id,
                    content=f"工具执行失败：{str(e)}",
                    is_error=True,
                )

            # Add tool result to history
            self.conversation_history.append({
                "role": "user",
                "content": [tool_result],
            })

    def _execute_tool(self, tool_name: str, tool_input: Dict[str, Any]) -> Any:
        """
        Execute a specific tool.

        Args:
            tool_name: Name of the tool to execute
            tool_input: Tool input parameters

        Returns:
            Tool execution result
        """
        # Dispatch to appropriate handler
        if tool_name == "inspect_asktable_project":
            return self._tool_inspect_project(tool_input)

        elif tool_name == "design_database_schema":
            return self._tool_design_schema(tool_input)

        elif tool_name == "generate_sample_data":
            return self._tool_generate_data(tool_input)

        elif tool_name == "execute_sql":
            return self._tool_execute_sql(tool_input)

        elif tool_name == "create_asktable_datasource":
            return self._tool_create_datasource(tool_input)

        elif tool_name == "create_asktable_bot":
            return self._tool_create_bot(tool_input)

        elif tool_name == "create_asktable_chat":
            return self._tool_create_chat(tool_input)

        elif tool_name == "enhance_bot":
            return self._tool_enhance_bot(tool_input)

        elif tool_name == "create_permissions":
            return self._tool_create_permissions(tool_input)

        elif tool_name == "ask_datasource":
            return self._tool_ask_datasource(tool_input)

        elif tool_name == "ask_bot":
            return self._tool_ask_bot(tool_input)

        elif tool_name == "list_available_datasources":
            return self._tool_list_datasources(tool_input)

        elif tool_name == "list_available_bots":
            return self._tool_list_bots(tool_input)

        elif tool_name == "search_asktable_api":
            return self._tool_search_api(tool_input)

        elif tool_name == "call_asktable_api":
            return self._tool_call_api(tool_input)

        elif tool_name == "ask_user":
            return self._tool_ask_user(tool_input)

        else:
            raise ValueError(f"Unknown tool: {tool_name}")

    # Tool implementations
    def _tool_inspect_project(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Inspect AskTable project."""
        detailed = params.get("detailed", False)
        return self.asktable_inspector.inspect_project(detailed=detailed)

    def _tool_design_schema(self, params: Dict[str, Any]) -> str:
        """Design database schema."""
        return self.schema_generator.generate_schema(
            scenario_name=params["scenario_name"],
            scenario_description=params["scenario_description"],
            requirements=params.get("requirements"),
            scale_info=params.get("scale_info"),
        )

    def _tool_generate_data(self, params: Dict[str, Any]) -> str:
        """Generate sample data."""
        return self.data_generator.generate_data(
            schema_sql=params["schema_sql"],
            scenario_context=params.get("scenario_context", ""),
            data_volume=params["data_volume"],
        )

    def _tool_execute_sql(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute SQL statements."""
        sql = params["sql"]
        description = params.get("description", "执行 SQL")

        count = self.db_manager.execute_sql(sql, description)

        return {
            "success": True,
            "statements_executed": count,
            "message": f"成功执行 {count} 条 SQL 语句",
        }

    def _tool_create_datasource(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Create AskTable datasource."""
        datasource = self.asktable_client.create_datasource(
            name=params["name"],
            database_name=params["database_name"],
            description=params.get("description"),
        )
        return datasource

    def _tool_create_bot(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Create AskTable bot."""
        bot = self.asktable_client.create_bot(
            name=params["name"],
            datasource_id=params["datasource_id"],
            description=params.get("description"),
            instructions=params.get("instructions"),
            sample_questions=params.get("sample_questions"),
        )
        return bot

    def _tool_create_chat(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Create AskTable chat."""
        chat = self.asktable_client.create_chat(
            bot_id=params["bot_id"],
            name=params["name"],
        )
        return chat

    def _tool_enhance_bot(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Enhance existing bot."""
        bot_id = params["bot_id"]
        action = params["action"]
        content = params.get("content", {})

        if action == "add_questions":
            # Get current bot
            bot = self.asktable_client.get_bot(bot_id)
            if not bot:
                raise ValueError(f"Bot not found: {bot_id}")

            # Add new questions
            current_questions = bot.get("sample_questions", [])
            new_questions = content.get("questions", [])
            all_questions = current_questions + new_questions

            # Update bot
            updated_bot = self.asktable_client.update_bot(
                bot_id=bot_id,
                sample_questions=all_questions,
            )
            return updated_bot

        elif action == "update_instructions":
            updated_bot = self.asktable_client.update_bot(
                bot_id=bot_id,
                instructions=content.get("instructions"),
            )
            return updated_bot

        else:
            raise ValueError(f"Unknown action: {action}")

    def _tool_create_permissions(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Create permissions (placeholder)."""
        # This is a placeholder for future implementation
        return {
            "message": "权限配置功能尚未实现，这是占位符",
            "datasource_id": params.get("datasource_id"),
            "roles": params.get("roles", []),
        }

    def _tool_ask_datasource(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Ask a question to a datasource."""
        datasource_id = params["datasource_id"]
        question = params["question"]
        max_rows = params.get("max_rows")

        answer = self.asktable_client.ask_datasource(
            datasource_id=datasource_id,
            question=question,
            max_rows=max_rows,
        )

        return answer

    def _tool_ask_bot(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Ask a question to a bot."""
        bot_id = params["bot_id"]
        question = params["question"]
        chat_id = params.get("chat_id")

        message = self.asktable_client.ask_bot(
            bot_id=bot_id,
            question=question,
            chat_id=chat_id,
        )

        return message

    def _tool_list_datasources(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """List all available datasources."""
        datasources = self.asktable_client.list_datasources()

        return {
            "datasources": datasources,
            "count": len(datasources),
        }

    def _tool_list_bots(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """List all available bots."""
        bots = self.asktable_client.list_bots()

        return {
            "bots": bots,
            "count": len(bots),
        }

    def _tool_search_api(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Search for AskTable API endpoints."""
        query = params["query"]
        results = self.api_schema.search_endpoints(query)

        return {
            "query": query,
            "results": results,
            "count": len(results),
        }

    def _tool_call_api(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Call any AskTable API endpoint."""
        method = params["method"]
        path = params["path"]
        query_params = params.get("params")
        json_data = params.get("json_data")

        result = self.asktable_client.call_api(
            method=method,
            path=path,
            params=query_params,
            json_data=json_data,
        )

        return result

    def _tool_ask_user(self, params: Dict[str, Any]) -> str:
        """Ask user a question (returns question to be displayed)."""
        # In CLI mode, this will be handled by the CLI layer
        # For now, just return the question
        question = params["question"]
        options = params.get("options")

        if options:
            return f"{question}\n选项：{', '.join(options)}"
        return question

    def reset_conversation(self) -> None:
        """Reset conversation history."""
        self.conversation_history = []
        logger.info("Conversation reset")

    def test_connections(self) -> Dict[str, bool]:
        """Test all connections."""
        return {
            "llm": self.llm_client.test_connection(),
            "database": self.db_manager.test_connection(),
            "asktable": self.asktable_client.test_connection(),
        }
