"""AskTable OpenAPI schema parser and documentation generator."""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)


class AskTableAPISchema:
    """
    Parse and provide AskTable OpenAPI schema documentation.

    This class fetches the OpenAPI specification from AskTable API
    and generates simplified documentation for LLM consumption.
    """

    def __init__(self, api_base_url: str = "https://api.asktable.com"):
        """
        Initialize API schema parser.

        Args:
            api_base_url: AskTable API base URL
        """
        self.api_base_url = api_base_url
        self.openapi_url = f"{api_base_url}/openapi.json"
        self._spec: Optional[Dict[str, Any]] = None
        self._cache_file = Path("/tmp/asktable_openapi_cache.json")

    @property
    def spec(self) -> Dict[str, Any]:
        """Get OpenAPI specification (cached)."""
        if self._spec is None:
            self._spec = self._load_spec()
        return self._spec

    def _load_spec(self) -> Dict[str, Any]:
        """Load OpenAPI spec from cache or fetch from API."""
        # Try cache first
        if self._cache_file.exists():
            try:
                with open(self._cache_file, 'r') as f:
                    spec = json.load(f)
                logger.info("Loaded OpenAPI spec from cache")
                return spec
            except Exception as e:
                logger.warning(f"Failed to load cache: {e}")

        # Fetch from API
        try:
            logger.info(f"Fetching OpenAPI spec from {self.openapi_url}")
            response = httpx.get(self.openapi_url, timeout=30.0)
            response.raise_for_status()
            spec = response.json()

            # Save to cache
            try:
                with open(self._cache_file, 'w') as f:
                    json.dump(spec, f)
                logger.info("Saved OpenAPI spec to cache")
            except Exception as e:
                logger.warning(f"Failed to save cache: {e}")

            return spec
        except Exception as e:
            logger.error(f"Failed to fetch OpenAPI spec: {e}")
            return {"paths": {}}

    def get_api_categories(self) -> Dict[str, List[str]]:
        """
        Get API endpoints grouped by category.

        Returns:
            Dict mapping category name to list of endpoint paths
        """
        paths = self.spec.get('paths', {})
        categories: Dict[str, List[str]] = {}

        for path in paths.keys():
            # Extract category from path (e.g., /v1/bots/{id} -> bots)
            parts = path.strip('/').split('/')
            if len(parts) > 1 and parts[0] == 'v1':
                category = parts[1]
            else:
                category = 'other'

            if category not in categories:
                categories[category] = []
            categories[category].append(path)

        return categories

    def get_endpoint_info(self, path: str, method: str) -> Optional[Dict[str, Any]]:
        """
        Get detailed information about an API endpoint.

        Args:
            path: API path (e.g., /v1/bots)
            method: HTTP method (e.g., GET, POST)

        Returns:
            Endpoint information or None if not found
        """
        paths = self.spec.get('paths', {})
        if path not in paths:
            return None

        method_lower = method.lower()
        endpoint = paths[path].get(method_lower)
        if not endpoint:
            return None

        return {
            'path': path,
            'method': method.upper(),
            'summary': endpoint.get('summary', ''),
            'description': endpoint.get('description', ''),
            'parameters': endpoint.get('parameters', []),
            'requestBody': endpoint.get('requestBody'),
            'responses': endpoint.get('responses', {}),
        }

    def generate_api_documentation(self, max_endpoints: int = 50) -> str:
        """
        Generate simplified API documentation for LLM.

        Args:
            max_endpoints: Maximum number of endpoints to include

        Returns:
            Formatted API documentation string
        """
        categories = self.get_api_categories()
        doc_lines = [
            "# AskTable API 参考文档",
            "",
            f"API 版本: {self.spec.get('info', {}).get('version', 'unknown')}",
            f"Base URL: {self.api_base_url}",
            "",
            "## API 分类",
            "",
        ]

        # Priority categories (most commonly used)
        priority_categories = [
            'bots', 'chats', 'datasources', 'single-turn',
            'canvas', 'reports', 'roles', 'policies'
        ]

        endpoint_count = 0
        for category in priority_categories:
            if category not in categories:
                continue
            if endpoint_count >= max_endpoints:
                break

            doc_lines.append(f"### {category}")
            doc_lines.append("")

            paths = self.spec.get('paths', {})
            for path in categories[category][:5]:  # Limit per category
                if endpoint_count >= max_endpoints:
                    break

                for method in ['get', 'post', 'put', 'delete', 'patch']:
                    if method in paths.get(path, {}):
                        endpoint = paths[path][method]
                        summary = endpoint.get('summary', '')
                        if summary:
                            doc_lines.append(f"- `{method.upper()} {path}` - {summary}")
                            endpoint_count += 1

            doc_lines.append("")

        return "\n".join(doc_lines)

    def search_endpoints(self, query: str) -> List[Dict[str, Any]]:
        """
        Search for API endpoints by keyword.

        Args:
            query: Search query (e.g., "chat", "message", "datasource")

        Returns:
            List of matching endpoints with their info
        """
        query_lower = query.lower()
        results = []

        paths = self.spec.get('paths', {})
        for path, methods in paths.items():
            # Check if query matches path
            if query_lower in path.lower():
                for method, endpoint in methods.items():
                    if method.upper() in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']:
                        results.append({
                            'path': path,
                            'method': method.upper(),
                            'summary': endpoint.get('summary', ''),
                            'score': 2 if query_lower in path.lower() else 1
                        })
            # Check if query matches summary/description
            else:
                for method, endpoint in methods.items():
                    if method.upper() in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']:
                        summary = endpoint.get('summary', '').lower()
                        description = endpoint.get('description', '').lower()
                        if query_lower in summary or query_lower in description:
                            results.append({
                                'path': path,
                                'method': method.upper(),
                                'summary': endpoint.get('summary', ''),
                                'score': 1
                            })

        # Sort by relevance score
        results.sort(key=lambda x: x['score'], reverse=True)
        return results[:10]  # Return top 10


def get_api_schema(api_base_url: str = "https://api.asktable.com") -> AskTableAPISchema:
    """Get or create AskTable API schema instance."""
    return AskTableAPISchema(api_base_url)
