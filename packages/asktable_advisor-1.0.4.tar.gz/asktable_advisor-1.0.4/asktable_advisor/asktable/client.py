"""AskTable API client for Advisor Agent."""

import logging
from typing import Any, Dict, List, Optional

import httpx
from asktable import Asktable

logger = logging.getLogger(__name__)


class AskTableClient:
    """
    AskTable API client wrapper.

    Provides a clean interface to interact with AskTable resources.
    """

    def __init__(self, api_key: str, base_url: str):
        """
        Initialize AskTable client.

        Args:
            api_key: AskTable API key
            base_url: AskTable API base URL
        """
        self.api_key = api_key
        self.base_url = base_url
        self._client: Optional[Asktable] = None

        logger.info(f"AskTable client initialized: {base_url}")

    @property
    def client(self) -> Asktable:
        """Get or create AskTable SDK client."""
        if self._client is None:
            self._client = Asktable(
                base_url=self.base_url,
                api_key=self.api_key,
            )
        return self._client

    def test_connection(self) -> bool:
        """
        Test AskTable API connection.

        Returns:
            True if connection successful, False otherwise
        """
        try:
            self.client.datasources.list()
            logger.info("AskTable API connection successful")
            return True
        except Exception as e:
            logger.error(f"AskTable API connection failed: {e}")
            return False

    # Datasource operations
    def list_datasources(self) -> List[Dict[str, Any]]:
        """List all datasources in the project."""
        try:
            result = self.client.datasources.list()
            datasources = result.items if hasattr(result, 'items') else result

            ds_list = []
            for ds in datasources:
                if hasattr(ds, 'model_dump'):
                    ds_list.append(ds.model_dump())
                elif hasattr(ds, 'dict'):
                    ds_list.append(ds.dict())
                else:
                    ds_list.append(ds)
            return ds_list
        except Exception as e:
            logger.error(f"Failed to list datasources: {e}")
            return []

    def get_datasource(self, datasource_id: str) -> Optional[Dict[str, Any]]:
        """Get datasource by ID."""
        try:
            datasource = self.client.datasources.retrieve(datasource_id)
            if hasattr(datasource, 'model_dump'):
                return datasource.model_dump()
            elif hasattr(datasource, 'dict'):
                return datasource.dict()
            return datasource
        except Exception as e:
            logger.warning(f"Datasource not found: {e}")
            return None

    def create_datasource(
        self,
        name: str,
        database_name: str,
        description: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new datasource."""
        try:
            # Use provided connection info or fall back to env defaults
            from ..config import get_settings
            settings = get_settings()

            datasource = self.client.datasources.create(
                name=name,
                engine="mysql",
                access_config={
                    "host": host or settings.mysql_host,
                    "port": port or settings.mysql_port,
                    "db": database_name,
                    "user": username or settings.mysql_user,
                    "password": password or settings.mysql_password,
                },
            )

            logger.info(f"Created datasource: {name}")

            if hasattr(datasource, 'model_dump'):
                return datasource.model_dump()
            elif hasattr(datasource, 'dict'):
                return datasource.dict()
            return datasource
        except Exception as e:
            logger.error(f"Failed to create datasource: {e}")
            raise

    def delete_datasource(self, datasource_id: str) -> bool:
        """Delete a datasource."""
        try:
            self.client.datasources.delete(datasource_id)
            logger.info(f"Deleted datasource: {datasource_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete datasource: {e}")
            return False

    # Bot operations
    def list_bots(self) -> List[Dict[str, Any]]:
        """List all bots in the project."""
        try:
            result = self.client.bots.list()
            bots = result.items if hasattr(result, 'items') else result

            bot_list = []
            for bot in bots:
                if hasattr(bot, 'model_dump'):
                    bot_list.append(bot.model_dump())
                elif hasattr(bot, 'dict'):
                    bot_list.append(bot.dict())
                else:
                    bot_list.append(bot)
            return bot_list
        except Exception as e:
            logger.error(f"Failed to list bots: {e}")
            return []

    def get_bot(self, bot_id: str) -> Optional[Dict[str, Any]]:
        """Get bot by ID."""
        try:
            bot = self.client.bots.retrieve(bot_id)
            if hasattr(bot, 'model_dump'):
                return bot.model_dump()
            elif hasattr(bot, 'dict'):
                return bot.dict()
            return bot
        except Exception as e:
            logger.warning(f"Bot not found: {e}")
            return None

    def create_bot(
        self,
        name: str,
        datasource_id: str,
        description: Optional[str] = None,
        instructions: Optional[str] = None,
        sample_questions: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Create a new bot."""
        try:
            bot = self.client.bots.create(
                name=name,
                datasource_ids=[datasource_id],
                welcome_message=description,
                magic_input=instructions,
                sample_questions=sample_questions or [],
            )

            logger.info(f"Created bot: {name}")

            if hasattr(bot, 'model_dump'):
                return bot.model_dump()
            elif hasattr(bot, 'dict'):
                return bot.dict()
            return bot
        except Exception as e:
            logger.error(f"Failed to create bot: {e}")
            raise

    def update_bot(
        self,
        bot_id: str,
        name: Optional[str] = None,
        instructions: Optional[str] = None,
        sample_questions: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Update an existing bot."""
        try:
            update_data = {}
            if name:
                update_data["name"] = name
            if instructions:
                update_data["magic_input"] = instructions
            if sample_questions:
                update_data["sample_questions"] = sample_questions

            bot = self.client.bots.update(bot_id, **update_data)
            logger.info(f"Updated bot: {bot_id}")

            if hasattr(bot, 'model_dump'):
                return bot.model_dump()
            elif hasattr(bot, 'dict'):
                return bot.dict()
            return bot
        except Exception as e:
            logger.error(f"Failed to update bot: {e}")
            raise

    # Chat operations
    def list_chats(self) -> List[Dict[str, Any]]:
        """List all chats in the project."""
        try:
            result = self.client.chats.list()
            chats = result.items if hasattr(result, 'items') else result

            chat_list = []
            for chat in chats:
                if hasattr(chat, 'model_dump'):
                    chat_list.append(chat.model_dump())
                elif hasattr(chat, 'dict'):
                    chat_list.append(chat.dict())
                else:
                    chat_list.append(chat)
            return chat_list
        except Exception as e:
            logger.error(f"Failed to list chats: {e}")
            return []

    def create_chat(
        self,
        bot_id: str,
        name: str,
    ) -> Dict[str, Any]:
        """Create a new chat session."""
        try:
            chat = self.client.chats.create(
                bot_id=bot_id,
                name=name,
            )

            logger.info(f"Created chat: {name}")

            if hasattr(chat, 'model_dump'):
                return chat.model_dump()
            elif hasattr(chat, 'dict'):
                return chat.dict()
            return chat
        except Exception as e:
            logger.error(f"Failed to create chat: {e}")
            raise

    # Question & Answer operations
    def ask_datasource(
        self,
        datasource_id: str,
        question: str,
        max_rows: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Ask a question directly to a datasource.

        Args:
            datasource_id: Target datasource ID
            question: Natural language question
            max_rows: Maximum rows to return (default: unlimited)

        Returns:
            Answer response with query results
        """
        try:
            params = {
                "datasource_id": datasource_id,
                "question": question,
            }
            if max_rows is not None:
                params["max_rows"] = max_rows

            answer = self.client.answers.create(**params)

            logger.info(f"Asked datasource {datasource_id}: {question[:50]}...")

            if hasattr(answer, 'model_dump'):
                return answer.model_dump()
            elif hasattr(answer, 'dict'):
                return answer.dict()
            return answer
        except Exception as e:
            logger.error(f"Failed to ask datasource: {e}")
            raise

    def ask_bot(
        self,
        bot_id: str,
        question: str,
        chat_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Ask a question to a bot via chat.

        Args:
            bot_id: Target bot ID
            question: Natural language question
            chat_id: Existing chat ID (if None, creates a new chat)

        Returns:
            Message response with bot's answer
        """
        try:
            # Create chat if not provided
            if not chat_id:
                chat = self.client.chats.create(
                    bot_id=bot_id,
                    name=f"Query: {question[:30]}...",
                )
                if hasattr(chat, 'id'):
                    chat_id = chat.id
                elif isinstance(chat, dict):
                    chat_id = chat.get('id')
                else:
                    raise ValueError("Failed to get chat ID")

            # Send message to chat
            message = self.client.chats.messages.create(
                chat_id=chat_id,
                question=question,
            )

            logger.info(f"Asked bot {bot_id}: {question[:50]}...")

            if hasattr(message, 'model_dump'):
                return message.model_dump()
            elif hasattr(message, 'dict'):
                return message.dict()
            return message
        except Exception as e:
            logger.error(f"Failed to ask bot: {e}")
            raise

    # Generic API operations
    def call_api(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Call any AskTable API endpoint dynamically.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            path: API path (e.g., /v1/bots)
            params: Query parameters
            json_data: Request body (for POST/PUT/PATCH)

        Returns:
            API response as dict

        Example:
            # List all canvas
            response = client.call_api('GET', '/v1/canvas')

            # Create a report
            response = client.call_api(
                'POST',
                '/v1/reports',
                json_data={'name': 'My Report', 'bot_id': 'bot_xxx'}
            )
        """
        try:
            # Build full URL
            if path.startswith('/'):
                url = f"{self.base_url}{path}"
            else:
                url = f"{self.base_url}/{path}"

            # Prepare headers
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }

            # Make request
            method_upper = method.upper()
            logger.info(f"Calling API: {method_upper} {path}")

            with httpx.Client(timeout=60.0) as http_client:
                response = http_client.request(
                    method=method_upper,
                    url=url,
                    params=params,
                    json=json_data,
                    headers=headers,
                )
                response.raise_for_status()

                # Try to parse JSON response
                try:
                    result = response.json()
                except Exception:
                    result = {"status": "success", "text": response.text}

                logger.info(f"API call successful: {method_upper} {path}")
                return result

        except httpx.HTTPStatusError as e:
            error_msg = f"HTTP {e.response.status_code}: {e.response.text}"
            logger.error(f"API call failed: {error_msg}")
            raise Exception(error_msg)
        except Exception as e:
            logger.error(f"API call failed: {e}")
            raise

