_NAME_STR = "name"
_NAMES_STR = "Names"
_TYPE_STR = "VisibleTypeName"
_VALUE_STR = "Value"
_GET_VALUES_STR = "GetValues"
_VALUES_STR = "Values"

_UPPERCASE_WORDS_TO_IGNORE = {"ID"}