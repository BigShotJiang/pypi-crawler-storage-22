from enum import Enum

class HysysObjectType(Enum):
    OBJECT = 0
    CONSTANT = 1
    ARRAY = 2
    DICT = 3