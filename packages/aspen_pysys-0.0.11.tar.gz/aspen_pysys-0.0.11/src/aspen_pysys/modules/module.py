from .module_type import HysysModuleType
from typing import Optional
from ..types.object import HysysObject

class HysysModule(HysysObject):
    def __init__(self, object: any, type: HysysModuleType):
        super().__init__(object)
        self._type = type

    def __repr__(self):
        return f"{self.name()} (HYSYS {self._type})"

    def getattr(self, attr: str) -> Optional[HysysObject]:
        result = super().getattr(attr)

        if result is None:
            return None

        module = HysysObject._loader.get_module(result.name())

        if module is None:
            return result

        return module