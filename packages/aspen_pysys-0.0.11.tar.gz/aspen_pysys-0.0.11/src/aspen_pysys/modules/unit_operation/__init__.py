from ..module import HysysModule
from ..module_type import HysysModuleType
from ...constants import _TYPE_STR

class UnitOperation(HysysModule):
    def  __init__(self, object: any):
        super().__init__(object, HysysModuleType.UNIT_OPERATION)

    def __repr__(self):
        return f"{self.name()} (HYSYS {self._type}, {self.operation_type()})"

    def operation_type(self) -> str:
        return getattr(self._object, _TYPE_STR)