from .types import HysysObject, HysysObjManager
from .modules import HysysModule
from .app import Hysys

def setup():
    Hysys.init(HysysObjManager.construct)
    HysysObject._set_loader(Hysys)