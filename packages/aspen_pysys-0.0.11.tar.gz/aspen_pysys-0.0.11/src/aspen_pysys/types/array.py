from .object import HysysObject
from .constant import HysysConstant
from .object_type import HysysObjectType

class HysysArray(HysysConstant):
    def __init__(self, object):
        super().__init__(object, HysysObjectType.ARRAY)

    def __repr__(self):
        return f"{self._object} ({self.type()})"

    # def list(self) -> list[any]:
    #     return

    def get(self, index) -> any:
        return self._object[index]

    def set(self, index, value) -> None:
        self._object[index] = value
        HysysObject._on_set()