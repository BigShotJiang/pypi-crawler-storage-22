from .object import HysysObject
from .non_module import HysysNonModule
from .object_type import HysysObjectType

class HysysConstant(HysysNonModule):
    def __init__(self, object, object_type=HysysObjectType.CONSTANT):
        super().__init__(object, object_type)

    def __repr__(self):
        return f"{self.get()} ({self.type()})"

    def get(self) -> any:
        return self._object

    def set(self, value) -> None:
        try:
            self._object = value
            HysysObject._on_set()
        except:
            print(f"'{self}' cannot be set.")