from typing import Optional
from ..constants import _NAMES_STR
from .object import HysysObject
from .object_type import HysysObjectType
from .non_module import HysysNonModule

class HysysDict(HysysNonModule):
    def __init__(self, object):
        super().__init__(object, HysysObjectType.DICT)

    def __repr__(self):
        return f"{self.keys()} ({self.type()})"

    def dict(self) -> dict[str, any]:
        return {key: self.get(key) for key in self.keys()}

    def keys(self) -> tuple[str]:
        return getattr(self._object, _NAMES_STR)

    def contains(self, key: str) -> bool:
        return key in self.keys()

    def get(self, key: str) -> Optional[HysysObject]:
        if self.contains(key):
            value = self._object.Item(key)
            return HysysObject._loader._object_constructor(value)

        return None

    # def set(self, key: str, value) -> None:
    #     if self.contains(key):
    #         self._object.Item(key) = value
    #         HysysObject._on_set()
    #     else:
    #         print(f"Value cannot be set for key '{key}'.")