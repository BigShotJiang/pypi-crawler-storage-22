from typing import Optional
from .object import HysysObject

class HysysNonModule(HysysObject):
    def __repr__(self):
        return "HYSYS Non-Module"

    def name(self) -> str:
        return None

    def attrs(self) -> list[str]:
        return [attr for attr in dir(self) if "_" not in attr]

    def getattr(self, _: str) -> Optional[HysysObject]:
        return None

