from typing import Optional
from ..constants import _NAME_STR
from .object_type import HysysObjectType

class HysysObject:
    @staticmethod
    def _set_loader(loader):
        HysysObject._loader = loader

    @staticmethod
    def _on_set():
        HysysObject._loader.refresh()

    def __init__(self, object, object_type=HysysObjectType.OBJECT):
        self._object = object
        self._obj_type = object_type

    def __repr__(self):
        return f"{self.name()} ({self.type()})"

    def type(self) -> HysysObjectType:
        return self._obj_type

    def name(self) -> str:
        return str(getattr(self._object, _NAME_STR)) \
            if hasattr(self._object, _NAME_STR) else "None"

    def attrs(self) -> list[str]:
        return [attr for attr in dir(self._object) if "_" not in attr]

    def getattr(self, attr: str) -> Optional[HysysObject]:
        try:
            result = HysysObject._loader \
                ._object_constructor(getattr(self._object, attr))
        except:
            print(f"Attribute '{attr}' for '{self}' does not exist.")
            return None

        return result

    def setattr(self, attr: str, value: any) -> None:
        try:
            setattr(self._object, attr, value)
            HysysObject._on_set()
        except:
            print(f"Attribute '{attr}' for '{self}' cannot be set.")
