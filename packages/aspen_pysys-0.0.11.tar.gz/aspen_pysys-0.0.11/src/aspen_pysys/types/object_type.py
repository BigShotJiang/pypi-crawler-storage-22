from enum import Enum

OBJECT_STR = "HYSYS Object"
CONSTANT_STR = "HYSYS Constant"
ARRAY_STR = "HYSYS Array"
DICT_STR = "HYSYS Dictionary"

class HysysObjectType(Enum):
    OBJECT = 0
    CONSTANT = 1
    ARRAY = 2
    DICT = 3

    def __str__(self):
        if self == HysysObjectType.OBJECT:
            return OBJECT_STR
        elif self == HysysObjectType.CONSTANT:
            return CONSTANT_STR
        elif self == HysysObjectType.ARRAY:
            return ARRAY_STR
        elif self == HysysObjectType.DICT:
            return DICT_STR