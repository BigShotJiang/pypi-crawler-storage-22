from .object import HysysObject

class HysysNonModule(HysysObject):
    def name(self) -> str:
        return None


