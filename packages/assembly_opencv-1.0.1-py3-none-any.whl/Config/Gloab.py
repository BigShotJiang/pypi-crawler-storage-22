
operator_menus = []
library_tree_data = []