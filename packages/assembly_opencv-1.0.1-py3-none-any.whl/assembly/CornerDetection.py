import cv2
import numpy as np

from assembly.description.Decoration import func_description, class_description

'''
角点检测算子

输入：灰度图
输出：角点坐标列表
'''


@class_description(
    title="角点检测",
    description="角点检测算子是一种图像特征提取技术，用于检测图像中的特征点，如角点、边缘、斑点等。",
    level=9
)
class CornerDetection(object):

    @func_description(
        title="角点检测Harris算法:",
        description="基于图像局部灰度变化，通过计算像素点在x/y 方向的梯度，构建结构张量矩阵（梯度自相关矩阵），再通过响应函数判断是否为角点"
    )
    @staticmethod
    def corner_harris(gray):
        """
        :name Harris角点检测
        :param gray: 单通道图
        :return list:角点坐标列表
        """

        image_float = np.float32(gray)
        dst = cv2.cornerHarris(image_float, blockSize=2, ksize=3, k=0.04)
        dst = cv2.dilate(dst, None)
        ret, dst = cv2.threshold(dst, 0.01 * dst.max(), 255, 0)
        dst = np.uint8(dst)
        ret, labels, stats, centroids = cv2.connectedComponentsWithStats(dst)
        result = [[stats[i][0], stats[i][1]] for i in range(1, ret)]
        return result

    @func_description(
        title="角点检测Shi-Tomasi算法:",
        description="Harris 算法的改进版，直接利用矩阵 M 的最小特征值判断角点"
    )
    @staticmethod
    def corner_shi_tomasi(gray):
        """
        :name Shi-Tomasi角点检测
        :param gray: 单通道图
        :return list:角点坐标列表
        """
        corners = cv2.goodFeaturesToTrack(gray, maxCorners=100, qualityLevel=0.01, minDistance=10)
        corners = np.intp(corners)
        print(corners.reshape(-1, 2).tolist())
        print(corners[0].ravel)
        result = [[i.ravel] for i in corners]
        return result

    @func_description(
        title="角点检测FAST算法:",
        description="基于像素灰度差异的高效角点检测算法，不直接用于角点检测，但可以用于特征匹配"
    )
    @staticmethod
    def corner_fast(gray, threshold=30, nonmaxSuppression=True):
        """
        :name FAST角点检测
        :param gray: 单通道图
        :param threshold: 阈值
        :param nonmaxSuppression: 是否关闭非极大值抑制
        :return list:角点坐标列表
        """

        fast = cv2.FastFeatureDetector_create(threshold=threshold)

        if nonmaxSuppression:
            # 关闭非极大值抑制
            fast.setNonmaxSuppression(0)
        # 检测图像上的关键点
        kp = fast.detect(gray, None)

        result = [[point.pt] for point in kp]
        return result


# def corner_SIFT(gray):
#     # 使用SIFT检测关键点并计算描述符
#     sift = cv2.SIFT_create()
#     keypoints, descriptors = sift.detectAndCompute(gray, None)
#
#     # 在图像上绘制关键点（实际上是特征点）
#     image_with_keypoints = cv2.drawKeypoints(gray, keypoints, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
#     return image_with_keypoints


# 暴露方法
def corner_detection_fast(gray_img, threshold=30, nonmaxSuppression=True):
    return CornerDetection.corner_fast(gray_img, threshold, nonmaxSuppression)

def corner_detection_shi_tomasi(gray_img):
    return CornerDetection.corner_shi_tomasi(gray_img)

def corner_detection_harris(gray_img):
    return CornerDetection.corner_harris(gray_img)


if __name__ == '__main__':
    corner_detection = CornerDetection()
    img = cv2.imdecode(np.fromfile(r"C:\Users\GT-LAPTOP-043\Downloads\黑白格.jpg", dtype=np.uint8),
                       cv2.IMREAD_COLOR)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # show_image("gray_img", gray_img, 500, 500)
    print("corner_harris", corner_detection.corner_harris(gray_img))
    print("corner_shi_tomasi", corner_detection.corner_shi_tomasi(gray_img))
    print("corner_fast", corner_detection.corner_fast(gray_img))

    cv2.destroyAllWindows()
