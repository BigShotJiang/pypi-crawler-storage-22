import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
绘制图像

输入：原始图
输出：原始图
'''


@class_description(
    title="绘制图像",
    description="在图像上绘制轮廓，包括点，线，矩形，圆等基本图形",
    level=2
)
class DrawImage(object):

    @func_description(
        title="生成空白图像",
        description="生成指定大小和颜色的空白图像"
    )
    @staticmethod
    def generate_blank_image(width, height, color=(0, 0, 0)):
        """
        :name 生成空白图像
        :param width: 图像宽度
        :param height: 图像高度
        :param color: 图像颜色
        :return img: 空白图像
        """
        img = np.zeros((height, width, 3), np.uint8)
        img[:] = color

        return img

    @func_description(
        title="绘制轮廓",
        description="在图像上绘制轮廓"
    )
    @staticmethod
    def draw_contours(img, contours, contour_color=(0, 255, 0), thickness=2):
        """
        :name 绘制轮廓
        :param img: 原始图
        :param contours: 轮廓列表
        :param contour_color: 轮廓颜色
        :param thickness: 轮廓线宽
        :return img: 绘制轮廓后的图像
        """
        img_draw = img.copy()
        cv2.drawContours(img_draw, contours, -1, contour_color, thickness)

        return img_draw

    @func_description(
        title="绘制点",
        description="在图像上绘制点"
    )
    @staticmethod
    def draw_points(img, points, point_color=(0, 0, 255), thickness=2):
        """
        :name 绘制点
        :param img: 原始图
        :param points: 点列表，格式为 [(x1, y1), (x2, y2), ...]
        :param point_color: 点颜色
        :param thickness: 点大小
        :return img: 绘制点后的图像
        """
        img_draw = img.copy()
        for point in points:
            cv2.circle(img_draw, point, thickness, point_color, -1)

        return img_draw

    @func_description(
        title="绘制线",
        description="在图像上绘制线"
    )
    @staticmethod
    def draw_lines(img, lines, line_color=(0, 255, 255), thickness=2):
        """
        :name 绘制线
        :param img: 原始图
        :param lines: 线列表，格式为 [(x1, y1, x2, y2), (x3, y3, x4, y4), ...]
        :param line_color: 线颜色
        :param thickness: 线宽
        :return img: 绘制线后的图像
        """
        img_draw = img.copy()
        for line in lines:
            cv2.line(img_draw, (line[0], line[1]), (line[2], line[3]), line_color, thickness)

        return img_draw

    @func_description(
        title="绘制矩形",
        description="在图像上绘制矩形"
    )
    @staticmethod
    def draw_rectangles(img, rectangles, rectangle_color=(255, 0, 0), thickness=2):
        """
        :name 绘制矩形
        :param img: 原始图
        :param rectangles: 矩形列表，格式为 [(x1, y1, w, h), (x2, y2, w, h), ...]
        :param rectangle_color: 矩形颜色
        :param thickness: 矩形线宽
        :return img: 绘制矩形后的图像
        """
        img_draw = img.copy()
        for rectangle in rectangles:
            cv2.rectangle(img_draw, (rectangle[0], rectangle[1]),
                          (rectangle[0] + rectangle[2], rectangle[1] + rectangle[3]), rectangle_color, thickness)

        return img_draw

    @func_description(
        title="绘制圆",
        description="在图像上绘制圆"
    )
    @staticmethod
    def draw_circles(img, circles, circle_color=(255, 255, 0), thickness=2):
        """
        :name 绘制圆
        :param img: 原始图
        :param circles: 圆列表，格式为 [(x, y, r), (x, y, r), ...]
        :param circle_color: 圆颜色
        :param thickness: 圆线宽
        :return img: 绘制圆后的图像
        """
        img_draw = img.copy()
        for circle in circles:
            cv2.circle(img_draw, (circle[0], circle[1]), circle[2], circle_color, thickness)

        return img_draw

    @func_description(
        title="绘制椭圆",
        description="在图像上绘制椭圆"
    )
    @staticmethod
    def draw_ellipses(img, ellipses, ellipse_color=(0, 255, 255), thickness=2):
        """
        :name 绘制椭圆
        :param img: 原始图
        :param ellipses: 椭圆列表，格式为 [(x, y, w, h), (x, y, w, h), ...]
        :param ellipse_color: 椭圆颜色
        :param thickness: 椭圆线宽
        :return img: 绘制椭圆后的图像
        """
        img_draw = img.copy()
        for ellipse in ellipses:
            cv2.ellipse(img_draw, (ellipse[0], ellipse[1]), (ellipse[2], ellipse[3]), 0, 0, 360, ellipse_color,
                        thickness)

        return img_draw

    @func_description(
        title="绘制多边形",
        description="在图像上绘制多边形"
    )
    @staticmethod
    def draw_polygons(img, polygons, polygon_color=(255, 0, 255), thickness=2):
        """
        :name 绘制多边形
        :param img: 原始图
        :param polygons: 多边形列表，格式为 [[(x1, y1), (x2, y2), ...], [(x1, y1), (x2, y2), ...], ...]
        :param polygon_color: 多边形颜色
        :param thickness: 多边形线宽
        :return img: 绘制多边形后的图像
        """
        img_draw = img.copy()
        for polygon in polygons:
            cv2.polylines(img_draw, [np.array(polygon, dtype=np.int32)], True, polygon_color, thickness)

        return img_draw

    @func_description(
        title="绘制文字",
        description="在图像上绘制文字"
    )
    @staticmethod
    def draw_text(img, text, text_position, text_color=(0, 0, 0), font_size=12, font_bold=False):
        """
        :name 绘制文字
        :param img: 原始图
        :param text: 文字内容
        :param text_position: 文字位置，格式为 (x, y)
        :param text_color: 文字颜色
        :param font_size: 文字大小
        :param font_bold: 是否加粗
        :return img: 绘制文字后的图像
        """
        img_draw = img.copy()
        # 转换为Pillow图像
        img_pil = Image.fromarray(cv2.cvtColor(img_draw, cv2.COLOR_BGR2RGB))
        # 加载字体
        font = ImageFont.truetype("../front/simsun.ttc", font_size, index=1 if font_bold else 0)  # 替换为实际的字体路径
        # 在Pillow图像上绘制中文
        draw = ImageDraw.Draw(img_pil)
        draw.text(text_position, text, font=font, fill=text_color)
        # 转换回OpenCV格式
        img_draw = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)

        return img_draw

    @func_description(
        title="绘制边框",
        description="在图像四周增加边框"
    )
    @staticmethod
    def draw_border(img, border_width=5, border_color=(255, 255, 255)):
        """
        :name 绘制边框
        :param img: 原始图
        :param border_width: 边框宽度
        :param border_color: 边框颜色
        :return img: 绘制边框后的图像
        """
        img_draw = img.copy()
        img_draw = cv2.copyMakeBorder(img_draw, border_width, border_width, border_width, border_width,
                                      cv2.BORDER_CONSTANT, value=border_color)

        return img_draw


# 暴露外部调用方法

def generate_blank_image(width, height, color=(0, 0, 0)):
    return DrawImage.generate_blank_image(width, height, color)

def draw_contours(img, contours, contour_color=(0, 255, 0), thickness=2):
    return DrawImage.draw_contours(img, contours, contour_color, thickness)

def draw_points(img, points, point_color=(0, 0, 255), radius=5, thickness=-1):
    return DrawImage.draw_points(img, points, point_color, radius, thickness)

def draw_lines(img, lines, line_color=(255, 0, 0), thickness=2):
    return DrawImage.draw_lines(img, lines, line_color, thickness)

def draw_rectangles(img, rectangles, rectangle_color=(255, 0, 0), thickness=2):
    return DrawImage.draw_rectangles(img, rectangles, rectangle_color, thickness)

def draw_circles(img, circles, circle_color=(0, 255, 255), thickness=2):
    return DrawImage.draw_circles(img, circles, circle_color, thickness)

def draw_ellipses(img, ellipses, ellipse_color=(0, 255, 255), thickness=2):
    return DrawImage.draw_ellipses(img, ellipses, ellipse_color, thickness)

def draw_polygons(img, polygons, polygon_color=(255, 0, 255), thickness=2):
    return DrawImage.draw_polygons(img, polygons, polygon_color, thickness)

def draw_text(img, text, text_position, text_color=(0, 0, 0), font_size=12, font_bold=False):
    return DrawImage.draw_text(img, text, text_position, text_color, font_size, font_bold)

def draw_border(img, border_width=5, border_color=(255, 255, 255)):
    return DrawImage.draw_border(img, border_width, border_color)



if __name__ == '__main__':
    draw_image = DrawImage()
    img = draw_image.generate_blank_image(500, 500, (255, 255, 255))
    show_image("img", img)

    img = draw_image.draw_contours(img, [np.array([[100, 100], [200, 100], [200, 200], [100, 200]])])
    show_image("img", img)

    img = draw_image.draw_points(img, [[100, 100], [200, 200], [300, 300]])
    show_image("img", img)

    img = draw_image.draw_lines(img, [(50, 50, 450, 450), (450, 50, 50, 450)])
    show_image("img", img)

    img = draw_image.draw_rectangles(img, [(100, 100, 100, 100), (200, 200, 100, 100)])
    show_image("img", img)

    img = draw_image.draw_circles(img, [(100, 100, 50), (200, 200, 100)])
    show_image("img", img)

    img = draw_image.draw_ellipses(img, [(100, 100, 100, 50), (200, 200, 50, 100)])
    show_image("img", img)

    img = draw_image.draw_polygons(img, [[(100, 100), (200, 100), (200, 200), (100, 200)],
                                         [(300, 300), (400, 300), (400, 400), (300, 400)]])
    show_image("img", img)

    img = draw_image.draw_text(img, "特丝特 特丝特", (100, 100), font_size=24, font_bold=True)
    img = draw_image.draw_text(img, "特丝特 特丝特", (100, 150), font_size=24, font_bold=False)
    show_image("img", img)

    img = draw_image.draw_border(img, 10, (0, 0, 0))
    show_image("img", img)
