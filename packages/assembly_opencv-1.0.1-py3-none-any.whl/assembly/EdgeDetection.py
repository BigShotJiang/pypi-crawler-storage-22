import cv2
import numpy as np

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
边缘检测算子

输入：灰度图
输出：边缘轮廓图
'''


@class_description(
    title="边缘检测",
    description="边缘检测是图像处理中常用的技术，其目的是识别图像中的明显特征，并从中提取其特征点，从而对图像进行分析、处理、识别等。",
    level=8
)
class EdgeDetection(object):

    @func_description(
        title="边缘检测Canny算法",
        description="最经典的边缘检测算法之一，其核心目标是在噪声图像中提取精确、单像素宽、连续的边缘"
    )
    @staticmethod
    def edge_canny(gray, threshold1=50, threshold2=150, apertureSize=3, kernel=3):
        """
        :name Canny边缘检测算法
        :param gray: 单通道图
        :param threshold1: 阈值1
        :param threshold2: 阈值2
        :param apertureSize: 孔径大小
        :param kernel: 卷积核大小
        :return binary: 二值化图
        """
        if kernel and kernel in [3, 5, 7]:
            gray = cv2.GaussianBlur(gray, (kernel, kernel), 0)  # 高斯去噪
        # 调用Canny
        edges = cv2.Canny(gray, threshold1=threshold1, threshold2=threshold2, apertureSize=apertureSize)
        return edges

    @func_description(
        title="边缘检测Sobel算法",
        description="Sobel算子（索贝尔算子）利用像素上、下、左、右邻域的灰度加权算法，根据在边缘点处达到极值这一原理进行边缘检测。"
    )
    @staticmethod
    def edge_sobel(gray, ksize=3):
        """
        :name Sobel边缘检测算法
        :param gray: 单通道图
        :param ksize: 卷积核大小
        :return binary: 二值化图
        """
        # 计算 Sobel X 和 Y 方向的梯度
        dst_sobel_x = cv2.Sobel(gray, cv2.CV_16S, 1, 0, ksize=ksize)
        dst_sobel_y = cv2.Sobel(gray, cv2.CV_16S, 0, 1, ksize=ksize)
        # 转换为绝对值并缩放到 8 位
        dst_sobel_x = cv2.convertScaleAbs(dst_sobel_x)
        dst_sobel_y = cv2.convertScaleAbs(dst_sobel_y)
        # 合并 X 和 Y 方向的梯度
        dst = cv2.add(dst_sobel_x, dst_sobel_y)
        return dst

    @func_description(
        title="边缘检测Scharr算法",
        description="Sobel算子与Scharr算子比较：Sobel算子的缺点是，当结构较小是，精确度不高，Scharr算子具有更高的精度"
    )
    @staticmethod
    def edge_scharr(gray):
        """
        :name Scharr边缘检测算法
        :param gray: 单通道图
        :return binary: 二值化图
        """
        # 计算水平方向边缘信息
        scharrx = cv2.Scharr(gray, cv2.CV_64F, 1, 0)
        # 计算垂直方向边缘信息
        scharry = cv2.Scharr(gray, cv2.CV_64F, 0, 1)
        # 求绝对值
        scharrx = cv2.convertScaleAbs(scharrx)
        scharry = cv2.convertScaleAbs(scharry)
        # 水平方向和垂直方向的边缘叠加
        scharrxy = cv2.addWeighted(scharrx, 0.5, scharry, 0.5, 0)
        return scharrxy

    @func_description(
        title="边缘检测Laplacian算法",
        description="拉普拉斯算子是一种二阶导数算子，其具有旋转不变性，可以满足不同方向的图像边缘锐化（边缘检测）的要求。"
    )
    @staticmethod
    def edge_laplacian(gray):
        """
        :name Laplacian边缘检测算法
        :param gray: 单通道图
        :return binary: 二值化图
        """
        # 计算边缘信息
        laplace = cv2.Laplacian(gray, cv2.CV_64F)
        # 求绝对值
        laplace = cv2.convertScaleAbs(laplace)
        return laplace

    @func_description(
        title="边缘检测Roberts算法",
        description="Roberts算子又称为交叉微分算法，是基于交叉差分的梯度算法，通过局部差分计算检测边缘线条。"
    )
    @staticmethod
    def edge_roberts(gray):
        """
        :name Roberts边缘检测算法
        :param gray: 单通道图
        :return binary: 二值化图
        """
        # 定义 roberts 卷积核（注意 dtype 必须为 float32 以确保计算精度）
        kernel_roberts_x = np.array([[-1, 0],
                                     [0, 1]], dtype=np.float32)
        kernel_roberts_y = np.array([[0, -1],
                                     [1, 0]], dtype=np.float32)
        # 执行卷积（输出类型设为 CV_32F 保留正负值）
        dst = self.dege_filter2D(gray, kernel_roberts_x, kernel_roberts_y)
        return dst

    @func_description(
        title="边缘检测Prewitt算法",
        description="Prewitt边缘算子是一种边缘样板算子。由理想的边缘算子图像构成，依次用边缘样板去检测图像，与被检测区域最为相似的样板给出最大值，用这个最大值作为算子的输出。"
    )
    @staticmethod
    def edge_prewitt(gray):
        """
        :name Prewitt边缘检测算法
        :param gray: 单通道图
        :return binary: 二值化图
        """
        # 定义 Prewitt 卷积核（注意 dtype 必须为 float32 以确保计算精度）
        kernel_prewitt_x = np.array([[-1, 0, 1],
                                     [-1, 0, 1],
                                     [-1, 0, 1]], dtype=np.float32)
        kernel_prewitt_y = np.array([[-1, -1, -1],
                                     [0, 0, 0],
                                     [1, 1, 1]], dtype=np.float32)
        # 执行卷积（输出类型设为 CV_32F 保留正负值）
        dst = self.dege_filter2D(gray, kernel_prewitt_x, kernel_prewitt_y)
        return dst

    @staticmethod
    def dege_filter2D(gray, kernel_x, kernel_y):
        '''封装方法 利用filter2D实现边缘检测算法'''
        dst_prewitt_x = cv2.filter2D(gray, cv2.CV_32F, kernel_x)
        dst_prewitt_y = cv2.filter2D(gray, cv2.CV_32F, kernel_y)
        dst_prewitt_x = cv2.convertScaleAbs(dst_prewitt_x)
        dst_prewitt_y = cv2.convertScaleAbs(dst_prewitt_y)
        dst = cv2.add(dst_prewitt_x, dst_prewitt_y)
        return dst


# 保留方法
def edge_canny(gray, threshold1=50, threshold2=150, apertureSize=3, kernel=3):
    return EdgeDetection.edge_canny(gray, threshold1, threshold2, apertureSize, kernel)

def edge_sobel(gray, ksize=3):
    return EdgeDetection.edge_sobel(gray, ksize)

def edge_scharr(gray):
    return EdgeDetection.edge_scharr(gray)

def edge_laplacian(gray):
    return EdgeDetection.edge_laplacian(gray)

def edge_roberts(gray):
    return EdgeDetection.edge_roberts(gray)

def edge_prewitt(gray):
    return EdgeDetection.edge_prewitt(gray)


if __name__ == '__main__':
    edge_detection = EdgeDetection()
    img = cv2.imdecode(np.fromfile(r"C:\Users\GT-LAPTOP-043\Downloads\黑白格.jpg", dtype=np.uint8),
                       cv2.IMREAD_COLOR)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    show_image("gray_img", gray_img, 500, 500)
    show_image("edge_canny", edge_detection.edge_canny(gray_img), 500, 500)
    show_image("edge_sobel", edge_detection.edge_sobel(gray_img), 500, 500)
    show_image("edge_scharr", edge_detection.edge_scharr(gray_img), 500, 500)
    show_image("edge_laplacian", edge_detection.edge_laplacian(gray_img), 500, 500)
    show_image("edge_roberts", edge_detection.edge_roberts(gray_img), 500, 500)
    show_image("edge_prewitt", edge_detection.edge_prewitt(gray_img), 500, 500)

    cv2.destroyAllWindows()
