import cv2
import numpy as np

from assembly.description.Decoration import func_description, class_description

'''
常用工具

输入：任意
输出：任意
'''


@class_description(
    title="常用工具",
    description="包含通道转化、ROI、Mask等常用工具",
    level=1
)
class GeneralUtil(object):

    @func_description(
        title="BGR转灰度",
        description="BGR图像转换为灰度"
    )
    @staticmethod
    def color_transform_gray(img):
        """
           :name 转灰度图
           :param img: 原图: img
           :return img: 转化后图片: img
        """
        return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    @func_description(
        title="BGR转HSV",
        description="BGR图像转换为HSV"
    )
    @staticmethod
    def color_transform_hsv(img):
        """
           :name 转换颜色空间
           :param img: 原图: img
           :return img: 转化后图片: img
        """
        return cv2.cvtColor(img, cv2.COLOR_BGR2HSV)


    @func_description(
        title="读图",
        description="读取图像"
    )
    @staticmethod
    def read_img(img_path):
        """
        :name 读取图像
        :param img_path: 图片名: library_menu_select
        :return img: 原图: img
        """
        return cv2.imdecode(np.fromfile(img_path, dtype=np.uint8), cv2.IMREAD_COLOR)

    @staticmethod
    def write_img(img, img_path):
        """
        :name 写入图像
        :param img: 原图: img
        :param img_path: 图片名: library_menu_select
        :return None
        """
        cv2.imencode('.jpg', img)[1].tofile(img_path)

    @staticmethod
    def find_contours(img, mode=cv2.RETR_EXTERNAL, method=cv2.CHAIN_APPROX_SIMPLE):
        """
        :name 查找轮廓
        :param img: 原图: img
        :return contours: 轮廓列表: contours
        """
        contours, _ = cv2.findContours(img, mode, method)
        return contours

# 暴露方法
def color_transform_gray(img):
    return GeneralUtil.color_transform_gray(img)

def color_transform_hsv(img):
    return GeneralUtil.color_transform_hsv(img)

def read_img(img_path):
    return GeneralUtil.read_img(img_path)

def write_img(img, img_path):
    GeneralUtil.write_img(img, img_path)

def find_contours(img, mode=cv2.RETR_EXTERNAL, method=cv2.CHAIN_APPROX_SIMPLE):
    return GeneralUtil.find_contours(img, mode, method)

def show_image(win_name, img, wx=None, wy=None):
    cv2.namedWindow(win_name, cv2.WINDOW_NORMAL)
    if wx is not None and wy is not None:
        cv2.resizeWindow(win_name, wx, wy)
    cv2.imshow(win_name, img)
    cv2.waitKey(0)

