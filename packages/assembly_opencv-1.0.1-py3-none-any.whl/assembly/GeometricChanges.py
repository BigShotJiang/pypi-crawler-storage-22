import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
几何变化

输入：原始图
输出：原始图
'''

@class_description(
    title="几何变化",
    description="在图像上绘制轮廓，包括点，线，矩形，圆等基本图形",
    level=3
)
class GeometricChanges(object):

    @func_description(
        title="图像翻转",
        description="对图像进行水平或垂直翻转"
    )
    @staticmethod
    def flip_image(img, mode='horizontal'):
        """
        :name 图像翻转
        :param img: 原始图
        :param mode: 翻转模式，'horizontal'表示水平翻转，'vertical'表示垂直翻转
        :return img: 翻转后的图像
        """
        if mode == 'horizontal':
            img_flipped = cv2.flip(img, 1)
        elif mode == 'vertical':
            img_flipped = cv2.flip(img, 0)
        else:
            raise ValueError("Invalid mode. Use 'horizontal' or 'vertical'.")

        return img_flipped

    @func_description(
        title="图像旋转",
        description="对图像进行旋转"
    )
    @staticmethod
    def rotate_image(img, angle):
        """
        :name 图像旋转
        :param img: 原始图
        :param angle: 旋转角度，正值表示逆时针旋转，负值表示顺时针旋转
        :return img: 旋转后的图像
        """
        (h, w) = img.shape[:2]
        center = (w // 2, h // 2)

        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        img_rotated = cv2.warpAffine(img, M, (w, h))

        return img_rotated

    @func_description(
        title="图像缩放",
        description="对图像进行缩放"
    )
    @staticmethod
    def scale_image(img, scale_x, scale_y):
        """
        :name 图像缩放
        :param img: 原始图
        :param scale_x: 水平缩放因子
        :param scale_y: 垂直缩放因子
        :return img: 缩放后的图像
        """
        img_scaled = cv2.resize(img, None, fx=scale_x, fy=scale_y, interpolation=cv2.INTER_LINEAR)
        return img_scaled

    @func_description(
        title="图像裁剪",
        description="对图像进行裁剪"
    )
    @staticmethod
    def crop_image(img, x, y, width, height):
        """
        :name 图像裁剪
        :param img: 原始图
        :param x: 裁剪区域左上角x坐标
        :param y: 裁剪区域左上角y坐标
        :param width: 裁剪区域宽度
        :param height: 裁剪区域高度
        :return img: 裁剪后的图像
        """
        img_cropped = img[y:y+height, x:x+width]
        return img_cropped

    @func_description(
        title="图像透视变换",
        description="将图像从一个视平面投影到另一个视平面的几何变换，用于解决图像的透视畸变问题（如近大远小的视觉效果），或实现视角转换（如从倾斜图像恢复正视图）"
    )
    @staticmethod
    def perspective_transform(img, src_points, dst_points):
        """
        :name 图像透视变换
        :param img: 原始图
        :param src_points: 源点坐标，形如[[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
        :param dst_points: 目标点坐标，形如[[x1', y1'], [x2', y2'], [x3', y3'], [x4', y4']]
        :return img: 透视变换后的图像
        """
        src_pts = np.array(src_points, dtype=np.float32)
        dst_pts = np.array(dst_points, dtype=np.float32)

        M = cv2.getPerspectiveTransform(src_pts, dst_pts)
        (h, w) = img.shape[:2]
        img_transformed = cv2.warpPerspective(img, M, (w, h))

        return img_transformed

    @func_description(
        title="图像仿射变换",
        description="仿射变换也称仿射投影，是指几何中，对一个向量空间进行线性变换并接上一个平移，变换为另一个向量空间"
    )
    @staticmethod
    def wrap_affine(img, src_points, dst_points):
        """
        :name 图像仿射变换
        :param img: 原始图
        :param src_points: 源点坐标，形如[[x1, y1], [x2, y2], [x3, y3]]
        :param dst_points: 目标点坐标，形如[[x1', y1'], [x2', y2'], [x3', y3']]
        :return img: 仿射变换后的图像
        """
        src_pts = np.array(src_points, dtype=np.float32)
        dst_pts = np.array(dst_points, dtype=np.float32)

        M = cv2.getAffineTransform(src_pts, dst_pts)
        (h, w) = img.shape[:2]
        img_transformed = cv2.warpAffine(img, M, (w, h))

        return img_transformed

# 暴露方法
def flip_image(img, mode='horizontal'):
    return GeometricChanges.flip_image(img, mode)

def rotate_image(img, angle):
    return GeometricChanges.rotate_image(img, angle)

def scale_image(img, scale_x, scale_y):
    return GeometricChanges.scale_image(img, scale_x, scale_y)

def crop_image(img, x, y, width, height):
    return GeometricChanges.crop_image(img, x, y, width, height)

def perspective_transform(img, src_points, dst_points):
    return GeometricChanges.perspective_transform(img, src_points, dst_points)

def wrap_affine(img, src_points, dst_points):
    return GeometricChanges.wrap_affine(img, src_points, dst_points)



if __name__ == '__main__':
    geo = GeometricChanges()
    img = cv2.imdecode(np.fromfile(r"D:\新能源\2025-08\top\20250827165052_186_32_1(1).jpg", dtype=np.uint8),
                       cv2.IMREAD_COLOR)
    show_image("img", img)

    trans_img = geo.wrap_affine(img, [[100,100],[200,100],[100,200]], [[150,150],[250,150],[150,250]])
    show_image("wrap_affine",trans_img)
    trans_img = geo.perspective_transform(img, [[100,100],[200,100],[100,200],[200,200]], [[150,150],[250,150],[150,250],[250,250]])
    show_image("perspective_transform",trans_img)