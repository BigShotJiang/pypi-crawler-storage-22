import cv2
import numpy as np

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
图像增强

输入：任意图像
输出：任意图像
'''


@class_description(
    title="图像增强",
    description="图像增强是指对图像进行各种增强处理，以提升图像的视觉效果。",
    level=5
)
class ImageEnhance(object):

    @func_description(
        title="亮度/对比度调整",
        description="通过调整图像的亮度，使得图像更加鲜艳，适用彩色/灰色图像"
    )
    @staticmethod
    def enhance_brightness(img, alpha=1.0, beta=0.0):
        """
        :name 亮度/对比度调整
        :param img: 多通道图
        :param alpha: 亮度调节因子
        :param beta: 亮度偏移量
        :return img: 多通道图
        """
        return cv2.convertScaleAbs(img, alpha=alpha, beta=beta)

    @func_description(
        title="伽马校正",
        description="通过对图像进行非线性拉伸，使得图像的对比度更加均匀，适用彩色/灰色图像"
    )
    @staticmethod
    def enhance_gamma_correction(img, gamma=1.0):
        """
        :name 伽马校正
        :param img: 多通道图
        :param gamma: 伽马值
        :return img: 多通道图
        """
        inv_gamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
        return cv2.LUT(img, table)

    @func_description(
        title="均值滤波",
        description="通过减少图像中的噪声，使得图像更加平滑，适用彩色/灰色图像"
    )
    @staticmethod
    def enhance_smoothing(img, kernel_size=3):
        """
        :name 均值滤波
        :param img: 多通道图
        :param kernel_size: 卷积核大小，必须为奇数
        :return img: 多通道图
        """
        if kernel_size % 2 == 0:
            kernel_size += 1
        return cv2.blur(img, (kernel_size, kernel_size))

    @func_description(
        title="高斯滤波",
        description="通过对图像进行平滑，使得图像更加平滑，适用彩色/灰色图像"
    )
    @staticmethod
    def enhance_gaussian_filtering(img, kernel_size=3, sigma=0):
        """
        :name 高斯滤波
        :param img: 多通道图
        :param kernel_size: 卷积核大小，必须为奇数
        :param sigma: 标准差
        :return img: 多通道图
        """
        if kernel_size % 2 == 0:
            kernel_size += 1
        return cv2.GaussianBlur(img, (kernel_size, kernel_size), sigma)

    @func_description(
        title="中值滤波",
        description="通过减少图像中的椒盐噪声，使得图像更加平滑，适用彩色/灰色图像"
    )
    @staticmethod
    def enhance_median_filtering(img, kernel_size=3):
        """
        :name 中值滤波
        :param img: 多通道图
        :param kernel_size: 卷积核大小，必须为奇数
        :return img: 多通道图
        """
        if kernel_size % 2 == 0:
            kernel_size += 1
        return cv2.medianBlur(img, kernel_size)

    @func_description(
        title="双边滤波",
        description="通过在平滑图像的同时保留边缘信息，使得图像更加清晰，适用彩色/灰色图像"
    )
    @staticmethod
    def enhance_bilateral_filtering(img, d=9, sigma_color=75, sigma_space=75):
        """
        :name 双边滤波
        :param img: 多通道图
        :param d: 领域直径
        :param sigma_color: 颜色空间标准差
        :param sigma_space: 坐标空间标准差
        :return img: 多通道图
        """
        return cv2.bilateralFilter(img, d, sigma_color, sigma_space)

    @func_description(
        title="锐化",
        description="通过增强图像的边缘信息，使得图像更加清晰，适用彩色/灰色图像"
    )
    @staticmethod
    def enhance_sharpening(img, kernel_size=3):
        """
        :name 锐化
        :param img: 多通道图
        :param kernel_size: 卷积核大小，必须为奇数
        :return img: 多通道图
        """
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
        if kernel_size % 2 == 0:
            kernel_size += 1
        return cv2.filter2D(img, -1, kernel, borderType=cv2.BORDER_REPLICATE)

    @func_description(
        title="拉普拉斯增强",
        description="通过对图像进行非线性拉伸，使得图像的对比度更加均匀，适用于灰度图像"
    )
    @staticmethod
    def enhance_laplacian_enhancement(gray, kernel_size=3):
        """
        :name 拉普拉斯增强
        :param gray: 单通道图
        :param kernel_size: 卷积核大小，必须为奇数
        :return gray: 单通道图
        """
        if kernel_size % 2 == 0:
            kernel_size += 1
        return cv2.Laplacian(gray, cv2.CV_64F, ksize=kernel_size)

    @func_description(
        title="直方图均衡化",
        description="通过调整图像的对比度来增强图像的视觉效果，适用于灰度图像"
    )
    @staticmethod
    def enhance_histogram_equalization(gray):
        """
        :name 直方图均衡化
        :param gray: 单通道图
        :return gray: 单通道图
        """
        equalized = cv2.equalizeHist(gray)
        return equalized

    @func_description(
        title="CLAHE(自适应直方图均衡化):",
        description="通过对图像进行自适应直方图均衡化，可以增强图像的对比度和亮度，适用于灰度图像"
    )
    @staticmethod
    def enhance_adaptive_histogram_equalization(gray, clip_limit=2.0, tile_size=(8, 8)):
        """
        :name CLAHE(自适应直方图均衡化)
        :param gray: 单通道图
        :param clip_limit: 裁剪限值
        :param tile_size: 块大小
        :return gray: 单通道图
        """
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_size)
        return clahe.apply(gray)


# 暴露方法
def enhance_brightness(img, alpha=1.5, beta=0):
    return ImageEnhance.enhance_brightness(img, alpha, beta)

def enhance_gamma_correction(img, gamma=1.5):
    return ImageEnhance.enhance_gamma_correction(img, gamma)

def enhance_smoothing(img, kernel_size=3):
    return ImageEnhance.enhance_smoothing(img, kernel_size)

def enhance_gaussian_filtering(img, kernel_size=3, sigma=0):
    return ImageEnhance.enhance_gaussian_filtering(img, kernel_size, sigma)

def enhance_median_filtering(img, kernel_size=3):
    return ImageEnhance.enhance_median_filtering(img, kernel_size)

def enhance_bilateral_filtering(img, d=9, sigma_color=75, sigma_space=75):
    return ImageEnhance.enhance_bilateral_filtering(img, d, sigma_color, sigma_space)

def enhance_sharpening(img, kernel_size=3):
    return ImageEnhance.enhance_sharpening(img, kernel_size)

def enhance_laplacian_enhancement(img, kernel_size=3):
    return ImageEnhance.enhance_laplacian_enhancement(img, kernel_size)

def enhance_histogram_equalization(img):
    return ImageEnhance.enhance_histogram_equalization(img)

def enhance_adaptive_histogram_equalization(img, clip_limit=2.0, tile_size=(8, 8)):
    return ImageEnhance.enhance_adaptive_histogram_equalization(img, clip_limit, tile_size)



if __name__ == '__main__':
    image_enhance = ImageEnhance()
    img = cv2.imdecode(np.fromfile(r"D:\新能源\2025-08\top\20250827165052_186_32_1(1).jpg", dtype=np.uint8),
                       cv2.IMREAD_COLOR)

    show_image("gray_img", img)
    enhanced_img = image_enhance.enhance_brightness(img, alpha=1.5, beta=0)
    show_image("enhance_brightness", enhanced_img)
    enhanced_img = image_enhance.enhance_gamma_correction(img, gamma=1.5)
    show_image("enhance_gamma_correction", enhanced_img)
    enhanced_img = image_enhance.enhance_laplacian_enhancement(img, kernel_size=3)
    show_image("enhance_laplacian_enhancement", enhanced_img)
    enhanced_img = image_enhance.enhance_smoothing(img, kernel_size=3)
    show_image("enhance_smoothing", enhanced_img)
    enhanced_img = image_enhance.enhance_gaussian_filtering(img, kernel_size=3, sigma=0)
    show_image("enhance_gaussian_filtering", enhanced_img)
    enhanced_img = image_enhance.enhance_median_filtering(img, kernel_size=3)
    show_image("enhance_median_filtering", enhanced_img)
    enhanced_img = image_enhance.enhance_bilateral_filtering(gray_img, d=9, sigma_color=75, sigma_space=75)
    show_image("enhance_bilateral_filtering", enhanced_img)
    enhanced_img = image_enhance.enhance_sharpening(img, kernel_size=3)
    show_image("enhance_sharpening", enhanced_img)

    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    enhanced_img = image_enhance.enhance_histogram_equalization(gray_img)
    show_image("enhance_histogram_equalization", enhanced_img)
    enhanced_img = image_enhance.enhance_adaptive_histogram_equalization(gray_img)
    show_image("enhance_adaptive_histogram_equalization", enhanced_img)
