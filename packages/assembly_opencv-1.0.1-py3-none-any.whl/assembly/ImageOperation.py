import cv2
import numpy as np

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
图像运算

输入：原始图
输出：原始图
'''


@class_description(
    title="图像运算",
    description="图像运算主要是指对图像进行各种数学运算以实现图像的增强、变换和分析等功能。",
    level=6
)
class ImageOperation(object):

    @func_description(
        title="加法运算",
        description="实现饱和加法（结果超过255时截断为255）"
    )
    @staticmethod
    def image_add(img1, img2):
        """
        :name 加法运算
        :param img1: 原始图1
        :param img2: 原始图2
        :return: img: 加法运算后的图像
        """
        img_added = cv2.add(img1, img2)
        return img_added

    @func_description(
        title="减法运算",
        description="实现饱和减法（结果小于0时截断为0）"
    )
    @staticmethod
    def image_subtract(img1, img2):
        """
        :name 减法运算
        :param img1: 原始图1
        :param img2: 原始图2
        :return: img: 减法运算后的图像
        """
        img_subtracted = cv2.subtract(img1, img2)
        return img_subtracted

    @func_description(
        title="乘法运算",
        description="对两个图像的每个像素进行逐元素乘法操作,增强对比度"
    )
    @staticmethod
    def image_multiply(img1, img2):
        """
        :name 乘法运算
        :param img1: 原始图1
        :param img2: 原始图2
        :return: img: 乘法运算后的图像
        """
        img_multiplied = cv2.multiply(img1, img2)
        return img_multiplied

    @func_description(
        title="除法运算",
        description="对两个图像的每个像素进行逐元素除法操作,用于光照归一化"
    )
    @staticmethod
    def image_divide(img1, img2):
        """
        :name 除法运算
        :param img1: 原始图1
        :param img2: 原始图2
        :return: img: 除法运算后的图像
        """
        img_divided = cv2.divide(img1, img2)
        return img_divided

    @func_description(
        title="按位与运算",
        description="对两个图像的每个像素进行按位与操作"
    )
    @staticmethod
    def image_bitwise_and(img1, img2):
        """
        :name 按位与运算
        :param img1: 原始图1
        :param img2: 原始图2
        :return: img: 按位与运算后的图像
        """
        img_and = cv2.bitwise_and(img1, img2)
        return img_and

    @func_description(
        title="按位或运算",
        description="对两个图像的每个像素进行按位或操作"
    )
    @staticmethod
    def image_bitwise_or(img1, img2):
        """
        :name 按位或运算
        :param img1: 原始图1
        :param img2: 原始图2
        :return: img: 按位或运算后的图像
        """
        img_or = cv2.bitwise_or(img1, img2)
        return img_or

    @func_description(
        title="按位异或运算",
        description="对两个图像的每个像素进行按位异或操作"
    )
    @staticmethod
    def image_bitwise_xor(img1, img2):
        """
        :name 按位异或运算
        :param img1: 原始图1
        :param img2: 原始图2
        :return: img: 按位异或运算后的图像
        """
        img_xor = cv2.bitwise_xor(img1, img2)
        return img_xor

    @func_description(
        title="按位非运算",
        description="对图像的每个像素进行按位非操作"
    )
    @staticmethod
    def image_bitwise_not(img):
        """
        :name 按位非运算
        :param img: 原始图
        :return: img: 按位非运算后的图像
        """
        img_not = cv2.bitwise_not(img)
        return img_not

    @func_description(
        title="图像加权混合",
        description="通过加权平均的方式将两幅图像混合在一起"
    )   
    @staticmethod
    def image_blend(img1, img2, alpha=0.5, beta=0.5, gamma=0):
        """
        :name 图像加权混合
        :param img1: 原始图1
        :param img2: 原始图2
        :param alpha: 图像1的权重
        :param beta: 图像2的权重
        :param gamma: 标量值，添加到每个和中
        :return: img: 混合后的图像
        """
        img_blended = cv2.addWeighted(img1, alpha, img2, beta, gamma)
        return img_blended

# 暴露方法
def image_add(img1, img2):
    return ImageOperation.image_add(img1, img2)

def image_subtract(img1, img2):
    return ImageOperation.image_subtract(img1, img2)

def image_multiply(img1, img2):
    return ImageOperation.image_multiply(img1, img2)

def image_divide(img1, img2):
    return ImageOperation.image_divide(img1, img2)

def image_bitwise_and(img1, img2):
    return ImageOperation.image_bitwise_and(img1, img2)

def image_bitwise_or(img1, img2):
    return ImageOperation.image_bitwise_or(img1, img2)

def image_bitwise_xor(img1, img2):
    return ImageOperation.image_bitwise_xor(img1, img2)

def image_bitwise_not(img):
    return ImageOperation.image_bitwise_not(img)
    
def image_blend(img1, img2, alpha=0.5, beta=0.5, gamma=0):
    return ImageOperation.image_blend(img1, img2, alpha, beta, gamma)
    