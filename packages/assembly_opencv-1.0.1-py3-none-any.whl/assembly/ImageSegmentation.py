import cv2
import numpy as np

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
图像分割

输入：单通道图像 & 原始图
输出：二值化图像
'''


@class_description(
    title="图像分割",
    description="图像分割主要是指将图像分成各具特性的区域并提取出感兴趣目标的技术。",
    level=7
)
class ImageSegmentation(object):

    @func_description(
        title="RGB阈值分割",
        description="通过指定的RGB阈值范围将图像分割为前景和背景"
    )
    @staticmethod
    def rgb_threshold(img, lower_bound=(0, 0, 0), upper_bound=(255, 255, 255)):
        """
        :name RGB阈值分割
        :param img: 原始图
        :param lower_bound: bgr下限
        :param upper_bound: bgr上限
        :return: binary: 二值化图
        """
        mask = cv2.inRange(img, np.array(lower_bound), np.array(upper_bound))
        return mask

    @func_description(
        title="HSV阈值分割",
        description="通过指定的HSV阈值范围将图像分割为前景和背景"
    )
    @staticmethod
    def hsv_threshold(img, lower_bound=(0, 0, 0), upper_bound=(179, 255, 255)):
        """
        :name HSV阈值分割
        :param img: 原始图
        :param lower_bound: hsv下限
        :param upper_bound: hsv上限
        :return: binary: 二值化图
        """
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        mask = cv2.inRange(hsv, np.array(lower_bound), np.array(upper_bound))
        return mask

    @func_description(
        title="固定阈值分割",
        description="通过指定的阈值范围将图像分割为前景和背景"
    )
    @staticmethod
    def normal_threshold(gray, thresh, maxval=255, is_inv=False):
        """
        :name 固定阈值分割
        :param gray: 单通道图
        :param thresh: 阈值
        :param maxval: 满足阈值赋予的新值
        :param is_inv: 阈值类型，默认 False cv2.THRESH_BINARY，True为 cv2.THRESH_BINARY_INV
        :return: binary: 二值化图
        """
        if is_inv:
            THRESH_TYPE = cv2.THRESH_BINARY_INV
        else:
            THRESH_TYPE = cv2.THRESH_BINARY
        retval, binary = cv2.threshold(gray, thresh, maxval, THRESH_TYPE)
        return binary

    @func_description(
        title="Otsu阈值分割",
        description="通过分析图像的灰度直方图自动计算全局阈值，将图像分割为前景和背景"
    )
    @staticmethod
    def otsu_threshold(gray, maxval=255, is_inv=False):
        """
        :name Otsu阈值分割
        :param gray: 单通道图
        :param maxval: 满足阈值赋予的新值
        :param is_inv: 阈值类型，默认 False cv2.THRESH_BINARY，True为 cv2.THRESH_BINARY_INV
        :return: binary: 二值化图
        """
        if is_inv:
            THRESH_TYPE = cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
        else:
            THRESH_TYPE = cv2.THRESH_BINARY + cv2.THRESH_OTSU
        retval, binary = cv2.threshold(gray, 0, maxval, THRESH_TYPE)
        return binary

    @func_description(
        title="自适应阈值分割",
        description="根据图像局部区域的灰度变化自动计算阈值，将图像分割为前景和背景"
    )   
    @staticmethod
    def adaptive_threshold(gray, maxval=255, method=cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                           is_inv=False, block_size=11, C=2):
        """
        :name 自适应阈值分割
        :param gray: 单通道图
        :param maxval: 满足阈值赋予的新值
        :param method: 计算阈值的方法，默认 cv2.ADAPTIVE_THRESH_GAUSSIAN_C，可选 cv2.ADAPTIVE_THRESH_MEAN_C
        :param is_inv: 阈值类型，默认 False cv2.THRESH_BINARY，True为 cv2.THRESH_BINARY_INV
        :param block_size: 计算阈值的邻域大小，必须为奇数
        :param C: 从计算得到的阈值中减去的常数
        :return: binary: 二值化图
        """
        if is_inv:
            THRESH_TYPE = cv2.THRESH_BINARY_INV
        else:
            THRESH_TYPE = cv2.THRESH_BINARY
        if block_size % 2 == 0:
            raise ValueError("block_size must be an odd number")
        binary = cv2.adaptiveThreshold(gray, maxval, method, THRESH_TYPE, block_size, C)
        return binary

    @func_description(
        title="漫水填充分割",
        description="通过从种子点开始扩展区域，将图像分割为不同的区域"
    )
    @staticmethod
    def flood_fill(gray, seed_point, new_val, lo_diff=5, up_diff=5, flags=4):
        """
        :name 漫水填充分割
        :param gray: 单通道图
        :param seed_point: 种子点，格式为 (x, y)
        :param new_val: 新值，格式为 (B, G, R)
        :param lo_diff: 低差分，表示允许的颜色变化范围
        :param up_diff: 高差分，表示允许的颜色变化范围
        :param flags: 漫水填充的连接方式，默认 4，可选 8
        :return: binary: 二值化图
        """
        img_copy = gray.copy()
        h, w = img_copy.shape[:2]
        mask = np.zeros((h + 2, w + 2), np.uint8)
        num_filled_pixels, image, mask, rect = cv2.floodFill(img_copy, mask, seed_point, new_val, (lo_diff,),
                                                             (up_diff,), flags)
        # 裁剪掩膜（去除边缘的多余像素）
        binary_mask = mask[1:-1, 1:-1]  # 得到(h, w)尺寸的掩膜
        # 生成二值图：填充区=黑色(0)，其余=白色(255)
        binary_result = np.where(binary_mask > 0, 0, 255).astype(np.uint8)
        return binary_result


# 暴露方法
def rgb_threshold(img, lower_bound=(0, 0, 0), upper_bound=(255, 255, 255)):
    return ImageSegmentation.rgb_threshold(img, lower_bound, upper_bound)

def hsv_threshold(img, lower_bound=(0, 0, 0), upper_bound=(179, 255, 255)):
    return ImageSegmentation.hsv_threshold(img, lower_bound, upper_bound)

def normal_threshold(gray, thresh, maxval=255, is_inv=False):
    return ImageSegmentation.normal_threshold(gray, thresh, maxval, is_inv)

def otsu_threshold(gray, maxval=255, is_inv=False):
    return ImageSegmentation.otsu_threshold(gray, maxval, is_inv)

def adaptive_threshold(gray, maxval=255, method=cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                           is_inv=False, block_size=11, C=2):
    return ImageSegmentation.adaptive_threshold(gray, maxval, method, is_inv, block_size, C)

def flood_fill(gray, seed_point, new_val, lo_diff=5, up_diff=5, flags=4):
    return ImageSegmentation.flood_fill(gray, seed_point, new_val, lo_diff, up_diff, flags)



if __name__ == '__main__':
    image_segment = ImageSegmentation()
    img = cv2.imdecode(np.fromfile(r"C:\Users\GT-LAPTOP-043\Downloads\test.jpg", dtype=np.uint8),
                       cv2.IMREAD_COLOR)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    show_image("gray_img", gray_img)
    binary_img = image_segment.rgb_threshold(img, lower_bound=[0, 0, 0], upper_bound=[100, 100, 100])
    show_image("rgb_threshold", binary_img)
    binary_img = image_segment.hsv_threshold(img, lower_bound=[0, 0, 0], upper_bound=[179, 255, 100])
    show_image("hsv_threshold", binary_img)
    binary_img = image_segment.normal_threshold(gray_img, 127, is_inv=True)
    show_image("normal_threshold", binary_img)
    binary_img = image_segment.otsu_threshold(gray_img, is_inv=True)
    show_image("otsu_threshold", binary_img)
    binary_img = image_segment.adaptive_threshold(gray_img, is_inv=True)
    show_image("adaptive_threshold", binary_img)
    binary_img = image_segment.flood_fill(gray_img, (50, 50), 255)
    show_image("flood_fill", binary_img)
