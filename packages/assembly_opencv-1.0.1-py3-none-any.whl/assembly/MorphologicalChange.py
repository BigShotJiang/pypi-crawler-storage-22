import cv2
import numpy as np

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
形态学变化

输入：二值化图
输出：二值化图
'''


@class_description(
    title="形态学变化",
    description="形态学变化是图像处理中常用的图像处理技术之一，它是对图像进行形态学操作的过程，包括腐蚀、膨胀、开运算、闭运算等。",
    level=4
)
class MorphologicalChange(object):

    @func_description(
        title="腐蚀操作",
        description="腐蚀操作会使图像中的前景物体变小，去除小的噪点，断开细小的连接"
    )
    @staticmethod
    def mlc_erode(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
        """
        :name 腐蚀操作
        :param binary: 二值化图
        :param kernel_size: 卷积核大小，必须为奇数
        :param kernel_type: 卷积核类型，默认矩形 cv2.MORPH_RECT, 可选 cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS
        :param iterations: 腐蚀次数
        :return binary: 二值化图
        """
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be an odd number")
        kernel = cv2.getStructuringElement(kernel_type, (kernel_size, kernel_size))
        eroded = cv2.erode(binary, kernel, iterations=iterations)
        return eroded

    @func_description(
        title="膨胀操作",
        description="膨胀操作会使图像中的前景物体变大，填充小的空白，连接物体上的小洞"
    )
    @staticmethod
    def mlc_dilate(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
        """
        :name 膨胀操作
        :param binary: 二值化图
        :param kernel_size: 卷积核大小，必须为奇数
        :param kernel_type: 卷积核类型，默认矩形 cv2.MORPH_RECT, 可选 cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS
        :param iterations: 膨胀次数
        :return binary: 二值化图
        """
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be an odd number")
        kernel = cv2.getStructuringElement(kernel_type, (kernel_size, kernel_size))
        dilated = cv2.dilate(binary, kernel, iterations=iterations)
        return dilated

    @func_description(
        title="开运算",
        description="先腐蚀后膨胀，去除小的噪点，断开细小的连接"
    )
    @staticmethod
    def mlc_open(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
        """
        :name 开运算
        :param binary: 二值化图
        :param kernel_size: 卷积核大小，必须为奇数
        :param kernel_type: 卷积核类型，默认矩形 cv2.MORPH_RECT, 可选 cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS
        :param iterations: 开操作次数
        :return binary: 二值化图
        """
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be an odd number")
        kernel = cv2.getStructuringElement(kernel_type, (kernel_size, kernel_size))
        opened = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=iterations)
        return opened

    @func_description(
        title="闭运算",
        description="先膨胀后腐蚀，填充小的空白，连接物体上的小洞"
    )
    @staticmethod
    def mlc_close(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
        """
        :name 闭运算
        :param binary: 二值化图
        :param kernel_size: 卷积核大小，必须为奇数
        :param kernel_type: 卷积核类型，默认矩形 cv2.MORPH_RECT, 可选 cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS
        :param iterations: 闭操作次数
        :return binary: 二值化图
        """
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be an odd number")
        kernel = cv2.getStructuringElement(kernel_type, (kernel_size, kernel_size))
        closed = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=iterations)
        return closed

    @func_description(
        title="形态学梯度",
        description="形态学梯度是图像的梯度，表示图像中前景物体与背景之间的差异"
    )
    @staticmethod
    def mlc_gradient(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
        """
        :name 形态学梯度
        :param binary: 二值化图
        :param kernel_size: 卷积核大小，必须为奇数
        :param kernel_type: 卷积核类型，默认矩形 cv2.MORPH_RECT, 可选 cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS
        :param iterations: 形态学梯度次数
        :return binary: 二值化图
        """
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be an odd number")
        kernel = cv2.getStructuringElement(kernel_type, (kernel_size, kernel_size))
        gradient = cv2.morphologyEx(binary, cv2.MORPH_GRADIENT, kernel, iterations=iterations)
        return gradient

    @func_description(
        title="顶帽操作",
        description="顶帽操作是原始图像与开操作结果之间的差异，突出图像中的小亮区域"
    )
    @staticmethod
    def mlc_top_hat(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
        """
        :name 顶帽操作
        :param binary: 二值化图
        :param kernel_size: 卷积核大小，必须为奇数
        :param kernel_type: 卷积核类型，默认矩形 cv2.MORPH_RECT, 可选 cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS
        :param iterations: 顶帽操作次数
        :return img:顶帽操作后的图像
        """
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be an odd number")
        kernel = cv2.getStructuringElement(kernel_type, (kernel_size, kernel_size))
        tophat = cv2.morphologyEx(binary, cv2.MORPH_TOPHAT, kernel, iterations=iterations)
        return tophat

    @func_description(
        title="黑帽操作",
        description="黑帽操作是闭操作结果与原始图像之间的差异，突出图像中的小暗区域"
    )
    @staticmethod
    def mlc_black_hat(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
        """
        :name 黑帽操作
        :param binary: 二值化图
        :param kernel_size: 卷积核大小，必须为奇数
        :param kernel_type: 卷积核类型，默认矩形 cv2.MORPH_RECT, 可选 cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS
        :param iterations: 黑帽操作次数
        :return binary: 二值化图
        """
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be an odd number")
        kernel = cv2.getStructuringElement(kernel_type, (kernel_size, kernel_size))
        blackhat = cv2.morphologyEx(binary, cv2.MORPH_BLACKHAT, kernel, iterations=iterations)
        return blackhat

    @func_description(
        title="骨架化",
        description="骨架化是将图像中连通区域的边界线去除，使图像变成一个单一的轮廓线"
    )
    @staticmethod
    def mlc_skeletonize(binary):
        """
        :name 骨架化
        :param binary: 二值化图
        :return binary: 二值化图
        """
        skeleton = cv2.ximgproc.thinning(binary)
        return skeleton


# 暴露方法

def mlc_erode(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
    return MorphologicalChange.mlc_erode(binary, kernel_size, kernel_type, iterations)

def mlc_dilate(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
    return MorphologicalChange.mlc_dilate(binary, kernel_size, kernel_type, iterations)

def mlc_open(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
    return MorphologicalChange.mlc_open(binary, kernel_size, kernel_type, iterations)

def mlc_close(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
    return MorphologicalChange.mlc_close(binary, kernel_size, kernel_type, iterations)

def mlc_gradient(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
    return MorphologicalChange.mlc_gradient(binary, kernel_size, kernel_type, iterations)

def mlc_top_hat(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
    return MorphologicalChange.mlc_top_hat(binary, kernel_size, kernel_type, iterations)

def mlc_black_hat(binary, kernel_size=3, kernel_type=cv2.MORPH_RECT, iterations=1):
    return MorphologicalChange.mlc_black_hat(binary, kernel_size, kernel_type, iterations)

def mlc_skeletonize(binary):
    return MorphologicalChange.mlc_skeletonize(binary)


if __name__ == '__main__':
    morphological_change = MorphologicalChange()
    img = cv2.imdecode(np.fromfile(r"C:\Users\GT-LAPTOP-043\Downloads\黑白格.jpg", dtype=np.uint8),
                       cv2.IMREAD_COLOR)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, gray_img = cv2.threshold(gray_img, 127, 255, cv2.THRESH_BINARY_INV, gray_img)

    show_image("gray_img", gray_img, 500, 500)
    show_image("mlc_erode", morphological_change.mlc_erode(gray_img), 500, 500)
    show_image("mlc_dilate", morphological_change.mlc_dilate(gray_img), 500, 500)
    show_image("mlc_open", morphological_change.mlc_open(gray_img), 500, 500)
    show_image("mlc_close", morphological_change.mlc_close(gray_img), 500, 500)
    show_image("mlc_gradient", morphological_change.mlc_gradient(gray_img), 500, 500)
    show_image("mlc_top_hat", morphological_change.mlc_top_hat(gray_img), 500, 500)
    show_image("mlc_black_hat", morphological_change.mlc_black_hat(gray_img), 500, 500)
    show_image("mlc_skeletonize", morphological_change.mlc_skeletonize(gray_img), 500, 500)

    cv2.destroyAllWindows()
