import cv2
import numpy as np
from shapely import Polygon

from assembly.description.Decoration import func_description, class_description
from assembly.GeneralUtil import show_image

'''
轮廓运算

输入：轮廓矩阵
输出：轮廓矩阵
'''


@class_description(
    title="轮廓运算",
    description="轮廓运算主要是指对轮廓进行各种数学运算以实现轮廓的增强、变换和分析等功能。",
    level=10
)
class PolygonOperation(object):

    @func_description(
        title="轮廓平移",
        description="对轮廓进行平移操作"
    )
    @staticmethod
    def polygon_translate(contour, tx, ty):
        """
        :name 轮廓平移
        :param contour: 轮廓矩阵
        :param tx: x方向平移距离
        :param ty: y方向平移距离
        :return contour: 平移后的轮廓矩阵
        """
        M = np.array([[1, 0, tx], [0, 1, ty]], dtype=np.float32)
        contour_translated = cv2.transform(contour, M)
        return contour_translated

    @func_description(
        title="轮廓旋转",
        description="对轮廓进行旋转操作"
    )  
    @staticmethod
    def polygon_rotate(contour, angle, center=None):
        """
        :name 轮廓旋转
        :param contour: 轮廓矩阵
        :param angle: 旋转角度，正值表示逆时针旋转，负值表示顺时针旋转
        :param center: 旋转中心点，默认None表示以轮廓的质心为中心
        :return contour: 旋转后的轮廓矩阵
        """
        if center is None:
            M = cv2.moments(contour)
            if M["m00"] != 0:
                center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
            else:
                center = (0, 0)

        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        contour_rotated = cv2.transform(contour, M)
        return contour_rotated

    @func_description(
        title="轮廓缩放",
        description="对轮廓进行缩放操作"
    )
    @staticmethod
    def polygon_scale(contour, scale_x, scale_y, center=None):
        """
        :name 轮廓缩放
        :param contour: 轮廓矩阵
        :param scale_x: x方向缩放因子
        :param scale_y: y方向缩放因子
        :param center: 缩放中心点，默认None表示以轮廓的质心为中心
        :return contour: 缩放后的轮廓矩阵
        """
        if center is None:
            M = cv2.moments(contour)
            if M["m00"] != 0:
                center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
            else:
                center = (0, 0)

        M = np.array([[scale_x, 0, (1 - scale_x) * center[0]],
                      [0, scale_y, (1 - scale_y) * center[1]]], dtype=np.float32)
        contour_scaled = cv2.transform(contour, M)
        return contour_scaled

    @func_description(
        title="轮廓取交集",
        description="计算两个轮廓的交集区域"
    )
    @staticmethod
    def contours_intersect(contour1, contour2, buffer=0):
        """
        :name 轮廓取交集
        :param contour1: 轮廓矩阵1
        :param contour2: 轮廓矩阵2
        :param buffer: 扩展轮廓 >0外扩 <0内缩
        :return intersect: 布尔值，表示是否相交
        """
        poly1 = Polygon(contour1)
        if buffer != 0:
            poly1 = poly1.buffer(buffer)

        poly2 = Polygon(contour2)
        if buffer != 0:
            poly2 = poly2.buffer(buffer)

        if not poly1.is_valid:
            poly1 = poly1.buffer(0)
        if not poly2.is_valid:
            poly2 = poly2.buffer(0)

        if poly1.intersects(poly2):
            intersect_poly = poly1.intersection(poly2)
            intersect = self.shapely_poly_to_cv(intersect_poly)
        else:
            intersect = []

        return intersect

    @func_description(
        title="轮廓取差集",
        description="计算两个轮廓的差集区域"
    )
    @staticmethod
    def contours_difference(contour1, contour2, buffer=0):
        """
        :name 轮廓取差集
        :param contour1: 轮廓矩阵1
        :param contour2: 轮廓矩阵2
        :param buffer: 扩展轮廓 >0外扩 <0内缩
        :return difference_contour: 差集轮廓矩阵
        """
        poly1 = Polygon(contour1)
        if buffer != 0:
            poly1 = poly1.buffer(buffer)

        poly2 = Polygon(contour2)
        if buffer != 0:
            poly2 = poly2.buffer(buffer)

        if not poly1.is_valid:
            poly1 = poly1.buffer(0)
        if not poly2.is_valid:
            poly2 = poly2.buffer(0)

        if poly1.intersects(poly2):
            difference_poly = poly1.difference(poly2)
            difference = self.shapely_poly_to_cv(difference_poly)
        else:
            difference = []

        return difference

    @func_description(
        title="轮廓取并集",
        description="计算两个轮廓的并集区域"
    )
    @staticmethod
    def contours_union(contour1, contour2, buffer=0):
        """
        :name 轮廓取并集
        :param contour1: 轮廓矩阵1
        :param contour2: 轮廓矩阵2
        :param buffer: 扩展轮廓 >0外扩 <0内缩
        :return union_contour: 并集轮廓矩阵
        """
        poly1 = Polygon(contour1)
        if buffer != 0:
            poly1 = poly1.buffer(buffer)

        poly2 = Polygon(contour2)
        if buffer != 0:
            poly2 = poly2.buffer(buffer)

        if not poly1.is_valid:
            poly1 = poly1.buffer(0)
        if not poly2.is_valid:
            poly2 = poly2.buffer(0)

        if poly1.intersects(poly2):
            union_poly = poly1.union(poly2)
            union = self.shapely_poly_to_cv(union_poly)
        else:
            union = []

        return union

    @func_description(
        title="轮廓交并比",
        description="计算两个轮廓的交并比"
    )
    @staticmethod
    def contours_iou(contour1, contour2, buffer=0):
        """
        :name 轮廓交并比
        :param contour1: 轮廓矩阵1
        :param contour2: 轮廓矩阵2
        :param buffer: 扩展轮廓 >0外扩 <0内缩
        :return iou: 交并比
        """
        poly1 = Polygon(contour1)
        if buffer != 0:
            poly1 = poly1.buffer(buffer)

        poly2 = Polygon(contour2)
        if buffer != 0:
            poly2 = poly2.buffer(buffer)

        if not poly1.is_valid:
            poly1 = poly1.buffer(0)
        if not poly2.is_valid:
            poly2 = poly2.buffer(0)

        if poly1.intersects(poly2):
            intersection = poly1.intersection(poly2)
            intersection_area = intersection.area

            union = poly1.union(poly2)

            return intersection_area / union.area
        else:
            return 0

    @func_description(
        title="轮廓绘制",
        description="在图像上绘制轮廓"
    )
    @staticmethod
    def draw_contours(img, contours, color=(0, 255, 0), thickness=2):
        """
        :name 轮廓绘制
        :param img: 原始图像
        :param contours: 轮廓矩阵或轮廓矩阵列表
        :param color: 轮廓颜色，默认为绿色
        :param thickness: 轮廓线条粗细，默认为2
        :return img_with_contours: 绘制轮廓后的图像
        """

        if img is not None:
            img_with_contours = img.copy()
        else:
            contour_width = contours[:, :, 0].max() - contours[:, :, 0].min() + 10
            contour_height = contours[:, :, 1].max() - contours[:, :, 1].min() + 10
            img_with_contours = np.zeros((contour_height, contour_width, 3), dtype=np.uint8)
        if isinstance(contours, list):
            cv2.drawContours(img_with_contours, contours, -1, color, thickness)
        else:
            cv2.drawContours(img_with_contours, [contours], -1, color, thickness)
        return img_with_contours

    # OpenCV多边形 -> Shapely多边形
    @staticmethod
    def cv_poly_to_shapely(cv_poly):
        # 将点从OpenCV格式（float32）转换为整数格式
        points = np.round(cv_poly.reshape(-1, 1, 2)).astype(np.int)
        return Polygon(points)

    # Shapely多边形 -> OpenCV多边形
    @staticmethod
    def shapely_poly_to_cv(shapely_poly):
        # 提取Shapely多边形的顶点
        vertices = np.array(shapely_poly.exterior.coords)
        # 转换为float32类型
        return vertices.astype(int)


# 暴露方法
def polygon_translate(contour, tx, ty):
    return PolygonOperation.polygon_translate(contour, tx, ty)

def polygon_rotate(contour, angle, center=None):
    return PolygonOperation.polygon_rotate(contour, angle, center)

def polygon_scale(contour, scale_factor, center=None):
    return PolygonOperation.polygon_scale(contour, scale_factor, center)

def contours_intersect(contour1, contour2, buffer=0):
    return PolygonOperation.contours_intersect(contour1, contour2, buffer)

def contours_union(contour1, contour2, buffer=0):
    return PolygonOperation.contours_union(contour1, contour2, buffer)

def contours_difference(contour1, contour2, buffer=0):
    return PolygonOperation.contours_difference(contour1, contour2, buffer)

def contours_iou(contour1, contour2, buffer=0):
    return PolygonOperation.contours_iou(contour1, contour2, buffer)

def draw_contours(img, contours, color=(0, 255, 0), thickness=2):
    return PolygonOperation.draw_contours(img, contours, color, thickness)



if __name__ == '__main__':
    poly = PolygonOperation()
    polygon1 = [[100, 100], [200, 100], [200, 200], [100, 200]]
    polygon2 = [[150, 150], [300, 150], [300, 300], [150, 300]]

    img = np.zeros((400, 400, 3), dtype=np.uint8)
    img1 = poly.draw_contours(img, np.array(polygon1))
    img2 = poly.draw_contours(img, np.array(polygon2), color=(255, 0, 0))

    show_image("polygon1", img1)
    show_image("polygon2", img2)

    contours_intersect = poly.contours_intersect(np.array(polygon1), np.array(polygon2))
    img_contour = poly.draw_contours(img, np.array(contours_intersect))
    show_image("contours_intersect", img_contour)

    contours_union = poly.contours_union(np.array(polygon1), np.array(polygon2))
    img_contour = poly.draw_contours(img, np.array(contours_union))
    show_image("contours_union", img_contour)

    contours_difference = poly.contours_difference(np.array(polygon1), np.array(polygon2))
    img_contour = poly.draw_contours(img, np.array(contours_difference))
    show_image("contours_difference", img_contour)

    iou = poly.contours_iou(np.array(polygon1), np.array(polygon2))
    print("交并比：", iou)
