import json
import time
import traceback
from functools import wraps
import inspect
from Config import Gloab


def func_description(title: str = "", description: str = ""):
    """装饰器：为函数添加描述信息"""

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            print(f"Title: {title}")
            print(f"Description: {description}")
            print(f"Function: {func.__name__}")
            print(f"class: {func.__qualname__.split('.')[0]}")
            print(f"Args len: {len(args)}")
            print(f"Kwargs: {kwargs}")

            try:
                start_time = time.time()
                result = func(*args, **kwargs)
                end_time = time.time()
                print(f"Time elapsed: {end_time - start_time:.4f}s")

                return result
            except Exception as e:
                print(f"An error occurred in function '{traceback.format_exc()}")
                return None

        return wrapper

    return decorator


def class_description(title: str = "", description: str = "", level: int = 999):
    """装饰器：为类添加描述信息"""

    def decorator(cls):
        original_init = cls.__init__

        @wraps(original_init)
        def new_init(self, *args, **kwargs):

            menu_info = {"group_name": cls.__name__, "group_cn_name": title, "group_description": description,
                         "level": level,
                         "func_list": []}
            for item in list(cls.__dict__.keys()):
                if not item.startswith('__'):

                    func_info = {}
                    func = getattr(cls, item)
                    try:
                        source_code = inspect.getsource(func)
                        func_info["source_code"] = source_code
                    except Exception as e:
                        print(f"获取源码失败: {e}")
                        func_info["source_code"] = ""
                    # print(f"func_info: {func_info['source_code']}")
              
                    doc = func.__doc__
                    if doc:
                        if ":name" not in doc:
                            continue
                        docs = doc.split('\n')

                        for d in docs:
                            if ":name" in d:
                                func_info["func_name"] = item
                                func_info["func_cn_name"] = d.split(':name')[1].strip()
                                func_info["param_list"] = []
                            if ":param" in d:
                                params = d.split(':param')[1].strip().split(':')

                                param_name = params[0].strip() if params else ""
                                param_cn_name = params[1].strip() if len(
                                    params) >= 2 else param_name  # 不足时用 param_name 代替
                                param_type = params[2].strip() if len(params) >= 3 else ""
                                param_menu = params[3].strip() if len(params) >= 4 else []

                                func_info["param_list"].append(
                                    {"param_name": param_name, "param_cn_name": param_cn_name, "param_type": param_type,
                                     "param_menu": param_menu, "param_value": ""})
                            if ":return" in d:
                                results = d.split(':return')[1].strip().split(':')

                                if len(results) == 2:
                                    func_info["return_type"] = results[0].strip()
                                    func_info["return"] = results[1].strip()

                    menu_info["func_list"].append(func_info)

            Gloab.operator_menus.append(menu_info)
            try:
                start_time = time.time()
                original_init(self, *args, **kwargs)
                end_time = time.time()
                print(f"{cls.__name__} class init time elapsed: {end_time - start_time:.4f}s")
            except Exception as e:
                print(f"An error occurred in class '{cls.__name__}' initialization: {traceback.format_exc()}")

        cls.__init__ = new_init
        return cls

    return decorator
