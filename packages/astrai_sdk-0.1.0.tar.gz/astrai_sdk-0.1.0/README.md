# Astrai SDK

Drop-in cost, routing, and privacy control layer for AI agents. Compatible with OpenAI-style clients.

## Features
- `model="auto"` smart routing (server-side) or `privacy_mode="local"` to keep prompts on-device and route via BYOK.
- Per-agent budget headers and `_astrai_meta` tracing with costs, savings, and reasons.
- Lightweight local classifier for task type / complexity without sending content to Astrai.

## Quickstart
```python
from astrai import Astrai

client = Astrai(api_key="astrai_sk_...", privacy_mode="proxy")
resp = client.chat.completions.create(
    model="auto",
    messages=[{"role": "user", "content": "Classify: refund request"}],
)
print(resp.astrai.cost_usd, resp.astrai.routing_reason)
```

## Local privacy mode
```python
client = Astrai(
    privacy_mode="local",              # no prompt leaves your machine
    byok_keys={"openai": "sk-..."},  # provider keys for direct dispatch
    provider_endpoints={"openai": "https://api.openai.com/v1"},
)
resp = client.chat.completions.create(
    messages=[{"role": "user", "content": "Write a haiku about Saturn"}],
)
print(resp.astrai.model_used)
```

## Routing feedback (metadata only)
Report outcomes to improve routing without sharing content:
```python
# POST /v1/routing/feedback with your Astrai key
```

## License
Proprietary – see repository owner for terms.
