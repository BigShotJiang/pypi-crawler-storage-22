"""
Astrai SDK - Drop-in cost & safety layer for AI agents.

Usage:
    from astrai import Astrai

    client = Astrai(
        api_key="sk-astrai-xxx",
        budget_limit=5.00,
        region="us",
        no_train=True,
    )

    response = client.chat.completions.create(
        messages=[{"role": "user", "content": "Hello"}],
        model="auto",  # Astrai picks best model
    )

    print(response.astrai.cost_usd)
    print(response.astrai.budget_remaining)
"""

from .client import Astrai, AstraiAgent

__all__ = ["Astrai", "AstraiAgent"]
__version__ = "0.1.0"
