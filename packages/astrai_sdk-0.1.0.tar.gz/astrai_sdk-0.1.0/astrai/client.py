"""
Astrai Client - OpenAI-compatible wrapper with automatic cost control.

Injects Astrai headers for:
- Budget tracking & enforcement
- Region/locality constraints
- Privacy mode (no-train)
- Agent identification
- Automatic tracing
"""

import os
import time
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
import httpx

from .local_classifier import LocalClassifier


@dataclass
class AstraiMeta:
    """Metadata returned with each Astrai response."""
    trace_id: str = ""
    model_used: str = ""
    provider_used: str = ""
    cost_usd: float = 0.0
    budget_remaining: float = 0.0
    routing_reason: str = ""
    classifier: str = ""
    memory_used: List[str] = field(default_factory=list)
    alerts: List[str] = field(default_factory=list)
    health: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AstraiConfig:
    """Configuration for Astrai client."""
    api_key: str = ""
    base_url: str = "https://api.astrai.io"
    budget_limit: Optional[float] = None
    budget_warn_threshold: float = 0.8  # Warn at 80%
    region: Optional[str] = None  # "us", "eu", "asia"
    no_train: bool = False
    # privacy_mode: proxy (default), local (metadata-only routing + BYOK), enhanced/max/standard (server handled)
    privacy_mode: str = "proxy"
    agent_id: Optional[str] = None
    dry_run: bool = False
    budget_webhook_url: Optional[str] = None  # URL to receive budget notifications
    budget_thresholds: List[int] = field(default_factory=lambda: [50, 80, 100])  # Notify at these %
    budget_webhook_secret: Optional[str] = None  # Secret for webhook signature verification
    byok_keys: Dict[str, str] = field(default_factory=dict)  # provider -> key
    provider_endpoints: Dict[str, str] = field(default_factory=dict)  # provider -> base_url
    local_model_path: Optional[str] = None
    local_model_name: str = "distilbert-base-uncased"
    byok_keys: Dict[str, str] = field(default_factory=dict)  # provider -> key
    provider_endpoints: Dict[str, str] = field(default_factory=dict)  # provider -> base_url (OpenAI compatible)
    local_model_path: Optional[str] = None
    local_model_name: str = "distilbert-base-uncased"


class AstraiAgent:
    """
    Agent-scoped Astrai client with automatic budget tracking.

    Usage:
        agent = AstraiAgent(
            agent_id="my-agent",
            budget_limit=5.00,
        )

        response = agent.chat("Write code")
        print(agent.spend)  # Current spend
        print(agent.remaining)  # Budget remaining

    With budget webhook notifications:
        agent = AstraiAgent(
            agent_id="my-agent",
            budget_limit=10.00,
            budget_webhook_url="https://myapp.com/webhooks/budget",
            budget_thresholds=[50, 80, 100],  # Notify at 50%, 80%, and 100%
            budget_webhook_secret="whsec_...",
        )
    """

    def __init__(
        self,
        agent_id: str,
        budget_limit: float = 10.0,
        api_key: Optional[str] = None,
        base_url: str = "https://api.astrai.io",
        region: Optional[str] = None,
        no_train: bool = False,
        privacy_mode: str = "proxy",
        budget_webhook_url: Optional[str] = None,
        budget_thresholds: Optional[List[int]] = None,
        budget_webhook_secret: Optional[str] = None,
        byok_keys: Optional[Dict[str, str]] = None,
        provider_endpoints: Optional[Dict[str, str]] = None,
        local_model_path: Optional[str] = None,
        local_model_name: str = "distilbert-base-uncased",
    ):
        self.agent_id = agent_id
        self.budget_limit = budget_limit
        self.api_key = api_key or os.environ.get("ASTRAI_API_KEY", "")
        self.base_url = base_url
        self.region = region
        self.no_train = no_train
        self.privacy_mode = privacy_mode
        self.budget_webhook_url = budget_webhook_url
        self.budget_thresholds = budget_thresholds
        self.budget_webhook_secret = budget_webhook_secret

        self._spend = 0.0
        self._traces: List[AstraiMeta] = []

        # Create underlying client
        self._client = Astrai(
            api_key=self.api_key,
            base_url=self.base_url,
            budget_limit=budget_limit,
            region=region,
            no_train=no_train,
            privacy_mode=privacy_mode,
            agent_id=agent_id,
            budget_webhook_url=budget_webhook_url,
            budget_thresholds=budget_thresholds,
            budget_webhook_secret=budget_webhook_secret,
            byok_keys=byok_keys,
            provider_endpoints=provider_endpoints,
            local_model_path=local_model_path,
            local_model_name=local_model_name,
        )

    @property
    def spend(self) -> float:
        """Total spend for this agent."""
        return self._spend

    @property
    def remaining(self) -> float:
        """Remaining budget."""
        return max(0, self.budget_limit - self._spend)

    @property
    def traces(self) -> List[AstraiMeta]:
        """All traces for this agent session."""
        return self._traces

    def chat(
        self,
        content: str,
        system: Optional[str] = None,
        model: str = "auto",
        **kwargs
    ) -> Any:
        """
        Simple chat interface with automatic tracking.

        Args:
            content: User message
            system: Optional system prompt
            model: Model to use ("auto" for Astrai routing)
            **kwargs: Additional OpenAI params
        """
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": content})

        response = self._client.chat.completions.create(
            messages=messages,
            model=model,
            **kwargs
        )

        # Track spend
        if hasattr(response, 'astrai'):
            self._spend += response.astrai.cost_usd
            self._traces.append(response.astrai)

        return response


class Astrai:
    """
    OpenAI-compatible client with Astrai cost control.

    Drop-in replacement for OpenAI client:

        # Before
        from openai import OpenAI
        client = OpenAI()

        # After
        from astrai import Astrai
        client = Astrai(budget_limit=5.00)

    All standard OpenAI methods work, plus:
    - Automatic model routing (model="auto")
    - Budget enforcement
    - Cost tracking in response.astrai
    - Region/privacy constraints
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.astrai.io",
        budget_limit: Optional[float] = None,
        budget_warn_threshold: float = 0.8,
        region: Optional[str] = None,
        no_train: bool = False,
        privacy_mode: str = "proxy",
        agent_id: Optional[str] = None,
        dry_run: bool = False,
        budget_webhook_url: Optional[str] = None,
        budget_thresholds: Optional[List[int]] = None,
        budget_webhook_secret: Optional[str] = None,
        byok_keys: Optional[Dict[str, str]] = None,
        provider_endpoints: Optional[Dict[str, str]] = None,
        local_model_path: Optional[str] = None,
        local_model_name: str = "distilbert-base-uncased",
    ):
        self.config = AstraiConfig(
            api_key=api_key or os.environ.get("ASTRAI_API_KEY", ""),
            base_url=base_url,
            budget_limit=budget_limit,
            budget_warn_threshold=budget_warn_threshold,
            region=region,
            no_train=no_train,
            privacy_mode=privacy_mode,
            agent_id=agent_id,
            dry_run=dry_run,
            budget_webhook_url=budget_webhook_url or os.environ.get("ASTRAI_BUDGET_WEBHOOK_URL"),
            budget_thresholds=budget_thresholds or [50, 80, 100],
            budget_webhook_secret=budget_webhook_secret or os.environ.get("ASTRAI_BUDGET_WEBHOOK_SECRET"),
            byok_keys=byok_keys or {},
            provider_endpoints=provider_endpoints or {},
            local_model_path=local_model_path,
            local_model_name=local_model_name,
        )

        # Lazy import OpenAI to avoid hard dependency
        self._openai_client = None
        self._local_classifier = LocalClassifier(
            model_name=self.config.local_model_name,
            model_path=self.config.local_model_path,
        )

        # Expose chat interface
        self.chat = _ChatNamespace(self)

    def _get_openai_client(self):
        """Lazy-load OpenAI client."""
        if self._openai_client is None:
            try:
                from openai import OpenAI
                self._openai_client = OpenAI(
                    api_key=self.config.api_key,
                    base_url=self.config.base_url,
                    default_headers=self._build_headers(),
                )
            except ImportError:
                raise ImportError(
                    "OpenAI package required. Install with: pip install openai"
                )
        return self._openai_client

    def _recommend_route(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Call Astrai metadata-only recommendation endpoint."""
        url = f"{self.config.base_url}/v1/routing/recommend"
        try:
            resp = httpx.post(
                url,
                json=payload,
                headers=self._build_headers(),
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            raise RuntimeError(f"Routing recommendation failed: {e}")

    def _report_outcome(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        latency_ms: float,
        cost_usd: float,
        success: bool,
        routing_reason: Optional[str] = None,
        task_type: Optional[str] = None,
        privacy_mode: Optional[str] = None,
        byok_provider: Optional[str] = None,
    ):
        """Send post-inference telemetry without content."""
        payload = {
            "provider": provider,
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "latency_ms": latency_ms,
            "cost_usd": cost_usd,
            "success": success,
            "routing_reason": routing_reason,
            "task_type": task_type or "unknown",
            "privacy_mode": privacy_mode or self.config.privacy_mode,
            "byok_provider": byok_provider,
        }
        urls = [
            f"{self.config.base_url}/v1/routing/feedback",
            f"{self.config.base_url}/v1/routing/report",
        ]
        last_err = None
        for url in urls:
            try:
                httpx.post(
                    url,
                    json=payload,
                    headers=self._build_headers(),
                    timeout=5,
                )
                return
            except Exception as e:
                last_err = e
        if last_err:
            print(f"⚠️ Astrai telemetry (routing/feedback) failed: {last_err}")

    def _dispatch_to_provider(self, provider: str, model: str, request_kwargs: Dict[str, Any], routing_reason: Optional[str] = None):
        """
        Dispatch request directly to provider using BYOK. Supports any
        OpenAI-compatible endpoint when a base_url override is provided.
        """
        api_key = self.config.byok_keys.get(provider)
        if not api_key:
            raise ValueError(f"No BYOK key configured for provider '{provider}'")

        base_url = self.config.provider_endpoints.get(provider)

        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("openai package is required for BYOK local mode. Install with: pip install openai")

        client_kwargs = {"api_key": api_key}
        if base_url:
            client_kwargs["base_url"] = base_url

        client = OpenAI(**client_kwargs)

        # Ensure model is set to recommendation result
        request_payload = dict(request_kwargs)
        request_payload["model"] = model

        start = time.monotonic()
        response = client.chat.completions.create(**request_payload)
        latency_ms = (time.monotonic() - start) * 1000

        # Attach meta placeholder (cost unknown; set 0)
        input_tokens = getattr(getattr(response, "usage", None), "prompt_tokens", 0)
        output_tokens = getattr(getattr(response, "usage", None), "completion_tokens", 0)
        setattr(response, "_astrai_latency_ms", latency_ms)
        self._report_outcome(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            cost_usd=0.0,
            success=True,
            routing_reason=routing_reason,
            privacy_mode=self.config.privacy_mode,
            byok_provider=provider,
        )

        return response

    def _build_headers(self) -> Dict[str, str]:
        """Build Astrai-specific headers."""
        headers = {}

        if self.config.agent_id:
            headers["X-Astrai-Agent"] = self.config.agent_id

        if self.config.budget_limit is not None:
            headers["X-Astrai-Budget-Limit"] = str(self.config.budget_limit)
            headers["X-Astrai-Budget-Warn"] = str(self.config.budget_warn_threshold)

        if self.config.region:
            headers["X-Astrai-Region"] = self.config.region

        if self.config.no_train:
            headers["X-Astrai-No-Train"] = "true"

        privacy = self.config.privacy_mode or "proxy"
        if privacy in ("proxy", "standard"):
            headers["X-Astrai-Privacy"] = "standard"
        else:
            headers["X-Astrai-Privacy"] = privacy

        if self.config.dry_run:
            headers["X-Astrai-Dry-Run"] = "true"

        if self.config.budget_webhook_url:
            headers["X-Astrai-Budget-Webhook-Url"] = self.config.budget_webhook_url

        if self.config.budget_thresholds:
            headers["X-Astrai-Budget-Thresholds"] = ",".join(str(t) for t in self.config.budget_thresholds)

        if self.config.budget_webhook_secret:
            headers["X-Astrai-Budget-Webhook-Secret"] = self.config.budget_webhook_secret

        return headers


class _ChatNamespace:
    """Namespace for chat.completions interface."""

    def __init__(self, client: Astrai):
        self._client = client
        self.completions = _CompletionsNamespace(client)


class _CompletionsNamespace:
    """Namespace for completions interface."""

    def __init__(self, client: Astrai):
        self._client = client

    def create(self, **kwargs) -> Any:
        """
        Create a chat completion with Astrai routing.

        Accepts all standard OpenAI parameters, plus:
        - model="auto" for automatic routing
        - Extra Astrai metadata in response.astrai
        """
        if self._client.config.privacy_mode == "local":
            return self._create_local_completion(**kwargs)

        openai_client = self._client._get_openai_client()

        # Handle "auto" model
        model = kwargs.get("model", "auto")
        if model == "auto":
            # Let Astrai backend handle routing
            kwargs["model"] = "astrai/auto"

        # Make request
        response = openai_client.chat.completions.create(**kwargs)

        # Parse Astrai metadata from response
        # (Backend adds _astrai_meta to response or final SSE chunk)
        if hasattr(response, '_astrai_meta'):
            response.astrai = AstraiMeta(**response._astrai_meta)
        else:
            # Create empty meta if not present
            response.astrai = AstraiMeta()

        return response

    def _create_local_completion(self, **kwargs) -> Any:
        messages = kwargs.get("messages")
        if not messages:
            raise ValueError("messages are required for chat.completions.create")

        # 1) Local classification (no content leaves device)
        classification = self._client._local_classifier.classify(messages)

        # 2) Request routing recommendation using metadata only
        recommend_payload = {
            "task_type": classification.get("task_type"),
            "complexity": classification.get("complexity"),
            "tokens": classification.get("tokens"),
            "entropy": classification.get("entropy"),
            "constraints": kwargs.pop("constraints", {}),
            "privacy_mode": "local",
        }
        recommendation = self._client._recommend_route(recommend_payload)
        provider = recommendation.get("provider")
        model = recommendation.get("model")
        reason = recommendation.get("reason", "")

        if not provider or not model:
            raise RuntimeError(f"Routing recommendation missing provider/model: {recommendation}")

        # 3) Route directly to provider using BYOK
        response = self._client._dispatch_to_provider(
            provider=provider,
            model=model,
            request_kwargs=kwargs,
            routing_reason=reason,
        )

        # 4) Attach Astrai metadata locally
        response.astrai = AstraiMeta(
            provider_used=provider,
            model_used=model,
            routing_reason=reason,
            classifier=classification.get("source", ""),
        )

        # 5) Report outcome (content-free)
        usage = getattr(response, "usage", None)
        input_tokens = getattr(usage, "prompt_tokens", 0) if usage else 0
        output_tokens = getattr(usage, "completion_tokens", 0) if usage else 0
        latency_ms = getattr(response, "_astrai_latency_ms", recommendation.get("latency_ms", 0.0))
        self._client._report_outcome(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            cost_usd=0.0,
            success=True,
            routing_reason=reason,
            task_type=classification.get("task_type"),
            privacy_mode="local",
            byok_provider=provider,
        )

        return response


# Convenience function for quick usage
def create_agent(
    agent_id: str,
    budget_limit: float = 10.0,
    **kwargs
) -> AstraiAgent:
    """
    Create a budget-controlled agent.

    Usage:
        agent = astrai.create_agent("my-bot", budget_limit=5.00)
        response = agent.chat("Hello")
        print(agent.spend)
    """
    return AstraiAgent(agent_id=agent_id, budget_limit=budget_limit, **kwargs)
