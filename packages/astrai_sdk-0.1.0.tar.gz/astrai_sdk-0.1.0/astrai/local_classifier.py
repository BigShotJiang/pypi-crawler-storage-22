"""
Local Classifier - Privacy-preserving task classification that runs on user's machine.

This module classifies prompts locally WITHOUT sending content to Astrai servers.
Only metadata (task_type, complexity, entropy, token count) is sent for routing.

Features:
- Task type classification (coding, writing, analysis, math, chat, etc.)
- Complexity estimation (low, medium, high)
- Entropy calculation for GlimpRouter
- Token counting
- All computation happens on user's device
"""

import math
import re
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from collections import Counter


@dataclass
class LocalClassification:
    """Result of local task classification."""
    task_type: str = "general"
    complexity: str = "medium"  # low, medium, high
    entropy: float = 1.0  # Shannon entropy of token distribution
    tokens: int = 0
    requires_reasoning: bool = False
    requires_creativity: bool = False
    requires_code: bool = False
    requires_math: bool = False
    confidence: float = 0.5
    source: str = "local_heuristic"  # local_heuristic or local_model

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_type": self.task_type,
            "complexity": self.complexity,
            "entropy": self.entropy,
            "tokens": self.tokens,
            "requires_reasoning": self.requires_reasoning,
            "requires_creativity": self.requires_creativity,
            "requires_code": self.requires_code,
            "requires_math": self.requires_math,
            "confidence": self.confidence,
            "source": self.source,
        }


class LocalClassifier:
    """
    Privacy-preserving local classifier.

    Runs entirely on user's machine. No content is sent to Astrai servers.
    Only metadata (task_type, complexity, entropy, tokens) is transmitted.

    Usage:
        classifier = LocalClassifier()
        result = classifier.classify(messages)
        # result contains only metadata, safe to send to Astrai
    """

    # Task patterns for heuristic classification
    TASK_PATTERNS = {
        "coding": [
            r"\b(code|program|function|class|implement|debug|fix|refactor)\b",
            r"\b(python|javascript|typescript|java|rust|go|sql|html|css)\b",
            r"\b(api|endpoint|database|query|algorithm|compile|runtime)\b",
            r"```",  # Code blocks
        ],
        "writing": [
            r"\b(write|draft|compose|create|generate)\b.*(article|essay|blog|story|email|letter)",
            r"\b(summarize|paraphrase|rewrite|edit|proofread)\b",
            r"\b(tone|style|voice|audience)\b",
        ],
        "analysis": [
            r"\b(analyze|evaluate|compare|assess|review|examine)\b",
            r"\b(data|metrics|statistics|trends|insights|patterns)\b",
            r"\b(pros|cons|advantages|disadvantages|trade-?offs)\b",
        ],
        "math": [
            r"\b(calculate|compute|solve|equation|formula|derivative|integral)\b",
            r"\b(math|algebra|calculus|statistics|probability|geometry)\b",
            r"\d+\s*[\+\-\*\/\^\=]\s*\d+",  # Expressions like "2 + 2"
            r"\b(sum|product|mean|median|variance)\b",
        ],
        "reasoning": [
            r"\b(explain|why|how does|reason|logic|think through|step by step)\b",
            r"\b(chain of thought|reasoning|deduce|infer|conclude)\b",
            r"\b(prove|disprove|argue|justify)\b",
        ],
        "creative": [
            r"\b(creative|imaginative|brainstorm|ideas|innovative)\b",
            r"\b(story|poem|fiction|narrative|character|plot)\b",
            r"\b(design|concept|vision|artistic)\b",
        ],
        "classification": [
            r"\b(classify|categorize|label|tag|sort)\b",
            r"\b(sentiment|positive|negative|neutral)\b",
            r"\b(is this|which category|what type)\b",
        ],
        "extraction": [
            r"\b(extract|find|identify|locate|parse)\b",
            r"\b(entities|names|dates|numbers|keywords)\b",
            r"\b(from (this|the) (text|document|data))\b",
        ],
        "translation": [
            r"\b(translate|convert|transform)\b.*(to|into|from)\b",
            r"\b(english|spanish|french|german|chinese|japanese)\b",
        ],
        "chat": [
            r"^\s*(hello|hi|hey|thanks|thank you|ok|okay|sure|yes|no)\s*[!?.]?\s*$",
            r"^.{0,30}$",  # Very short messages
        ],
    }

    # Complexity indicators
    COMPLEXITY_INDICATORS = {
        "high": [
            r"\b(complex|advanced|sophisticated|comprehensive|detailed)\b",
            r"\b(architect|design|system|infrastructure|enterprise)\b",
            r"\b(optimize|scale|performance|production)\b",
            r".{2000,}",  # Very long prompts
        ],
        "low": [
            r"\b(simple|basic|quick|brief|short|easy)\b",
            r"^.{0,100}$",  # Very short
            r"\b(just|only|single)\b",
        ],
    }

    def __init__(
        self,
        model_name: str = "distilbert-base-uncased",
        model_path: Optional[str] = None,
        use_model: bool = False,
    ):
        """
        Initialize local classifier.

        Args:
            model_name: Name of transformer model for advanced classification
            model_path: Path to local model weights
            use_model: Whether to use ML model (requires transformers library)
        """
        self.model_name = model_name
        self.model_path = model_path
        self.use_model = use_model
        self._model = None
        self._tokenizer = None

    def classify(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Classify messages locally.

        Args:
            messages: List of message dicts with 'role' and 'content'

        Returns:
            Classification metadata (safe to send to server)
        """
        # Extract text from messages
        text = self._extract_text(messages)

        # Count tokens (approximate)
        tokens = self._count_tokens(text)

        # Calculate entropy
        entropy = self._calculate_entropy(text)

        # Classify task type and complexity
        classification = self._classify_heuristic(text)
        classification.tokens = tokens
        classification.entropy = entropy

        return classification.to_dict()

    def _extract_text(self, messages: List[Dict[str, str]]) -> str:
        """Extract combined text from messages."""
        parts = []
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                parts.append(content)
            elif isinstance(content, list):
                # Handle multimodal messages
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        parts.append(item.get("text", ""))
        return " ".join(parts)

    def _count_tokens(self, text: str) -> int:
        """
        Approximate token count.

        Uses simple word-based heuristic. For production, could use tiktoken.
        """
        # Rough approximation: ~1.3 tokens per word for English
        words = len(text.split())
        return int(words * 1.3)

    def _calculate_entropy(self, text: str) -> float:
        """
        Calculate Shannon entropy of token distribution.

        Higher entropy = more diverse/complex content
        Lower entropy = more repetitive/simple content

        Used by GlimpRouter:
        - H < 0.6: Simple task, route to draft tier
        - H > 1.8: Complex task, route to ultra tier
        - Otherwise: Balanced tier
        """
        if not text:
            return 0.0

        # Tokenize into words (simple approach)
        tokens = re.findall(r'\b\w+\b', text.lower())

        if not tokens:
            return 0.0

        # Count frequencies
        counter = Counter(tokens)
        total = len(tokens)

        # Calculate Shannon entropy
        entropy = 0.0
        for count in counter.values():
            if count > 0:
                p = count / total
                entropy -= p * math.log2(p)

        return round(entropy, 4)

    def _classify_heuristic(self, text: str) -> LocalClassification:
        """Classify using pattern matching heuristics."""
        if not text:
            return LocalClassification()

        text_lower = text.lower()
        result = LocalClassification()

        # Detect task type
        task_scores: Dict[str, int] = {}
        for task_type, patterns in self.TASK_PATTERNS.items():
            score = sum(
                1 for p in patterns
                if re.search(p, text_lower, re.IGNORECASE | re.MULTILINE)
            )
            if score > 0:
                task_scores[task_type] = score

        if task_scores:
            result.task_type = max(task_scores, key=task_scores.get)
            result.confidence = min(0.9, 0.5 + task_scores[result.task_type] * 0.1)

        # Detect complexity
        for complexity, patterns in self.COMPLEXITY_INDICATORS.items():
            if any(re.search(p, text, re.IGNORECASE) for p in patterns):
                result.complexity = complexity
                break

        # Detect special requirements
        result.requires_code = result.task_type == "coding" or bool(
            re.search(r"```|def |function |class |import |require\(", text)
        )
        result.requires_math = result.task_type == "math" or bool(
            re.search(r"\b(calculate|compute|equation|\d+\s*[\+\-\*\/\^]\s*\d+)\b", text_lower)
        )
        result.requires_reasoning = result.task_type == "reasoning" or bool(
            re.search(r"\b(why|explain|step by step|reason|because)\b", text_lower)
        )
        result.requires_creativity = result.task_type == "creative" or bool(
            re.search(r"\b(creative|brainstorm|imagine|invent|story)\b", text_lower)
        )

        result.source = "local_heuristic"
        return result

    def get_tier_recommendation(self, entropy: float) -> str:
        """
        Get routing tier based on entropy (GlimpRouter logic).

        Args:
            entropy: Shannon entropy of the request

        Returns:
            Tier recommendation: "draft", "balanced", or "ultra"
        """
        if entropy < 0.6:
            return "draft"
        elif entropy > 1.8:
            return "ultra"
        else:
            return "balanced"


# Convenience functions
def classify_locally(messages: List[Dict[str, str]]) -> Dict[str, Any]:
    """
    Classify messages locally without sending content anywhere.

    Args:
        messages: OpenAI-format messages

    Returns:
        Metadata dict safe to send to routing server
    """
    classifier = LocalClassifier()
    return classifier.classify(messages)


def estimate_tokens(text: str) -> int:
    """
    Estimate token count for text.

    Uses simple word-based heuristic (~1.3 tokens per word).
    For production, could use tiktoken for exact counts.

    Args:
        text: Input text

    Returns:
        Estimated token count
    """
    if not text:
        return 0
    words = len(text.split())
    return int(words * 1.3)
