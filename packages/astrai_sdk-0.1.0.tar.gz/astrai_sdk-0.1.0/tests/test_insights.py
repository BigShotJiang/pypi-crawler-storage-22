"""
Tests for Savings Insights Endpoints

Tests the /v1/insights, /v1/insights/workflows, and /v1/optimization/enable endpoints.
Run with: pytest tests/test_insights.py -v
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, patch, AsyncMock
import sys
import os
from datetime import datetime, timezone

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture
def mock_account():
    """Create a mock authenticated account."""
    from main import AuthedAccount
    return AuthedAccount(
        account_id="test-account-123",
        api_key_id="test-key-456",
        preferences={}
    )


@pytest.fixture
def client_with_auth(mock_account):
    """Create test client with mocked auth."""
    os.environ.setdefault("SUPABASE_URL", "https://test.supabase.co")
    os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY", "test-key")

    from main import app, get_current_account, RoutingPreferences

    # Save original override
    previous_override = app.dependency_overrides.get(get_current_account)

    async def override_auth():
        return mock_account

    app.dependency_overrides[get_current_account] = override_auth

    with TestClient(app) as client:
        yield client

    # Restore the previous override for other tests
    if previous_override is not None:
        app.dependency_overrides[get_current_account] = previous_override
    else:
        # Recreate the dummy account override from conftest
        class DummyAccount:
            def __init__(self):
                self.account_id = "acct-test"
                self.api_key_id = "key-test"
                self.preferences = RoutingPreferences()

        async def dummy_auth():
            return DummyAccount()

        app.dependency_overrides[get_current_account] = dummy_auth


class TestInsightsEndpoint:
    """Tests for /v1/insights endpoint."""

    def test_insights_returns_200(self, client_with_auth):
        """Insights endpoint should return 200 for authenticated users."""
        response = client_with_auth.get("/v1/insights")
        assert response.status_code == 200

    def test_insights_has_required_fields(self, client_with_auth):
        """Insights response should have required fields."""
        response = client_with_auth.get("/v1/insights")
        data = response.json()

        assert "success" in data
        # When DB not available, it returns error
        if data.get("success"):
            assert "summary" in data
            assert "opportunities" in data
            assert "by_task_type" in data

    def test_insights_requires_auth(self):
        """Insights should require authentication."""
        os.environ.setdefault("SUPABASE_URL", "https://test.supabase.co")
        os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY", "test-key")

        from main import app, get_current_account
        from fastapi import HTTPException

        # Save current override and remove it to test auth requirement
        previous_override = app.dependency_overrides.get(get_current_account)

        async def deny_auth():
            raise HTTPException(status_code=401, detail="Unauthorized")

        app.dependency_overrides[get_current_account] = deny_auth

        try:
            with TestClient(app) as client:
                response = client.get("/v1/insights")
                assert response.status_code == 401
        finally:
            # Restore override
            if previous_override:
                app.dependency_overrides[get_current_account] = previous_override


class TestWorkflowInsightsEndpoint:
    """Tests for /v1/insights/workflows endpoint."""

    def test_workflows_returns_200(self, client_with_auth):
        """Workflow insights endpoint should return 200."""
        response = client_with_auth.get("/v1/insights/workflows")
        assert response.status_code == 200

    def test_workflows_has_required_fields(self, client_with_auth):
        """Workflow insights response should have required fields."""
        response = client_with_auth.get("/v1/insights/workflows")
        data = response.json()

        assert "success" in data
        if data.get("success"):
            assert "workflows" in data
            assert isinstance(data["workflows"], list)

    def test_workflows_requires_auth(self):
        """Workflow insights should require authentication."""
        os.environ.setdefault("SUPABASE_URL", "https://test.supabase.co")
        os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY", "test-key")

        from main import app, get_current_account
        from fastapi import HTTPException

        previous_override = app.dependency_overrides.get(get_current_account)

        async def deny_auth():
            raise HTTPException(status_code=401, detail="Unauthorized")

        app.dependency_overrides[get_current_account] = deny_auth

        try:
            with TestClient(app) as client:
                response = client.get("/v1/insights/workflows")
                assert response.status_code == 401
        finally:
            if previous_override:
                app.dependency_overrides[get_current_account] = previous_override


class TestOptimizationEnableEndpoint:
    """Tests for /v1/optimization/enable endpoint."""

    def test_optimization_requires_auth(self):
        """Optimization enable should require authentication."""
        os.environ.setdefault("SUPABASE_URL", "https://test.supabase.co")
        os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY", "test-key")

        from main import app, get_current_account
        from fastapi import HTTPException

        previous_override = app.dependency_overrides.get(get_current_account)

        async def deny_auth():
            raise HTTPException(status_code=401, detail="Unauthorized")

        app.dependency_overrides[get_current_account] = deny_auth

        try:
            with TestClient(app) as client:
                response = client.post(
                    "/v1/optimization/enable",
                    json={"mode": "auto"}
                )
                assert response.status_code == 401
        finally:
            if previous_override:
                app.dependency_overrides[get_current_account] = previous_override

    def test_optimization_validates_mode(self, client_with_auth):
        """Optimization should validate mode parameter."""
        response = client_with_auth.post(
            "/v1/optimization/enable",
            json={"mode": "invalid_mode"}
        )
        # Should return 422 for invalid mode
        assert response.status_code == 422

    def test_optimization_accepts_valid_modes(self, client_with_auth):
        """Optimization should accept valid mode values."""
        for mode in ["shadow", "auto", "manual"]:
            response = client_with_auth.post(
                "/v1/optimization/enable",
                json={"mode": mode}
            )
            # Should return 200 (or error from DB, but not validation error)
            assert response.status_code in [200, 500]


class TestSavingsSummaryEndpoint:
    """Tests for /v1/billing/savings-summary endpoint."""

    def test_savings_summary_returns_200(self, client_with_auth):
        """Savings summary should return 200."""
        response = client_with_auth.get("/v1/billing/savings-summary")
        assert response.status_code == 200

    def test_savings_summary_has_structure(self, client_with_auth):
        """Savings summary should have proper structure."""
        response = client_with_auth.get("/v1/billing/savings-summary")
        data = response.json()

        # When DB available, has success field; otherwise has error
        if "success" in data and data.get("success"):
            assert "routing_status" in data
            assert "summary" in data
        else:
            # DB not available case
            assert "error" in data or "success" in data


class TestEndpointIntegration:
    """Integration tests for insights flow."""

    def test_full_insights_flow(self, client_with_auth):
        """Test complete insights data flow."""
        # 1. Get insights
        insights = client_with_auth.get("/v1/insights")
        assert insights.status_code == 200

        # 2. Get workflow insights
        workflows = client_with_auth.get("/v1/insights/workflows")
        assert workflows.status_code == 200

        # 3. Get savings summary
        savings = client_with_auth.get("/v1/billing/savings-summary")
        assert savings.status_code == 200

    def test_optimization_mode_change(self, client_with_auth):
        """Test changing optimization mode."""
        # Enable auto mode
        response = client_with_auth.post(
            "/v1/optimization/enable",
            json={"mode": "auto"}
        )
        assert response.status_code in [200, 500]  # 500 if DB not available
