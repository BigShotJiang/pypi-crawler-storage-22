"""
Tests for memory encryption functionality.
"""

import pytest
import tempfile
import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestMemoryEncryption:
    """Tests for memory_encryption module."""

    def test_simple_encryption_roundtrip(self):
        """Simple encryption should encrypt and decrypt correctly."""
        from memory_encryption import SimpleEncryption

        enc = SimpleEncryption("test_password")
        plaintext = "This is a secret memory"

        encrypted = enc.encrypt(plaintext)
        decrypted = enc.decrypt(encrypted)

        assert decrypted == plaintext
        assert encrypted != plaintext

    def test_simple_encryption_different_passwords(self):
        """Different passwords should produce different results."""
        from memory_encryption import SimpleEncryption

        enc1 = SimpleEncryption("password1")
        enc2 = SimpleEncryption("password2")
        plaintext = "Same message"

        encrypted1 = enc1.encrypt(plaintext)
        encrypted2 = enc2.encrypt(plaintext)

        assert encrypted1 != encrypted2

    def test_get_encryption_returns_implementation(self):
        """get_encryption should return a valid implementation."""
        from memory_encryption import get_encryption

        enc = get_encryption("test_password")

        # Should have encrypt/decrypt methods
        assert hasattr(enc, "encrypt")
        assert hasattr(enc, "decrypt")
        assert hasattr(enc, "get_salt")

    def test_encryption_with_salt(self):
        """Same password + salt should produce same key."""
        from memory_encryption import get_encryption

        enc1 = get_encryption("password")
        salt = enc1.get_salt()

        enc2 = get_encryption("password", salt)

        plaintext = "Test message"
        encrypted = enc1.encrypt(plaintext)

        # enc2 with same salt should decrypt
        # Note: This won't work for AES-GCM due to nonce,
        # but salt recovery should work
        assert enc2.get_salt() == salt

    def test_password_hash(self):
        """password_hash should produce consistent hashes."""
        from memory_encryption import password_hash

        hash1 = password_hash("test_password")
        hash2 = password_hash("test_password")
        hash3 = password_hash("different_password")

        assert hash1 == hash2
        assert hash1 != hash3
        assert len(hash1) == 32  # 32 hex chars


class TestUserMemoryEncryption:
    """Tests for UserMemoryStore encryption integration."""

    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for test databases."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir

    def test_unencrypted_store_works(self, temp_dir):
        """Store without password should work normally."""
        from user_memory import UserMemoryStore
        import asyncio

        store = UserMemoryStore("test_user", data_dir=temp_dir)
        assert store.is_encrypted is False

        # Should be able to store and recall
        async def test():
            memory = await store.remember("Test memory content")
            assert memory.content == "Test memory content"

            results = await store.recall("Test memory")
            assert len(results) > 0

        asyncio.run(test())

    def test_encrypted_store_works(self, temp_dir):
        """Store with password should encrypt content."""
        from user_memory import UserMemoryStore
        import asyncio

        store = UserMemoryStore("test_user", data_dir=temp_dir, password="secret123")
        assert store.is_encrypted is True

        async def test():
            memory = await store.remember("Secret memory content")
            assert memory.content == "Secret memory content"

            results = await store.recall("Secret memory")
            # Results should return decrypted content
            assert len(results) > 0
            assert results[0].memory.content == "Secret memory content"

        asyncio.run(test())

    def test_encrypted_store_persists(self, temp_dir):
        """Encrypted store should persist and reload correctly."""
        from user_memory import UserMemoryStore
        import asyncio

        # Create store and add memory
        store1 = UserMemoryStore("test_user", data_dir=temp_dir, password="secret123")

        async def create():
            await store1.remember("Persistent secret")

        asyncio.run(create())

        # Create new store instance with same password
        store2 = UserMemoryStore("test_user", data_dir=temp_dir, password="secret123")

        async def verify():
            memories = await store2.get_all()
            assert len(memories) == 1
            assert memories[0].content == "Persistent secret"

        asyncio.run(verify())

    def test_wrong_password_raises(self, temp_dir):
        """Wrong password should raise ValueError."""
        from user_memory import UserMemoryStore
        import asyncio

        # Create encrypted store
        store1 = UserMemoryStore("test_user", data_dir=temp_dir, password="correct")

        async def create():
            await store1.remember("Secret")

        asyncio.run(create())

        # Try to open with wrong password
        with pytest.raises(ValueError, match="Incorrect password"):
            UserMemoryStore("test_user", data_dir=temp_dir, password="wrong")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
