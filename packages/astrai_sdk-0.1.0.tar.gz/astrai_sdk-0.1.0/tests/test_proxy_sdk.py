import json
import asyncio
import pytest

import main
from main import get_agent_queue


def test_budget_blocks_calls(client):
    resp = client.post(
        "/v1/chat/completions",
        headers={
            "Authorization": "Bearer test",
            "X-Astrai-Budget-Usd": "0",
            "X-Astrai-Agent-Id": "agent-test",
        },
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 429
    assert "Budget exceeded" in resp.json()["detail"]


def test_astrai_meta_present_dry_run(client):
    resp = client.post(
        "/v1/chat/completions",
        headers={
            "Authorization": "Bearer test",
            "X-Astrai-Dry-Run": "true",
            "X-Astrai-Agent-Id": "agent-test2",
            "X-Astrai-Budget-Usd": "10",
        },
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hello"}],
        },
    )
    assert resp.status_code == 200
    meta = resp.json().get("_astrai_meta")
    assert meta
    assert "trace_id" in meta
    assert "classifier" in meta


def test_sse_emits_event(client):
    agent_id = "agent-sse"
    queue = get_agent_queue(agent_id)
    # Preload an event
    queue.put_nowait({"type": "test", "data": {"ok": True}, "timestamp": "now"})

    with client.stream("GET", f"/v1/agent/{agent_id}/events?once=true", headers={"Authorization": "Bearer test"}, timeout=5.0) as stream:
        line = next(stream.iter_lines())
        stream.close()
        assert line.startswith("data: ")
        payload = json.loads(line.replace("data: ", ""))
    assert payload["type"] == "test"


def test_budget_warning_helper_sets_flag():
    agent_id = "agent-budget-warn"
    main.BUDGET_STATE.pop(agent_id, None)
    _, remaining, warn, exceeded = main.apply_budget_spend(agent_id, budget_limit=10.0, spend_delta=8.0)
    assert pytest.approx(remaining, rel=1e-6) == 2.0
    assert warn is True
    assert exceeded is False


def test_streaming_returns_final_meta_before_done(client, monkeypatch):
    class FakeDelta:
        def __init__(self, content=None):
            self.content = content

    class FakeChoice:
        def __init__(self, content=None, finish_reason=None):
            self.delta = FakeDelta(content)
            self.finish_reason = finish_reason

    class FakeChunk:
        def __init__(self, content=None, finish_reason=None):
            self.choices = [FakeChoice(content, finish_reason)]

        def model_dump_json(self):
            return json.dumps(
                {
                    "choices": [
                        {
                            "delta": {"content": self.choices[0].delta.content},
                            "finish_reason": self.choices[0].finish_reason,
                        }
                    ]
                }
            )

    async def fake_acompletion(**kwargs):
        async def gen():
            yield FakeChunk(content="hello")
            yield FakeChunk(finish_reason="stop")

        return gen()

    async def noop(*args, **kwargs):
        return None

    monkeypatch.setattr(main, "acompletion", fake_acompletion)
    async def allow_budget(*args, **kwargs):
        return True, None

    monkeypatch.setattr(main, "log_inference_event", noop)
    monkeypatch.setattr(main, "learn_from_outcome", noop)
    monkeypatch.setattr(main, "deduct_balance", noop)
    monkeypatch.setattr(main, "check_budget", allow_budget)
    monkeypatch.setattr(main.INFERENCE_ROUTER, "get_financials", lambda **kwargs: {
        "retail_price": 0.01,
        "wholesale_cost": 0.005,
        "spread_captured": 0.005,
        "spread_bps": 50,
    })
    monkeypatch.setattr(main.INFERENCE_ROUTER, "record_success", lambda *args, **kwargs: None)

    with client.stream(
        "POST",
        "/v1/chat/completions",
        headers={
            "Authorization": "Bearer test",
            "X-Astrai-Agent-Id": "agent-stream-meta",
            "X-Astrai-Budget-Usd": "5",
        },
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hi"}],
            "stream": True,
        },
        timeout=5.0,
    ) as stream:
        lines = [line.decode() if isinstance(line, (bytes, bytearray)) else line for line in stream.iter_lines()]

    meta_lines = [line for line in lines if '"_astrai_meta"' in (line or "")]
    assert meta_lines, f"stream lines missing meta: {lines}"
    done_index = next(i for i, line in enumerate(lines) if "[DONE]" in (line or ""))
    assert lines.index(meta_lines[0]) < done_index

    meta_payload = json.loads(meta_lines[0].replace("data: ", ""))
    assert "_astrai_meta" in meta_payload
    assert meta_payload["_astrai_meta"]["budget_remaining_usd"] is not None


def test_dry_run_includes_meta_and_budget(client):
    resp = client.post(
        "/v1/chat/completions",
        headers={
            "Authorization": "Bearer test",
            "X-Astrai-Dry-Run": "true",
            "X-Astrai-Agent-Id": "agent-dry-run",
            "X-Astrai-Budget-Usd": "3",
        },
        json={
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "hello"}],
        },
    )
    assert resp.status_code == 200
    meta = resp.json().get("_astrai_meta")
    assert meta, "dry-run should return _astrai_meta"
    assert meta.get("trace_id")
    assert meta.get("budget_remaining_usd") == 3.0
    assert meta.get("classifier") is not None


def test_agent_events_ping_once(client):
    agent_id = "agent-ping-once"
    queue = get_agent_queue(agent_id)
    queue.put_nowait({"type": "ping", "timestamp": "now", "data": {}})

    with client.stream(
        "GET",
        f"/v1/agent/{agent_id}/events?once=true",
        headers={"Authorization": "Bearer test"},
        timeout=5.0,
    ) as stream:
        line = next(stream.iter_lines())

    assert line.startswith("data: ")
    payload = json.loads(line.replace("data: ", ""))
    assert payload["type"] == "ping"


def test_routing_feedback_accepts_alias_tokens(client):
    resp = client.post(
        "/v1/routing/feedback",
        headers={"Authorization": "Bearer test"},
        json={
            "task_type": "code",
            "provider": "openai",
            "model": "gpt-4o",
            "success": True,
            "input_tokens": 12,
            "output_tokens": 4,
            "latency_ms": 42.0,
            "cost_usd": 0.001,
            "routing_reason": "unit-test",
            "privacy_mode": "local",
        },
        timeout=5.0,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert body["task_type"] == "code"
    assert "venue" in body
