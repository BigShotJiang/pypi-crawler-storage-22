"""
Smoke Tests for Astrai API

Basic health checks to verify the server starts and responds correctly.
Run with: pytest tests/test_smoke.py -v
"""

import pytest
from fastapi import HTTPException, Request
from fastapi.testclient import TestClient
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture
def client():
    """Create test client with mocked Supabase."""
    # Mock environment variables before importing main
    os.environ.setdefault("SUPABASE_URL", "https://test.supabase.co")
    os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY", "test-key")

    # Import after setting env vars
    from main import app, get_current_account, RoutingPreferences

    # Save the current override (from conftest.py)
    previous_override = app.dependency_overrides.get(get_current_account)

    async def deny_auth(request: Request):
        raise HTTPException(status_code=401, detail="Unauthorized")

    app.dependency_overrides[get_current_account] = deny_auth

    with TestClient(app) as client:
        yield client

    # Restore the previous override for other tests
    if previous_override is not None:
        app.dependency_overrides[get_current_account] = previous_override
    else:
        # Recreate the dummy account override from conftest
        class DummyAccount:
            def __init__(self):
                self.account_id = "acct-test"
                self.api_key_id = "key-test"
                self.preferences = RoutingPreferences()

        async def dummy_auth():
            return DummyAccount()

        app.dependency_overrides[get_current_account] = dummy_auth


class TestHealthEndpoint:
    """Tests for /health endpoint."""

    def test_health_returns_200(self, client):
        """Health endpoint should return 200 OK."""
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_has_required_fields(self, client):
        """Health response should contain required fields."""
        response = client.get("/health")
        data = response.json()

        assert "status" in data
        assert "version" in data
        assert "timestamp" in data
        assert "checks" in data

    def test_health_status_ok_or_degraded(self, client):
        """Health status should be 'ok' or 'degraded'."""
        response = client.get("/health")
        data = response.json()

        assert data["status"] in ["ok", "degraded"]

    def test_health_includes_region(self, client):
        """Health should include region info."""
        response = client.get("/health")
        data = response.json()

        assert "region" in data


class TestRootEndpoint:
    """Tests for root endpoint."""

    def test_root_redirects_to_docs(self, client):
        """Root endpoint should redirect to /docs."""
        response = client.get("/", follow_redirects=False)
        assert response.status_code in [302, 307]
        assert "/docs" in response.headers.get("location", "")


class TestDocsEndpoint:
    """Tests for documentation endpoints."""

    def test_docs_available(self, client):
        """OpenAPI docs should be available."""
        response = client.get("/docs")
        assert response.status_code == 200

    def test_openapi_schema_available(self, client):
        """OpenAPI schema should be available."""
        response = client.get("/openapi.json")
        assert response.status_code == 200
        data = response.json()
        assert "openapi" in data
        assert "paths" in data


class TestChatCompletionsAuth:
    """Tests for /v1/chat/completions authentication."""

    def test_chat_requires_auth(self, client):
        """Chat endpoint should require authentication."""
        response = client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "Hello"}]
            }
        )
        # Should fail with 401 (no auth) not 500 (server error)
        assert response.status_code in [401, 403]

    def test_chat_rejects_invalid_token(self, client):
        """Chat endpoint should reject invalid tokens."""
        response = client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "Hello"}]
            },
            headers={"Authorization": "Bearer invalid-token"}
        )
        # Should fail with auth error, not server error
        assert response.status_code in [401, 403]


class TestMarketDataEndpoint:
    """Tests for /v1/market-data endpoint."""

    def test_market_data_returns_200(self, client):
        """Market data endpoint should return 200."""
        response = client.get("/v1/market-data")
        assert response.status_code == 200

    def test_market_data_returns_dict(self, client):
        """Market data should return a dictionary."""
        response = client.get("/v1/market-data")
        data = response.json()
        assert isinstance(data, dict)


class TestLearningEndpoints:
    """Tests for /v1/learning/* and /v1/preferences/* endpoints."""

    def test_learning_insights_requires_auth(self, client):
        """Learning insights should require authentication."""
        response = client.get("/v1/learning/insights")
        assert response.status_code in [401, 403]

    def test_preferences_requires_auth(self, client):
        """Preferences endpoint should require authentication."""
        response = client.get("/v1/preferences")
        assert response.status_code in [401, 403]

    def test_preferences_history_requires_auth(self, client):
        """Preferences history should require authentication."""
        response = client.get("/v1/preferences/history")
        assert response.status_code in [401, 403]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
