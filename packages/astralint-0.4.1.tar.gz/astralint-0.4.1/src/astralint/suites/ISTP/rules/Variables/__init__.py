# ISTP Variable Rules

