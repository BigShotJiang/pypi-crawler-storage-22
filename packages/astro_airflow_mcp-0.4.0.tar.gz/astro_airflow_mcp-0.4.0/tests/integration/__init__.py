"""Integration tests for Airflow MCP Server.

These tests run against real Airflow instances (2.x and 3.x) to validate
that the MCP server correctly handles API differences between versions.
"""
