"""Astroeasy test suite."""
