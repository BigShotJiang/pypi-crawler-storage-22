Release history
===============

.. currentmodule:: asyncactor

.. towncrier release notes start

AsyncActor 0.11
---------------

- Initial non-release

