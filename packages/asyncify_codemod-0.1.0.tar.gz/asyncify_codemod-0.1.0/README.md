# asyncify-codemod

`asyncify-codemod` is a codemod that converts synchronous Python code into async where
possible. It focuses on a few common patterns (like `requests`, `time.sleep`,
and file I/O) and rewrites them to async equivalents.

## Install with pipx

```bash
pipx install .
```

## Install from PyPI

```bash
pipx install asyncify-codemod
```

Or with pip:

```bash
pip install asyncify-codemod
```

## Usage

```bash
asyncify-codemod path/to/file.py
```

To print to stdout instead of overwriting:

```bash
asyncify-codemod --stdout path/to/file.py
```

To skip Black formatting:

```bash
asyncify-codemod --no-format path/to/file.py
```

## Release

Build and publish to PyPI:

```bash
make build
make publish
```

Publish to TestPyPI:

```bash
make publish-test
```
