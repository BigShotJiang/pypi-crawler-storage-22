import argparse
from pathlib import Path

from .core import transform_source


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="asyncify",
        description="Convert synchronous Python code to async where possible.",
    )
    parser.add_argument("path", help="Path to a Python file to transform.")
    parser.add_argument(
        "--stdout",
        action="store_true",
        help="Write transformed code to stdout instead of overwriting the file.",
    )
    parser.add_argument(
        "--no-format",
        action="store_true",
        help="Skip Black formatting for the output.",
    )
    args = parser.parse_args(argv)

    path = Path(args.path)
    source = path.read_text(encoding="utf-8")
    module_sources = {
        module_path.stem: module_path.read_text(encoding="utf-8")
        for module_path in path.parent.glob("*.py")
        if module_path.is_file()
    }
    transformed = transform_source(
        source,
        format_with_black=not args.no_format,
        module_sources=module_sources,
    )

    if args.stdout:
        print(transformed, end="")
        return 0

    path.write_text(transformed, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
