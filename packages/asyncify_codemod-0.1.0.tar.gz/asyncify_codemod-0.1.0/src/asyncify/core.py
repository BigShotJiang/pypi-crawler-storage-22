import ast
from textwrap import dedent
from typing import Set

import black


def _collect_httpx_client_names(source: str) -> Set[str]:
    class _HttpxClientCollector(ast.NodeVisitor):
        def __init__(self) -> None:
            self.httpx_module_aliases: Set[str] = set()
            self.httpx_client_class_aliases: Set[str] = set()
            self.httpx_client_instances: Set[str] = set()

        def visit_Import(self, node: ast.Import) -> None:
            for alias in node.names:
                if alias.name == "httpx":
                    self.httpx_module_aliases.add(alias.asname or "httpx")
            self.generic_visit(node)

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            if node.module == "httpx":
                for alias in node.names:
                    if alias.name in {"Client", "AsyncClient"}:
                        self.httpx_client_class_aliases.add(alias.asname or alias.name)
            self.generic_visit(node)

        def _record_client_names(self, node: ast.AST, value: ast.AST) -> None:
            if (
                isinstance(value, ast.Call)
                and isinstance(value.func, ast.Attribute)
                and isinstance(value.func.value, ast.Name)
                and value.func.value.id in self.httpx_module_aliases
                and value.func.attr in {"Client", "AsyncClient"}
            ):
                if isinstance(node, ast.Name):
                    self.httpx_client_instances.add(node.id)
            if (
                isinstance(value, ast.Call)
                and isinstance(value.func, ast.Name)
                and value.func.id in self.httpx_client_class_aliases
            ):
                if isinstance(node, ast.Name):
                    self.httpx_client_instances.add(node.id)

        def visit_Assign(self, node: ast.Assign) -> None:
            for target in node.targets:
                self._record_client_names(target, node.value)
            self.generic_visit(node)

        def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
            if node.value:
                self._record_client_names(node.target, node.value)
            self.generic_visit(node)

    tree = ast.parse(dedent(source))
    collector = _HttpxClientCollector()
    collector.visit(tree)
    return collector.httpx_client_instances


class ImportCollector(ast.NodeVisitor):
    def __init__(self, module_sources: dict[str, str] | None = None) -> None:
        self.requests_functions: Set[str] = set()
        self.requests_module_aliases: Set[str] = set()
        self.time_sleep_aliases: Set[str] = set()
        self.time_module_aliases: Set[str] = set()
        self.httpx_module_aliases: Set[str] = set()
        self.httpx_client_class_aliases: Set[str] = set()
        self.httpx_client_instances: Set[str] = set()
        self.module_sources = module_sources or {}

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            if alias.name == "requests":
                self.requests_module_aliases.add(alias.asname or "requests")
            elif alias.name == "time":
                self.time_module_aliases.add(alias.asname or "time")
            elif alias.name == "httpx":
                self.httpx_module_aliases.add(alias.asname or "httpx")
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module == "requests":
            for alias in node.names:
                self.requests_functions.add(alias.asname or alias.name)
        elif node.module == "time":
            for alias in node.names:
                if alias.name == "sleep":
                    self.time_sleep_aliases.add(alias.asname or "sleep")
        elif node.module == "httpx":
            for alias in node.names:
                if alias.name in {"Client", "AsyncClient"}:
                    self.httpx_client_class_aliases.add(alias.asname or alias.name)
        elif node.module in self.module_sources:
            exported_clients = _collect_httpx_client_names(self.module_sources[node.module])
            for alias in node.names:
                if alias.name in exported_clients:
                    self.httpx_client_instances.add(alias.asname or alias.name)
        self.generic_visit(node)

    def _record_client_names(self, target: ast.AST, value: ast.AST) -> None:
        if (
            isinstance(value, ast.Call)
            and isinstance(value.func, ast.Attribute)
            and isinstance(value.func.value, ast.Name)
            and value.func.value.id in self.httpx_module_aliases
            and value.func.attr in {"Client", "AsyncClient"}
        ):
            if isinstance(target, ast.Name):
                self.httpx_client_instances.add(target.id)
        if (
            isinstance(value, ast.Call)
            and isinstance(value.func, ast.Name)
            and value.func.id in self.httpx_client_class_aliases
        ):
            if isinstance(target, ast.Name):
                self.httpx_client_instances.add(target.id)

    def visit_Assign(self, node: ast.Assign) -> None:
        for target in node.targets:
            self._record_client_names(target, node.value)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value:
            self._record_client_names(node.target, node.value)
        self.generic_visit(node)


class AsyncTransformer(ast.NodeTransformer):
    def __init__(self, collector: ImportCollector) -> None:
        self.made_changes_stack = []
        self.async_file_handles: Set[str] = set()
        self.imports_to_add: Set[str] = set()
        self.collector = collector
        self.in_await = False

    def record_change(self) -> None:
        if self.made_changes_stack:
            self.made_changes_stack[-1] = True

    def _maybe_await(self, node: ast.AST) -> ast.AST:
        if self.in_await:
            return node
        self.record_change()
        return ast.Await(value=node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        self.made_changes_stack.append(False)
        node.args = self.visit(node.args)
        node.body = [self.visit(s) for s in node.body]
        node.decorator_list = [self.visit(d) for d in node.decorator_list]
        if node.returns:
            node.returns = self.visit(node.returns)

        made_changes = self.made_changes_stack.pop()
        if made_changes:
            self.record_change()
            new_node = ast.AsyncFunctionDef(
                name=node.name,
                args=node.args,
                body=node.body,
                decorator_list=node.decorator_list,
                returns=node.returns,
                type_comment=getattr(node, "type_comment", None),
            )
            ast.copy_location(new_node, node)
            ast.fix_missing_locations(new_node)
            return new_node
        return node

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        self.made_changes_stack.append(False)
        node.args = self.visit(node.args)
        node.body = [self.visit(s) for s in node.body]
        node.decorator_list = [self.visit(d) for d in node.decorator_list]
        if node.returns:
            node.returns = self.visit(node.returns)

        made_changes = self.made_changes_stack.pop()
        if made_changes:
            self.record_change()
        return node

    def visit_Await(self, node: ast.Await):
        prev = self.in_await
        self.in_await = True
        node.value = self.visit(node.value)
        self.in_await = prev
        return node

    def visit_ImportFrom(self, node: ast.ImportFrom):
        if node.module == "httpx":
            updated = False
            for alias in node.names:
                if alias.name == "Client":
                    alias.name = "AsyncClient"
                    alias.asname = alias.asname or "Client"
                    updated = True
            if updated:
                self.record_change()
        return self.generic_visit(node)

    def visit_With(self, node: ast.With):
        is_open_call = False
        handle_name = None
        if node.items:
            item = node.items[0]
            if (
                isinstance(item.context_expr, ast.Call)
                and isinstance(item.context_expr.func, ast.Name)
                and item.context_expr.func.id == "open"
            ):
                is_open_call = True
                if item.optional_vars and isinstance(item.optional_vars, ast.Name):
                    handle_name = item.optional_vars.id

        if is_open_call:
            self.record_change()
            self.imports_to_add.add("anyio")
            if handle_name:
                self.async_file_handles.add(handle_name)

            node.items[0].context_expr.func = ast.Attribute(
                value=ast.Name(id="anyio", ctx=ast.Load()),
                attr="open_file",
                ctx=ast.Load(),
            )

            new_body = [self.visit(s) for s in node.body]

            if handle_name:
                self.async_file_handles.remove(handle_name)

            new_node = ast.AsyncWith(
                items=node.items,
                body=new_body,
                type_comment=getattr(node, "type_comment", None),
            )
            ast.copy_location(new_node, node)
            ast.fix_missing_locations(new_node)
            return new_node

        return self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        node = self.generic_visit(node)

        if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
            module_name = node.func.value.id
            if (
                module_name in self.collector.httpx_module_aliases
                and node.func.attr == "Client"
            ):
                node.func.attr = "AsyncClient"
                return node
            if module_name in self.collector.requests_module_aliases:
                node.func.value = ast.Name(id="httpx", ctx=ast.Load())
                self.imports_to_add.add("httpx")
                return self._maybe_await(node)
            if (
                module_name in self.collector.time_module_aliases
                and node.func.attr == "sleep"
            ):
                node.func.value = ast.Name(id="anyio", ctx=ast.Load())
                self.imports_to_add.add("anyio")
                return self._maybe_await(node)

        if isinstance(node.func, ast.Name):
            if node.func.id in self.collector.requests_functions:
                node.func = ast.Attribute(
                    value=ast.Name(id="httpx", ctx=ast.Load()),
                    attr=node.func.id,
                    ctx=ast.Load(),
                )
                self.imports_to_add.add("httpx")
                return self._maybe_await(node)
            if node.func.id in self.collector.time_sleep_aliases:
                node.func = ast.Attribute(
                    value=ast.Name(id="anyio", ctx=ast.Load()),
                    attr="sleep",
                    ctx=ast.Load(),
                )
                self.imports_to_add.add("anyio")
                return self._maybe_await(node)

        if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
            if node.func.value.id in self.collector.httpx_client_instances:
                return self._maybe_await(node)
            if node.func.value.id in self.async_file_handles:
                return self._maybe_await(node)

        return node


def _add_missing_imports(tree: ast.AST, imports: Set[str]) -> None:
    existing_imports = set()
    for body_item in tree.body:
        if isinstance(body_item, ast.Import):
            for name in body_item.names:
                existing_imports.add(name.name)
        if isinstance(body_item, ast.ImportFrom):
            if body_item.module:
                existing_imports.add(body_item.module)

    imports_to_add_nodes = []
    for imp in sorted(list(imports)):
        if imp not in existing_imports:
            imports_to_add_nodes.append(ast.Import(names=[ast.alias(name=imp)]))

    insert_pos = 0
    for i, node in enumerate(tree.body):
        if not isinstance(node, (ast.Import, ast.ImportFrom)):
            insert_pos = i
            break

    tree.body = tree.body[:insert_pos] + imports_to_add_nodes + tree.body[insert_pos:]


def transform_source(
    source: str,
    format_with_black: bool = True,
    module_sources: dict[str, str] | None = None,
) -> str:
    tree = ast.parse(source)
    collector = ImportCollector(module_sources=module_sources)
    collector.visit(tree)
    transformer = AsyncTransformer(collector)
    new_tree = transformer.visit(tree)
    _add_missing_imports(new_tree, transformer.imports_to_add)
    ast.fix_missing_locations(new_tree)
    new_source = ast.unparse(new_tree)
    if format_with_black:
        try:
            return black.format_str(new_source, mode=black.FileMode())
        except Exception:
            return new_source
    return new_source
