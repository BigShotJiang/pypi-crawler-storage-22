from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, NotRequired, TypedDict, overload

import aiohttp

if TYPE_CHECKING:

    class Response(TypedDict):
        meta: Meta
        data: list[Data]

    class Meta(TypedDict):
        status: int

    class Data(TypedDict):
        japanese: list[Japanese]
        senses: list[Sense]

    class Japanese(TypedDict):
        word: NotRequired[str]
        reading: NotRequired[str]

    class Sense(TypedDict):
        english_definitions: list[str]
        parts_of_speech: list[str]

    class Output(TypedDict):
        readings: list[str]
        words: list[str]
        parts_of_speech: list[str]
        english: list[str]


__all__ = ["Jisho"]


class Jisho:
    """The class that makes the API requests. A class is necessary to safely
    handle the aiohttp ClientSession."""

    api_url = "https://jisho.org/api/v1/search/words"

    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, *, loop: asyncio.AbstractEventLoop) -> None: ...

    @overload
    def __init__(self, *, session: aiohttp.ClientSession) -> None: ...

    def __init__(
        self,
        *,
        loop: asyncio.AbstractEventLoop | None = None,
        session: aiohttp.ClientSession | None = None,
    ) -> None:
        if loop is not None and session is not None:
            raise ValueError("Cannot specify both loop and session")
        elif loop is None:
            self._loop = asyncio.get_event_loop()
        else:
            self._loop = loop
        if session is None:
            self._session = aiohttp.ClientSession(loop=self._loop)
            self._close = True
        else:
            self._session = session
            self._close = False

    def __del__(self) -> None:
        # we should always close the session beforehand,
        # but just in case someone doesn't, we'll try
        if self._close:
            try:
                self._loop.create_task(self._session.close())
            except RuntimeError:
                # loop is closed
                pass

    def _parse(self, response: Response) -> list[Output]:
        results: list[Output] = []
        for data in response["data"]:
            readings: set[str] = set()
            words: set[str] = set()

            for jp in data["japanese"]:
                reading = jp.get("reading")
                if reading and reading not in readings:
                    readings.add(reading)

                if word := jp.get("word"):
                    words.add(word)

            english = []
            parts_of_speech = []

            for sense in data["senses"]:
                english.extend(sense.get("english_definitions", ()))
                parts_of_speech.extend(sense.get("parts_of_speech", ()))

            try:
                parts_of_speech.remove("Wikipedia definition")
            except ValueError:
                pass

            result: Output = {
                "readings": list(readings),
                "words": list(words),
                "parts_of_speech": parts_of_speech,
                "english": english,
            }

            results.append(result)

        return results

    async def lookup(self, keyword: str, **kwargs) -> list[Output]:
        """Search Jisho.org for a word. Returns a list of dicts with keys
        readings, words, english, parts_of_speech."""
        params: dict[str, str] = {"keyword": keyword, **kwargs}
        async with self._session.get(self.api_url, params=params) as resp:
            response: Response = await resp.json()
        return self._parse(response)

    async def close(self):
        """Closes the internal ClientSession.
        Only use this if you do not plan to reuse the session,
        such as when you do not specify one in the constructor."""
        await self._session.close()
        self._close = False

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._close:
            await self._session.close()
