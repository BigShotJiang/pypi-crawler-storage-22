import unittest

from asyncjisho import Jisho


class DictTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        await super().asyncSetUp()
        self.jisho = Jisho()

    async def asyncTearDown(self):
        await super().asyncTearDown()
        await self.jisho.close()

    async def test_lookup(self):
        result = (await self.jisho.lookup("to go"))[0]
        assert set(result["readings"]) == {"いく", "ゆく"}
        assert set(result["words"]) == {"行く", "往く"}
        assert "Intransitive verb" in result["parts_of_speech"]
        assert "to go" in result["english"]


if __name__ == "__main__":
    unittest.main()
