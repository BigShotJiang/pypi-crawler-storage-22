import asyncio
from functools import wraps

def run_in_background(func):
    """
        Decorator to run an async function in the background via asyncio.create_task.

        Allows the caller to proceed immediately without waiting for the result.
        Useful for fire-and-forget tasks like timers or notifications.

        Args:
            func: The coroutine function to run.

        Returns:
            None: Returns immediately after scheduling the task.
    """
    @wraps(func)
    async def wrapper(*args, **kwargs):
        async def run_func():
            try:
                await func(*args, **kwargs)
            except asyncio.CancelledError:
                pass
            except Exception as e:
                raise
        asyncio.create_task(run_func())
        return
    return wrapper