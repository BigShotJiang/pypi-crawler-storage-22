# SPDX-License-Identifier: LGPL-2.1-only
# Copyright (c) 2025 Akshat kotpalliwar (alias IntegerAlex)
