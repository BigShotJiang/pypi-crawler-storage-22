# Changelog

## [0.4.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.3.0...v0.4.0) (2026-02-11)


### Features

* functionality to download example data ([#42](https://github.com/maxplanck-ie/ATACofthesnake/issues/42)) ([1be0228](https://github.com/maxplanck-ie/ATACofthesnake/commit/1be0228eca56e23a8045750c0f82bb825cea3a5a))
* handle both cram and bam files ([1be0228](https://github.com/maxplanck-ie/ATACofthesnake/commit/1be0228eca56e23a8045750c0f82bb825cea3a5a))

## [0.3.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.2.0...v0.3.0) (2026-02-09)


### Features

* validate sample presence in samplesheet ([#40](https://github.com/maxplanck-ie/ATACofthesnake/issues/40)) ([f68dd85](https://github.com/maxplanck-ie/ATACofthesnake/commit/f68dd859564af5ad157466a71b50472799b5f170))

## [0.2.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.1.0...v0.2.0) (2026-02-08)


### Features

* scm for versioning ([a5f5575](https://github.com/maxplanck-ie/ATACofthesnake/commit/a5f5575741713571c033b6555d37afa9ce645e82))

## [0.1.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.0.1...v0.1.0) (2026-02-08)


### Features

* drop conda ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
* logger ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
* release rework ([#34](https://github.com/maxplanck-ie/ATACofthesnake/issues/34)) ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
* smk_profile optional ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
