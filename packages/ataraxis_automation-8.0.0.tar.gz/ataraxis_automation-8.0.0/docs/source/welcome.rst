Welcome to ataraxis-automation API documentation page
=====================================================

Supports tox-based development automation pipelines and provides agentic skills for Claude Code used by other Sun
(NeuroAI) lab projects.

This library is part of the broader 'Ataraxis' science-automation project, developed in the
`Sun (NeuroAI) lab <https://neuroai.github.io/sunlab/>`_ at Cornell University.

This website only contains the API documentation for the classes and methods offered by this library. See the project
GitHub repository for installation instructions and library usage examples:
`ataraxis-automation GitHub repository <https://github.com/Sun-Lab-NBB/ataraxis-automation>`_.

.. _`ataraxis-automation GitHub repository`: https://github.com/Sun-Lab-NBB/ataraxis-automation
.. _`Sun (NeuroAI) lab`: https://neuroai.github.io/sunlab/
