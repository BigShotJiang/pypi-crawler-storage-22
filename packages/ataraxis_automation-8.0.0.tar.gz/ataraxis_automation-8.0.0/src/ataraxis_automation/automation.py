"""Provides the assets that support various project development automation Command Line Interface (CLI) commands
exposed by the 'cli' module. Implements the logic of all automation tasks.
"""

import os
import re
import sys
import stat
import time
import shutil
from typing import Any
from pathlib import Path
import textwrap
import subprocess
from dataclasses import dataclass
from configparser import ConfigParser

import click
import tomli

# Stores supported platform (OS) names together with their suffixes. This library is designed to work only with these
# listed operating systems.
_SUPPORTED_PLATFORMS: dict[str, str] = {
    "win32": "_win",
    "linux": "_lin",
    "darwin": "_osx",
}

# Stores the module-level compiled regex pattern for extracting package base names.
_BASE_NAME_PATTERN: re.Pattern[str] = re.compile(r"^([a-zA-Z0-9_.-]+)")

# Stores the maximum number of retry attempts for file operations that may fail due to transient Windows file locks.
_FILE_RETRY_COUNT: int = 5

# Stores the initial delay in seconds between file operation retry attempts. Each subsequent retry doubles the delay.
_FILE_RETRY_INITIAL_DELAY: float = 0.5


@dataclass(frozen=True)
class ProjectEnvironment:
    """Encapsulates the data used to interface with the project's mamba environment.

    This class resolves and stores executable commands used to manage the project environment and important metadata
    information used by these commands.

    Notes:
        This class should not be instantiated directly. Instead, use the `resolve_environment_commands()` class method
        to get an instance of this class.
    """

    activate_command: str
    """Stores the command used to activate the project's mamba environment."""
    deactivate_command: str
    """Stores the command used to deactivate any current environment and switch to the base environment."""
    create_command: str
    """Stores the command used to generate a minimally-configured mamba environment."""
    create_from_yaml_command: str | None
    """Stores the command used to create a new mamba environment from an existing .yml file."""
    remove_command: str
    """Stores the command used to remove (delete) the project's mamba environment."""
    install_dependencies_command: str
    """Stores the command used to install all project dependencies into the project's mamba environment using uv."""
    update_command: str | None
    """Stores the command used to update an already existing mamba environment using an existing .yml file."""
    export_yaml_command: str
    """Stores the command used to export the project's mamba environment to a .yml file."""
    export_spec_command: str
    """Stores the command used to export the project's mamba environment to a spec.txt file with revision history."""
    install_project_command: str
    """Stores the command used to build and install the project as a library into the project's mamba environment."""
    uninstall_project_command: str
    """Stores the command used to uninstall the project library from the project's mamba environment."""
    environment_name: str
    """Stores the name of the project's mamba environment with the appended os-suffix."""
    environment_directory: Path
    """Stores the path to the project's mamba environment directory."""

    @classmethod
    def resolve_project_environment(
        cls,
        project_root: Path,
        environment_name: str,
        python_version: str = "3.13",
        environment_directory: Path | None = None,
        *,
        prerelease: bool = False,
    ) -> "ProjectEnvironment":
        """Generates the mamba and uv commands used to manipulate the project- and os-specific mamba
        environment and packages them into a ProjectEnvironment instance.

        Args:
            project_root: The absolute path to the root directory of the processed project.
            environment_name: The base-name of the project's mamba environment.
            python_version: The Python version to use as part of the new environment creation or provisioning runtimes.
            environment_directory: Optional. The absolute path to the directory used by the mamba / conda manager to
                store Python environments. This argument only needs to be provided if the automatic (default)
                environment resolution fails.
            prerelease: Determines whether uv is allowed to install prerelease versions of dependencies.

        Returns:
            The resolved ProjectEnvironment instance.

        Raises:
            RuntimeError: If the host OS is unsupported, mamba or uv is not accessible, or the mamba environments
                directory cannot be resolved and no manual override is provided.
            ValueError: If the project name cannot be extracted from pyproject.toml or duplicate dependencies are
                found.
        """
        # Gets the environment name with the appropriate os-extension and the paths to the .yml and /spec files.
        extended_environment_name, yaml_path, spec_path = _resolve_environment_files(project_root, environment_name)

        # Gets the name of the project from the pyproject.toml file.
        project_name = _resolve_project_name(project_root=project_root)

        # Verifies that mamba and uv are accessible to the caller.
        _check_package_engines()

        # Resolves the physical path to the project's mamba environment directory.
        try:
            target_environment_directory = _resolve_mamba_environments_directory().joinpath(extended_environment_name)
        # Only uses the manual override if the automated resolution fails.
        except RuntimeError:
            if environment_directory is not None:
                target_environment_directory = environment_directory.joinpath(extended_environment_name)
            else:
                # If no manual override is available, re-raises the original error.
                raise

        # Generates commands that depend on the host OS type. Relies on resolve_environment_files() method to err if
        # the host is running an unsupported OS, as the OS versions evaluated below are the same as used by
        # resolve_environment_files(). Also generates the list of platform-specific dependencies.

        # WINDOWS
        if "_win" in extended_environment_name:
            # .yml export
            export_yaml_command = (
                f'mamba env export --name {extended_environment_name} --use-uv | findstr -v "prefix" > {yaml_path}'
            )

            # Mamba environment activation and deactivation commands. Still uses 'conda' for activation due to more
            # streamlined behavior and no performance downsides.
            conda_initialization_command = "call conda.bat >NUL 2>&1"  # Redirects stdout and stderr to null

        # LINUX
        elif "_lin" in extended_environment_name:
            # .yml export
            export_yaml_command = (
                f"mamba env export --name {extended_environment_name} --use-uv | head -n -1 > {yaml_path}"
            )

            # Conda environment activation command
            conda_initialization_command = ". $(conda info --base)/etc/profile.d/conda.sh"

        # MACOS
        else:
            # .yml export
            export_yaml_command = (
                f"mamba env export --name {extended_environment_name} --use-uv | tail -r | "
                f"tail -n +2 | tail -r > {yaml_path}"
            )

            # Conda environment activation command.
            conda_initialization_command = ". $(conda info --base)/etc/profile.d/conda.sh"

        # Resolves activation and deactivation commands using the resolved conda initialization command.
        activate_command = f"{conda_initialization_command} && conda activate {target_environment_directory}"
        deactivate_command = f"{conda_initialization_command} && conda deactivate"

        # Generates the spec.txt export command, which is the same for all OS versions (unlike .yml export).
        export_spec_command = f"mamba list -n {extended_environment_name} --use-uv --explicit > {spec_path}"

        # Generates dependency installation commands using uv:
        prerelease_flag = " --prerelease=allow" if prerelease else ""
        install_dependencies_command = (
            f"uv pip install {' '.join(_resolve_dependencies(project_root))} --resolution highest "
            f"--refresh --compile-bytecode --python={target_environment_directory} --strict --exact{prerelease_flag}"
        )
        uninstall_project_command = f"uv pip uninstall {project_name} --python={target_environment_directory}"
        install_project_command = (
            f"uv pip install . --resolution highest --refresh --reinstall-package {project_name} --compile-bytecode "
            f"--python={target_environment_directory} --strict{prerelease_flag}"
        )

        # Generates mamba environment manipulation commands.
        # Creation (base) generates a minimal mamba environment. It is expected that mamba and uv dependencies
        # are added via separate dependency commands generated above. Note, installs the latest versions of tox, uv,
        # and tox-uv with the expectation that dependency installation commands use --reinstall to override the
        # versions of these packages as necessary.
        create_command: str = (
            f"mamba create -n {extended_environment_name} python={python_version} uv tox tox-uv --yes "
            f"--retry-clean-cache --pyc --use-uv"
        )
        remove_command: str = f"mamba remove -n {extended_environment_name} --all --yes"

        # Resolves .yml based commands. These commands are set to valid string-commands only if the .yml file for the
        # project's environment exists and to None otherwise.
        yaml_create_command: str | None = None
        update_command: str | None = None
        if yaml_path.exists():
            yaml_create_command = f"mamba env create -f {yaml_path} --yes --retry-clean-cache --pyc --use-uv"
            update_command = f"mamba env update -n {extended_environment_name} -f {yaml_path} --yes --prune --use-uv"

        return cls(
            activate_command=activate_command,
            deactivate_command=deactivate_command,
            export_yaml_command=export_yaml_command,
            export_spec_command=export_spec_command,
            create_command=create_command,
            create_from_yaml_command=yaml_create_command,
            remove_command=remove_command,
            install_dependencies_command=install_dependencies_command,
            update_command=update_command,
            environment_name=extended_environment_name,
            install_project_command=install_project_command,
            uninstall_project_command=uninstall_project_command,
            environment_directory=target_environment_directory,
        )

    def environment_exists(self) -> bool:
        """Determines whether the environment can be activated (exists)."""
        # Verifies that the project- and os-specific mamba environment can be activated.
        try:
            subprocess.run(
                self.activate_command,
                shell=True,
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except subprocess.CalledProcessError:
            return False
        else:
            return True


def format_message(message: str) -> str:
    """Formats input message strings to follow the general Sun lab and project Ataraxis style.

    Args:
        message: The input message string to format.

    Returns:
        The formatted message string.
    """
    return textwrap.fill(
        text=message,
        width=120,
        break_long_words=False,
        break_on_hyphens=False,
    )


def colorize_message(message: str, color: str, *, wrap: bool = True) -> str:
    """Modifies the input string to include an ANSI color code and, if necessary, formats the message by wrapping it
    at 120 characters.

    Args:
        message: The input message string to format and colorize.
        color: The ANSI color code to use for coloring the message.
        wrap: Determines whether to format the message by wrapping it at 120 lines.

    Returns:
        The colorized and wrapped (if requested) message string.
    """
    if wrap:
        message = format_message(message)

    return click.style(text=message, fg=color)


def resolve_project_directory() -> Path:
    """Resolves the current working directory and verifies that it points to a valid Sun lab project.

    Returns:
        The absolute path to the current working directory, if it points to a valid Sun lab project.

    Raises:
        RuntimeError: If the current working directory does not point to a valid Sun lab project.
    """
    # Gets current working directory
    project_dir = Path.cwd()

    # Checks if the current working directory points to a valid Sun lab project based on the presence of required
    # files in the root directory.
    required_items = {
        project_dir.joinpath("src"),
        project_dir.joinpath("envs"),
        project_dir.joinpath("pyproject.toml"),
        project_dir.joinpath("tox.ini"),
    }
    if not all(item.exists() for item in required_items):
        message: str = (
            f"Unable to confirm that ataraxis automation CLI has been called from the root directory of a valid "
            f"Python project. This CLI expects that the current working directory is set to the root directory of the "
            f"project, judged by the presence of '/src', '/envs', 'pyproject.toml' and 'tox.ini'. Current working "
            f"directory is set to {project_dir}, which does not contain at least one of the required files."
        )
        raise RuntimeError(format_message(message))

    return project_dir


def resolve_library_root(project_root: Path) -> Path:
    """Resolves the absolute path to the project's root library directory.

    Notes:
        This function relies on the following resolution heuristic: library root is a directory at most one
        level below /src with an __init__.py file.

    Args:
        project_root: The absolute path to the root directory of the processed project.

    Returns:
        The absolute path to the root library directory.

    Raises:
        RuntimeError: If the valid root directory candidate cannot be found based on the determination heuristics.
    """
    # Resolves the target directory
    src_path: Path = project_root.joinpath("src")

    # If the __init__.py is found inside the /src directory, this indicates /src is the library root. This is typically
    # true for C-extension projects, but not for pure Python project.
    if src_path.joinpath("__init__.py").exists():
        return src_path

    # If __init__.py is not found at the level of the src, this implies that the processed project is a pure python
    # project and, in this case, it is expected that there is a single library-directory under /src that is the
    # root.

    # Discovers all candidates for the library root directory. Candidates are expected to be directories directly under
    # /src that also contain an __init__.py file.
    candidates: set[Path] = {
        candidate_path
        for candidate_path in src_path.iterdir()
        if candidate_path.is_dir() and (candidate_path.joinpath("__init__.py")).exists()
    }

    # The expectation is that there is exactly one candidate that fits the requirements. If this is not true, the
    # project structure is not well-configured and should not be processed.
    if len(candidates) != 1:
        message: str = (
            f"Unable to resolve the path to the library root directory from the project root path {project_root}. "
            f"Specifically, did not find an __init__.py inside the /src directory and found {len(candidates)} "
            f"sub-directories with __init__.py inside the /src directory. Make sure there is an __init__.py "
            f"inside /src or ONE of the sub-directories under /src."
        )
        raise RuntimeError(format_message(message))

    return candidates.pop()


def generate_typed_marker(library_root: Path) -> None:
    """Crawls the library directory tree and ensures that the py.typed marker exists only at the root level of the
    directory.

    If the 'py.typed' is not found in the root directory, adds the marker file. If it is found in any subdirectory,
    removes the marker file.

    Args:
        library_root: The path to the root level of the library directory.
    """
    # Adds py.typed to the root directory if it doesn't exist
    root_py_typed = library_root.joinpath("py.typed")
    if not root_py_typed.exists():
        root_py_typed.touch()
        message: str = f"Added py.typed marker to library root ({library_root})."
        click.echo(colorize_message(message, color="white"), color=True)

    # Removes py.typed from all subdirectories
    for path in library_root.rglob("py.typed"):
        if path != root_py_typed:
            _unlink_with_retry(path)
            message = f"Removed no longer needed py.typed marker file {path}."
            click.echo(colorize_message(message, color="white"), color=True)


def move_stubs(stubs_directory: Path, library_root: Path) -> None:
    """Moves typing stub (.pyi) files from the 'stubs' directory to the appropriate level(s) of the library directory
    tree.

    This function should be called after running stubgen on the built library package (wheel). It distributes the stubs
    generated by stubgen to their final destinations in the library source code.

    Notes:
        This function expects that the 'stubs' directory has exactly one subdirectory, which contains an __init__.pyi
        file. This subdirectory is considered to be the library root in the 'stubs' directory structure.

    Args:
        stubs_directory: The absolute path to the project's "stubs" directory.
        library_root: The absolute path to the root library directory.
    """
    # Compiles regex patterns once to optimize the cycles below
    copy_pattern = re.compile(r" (\d+)\.pyi$")
    base_name_pattern = re.compile(r" \d+\.pyi$")

    # Verifies the 'stubs' directory structure and finds the library name. To do so, first generates a set of all
    # subdirectories under /stubs that also have an __init__.pyi file.
    valid_subdirectories = [
        sub_dir
        for sub_dir in stubs_directory.iterdir()
        if sub_dir.is_dir() and sub_dir.joinpath("__init__.pyi").exists()
    ]

    # Expects that the process above yields a single output directory. Otherwise, raises a RuntimeError.
    if len(valid_subdirectories) != 1:
        message: str = (
            f"Unable to move the generated stub files to appropriate levels of the library source code directory. "
            f"Expected exactly one subdirectory with __init__.pyi in '{stubs_directory}', but found "
            f"{len(valid_subdirectories)}."
        )
        raise RuntimeError(format_message(message))

    # Extracts the single valid directory and uses it as the source for .pyi files.
    source_directory = valid_subdirectories[0]

    # Moves .pyi files from source to destination and tracks moved files for duplicate handling.
    # Assumes that the structure of the source_directory exactly matches the structure of the library_root.
    moved_files: dict[Path, list[Path]] = {}

    for stub_path in source_directory.rglob("*.pyi"):
        relative_path = stub_path.relative_to(source_directory)
        destination_path = library_root.joinpath(relative_path)

        # Ensures the destination directory exists
        destination_path.parent.mkdir(parents=True, exist_ok=True)

        # Removes the old .pyi file if it already exists
        _unlink_with_retry(destination_path, missing_ok=True)

        # Moves the stub file to its destination directory using rename (this is more efficient than shutil.move)
        _rename_with_retry(stub_path, destination_path)

        message = f"Moved stub file from /stubs to /src: {destination_path.name}."
        click.echo(colorize_message(message, color="white"), color=True)

        # Tracks moved files by directory for duplicate handling
        moved_files.setdefault(destination_path.parent, []).append(destination_path)

    # This section handles an OSX-unique issue, where this function produces multiple copies that
    # have space+copy_number appended to each file name, rather than a single copy of the .pyi file.

    # Processes each directory that received stub files
    for directory_path, files in moved_files.items():
        # Groups files by their base name (without space and number)
        file_groups: dict[str, list[Path]] = {}
        for file_path in files:
            # Extracts base name without copy number
            base_name = base_name_pattern.sub(".pyi", file_path.name)
            file_groups.setdefault(base_name, []).append(file_path)

        # Handles duplicates within each group
        for base_name, group in file_groups.items():
            # If the group only has a single file, renames it if it has a copy number
            if len(group) == 1:
                file_path = group[0]
                if file_path.name != base_name:
                    new_path = file_path.with_name(base_name)
                    _rename_with_retry(file_path, new_path)
                    message = f"Renamed stub file in {directory_path}: {file_path.name} -> {base_name}."
                    click.echo(colorize_message(message, color="white"), color=True)
            # If the group has multiple files, keeps the one with the highest copy number
            else:
                # Sorts by copy number in the descending order and keeps the first item
                group.sort(key=lambda path: _get_copy_number(path, copy_pattern=copy_pattern), reverse=True)
                kept_file = group[0]

                # Removes all duplicates
                for file_to_remove in group[1:]:
                    _unlink_with_retry(file_to_remove)
                    message = f"Removed duplicate .pyi file in {directory_path}: {file_to_remove.name}."
                    click.echo(colorize_message(message, color="white"), color=True)

                # Renames the kept file to remove copy number if needed
                if kept_file.name != base_name:
                    new_path = kept_file.with_name(base_name)
                    _rename_with_retry(kept_file, new_path)
                    message = f"Renamed stub file in {directory_path}: {kept_file.name} -> {base_name}."
                    click.echo(colorize_message(message, color="white"), color=True)


def delete_stubs(library_root: Path) -> None:
    """Removes all .pyi stub files from the root library directory and its subdirectories.

    Args:
        library_root: The absolute path to the root library directory.
    """
    # Iterates over all .pyi files in the directory tree and removes them.
    pyi_file: Path
    for pyi_file in library_root.rglob("*.pyi"):
        _unlink_with_retry(pyi_file)
        click.echo(colorize_message(f"Removed stub file: {pyi_file.name}.", color="white"), color=True)


def verify_pypirc(file_path: Path) -> bool:
    """Verifies that the target .pypirc file contains valid PyPI authentication credentials (API token).

    Notes:
        This function is not able to verify whether the token is currently active.

    Args:
        file_path: The absolute path to the .pypirc file to verify.

    Returns:
        True if the .pypirc file appears to contain a well-configured API token and False otherwise.
    """
    config_validator: ConfigParser = ConfigParser()
    config_validator.read(file_path)
    return (
        config_validator.has_section("pypi")
        and config_validator.has_option("pypi", "username")
        and config_validator.has_option("pypi", "password")
        and config_validator.get("pypi", "username") == "__token__"
        and config_validator.get("pypi", "password").startswith("pypi-")
    )


def robust_rmtree(path: Path) -> None:
    """Removes a directory tree with retry logic to handle transient Windows file locks.

    On Windows, antivirus scanners, the Search Indexer, and recently-exited processes can hold file handles briefly
    after the calling process has finished with them. This function wraps ``shutil.rmtree()`` with an ``onerror``
    handler that clears read-only attributes and an outer retry loop with exponential backoff to tolerate these
    transient locks. On non-Windows platforms, calls ``shutil.rmtree()`` directly with no retry overhead.

    Args:
        path: The absolute path to the directory tree to remove.

    Raises:
        PermissionError: If the directory cannot be removed after exhausting all retry attempts on Windows, or
            immediately on non-Windows platforms.
    """
    # On non-Windows platforms, file locks are advisory, so no retry logic is needed.
    if sys.platform != "win32":
        shutil.rmtree(path)
        return

    # On Windows, retries with exponential backoff to tolerate transient file locks.
    delay = _FILE_RETRY_INITIAL_DELAY
    for attempt in range(_FILE_RETRY_COUNT):
        try:
            shutil.rmtree(path, onerror=_rmtree_onerror)
        except PermissionError:
            if attempt < _FILE_RETRY_COUNT - 1:
                time.sleep(delay)
                delay *= 2
            else:
                raise
        else:
            return


def _rmtree_onerror(func: Any, path: str, exc_info: Any) -> None:
    """Handles errors during ``shutil.rmtree()`` by clearing the Windows read-only attribute and retrying.

    This is passed as the ``onerror`` callback to ``shutil.rmtree()``. When Windows marks files as read-only during
    concurrent operations, this handler clears the read-only flag and retries the failed deletion. Non-PermissionError
    exceptions are re-raised.

    Args:
        func: The function that raised the exception (e.g., ``os.remove`` or ``os.rmdir``).
        path: The path to the file or directory that could not be removed.
        exc_info: The exception information tuple returned by ``sys.exc_info()``.

    Raises:
        OSError: If the original exception is not a PermissionError.
    """
    exception = exc_info[1]
    if isinstance(exception, PermissionError):
        Path(path).chmod(stat.S_IWRITE)
        func(path)
    else:
        raise exception


def _unlink_with_retry(path: Path, *, missing_ok: bool = False) -> None:
    """Removes a file with retry logic to handle transient Windows file locks.

    On Windows, retries up to ``_FILE_RETRY_COUNT`` times with exponential backoff when a ``PermissionError`` is
    encountered. On non-Windows platforms, calls ``Path.unlink()`` directly with no retry overhead.

    Args:
        path: The absolute path to the file to remove.
        missing_ok: Determines whether to suppress ``FileNotFoundError`` if the file does not exist.

    Raises:
        PermissionError: If the file cannot be removed after exhausting all retry attempts on Windows, or immediately
            on non-Windows platforms.
    """
    if sys.platform != "win32":
        path.unlink(missing_ok=missing_ok)
        return

    delay = _FILE_RETRY_INITIAL_DELAY
    for attempt in range(_FILE_RETRY_COUNT):
        try:
            path.unlink(missing_ok=missing_ok)
        except PermissionError:
            if attempt < _FILE_RETRY_COUNT - 1:
                time.sleep(delay)
                delay *= 2
            else:
                raise
        else:
            return


def _rename_with_retry(source: Path, destination: Path) -> None:
    """Renames a file with retry logic to handle transient Windows file locks.

    On Windows, retries up to ``_FILE_RETRY_COUNT`` times with exponential backoff when a ``PermissionError`` is
    encountered. On non-Windows platforms, calls ``Path.rename()`` directly with no retry overhead.

    Args:
        source: The absolute path to the file to rename.
        destination: The absolute path to the target file name.

    Raises:
        PermissionError: If the file cannot be renamed after exhausting all retry attempts on Windows, or immediately
            on non-Windows platforms.
    """
    if sys.platform != "win32":
        source.rename(destination)
        return

    delay = _FILE_RETRY_INITIAL_DELAY
    for attempt in range(_FILE_RETRY_COUNT):
        try:
            source.rename(destination)
        except PermissionError:
            if attempt < _FILE_RETRY_COUNT - 1:
                time.sleep(delay)
                delay *= 2
            else:
                raise
        else:
            return


def _get_copy_number(path: Path, copy_pattern: re.Pattern[str]) -> int:
    """Extracts the copy number from a stub file path name for duplicate sorting.

    Args:
        path: The path to the stub file to extract the copy number from.
        copy_pattern: The compiled regex pattern used to match copy number suffixes.

    Returns:
        The extracted copy number, or 0 if no copy number is present.
    """
    match = copy_pattern.search(path.name)
    return int(match.group(1)) if match else 0


def _get_base_name(dependency: str) -> str:
    """Extracts the base name of a dependency, removing versions, extras, and platform markers.

    Args:
        dependency: The dependency name to process.

    Returns:
        The process dependency name, stripped of version, platform, and any other modifiers.
    """
    # Strips quotes if present
    dependency = dependency.strip("\"'")

    # Strips platform markers first (anything after semicolon)
    dependency = dependency.split(";")[0].strip()

    # Uses regex to extract the base package name, removing extras and version specifiers in one operation
    match = _BASE_NAME_PATTERN.match(dependency)
    return match.group(1) if match else dependency.strip()


def _add_dependency(dependency: str, dependencies: list[str], processed_dependencies: set[str]) -> None:
    """Verifies that dependency base-name is not already added to the input list and, if not, adds it to the list.

    This method ensures that each dependency only appears in a single pyproject.toml dependency list, preventing
    listing dependencies as both required and development.

    Notes:
        As part of its runtime, it modifies the input 'dependencies' list and 'processed_dependencies' set to include
        resolved dependency names.

    Args:
        dependency: The name of the evaluated dependency.
        dependencies: The list to which the processed dependency is added if it passes verification.
        processed_dependencies: The set used to store already processed dependencies.

    Raises:
        ValueError: If the extracted dependency is found in multiple pyproject.toml dependency lists.
    """
    # Strips the version, extras, and platform markers from dependencies to verify they are not duplicates
    stripped_dependency: str = _get_base_name(dependency=dependency)
    if stripped_dependency in processed_dependencies:
        message: str = (
            f"Unable to resolve project dependencies. Found a duplicate dependency for '{dependency}', listed in the "
            f"pyproject.toml file. A dependency should only be found once across the 'dependencies' and "
            f"'dependency-groups' lists."
        )
        raise ValueError(format_message(message))

    # Wraps dependency in quotes to properly handle version specifiers and platform markers when dependencies are
    # installed via uv. This is needed for 'special' version specifications that use < or > and similar notations,
    # as well as for platform markers containing spaces.
    dependencies.append(f'"{dependency}"')
    processed_dependencies.add(stripped_dependency)


def _resolve_dependencies(project_root: Path) -> tuple[str, ...]:
    """Extracts project dependencies from pyproject.toml as a tuple of all dependencies (runtime and development).

    Notes:
        Reads runtime dependencies from ``[project].dependencies`` and development dependencies from
        ``[dependency-groups].dev`` (PEP 735). Falls back to ``[project.optional-dependencies].dev`` for backward
        compatibility with projects that have not yet migrated. As part of its runtime, this function also ensures
        that each dependency appears in only one list, preventing duplicates.

    Args:
        project_root: The absolute path to the root directory of the processed project.

    Returns:
        A tuple that stores the extracted and verified dependencies.

    Raises:
        ValueError: If duplicate dependencies (based on versionless dependency names) are found in different pyproject
            dependency lists.
    """
    # Resolves the paths to the .toml file. The function that generates the project root path checks for
    # the presence of this file as part of its runtime, so it is assumed that it always exists.
    pyproject_path: Path = project_root.joinpath("pyproject.toml")

    # Opens pyproject.toml and parses its contents
    with pyproject_path.open(mode="rb") as toml_file:
        pyproject_data = tomli.load(toml_file)

    # Extracts runtime dependencies from the main 'project' metadata section.
    project_data: dict[str, Any] = pyproject_data.get("project", {})
    dependencies: list[str] = project_data.get("dependencies", [])

    runtime_dependencies: list[str] = []  # Stores all platform-applicable runtime dependencies
    development_dependencies: list[str] = []  # Stores all platform-applicable development dependencies
    processed_dependencies: set[str] = set()  # Keeps track of duplicates to prevent double-listing

    # Processes runtime dependencies first. These are the core dependencies required for the project to function.
    for dependency in dependencies:
        _add_dependency(
            dependency=dependency,
            dependencies=runtime_dependencies,
            processed_dependencies=processed_dependencies,
        )

    # Extracts development dependencies. Prefers PEP 735 dependency groups over legacy optional-dependencies.
    dependency_groups: dict[str, Any] = pyproject_data.get("dependency-groups", {})
    if "dev" in dependency_groups:
        for dependency in dependency_groups["dev"]:
            # Skips PEP 735 include-group references (dict entries), only processes string dependencies.
            if isinstance(dependency, str):
                _add_dependency(
                    dependency=dependency,
                    dependencies=development_dependencies,
                    processed_dependencies=processed_dependencies,
                )
    else:
        # Falls back to legacy optional-dependencies for backward compatibility with unmigrated projects.
        optional_dependencies: dict[str, list[str]] = project_data.get("optional-dependencies", {})
        if "dev" in optional_dependencies:
            for dependency in optional_dependencies["dev"]:
                _add_dependency(
                    dependency=dependency,
                    dependencies=development_dependencies,
                    processed_dependencies=processed_dependencies,
                )

    # Merges the two dependency lists and returns the merged list to caller as a tuple
    runtime_dependencies.extend(development_dependencies)
    return tuple(runtime_dependencies)


def _resolve_project_name(project_root: Path) -> str:
    """Extracts the project name from the pyproject.toml file.

    Args:
        project_root: The absolute path to the root directory of the processed project.

    Returns:
        The name of the project.

    Raises:
        ValueError: If the project name is not defined in the pyproject.toml file. Also, if the pyproject.toml file is
            corrupted or otherwise malformed.
    """
    # Resolves the path to the pyproject.toml file
    pyproject_path: Path = project_root.joinpath("pyproject.toml")

    # Reads and parses the pyproject.toml file
    try:
        with pyproject_path.open(mode="rb") as toml_file:
            pyproject_data: dict[str, Any] = tomli.load(toml_file)
    except tomli.TOMLDecodeError as e:
        message: str = (
            f"Unable to parse the pyproject.toml file. The file may be corrupted or contains invalid TOML syntax. "
            f"Error details: {e}."
        )
        raise ValueError(format_message(message)) from None

    # Extracts the project name from the [project] section
    project_data: dict[str, Any] = pyproject_data.get("project", {})
    project_name: str | None = project_data.get("name")

    # Checks if the project name was successfully extracted
    if project_name is None:
        message = (
            "Unable to resolve the project name from the pyproject.toml file. The 'name' field is missing or "
            "empty in the [project] section of the file."
        )
        raise ValueError(format_message(message))

    return project_name


def _resolve_mamba_environments_directory() -> Path:
    """Returns the absolute path to the local mamba environments directory.

    Returns:
        The absolute path to the mamba environments directory.

    Raises:
        RuntimeError: If mamba (via miniforge) is not installed and/or initialized.
    """
    # First tries to use CONDA_PREFIX (mamba uses the same environment variables as conda)
    mamba_prefix = os.environ.get("CONDA_PREFIX")
    if mamba_prefix:
        mamba_prefix_path = Path(mamba_prefix)
        # If the 'base' environment is active, the prefix points to the root mamba manager folder and needs to be
        # extended with 'envs'.
        if os.environ.get("CONDA_DEFAULT_ENV") == "base":
            return mamba_prefix_path.joinpath("envs")

        # Otherwise, for named environments, the root /envs directory is one level below the named directory:
        # e.g., /path/to/miniforge3/envs/myenv -> /path/to/miniforge3/envs
        return mamba_prefix_path.parent

    # The call above does not resolve the mamba environment when this method runs in a tox environment, which is the
    # intended runtime scenario. Therefore, attempts to find the mamba environments directory manually.

    # Method 1: Checks whether this script is executed from a miniforge-based python shell.
    python_executable = Path(sys.executable)

    if "miniforge" in str(python_executable).lower():
        # Navigates up until it finds the miniforge root.
        current = python_executable.parent
        while current != current.parent:  # Stops at root
            # If the 'envs' directory is found while ascending towards the root, returns the directory path to caller
            if current.name == "envs":
                return current

            # If the 'conda-meta' directory is found while ascending towards the root, this indicates that this is the
            # root of a mamba environment manager.
            if current.joinpath("conda-meta").exists():
                # In a mamba environment, the /envs folder will be found directly under the root
                environments_path = current.joinpath("envs")
                if environments_path.exists():
                    return environments_path

                # Otherwise, navigates up to find envs
                if current.parent.name == "envs":
                    return current.parent

            current = current.parent

    # Method 2: Tries to find mamba by locating mamba/conda executable (mamba uses CONDA_EXE).
    mamba_executable = os.environ.get("CONDA_EXE")
    if mamba_executable:
        environments_directory = Path(mamba_executable).parents[1].joinpath("envs")
        if environments_directory.exists():
            return environments_directory

    # Method 3: Checks the standard miniforge3 installation location.
    home = Path.home()

    # Standard miniforge3 location on Unix-like systems
    miniforge_environments = home.joinpath("miniforge3", "envs")
    if miniforge_environments.exists():
        return miniforge_environments

    # On Windows, also checks the AppData location
    if sys.platform == "win32":
        # First try: constructs the path from user's home directory
        windows_miniforge_environments = home.joinpath("AppData", "Local", "miniforge3", "envs")
        if windows_miniforge_environments.exists():
            return windows_miniforge_environments

        # Fallback: uses LOCALAPPDATA environment variable
        local_appdata = os.environ.get("LOCALAPPDATA")
        if local_appdata:
            windows_miniforge_environments = Path(local_appdata).joinpath("miniforge3", "envs")
            if windows_miniforge_environments.exists():
                return windows_miniforge_environments

    # If this point is reached, miniforge is not installed and/or initialized. Raises an error.
    message: str = (
        "Unable to resolve the path to the mamba environments directory. This version of ataraxis-automation expects "
        "that mamba is installed via miniforge3, following the deprecation of mambaforge. Make sure miniforge3 is "
        "installed and initialized before using ataraxis-automation cli. Install from: "
        "https://github.com/conda-forge/miniforge"
    )
    raise RuntimeError(format_message(message))


def _resolve_environment_files(project_root: Path, environment_base_name: str) -> tuple[str, Path, Path]:
    """Determines the Operating System of the host platform and uses it to generate the absolute paths to the
    os-specific mamba environment '.yml' and 'spec.txt' files.

    Notes:
        Currently, this command supports the following Operating Systems: macOS (ARM64: Darwin), Linux (AMD64), and
        Windows (AMD64).

    Args:
        project_root: The absolute path to the root directory of the processed project.
        environment_base_name: The name of the environment excluding the os_suffix, e.g.: 'axa_dev'.

    Returns:
        A tuple of three elements. The first element is the name of the environment with the os-suffix, suitable
        for local mamba commands. The second element is the absolute path to the os-specific environment's '.yml'
        file. The third element is the absolute path to the os-specific environment's 'spec.txt' file.

    Raises:
        RuntimeError: If the host OS does not match any of the supported operating systems.
    """
    os_name: str = sys.platform  # Obtains host os name

    # If the os name is not one of the supported names, raises an error
    if os_name not in _SUPPORTED_PLATFORMS:
        message: str = (
            f"Unable to resolve the operating-system-specific suffix to use for mamba environment file names. The "
            f"local machine is using an unsupported operating system '{os_name}'. Currently, only the following "
            f"operating systems are supported: {', '.join(_SUPPORTED_PLATFORMS.keys())}."
        )
        raise RuntimeError(format_message(message))

    # Resolves the absolute path to the 'envs' directory.
    environments_directory: Path = project_root.joinpath("envs")

    # Selects the environment name according to the host OS and constructs the path to the environment .yml and spec
    # files using the generated name.
    os_suffix = _SUPPORTED_PLATFORMS[os_name]
    environment_name: str = f"{environment_base_name}{os_suffix}"
    yaml_path: Path = environments_directory.joinpath(f"{environment_name}.yml")
    spec_path: Path = environments_directory.joinpath(f"{environment_name}_spec.txt")

    return environment_name, yaml_path, spec_path


def _check_package_engines() -> None:
    """Determines whether mamba and uv can be accessed from this script by silently calling 'COMMAND --version'.

    Raises:
        RuntimeError: If either mamba or uv is not accessible via subprocess call through the shell.
    """
    # Verifies that mamba is available for environment management operations
    try:
        subprocess.run(
            "mamba --version",
            shell=True,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        # If mamba is not available, raises an error as it is now required
        message: str = (
            "Unable to interface with mamba for environment management. Mamba is required for this automation "
            "module and provides significantly faster conda operations. Install mamba (e.g., via miniforge3) and "
            "ensure it is initialized and added to PATH."
        )
        raise RuntimeError(format_message(message)) from None

    # Verifies that uv is available for package installation operations
    try:
        subprocess.run(
            "uv --version",
            shell=True,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        # If uv is not available, raises an error as it is now required
        message = (
            "Unable to interface with uv for package installation. uv is required for this automation module and "
            "provides significantly faster pip operations. Install uv (e.g., 'pip install uv' or 'mamba install uv') "
            "in the active Python environment."
        )
        raise RuntimeError(format_message(message)) from None
