<!-- Project-Specific Rules -->
<!-- Add rules specific to your project here. Examples: -->
<!-- - Don't modify the /v1/ API endpoints without approval -->
<!-- - Always update CHANGELOG.md when adding features -->
<!-- - Database migrations must be backward-compatible -->
