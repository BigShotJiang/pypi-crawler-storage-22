"""Modal serverless processing backend for atdata datasets."""

from atdata_lambda._config import S3Config, ShardIndex, list_shards, s3_env_var_names
from atdata_lambda._dispatcher import Dispatcher, JobResult, create_dispatch_endpoint
from atdata_lambda._manifest import (
    ManifestBuilder,
    ManifestWriter,
    ShardManifest,
    write_manifest,
)
from atdata_lambda._processor import ProcessorError, processor
from atdata_lambda._shard_worker import ShardResult

__all__ = [
    "Dispatcher",
    "JobResult",
    "ManifestBuilder",
    "ManifestWriter",
    "ProcessorError",
    "S3Config",
    "ShardIndex",
    "ShardManifest",
    "ShardResult",
    "create_dispatch_endpoint",
    "list_shards",
    "processor",
    "s3_env_var_names",
    "write_manifest",
]
