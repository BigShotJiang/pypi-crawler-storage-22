"""Runtime configuration for S3-compatible storage and Modal compute."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import boto3

if TYPE_CHECKING:
    from mypy_boto3_s3 import S3Client

DEFAULT_SECRET_NAME = "s3-credentials"
"""Default Modal Secret name for S3 credentials."""

_REQUIRED_SUFFIXES = ("ENDPOINT_URL", "ACCESS_KEY_ID", "SECRET_ACCESS_KEY", "BUCKET")
_ALL_SUFFIXES = (*_REQUIRED_SUFFIXES, "REGION")


def s3_env_var_names(
    prefixes: tuple[str, ...] = ("S3_", "S3_INPUT_", "S3_OUTPUT_"),
) -> list[str]:
    """Return all S3 env var names across the given prefixes.

    Useful for ``modal.Secret.from_local_environ()`` so it forwards exactly
    the vars the workers need.
    """
    return [f"{p}{s}" for p in prefixes for s in _ALL_SUFFIXES]


@dataclass(frozen=True)
class S3Config:
    """S3-compatible storage connection configuration.

    Works with any S3-compatible backend (AWS S3, Cloudflare R2, MinIO, etc.).

    Environment variable convention:
        - Shared (single backend): ``S3_ENDPOINT_URL``, ``S3_ACCESS_KEY_ID``,
          ``S3_SECRET_ACCESS_KEY``, ``S3_BUCKET``
        - Input-specific: ``S3_INPUT_ENDPOINT_URL``, etc.
        - Output-specific: ``S3_OUTPUT_ENDPOINT_URL``, etc.

    Prefixed vars take precedence; unprefixed ``S3_*`` vars are used as fallback.
    """

    endpoint_url: str
    access_key_id: str
    secret_access_key: str
    bucket: str
    region: str = "auto"

    @classmethod
    def from_env(
        cls,
        prefix: str = "S3_",
        *,
        fallback_prefix: str | None = None,
    ) -> S3Config:
        """Build config from environment variables.

        For each required field, tries ``{prefix}SUFFIX`` first, then
        ``{fallback_prefix}SUFFIX`` if a fallback is provided.

        Args:
            prefix: Primary env var prefix (e.g. ``"S3_INPUT_"``).
            fallback_prefix: Optional fallback prefix (e.g. ``"S3_"``).

        Raises:
            KeyError: If any required variable is missing from both prefix and fallback.
        """

        def _get(suffix: str, required: bool = True) -> str | None:
            val = os.environ.get(f"{prefix}{suffix}")
            if val is not None:
                return val
            if fallback_prefix is not None:
                val = os.environ.get(f"{fallback_prefix}{suffix}")
                if val is not None:
                    return val
            if required:
                candidates = [f"{prefix}{suffix}"]
                if fallback_prefix is not None:
                    candidates.append(f"{fallback_prefix}{suffix}")
                raise KeyError(
                    f"Missing required environment variable: set {' or '.join(candidates)}"
                )
            return None

        return cls(
            endpoint_url=_get("ENDPOINT_URL"),  # type: ignore[arg-type]
            access_key_id=_get("ACCESS_KEY_ID"),  # type: ignore[arg-type]
            secret_access_key=_get("SECRET_ACCESS_KEY"),  # type: ignore[arg-type]
            bucket=_get("BUCKET"),  # type: ignore[arg-type]
            region=_get("REGION", required=False) or "auto",
        )

    @classmethod
    def input_from_env(cls) -> S3Config:
        """Build input storage config, falling back to shared ``S3_*`` vars."""
        return cls.from_env(prefix="S3_INPUT_", fallback_prefix="S3_")

    @classmethod
    def output_from_env(cls) -> S3Config:
        """Build output storage config, falling back to shared ``S3_*`` vars."""
        return cls.from_env(prefix="S3_OUTPUT_", fallback_prefix="S3_")


def get_s3_client(config: S3Config) -> S3Client:
    """Create a boto3 S3 client from the given configuration."""
    return boto3.client(
        "s3",
        endpoint_url=config.endpoint_url,
        aws_access_key_id=config.access_key_id,
        aws_secret_access_key=config.secret_access_key,
        region_name=config.region,
    )


@dataclass
class ShardIndex:
    """Result of listing shards under a prefix."""

    bucket: str
    prefix: str
    keys: list[str] = field(default_factory=list)

    @property
    def urls(self) -> list[str]:
        """S3-style URLs for each shard."""
        return [f"s3://{self.bucket}/{key}" for key in self.keys]


def list_shards(prefix: str, config: S3Config) -> ShardIndex:
    """List all .tar shard objects under a prefix in S3-compatible storage.

    Args:
        prefix: S3 key prefix to search under.
        config: S3-compatible storage configuration.

    Returns:
        ShardIndex with discovered shard keys.
    """
    client = get_s3_client(config)
    paginator = client.get_paginator("list_objects_v2")
    keys: list[str] = []
    for page in paginator.paginate(Bucket=config.bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.endswith(".tar"):
                keys.append(key)
    keys.sort()
    return ShardIndex(bucket=config.bucket, prefix=prefix, keys=keys)
