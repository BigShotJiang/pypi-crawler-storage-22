"""Fan-out orchestration for parallel shard processing via Modal."""

from __future__ import annotations

import logging
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import modal

from atdata_lambda._config import S3Config, list_shards

logger = logging.getLogger(__name__)


@dataclass
class JobResult:
    """Aggregated result of processing all shards in a job."""

    job_id: str
    total_shards: int
    completed: int
    failed: int
    results: list[dict[str, Any]] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return self.failed == 0

    def summary(self) -> str:
        status = "SUCCESS" if self.success else "PARTIAL FAILURE"
        return (
            f"Job {self.job_id}: {status} — "
            f"{self.completed}/{self.total_shards} shards completed, "
            f"{self.failed} failed"
        )


class Dispatcher:
    """Orchestrates fan-out of shard processing across Modal workers.

    Takes a ``@processor``-decorated function and dispatches each input shard
    to a separate Modal worker via ``.map()``.

    Args:
        processor_fn: A function decorated with ``@processor``, which has
            ``.modal_function``, ``.input_type``, and ``.output_type`` attributes.
        input_config: S3 config for listing/reading input shards. If ``None``,
            reads from ``S3_INPUT_*`` env vars (falling back to ``S3_*``).
        output_config: S3 config for writing output shards. Stored for reference
            only — workers resolve their own output config from env vars injected
            by the Modal Secret.
        on_error: Per-sample error handling — ``"skip"`` or ``"raise"``.

    Example::

        dispatcher = Dispatcher(embed_images)
        result = dispatcher.run(
            input_prefix="data/raw/train/",
            output_prefix="data/embedded/train/",
        )
        print(result.summary())
    """

    def __init__(
        self,
        processor_fn: Callable[..., Any],
        *,
        input_config: S3Config | None = None,
        output_config: S3Config | None = None,
        on_error: str = "skip",
    ) -> None:
        if not hasattr(processor_fn, "modal_function"):
            raise TypeError(
                f"{processor_fn!r} is not a @processor-decorated function. "
                f"Decorate it with @processor(app, ...) first."
            )
        self._processor_fn = processor_fn
        self._modal_fn = processor_fn.modal_function  # type: ignore[union-attr]
        self._input_config = input_config
        self._output_config = output_config
        self._on_error = on_error

    @property
    def input_type(self) -> type:
        return self._processor_fn.input_type  # type: ignore[union-attr]

    @property
    def output_type(self) -> type:
        return self._processor_fn.output_type  # type: ignore[union-attr]

    def _get_input_config(self) -> S3Config:
        if self._input_config is not None:
            return self._input_config
        return S3Config.input_from_env()

    def run(
        self,
        input_prefix: str,
        output_prefix: str,
        *,
        input_config: S3Config | None = None,
    ) -> JobResult:
        """Execute shard processing across all shards under the input prefix.

        Enumerates shards at ``input_prefix``, fans out to Modal workers via
        ``.map()``, and collects results.

        Args:
            input_prefix: S3 key prefix containing input ``.tar`` shards.
            output_prefix: S3 key prefix where output shards will be written.
            input_config: Override input S3 config for this run.

        Returns:
            JobResult with per-shard results and aggregate counts.
        """
        config = input_config or self._get_input_config()
        job_id = uuid.uuid4().hex[:12]

        logger.info("Job %s: listing shards at %s", job_id, input_prefix)
        shard_index = list_shards(input_prefix, config)

        if not shard_index.keys:
            logger.warning("Job %s: no shards found at prefix %s", job_id, input_prefix)
            return JobResult(
                job_id=job_id,
                total_shards=0,
                completed=0,
                failed=0,
            )

        shard_urls = shard_index.urls
        total = len(shard_urls)
        logger.info("Job %s: dispatching %d shards", job_id, total)

        results: list[dict[str, Any]] = []
        completed = 0
        failed = 0

        for result_dict in self._modal_fn.map(
            shard_urls,
            kwargs={"output_prefix": output_prefix, "on_error": self._on_error},
            return_exceptions=True,
        ):
            if isinstance(result_dict, BaseException):
                failed += 1
                results.append(
                    {
                        "error": f"{type(result_dict).__name__}: {result_dict}",
                    }
                )
                logger.error("Job %s: shard failed: %s", job_id, result_dict)
            else:
                completed += 1
                if result_dict.get("error_count", 0) > 0:
                    logger.warning(
                        "Job %s: shard %s had %d sample errors",
                        job_id,
                        result_dict.get("input_url", "?"),
                        result_dict["error_count"],
                    )
                results.append(result_dict)

        logger.info(
            "Job %s: finished — %d/%d completed, %d failed",
            job_id,
            completed,
            total,
            failed,
        )

        return JobResult(
            job_id=job_id,
            total_shards=total,
            completed=completed,
            failed=failed,
            results=results,
        )


def create_dispatch_endpoint(
    app: modal.App,
    dispatcher: Dispatcher,
) -> None:
    """Register an HTTP endpoint on the Modal app for event-driven dispatch.

    Creates a POST endpoint that accepts JSON with ``input_prefix`` and
    ``output_prefix`` fields, triggers shard processing, and returns the
    job result.

    Args:
        app: The Modal App to register the endpoint on.
        dispatcher: The Dispatcher instance to use for processing.
    """

    @app.function()
    @modal.fastapi_endpoint(method="POST")
    async def dispatch(request: dict[str, Any]) -> dict[str, Any]:
        input_prefix = request["input_prefix"]
        output_prefix = request["output_prefix"]
        on_error = request.get("on_error", "skip")

        dispatcher._on_error = on_error
        result = dispatcher.run(input_prefix, output_prefix)

        return {
            "job_id": result.job_id,
            "total_shards": result.total_shards,
            "completed": result.completed,
            "failed": result.failed,
            "success": result.success,
            "summary": result.summary(),
        }
