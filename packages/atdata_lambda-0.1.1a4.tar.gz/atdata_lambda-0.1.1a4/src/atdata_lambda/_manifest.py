"""Per-shard manifest writing for output datasets.

Delegates to ``atdata.manifest`` (v0.3+) for manifest construction and
serialization, adding S3-compatible upload support on top.
"""

from __future__ import annotations

import logging
import tempfile
from pathlib import Path

from atdata.manifest import ManifestBuilder as _AtdataManifestBuilder
from atdata.manifest import ManifestWriter as _AtdataManifestWriter
from atdata.manifest import ShardManifest as _AtdataShardManifest

from atdata_lambda._config import S3Config, get_s3_client

logger = logging.getLogger(__name__)

# Re-export atdata's canonical types so callers can import from one place.
ManifestBuilder = _AtdataManifestBuilder
ManifestWriter = _AtdataManifestWriter
ShardManifest = _AtdataShardManifest


def write_manifest(
    manifest: _AtdataShardManifest,
    output_prefix: str,
    config: S3Config,
) -> tuple[str, str]:
    """Write a shard manifest (JSON + Parquet) to S3-compatible storage.

    Uses ``atdata.manifest.ManifestWriter`` to produce the canonical
    ``.manifest.json`` and ``.manifest.parquet`` companion files, then
    uploads both alongside the output shard.

    Args:
        manifest: The shard manifest to write (from ``ManifestBuilder.build()``).
        output_prefix: S3 key prefix for the output (e.g. ``"data/out/train"``).
        config: S3-compatible storage configuration.

    Returns:
        Tuple of ``(json_url, parquet_url)`` — S3 URLs of the uploaded files.
    """
    shard_name = manifest.shard_id.rstrip("/").rsplit("/", 1)[-1]
    base_name = shard_name.removesuffix(".tar")
    prefix = output_prefix.rstrip("/")

    client = get_s3_client(config)

    with tempfile.TemporaryDirectory() as tmpdir:
        base_path = Path(tmpdir) / base_name
        writer = _AtdataManifestWriter(base_path)
        json_path, parquet_path = writer.write(manifest)

        json_key = f"{prefix}/{json_path.name}"
        parquet_key = f"{prefix}/{parquet_path.name}"

        client.upload_file(str(json_path), config.bucket, json_key)
        client.upload_file(str(parquet_path), config.bucket, parquet_key)

    json_url = f"s3://{config.bucket}/{json_key}"
    parquet_url = f"s3://{config.bucket}/{parquet_key}"
    logger.info("Wrote manifest to %s and %s", json_url, parquet_url)
    return json_url, parquet_url
