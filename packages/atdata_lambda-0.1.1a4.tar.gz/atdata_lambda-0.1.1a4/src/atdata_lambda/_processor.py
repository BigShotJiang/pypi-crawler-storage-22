"""@processor decorator for wrapping user functions as Modal shard processors."""

from __future__ import annotations

import functools
import inspect
from collections.abc import Callable
from typing import Any, get_type_hints

import modal
from atdata import PackableSample

from atdata_lambda._config import DEFAULT_SECRET_NAME, s3_env_var_names


class ProcessorError(Exception):
    """Raised when processor configuration is invalid."""


def _extract_sample_types(fn: Callable[..., Any]) -> tuple[type, type]:
    """Extract input and output sample types from a processor function's annotations.

    The function must have exactly one positional parameter (the input sample)
    and a return annotation (the output sample). Both must be subclasses of
    ``atdata.PackableSample``.

    Args:
        fn: The user-defined processor function.

    Returns:
        Tuple of (input_type, output_type).

    Raises:
        ProcessorError: If annotations are missing or types aren't PackableSample subclasses.
    """
    hints = get_type_hints(fn)

    if "return" not in hints:
        raise ProcessorError(
            f"Processor function {fn.__qualname__!r} must have a return type annotation."
        )

    sig = inspect.signature(fn)
    params = [p for p in sig.parameters.values() if p.name != "self"]
    if not params:
        raise ProcessorError(
            f"Processor function {fn.__qualname__!r} must accept at least one parameter "
            f"(the input sample)."
        )

    input_param = params[0]
    if input_param.name not in hints:
        raise ProcessorError(
            f"Parameter {input_param.name!r} of {fn.__qualname__!r} must have a type annotation."
        )

    input_type = hints[input_param.name]
    output_type = hints["return"]

    if not (isinstance(input_type, type) and issubclass(input_type, PackableSample)):
        raise ProcessorError(
            f"Input type {input_type!r} of {fn.__qualname__!r} must be a subclass of "
            f"atdata.PackableSample."
        )
    if not (isinstance(output_type, type) and issubclass(output_type, PackableSample)):
        raise ProcessorError(
            f"Return type {output_type!r} of {fn.__qualname__!r} must be a subclass of "
            f"atdata.PackableSample."
        )

    return input_type, output_type


def processor(
    app: modal.App,
    *,
    cpu: float | int = 2,
    memory: int = 4096,
    gpu: str | None = None,
    timeout: int = 600,
    image: modal.Image | None = None,
    secret_name: str = DEFAULT_SECRET_NAME,
    use_local_env: bool = False,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that registers a sample-processing function as a Modal shard processor.

    The decorated function should accept a single ``PackableSample`` and return a
    ``PackableSample``. The decorator extracts type information, validates it, and
    registers the function with Modal for remote execution.

    Args:
        app: The Modal App to register the function with.
        cpu: Number of CPU cores per worker.
        memory: Memory in MB per worker.
        gpu: GPU type string (e.g. ``"T4"``, ``"A100"``), or ``None`` for CPU-only.
        timeout: Maximum execution time in seconds per shard.
        image: Modal container image. If ``None``, uses a default image with
            ``atdata``, ``boto3``, and ``webdataset`` installed.
        secret_name: Name of the Modal Secret containing S3 credentials.
            Ignored when ``use_local_env=True``.
        use_local_env: If ``True``, forward local ``S3_*`` / ``S3_INPUT_*`` /
            ``S3_OUTPUT_*`` environment variables into Modal workers via
            ``modal.Secret.from_local_environ()``. Convenient for development;
            use named secrets (the default) for production.

    Returns:
        A decorator that wraps the user function with Modal execution metadata.

    Example::

        app = modal.App("my-pipeline")

        @processor(app, gpu="T4", memory=8192)
        def embed_images(sample: ImageSample) -> EmbeddingSample:
            embedding = model.encode(sample.image)
            return EmbeddingSample(embedding=embedding, label=sample.label)
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        input_type, output_type = _extract_sample_types(fn)

        if image is None:
            container_image = modal.Image.debian_slim(python_version="3.12").pip_install(
                "atdata", "boto3", "webdataset"
            )
        else:
            container_image = image

        if use_local_env:
            secrets = [modal.Secret.from_local_environ(s3_env_var_names())]
        else:
            secrets = [modal.Secret.from_name(secret_name)]

        modal_kwargs: dict[str, Any] = {
            "image": container_image,
            "secrets": secrets,
            "cpu": cpu,
            "memory": memory,
            "timeout": timeout,
            "serialized": True,
        }
        if gpu is not None:
            modal_kwargs["gpu"] = gpu

        # Import here to avoid circular dependency
        from atdata_lambda._shard_worker import process_shard

        @app.function(**modal_kwargs)
        def _modal_shard_worker(
            shard_url: str,
            output_prefix: str,
            *,
            on_error: str = "skip",
        ) -> dict[str, Any]:
            result = process_shard(
                shard_url=shard_url,
                output_prefix=output_prefix,
                processor_fn=fn,
                input_type=input_type,
                output_type=output_type,
                on_error=on_error,
            )
            return result.to_dict()

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return fn(*args, **kwargs)

        # Attach metadata for introspection by Dispatcher
        wrapper.input_type = input_type  # type: ignore[attr-defined]
        wrapper.output_type = output_type  # type: ignore[attr-defined]
        wrapper.modal_function = _modal_shard_worker  # type: ignore[attr-defined]
        wrapper.resource_spec = {  # type: ignore[attr-defined]
            "cpu": cpu,
            "memory": memory,
            "gpu": gpu,
            "timeout": timeout,
        }

        return wrapper

    return decorator
