"""Per-shard processing logic that runs inside Modal workers."""

from __future__ import annotations

import logging
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TypeVar

import webdataset as wds
from atdata import Dataset, Packable, S3Source
from atdata.manifest import ManifestBuilder

from atdata_lambda._config import S3Config, get_s3_client

logger = logging.getLogger(__name__)

InputT = TypeVar("InputT", bound=Packable)
OutputT = TypeVar("OutputT", bound=Packable)


@dataclass
class ShardResult:
    """Result of processing a single shard."""

    input_url: str
    output_url: str
    sample_count: int
    error_count: int = 0
    errors: list[dict[str, str]] = field(default_factory=list)
    manifest_url: str | None = None

    @property
    def success(self) -> bool:
        return self.error_count == 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "input_url": self.input_url,
            "output_url": self.output_url,
            "sample_count": self.sample_count,
            "error_count": self.error_count,
            "errors": self.errors,
            "manifest_url": self.manifest_url,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ShardResult:
        return cls(
            input_url=data["input_url"],
            output_url=data["output_url"],
            sample_count=data["sample_count"],
            error_count=data.get("error_count", 0),
            errors=data.get("errors", []),
            manifest_url=data.get("manifest_url"),
        )


def _shard_name_from_key(key: str) -> str:
    """Extract shard filename from an S3 key or URL.

    Examples:
        >>> _shard_name_from_key("data/train/shard-000042.tar")
        'shard-000042.tar'
        >>> _shard_name_from_key("s3://bucket/data/shard-000042.tar")
        'shard-000042.tar'
    """
    return key.rstrip("/").rsplit("/", 1)[-1]


def _upload_file(local_path: Path, key: str, config: S3Config) -> str:
    """Upload a local file to S3-compatible storage and return the S3 URL."""
    client = get_s3_client(config)
    client.upload_file(str(local_path), config.bucket, key)
    return f"s3://{config.bucket}/{key}"


def _open_input_shard(
    shard_url: str,
    input_type: type[InputT],
    config: S3Config,
) -> Dataset[InputT]:
    """Open an input shard as an atdata Dataset.

    Supports S3 URLs (``s3://bucket/key``) via ``S3Source.from_urls()``.
    """
    if shard_url.startswith("s3://"):
        source = S3Source.from_urls(
            [shard_url],
            endpoint=config.endpoint_url,
            access_key=config.access_key_id,
            secret_key=config.secret_access_key,
        )
        return Dataset[input_type](source)  # type: ignore[valid-type]
    return Dataset[input_type](shard_url)  # type: ignore[valid-type]


def process_shard(
    shard_url: str,
    output_prefix: str,
    processor_fn: Callable[[InputT], OutputT],
    *,
    input_type: type[InputT],
    output_type: type[OutputT],
    input_config: S3Config | None = None,
    output_config: S3Config | None = None,
    on_error: str = "skip",
) -> ShardResult:
    """Process a single shard: read samples, apply processor, write output.

    Args:
        shard_url: URL or S3 path of the input shard tar file.
        output_prefix: S3 key prefix for the output shard.
        processor_fn: User function mapping input samples to output samples.
        input_type: The Packable input sample type.
        output_type: The Packable output sample type.
        input_config: S3 config for reading input shards. Defaults to
            ``S3Config.input_from_env()``.
        output_config: S3 config for writing output shards and manifests.
            Defaults to ``S3Config.output_from_env()``.
        on_error: Error handling strategy — ``"skip"`` to log and continue,
            ``"raise"`` to propagate immediately.

    Returns:
        ShardResult with processing metadata.

    Raises:
        ValueError: If ``on_error`` is not ``"skip"`` or ``"raise"``.
        Exception: Re-raised sample processing errors when ``on_error="raise"``.
    """
    if on_error not in ("skip", "raise"):
        raise ValueError(f"on_error must be 'skip' or 'raise', got {on_error!r}")

    shard_name = _shard_name_from_key(shard_url)
    output_key = f"{output_prefix.rstrip('/')}/{shard_name}"

    in_cfg = input_config or S3Config.input_from_env()
    out_cfg = output_config or S3Config.output_from_env()

    ds = _open_input_shard(shard_url, input_type, in_cfg)

    sample_count = 0
    error_count = 0
    errors: list[dict[str, str]] = []

    manifest_builder = ManifestBuilder(
        sample_type=output_type,
        shard_id=shard_name,
        parent_shards=[shard_url],
    )

    with tempfile.TemporaryDirectory() as tmpdir:
        local_output = Path(tmpdir) / shard_name
        byte_offset = 0

        with wds.TarWriter(str(local_output)) as sink:
            for idx, sample in enumerate(ds.ordered()):
                key = f"sample-{idx:08d}"
                try:
                    result = processor_fn(sample)
                    packed = result.packed
                    sink.write({"__key__": key, "msgpack": packed})
                    manifest_builder.add_sample(
                        key=key,
                        offset=byte_offset,
                        size=len(packed),
                        sample=result,
                    )
                    byte_offset += len(packed)
                    sample_count += 1
                except Exception as exc:
                    error_count += 1
                    error_info = {
                        "sample_index": str(idx),
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                    errors.append(error_info)
                    if on_error == "raise":
                        raise
                    logger.warning(
                        "Skipping sample %d in %s: %s",
                        idx,
                        shard_url,
                        exc,
                    )

        output_url = _upload_file(local_output, output_key, out_cfg)

        # Write and upload manifest alongside shard
        manifest_url: str | None = None
        if sample_count > 0:
            from atdata_lambda._manifest import write_manifest

            shard_manifest = manifest_builder.build()
            json_url, _parquet_url = write_manifest(shard_manifest, output_prefix, out_cfg)
            manifest_url = json_url

    return ShardResult(
        input_url=shard_url,
        output_url=output_url,
        sample_count=sample_count,
        error_count=error_count,
        errors=errors,
        manifest_url=manifest_url,
    )
