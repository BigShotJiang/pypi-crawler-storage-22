# -*- coding: utf-8 -*-
"""
Runner with long-context memory for AtendentePro.

run_with_memory: load user context, retrieve memories, enrich messages, run agent, save turn.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


def _last_user_message(messages: List[Dict[str, Any]]) -> str:
    """Extract the last user message content for memory search query."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content")
            if isinstance(content, str):
                return content.strip()
            break
    return ""


async def run_with_memory(
    network: Any,
    agent: Any,
    messages: List[Dict[str, Any]],
    *,
    memory_backend: Optional[Any] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    session_id_factory: Optional[Callable[[Any, List[Dict[str, Any]]], Optional[str]]] = None,
    search_method: str = "graph",
    memory_limit: int = 5,
    memory_threshold: float = 0.3,
    memory_header: str = "Memória relevante (conversas anteriores):",
    strict_memory: bool = False,
) -> Any:
    """
    Run agent with optional long-context memory: search before run, inject context, save after.

    1. Load user context via network.user_loader(messages) if configured.
    2. Resolve user_id from param or network.loaded_user_context.user_id; session_id from
       param, then loaded_user_context.session_id, then loaded_user_context.metadata["session_id"],
       then network.session_id_factory(network, messages) if set, then param session_id_factory(network, messages).
    3. If memory_backend (or network.memory_backend): search with last user message,
       prepend a system message with memory_header + context.
    4. Run agent with Runner.run(agent, messages).
    5. Save turn with memory_backend.save_conversation_async(messages + assistant).

    Args:
        network: AgentNetwork (with optional user_loader and memory_backend).
        agent: Agent to run.
        messages: List of message dicts (role, content).
        memory_backend: Optional MemoryBackend (e.g. GRKMemoryBackend). If None,
            uses getattr(network, "memory_backend", None).
        user_id: Optional user id for memory isolation. If None, uses
            network.loaded_user_context.user_id after user_loader runs.
        session_id: Optional session id. If None, may be taken from
            UserContext.session_id or UserContext.metadata["session_id"] when
            user_loader fills loaded_user_context, or from network.session_id_factory
            or this session_id_factory (see resolution order in step 2).
        session_id_factory: Optional callable to derive session_id from (network, messages).
            The network may also have session_id_factory set (e.g. network.session_id_factory = ...)
            for the same effect without passing it on every call.
        search_method: Passed to backend search_async (e.g. "graph", "embedding").
        memory_limit: Max results for search.
        memory_threshold: Minimum similarity threshold for search.
        memory_header: Text prepended to the injected memory block.
        strict_memory: If True, re-raise on memory backend errors; else log and continue.

    Returns:
        RunResult from Runner.run(agent, messages).
    """
    from agents import Runner

    # 1. Load user context (same as run_with_user_context)
    if hasattr(network, "user_loader") and network.user_loader:
        try:
            user_context = network.user_loader(messages)
            if user_context:
                network.loaded_user_context = user_context
        except Exception:
            pass

    # 2. Resolve user_id / session_id
    if user_id is None and hasattr(network, "loaded_user_context") and network.loaded_user_context:
        user_id = getattr(network.loaded_user_context, "user_id", None)

    if session_id is None and hasattr(network, "loaded_user_context") and network.loaded_user_context:
        session_id = getattr(network.loaded_user_context, "session_id", None)
    if session_id is None and hasattr(network, "loaded_user_context") and network.loaded_user_context:
        meta = getattr(network.loaded_user_context, "metadata", None) or {}
        session_id = meta.get("session_id") if isinstance(meta, dict) else None
    if session_id is None:
        network_factory = getattr(network, "session_id_factory", None)
        if callable(network_factory):
            session_id = network_factory(network, messages)
    if session_id is None and session_id_factory is not None:
        session_id = session_id_factory(network, messages)

    backend = memory_backend if memory_backend is not None else getattr(network, "memory_backend", None)

    # 3. Search and enrich messages
    messages_to_run: List[Dict[str, Any]] = list(messages)
    if backend is not None:
        query = _last_user_message(messages)
        if query:
            try:
                context_str = await backend.search_async(
                    query,
                    user_id=user_id,
                    session_id=session_id,
                    method=search_method,
                    limit=memory_limit,
                    threshold=memory_threshold,
                )
            except Exception as exc:
                if strict_memory:
                    raise
                logger.warning("Memory search failed: %s", exc)
                context_str = ""
        else:
            context_str = ""

        if context_str and context_str.strip():
            block = f"{memory_header}\n{context_str.strip()}"
            system_msg = {"role": "system", "content": block}
            messages_to_run = [system_msg] + list(messages)

    # 4. Run agent
    result = await Runner.run(agent, messages_to_run)

    # 5. Save turn
    if backend is not None:
        try:
            assistant_content = getattr(result, "final_output", None) or ""
            turn_messages = list(messages) + [{"role": "assistant", "content": assistant_content}]
            await backend.save_conversation_async(
                turn_messages,
                user_id=user_id,
                session_id=session_id,
            )
        except Exception as exc:
            if strict_memory:
                raise
            logger.warning("Memory save_conversation failed: %s", exc)

    return result
