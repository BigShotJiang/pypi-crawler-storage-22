# -*- coding: utf-8 -*-
"""
User Loader utilities for AtendentePro.

Provides functions to load user data from various sources and create UserContext
objects for enriching agent conversations with user information.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from atendentepro.models import UserContext


def extract_phone_from_messages(messages: List[Dict[str, Any]]) -> Optional[str]:
    """
    Extract phone number from user messages.
    
    Searches for phone patterns in the first user message.
    Supports formats: (11) 99999-9999, 11999999999, +55 11 99999-9999, etc.
    
    Args:
        messages: List of message dictionaries with 'role' and 'content' keys.
        
    Returns:
        Phone number string if found, None otherwise.
        
    Example:
        >>> messages = [{"role": "user", "content": "Meu telefone é (11) 99999-8888"}]
        >>> extract_phone_from_messages(messages)
        '11999998888'
    """
    if not messages:
        return None
    
    # Find first user message
    user_message = None
    for msg in messages:
        if msg.get("role") == "user" and msg.get("content"):
            user_message = msg["content"]
            break
    
    if not user_message:
        return None
    
    # Phone patterns: (XX) XXXXX-XXXX, XX XXXXXXXX, +55 XX XXXXXXXX, etc.
    phone_patterns = [
        r'\(?(\d{2})\)?\s*(\d{4,5})-?(\d{4})',  # (11) 99999-8888 or 11 99999-8888
        r'\+?55\s*(\d{2})\s*(\d{4,5})-?(\d{4})',  # +55 11 99999-8888
        r'(\d{10,11})',  # 11999998888
    ]
    
    for pattern in phone_patterns:
        match = re.search(pattern, user_message)
        if match:
            # Extract digits only
            digits = re.sub(r'\D', '', match.group(0))
            # Normalize to 10 or 11 digits (with or without area code)
            if len(digits) >= 10:
                return digits[-10:] if len(digits) > 10 else digits
    
    return None


def extract_email_from_messages(messages: List[Dict[str, Any]]) -> Optional[str]:
    """
    Extract email address from user messages.
    
    Searches for email patterns in user messages.
    
    Args:
        messages: List of message dictionaries with 'role' and 'content' keys.
        
    Returns:
        Email address string if found, None otherwise.
        
    Example:
        >>> messages = [{"role": "user", "content": "Meu email é joao@example.com"}]
        >>> extract_email_from_messages(messages)
        'joao@example.com'
    """
    if not messages:
        return None
    
    # Find first user message
    user_message = None
    for msg in messages:
        if msg.get("role") == "user" and msg.get("content"):
            user_message = msg["content"]
            break
    
    if not user_message:
        return None
    
    # Email pattern
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    match = re.search(email_pattern, user_message)
    
    if match:
        return match.group(0).lower()
    
    return None


def extract_user_id_from_messages(messages: List[Dict[str, Any]]) -> Optional[str]:
    """
    Extract user ID from user messages.
    
    Looks for common patterns like "user_id:", "id:", "CPF:", etc.
    
    Args:
        messages: List of message dictionaries with 'role' and 'content' keys.
        
    Returns:
        User ID string if found, None otherwise.
        
    Example:
        >>> messages = [{"role": "user", "content": "Meu CPF é 123.456.789-00"}]
        >>> extract_user_id_from_messages(messages)
        '12345678900'
    """
    if not messages:
        return None
    
    # Find first user message
    user_message = None
    for msg in messages:
        if msg.get("role") == "user" and msg.get("content"):
            user_message = msg["content"]
            break
    
    if not user_message:
        return None
    
    # Patterns for user IDs
    patterns = [
        (r'(?:user[_\s]?id|id[_\s]?usuario|cpf|documento)[:\s]+([\d\.\-\/]+)', lambda m: re.sub(r'\D', '', m.group(1))),
        (r'([\d]{11})', lambda m: m.group(1)),  # CPF-like (11 digits)
        (r'([\d]{14})', lambda m: m.group(1)),  # CNPJ-like (14 digits)
    ]
    
    for pattern, extractor in patterns:
        match = re.search(pattern, user_message, re.IGNORECASE)
        if match:
            return extractor(match)
    
    return None


def load_user_from_csv(
    csv_path: Path,
    identifier_field: str,
    identifier_value: str,
) -> Optional[Dict[str, Any]]:
    """
    Load user data from a CSV file.
    
    Args:
        csv_path: Path to the CSV file.
        identifier_field: Name of the column to search (e.g., "email", "telefone", "cpf").
        identifier_value: Value to search for in the identifier_field column.
        
    Returns:
        Dictionary with user data if found, None otherwise.
        
    Example:
        >>> from pathlib import Path
        >>> user_data = load_user_from_csv(
        ...     Path("users.csv"),
        ...     "email",
        ...     "joao@example.com"
        ... )
        >>> if user_data:
        ...     print(user_data["nome"])
    """
    if not csv_path.exists():
        return None
    
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            
            # Normalize identifier value (remove formatting)
            normalized_value = re.sub(r'\D', '', str(identifier_value).lower())
            
            for row in reader:
                # Get value from identifier field
                field_value = row.get(identifier_field, '')
                # Normalize for comparison
                normalized_field = re.sub(r'\D', '', str(field_value).lower())
                
                if normalized_field == normalized_value:
                    # Return all row data as dict
                    return dict(row)
    
    except Exception:
        return None
    
    return None


def create_user_loader(
    loader_func: Callable[[str], Optional[Dict[str, Any]]],
    identifier_extractor: Optional[Callable[[List[Dict[str, Any]]], Optional[str]]] = None,
) -> Callable[[List[Dict[str, Any]]], Optional[UserContext]]:
    """
    Create a user loader function.
    
    Factory function that creates a callable that extracts user identifier from
    messages and loads user data using the provided loader function.
    
    Args:
        loader_func: Function that receives an identifier (str) and returns
                     user data dict or None if not found.
        identifier_extractor: Optional function to extract identifier from messages.
                             If None, tries common extractors (phone, email, user_id).
                             
    Returns:
        Function that receives messages and returns UserContext or None.
        
    Example:
        >>> def load_from_db(identifier: str) -> Optional[Dict]:
        ...     # Your database lookup logic
        ...     return {"user_id": "123", "role": "cliente", "nome": "João"}
        ...
        >>> loader = create_user_loader(
        ...     loader_func=load_from_db,
        ...     identifier_extractor=extract_email_from_messages
        ... )
        >>> 
        >>> messages = [{"role": "user", "content": "joao@example.com"}]
        >>> user_context = loader(messages)
        >>> if user_context:
        ...     print(user_context.user_id)
    """
    def load_user(messages: List[Dict[str, Any]]) -> Optional[UserContext]:
        """
        Load user context from messages.
        
        Args:
            messages: List of message dictionaries.
            
        Returns:
            UserContext if user found, None otherwise.
        """
        # Extract identifier
        identifier = None
        if identifier_extractor:
            identifier = identifier_extractor(messages)
        else:
            # Try common extractors in order
            identifier = (
                extract_phone_from_messages(messages) or
                extract_email_from_messages(messages) or
                extract_user_id_from_messages(messages)
            )
        
        if not identifier:
            return None
        
        # Load user data
        user_data = loader_func(identifier)
        if not user_data:
            return None
        
        # Create UserContext
        return UserContext(
            user_id=user_data.get("user_id") or identifier,
            role=user_data.get("role"),
            metadata={
                **user_data,  # Include all user data in metadata
                "loaded_from": "user_loader",
            }
        )
    
    return load_user


async def run_with_user_context(
    network: Any,
    agent: Any,
    messages: List[Dict[str, Any]],
) -> Any:
    """
    Run agent with automatic user context loading.
    
    This function automatically loads user data if a user_loader is configured
    in the network, enriches the network's loaded_user_context, and then runs
    the agent normally.
    
    Args:
        network: AgentNetwork instance with optional user_loader configured.
        agent: Agent instance to run.
        messages: List of message dictionaries.
        
    Returns:
        RunResult from the agent execution.
        
    Example:
        >>> from agents import Runner
        >>> from atendentepro import create_standard_network, create_user_loader
        >>> from pathlib import Path
        >>> 
        >>> def load_user(identifier: str):
        ...     # Your loading logic
        ...     return {"user_id": identifier, "role": "cliente"}
        >>> 
        >>> loader = create_user_loader(load_user)
        >>> network = create_standard_network(
        ...     templates_root=Path("templates"),
        ...     user_loader=loader
        ... )
        >>> 
        >>> messages = [{"role": "user", "content": "Olá!"}]
        >>> result = await run_with_user_context(network, network.triage, messages)
        >>> print(result.final_output)
    """
    from agents import Runner
    
    # Load user if loader is configured
    if hasattr(network, 'user_loader') and network.user_loader:
        try:
            user_context = network.user_loader(messages)
            if user_context:
                network.loaded_user_context = user_context
        except Exception:
            # Silently fail if loading fails - don't break the conversation
            pass
    
    # Run agent normally
    return await Runner.run(agent, messages)
