# Changelog

All notable changes to `athena-python-pptx` are documented in this file.

## 0.1.39

- Added SDK support for `slide.shapes.add_table(...)` and table creation command wiring.
- Added `slide.notes_slide.notes_text_frame.text` compatibility adapter for python-pptx style notes access.
- Added support for auto-shape text frame access (`shape.text_frame`) to match python-pptx behavior.
- Added smoke/integration tests for table creation/cell updates, notes slide adapter, and shape text-frame regression.
- Updated README examples for notes slide adapter and auto-shape text support.
