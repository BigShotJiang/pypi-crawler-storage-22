# Python SDK Local Development Guide

## Quick Setup

```bash
# Install in editable mode (changes take effect immediately, no reinstall)
cd python-sdk
pip install -e ".[dev]"

# Point at local API
export ATHENA_PPTX_BASE_URL=http://localhost:4000

# Start the API server (in another terminal)
pnpm dev
```

## Testing Changes

### Run a scratch script

Create `scratch.py` in the `python-sdk/` directory:

```python
from pptx import Presentation

# Upload a test file or use an existing deck ID
prs = Presentation.upload("path/to/test.pptx", name="test")
print(f"Deck: {prs.deck_id}, Slides: {prs.slide_count}")

slide = prs.slides[0]
for shape in slide.shapes:
    if shape.has_text_frame:
        print(f"  {shape.shape_id}: {shape.text_frame.text[:50]}")

# Test your change
with prs.batch():
    slide.shapes[0].text_frame.text = "Hello from SDK"
```

```bash
python scratch.py
```

### Run tests

```bash
# All tests
pytest tests/ -v

# Single file
pytest tests/test_text.py -v

# Single test
pytest tests/test_text.py::TestTextFrame::test_set_text -v

# Integration tests (needs running API)
ATHENA_PPTX_BASE_URL=http://localhost:4000 pytest tests/test_smoke_integration.py -v
```

### Interactive REPL

```bash
pip install ipython
ATHENA_PPTX_BASE_URL=http://localhost:4000 ipython
```

### Debug HTTP calls

```python
import logging
logging.basicConfig(level=logging.DEBUG)
# All HTTP requests/responses will be printed
```

## Architecture Overview

The SDK is a **remote proxy** over the PPTX Studio API:

1. **Snapshot**: `GET /decks/:id/snapshot` fetches the full deck state
2. **Proxy classes**: `Presentation`, `Slide`, `Shape`, `TextFrame` etc. hold cached snapshot data
3. **Commands**: Mutations (`SetText`, `AddSlide`, etc.) are sent via `POST /decks/:id/commands`
4. **Batching**: `with prs.batch():` buffers commands and sends them as one request on exit

### Key files

| File | Purpose |
|------|---------|
| `pptx/client.py` | HTTP client with retry logic |
| `pptx/presentation.py` | Main `Presentation` class |
| `pptx/slides.py` | `Slides` collection and `Slide` |
| `pptx/shapes.py` | Shape classes (largest module) |
| `pptx/text.py` | `TextFrame`, `Paragraph`, `Run`, `Font` |
| `pptx/commands.py` | Command dataclasses sent to API |
| `pptx/batching.py` | `CommandBuffer` for batch mode |
| `pptx/errors.py` | Exception hierarchy |
| `pptx/units.py` | EMU conversions: `Inches()`, `Pt()`, `Cm()` |

### Configuration

| Method | Example |
|--------|---------|
| Env vars | `ATHENA_PPTX_BASE_URL=http://localhost:4000` |
| Explicit | `Presentation(deck_id, base_url="http://localhost:4000")` |
| API key (optional) | `ATHENA_PPTX_API_KEY=your-key` |
