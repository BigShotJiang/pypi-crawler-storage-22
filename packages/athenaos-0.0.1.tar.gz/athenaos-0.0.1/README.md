# athenaos

Athena OS – placeholder package. Full functionality coming soon.

## Installation

```
pip install athenaos
```
