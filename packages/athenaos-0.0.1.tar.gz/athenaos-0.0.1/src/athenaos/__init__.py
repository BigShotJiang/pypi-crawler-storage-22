"""Athena OS – placeholder package. Full functionality coming soon."""

__version__ = "0.0.1"
