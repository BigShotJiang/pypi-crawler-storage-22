"""PostgreSQL + pgvector operations for vector storage and search."""

from __future__ import annotations

import asyncio
import os
import threading
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from dotenv import load_dotenv

from logging_config import get_logger
from langchain_core.documents import Document

# Load environment from package directory
load_dotenv()

logger = get_logger("hc_ai.db")

# Database configuration
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "hc_ai")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")

TABLE_NAME = os.getenv("DB_TABLE_NAME", "hc_ai_chunks")
SCHEMA_NAME = os.getenv("DB_SCHEMA_NAME", "public")
VECTOR_SIZE = int(os.getenv("DB_VECTOR_SIZE", "1024"))

# Connection pool configuration
MAX_POOL_SIZE = int(os.getenv("DB_MAX_POOL_SIZE", "10"))
MAX_OVERFLOW = int(os.getenv("DB_MAX_OVERFLOW", "5"))
POOL_TIMEOUT = int(os.getenv("DB_POOL_TIMEOUT", "30"))

# Queue configuration
QUEUE_MAX_SIZE = int(os.getenv("CHUNK_QUEUE_MAX_SIZE", "1000"))
MAX_RETRIES = int(os.getenv("CHUNK_MAX_RETRIES", "5"))
RETRY_BASE_DELAY = float(os.getenv("CHUNK_RETRY_BASE_DELAY", "1.0"))
RETRY_MAX_DELAY = float(os.getenv("CHUNK_RETRY_MAX_DELAY", "60.0"))

# Error classification keywords for retry logic
RETRYABLE_KEYWORDS = [
    "too many clients",
    "connection",
    "timeout",
    "deadlock",
    "lock timeout",
    "connection refused",
]

# Global state
_engine = None
_pg_engine = None
_vector_store = None
_queue: Optional[asyncio.Queue] = None
_queue_worker_task = None
_queue_worker_lock = threading.Lock()
_queue_stats = {
    "queued": 0,
    "processed": 0,
    "failed": 0,
    "retries": 0,
}
_queue_stats_lock = threading.Lock()
_error_log: List[Dict[str, Any]] = []


class CustomEmbeddings:
    """Custom embeddings wrapper that uses the embedder module."""
    
    def __init__(self):
        from embeddings.embedder import get_embedding, get_embeddings
        self._get_embedding = get_embedding
        self._get_embeddings = get_embeddings
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of documents."""
        embeddings = self._get_embeddings(texts)
        if embeddings is None:
            raise ValueError("Failed to generate embeddings")
        return embeddings
    
    def embed_query(self, text: str) -> List[float]:
        """Embed a single query."""
        embedding = self._get_embedding(text)
        if embedding is None:
            raise ValueError(f"Failed to generate embedding for query")
        return embedding


def _classify_error(exc: Exception) -> str:
    """Classify an error as retryable, duplicate, or fatal."""
    msg = str(exc).lower()
    for kw in RETRYABLE_KEYWORDS:
        if kw in msg:
            return "retryable"
    if "duplicate key" in msg or "unique constraint" in msg or "conflict" in msg:
        return "duplicate"
    return "fatal"


def _validate_chunk(chunk_text: str, chunk_id: str, metadata: Dict[str, Any]) -> Tuple[bool, str]:
    """Validate a chunk before storage."""
    if not chunk_text or not chunk_text.strip():
        return False, "Empty chunk text"
    try:
        uuid.UUID(chunk_id)
    except Exception:
        return False, "Invalid chunk_id (must be UUID)"
    if not isinstance(metadata, dict):
        return False, "Metadata must be a dict"
    if len(chunk_text) > 50000:
        return False, "Chunk text too large (max 50000 chars)"
    return True, ""


async def _log_error(
    chunk_id: str,
    error_type: str,
    error_message: str,
    metadata: Optional[Dict[str, Any]] = None,
    retry_count: int = 0,
) -> None:
    """Log an error to the in-memory error log."""
    _error_log.append({
        "timestamp": time.time(),
        "chunk_id": chunk_id,
        "error_type": error_type,
        "error_message": error_message,
        "metadata": metadata or {},
        "retry_count": retry_count,
    })
    # Keep only last 1000 errors
    if len(_error_log) > 1000:
        _error_log.pop(0)


async def initialize_vector_store():
    """Initialize the PostgreSQL vector store with connection pooling."""
    global _engine, _pg_engine, _vector_store
    
    if _vector_store is not None:
        return _vector_store
    
    # Validate required environment variables
    if not DB_PASSWORD:
        raise ValueError("DB_PASSWORD environment variable is required")
    
    try:
        from sqlalchemy.ext.asyncio import create_async_engine
        from sqlalchemy import text
        from langchain_postgres import PGVectorStore, PGEngine
    except ImportError as e:
        raise ImportError(
            "Required packages not installed. Run: pip install sqlalchemy asyncpg langchain-postgres"
        ) from e
    
    # Create engine if not exists
    if _engine is None:
        connection_string = f"postgresql+asyncpg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

        # SSL configuration for remote databases (e.g., AWS RDS)
        connect_args: Dict[str, Any] = {}
        ssl_enabled = os.getenv("DB_SSL_ENABLED", "auto").lower()
        is_remote = DB_HOST not in ("localhost", "127.0.0.1")

        if ssl_enabled == "true" or (ssl_enabled == "auto" and is_remote):
            import ssl as _ssl
            ssl_cert = os.getenv("DB_SSL_CERT", "")
            pkg_dir = os.path.dirname(os.path.dirname(__file__))
            rds_ca_path = os.path.join(pkg_dir, "rds-combined-ca-bundle.pem")

            if ssl_cert and os.path.exists(ssl_cert):
                ssl_ctx = _ssl.create_default_context(cafile=ssl_cert)
            elif os.path.exists(rds_ca_path):
                ssl_ctx = _ssl.create_default_context(cafile=rds_ca_path)
            elif os.path.exists("/app/rds-combined-ca-bundle.pem"):
                ssl_ctx = _ssl.create_default_context(cafile="/app/rds-combined-ca-bundle.pem")
            else:
                ssl_ctx = _ssl.create_default_context()
            connect_args["ssl"] = ssl_ctx
            logger.info("SSL enabled for database connection to %s", DB_HOST)

        _engine = create_async_engine(
            connection_string,
            pool_size=MAX_POOL_SIZE,
            max_overflow=MAX_OVERFLOW,
            pool_timeout=POOL_TIMEOUT,
            pool_pre_ping=True,
            echo=False,
            connect_args=connect_args,
        )

        # Set IVFFlat probes on every new connection for optimal index recall
        ivfflat_probes = int(os.getenv("DB_IVFFLAT_PROBES", "0"))
        if ivfflat_probes > 0:
            from sqlalchemy import event
            @event.listens_for(_engine.sync_engine, "connect")
            def _set_ivfflat_probes(dbapi_conn, connection_record):
                cursor = dbapi_conn.cursor()
                cursor.execute(f"SET ivfflat.probes = {ivfflat_probes}")
                cursor.close()
            logger.info("IVFFlat probes set to %d on new connections", ivfflat_probes)

        _pg_engine = PGEngine.from_engine(engine=_engine)
    
    # Create schema if it doesn't exist
    async with _engine.begin() as conn:
        await conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_NAME}"'))
        # Enable pgvector extension
        await conn.execute(text('CREATE EXTENSION IF NOT EXISTS vector'))
    
    # Check if table exists
    async with _engine.begin() as conn:
        result = await conn.execute(
            text("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_schema = :schema_name
                    AND table_name = :table_name
                )
            """),
            {"schema_name": SCHEMA_NAME, "table_name": TABLE_NAME}
        )
        table_exists = result.scalar_one()
    
    # Create table if it doesn't exist
    if not table_exists:
        await _pg_engine.ainit_vectorstore_table(
            table_name=TABLE_NAME,
            vector_size=VECTOR_SIZE,
            schema_name=SCHEMA_NAME,
        )
    
    # Create embeddings instance and vector store
    embedding = CustomEmbeddings()
    _vector_store = await PGVectorStore.create(
        engine=_pg_engine,
        table_name=TABLE_NAME,
        schema_name=SCHEMA_NAME,
        embedding_service=embedding,
    )
    
    # Start queue worker
    await _start_queue_worker()
    
    return _vector_store


async def _start_queue_worker():
    """Start the background queue worker."""
    global _queue, _queue_worker_task
    
    if _queue is None:
        _queue = asyncio.Queue(maxsize=QUEUE_MAX_SIZE)
    
    with _queue_worker_lock:
        if _queue_worker_task is None or _queue_worker_task.done():
            _queue_worker_task = asyncio.create_task(_queue_worker())


async def _queue_worker():
    """Background worker that retries queued chunks with exponential backoff."""
    from db.models import QueuedChunk
    
    while True:
        try:
            queued_chunk: QueuedChunk = await _queue.get()
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(0.5)
            continue
        
        delay = min(RETRY_BASE_DELAY * (2 ** queued_chunk.retry_count), RETRY_MAX_DELAY)
        if queued_chunk.retry_count > 0:
            await asyncio.sleep(delay)
        
        try:
            success = await _store_chunk_direct(
                chunk_text=queued_chunk.chunk_text,
                chunk_id=queued_chunk.chunk_id,
                metadata=queued_chunk.metadata,
            )
            if success:
                with _queue_stats_lock:
                    _queue_stats["processed"] += 1
            else:
                raise Exception("Unknown failure during store_chunk_direct")
        except Exception as e:
            classification = _classify_error(e)
            if classification == "retryable" and queued_chunk.retry_count < MAX_RETRIES:
                queued_chunk.retry_count += 1
                with _queue_stats_lock:
                    _queue_stats["retries"] += 1
                try:
                    await _queue.put(queued_chunk)
                except asyncio.QueueFull:
                    with _queue_stats_lock:
                        _queue_stats["failed"] += 1
                    await _log_error(
                        chunk_id=queued_chunk.chunk_id,
                        error_type="queue_full",
                        error_message=f"Queue full after {queued_chunk.retry_count} retries: {str(e)}",
                        metadata=queued_chunk.metadata,
                        retry_count=queued_chunk.retry_count,
                    )
            else:
                with _queue_stats_lock:
                    _queue_stats["failed"] += 1
                error_type = "max_retries" if queued_chunk.retry_count >= MAX_RETRIES else "fatal"
                await _log_error(
                    chunk_id=queued_chunk.chunk_id,
                    error_type=error_type,
                    error_message=str(e),
                    metadata=queued_chunk.metadata,
                    retry_count=queued_chunk.retry_count,
                )
        finally:
            _queue.task_done()


async def _store_chunk_direct(
    chunk_text: str,
    chunk_id: str,
    metadata: Dict[str, Any],
) -> bool:
    """Store a single chunk directly without queuing."""
    is_valid, msg = _validate_chunk(chunk_text, chunk_id, metadata)
    if not is_valid:
        await _log_error(
            chunk_id=chunk_id,
            error_type="validation",
            error_message=msg,
            metadata=metadata,
        )
        raise ValueError(msg)
    
    vector_store = await initialize_vector_store()
    doc = Document(
        id=chunk_id,
        page_content=chunk_text,
        metadata=metadata,
    )
    await vector_store.aadd_documents([doc])
    return True


async def store_chunk(
    chunk_text: str,
    chunk_id: str,
    metadata: Dict[str, Any],
    use_queue: bool = True,
) -> bool:
    """Store a single chunk with optional queuing on retryable errors.
    
    Args:
        chunk_text: The text content of the chunk.
        chunk_id: Unique identifier (UUID) for the chunk.
        metadata: Dictionary of metadata to store with the chunk.
        use_queue: Whether to queue failed chunks for retry.
    
    Returns:
        True if stored successfully, False if queued for retry.
    """
    from db.models import QueuedChunk
    
    try:
        return await _store_chunk_direct(chunk_text, chunk_id, metadata)
    except Exception as e:
        classification = _classify_error(e)
        if classification == "duplicate":
            return True  # Treat duplicates as success
        if use_queue and classification == "retryable":
            try:
                await _start_queue_worker()
                q_item = QueuedChunk(
                    chunk_text=chunk_text,
                    chunk_id=chunk_id,
                    metadata=metadata,
                    first_queued_at=time.time(),
                )
                await _queue.put(q_item)
                with _queue_stats_lock:
                    _queue_stats["queued"] += 1
                return False
            except asyncio.QueueFull:
                with _queue_stats_lock:
                    _queue_stats["failed"] += 1
                await _log_error(
                    chunk_id=chunk_id,
                    error_type="queue_full",
                    error_message=f"Queue full: {str(e)}",
                    metadata=metadata,
                )
                return False
        await _log_error(
            chunk_id=chunk_id,
            error_type="fatal",
            error_message=str(e),
            metadata=metadata,
        )
        raise


async def store_chunks_batch(chunks: List[Dict[str, Any]]) -> int:
    """Store multiple chunks in a batch operation.
    
    Args:
        chunks: List of dictionaries with 'text', 'id', and 'metadata' keys.
    
    Returns:
        Number of successfully stored chunks.
    """
    stored = 0
    for chunk in chunks:
        chunk_text = chunk.get("text", "")
        chunk_id = chunk.get("id") or str(uuid.uuid4())
        metadata = chunk.get("metadata", {})
        try:
            success = await store_chunk(chunk_text, chunk_id, metadata, use_queue=True)
            if success:
                stored += 1
        except Exception:
            continue
    return stored


async def search_similar_chunks(
    query: str,
    k: int = 10,
    filter_metadata: Optional[Dict[str, Any]] = None,
) -> List[Document]:
    """Search for similar chunks using semantic similarity.
    
    Args:
        query: Search query text.
        k: Number of results to return.
        filter_metadata: Optional metadata filters.
    
    Returns:
        List of similar Document objects.
    """
    try:
        vector_store = await initialize_vector_store()
        results = await vector_store.asimilarity_search(
            query=query,
            k=k,
            filter=filter_metadata,
        )
        return results
    except Exception as e:
        logger.error("Error searching chunks: %s", e)
        raise


async def get_connection_stats() -> Dict[str, Any]:
    """Get database connection and pool statistics."""
    with _queue_stats_lock:
        queue_stats_snapshot = _queue_stats.copy()
    stats: Dict[str, Any] = {
        "active_connections": 0,
        "max_connections": 0,
        "pool_size": MAX_POOL_SIZE,
        "pool_overflow": MAX_OVERFLOW,
        "pool_checked_out": 0,
        "pool_checked_in": 0,
        "queue_size": _queue.qsize() if _queue else 0,
        "queue_stats": queue_stats_snapshot,
    }
    
    if _engine is None:
        return stats
    
    try:
        from sqlalchemy import text
        async with _engine.begin() as conn:
            result = await conn.execute(
                text("""
                    SELECT 
                        count(*) as active_connections,
                        (SELECT setting::int FROM pg_settings WHERE name = 'max_connections') as max_connections
                    FROM pg_stat_activity 
                    WHERE datname = current_database()
                    AND state = 'active'
                """)
            )
            row = result.fetchone()
            if row:
                stats["active_connections"] = row[0]
                stats["max_connections"] = row[1]
        
        if hasattr(_engine, "pool"):
            pool = _engine.pool
            stats["pool_checked_out"] = pool.checkedout()
            stats["pool_checked_in"] = pool.checkedin()
    except Exception as e:
        stats["error"] = str(e)
    
    return stats


async def get_queue_stats() -> Dict[str, Any]:
    """Get queue statistics."""
    with _queue_stats_lock:
        queue_stats_snapshot = _queue_stats.copy()
    return {
        "memory_queue_size": _queue.qsize() if _queue else 0,
        "stats": queue_stats_snapshot,
    }


async def get_error_logs(
    limit: int = 100,
    offset: int = 0,
    error_type: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Get error logs with optional filtering.
    
    Args:
        limit: Maximum number of records to return.
        offset: Offset for pagination.
        error_type: Filter by error type.
    
    Returns:
        List of error log records.
    """
    logs = _error_log.copy()
    
    if error_type:
        logs = [log for log in logs if log.get("error_type") == error_type]
    
    # Sort by timestamp descending (newest first)
    logs.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
    
    return logs[offset:offset + limit]


async def _search_similar_with_sql_filter(
    query: str,
    k: int = 10,
    filter_metadata: Optional[Dict[str, Any]] = None,
) -> List[Document]:
    """Search using SQL-level patient filtering for better performance."""
    try:
        vector_store = await initialize_vector_store()
        results = await vector_store.asimilarity_search(
            query=query,
            k=k,
            filter=filter_metadata,
        )
        return results
    except Exception as e:
        logger.error("SQL-filtered search error: %s", e)
        raise


async def hybrid_search(
    query: str,
    k: int = 50,
    filter_metadata: Optional[Dict[str, Any]] = None,
    bm25_weight: float = 0.5,
    semantic_weight: float = 0.5,
) -> List[Document]:
    """
    Perform hybrid BM25 + semantic search with reciprocal rank fusion.

    Args:
        query: Search query text.
        k: Number of results to return.
        filter_metadata: Optional metadata filters.
        bm25_weight: Weight for BM25 results (0.0-1.0).
        semantic_weight: Weight for semantic results (0.0-1.0).

    Returns:
        List of Document objects sorted by fused relevance score.
    """
    from db.bm25_search import bm25_search

    # Run both searches
    try:
        semantic_results = await search_similar_chunks(query, k=k, filter_metadata=filter_metadata)
    except Exception as e:
        logger.error("Semantic search failed in hybrid: %s", e)
        semantic_results = []

    try:
        bm25_results = await bm25_search(query, k=k, filter_metadata=filter_metadata, engine=_engine)
    except Exception as e:
        logger.error("BM25 search failed in hybrid: %s", e)
        bm25_results = []

    if not semantic_results and not bm25_results:
        return []

    if not bm25_results:
        return semantic_results[:k]
    if not semantic_results:
        return bm25_results[:k]

    # Reciprocal Rank Fusion
    rrf_constant = 60
    scores: Dict[str, float] = {}
    doc_map: Dict[str, Document] = {}

    for rank, doc in enumerate(semantic_results):
        doc_id = str(getattr(doc, "id", "")) or doc.page_content[:100]
        scores[doc_id] = scores.get(doc_id, 0.0) + semantic_weight / (rrf_constant + rank + 1)
        doc_map[doc_id] = doc

    for rank, doc in enumerate(bm25_results):
        doc_id = str(getattr(doc, "id", "")) or doc.page_content[:100]
        scores[doc_id] = scores.get(doc_id, 0.0) + bm25_weight / (rrf_constant + rank + 1)
        if doc_id not in doc_map:
            doc_map[doc_id] = doc

    sorted_ids = sorted(scores, key=lambda x: scores[x], reverse=True)
    return [doc_map[doc_id] for doc_id in sorted_ids[:k]]


async def get_patient_timeline(
    patient_id: str,
    k: int = 50,
    resource_types: Optional[List[str]] = None,
) -> List[Document]:
    """
    Get chronological patient data sorted by date.

    Args:
        patient_id: Patient UUID to filter by.
        k: Number of results to return.
        resource_types: Optional filter for specific FHIR resource types.

    Returns:
        List of Document objects sorted chronologically.
    """
    from sqlalchemy import text as sql_text

    if _engine is None:
        await initialize_vector_store()

    if not _engine:
        return []

    params: Dict[str, Any] = {"patient_id": patient_id, "k": k}

    base_sql = f"""
        SELECT
            langchain_id,
            content,
            langchain_metadata
        FROM "{SCHEMA_NAME}"."{TABLE_NAME}"
        WHERE langchain_metadata->>'patient_id' = :patient_id
    """

    if resource_types:
        base_sql += " AND langchain_metadata->>'resource_type' = ANY(:resource_types)"
        params["resource_types"] = resource_types

    base_sql += """
        ORDER BY langchain_metadata->>'effective_date' ASC NULLS LAST
        LIMIT :k
    """

    try:
        async with _engine.begin() as conn:
            result = await conn.execute(sql_text(base_sql), params)
            rows = result.fetchall()

            documents = []
            for row in rows:
                if hasattr(row, '_mapping'):
                    langchain_id = row._mapping['langchain_id']
                    content = row._mapping['content']
                    metadata = row._mapping['langchain_metadata'] or {}
                else:
                    langchain_id, content, metadata = row

                doc = Document(
                    id=str(langchain_id),
                    page_content=content or "",
                    metadata=metadata if isinstance(metadata, dict) else {},
                )
                documents.append(doc)

            return documents
    except Exception as e:
        logger.error("Patient timeline error: %s", e)
        return []


async def list_patients(limit: int = 100) -> List[Dict[str, Any]]:
    """List all unique patients in the vector store with summary info.

    Returns a list of patient objects with:
    - id: patient UUID
    - name: extracted from source_file metadata (format: LastName_FirstName_N.json)
    - chunk_count: number of chunks for this patient
    - resource_types: list of FHIR resource types for this patient

    Args:
        limit: Maximum number of patients to return.

    Returns:
        List of patient summary dictionaries.
    """
    from sqlalchemy import text as sql_text

    if _engine is None:
        await initialize_vector_store()

    if not _engine:
        return []

    try:
        async with _engine.begin() as conn:
            result = await conn.execute(sql_text(f"""
                SELECT
                    langchain_metadata->>'patient_id' as patient_id,
                    COUNT(*) as chunk_count,
                    MIN(langchain_metadata->>'source_file') as source_file
                FROM "{SCHEMA_NAME}"."{TABLE_NAME}"
                WHERE langchain_metadata->>'patient_id' IS NOT NULL
                GROUP BY langchain_metadata->>'patient_id'
                ORDER BY chunk_count DESC
                LIMIT :limit
            """), {"limit": limit})
            patient_rows = result.fetchall()

            if not patient_rows:
                return []

            patient_ids = [row[0] for row in patient_rows]
            result = await conn.execute(sql_text(f"""
                SELECT
                    langchain_metadata->>'patient_id' as patient_id,
                    array_agg(DISTINCT langchain_metadata->>'resource_type') as resource_types
                FROM "{SCHEMA_NAME}"."{TABLE_NAME}"
                WHERE langchain_metadata->>'patient_id' = ANY(:patient_ids)
                GROUP BY langchain_metadata->>'patient_id'
            """), {"patient_ids": patient_ids})
            resource_type_rows = {row[0]: row[1] for row in result.fetchall()}

        patients = []
        for patient_id, chunk_count, source_file in patient_rows:
            resource_types = resource_type_rows.get(patient_id, [])
            resource_types = [rt for rt in (resource_types or []) if rt]

            name = "Unknown Patient"
            if source_file:
                try:
                    filename = source_file.split("/")[-1].replace(".json", "")
                    parts = filename.split("_")
                    if len(parts) >= 2:
                        last_name = ''.join(c for c in parts[0] if not c.isdigit())
                        first_name = ''.join(c for c in parts[1] if not c.isdigit())
                        if first_name and last_name:
                            name = f"{first_name} {last_name}"
                except Exception:
                    pass

            patients.append({
                "id": patient_id,
                "name": name,
                "chunk_count": chunk_count,
                "resource_types": resource_types,
            })

        return patients
    except Exception as e:
        logger.error("Error listing patients: %s", e)
        return []


async def close_connections():
    """Close database connections and cleanup."""
    global _engine, _vector_store, _queue_worker_task
    
    if _queue_worker_task:
        _queue_worker_task.cancel()
        try:
            await _queue_worker_task
        except asyncio.CancelledError:
            pass
        _queue_worker_task = None
    
    if _engine:
        await _engine.dispose()
        _engine = None
        _vector_store = None
