"""ASR (Speech-to-Text) providers."""

from core.config import ASRConfig

from .base import BaseASR
from .deepgram import DeepgramASR
from .cartesia import CartesiaASR

__all__ = ["BaseASR", "DeepgramASR", "CartesiaASR", "get_asr_from_config"]


def get_asr_from_config(config: ASRConfig) -> BaseASR:
    """
    Instantiate ASR provider from config.

    Args:
        config: ASRConfig object with provider name and settings

    Returns:
        Initialized BaseASR provider instance

    Raises:
        ValueError: If provider name is not recognized
    """
    provider_name = config.provider.lower()

    if provider_name == "deepgram":
        return DeepgramASR(
            api_key=config.api_key,
            model=config.model or "nova-2",
            language=config.language,
            **config.extra,
        )
    elif provider_name == "cartesia":
        return CartesiaASR(
            api_key=config.api_key,
            model=config.model or "ink-whisper",
            language=config.language,
            **config.extra,
        )
    else:
        raise ValueError(
            f"Unknown ASR provider: {config.provider}. "
            f"Supported: deepgram, cartesia"
        )
