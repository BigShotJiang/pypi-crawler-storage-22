"""Abstract base class for ASR (Speech-to-Text) providers."""

from abc import ABC, abstractmethod
from typing import AsyncIterator, Optional

from core.types import AudioChunk, TranscriptChunk


class BaseASR(ABC):
    """
    Abstract base class for Speech-to-Text providers.

    All ASR implementations must inherit from this class and implement
    the required methods for both batch and streaming transcription.
    """

    def __init__(self, api_key: Optional[str] = None, **kwargs):
        """
        Initialize the ASR provider.

        Args:
            api_key: API key for the provider (if required)
            **kwargs: Additional provider-specific configuration
        """
        self.api_key = api_key
        self.config = kwargs

    @abstractmethod
    async def transcribe(self, audio: bytes, sample_rate: int = 16000) -> str:
        """
        Transcribe a complete audio buffer to text.

        Args:
            audio: Raw audio bytes (PCM format expected)
            sample_rate: Sample rate of the audio in Hz

        Returns:
            Transcribed text string
        """
        pass

    @abstractmethod
    async def transcribe_stream(
        self, audio_stream: AsyncIterator[AudioChunk]
    ) -> AsyncIterator[TranscriptChunk]:
        """
        Transcribe streaming audio in real-time.

        Args:
            audio_stream: Async iterator yielding AudioChunk objects

        Yields:
            TranscriptChunk objects with partial and final transcriptions
        """
        pass

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()

    async def connect(self):
        """
        Establish connection to the ASR service.
        Override in subclasses if needed.
        """
        pass

    async def disconnect(self):
        """
        Close connection to the ASR service.
        Override in subclasses if needed.
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the name of this ASR provider."""
        pass

    @property
    def supports_streaming(self) -> bool:
        """Whether this provider supports real-time streaming."""
        return True
