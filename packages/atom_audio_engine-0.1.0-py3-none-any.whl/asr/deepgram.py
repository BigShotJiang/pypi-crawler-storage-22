"""Deepgram API implementation for ASR (Speech-to-Text)."""

import logging
from typing import AsyncIterator, Optional

from deepgram import DeepgramClient

from core.types import AudioChunk, TranscriptChunk
from .base import BaseASR

logger = logging.getLogger(__name__)


class DeepgramASR(BaseASR):
    """
    Deepgram API client for speech-to-text transcription.

    Supports both batch transcription and real-time streaming.
    Outputs high-accuracy transcripts using Deepgram's Nova-2 model by default.

    Example:
        asr = DeepgramASR(api_key="dg_...")

        # Batch transcription
        text = await asr.transcribe(audio_bytes)

        # Streaming transcription
        async for chunk in asr.transcribe_stream(audio_stream):
            print(chunk.text, end="", flush=True)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "nova-2",
        language: str = "en",
        **kwargs,
    ):
        """
        Initialize Deepgram ASR provider.

        Args:
            api_key: Deepgram API key
            model: Model to use (e.g., "nova-2", "nova", "enhanced")
            language: Language code (e.g., "en", "es", "fr")
            **kwargs: Additional config (stored in self.config)
        """
        super().__init__(api_key=api_key, **kwargs)
        self.model = model
        self.language = language
        self.client = None

    @property
    def name(self) -> str:
        """Return provider name."""
        return "deepgram"

    async def connect(self):
        """
        Initialize Deepgram client.

        Approach:
        1. Create client with API key (from param or env var DEEPGRAM_API_KEY)
        2. Log initialization status

        Rationale: Client reuse for multiple transcription requests.
        """
        try:
            if self.api_key:
                self.client = DeepgramClient(api_key=self.api_key)
            else:
                # Fallback to env var DEEPGRAM_API_KEY
                self.client = DeepgramClient()

            logger.debug("Deepgram client initialized")
        except Exception as e:
            logger.error(f"Failed to initialize Deepgram client: {e}")
            raise

    async def disconnect(self):
        """Close Deepgram client connection."""
        if self.client:
            try:
                pass
            except Exception as e:
                logger.error(f"Error disconnecting Deepgram: {e}")

    async def transcribe(self, audio: bytes, sample_rate: int = 16000) -> str:
        """
        Transcribe complete audio buffer to text.

        Approach:
        1. Initialize client if needed
        2. Send audio to Deepgram prerecorded API
        3. Extract and return transcript text

        Rationale: Batch mode for complete audio files with standard latency.

        Args:
            audio: Raw PCM audio bytes
            sample_rate: Sample rate in Hz (default 16000)

        Returns:
            Transcribed text
        """
        if not self.client:
            await self.connect()

        try:
            logger.debug(f"Transcribing {len(audio)} bytes at {sample_rate}Hz")

            # Call Deepgram API - using synchronous client
            response = self.client.listen.prerecorded.v(
                {
                    "model": self.model,
                    "language": self.language,
                    "encoding": "linear16",
                    "sample_rate": sample_rate,
                }
            ).transcribe_file({"buffer": audio})

            # Extract transcript
            if response and response.results:
                if response.results.channels:
                    channel = response.results.channels[0]
                    if channel.alternatives:
                        transcript = channel.alternatives[0].transcript
                        logger.debug(f"Transcribed to: {transcript[:100]}...")
                        return transcript

            return ""

        except Exception as e:
            logger.error(f"Deepgram transcription error: {e}")
            raise

    async def transcribe_stream(
        self, audio_stream: AsyncIterator[AudioChunk]
    ) -> AsyncIterator[TranscriptChunk]:
        """
        Transcribe streaming audio in real-time.

        Approach:
        1. Collect audio chunks from stream until is_final flag
        2. Send buffered audio to Deepgram API
        3. Yield transcription results

        Rationale: Simple buffering approach; Deepgram SDK doesn't expose
        native streaming in current version, so we batch on is_final signals.

        Args:
            audio_stream: Async iterator yielding AudioChunk objects

        Yields:
            TranscriptChunk objects with partial and final transcriptions
        """
        if not self.client:
            await self.connect()

        try:
            buffer = bytearray()

            async for chunk in audio_stream:
                buffer.extend(chunk.data)

                if chunk.is_final:
                    # Transcribe accumulated buffer
                    if buffer:
                        response = self.client.listen.prerecorded.v(
                            {
                                "model": self.model,
                                "language": self.language,
                                "encoding": "linear16",
                                "sample_rate": 16000,
                            }
                        ).transcribe_file({"buffer": bytes(buffer)})

                        if response and response.results:
                            if response.results.channels:
                                channel = response.results.channels[0]
                                if channel.alternatives:
                                    transcript = channel.alternatives[0].transcript

                                    yield TranscriptChunk(
                                        text=transcript,
                                        is_final=True,
                                        confidence=getattr(
                                            channel.alternatives[0], "confidence", None
                                        ),
                                    )

                        buffer = bytearray()

        except Exception as e:
            logger.error(f"Deepgram streaming error: {e}")
            raise
