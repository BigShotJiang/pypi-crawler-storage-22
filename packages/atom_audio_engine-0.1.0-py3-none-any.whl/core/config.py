"""Configuration management for the audio engine."""

from dataclasses import dataclass, field
from typing import Optional, Any

# Provider defaults
DEFAULT_ASR_PROVIDER = "cartesia"
DEFAULT_LLM_PROVIDER = "groq"
DEFAULT_TTS_PROVIDER = "cartesia"


@dataclass
class ASRConfig:
    """Configuration for ASR (Speech-to-Text) provider."""

    provider: str = DEFAULT_ASR_PROVIDER  # deepgram, etc.
    api_key: Optional[str] = None
    model: Optional[str] = None
    language: str = "en"
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMConfig:
    """Configuration for LLM provider."""

    provider: str = DEFAULT_LLM_PROVIDER  # groq, etc.
    api_key: Optional[str] = None
    model: str = "llama-3.1-8b-instant"
    temperature: float = 0.7
    max_tokens: int = 1024
    system_prompt: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class TTSConfig:
    """Configuration for TTS (Text-to-Speech) provider."""

    provider: str = DEFAULT_TTS_PROVIDER  # cartesia, etc.
    api_key: Optional[str] = None
    voice_id: Optional[str] = None
    model: Optional[str] = None
    speed: float = 1.0
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class StreamingConfig:
    """Configuration for streaming/WebSocket server."""

    host: str = "0.0.0.0"
    port: int = 8765
    chunk_size_ms: int = 100  # Audio chunk size in milliseconds
    buffer_size: int = 4096
    timeout_seconds: float = 30.0


@dataclass
class GeneFaceConfig:
    """Configuration for GeneFace++ integration."""

    enabled: bool = False
    model_path: Optional[str] = None
    output_resolution: tuple[int, int] = (512, 512)
    fps: int = 25


@dataclass
class AudioEngineConfig:
    """Main configuration for the audio engine."""

    asr: ASRConfig = field(default_factory=ASRConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    tts: TTSConfig = field(default_factory=TTSConfig)
    streaming: StreamingConfig = field(default_factory=StreamingConfig)
    geneface: GeneFaceConfig = field(default_factory=GeneFaceConfig)

    # Global settings
    debug: bool = False
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "AudioEngineConfig":
        """
        Create config from environment variables.

        Supported environment variables:
        - ASR_PROVIDER: ASR provider name (default: deepgram)
        - ASR_API_KEY: ASR API key (fallback: DEEPGRAM_API_KEY)
        - LLM_PROVIDER: LLM provider name (default: groq)
        - LLM_API_KEY: LLM API key (fallback: GROQ_API_KEY)
        - LLM_MODEL: LLM model name (default: llama-3.1-8b-instant)
        - TTS_PROVIDER: TTS provider name (default: cartesia)
        - TTS_API_KEY: TTS API key (fallback: CARTESIA_API_KEY)
        - TTS_VOICE_ID: TTS voice identifier
        - DEBUG: Enable debug mode (default: false)
        """
        import os

        return cls(
            asr=ASRConfig(
                provider=os.getenv("ASR_PROVIDER", DEFAULT_ASR_PROVIDER),
                api_key=os.getenv("ASR_API_KEY")
                or os.getenv("CARTESIA_API_KEY")
                or os.getenv("DEEPGRAM_API_KEY"),
            ),
            llm=LLMConfig(
                provider=os.getenv("LLM_PROVIDER", DEFAULT_LLM_PROVIDER),
                api_key=os.getenv("LLM_API_KEY") or os.getenv("GROQ_API_KEY"),
                model=os.getenv("LLM_MODEL", "llama-3.1-8b-instant"),
            ),
            tts=TTSConfig(
                provider=os.getenv("TTS_PROVIDER", DEFAULT_TTS_PROVIDER),
                api_key=os.getenv("TTS_API_KEY") or os.getenv("CARTESIA_API_KEY"),
                voice_id=os.getenv("TTS_VOICE_ID"),
            ),
            debug=os.getenv("DEBUG", "false").lower() == "true",
        )

    @classmethod
    def from_dict(cls, data: dict) -> "AudioEngineConfig":
        """Create config from a dictionary."""
        return cls(
            asr=ASRConfig(**data.get("asr", {})),
            llm=LLMConfig(**data.get("llm", {})),
            tts=TTSConfig(**data.get("tts", {})),
            streaming=StreamingConfig(**data.get("streaming", {})),
            geneface=GeneFaceConfig(**data.get("geneface", {})),
            debug=data.get("debug", False),
            log_level=data.get("log_level", "INFO"),
        )

    def create_pipeline(self, system_prompt: Optional[str] = None) -> "Pipeline":
        """
        Create a Pipeline instance from this config.

        Args:
            system_prompt: Optional system prompt override

        Returns:
            Initialized Pipeline with providers

        Raises:
            ValueError: If provider initialization fails
        """
        from asr import get_asr_from_config
        from llm import get_llm_from_config
        from tts import get_tts_from_config
        from core.pipeline import Pipeline

        asr = get_asr_from_config(self.asr)
        llm = get_llm_from_config(self.llm)
        tts = get_tts_from_config(self.tts)

        return Pipeline(
            asr=asr,
            llm=llm,
            tts=tts,
            system_prompt=system_prompt or self.llm.system_prompt,
            debug=self.debug,
        )
