"""Main pipeline orchestrator for audio-to-audio conversation."""

import asyncio
import logging
import time
from typing import AsyncIterator, Optional, Callable, Any

from asr.base import BaseASR
from llm.base import BaseLLM
from tts.base import BaseTTS
from core.types import (
    AudioChunk,
    TranscriptChunk,
    ResponseChunk,
    ConversationContext,
)

logger = logging.getLogger(__name__)


class Pipeline:
    """
    Main orchestrator for the audio-to-audio conversational pipeline.

    Coordinates the flow: Audio Input → ASR → LLM → TTS → Audio Output

    Example:
        ```python
        pipeline = Pipeline(
            asr=WhisperASR(api_key="..."),
            llm=AnthropicLLM(api_key="...", model="claude-sonnet-4-20250514"),
            tts=CartesiaTTS(api_key="...", voice_id="...")
        )

        # Simple usage
        response_audio = await pipeline.process(input_audio_bytes)

        # Streaming usage
        async for chunk in pipeline.stream(audio_stream):
            play_audio(chunk)
        ```
    """

    def __init__(
        self,
        asr: BaseASR,
        llm: BaseLLM,
        tts: BaseTTS,
        system_prompt: Optional[str] = None,
        on_transcript: Optional[Callable[[str], Any]] = None,
        on_llm_response: Optional[Callable[[str], Any]] = None,
        debug: bool = False,
    ):
        """
        Initialize the pipeline with providers.

        Args:
            asr: Speech-to-Text provider instance
            llm: Language model provider instance
            tts: Text-to-Speech provider instance
            system_prompt: System prompt for the LLM
            on_transcript: Callback when transcript is ready
            on_llm_response: Callback when LLM response is ready
            debug: Enable debug logging
        """
        self.asr = asr
        self.llm = llm
        self.tts = tts

        self.context = ConversationContext(system_prompt=system_prompt)
        self.on_transcript = on_transcript
        self.on_llm_response = on_llm_response
        self.debug = debug

        if debug:
            logging.basicConfig(level=logging.DEBUG)

        self._is_connected = False

    async def connect(self):
        """Initialize connections to all providers."""
        if self._is_connected:
            return

        await asyncio.gather(
            self.asr.connect(),
            self.llm.connect(),
            self.tts.connect(),
        )
        self._is_connected = True
        logger.info("Pipeline connected to all providers")

    async def disconnect(self):
        """Close connections to all providers."""
        if not self._is_connected:
            return

        await asyncio.gather(
            self.asr.disconnect(),
            self.llm.disconnect(),
            self.tts.disconnect(),
        )
        self._is_connected = False
        logger.info("Pipeline disconnected from all providers")

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()

    async def process(self, audio: bytes, sample_rate: int = 16000) -> bytes:
        """
        Process audio input and return complete audio response.

        This is the simple, non-streaming interface. Use `stream()` for
        lower latency.

        Args:
            audio: Input audio bytes (PCM format)
            sample_rate: Sample rate of input audio

        Returns:
            Response audio bytes
        """
        start_time = time.time()

        # Step 1: ASR - Transcribe audio to text
        transcript = await self.asr.transcribe(audio, sample_rate)
        asr_time = time.time() - start_time
        logger.debug(f"ASR completed in {asr_time:.2f}s: {transcript[:50]}...")

        if self.on_transcript:
            self.on_transcript(transcript)

        # Add user message to context
        self.context.add_message("user", transcript)

        # Step 2: LLM - Generate response
        llm_start = time.time()
        response_text = await self.llm.generate(transcript, self.context)
        llm_time = time.time() - llm_start
        logger.debug(f"LLM completed in {llm_time:.2f}s: {response_text[:50]}...")

        if self.on_llm_response:
            self.on_llm_response(response_text)

        # Add assistant message to context
        self.context.add_message("assistant", response_text)

        # Step 3: TTS - Synthesize response to audio
        tts_start = time.time()
        response_audio = await self.tts.synthesize(response_text)
        tts_time = time.time() - tts_start
        logger.debug(f"TTS completed in {tts_time:.2f}s")

        total_time = time.time() - start_time
        logger.info(
            f"Pipeline total: {total_time:.2f}s "
            f"(ASR: {asr_time:.2f}s, LLM: {llm_time:.2f}s, TTS: {tts_time:.2f}s)"
        )

        return response_audio

    async def stream(
        self, audio_stream: AsyncIterator[AudioChunk]
    ) -> AsyncIterator[AudioChunk]:
        """
        Process streaming audio input and yield streaming audio output.

        This provides the lowest latency by:
        1. Streaming ASR transcription
        2. Streaming LLM generation
        3. Streaming TTS synthesis

        Args:
            audio_stream: Async iterator of input AudioChunk objects

        Yields:
            AudioChunk objects containing response audio
        """
        start_time = time.time()

        # Step 1: Stream audio through ASR
        transcript_buffer = ""
        async for transcript_chunk in self.asr.transcribe_stream(audio_stream):
            transcript_buffer += transcript_chunk.text
            if transcript_chunk.is_final:
                break

        if not transcript_buffer.strip():
            return

        asr_time = time.time() - start_time
        logger.debug(f"ASR streaming completed in {asr_time:.2f}s")

        if self.on_transcript:
            self.on_transcript(transcript_buffer)

        self.context.add_message("user", transcript_buffer)

        # Step 2: Stream LLM response and pipe to TTS
        llm_start = time.time()
        response_buffer = ""

        async def llm_text_stream() -> AsyncIterator[str]:
            nonlocal response_buffer
            async for chunk in self.llm.generate_stream(
                transcript_buffer, self.context
            ):
                response_buffer += chunk.text
                yield chunk.text
                if chunk.is_final:
                    break

        # Step 3: Stream TTS audio as LLM generates text
        first_audio_time = None
        async for audio_chunk in self.tts.synthesize_stream_text(llm_text_stream()):
            if first_audio_time is None:
                first_audio_time = time.time() - start_time
                logger.debug(f"Time to first audio: {first_audio_time:.2f}s")
            yield audio_chunk

        llm_time = time.time() - llm_start
        logger.debug(f"LLM+TTS streaming completed in {llm_time:.2f}s")

        if self.on_llm_response:
            self.on_llm_response(response_buffer)

        self.context.add_message("assistant", response_buffer)

        total_time = time.time() - start_time
        logger.info(f"Pipeline streaming total: {total_time:.2f}s")

    async def stream_text_input(self, text: str) -> AsyncIterator[AudioChunk]:
        """
        Process text input (skip ASR) and yield streaming audio output.

        Useful for text-based input or when ASR is handled externally.

        Args:
            text: User's text input

        Yields:
            AudioChunk objects containing response audio
        """
        self.context.add_message("user", text)

        response_buffer = ""

        async def llm_text_stream() -> AsyncIterator[str]:
            nonlocal response_buffer
            async for chunk in self.llm.generate_stream(text, self.context):
                response_buffer += chunk.text
                yield chunk.text

        async for audio_chunk in self.tts.synthesize_stream_text(llm_text_stream()):
            yield audio_chunk

        self.context.add_message("assistant", response_buffer)

    def reset_context(self):
        """Clear conversation history."""
        self.context.clear()
        logger.debug("Conversation context cleared")

    def set_system_prompt(self, prompt: str):
        """Update the system prompt."""
        self.context.system_prompt = prompt
        logger.debug("System prompt updated")

    @property
    def providers(self) -> dict:
        """Get information about configured providers."""
        return {
            "asr": self.asr.name,
            "llm": self.llm.name,
            "tts": self.tts.name,
        }
