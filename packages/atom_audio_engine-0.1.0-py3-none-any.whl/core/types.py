"""Shared types and data structures for the audio engine."""

from dataclasses import dataclass, field
from typing import Optional
from enum import Enum


class AudioFormat(Enum):
    """Supported audio formats."""

    PCM_16K = "pcm_16k"  # 16-bit PCM at 16kHz
    PCM_24K = "pcm_24k"  # 16-bit PCM at 24kHz
    PCM_44K = "pcm_44k"  # 16-bit PCM at 44.1kHz
    WAV = "wav"
    MP3 = "mp3"
    OGG = "ogg"


@dataclass
class AudioChunk:
    """A chunk of audio data."""

    data: bytes
    sample_rate: int = 16000
    channels: int = 1
    format: AudioFormat = AudioFormat.PCM_16K
    timestamp_ms: Optional[int] = None
    is_final: bool = False


@dataclass
class TranscriptChunk:
    """A chunk of transcribed text from ASR."""

    text: str
    is_final: bool = False
    confidence: Optional[float] = None
    timestamp_ms: Optional[int] = None


@dataclass
class ResponseChunk:
    """A chunk of LLM response text."""

    text: str
    is_final: bool = False
    timestamp_ms: Optional[int] = None


@dataclass
class ConversationMessage:
    """A message in the conversation history."""

    role: str  # "user" or "assistant"
    content: str
    timestamp_ms: Optional[int] = None


@dataclass
class ConversationContext:
    """Maintains conversation state and history."""

    messages: list[ConversationMessage] = field(default_factory=list)
    system_prompt: Optional[str] = None
    max_history: int = 20

    def add_message(self, role: str, content: str, timestamp_ms: Optional[int] = None):
        """Add a message to the conversation history."""
        self.messages.append(
            ConversationMessage(role=role, content=content, timestamp_ms=timestamp_ms)
        )
        # Trim history if needed
        if len(self.messages) > self.max_history:
            self.messages = self.messages[-self.max_history :]

    def get_messages_for_llm(self) -> list[dict]:
        """Get messages formatted for LLM API calls."""
        result = []
        if self.system_prompt:
            result.append({"role": "system", "content": self.system_prompt})
        for msg in self.messages:
            result.append({"role": msg.role, "content": msg.content})
        return result

    def clear(self):
        """Clear conversation history."""
        self.messages = []
