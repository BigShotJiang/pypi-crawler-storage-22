"""LLM (Large Language Model) providers."""

from core.config import LLMConfig

from .base import BaseLLM
from .groq import GroqLLM

__all__ = ["BaseLLM", "GroqLLM", "get_llm_from_config"]


def get_llm_from_config(config: LLMConfig) -> BaseLLM:
    """
    Instantiate LLM provider from config.

    Args:
        config: LLMConfig object with provider name and settings

    Returns:
        Initialized BaseLLM provider instance

    Raises:
        ValueError: If provider name is not recognized
    """
    provider_name = config.provider.lower()

    if provider_name == "groq":
        return GroqLLM(
            api_key=config.api_key,
            model=config.model or "llama-3.1-8b-instant",
            temperature=config.temperature,
            max_tokens=config.max_tokens,
            system_prompt=config.system_prompt,
            **config.extra,
        )
    else:
        raise ValueError(
            f"Unknown LLM provider: {config.provider}. " f"Supported: groq"
        )
