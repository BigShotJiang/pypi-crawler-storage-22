"""Abstract base class for LLM providers."""

from abc import ABC, abstractmethod
from typing import AsyncIterator, Optional

from core.types import ResponseChunk, ConversationContext


class BaseLLM(ABC):
    """
    Abstract base class for Large Language Model providers.

    All LLM implementations must inherit from this class and implement
    the required methods for both batch and streaming text generation.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4o",
        temperature: float = 0.7,
        max_tokens: int = 1024,
        system_prompt: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize the LLM provider.

        Args:
            api_key: API key for the provider
            model: Model identifier to use
            temperature: Sampling temperature (0.0-2.0)
            max_tokens: Maximum tokens in response
            system_prompt: Default system prompt
            **kwargs: Additional provider-specific configuration
        """
        self.api_key = api_key
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.system_prompt = system_prompt
        self.config = kwargs

    @abstractmethod
    async def generate(
        self, prompt: str, context: Optional[ConversationContext] = None
    ) -> str:
        """
        Generate a complete response to a prompt.

        Args:
            prompt: User's input text
            context: Optional conversation history

        Returns:
            Complete response text
        """
        pass

    @abstractmethod
    async def generate_stream(
        self, prompt: str, context: Optional[ConversationContext] = None
    ) -> AsyncIterator[ResponseChunk]:
        """
        Generate a streaming response to a prompt.

        Args:
            prompt: User's input text
            context: Optional conversation history

        Yields:
            ResponseChunk objects with partial text
        """
        pass

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()

    async def connect(self):
        """
        Initialize the LLM client.
        Override in subclasses if needed.
        """
        pass

    async def disconnect(self):
        """
        Clean up the LLM client.
        Override in subclasses if needed.
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the name of this LLM provider."""
        pass

    @property
    def supports_streaming(self) -> bool:
        """Whether this provider supports streaming responses."""
        return True
