"""Groq API implementation for LLM (Language Model)."""

import logging
from typing import AsyncIterator, Optional

from groq import Groq

from core.types import ResponseChunk, ConversationContext
from .base import BaseLLM

logger = logging.getLogger(__name__)


class GroqLLM(BaseLLM):
    """
    Groq API client for language model text generation.

    Supports both batch and streaming text generation with excellent
    latency for conversational AI. Uses Groq's optimized inference engine.

    Example:
        llm = GroqLLM(
            api_key="gsk_...",
            model="llama-3.1-8b-instant"
        )

        # Batch generation
        response = await llm.generate("Hello", context=conversation)

        # Streaming generation
        async for chunk in llm.generate_stream("Hello", context=conversation):
            print(chunk.text, end="", flush=True)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "llama-3.1-8b-instant",
        temperature: float = 0.7,
        max_tokens: int = 1024,
        system_prompt: Optional[str] = None,
        **kwargs,
    ):
        """
        Initialize Groq LLM provider.

        Args:
            api_key: Groq API key
            model: Model to use (default "llama-3.1-8b-instant", alternatives: "llama-3.3-70b-versatile", "mixtral-8x7b-32768")
            temperature: Sampling temperature (0.0-2.0)
            max_tokens: Maximum tokens in response
            system_prompt: Default system prompt
            **kwargs: Additional config (stored in self.config)
        """
        super().__init__(
            api_key=api_key,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            system_prompt=system_prompt,
            **kwargs,
        )
        self.client = None

    @property
    def name(self) -> str:
        """Return provider name."""
        return "groq"

    async def connect(self):
        """Initialize Groq client."""
        try:
            self.client = Groq(api_key=self.api_key)
            logger.debug("Groq client initialized")
        except Exception as e:
            logger.error(f"Failed to initialize Groq client: {e}")
            raise

    async def disconnect(self):
        """Close Groq client connection."""
        if self.client:
            try:
                # Groq client cleanup (if supported)
                pass
            except Exception as e:
                logger.error(f"Error disconnecting Groq: {e}")

    async def generate(
        self, prompt: str, context: Optional[ConversationContext] = None
    ) -> str:
        """
        Generate a complete response to a prompt.

        Args:
            prompt: User's input text
            context: Optional conversation history

        Returns:
            Complete response text
        """
        if not self.client:
            await self.connect()

        try:
            # Build message list from context
            messages = []

            # Add system prompt
            system = self.system_prompt or context.system_prompt if context else None
            if system:
                messages.append({"role": "system", "content": system})

            # Add conversation history
            if context:
                for msg in context.get_messages_for_llm():
                    if msg["role"] != "system":  # Avoid duplicate system prompt
                        messages.append(msg)

            # Add current prompt
            messages.append({"role": "user", "content": prompt})

            logger.debug(f"Generating response with {len(messages)} messages")

            # Call Groq API
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=False,
            )

            # Extract text
            if response.choices and response.choices[0].message:
                text = response.choices[0].message.content
                logger.debug(f"Generated response: {text[:100]}...")
                return text

            return ""

        except Exception as e:
            logger.error(f"Groq generation error: {e}")
            raise

    async def generate_stream(
        self, prompt: str, context: Optional[ConversationContext] = None
    ) -> AsyncIterator[ResponseChunk]:
        """
        Generate a streaming response to a prompt.

        Yields text chunks as they are generated for real-time display.

        Args:
            prompt: User's input text
            context: Optional conversation history

        Yields:
            ResponseChunk objects with partial and final text
        """
        if not self.client:
            await self.connect()

        try:
            # Build message list from context
            messages = []

            # Add system prompt
            system = self.system_prompt or context.system_prompt if context else None
            if system:
                messages.append({"role": "system", "content": system})

            # Add conversation history
            if context:
                for msg in context.get_messages_for_llm():
                    if msg["role"] != "system":  # Avoid duplicate system prompt
                        messages.append(msg)

            # Add current prompt
            messages.append({"role": "user", "content": prompt})

            logger.debug(f"Streaming response with {len(messages)} messages")

            # Call Groq API with streaming
            with self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=True,
            ) as response:

                full_text = ""
                for chunk in response:
                    if chunk.choices and chunk.choices[0].delta.content:
                        delta = chunk.choices[0].delta.content
                        full_text += delta

                        # Check if this is the last chunk
                        is_final = (
                            chunk.choices[0].finish_reason is not None
                            and chunk.choices[0].finish_reason != "length"
                        )

                        yield ResponseChunk(text=delta, is_final=is_final)

                logger.debug(f"Streaming complete. Total: {full_text[:100]}...")

        except Exception as e:
            logger.error(f"Groq streaming error: {e}")
            raise
