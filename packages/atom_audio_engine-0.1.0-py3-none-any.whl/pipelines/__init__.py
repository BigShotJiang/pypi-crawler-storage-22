"""Pipeline implementations for audio-engine."""
