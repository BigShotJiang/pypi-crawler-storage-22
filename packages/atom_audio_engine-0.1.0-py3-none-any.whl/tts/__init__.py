"""TTS (Text-to-Speech) providers."""

from core.config import TTSConfig

from .base import BaseTTS
from .cartesia import CartesiaTTS

__all__ = ["BaseTTS", "CartesiaTTS", "get_tts_from_config"]


def get_tts_from_config(config: TTSConfig) -> BaseTTS:
    """
    Instantiate TTS provider from config.

    Args:
        config: TTSConfig object with provider name and settings

    Returns:
        Initialized BaseTTS provider instance

    Raises:
        ValueError: If provider name is not recognized
    """
    provider_name = config.provider.lower()

    if provider_name == "cartesia":
        return CartesiaTTS(
            api_key=config.api_key,
            voice_id=config.voice_id,  # None will use DEFAULT_VOICE_ID in CartesiaTTS
            model=config.model or "sonic-3",
            speed=config.speed,
            **config.extra,
        )
    else:
        raise ValueError(
            f"Unknown TTS provider: {config.provider}. " f"Supported: cartesia"
        )
