"""Abstract base class for TTS (Text-to-Speech) providers."""

from abc import ABC, abstractmethod
from typing import AsyncIterator, Optional

from core.types import AudioChunk, AudioFormat


class BaseTTS(ABC):
    """
    Abstract base class for Text-to-Speech providers.

    All TTS implementations must inherit from this class and implement
    the required methods for both batch and streaming audio synthesis.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        voice_id: Optional[str] = None,
        model: Optional[str] = None,
        speed: float = 1.0,
        output_format: AudioFormat = AudioFormat.PCM_24K,
        **kwargs
    ):
        """
        Initialize the TTS provider.

        Args:
            api_key: API key for the provider
            voice_id: Voice identifier to use
            model: Model identifier (if applicable)
            speed: Speech speed multiplier (1.0 = normal)
            output_format: Desired audio output format
            **kwargs: Additional provider-specific configuration
        """
        self.api_key = api_key
        self.voice_id = voice_id
        self.model = model
        self.speed = speed
        self.output_format = output_format
        self.config = kwargs

    @abstractmethod
    async def synthesize(self, text: str) -> bytes:
        """
        Synthesize complete audio from text.

        Args:
            text: Text to convert to speech

        Returns:
            Complete audio as bytes
        """
        pass

    @abstractmethod
    async def synthesize_stream(self, text: str) -> AsyncIterator[AudioChunk]:
        """
        Synthesize streaming audio from text.

        Args:
            text: Text to convert to speech

        Yields:
            AudioChunk objects with audio data
        """
        pass

    async def synthesize_stream_text(
        self, text_stream: AsyncIterator[str]
    ) -> AsyncIterator[AudioChunk]:
        """
        Synthesize streaming audio from streaming text input.

        This enables sentence-by-sentence TTS as the LLM generates text.
        Default implementation buffers until punctuation. Override for
        providers with native text streaming support.

        Args:
            text_stream: Async iterator yielding text chunks

        Yields:
            AudioChunk objects with audio data
        """
        buffer = ""
        sentence_enders = ".!?;"

        async for text_chunk in text_stream:
            buffer += text_chunk

            # Check if we have a complete sentence
            for ender in sentence_enders:
                if ender in buffer:
                    # Split at the sentence boundary
                    parts = buffer.split(ender, 1)
                    sentence = parts[0] + ender

                    if sentence.strip():
                        async for audio_chunk in self.synthesize_stream(
                            sentence.strip()
                        ):
                            yield audio_chunk

                    buffer = parts[1] if len(parts) > 1 else ""
                    break

        # Handle remaining text
        if buffer.strip():
            async for audio_chunk in self.synthesize_stream(buffer.strip()):
                yield audio_chunk

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()

    async def connect(self):
        """
        Establish connection to the TTS service.
        Override in subclasses if needed.
        """
        pass

    async def disconnect(self):
        """
        Close connection to the TTS service.
        Override in subclasses if needed.
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the name of this TTS provider."""
        pass

    @property
    def supports_streaming(self) -> bool:
        """Whether this provider supports streaming audio output."""
        return True

    @property
    def sample_rate(self) -> int:
        """Return the sample rate for this provider's output."""
        format_rates = {
            AudioFormat.PCM_16K: 16000,
            AudioFormat.PCM_24K: 24000,
            AudioFormat.PCM_44K: 44100,
        }
        return format_rates.get(self.output_format, 24000)
