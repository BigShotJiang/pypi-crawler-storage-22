"""Audio utility functions."""

import struct
from typing import Optional


def resample_audio(
    audio: bytes,
    from_rate: int,
    to_rate: int,
    channels: int = 1,
    sample_width: int = 2,
) -> bytes:
    """
    Resample audio to a different sample rate.

    Uses linear interpolation for simple resampling.
    For higher quality, consider using librosa or scipy.

    Args:
        audio: Input audio bytes (PCM format)
        from_rate: Original sample rate
        to_rate: Target sample rate
        channels: Number of audio channels
        sample_width: Bytes per sample (2 for 16-bit)

    Returns:
        Resampled audio bytes
    """
    if from_rate == to_rate:
        return audio

    try:
        import numpy as np
        from scipy import signal

        # Convert bytes to numpy array
        dtype = np.int16 if sample_width == 2 else np.int32
        samples = np.frombuffer(audio, dtype=dtype)

        # Resample using scipy
        num_samples = int(len(samples) * to_rate / from_rate)
        resampled = signal.resample(samples, num_samples)

        return resampled.astype(dtype).tobytes()

    except ImportError:
        # Fallback to simple linear interpolation
        return _simple_resample(audio, from_rate, to_rate, sample_width)


def _simple_resample(
    audio: bytes,
    from_rate: int,
    to_rate: int,
    sample_width: int = 2,
) -> bytes:
    """Simple linear interpolation resampling."""
    if sample_width == 2:
        fmt = "<h"
        samples = [
            struct.unpack(fmt, audio[i : i + 2])[0] for i in range(0, len(audio), 2)
        ]
    else:
        raise ValueError(f"Unsupported sample width: {sample_width}")

    ratio = from_rate / to_rate
    new_length = int(len(samples) / ratio)
    resampled = []

    for i in range(new_length):
        pos = i * ratio
        idx = int(pos)
        frac = pos - idx

        if idx + 1 < len(samples):
            sample = int(samples[idx] * (1 - frac) + samples[idx + 1] * frac)
        else:
            sample = samples[idx]

        resampled.append(sample)

    return struct.pack(f"<{len(resampled)}h", *resampled)


def pcm_to_wav(
    pcm_data: bytes,
    sample_rate: int = 16000,
    channels: int = 1,
    bits_per_sample: int = 16,
) -> bytes:
    """
    Convert raw PCM data to WAV format.

    Args:
        pcm_data: Raw PCM audio bytes
        sample_rate: Sample rate in Hz
        channels: Number of audio channels
        bits_per_sample: Bits per sample (typically 16)

    Returns:
        WAV file as bytes
    """
    byte_rate = sample_rate * channels * bits_per_sample // 8
    block_align = channels * bits_per_sample // 8
    data_size = len(pcm_data)

    header = struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF",
        36 + data_size,
        b"WAVE",
        b"fmt ",
        16,  # fmt chunk size
        1,  # audio format (PCM)
        channels,
        sample_rate,
        byte_rate,
        block_align,
        bits_per_sample,
        b"data",
        data_size,
    )

    return header + pcm_data


def wav_to_pcm(wav_data: bytes) -> tuple[bytes, int, int, int]:
    """
    Extract raw PCM data from WAV format.

    Args:
        wav_data: WAV file as bytes

    Returns:
        Tuple of (pcm_data, sample_rate, channels, bits_per_sample)
    """
    # Parse RIFF header
    if wav_data[:4] != b"RIFF" or wav_data[8:12] != b"WAVE":
        raise ValueError("Invalid WAV file")

    # Find fmt chunk
    pos = 12
    sample_rate = 0
    channels = 0
    bits_per_sample = 0

    while pos < len(wav_data):
        chunk_id = wav_data[pos : pos + 4]
        chunk_size = struct.unpack("<I", wav_data[pos + 4 : pos + 8])[0]

        if chunk_id == b"fmt ":
            _, channels, sample_rate, _, _, bits_per_sample = struct.unpack(
                "<HHIIHH", wav_data[pos + 8 : pos + 24]
            )
        elif chunk_id == b"data":
            pcm_data = wav_data[pos + 8 : pos + 8 + chunk_size]
            return pcm_data, sample_rate, channels, bits_per_sample

        pos += 8 + chunk_size

    raise ValueError("No data chunk found in WAV file")


def get_audio_duration(
    audio: bytes,
    sample_rate: int,
    channels: int = 1,
    bits_per_sample: int = 16,
) -> float:
    """
    Calculate duration of PCM audio in seconds.

    Args:
        audio: PCM audio bytes
        sample_rate: Sample rate in Hz
        channels: Number of audio channels
        bits_per_sample: Bits per sample

    Returns:
        Duration in seconds
    """
    bytes_per_sample = bits_per_sample // 8
    total_samples = len(audio) // (bytes_per_sample * channels)
    return total_samples / sample_rate


def normalize_audio(audio: bytes, target_db: float = -20.0) -> bytes:
    """
    Normalize audio to a target dB level.

    Args:
        audio: PCM audio bytes (16-bit)
        target_db: Target dB level

    Returns:
        Normalized audio bytes
    """
    try:
        import numpy as np

        samples = np.frombuffer(audio, dtype=np.int16).astype(np.float32)

        # Calculate current RMS
        rms = np.sqrt(np.mean(samples**2))
        if rms == 0:
            return audio

        # Calculate target RMS
        target_rms = 32768 * (10 ** (target_db / 20))

        # Scale
        gain = target_rms / rms
        normalized = np.clip(samples * gain, -32768, 32767).astype(np.int16)

        return normalized.tobytes()

    except ImportError:
        # Return unchanged if numpy not available
        return audio
