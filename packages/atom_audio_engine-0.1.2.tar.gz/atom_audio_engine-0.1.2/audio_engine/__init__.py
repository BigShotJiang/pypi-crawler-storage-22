"""
Audio Engine - Pluggable audio-to-audio conversational AI framework.

Orchestrates ASR → LLM → TTS pipeline with real-time streaming support.
"""

__version__ = "0.1.0"

# Core exports
from .core.pipeline import Pipeline
from .core.config import (
    AudioEngineConfig,
    ASRConfig,
    LLMConfig,
    TTSConfig,
    StreamingConfig,
)
from .core.types import (
    AudioChunk,
    TranscriptChunk,
    ResponseChunk,
    ConversationContext,
)

# ASR Providers
from .asr.base import BaseASR
from .asr.cartesia import CartesiaASR

try:
    from .asr.deepgram import DeepgramASR
except ImportError:
    pass

# LLM Providers
from .llm.base import BaseLLM
from .llm.groq import GroqLLM

# TTS Providers
from .tts.base import BaseTTS
from .tts.cartesia import CartesiaTTS

# Streaming
from .streaming.websocket_server import WebSocketServer

# Integrations
try:
    from .integrations.geneface import GeneFacePipelineWrapper, GeneFaceConfig
except ImportError:
    pass

__all__ = [
    # Version
    "__version__",
    # Core
    "Pipeline",
    "AudioEngineConfig",
    "ASRConfig",
    "LLMConfig",
    "TTSConfig",
    "StreamingConfig",
    "AudioChunk",
    "TranscriptChunk",
    "ResponseChunk",
    "ConversationContext",
    # ASR
    "BaseASR",
    "CartesiaASR",
    "DeepgramASR",
    # LLM
    "BaseLLM",
    "GroqLLM",
    # TTS
    "BaseTTS",
    "CartesiaTTS",
    # Streaming
    "WebSocketServer",
    # Integrations
    "GeneFacePipelineWrapper",
    "GeneFaceConfig",
]
