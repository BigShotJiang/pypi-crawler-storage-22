"""Example scripts for the audio engine."""
