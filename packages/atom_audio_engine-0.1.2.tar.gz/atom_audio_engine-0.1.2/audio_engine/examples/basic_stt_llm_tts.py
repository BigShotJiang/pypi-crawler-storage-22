#!/usr/bin/env python3
"""
Example: Basic STT-LLM-TTS Pipeline

Simple example showing how to use the core audio-to-audio pipeline:
Audio Input → ASR → LLM → TTS → Audio Output

Usage:
    # Text input only (skips ASR)
    python examples/basic_stt_llm_tts.py

    # Audio file input (full STT-LLM-TTS)
    python examples/basic_stt_llm_tts.py examples/audio_clip_1.mp3

Setup:
    export CARTESIA_API_KEY="your-cartesia-key"
    export GROQ_API_KEY="your-groq-key"
"""

import asyncio
import logging
import sys
import wave
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
from core.config import AudioEngineConfig
from core.types import AudioChunk

# Load environment variables from .env file
load_dotenv(Path(__file__).parent.parent.parent / ".env")

# Setup logging to see debug messages
logging.basicConfig(
    level=logging.DEBUG, format="%(name)s - %(levelname)s - %(message)s"
)


async def stream_audio_file(file_path: str, chunk_size: int = 4096):
    """Stream audio from file (MP3, WAV, etc.) as chunks."""
    try:
        from pydub import AudioSegment
    except ImportError:
        print("❌ pydub required. Install: pip install pydub")
        raise

    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"Audio file not found: {file_path}")

    print(f"📁 Loading: {file_path.name}")

    # Load and convert to 16kHz mono 16-bit PCM
    audio = AudioSegment.from_file(str(file_path))
    audio = audio.set_channels(1).set_frame_rate(16000).set_sample_width(2)

    duration_sec = len(audio) / 1000.0
    print(f"✓ Audio: {duration_sec:.2f}s @ 16kHz mono\n")

    # Stream as chunks
    audio_bytes = audio.raw_data
    chunk_index = 0
    offset = 0
    total_chunks = (len(audio_bytes) + chunk_size - 1) // chunk_size

    while offset < len(audio_bytes):
        chunk_data = audio_bytes[offset : offset + chunk_size]
        chunk_index += 1
        is_final = offset + chunk_size >= len(audio_bytes)

        # Yield as AudioChunk object
        yield AudioChunk(
            data=chunk_data, sample_rate=16000, format="pcm_s16le", is_final=is_final
        )
        offset += chunk_size


async def main():
    """Run basic pipeline example."""
    print("=" * 60)
    print("Audio Engine: Basic STT-LLM-TTS Pipeline")
    print("=" * 60)
    print()

    # Check if audio file provided as argument
    audio_file = None
    if len(sys.argv) > 1:
        audio_file = sys.argv[1]

    # Load configuration from environment
    config = AudioEngineConfig.from_env()
    print(f"✓ Config loaded:")
    print(f"  - ASR: {config.asr.provider}")
    print(f"  - LLM: {config.llm.provider}")
    print(f"  - TTS: {config.tts.provider}")
    print()

    # Create pipeline from config
    pipeline = config.create_pipeline(
        system_prompt="You are a helpful assistant. Keep responses brief."
    )
    print(f"✓ Pipeline created")
    print()

    if audio_file:
        # Full pipeline: Audio → ASR → LLM → TTS
        print("-" * 60)
        print("FULL PIPELINE: STT → LLM → TTS")
        print("-" * 60 + "\n")

        transcript = ""
        llm_response = ""
        audio_output = bytearray()
        chunk_count = 0

        try:
            audio_generator = stream_audio_file(audio_file)

            async for result in pipeline.stream(audio_generator):
                if hasattr(result, "text"):
                    class_name = result.__class__.__name__
                    if class_name == "TranscriptChunk":
                        transcript += result.text
                        print(f"🎤 STT: {result.text!r}")
                    elif class_name == "ResponseChunk":
                        llm_response += result.text
                        print(f"🧠 LLM: {result.text!r}")

                elif hasattr(result, "data") and result.data:
                    audio_output.extend(result.data)
                    chunk_count += 1
                    if chunk_count % 5 == 0:
                        print(f"🔊 TTS: {len(audio_output)} bytes...")

            if chunk_count > 0:
                print(f"🔊 TTS: {len(audio_output)} bytes total")

            # Save output
            if audio_output:
                output_dir = Path(__file__).parent / "output_samples"
                output_dir.mkdir(exist_ok=True)
                output_path = output_dir / "output_audio.wav"
                with wave.open(str(output_path), "wb") as wav_file:
                    wav_file.setnchannels(1)
                    wav_file.setsampwidth(2)
                    wav_file.setframerate(16000)
                    wav_file.writeframes(bytes(audio_output))

                duration_sec = len(audio_output) / 32000
                print(f"\n✓ Audio saved to {output_path} ({duration_sec:.2f}s)")

            # Print results
            print("\n" + "=" * 60)
            print("RESULTS")
            print("=" * 60)
            if transcript:
                print(f"🎤 Transcribed: {transcript!r}")
            if llm_response:
                print(f"🧠 Response: {llm_response!r}")
            print("=" * 60 + "\n")

        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback

            traceback.print_exc()
            return

    else:
        # Simplified pipeline: Text → LLM → TTS (no ASR)
        print("-" * 60)
        print("SIMPLIFIED PIPELINE: Text → LLM → TTS")
        print("-" * 60 + "\n")

        user_text = "What is the capital of France?"
        print(f"User: {user_text}\n")

        chunk_count = 0
        total_bytes = 0
        async for audio_chunk in pipeline.stream_text_input(user_text):
            chunk_count += 1
            total_bytes += len(audio_chunk.data)
            print(f"  • Audio chunk {chunk_count}: {len(audio_chunk.data)} bytes")

        print()
        print("✓ Pipeline complete")
        print(f"  Total audio: {total_bytes} bytes across {chunk_count} chunks")
        print()
        print("Conversation history:")
        for msg in pipeline.context.messages:
            role = msg.role.upper()
            content = msg.content[:60]
            print(f"  {role}: {content}...")


if __name__ == "__main__":
    asyncio.run(main())
