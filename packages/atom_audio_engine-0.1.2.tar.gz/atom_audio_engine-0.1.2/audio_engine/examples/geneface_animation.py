#!/usr/bin/env python3
"""
Example: GeneFace++ Face Animation Integration

Combines audio with GeneFace++ to generate an animated face
that speaks the assistant's responses.

GeneFaceIntegration takes a GeneFaceConfig (no pipeline parameter).
It generates videos from audio bytes using:
- generate_video(audio_bytes, sample_rate) -> video_path
- generate_video_stream(audio_chunks) -> video_path

Setup:
    1. Clone GeneFace++ repository:
       git clone https://github.com/yerfor/GeneFace-plusplus.git

    2. Install GeneFace++ (see their docs)

    3. Update geneface_path in this script

Run:
    python examples/geneface_animation.py
"""

import asyncio
import sys
import logging
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
from integrations.geneface import GeneFaceIntegration, GeneFaceConfig

# Load environment variables from .env file
load_dotenv(Path(__file__).parent.parent / ".env")

# Setup logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    """Run GeneFace++ animation example."""
    print("=" * 60)
    print("Audio Engine: GeneFace++ Face Animation")
    print("=" * 60)
    print()

    # Setup GeneFace++ configuration
    geneface_path = ""
    if not geneface_path.exists():
        logger.error(f"GeneFace++ path not found: {geneface_path}")
        logger.info("Clone GeneFace-plusplus:")
        logger.info("  git clone https://github.com/yerfor/GeneFace-plusplus.git")
        logger.info()
        logger.info("Update geneface_path variable in this script")
        return

    geneface_config = GeneFaceConfig(
        geneface_path=str(geneface_path),
        checkpoint_path=None,  # Specify trained model checkpoint if available
        output_resolution=(512, 512),
        fps=25,
        device="cuda",  # or "cpu"
    )

    # Initialize GeneFace integration
    try:
        geneface = GeneFaceIntegration(config=geneface_config)
        logger.info("GeneFace++ integration initialized")
        print()

        # Example: Generate video from audio
        sample_rate = 16000
        duration_seconds = 2
        # For demo, create silence (all zeros)
        audio_bytes = bytes(sample_rate * duration_seconds * 2)  # 16-bit PCM

        logger.info(f"Generating video from {duration_seconds}s audio...")
        video_path = await geneface.generate_video(
            audio=audio_bytes,
            sample_rate=sample_rate,
            output_path=None,  # Uses temp file
        )

        logger.info(f"✓ Video saved to: {video_path}")
        logger.info("GeneFace++ video generation working!")

    except Exception as e:
        logger.error(f"Error: {e}")
        logger.info("Make sure GeneFace++ is properly installed and configured")


if __name__ == "__main__":
    asyncio.run(main())
