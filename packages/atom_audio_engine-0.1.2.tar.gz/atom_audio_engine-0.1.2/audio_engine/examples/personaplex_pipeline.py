#!/usr/bin/env python3
"""
Example: PersonaPlex Full-Duplex Pipeline

PersonaPlex is a full-duplex audio pipeline allowing simultaneous
input/output - user can interrupt while assistant is speaking.

PersonaPlexPipeline API:
- __init__(config=None, system_prompt="...", save_transcripts=True)
- await start() -> connects to server
- await stop() -> closes connection, saves transcript
- async for (audio_chunk, text_chunk) in stream(audio_stream=None)
- PersonaPlexConfig uses voice_prompt (not voice_id)

Setup:
    Obtain PersonaPlex server URL from RunPod or similar service
    Set environment (optional, PersonaPlexConfig has defaults):
       export PERSONAPLEX_SERVER="wss://your-server/"
       export PERSONAPLEX_VOICE_PROMPT="NATF0.pt"

Run:
    python examples/personaplex_pipeline.py

Note:
    PersonaPlex is full-duplex (simultaneous I/O) unlike
    sequential STT-LLM-TTS pipeline.
"""

import asyncio
import sys
import logging
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
from pipelines.personaplex import PersonaPlexPipeline, PersonaPlexConfig

# Load environment variables from .env file
load_dotenv(Path(__file__).parent.parent / ".env")

# Setup logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    """Run PersonaPlex full-duplex pipeline example."""
    print("=" * 60)
    print("Audio Engine: PersonaPlex Full-Duplex Pipeline")
    print("=" * 60)
    print()

    # Configure PersonaPlex
    config = PersonaPlexConfig(
        # server_url="wss://your-personaplex-server",  # Uses default if not set
        voice_prompt="NATF0.pt",  # Voice ID (not voice_id)
        text_temperature=0.7,
        audio_temperature=0.8,
        save_transcripts=True,
    )

    logger.info("PersonaPlex Configuration:")
    logger.info(f"  Server: {config.server_url[:50]}...")
    logger.info(f"  Voice Prompt: {config.voice_prompt}")
    logger.info(f"  Text Temp: {config.text_temperature}")
    logger.info(f"  Audio Temp: {config.audio_temperature}")
    print()

    # Create pipeline
    pipeline = PersonaPlexPipeline(
        config=config,
        system_prompt="You are a helpful, friendly AI assistant.",
        save_transcripts=True,
    )

    try:
        # Start connection
        await pipeline.start()
        logger.info("✓ Connected to PersonaPlex server")
        logger.info("✓ Ready for full-duplex streaming")
        print()

        # Example: Stream bidirectional audio/text
        logger.info("Streaming audio and text (press Ctrl+C to stop)...")
        chunk_count = 0

        async for audio_chunk, text_chunk in pipeline.stream():
            if text_chunk:
                logger.info(f"[Assistant] {text_chunk.text}")
            if audio_chunk:
                chunk_count += 1
                logger.info(
                    f"[Audio] Chunk {chunk_count}: {len(audio_chunk.data)} bytes"
                )

        # Stop and save transcript
        transcript_data = await pipeline.stop()
        logger.info("✓ Pipeline stopped")
        if transcript_data:
            logger.info(f"✓ Transcript saved (session: {transcript_data.session_id})")

    except KeyboardInterrupt:
        logger.info("\n⏹️  Stopped by user")
        await pipeline.stop()
    except Exception as e:
        logger.error(f"Error: {e}")
        logger.info("Make sure PersonaPlex server is running and accessible")
        await pipeline.stop()


if __name__ == "__main__":
    asyncio.run(main())
