#!/usr/bin/env python3
"""
Example: WebSocket Server for Real-Time Audio Streaming

Runs a WebSocket server that accepts live audio streams and returns
responses in real-time. Clients can send binary audio and receive text
transcripts + response audio.

Setup:
    export DEEPGRAM_API_KEY="your-deepgram-key"
    export GROQ_API_KEY="your-groq-key"
    export CARTESIA_API_KEY="your-cartesia-key"

Run:
    python examples/websocket_server.py

Then connect a WebSocket client to ws://localhost:8765

Example client (JavaScript):
    const ws = new WebSocket("ws://localhost:8765");
    ws.binaryType = "arraybuffer";
    ws.onopen = () => {
        // Send audio data
        ws.send(audioBuffer);
        // Signal end of speech
        ws.send(JSON.stringify({"type": "end_of_speech"}));
    };
    ws.onmessage = (event) => {
        if (typeof event.data === "string") {
            console.log("Event:", JSON.parse(event.data));
        } else {
            console.log("Audio data:", event.data);
        }
    };
"""

import asyncio
import sys
import logging
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
from core.config import AudioEngineConfig
from streaming.websocket_server import run_server_from_config

# Load environment variables from .env file
load_dotenv(Path(__file__).parent.parent / ".env")

# Setup logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    """Run WebSocket server."""
    print("=" * 60)
    print("Audio Engine: WebSocket Server")
    print("=" * 60)
    print()

    # Load configuration from environment
    config = AudioEngineConfig.from_env()
    logger.info(f"Config loaded")
    logger.info(f"  ASR: {config.asr.provider}")
    logger.info(f"  LLM: {config.llm.provider}")
    logger.info(f"  TTS: {config.tts.provider}")
    logger.info(f"  Host: {config.streaming.host}")
    logger.info(f"  Port: {config.streaming.port}")
    print()

    try:
        await run_server_from_config(
            config,
            system_prompt="You are a helpful audio assistant. Keep responses brief and natural.",
        )
    except KeyboardInterrupt:
        logger.info("Server shutting down...")


if __name__ == "__main__":
    asyncio.run(main())
