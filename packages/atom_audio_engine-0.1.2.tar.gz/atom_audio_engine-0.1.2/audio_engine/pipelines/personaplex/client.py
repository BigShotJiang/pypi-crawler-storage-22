"""Low-level WebSocket client for PersonaPlex."""

import asyncio
import logging
from typing import AsyncIterator, Optional

import websockets
from websockets.asyncio.client import ClientConnection

from .config import PersonaPlexConfig
from .types import MessageType, PersonaPlexMessage, AudioChunk, TextChunk

logger = logging.getLogger(__name__)


class PersonaPlexClient:
    """
    WebSocket client for PersonaPlex speech-to-speech model.

    Handles binary message encoding/decoding, Opus audio streaming,
    and bidirectional text/audio communication.

    Approach:
    - Connect to WebSocket URL with query parameters (text_prompt, voice_prompt, etc.)
    - Send Opus audio chunks with 0x01 prefix
    - Receive Opus audio and text tokens asynchronously
    - Handle connection lifecycle: connect, send, receive, disconnect
    """

    def __init__(self, config: PersonaPlexConfig):
        """
        Initialize PersonaPlex WebSocket client.

        Args:
            config: PersonaPlexConfig with server URL and model parameters
        """
        self.config = config
        self.connection: Optional[ClientConnection] = None
        self._is_connected = False

    def _build_url(self, system_prompt: str) -> str:
        """
        Build WebSocket URL with query parameters.

        Args:
            system_prompt: Text prompt for controlling persona/behavior

        Returns:
            Full WebSocket URL with encoded parameters
        """
        url = self.config.server_url
        params = {
            "text_prompt": system_prompt,
            "voice_prompt": self.config.voice_prompt,
            "text_temperature": str(self.config.text_temperature),
            "audio_temperature": str(self.config.audio_temperature),
            "text_topk": str(self.config.text_topk),
            "audio_topk": str(self.config.audio_topk),
        }

        # URL-encode and append parameters
        param_str = "&".join(f"{k}={v}" for k, v in params.items())
        return f"{url}?{param_str}"

    async def connect(self, system_prompt: str) -> None:
        """
        Connect to PersonaPlex WebSocket server.

        Args:
            system_prompt: System prompt for persona control

        Raises:
            ConnectionError: If connection fails
        """
        if self._is_connected:
            logger.warning("Already connected, skipping reconnect")
            return

        try:
            url = self._build_url(system_prompt)
            logger.debug(f"Connecting to PersonaPlex at {url}")

            self.connection = await websockets.connect(
                url,
                ping_interval=30,  # Send ping every 30s to keep connection alive
                ping_timeout=10,
            )
            self._is_connected = True
            logger.info("Connected to PersonaPlex server")

        except Exception as e:
            logger.error(f"Failed to connect to PersonaPlex: {e}")
            raise ConnectionError(f"PersonaPlex connection failed: {e}") from e

    async def disconnect(self) -> None:
        """Close WebSocket connection."""
        if self.connection and self._is_connected:
            try:
                await self.connection.close()
                logger.info("Disconnected from PersonaPlex server")
            except Exception as e:
                logger.error(f"Error closing connection: {e}")
            finally:
                self.connection = None
                self._is_connected = False

    async def send_audio(self, audio_chunk: bytes) -> None:
        """
        Send Opus-encoded audio chunk to server.

        Args:
            audio_chunk: Raw Opus-encoded audio bytes

        Raises:
            RuntimeError: If not connected
        """
        if not self._is_connected or not self.connection:
            raise RuntimeError("Not connected to PersonaPlex server")

        try:
            # Message format: 0x01 (audio type) + Opus bytes
            message = MessageType.AUDIO.value.to_bytes(1, "big") + audio_chunk
            await self.connection.send(message)
        except Exception as e:
            logger.error(f"Failed to send audio: {e}")
            raise

    async def receive_audio(self) -> Optional[AudioChunk]:
        """
        Receive next audio chunk from server.

        Returns:
            AudioChunk with Opus data, or None if disconnected

        Raises:
            RuntimeError: If not connected
        """
        if not self._is_connected or not self.connection:
            raise RuntimeError("Not connected to PersonaPlex server")

        try:
            message = await asyncio.wait_for(
                self.connection.recv(),
                timeout=self.config.session_timeout_seconds,
            )

            if isinstance(message, bytes):
                parsed = PersonaPlexMessage.decode(message)
                if parsed.type == MessageType.AUDIO:
                    return AudioChunk(
                        data=parsed.data,  # type: ignore
                        sample_rate=self.config.sample_rate,
                    )
                elif parsed.type == MessageType.ERROR:
                    error_msg = (
                        parsed.data.decode("utf-8")
                        if isinstance(parsed.data, bytes)
                        else parsed.data
                    )
                    logger.error(f"Server error: {error_msg}")
                    return None
        except asyncio.TimeoutError:
            logger.warning("Timeout waiting for audio from server")
            return None
        except Exception as e:
            logger.error(f"Error receiving audio: {e}")
            raise

        return None

    async def receive_text(self) -> Optional[TextChunk]:
        """
        Receive next text token from server.

        Returns:
            TextChunk with text data, or None if no text available

        Raises:
            RuntimeError: If not connected
        """
        if not self._is_connected or not self.connection:
            raise RuntimeError("Not connected to PersonaPlex server")

        try:
            message = await asyncio.wait_for(
                self.connection.recv(),
                timeout=self.config.session_timeout_seconds,
            )

            if isinstance(message, bytes):
                parsed = PersonaPlexMessage.decode(message)
                if parsed.type == MessageType.TEXT:
                    return TextChunk(text=parsed.data)  # type: ignore
        except asyncio.TimeoutError:
            logger.warning("Timeout waiting for text from server")
            return None
        except Exception as e:
            logger.error(f"Error receiving text: {e}")
            raise

        return None

    async def receive_any(self) -> Optional[PersonaPlexMessage]:
        """
        Receive next message of any type from server.

        Returns:
            PersonaPlexMessage, or None on timeout/error
        """
        if not self._is_connected or not self.connection:
            raise RuntimeError("Not connected to PersonaPlex server")

        try:
            message = await asyncio.wait_for(
                self.connection.recv(),
                timeout=self.config.session_timeout_seconds,
            )

            if isinstance(message, bytes):
                return PersonaPlexMessage.decode(message)
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.error(f"Error receiving message: {e}")
            raise

        return None

    async def stream_messages(self) -> AsyncIterator[PersonaPlexMessage]:
        """
        Stream all messages from server until disconnection.

        Yields:
            PersonaPlexMessage objects as they arrive
        """
        if not self._is_connected or not self.connection:
            raise RuntimeError("Not connected to PersonaPlex server")

        try:
            async for message in self.connection:
                if isinstance(message, bytes):
                    parsed = PersonaPlexMessage.decode(message)
                    yield parsed
        except Exception as e:
            logger.error(f"Error in message stream: {e}")
            raise

    @property
    def is_connected(self) -> bool:
        """Check if currently connected."""
        return self._is_connected and self.connection is not None

    async def __aenter__(self) -> "PersonaPlexClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()
