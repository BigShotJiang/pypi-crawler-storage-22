"""Configuration for PersonaPlex speech-to-speech pipeline."""

from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path


@dataclass
class PersonaPlexConfig:
    """
    Configuration for PersonaPlex full-duplex speech-to-speech model.

    PersonaPlex is a real-time, full-duplex conversational speech model
    that handles audio input/output simultaneously with optional text streaming.

    Attributes:
        server_url: WebSocket URL to PersonaPlex server (default: official RunPod deployment)
        voice_prompt: Voice preset name (e.g., "NATF0.pt", "NATM1.pt")
                     See: https://github.com/NVIDIA/personaplex#voices
        text_prompt: System prompt for controlling persona/behavior
        text_temperature: LLM temperature for text generation (0.0-2.0)
        audio_temperature: Audio codec temperature for naturalness (0.0-2.0)
        text_topk: Top-K sampling for text tokens
        audio_topk: Top-K sampling for audio tokens
        sample_rate: Audio sample rate in Hz (Opus default: 48000)
        save_transcripts: Whether to save session transcripts to disk
        transcript_path: Directory to save transcripts
        session_timeout_seconds: Max seconds to wait before closing idle connection
    """

    server_url: str = "wss://cl9unux255nnzf-8998.proxy.runpod.net"
    voice_prompt: str = "NATF0.pt"
    text_prompt: str = "You are a helpful AI assistant. Have a natural conversation."
    text_temperature: float = 0.7
    audio_temperature: float = 0.8
    text_topk: int = 25
    audio_topk: int = 250
    sample_rate: int = 48000
    save_transcripts: bool = True
    transcript_path: str = "./transcripts/"
    session_timeout_seconds: float = 300.0
    extra: dict = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.text_temperature < 0.0 or self.text_temperature > 2.0:
            raise ValueError("text_temperature must be between 0.0 and 2.0")
        if self.audio_temperature < 0.0 or self.audio_temperature > 2.0:
            raise ValueError("audio_temperature must be between 0.0 and 2.0")
        if self.text_topk < 1:
            raise ValueError("text_topk must be >= 1")
        if self.audio_topk < 1:
            raise ValueError("audio_topk must be >= 1")
        if self.sample_rate not in (48000, 24000, 16000):
            raise ValueError("sample_rate must be 48000, 24000, or 16000")

        # Create transcript directory if save_transcripts is enabled
        if self.save_transcripts:
            Path(self.transcript_path).mkdir(parents=True, exist_ok=True)

    @classmethod
    def default(cls) -> "PersonaPlexConfig":
        """Get default configuration."""
        return cls()

    @classmethod
    def from_dict(cls, data: dict) -> "PersonaPlexConfig":
        """Create config from dictionary."""
        return cls(**data)
