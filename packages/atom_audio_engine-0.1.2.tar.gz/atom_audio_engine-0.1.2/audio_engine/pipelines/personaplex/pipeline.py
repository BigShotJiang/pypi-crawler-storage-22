"""Main PersonaPlex pipeline orchestrator."""

import asyncio
import logging
from typing import AsyncIterator, Optional, Tuple

from .config import PersonaPlexConfig
from .client import PersonaPlexClient
from .types import MessageType, AudioChunk, TextChunk, SessionData
from .utils import generate_session_id, get_timestamp_iso, save_transcript

logger = logging.getLogger(__name__)


class PersonaPlexPipeline:
    """
    Full-duplex speech-to-speech pipeline using PersonaPlex.

    This pipeline handles real-time bidirectional communication:
    - Sends user audio to PersonaPlex
    - Receives assistant audio and text streaming from PersonaPlex
    - Maintains conversation transcript
    - Optionally saves transcripts to disk

    Unlike the audio-engine's sequential ASR→LLM→TTS pipeline, PersonaPlex
    is truly full-duplex: user can speak while assistant responds simultaneously.

    Approach:
    1. Create session with UUID and timestamp
    2. Connect client with system prompt
    3. Launch concurrent receive task to handle server messages
    4. Caller sends user audio; pipeline yields received audio/text chunks
    5. On stop, save transcript and disconnect

    Example:
        ```python
        pipeline = PersonaPlexPipeline(
            system_prompt="You are a helpful AI.",
            save_transcripts=True
        )
        await pipeline.start()

        # Send user audio, receive assistant response
        async for audio_chunk, text_chunk in pipeline.stream(user_audio_stream):
            if audio_chunk:
                play_audio(audio_chunk)
            if text_chunk:
                print(text_chunk.text, end="", flush=True)

        transcript = await pipeline.stop()
        ```
    """

    def __init__(
        self,
        config: Optional[PersonaPlexConfig] = None,
        system_prompt: str = "You are a helpful AI assistant.",
        save_transcripts: bool = True,
        debug: bool = False,
    ):
        """
        Initialize PersonaPlex pipeline.

        Args:
            config: PersonaPlexConfig (uses defaults if None)
            system_prompt: System prompt for persona control
            save_transcripts: Whether to save transcript after session
            debug: Enable debug logging
        """
        self.config = config or PersonaPlexConfig()
        self.config.text_prompt = system_prompt
        self.config.save_transcripts = save_transcripts

        self.system_prompt = system_prompt
        self.client = PersonaPlexClient(self.config)

        # Session state
        self.session_id = generate_session_id()
        self.session_data = SessionData(
            session_id=self.session_id,
            timestamp=get_timestamp_iso(),
            system_prompt=system_prompt,
            voice_prompt=self.config.voice_prompt,
        )

        self._is_running = False
        self._receive_task: Optional[asyncio.Task] = None
        self._audio_queue: asyncio.Queue[Optional[AudioChunk]] = asyncio.Queue()
        self._text_queue: asyncio.Queue[Optional[TextChunk]] = asyncio.Queue()

        if debug:
            logging.basicConfig(level=logging.DEBUG)

        logger.info(f"PersonaPlexPipeline initialized (session: {self.session_id})")

    async def start(self) -> None:
        """
        Connect to PersonaPlex server and start listening for messages.

        Raises:
            ConnectionError: If connection fails
        """
        if self._is_running:
            logger.warning("Pipeline already running")
            return

        try:
            await self.client.connect(self.system_prompt)
            self._is_running = True

            # Start background task to receive messages
            self._receive_task = asyncio.create_task(self._receive_loop())
            logger.info("PersonaPlex pipeline started")

        except Exception as e:
            logger.error(f"Failed to start pipeline: {e}")
            raise

    async def stop(self) -> Optional[SessionData]:
        """
        Stop the pipeline, close connection, and optionally save transcript.

        Returns:
            SessionData with transcript if save_transcripts=True, else None
        """
        if not self._is_running:
            logger.warning("Pipeline not running")
            return None

        try:
            self._is_running = False

            # Cancel receive task
            if self._receive_task:
                self._receive_task.cancel()
                try:
                    await self._receive_task
                except asyncio.CancelledError:
                    pass

            # Disconnect from server
            await self.client.disconnect()

            # Save transcript if enabled
            if self.config.save_transcripts:
                transcript_path = save_transcript(
                    self.session_data,
                    self.config.transcript_path,
                )
                logger.info(f"Transcript saved: {transcript_path}")

            logger.info("PersonaPlex pipeline stopped")
            return self.session_data

        except Exception as e:
            logger.error(f"Error stopping pipeline: {e}")
            raise

    async def _receive_loop(self) -> None:
        """
        Background task: continuously receive messages from server.

        Puts audio/text chunks into respective queues.
        """
        try:
            async for message in self.client.stream_messages():
                if not self._is_running:
                    break

                if message.type == MessageType.AUDIO:
                    chunk = AudioChunk(
                        data=message.data,  # type: ignore
                        sample_rate=self.config.sample_rate,
                    )
                    await self._audio_queue.put(chunk)

                elif message.type == MessageType.TEXT:
                    text = (
                        message.data.decode("utf-8")
                        if isinstance(message.data, bytes)
                        else message.data
                    )
                    chunk = TextChunk(text=text)
                    # Track in transcript
                    if text and text.strip():
                        self.session_data.add_message("assistant", text)
                    await self._text_queue.put(chunk)

                elif message.type == MessageType.ERROR:
                    error_msg = (
                        message.data.decode("utf-8")
                        if isinstance(message.data, bytes)
                        else str(message.data)
                    )
                    logger.error(f"Server error: {error_msg}")

        except asyncio.CancelledError:
            logger.debug("Receive loop cancelled")
        except Exception as e:
            logger.error(f"Error in receive loop: {e}")

    async def send_audio(self, audio_chunk: bytes) -> None:
        """
        Send audio chunk to PersonaPlex server.

        Args:
            audio_chunk: Raw Opus-encoded audio bytes
        """
        if not self._is_running:
            raise RuntimeError("Pipeline not running")

        try:
            await self.client.send_audio(audio_chunk)
            # Track in transcript (user audio sent)
            # Note: We don't transcribe user audio; PersonaPlex returns text
        except Exception as e:
            logger.error(f"Failed to send audio: {e}")
            raise

    async def stream(
        self,
        audio_stream: Optional[AsyncIterator[bytes]] = None,
    ) -> AsyncIterator[Tuple[Optional[AudioChunk], Optional[TextChunk]]]:
        """
        Stream bidirectional audio/text from PersonaPlex.

        This is a generator that yields (audio_chunk, text_chunk) tuples.
        If audio_stream is provided, sends user audio concurrently.

        Approach:
        - If audio_stream provided: spawn task to continuously send user audio
        - Concurrently receive audio and text from server
        - Yield (audio, text) tuples as they arrive (either can be None)

        Args:
            audio_stream: Optional async iterator of audio bytes to send

        Yields:
            Tuple of (AudioChunk or None, TextChunk or None)
        """
        if not self._is_running:
            raise RuntimeError("Pipeline not running")

        # Optional task to send user audio
        send_task: Optional[asyncio.Task] = None

        if audio_stream:

            async def send_user_audio():
                """Background task: send audio from user stream."""
                try:
                    async for audio_chunk in audio_stream:
                        if not self._is_running:
                            break
                        await self.send_audio(audio_chunk)
                except asyncio.CancelledError:
                    logger.debug("Send task cancelled")
                except Exception as e:
                    logger.error(f"Error sending audio: {e}")

            send_task = asyncio.create_task(send_user_audio())

        try:
            while self._is_running:
                # Wait for either audio or text (non-blocking)
                try:
                    # Try to get audio (non-blocking)
                    audio_chunk = self._audio_queue.get_nowait()
                except asyncio.QueueEmpty:
                    audio_chunk = None

                try:
                    # Try to get text (non-blocking)
                    text_chunk = self._text_queue.get_nowait()
                except asyncio.QueueEmpty:
                    text_chunk = None

                # If we got something, yield it
                if audio_chunk or text_chunk:
                    yield (audio_chunk, text_chunk)
                else:
                    # Nothing available, wait a bit before polling again
                    await asyncio.sleep(0.01)

        finally:
            # Clean up send task
            if send_task:
                send_task.cancel()
                try:
                    await send_task
                except asyncio.CancelledError:
                    pass

    async def __aenter__(self) -> "PersonaPlexPipeline":
        """Async context manager entry."""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.stop()
