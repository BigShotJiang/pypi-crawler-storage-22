"""Data types for PersonaPlex speech-to-speech pipeline."""

from dataclasses import dataclass, field
from typing import Optional
from enum import Enum
from datetime import UTC, datetime


class MessageType(Enum):
    """WebSocket message types for PersonaPlex protocol."""

    HANDSHAKE = 0x00
    AUDIO = 0x01
    TEXT = 0x02
    CONTROL = 0x03
    METADATA = 0x04
    ERROR = 0x05
    PING = 0x06


@dataclass
class PersonaPlexMessage:
    """
    A message in the PersonaPlex WebSocket protocol.

    Attributes:
        type: Message type (audio, text, handshake, etc.)
        data: Message payload (bytes for audio, str for text)
        timestamp_ms: Optional timestamp in milliseconds
    """

    type: MessageType
    data: bytes | str
    timestamp_ms: Optional[int] = None

    def encode(self) -> bytes:
        """Encode message to binary format for transmission."""
        type_byte = bytes([self.type.value])
        if isinstance(self.data, bytes):
            return type_byte + self.data
        else:
            return type_byte + self.data.encode("utf-8")

    @classmethod
    def decode(cls, data: bytes) -> "PersonaPlexMessage":
        """Decode binary message from WebSocket."""
        if len(data) < 1:
            raise ValueError("Message too short")

        msg_type = MessageType(data[0])
        payload = data[1:]

        # Text messages are UTF-8 decoded
        if msg_type == MessageType.TEXT:
            text_data = payload.decode("utf-8")
            return cls(type=msg_type, data=text_data)
        else:
            return cls(type=msg_type, data=payload)


@dataclass
class TranscriptMessage:
    """
    A single message in the conversation transcript.

    Attributes:
        role: "user" or "assistant"
        text: The message content
        timestamp: ISO 8601 timestamp when message was generated
    """

    role: str
    text: str
    timestamp: str


@dataclass
class SessionData:
    """
    Metadata and transcript for a PersonaPlex session.

    Attributes:
        session_id: Unique session identifier (UUID)
        timestamp: Session start time (ISO 8601)
        system_prompt: System prompt used for the session
        voice_prompt: Voice preset used (e.g., "NATF0.pt")
        messages: List of transcript messages (user + assistant)
    """

    session_id: str
    timestamp: str
    system_prompt: str
    voice_prompt: str
    messages: list[TranscriptMessage] = field(default_factory=list)

    def add_message(self, role: str, text: str) -> None:
        """Add a message to the transcript."""
        msg = TranscriptMessage(
            role=role,
            text=text,
            timestamp=datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        )
        self.messages.append(msg)

    def to_dict(self) -> dict:
        """Convert session data to dictionary for JSON serialization."""
        return {
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "system_prompt": self.system_prompt,
            "voice_prompt": self.voice_prompt,
            "messages": [
                {
                    "role": msg.role,
                    "text": msg.text,
                    "timestamp": msg.timestamp,
                }
                for msg in self.messages
            ],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SessionData":
        """Create SessionData from dictionary."""
        messages = [
            TranscriptMessage(
                role=msg["role"],
                text=msg["text"],
                timestamp=msg.get("timestamp", ""),
            )
            for msg in data.get("messages", [])
        ]
        return cls(
            session_id=data["session_id"],
            timestamp=data["timestamp"],
            system_prompt=data["system_prompt"],
            voice_prompt=data["voice_prompt"],
            messages=messages,
        )


@dataclass
class AudioChunk:
    """
    A chunk of audio data from PersonaPlex.

    Attributes:
        data: Raw Opus-encoded audio bytes
        sample_rate: Sample rate in Hz (typically 48000)
        timestamp_ms: When this chunk was generated
        is_final: Whether this is the last chunk in a sequence
    """

    data: bytes
    sample_rate: int = 48000
    timestamp_ms: Optional[int] = None
    is_final: bool = False


@dataclass
class TextChunk:
    """
    A text token from PersonaPlex LLM output.

    Attributes:
        text: Text content (partial or complete word)
        timestamp_ms: When this token was generated
        is_final: Whether this is the last token in a sequence
    """

    text: str
    timestamp_ms: Optional[int] = None
    is_final: bool = False
