"""Utility functions for PersonaPlex pipeline."""

import json
import logging
import uuid
from pathlib import Path
from datetime import datetime, UTC
from typing import Optional

from .types import SessionData

logger = logging.getLogger(__name__)


def generate_session_id() -> str:
    """
    Generate a unique session identifier.

    Returns:
        UUID4 string for this session
    """
    return str(uuid.uuid4())


def get_timestamp_iso() -> str:
    """
    Get current timestamp in ISO 8601 format with Z suffix.

    Returns:
        Timestamp string (e.g., "2026-02-03T10:30:45.123456Z")
    """
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def save_transcript(
    session_data: SessionData,
    output_path: Optional[str] = None,
) -> Path:
    """
    Save session transcript to JSON file.

    Approach:
    1. Convert SessionData to dictionary
    2. Write as formatted JSON
    3. Return path for verification

    Args:
        session_data: SessionData object with transcript
        output_path: Directory to save transcript (default: ./transcripts/)

    Returns:
        Path to saved JSON file

    Raises:
        IOError: If file write fails
    """
    if output_path is None:
        output_path = "./transcripts/"

    output_dir = Path(output_path)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Filename: session_id_YYYY-MM-DD.json
    timestamp_str = session_data.timestamp.split("T")[0]  # Extract date
    filename = f"{session_data.session_id}_{timestamp_str}.json"
    filepath = output_dir / filename

    try:
        with open(filepath, "w") as f:
            json.dump(session_data.to_dict(), f, indent=2)
        logger.info(f"Transcript saved to {filepath}")
        return filepath
    except IOError as e:
        logger.error(f"Failed to save transcript: {e}")
        raise


def load_transcript(filepath: str | Path) -> SessionData:
    """
    Load session transcript from JSON file.

    Args:
        filepath: Path to transcript JSON file

    Returns:
        SessionData object

    Raises:
        FileNotFoundError: If file doesn't exist
        json.JSONDecodeError: If JSON is invalid
    """
    filepath = Path(filepath)

    try:
        with open(filepath, "r") as f:
            data = json.load(f)
        logger.info(f"Loaded transcript from {filepath}")
        return SessionData.from_dict(data)
    except FileNotFoundError:
        logger.error(f"Transcript file not found: {filepath}")
        raise
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in transcript file: {e}")
        raise


def list_transcripts(directory: str | Path = "./transcripts/") -> list[Path]:
    """
    List all transcript files in a directory.

    Args:
        directory: Path to transcripts directory

    Returns:
        List of Path objects for .json files, sorted by modification time (newest first)
    """
    dir_path = Path(directory)
    if not dir_path.exists():
        logger.warning(f"Transcripts directory does not exist: {directory}")
        return []

    transcripts = sorted(
        dir_path.glob("*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return transcripts


def format_transcript_for_display(session_data: SessionData) -> str:
    """
    Format transcript as human-readable text.

    Args:
        session_data: SessionData object

    Returns:
        Formatted text with speaker labels and messages
    """
    lines = [
        f"=== PersonaPlex Session ===",
        f"Session ID: {session_data.session_id}",
        f"Started: {session_data.timestamp}",
        f"Voice: {session_data.voice_prompt}",
        f"Prompt: {session_data.system_prompt}",
        f"",
        "--- Transcript ---",
    ]

    for msg in session_data.messages:
        speaker = msg.role.upper()
        lines.append(f"{speaker}: {msg.text}")
        lines.append("")

    return "\n".join(lines)


def cleanup_old_transcripts(
    directory: str | Path = "./transcripts/",
    max_age_days: int = 30,
) -> int:
    """
    Delete transcripts older than specified number of days.

    Args:
        directory: Path to transcripts directory
        max_age_days: Delete files older than this many days

    Returns:
        Number of files deleted
    """
    from datetime import timedelta
    import time

    dir_path = Path(directory)
    if not dir_path.exists():
        return 0

    cutoff_time = time.time() - (max_age_days * 24 * 60 * 60)
    deleted_count = 0

    for transcript_file in dir_path.glob("*.json"):
        if transcript_file.stat().st_mtime < cutoff_time:
            try:
                transcript_file.unlink()
                logger.info(f"Deleted old transcript: {transcript_file}")
                deleted_count += 1
            except OSError as e:
                logger.error(f"Failed to delete {transcript_file}: {e}")

    logger.info(f"Cleaned up {deleted_count} old transcripts")
    return deleted_count
