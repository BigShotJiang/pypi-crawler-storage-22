#!/usr/bin/env python3
"""
Debug the exact pipeline flow
"""

import asyncio
import sys
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.DEBUG, format="%(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

from core.config import AudioEngineConfig


async def main():
    logger.info("\n" + "=" * 70)
    logger.info("DEBUG: Full Pipeline Flow")
    logger.info("=" * 70)

    # Load config exactly like the example does
    config = AudioEngineConfig.from_env()
    logger.info(f"✓ Config loaded")
    logger.info(f"  ASR: {config.asr.provider}")
    logger.info(f"  LLM: {config.llm.provider}")
    logger.info(f"  TTS: {config.tts.provider}")

    # Create pipeline exactly like the example does
    pipeline = config.create_pipeline(
        system_prompt="You are a helpful assistant. Keep responses brief."
    )
    logger.info(f"✓ Pipeline created")

    # Log TTS config
    logger.info(f"\n  TTS Details:")
    logger.info(
        f"    api_key: {pipeline.tts.api_key[:10]}..."
        if pipeline.tts.api_key
        else "    api_key: None"
    )
    logger.info(f"    voice_id: {pipeline.tts.voice_id}")
    logger.info(f"    model: {pipeline.tts.model}")
    logger.info(f"    sample_rate: {pipeline.tts.sample_rate}")

    # Test with simple text
    logger.info(f"\n✓ Testing with simple text...")
    user_text = "Hello world"

    try:
        chunk_count = 0
        total_bytes = 0
        async for audio_chunk in pipeline.stream_text_input(user_text):
            chunk_count += 1
            total_bytes += len(audio_chunk.data) if audio_chunk.data else 0
            is_final_str = "final" if audio_chunk.is_final else "chunk"
            logger.info(
                f"  • Audio {is_final_str} {chunk_count}: {len(audio_chunk.data) if audio_chunk.data else 0} bytes"
            )

        logger.info(f"\n✓ SUCCESS: Got {chunk_count} chunks, {total_bytes} bytes")
    except Exception as e:
        logger.error(f"✗ FAILED: {type(e).__name__}: {e}", exc_info=True)
        return 1

    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
