#!/usr/bin/env python3
"""
Debug script: Test CartesiaTTS in isolation
"""

import asyncio
import sys
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from dotenv import load_dotenv
from tts.cartesia import CartesiaTTS

# Load env variables
load_dotenv()

# Setup logging
logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def test_simple_text():
    """Test simple text-to-speech."""
    logger.info("=" * 70)
    logger.info("TEST: Simple Text-to-Speech")
    logger.info("=" * 70)

    tts = CartesiaTTS(
        api_key=None,  # Will use env var
        voice_id=None,  # Will use default
        model="sonic-3",
        sample_rate=16000,
    )

    logger.info(f"TTS Config:")
    logger.info(f"  API Key: {tts.api_key}")
    logger.info(f"  Voice ID: {tts.voice_id}")
    logger.info(f"  Model: {tts.model}")
    logger.info(f"  Sample Rate: {tts.sample_rate}")

    try:
        logger.info("\nCalling synthesize_stream_text with simple text...")

        async def text_gen():
            yield "Hello "
            yield "world"

        chunk_count = 0
        total_bytes = 0

        async for chunk in tts.synthesize_stream_text(text_gen()):
            chunk_count += 1
            if chunk.data:
                total_bytes += len(chunk.data)
                logger.info(
                    f"✓ Got audio chunk {chunk_count}: {len(chunk.data)} bytes, is_final={chunk.is_final}"
                )
            else:
                logger.info(f"✓ Got final marker: is_final={chunk.is_final}")

        logger.info(f"\n✓ SUCCESS: Got {chunk_count} chunks, {total_bytes} bytes total")

    except Exception as e:
        logger.error(f"✗ FAILED: {type(e).__name__}: {e}", exc_info=True)
        return False

    return True


async def test_with_queue():
    """Test using asyncio.Queue like the original example."""
    logger.info("\n" + "=" * 70)
    logger.info("TEST: With asyncio.Queue (like StreamingService)")
    logger.info("=" * 70)

    tts = CartesiaTTS(
        api_key=None,
        voice_id=None,
        model="sonic-3",
        sample_rate=16000,
    )

    queue = asyncio.Queue()

    async def text_producer():
        """Simulate LLM producing text tokens."""
        tokens = ["Hello ", "world", "!"]
        for token in tokens:
            logger.info(f"📤 Producing: {token!r}")
            await queue.put(token)
        logger.info("📤 Putting None to signal end")
        await queue.put(None)

    async def queue_to_async_iter():
        """Convert queue to async iterator."""
        while True:
            token = await queue.get()
            if token is None:
                break
            yield token

    try:
        logger.info("\nStarting text producer and TTS consumer...")

        producer_task = asyncio.create_task(text_producer())

        chunk_count = 0
        total_bytes = 0

        async for chunk in tts.synthesize_stream_text(queue_to_async_iter()):
            chunk_count += 1
            if chunk.data:
                total_bytes += len(chunk.data)
                logger.info(f"✓ Got audio chunk {chunk_count}: {len(chunk.data)} bytes")
            else:
                logger.info(f"✓ Got final marker")

        await producer_task

        logger.info(f"\n✓ SUCCESS: Got {chunk_count} chunks, {total_bytes} bytes total")
        return True

    except Exception as e:
        logger.error(f"✗ FAILED: {type(e).__name__}: {e}", exc_info=True)
        return False


async def main():
    logger.info("\n")
    logger.info("╔" + "=" * 68 + "╗")
    logger.info("║" + " " * 15 + "CARTESIA TTS DEBUG TEST" + " " * 31 + "║")
    logger.info("╚" + "=" * 68 + "╝")

    results = []

    # Test 1: Simple text
    results.append(("Simple text-to-speech", await test_simple_text()))

    # Test 2: Queue-based
    results.append(("Queue-based streaming", await test_with_queue()))

    # Summary
    logger.info("\n" + "=" * 70)
    logger.info("SUMMARY")
    logger.info("=" * 70)
    for test_name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        logger.info(f"{status}: {test_name}")

    all_passed = all(result for _, result in results)
    logger.info("=" * 70)

    return 0 if all_passed else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
