#!/usr/bin/env python3
"""Test Cartesia WebSocket connection and capture error message."""

import asyncio
import logging
from pathlib import Path
from urllib.parse import quote

import websockets
from websockets.exceptions import InvalidStatus

# Setup logging
logging.basicConfig(level=logging.DEBUG)

# Load env
from dotenv import load_dotenv
import os

load_dotenv(Path(__file__).parent.parent / ".env")

CARTESIA_API_KEY = os.getenv("CARTESIA_API_KEY")


async def test_connection():
    """Test Cartesia WebSocket connection."""
    url = (
        f"wss://api.cartesia.ai/stt/websocket?"
        f"model={quote('ink-whisper')}"
        f"&language={quote('en')}"
        f"&encoding={quote('pcm_s16le')}"
        f"&sample_rate={quote('16000')}"
        f"&min_volume={quote('0.0')}"
        f"&max_silence_duration_secs={quote('30.0')}"
        f"&api_key={quote(CARTESIA_API_KEY)}"
    )

    print(f"Connecting to: {url}\n")

    try:
        async with websockets.connect(url, open_timeout=30) as ws:
            print("✓ Connected!")
    except InvalidStatus as e:
        print(f"✗ Invalid Status Error")
        print(f"  Response object: {e.response}")
        print(
            f"  Response dir: {[attr for attr in dir(e.response) if not attr.startswith('_')]}"
        )
        print(f"  Exception str: {str(e)}")
    except Exception as e:
        print(f"✗ Connection failed: {e}")
        import traceback

        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test_connection())
