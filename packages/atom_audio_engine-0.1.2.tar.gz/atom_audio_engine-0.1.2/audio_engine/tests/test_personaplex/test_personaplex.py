"""PersonaPlex test suite.

Organized by step for maintainability:
- test_personaplex_config.py     (Step 1: Config)
- test_personaplex_message.py    (Step 2: Message encoding/decoding)
- test_personaplex_transcript.py (Step 3: Transcript save/load)
- test_personaplex_session.py    (Step 4: Session management)
- test_personaplex_client.py     (Step 5: Client connection)
- test_personaplex_pipeline.py   (Step 6-7: Pipeline lifecycle + mock messages)
"""
