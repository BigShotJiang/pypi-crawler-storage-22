"""Tests for PersonaPlexClient WebSocket connection (Step 5)."""

import pytest
from unittest.mock import AsyncMock, patch
import asyncio

from pipelines.personaplex import PersonaPlexClient, PersonaPlexConfig


class TestPersonaPlexClientInit:
    """Test client initialization and URL building."""

    def test_client_init_with_defaults(self):
        """Can we create a client with default config?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        assert client.config == config
        assert client.connection is None
        assert not client._is_connected

    def test_client_init_with_custom_config(self):
        """Can we create a client with custom config?"""
        config = PersonaPlexConfig(
            server_url="wss://custom.example.com",
            voice_prompt="NATM0.pt",
        )
        client = PersonaPlexClient(config)

        assert client.config.server_url == "wss://custom.example.com"
        assert client.config.voice_prompt == "NATM0.pt"

    def test_url_building_includes_voice_prompt(self):
        """Does URL building include voice_prompt parameter?"""
        config = PersonaPlexConfig(voice_prompt="NATF0.pt")
        client = PersonaPlexClient(config)

        url = client._build_url("Test prompt")

        assert "voice_prompt=NATF0.pt" in url
        assert "text_prompt=" in url

    def test_url_building_includes_temperatures(self):
        """Does URL include temperature parameters?"""
        config = PersonaPlexConfig(
            text_temperature=0.5,
            audio_temperature=0.9,
        )
        client = PersonaPlexClient(config)

        url = client._build_url("Test prompt")

        assert "text_temperature=0.5" in url
        assert "audio_temperature=0.9" in url

    def test_url_building_encodes_system_prompt(self):
        """Is system prompt included in URL?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        url = client._build_url("Hello world!")

        assert "text_prompt=" in url


@pytest.mark.asyncio
class TestPersonaPlexClientConnection:
    """Test client WebSocket connection lifecycle."""

    async def test_connect_opens_websocket(self):
        """Does connect establish a WebSocket?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        with patch("websockets.connect", new_callable=AsyncMock) as mock_connect:
            mock_conn = AsyncMock()
            mock_connect.return_value = mock_conn

            await client.connect("Hello assistant")

            assert client._is_connected
            mock_connect.assert_called_once()

    async def test_disconnect_closes_websocket(self):
        """Does disconnect close the WebSocket?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        mock_conn = AsyncMock()
        client.connection = mock_conn
        client._is_connected = True

        await client.disconnect()

        mock_conn.close.assert_called_once()
        assert not client._is_connected
        assert client.connection is None

    async def test_context_manager_exits_cleanly(self):
        """Does context manager call disconnect on exit?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        # Manually set up connection
        mock_conn = AsyncMock()
        client.connection = mock_conn
        client._is_connected = True

        async with client:
            # Still connected during the context
            assert client._is_connected

        # Should be disconnected after exiting
        mock_conn.close.assert_called_once()
        assert not client._is_connected


@pytest.mark.asyncio
class TestPersonaPlexClientSendReceive:
    """Test sending and receiving data."""

    async def test_send_audio_creates_message(self):
        """Does send_audio create a binary message?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        mock_conn = AsyncMock()
        client.connection = mock_conn
        client._is_connected = True

        audio_data = b"fake_opus_data"
        await client.send_audio(audio_data)

        mock_conn.send.assert_called_once()
        sent_data = mock_conn.send.call_args[0][0]

        # Should start with 0x01 (audio type)
        assert sent_data[0] == 0x01
        assert sent_data[1:] == audio_data

    async def test_receive_audio_parses_message(self):
        """Does receive_audio return AudioChunk?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        # Create a raw audio message (0x01 + audio data)
        audio_data = b"received_opus"
        raw_message = bytes([0x01]) + audio_data

        mock_conn = AsyncMock()
        mock_conn.recv.return_value = raw_message
        client.connection = mock_conn
        client._is_connected = True

        from pipelines.personaplex import AudioChunk

        chunk = await client.receive_audio()

        assert isinstance(chunk, AudioChunk)
        assert chunk.data == audio_data
        assert chunk.sample_rate == 48000

    async def test_receive_text_parses_message(self):
        """Does receive_text return TextChunk?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        # Create a raw text message (0x02 + UTF-8 text)
        text = "Hello from server"
        raw_message = bytes([0x02]) + text.encode("utf-8")

        mock_conn = AsyncMock()
        mock_conn.recv.return_value = raw_message
        client.connection = mock_conn
        client._is_connected = True

        from pipelines.personaplex import TextChunk

        chunk = await client.receive_text()

        assert isinstance(chunk, TextChunk)
        assert chunk.text == text

    async def test_receive_error_returns_none(self):
        """Does receive_audio handle error messages gracefully?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        # Create an error message (0x05 + error text)
        error_text = "Connection failed"
        raw_message = bytes([0x05]) + error_text.encode("utf-8")

        mock_conn = AsyncMock()
        mock_conn.recv.return_value = raw_message
        client.connection = mock_conn
        client._is_connected = True

        result = await client.receive_audio()

        # Should return None, not raise
        assert result is None


@pytest.mark.asyncio
class TestPersonaPlexClientStreaming:
    """Test streaming message handling."""

    async def test_stream_messages_yields_raw_messages(self):
        """Does stream_messages yield PersonaPlexMessage objects?"""
        from pipelines.personaplex import PersonaPlexMessage, MessageType

        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        # Create mock messages - raw bytes
        audio_msg = bytes([0x01]) + b"audio_data"
        text_msg = bytes([0x02]) + "Hello".encode("utf-8")

        # Mock connection returns bytes
        mock_conn = AsyncMock()
        mock_conn.__aiter__.return_value = [audio_msg, text_msg]
        client.connection = mock_conn
        client._is_connected = True

        messages = []
        try:
            async for msg in client.stream_messages():
                messages.append(msg)
                if len(messages) >= 2:
                    break
        except (StopAsyncIteration, asyncio.CancelledError):
            pass

        # Should get 2 PersonaPlexMessage objects
        assert len(messages) == 2
        assert messages[0].type == MessageType.AUDIO
        assert messages[1].type == MessageType.TEXT

    async def test_stream_messages_skips_errors(self):
        """Does stream_messages skip error messages?"""
        config = PersonaPlexConfig()
        client = PersonaPlexClient(config)

        # Error message type (0x05)
        error_msg = bytes([0x05]) + b"Server error"

        mock_conn = AsyncMock()
        mock_conn.recv.return_value = error_msg
        client.connection = mock_conn
        client._is_connected = True

        chunks = []
        async for chunk in client.stream_messages():
            chunks.append(chunk)
            if len(chunks) > 1:  # Prevent infinite loop
                break

        # Error should be skipped (logged), not returned as chunk
        assert len(chunks) == 0
