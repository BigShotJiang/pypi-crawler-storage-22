"""Tests for PersonaPlexConfig (Step 1)."""

import pytest
from pathlib import Path
from pipelines.personaplex import PersonaPlexConfig


class TestPersonaPlexConfig:
    """Test PersonaPlexConfig creation and validation."""

    def test_default_creation(self):
        """Can we create PersonaPlexConfig with defaults?"""
        config = PersonaPlexConfig()
        assert config.voice_prompt == "NATF0.pt"
        assert config.text_temperature == 0.7
        assert config.audio_temperature == 0.8
        assert config.sample_rate == 48000

    def test_custom_values(self):
        """Can we create config with custom values?"""
        config = PersonaPlexConfig(
            voice_prompt="NATM1.pt",
            text_temperature=0.5,
            audio_temperature=0.9,
        )
        assert config.voice_prompt == "NATM1.pt"
        assert config.text_temperature == 0.5
        assert config.audio_temperature == 0.9

    def test_reject_invalid_text_temp(self):
        """Does it reject text_temperature > 2.0?"""
        with pytest.raises(ValueError):
            PersonaPlexConfig(text_temperature=2.5)

    def test_reject_invalid_audio_temp(self):
        """Does it reject audio_temperature < 0.0?"""
        with pytest.raises(ValueError):
            PersonaPlexConfig(audio_temperature=-0.1)

    def test_reject_invalid_topk(self):
        """Does it reject invalid top-K values?"""
        with pytest.raises(ValueError):
            PersonaPlexConfig(text_topk=0)

    def test_reject_invalid_sample_rate(self):
        """Does it reject invalid sample rates?"""
        with pytest.raises(ValueError):
            PersonaPlexConfig(sample_rate=22050)

    def test_from_dict(self):
        """Can we load config from a dictionary?"""
        data = {
            "voice_prompt": "NATF2.pt",
            "text_temperature": 0.8,
            "audio_temperature": 0.9,
        }
        config = PersonaPlexConfig.from_dict(data)
        assert config.voice_prompt == "NATF2.pt"
        assert config.text_temperature == 0.8
        assert config.audio_temperature == 0.9

    def test_transcript_dir_created(self):
        """Does it create transcript directory on init?"""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            config = PersonaPlexConfig(
                transcript_path=tmpdir + "/transcripts/",
                save_transcripts=True,
            )
            assert Path(config.transcript_path).exists()
