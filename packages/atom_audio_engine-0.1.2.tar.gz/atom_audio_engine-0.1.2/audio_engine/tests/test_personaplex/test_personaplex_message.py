"""Tests for PersonaPlexMessage (Step 2)."""

import pytest
from pipelines.personaplex import PersonaPlexMessage, MessageType


class TestPersonaPlexMessage:
    """Test WebSocket message encoding and decoding."""

    def test_encode_audio(self):
        """Can we encode an audio message?"""
        audio_data = b"fake_opus_audio"
        msg = PersonaPlexMessage(type=MessageType.AUDIO, data=audio_data)
        encoded = msg.encode()

        assert encoded[0] == 0x01
        assert encoded[1:] == audio_data

    def test_encode_text(self):
        """Can we encode a text message?"""
        text = "Hello, world!"
        msg = PersonaPlexMessage(type=MessageType.TEXT, data=text)
        encoded = msg.encode()

        assert encoded[0] == 0x02
        assert encoded[1:] == text.encode("utf-8")

    def test_decode_audio(self):
        """Can we decode an audio message?"""
        audio_data = b"fake_opus_audio"
        raw = bytes([0x01]) + audio_data

        msg = PersonaPlexMessage.decode(raw)
        assert msg.type == MessageType.AUDIO
        assert msg.data == audio_data

    def test_decode_text(self):
        """Can we decode a text message?"""
        text = "Hello, assistant!"
        raw = bytes([0x02]) + text.encode("utf-8")

        msg = PersonaPlexMessage.decode(raw)
        assert msg.type == MessageType.TEXT
        assert msg.data == text

    def test_decode_error(self):
        """Can we decode an error message?"""
        error_text = b"Connection timeout"
        raw = bytes([0x05]) + error_text

        msg = PersonaPlexMessage.decode(raw)
        assert msg.type == MessageType.ERROR
        assert msg.data == error_text

    def test_roundtrip_audio(self):
        """Audio message roundtrip: encode then decode?"""
        original_data = b"\x00\x01\x02\x03\x04\x05"
        msg1 = PersonaPlexMessage(type=MessageType.AUDIO, data=original_data)

        encoded = msg1.encode()
        msg2 = PersonaPlexMessage.decode(encoded)

        assert msg2.type == msg1.type
        assert msg2.data == original_data

    def test_roundtrip_text(self):
        """Text message roundtrip: encode then decode?"""
        original_text = "This is a test message with émojis 🎉"
        msg1 = PersonaPlexMessage(type=MessageType.TEXT, data=original_text)

        encoded = msg1.encode()
        msg2 = PersonaPlexMessage.decode(encoded)

        assert msg2.type == msg1.type
        assert msg2.data == original_text

    def test_decode_too_short(self):
        """Does decode reject empty message?"""
        with pytest.raises(ValueError):
            PersonaPlexMessage.decode(b"")
