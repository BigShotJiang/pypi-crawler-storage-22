"""Tests for PersonaPlexPipeline lifecycle and orchestration (Step 6-7)."""

import pytest
from unittest.mock import AsyncMock

from pipelines.personaplex import (
    PersonaPlexPipeline,
    PersonaPlexConfig,
    SessionData,
    AudioChunk,
    TextChunk,
)


class TestPersonaPlexPipelineInit:
    """Test pipeline initialization."""

    def test_pipeline_init_with_defaults(self):
        """Can we create a pipeline with defaults?"""
        pipeline = PersonaPlexPipeline()

        assert pipeline.session_id is not None
        assert pipeline.session_data is not None
        assert pipeline.system_prompt is not None

    def test_pipeline_init_with_custom_config(self):
        """Can we create pipeline with custom config?"""
        config = PersonaPlexConfig(voice_prompt="NATM0.pt")
        pipeline = PersonaPlexPipeline(config=config)

        assert pipeline.config.voice_prompt == "NATM0.pt"

    def test_pipeline_init_creates_session_data(self):
        """Does init create a SessionData object?"""
        pipeline = PersonaPlexPipeline(system_prompt="Custom prompt")

        assert isinstance(pipeline.session_data, SessionData)
        assert pipeline.session_data.system_prompt == "Custom prompt"

    def test_pipeline_is_not_running_initially(self):
        """Is pipeline not running after init?"""
        pipeline = PersonaPlexPipeline()

        assert not pipeline._is_running


@pytest.mark.asyncio
class TestPersonaPlexPipelineLifecycle:
    """Test pipeline start/stop lifecycle."""

    async def test_pipeline_start_connects_client(self):
        """Does start() connect the client?"""
        pipeline = PersonaPlexPipeline()
        pipeline.client = AsyncMock()

        await pipeline.start()

        assert pipeline._is_running
        pipeline.client.connect.assert_called_once()

    async def test_pipeline_start_creates_receive_task(self):
        """Does start() create a receive task?"""
        pipeline = PersonaPlexPipeline()
        pipeline.client = AsyncMock()
        pipeline.client.stream_messages = AsyncMock(
            return_value=AsyncMock(
                __aiter__=AsyncMock(
                    return_value=AsyncMock(
                        __anext__=AsyncMock(side_effect=StopAsyncIteration)
                    )
                )
            )
        )

        await pipeline.start()

        assert pipeline._receive_task is not None

    async def test_pipeline_stop_disconnects_client(self):
        """Does stop() disconnect the client?"""
        pipeline = PersonaPlexPipeline()
        pipeline.client = AsyncMock()
        pipeline._is_running = True

        result = await pipeline.stop()

        pipeline.client.disconnect.assert_called_once()
        assert not pipeline._is_running

    async def test_pipeline_context_manager(self):
        """Does context manager handle lifecycle?"""
        pipeline = PersonaPlexPipeline()
        pipeline.client = AsyncMock()
        pipeline.client.stream_messages = AsyncMock(
            return_value=AsyncMock(
                __aiter__=AsyncMock(
                    return_value=AsyncMock(
                        __anext__=AsyncMock(side_effect=StopAsyncIteration)
                    )
                )
            )
        )

        async with pipeline:
            assert pipeline._is_running

        pipeline.client.disconnect.assert_called_once()


@pytest.mark.asyncio
class TestPersonaPlexPipelineSendAudio:
    """Test sending audio."""

    async def test_pipeline_send_audio_when_running(self):
        """Can we send audio when pipeline is running?"""
        pipeline = PersonaPlexPipeline()
        pipeline.client = AsyncMock()
        pipeline._is_running = True

        audio = b"opus_audio_data"
        await pipeline.send_audio(audio)

        pipeline.client.send_audio.assert_called_once_with(audio)

    async def test_pipeline_send_audio_fails_when_stopped(self):
        """Does send_audio fail when not running?"""
        pipeline = PersonaPlexPipeline()
        pipeline._is_running = False

        with pytest.raises(RuntimeError):
            await pipeline.send_audio(b"audio")


@pytest.mark.asyncio
class TestPersonaPlexPipelineStreaming:
    """Test streaming interface."""

    async def test_pipeline_stream_requires_running(self):
        """Does stream() require pipeline to be running?"""
        pipeline = PersonaPlexPipeline()
        pipeline._is_running = False

        with pytest.raises(RuntimeError):
            async for _ in pipeline.stream():
                pass

    async def test_pipeline_stream_yields_tuples(self):
        """Does stream() yield (audio, text) tuples?"""
        import asyncio

        pipeline = PersonaPlexPipeline()
        pipeline._is_running = True

        # Pre-populate queues
        audio_chunk = AudioChunk(data=b"audio", sample_rate=48000)
        text_chunk = TextChunk(text="Hello")

        await pipeline._audio_queue.put(audio_chunk)
        await pipeline._text_queue.put(text_chunk)

        # Stop after one iteration
        async def stop_soon():
            await asyncio.sleep(0.01)
            pipeline._is_running = False

        asyncio.create_task(stop_soon())

        results = []
        async for audio, text in pipeline.stream():
            results.append((audio, text))
            if len(results) >= 1:
                break

        # Should get at least one result
        assert len(results) >= 1


@pytest.mark.asyncio
class TestPersonaPlexPipelineTranscript:
    """Test transcript management."""

    def test_pipeline_session_data_stores_messages(self):
        """Does session_data store conversation messages?"""
        pipeline = PersonaPlexPipeline()

        pipeline.session_data.add_message("user", "Hello")
        pipeline.session_data.add_message("assistant", "Hi there!")

        assert len(pipeline.session_data.messages) == 2
        assert pipeline.session_data.messages[0].role == "user"
        assert pipeline.session_data.messages[1].role == "assistant"

    async def test_pipeline_stop_can_save_transcript(self):
        """Can pipeline save transcript when configured?"""
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmpdir:
            config = PersonaPlexConfig(transcript_path=tmpdir, save_transcripts=True)
            pipeline = PersonaPlexPipeline(config=config)
            pipeline.client = AsyncMock()
            pipeline._is_running = True  # Pretend running so stop works

            # Add a message to transcript
            pipeline.session_data.add_message("user", "Test message")

            # Stop (should save because save_transcripts=True)
            result = await pipeline.stop()

            # Check transcript was saved if result is not None
            if result is not None:
                transcript_files = list(Path(tmpdir).glob("*.json"))
                assert len(transcript_files) > 0

    def test_pipeline_session_data_to_dict(self):
        """Can we convert session data to dict?"""
        pipeline = PersonaPlexPipeline(system_prompt="Test")
        pipeline.session_data.add_message("user", "Hello")

        data = pipeline.session_data.to_dict()

        assert "session_id" in data
        assert "timestamp" in data
        assert "system_prompt" in data
        assert "messages" in data
        assert len(data["messages"]) == 1
