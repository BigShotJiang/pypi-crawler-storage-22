"""Tests for session management utilities (Step 4)."""

from datetime import datetime, UTC
import uuid

from pipelines.personaplex import (
    generate_session_id,
    get_timestamp_iso,
    list_transcripts,
    format_transcript_for_display,
)


class TestSessionUtilities:
    """Test session ID and timestamp generation."""

    def test_generate_session_id_returns_string(self):
        """Does generate_session_id return a string?"""
        session_id = generate_session_id()

        assert isinstance(session_id, str)
        assert len(session_id) > 0

    def test_generate_session_id_is_uuid4(self):
        """Does it generate valid UUID4 format?"""
        session_id = generate_session_id()

        # Should be valid UUID
        uuid.UUID(session_id)

    def test_generate_session_id_unique(self):
        """Do consecutive calls generate different IDs?"""
        id1 = generate_session_id()
        id2 = generate_session_id()

        assert id1 != id2

    def test_get_timestamp_iso_returns_string(self):
        """Does get_timestamp_iso return a string?"""
        timestamp = get_timestamp_iso()

        assert isinstance(timestamp, str)
        assert len(timestamp) > 0

    def test_get_timestamp_iso_ends_with_z(self):
        """Does timestamp end with Z suffix?"""
        timestamp = get_timestamp_iso()

        assert timestamp.endswith("Z")

    def test_get_timestamp_iso_is_valid_iso8601(self):
        """Is the timestamp in ISO 8601 format?"""
        timestamp = get_timestamp_iso()

        # Remove Z suffix and parse
        iso_part = timestamp[:-1]
        parsed = datetime.fromisoformat(iso_part)

        assert isinstance(parsed, datetime)

    def test_get_timestamp_iso_close_to_now(self):
        """Is generated timestamp close to current time?"""
        before = datetime.now(UTC)
        timestamp = get_timestamp_iso()
        after = datetime.now(UTC)

        # Parse timestamp (remove Z and convert to UTC-aware)
        iso_part = timestamp[:-1]
        parsed = datetime.fromisoformat(iso_part).replace(tzinfo=UTC)

        # Should be within 1 second of now
        assert before <= parsed <= after


class TestTranscriptUtilities:
    """Test transcript management utilities."""

    def test_format_transcript_for_display_empty(self):
        """Can we format an empty transcript?"""
        from pipelines.personaplex import SessionData

        session = SessionData(
            session_id="test-format",
            timestamp="2025-01-01T00:00:00Z",
            system_prompt="You are helpful",
            voice_prompt="NATF0.pt",
            messages=[],
        )

        formatted = format_transcript_for_display(session)

        assert isinstance(formatted, str)

    def test_format_transcript_for_display_with_messages(self):
        """Does formatting show user/assistant messages?"""
        from pipelines.personaplex import SessionData, TranscriptMessage

        msg1 = TranscriptMessage(
            role="user",
            text="Hello",
            timestamp="2025-01-01T00:00:01Z",
        )
        msg2 = TranscriptMessage(
            role="assistant",
            text="Hi there!",
            timestamp="2025-01-01T00:00:02Z",
        )
        session = SessionData(
            session_id="test-format-msg",
            timestamp="2025-01-01T00:00:00Z",
            system_prompt="You are helpful",
            voice_prompt="NATF0.pt",
            messages=[msg1, msg2],
        )

        formatted = format_transcript_for_display(session)

        # Should contain message text
        assert "Hello" in formatted
        assert "Hi there!" in formatted

    def test_format_transcript_for_display_labels_speakers(self):
        """Does formatting include speaker labels?"""
        from pipelines.personaplex import SessionData, TranscriptMessage

        msg = TranscriptMessage(
            role="user",
            text="Test message",
            timestamp="2025-01-01T00:00:01Z",
        )
        session = SessionData(
            session_id="test-labels",
            timestamp="2025-01-01T00:00:00Z",
            system_prompt="You are helpful",
            voice_prompt="NATF0.pt",
            messages=[msg],
        )

        formatted = format_transcript_for_display(session)

        # Should show role/speaker
        assert "user" in formatted.lower() or "User" in formatted

    def test_list_transcripts_returns_list(self):
        """Does list_transcripts return a list?"""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            transcripts = list_transcripts(tmpdir)

            assert isinstance(transcripts, list)

    def test_list_transcripts_empty_dir(self):
        """Does it return empty list for empty directory?"""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            transcripts = list_transcripts(tmpdir)

            assert len(transcripts) == 0

    def test_list_transcripts_finds_json_files(self):
        """Does it find transcript JSON files?"""
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmpdir:
            from pipelines.personaplex import save_transcript, SessionData

            # Create a transcript
            session = SessionData(
                session_id="list-test",
                timestamp="2025-01-01T00:00:00Z",
                system_prompt="You are helpful",
                voice_prompt="NATF0.pt",
                messages=[],
            )
            save_transcript(session, tmpdir)

            # List should find it
            transcripts = list_transcripts(tmpdir)

            assert len(transcripts) >= 1
            assert any("list-test" in str(t) for t in transcripts)
