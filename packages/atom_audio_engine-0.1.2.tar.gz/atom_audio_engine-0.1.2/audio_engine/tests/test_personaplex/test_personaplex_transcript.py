"""Tests for transcript persistence (Step 3)."""

import json
import tempfile
from pathlib import Path

from pipelines.personaplex import (
    SessionData,
    TranscriptMessage,
    save_transcript,
    load_transcript,
)


class TestTranscriptPersistence:
    """Test transcript saving and loading."""

    def test_save_transcript_creates_file(self):
        """Does save_transcript create a JSON file?"""
        with tempfile.TemporaryDirectory() as tmpdir:
            session = SessionData(
                session_id="test-123",
                timestamp="2025-01-01T00:00:00Z",
                system_prompt="You are helpful",
                voice_prompt="NATF0.pt",
                messages=[],
            )

            saved_path = save_transcript(session, Path(tmpdir))

            assert saved_path.exists()
            assert saved_path.suffix == ".json"

    def test_save_transcript_contains_correct_structure(self):
        """Does saved JSON have session_id, timestamp, and messages?"""
        with tempfile.TemporaryDirectory() as tmpdir:
            msg = TranscriptMessage(
                role="user",
                text="Hello",
                timestamp="2025-01-01T00:00:01Z",
            )
            session = SessionData(
                session_id="test-456",
                timestamp="2025-01-01T00:00:00Z",
                system_prompt="You are helpful",
                voice_prompt="NATF0.pt",
                messages=[msg],
            )

            saved_path = save_transcript(session, Path(tmpdir))

            with open(saved_path, "r") as f:
                data = json.load(f)

            assert data["session_id"] == "test-456"
            assert data["timestamp"] == "2025-01-01T00:00:00Z"
            assert len(data["messages"]) == 1
            assert data["messages"][0]["role"] == "user"
            assert data["messages"][0]["text"] == "Hello"

    def test_load_transcript_reads_file(self):
        """Can we load a transcript from JSON?"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create and save a session
            msg = TranscriptMessage(
                role="assistant",
                text="Hi there!",
                timestamp="2025-01-01T00:00:02Z",
            )
            original = SessionData(
                session_id="test-789",
                timestamp="2025-01-01T00:00:00Z",
                system_prompt="You are helpful",
                voice_prompt="NATF0.pt",
                messages=[msg],
            )

            saved_path = save_transcript(original, Path(tmpdir))

            # Load it back
            loaded = load_transcript(saved_path)

            assert loaded.session_id == "test-789"
            assert loaded.timestamp == "2025-01-01T00:00:00Z"
            assert len(loaded.messages) == 1
            assert loaded.messages[0].role == "assistant"
            assert loaded.messages[0].text == "Hi there!"

    def test_transcript_roundtrip(self):
        """Session → save → load → Session equals original?"""
        with tempfile.TemporaryDirectory() as tmpdir:
            msg1 = TranscriptMessage(
                role="user",
                text="First message",
                timestamp="2025-01-01T00:00:01Z",
            )
            msg2 = TranscriptMessage(
                role="assistant",
                text="Response",
                timestamp="2025-01-01T00:00:02Z",
            )
            original = SessionData(
                session_id="roundtrip-123",
                timestamp="2025-01-01T00:00:00Z",
                system_prompt="You are helpful",
                voice_prompt="NATF0.pt",
                messages=[msg1, msg2],
            )

            saved_path = save_transcript(original, Path(tmpdir))
            loaded = load_transcript(saved_path)

            # Compare all fields
            assert loaded.session_id == original.session_id
            assert loaded.timestamp == original.timestamp
            assert loaded.system_prompt == original.system_prompt
            assert loaded.voice_prompt == original.voice_prompt
            assert len(loaded.messages) == len(original.messages)
            for i, msg in enumerate(original.messages):
                assert loaded.messages[i].role == msg.role
                assert loaded.messages[i].text == msg.text
                assert loaded.messages[i].timestamp == msg.timestamp

    def test_transcript_add_message(self):
        """Can we add messages to a SessionData?"""
        session = SessionData(
            session_id="add-test",
            timestamp="2025-01-01T00:00:00Z",
            system_prompt="You are helpful",
            voice_prompt="NATF0.pt",
            messages=[],
        )

        assert len(session.messages) == 0

        session.add_message("user", "Test")

        assert len(session.messages) == 1
        assert session.messages[0].text == "Test"

    def test_transcript_to_dict(self):
        """Can we convert SessionData to dict?"""
        msg = TranscriptMessage(
            role="user",
            text="Convert me",
            timestamp="2025-01-01T00:00:01Z",
        )
        session = SessionData(
            session_id="dict-test",
            timestamp="2025-01-01T00:00:00Z",
            system_prompt="You are helpful",
            voice_prompt="NATF0.pt",
            messages=[msg],
        )

        data = session.to_dict()

        assert isinstance(data, dict)
        assert data["session_id"] == "dict-test"
        assert data["timestamp"] == "2025-01-01T00:00:00Z"
        assert len(data["messages"]) == 1

    def test_transcript_from_dict(self):
        """Can we create SessionData from dict?"""
        data = {
            "session_id": "from-dict-test",
            "timestamp": "2025-01-01T00:00:00Z",
            "system_prompt": "You are helpful",
            "voice_prompt": "NATF0.pt",
            "messages": [
                {
                    "role": "user",
                    "text": "Recreate me",
                    "timestamp": "2025-01-01T00:00:01Z",
                }
            ],
        }

        session = SessionData.from_dict(data)

        assert session.session_id == "from-dict-test"
        assert session.system_prompt == "You are helpful"
        assert len(session.messages) == 1
        assert session.messages[0].text == "Recreate me"
