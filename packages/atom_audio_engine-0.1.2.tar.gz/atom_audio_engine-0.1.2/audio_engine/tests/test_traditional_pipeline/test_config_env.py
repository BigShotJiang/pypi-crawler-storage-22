"""Tests for AudioEngineConfig environment variable loading."""

import os
import pytest
from core.config import AudioEngineConfig


class TestConfigEnvironment:
    """Test AudioEngineConfig environment variable loading."""

    def test_from_env_uses_defaults(self):
        """Does from_env() use defaults when no env vars set?"""
        # Ensure env is clean
        for key in [
            "ASR_PROVIDER",
            "ASR_API_KEY",
            "LLM_PROVIDER",
            "LLM_API_KEY",
            "TTS_PROVIDER",
            "TTS_API_KEY",
            "DEEPGRAM_API_KEY",
            "GROQ_API_KEY",
            "CARTESIA_API_KEY",
        ]:
            os.environ.pop(key, None)

        config = AudioEngineConfig.from_env()

        assert config.asr.provider == "cartesia"
        assert config.llm.provider == "groq"
        assert config.tts.provider == "cartesia"

    def test_from_env_reads_asr_provider(self):
        """Does from_env() read ASR_PROVIDER env var?"""
        os.environ["ASR_PROVIDER"] = "openai"

        config = AudioEngineConfig.from_env()

        assert config.asr.provider == "openai"
        os.environ.pop("ASR_PROVIDER", None)

    def test_from_env_reads_llm_provider(self):
        """Does from_env() read LLM_PROVIDER env var?"""
        os.environ["LLM_PROVIDER"] = "anthropic"

        config = AudioEngineConfig.from_env()

        assert config.llm.provider == "anthropic"
        os.environ.pop("LLM_PROVIDER", None)

    def test_from_env_reads_tts_provider(self):
        """Does from_env() read TTS_PROVIDER env var?"""
        os.environ["TTS_PROVIDER"] = "elevenlabs"

        config = AudioEngineConfig.from_env()

        assert config.tts.provider == "elevenlabs"
        os.environ.pop("TTS_PROVIDER", None)

    def test_from_env_reads_api_keys(self):
        """Does from_env() read API key env vars?"""
        os.environ["ASR_API_KEY"] = "test-asr-key"
        os.environ["LLM_API_KEY"] = "test-llm-key"
        os.environ["TTS_API_KEY"] = "test-tts-key"

        config = AudioEngineConfig.from_env()

        assert config.asr.api_key == "test-asr-key"
        assert config.llm.api_key == "test-llm-key"
        assert config.tts.api_key == "test-tts-key"

        os.environ.pop("ASR_API_KEY", None)
        os.environ.pop("LLM_API_KEY", None)
        os.environ.pop("TTS_API_KEY", None)

    def test_from_env_fallback_to_provider_specific_keys(self):
        """Does from_env() fallback to provider-specific keys (DEEPGRAM_API_KEY)?"""
        os.environ["DEEPGRAM_API_KEY"] = "fallback-deepgram-key"
        os.environ.pop("ASR_API_KEY", None)

        config = AudioEngineConfig.from_env()

        assert config.asr.api_key == "fallback-deepgram-key"

        os.environ.pop("DEEPGRAM_API_KEY", None)

    def test_from_env_api_key_priority(self):
        """Does ASR_API_KEY take priority over DEEPGRAM_API_KEY?"""
        os.environ["ASR_API_KEY"] = "primary-key"
        os.environ["DEEPGRAM_API_KEY"] = "fallback-key"

        config = AudioEngineConfig.from_env()

        assert config.asr.api_key == "primary-key"

        os.environ.pop("ASR_API_KEY", None)
        os.environ.pop("DEEPGRAM_API_KEY", None)
