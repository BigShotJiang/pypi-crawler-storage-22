"""Tests for ConversationContext."""

import pytest
from core.types import ConversationContext, ConversationMessage


class TestConversationContext:
    """Test ConversationContext message management."""

    def test_add_user_message(self):
        """Can we add a user message to context?"""
        context = ConversationContext()

        context.add_message("user", "Hello")

        assert len(context.messages) == 1
        assert context.messages[0].role == "user"
        assert context.messages[0].content == "Hello"

    def test_add_assistant_message(self):
        """Can we add an assistant message to context?"""
        context = ConversationContext()

        context.add_message("assistant", "Hi there")

        assert len(context.messages) == 1
        assert context.messages[0].role == "assistant"
        assert context.messages[0].content == "Hi there"

    def test_message_history_order(self):
        """Are messages stored in correct order?"""
        context = ConversationContext()

        context.add_message("user", "Message 1")
        context.add_message("assistant", "Message 2")
        context.add_message("user", "Message 3")

        assert len(context.messages) == 3
        assert context.messages[0].content == "Message 1"
        assert context.messages[1].content == "Message 2"
        assert context.messages[2].content == "Message 3"

    def test_system_prompt_set_on_context(self):
        """Can we set system_prompt on context?"""
        prompt = "You are a helpful assistant"
        context = ConversationContext(system_prompt=prompt)

        assert context.system_prompt == prompt

    def test_get_messages_for_llm_with_system_prompt(self):
        """Does get_messages_for_llm() include system prompt?"""
        context = ConversationContext(system_prompt="You are helpful")
        context.add_message("user", "Hello")
        context.add_message("assistant", "Hi")

        messages = context.get_messages_for_llm()

        assert len(messages) == 3
        assert messages[0]["role"] == "system"
        assert messages[0]["content"] == "You are helpful"

    def test_get_messages_for_llm_without_system_prompt(self):
        """Does get_messages_for_llm() work without system prompt?"""
        context = ConversationContext()
        context.add_message("user", "Hello")
        context.add_message("assistant", "Hi")

        messages = context.get_messages_for_llm()

        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert messages[1]["role"] == "assistant"

    def test_get_messages_for_llm_format(self):
        """Does get_messages_for_llm() return correct format?"""
        context = ConversationContext()
        context.add_message("user", "Test message")

        messages = context.get_messages_for_llm()

        assert isinstance(messages, list)
        assert isinstance(messages[0], dict)
        assert "role" in messages[0]
        assert "content" in messages[0]

    def test_max_history_trim(self):
        """Does context trim history when max_history exceeded?"""
        context = ConversationContext(max_history=3)

        context.add_message("user", "Message 1")
        context.add_message("user", "Message 2")
        context.add_message("user", "Message 3")
        context.add_message("user", "Message 4")

        assert len(context.messages) == 3
        assert context.messages[0].content == "Message 2"
        assert context.messages[2].content == "Message 4"

    def test_clear_messages(self):
        """Can we clear the message history?"""
        context = ConversationContext()
        context.add_message("user", "Hello")
        context.add_message("assistant", "Hi")

        context.messages = []

        assert len(context.messages) == 0

    def test_message_with_timestamp(self):
        """Can we add messages with timestamps?"""
        context = ConversationContext()

        context.add_message("user", "Hello", timestamp_ms=1000)

        assert context.messages[0].timestamp_ms == 1000
