"""Tests for Pipeline creation from config."""

import pytest
from core.config import AudioEngineConfig
from core.pipeline import Pipeline


class TestPipelineCreation:
    """Test Pipeline creation from AudioEngineConfig."""

    def test_create_pipeline_from_config(self):
        """Does config.create_pipeline() create a Pipeline instance?"""
        config = AudioEngineConfig.from_env()

        pipeline = config.create_pipeline(system_prompt="Test prompt")

        assert isinstance(pipeline, Pipeline)

    def test_pipeline_has_all_providers(self):
        """Does Pipeline have ASR, LLM, and TTS providers initialized?"""
        config = AudioEngineConfig.from_env()

        pipeline = config.create_pipeline()

        assert pipeline.asr is not None
        assert pipeline.llm is not None
        assert pipeline.tts is not None

    def test_pipeline_has_correct_provider_types(self):
        """Does Pipeline have correct provider types?"""
        config = AudioEngineConfig.from_env()

        pipeline = config.create_pipeline()

        assert pipeline.asr.__class__.__name__ == "CartesiaASR"
        assert pipeline.llm.__class__.__name__ == "GroqLLM"
        assert pipeline.tts.__class__.__name__ == "CartesiaTTS"

    def test_pipeline_system_prompt_set(self):
        """Does pipeline.context have system_prompt set?"""
        prompt = "You are a helpful assistant"
        config = AudioEngineConfig.from_env()

        pipeline = config.create_pipeline(system_prompt=prompt)

        assert pipeline.context.system_prompt == prompt

    def test_pipeline_default_system_prompt_from_config(self):
        """Does pipeline use config system_prompt as default?"""
        config = AudioEngineConfig.from_env()
        config.llm.system_prompt = "Config default prompt"

        pipeline = config.create_pipeline()

        assert pipeline.context.system_prompt == "Config default prompt"

    def test_pipeline_system_prompt_override(self):
        """Does explicit system_prompt override config default?"""
        config = AudioEngineConfig.from_env()
        config.llm.system_prompt = "Config default"

        pipeline = config.create_pipeline(system_prompt="Override prompt")

        assert pipeline.context.system_prompt == "Override prompt"
