"""Tests for Pipeline with mocked providers."""

import pytest
from unittest.mock import AsyncMock, MagicMock
from core.pipeline import Pipeline
from core.types import AudioChunk, TranscriptChunk, ResponseChunk, AudioFormat
from asr.base import BaseASR
from llm.base import BaseLLM
from tts.base import BaseTTS


class MockASR(BaseASR):
    """Mock ASR provider for testing."""

    @property
    def name(self):
        return "mock_asr"

    async def transcribe(self, audio: bytes, sample_rate: int = 16000) -> str:
        return "Hello"

    async def transcribe_stream(self, audio_stream):
        yield TranscriptChunk(text="Hello", confidence=0.95, is_final=True)


class MockLLM(BaseLLM):
    """Mock LLM provider for testing."""

    @property
    def name(self):
        return "mock_llm"

    async def generate(self, prompt: str, context=None) -> str:
        return "Hi there"

    async def generate_stream(self, prompt: str, context=None):
        yield ResponseChunk(text="Hi there", is_final=True)


class MockTTS(BaseTTS):
    """Mock TTS provider for testing."""

    @property
    def name(self):
        return "mock_tts"

    async def synthesize(self, text: str) -> bytes:
        return b"audio_bytes"

    async def synthesize_stream(self, text: str):
        yield AudioChunk(
            data=b"audio_bytes",
            sample_rate=24000,
            channels=1,
            format=AudioFormat.PCM_24K,
            timestamp_ms=0,
            is_final=True,
        )

    async def synthesize_stream_text(self, text_stream):
        async for text in text_stream:
            yield AudioChunk(
                data=b"audio_chunk",
                sample_rate=24000,
                channels=1,
                format=AudioFormat.PCM_24K,
                timestamp_ms=0,
                is_final=True,
            )


@pytest.mark.asyncio
class TestPipelineWithMocks:
    """Test Pipeline with mocked providers."""

    async def test_pipeline_process_calls_providers_in_order(self):
        """Does pipeline.process() call ASR → LLM → TTS in order?"""
        asr = MockASR(api_key="test")
        llm = MockLLM(api_key="test")
        tts = MockTTS(api_key="test")

        pipeline = Pipeline(asr=asr, llm=llm, tts=tts)

        # Mock the methods to track calls
        asr.transcribe = AsyncMock(return_value="Hello")
        llm.generate = AsyncMock(return_value="Hi there")
        tts.synthesize = AsyncMock(return_value=b"audio_bytes")

        result = await pipeline.process(b"audio_data")

        assert result == b"audio_bytes"
        assert asr.transcribe.called
        assert llm.generate.called
        assert tts.synthesize.called

    async def test_pipeline_process_adds_user_message_to_context(self):
        """Does pipeline.process() add user message to context?"""
        asr = MockASR(api_key="test")
        llm = MockLLM(api_key="test")
        tts = MockTTS(api_key="test")

        asr.transcribe = AsyncMock(return_value="User said this")
        llm.generate = AsyncMock(return_value="Response")
        tts.synthesize = AsyncMock(return_value=b"audio")

        pipeline = Pipeline(asr=asr, llm=llm, tts=tts)
        await pipeline.process(b"audio_data")

        messages = pipeline.context.messages
        assert len(messages) >= 1
        assert messages[0].role == "user"
        assert messages[0].content == "User said this"

    async def test_pipeline_process_adds_assistant_message_to_context(self):
        """Does pipeline.process() add assistant message to context?"""
        asr = MockASR(api_key="test")
        llm = MockLLM(api_key="test")
        tts = MockTTS(api_key="test")

        asr.transcribe = AsyncMock(return_value="Hello")
        llm.generate = AsyncMock(return_value="Assistant response")
        tts.synthesize = AsyncMock(return_value=b"audio")

        pipeline = Pipeline(asr=asr, llm=llm, tts=tts)
        await pipeline.process(b"audio_data")

        messages = pipeline.context.messages
        assert len(messages) >= 2
        assert messages[1].role == "assistant"
        assert messages[1].content == "Assistant response"

    async def test_pipeline_stream_works_with_mocks(self):
        """Does pipeline.stream() work with mocked providers?"""
        asr = MockASR(api_key="test")
        llm = MockLLM(api_key="test")
        tts = MockTTS(api_key="test")

        pipeline = Pipeline(asr=asr, llm=llm, tts=tts)

        # Create a simple async generator for audio input
        async def mock_audio_stream():
            yield AudioChunk(
                data=b"audio",
                sample_rate=16000,
                channels=1,
                format=AudioFormat.PCM_16K,
                timestamp_ms=0,
                is_final=True,
            )

        chunks = []
        async for chunk in pipeline.stream(mock_audio_stream()):
            chunks.append(chunk)

        assert len(chunks) > 0

    async def test_pipeline_reset_context_clears_messages(self):
        """Does pipeline.reset_context() clear conversation history?"""
        asr = MockASR(api_key="test")
        llm = MockLLM(api_key="test")
        tts = MockTTS(api_key="test")

        asr.transcribe = AsyncMock(return_value="Hello")
        llm.generate = AsyncMock(return_value="Hi")
        tts.synthesize = AsyncMock(return_value=b"audio")

        pipeline = Pipeline(asr=asr, llm=llm, tts=tts)

        await pipeline.process(b"audio_data")
        assert len(pipeline.context.messages) > 0

        pipeline.reset_context()
        assert len(pipeline.context.messages) == 0
