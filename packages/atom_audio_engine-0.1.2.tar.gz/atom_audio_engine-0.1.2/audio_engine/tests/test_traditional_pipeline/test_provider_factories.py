"""Tests for provider factory functions."""

import pytest
from core.config import ASRConfig, LLMConfig, TTSConfig
from asr import get_asr_from_config
from llm import get_llm_from_config
from tts import get_tts_from_config


class TestProviderFactories:
    """Test provider factory functions."""

    def test_get_asr_from_config_deepgram(self):
        """Does get_asr_from_config() create DeepgramASR for deepgram provider?"""
        config = ASRConfig(provider="deepgram", api_key="test-key")

        asr = get_asr_from_config(config)

        assert asr.__class__.__name__ == "DeepgramASR"
        assert asr.api_key == "test-key"

    def test_get_llm_from_config_groq(self):
        """Does get_llm_from_config() create GroqLLM for groq provider?"""
        config = LLMConfig(
            provider="groq", api_key="test-key", model="llama-3.1-8b-instant"
        )

        llm = get_llm_from_config(config)

        assert llm.__class__.__name__ == "GroqLLM"
        assert llm.api_key == "test-key"

    def test_get_tts_from_config_cartesia(self):
        """Does get_tts_from_config() create CartesiaTTS for cartesia provider?"""
        config = TTSConfig(provider="cartesia", api_key="test-key", voice_id="sonic")

        tts = get_tts_from_config(config)

        assert tts.__class__.__name__ == "CartesiaTTS"
        assert tts.api_key == "test-key"

    def test_get_asr_from_config_unknown_provider(self):
        """Does get_asr_from_config() raise error for unknown provider?"""
        config = ASRConfig(provider="unknown_provider", api_key="test-key")

        with pytest.raises(ValueError):
            get_asr_from_config(config)

    def test_get_llm_from_config_unknown_provider(self):
        """Does get_llm_from_config() raise error for unknown provider?"""
        config = LLMConfig(provider="unknown_provider", api_key="test-key")

        with pytest.raises(ValueError):
            get_llm_from_config(config)

    def test_get_tts_from_config_unknown_provider(self):
        """Does get_tts_from_config() raise error for unknown provider?"""
        config = TTSConfig(provider="unknown_provider", api_key="test-key")

        with pytest.raises(ValueError):
            get_tts_from_config(config)
