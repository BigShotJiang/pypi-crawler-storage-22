"""Tests for WebSocket server initialization."""

import pytest
from core.config import AudioEngineConfig
from streaming.websocket_server import WebSocketServer


class TestWebSocketServerCreation:
    """Test WebSocket server creation from config."""

    def test_websocket_server_init(self):
        """Can we create a WebSocketServer instance?"""
        config = AudioEngineConfig.from_env()
        pipeline = config.create_pipeline()

        server = WebSocketServer(pipeline, host="localhost", port=8765)

        assert server is not None
        assert server.host == "localhost"
        assert server.port == 8765

    def test_websocket_server_has_pipeline(self):
        """Does WebSocketServer store the pipeline?"""
        config = AudioEngineConfig.from_env()
        pipeline = config.create_pipeline()

        server = WebSocketServer(pipeline)

        assert server.pipeline == pipeline

    def test_websocket_server_default_host_port(self):
        """Does WebSocketServer use default host/port?"""
        config = AudioEngineConfig.from_env()
        pipeline = config.create_pipeline()

        server = WebSocketServer(pipeline)

        assert server.host == "0.0.0.0"
        assert server.port == 8765

    def test_websocket_server_custom_host_port(self):
        """Can we set custom host/port on WebSocketServer?"""
        config = AudioEngineConfig.from_env()
        pipeline = config.create_pipeline()

        server = WebSocketServer(pipeline, host="127.0.0.1", port=9000)

        assert server.host == "127.0.0.1"
        assert server.port == 9000

    def test_run_server_config_host_port(self):
        """Does run_server_from_config() use config host/port?"""
        config = AudioEngineConfig.from_env()
        config.streaming.host = "192.168.1.1"
        config.streaming.port = 9999

        assert config.streaming.host == "192.168.1.1"
        assert config.streaming.port == 9999
