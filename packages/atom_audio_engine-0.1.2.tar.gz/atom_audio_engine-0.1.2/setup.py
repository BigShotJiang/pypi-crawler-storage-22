#!/usr/bin/env python
"""Setup script for audio-engine package."""

from setuptools import setup, find_packages

setup()
