"""
Domain interfaces (Ports) for the Dual-State Framework.

These abstract base classes define the contracts that implementations must satisfy.
They have no external dependencies and represent the core domain boundaries.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from atomicguard.domain.models import (
        Artifact,
        Context,
        GuardResult,
        HumanAmendment,
        WorkflowCheckpoint,
    )
    from atomicguard.domain.prompts import PromptTemplate


class GeneratorInterface(ABC):
    """
    Port for artifact generation.

    Implementations connect to LLMs or other generation sources.

    Note (Hierarchical Composition & Semantic Agency):
        The generator is not constrained to a single inference step. It may be
        instantiated as an autonomous Semantic Agent (ReAct loop, CoT reasoning,
        multi-tool orchestration) operating within the stochastic environment.
        From the workflow's perspective, this agentic process is atomic — the
        Workflow State tracks only the final artifact's validity via the Guard.

    Note (Side Effects & Idempotency):
        While generate() formally produces an artifact, implementations
        may induce side effects (filesystem I/O, API calls). In such cases:
        1. The artifact serves as a receipt/manifest of the operation
        2. Guards act as sensors verifying environmental state
        3. Side-effecting generators MUST be idempotent for retry safety
    """

    @abstractmethod
    def generate(
        self,
        context: "Context",
        template: "PromptTemplate",
        action_pair_id: str = "unknown",
        workflow_id: str = "unknown",
        workflow_ref: str | None = None,
    ) -> "Artifact":
        """
        Generate an artifact based on context.

        Args:
            context: The generation context including specification and feedback
            template: Prompt template for structured generation
            action_pair_id: Identifier for the action pair requesting generation
            workflow_id: UUID of the workflow execution instance
            workflow_ref: Content-addressed workflow hash (Extension 01, Def 11)

        Returns:
            A new Artifact containing the generated content
        """
        pass


class GuardInterface(ABC):
    """
    Port for artifact validation.

    Guards are deterministic validators that return ⊤ (pass) or ⊥ (fail with feedback).
    """

    @abstractmethod
    def validate(
        self, artifact: "Artifact", **dependencies: "Artifact"
    ) -> "GuardResult":
        """
        Validate an artifact.

        Args:
            artifact: The artifact to validate
            **dependencies: Artifacts from prior workflow steps (key -> Artifact)

        Returns:
            GuardResult with passed=True/False and optional feedback
        """
        pass


class ArtifactDAGInterface(ABC):
    """
    Port for artifact persistence.

    Implementations provide append-only storage for the Versioned Repository (Definition 4).
    """

    @abstractmethod
    def store(self, artifact: "Artifact") -> str:
        """
        Store an artifact in the DAG.

        Args:
            artifact: The artifact to store

        Returns:
            The artifact_id
        """
        pass

    @abstractmethod
    def get_artifact(self, artifact_id: str) -> "Artifact":
        """
        Retrieve an artifact by ID.

        Args:
            artifact_id: The unique identifier

        Returns:
            The artifact

        Raises:
            KeyError: If artifact not found
        """
        pass

    @abstractmethod
    def get_provenance(self, artifact_id: str) -> list["Artifact"]:
        """
        Trace the retry chain via previous_attempt_id.

        Args:
            artifact_id: Starting artifact

        Returns:
            List of artifacts from oldest to newest in the chain
        """
        pass

    @abstractmethod
    def get_latest_for_action_pair(
        self, action_pair_id: str, workflow_id: str
    ) -> Optional["Artifact"]:
        """
        Get the most recent artifact for an action pair in a workflow.

        Args:
            action_pair_id: The action pair identifier (e.g., 'g_test')
            workflow_id: UUID of the workflow execution instance

        Returns:
            The most recent artifact, or None if not found
        """
        pass

    @abstractmethod
    def get_all(self) -> list["Artifact"]:
        """
        Return all artifacts in the DAG.

        Used by extraction queries that need to filter across all artifacts.
        Implementations should return artifacts in a consistent order (e.g., by created_at).

        Returns:
            List of all artifacts in the repository.
        """
        pass


class CheckpointDAGInterface(ABC):
    """
    Port for checkpoint persistence.

    Provides storage for workflow checkpoints and human amendments,
    enabling resumable workflows after failure/escalation.
    """

    @abstractmethod
    def store_checkpoint(self, checkpoint: "WorkflowCheckpoint") -> str:
        """
        Store a checkpoint and return its ID.

        Args:
            checkpoint: The checkpoint to store

        Returns:
            The checkpoint_id
        """
        pass

    @abstractmethod
    def get_checkpoint(self, checkpoint_id: str) -> "WorkflowCheckpoint":
        """
        Retrieve checkpoint by ID.

        Args:
            checkpoint_id: The unique identifier

        Returns:
            The checkpoint

        Raises:
            KeyError: If checkpoint not found
        """
        pass

    @abstractmethod
    def store_amendment(self, amendment: "HumanAmendment") -> str:
        """
        Store a human amendment and return its ID.

        Args:
            amendment: The amendment to store

        Returns:
            The amendment_id
        """
        pass

    @abstractmethod
    def get_amendment(self, amendment_id: str) -> "HumanAmendment":
        """
        Retrieve amendment by ID.

        Args:
            amendment_id: The unique identifier

        Returns:
            The amendment

        Raises:
            KeyError: If amendment not found
        """
        pass

    @abstractmethod
    def get_amendments_for_checkpoint(
        self, checkpoint_id: str
    ) -> list["HumanAmendment"]:
        """
        Get all amendments for a checkpoint.

        Args:
            checkpoint_id: The checkpoint identifier

        Returns:
            List of amendments linked to this checkpoint
        """
        pass

    @abstractmethod
    def list_checkpoints(
        self, workflow_id: str | None = None
    ) -> list["WorkflowCheckpoint"]:
        """
        List checkpoints, optionally filtered by workflow_id.

        Args:
            workflow_id: Optional filter by workflow

        Returns:
            List of matching checkpoints, newest first
        """
        pass
