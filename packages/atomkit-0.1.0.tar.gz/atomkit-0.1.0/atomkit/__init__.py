"""
Atomkit - Atom-level analysis toolkit for molecular dynamics trajectories.
"""

from atomkit.region import Region, RegionTuple, ensure_region, INF, NEG_INF
from atomkit.spatial_grid import SpatialGrid, preprocess_lammps

__version__ = "0.1.0"
__all__ = [
    "SpatialGrid",
    "Region",
    "RegionTuple",
    "ensure_region",
    "preprocess_lammps",
    "INF",
    "NEG_INF",
]
