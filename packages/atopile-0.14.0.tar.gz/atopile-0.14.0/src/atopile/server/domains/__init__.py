"""Domain-specific route registration helpers."""
