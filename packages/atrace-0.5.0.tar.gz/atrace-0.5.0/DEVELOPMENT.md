# TODO

- Thonny, which adds a lot of indirection and magic. Try and find a way to edit the package directly when running in thonny when debugging.

- functions
- globals

- all XXX

- problem when repeating a test
- unittest for reporter
- Assert stuff in abrupt termination
- Get rid of the test specific initialization
- tests for everything, including syntax error
- cleanup even when exception

- update docs if we remove exit handlers

# Linting

    uv run ruff check src tests

# Type Checking

    uv run mypy src tests

# Running unit tests

We use unittest instead of pytest, because pytest's heavy instrumentation of the code causes trouble.

    uv run python -m unittest tests/Test*

# Translating

    uv run pybabel extract -o locale/base.pot src

    uv run pybabel init -l fr_FR -i locale/base.pot -D atrace -d locale

    uv run pybabel update -i locale/base.pot -D atrace -d locale

    uv run pybabel compile -D atrace -d locale

# Deployment

Every time we push a new tag, the package is automatically deployed to pypi:
https://pypi.org/project/atrace/
