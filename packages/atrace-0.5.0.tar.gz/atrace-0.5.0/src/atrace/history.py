from dataclasses import dataclass
from itertools import pairwise
from typing import Any, Sequence, TypeAlias

from .tracer import (
    Event,
    ExecutionEvent,
    LineEvent,
    Loc,
    Locals,
    OutputEvent,
    Trace,
)

""""
Takes a raw trace and attaches Decorations to the trace items:
    - With subsequence outputs coalesced
    - With variable assignations attached to the correct line
"""


@dataclass(frozen=True)
class Var:
    scope: str
    name: str


Assignments: TypeAlias = dict[Var, Any]


IndexedTraceItem: TypeAlias = tuple[int, Loc, Event]


HistoryItem: TypeAlias = tuple[Loc, Assignments | None, str | None]


History: TypeAlias = Sequence[HistoryItem]


def build_outputs(indexed_trace: list[IndexedTraceItem]) -> dict[int, str]:
    result = {}
    pending_id, pending_loc = None, None
    for id, loc, event in indexed_trace:
        match event:
            case OutputEvent(text):
                if pending_id and pending_loc == loc:
                    result[pending_id] += text
                else:
                    result[id] = text
                    pending_id, pending_loc = id, loc
            case _:
                pending_id, pending_loc = None, None

    return result


def build_assignments(indexed_trace: list[IndexedTraceItem]) -> dict[int, Assignments]:
    """
    Associates assignments to the place they occured
    # XXX: Depends on an extra event at the end ?
    # XXX: What about calls and return semantics (their locals are not before the call) ?
    # XXX: What about globals ?
    """
    result = {}
    execution_items = [
        (id, loc, event)
        for id, loc, event in indexed_trace
        if isinstance(event, ExecutionEvent)
    ]
    for (item_id, item_loc, item_event), (_, _, next_event) in pairwise(
        execution_items
    ):
        match item_event:
            case LineEvent(locals):
                assignments = changes(item_loc.function_name, locals, next_event.locals)
                if assignments:
                    result[item_id] = assignments
    return result


def changes(scope: str, before: Locals, after: Locals) -> Assignments:
    assignments = {}
    for var, val in after.items():
        if var not in before or val != before[var]:
            assignments[Var(scope, var)] = val
    return assignments


def trace_to_history(trace: Trace) -> History:
    indexed_trace = [(i, loc, event) for i, (loc, event) in enumerate(trace)]
    outputs = build_outputs(indexed_trace)
    assignments = build_assignments(indexed_trace)

    result = []
    for id, loc, _ in indexed_trace:
        a = assignments.get(id)
        o = outputs.get(id)
        if a or o:
            result.append((loc, a, o))
    return result
