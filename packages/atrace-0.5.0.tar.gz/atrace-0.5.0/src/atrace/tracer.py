import copy
import sys
from dataclasses import dataclass
from types import FrameType, ModuleType, TracebackType
from typing import Any, Callable, TextIO, TypeAlias

"""
See:
    https://docs.python.org/3/library/sys.html#sys.settrace
    https://docs.python.org/3/library/inspect.html
"""


@dataclass(frozen=True)
class Loc:
    function_name: str
    line_no: int


Locals: TypeAlias = dict[str, Any]


@dataclass(frozen=True)
class ExecutionEvent:
    locals: Locals


@dataclass(frozen=True)
class LineEvent(ExecutionEvent):
    """
    The interpreter is about to execute a new line of code or re-execute the condition of a loop
    """


@dataclass(frozen=True)
class CallEvent(ExecutionEvent):
    """
    A function is called (or some other code block entered).
    This is emitted before entering the function (in most cases this is on the line of the function def)
    One can already see:
        - The function name
        - The bound parameters
    """


@dataclass(frozen=True)
class ReturnEvent(ExecutionEvent):
    """
    A function (or other code block) is about to return.
    """

    return_value: Any


@dataclass(frozen=True)
class ExceptionEvent(ExecutionEvent):
    """
    An exception has occured
    """

    exception: Exception
    value: Any
    traceback: TracebackType


@dataclass(frozen=True)
class OutputEvent:
    """
    Some text was written to stdout
    """

    text: str


Event: TypeAlias = LineEvent | CallEvent | ReturnEvent | ExceptionEvent | OutputEvent

Trace: TypeAlias = list[tuple[Loc, Event]]

DoneCallback = Callable[[Trace], None]


def ignore_variable(name: str, value: Any):
    return name.startswith("__") or callable(value) or isinstance(value, ModuleType)


def filtered_variables(variables: dict[str, Any]) -> dict[str, Any]:
    return {
        name: value
        for name, value in variables.items()
        if not ignore_variable(name, value)
    }


def copy_carefully(d: dict[str, Any]) -> dict[str, Any]:
    res = {}
    for k, v in d.items():
        try:
            v_copy = copy.deepcopy(v)
        except Exception:
            v_copy = v
        res[k] = v_copy
    return res


class OutputLogger:
    """
    OutputLogger wraps stdout, passing down writes and flushes to it, while simultaneously capturing the text to the trace.
    """

    def __init__(self, trace: Trace, stdout: TextIO):
        self.trace = trace
        self.stdout = stdout

    def write(self, text: str) -> None:
        """
        Write to stdout and also record the text in the trace
        """
        self.stdout.write(text)

        frame = sys._getframe(1)

        self.trace.append(
            (
                Loc(frame.f_code.co_name, frame.f_lineno),
                OutputEvent(text),
            )
        )

    def flush(self):
        self.stdout.flush()


CONAME = "<module>"


class VarTracer:
    def __init__(
        self, done_callback: DoneCallback, attached_to_frame: FrameType | None
    ):
        self.done_callback = done_callback
        self.attached_to_frame = attached_to_frame
        self.trace: Trace = []
        self.original_stdout = sys.stdout
        self.filename_of_interest: str | None = None
        sys.settrace(self.trace_vars)
        if attached_to_frame:
            attached_to_frame.f_trace = self.trace_vars

    def trace_vars(self, frame: FrameType, event: str, arg: Any):
        if not self.filename_of_interest:
            if frame.f_code.co_name == CONAME:
                # Until now we were lurking, finding out when to start collecting info
                # It's time to get to work
                self.filename_of_interest = frame.f_code.co_filename
                sys.stdout = OutputLogger(trace=self.trace, stdout=self.original_stdout)
            else:
                return

        if frame.f_code.co_filename != self.filename_of_interest:
            return

        locals = copy_carefully(filtered_variables(frame.f_locals))
        trace_event: Event | None = None
        match event:
            case "line":
                trace_event = LineEvent(locals=locals)
            case "call":
                trace_event = CallEvent(locals=locals)
            case "return":
                trace_event = ReturnEvent(locals=locals, return_value=arg)
            case "exception":
                trace_event = ExceptionEvent(
                    locals=locals, exception=arg[0], value=arg[1], traceback=arg[2]
                )
            case _:
                pass

        if trace_event:
            self.trace.append(
                (
                    Loc(frame.f_code.co_name, frame.f_lineno),
                    trace_event,
                )
            )

        # Unload if the job is done.
        # We do this only after recording the return event (for instance for changes to variables that occured the line before)
        if (
            event == "return"
            and frame.f_code.co_filename == self.filename_of_interest
            and frame.f_code.co_name == CONAME
        ):
            self.unload()
            return

        return self.trace_vars  # XXX: Not really sure this does anything

    def unload(self):
        sys.settrace(None)
        if self.attached_to_frame:
            self.attached_to_frame.f_trace = None
        sys.stdout = self.original_stdout
        self.done_callback(self.trace)
