import unittest

import atrace
from atrace.tracer import CallEvent, LineEvent, Loc, ReturnEvent


class TestFunctions(unittest.TestCase):
    def callback_done(self, trace):
        self.trace = trace

    def test_simple_function(self):
        atrace.trace_next_loaded_module(self.callback_done)
        from .programs import function  # noqa

        expected_trace = [
            (Loc("<module>", 0), CallEvent({})),
            (Loc("<module>", 1), LineEvent({})),
            (Loc("<module>", 4), LineEvent({})),
            (Loc("<module>", 9), LineEvent({})),
            (Loc("double", 4), CallEvent({"a": 3})),
            (Loc("double", 5), LineEvent({"a": 3})),
            (Loc("double", 6), LineEvent({"a": 3, "result": 6})),
            (Loc("double", 6), ReturnEvent({"a": 3, "result": 6}, 6)),
            (Loc("<module>", 9), ReturnEvent({"x": 6}, None)),
        ]
        self.assertEqual(expected_trace, self.trace)

    def test_function_modifying_global(self):
        atrace.trace_next_loaded_module(self.callback_done)
        from .programs import function_modifying_global  # noqa

        expected_trace = [
            (Loc("<module>", 0), CallEvent({})),
            (Loc("<module>", 1), LineEvent({})),
            (Loc("<module>", 3), LineEvent({})),
            (Loc("<module>", 6), LineEvent({"c": "start"})),
            (Loc("<module>", 12), LineEvent({"c": "start"})),
            (Loc("f", 6), CallEvent({"a": 3, "b": 14})),
            (Loc("f", 8), LineEvent({"a": 3, "b": 14})),
            (Loc("f", 9), LineEvent({"a": 3, "b": 14})),
            (Loc("f", 9), ReturnEvent({"a": 3, "b": 14}, return_value=17)),
            (Loc("<module>", 12), ReturnEvent({"c": 17, "x": 34}, None)),
        ]
        self.assertEqual(expected_trace, self.trace)

    def test_function_shadowing_global(self):
        atrace.trace_next_loaded_module(self.callback_done)
        from .programs import function_shadowing_global  # noqa

        expected_trace = [
            (Loc("<module>", 0), CallEvent({})),
            (Loc("<module>", 1), LineEvent({})),
            (Loc("<module>", 3), LineEvent({})),
            (Loc("<module>", 6), LineEvent({"c": "start"})),
            (Loc("<module>", 11), LineEvent({"c": "start"})),
            (Loc("f", 6), CallEvent({"a": 3, "b": 14})),
            (Loc("f", 7), LineEvent({"a": 3, "b": 14})),
            (Loc("f", 8), LineEvent({"a": 3, "b": 14, "c": 17})),
            (Loc("f", 8), ReturnEvent({"a": 3, "b": 14, "c": 17}, return_value=17)),
            (Loc("<module>", 11), ReturnEvent({"c": "start", "x": 34}, None)),
        ]
        self.assertEqual(expected_trace, self.trace)

    def test_function_with_recursion(self):
        atrace.trace_next_loaded_module(self.callback_done)
        from .programs import function_with_recursion  # noqa

        expected_trace = [
            (Loc("<module>", 0), CallEvent({})),
            (Loc("<module>", 1), LineEvent({})),
            (Loc("<module>", 4), LineEvent({})),
            (Loc("<module>", 8), LineEvent({})),
            (Loc("sum_up_to", 4), CallEvent({"x": 2})),
            (Loc("sum_up_to", 5), LineEvent({"x": 2})),
            (Loc("sum_up_to", 4), CallEvent({"x": 1})),
            (Loc("sum_up_to", 5), LineEvent({"x": 1})),
            (Loc("sum_up_to", 4), CallEvent({"x": 0})),
            (Loc("sum_up_to", 5), LineEvent({"x": 0})),
            (Loc("sum_up_to", 5), ReturnEvent({"x": 0}, 0)),
            (Loc("sum_up_to", 5), ReturnEvent({"x": 1}, 1)),
            (Loc("sum_up_to", 5), ReturnEvent({"x": 2}, 3)),
            (Loc("<module>", 8), ReturnEvent({"result": 3}, None)),
        ]
        self.assertEqual(expected_trace, self.trace)
