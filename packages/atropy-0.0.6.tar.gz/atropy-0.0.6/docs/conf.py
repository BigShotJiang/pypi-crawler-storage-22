# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = 'atropy'
copyright = '2025, Julian Mangott, Stefan Brunner, Lukas Einkemmer, Martina Prugger'
author = 'Julian Mangott, Stefan Brunner, Lukas Einkemmer, Martina Prugger'
release = '0.0.4'


# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = ['autoapi.extension', 'sphinx.ext.todo', 'sphinx.ext.viewcode']
# Display todos by setting to true
todo_include_todos = True

templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']

# Add autoapi options

autoapi_dirs = ['../atropy']
autoapi_type = "python"

# Ignore some files

autoapi_ignore = ["*/src/examples/*", "*/src/tests/*", "*/core/*"]


# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'alabaster'
html_static_path = ['_static']
