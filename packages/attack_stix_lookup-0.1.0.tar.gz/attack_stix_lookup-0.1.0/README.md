# attack-stix-lookup

Compact MITRE ATT&CK v18.1 STIX 2.1 lookup data with Python helper functions.

Extracted from [mitre-attack/attack-stix-data](https://github.com/mitre-attack/attack-stix-data) `enterprise-attack-18.1.json` using `attack-stix-splitter-v1.0.py`.

## Installation

```bash
pip install attack-stix-lookup
```

## Quick Start

```python
from attack_stix_lookup import AttackLookup

db = AttackLookup()

# Look up a technique by ATT&CK ID
t1490 = db.technique("T1490")
print(t1490["stix_id"])      # attack-pattern--f5d8eed6-...
print(t1490["name"])          # Inhibit System Recovery
print(t1490["tactics"])       # ['impact']

# Look up software by ATT&CK ID
revil = db.software("S0496")
print(revil["stix_id"])       # malware--ac61f1f9-...
print(revil["aliases"])       # ['REvil', 'Sodinokibi']

# Find all techniques a piece of software uses
techs = db.relationships_for(source_id=revil["stix_id"], rel_type="uses")
for rel in techs:
    t = db.technique_by_stix_id(rel["target_ref"])
    if t:
        print(f"  {t['external_id']} {t['name']}")

# Look up detection strategies for a technique
strategies = db.detection_strategies_for_technique(t1490["stix_id"])
for s in strategies:
    print(f"  {s['name']} -> {len(s['analytic_refs'])} analytics")

# Look up an analytic and its mutable elements
analytic = db.analytic("AN0001")  # by external_id
# or by STIX ID:
analytic = db.analytic_by_stix_id("x-mitre-analytic--aaaaaaaa-...")

# Look up a data component
dc = db.data_component("Process Creation")  # by name

# Look up groups and campaigns
apt29 = db.group("G0016")
campaign = db.campaign("C0001")

# Get a mitigation
m1053 = db.mitigation("M1053")

# Look up a tactic
impact = db.tactic("TA0040")

# Search by name substring (case-insensitive)
results = db.search_techniques("shadow")
results = db.search_software("sodinokibi")
```

## Data Files

The package bundles 7 JSON lookup files:

| File | Contents |
|---|---|
| `attack-patterns-lookup-v18.1.json` | Techniques & sub-techniques |
| `software-lookup-v18.1.json` | Malware & tools |
| `groups-campaigns-lookup-v18.1.json` | Intrusion sets & campaigns |
| `detection-objects-lookup-v18.1.json` | Detection strategies, analytics, data components |
| `relationships-lookup-v18.1.json` | All STIX Relationship Objects |
| `mitigations-lookup-v18.1.json` | Courses of action |
| `infrastructure-lookup-v18.1.json` | Tactics, matrices, identities, markings |

## Direct JSON Access

```python
from attack_stix_lookup import load_raw

attack_patterns = load_raw("attack-patterns-lookup-v18.1.json")
relationships = load_raw("relationships-lookup-v18.1.json")
```

## ATT&CK Data Version

- **ATT&CK Version:** v18.1 (Enterprise)
- **ATT&CK Spec Version:** 3.3.0
- **Source:** `enterprise-attack-18.1.json`

## License

MIT. ATT&CK data is Copyright © The MITRE Corporation, used under [ATT&CK Terms of Use](https://attack.mitre.org/resources/terms-of-use/).
