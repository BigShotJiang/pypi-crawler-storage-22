"""
attack-stix-lookup v0.1.0

Compact MITRE ATT&CK v18.1 STIX 2.1 lookup data with Python helper functions.
Designed for use in threat intelligence workflows, procedure modeling, and
detection engineering.

Usage:
    from attack_stix_lookup import AttackLookup
    db = AttackLookup()
    t1490 = db.technique("T1490")
"""

__version__ = "0.1.0"
__attack_version__ = "18.1"

import json
import os
from typing import Any, Dict, List, Optional, Union

_DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

_FILE_MAP = {
    "attack_patterns": "attack-patterns-lookup-v18.1.json",
    "software": "software-lookup-v18.1.json",
    "groups_campaigns": "groups-campaigns-lookup-v18.1.json",
    "detection_objects": "detection-objects-lookup-v18.1.json",
    "relationships": "relationships-lookup-v18.1.json",
    "mitigations": "mitigations-lookup-v18.1.json",
    "infrastructure": "infrastructure-lookup-v18.1.json",
}


def load_raw(filename: str) -> dict:
    """Load a raw JSON data file by filename.

    Args:
        filename: Name of the JSON file (e.g., 'attack-patterns-lookup-v18.1.json')

    Returns:
        Parsed JSON content as a dictionary.
    """
    filepath = os.path.join(_DATA_DIR, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


def _data_path(filename: str) -> str:
    return os.path.join(_DATA_DIR, filename)


class AttackLookup:
    """Primary interface for querying ATT&CK v18.1 STIX data.

    Lazily loads data files on first access to minimize startup cost.
    Builds in-memory indexes for fast lookups by external_id, stix_id, and name.
    """

    def __init__(self):
        self._cache: Dict[str, Any] = {}
        self._indexes: Dict[str, Dict[str, Any]] = {}

    def _load(self, key: str) -> Any:
        """Load and cache a data file."""
        if key not in self._cache:
            filepath = _data_path(_FILE_MAP[key])
            with open(filepath, "r", encoding="utf-8") as f:
                self._cache[key] = json.load(f)
        return self._cache[key]

    def _build_index(self, index_name: str, data_key: str, list_key: str,
                     field: str) -> Dict[str, dict]:
        """Build a lookup index on a specific field."""
        full_name = f"{index_name}_{field}"
        if full_name not in self._indexes:
            data = self._load(data_key)
            items = data.get(list_key, [])
            if isinstance(items, dict):
                # detection_objects has nested structure
                items = []
                for v in data.values():
                    if isinstance(v, list):
                        items.extend(v)
            self._indexes[full_name] = {}
            for item in items:
                val = item.get(field)
                if val:
                    key_val = val.lower() if isinstance(val, str) else val
                    self._indexes[full_name][key_val] = item
        return self._indexes[full_name]

    # -------------------------------------------------------------------------
    # Attack Patterns (Techniques & Sub-techniques)
    # -------------------------------------------------------------------------

    def technique(self, external_id: str) -> Optional[dict]:
        """Look up a technique by ATT&CK ID (e.g., 'T1490', 'T1059.003').

        Case-insensitive.
        """
        idx = self._build_index("ap", "attack_patterns", "attack_patterns", "external_id")
        return idx.get(external_id.lower())

    def technique_by_stix_id(self, stix_id: str) -> Optional[dict]:
        """Look up a technique by its STIX ID (e.g., 'attack-pattern--f5d8eed6-...')."""
        idx = self._build_index("ap_stix", "attack_patterns", "attack_patterns", "stix_id")
        return idx.get(stix_id.lower())

    def all_techniques(self) -> List[dict]:
        """Return all techniques and sub-techniques."""
        return self._load("attack_patterns").get("attack_patterns", [])

    def search_techniques(self, name_substring: str) -> List[dict]:
        """Search techniques by name substring (case-insensitive)."""
        query = name_substring.lower()
        return [t for t in self.all_techniques()
                if query in (t.get("name") or "").lower()]

    # -------------------------------------------------------------------------
    # Software (Malware & Tools)
    # -------------------------------------------------------------------------

    def software(self, external_id: str) -> Optional[dict]:
        """Look up software by ATT&CK ID (e.g., 'S0496')."""
        idx = self._build_index("sw", "software", "software", "external_id")
        return idx.get(external_id.lower())

    def software_by_stix_id(self, stix_id: str) -> Optional[dict]:
        """Look up software by STIX ID."""
        idx = self._build_index("sw_stix", "software", "software", "stix_id")
        return idx.get(stix_id.lower())

    def software_by_name(self, name: str) -> Optional[dict]:
        """Look up software by exact name (case-insensitive)."""
        idx = self._build_index("sw_name", "software", "software", "name")
        return idx.get(name.lower())

    def all_software(self) -> List[dict]:
        """Return all malware and tools."""
        return self._load("software").get("software", [])

    def search_software(self, query: str) -> List[dict]:
        """Search software by name or alias substring (case-insensitive)."""
        q = query.lower()
        results = []
        for s in self.all_software():
            if q in (s.get("name") or "").lower():
                results.append(s)
                continue
            for alias in s.get("aliases", []):
                if q in alias.lower():
                    results.append(s)
                    break
        return results

    # -------------------------------------------------------------------------
    # Groups & Campaigns
    # -------------------------------------------------------------------------

    def group(self, external_id: str) -> Optional[dict]:
        """Look up a threat group by ATT&CK ID (e.g., 'G0016')."""
        idx = self._build_index("gc", "groups_campaigns", "groups_campaigns", "external_id")
        return idx.get(external_id.lower())

    def group_by_stix_id(self, stix_id: str) -> Optional[dict]:
        """Look up a group by STIX ID."""
        idx = self._build_index("gc_stix", "groups_campaigns", "groups_campaigns", "stix_id")
        return idx.get(stix_id.lower())

    def campaign(self, external_id: str) -> Optional[dict]:
        """Look up a campaign by ATT&CK ID (e.g., 'C0001')."""
        return self.group(external_id)  # Same index, campaigns use same structure

    def all_groups(self) -> List[dict]:
        """Return all groups (intrusion-sets)."""
        return [g for g in self._load("groups_campaigns").get("groups_campaigns", [])
                if g.get("stix_type") == "intrusion-set"]

    def all_campaigns(self) -> List[dict]:
        """Return all campaigns."""
        return [c for c in self._load("groups_campaigns").get("groups_campaigns", [])
                if c.get("stix_type") == "campaign"]

    # -------------------------------------------------------------------------
    # Relationships
    # -------------------------------------------------------------------------

    def _load_relationships(self) -> List[dict]:
        return self._load("relationships").get("relationships", [])

    def relationships_for(self, source_id: Optional[str] = None,
                          target_id: Optional[str] = None,
                          rel_type: Optional[str] = None) -> List[dict]:
        """Find relationships matching any combination of filters.

        Args:
            source_id: Filter by source_ref STIX ID
            target_id: Filter by target_ref STIX ID
            rel_type: Filter by relationship_type (e.g., 'uses', 'detects', 'mitigates')

        Returns:
            List of matching relationship objects.
        """
        results = []
        for rel in self._load_relationships():
            if rel.get("revoked") or rel.get("deprecated"):
                continue
            if source_id and rel.get("source_ref") != source_id:
                continue
            if target_id and rel.get("target_ref") != target_id:
                continue
            if rel_type and rel.get("relationship_type") != rel_type:
                continue
            results.append(rel)
        return results

    def relationship_types(self) -> List[str]:
        """Return all distinct relationship types in the dataset."""
        types = set()
        for rel in self._load_relationships():
            rt = rel.get("relationship_type")
            if rt:
                types.add(rt)
        return sorted(types)

    # -------------------------------------------------------------------------
    # Detection Objects (v18)
    # -------------------------------------------------------------------------

    def _load_detection(self) -> dict:
        return self._load("detection_objects")

    def detection_strategy(self, external_id: str) -> Optional[dict]:
        """Look up a detection strategy by external ID (e.g., 'DET0329')."""
        for s in self._load_detection().get("detection_strategies", []):
            if (s.get("external_id") or "").lower() == external_id.lower():
                return s
        return None

    def detection_strategy_by_stix_id(self, stix_id: str) -> Optional[dict]:
        """Look up a detection strategy by STIX ID."""
        for s in self._load_detection().get("detection_strategies", []):
            if s.get("stix_id") == stix_id:
                return s
        return None

    def detection_strategies_for_technique(self, technique_stix_id: str) -> List[dict]:
        """Find all detection strategies that detect a given technique.

        Uses the 'detects' relationship type.
        """
        rels = self.relationships_for(target_id=technique_stix_id, rel_type="detects")
        strategy_ids = {r["source_ref"] for r in rels}
        return [s for s in self._load_detection().get("detection_strategies", [])
                if s.get("stix_id") in strategy_ids]

    def analytic(self, external_id: str) -> Optional[dict]:
        """Look up an analytic by external ID (e.g., 'AN0001')."""
        for a in self._load_detection().get("analytics", []):
            if (a.get("external_id") or "").lower() == external_id.lower():
                return a
        return None

    def analytic_by_stix_id(self, stix_id: str) -> Optional[dict]:
        """Look up an analytic by STIX ID."""
        for a in self._load_detection().get("analytics", []):
            if a.get("stix_id") == stix_id:
                return a
        return None

    def analytics_for_strategy(self, strategy: dict) -> List[dict]:
        """Given a detection strategy dict, return all its linked analytics."""
        ref_ids = set(strategy.get("analytic_refs", []))
        return [a for a in self._load_detection().get("analytics", [])
                if a.get("stix_id") in ref_ids]

    def data_component(self, name: str) -> Optional[dict]:
        """Look up a data component by name (case-insensitive)."""
        q = name.lower()
        for dc in self._load_detection().get("data_components", []):
            if (dc.get("name") or "").lower() == q:
                return dc
        return None

    def data_component_by_stix_id(self, stix_id: str) -> Optional[dict]:
        """Look up a data component by STIX ID."""
        for dc in self._load_detection().get("data_components", []):
            if dc.get("stix_id") == stix_id:
                return dc
        return None

    def all_detection_strategies(self) -> List[dict]:
        return self._load_detection().get("detection_strategies", [])

    def all_analytics(self) -> List[dict]:
        return self._load_detection().get("analytics", [])

    def all_data_components(self) -> List[dict]:
        return self._load_detection().get("data_components", [])

    # -------------------------------------------------------------------------
    # Mitigations
    # -------------------------------------------------------------------------

    def mitigation(self, external_id: str) -> Optional[dict]:
        """Look up a mitigation by ATT&CK ID (e.g., 'M1053')."""
        idx = self._build_index("mit", "mitigations", "mitigations", "external_id")
        return idx.get(external_id.lower())

    def mitigation_by_stix_id(self, stix_id: str) -> Optional[dict]:
        """Look up a mitigation by STIX ID."""
        idx = self._build_index("mit_stix", "mitigations", "mitigations", "stix_id")
        return idx.get(stix_id.lower())

    def all_mitigations(self) -> List[dict]:
        return self._load("mitigations").get("mitigations", [])

    # -------------------------------------------------------------------------
    # Infrastructure (Tactics, Matrices, etc.)
    # -------------------------------------------------------------------------

    def tactic(self, external_id: str) -> Optional[dict]:
        """Look up a tactic by ATT&CK ID (e.g., 'TA0040')."""
        for t in self._load("infrastructure").get("tactics", []):
            if (t.get("external_id") or "").lower() == external_id.lower():
                return t
        return None

    def tactic_by_shortname(self, shortname: str) -> Optional[dict]:
        """Look up a tactic by shortname (e.g., 'impact')."""
        q = shortname.lower()
        for t in self._load("infrastructure").get("tactics", []):
            if (t.get("shortname") or "").lower() == q:
                return t
        return None

    def all_tactics(self) -> List[dict]:
        return self._load("infrastructure").get("tactics", [])

    def matrix(self) -> Optional[dict]:
        """Return the Enterprise ATT&CK matrix."""
        matrices = self._load("infrastructure").get("matrices", [])
        return matrices[0] if matrices else None

    def identity_mitre(self) -> Optional[dict]:
        """Return the MITRE identity object."""
        for i in self._load("infrastructure").get("identities", []):
            if "MITRE" in (i.get("name") or ""):
                return i
        return None

    def marking_definitions(self) -> List[dict]:
        """Return all marking definitions."""
        return self._load("infrastructure").get("marking_definitions", [])

    # -------------------------------------------------------------------------
    # Cross-cutting utilities
    # -------------------------------------------------------------------------

    def resolve_stix_id(self, stix_id: str) -> Optional[dict]:
        """Resolve any STIX ID to its object, regardless of type.

        Checks attack-patterns, software, groups/campaigns, detection objects,
        mitigations, and infrastructure in order.
        """
        # Determine type from STIX ID prefix
        prefix = stix_id.split("--")[0] if "--" in stix_id else ""

        if prefix == "attack-pattern":
            return self.technique_by_stix_id(stix_id)
        elif prefix in ("malware", "tool"):
            return self.software_by_stix_id(stix_id)
        elif prefix in ("intrusion-set", "campaign"):
            return self.group_by_stix_id(stix_id)
        elif prefix == "course-of-action":
            return self.mitigation_by_stix_id(stix_id)
        elif prefix == "x-mitre-detection-strategy":
            return self.detection_strategy_by_stix_id(stix_id)
        elif prefix == "x-mitre-analytic":
            return self.analytic_by_stix_id(stix_id)
        elif prefix == "x-mitre-data-component":
            return self.data_component_by_stix_id(stix_id)
        else:
            # Brute force search across all types
            for method in [self.technique_by_stix_id, self.software_by_stix_id,
                           self.group_by_stix_id, self.mitigation_by_stix_id,
                           self.detection_strategy_by_stix_id,
                           self.analytic_by_stix_id,
                           self.data_component_by_stix_id]:
                result = method(stix_id)
                if result:
                    return result
        return None

    def stats(self) -> dict:
        """Return counts of all object types in the dataset."""
        return {
            "techniques": len(self.all_techniques()),
            "software": len(self.all_software()),
            "groups": len(self.all_groups()),
            "campaigns": len(self.all_campaigns()),
            "relationships": len(self._load_relationships()),
            "detection_strategies": len(self.all_detection_strategies()),
            "analytics": len(self.all_analytics()),
            "data_components": len(self.all_data_components()),
            "mitigations": len(self.all_mitigations()),
            "tactics": len(self.all_tactics()),
        }