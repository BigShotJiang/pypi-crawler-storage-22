# Data directory for ATT&CK STIX lookup JSON files.
# Populated by running attack-stix-splitter-v1.0.py
