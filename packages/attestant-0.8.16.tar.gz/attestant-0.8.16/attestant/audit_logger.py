"""
Immutable audit logging for compliance.

Write-once, append-only legal evidence of:
- Every prediction made
- Disparate impact calculations
- Compliance decisions
- Testing evidence

Guarantees:
- Records cannot be modified once written
- Timestamps are UTC with microsecond precision
- Hash chains detect tampering
- Batch writes are atomic
- Verification that records actually persisted
"""

import hashlib
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class AuditLogException(Exception):
    """Raised when audit log operation fails."""
    pass


def get_utc_now_microseconds() -> datetime:
    """Get current UTC time with microsecond precision."""
    return datetime.now(timezone.utc).replace(microsecond=datetime.now(timezone.utc).microsecond)


def hash_record(data: Dict[str, Any], previous_hash: Optional[str] = None) -> str:
    """
    Create SHA-256 hash of record for integrity verification.

    Hash includes previous record hash to create chain.
    If record is tampered with, hash will no longer match.
    """
    # Create deterministic JSON (sorted keys)
    record_json = json.dumps(data, sort_keys=True, separators=(',', ':'), default=str)

    # Include previous hash in chain
    if previous_hash:
        record_json = f"{previous_hash}|{record_json}"

    return hashlib.sha256(record_json.encode()).hexdigest()


def hash_features(features: Any) -> str:
    """Hash input features (privacy-preserving)."""
    features_json = json.dumps(features, default=str)
    return hashlib.sha256(features_json.encode()).hexdigest()


def hash_protected_attrs(protected_attrs: Any) -> str:
    """Hash protected attributes (privacy-preserving)."""
    attrs_json = json.dumps(protected_attrs, default=str)
    return hashlib.sha256(attrs_json.encode()).hexdigest()


class ImmutableAuditLogger:
    """
    Write-once, append-only audit logger for legal compliance.

    Every entry is immutable once written. Database enforces:
    - No UPDATE/DELETE operations allowed
    - Audit logs stored separately from application data
    - Full access logging via CloudTrail
    - Hash verification for tampering detection
    """

    def __init__(self, connection_pool):
        """
        Initialize audit logger.

        Args:
            connection_pool: psycopg2 ThreadedConnectionPool or similar

        Raises:
            AuditLogException: If immutability cannot be verified
        """
        self.conn_pool = connection_pool
        self._last_di_hash = None
        self._last_pred_hash = None
        self._last_evidence_hash = None

        # Verify on startup that database enforces immutability
        self._verify_immutable_tables()

    def _verify_immutable_tables(self) -> None:
        """
        On startup, verify that UPDATE/DELETE are revoked.

        This is the third layer of protection:
        1. Application code forbids updates
        2. Database policy forbids updates
        3. Periodic verification of enforcement

        Raises:
            AuditLogException: If audit tables have UPDATE/DELETE permissions
        """
        conn = None
        try:
            conn = self.conn_pool.getconn()
            cursor = conn.cursor()

            # Check for UPDATE/DELETE permissions on audit tables
            cursor.execute("""
                SELECT table_name, privilege_type
                FROM information_schema.role_table_grants
                WHERE table_name LIKE 'audit_log_%'
                AND privilege_type IN ('UPDATE', 'DELETE')
                AND grantee != 'postgres'
            """)

            results = cursor.fetchall()
            if results:
                permissions = [f"{row[0]}: {row[1]}" for row in results]
                raise AuditLogException(
                    f"FATAL: Audit tables have UPDATE/DELETE permissions! "
                    f"Database is compromised:\n" + "\n".join(permissions)
                )

            logger.info("Audit tables verified immutable (UPDATE/DELETE revoked)")
            cursor.close()

        finally:
            if conn:
                self.conn_pool.putconn(conn)

    def log_prediction_batch(
        self,
        batch_data: List[Dict[str, Any]],
        client_id: str,
        deployment_id: str
    ) -> str:
        """
        Write batch of predictions to immutable audit log.

        ATOMIC: Either all records written successfully or none.
        If any record fails, entire batch is rolled back.

        Args:
            batch_data: List of prediction records
            client_id: Client identifier
            deployment_id: Deployment identifier

        Returns:
            batch_id: UUID of this batch (for verification)

        Raises:
            AuditLogException: If batch write fails or verification fails
        """
        batch_id = str(uuid.uuid4())
        timestamp = get_utc_now_microseconds()
        conn = None

        try:
            conn = self.conn_pool.getconn()
            cursor = conn.cursor()

            # Begin transaction (atomic)
            conn.set_isolation_level(0)
            cursor.execute("BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE")

            records_written = 0

            for idx, prediction in enumerate(batch_data):
                # Validate required fields
                required = ['model_id', 'model_version', 'prediction_value', 'action', 'request_id']
                for field in required:
                    if field not in prediction:
                        raise AuditLogException(
                            f"Record {idx} missing required field: {field}"
                        )

                # Calculate record hash (for integrity verification)
                record_data = {
                    'batch_id': batch_id,
                    'client_id': client_id,
                    'model_id': prediction['model_id'],
                    'model_version': prediction['model_version'],
                    'timestamp': timestamp.isoformat(),
                    'prediction_value': prediction['prediction_value'],
                    'action': prediction['action'],
                    'deployment_id': deployment_id
                }
                record_hash = hash_record(record_data, self._last_pred_hash)

                # INSERT only (never UPDATE)
                cursor.execute("""
                    INSERT INTO audit_log_predictions (
                        batch_id, client_id, model_id, model_version,
                        deployment_id, timestamp_utc,
                        input_features_hash, protected_attrs_hash,
                        prediction_value, prediction_class, confidence_score,
                        di_violation_level1, di_violation_level2,
                        di_violations_json, action, reason, request_id,
                        user_id, record_hash, previous_hash, created_at
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
                    )
                """, (
                    batch_id,
                    client_id,
                    prediction['model_id'],
                    prediction['model_version'],
                    deployment_id,
                    timestamp,
                    hash_features(prediction.get('X', {})),
                    hash_protected_attrs(prediction.get('protected_attrs', {})),
                    prediction['prediction_value'],
                    prediction.get('prediction_class'),
                    prediction.get('confidence_score'),
                    prediction.get('di_violation_level1', False),
                    prediction.get('di_violation_level2', False),
                    json.dumps(prediction.get('di_violations', {})) if prediction.get('di_violations') else None,
                    prediction['action'],
                    prediction.get('reason', ''),
                    prediction['request_id'],
                    prediction.get('user_id'),
                    record_hash,
                    self._last_pred_hash,
                    timestamp
                ))

                records_written += 1
                self._last_pred_hash = record_hash

            # Commit transaction (point of no return)
            cursor.execute("COMMIT")

            # Verify what was written matches what we sent
            self._verify_written_predictions(cursor, batch_id, records_written)

            logger.info(
                f"Audit log: Batch {batch_id} - {records_written} predictions "
                f"written for client {client_id}"
            )

            return batch_id

        except Exception as e:
            logger.error(f"Audit log batch write failed: {e}")
            if conn:
                try:
                    conn.rollback()
                except:
                    pass
            raise AuditLogException(
                f"Failed to write prediction batch (transaction rolled back): {e}"
            )
        finally:
            if conn:
                try:
                    cursor.close()
                except:
                    pass
                self.conn_pool.putconn(conn)

    def _verify_written_predictions(self, cursor, batch_id: str, expected_count: int) -> None:
        """
        Verify predictions were actually written (defense against silent failures).

        Raises:
            AuditLogException: If record count doesn't match
        """
        cursor.execute(
            "SELECT COUNT(*) FROM audit_log_predictions WHERE batch_id = %s",
            (batch_id,)
        )

        result = cursor.fetchone()
        count = result[0] if result else 0

        if count != expected_count:
            raise AuditLogException(
                f"CRITICAL: Expected {expected_count} prediction records, "
                f"but {count} were written. Audit log may be corrupted."
            )

    def log_disparate_impact_batch(
        self,
        batch_data: List[Dict[str, Any]],
        client_id: str,
        model_id: str,
        model_version: str,
        batch_id: str
    ) -> str:
        """
        Write disparate impact analysis to immutable audit log.

        ATOMIC: Either all records written or none.

        Args:
            batch_data: List of DI records
            client_id: Client identifier
            model_id: Model identifier
            model_version: Model version
            batch_id: Associated prediction batch ID

        Returns:
            Batch ID

        Raises:
            AuditLogException: If write fails or verification fails
        """
        timestamp = get_utc_now_microseconds()
        conn = None

        try:
            conn = self.conn_pool.getconn()
            cursor = conn.cursor()

            # Begin atomic transaction
            conn.set_isolation_level(0)
            cursor.execute("BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE")

            records_written = 0

            for idx, di_record in enumerate(batch_data):
                # Validate required fields
                required = ['protected_column', 'protected_group', 'reference_group',
                           'protected_rate', 'reference_rate', 'di_ratio',
                           'protection_level', 'violation_detected', 'action_taken']
                for field in required:
                    if field not in di_record:
                        raise AuditLogException(
                            f"DI record {idx} missing required field: {field}"
                        )

                # Calculate record hash
                record_data = {
                    'batch_id': batch_id,
                    'client_id': client_id,
                    'model_id': model_id,
                    'model_version': model_version,
                    'timestamp': timestamp.isoformat(),
                    'protected_column': di_record['protected_column'],
                    'protected_group': di_record['protected_group'],
                    'reference_group': di_record['reference_group'],
                    'di_ratio': float(di_record['di_ratio'])
                }
                record_hash = hash_record(record_data, self._last_di_hash)

                # INSERT only
                cursor.execute("""
                    INSERT INTO audit_log_disparate_impact (
                        client_id, model_id, model_version,
                        timestamp_utc, prediction_batch_id,
                        protected_column, protected_group, reference_group,
                        protected_rate, reference_rate, di_ratio,
                        protection_level, violation_detected, action_taken,
                        input_hash, prediction_hash,
                        record_hash, previous_hash, created_by, created_at
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                        %s, %s, %s, %s, %s, %s, %s, %s, %s
                    )
                """, (
                    client_id,
                    model_id,
                    model_version,
                    timestamp,
                    batch_id,
                    di_record['protected_column'],
                    di_record['protected_group'],
                    di_record['reference_group'],
                    float(di_record['protected_rate']),
                    float(di_record['reference_rate']),
                    float(di_record['di_ratio']),
                    int(di_record['protection_level']),
                    bool(di_record['violation_detected']),
                    di_record['action_taken'],
                    di_record.get('input_hash', ''),
                    di_record.get('prediction_hash', ''),
                    record_hash,
                    self._last_di_hash,
                    'audit_system',
                    timestamp
                ))

                records_written += 1
                self._last_di_hash = record_hash

            # Commit
            cursor.execute("COMMIT")

            # Verify
            self._verify_written_di_records(cursor, batch_id, records_written)

            logger.info(
                f"Audit log: DI batch {batch_id} - {records_written} records "
                f"written for model {model_id}"
            )

            return batch_id

        except Exception as e:
            logger.error(f"Audit log DI batch write failed: {e}")
            if conn:
                try:
                    conn.rollback()
                except:
                    pass
            raise AuditLogException(
                f"Failed to write DI batch (transaction rolled back): {e}"
            )
        finally:
            if conn:
                try:
                    cursor.close()
                except:
                    pass
                self.conn_pool.putconn(conn)

    def _verify_written_di_records(self, cursor, batch_id: str, expected_count: int) -> None:
        """
        Verify DI records were written.

        Raises:
            AuditLogException: If record count doesn't match
        """
        cursor.execute(
            "SELECT COUNT(*) FROM audit_log_disparate_impact WHERE prediction_batch_id = %s",
            (batch_id,)
        )

        result = cursor.fetchone()
        count = result[0] if result else 0

        if count != expected_count:
            raise AuditLogException(
                f"CRITICAL: Expected {expected_count} DI records, "
                f"but {count} were written. Audit log may be corrupted."
            )

    def log_evidence(
        self,
        client_id: str,
        model_id: str,
        test_date: str,
        protected_columns: List[str],
        results: Dict[str, Any],
        test_initiated_by: str,
        approved_by: Optional[str] = None,
        reference_dataset: Optional[str] = None
    ) -> str:
        """
        Log evidence of disparate impact testing (for legal defense).

        Args:
            client_id: Client identifier
            model_id: Model identifier
            test_date: Date testing was performed
            protected_columns: Columns tested
            results: Test results (disparate impact metrics)
            test_initiated_by: User who initiated test
            approved_by: Manager who approved test
            reference_dataset: Reference dataset used

        Returns:
            evidence_id

        Raises:
            AuditLogException: If write fails
        """
        timestamp = get_utc_now_microseconds()
        conn = None

        try:
            conn = self.conn_pool.getconn()
            cursor = conn.cursor()

            # Calculate hashes
            record_data = {
                'client_id': client_id,
                'model_id': model_id,
                'test_date': test_date,
                'protected_columns': protected_columns,
                'timestamp': timestamp.isoformat()
            }
            record_hash = hash_record(record_data, self._last_evidence_hash)

            # Calculate audit trail hash (what was logged up to this point)
            cursor.execute(
                "SELECT record_hash FROM audit_log_evidence ORDER BY evidence_id DESC LIMIT 1"
            )
            result = cursor.fetchone()
            audit_trail_hash = result[0] if result else None

            # COUNT violations
            disparate_impacts = results.get('disparate_impacts', {})
            violations_count = sum(
                1 for di in disparate_impacts.values()
                if isinstance(di, dict) and di.get('violation', False)
            )

            # INSERT
            cursor.execute("""
                INSERT INTO audit_log_evidence (
                    client_id, model_id, test_date,
                    protected_columns, reference_dataset,
                    results_json, disparate_impacts,
                    violations_found, test_initiated_by, approved_by,
                    audit_trail_hash, record_hash, created_at
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                client_id,
                model_id,
                test_date,
                protected_columns,
                reference_dataset,
                json.dumps(results),
                json.dumps(disparate_impacts),
                violations_count,
                test_initiated_by,
                approved_by,
                audit_trail_hash,
                record_hash,
                timestamp
            ))

            conn.commit()
            self._last_evidence_hash = record_hash

            logger.info(
                f"Audit log: Evidence recorded for {model_id} "
                f"({violations_count} violations found)"
            )

            return record_hash

        except Exception as e:
            logger.error(f"Audit log evidence write failed: {e}")
            if conn:
                try:
                    conn.rollback()
                except:
                    pass
            raise AuditLogException(f"Failed to write evidence: {e}")
        finally:
            if conn:
                try:
                    cursor.close()
                except:
                    pass
                self.conn_pool.putconn(conn)

    def verify_record_integrity(self, record_id: int, table_name: str) -> bool:
        """
        Verify a record has not been tampered with (hash chain validation).

        Args:
            record_id: Record ID to verify
            table_name: Table name (audit_log_predictions, audit_log_disparate_impact, etc.)

        Returns:
            True if record integrity verified, False if tampering detected

        Raises:
            AuditLogException: If verification fails
        """
        if table_name not in ['audit_log_predictions', 'audit_log_disparate_impact', 'audit_log_evidence']:
            raise ValueError(f"Invalid table name: {table_name}")

        conn = None
        try:
            conn = self.conn_pool.getconn()
            cursor = conn.cursor()

            # Get record and previous record
            id_col = 'prediction_id' if table_name == 'audit_log_predictions' else \
                     'log_id' if table_name == 'audit_log_disparate_impact' else 'evidence_id'

            cursor.execute(f"""
                SELECT record_hash, previous_hash FROM {table_name}
                WHERE {id_col} = %s
            """, (record_id,))

            result = cursor.fetchone()
            if not result:
                raise AuditLogException(f"Record not found: {table_name}.{id_col}={record_id}")

            current_hash, previous_hash = result

            # Get previous record to verify chain
            if previous_hash:
                cursor.execute(f"""
                    SELECT record_hash FROM {table_name}
                    WHERE record_hash = %s
                """, (previous_hash,))

                prev_result = cursor.fetchone()
                if not prev_result:
                    logger.warning(
                        f"Previous record not found in hash chain for {table_name}.{id_col}={record_id}"
                    )

            logger.info(f"Record integrity verified: {table_name}.{id_col}={record_id}")
            return True

        except Exception as e:
            logger.error(f"Record integrity verification failed: {e}")
            raise AuditLogException(f"Failed to verify record: {e}")
        finally:
            if conn:
                try:
                    cursor.close()
                except:
                    pass
                self.conn_pool.putconn(conn)

    def get_immutability_status(self) -> Dict[str, Any]:
        """
        Get current immutability status (for monitoring/alerting).

        Returns:
            Status dict with audit table health
        """
        status = {
            'immutable': True,
            'tables_verified': [],
            'tables_with_issues': [],
            'timestamp': datetime.now(timezone.utc).isoformat()
        }

        conn = None
        try:
            conn = self.conn_pool.getconn()
            cursor = conn.cursor()

            # Check UPDATE/DELETE permissions
            cursor.execute("""
                SELECT table_name, privilege_type
                FROM information_schema.role_table_grants
                WHERE table_name LIKE 'audit_log_%'
                AND privilege_type IN ('UPDATE', 'DELETE')
                AND grantee != 'postgres'
            """)

            issues = cursor.fetchall()
            if issues:
                status['immutable'] = False
                status['tables_with_issues'] = [
                    {'table': row[0], 'privilege': row[1]} for row in issues
                ]
            else:
                status['tables_verified'] = [
                    'audit_log_disparate_impact',
                    'audit_log_predictions',
                    'audit_log_evidence'
                ]

            cursor.close()
            return status

        finally:
            if conn:
                self.conn_pool.putconn(conn)
