"""
Attestant CLI: unified command-line interface for provenance, fairness, and docs.

Usage:
    attestant fairness analyze --model m.pkl --data d.csv --protected race,sex --industry lending
    attestant docs generate --template sr11-7 --model metadata.json
    attestant docs templates
    attestant compliance check --db provenance.db --fingerprint 0xABC123
    attestant compliance score --db provenance.db
    attestant health --db provenance.db
    attestant dashboard
    attestant keys generate <tenant> --name "Databricks Production"
    attestant keys list <tenant>
    attestant keys revoke <tenant> <key-id>
    attestant keys rotate <tenant> <key-id>
"""

import argparse
import json
import os
import sys

try:
    from attestant import __version__
except ImportError:
    from proveit import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="proveit",
        description="Attestant: Cryptographically Provable AI Compliance for Banks",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"proveit {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command")

    # --- fairness (from fairlens) ---
    fairness_parser = subparsers.add_parser(
        "fairness",
        help="Algorithmic fairness analysis",
    )
    fairness_sub = fairness_parser.add_subparsers(dest="fairness_command")
    from .fairness.cli import register_subcommands as reg_fairness
    reg_fairness(fairness_sub)

    # --- docs (from autodoc) ---
    docs_parser = subparsers.add_parser(
        "docs",
        help="Compliance documentation generation",
    )
    docs_sub = docs_parser.add_subparsers(dest="docs_command")
    from .docs.cli import register_subcommands as reg_docs
    reg_docs(docs_sub)

    # --- compliance ---
    compliance_parser = subparsers.add_parser(
        "compliance",
        help="Run compliance checks on a provenance DAG",
    )
    compliance_sub = compliance_parser.add_subparsers(dest="compliance_command")

    check_parser = compliance_sub.add_parser(
        "check",
        help="Run compliance engines against a specific DAG root fingerprint",
    )
    check_parser.add_argument(
        "--db", required=True,
        help="Path to the SQLite provenance database",
    )
    check_parser.add_argument(
        "--fingerprint", required=True,
        help="Root node fingerprint (hex, e.g. 0xABC123)",
    )
    check_parser.add_argument(
        "--format", choices=["json", "text"], default="text",
        help="Output format (default: text)",
    )

    score_parser = compliance_sub.add_parser(
        "score",
        help="Calculate board-reportable compliance score",
    )
    score_parser.add_argument(
        "--db", required=True,
        help="Path to the SQLite provenance database",
    )
    score_parser.add_argument(
        "--fingerprint", required=True,
        help="Root node fingerprint (hex, e.g. 0xABC123)",
    )

    # --- health ---
    health_parser = subparsers.add_parser(
        "health",
        help="Run platform health check",
    )
    health_parser.add_argument(
        "--db",
        help="Optional SQLite DB path to check connectivity",
    )

    # --- dashboard ---
    subparsers.add_parser(
        "dashboard",
        help="Launch the provenance dashboard",
    )

    # --- config ---
    config_parser = subparsers.add_parser(
        "config",
        help="Manage Attestant configuration",
    )
    config_sub = config_parser.add_subparsers(dest="config_command")

    show_config = config_sub.add_parser("show", help="Show current configuration")
    show_config.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    test_db = config_sub.add_parser(
        "test-db", help="Test database connection"
    )
    test_db.add_argument(
        "--dsn",
        help="Database DSN (uses ATTESTANT_DB_CONNECTION if not provided)",
    )

    version_cmd = config_sub.add_parser("version", help="Show Attestant version")

    # --- api-key (legacy) ---
    key_parser = subparsers.add_parser(
        "api-key",
        help="Manage customer API keys (legacy, use 'keys' instead)",
    )
    key_sub = key_parser.add_subparsers(dest="key_command")
    create_key_parser = key_sub.add_parser("create", help="Create a new API key for a tenant")
    create_key_parser.add_argument("--tenant-id", required=True, help="Tenant identifier")
    create_key_parser.add_argument("--tenant-name", default="", help="Human-readable tenant name")
    create_key_parser.add_argument("--tier", default="professional", choices=["starter", "professional", "enterprise"])
    key_sub.add_parser("list", help="List all API keys")

    # --- keys (new: DashboardStore-backed) ---
    keys_parser = subparsers.add_parser(
        "keys",
        help="Manage API keys for tenants (Aurora PostgreSQL)",
    )
    keys_sub = keys_parser.add_subparsers(dest="keys_command")

    keys_gen = keys_sub.add_parser(
        "generate", help="Generate a new API key for a tenant",
    )
    keys_gen.add_argument("tenant", help="Tenant identifier (e.g. test_company)")
    keys_gen.add_argument(
        "--name", dest="key_name", default=None,
        help="Human-readable key name (e.g. 'Databricks Production')",
    )
    keys_gen.add_argument(
        "--expires-in", type=int, default=None, dest="expires_in",
        help="Key expiration in days (default: never)",
    )

    keys_list = keys_sub.add_parser(
        "list", help="List all API keys for a tenant",
    )
    keys_list.add_argument("tenant", help="Tenant identifier")
    keys_list.add_argument(
        "--format", choices=["json", "table"], default="table",
        dest="output_format", help="Output format (default: table)",
    )

    keys_revoke = keys_sub.add_parser(
        "revoke", help="Revoke an API key (cannot be undone)",
    )
    keys_revoke.add_argument("tenant", help="Tenant identifier")
    keys_revoke.add_argument("key_id", type=int, help="Key ID to revoke")

    keys_rotate = keys_sub.add_parser(
        "rotate", help="Rotate an API key (revoke old, generate new)",
    )
    keys_rotate.add_argument("tenant", help="Tenant identifier")
    keys_rotate.add_argument("key_id", type=int, help="Key ID to rotate")
    keys_rotate.add_argument(
        "--name", dest="key_name", default=None,
        help="Name for the new key",
    )

    args = parser.parse_args()

    if args.command == "fairness":
        _dispatch_fairness(args, fairness_parser)
    elif args.command == "docs":
        _dispatch_docs(args, docs_parser)
    elif args.command == "compliance":
        _dispatch_compliance(args, compliance_parser)
    elif args.command == "config":
        _dispatch_config(args, config_parser)
    elif args.command == "health":
        _dispatch_health(args)
    elif args.command == "dashboard":
        from .dashboard.server import main as dashboard_main
        dashboard_main()
    elif args.command == "api-key":
        _dispatch_api_key(args, key_parser)
    elif args.command == "keys":
        _dispatch_keys(args, keys_parser)
    else:
        parser.print_help()


def _dispatch_fairness(args, parent_parser):
    from .fairness.cli import cmd_analyze, _validate_regulation
    if getattr(args, "fairness_command", None) == "analyze":
        _validate_regulation(args.regulation)
        cmd_analyze(args)
    else:
        parent_parser.print_help()


def _dispatch_docs(args, parent_parser):
    from .docs.cli import cmd_generate, cmd_templates
    if getattr(args, "docs_command", None) == "generate":
        cmd_generate(args)
    elif getattr(args, "docs_command", None) == "templates":
        cmd_templates(args)
    else:
        parent_parser.print_help()


def _dispatch_compliance(args, parent_parser):
    cmd = getattr(args, "compliance_command", None)
    if cmd == "check":
        _cmd_compliance_check(args)
    elif cmd == "score":
        _cmd_compliance_score(args)
    else:
        parent_parser.print_help()


def _cmd_compliance_check(args):
    """Run compliance engines against a DAG and print results."""
    from .persistence.sqlite_storage import SQLiteStorage
    from .compliance import EUAIActEngine, ECOAEngine, ComplianceReport
    from .dashboard.server import _load_dag_graph, _build_computation_dag

    storage = SQLiteStorage(args.db)
    storage.connect()

    try:
        fp = int(args.fingerprint, 0)
    except ValueError:
        print(f"Error: invalid fingerprint '{args.fingerprint}'", file=sys.stderr)
        sys.exit(1)

    root_data = storage.get_node_by_fingerprint(fp)
    if not root_data:
        print(f"Error: fingerprint {args.fingerprint} not found in database", file=sys.stderr)
        sys.exit(1)

    nodes_map, edges_list = _load_dag_graph(storage, root_data["node_id"])
    dag = _build_computation_dag(nodes_map, edges_list, root_data["node_id"])

    report = ComplianceReport()
    for engine in [EUAIActEngine(), ECOAEngine()]:
        try:
            report.add(engine.check(dag, {"domain": "general"}))
        except Exception as e:
            print(f"Warning: {engine.regulation_name} engine failed: {e}", file=sys.stderr)

    if args.format == "json":
        print(json.dumps(report.to_dict(), indent=2, default=str))
    else:
        summary = report.summary()
        status = "PASS" if summary["overall_passed"] else "FAIL"
        print(f"Overall: {status}")
        print(f"Engines run: {summary['engines_run']}")
        print(f"Findings: {summary['total_findings']} "
              f"({summary['total_critical']} critical, {summary['total_warnings']} warnings)")
        for reg, info in summary["per_regulation"].items():
            s = "PASS" if info["passed"] else "FAIL"
            print(f"  {reg}: {s} ({info['critical']}C / {info['warning']}W)")

    storage.disconnect()


def _cmd_compliance_score(args):
    """Calculate and print a board-reportable compliance score."""
    from .persistence.sqlite_storage import SQLiteStorage
    from .compliance import EUAIActEngine, ECOAEngine, ComplianceReport
    from .compliance.score import ComplianceScorer
    from .dashboard.server import _load_dag_graph, _build_computation_dag

    storage = SQLiteStorage(args.db)
    storage.connect()

    try:
        fp = int(args.fingerprint, 0)
    except ValueError:
        print(f"Error: invalid fingerprint '{args.fingerprint}'", file=sys.stderr)
        sys.exit(1)

    root_data = storage.get_node_by_fingerprint(fp)
    if not root_data:
        print(f"Error: fingerprint {args.fingerprint} not found in database", file=sys.stderr)
        sys.exit(1)

    nodes_map, edges_list = _load_dag_graph(storage, root_data["node_id"])
    dag = _build_computation_dag(nodes_map, edges_list, root_data["node_id"])

    report = ComplianceReport()
    for engine in [EUAIActEngine(), ECOAEngine()]:
        try:
            report.add(engine.check(dag, {"domain": "general"}))
        except Exception as e:
            print(f"Warning: {engine.regulation_name} engine failed: {e}", file=sys.stderr)

    scorer = ComplianceScorer()
    result = scorer.score(report)
    print(result.board_summary())

    storage.disconnect()


def _dispatch_api_key(args, parent_parser):
    """Manage customer API keys (server-side only)."""
    import os
    cmd = getattr(args, "key_command", None)
    dsn = os.environ.get("ATTESTANT_DSN") or os.environ.get("DASH_WRITER_DSN")
    if not dsn:
        print("Error: Set ATTESTANT_DSN or DASH_WRITER_DSN environment variable", file=sys.stderr)
        sys.exit(1)

    if cmd == "create":
        os.environ["ATTESTANT_DSN"] = dsn
        from .api.server import create_api_key
        raw_key = create_api_key(
            tenant_id=args.tenant_id,
            tenant_name=args.tenant_name,
            tier=args.tier,
        )
        print(f"API key created for tenant '{args.tenant_id}' ({args.tier}):")
        print(f"  {raw_key}")
        print()
        print("Give this key to the customer. It cannot be retrieved again.")
    elif cmd == "list":
        import psycopg2
        conn = psycopg2.connect(dsn)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT key_prefix, tenant_id, tenant_name, tier,
                           is_active, created_at, last_used_at
                    FROM api_keys ORDER BY created_at DESC
                    """
                )
                rows = cur.fetchall()
                if not rows:
                    print("No API keys found.")
                    return
                print(f"{'Prefix':<18} {'Tenant':<20} {'Name':<20} {'Tier':<14} {'Active':<8} {'Created':<22} {'Last Used'}")
                print("-" * 130)
                for r in rows:
                    last_used = r[6].strftime("%Y-%m-%d %H:%M") if r[6] else "never"
                    created = r[5].strftime("%Y-%m-%d %H:%M") if r[5] else ""
                    print(f"{r[0]:<18} {r[1]:<20} {(r[2] or ''):<20} {r[3]:<14} {'yes' if r[4] else 'no':<8} {created:<22} {last_used}")
        finally:
            conn.close()
    else:
        parent_parser.print_help()


def _get_store():
    """Create and connect a DashboardStore for CLI operations."""
    dsn = os.environ.get("DASH_WRITER_DSN") or os.environ.get("ATTESTANT_DSN")
    if not dsn:
        print(
            "Error: Cannot connect to database (check DASH_WRITER_DSN)",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        from .dashboard.dashdb import DashboardStore
    except ImportError:
        print(
            "Error: psycopg2 not installed (pip install psycopg2-binary)",
            file=sys.stderr,
        )
        sys.exit(1)

    store = DashboardStore(
        writer_dsn=dsn,
        reader_dsn=os.environ.get("DASH_READER_DSN"),
    )
    try:
        store.connect()
    except Exception as exc:
        print(f"Error: Cannot connect to database ({exc})", file=sys.stderr)
        sys.exit(1)

    return store


def _resolve_tenant(store, tenant_name: str) -> str:
    """Verify a tenant exists and return its tenant_id."""
    tenant = store.get_tenant(tenant_name)
    if not tenant:
        print(f"Error: Tenant '{tenant_name}' not found", file=sys.stderr)
        sys.exit(1)
    return tenant["tenant_id"]


def _dispatch_keys(args, parent_parser):
    """Manage API keys via DashboardStore (Aurora PostgreSQL)."""
    cmd = getattr(args, "keys_command", None)
    if cmd is None:
        parent_parser.print_help()
        return

    store = _get_store()
    try:
        if cmd == "generate":
            _cmd_keys_generate(store, args)
        elif cmd == "list":
            _cmd_keys_list(store, args)
        elif cmd == "revoke":
            _cmd_keys_revoke(store, args)
        elif cmd == "rotate":
            _cmd_keys_rotate(store, args)
        else:
            parent_parser.print_help()
    finally:
        store.disconnect()


def _cmd_keys_generate(store, args):
    """Generate a new API key for a tenant."""
    from datetime import timedelta

    tenant_id = _resolve_tenant(store, args.tenant)
    key_name = args.key_name or "Default"
    created_by = os.environ.get("USER", "cli")
    expires_at = None
    if args.expires_in is not None:
        from datetime import datetime, timezone
        expires_at = datetime.now(timezone.utc) + timedelta(days=args.expires_in)

    try:
        key_value, key_id = store.create_api_key(
            tenant_id=tenant_id,
            key_name=key_name,
            created_by=created_by,
            expires_at=expires_at,
        )
    except Exception as exc:
        print(f"Error: Failed to create API key ({exc})", file=sys.stderr)
        sys.exit(1)

    expires_str = "Never"
    if expires_at is not None:
        expires_str = expires_at.strftime("%Y-%m-%d")

    print(f"\nAPI key created for tenant: {args.tenant}")
    print()
    print(f"  Key ID:     {key_id}")
    print(f"  Key Name:   {key_name}")
    print(f"  Status:     active")
    print(f"  Expires:    {expires_str}")
    print()
    print(f"  Your API Key (shown once, save it securely):")
    print(f"     {key_value}")
    print()
    print(f"  Usage in Databricks:")
    print(f'    API_KEY = "{key_value}"')
    print(f"    attestant.configure(api_key=API_KEY)")
    print()


def _cmd_keys_list(store, args):
    """List all API keys for a tenant."""
    tenant_id = _resolve_tenant(store, args.tenant)
    keys = store.list_api_keys(tenant_id)

    if not keys:
        print(f"No API keys found for tenant '{args.tenant}'.")
        return

    if args.output_format == "json":
        out = []
        for k in keys:
            out.append({
                "id": k["id"],
                "name": k.get("key_name") or "",
                "status": k.get("status", "active"),
                "created_at": k["created_at"].isoformat() if k.get("created_at") else None,
                "expires_at": k["expires_at"].isoformat() if k.get("expires_at") else None,
                "last_used_at": k["last_used_at"].isoformat() if k.get("last_used_at") else None,
                "created_by": k.get("created_by") or "",
            })
        print(json.dumps(out, indent=2))
        return

    print(
        f"{'ID':<6}{'Name':<22}{'Status':<10}{'Created':<21}"
        f"{'Expires':<12}{'Last Used':<12}{'Created By'}"
    )
    print("-" * 95)
    for k in keys:
        key_id = k["id"]
        name = (k.get("key_name") or "")[:20]
        status = k.get("status", "active")
        created = (
            k["created_at"].strftime("%Y-%m-%d %H:%M:%S")
            if k.get("created_at")
            else ""
        )
        expires = (
            k["expires_at"].strftime("%Y-%m-%d")
            if k.get("expires_at")
            else "Never"
        )
        last_used = (
            k["last_used_at"].strftime("%Y-%m-%d")
            if k.get("last_used_at")
            else "Never"
        )
        created_by = (k.get("created_by") or "")[:12]
        print(
            f"{key_id:<6}{name:<22}{status:<10}{created:<21}"
            f"{expires:<12}{last_used:<12}{created_by}"
        )


def _cmd_keys_revoke(store, args):
    """Revoke an API key."""
    tenant_id = _resolve_tenant(store, args.tenant)

    keys = store.list_api_keys(tenant_id)
    key_exists = any(k["id"] == args.key_id for k in keys)
    if not key_exists:
        print(
            f"Error: Key ID {args.key_id} not found for tenant '{args.tenant}'",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        store.revoke_api_key(tenant_id, args.key_id)
    except Exception as exc:
        print(f"Error: Failed to revoke key ({exc})", file=sys.stderr)
        sys.exit(1)

    print(f"\nAPI key #{args.key_id} revoked (status changed to 'revoked')")
    print("All requests with this key will now fail with 401.")
    print()


def _cmd_keys_rotate(store, args):
    """Rotate an API key (revoke old, create new)."""
    tenant_id = _resolve_tenant(store, args.tenant)
    created_by = os.environ.get("USER", "cli")

    if args.key_name:
        keys = store.list_api_keys(tenant_id)
        key_exists = any(k["id"] == args.key_id for k in keys)
        if not key_exists:
            print(
                f"Error: Key ID {args.key_id} not found for tenant '{args.tenant}'",
                file=sys.stderr,
            )
            sys.exit(1)
        try:
            store.revoke_api_key(tenant_id, args.key_id)
            new_key_value, new_key_id = store.create_api_key(
                tenant_id=tenant_id,
                key_name=args.key_name,
                created_by=created_by,
            )
        except Exception as exc:
            print(f"Error: Failed to rotate key ({exc})", file=sys.stderr)
            sys.exit(1)
    else:
        try:
            new_key_value, new_key_id = store.rotate_api_key(
                tenant_id=tenant_id,
                key_id=args.key_id,
                created_by=created_by,
            )
        except ValueError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            sys.exit(1)
        except Exception as exc:
            print(f"Error: Failed to rotate key ({exc})", file=sys.stderr)
            sys.exit(1)

    print(f"\nAPI key rotated")
    print()
    print(f"  Old key:     #{args.key_id} (revoked)")
    print(f"  New key:     #{new_key_id}")
    print()
    print(f"  New API Key (shown once):")
    print(f"     {new_key_value}")
    print()
    print(f"  Usage in Databricks:")
    print(f'    API_KEY = "{new_key_value}"')
    print(f"    attestant.configure(api_key=API_KEY)")
    print()


def _dispatch_config(args, parent_parser):
    """Handle configuration management commands."""
    cmd = getattr(args, "config_command", None)

    if cmd == "show":
        _cmd_config_show(args)
    elif cmd == "test-db":
        _cmd_config_test_db(args)
    elif cmd == "version":
        _cmd_config_version()
    else:
        parent_parser.print_help()


def _cmd_config_show(args):
    """Show current Attestant configuration."""
    from . import __version__
    from .compliance_config import get_compliance_config

    config = get_compliance_config()
    config_dict = config.to_dict()

    if args.format == "json":
        print(json.dumps(config_dict, indent=2, default=str))
    else:
        print("=" * 60)
        print(f"Attestant Configuration")
        print("=" * 60)
        print()
        print(f"Version:           {__version__}")
        print(f"Initialized:       {config_dict['initialized']}")
        print(f"Audit Mode:        {config_dict['audit_mode']}")
        print(f"Database:          {'Configured' if config_dict['db_configured'] else 'Not configured'}")
        if config_dict["s3_bucket"]:
            print(f"S3 Bucket:         {config_dict['s3_bucket']}")
        print(f"Log Level:         {config_dict['log_level']}")
        print(f"Audit Logger:      {config_dict['audit_logger_type']}")
        print()
        print("Defaults:")
        defaults = config_dict["defaults"]
        print(f"  DI Threshold:    {defaults['di_threshold']} (80% rule)")
        print(f"  Protection Lvl:  {defaults['default_protection_level']} ({defaults['protection_level_name']})")
        print(f"  Retention:       {defaults['audit_retention_days']} days (7 years)")
        print(f"  Perf Threshold:  {defaults['performance_threshold_ms']}ms")
        print()
        print("Environment Variables:")
        print(f"  ATTESTANT_DB_CONNECTION  = {config.db_connection_string[:20] + '...' if config.db_connection_string else '(not set)'}")
        print(f"  ATTESTANT_AUDIT_MODE     = {os.environ.get('ATTESTANT_AUDIT_MODE', '(not set)')}")
        print(f"  ATTESTANT_S3_BUCKET      = {os.environ.get('ATTESTANT_S3_BUCKET', '(not set)')}")
        print(f"  ATTESTANT_LOG_LEVEL      = {os.environ.get('ATTESTANT_LOG_LEVEL', '(not set)')}")
        print()


def _cmd_config_test_db(args):
    """Test database connection."""
    import os

    dsn = args.dsn or os.environ.get("ATTESTANT_DB_CONNECTION")

    if not dsn:
        print("Error: No database connection string provided", file=sys.stderr)
        print("  Use --dsn flag or set ATTESTANT_DB_CONNECTION env var", file=sys.stderr)
        sys.exit(1)

    try:
        import psycopg2

        conn = psycopg2.connect(dsn, connect_timeout=5)
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT version();")
                version = cur.fetchone()[0]
                print("✓ Database connection successful")
                print(f"  PostgreSQL: {version.split(',')[0]}")
        finally:
            conn.close()
    except ImportError:
        print("Error: psycopg2 not installed", file=sys.stderr)
        print("  Install with: pip install psycopg2", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"✗ Database connection failed: {e}", file=sys.stderr)
        sys.exit(1)


def _cmd_config_version():
    """Show Attestant version and build info."""
    from . import __version__

    print(f"Attestant {__version__}")
    print()
    print("Compliance Stack:")
    print("  • ComplianceWrapper (SR 11-7, ECOA, EU AI Act)")
    print("  • ImmutableAuditLogger (write-once, hash-chained)")
    print("  • DisparateImpactAnalyzer (80% rule enforcement)")
    print("  • Zero-config auto-initialization")


def _dispatch_health(args):
    """Run platform health checks."""
    from .vendor.health_check import PlatformHealthCheck

    check = PlatformHealthCheck()

    if args.db:
        from .persistence.sqlite_storage import SQLiteStorage
        storage = SQLiteStorage(args.db)
        try:
            storage.connect()
            stats = storage.get_stats()
            print(f"Database: OK ({stats.get('nodes', 0)} nodes, "
                  f"{stats.get('edges', 0)} edges)")
            storage.disconnect()
        except Exception as e:
            print(f"Database: FAIL ({e})", file=sys.stderr)
            sys.exit(1)

    result = check.run_checks()
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
