"""
Zero-configuration auto-initialization for Attestant compliance stack.

This module provides automatic setup of compliance, fairness, and audit components
from environment variables. Once imported, users can use attestant.ComplianceWrapper
and other compliance features without explicit initialization.

Environment Variables:
    ATTESTANT_DB_CONNECTION: Aurora PostgreSQL DSN (optional, uses mock if not set)
    ATTESTANT_AUDIT_MODE: 'live', 'test', or 'mock' (default: 'mock' if no DB)
    ATTESTANT_S3_BUCKET: S3 bucket for audit archive (optional)
    ATTESTANT_LOG_LEVEL: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)

Example:
    import attestant

    model = load_model("model.pkl")
    wrapper = attestant.ComplianceWrapper(
        model=model,
        protected_columns=["race", "gender"],
    )

    predictions = wrapper.predict(X, protected_attributes)
"""

import os
import logging
from typing import Optional, Dict, Any
from threading import Lock
import sys

try:
    from .compliance_defaults import (
        ComplianceDefaults,
        AUDIT_MODES,
        LOG_LEVELS,
        DATABASE_DEFAULTS,
        FEATURE_FLAGS,
        DI_THRESHOLD_80_PERCENT_RULE,
    )
except ImportError:
    from attestant.compliance_defaults import (
        ComplianceDefaults,
        AUDIT_MODES,
        LOG_LEVELS,
        DATABASE_DEFAULTS,
        FEATURE_FLAGS,
        DI_THRESHOLD_80_PERCENT_RULE,
    )

logger = logging.getLogger(__name__)

# =============================================================================
# Singleton Configuration Instance
# =============================================================================

_config_instance: Optional["ComplianceConfig"] = None
_config_lock = Lock()


class MockAuditLogger:
    """
    In-memory mock audit logger for development/testing without a database.

    Does not require any database connection. All records are stored in memory
    and can be inspected for testing purposes.
    """

    def __init__(self):
        """Initialize mock audit logger."""
        self._predictions: list = []
        self._disparate_impacts: list = []
        self._evidence: list = []
        logger.info("MockAuditLogger initialized (in-memory, no database)")

    def log_prediction_batch(
        self,
        predictions: list,
        protected_attributes: Dict[str, Any],
        disparate_impact_results: Optional[Dict[str, Any]] = None,
        batch_id: Optional[str] = None,
    ) -> None:
        """
        Log a batch of predictions (mock implementation).

        Args:
            predictions: List of prediction results
            protected_attributes: Protected attribute values per sample
            disparate_impact_results: Optional DI analysis results
            batch_id: Optional batch identifier
        """
        self._predictions.extend(predictions)
        if disparate_impact_results:
            self._disparate_impacts.append(disparate_impact_results)
        logger.debug(f"MockAuditLogger: logged {len(predictions)} predictions")

    def log_disparate_impact_batch(
        self, di_metrics: list, batch_id: Optional[str] = None
    ) -> None:
        """Log disparate impact metrics (mock implementation)."""
        self._disparate_impacts.extend(di_metrics)
        logger.debug(f"MockAuditLogger: logged {len(di_metrics)} DI metrics")

    def log_evidence(
        self, evidence_type: str, evidence_data: Dict[str, Any]
    ) -> None:
        """Log testing evidence (mock implementation)."""
        self._evidence.append({"type": evidence_type, "data": evidence_data})
        logger.debug(f"MockAuditLogger: logged evidence type '{evidence_type}'")

    def verify_record_integrity(self, record_id: str) -> bool:
        """Verify record integrity (always True for mock)."""
        return True

    def get_immutability_status(self) -> Dict[str, Any]:
        """Get immutability status."""
        return {
            "immutable": True,
            "mode": "mock",
            "prediction_count": len(self._predictions),
            "disparate_impact_count": len(self._disparate_impacts),
            "evidence_count": len(self._evidence),
        }


class ComplianceConfig:
    """
    Singleton configuration for Attestant compliance stack.

    Manages:
    - Database connections (Aurora PostgreSQL or mock)
    - Audit logger initialization (live, test, or mock)
    - Disparate impact engine configuration
    - Logging setup
    - Feature flags
    """

    def __init__(self):
        """Initialize compliance configuration from environment."""
        self._initialized = False
        self._db_connection_pool = None
        self._audit_logger = None
        self._disparate_impact_engine = None
        self._mock_audit_logger = None

        # Load settings from environment
        self.db_connection_string: Optional[str] = os.environ.get(
            "ATTESTANT_DB_CONNECTION"
        )
        self.audit_mode: str = self._resolve_audit_mode()
        self.s3_bucket: Optional[str] = os.environ.get("ATTESTANT_S3_BUCKET")
        self.log_level: str = self._resolve_log_level()

        # Create defaults
        self.defaults = ComplianceDefaults()

        # Initialize logging
        self._setup_logging()

        # Initialize audit logger
        self._initialize_audit_logger()

        self._initialized = True
        logger.info(f"ComplianceConfig initialized (mode={self.audit_mode})")

    def _resolve_audit_mode(self) -> str:
        """
        Determine audit mode from environment or database availability.

        Priority:
        1. Explicit ATTESTANT_AUDIT_MODE env var
        2. If ATTESTANT_DB_CONNECTION set, use 'live'
        3. Otherwise use 'mock'
        """
        explicit_mode = os.environ.get("ATTESTANT_AUDIT_MODE", "").lower()
        if explicit_mode in AUDIT_MODES:
            return explicit_mode

        if self.db_connection_string:
            return "live"

        return "mock"

    def _resolve_log_level(self) -> str:
        """Get log level from environment, defaulting to INFO."""
        level = os.environ.get("ATTESTANT_LOG_LEVEL", "INFO").upper()
        if level in LOG_LEVELS:
            return level
        logger.warning(f"Invalid log level '{level}', defaulting to INFO")
        return "INFO"

    def _setup_logging(self) -> None:
        """Configure logging for attestant modules."""
        numeric_level = getattr(logging, self.log_level, logging.INFO)
        root_logger = logging.getLogger("attestant")
        root_logger.setLevel(numeric_level)

        if not root_logger.handlers:
            handler = logging.StreamHandler(sys.stderr)
            handler.setLevel(numeric_level)
            formatter = logging.Formatter(
                "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
            )
            handler.setFormatter(formatter)
            root_logger.addHandler(handler)

    def _initialize_audit_logger(self) -> None:
        """Initialize audit logger based on configuration."""
        if self.audit_mode == "mock":
            self._mock_audit_logger = MockAuditLogger()
        elif self.audit_mode in ("live", "test"):
            if not self.db_connection_string:
                logger.warning(
                    f"Audit mode '{self.audit_mode}' requires ATTESTANT_DB_CONNECTION. "
                    "Falling back to mock."
                )
                self._mock_audit_logger = MockAuditLogger()
                self.audit_mode = "mock"
            else:
                logger.info(
                    f"Audit logger will connect to database (mode={self.audit_mode})"
                )

    def get_audit_logger(self):
        """
        Get the active audit logger.

        Returns the real ImmutableAuditLogger if database is configured,
        otherwise returns a mock audit logger for testing.

        Returns:
            ImmutableAuditLogger or MockAuditLogger instance

        Raises:
            RuntimeError: If audit logger not properly initialized
        """
        if self._mock_audit_logger is not None:
            return self._mock_audit_logger

        if self._audit_logger is not None:
            return self._audit_logger

        if self.db_connection_string and self.audit_mode in ("live", "test"):
            try:
                from .governance.immutable_audit_logger import ImmutableAuditLogger

                conn_pool = self.get_database_connection()
                self._audit_logger = ImmutableAuditLogger(conn_pool)
                return self._audit_logger
            except Exception as e:
                logger.error(f"Failed to initialize real audit logger: {e}")
                logger.info("Falling back to mock audit logger")
                self._mock_audit_logger = MockAuditLogger()
                return self._mock_audit_logger

        self._mock_audit_logger = MockAuditLogger()
        return self._mock_audit_logger

    def get_database_connection(self):
        """
        Get database connection pool.

        Returns:
            psycopg2 ThreadedConnectionPool or None if not configured

        Raises:
            ValueError: If database connection string is invalid
        """
        if self._db_connection_pool is not None:
            return self._db_connection_pool

        if not self.db_connection_string:
            logger.debug("No database connection configured")
            return None

        try:
            import psycopg2
            from psycopg2 import pool

            self._db_connection_pool = pool.ThreadedConnectionPool(
                minconn=DATABASE_DEFAULTS["pool_size"],
                maxconn=DATABASE_DEFAULTS["pool_size"]
                + DATABASE_DEFAULTS["max_overflow"],
                dsn=self.db_connection_string,
            )
            logger.info("Database connection pool created")
            return self._db_connection_pool
        except ImportError:
            logger.error("psycopg2 not installed. Install with: pip install psycopg2")
            return None
        except Exception as e:
            logger.error(f"Failed to create database connection pool: {e}")
            return None

    def get_disparate_impact_threshold(self) -> float:
        """
        Get disparate impact threshold (80% rule).

        Returns:
            Threshold value (default 0.80)
        """
        return self.defaults.di_threshold

    def get_performance_threshold_ms(self) -> int:
        """
        Get performance threshold for predictions in milliseconds.

        Returns:
            Threshold in milliseconds
        """
        return self.defaults.performance_threshold_ms

    def is_feature_enabled(self, feature_name: str) -> bool:
        """
        Check if a feature is enabled.

        Args:
            feature_name: Name of feature to check

        Returns:
            True if feature is enabled, False otherwise
        """
        return FEATURE_FLAGS.get(feature_name, False)

    def to_dict(self) -> Dict[str, Any]:
        """
        Export configuration to dictionary.

        Returns:
            Configuration dictionary (secrets redacted)
        """
        return {
            "initialized": self._initialized,
            "audit_mode": self.audit_mode,
            "db_configured": self.db_connection_string is not None,
            "s3_bucket": self.s3_bucket,
            "log_level": self.log_level,
            "defaults": self.defaults.to_dict(),
            "audit_logger_type": (
                "MockAuditLogger"
                if self._mock_audit_logger
                else "ImmutableAuditLogger"
            ),
        }


def get_compliance_config() -> ComplianceConfig:
    """
    Get or create singleton compliance configuration.

    Returns:
        ComplianceConfig instance
    """
    global _config_instance
    if _config_instance is None:
        with _config_lock:
            if _config_instance is None:
                _config_instance = ComplianceConfig()
    return _config_instance


def reset_compliance_config() -> None:
    """Reset compliance configuration (useful for testing)."""
    global _config_instance
    with _config_lock:
        _config_instance = None


def _auto_initialize_compliance() -> None:
    """Auto-initialize compliance configuration on module import."""
    try:
        get_compliance_config()
    except Exception as e:
        logger.warning(f"Failed to auto-initialize compliance config: {e}")
