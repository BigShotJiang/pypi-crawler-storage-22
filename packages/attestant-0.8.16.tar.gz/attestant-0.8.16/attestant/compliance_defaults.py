"""
Default configuration for compliance and fairness systems.

These defaults follow legal best practices for regulated ML:
- Disparate impact threshold: 80% (four-fifths rule per EEOC/ECOA)
- Audit retention: 7 years (OCC/Federal Reserve regulatory standard)
- Protection level 1: Do Not Use (completely blocked)
- Protection level 2: Can Be Used (monitored for disparate impact)
"""

from typing import Dict, Any
from dataclasses import dataclass

# =============================================================================
# Disparate Impact Defaults
# =============================================================================

DI_THRESHOLD_80_PERCENT_RULE = 0.80

DISPARATE_IMPACT_DEFAULTS: Dict[str, Any] = {
    "threshold": DI_THRESHOLD_80_PERCENT_RULE,
    "min_sample_size": 30,
    "confidence_level": 0.95,
    "use_fisher_exact": False,
    "protected_attributes": [],
}

# =============================================================================
# Protection Levels
# =============================================================================

PROTECTION_LEVELS = {
    1: "DO_NOT_USE",
    2: "CAN_BE_USED_WITH_MONITORING",
}

DEFAULT_PROTECTION_LEVEL_BY_COLUMN_TYPE: Dict[str, int] = {
    "race": 1,
    "ethnicity": 1,
    "national_origin": 1,
    "color": 1,
    "gender": 2,
    "sex": 2,
    "age": 2,
    "age_group": 2,
    "religion": 1,
    "disability": 1,
    "veteran_status": 1,
    "genetic_information": 1,
    "sexual_orientation": 1,
    "gender_identity": 1,
}

DEFAULT_PROTECTION_LEVEL_FALLBACK = 2

# =============================================================================
# Audit and Compliance Retention
# =============================================================================

AUDIT_RETENTION_DAYS = 7 * 365

AUDIT_RETENTION_DEFAULTS: Dict[str, Any] = {
    "retention_days": AUDIT_RETENTION_DAYS,
    "archive_after_days": 365,
    "archive_location": "s3://attestant-archive",
}

# =============================================================================
# Audit Mode Configurations
# =============================================================================

AUDIT_MODES = {
    "live": {
        "description": "Write to production database (Aurora PostgreSQL)",
        "requires_db_connection": True,
        "immutability_enforced": True,
        "hash_chain_verified": True,
    },
    "test": {
        "description": "Write to test database (SQLite or test Aurora)",
        "requires_db_connection": True,
        "immutability_enforced": True,
        "hash_chain_verified": True,
    },
    "mock": {
        "description": "In-memory mock (no database required, testing only)",
        "requires_db_connection": False,
        "immutability_enforced": True,
        "hash_chain_verified": True,
    },
}

# =============================================================================
# Performance Thresholds
# =============================================================================

PERFORMANCE_THRESHOLDS: Dict[str, Any] = {
    "prediction_latency_ms": 100,
    "batch_prediction_latency_ms": 50,
    "audit_log_latency_ms": 10,
    "disparate_impact_calculation_ms": 500,
}

# =============================================================================
# Model Configuration Defaults
# =============================================================================

MODEL_DEFAULTS: Dict[str, Any] = {
    "max_model_age_days": 365,
    "min_validation_dataset_size": 1000,
    "min_backtesting_samples": 100,
    "require_model_card": True,
    "require_fairness_testing": True,
}

# =============================================================================
# Logging
# =============================================================================

LOG_LEVELS = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
DEFAULT_LOG_LEVEL = "INFO"

LOGGING_DEFAULTS: Dict[str, Any] = {
    "level": DEFAULT_LOG_LEVEL,
    "format": "json",
    "include_timestamp": True,
}

# =============================================================================
# Database Connection Defaults
# =============================================================================

DATABASE_DEFAULTS: Dict[str, Any] = {
    "pool_size": 10,
    "max_overflow": 20,
    "pool_timeout": 30,
    "pool_recycle": 3600,
    "isolation_level": "SERIALIZABLE",
}

# =============================================================================
# Feature Defaults
# =============================================================================

FEATURE_FLAGS: Dict[str, bool] = {
    "auto_init_compliance_wrapper": True,
    "auto_init_audit_logger": True,
    "auto_init_disparate_impact": True,
    "enable_disparate_impact_monitoring": True,
    "enable_audit_trail": True,
}


@dataclass
class ComplianceDefaults:
    """Immutable defaults for compliance configuration."""

    di_threshold: float = DI_THRESHOLD_80_PERCENT_RULE
    default_protection_level: int = DEFAULT_PROTECTION_LEVEL_FALLBACK
    audit_retention_days: int = AUDIT_RETENTION_DAYS
    log_level: str = DEFAULT_LOG_LEVEL
    performance_threshold_ms: int = PERFORMANCE_THRESHOLDS["prediction_latency_ms"]

    @classmethod
    def from_config(cls, config_dict: Dict[str, Any]) -> "ComplianceDefaults":
        """Create defaults from configuration dictionary."""
        return cls(
            di_threshold=config_dict.get("di_threshold", DI_THRESHOLD_80_PERCENT_RULE),
            default_protection_level=config_dict.get(
                "default_protection_level", DEFAULT_PROTECTION_LEVEL_FALLBACK
            ),
            audit_retention_days=config_dict.get(
                "audit_retention_days", AUDIT_RETENTION_DAYS
            ),
            log_level=config_dict.get("log_level", DEFAULT_LOG_LEVEL),
            performance_threshold_ms=config_dict.get(
                "performance_threshold_ms",
                PERFORMANCE_THRESHOLDS["prediction_latency_ms"],
            ),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Export defaults to dictionary."""
        return {
            "di_threshold": self.di_threshold,
            "default_protection_level": self.default_protection_level,
            "protection_level_name": PROTECTION_LEVELS.get(
                self.default_protection_level, "UNKNOWN"
            ),
            "audit_retention_days": self.audit_retention_days,
            "log_level": self.log_level,
            "performance_threshold_ms": self.performance_threshold_ms,
        }


def get_protection_level_for_column(column_name: str) -> int:
    """
    Get default protection level for a column by name.

    Matches common protected attribute names. Falls back to DEFAULT_PROTECTION_LEVEL_FALLBACK.

    Args:
        column_name: Name of the column (e.g., "race", "gender", "age")

    Returns:
        Protection level (1 or 2)
    """
    col_lower = column_name.lower().strip()
    return DEFAULT_PROTECTION_LEVEL_BY_COLUMN_TYPE.get(
        col_lower, DEFAULT_PROTECTION_LEVEL_FALLBACK
    )
