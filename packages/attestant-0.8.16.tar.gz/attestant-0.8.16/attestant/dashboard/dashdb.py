"""
Aurora PostgreSQL read-optimized data store for Attestant dashboards.

Designed for heavy dashboard reads with:
- Separate reader/writer connection pools (Aurora read replicas)
- Denormalized snapshot tables refreshed periodically
- Tenant isolation for multi-client deployments
- Connection pooling via psycopg2 ThreadedConnectionPool

Schema is optimized for the two dashboard use cases:
1. Client dashboard: bank CRO sees their own compliance posture
2. Admin dashboard: founder monitors all tenants

Usage::

    store = DashboardStore(
        writer_dsn="postgresql://writer.cluster.rds.amazonaws.com/proveit",
        reader_dsn="postgresql://reader.cluster-ro.rds.amazonaws.com/proveit",
    )
    store.connect()
    store.ensure_schema()

    # Write path (goes to Aurora primary)
    store.upsert_tenant_snapshot(tenant_id, snapshot_data)

    # Read path (goes to Aurora read replica)
    data = store.get_tenant_overview(tenant_id)
"""

import hashlib
import json
import logging
import secrets
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class _NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy types."""

    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)


def _json_dumps(obj) -> str:
    """Serialize to JSON with numpy support."""
    return json.dumps(obj, cls=_NumpyEncoder)

# ---------------------------------------------------------------------------
# Schema DDL — executed once via ensure_schema()
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
-- Tenants (bank clients)
CREATE TABLE IF NOT EXISTS tenants (
    tenant_id       TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    tier            TEXT NOT NULL DEFAULT 'professional',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    config          JSONB DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_tenants_active ON tenants (active);

-- Compliance score snapshots (denormalized for fast reads)
CREATE TABLE IF NOT EXISTS compliance_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    score           REAL NOT NULL,
    grade           TEXT NOT NULL,
    engines_evaluated INTEGER NOT NULL DEFAULT 0,
    critical_findings INTEGER NOT NULL DEFAULT 0,
    warning_findings  INTEGER NOT NULL DEFAULT 0,
    total_findings  INTEGER NOT NULL DEFAULT 0,
    top_risks       JSONB DEFAULT '[]',
    breakdowns      JSONB DEFAULT '[]',
    bonuses         JSONB DEFAULT '{}',
    trend           TEXT,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_comp_snap_tenant
    ON compliance_snapshots (tenant_id, snapshot_at DESC);

-- Model inventory snapshots (denormalized)
CREATE TABLE IF NOT EXISTS model_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    name            TEXT NOT NULL,
    version         TEXT,
    tier            INTEGER NOT NULL DEFAULT 3,
    status          TEXT NOT NULL DEFAULT 'development',
    domain          TEXT,
    owner           TEXT,
    compliance_score REAL,
    last_validated  TIMESTAMPTZ,
    last_monitored  TIMESTAMPTZ,
    validation_overdue BOOLEAN DEFAULT FALSE,
    monitoring_overdue BOOLEAN DEFAULT FALSE,
    finding_count   INTEGER DEFAULT 0,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_model_snap_tenant
    ON model_snapshots (tenant_id, snapshot_at DESC);
CREATE INDEX IF NOT EXISTS idx_model_snap_status
    ON model_snapshots (tenant_id, status);

-- Fairness analysis results (per model, per run)
CREATE TABLE IF NOT EXISTS fairness_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    has_disparate_impact BOOLEAN DEFAULT FALSE,
    worst_ratio     REAL,
    worst_group     TEXT,
    p_value         REAL,
    statistically_significant BOOLEAN DEFAULT FALSE,
    protected_attributes JSONB DEFAULT '[]',
    sample_size_warnings JSONB DEFAULT '[]',
    details         JSONB DEFAULT '{}',
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fair_snap_tenant
    ON fairness_snapshots (tenant_id, snapshot_at DESC);

-- Certification status
CREATE TABLE IF NOT EXISTS certification_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    cert_type       TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'not_started',
    issued_date     DATE,
    expiry_date     DATE,
    days_until_expiry INTEGER,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cert_snap_tenant
    ON certification_snapshots (tenant_id, snapshot_at DESC);

-- Alert / finding log
CREATE TABLE IF NOT EXISTS alert_log (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    severity        TEXT NOT NULL,
    source          TEXT NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT,
    model_id        TEXT,
    regulation      TEXT,
    resolved        BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_alert_tenant
    ON alert_log (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alert_unresolved
    ON alert_log (tenant_id, resolved, severity);

-- Pipeline execution stats (deduplicated by model version)
CREATE TABLE IF NOT EXISTS pipeline_stats (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    pipeline_name   TEXT,
    display_name    TEXT,
    model_hash      TEXT,
    status          TEXT NOT NULL,
    node_count      INTEGER DEFAULT 0,
    edge_count      INTEGER DEFAULT 0,
    case_count      INTEGER DEFAULT 0,
    provenance_pipeline_id INTEGER,
    first_seen_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_used_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, pipeline_name, model_hash)
);

CREATE INDEX IF NOT EXISTS idx_pipeline_tenant
    ON pipeline_stats (tenant_id, last_used_at DESC);

CREATE INDEX IF NOT EXISTS idx_pipeline_prov
    ON pipeline_stats (tenant_id, provenance_pipeline_id)
    WHERE provenance_pipeline_id IS NOT NULL;

-- Individual cases processed by pipelines
CREATE TABLE IF NOT EXISTS pipeline_row_results (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    pipeline_id     BIGINT NOT NULL REFERENCES pipeline_stats(id) ON DELETE CASCADE,
    row_index       INTEGER NOT NULL,
    decision        TEXT,
    score           REAL,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pipeline_rows
    ON pipeline_row_results (tenant_id, pipeline_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_pipeline_rows_timestamp
    ON pipeline_row_results (tenant_id, timestamp DESC);

-- System metrics (for admin dashboard)
CREATE TABLE IF NOT EXISTS system_metrics (
    id              BIGSERIAL PRIMARY KEY,
    metric_name     TEXT NOT NULL,
    metric_value    REAL NOT NULL,
    labels          JSONB DEFAULT '{}',
    recorded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sys_metrics
    ON system_metrics (metric_name, recorded_at DESC);

CREATE TABLE IF NOT EXISTS dashboard_users (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL,
    email           TEXT NOT NULL,
    password_hash   TEXT,
    display_name    TEXT NOT NULL DEFAULT '',
    role            TEXT NOT NULL DEFAULT 'analyst',
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    invited_by      TEXT,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_tenant
    ON dashboard_users (tenant_id, active);
CREATE INDEX IF NOT EXISTS idx_users_email
    ON dashboard_users (email);

CREATE TABLE IF NOT EXISTS user_permissions (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   TEXT NOT NULL,
    user_id     BIGINT NOT NULL REFERENCES dashboard_users(id) ON DELETE CASCADE,
    permission  TEXT NOT NULL,
    granted     BOOLEAN NOT NULL DEFAULT TRUE,
    granted_by  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, user_id, permission)
);
CREATE INDEX IF NOT EXISTS idx_user_perms_tenant_user ON user_permissions (tenant_id, user_id);

CREATE TABLE IF NOT EXISTS api_keys (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    key_hash        TEXT NOT NULL UNIQUE,
    key_name        TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'active',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ,
    last_used_at    TIMESTAMPTZ,
    created_by      TEXT
);

CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys (tenant_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys (key_hash);
CREATE INDEX IF NOT EXISTS idx_api_keys_status ON api_keys (tenant_id, status);

-- Provenance row values (for detailed lineage tracking)
CREATE TABLE IF NOT EXISTS row_values (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    pipeline_id     INTEGER NOT NULL,
    row_index       INTEGER NOT NULL,
    fingerprint     TEXT,
    node_operation  TEXT,
    column_name     TEXT,
    value           REAL,
    text_value      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_row_values_tenant
    ON row_values (tenant_id, pipeline_id, row_index);
CREATE INDEX IF NOT EXISTS idx_row_values_fingerprint
    ON row_values (tenant_id, fingerprint);
"""

ALL_PERMISSIONS = [
    "view_compliance",
    "view_fairness",
    "view_models",
    "view_pipelines",
    "view_alerts",
    "view_reports",
    "manage_users",
    "manage_permissions",
    "export_data",
]

ROLE_DEFAULTS = {
    "admin": {
        "view_compliance": True,
        "view_fairness": True,
        "view_models": True,
        "view_pipelines": True,
        "view_alerts": True,
        "view_reports": True,
        "manage_users": True,
        "manage_permissions": True,
        "export_data": True,
    },
    "manager": {
        "view_compliance": True,
        "view_fairness": True,
        "view_models": True,
        "view_pipelines": True,
        "view_alerts": True,
        "view_reports": True,
        "manage_users": True,
        "manage_permissions": False,
        "export_data": True,
    },
    "analyst": {
        "view_compliance": True,
        "view_fairness": False,
        "view_models": True,
        "view_pipelines": False,
        "view_alerts": True,
        "view_reports": False,
        "manage_users": False,
        "manage_permissions": False,
        "export_data": False,
    },
}


class DashboardStore:
    """Aurora PostgreSQL read-optimized store for dashboards.

    Supports separate writer and reader connection strings for
    Aurora read replicas.  Falls back to writer DSN for reads
    if no reader DSN is provided (single-instance mode).
    """

    def __init__(
        self,
        writer_dsn: str,
        reader_dsn: Optional[str] = None,
        min_conn: int = 2,
        max_conn: int = 10,
    ):
        self.writer_dsn = writer_dsn
        self.reader_dsn = reader_dsn or writer_dsn
        self.min_conn = min_conn
        self.max_conn = max_conn
        self._writer_pool = None
        self._reader_pool = None

    def connect(self) -> None:
        """Create connection pools for writer and reader endpoints."""
        from psycopg2 import pool as pg_pool
        from psycopg2.extras import register_default_jsonb

        register_default_jsonb()

        self._writer_pool = pg_pool.ThreadedConnectionPool(
            self.min_conn, self.max_conn, self.writer_dsn,
        )
        if self.reader_dsn != self.writer_dsn:
            self._reader_pool = pg_pool.ThreadedConnectionPool(
                self.min_conn, self.max_conn, self.reader_dsn,
            )
        else:
            self._reader_pool = self._writer_pool

        logger.info("DashboardStore connected (writer + reader pools)")

    def disconnect(self) -> None:
        """Close all connection pools."""
        if self._writer_pool is not None:
            self._writer_pool.closeall()
        if self._reader_pool is not None and self._reader_pool is not self._writer_pool:
            self._reader_pool.closeall()
        self._writer_pool = None
        self._reader_pool = None

    def ensure_schema(self) -> None:
        """Create tables if they don't exist (idempotent)."""
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(_SCHEMA_SQL)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

        try:
            conn2 = self._writer_pool.getconn()
            with conn2.cursor() as cur:
                cur.execute(
                    "ALTER TABLE pipeline_stats "
                    "ADD COLUMN IF NOT EXISTS provenance_pipeline_id INTEGER"
                )
            conn2.commit()
            self._writer_pool.putconn(conn2)
        except Exception:
            try:
                conn2.rollback()
                self._writer_pool.putconn(conn2)
            except Exception:
                pass

        try:
            tenants = self._read_dicts(
                "SELECT tenant_id FROM tenants WHERE active = TRUE"
            )
            for t in tenants:
                count = self.backfill_user_permissions(t["tenant_id"])
                if count > 0:
                    logger.info(
                        "Backfilled permissions for %d user(s) in tenant %s",
                        count, t["tenant_id"],
                    )
        except Exception as e:
            logger.warning("Permission backfill skipped: %s", e)

    # -- Writer methods (Aurora primary) ------------------------------------

    @staticmethod
    def _adapt_params(params: tuple) -> tuple:
        """Convert numpy types and dicts to native Python for psycopg2."""
        adapted = []
        for p in params:
            if isinstance(p, (np.integer,)):
                adapted.append(int(p))
            elif isinstance(p, (np.floating,)):
                adapted.append(float(p))
            elif isinstance(p, (np.bool_,)):
                adapted.append(bool(p))
            elif isinstance(p, (dict, list)):
                adapted.append(_json_dumps(p))
            elif isinstance(p, np.ndarray):
                adapted.append(_json_dumps(p.tolist()))
            else:
                adapted.append(p)
        return tuple(adapted)

    def _write(self, sql: str, params: tuple = ()) -> None:
        params = self._adapt_params(params)
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

    def _write_returning(self, sql: str, params: tuple = ()) -> Any:
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                result = cur.fetchone()
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

    # -- Reader methods (Aurora read replica) --------------------------------

    def _read_one(self, sql: str, params: tuple = ()) -> Optional[tuple]:
        conn = self._reader_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchone()
        finally:
            self._reader_pool.putconn(conn)

    def _read_all(self, sql: str, params: tuple = ()) -> List[tuple]:
        conn = self._reader_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchall()
        finally:
            self._reader_pool.putconn(conn)

    def _read_dicts(self, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
        conn = self._reader_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                cols = [desc[0] for desc in cur.description]
                return [dict(zip(cols, row)) for row in cur.fetchall()]
        finally:
            self._reader_pool.putconn(conn)

    # -- Tenant management ---------------------------------------------------

    def upsert_tenant(self, tenant_id: str, name: str, tier: str = "professional",
                      config: Optional[Dict[str, Any]] = None) -> None:
        cfg = _json_dumps(config or {})
        self._write(
            """INSERT INTO tenants (tenant_id, name, tier, config)
               VALUES (%s, %s, %s, %s)
               ON CONFLICT (tenant_id) DO UPDATE
               SET name = EXCLUDED.name, tier = EXCLUDED.tier,
                   config = EXCLUDED.config""",
            (tenant_id, name, tier, cfg),
        )

    def get_tenant(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            "SELECT * FROM tenants WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_tenant_config(self, tenant_id: str) -> Dict[str, Any]:
        rows = self._read_dicts(
            "SELECT config FROM tenants WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        if not rows:
            return {}
        raw = rows[0].get("config", {})
        if isinstance(raw, str):
            return json.loads(raw)
        return raw or {}

    def get_all_tenants(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT * FROM tenants WHERE active = TRUE ORDER BY name"
        )

    # -- Compliance snapshots ------------------------------------------------

    def insert_compliance_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO compliance_snapshots
               (tenant_id, score, grade, engines_evaluated, critical_findings,
                warning_findings, total_findings, top_risks, breakdowns, bonuses, trend)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                tenant_id,
                data["score"], data["grade"], data.get("engines_evaluated", 0),
                data.get("critical_findings", 0), data.get("warning_findings", 0),
                data.get("total_findings", 0),
                _json_dumps(data.get("top_risks", [])),
                _json_dumps(data.get("breakdowns", [])),
                _json_dumps(data.get("bonuses_applied", {})),
                data.get("trend"),
            ),
        )

    def get_latest_compliance(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM compliance_snapshots
               WHERE tenant_id = %s ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_compliance_history(self, tenant_id: str, limit: int = 30) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT score, grade, total_findings, critical_findings,
                      snapshot_at
               FROM compliance_snapshots
               WHERE tenant_id = %s ORDER BY snapshot_at DESC LIMIT %s""",
            (tenant_id, limit),
        )

    # -- Model snapshots -----------------------------------------------------

    def upsert_model_snapshot(self, tenant_id: str, model: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO model_snapshots
               (tenant_id, model_id, name, version, tier, status, domain, owner,
                compliance_score, last_validated, last_monitored,
                validation_overdue, monitoring_overdue, finding_count)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, model["model_id"], model["name"],
                model.get("version"), model.get("tier", 3),
                model.get("status", "development"), model.get("domain"),
                model.get("owner"), model.get("compliance_score"),
                model.get("last_validated"), model.get("last_monitored"),
                model.get("validation_overdue", False),
                model.get("monitoring_overdue", False),
                model.get("finding_count", 0),
            ),
        )

    def get_models(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (model_id)
                      model_id, name, version, tier, status, domain, owner,
                      compliance_score, last_validated, last_monitored,
                      validation_overdue, monitoring_overdue, finding_count,
                      snapshot_at
               FROM model_snapshots
               WHERE tenant_id = %s
               ORDER BY model_id, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Fairness snapshots --------------------------------------------------

    def insert_fairness_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO fairness_snapshots
               (tenant_id, model_id, has_disparate_impact, worst_ratio,
                worst_group, p_value, statistically_significant,
                protected_attributes, sample_size_warnings, details)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, data["model_id"],
                data.get("has_disparate_impact", False),
                data.get("worst_ratio"), data.get("worst_group"),
                data.get("p_value"), data.get("statistically_significant", False),
                _json_dumps(data.get("protected_attributes", [])),
                _json_dumps(data.get("sample_size_warnings", [])),
                _json_dumps(data.get("details", {})),
            ),
        )

    def get_latest_fairness(self, tenant_id: str, model_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM fairness_snapshots
               WHERE tenant_id = %s AND model_id = %s
               ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id, model_id),
        )
        return rows[0] if rows else None

    def get_all_fairness(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (model_id) *
               FROM fairness_snapshots
               WHERE tenant_id = %s
               ORDER BY model_id, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Certifications ------------------------------------------------------

    def upsert_certification(self, tenant_id: str, cert: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO certification_snapshots
               (tenant_id, cert_type, status, issued_date, expiry_date, days_until_expiry)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, cert["cert_type"], cert.get("status", "not_started"),
                cert.get("issued_date"), cert.get("expiry_date"),
                cert.get("days_until_expiry"),
            ),
        )

    def get_certifications(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (cert_type)
                      cert_type, status, issued_date, expiry_date,
                      days_until_expiry, snapshot_at
               FROM certification_snapshots
               WHERE tenant_id = %s
               ORDER BY cert_type, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Alert log -----------------------------------------------------------

    def insert_alert(self, tenant_id: str, alert: Dict[str, Any]) -> int:
        row = self._write_returning(
            """INSERT INTO alert_log
               (tenant_id, severity, source, title, description, model_id, regulation)
               VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id""",
            (
                tenant_id, alert["severity"], alert["source"],
                alert["title"], alert.get("description"),
                alert.get("model_id"), alert.get("regulation"),
            ),
        )
        return row[0] if row else 0

    def get_alerts(self, tenant_id: str, unresolved_only: bool = True,
                   limit: int = 50) -> List[Dict[str, Any]]:
        if unresolved_only:
            return self._read_dicts(
                """SELECT * FROM alert_log
                   WHERE tenant_id = %s AND resolved = FALSE
                   ORDER BY CASE severity
                       WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
                   END, created_at DESC LIMIT %s""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT * FROM alert_log WHERE tenant_id = %s
               ORDER BY created_at DESC LIMIT %s""",
            (tenant_id, limit),
        )

    def resolve_alert(self, alert_id: int) -> None:
        self._write(
            "UPDATE alert_log SET resolved = TRUE, resolved_at = NOW() WHERE id = %s",
            (alert_id,),
        )

    # -- Provenance row values -----------------------------------------------

    def insert_row_values(self, tenant_id: str, values: List[Dict[str, Any]]) -> None:
        """Batch insert provenance row values."""
        if not values:
            return

        # Batch insert using executemany
        for v in values:
            self._write(
                """INSERT INTO row_values
                   (tenant_id, pipeline_id, row_index, fingerprint, node_operation,
                    column_name, value, text_value)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    v.get("pipeline_id"),
                    v.get("row_index"),
                    v.get("fingerprint"),
                    v.get("node_operation"),
                    v.get("column_name"),
                    v.get("value"),
                    v.get("text_value"),
                ),
            )

    def get_row_values(self, tenant_id: str, pipeline_id: int,
                       row_index: int) -> List[Dict[str, Any]]:
        """Get all provenance values for a specific row."""
        return self._read_dicts(
            """SELECT pipeline_id, row_index, fingerprint, node_operation,
                      column_name, value, text_value, created_at
               FROM row_values
               WHERE tenant_id = %s AND pipeline_id = %s AND row_index = %s
               ORDER BY created_at""",
            (tenant_id, pipeline_id, row_index),
        )

    # -- Pipeline stats (admin) ----------------------------------------------

    def insert_pipeline_stat(self, tenant_id: str, stat: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO pipeline_stats
               (tenant_id, pipeline_name, status, node_count, edge_count,
                duration_ms, provenance_pipeline_id, completed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, stat.get("pipeline_name"), stat["status"],
                stat.get("node_count", 0), stat.get("edge_count", 0),
                stat.get("duration_ms"), stat.get("provenance_pipeline_id"),
                stat.get("completed_at"),
            ),
        )

    def get_pipeline_stats(self, tenant_id: Optional[str] = None,
                           limit: int = 100) -> List[Dict[str, Any]]:
        if tenant_id:
            return self._read_dicts(
                """SELECT id AS pipeline_id, tenant_id, pipeline_name, display_name, model_hash,
                          status, node_count, edge_count, case_count, last_used_at, first_seen_at
                   FROM pipeline_stats WHERE tenant_id = %s
                   ORDER BY last_used_at DESC LIMIT %s""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT id AS pipeline_id, tenant_id, pipeline_name, display_name, model_hash,
                      status, node_count, edge_count, case_count, last_used_at, first_seen_at
               FROM pipeline_stats ORDER BY last_used_at DESC LIMIT %s""",
            (limit,),
        )

    def update_pipeline_display_name(self, tenant_id: str, pipeline_id: int,
                                      display_name: str) -> bool:
        self._write(
            """UPDATE pipeline_stats SET display_name = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (display_name, pipeline_id, tenant_id),
        )
        return True

    def insert_or_update_pipeline(self, tenant_id: str, pipeline_name: str,
                                   display_name: str, model_hash: str,
                                   status: str = "completed",
                                   node_count: int = 0,
                                   edge_count: int = 0) -> int:
        """Insert or update a pipeline. Returns pipeline_id."""
        result = self._read_dict(
            """INSERT INTO pipeline_stats
               (tenant_id, pipeline_name, display_name, model_hash, status,
                node_count, edge_count, case_count, first_seen_at, last_used_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, 0, NOW(), NOW())
               ON CONFLICT (tenant_id, pipeline_name, model_hash)
               DO UPDATE SET last_used_at = NOW(), updated_at = NOW()
               RETURNING id""",
            (tenant_id, pipeline_name, display_name, model_hash, status,
             node_count, edge_count),
        )
        return result["id"] if result else None

    def add_pipeline_row_result(self, tenant_id: str, pipeline_id: int,
                                 row_index: int, decision: Optional[str] = None,
                                 score: Optional[float] = None) -> None:
        """Record an individual case result for a pipeline."""
        self._write(
            """INSERT INTO pipeline_row_results
               (tenant_id, pipeline_id, row_index, decision, score, timestamp)
               VALUES (%s, %s, %s, %s, %s, NOW())""",
            (tenant_id, pipeline_id, row_index, decision, score),
        )
        self._write(
            """UPDATE pipeline_stats SET case_count = case_count + 1
               WHERE id = %s AND tenant_id = %s""",
            (pipeline_id, tenant_id),
        )

    def get_pipeline_row_results(self, tenant_id: str, pipeline_id: int,
                                  limit: int = 100) -> List[Dict[str, Any]]:
        """Get all individual case results for a pipeline."""
        return self._read_dicts(
            """SELECT row_index, decision, score, timestamp
               FROM pipeline_row_results
               WHERE tenant_id = %s AND pipeline_id = %s
               ORDER BY timestamp DESC LIMIT %s""",
            (tenant_id, pipeline_id, limit),
        )

    # -- System metrics (admin) ----------------------------------------------

    def record_metric(self, name: str, value: float,
                      labels: Optional[Dict[str, str]] = None) -> None:
        self._write(
            """INSERT INTO system_metrics (metric_name, metric_value, labels)
               VALUES (%s, %s, %s)""",
            (name, value, _json_dumps(labels or {})),
        )

    def get_latest_metrics(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (metric_name)
                      metric_name, metric_value, labels, recorded_at
               FROM system_metrics ORDER BY metric_name, recorded_at DESC"""
        )

    # -- Admin aggregates (read-heavy, hits read replica) --------------------

    def admin_tenant_summary(self) -> List[Dict[str, Any]]:
        """Aggregate summary for admin dashboard — one row per tenant."""
        return self._read_dicts("""
            SELECT
                t.tenant_id, t.name, t.tier, t.created_at,
                cs.score AS latest_score, cs.grade AS latest_grade,
                cs.critical_findings, cs.warning_findings,
                cs.trend,
                (SELECT COUNT(*) FROM model_snapshots ms
                 WHERE ms.tenant_id = t.tenant_id
                   AND ms.snapshot_at = (SELECT MAX(snapshot_at) FROM model_snapshots
                                         WHERE tenant_id = t.tenant_id)
                ) AS model_count,
                (SELECT COUNT(*) FROM alert_log a
                 WHERE a.tenant_id = t.tenant_id AND a.resolved = FALSE
                ) AS open_alerts,
                (SELECT COUNT(*) FROM pipeline_stats ps
                 WHERE ps.tenant_id = t.tenant_id
                   AND ps.started_at > NOW() - INTERVAL '24 hours'
                ) AS pipelines_24h
            FROM tenants t
            LEFT JOIN LATERAL (
                SELECT score, grade, critical_findings, warning_findings, trend
                FROM compliance_snapshots
                WHERE tenant_id = t.tenant_id
                ORDER BY snapshot_at DESC LIMIT 1
            ) cs ON TRUE
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY cs.score ASC NULLS LAST
        """)

    def admin_system_health(self) -> Dict[str, Any]:
        """System-wide health metrics for admin dashboard."""
        totals = self._read_one("""
            SELECT
                (SELECT COUNT(*) FROM tenants WHERE active = TRUE AND tenant_id != '_platform_admin'),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = FALSE AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats
                 WHERE started_at > NOW() - INTERVAL '24 hours' AND tenant_id != '_platform_admin'),
                (SELECT AVG(score) FROM (
                    SELECT DISTINCT ON (tenant_id) score
                    FROM compliance_snapshots
                    WHERE tenant_id != '_platform_admin'
                    ORDER BY tenant_id, snapshot_at DESC
                ) recent),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = FALSE AND severity = 'critical' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'completed' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'failed' AND tenant_id != '_platform_admin'),
                (SELECT AVG(duration_ms) FROM pipeline_stats WHERE status = 'completed' AND duration_ms IS NOT NULL AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM alert_log WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = TRUE AND tenant_id != '_platform_admin'),
                (SELECT started_at FROM pipeline_stats WHERE tenant_id != '_platform_admin' ORDER BY started_at DESC LIMIT 1),
                (SELECT snapshot_at FROM compliance_snapshots WHERE tenant_id != '_platform_admin' ORDER BY snapshot_at DESC LIMIT 1),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE status = 'production' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE finding_count > 0 AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM fairness_snapshots WHERE has_disparate_impact = TRUE AND statistically_significant = TRUE),
                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT ON (tenant_id) score
                    FROM compliance_snapshots
                    ORDER BY tenant_id, snapshot_at DESC
                ) sub WHERE score < 60)
        """)
        if not totals:
            return {}

        tenant_count = totals[0] or 0
        total_models = totals[1] or 0
        open_alerts = totals[2] or 0
        pipelines_24h = totals[3] or 0
        avg_score = totals[4]
        critical_alerts = totals[5] or 0
        p_total = totals[6] or 0
        p_completed = totals[7] or 0
        p_failed = totals[8] or 0
        avg_dur = totals[9]
        t_alerts = totals[10] or 0
        r_alerts = totals[11] or 0

        table_names = [
            "tenants", "compliance_snapshots", "model_snapshots",
            "fairness_snapshots", "certification_snapshots", "alert_log",
            "pipeline_stats", "system_metrics",
        ]
        table_row_counts = {}
        total_rows = 0
        for tbl in table_names:
            row = self._read_one(f"SELECT COUNT(*) FROM {tbl}")
            cnt = row[0] if row else 0
            table_row_counts[tbl] = cnt
            total_rows += cnt

        return {
            "tenant_count": tenant_count,
            "total_models": total_models,
            "open_alerts": open_alerts,
            "pipelines_24h": pipelines_24h,
            "avg_compliance_score": round(avg_score, 1) if avg_score else None,
            "critical_alerts": critical_alerts,
            "pipelines_total": p_total,
            "pipeline_success_rate": round(p_completed / max(p_total, 1) * 100, 1),
            "pipeline_failure_rate": round(p_failed / max(p_total, 1) * 100, 1),
            "avg_pipeline_duration_ms": round(avg_dur, 1) if avg_dur else None,
            "total_alerts": t_alerts,
            "resolved_alerts": r_alerts,
            "alert_resolution_rate": round(r_alerts / max(t_alerts, 1) * 100, 1),
            "table_row_counts": table_row_counts,
            "total_rows": total_rows,
            "latest_pipeline_at": str(totals[12]) if totals[12] else None,
            "latest_compliance_at": str(totals[13]) if totals[13] else None,
            "models_in_production": totals[14] or 0,
            "models_with_findings": totals[15] or 0,
            "di_confirmed_count": totals[16] or 0,
            "tenants_below_c": totals[17] or 0,
        }

    # -- Platform-wide queries (admin) ---------------------------------------

    def get_all_models_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT DISTINCT ON (ms.tenant_id, ms.model_id)
                   ms.model_id, ms.tenant_id, ms.name, ms.version, ms.tier,
                   ms.status, ms.domain, ms.owner, ms.compliance_score,
                   ms.last_validated, ms.last_monitored,
                   ms.validation_overdue, ms.monitoring_overdue,
                   ms.finding_count, ms.snapshot_at,
                   t.name as tenant_name
            FROM model_snapshots ms
            JOIN tenants t ON ms.tenant_id = t.tenant_id
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY ms.tenant_id, ms.model_id, ms.snapshot_at DESC
        """)

    def get_all_fairness_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT DISTINCT ON (fs.tenant_id, fs.model_id)
                   fs.*, t.name as tenant_name
            FROM fairness_snapshots fs
            JOIN tenants t ON fs.tenant_id = t.tenant_id
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY fs.tenant_id, fs.model_id, fs.snapshot_at DESC
        """)

    def get_compliance_platform(self) -> Dict[str, Any]:
        tenant_scores = self._read_dicts("""
            SELECT DISTINCT ON (cs.tenant_id)
                   cs.tenant_id, t.name as tenant_name, t.tier,
                   cs.score, cs.grade, cs.critical_findings, cs.warning_findings,
                   cs.trend, cs.breakdowns, cs.top_risks, cs.snapshot_at
            FROM compliance_snapshots cs
            JOIN tenants t ON cs.tenant_id = t.tenant_id
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY cs.tenant_id, cs.snapshot_at DESC
        """)
        scores = [t["score"] for t in tenant_scores if t["score"] is not None]
        return {
            "tenants": tenant_scores,
            "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
            "min_score": min(scores) if scores else None,
            "max_score": max(scores) if scores else None,
            "grade_distribution": {
                "A": len([s for s in scores if s >= 90]),
                "B": len([s for s in scores if 75 <= s < 90]),
                "C": len([s for s in scores if 60 <= s < 75]),
                "D": len([s for s in scores if s < 60]),
            },
        }

    def get_pipeline_summary(self) -> Dict[str, Any]:
        totals = self._read_one("""
            SELECT
                (SELECT COUNT(*) FROM pipeline_stats WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'completed' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'failed' AND tenant_id != '_platform_admin'),
                (SELECT AVG(duration_ms) FROM pipeline_stats
                 WHERE status = 'completed' AND duration_ms IS NOT NULL AND tenant_id != '_platform_admin')
        """)
        total = totals[0] if totals else 0
        completed = totals[1] if totals else 0
        failed = totals[2] if totals else 0
        avg_dur = totals[3] if totals else None

        by_tenant = self._read_dicts("""
            SELECT ps.tenant_id, t.name as tenant_name,
                   COUNT(*) as total_runs,
                   SUM(CASE WHEN ps.status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN ps.status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN ps.status = 'completed'
                             THEN ps.duration_ms END)::numeric, 0) as avg_duration_ms,
                   SUM(ps.node_count) as total_nodes,
                   SUM(ps.edge_count) as total_edges
            FROM pipeline_stats ps
            JOIN tenants t ON ps.tenant_id = t.tenant_id
            WHERE t.tenant_id != '_platform_admin'
            GROUP BY ps.tenant_id, t.name
            ORDER BY total_runs DESC
        """)
        by_pipeline = self._read_dicts("""
            SELECT pipeline_name,
                   COUNT(*) as run_count,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN status = 'completed'
                             THEN duration_ms END)::numeric, 0) as avg_duration_ms
            FROM pipeline_stats
            WHERE tenant_id != '_platform_admin'
            GROUP BY pipeline_name
            ORDER BY run_count DESC
        """)
        return {
            "total_runs": total,
            "completed": completed,
            "failed": failed,
            "success_rate": round(completed / max(total, 1) * 100, 1),
            "avg_duration_ms": round(avg_dur, 1) if avg_dur else None,
            "by_tenant": by_tenant,
            "by_pipeline": by_pipeline,
        }

    def get_all_alerts_platform(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT id, tenant_id, severity, source, title, model_id, created_at
               FROM alert_log WHERE resolved = FALSE AND tenant_id != '_platform_admin'
               ORDER BY CASE severity
                   WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
               END, created_at DESC LIMIT %s""",
            (limit,),
        )

    # -- User management (authentication) ------------------------------------

    def get_user_by_email(self, tenant_id: str, email: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT id, tenant_id, email, password_hash, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = %s AND email = %s AND active = TRUE""",
            (tenant_id, email),
        )
        return rows[0] if rows else None

    def get_users(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT id, tenant_id, email, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = %s
               ORDER BY role, email""",
            (tenant_id,),
        )

    def create_user(self, tenant_id: str, email: str, password_hash: str,
                    display_name: str, role: str = "analyst",
                    invited_by: str = None) -> Optional[int]:
        row = self._write_returning(
            """INSERT INTO dashboard_users
               (tenant_id, email, password_hash, display_name, role, invited_by)
               VALUES (%s, %s, %s, %s, %s, %s) RETURNING id""",
            (tenant_id, email, password_hash, display_name, role, invited_by),
        )
        return row[0] if row else None

    def update_user_role(self, tenant_id: str, user_id: int, role: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET role = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (role, user_id, tenant_id),
        )
        return True

    def deactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = FALSE, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (user_id, tenant_id),
        )
        return True

    def reactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = TRUE, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (user_id, tenant_id),
        )
        return True

    def record_login(self, tenant_id: str, email: str) -> None:
        self._write(
            """UPDATE dashboard_users SET last_login_at = NOW()
               WHERE tenant_id = %s AND email = %s""",
            (tenant_id, email),
        )

    def update_user_password(self, tenant_id: str, user_id: int,
                             password_hash: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET password_hash = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (password_hash, user_id, tenant_id),
        )
        return True

    def count_users(self, tenant_id: str) -> int:
        row = self._read_one(
            "SELECT COUNT(*) FROM dashboard_users WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        return row[0] if row else 0

    # -- User Permissions ----------------------------------------------------

    def get_user_permissions(self, tenant_id: str, user_id: int) -> Dict[str, bool]:
        rows = self._read_dicts(
            "SELECT permission, granted FROM user_permissions "
            "WHERE tenant_id = %s AND user_id = %s",
            (tenant_id, user_id),
        )
        return {r["permission"]: r["granted"] for r in rows}

    def set_user_permissions_bulk(self, tenant_id: str, user_id: int,
                                  permissions: Dict[str, bool],
                                  granted_by: str = None) -> None:
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM user_permissions "
                    "WHERE tenant_id = %s AND user_id = %s",
                    (tenant_id, user_id),
                )
                for perm, granted in permissions.items():
                    if perm not in ALL_PERMISSIONS:
                        continue
                    cur.execute(
                        "INSERT INTO user_permissions "
                        "(tenant_id, user_id, permission, granted, granted_by) "
                        "VALUES (%s, %s, %s, %s, %s)",
                        (tenant_id, user_id, perm, granted, granted_by),
                    )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

    def delete_user_permissions(self, tenant_id: str, user_id: int) -> None:
        self._write(
            "DELETE FROM user_permissions WHERE tenant_id = %s AND user_id = %s",
            (tenant_id, user_id),
        )

    def initialize_user_permissions(self, tenant_id: str, user_id: int,
                                     role: str) -> None:
        defaults = ROLE_DEFAULTS.get(role, ROLE_DEFAULTS["analyst"])
        self.set_user_permissions_bulk(tenant_id, user_id, defaults,
                                       granted_by="system")

    def backfill_user_permissions(self, tenant_id: str) -> int:
        users = self._read_dicts(
            "SELECT u.id, u.role FROM dashboard_users u "
            "WHERE u.tenant_id = %s AND u.active = TRUE "
            "AND NOT EXISTS ("
            "  SELECT 1 FROM user_permissions p "
            "  WHERE p.tenant_id = u.tenant_id AND p.user_id = u.id"
            ")",
            (tenant_id,),
        )
        for u in users:
            self.initialize_user_permissions(tenant_id, u["id"], u["role"])
        return len(users)

    # -- API Key Management --------------------------------------------------

    @staticmethod
    def _hash_api_key(key_value: str) -> str:
        return hashlib.sha256(key_value.encode()).hexdigest()

    def validate_api_key(self, key_value: str) -> Optional[Tuple[str, int]]:
        """Validate an API key and return (tenant_id, key_id) or None.

        Returns None for invalid, expired, or revoked keys.
        Updates last_used_at on successful validation.
        """
        if not key_value or not isinstance(key_value, str):
            return None
        key_hash = self._hash_api_key(key_value)
        row = self._read_one(
            "SELECT id, tenant_id FROM api_keys "
            "WHERE key_hash = %s AND status = 'active' "
            "AND (expires_at IS NULL OR expires_at > NOW())",
            (key_hash,),
        )
        if not row:
            return None
        key_id, tenant_id = row[0], row[1]
        self._write(
            "UPDATE api_keys SET last_used_at = NOW() WHERE id = %s",
            (key_id,),
        )
        return (tenant_id, key_id)

    def validate_api_key_detailed(self, key_value: str) -> Dict[str, Any]:
        """Validate an API key with detailed error information.

        Returns dict with:
          - valid=True, tenant_id, key_id on success
          - valid=False, reason="invalid"|"expired"|"revoked" on failure
        """
        if not key_value or not isinstance(key_value, str):
            return {"valid": False, "reason": "invalid"}
        key_hash = self._hash_api_key(key_value)
        row = self._read_dicts(
            "SELECT id, tenant_id, status, expires_at "
            "FROM api_keys WHERE key_hash = %s",
            (key_hash,),
        )
        if not row:
            return {"valid": False, "reason": "invalid"}
        rec = row[0]
        if rec["status"] == "revoked":
            return {"valid": False, "reason": "revoked"}
        if rec["expires_at"] is not None:
            now = datetime.now(timezone.utc)
            exp = rec["expires_at"]
            if hasattr(exp, "tzinfo") and exp.tzinfo is None:
                from datetime import timezone as _tz
                exp = exp.replace(tzinfo=_tz.utc)
            if exp <= now:
                return {"valid": False, "reason": "expired"}
        if rec["status"] != "active":
            return {"valid": False, "reason": "invalid"}
        self._write(
            "UPDATE api_keys SET last_used_at = NOW() WHERE id = %s",
            (rec["id"],),
        )
        return {
            "valid": True,
            "tenant_id": rec["tenant_id"],
            "key_id": rec["id"],
        }

    def create_api_key(
        self,
        tenant_id: str,
        key_name: str,
        created_by: str,
        expires_at: Optional[datetime] = None,
    ) -> Tuple[str, int]:
        """Create a new API key. Returns (key_value, key_id).

        The key_value is returned exactly once and never stored.
        Only the SHA-256 hash is persisted.
        """
        key_secret = secrets.token_urlsafe(32)
        key_value = f"pvt_live_{key_secret}"
        key_hash = self._hash_api_key(key_value)
        row = self._write_returning(
            "INSERT INTO api_keys "
            "(tenant_id, key_hash, key_name, status, created_by, expires_at) "
            "VALUES (%s, %s, %s, 'active', %s, %s) RETURNING id",
            (tenant_id, key_hash, key_name, created_by, expires_at),
        )
        key_id = row[0]
        return (key_value, key_id)

    def list_api_keys(self, tenant_id: str) -> List[Dict[str, Any]]:
        """List all API keys for a tenant. Never returns key_value or key_hash."""
        return self._read_dicts(
            "SELECT id, key_name, status, created_at, expires_at, "
            "last_used_at, created_by "
            "FROM api_keys WHERE tenant_id = %s "
            "ORDER BY created_at DESC",
            (tenant_id,),
        )

    def revoke_api_key(self, tenant_id: str, key_id: int) -> bool:
        """Revoke an API key. Idempotent."""
        self._write(
            "UPDATE api_keys SET status = 'revoked' "
            "WHERE id = %s AND tenant_id = %s",
            (key_id, tenant_id),
        )
        return True

    def rotate_api_key(
        self,
        tenant_id: str,
        key_id: int,
        created_by: str,
    ) -> Tuple[str, int]:
        """Revoke old key and create new key atomically. Returns (new_key_value, new_key_id)."""
        key_secret = secrets.token_urlsafe(32)
        new_key_value = f"pvt_live_{key_secret}"
        new_key_hash = self._hash_api_key(new_key_value)
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT key_name FROM api_keys "
                    "WHERE id = %s AND tenant_id = %s",
                    (key_id, tenant_id),
                )
                old = cur.fetchone()
                if not old:
                    raise ValueError(f"API key {key_id} not found for tenant {tenant_id}")
                key_name = old[0]
                cur.execute(
                    "UPDATE api_keys SET status = 'revoked' "
                    "WHERE id = %s AND tenant_id = %s",
                    (key_id, tenant_id),
                )
                cur.execute(
                    "INSERT INTO api_keys "
                    "(tenant_id, key_hash, key_name, status, created_by) "
                    "VALUES (%s, %s, %s, 'active', %s) RETURNING id",
                    (tenant_id, new_key_hash, key_name, created_by),
                )
                new_key_id = cur.fetchone()[0]
            conn.commit()
            return (new_key_value, new_key_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

    # -- Deployment Gate & Compliance (Unified Platform Features) -------------

    def _table_exists(self, table_name: str) -> bool:
        """Check if a table exists in the PostgreSQL schema."""
        rows = self._read_dicts(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = %s",
            (table_name,),
        )
        return len(rows) > 0

    def get_deployment_gate_status(self) -> Dict[str, Any]:
        """Get deployment gate status across all models/tenants."""
        if not self._table_exists("deployment_decisions"):
            return {
                "total_deployments": 0,
                "approved": 0,
                "blocked": 0,
                "recent_decisions": [],
            }

        row = self._read_one(
            "SELECT COUNT(*) AS total, "
            "SUM(CASE WHEN deployment_approved = TRUE THEN 1 ELSE 0 END) AS approved, "
            "SUM(CASE WHEN deployment_approved = FALSE THEN 1 ELSE 0 END) AS blocked "
            "FROM deployment_decisions"
        )
        total = row[0] if row else 0
        approved = row[1] if row else 0
        blocked = row[2] if row else 0

        recent = self._read_dicts(
            "SELECT model_name, model_version, deployment_approved, "
            "blocking_findings_count, timestamp, attestation_id "
            "FROM deployment_decisions "
            "ORDER BY timestamp DESC LIMIT 20"
        )

        return {
            "total_deployments": total or 0,
            "approved": approved or 0,
            "blocked": blocked or 0,
            "approval_rate": round((approved or 0) / max(total or 0, 1) * 100, 1),
            "recent_decisions": recent,
        }

    def get_compliance_violations(self) -> Dict[str, Any]:
        """Get active compliance violations across all models."""
        if not self._table_exists("compliance_violations"):
            return {
                "violations": [],
                "total_count": 0,
                "critical_count": 0,
                "by_regulation": {},
            }

        violations = self._read_dicts(
            "SELECT model_name, model_version, violation_type, severity, "
            "regulation, description, created_at, resolved "
            "FROM compliance_violations "
            "WHERE resolved = FALSE "
            "ORDER BY CASE severity "
            "  WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 "
            "END, created_at DESC LIMIT 100"
        )

        total = len(violations)
        critical = sum(1 for v in violations if v.get("severity") == "critical")

        by_regulation: Dict[str, int] = {}
        for v in violations:
            reg = v.get("regulation", "unknown")
            by_regulation[reg] = by_regulation.get(reg, 0) + 1

        return {
            "violations": violations,
            "total_count": total,
            "critical_count": critical,
            "by_regulation": by_regulation,
        }

    def get_fairness_regression_trends(self) -> Dict[str, Any]:
        """Get fairness regression trends across model versions."""
        if not self._table_exists("fairness_regression"):
            return {"models": [], "degrading_count": 0}

        trends = self._read_dicts(
            "SELECT model_name, current_version, previous_version, "
            "disparate_impact_change, degradation_detected, created_at "
            "FROM fairness_regression "
            "ORDER BY created_at DESC LIMIT 50"
        )

        degrading = sum(1 for t in trends if t.get("degradation_detected"))

        return {
            "models": trends,
            "degrading_count": degrading,
            "total_comparisons": len(trends),
        }

    def get_model_lifecycle(self, model_name: str) -> Dict[str, Any]:
        """Get complete lifecycle view for a specific model."""
        if not self._table_exists("deployment_decisions"):
            return {
                "model_name": model_name,
                "versions": [],
                "fairness_trend": [],
            }

        versions = self._read_dicts(
            "SELECT model_version, deployment_approved, timestamp, "
            "blocking_findings_count, attestation_id "
            "FROM deployment_decisions "
            "WHERE model_name = %s "
            "ORDER BY timestamp DESC",
            (model_name,),
        )

        fairness_trend = []
        for v in versions:
            fairness_trend.append({
                "version": v["model_version"],
                "timestamp": v["timestamp"],
                "approved": v["deployment_approved"],
            })

        return {
            "model_name": model_name,
            "versions": versions,
            "fairness_trend": fairness_trend,
        }
