"""
AWS Lambda handler for Attestant Deployment Gate.

This Lambda function provides the deployment gate as an HTTP API that can be
invoked from CI/CD pipelines, GitHub Actions, or manual deployment scripts.

API Endpoints:
- POST /validate - Validate a model for deployment
- GET /attestation/{attestation_id} - Retrieve deployment attestation
- GET /health - Health check

Request format for /validate:
{
    "model_name": "credit_scoring_v2.1.0",
    "model_version": "2.1.0",
    "model_s3_uri": "s3://models/credit_scoring_v2.1.0.pkl",
    "test_data_s3_uri": "s3://data/test_set.parquet",
    "protected_data_s3_uri": "s3://data/protected_attributes.parquet",
    "protected_columns": ["race", "sex", "age"],
    "previous_version": "2.0.0",
    "metadata": {}
}

Response format:
{
    "deployment_approved": true,
    "gate_status": "approved",
    "model_name": "credit_scoring_v2.1.0",
    "model_version": "2.1.0",
    "model_hash": "a3f2b1...",
    "blocking_findings": [],
    "warning_findings": [],
    "attestation_id": "e4c7d...",
    "summary": {}
}

Environment Variables:
- ATTESTANT_S3_BUCKET: S3 bucket for provenance storage
- ATTESTANT_DB_CONNECTION: Aurora PostgreSQL connection string (optional)
- FOUR_FIFTHS_THRESHOLD: Disparate impact threshold (default: 0.80)
- STRICT_MODE: Block on all CRITICAL findings (default: true)
"""

import json
import logging
import os
import pickle
import tempfile
from typing import Any, Dict

import boto3
import pandas as pd

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for deployment gate validation.

    Args:
        event: API Gateway event with request details
        context: Lambda context

    Returns:
        API Gateway response with validation results
    """
    try:
        http_method = event.get("httpMethod", "GET")
        path = event.get("path", "/")

        if path == "/health":
            return _response(200, {"status": "healthy"})

        if path == "/validate" and http_method == "POST":
            return _handle_validate(event)

        if path.startswith("/attestation/") and http_method == "GET":
            attestation_id = path.split("/")[-1]
            return _handle_get_attestation(attestation_id)

        return _response(404, {"error": "Not found"})

    except Exception as exc:
        logger.exception("Deployment gate validation failed")
        return _response(500, {"error": str(exc)})


def _handle_validate(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle POST /validate request."""
    body = json.loads(event.get("body", "{}"))

    model_name = body.get("model_name")
    model_version = body.get("model_version")
    model_s3_uri = body.get("model_s3_uri")
    test_data_s3_uri = body.get("test_data_s3_uri")
    protected_data_s3_uri = body.get("protected_data_s3_uri")
    protected_columns = body.get("protected_columns", [])
    previous_version = body.get("previous_version")
    metadata = body.get("metadata", {})

    if not all([model_name, model_s3_uri, test_data_s3_uri, protected_data_s3_uri, protected_columns]):
        return _response(400, {
            "error": "Missing required fields: model_name, model_s3_uri, test_data_s3_uri, protected_data_s3_uri, protected_columns"
        })

    logger.info("Validating deployment: %s v%s", model_name, model_version)

    s3 = boto3.client("s3")

    with tempfile.TemporaryDirectory() as tmpdir:
        model_path = os.path.join(tmpdir, "model.pkl")
        test_data_path = os.path.join(tmpdir, "test_data.parquet")
        protected_data_path = os.path.join(tmpdir, "protected_data.parquet")

        _download_s3_file(s3, model_s3_uri, model_path)
        _download_s3_file(s3, test_data_s3_uri, test_data_path)
        _download_s3_file(s3, protected_data_s3_uri, protected_data_path)

        with open(model_path, "rb") as f:
            model = pickle.load(f)

        test_df = pd.read_parquet(test_data_path)
        protected_df = pd.read_parquet(protected_data_path)

        if "target" not in test_df.columns and "label" not in test_df.columns:
            return _response(400, {"error": "Test data must have 'target' or 'label' column"})

        target_col = "target" if "target" in test_df.columns else "label"
        y_test = test_df[target_col].values
        X_test = test_df.drop(columns=[target_col])

        from attestant.deployment.gate import DeploymentGate
        from attestant.persistence.s3_storage import S3Storage

        s3_bucket = os.environ.get("ATTESTANT_S3_BUCKET", "attestant-provenance")
        strict_mode = os.environ.get("STRICT_MODE", "true").lower() == "true"
        four_fifths_threshold = float(os.environ.get("FOUR_FIFTHS_THRESHOLD", "0.80"))

        with S3Storage(bucket=s3_bucket, prefix="provenance") as storage:
            gate = DeploymentGate(
                storage=storage,
                strict_mode=strict_mode,
                four_fifths_threshold=four_fifths_threshold,
            )

            result = gate.validate_deployment(
                model=model,
                model_name=model_name,
                X_train=X_test,
                y_train=y_test,
                X_test=X_test,
                y_test=y_test,
                protected_data=protected_df,
                protected_columns=protected_columns,
                model_version=model_version,
                previous_version=previous_version,
                metadata=metadata,
            )

        response_body = result.to_dict()

        status_code = 200 if result.deployment_approved else 403

        return _response(status_code, response_body)


def _handle_get_attestation(attestation_id: str) -> Dict[str, Any]:
    """Handle GET /attestation/{id} request."""
    return _response(200, {
        "attestation_id": attestation_id,
        "status": "not_implemented",
        "message": "Attestation retrieval from storage not yet implemented"
    })


def _download_s3_file(s3_client, s3_uri: str, local_path: str) -> None:
    """Download file from S3."""
    if not s3_uri.startswith("s3://"):
        raise ValueError(f"Invalid S3 URI: {s3_uri}")

    parts = s3_uri[5:].split("/", 1)
    bucket = parts[0]
    key = parts[1] if len(parts) > 1 else ""

    logger.info("Downloading s3://%s/%s to %s", bucket, key, local_path)
    s3_client.download_file(bucket, key, local_path)


def _response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Build API Gateway response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body, default=str),
    }
