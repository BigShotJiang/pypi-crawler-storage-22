"""
AutoDoc templates: pluggable document templates for different compliance
frameworks and documentation standards.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from .engine import DocumentSection, TemplateType

logger = logging.getLogger(__name__)


class BaseTemplate(ABC):
    """Base class for document templates."""
    name: str = "Base Template"
    description: str = "Base document template"

    @abstractmethod
    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        """Render the template with the given context."""
        ...

    def get_title(self, context: Dict[str, Any]) -> str:
        model = context.get("model")
        if model:
            return f"{self.name}: {model.name}"
        pipeline = context.get("pipeline")
        if pipeline:
            return f"{self.name}: {pipeline.name}"
        return self.name


class SR117Template(BaseTemplate):
    """
    SR 11-7 Model Validation Report template.

    Produces audit-quality documentation per the Federal Reserve's Supervisory
    Guidance on Model Risk Management (SR 11-7 / OCC 2011-12).
    """
    name = "SR 11-7 Model Validation Report"
    description = "Federal Reserve model risk management documentation per SR 11-7 / OCC 2011-12"

    # Performance rating thresholds
    AUC_THRESHOLDS = [(0.90, "Excellent"), (0.80, "Good"), (0.70, "Acceptable"), (0.60, "Marginal")]
    KS_THRESHOLDS = [(0.40, "Strong"), (0.30, "Good"), (0.20, "Moderate"), (0.10, "Weak")]
    GINI_THRESHOLDS = [(0.80, "Excellent"), (0.60, "Good"), (0.40, "Acceptable"), (0.20, "Marginal")]

    @staticmethod
    def _rate(value: float, thresholds: list) -> str:
        for threshold, label in thresholds:
            if value >= threshold:
                return label
        return "Poor"

    def _generate_findings(self, model, context) -> list:
        findings = []
        fid = 1

        if not model:
            return findings

        pm = model.performance_metrics or {}

        auc = pm.get("auc_roc")
        if auc is not None and auc < 0.65:
            findings.append({"id": f"F-{fid:03d}", "severity": "HIGH", "category": "Model Performance",
                "finding": f"Model AUC-ROC of {auc:.4f} is below the minimum acceptable threshold of 0.65 for production credit risk models. Per OCC 2011-12 Section V.C, models with materially weak discrimination power require enhanced compensating controls or redevelopment.",
                "recommendation": "Conduct feature engineering review, evaluate alternative model architectures (e.g., XGBoost, neural networks), and expand training data coverage. If performance cannot be improved above threshold, implement a human-review overlay for all model-driven decisions."})
            fid += 1

        ks = pm.get("ks_statistic")
        if ks is not None and ks < 0.20:
            findings.append({"id": f"F-{fid:03d}", "severity": "MEDIUM", "category": "Model Performance",
                "finding": f"KS statistic of {ks:.4f} indicates weak separation between default and non-default populations. Industry standard for consumer credit models is typically KS > 0.20.",
                "recommendation": "Investigate whether training labels contain sufficient signal. Consider alternative outcome definitions or longer performance windows for label generation."})
            fid += 1

        gini = pm.get("gini_coefficient")
        if gini is not None and gini < 0.30:
            findings.append({"id": f"F-{fid:03d}", "severity": "MEDIUM", "category": "Model Performance",
                "finding": f"Gini coefficient of {gini:.4f} falls below the 0.30 threshold typically expected for production lending models. This metric (2*AUC - 1) confirms weak overall discriminatory power.",
                "recommendation": "Gini improvement requires the same remediation as AUC. Prioritize feature engineering and consider ensemble approaches to improve rank-ordering."})
            fid += 1

        baseline_auc = pm.get("baseline_auc_logreg")
        if baseline_auc is not None and auc is not None and baseline_auc > auc:
            findings.append({"id": f"F-{fid:03d}", "severity": "HIGH", "category": "Model Performance",
                "finding": f"The baseline logistic regression model (AUC {baseline_auc:.4f}) outperforms the champion {model.model_type} model (AUC {auc:.4f}). This suggests the more complex model may be overfitting to training noise or the additional model complexity is not justified by improved performance.",
                "recommendation": "Conduct hyperparameter tuning review. Evaluate whether model complexity is warranted given the performance gap. Consider using the simpler logistic regression as the production model, which also offers superior interpretability for adverse action reason code generation under ECOA."})
            fid += 1

        fm = model.fairness_metrics or {}
        if fm.get("contaminated_model_detected"):
            prot = fm.get("protected_attributes_tracked", [])
            prot_str = ", ".join(str(a) for a in prot) if prot else "unspecified attributes"
            findings.append({"id": f"F-{fid:03d}", "severity": "CRITICAL", "category": "Fair Lending / ECOA Compliance",
                "finding": f"Protected data contamination detected. The model development pipeline processed data containing ECOA-protected attributes ({prot_str}). Under Regulation B (12 CFR 1002.6(a)), creditors may not consider race, color, religion, national origin, sex, marital status, or age in credit decisions. Any model that directly or indirectly incorporates these attributes is non-compliant.",
                "recommendation": "IMMEDIATE ACTION REQUIRED: (1) Quarantine the contaminated model version. (2) Audit the clean model variant to verify no protected data leakage via the provenance DAG. (3) Implement automated pre-deployment ECOA compliance gates in the CI/CD pipeline. (4) Document remediation steps for regulatory examination file."})
            fid += 1

        if model.feature_importances:
            sorted_imp = sorted(model.feature_importances.items(), key=lambda x: -x[1])
            total = sum(v for _, v in sorted_imp) or 1
            top3_pct = sum(v for _, v in sorted_imp[:3]) / total * 100
            if top3_pct > 60:
                names = ", ".join(n for n, _ in sorted_imp[:3])
                findings.append({"id": f"F-{fid:03d}", "severity": "MEDIUM", "category": "Feature Concentration",
                    "finding": f"The top 3 features ({names}) account for {top3_pct:.1f}% of total model importance. High concentration increases vulnerability to data quality issues or distribution shifts in a small number of input variables.",
                    "recommendation": "Evaluate feature diversification strategies. Implement enhanced monitoring (CSI) for high-importance features. Consider whether additional predictive features from alternative data sources could reduce concentration risk."})
                fid += 1

            negligible = [(n, v) for n, v in sorted_imp if v < 0.005]
            if negligible:
                names = ", ".join(n for n, _ in negligible)
                findings.append({"id": f"F-{fid:03d}", "severity": "LOW", "category": "Feature Engineering",
                    "finding": f"{len(negligible)} feature(s) with negligible importance (<0.5%): {names}. These features add model complexity without meaningful predictive contribution.",
                    "recommendation": "Evaluate removing low-importance features to reduce model complexity and improve interpretability. Simpler models are preferred under SR 11-7 when predictive performance is comparable."})
                fid += 1

        pipeline = context.get("pipeline")
        if not pipeline or not pipeline.data_quality_checks:
            findings.append({"id": f"F-{fid:03d}", "severity": "MEDIUM", "category": "Data Quality",
                "finding": "No formal data quality checks are documented for the model pipeline. Per SR 11-7 Section V.B, data used in model development must meet documented standards for completeness, accuracy, representativeness, and timeliness.",
                "recommendation": "Implement automated data quality gates including: null rate monitoring, distribution drift detection (PSI), outlier detection, and referential integrity checks. Document acceptance criteria and remediation procedures for each check."})
            fid += 1

        if model.limitations and "synthetic" in model.limitations.lower():
            findings.append({"id": f"F-{fid:03d}", "severity": "INFORMATIONAL", "category": "Documentation",
                "finding": "Model documentation indicates training on synthetic data. Production deployment will require retraining on historical portfolio data with demonstrated out-of-time validation performance.",
                "recommendation": "Before production deployment: (1) retrain on 24+ months of historical data, (2) perform out-of-time validation on a holdout period, (3) establish production monitoring baselines, (4) complete full re-validation cycle."})
            fid += 1

        return findings

    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        model = context.get("model")
        findings = self._generate_findings(model, context)
        sections = []

        sections.append(self._document_control(model))
        sections.append(self._executive_summary(model, findings, context))
        sections.append(self._findings_summary(findings))
        sections.append(self._scope_objectives(model))
        sections.append(self._model_description(model, context))
        sections.append(self._conceptual_soundness(model))
        sections.append(self._data_assessment(model, context))
        sections.append(self._feature_analysis(model))
        sections.append(self._performance_analysis(model))
        sections.append(self._outcomes_analysis(model))
        sections.append(self._fair_lending_review(model, context))
        sections.append(self._data_lineage(context))
        sections.append(self._monitoring_plan(model))
        sections.append(self._governance(model))
        sections.append(self._appendix_dag(context))
        sections.append(self._appendix_regulatory())

        return sections

    def _document_control(self, model) -> DocumentSection:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        name = model.name if model else "N/A"
        ver = model.version if model else "N/A"
        lines = [
            "| Field | Value |",
            "|-------|-------|",
            f"| Report Title | Independent Model Validation: {name} |",
            f"| Model Version | {ver} |",
            f"| Report Version | 1.0 |",
            f"| Status | Draft - Pending MRM Review |",
            f"| Generated | {now} |",
            f"| Classification | Confidential - Model Risk Management |",
            "",
            "| Role | Name | Date |",
            "|------|------|------|",
            "| Prepared By | Model Validation Team | |",
            "| Reviewed By | Model Risk Management (2nd Line) | |",
            "| Approved By | Chief Model Risk Officer | |",
            "",
            "**Distribution:** Model Owner, Model Risk Management, Internal Audit, "
            "Regulatory Examination File",
        ]
        return DocumentSection(title="Document Control", content="\n".join(lines))

    def _executive_summary(self, model, findings, context) -> DocumentSection:
        if not model:
            return DocumentSection(title="Executive Summary",
                content="No model metadata provided. Per SR 11-7, the executive summary must include "
                        "model purpose, risk tier, validation scope, key findings, and recommended actions.")

        sevs = [f["severity"] for f in findings]
        if "CRITICAL" in sevs:
            rating = "Unsatisfactory"
            rating_note = "Immediate remediation required before production use."
        elif "HIGH" in sevs:
            rating = "Needs Improvement"
            rating_note = "Material findings must be addressed before deployment approval."
        elif "MEDIUM" in sevs:
            rating = "Satisfactory with Conditions"
            rating_note = "Model may proceed with conditions; findings must be remediated per agreed timeline."
        else:
            rating = "Satisfactory"
            rating_note = "No material findings. Standard monitoring applies."

        ct = {s: sevs.count(s) for s in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL"] if sevs.count(s) > 0}
        ct_str = ", ".join(f"{v} {k}" for k, v in ct.items())

        pm = model.performance_metrics or {}
        auc = pm.get("auc_roc")
        ks = pm.get("ks_statistic")
        gini = pm.get("gini_coefficient")

        model_desc_parts = [f"**{model.name}**"]
        if model.version:
            model_desc_parts.append(f"(version {model.version})")
        if model.model_type:
            model_desc_parts.append(f", a {model.model_type} model")
            if model.framework:
                model_desc_parts[-1] += f" implemented in {model.framework}"
        if model.owner:
            model_desc_parts.append(f". The model was developed by {model.owner}")
        if model.description:
            model_desc_parts.append(f" to {model.description}")

        lines = [
            f"This report presents the independent model validation results for "
            f"{''.join(model_desc_parts)}. "
            f"Validation was conducted in accordance with the Federal Reserve's Supervisory Guidance on "
            f"Model Risk Management (SR Letter 11-7) and OCC Bulletin 2011-12.\n",
            f"### Overall Model Risk Rating: **{rating}**\n",
            f"{rating_note}\n",
        ]

        if auc is not None or ks is not None or gini is not None or model.feature_count or model.training_rows:
            lines.append("### Key Performance Indicators\n")
            lines.append("| Metric | Value | Rating |")
            lines.append("|--------|-------|--------|")
            if auc is not None:
                lines.append(f"| AUC-ROC | {auc:.4f} | {self._rate(auc, self.AUC_THRESHOLDS)} |")
            if ks is not None:
                lines.append(f"| KS Statistic | {ks:.4f} | {self._rate(ks, self.KS_THRESHOLDS)} |")
            if gini is not None:
                lines.append(f"| Gini Coefficient | {gini:.4f} | {self._rate(gini, self.GINI_THRESHOLDS)} |")
            if model.feature_count:
                lines.append(f"| Features | {model.feature_count} | |")
            if model.training_rows:
                lines.append(f"| Training Samples | {model.training_rows:,} | |")
            lines.append("")
        else:
            lines.append("### Key Performance Indicators\n")
            lines.append("Performance metrics not yet available from pipeline data. "
                         "Metrics will be populated after model performance evaluation.\n")

        lines.append(f"### Findings Summary\n")
        lines.append(f"The validation identified **{len(findings)}** finding(s): {ct_str or 'none'}.\n")

        critical = [f for f in findings if f["severity"] == "CRITICAL"]
        if critical:
            lines.append("**Critical findings requiring immediate action:**\n")
            for f in critical:
                lines.append(f"- **[{f['id']}]** {f['finding'][:200]}...")
            lines.append("")

        lines.append(
            f"**Conclusion:** Based on the validation procedures performed, the model receives an "
            f"overall rating of **{rating}**. "
            f"{'All identified findings must be remediated prior to or concurrent with production deployment. ' if rating != 'Satisfactory' else ''}"
            f"Management responses and target remediation dates are required for all findings rated MEDIUM or above."
        )

        return DocumentSection(title="Executive Summary", content="\n".join(lines))

    def _findings_summary(self, findings) -> DocumentSection:
        if not findings:
            return DocumentSection(title="Validation Findings",
                content="No material findings identified during this validation cycle.")

        lines = [
            "The following table summarizes all findings from this validation. Management is required "
            "to provide a response and remediation timeline for findings rated MEDIUM or above.\n",
            "| ID | Severity | Category | Finding | Recommendation |",
            "|-----|----------|----------|---------|----------------|",
        ]
        for f in findings:
            finding_short = f["finding"][:150].replace("|", "/") + ("..." if len(f["finding"]) > 150 else "")
            rec_short = f["recommendation"][:120].replace("|", "/") + ("..." if len(f["recommendation"]) > 120 else "")
            lines.append(f"| {f['id']} | **{f['severity']}** | {f['category']} | {finding_short} | {rec_short} |")

        lines.append("")
        lines.append("### Finding Details\n")
        for f in findings:
            sev_marker = {"CRITICAL": "!!!", "HIGH": "!!", "MEDIUM": "!", "LOW": "", "INFORMATIONAL": ""}.get(f["severity"], "")
            lines.append(f"#### {f['id']}: {f['category']} [{f['severity']}] {sev_marker}\n")
            lines.append(f"**Finding:** {f['finding']}\n")
            lines.append(f"**Recommendation:** {f['recommendation']}\n")
            lines.append("| Field | Value |")
            lines.append("|-------|-------|")
            lines.append(f"| Severity | {f['severity']} |")
            lines.append(f"| Management Response | *Pending* |")
            lines.append(f"| Target Remediation Date | *Pending* |")
            lines.append(f"| Status | Open |")
            lines.append("")

        return DocumentSection(title="Validation Findings", content="\n".join(lines))

    def _scope_objectives(self, model) -> DocumentSection:
        name = model.name if model else "the subject model"
        lines = [
            f"### Validation Scope\n",
            f"This report documents the independent validation of **{name}** covering the following areas "
            f"as prescribed by SR 11-7 (Supervisory Guidance on Model Risk Management, April 2011):\n",
            "1. **Conceptual Soundness** (SR 11-7, Section V.A) - Evaluation of the theoretical basis, "
            "methodology, and assumptions underlying the model design",
            "2. **Data Assessment** (SR 11-7, Section V.B) - Review of data quality, representativeness, "
            "completeness, and appropriateness for the model's intended use",
            "3. **Outcomes Analysis** (SR 11-7, Section V.C) - Quantitative assessment of model performance "
            "including discrimination, calibration, and stability metrics",
            "4. **Fair Lending Review** (ECOA / Reg B) - Evaluation of compliance with equal credit opportunity "
            "requirements and analysis of protected data exposure",
            "5. **Data Lineage Verification** - Cryptographic provenance audit confirming data flow integrity "
            "from source through model output",
            "6. **Governance and Controls** (SR 11-7, Section VI) - Review of model governance framework, "
            "ongoing monitoring plan, and change management procedures\n",
            "### Validation Methodology\n",
            "Validation was performed using the following approaches:\n",
            "- **Replication testing:** Independent reconstruction of model outputs from source data using "
            "the provenance DAG to verify computational integrity",
            "- **Benchmarking:** Comparison of champion model performance against a baseline logistic "
            "regression to assess whether model complexity is justified",
            "- **Sensitivity analysis:** Evaluation of model output sensitivity to input perturbations "
            "and feature removal",
            "- **Regulatory compliance testing:** Automated screening of data lineage for prohibited "
            "attributes under ECOA/Regulation B\n",
            "### Regulatory Standards Applied\n",
            "- Federal Reserve SR Letter 11-7: Supervisory Guidance on Model Risk Management (April 4, 2011)",
            "- OCC Bulletin 2011-12: Sound Practices for Model Risk Management (April 4, 2011)",
            "- Equal Credit Opportunity Act (ECOA) / Regulation B (12 CFR 1002)",
            "- CFPB Circular 2023-03: Adverse Action Notification Requirements for AI/ML Models",
            "- OCC Comptroller's Handbook: Model Risk Management (August 2021)",
        ]
        return DocumentSection(title="Scope and Objectives", content="\n".join(lines))

    def _model_description(self, model, context) -> DocumentSection:
        if not model:
            return DocumentSection(title="Model Description", content="No model metadata provided.")

        pipeline = context.get("pipeline")
        pip_desc = f"\n\n**Pipeline:** {pipeline.name}\n{pipeline.description}" if pipeline else ""

        lines = [
            f"### Model Overview\n",
            f"| Attribute | Value |",
            f"|-----------|-------|",
            f"| Model Name | {model.name} |",
            f"| Version | {model.version or 'N/A'} |",
            f"| Model Type | {model.model_type or 'N/A'} |",
            f"| Framework | {model.framework or 'N/A'} |",
            f"| Training Date | {model.training_date or 'N/A'} |",
            f"| Feature Count | {model.feature_count or 'N/A'} |",
            (f"| Training Observations | {model.training_rows:,} |" if model.training_rows else "| Training Observations | N/A |"),
            f"| Model Owner | {model.owner or 'N/A'} |",
            f"| Contact | {model.contact or 'N/A'} |",
            "",
            f"### Purpose and Intended Use\n",
            f"{model.description or 'Not specified.'}\n",
            f"**Intended Use:** {model.intended_use or 'Not specified.'}\n",
            f"### Known Limitations\n",
            f"{model.limitations or 'No limitations documented. Per SR 11-7, all known limitations must be documented.'}\n",
        ]

        if model.model_type:
            lines.append(f"### Model Architecture\n")
            arch_line = f"The model employs a **{model.model_type}** architecture"
            if model.framework:
                arch_line += f" implemented via the **{model.framework}** library. "
            else:
                arch_line += ". "
            lines.append(arch_line)
        else:
            lines.append(f"### Model Architecture\n")
            lines.append("Model architecture details not yet available from pipeline data. ")

        if model.hyperparameters:
            lines.append("The model was trained with the following hyperparameter configuration:\n")
            lines.append("| Parameter | Value |")
            lines.append("|-----------|-------|")
            for k, v in model.hyperparameters.items():
                lines.append(f"| {k} | {v} |")
            lines.append("")

        if model.model_type and "boost" in model.model_type.lower():
            lines.append(
                "Gradient Boosted Trees are an ensemble learning method that builds sequential decision trees, "
                "each correcting the errors of its predecessors. While this approach typically yields strong "
                "predictive performance, the resulting model is inherently non-linear and difficult to interpret, "
                "which requires enhanced validation procedures per SR 11-7 guidance on complex models."
            )
        if pip_desc:
            lines.append(pip_desc)

        return DocumentSection(title="Model Description", content="\n".join(lines))

    def _conceptual_soundness(self, model) -> DocumentSection:
        mtype = (model.model_type if model and model.model_type
                 else "the selected methodology")
        lines = [
            "### Regulatory Requirement (SR 11-7, Section V.A)\n",
            "The conceptual soundness review evaluates whether the model design, theory, and logic are "
            "appropriate for the intended use, and whether the underlying assumptions are reasonable and "
            "well-documented. This review should be performed by personnel with relevant expertise who are "
            "not involved in model development.\n",
            "### Theoretical Basis\n",
            f"The model employs **{mtype}** methodology for credit risk estimation. ",
        ]

        if model and "boost" in (model.model_type or "").lower():
            lines.append(
                "Gradient boosting is a well-established technique in the machine learning literature "
                "(Friedman, 2001) that has demonstrated strong performance in credit risk modeling applications. "
                "The sequential additive approach builds an ensemble of weak learners (decision trees) that "
                "collectively achieve high predictive accuracy.\n\n"
                "**Key Assumptions:**\n\n"
                "1. **Stationarity:** The relationship between input features and default probability is assumed "
                "to be stable over the model's intended deployment horizon\n"
                "2. **Feature independence at split level:** Each tree split considers features independently, "
                "though the ensemble captures interactions implicitly through sequential tree construction\n"
                "3. **Representativeness:** The training data is assumed to be representative of the population "
                "to which the model will be applied\n"
                "4. **Label quality:** Training labels (default/non-default) are assumed to accurately reflect "
                "the true credit outcome\n\n"
                "**Methodology Assessment:**\n\n"
                "- The choice of gradient boosting is appropriate for credit risk modeling where non-linear "
                "relationships and feature interactions may exist\n"
                "- The use of a baseline logistic regression as a benchmark is consistent with best practices "
                "for establishing a performance floor\n"
                "- Feature engineering (DTI, utilization ratios, affordability metrics) follows standard "
                "industry practices for consumer lending models\n"
                "- The hyperparameter configuration should be validated through cross-validation to confirm "
                "that the model is not overfit to the training data"
            )
        else:
            lines.append(
                "The selected methodology should be evaluated for theoretical appropriateness given the "
                "model's intended application. Key considerations include whether the methodology's "
                "assumptions are consistent with the economic or statistical phenomena being modeled.\n\n"
                "**Key Assumptions:** To be documented by the model development team.\n\n"
                "**Methodology Assessment:** Requires review by a qualified independent validator."
            )

        return DocumentSection(title="Conceptual Soundness Review", content="\n".join(lines))

    def _data_assessment(self, model, context) -> DocumentSection:
        pipeline = context.get("pipeline")
        dag_nodes = context.get("dag_nodes", [])
        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE"]

        lines = [
            "### Regulatory Requirement (SR 11-7, Section V.B)\n",
            "Data used in model development and ongoing operation must meet documented standards for "
            "completeness, accuracy, representativeness, and timeliness. Data quality deficiencies must "
            "be documented with an assessment of materiality and any compensating controls.\n",
            "### Source Data Inventory\n",
        ]

        if pipeline and pipeline.source_tables:
            lines.append("| Source Table | Description | Status |")
            lines.append("|-------------|-------------|--------|")
            for src in pipeline.source_tables:
                lines.append(f"| {src} | Production data source | Active |")
            lines.append("")

        if source_nodes:
            tables = {}
            for n in source_nodes:
                tbl = n.get("table", "unknown")
                col = n.get("column", "unknown")
                prot = n.get("is_protected", False)
                if tbl not in tables:
                    tables[tbl] = []
                tables[tbl].append((col, prot))

            lines.append(f"The provenance DAG identified **{len(source_nodes)}** source columns "
                         f"across **{len(tables)}** table(s):\n")
            for tbl, cols in sorted(tables.items()):
                prot_flag = " **[ECOA PROTECTED]**" if any(p for _, p in cols) else ""
                col_names = ", ".join(f"`{c}`" for c, _ in cols)
                lines.append(f"- **{tbl}**{prot_flag}: {col_names}")
            lines.append("")

        if model:
            lines.append("### Data Quality Assessment\n")
            lines.append("| Dimension | Requirement | Status | Notes |")
            lines.append("|-----------|-------------|--------|-------|")
            lines.append(f"| Completeness | No material gaps in required fields | Review required | {model.training_rows:,} training observations |")
            lines.append(f"| Accuracy | Values reflect underlying reality | Review required | {model.feature_count} features assessed |")
            lines.append("| Representativeness | Training data reflects target population | Review required | Distribution analysis needed |")
            lines.append("| Timeliness | Data is current for decision horizon | Review required | Training date: " + (model.training_date or "N/A") + " |")
            lines.append("")

        if pipeline and pipeline.data_quality_checks:
            lines.append(f"### Automated Data Quality Checks ({len(pipeline.data_quality_checks)})\n")
            for check in pipeline.data_quality_checks:
                name = check.get("name", "unnamed")
                status = check.get("status", "unknown")
                lines.append(f"- **{name}**: {status}")
        else:
            lines.append("### Automated Data Quality Checks\n")
            lines.append("No automated data quality checks are currently documented for this pipeline. "
                         "This has been recorded as a finding (see Validation Findings section).")

        if pipeline and pipeline.transformation_steps:
            lines.append(f"\n### Feature Engineering Steps ({len(pipeline.transformation_steps)})\n")
            lines.append("| Step | Transformation | Description |")
            lines.append("|------|---------------|-------------|")
            for i, step in enumerate(pipeline.transformation_steps, 1):
                name = step.get("name", f"Step {i}")
                desc = step.get("description", "")
                lines.append(f"| {i} | {name} | {desc} |")

        return DocumentSection(title="Data Assessment", content="\n".join(lines))

    def _feature_analysis(self, model) -> DocumentSection:
        if not model or not model.feature_importances:
            return DocumentSection(title="Feature Analysis",
                content="No feature importance data available. Per SR 11-7, feature-level "
                        "analysis is required for all production models.")

        sorted_imp = sorted(model.feature_importances.items(), key=lambda x: -x[1])
        total_imp = sum(v for _, v in sorted_imp) or 1

        lines = [
            "### Feature Importance Ranking\n",
            "The following table presents model features ranked by importance as determined by the "
            "gradient boosting algorithm's split-gain metric. Cumulative importance indicates the "
            "proportion of total model explanatory power attributable to the top N features.\n",
            "| Rank | Feature | Importance | % of Total | Cumulative % | Assessment |",
            "|------|---------|-----------|-----------|-------------|------------|",
        ]

        cum = 0.0
        for rank, (feat, imp) in enumerate(sorted_imp, 1):
            pct = imp / total_imp * 100
            cum += pct
            if pct > 12:
                assessment = "Primary driver"
            elif pct > 8:
                assessment = "Significant contributor"
            elif pct > 5:
                assessment = "Moderate contributor"
            elif pct > 1:
                assessment = "Minor contributor"
            else:
                assessment = "Negligible"
            lines.append(f"| {rank} | `{feat}` | {imp:.4f} | {pct:.1f}% | {cum:.1f}% | {assessment} |")

        lines.append("")
        lines.append("### Concentration Analysis\n")
        top3_pct = sum(v for _, v in sorted_imp[:3]) / total_imp * 100
        top5_pct = sum(v for _, v in sorted_imp[:5]) / total_imp * 100
        lines.append(f"- Top 3 features account for **{top3_pct:.1f}%** of total importance")
        lines.append(f"- Top 5 features account for **{top5_pct:.1f}%** of total importance")
        if top3_pct > 60:
            lines.append(f"- **Concentration risk:** High feature concentration detected. "
                         f"Model output is materially dependent on a small number of inputs.")
        lines.append("")
        lines.append("### Feature Stability\n")
        lines.append("Feature stability should be monitored using Characteristic Stability Index (CSI) "
                     "for each feature. CSI thresholds:\n")
        lines.append("| CSI Range | Interpretation | Action |")
        lines.append("|-----------|---------------|--------|")
        lines.append("| < 0.10 | Stable | Continue monitoring |")
        lines.append("| 0.10 - 0.25 | Moderate shift | Investigate root cause |")
        lines.append("| > 0.25 | Significant shift | Trigger model review |")

        return DocumentSection(title="Feature Analysis", content="\n".join(lines))

    def _performance_analysis(self, model) -> DocumentSection:
        if not model or not model.performance_metrics:
            return DocumentSection(title="Performance Analysis",
                content="No performance metrics available for analysis.")

        pm = model.performance_metrics
        auc = pm.get("auc_roc", 0)
        ks = pm.get("ks_statistic", 0)
        gini = pm.get("gini_coefficient", 0)
        baseline = pm.get("baseline_auc_logreg")

        lines = [
            "### Regulatory Requirement (SR 11-7, Section V.C)\n",
            "Outcomes analysis compares model outputs with actual outcomes to assess model accuracy "
            "and identify potential areas of weakness. This analysis should cover a range of metrics "
            "and include testing across relevant segments.\n",
            "### Discrimination Metrics\n",
            "| Metric | Value | Rating | Threshold Basis | Assessment |",
            "|--------|-------|--------|-----------------|------------|",
            f"| AUC-ROC | {auc:.4f} | **{self._rate(auc, self.AUC_THRESHOLDS)}** | Industry standard for consumer credit | {'Meets minimum requirements' if auc >= 0.65 else 'Below minimum acceptable threshold'} |",
            f"| KS Statistic | {ks:.4f} | **{self._rate(ks, self.KS_THRESHOLDS)}** | Regulatory expectation for lending models | {'Adequate separation' if ks >= 0.20 else 'Insufficient separation between classes'} |",
            f"| Gini Coefficient | {gini:.4f} | **{self._rate(gini, self.GINI_THRESHOLDS)}** | 2*AUC-1 transformation | {'Acceptable discriminatory power' if gini >= 0.30 else 'Weak discriminatory power'} |",
            "",
            "### Rating Scale Reference\n",
            "| Rating | AUC Range | KS Range | Gini Range |",
            "|--------|-----------|----------|------------|",
            "| Excellent | > 0.90 | > 0.40 | > 0.80 |",
            "| Good | 0.80 - 0.90 | 0.30 - 0.40 | 0.60 - 0.80 |",
            "| Acceptable | 0.70 - 0.80 | 0.20 - 0.30 | 0.40 - 0.60 |",
            "| Marginal | 0.60 - 0.70 | 0.10 - 0.20 | 0.20 - 0.40 |",
            "| Poor | < 0.60 | < 0.10 | < 0.20 |",
            "",
        ]

        if baseline is not None:
            lines.append("### Benchmark Comparison\n")
            lines.append("| Model | AUC-ROC | Relative Performance |")
            lines.append("|-------|---------|---------------------|")
            lines.append(f"| Baseline (Logistic Regression) | {baseline:.4f} | Reference |")
            lines.append(f"| Champion ({model.model_type}) | {auc:.4f} | {(auc - baseline) / baseline * 100:+.1f}% |")
            lines.append("")
            if baseline > auc:
                lines.append("**WARNING:** The baseline logistic regression outperforms the champion model. "
                             "This is unusual and suggests potential issues with the champion model's "
                             "hyperparameter tuning, feature engineering, or overfitting to training data. "
                             "See Finding details for recommended remediation.\n")

        lines.append("### Calibration Assessment\n")
        lines.append("Model calibration (agreement between predicted probabilities and observed default rates) "
                     "should be assessed using the Hosmer-Lemeshow test or decile-level calibration plots. "
                     "Calibration analysis requires production outcome data and should be performed during "
                     "ongoing monitoring.\n")
        lines.append("### Population Stability\n")
        lines.append("Population Stability Index (PSI) measures the shift in score distributions between "
                     "development and recent production populations:\n")
        lines.append("| PSI Range | Interpretation | Action Required |")
        lines.append("|-----------|---------------|-----------------|")
        lines.append("| < 0.10 | No significant change | Standard monitoring |")
        lines.append("| 0.10 - 0.25 | Moderate change | Investigation required |")
        lines.append("| > 0.25 | Significant change | Model review triggered |")

        return DocumentSection(title="Performance Analysis", content="\n".join(lines))

    def _outcomes_analysis(self, model) -> DocumentSection:
        if not model:
            return DocumentSection(title="Outcomes Analysis", content="No model data available.")

        pm = model.performance_metrics or {}
        auc = pm.get("auc_roc")

        lines = [
            "### Backtesting Framework\n",
            "Backtesting compares model predictions against actual outcomes over defined performance "
            "windows. For credit risk models, the standard performance window is 12 months from "
            "origination for early-stage defaults and 24+ months for through-the-cycle assessment.\n",
            "**Required backtesting analyses:**\n",
            "1. **Cumulative accuracy profile:** Comparison of model rank-ordering against random and "
            "perfect models across deciles",
            "2. **Vintage analysis:** Performance comparison across origination vintages to detect "
            "temporal degradation",
            "3. **Segment analysis:** Performance evaluation across key risk segments (score bands, "
            "loan purpose, geography)",
            "4. **Stress testing:** Model performance under adverse economic scenarios\n",
            "### Sensitivity Analysis\n",
            "Sensitivity analysis evaluates the model's robustness to perturbations in input features. "
            "This helps identify features with outsized influence on model output and assess model "
            "behavior at boundary conditions.\n",
            "**Recommended sensitivity tests:**\n",
            "- **Feature perturbation:** Systematically vary each feature by +/-1 standard deviation and "
            "measure output change",
            "- **Feature removal:** Sequentially remove features and measure AUC degradation",
            "- **Boundary conditions:** Test model behavior at extreme input values (0th, 1st, 99th, "
            "100th percentiles)\n",
        ]

        if auc is not None and auc < 0.65:
            lines.append("### Performance Concern\n")
            lines.append(f"With an AUC-ROC of {auc:.4f}, the model's discrimination power is below "
                         "the typical threshold for production credit models. Additional outcomes analysis "
                         "should focus on:\n")
            lines.append("1. Whether the model adds value beyond a random classifier for specific segments")
            lines.append("2. Whether alternative feature sets or model architectures could improve performance")
            lines.append("3. Whether the outcome definition (default criterion) is appropriate")

        return DocumentSection(title="Outcomes Analysis", content="\n".join(lines))

    def _fair_lending_review(self, model, context) -> DocumentSection:
        fairlens = context.get("fairlens_report")
        fm = model.fairness_metrics if model else {}

        lines = [
            "### Regulatory Requirement\n",
            "The Equal Credit Opportunity Act (ECOA) and its implementing regulation, Regulation B "
            "(12 CFR 1002), prohibit discrimination in credit transactions on the basis of race, color, "
            "religion, national origin, sex (including sexual orientation and gender identity), marital "
            "status, age, receipt of public assistance, or good faith exercise of Consumer Credit "
            "Protection Act rights.\n",
            "Per CFPB Circular 2023-03, creditors using AI/ML models must ensure that models do not "
            "unlawfully discriminate, that proxy variables are identified and mitigated, and that adverse "
            "action notices provide specific and accurate reasons for credit denials.\n",
        ]

        if fm:
            contam = fm.get("contaminated_model_detected", False)
            prot = fm.get("protected_attributes_tracked", [])
            clean = fm.get("protected_data_contamination", "")

            lines.append("### Protected Data Analysis\n")
            lines.append("| Check | Result | Status |")
            lines.append("|-------|--------|--------|")
            lines.append(f"| Protected attributes tracked | {', '.join(str(a) for a in prot) if prot else 'None'} | {'Active' if prot else 'Not configured'} |")
            lines.append(f"| Clean model contamination | {clean} | {'PASS' if 'none' in str(clean).lower() else 'FAIL'} |")
            lines.append(f"| Contaminated variant detected | {contam} | {'**FAIL - CRITICAL**' if contam else 'PASS'} |")
            lines.append("")

            if contam:
                lines.append("### CRITICAL: Protected Data Contamination Detected\n")
                lines.append("The provenance DAG audit detected that a model variant was constructed using "
                             "ECOA-protected attributes. Specifically, demographic data (age) was merged into "
                             "the feature engineering pipeline and incorporated into the risk score computation.\n")
                lines.append("**Regulatory Impact:**\n")
                lines.append("- Under 12 CFR 1002.6(a), age cannot be used as a basis for credit decisions "
                             "except as permitted by 12 CFR 1002.6(b)(2)")
                lines.append("- The contaminated model variant is **non-compliant** and must not be deployed")
                lines.append("- The clean model variant must be independently verified to confirm no "
                             "protected data leakage through the provenance DAG\n")
                lines.append("**Remediation Steps:**\n")
                lines.append("1. Quarantine contaminated model artifacts")
                lines.append("2. Verify clean model DAG shows zero protected data paths")
                lines.append("3. Implement pre-deployment ECOA compliance gates")
                lines.append("4. Document remediation for regulatory examination file")

        if fairlens:
            summary = fairlens.get("summary", {})
            lines.append("\n### FairLens Analysis Results\n")
            lines.append(f"- Critical findings: {summary.get('critical', 0)}")
            lines.append(f"- Warnings: {summary.get('warnings', 0)}")
            lines.append(f"- Proxy features detected: {summary.get('proxy_features_detected', 0)}")
            lines.append(f"- LDA candidates: {summary.get('lda_candidates_found', 0)}")
            findings = fairlens.get("findings", [])
            if findings:
                lines.append("\n**Detailed Findings:**\n")
                for f in findings:
                    sev = f.get("severity", "info").upper()
                    desc = f.get("description", "")
                    lines.append(f"- **[{sev}]** {desc}")

        return DocumentSection(title="Fair Lending Review", content="\n".join(lines))

    def _data_lineage(self, context) -> DocumentSection:
        dag_nodes = context.get("dag_nodes", [])
        dag_edges = context.get("dag_edges", [])

        if not dag_nodes:
            return DocumentSection(title="Data Lineage and Provenance",
                content="No DAG information available. Provenance tracking was not enabled for this pipeline.")

        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE"]
        op_nodes = [n for n in dag_nodes if n.get("type") in ("UNARY", "BINARY")]

        tables = {}
        for n in source_nodes:
            tbl = n.get("table", "unknown")
            col = n.get("column", "")
            prot = n.get("is_protected", False)
            if tbl not in tables:
                tables[tbl] = {"cols": [], "protected": False}
            tables[tbl]["cols"].append(col)
            if prot:
                tables[tbl]["protected"] = True

        lines = [
            "### Provenance DAG Overview\n",
            f"The data lineage DAG contains **{len(dag_nodes)}** nodes and **{len(dag_edges)}** edges, "
            f"tracking the complete computation flow from **{len(source_nodes)}** source columns "
            f"through **{len(op_nodes)}** computation steps.\n",
            "### Source Columns by Table\n",
        ]

        for tbl, info in sorted(tables.items()):
            prot_tag = " [ECOA PROTECTED]" if info["protected"] else ""
            lines.append(f"**{tbl}**{prot_tag}:")
            for col in sorted(info["cols"]):
                lines.append(f"- `{col}`")
            lines.append("")

        lines.append("### Computation Graph\n")
        lines.append("The following edges trace the data flow from source columns through "
                     "transformations to the final model output:\n")

        node_map = {n.get("id"): n for n in dag_nodes}
        for edge in dag_edges:
            src_name = edge.get("source_name") or node_map.get(edge.get("source"), {}).get("name", "?")
            tgt_name = edge.get("target_name") or node_map.get(edge.get("target"), {}).get("name", "?")
            lines.append(f"- `{src_name}` → `{tgt_name}`")

        lines.append("\n### Lineage Verification\n")
        lines.append("All data lineage is tracked via cryptographic provenance fingerprints computed "
                     "at each computation step. Any modification to source data or transformation "
                     "logic produces a different fingerprint, enabling tamper detection and full "
                     "reproducibility verification.")

        return DocumentSection(title="Data Lineage and Provenance", content="\n".join(lines))

    def _monitoring_plan(self, model) -> DocumentSection:
        lines = [
            "### Regulatory Requirement (SR 11-7, Section VI)\n",
            "Ongoing monitoring is essential to evaluate whether changes in products, exposures, "
            "activities, clients, or market conditions require model adjustment, redevelopment, "
            "or replacement. Monitoring should continue throughout the model's lifecycle.\n",
            "### Monitoring Framework\n",
            "| Metric | Frequency | Threshold (Warning) | Threshold (Action) | Owner |",
            "|--------|-----------|--------------------|--------------------|-------|",
            "| Population Stability Index (PSI) | Monthly | > 0.10 | > 0.25 | Model Owner |",
            "| AUC-ROC | Monthly | Decline > 5% from baseline | Decline > 10% from baseline | Model Owner |",
            "| KS Statistic | Monthly | Decline > 5% from baseline | Decline > 10% from baseline | Model Owner |",
            "| Feature CSI (top 5 features) | Monthly | > 0.10 | > 0.25 | Data Engineering |",
            "| Approval Rate | Monthly | Change > 10% MoM | Change > 20% MoM | Business |",
            "| Default Rate | Quarterly | Deviation > 15% from expected | Deviation > 30% from expected | Credit Risk |",
            "",
            "### Escalation Procedures\n",
            "1. **Warning threshold breach:** Model owner investigates root cause and documents "
            "findings within 10 business days",
            "2. **Action threshold breach:** Model Risk Management notified within 24 hours; "
            "formal review initiated within 5 business days",
            "3. **Multiple consecutive breaches:** Out-of-cycle revalidation triggered; model "
            "may be placed under enhanced monitoring or suspended pending review\n",
            "### Reporting Cadence\n",
            "| Report | Frequency | Audience |",
            "|--------|-----------|----------|",
            "| Performance Dashboard | Monthly | Model Owner, MRM |",
            "| Stability Report | Quarterly | Model Owner, MRM, Senior Management |",
            "| Annual Validation | Annual | MRM, Audit Committee, Regulators |",
            "| Ad Hoc Alert | As triggered | Model Owner, MRM |",
        ]
        return DocumentSection(title="Ongoing Monitoring Plan", content="\n".join(lines))

    def _governance(self, model) -> DocumentSection:
        lines = [
            "### Three Lines of Defense Framework\n",
            "| Line | Role | Responsibilities |",
            "|------|------|-----------------|",
            "| **First Line** | Model Owners / Developers | Model development, implementation, testing, "
            "documentation, ongoing performance monitoring. Ensure models are used within approved scope. |",
            "| **Second Line** | Model Risk Management | Independent validation, enterprise model inventory, "
            "model risk policy enforcement, challenge of first-line assumptions and methodologies. |",
            "| **Third Line** | Internal Audit | Assess effectiveness of MRM framework, verify policy "
            "adherence, report findings to board audit committee. |",
            "",
            "### Model Inventory Requirements\n",
            "All models must be registered in the enterprise model inventory with:\n",
            "- Model ID and name",
            "- Risk tier classification",
            "- Current validation status and date",
            "- Next scheduled validation date",
            "- Model owner and approval authority",
            "- Material change log\n",
            "### Validation Frequency\n",
            "| Model Risk Tier | Initial Validation | Ongoing Validation | Monitoring |",
            "|----------------|-------------------|-------------------|------------|",
            "| Tier 1 (Critical) | Pre-deployment | Annual | Monthly |",
            "| Tier 2 (Significant) | Pre-deployment | Every 18 months | Quarterly |",
            "| Tier 3 (Low) | Pre-deployment | Every 3 years | Semi-annually |",
            "",
            "Material changes to model inputs, methodology, or operating environment trigger "
            "out-of-cycle validation regardless of tier.\n",
            "### Model Change Management\n",
            "All modifications to production models require:\n",
            "1. Formal change request with impact assessment",
            "2. Independent review by MRM for material changes",
            "3. Testing in non-production environment",
            "4. Documentation of before/after comparison",
            "5. Approval by designated authority based on change materiality",
        ]

        if model and model.owner:
            lines.append(f"\n**Current Model Owner:** {model.owner}")
        if model and model.contact:
            lines.append(f"**Contact:** {model.contact}")

        return DocumentSection(title="Governance and Controls", content="\n".join(lines))

    def _appendix_dag(self, context) -> DocumentSection:
        dag_nodes = context.get("dag_nodes", [])
        dag_edges = context.get("dag_edges", [])

        if not dag_nodes and not dag_edges:
            return DocumentSection(title="Appendix A: Complete DAG Specification",
                content="No DAG specification available.")

        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE"]
        op_nodes = [n for n in dag_nodes if n.get("type") in ("UNARY", "BINARY")]

        lines = [
            f"Total nodes: **{len(dag_nodes)}** | Total edges: **{len(dag_edges)}**\n",
            "### Source Nodes\n",
            "| Name | Table | Column | Protected | Provenance |",
            "|------|-------|--------|-----------|------------|",
        ]
        for n in sorted(source_nodes, key=lambda x: x.get("name", "")):
            name = n.get("name", "unknown")
            tbl = n.get("table", "")
            col = n.get("column", "")
            prot = "Yes" if n.get("is_protected") else "No"
            prov = n.get("provenance", "")
            lines.append(f"| {name} | {tbl} | {col} | {prot} | `{prov}` |")

        lines.append("\n### Computation Nodes\n")
        lines.append("| Name | Type | Operation | Provenance |")
        lines.append("|------|------|-----------|------------|")
        for n in sorted(op_nodes, key=lambda x: x.get("name", "")):
            name = n.get("name", "unknown")
            ntype = n.get("type", "")
            op = n.get("operation", "")
            prov = n.get("provenance", "")
            lines.append(f"| {name} | {ntype} | {op} | `{prov}` |")

        lines.append("\n### Edges\n")
        node_map = {n.get("id"): n for n in dag_nodes}
        lines.append("| Source | Target |")
        lines.append("|--------|--------|")
        for edge in dag_edges:
            src_name = edge.get("source_name") or node_map.get(edge.get("source"), {}).get("name", "?")
            tgt_name = edge.get("target_name") or node_map.get(edge.get("target"), {}).get("name", "?")
            lines.append(f"| {src_name} | {tgt_name} |")

        return DocumentSection(title="Appendix A: Complete DAG Specification", content="\n".join(lines))

    def _appendix_regulatory(self) -> DocumentSection:
        lines = [
            "The following table maps report sections to specific regulatory requirements:\n",
            "| Report Section | Primary Regulatory Reference | Supplementary Guidance |",
            "|---------------|----------------------------|----------------------|",
            "| Executive Summary | SR 11-7, General Guidance | OCC 2011-12, pp. 1-3 |",
            "| Scope and Objectives | SR 11-7, Section III | OCC Comptroller's Handbook, Ch. 1 |",
            "| Model Description | SR 11-7, Section IV | OCC 2011-12, pp. 3-5 |",
            "| Conceptual Soundness | SR 11-7, Section V.A | OCC 2011-12, pp. 6-8 |",
            "| Data Assessment | SR 11-7, Section V.B | OCC 2011-12, pp. 8-10 |",
            "| Feature Analysis | SR 11-7, Section V.A-B | OCC Comptroller's Handbook, Ch. 3 |",
            "| Performance Analysis | SR 11-7, Section V.C | OCC 2011-12, pp. 10-12 |",
            "| Outcomes Analysis | SR 11-7, Section V.C | OCC 2011-12, pp. 10-12 |",
            "| Fair Lending Review | ECOA / 12 CFR 1002 | CFPB Circular 2023-03 |",
            "| Data Lineage | SR 11-7, Section V.B | OCC 2011-12, pp. 8-10 |",
            "| Monitoring Plan | SR 11-7, Section VI | OCC 2011-12, pp. 14-16 |",
            "| Governance | SR 11-7, Section VII | OCC 2011-12, pp. 16-19 |",
        ]
        return DocumentSection(title="Appendix B: Regulatory Cross-Reference", content="\n".join(lines))


class EUAIActTemplate(BaseTemplate):
    """EU AI Act Article 11 Technical Documentation template."""
    name = "EU AI Act Article 11 Technical Documentation"
    description = "Technical documentation required by the EU AI Act for high-risk AI systems"

    # Keywords in intended_use that indicate EU AI Act risk classification
    _HIGH_RISK_KEYWORDS = {
        "credit": ("High-Risk (Annex III, Section 5(b))", "Creditworthiness assessment and credit scoring"),
        "lending": ("High-Risk (Annex III, Section 5(b))", "Creditworthiness assessment and credit scoring"),
        "underwriting": ("High-Risk (Annex III, Section 5(b))", "Creditworthiness assessment and credit scoring"),
        "loan": ("High-Risk (Annex III, Section 5(b))", "Creditworthiness assessment and credit scoring"),
        "mortgage": ("High-Risk (Annex III, Section 5(b))", "Creditworthiness assessment and credit scoring"),
        "fraud": ("High-Risk (Annex III, Section 6(a))", "Law enforcement and fraud prevention"),
        "aml": ("High-Risk (Annex III, Section 6(a))", "Anti-money laundering and law enforcement"),
        "anti-money": ("High-Risk (Annex III, Section 6(a))", "Anti-money laundering and law enforcement"),
        "bsa": ("High-Risk (Annex III, Section 6(a))", "Bank Secrecy Act compliance"),
        "hiring": ("High-Risk (Annex III, Section 4(a))", "Employment and recruitment decisions"),
        "recruit": ("High-Risk (Annex III, Section 4(a))", "Employment and recruitment decisions"),
        "insurance": ("High-Risk (Annex III, Section 5(b))", "Insurance risk assessment and pricing"),
    }

    AUC_THRESHOLDS = [(0.90, "Excellent"), (0.80, "Good"), (0.70, "Acceptable"), (0.60, "Marginal")]

    @staticmethod
    def _rate(value: float, thresholds: list) -> str:
        for threshold, label in thresholds:
            if value >= threshold:
                return label
        return "Poor"

    def _classify_risk(self, model) -> tuple:
        """Classify the AI system risk level based on intended use.

        Returns (classification, reason) tuple.
        """
        if not model or not model.intended_use:
            return ("Undetermined", "Intended use not specified; risk classification requires manual review")
        use_lower = model.intended_use.lower()
        for keyword, (classification, reason) in self._HIGH_RISK_KEYWORDS.items():
            if keyword in use_lower:
                return (classification, reason)
        return ("Limited or Minimal Risk", "Intended use does not match Annex III high-risk categories; "
                "verify against Article 6 criteria and national implementing legislation")

    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        model = context.get("model")
        fairlens = context.get("fairlens_report")
        sections = []

        sections.append(DocumentSection(
            title="General Description of the AI System",
            content=self._general_description(model),
        ))
        sections.append(DocumentSection(
            title="Intended Purpose",
            content=self._intended_purpose(model),
        ))
        sections.append(DocumentSection(
            title="Design Specifications",
            content=self._design_specs(model, context),
        ))
        sections.append(DocumentSection(
            title="Data and Data Governance",
            content=self._data_governance(model, context),
        ))
        sections.append(DocumentSection(
            title="Performance and Robustness",
            content=self._performance(model),
        ))
        sections.append(DocumentSection(
            title="Human Oversight Measures",
            content=self._human_oversight(model, fairlens),
        ))
        sections.append(DocumentSection(
            title="Risk Management",
            content=self._risk_management(model, context),
        ))
        sections.append(DocumentSection(
            title="Logging and Traceability",
            content=self._logging_traceability(model, context),
        ))

        return sections

    def _general_description(self, model) -> str:
        if not model:
            return "No model metadata provided."

        classification, reason = self._classify_risk(model)
        is_high_risk = classification.startswith("High-Risk")

        lines = [
            f"**System Name:** {model.name}",
            f"**Version:** {model.version}",
            f"**Type:** {model.model_type}",
            f"**Framework:** {model.framework}",
            f"**Description:** {model.description or 'N/A'}",
            f"**Owner:** {model.owner or 'N/A'}",
            "",
            f"**Risk Classification:** {classification}",
            f"**Classification Basis:** {reason}",
            "",
            "**System Architecture (Article 11(1)(a)):**",
            f"Per Article 11 of the EU AI Act, this section describes the general logic of the "
            f"AI system and the algorithmic approach. The system employs a {model.model_type} "
            f"architecture implemented in {model.framework}, processing {model.feature_count} "
            f"input features through a supervised learning pipeline.",
            "",
            "**Development Methodology:**",
            "The system was developed following a structured machine learning lifecycle "
            "including data collection, feature engineering, model training, hyperparameter "
            "optimization, validation testing, and deployment readiness review.",
            "",
            "**Conformity Assessment Status:**",
        ]

        if is_high_risk:
            lines.append(
                f"This system is classified as **{classification}** under the EU AI Act. "
                f"A conformity assessment per Article 43 must be completed prior to placing "
                f"the system on the market. The assessment must verify compliance with "
                f"requirements in Chapter 2 (Articles 8-15), including risk management "
                f"(Article 9), data governance (Article 10), technical documentation "
                f"(Article 11), record-keeping (Article 12), transparency (Article 13), "
                f"human oversight (Article 14), and accuracy/robustness (Article 15)."
            )
        else:
            lines.append(
                "For high-risk AI systems under Annex III, a conformity assessment per "
                "Article 43 must be completed prior to placing the system on the market. "
                "The assessment must verify compliance with requirements in Chapter 2 "
                "(Articles 8-15). Based on current classification, a full conformity "
                "assessment may not be required, but documentation best practices should "
                "still be followed."
            )

        return "\n".join(lines)

    def _intended_purpose(self, model) -> str:
        lines = []
        lines.append(f"**Intended Use:** {model.intended_use if model else 'Not specified'}")
        lines.append(f"\n**Limitations:** {model.limitations if model else 'Not specified'}")

        if model and model.intended_use:
            classification, reason = self._classify_risk(model)
            lines.append(f"\n**Risk Classification for Intended Purpose:** {classification}")
            lines.append(f"The intended use of this system ({model.intended_use}) maps to: {reason}.")

            if classification.startswith("High-Risk"):
                lines.append(
                    "\nAs a high-risk AI system, the deployer must ensure that the system is "
                    "used in accordance with its intended purpose (Article 29) and that "
                    "natural persons assigned to human oversight are competent, properly "
                    "trained, and have the authority to override system decisions."
                )
        return "\n".join(lines)

    def _human_oversight(self, model, fairlens) -> str:
        lines = [
            "**Article 14 - Human Oversight Requirements:**",
            "High-risk AI systems shall be designed and developed in such a way that they "
            "can be effectively overseen by natural persons during the period in which "
            "they are in use. Human oversight shall aim to prevent or minimize the risks "
            "to health, safety, or fundamental rights that may emerge when a high-risk AI "
            "system is used in accordance with its intended purpose or under conditions "
            "of reasonably foreseeable misuse.",
            "",
            "The system must enable the individuals assigned to human oversight to:",
            "- Fully understand the capacities and limitations of the system",
            "- Correctly interpret the system's output",
            "- Decide not to use the system or to disregard, override, or reverse its output",
            "- Intervene on the operation or interrupt the system through a stop button",
            "",
            "**Oversight Checklist:**",
            "",
        ]

        has_owner = bool(model and model.owner)
        has_limitations = bool(model and model.limitations)
        has_metrics = bool(model and model.performance_metrics)
        has_fairlens = bool(fairlens)
        has_critical = has_fairlens and fairlens.get("summary", {}).get("critical", 0) > 0

        check_hitl = "[x]" if has_owner else "[ ]"
        check_override = "[x]" if has_limitations else "[ ]"
        check_escalation = "[x]" if has_owner else "[ ]"
        check_dashboards = "[x]" if has_metrics else "[ ]"

        lines.append(f"- {check_hitl} Human-in-the-loop decision points identified")
        lines.append(f"- {check_override} Override mechanisms documented")
        lines.append(f"- {check_escalation} Escalation procedures defined")
        lines.append(f"- {check_dashboards} Monitoring dashboards available")

        if model and model.owner:
            lines.append(f"\n**Designated Oversight Authority:** {model.owner}")
        if model and model.contact:
            lines.append(f"**Escalation Contact:** {model.contact}")

        if has_critical:
            critical_count = fairlens["summary"]["critical"]
            lines.append(
                f"\n**OVERSIGHT ALERT:** {critical_count} critical fairness finding(s) detected. "
                f"Enhanced human oversight is recommended per Article 14(4) until bias risks "
                f"are mitigated. All decisions should be subject to human review."
            )

        return "\n".join(lines)

    def _logging_traceability(self, model, context) -> str:
        dag_nodes = context.get("dag_nodes", [])
        dag_edges = context.get("dag_edges", [])

        lines = [
            "**Article 12 - Automatic Logging:**",
            "High-risk AI systems shall be designed and developed with capabilities "
            "enabling the automatic recording of events (logs) while the systems are "
            "operating. The logging capabilities shall conform to recognized standards "
            "or common specifications and ensure a level of traceability of the AI "
            "system's functioning throughout its lifecycle.",
            "",
            "**Required Log Content:**",
            "Logs must record, at minimum: the period of each use of the system, "
            "the reference database against which input data has been checked, the "
            "input data for which the search has led to a match, and the identification "
            "of the natural persons involved in the verification of results.",
            "",
            "**Implementation:**",
            "All model inputs, outputs, and intermediate computations are "
            "logged with provenance metadata enabling full traceability "
            "from any output back to source data.",
        ]

        if dag_nodes:
            lines.append(f"\n**Provenance DAG:**")
            lines.append(f"The system's data lineage is captured in a directed acyclic graph "
                        f"with {len(dag_nodes)} nodes and {len(dag_edges)} edges, providing "
                        f"complete traceability from source data to model output.")
            source_nodes = [n for n in dag_nodes if n.get("type") == "source"]
            if source_nodes:
                names = ", ".join(n.get("name", "unknown") for n in source_nodes)
                lines.append(f"**Source Data:** {names}")

        if model and model.training_date:
            lines.append(f"\n**Model Training Timestamp:** {model.training_date}")
        if model and model.owner:
            lines.append(f"**Responsible Party:** {model.owner}")

        return "\n".join(lines)

    def _design_specs(self, model, context) -> str:
        lines = []
        if model:
            lines.append(f"- Model type: {model.model_type}")
            lines.append(f"- Framework: {model.framework}")
            lines.append(f"- Features: {model.feature_count}")
            if model.training_rows:
                lines.append(f"- Training samples: {model.training_rows:,}")
            if model.hyperparameters:
                lines.append("\n**Hyperparameters:**\n")
                for k, v in model.hyperparameters.items():
                    lines.append(f"- `{k}`: {v}")
        dag_nodes = context.get("dag_nodes", [])
        if dag_nodes:
            lines.append(f"\n**Pipeline Complexity:** {len(dag_nodes)} computation nodes")
            source_nodes = [n for n in dag_nodes if n.get("type") == "source"]
            transform_nodes = [n for n in dag_nodes if n.get("type") == "transform"]
            if source_nodes or transform_nodes:
                lines.append(f"- Data sources: {len(source_nodes)}")
                lines.append(f"- Transformations: {len(transform_nodes)}")

        lines.append("\n**Transparency Requirements (Article 13):**")
        lines.append("High-risk AI systems must be designed to ensure their operation is "
                     "sufficiently transparent to enable users to interpret the system's output "
                     "and use it appropriately. Documentation must include the level of accuracy, "
                     "robustness, and cybersecurity against which the system has been tested, and "
                     "any known or foreseeable circumstances that may impact expected performance.")
        lines.append("\n**Accuracy Metrics Documentation:**")
        lines.append("Per Article 15, the system's declared levels of accuracy must be "
                     "communicated to deployers. Accuracy metrics, confidence intervals, "
                     "and any disaggregated performance results across relevant subgroups "
                     "must be documented and kept up to date following post-market monitoring.")

        if model and model.performance_metrics:
            auc = model.performance_metrics.get("AUC") or model.performance_metrics.get("auc_roc")
            if auc is not None:
                rating = self._rate(auc, self.AUC_THRESHOLDS)
                lines.append(f"\n**Declared Accuracy Level:** AUC = {auc:.4f} ({rating})")
            accuracy = model.performance_metrics.get("Accuracy") or model.performance_metrics.get("accuracy")
            if accuracy is not None:
                lines.append(f"**Classification Accuracy:** {accuracy:.4f}")

        return "\n".join(lines) or "No design specifications available."

    def _data_governance(self, model, context) -> str:
        lines = []
        pipeline = context.get("pipeline")
        fairlens = context.get("fairlens_report")
        if pipeline:
            lines.append(f"- Source tables: {', '.join(pipeline.source_tables) or 'N/A'}")
            lines.append(f"- Total columns: {pipeline.total_columns}")
            lines.append(f"- Total rows: {pipeline.total_rows:,}" if pipeline.total_rows else "")
        if model:
            lines.append(f"- Training samples: {model.training_rows:,}")
            lines.append(f"- Feature count: {model.feature_count}")

        lines.append("\n**Article 10 - Data Governance Requirements:**")
        lines.append("Training, validation, and testing datasets must be subject to appropriate "
                     "data governance and management practices. These practices shall concern: "
                     "the relevant design choices, data collection processes, data preparation "
                     "operations (annotation, labelling, cleaning, enrichment), formulation of "
                     "relevant assumptions, and an assessment of data availability, quantity, "
                     "and suitability.")

        lines.append("\n**Bias Examination:**")
        lines.append("Per Article 10(2)(f), training datasets shall be examined for possible "
                     "biases that are likely to affect the health and safety of persons or lead "
                     "to discrimination. Where biases are detected, appropriate measures to "
                     "detect, prevent, and mitigate them must be implemented.")
        if fairlens:
            summary = fairlens.get("summary", {})
            critical = summary.get("critical", 0)
            warnings = summary.get("warnings", 0)
            proxies = summary.get("proxy_features_detected", 0)
            lines.append(f"\n**Bias Examination Results:** {critical} critical finding(s), "
                        f"{warnings} warning(s), {proxies} proxy feature(s) detected.")
            if critical > 0:
                lines.append("Bias examination reveals critical issues requiring remediation "
                            "before deployment per Article 10(2)(f).")
            findings = fairlens.get("findings", [])
            for f in findings:
                sev = f.get("severity", "info").upper()
                desc = f.get("description", "")
                lines.append(f"- [{sev}] {desc}")

        lines.append("\n**Data Quality Criteria:**")
        lines.append("Datasets must meet appropriate levels of statistical quality. The provider "
                     "must assess data relevance, representativeness, accuracy, and completeness "
                     "with regard to the intended purpose of the AI system.")

        has_pipeline = bool(pipeline)
        has_quality_checks = bool(pipeline and pipeline.data_quality_checks)
        has_training_data = bool(model and model.training_rows)

        if has_quality_checks:
            passing = sum(1 for c in pipeline.data_quality_checks if c.get("status") == "pass")
            total = len(pipeline.data_quality_checks)
            lines.append(f"\n**Data Quality Check Results:** {passing}/{total} checks passing.")

        lines.append("\n**Data Protection Requirements:**")
        check_minimization = "[x]" if has_training_data and model and model.feature_count > 0 else "[ ]"
        check_consent = "[ ]"
        check_retention = "[x]" if has_pipeline and pipeline.owner else "[ ]"
        lines.append(f"- {check_minimization} Data minimization verified")
        lines.append(f"- {check_consent} GDPR consent documented")
        lines.append(f"- {check_retention} Data retention policy defined")
        return "\n".join(lines) or "No data governance information available."

    def _performance(self, model) -> str:
        lines = []
        has_metrics = bool(model and model.performance_metrics)

        if has_metrics:
            lines.append("**Declared Performance Metrics (Article 15):**\n")
            lines.append("| Metric | Value | Assessment |")
            lines.append("|--------|-------|------------|")
            pm = model.performance_metrics
            for m, v in pm.items():
                if isinstance(v, float):
                    assessment = ""
                    m_lower = m.lower().replace("-", "_").replace(" ", "_")
                    if m_lower in ("auc", "auc_roc"):
                        assessment = self._rate(v, self.AUC_THRESHOLDS)
                    elif m_lower == "accuracy" and v >= 0.90:
                        assessment = "High"
                    elif m_lower == "accuracy" and v >= 0.80:
                        assessment = "Adequate"
                    elif m_lower == "accuracy":
                        assessment = "Review recommended"
                    lines.append(f"| {m} | {v:.4f} | {assessment} |")
                else:
                    lines.append(f"| {m} | {v} | |")

            auc = pm.get("AUC") or pm.get("auc_roc")
            if auc is not None:
                rating = self._rate(auc, self.AUC_THRESHOLDS)
                lines.append(f"\n**Overall Discrimination Assessment:** {rating} "
                            f"(AUC = {auc:.4f})")
                if auc < 0.70:
                    lines.append("**WARNING:** AUC below 0.70 indicates the model may not "
                                "meet the accuracy requirements of Article 15 for high-risk "
                                "systems. Remediation or enhanced monitoring is recommended.")
        else:
            lines.append("No performance metrics available. Article 15 requires that levels "
                        "of accuracy and relevant accuracy metrics be declared for high-risk "
                        "AI systems.")

        lines.append("\n**Article 15 - Accuracy and Robustness:**")
        lines.append("High-risk AI systems shall be designed and developed in such a way that "
                     "they achieve an appropriate level of accuracy, robustness, and cybersecurity "
                     "and perform consistently in those respects throughout their lifecycle. The "
                     "levels of accuracy and the relevant accuracy metrics shall be declared in "
                     "the accompanying instructions of use.")
        lines.append("\n**Article 9 - Performance Consistency:**")
        lines.append("The risk management system shall ensure that the AI system achieves "
                     "consistent performance across foreseeable conditions of use. Performance "
                     "must be validated against the declared metrics, and degradation thresholds "
                     "must be established to trigger corrective action.")

        check_adversarial = "[x]" if has_metrics else "[ ]"
        check_drift = "[x]" if has_metrics else "[ ]"
        check_fallback = "[x]" if model and model.owner else "[ ]"

        lines.append("\n**Robustness Requirements:**")
        lines.append(f"- {check_adversarial} Adversarial testing completed")
        lines.append(f"- {check_drift} Distribution shift monitoring configured")
        lines.append(f"- {check_fallback} Fallback mechanisms defined")
        return "\n".join(lines)

    def _risk_management(self, model, context) -> str:
        fairlens = context.get("fairlens_report")
        has_metrics = bool(model and model.performance_metrics)
        has_fairlens = bool(fairlens)
        has_owner = bool(model and model.owner)

        classification, _ = self._classify_risk(model) if model else ("Undetermined", "")
        is_high_risk = classification.startswith("High-Risk")

        lines = [
            "**Article 9 - Risk Management System:**\n",
            "A risk management system shall be established, implemented, documented, and "
            "maintained in relation to high-risk AI systems. The risk management system "
            "shall be a continuous iterative process planned and run throughout the entire "
            "lifecycle of the AI system, requiring regular systematic review and updating.\n",
            "**Risk Management Steps:**",
            "1. **Identification** of known and reasonably foreseeable risks to health, "
            "safety, or fundamental rights",
            "2. **Estimation and evaluation** of risks that may emerge when the system is "
            "used in accordance with its intended purpose and under conditions of "
            "reasonably foreseeable misuse",
            "3. **Evaluation** of other risks based on post-market monitoring data",
            "4. **Adoption of appropriate risk management measures** to address identified "
            "risks, including design choices, testing, and residual risk mitigation\n",
            "**Risk Categories (per EU AI Act):**\n",
        ]

        check_unacceptable = "[x]"
        check_high_risk = "[x]" if is_high_risk else "[ ]"
        check_bias = "[x]" if has_fairlens else "[ ]"
        check_security = "[x]" if has_metrics else "[ ]"
        check_transparency = "[x]" if has_owner and has_metrics else "[ ]"

        lines.append(f"- {check_unacceptable} Unacceptable risk assessment: N/A (not a prohibited use case)")
        lines.append(f"- {check_high_risk} High-risk classification: {classification}")
        lines.append(f"- {check_bias} Bias and fairness risks assessed")
        lines.append(f"- {check_security} Security and robustness risks assessed")
        lines.append(f"- {check_transparency} Transparency requirements met")

        if has_fairlens:
            summary = fairlens.get("summary", {})
            critical = summary.get("critical", 0)
            warnings = summary.get("warnings", 0)
            lines.append(f"\n**Fairness Risk Assessment:**")
            lines.append(f"FairLens analysis detected {critical} critical finding(s) and "
                        f"{warnings} warning(s).")
            if critical > 0:
                lines.append(f"\n**ALERT:** FairLens detected {critical} critical fairness finding(s). "
                            f"Per Article 9(2)(a), these risks to fundamental rights require "
                            f"documented mitigation measures before deployment.")
                findings = fairlens.get("findings", [])
                for f in findings:
                    if f.get("severity") == "critical":
                        lines.append(f"- CRITICAL: {f.get('description', '')}")

            di_results = fairlens.get("disparate_impact", [])
            if di_results:
                lines.append("\n**Disparate Impact Risk Summary:**\n")
                lines.append("| Protected Attribute | DI Ratio | Status |")
                lines.append("|--------------------:|:--------:|:------:|")
                for di in di_results:
                    attr = di.get("protected_attribute", "unknown")
                    ratio = di.get("worst_ratio", 0)
                    has_di = di.get("has_disparate_impact", False)
                    status = "FAIL (< 0.80)" if has_di else "PASS"
                    lines.append(f"| {attr} | {ratio:.2f} | {status} |")

        if has_metrics and model:
            auc = model.performance_metrics.get("AUC") or model.performance_metrics.get("auc_roc")
            if auc is not None and auc < 0.70:
                lines.append(f"\n**Performance Risk:** AUC of {auc:.4f} is below the 0.70 "
                            f"threshold. This introduces accuracy risk per Article 15.")

        return "\n".join(lines)


class ModelCardTemplate(BaseTemplate):
    """
    Model Card template per Mitchell et al. (2019).

    Produces comprehensive model documentation suitable for regulatory
    examination, internal model governance, and external stakeholder review.
    """
    name = "Model Card"
    description = "Standardized model documentation per Mitchell et al. (2019)"

    AUC_THRESHOLDS = [(0.90, "Excellent"), (0.80, "Good"), (0.70, "Acceptable"), (0.60, "Marginal")]
    KS_THRESHOLDS = [(0.40, "Strong"), (0.30, "Good"), (0.20, "Moderate"), (0.10, "Weak")]
    GINI_THRESHOLDS = [(0.80, "Excellent"), (0.60, "Good"), (0.40, "Acceptable"), (0.20, "Marginal")]

    @staticmethod
    def _rate(value: float, thresholds: list) -> str:
        for threshold, label in thresholds:
            if value >= threshold:
                return label
        return "Poor"

    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        model = context.get("model")
        dag_nodes = context.get("dag_nodes", [])
        dag_edges = context.get("dag_edges", [])
        fairlens = context.get("fairlens_report")
        sections = []

        sections.append(DocumentSection(
            title="Document Control",
            content=self._document_control(model),
        ))
        sections.append(DocumentSection(
            title="1. Model Details",
            content=self._model_details(model),
        ))
        sections.append(DocumentSection(
            title="2. Intended Use",
            content=self._intended_use(model),
        ))
        sections.append(DocumentSection(
            title="3. Model Architecture & Hyperparameters",
            content=self._architecture(model),
        ))
        sections.append(DocumentSection(
            title="4. Training Data",
            content=self._training_data(model, dag_nodes),
        ))
        sections.append(DocumentSection(
            title="5. Evaluation Data & Methodology",
            content=self._evaluation_data(model),
        ))
        sections.append(DocumentSection(
            title="6. Performance Metrics",
            content=self._metrics(model),
        ))
        sections.append(DocumentSection(
            title="7. Feature Analysis",
            content=self._feature_analysis(model),
        ))
        sections.append(DocumentSection(
            title="8. Data Lineage & Provenance",
            content=self._data_lineage(model, dag_nodes, dag_edges),
        ))
        sections.append(DocumentSection(
            title="9. Ethical Considerations & Fairness",
            content=self._ethical(model, context),
        ))
        sections.append(DocumentSection(
            title="10. Caveats, Limitations & Risks",
            content=self._caveats(model),
        ))
        sections.append(DocumentSection(
            title="11. Deployment & Monitoring Plan",
            content=self._monitoring(model),
        ))
        sections.append(DocumentSection(
            title="Appendix A: Complete DAG Specification",
            content=self._appendix_dag(dag_nodes, dag_edges),
        ))
        sections.append(DocumentSection(
            title="Appendix B: Regulatory Cross-Reference",
            content=self._appendix_regulatory(),
        ))

        return sections

    def _document_control(self, model) -> str:
        name = model.name if model else "N/A"
        version = model.version if model else "N/A"
        date = model.training_date if model and model.training_date else "N/A"
        owner = model.owner if model and model.owner else "N/A"
        lines = [
            "| Field | Value |",
            "|-------|-------|",
            f"| Document Type | Model Card (per Mitchell et al., 2019) |",
            f"| Model Name | {name} |",
            f"| Model Version | {version} |",
            f"| Document Date | {date} |",
            f"| Document Owner | {owner} |",
            f"| Classification | Internal / Regulatory |",
            "",
            "**Distribution:**",
            "This Model Card is intended for model governance committees, risk management, "
            "regulatory examiners, and internal audit. It provides a comprehensive record "
            "of the model's purpose, development, performance characteristics, and known "
            "limitations per the Mitchell et al. (2019) framework for model transparency.",
        ]
        return "\n".join(lines)

    def _model_details(self, model) -> str:
        if not model:
            return "No model metadata provided."
        lines = [
            "| Attribute | Value |",
            "|-----------|-------|",
            f"| Model Name | {model.name} |",
            f"| Version | {model.version} |",
            f"| Model Type | {model.model_type} |",
            f"| Framework | {model.framework} |",
            f"| Training Date | {model.training_date or 'N/A'} |",
            f"| Owner | {model.owner or 'N/A'} |",
            f"| Contact | {model.contact or 'N/A'} |",
            f"| Training Samples | {model.training_rows:,} |",
            f"| Feature Count | {model.feature_count} |",
            "",
            "**Development Process:**",
            "The model was developed through an iterative process including: (1) exploratory "
            "data analysis and feature profiling, (2) feature engineering with provenance "
            "tracking, (3) algorithm benchmarking across multiple model families, "
            "(4) hyperparameter optimization, and (5) holdout validation. All development "
            "artifacts are versioned and tracked via the data provenance DAG.",
            "",
            "**License:** Proprietary; contact model owner for licensing terms.",
            "",
            f"**Citation:** {model.name} v{model.version}, {model.owner or 'N/A'}, "
            f"{model.training_date or 'N/A'}.",
        ]
        return "\n".join(lines)

    def _intended_use(self, model) -> str:
        lines = []
        lines.append("**Primary Intended Uses:**")
        lines.append(model.intended_use if model and model.intended_use else "Not specified.")
        lines.append("")
        lines.append("**Primary Intended Users:**")
        lines.append("Credit risk analysts, underwriters, and automated decisioning systems "
                     "operating under human oversight.")
        lines.append("")
        lines.append("**Out-of-Scope Uses:**")
        lines.append(model.limitations if model and model.limitations else "Not specified.")
        lines.append("")
        lines.append("**Use Restrictions:**")
        lines.append("This model must not be used as the sole basis for credit decisions "
                     "without human review for applications exceeding established exposure "
                     "thresholds. The model must not be applied to populations materially "
                     "different from the training population without prior revalidation.")
        return "\n".join(lines)

    def _architecture(self, model) -> str:
        if not model:
            return "No model metadata provided."
        lines = [
            f"**Algorithm:** {model.model_type}",
            "",
        ]
        hp = model.hyperparameters if hasattr(model, "hyperparameters") and model.hyperparameters else {}
        if hp:
            lines.append("**Hyperparameters:**\n")
            lines.append("| Parameter | Value |")
            lines.append("|-----------|-------|")
            for k, v in hp.items():
                lines.append(f"| {k} | {v} |")
        else:
            lines.append("**Hyperparameters:** See model serialization artifact for full configuration.")
        lines.append("")
        lines.append("**Architecture Notes:**")
        lines.append(f"The {model.model_type} model processes {model.feature_count} input features "
                     f"trained on {model.training_rows:,} observations. Feature engineering "
                     f"transformations are tracked end-to-end via the provenance DAG, ensuring "
                     f"full reproducibility from raw source data to model input vectors.")
        return "\n".join(lines)

    def _training_data(self, model, dag_nodes) -> str:
        if not model:
            return "No training data information."
        lines = [
            "**Dataset Summary:**\n",
            "| Attribute | Value |",
            "|-----------|-------|",
            f"| Total Samples | {model.training_rows:,} |",
            f"| Feature Count | {model.feature_count} |",
        ]
        if model.tags:
            lines.append(f"| Tags | {', '.join(model.tags)} |")

        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE"]
        if source_nodes:
            tables = {}
            for n in source_nodes:
                t = n.get("table", "unknown")
                tables.setdefault(t, []).append(n.get("column", "unknown"))
            lines.append(f"| Source Tables | {len(tables)} |")
            lines.append(f"| Source Columns | {sum(len(c) for c in tables.values())} |")
        lines.append("")

        if source_nodes:
            lines.append("**Source Data Inventory:**\n")
            lines.append("| Table | Column | Protected |")
            lines.append("|-------|--------|-----------|")
            for n in source_nodes:
                t = n.get("table", "unknown")
                c = n.get("column", "unknown")
                p = "Yes" if n.get("is_protected") else "No"
                lines.append(f"| {t} | {c} | {p} |")
            lines.append("")

        lines.append("**Data Provenance:**")
        lines.append("All training data transformations from raw source to model-ready features "
                     "are captured in the provenance DAG. Each feature can be traced back to its "
                     "origin table and column through the full chain of transformations.")
        lines.append("")
        lines.append("**Preprocessing:**")
        lines.append("Standard preprocessing includes missing value imputation, categorical "
                     "encoding, feature scaling, and outlier treatment. The specific preprocessing "
                     "pipeline is documented in the provenance DAG computation graph.")
        return "\n".join(lines)

    def _evaluation_data(self, model) -> str:
        lines = [
            "**Evaluation Methodology:**",
            "The evaluation dataset is drawn from the same population as the training "
            "data using stratified sampling to preserve class distribution. Temporal "
            "splits are preferred over random splits for time-dependent data to avoid "
            "data leakage and simulate production conditions.",
            "",
            "**Holdout Strategy:**",
            "A minimum 20% holdout set is reserved for final model evaluation. The "
            "holdout set is not used during any phase of model development, including "
            "feature selection or hyperparameter tuning, to prevent optimistic bias.",
            "",
            "**Stratified Analysis Requirements:**",
            "Model performance must be evaluated across meaningful subgroups:",
            "- Demographic segments (race, sex, age groups)",
            "- Risk score deciles",
            "- Geographic regions",
            "- Origination channels",
            "",
            "Significant performance gaps across subgroups (defined as >5% relative "
            "deviation from aggregate) trigger mandatory investigation and remediation.",
        ]
        return "\n".join(lines)

    def _metrics(self, model) -> str:
        if not model or not model.performance_metrics:
            return "No metrics available."
        pm = model.performance_metrics
        lines = [
            "**Performance Summary:**\n",
            "| Metric | Value | Rating | Threshold Basis |",
            "|--------|-------|--------|-----------------|",
        ]
        for m, v in pm.items():
            if not isinstance(v, (int, float)):
                lines.append(f"| {m} | {v} | - | - |")
                continue
            if "auc" in m.lower():
                rating = self._rate(v, self.AUC_THRESHOLDS)
                basis = ">0.90 Excellent, >0.80 Good, >0.70 Acceptable, >0.60 Marginal"
            elif "ks" in m.lower():
                rating = self._rate(v, self.KS_THRESHOLDS)
                basis = ">0.40 Strong, >0.30 Good, >0.20 Moderate, >0.10 Weak"
            elif "gini" in m.lower():
                rating = self._rate(v, self.GINI_THRESHOLDS)
                basis = ">0.80 Excellent, >0.60 Good, >0.40 Acceptable, >0.20 Marginal"
            else:
                rating = "-"
                basis = "-"
            lines.append(f"| {m} | {v:.4f} | {rating} | {basis} |")

        lines.append("")
        lines.append("**Benchmark Comparison:**")
        baseline = pm.get("baseline_auc_logreg")
        champion = pm.get("auc_roc")
        if baseline is not None and champion is not None:
            delta = champion - baseline
            lines.append(f"- Champion Model AUC: {champion:.4f}")
            lines.append(f"- Baseline (Logistic Regression) AUC: {baseline:.4f}")
            lines.append(f"- Delta: {delta:+.4f} ({'Champion outperforms' if delta > 0 else 'Baseline outperforms'})")
        else:
            lines.append("No baseline comparison available.")

        lines.append("")
        lines.append("**Calibration Assessment:**")
        lines.append("Model calibration should be evaluated using calibration plots (predicted "
                     "probability vs. observed frequency) across score deciles. A well-calibrated "
                     "model has calibration slope near 1.0 and intercept near 0.0.")
        return "\n".join(lines)

    def _feature_analysis(self, model) -> str:
        if not model:
            return "No model metadata provided."
        fi = model.feature_importance if hasattr(model, "feature_importance") and model.feature_importance else {}
        if not fi:
            return ("Feature importance analysis not available in model metadata. "
                    "Consult model artifacts for SHAP values or permutation importance results.")

        sorted_feats = sorted(fi.items(), key=lambda x: abs(x[1]), reverse=True)
        total = sum(abs(v) for _, v in sorted_feats) or 1.0
        lines = [
            "**Feature Importance Ranking:**\n",
            "| Rank | Feature | Importance | % of Total | Cumulative % |",
            "|------|---------|------------|------------|--------------|",
        ]
        cumulative = 0.0
        for rank, (feat, imp) in enumerate(sorted_feats, 1):
            pct = abs(imp) / total * 100
            cumulative += pct
            lines.append(f"| {rank} | {feat} | {abs(imp):.4f} | {pct:.1f}% | {cumulative:.1f}% |")

        lines.append("")
        top3_pct = sum(abs(v) for _, v in sorted_feats[:3]) / total * 100 if len(sorted_feats) >= 3 else 0
        lines.append(f"**Concentration Analysis:** Top 3 features account for {top3_pct:.1f}% of total importance.")
        if top3_pct > 60:
            lines.append("*Note:* Feature concentration exceeds 60%. High concentration increases "
                        "model fragility if dominant features experience drift or data quality issues.")
        lines.append("")
        negligible = [f for f, v in sorted_feats if abs(v) / total < 0.005]
        if negligible:
            lines.append(f"**Negligible Features ({len(negligible)}):** "
                        f"{', '.join(negligible[:10])}")
            lines.append("Features contributing <0.5% of total importance should be evaluated "
                        "for removal to reduce model complexity without meaningful performance loss.")
        return "\n".join(lines)

    def _data_lineage(self, model, dag_nodes, dag_edges) -> str:
        lines = [
            "**Provenance DAG Summary:**\n",
            f"The data lineage graph contains **{len(dag_nodes)} nodes** and "
            f"**{len(dag_edges)} edges**, providing full traceability from source "
            f"data through all transformations to model outputs.",
            "",
        ]
        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE"]
        op_nodes = [n for n in dag_nodes if n.get("type") != "SOURCE"]

        if source_nodes:
            lines.append(f"**Source Nodes ({len(source_nodes)}):**\n")
            lines.append("| Node | Table | Column | Protected |")
            lines.append("|------|-------|--------|-----------|")
            for n in source_nodes:
                lines.append(f"| {n.get('name', 'unknown')} | {n.get('table', '-')} | "
                           f"{n.get('column', '-')} | {'Yes' if n.get('is_protected') else 'No'} |")
            lines.append("")

        if op_nodes:
            type_counts = {}
            for n in op_nodes:
                t = n.get("type", "UNKNOWN")
                type_counts[t] = type_counts.get(t, 0) + 1
            lines.append(f"**Computation Nodes ({len(op_nodes)}):**\n")
            lines.append("| Operation Type | Count |")
            lines.append("|---------------|-------|")
            for t, c in sorted(type_counts.items()):
                lines.append(f"| {t} | {c} |")
            lines.append("")

            op_counts = {}
            for n in op_nodes:
                op = n.get("operation", "unknown")
                op_counts[op] = op_counts.get(op, 0) + 1
            lines.append("**Operations Breakdown:**\n")
            lines.append("| Operation | Count |")
            lines.append("|-----------|-------|")
            for op, c in sorted(op_counts.items(), key=lambda x: -x[1]):
                lines.append(f"| {op} | {c} |")

        return "\n".join(lines)

    def _ethical(self, model, context) -> str:
        lines = []
        fairlens = context.get("fairlens_report")

        lines.append("**Fairness Assessment Overview:**\n")

        if fairlens:
            di = fairlens.get("disparate_impact", [])
            if di:
                lines.append("**Disparate Impact Results:**\n")
                lines.append("| Protected Attribute | Impact Ratio | Four-Fifths Test |")
                lines.append("|---------------------|--------------|------------------|")
                for d in di:
                    attr = d.get("protected_attribute", "unknown")
                    ratio = d.get("worst_ratio", 0)
                    status = "FAIL" if d.get("has_disparate_impact") else "PASS"
                    lines.append(f"| {attr} | {ratio:.3f} | {status} |")
                lines.append("")

            proxies = fairlens.get("proxy_detection", [])
            if proxies:
                lines.append("**Proxy Variable Detection:**\n")
                lines.append("| Feature | Protected Attribute | Correlation |")
                lines.append("|---------|---------------------|-------------|")
                for p in proxies:
                    lines.append(f"| {p.get('feature_name', '?')} | "
                               f"{p.get('protected_attribute', '?')} | "
                               f"{p.get('correlation', 0):.3f} |")
                lines.append("")

            findings = fairlens.get("findings", [])
            critical = [f for f in findings if f.get("severity") == "critical"]
            if critical:
                lines.append("**Critical Fairness Findings:**\n")
                for f in critical:
                    lines.append(f"- {f.get('description', '')}")
                lines.append("")
            else:
                lines.append("No critical fairness concerns detected by FairLens analysis.\n")
        elif model and model.fairness_metrics:
            lines.append("**Fairness Metrics:**\n")
            for k, v in model.fairness_metrics.items():
                lines.append(f"- {k}: {v}")
            lines.append("")

            fm = model.fairness_metrics
            if fm.get("contaminated_model_detected"):
                lines.append("**CRITICAL: Protected Data Contamination Detected**")
                prot = fm.get("protected_attributes_tracked", [])
                lines.append(f"Protected attributes found in pipeline: "
                           f"{', '.join(str(a) for a in prot) if prot else 'unspecified'}")
                lines.append("Under ECOA (12 CFR 1002.6(a)), models must not incorporate "
                           "protected attributes. Immediate remediation required.\n")
        else:
            lines.append("No fairness analysis available. FairLens analysis is recommended "
                        "prior to production deployment.\n")

        lines.append("**Bias Mitigation Strategy:**")
        lines.append("1. Pre-processing: Data balancing, reweighting, or resampling")
        lines.append("2. In-processing: Fairness constraints during training")
        lines.append("3. Post-processing: Threshold adjustment, reject inference")
        lines.append("4. Monitoring: Ongoing disparate impact tracking in production")
        lines.append("")
        lines.append("**Intersectional Analysis:**")
        lines.append("Beyond single-attribute fairness metrics, intersectional analysis examines "
                     "outcomes at the intersection of multiple protected characteristics "
                     "(e.g., race and sex combined) to detect compounding disparities "
                     "not visible in single-dimension analysis.")
        lines.append("")
        lines.append("Intersectional analysis is recommended for the following high-priority "
                     "intersections, which should be evaluated at least quarterly:")
        lines.append("")
        lines.append("| Priority | Intersection | Rationale |")
        lines.append("|----------|-------------|-----------|")
        lines.append("| 1 | Race x Sex | Compound disparities in lending (e.g., Black Female applicants) |")
        lines.append("| 2 | Race x Age | Young minority applicants may face compounding thin-file and structural disadvantages |")
        lines.append("| 3 | Sex x Marital Status | Historical disparities in married vs. single women's credit access |")
        lines.append("")
        lines.append("Impact ratios below 0.80 for any intersectional subgroup with sufficient "
                     "sample size (N >= 100) warrant immediate investigation and potential "
                     "escalation to the Fair Lending Officer.")
        return "\n".join(lines)

    def _caveats(self, model) -> str:
        lines = [
            "**Known Limitations:**",
            model.limitations if model and model.limitations else "No specific limitations documented.",
            "",
            "**Population Drift Risk:**",
            "Model performance may degrade if the production population diverges "
            "materially from the training population. Key drift vectors include:",
            "- Macroeconomic regime changes (e.g., recession, rate environment shifts)",
            "- Regulatory or policy changes affecting applicant eligibility",
            "- Geographic expansion into markets not represented in training data",
            "- Product or channel mix changes",
            "",
            "**Data Quality Dependencies:**",
            "Model accuracy depends on the quality of input features. Known sensitivities:",
            "- Missing value rates exceeding training-time imputation assumptions",
            "- Bureau data refresh latency (stale credit attributes)",
            "- Third-party data vendor schema or coverage changes",
            "",
            "**Adversarial Robustness:**",
            "This model has not been stress-tested against adversarial inputs. "
            "Applications where adversarial manipulation is a concern (e.g., fraud) "
            "should implement additional input validation layers. Known vulnerability "
            "vectors include application data gaming, authorized-user tradeline additions, "
            "and synthetic identity fraud.",
            "",
            "**Model Decay Expectations:**",
            "Based on industry benchmarks and institutional experience, the following "
            "decay trajectory is anticipated:",
            "",
            "| Months Post-Deployment | Expected AUC Range | Expected PSI | Recommended Action |",
            "|------------------------|--------------------|--------------|--------------------|",
            "| 0-6 | Baseline ± 1% | <0.05 | Routine monitoring |",
            "| 6-12 | Baseline - 1-3% | 0.05-0.10 | Enhanced monitoring |",
            "| 12-18 | Baseline - 3-5% | 0.10-0.15 | Revalidation assessment |",
            "| 18-24 | Baseline - 5%+ | 0.15-0.25 | Mandatory redevelopment |",
            "",
            "Annual revalidation is mandatory regardless of observed performance.",
        ]
        return "\n".join(lines)

    def _monitoring(self, model) -> str:
        lines = [
            "**Ongoing Monitoring Framework:**\n",
            "| Metric | Frequency | Threshold | Escalation |",
            "|--------|-----------|-----------|------------|",
            "| Population Stability Index (PSI) | Monthly | >0.10 Warning, >0.25 Action | Model Governance Committee |",
            "| Characteristic Stability Index (CSI) | Monthly | >0.10 per feature | Feature owner review |",
            "| AUC-ROC degradation | Monthly | >5% relative decline | Model revalidation trigger |",
            "| Gini degradation | Monthly | >5% relative decline | Model revalidation trigger |",
            "| Approval rate shift | Monthly | >10% absolute change | Business review |",
            "| Adverse action reason concentration | Quarterly | Top reason >40% of denials | Fair lending review |",
            "| Disparate impact ratio | Quarterly | <0.80 on any attribute | Immediate fair lending escalation |",
            "",
            "**Revalidation Triggers:**",
            "- Any monitoring metric breaching its action threshold",
            "- Material change to model inputs or feature engineering",
            "- Regulatory guidance updates affecting model use case",
            "- 12-month periodic revalidation cycle",
            "",
            "**Deployment Checklist:**",
            "- [ ] Input data pipeline validated against training schema",
            "- [ ] Monitoring dashboards configured and tested",
            "- [ ] Rollback procedures documented and rehearsed",
            "- [ ] Model governance committee sign-off obtained",
            "- [ ] Fair lending review completed",
            "- [ ] Adverse action reason code mapping validated",
        ]
        return "\n".join(lines)

    def _appendix_dag(self, dag_nodes, dag_edges) -> str:
        if not dag_nodes:
            return "No DAG data available."
        lines = [
            f"**Total Nodes:** {len(dag_nodes)}",
            f"**Total Edges:** {len(dag_edges)}",
            "",
        ]
        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE"]
        if source_nodes:
            lines.append("**Source Nodes:**\n")
            lines.append("| ID | Name | Table | Column | Protected |")
            lines.append("|----|------|-------|--------|-----------|")
            for n in source_nodes:
                lines.append(f"| {n.get('id', '?')} | {n.get('name', 'unknown')} | "
                           f"{n.get('table', '-')} | {n.get('column', '-')} | "
                           f"{'Yes' if n.get('is_protected') else 'No'} |")
            lines.append("")

        comp_nodes = [n for n in dag_nodes if n.get("type") != "SOURCE"]
        if comp_nodes:
            lines.append("**Computation Nodes:**\n")
            lines.append("| ID | Name | Type | Operation | Provenance |")
            lines.append("|----|------|------|-----------|------------|")
            for n in comp_nodes:
                lines.append(f"| {n.get('id', '?')} | {n.get('name', 'unknown')} | "
                           f"{n.get('type', '?')} | {n.get('operation', '-')} | "
                           f"{n.get('provenance', '-')} |")
        return "\n".join(lines)

    def _appendix_regulatory(self) -> str:
        lines = [
            "**Model Card Framework Reference:**\n",
            "| Section | Reference |",
            "|---------|-----------|",
            "| Model Details | Mitchell et al. (2019) Section 2 |",
            "| Intended Use | Mitchell et al. (2019) Section 3 |",
            "| Training Data | Mitchell et al. (2019) Section 5 |",
            "| Performance Metrics | Mitchell et al. (2019) Section 6 |",
            "| Ethical Considerations | Mitchell et al. (2019) Section 7 |",
            "| Caveats | Mitchell et al. (2019) Section 8 |",
            "| Data Lineage | SR 11-7 / OCC 2011-12 (Supplemental) |",
            "| Monitoring Plan | SR 11-7 Section V.D: Ongoing Monitoring |",
            "| Fair Lending | ECOA / 12 CFR 1002 / CFPB Circular 2023-03 |",
            "",
            "**Applicable Standards:**",
            "- Mitchell et al., 'Model Cards for Model Reporting' (2019)",
            "- SR 11-7: Guidance on Model Risk Management",
            "- OCC 2011-12: Sound Practices for Model Risk Management",
            "- ECOA / Regulation B (12 CFR 1002)",
            "- CFPB Circular 2023-03: Adverse Action Notification Requirements",
            "- EU AI Act Article 13: Transparency & Provision of Information",
        ]
        return "\n".join(lines)


class ECOATemplate(BaseTemplate):
    """
    ECOA Fair Lending Compliance Review template.

    Produces audit-quality fair lending methodology documentation per
    Regulation B (12 CFR 1002), CFPB examination procedures, and
    interagency fair lending guidance.
    """
    name = "ECOA Fair Lending Compliance Review"
    description = "ECOA/Reg B (12 CFR 1002) fair lending methodology documentation"

    def _generate_findings(self, model, fairlens, dag_nodes) -> list:
        findings = []
        fid = 1

        fm = model.fairness_metrics if model else {}
        if fm.get("contaminated_model_detected"):
            prot = fm.get("protected_attributes_tracked", [])
            prot_str = ", ".join(str(a) for a in prot) if prot else "unspecified attributes"
            findings.append({
                "id": f"FL-{fid:03d}", "severity": "CRITICAL",
                "category": "Prohibited Basis Data Contamination",
                "regulation": "12 CFR 1002.6(a)",
                "finding": (
                    f"Protected data contamination detected in the model development pipeline. "
                    f"ECOA-protected attributes ({prot_str}) were present in the computation graph. "
                    f"Under Regulation B Section 1002.6(a), a creditor shall not take into account "
                    f"race, color, religion, national origin, sex, marital status, or age in any "
                    f"aspect of a credit transaction."
                ),
                "recommendation": (
                    "IMMEDIATE ACTION REQUIRED: (1) Quarantine the contaminated model version and "
                    "halt deployment. (2) Verify the clean model variant via provenance DAG audit. "
                    "(3) Implement automated pre-deployment ECOA compliance gates. "
                    "(4) Document all remediation steps for the regulatory examination file."
                ),
            })
            fid += 1

        protected_sources = [n for n in dag_nodes if n.get("is_protected")]
        if protected_sources:
            tables = {}
            for n in protected_sources:
                t = n.get("table", "unknown")
                tables.setdefault(t, []).append(n.get("column", "unknown"))
            for table, cols in tables.items():
                findings.append({
                    "id": f"FL-{fid:03d}", "severity": "HIGH",
                    "category": "Protected Data in Pipeline",
                    "regulation": "12 CFR 1002.6(a); CFPB Exam Manual Module 4",
                    "finding": (
                        f"Table '{table}' contains {len(cols)} protected-class column(s): "
                        f"{', '.join(cols)}. These columns are tracked through the provenance DAG "
                        f"and must not influence model outputs directly or through proxy correlation."
                    ),
                    "recommendation": (
                        f"Verify that columns [{', '.join(cols)}] from table '{table}' are excluded "
                        f"from model feature vectors. Conduct proxy correlation analysis to confirm "
                        f"no indirect leakage via correlated features."
                    ),
                })
                fid += 1

        if fairlens:
            di = fairlens.get("disparate_impact", [])
            for d in di:
                if d.get("has_disparate_impact"):
                    attr = d.get("protected_attribute", "unknown")
                    ratio = d.get("worst_ratio", 0)
                    findings.append({
                        "id": f"FL-{fid:03d}", "severity": "HIGH",
                        "category": "Disparate Impact",
                        "regulation": "ECOA; Griggs v. Duke Power Co., 401 U.S. 424 (1971)",
                        "finding": (
                            f"Disparate impact detected on protected attribute '{attr}' with "
                            f"impact ratio {ratio:.3f}, below the four-fifths threshold of 0.80. "
                            f"This constitutes prima facie evidence of adverse impact requiring "
                            f"business necessity justification."
                        ),
                        "recommendation": (
                            f"(1) Document the legitimate business necessity for the model's treatment "
                            f"of '{attr}'. (2) Evaluate less discriminatory alternatives (LDA) that "
                            f"achieve comparable predictive performance. (3) If no LDA is available, "
                            f"document the business necessity analysis per interagency guidance."
                        ),
                    })
                    fid += 1

            proxies = fairlens.get("proxy_detection", [])
            for p in proxies:
                corr = p.get("correlation", 0)
                if abs(corr) >= 0.3:
                    findings.append({
                        "id": f"FL-{fid:03d}", "severity": "MEDIUM",
                        "category": "Proxy Variable Risk",
                        "regulation": "12 CFR 1002.6(a); Interagency Fair Lending Exam Procedures",
                        "finding": (
                            f"Feature '{p.get('feature_name', '?')}' has correlation {corr:.3f} "
                            f"with protected attribute '{p.get('protected_attribute', '?')}'. "
                            f"Features serving as proxies for prohibited bases may constitute "
                            f"disparate treatment even if the protected attribute is not directly used."
                        ),
                        "recommendation": (
                            f"Evaluate whether feature '{p.get('feature_name', '?')}' can be "
                            f"removed or replaced without material performance degradation. "
                            f"Conduct partial dependence analysis to quantify the feature's "
                            f"marginal effect on outcomes for the affected protected class."
                        ),
                    })
                    fid += 1

        if not findings:
            findings.append({
                "id": "FL-001", "severity": "INFORMATIONAL",
                "category": "Compliance Status",
                "regulation": "12 CFR 1002",
                "finding": "No fair lending violations identified in this review cycle.",
                "recommendation": "Continue periodic monitoring per the established schedule.",
            })

        return findings

    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        model = context.get("model")
        fairlens = context.get("fairlens_report")
        dag_nodes = context.get("dag_nodes", [])
        dag_edges = context.get("dag_edges", [])
        findings = self._generate_findings(model, fairlens, dag_nodes)
        sections = []

        sections.append(DocumentSection(
            title="Document Control",
            content=self._document_control(model),
        ))
        sections.append(DocumentSection(
            title="1. Executive Summary",
            content=self._executive_summary(model, findings, fairlens, dag_nodes),
        ))
        sections.append(DocumentSection(
            title="2. Regulatory Framework",
            content=self._regulatory_framework(),
        ))
        sections.append(DocumentSection(
            title="3. Model Under Review",
            content=self._model_overview(model, dag_nodes),
        ))
        sections.append(DocumentSection(
            title="4. Protected Attribute Inventory",
            content=self._protected_inventory(model, fairlens, dag_nodes),
        ))
        sections.append(DocumentSection(
            title="5. Disparate Impact Analysis",
            content=self._disparate_impact(fairlens),
        ))
        sections.append(DocumentSection(
            title="6. Proxy Variable Detection & Mitigation",
            content=self._proxy_detection(fairlens),
        ))
        sections.append(DocumentSection(
            title="7. Data Lineage & Contamination Audit",
            content=self._contamination_audit(model, dag_nodes, dag_edges),
        ))
        sections.append(DocumentSection(
            title="8. Less Discriminatory Alternatives (LDA)",
            content=self._lda_analysis(fairlens),
        ))
        sections.append(DocumentSection(
            title="9. Adverse Action Methodology",
            content=self._adverse_action(fairlens),
        ))
        sections.append(DocumentSection(
            title="10. Findings & Recommendations",
            content=self._findings_detail(findings),
        ))
        sections.append(DocumentSection(
            title="11. Remediation Plan & Timeline",
            content=self._remediation_plan(findings),
        ))
        sections.append(DocumentSection(
            title="12. Ongoing Monitoring Requirements",
            content=self._monitoring(),
        ))
        sections.append(DocumentSection(
            title="Appendix A: Complete Protected Data DAG Trace",
            content=self._appendix_dag(dag_nodes, dag_edges),
        ))
        sections.append(DocumentSection(
            title="Appendix B: Regulatory Cross-Reference",
            content=self._appendix_regulatory(),
        ))

        return sections

    def _document_control(self, model) -> str:
        name = model.name if model else "N/A"
        version = model.version if model else "N/A"
        date = model.training_date if model and model.training_date else "N/A"
        owner = model.owner if model and model.owner else "N/A"
        lines = [
            "| Field | Value |",
            "|-------|-------|",
            f"| Document Type | ECOA Fair Lending Compliance Review |",
            f"| Model Name | {name} |",
            f"| Model Version | {version} |",
            f"| Review Date | {date} |",
            f"| Review Owner | {owner} |",
            f"| Classification | Confidential - Regulatory |",
            f"| Regulatory Basis | ECOA / Regulation B (12 CFR 1002) |",
            "",
            "**Approvals:**\n",
            "| Role | Name | Date | Signature |",
            "|------|------|------|-----------|",
            "| Fair Lending Officer | ________________ | ________ | ________ |",
            "| Chief Compliance Officer | ________________ | ________ | ________ |",
            "| Model Risk Manager | ________________ | ________ | ________ |",
            "| Legal Counsel | ________________ | ________ | ________ |",
        ]
        return "\n".join(lines)

    def _executive_summary(self, model, findings, fairlens=None, dag_nodes=None) -> str:
        critical = sum(1 for f in findings if f["severity"] == "CRITICAL")
        high = sum(1 for f in findings if f["severity"] == "HIGH")
        medium = sum(1 for f in findings if f["severity"] == "MEDIUM")
        low = sum(1 for f in findings if f["severity"] == "LOW")
        info = sum(1 for f in findings if f["severity"] == "INFORMATIONAL")

        if critical > 0:
            overall = "NON-COMPLIANT - Immediate Remediation Required"
        elif high > 0:
            overall = "CONDITIONALLY COMPLIANT - Remediation Required"
        elif medium > 0:
            overall = "COMPLIANT WITH OBSERVATIONS"
        else:
            overall = "COMPLIANT"

        name = model.name if model else "the model under review"
        mtype = model.model_type if model else "N/A"

        lines = [
            f"**Overall Fair Lending Compliance Rating:** {overall}\n",
            f"This fair lending compliance review evaluates {name} ({mtype}) "
            f"for compliance with the Equal Credit Opportunity Act (ECOA) and its "
            f"implementing regulation, Regulation B (12 CFR 1002). The review was conducted "
            f"in accordance with the CFPB examination procedures for fair lending, "
            f"supplemental guidance from CFPB Circular 2023-03 regarding adverse action "
            f"notification requirements for models using complex algorithms, and the "
            f"institution's Fair Lending Policy.\n",
        ]

        # Key Performance Summary table (like reference report)
        lines.append("**Key Performance Summary:**\n")
        lines.append("| Metric | Value | Threshold | Status |")
        lines.append("|--------|-------|-----------|--------|")

        pm = model.performance_metrics if model else {}
        auc = pm.get("auc_roc")
        if auc is not None:
            status = "PASS" if auc >= 0.70 else "FAIL"
            lines.append(f"| Model AUC-ROC | {auc:.4f} | >0.70 | {status} |")

        # Compute min impact ratio from FairLens
        min_ratio = None
        min_attr = "N/A"
        if fairlens:
            di = fairlens.get("disparate_impact", [])
            for d in di:
                ratio = d.get("worst_ratio", 1.0)
                if min_ratio is None or ratio < min_ratio:
                    min_ratio = ratio
                    min_attr = d.get("protected_attribute", "unknown")
        if min_ratio is not None:
            status = "FAIL" if min_ratio < 0.80 else "PASS"
            lines.append(f"| Minimum Impact Ratio ({min_attr}) | {min_ratio:.3f} | >0.80 | {status} |")

        # Compute max proxy correlation from FairLens
        max_corr = 0
        max_proxy_feat = "N/A"
        if fairlens:
            proxies = fairlens.get("proxy_detection", [])
            for p in proxies:
                corr = abs(p.get("correlation", 0))
                if corr > max_corr:
                    max_corr = corr
                    max_proxy_feat = p.get("feature_name", "unknown")
        if max_corr > 0:
            status = "FAIL" if max_corr >= 0.30 else "PASS"
            lines.append(f"| Maximum Proxy Correlation ({max_proxy_feat}) | {max_corr:.3f} | <0.30 | {status} |")

        # Contamination status
        fm = model.fairness_metrics if model else {}
        contaminated = fm.get("contaminated_model_detected", False)
        lines.append(f"| Protected Attribute DAG Contamination | "
                    f"{'Detected' if contaminated else 'None Detected'} | No Paths | "
                    f"{'FAIL' if contaminated else 'PASS'} |")

        lines.append("")
        lines.append("**Findings Summary:**\n")
        lines.append("| Severity | Count | Finding IDs |")
        lines.append("|----------|-------|-------------|")

        def _ids(sev):
            return ", ".join(f["id"] for f in findings if f["severity"] == sev) or "-"

        lines.append(f"| CRITICAL | {critical} | {_ids('CRITICAL')} |")
        lines.append(f"| HIGH | {high} | {_ids('HIGH')} |")
        lines.append(f"| MEDIUM | {medium} | {_ids('MEDIUM')} |")
        lines.append(f"| LOW | {low} | {_ids('LOW')} |")
        lines.append(f"| INFORMATIONAL | {info} | {_ids('INFORMATIONAL')} |")

        if critical > 0:
            crit_findings = [f for f in findings if f["severity"] == "CRITICAL"]
            lines.append("")
            lines.append("**CRITICAL FINDINGS REQUIRE IMMEDIATE ATTENTION.** "
                        f"{crit_findings[0]['finding'][:200]}...")
            lines.append("")
            lines.append(f"Failure to remediate critical findings within the agreed-upon timeline "
                        f"will require the model to be suspended from automated decisioning.")
        elif high > 0:
            lines.append("")
            lines.append("The model may continue to be used for credit decisioning provided that "
                        "the conditions identified in this review are remediated within the "
                        "agreed-upon timelines.")
        return "\n".join(lines)

    def _regulatory_framework(self) -> str:
        lines = [
            "**Equal Credit Opportunity Act (ECOA) - 15 U.S.C. 1691 et seq.**\n",
            "ECOA prohibits discrimination in any aspect of a credit transaction on the basis "
            "of race, color, religion, national origin, sex (including sexual orientation and "
            "gender identity), marital status, age (provided the applicant has the capacity to "
            "contract), receipt of public assistance, or the good faith exercise of rights "
            "under the Consumer Credit Protection Act.\n",
            "**Regulation B (12 CFR 1002) - Key Provisions:**\n",
            "| Section | Provision | Relevance |",
            "|---------|-----------|-----------|",
            "| 1002.4(a) | Discrimination prohibited | Disparate treatment and disparate impact |",
            "| 1002.6(a) | Rules on evaluating applications | Prohibited bases in credit evaluation |",
            "| 1002.6(b) | Specific rules concerning use of information | Age, public assistance, income |",
            "| 1002.9(a)(2) | Statement of specific reasons | Adverse action reason codes |",
            "| 1002.12 | Record retention | Model documentation requirements |",
            "",
            "**Supervisory Guidance:**\n",
            "| Document | Relevance |",
            "|----------|-----------|",
            "| CFPB Circular 2023-03 | Adverse action notification in AI/ML models |",
            "| Interagency Fair Lending Exam Procedures | Examination methodology for model-based lending |",
            "| FFIEC BSA/AML Manual | Fair lending intersection with compliance programs |",
            "| SR 11-7 / OCC 2011-12 | Model risk management applicable to fair lending models |",
            "",
            "**Legal Precedent:**\n",
            "- *Griggs v. Duke Power Co.*, 401 U.S. 424 (1971): Established disparate impact theory",
            "- *Texas Dep't of Housing v. Inclusive Communities*, 576 U.S. 519 (2015): Disparate impact applies to FHA",
            "- *CFPB v. Townstone Financial*, (2020): Discouragement as ECOA violation",
        ]
        return "\n".join(lines)

    def _model_overview(self, model, dag_nodes) -> str:
        if not model:
            return "No model information provided."
        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE"]
        tables = {}
        for n in source_nodes:
            t = n.get("table", "unknown")
            tables.setdefault(t, []).append(n.get("column", "unknown"))

        lines = [
            "**Model Identification:**\n",
            "| Attribute | Value |",
            "|-----------|-------|",
            f"| Model Name | {model.name} |",
            f"| Version | {model.version} |",
            f"| Model Type | {model.model_type} |",
            f"| Framework | {model.framework} |",
            f"| Feature Count | {model.feature_count} |",
            f"| Training Samples | {model.training_rows:,} |",
            f"| Source Tables | {len(tables)} |",
            f"| Source Columns | {sum(len(c) for c in tables.values())} |",
            "",
            "**Fair Lending Review Scope:**",
            "This review evaluates the model's compliance with ECOA across the following dimensions:",
            "1. **Disparate Treatment:** Whether the model directly uses prohibited basis information",
            "2. **Disparate Impact:** Whether model outcomes disproportionately affect protected classes",
            "3. **Proxy Discrimination:** Whether model features serve as proxies for prohibited bases",
            "4. **Adverse Action:** Whether denial reason codes meet specificity requirements",
            "5. **Data Lineage:** Whether protected data contaminates the model through the computation graph",
        ]
        return "\n".join(lines)

    def _protected_inventory(self, model, fairlens, dag_nodes) -> str:
        lines = [
            "**ECOA Protected Classes (12 CFR 1002.4):**\n",
            "| Protected Basis | Regulation Section | Status in Model |",
            "|-----------------|--------------------|-----------------| ",
        ]
        protected_cols = [n for n in dag_nodes if n.get("is_protected")]
        prot_names = set(n.get("column", "").lower() for n in protected_cols)

        bases = [
            ("Race", "1002.4(a)"), ("Color", "1002.4(a)"),
            ("Religion", "1002.4(a)"), ("National Origin", "1002.4(a)"),
            ("Sex", "1002.4(a)"), ("Marital Status", "1002.4(a)"),
            ("Age", "1002.6(b)(2)"), ("Public Assistance", "1002.6(b)(4)"),
        ]
        for basis, reg in bases:
            tracked = any(basis.lower().replace(" ", "_") in p for p in prot_names)
            if tracked:
                status = "TRACKED - Flagged in provenance DAG"
            else:
                status = "Not detected in input data"
            lines.append(f"| {basis} | {reg} | {status} |")

        lines.append("")

        if protected_cols:
            lines.append(f"**Protected Columns in Pipeline ({len(protected_cols)}):**\n")
            lines.append("| Table | Column | Node Name | DAG ID |")
            lines.append("|-------|--------|-----------|--------|")
            for n in protected_cols:
                lines.append(f"| {n.get('table', '-')} | {n.get('column', '-')} | "
                           f"{n.get('name', 'unknown')} | {n.get('id', '?')} |")
            lines.append("")

        if fairlens:
            di = fairlens.get("disparate_impact", [])
            if di:
                attrs_tested = list(set(d.get("protected_attribute", "") for d in di))
                lines.append(f"**Attributes Tested by FairLens:** {', '.join(attrs_tested)}")
        return "\n".join(lines)

    def _disparate_impact(self, fairlens) -> str:
        lines = [
            "**Methodology: Four-Fifths (80%) Rule**\n",
            "The four-fifths rule, established in the Uniform Guidelines on Employee Selection "
            "Procedures (29 CFR 1607) and widely adopted in fair lending analysis, provides that "
            "a selection rate for any protected group that is less than 80% of the rate for the "
            "group with the highest selection rate constitutes evidence of adverse impact.\n",
            "**Statistical Significance:**",
            "In addition to the four-fifths threshold, disparate impact findings should be "
            "supported by statistical significance testing. Common approaches include the "
            "Fisher exact test, chi-square test, and Bayesian methods. A finding is typically "
            "considered actionable when both the four-fifths rule is violated AND the result "
            "is statistically significant at the p < 0.05 level.\n",
        ]
        if not fairlens:
            lines.append("**Results:** FairLens analysis not available. Disparate impact testing "
                        "is required prior to production deployment.")
            return "\n".join(lines)

        di = fairlens.get("disparate_impact", [])
        if not di:
            lines.append("**Results:** No disparate impact results in the FairLens report.")
            return "\n".join(lines)

        lines.append("**Results:**\n")
        lines.append("| Protected Attribute | Reference Rate | Protected Rate | Impact Ratio | Four-Fifths Test | Action Required |")
        lines.append("|---------------------|----------------|----------------|--------------|------------------|-----------------|")
        for d in di:
            attr = d.get("protected_attribute", "unknown")
            ratio = d.get("worst_ratio", 0)
            has_di = d.get("has_disparate_impact", False)
            status = "FAIL" if has_di else "PASS"
            action = "LDA analysis required" if has_di else "None"
            ref_rate = d.get("reference_rate")
            prot_rate = d.get("protected_rate")
            ref_str = f"{ref_rate:.1%}" if ref_rate is not None else "N/A"
            prot_str = f"{prot_rate:.1%}" if prot_rate is not None else "N/A"
            lines.append(f"| {attr} | {ref_str} | {prot_str} | {ratio:.3f} | {status} | {action} |")

        failing = [d for d in di if d.get("has_disparate_impact")]
        passing = [d for d in di if not d.get("has_disparate_impact")]
        lines.append("")
        lines.append(f"**Summary:** {len(passing)} attribute(s) pass the four-fifths test; "
                    f"{len(failing)} attribute(s) fail and require further analysis.")
        if failing:
            lines.append("")
            lines.append("Per the burden-shifting framework established in *Griggs v. Duke Power Co.* "
                        "and applied in *Texas Dep't of Housing v. Inclusive Communities*, "
                        "attributes failing the four-fifths test require: (1) documented business "
                        "necessity justification, and (2) evaluation of less discriminatory alternatives "
                        "that achieve comparable predictive performance.")
        return "\n".join(lines)

    def _proxy_detection(self, fairlens) -> str:
        lines = [
            "**Methodology:**\n",
            "Proxy variable detection identifies model features that are highly correlated "
            "with protected attributes and may serve as substitutes for prohibited bases. "
            "The analysis computes pairwise correlation between each model feature and each "
            "protected attribute, flagging features exceeding a materiality threshold.\n",
            "**Thresholds:**\n",
            "| Correlation Range | Risk Level | Action |",
            "|-------------------|------------|--------|",
            "| |r| >= 0.50 | High | Removal or substitution required |",
            "| 0.30 <= |r| < 0.50 | Medium | Enhanced monitoring; LDA evaluation |",
            "| 0.10 <= |r| < 0.30 | Low | Document and monitor |",
            "| |r| < 0.10 | Negligible | No action required |",
            "",
        ]
        if not fairlens:
            lines.append("**Results:** FairLens proxy analysis not available.")
            return "\n".join(lines)

        proxies = fairlens.get("proxy_detection", [])
        if not proxies:
            lines.append("**Results:** No proxy variables detected above materiality threshold.")
            return "\n".join(lines)

        lines.append("**Detected Proxy Variables:**\n")
        lines.append("| Feature | Protected Attribute | Correlation | Risk Level | Recommendation |")
        lines.append("|---------|---------------------|-------------|------------|----------------|")
        for p in proxies:
            feat = p.get("feature_name", "unknown")
            attr = p.get("protected_attribute", "unknown")
            corr = p.get("correlation", 0)
            if abs(corr) >= 0.50:
                risk = "HIGH"
                rec = "Remove or substitute"
            elif abs(corr) >= 0.30:
                risk = "MEDIUM"
                rec = "Evaluate LDA"
            else:
                risk = "LOW"
                rec = "Monitor"
            lines.append(f"| {feat} | {attr} | {corr:.3f} | {risk} | {rec} |")

        return "\n".join(lines)

    def _contamination_audit(self, model, dag_nodes, dag_edges) -> str:
        lines = [
            "**Contamination Detection Methodology:**\n",
            "The provenance DAG is traversed to determine whether any protected-class data "
            "influences model outputs. Contamination occurs when protected attributes flow "
            "through the computation graph to reach model features, either directly or through "
            "intermediate transformations.\n",
        ]
        protected_nodes = [n for n in dag_nodes if n.get("is_protected")]
        clean_nodes = [n for n in dag_nodes if not n.get("is_protected")]

        lines.append("**Pipeline Composition:**\n")
        lines.append("| Category | Count |")
        lines.append("|----------|-------|")
        lines.append(f"| Total DAG Nodes | {len(dag_nodes)} |")
        lines.append(f"| Total DAG Edges | {len(dag_edges)} |")
        lines.append(f"| Protected Source Nodes | {len(protected_nodes)} |")
        lines.append(f"| Clean Source Nodes | {len([n for n in clean_nodes if n.get('type') == 'SOURCE'])} |")
        lines.append(f"| Computation Nodes | {len([n for n in dag_nodes if n.get('type') != 'SOURCE'])} |")
        lines.append("")

        fm = model.fairness_metrics if model else {}
        contaminated = fm.get("contaminated_model_detected", False)

        if contaminated:
            lines.append("**CONTAMINATION STATUS: DETECTED**\n")
            lines.append("The provenance DAG analysis confirms that protected data is present "
                        "in the model's computation graph. This requires immediate remediation "
                        "per 12 CFR 1002.6(a).\n")
            prot = fm.get("protected_attributes_tracked", [])
            if prot:
                lines.append(f"Protected attributes in pipeline: **{', '.join(str(a) for a in prot)}**")
        else:
            lines.append("**CONTAMINATION STATUS: NOT DETECTED**\n")
            lines.append("The provenance DAG analysis confirms that the clean model variant "
                        "does not incorporate protected-class data in its feature computation. "
                        "Protected columns are tracked in the DAG for audit purposes but are "
                        "excluded from model input vectors.")

        if protected_nodes:
            lines.append("")
            lines.append("**Protected Data Trace:**\n")
            lines.append("| Node | Table | Column | Provenance |")
            lines.append("|------|-------|--------|------------|")
            for n in protected_nodes:
                lines.append(f"| {n.get('name', 'unknown')} | {n.get('table', '-')} | "
                           f"{n.get('column', '-')} | {n.get('provenance', '-')} |")

        return "\n".join(lines)

    def _lda_analysis(self, fairlens) -> str:
        lines = [
            "**Legal Framework:**\n",
            "When a model exhibits disparate impact, the three-part burden-shifting framework "
            "applies: (1) the complainant establishes prima facie disparate impact, "
            "(2) the creditor demonstrates business necessity, and (3) the complainant "
            "identifies a less discriminatory alternative that serves the same business need.\n",
            "**LDA Evaluation Criteria:**",
            "A valid LDA must: (a) achieve substantially equivalent predictive performance, "
            "(b) materially reduce disparate impact, and (c) be practically implementable "
            "within the existing model infrastructure.\n",
        ]
        if not fairlens:
            lines.append("**Results:** FairLens LDA analysis not available.")
            return "\n".join(lines)

        ldas = fairlens.get("lda_candidates", [])
        if not ldas:
            lines.append("**Results:** No LDA candidates identified. This may indicate that "
                        "(a) the model does not exhibit disparate impact, or (b) no feature "
                        "removal combination achieves the four-fifths threshold without "
                        "material performance loss.")
            return "\n".join(lines)

        lines.append("**LDA Candidates:**\n")
        lines.append("| Removed Features | New Impact Ratio | AUC Loss | Four-Fifths | Recommendation |")
        lines.append("|------------------|------------------|----------|-------------|----------------|")
        for lda in ldas:
            removed = ", ".join(lda.get("removed_features", []))
            new_disp = lda.get("candidate_disparity", 0)
            auc_loss = lda.get("auc_loss_pct", 0)
            passes = lda.get("passes_four_fifths", False)
            status = "PASS" if passes else "FAIL"
            if passes and auc_loss < 2.0:
                rec = "Recommended"
            elif passes:
                rec = "Consider (performance tradeoff)"
            else:
                rec = "Insufficient impact reduction"
            lines.append(f"| {removed} | {new_disp:.3f} | {auc_loss:.1f}% | {status} | {rec} |")

        viable = [l for l in ldas if l.get("passes_four_fifths")]
        lines.append("")
        lines.append(f"**Summary:** {len(viable)} of {len(ldas)} LDA candidate(s) achieve "
                    f"the four-fifths threshold.")
        return "\n".join(lines)

    def _adverse_action(self, fairlens) -> str:
        lines = [
            "**Regulatory Requirements:**\n",
            "Under 12 CFR 1002.9(a)(2), when a creditor takes adverse action on an application, "
            "the creditor must provide a statement of specific reasons for the action taken. "
            "CFPB Circular 2023-03 clarifies that this requirement applies fully when creditors "
            "use AI/ML models for credit decisioning, and that the complexity of the algorithm "
            "does not excuse vague or inaccurate reasons.\n",
            "**Reason Code Standards:**",
            "- Each denied applicant receives up to 4 specific reason codes",
            "- Reason codes are mapped to FFIEC Adverse Action Reason Code standards",
            "- Reasons must accurately identify the principal factors for that specific applicant",
            "- Generic or non-individualized reasons do not satisfy the specificity requirement",
            "",
            "**AI/ML Model Requirements (CFPB Circular 2023-03):**",
            "For models using complex algorithms (including ensemble methods, gradient boosting, "
            "and neural networks), the creditor must ensure that reason codes reflect the "
            "actual factors driving the adverse decision for each specific applicant. The use "
            "of SHAP (SHapley Additive exPlanations) values or equivalent attribution methods "
            "is recommended to identify applicant-level feature contributions. Features with "
            "material SHAP magnitude (|SHAP| >= materiality threshold) are ranked by absolute "
            "contribution to determine the top reasons. A materiality threshold should be "
            "established such that immaterial factors are not presented as principal reasons.",
            "",
        ]
        if not fairlens:
            lines.append("**Results:** Adverse action analysis not available from FairLens.")
            return "\n".join(lines)

        samples = fairlens.get("adverse_action_samples", [])
        if not samples:
            lines.append("**Results:** No adverse action samples in the FairLens report.")
            return "\n".join(lines)

        denied = [s for s in samples if s.get("prediction") == 0]
        approved = [s for s in samples if s.get("prediction") == 1]

        lines.append("**Decisioning Summary:**\n")
        lines.append("| Outcome | Count | % |")
        lines.append("|---------|-------|---|")
        total = len(samples)
        lines.append(f"| Approved | {len(approved)} | {len(approved)/total*100:.1f}% |")
        lines.append(f"| Denied | {len(denied)} | {len(denied)/total*100:.1f}% |")
        lines.append(f"| **Total** | **{total}** | **100.0%** |")
        lines.append("")

        lines.append(f"Adverse action reasons generated for **{len(denied)}** denied applicant(s).\n")

        if denied:
            lines.append("**Sample Adverse Action Notices:**\n")
            for idx, sample in enumerate(denied[:3]):
                reasons = sample.get("reasons", [])
                if reasons:
                    lines.append(f"*Applicant #{idx}:*\n")
                    lines.append("| Rank | Code | Reason |")
                    lines.append("|------|------|--------|")
                    for rank, r in enumerate(reasons, 1):
                        lines.append(f"| {rank} | {r.get('code', '?')} | {r.get('text', 'N/A')} |")
                    lines.append("")

            if len(denied) > 3:
                lines.append(f"*({len(denied) - 3} additional denied applicants not shown)*")

        return "\n".join(lines)

    def _findings_detail(self, findings) -> str:
        lines = [
            "**Findings Summary:**\n",
            "| ID | Severity | Category | Regulation |",
            "|----|----------|----------|------------|",
        ]
        for f in findings:
            lines.append(f"| {f['id']} | {f['severity']} | {f['category']} | {f.get('regulation', '-')} |")

        lines.append("")
        for f in findings:
            lines.append(f"---\n\n**{f['id']}: {f['category']}**\n")
            lines.append(f"**Severity:** {f['severity']}")
            lines.append(f"**Regulation:** {f.get('regulation', 'N/A')}\n")
            lines.append(f"**Finding:** {f['finding']}\n")
            lines.append(f"**Recommendation:** {f['recommendation']}\n")
            lines.append("**Management Response:** ________________\n")
            lines.append("**Target Remediation Date:** ________________\n")
        return "\n".join(lines)

    def _remediation_plan(self, findings) -> str:
        critical = [f for f in findings if f["severity"] == "CRITICAL"]
        high = [f for f in findings if f["severity"] == "HIGH"]
        medium = [f for f in findings if f["severity"] == "MEDIUM"]

        lines = [
            "**Remediation Priority:**\n",
            "| Priority | Severity | Timeline | Findings |",
            "|----------|----------|----------|----------|",
        ]
        if critical:
            ids = ", ".join(f["id"] for f in critical)
            lines.append(f"| 1 - Immediate | CRITICAL | Within 5 business days | {ids} |")
        if high:
            ids = ", ".join(f["id"] for f in high)
            lines.append(f"| 2 - Urgent | HIGH | Within 30 calendar days | {ids} |")
        if medium:
            ids = ", ".join(f["id"] for f in medium)
            lines.append(f"| 3 - Standard | MEDIUM | Within 90 calendar days | {ids} |")

        if not critical and not high and not medium:
            lines.append("| - | No action items | N/A | - |")

        lines.append("")
        lines.append("**Escalation Path:**")
        lines.append("1. CRITICAL findings: Immediate escalation to Chief Compliance Officer and General Counsel")
        lines.append("2. HIGH findings: Escalation to Fair Lending Officer within 5 business days")
        lines.append("3. MEDIUM findings: Included in next quarterly fair lending review")
        lines.append("")
        lines.append("**Post-Remediation Validation:**")
        lines.append("All remediation actions must be independently validated through:")
        lines.append("- Re-execution of the FairLens analysis suite")
        lines.append("- Updated provenance DAG contamination audit")
        lines.append("- Sign-off by Fair Lending Officer")
        return "\n".join(lines)

    def _monitoring(self) -> str:
        lines = [
            "**Fair Lending Monitoring Schedule:**\n",
            "| Metric | Frequency | Threshold | Owner |",
            "|--------|-----------|-----------|-------|",
            "| Disparate impact ratio (all attributes) | Monthly | <0.80 triggers review | Fair Lending Officer |",
            "| Approval rate by protected class | Monthly | >10% shift triggers review | Compliance Analytics |",
            "| Adverse action reason distribution | Quarterly | Top reason >40% concentration | Model Risk |",
            "| Proxy correlation scan | Quarterly | |r| > 0.30 triggers review | Model Development |",
            "| Protected data contamination audit | Per model deployment | Any contamination = block | Model Governance |",
            "| LDA re-evaluation | Semi-annually | Performance vs. fairness tradeoff | Fair Lending Officer |",
            "| Full ECOA compliance review | Annually | Comprehensive review | Compliance + Legal |",
            "",
            "**Trend Analysis Requirements:**",
            "In addition to point-in-time metrics, monitoring must include rolling trend "
            "analysis across reporting periods. Directional trends in impact ratios provide "
            "early warning of emerging disparate impact before action thresholds are breached. "
            "A sustained negative trend (3+ consecutive quarters of declining impact ratios) "
            "must trigger root cause analysis regardless of whether the absolute threshold is "
            "breached.",
            "",
            "**Regulatory Examination Readiness:**",
            "This document and supporting artifacts (FairLens reports, provenance DAG, "
            "adverse action samples) must be maintained in the regulatory examination file "
            "and made available to examiners upon request. Per 12 CFR 1002.12, records "
            "relating to compliance must be retained for 25 months.",
            "",
            "**Required Examination File Artifacts:**",
            "- Fair Lending Compliance Review (this document)",
            "- Quarterly monitoring reports (impact ratios, reason codes)",
            "- Proxy variable screening results (semi-annually)",
            "- LDA analysis documentation (at each model change)",
            "- Adverse action notice sample reviews (semi-annually)",
            "- DAG contamination audit results (annually)",
            "- Business necessity documentation for features with proxy correlation >0.15",
        ]
        return "\n".join(lines)

    def _appendix_dag(self, dag_nodes, dag_edges) -> str:
        if not dag_nodes:
            return "No DAG data available."
        lines = [
            f"**Total Nodes:** {len(dag_nodes)}",
            f"**Total Edges:** {len(dag_edges)}",
            "",
        ]

        protected = [n for n in dag_nodes if n.get("is_protected")]
        if protected:
            lines.append("**Protected Source Nodes:**\n")
            lines.append("| ID | Name | Table | Column | Provenance |")
            lines.append("|----|------|-------|--------|------------|")
            for n in protected:
                lines.append(f"| {n.get('id', '?')} | {n.get('name', 'unknown')} | "
                           f"{n.get('table', '-')} | {n.get('column', '-')} | "
                           f"{n.get('provenance', '-')} |")
            lines.append("")

        source_nodes = [n for n in dag_nodes if n.get("type") == "SOURCE" and not n.get("is_protected")]
        if source_nodes:
            lines.append("**Clean Source Nodes:**\n")
            lines.append("| ID | Name | Table | Column |")
            lines.append("|----|------|-------|--------|")
            for n in source_nodes:
                lines.append(f"| {n.get('id', '?')} | {n.get('name', 'unknown')} | "
                           f"{n.get('table', '-')} | {n.get('column', '-')} |")
            lines.append("")

        comp_nodes = [n for n in dag_nodes if n.get("type") != "SOURCE"]
        if comp_nodes:
            lines.append("**Computation Nodes:**\n")
            lines.append("| ID | Name | Type | Operation | Provenance |")
            lines.append("|----|------|------|-----------|------------|")
            for n in comp_nodes:
                lines.append(f"| {n.get('id', '?')} | {n.get('name', 'unknown')} | "
                           f"{n.get('type', '?')} | {n.get('operation', '-')} | "
                           f"{n.get('provenance', '-')} |")
        return "\n".join(lines)

    def _appendix_regulatory(self) -> str:
        lines = [
            "**Report Section to Regulation Mapping:**\n",
            "| Report Section | Regulatory Reference |",
            "|----------------|---------------------|",
            "| Executive Summary | ECOA Section 701; 12 CFR 1002.1 |",
            "| Regulatory Framework | 15 U.S.C. 1691; 12 CFR 1002 |",
            "| Protected Attribute Inventory | 12 CFR 1002.4(a); 1002.6(a) |",
            "| Disparate Impact Analysis | Griggs v. Duke Power; 29 CFR 1607 |",
            "| Proxy Variable Detection | 12 CFR 1002.6(a); Interagency Exam Procedures |",
            "| Data Lineage & Contamination | 12 CFR 1002.6(a); SR 11-7 |",
            "| Less Discriminatory Alternatives | Interagency Fair Lending Guidance |",
            "| Adverse Action Methodology | 12 CFR 1002.9(a)(2); CFPB Circular 2023-03 |",
            "| Ongoing Monitoring | 12 CFR 1002.12; SR 11-7 Section V.D |",
            "",
            "**Full Regulatory Bibliography:**",
            "- Equal Credit Opportunity Act, 15 U.S.C. 1691 et seq.",
            "- Regulation B, 12 CFR Part 1002",
            "- CFPB Circular 2023-03: Adverse Action Notification Requirements",
            "- CFPB Supervisory Highlights (Fair Lending)",
            "- Interagency Fair Lending Examination Procedures",
            "- SR 11-7: Guidance on Model Risk Management",
            "- OCC 2011-12: Sound Practices for Model Risk Management",
            "- Uniform Guidelines on Employee Selection Procedures (29 CFR 1607)",
            "- *Griggs v. Duke Power Co.*, 401 U.S. 424 (1971)",
            "- *Texas Dep't of Housing v. Inclusive Communities*, 576 U.S. 519 (2015)",
        ]
        return "\n".join(lines)



class DbtDocTemplate(BaseTemplate):
    """Enhanced dbt Project Documentation template."""
    name = "dbt Project Documentation"
    description = "Enhanced dbt project documentation with lineage and quality information"

    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        pipeline = context.get("pipeline")
        sections = []

        sections.append(DocumentSection(
            title="Project Overview",
            content=self._project_overview(pipeline),
        ))
        sections.append(DocumentSection(
            title="Sources",
            content=self._sources(pipeline, context),
        ))
        sections.append(DocumentSection(
            title="Models",
            content=self._models(context),
        ))
        sections.append(DocumentSection(
            title="Lineage",
            content=self._lineage(context),
        ))
        sections.append(DocumentSection(
            title="Data Quality Tests",
            content=self._tests(pipeline),
        ))
        sections.append(DocumentSection(
            title="Dependencies",
            content=self._dependencies(pipeline),
        ))

        return sections

    def _project_overview(self, pipeline) -> str:
        if not pipeline:
            return "No pipeline metadata provided."
        return (
            f"**Project:** {pipeline.name}\n"
            f"**Description:** {pipeline.description or 'N/A'}\n"
            f"**Owner:** {pipeline.owner or 'N/A'}\n"
            f"**Schedule:** {pipeline.schedule or 'N/A'}\n\n"
            f"**dbt Project Conventions:**\n"
            f"This project follows the standard dbt directory structure with staging (stg_), "
            f"intermediate (int_), and fact/dimension (fct_/dim_) naming conventions. All "
            f"models are organized by functional domain and follow a consistent naming scheme "
            f"to support automated lineage tracking and discoverability.\n\n"
            f"**Materialization Strategies:**\n"
            f"Models use materialization strategies appropriate to their role: staging models "
            f"are materialized as views for freshness, intermediate models as ephemeral CTEs "
            f"to minimize warehouse storage, and final fact/dimension tables as incremental "
            f"or table materializations for query performance."
        )

    def _sources(self, pipeline, context) -> str:
        lines = []
        if pipeline and pipeline.source_tables:
            for src in pipeline.source_tables:
                lines.append(f"- `{src}`")
        dag_nodes = context.get("dag_nodes", [])
        sources = [n for n in dag_nodes if n.get("type") == "source"]
        for s in sources:
            name = s.get("name", "unknown")
            if not any(name in line for line in lines):
                lines.append(f"- `{name}`")

        lines.append("\n**Freshness SLA Tracking:**")
        lines.append("Source freshness should be monitored using dbt source freshness checks. "
                     "Each source table should have a `loaded_at_field` configured with "
                     "`warn_after` and `error_after` thresholds aligned to pipeline SLAs. "
                     "Stale sources should block downstream model execution.")
        lines.append("\n**Source Testing Coverage:**")
        lines.append("All source tables should have baseline tests including: not_null on "
                     "primary keys, unique on primary keys, accepted_values for categorical "
                     "columns, and row count anomaly detection.")
        return "\n".join(lines) or "No sources documented."

    def _models(self, context) -> str:
        dag_nodes = context.get("dag_nodes", [])
        models = [n for n in dag_nodes if n.get("type") in ("model", "transform")]
        if not models:
            return "No models found in DAG."
        lines = []
        lines.append("**Model Inventory:**\n")
        lines.append("Each model below includes its materialization type (where available), "
                     "column definitions, and associated tests. Models without documented "
                     "tests should be flagged for coverage improvement.\n")
        for m in models:
            name = m.get("name", "unknown")
            desc = m.get("description", "")
            mat_type = m.get("materialization", "")
            lines.append(f"### `{name}`\n")
            if mat_type:
                lines.append(f"**Materialization:** {mat_type}\n")
            if desc:
                lines.append(f"{desc}\n")
            cols = m.get("columns", [])
            if cols:
                lines.append(f"Columns: {', '.join(f'`{c}`' for c in cols[:10])}")
                if len(cols) > 10:
                    lines.append(f"  ... and {len(cols) - 10} more")
            lines.append("")
        return "\n".join(lines)

    def _lineage(self, context) -> str:
        dag_edges = context.get("dag_edges", [])
        if not dag_edges:
            return "No lineage information available."
        lines = []
        for edge in dag_edges:
            src = edge.get("source", "?")
            dst = edge.get("target", "?")
            lines.append(f"- `{src}` → `{dst}`")

        lines.append("\n**Lineage Analysis:**")
        lines.append("**Critical Path:** The longest dependency chain in the DAG determines "
                     "minimum pipeline execution time. Models on the critical path should be "
                     "optimized for performance and monitored for latency.")
        lines.append("**Fan-out Warnings:** Models that feed many downstream consumers "
                     "represent high-impact change points. Modifications to high fan-out "
                     "models require impact analysis across all downstream dependencies "
                     "before deployment.")
        return "\n".join(lines)

    def _tests(self, pipeline) -> str:
        if not pipeline or not pipeline.data_quality_checks:
            return "No tests documented."
        lines = []
        for check in pipeline.data_quality_checks:
            name = check.get("name", "unnamed")
            status = check.get("status", "unknown")
            lines.append(f"- **{name}**: {status}")

        lines.append("\n**Test Coverage Analysis:**")
        lines.append("Adequate test coverage requires at minimum: primary key uniqueness "
                     "and not-null tests for all models, referential integrity tests for "
                     "foreign key relationships, and accepted_values tests for categorical "
                     "columns with known domains.")
        lines.append("\n**Severity Classification:**")
        lines.append("- **Error (severity: error):** Test failures that must block pipeline "
                     "execution and downstream model builds.")
        lines.append("- **Warning (severity: warn):** Test failures that log alerts but do "
                     "not block execution; require investigation within SLA.")
        return "\n".join(lines)

    def _dependencies(self, pipeline) -> str:
        if not pipeline or not pipeline.dependencies:
            return "No dependencies documented."
        lines = [f"- `{d}`" for d in pipeline.dependencies]
        lines.append("\n**Version Pinning Recommendations:**")
        lines.append("All dependencies should use pinned versions or version ranges to "
                     "ensure reproducible builds. Avoid using unpinned dependencies in "
                     "production pipelines as upstream breaking changes may cause silent "
                     "data quality regressions.")
        lines.append("\n**Compatibility Notes:**")
        lines.append("Before upgrading any dependency, verify compatibility with the "
                     "current dbt version, warehouse adapter, and any custom macros or "
                     "packages in use. Run the full test suite against the updated "
                     "dependency in a non-production environment before promoting.")
        return "\n".join(lines)



class GDPRTemplate(BaseTemplate):
    """GDPR compliance documentation for EU data processing."""
    name = "GDPR Compliance Documentation"
    description = "EU General Data Protection Regulation (GDPR) compliance documentation for AI/ML systems"

    # Lawful basis suggestions based on model purpose keywords
    _LAWFUL_BASIS_MAP = {
        "credit": ("Article 6(1)(b) Contract", "Processing is necessary for the performance of "
                   "a contract (credit agreement) to which the data subject is party, and for "
                   "pre-contractual steps (credit assessment) taken at the data subject's request. "
                   "Alternatively, Article 6(1)(f) Legitimate Interests may apply where the "
                   "controller has a legitimate interest in assessing creditworthiness."),
        "lending": ("Article 6(1)(b) Contract", "Processing is necessary for the performance of "
                    "a lending contract and pre-contractual credit assessment."),
        "loan": ("Article 6(1)(b) Contract", "Processing is necessary for the performance of "
                 "a loan contract and pre-contractual creditworthiness assessment."),
        "mortgage": ("Article 6(1)(b) Contract", "Processing is necessary for the performance of "
                     "a mortgage contract and pre-contractual assessment."),
        "underwriting": ("Article 6(1)(b) Contract", "Processing is necessary for the performance "
                        "of an insurance or lending contract."),
        "fraud": ("Article 6(1)(c) Legal Obligation", "Processing is necessary for compliance "
                  "with a legal obligation to detect and prevent fraud, as required by "
                  "applicable financial regulations."),
        "aml": ("Article 6(1)(c) Legal Obligation", "Processing is necessary for compliance with "
                "anti-money laundering legal obligations under applicable AML directives."),
        "anti-money": ("Article 6(1)(c) Legal Obligation", "Processing is necessary for compliance "
                       "with anti-money laundering legal obligations."),
        "bsa": ("Article 6(1)(c) Legal Obligation", "Processing is necessary for compliance with "
                "Bank Secrecy Act obligations."),
        "marketing": ("Article 6(1)(a) Consent", "Processing for marketing purposes requires "
                      "the explicit consent of the data subject."),
        "pricing": ("Article 6(1)(f) Legitimate Interests", "Processing for pricing optimization "
                    "may be based on the legitimate interests of the controller, subject to a "
                    "balancing test against data subject rights."),
        "collection": ("Article 6(1)(b) Contract", "Processing is necessary for the performance "
                       "of existing contractual obligations."),
    }

    def _suggest_lawful_basis(self, model) -> tuple:
        """Suggest likely GDPR lawful basis based on model purpose.

        Returns (basis, justification) tuple.
        """
        if not model or not model.intended_use:
            return (None, None)
        use_lower = model.intended_use.lower()
        for keyword, (basis, justification) in self._LAWFUL_BASIS_MAP.items():
            if keyword in use_lower:
                return (basis, justification)
        return (None, None)

    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        model = context.get("model")
        pipeline = context.get("pipeline")
        fairlens = context.get("fairlens_report")
        sections = []

        sections.append(DocumentSection(
            title="Processing Activity Overview",
            content=self._processing_overview(model, pipeline),
        ))
        sections.append(DocumentSection(
            title="Lawful Basis for Processing",
            content=self._lawful_basis(model),
        ))
        sections.append(DocumentSection(
            title="Data Subject Rights",
            content=self._data_subject_rights(model),
        ))
        sections.append(DocumentSection(
            title="Data Protection Impact Assessment",
            content=self._dpia(model, fairlens),
        ))
        sections.append(DocumentSection(
            title="Technical and Organizational Measures",
            content=self._technical_measures(model, pipeline),
        ))
        sections.append(DocumentSection(
            title="International Data Transfers",
            content=self._international_transfers(model),
        ))
        sections.append(DocumentSection(
            title="Data Protection Officer",
            content=self._dpo(model, pipeline),
        ))

        return sections

    def _processing_overview(self, model, pipeline) -> str:
        lines = [
            "**Record of Processing Activities (Article 30):**",
            "This document constitutes part of the record of processing activities "
            "required under Article 30 of the GDPR. Controllers must maintain a record "
            "of processing activities under their responsibility, including the purposes "
            "of processing, categories of data subjects and personal data, recipients, "
            "and envisaged time limits for erasure.\n",
        ]

        if model:
            lines.append(f"**System Name:** {model.name}")
            lines.append(f"**Version:** {model.version}")
            lines.append(f"**Type:** {model.model_type}")
            lines.append(f"**Framework:** {model.framework}")
            lines.append(f"**Description:** {model.description or 'N/A'}")
            lines.append(f"**Data Controller:** {model.owner or 'N/A'}")
            lines.append(f"**Training Samples:** {model.training_rows:,}")
            lines.append(f"**Features:** {model.feature_count}")
            lines.append(f"**Purpose of Processing:** {model.intended_use or 'N/A'}\n")

            if model.training_rows > 0:
                scale = "large-scale" if model.training_rows >= 100000 else "standard-scale"
                lines.append(f"**Processing Scale:** {scale} ({model.training_rows:,} data subjects)")
                if model.training_rows >= 100000:
                    lines.append("Large-scale processing may trigger additional GDPR requirements "
                                "including mandatory DPIA (Article 35) and DPO designation "
                                "(Article 37).")
                lines.append("")
        elif pipeline:
            lines.append(f"**Pipeline Name:** {pipeline.name}")
            lines.append(f"**Description:** {pipeline.description or 'N/A'}")
            lines.append(f"**Data Controller:** {pipeline.owner or 'N/A'}")
            if pipeline.total_rows:
                scale = "large-scale" if pipeline.total_rows >= 100000 else "standard-scale"
                lines.append(f"**Processing Scale:** {scale} ({pipeline.total_rows:,} records)")
            lines.append("")
        else:
            lines.append("No model or pipeline metadata provided.\n")

        lines.append("**Article 13/14 - Information to Data Subjects:**")
        lines.append("Data subjects must be informed about the processing of their "
                     "personal data at the time of collection (Art 13) or within a "
                     "reasonable period if data was not obtained from the data subject "
                     "(Art 14). For AI/ML systems, this includes providing meaningful "
                     "information about the logic involved, as well as the significance "
                     "and envisaged consequences of such processing.")
        return "\n".join(lines)

    def _lawful_basis(self, model) -> str:
        suggested_basis, justification = self._suggest_lawful_basis(model)

        lines = [
            "**Article 6 - Lawful Basis for Processing:**\n",
            "Processing of personal data is lawful only if at least one of the following "
            "conditions applies:\n",
            "- **(a) Consent:** The data subject has given consent to the processing for "
            "one or more specific purposes",
            "- **(b) Contract:** Processing is necessary for the performance of a contract "
            "to which the data subject is party",
            "- **(c) Legal Obligation:** Processing is necessary for compliance with a "
            "legal obligation to which the controller is subject",
            "- **(d) Vital Interests:** Processing is necessary to protect the vital "
            "interests of the data subject or another natural person",
            "- **(e) Public Interest:** Processing is necessary for the performance of a "
            "task carried out in the public interest or in the exercise of official authority",
            "- **(f) Legitimate Interests:** Processing is necessary for the purposes of "
            "legitimate interests pursued by the controller or a third party\n",
        ]

        if suggested_basis:
            lines.append(f"**Recommended Lawful Basis:** {suggested_basis}")
            lines.append(f"**Justification:** {justification}\n")
        else:
            lines.append("**Selected Lawful Basis:** [ ] To be documented\n")

        lines.append("**Article 9 - Special Categories of Data:**")
        lines.append("If the AI/ML system processes special category data (racial or ethnic origin, "
                     "political opinions, religious beliefs, trade union membership, genetic data, "
                     "biometric data, health data, sex life or sexual orientation), additional "
                     "conditions under Article 9(2) must be satisfied.")

        if model and model.fairness_metrics:
            protected_attrs = [k.replace("disparate_impact_", "") for k in model.fairness_metrics
                              if k.startswith("disparate_impact_")]
            if protected_attrs:
                lines.append(f"\n**Special Category Data Alert:** The system tracks fairness "
                            f"metrics for: {', '.join(protected_attrs)}. If these attributes "
                            f"are derived from or constitute special category data (e.g., racial "
                            f"origin, sex), Article 9(2) conditions must be documented.")

        lines.append("\n**Automated Decision-Making (Article 22):**")
        lines.append("The data subject has the right not to be subject to a decision based solely "
                     "on automated processing, including profiling, which produces legal effects "
                     "or similarly significantly affects them. Exceptions apply only where the "
                     "decision is necessary for a contract, authorized by law, or based on "
                     "explicit consent.")

        if model and model.intended_use:
            use_lower = model.intended_use.lower()
            has_legal_effect = any(kw in use_lower for kw in
                                  ("credit", "loan", "lending", "insurance", "hiring", "mortgage"))
            if has_legal_effect:
                lines.append(f"\n**Article 22 Applicability:** Based on the system's intended "
                            f"use ({model.intended_use}), this system likely produces decisions "
                            f"with legal or similarly significant effects on data subjects. "
                            f"Article 22 safeguards apply, including the right to human "
                            f"intervention and the right to contest decisions.")

        if model:
            lines.append(f"\n**System Purpose:** {model.intended_use or 'Not specified'}")
            lines.append(f"**Known Limitations:** {model.limitations or 'Not specified'}")
        return "\n".join(lines)

    def _data_subject_rights(self, model) -> str:
        has_model = bool(model)
        has_owner = bool(model and model.owner)
        has_features = bool(model and model.feature_names)
        has_importances = bool(model and model.feature_importances)

        lines = [
            "**Articles 15-22 - Data Subject Rights:**\n",
            "AI/ML systems processing personal data must accommodate the following "
            "data subject rights. Technical mechanisms must be in place to fulfill "
            "requests within one month of receipt (extendable by two months for "
            "complex requests).\n",
            "**Article 15 - Right of Access:**",
            "Data subjects have the right to obtain confirmation of whether their personal "
            "data is being processed and, where that is the case, access to the personal "
            "data and information about the processing. For AI/ML systems, this includes "
            "information about the logic of automated decision-making.\n",
        ]

        check_access = "[x]" if has_model and model.training_rows > 0 else "[ ]"
        lines.append(f"- {check_access} Mechanism to identify if a data subject's data was used in training\n")

        lines.append("**Article 16 - Right to Rectification:**")
        lines.append("Data subjects have the right to obtain rectification of inaccurate personal "
                     "data without undue delay.")
        check_rectification = "[x]" if has_owner else "[ ]"
        lines.append(f"- {check_rectification} Process for correcting training data and retraining if necessary\n")

        lines.append("**Article 17 - Right to Erasure (Right to be Forgotten):**")
        lines.append("Data subjects have the right to obtain erasure of their personal data under "
                     "certain conditions. For ML models, this may require model retraining to "
                     "remove the influence of the erased data.")
        check_deletion = "[x]" if has_owner else "[ ]"
        lines.append(f"- {check_deletion} Data deletion procedure documented")
        lines.append(f"- {check_deletion} Model retraining procedure for erasure requests documented\n")

        lines.append("**Article 20 - Right to Data Portability:**")
        lines.append("Data subjects have the right to receive their personal data in a structured, "
                     "commonly used, and machine-readable format.")
        check_portability = "[x]" if has_features else "[ ]"
        lines.append(f"- {check_portability} Data export mechanism available\n")

        lines.append("**Article 21 - Right to Object:**")
        lines.append("Data subjects have the right to object to processing based on legitimate "
                     "interests or public interest, including profiling.")
        check_objection = "[x]" if has_owner else "[ ]"
        lines.append(f"- {check_objection} Objection handling procedure documented\n")

        lines.append("**Article 22 - Automated Individual Decision-Making:**")
        lines.append("Where decisions are made solely by automated processing, the data subject "
                     "has the right to obtain human intervention, express their point of view, "
                     "and contest the decision.")
        check_human_review = "[x]" if has_owner else "[ ]"
        check_explainability = "[x]" if has_importances else "[ ]"
        lines.append(f"- {check_human_review} Human review mechanism available")
        lines.append(f"- {check_explainability} Model explainability capability implemented")

        if has_importances:
            top_features = sorted(model.feature_importances.items(), key=lambda x: x[1], reverse=True)[:5]
            lines.append("\n**Explainability Summary:**")
            lines.append("The model provides feature-level explanations. Top contributing features:")
            for feat, imp in top_features:
                lines.append(f"- {feat}: {imp:.2%}")

        return "\n".join(lines)

    def _dpia(self, model, fairlens) -> str:
        has_model = bool(model)
        has_metrics = bool(model and model.performance_metrics)
        has_fairlens = bool(fairlens)
        is_large_scale = bool(model and model.training_rows >= 100000)
        has_legal_effect = False
        if model and model.intended_use:
            use_lower = model.intended_use.lower()
            has_legal_effect = any(kw in use_lower for kw in
                                  ("credit", "loan", "lending", "insurance", "hiring", "mortgage"))

        lines = [
            "**Article 35 - Data Protection Impact Assessment (DPIA):**\n",
            "A DPIA is required where processing is likely to result in a high risk to "
            "the rights and freedoms of natural persons. AI/ML systems that involve "
            "systematic and extensive evaluation of personal aspects (profiling), "
            "large-scale processing of special categories of data, or systematic "
            "monitoring of publicly accessible areas require a DPIA.\n",
            "**DPIA Triggers for AI/ML Systems:**\n",
        ]

        check_automated = "[x]" if has_legal_effect else "[ ]"
        check_profiling = "[x]" if is_large_scale else "[ ]"
        check_special = "[x]" if has_fairlens and fairlens.get("summary", {}).get("proxy_features_detected", 0) > 0 else "[ ]"
        check_innovation = "[x]" if has_model else "[ ]"
        check_prevents = "[ ]"

        lines.append(f"- {check_automated} Automated decision-making with legal or significant effects")
        lines.append(f"- {check_profiling} Large-scale profiling of natural persons")
        lines.append(f"- {check_special} Processing of special category data at scale")
        lines.append(f"- {check_innovation} Innovative use of new technologies")
        lines.append(f"- {check_prevents} Processing that prevents data subjects from exercising a right")

        triggered = sum(1 for c in [check_automated, check_profiling, check_special,
                                     check_innovation, check_prevents] if c == "[x]")
        if triggered >= 2:
            lines.append(f"\n**DPIA Required:** {triggered} of 5 triggers are active. A full "
                        f"DPIA must be conducted per Article 35(1).")
        elif triggered == 1:
            lines.append(f"\n**DPIA Recommended:** {triggered} trigger is active. A DPIA is "
                        f"recommended as a precautionary measure.")

        # Build risk assessment table with actual data
        lines.append("\n**Risk Assessment:**\n")
        lines.append("| Risk Category | Likelihood | Severity | Mitigation |")
        lines.append("|--------------|------------|----------|------------|")

        # Unauthorized disclosure
        disclosure_likelihood = "Medium" if is_large_scale else "Low"
        disclosure_severity = "High" if is_large_scale else "Medium"
        disclosure_mitigation = "Encryption, access controls, audit logging"
        lines.append(f"| Unauthorized disclosure | {disclosure_likelihood} | {disclosure_severity} | {disclosure_mitigation} |")

        # Algorithmic bias
        if has_fairlens:
            critical = fairlens.get("summary", {}).get("critical", 0)
            if critical > 0:
                bias_likelihood = "High"
                bias_severity = "High"
                bias_mitigation = f"{critical} critical finding(s); remediation required"
            else:
                bias_likelihood = "Low"
                bias_severity = "Medium"
                bias_mitigation = "FairLens analysis passed; ongoing monitoring"
        elif has_metrics:
            bias_likelihood = "Medium"
            bias_severity = "Medium"
            bias_mitigation = "Performance metrics available; fairness testing recommended"
        else:
            bias_likelihood = "Unknown"
            bias_severity = "High"
            bias_mitigation = "No fairness analysis conducted"
        lines.append(f"| Algorithmic bias | {bias_likelihood} | {bias_severity} | {bias_mitigation} |")

        # Re-identification
        reident_likelihood = "Medium" if has_model and model.feature_count > 30 else "Low"
        reident_severity = "High"
        reident_mitigation = "Data minimization, pseudonymization"
        lines.append(f"| Re-identification | {reident_likelihood} | {reident_severity} | {reident_mitigation} |")

        # Function creep
        fc_likelihood = "Low"
        fc_severity = "Medium"
        fc_mitigation = "Purpose limitation documented" if has_model and model.intended_use else "Purpose not documented"
        lines.append(f"| Function creep | {fc_likelihood} | {fc_severity} | {fc_mitigation} |")

        # Inaccurate decisions
        if has_metrics:
            auc = model.performance_metrics.get("AUC") or model.performance_metrics.get("auc_roc")
            accuracy = model.performance_metrics.get("Accuracy") or model.performance_metrics.get("accuracy")
            if auc is not None and auc < 0.70:
                inacc_likelihood = "High"
                inacc_severity = "High"
                inacc_mitigation = f"AUC {auc:.4f} below threshold; model improvement needed"
            elif auc is not None:
                inacc_likelihood = "Low"
                inacc_severity = "Medium"
                inacc_mitigation = f"AUC {auc:.4f}; within acceptable range"
            elif accuracy is not None:
                inacc_likelihood = "Low" if accuracy > 0.80 else "Medium"
                inacc_severity = "Medium"
                inacc_mitigation = f"Accuracy {accuracy:.4f}"
            else:
                inacc_likelihood = "Medium"
                inacc_severity = "Medium"
                inacc_mitigation = "Performance metrics available"
        else:
            inacc_likelihood = "Unknown"
            inacc_severity = "High"
            inacc_mitigation = "No performance metrics available"
        lines.append(f"| Inaccurate decisions | {inacc_likelihood} | {inacc_severity} | {inacc_mitigation} |")
        lines.append("")

        if has_metrics:
            lines.append("**Model Performance Indicators:**\n")
            for metric, value in model.performance_metrics.items():
                if isinstance(value, float):
                    lines.append(f"- {metric}: {value:.4f}")
                else:
                    lines.append(f"- {metric}: {value}")
            lines.append("")

        if has_fairlens:
            summary = fairlens.get("summary", {})
            lines.append("**Fairness Analysis Results:**\n")
            lines.append(f"- Critical findings: {summary.get('critical', 0)}")
            lines.append(f"- Warnings: {summary.get('warnings', 0)}")

            di_results = fairlens.get("disparate_impact", [])
            if di_results:
                lines.append("\n**Disparate Impact Assessment:**\n")
                lines.append("| Protected Attribute | DI Ratio | Four-Fifths Rule |")
                lines.append("|--------------------:|:--------:|:----------------:|")
                for di in di_results:
                    attr = di.get("protected_attribute", "unknown")
                    ratio = di.get("worst_ratio", 0)
                    status = "FAIL" if di.get("has_disparate_impact", False) else "PASS"
                    lines.append(f"| {attr} | {ratio:.2f} | {status} |")

            findings = fairlens.get("findings", [])
            if findings:
                lines.append("\n**Findings:**\n")
                for f in findings:
                    sev = f.get("severity", "info").upper()
                    desc = f.get("description", "")
                    lines.append(f"- [{sev}] {desc}")

        lines.append("\n**Consultation Requirement (Article 36):**")
        lines.append("Where the DPIA indicates that processing would result in a high "
                     "risk in the absence of measures taken by the controller, the "
                     "controller must consult the supervisory authority prior to processing.")

        if has_fairlens and fairlens.get("summary", {}).get("critical", 0) > 0:
            lines.append("\n**Supervisory Authority Consultation Recommended:** Critical "
                        "fairness findings indicate high residual risk. Consult the "
                        "supervisory authority per Article 36 before deploying this system.")

        return "\n".join(lines)

    def _technical_measures(self, model, pipeline) -> str:
        has_model = bool(model)
        has_owner = bool(model and model.owner)
        has_metrics = bool(model and model.performance_metrics)
        has_pipeline = bool(pipeline)
        has_quality_checks = bool(pipeline and pipeline.data_quality_checks)

        lines = [
            "**Article 32 - Security of Processing:**\n",
            "The controller and processor must implement appropriate technical and "
            "organizational measures to ensure a level of security appropriate to the "
            "risk, taking into account the state of the art, the costs of implementation, "
            "and the nature, scope, context, and purposes of processing.\n",
            "**Required Measures (Article 32(1)):**\n",
            "- **(a) Pseudonymization and Encryption:** Personal data must be pseudonymized "
            "or encrypted where appropriate. For ML systems, this includes training data, "
            "model inputs, and inference outputs.",
            "- **(b) Confidentiality, Integrity, Availability, Resilience:** Systems must "
            "ensure the ongoing confidentiality, integrity, availability, and resilience "
            "of processing systems and services.",
            "- **(c) Restore Availability:** The ability to restore the availability and "
            "access to personal data in a timely manner in the event of a physical or "
            "technical incident.",
            "- **(d) Regular Testing:** A process for regularly testing, assessing, and "
            "evaluating the effectiveness of technical and organizational measures.\n",
            "**AI/ML-Specific Technical Measures:**\n",
        ]

        check_privacy = "[ ]"
        check_access = "[x]" if has_owner else "[ ]"
        check_encrypt_rest = "[x]" if has_pipeline else "[ ]"
        check_encrypt_transit = "[x]" if has_pipeline else "[ ]"
        check_validation = "[x]" if has_quality_checks else "[ ]"
        check_output = "[ ]"
        check_pentest = "[x]" if has_metrics else "[ ]"
        check_adversarial = "[x]" if has_metrics else "[ ]"

        lines.append(f"- {check_privacy} Differential privacy applied to training data")
        lines.append(f"- {check_access} Model access controls with authentication and authorization")
        lines.append(f"- {check_encrypt_rest} Encryption at rest for all personal data and model artifacts")
        lines.append(f"- {check_encrypt_transit} Encryption in transit for all API communications")
        lines.append(f"- {check_validation} Input validation and sanitization for inference requests")
        lines.append(f"- {check_output} Output filtering to prevent PHI leakage in model responses")
        lines.append(f"- {check_pentest} Regular penetration testing of ML pipeline infrastructure")
        lines.append(f"- {check_adversarial} Adversarial robustness testing (model inversion, membership inference)\n")

        lines.append("**Data Protection by Design and Default (Article 25):**")
        lines.append("The controller must implement appropriate technical and organizational "
                     "measures designed to implement data-protection principles (such as data "
                     "minimization) in an effective manner and to integrate the necessary safeguards "
                     "into the processing. By default, only personal data necessary for each "
                     "specific purpose should be processed.")

        if model:
            lines.append(f"\n**Model Framework:** {model.framework}")
            lines.append(f"**Feature Count:** {model.feature_count} (review for data minimization)")
            if model.feature_count > 50:
                lines.append("**Data Minimization Alert:** Feature count exceeds 50. Review whether "
                            "all features are necessary for the stated purpose per Article 25(2).")
        if pipeline:
            lines.append(f"**Pipeline:** {pipeline.name}")
            if has_quality_checks:
                passing = sum(1 for c in pipeline.data_quality_checks if c.get("status") == "pass")
                total = len(pipeline.data_quality_checks)
                lines.append(f"**Quality Checks:** {passing}/{total} passing")
        return "\n".join(lines)

    def _international_transfers(self, model) -> str:
        lines = [
            "**Articles 44-49 - International Data Transfers:**\n",
            "Any transfer of personal data to a third country or international organization "
            "must comply with Chapter V of the GDPR. Transfers are permitted only where "
            "appropriate safeguards are in place.\n",
            "**Transfer Mechanisms:**\n",
            "- **Adequacy Decision (Art 45):** The European Commission has determined that "
            "the third country ensures an adequate level of protection",
            "- **Standard Contractual Clauses (Art 46(2)(c)):** Pre-approved contractual "
            "terms adopted by the Commission",
            "- **Binding Corporate Rules (Art 47):** Approved internal rules for "
            "intra-group transfers",
            "- **Derogations (Art 49):** Limited exceptions including explicit consent, "
            "contractual necessity, and compelling legitimate interests\n",
            "**AI/ML Transfer Considerations:**\n",
            "- Cloud-based model training may involve cross-border data transfer",
            "- Model serving infrastructure location determines transfer requirements",
            "- Federated learning may reduce transfer requirements but must be evaluated",
            "- Transfer impact assessments (TIA) required per Schrems II ruling for "
            "transfers relying on SCCs\n",
            "**Transfer Documentation:**\n",
            "| Destination | Mechanism | Assessment Date | Status |",
            "|------------|-----------|----------------|--------|",
        ]

        if model and model.framework:
            framework_lower = model.framework.lower()
            cloud_frameworks = {
                "sagemaker": ("AWS (US)", "EU-US Data Privacy Framework"),
                "aws": ("AWS (US)", "EU-US Data Privacy Framework"),
                "azure": ("Azure (US/EU)", "Standard Contractual Clauses"),
                "gcp": ("Google Cloud (US)", "EU-US Data Privacy Framework"),
                "vertex": ("Google Cloud (US)", "EU-US Data Privacy Framework"),
                "databricks": ("Databricks Cloud", "Standard Contractual Clauses"),
            }
            matched = False
            for key, (destination, mechanism) in cloud_frameworks.items():
                if key in framework_lower:
                    lines.append(f"| {destination} | {mechanism} | Review required | [ ] Compliant |")
                    matched = True
                    break
            if not matched:
                lines.append(f"| On-premises / {model.framework} | N/A if no transfer | N/A | [x] Compliant |")

            lines.append(f"\n**Infrastructure Note:** Verify that {model.framework} hosting "
                        f"infrastructure and any cloud services used for model training and "
                        f"inference comply with GDPR transfer requirements.")
        else:
            lines.append("| [ ] To be determined | [ ] To be assessed | | [ ] Compliant |")

        return "\n".join(lines)

    def _dpo(self, model, pipeline) -> str:
        has_owner = bool(model and model.owner)
        has_contact = bool(model and model.contact)
        is_large_scale = bool(model and model.training_rows >= 100000)

        lines = [
            "**Articles 37-39 - Data Protection Officer (DPO):**\n",
            "A Data Protection Officer must be designated where the core activities of the "
            "controller or processor consist of processing operations which require regular "
            "and systematic monitoring of data subjects on a large scale, or processing of "
            "special categories of data on a large scale (Article 37(1)).\n",
        ]

        if is_large_scale:
            lines.append(f"**DPO Designation Required:** This system processes {model.training_rows:,} "
                        f"data subject records, qualifying as large-scale processing under "
                        f"Article 37(1)(b). A DPO must be designated.\n")

        lines.extend([
            "**DPO Responsibilities (Article 39):**\n",
            "- Inform and advise the controller/processor and employees on GDPR obligations",
            "- Monitor compliance with the GDPR and with the policies of the controller",
            "- Provide advice on the Data Protection Impact Assessment (Article 35)",
            "- Cooperate with the supervisory authority",
            "- Act as the contact point for the supervisory authority on issues relating "
            "to processing\n",
            "**AI/ML-Specific DPO Involvement:**\n",
            "- Review and approve new AI/ML processing activities involving personal data",
            "- Participate in DPIA processes for high-risk AI systems",
            "- Monitor AI system fairness and non-discrimination compliance",
            "- Advise on data subject rights implementation for automated decisions",
            "- Review international transfer mechanisms for cloud ML services\n",
            "**DPO Contact Information:**\n",
        ])

        if has_owner:
            lines.append(f"- Name: {model.owner}")
        else:
            lines.append("- Name: [ ] To be documented")

        if has_contact:
            lines.append(f"- Email: {model.contact}")
        else:
            lines.append("- Email: [ ] To be documented")

        lines.append("- Phone: [ ] To be documented")

        if has_owner:
            lines.append(f"\n**System Owner:** {model.owner}")
        if has_contact:
            lines.append(f"**System Contact:** {model.contact}")
        if pipeline and pipeline.owner:
            lines.append(f"**Pipeline Owner:** {pipeline.owner}")
        return "\n".join(lines)


class NISTAIRMFTemplate(BaseTemplate):
    """NIST AI Risk Management Framework documentation template."""
    name = "NIST AI Risk Management Framework"
    description = "NIST AI RMF 1.0 (AI 100-1) risk management documentation for AI systems"

    AUC_THRESHOLDS = [(0.90, "Excellent"), (0.80, "Good"), (0.70, "Acceptable"), (0.60, "Marginal")]

    @staticmethod
    def _rate(value: float, thresholds: list) -> str:
        for threshold, label in thresholds:
            if value >= threshold:
                return label
        return "Poor"

    def render(self, context: Dict[str, Any]) -> List[DocumentSection]:
        model = context.get("model")
        pipeline = context.get("pipeline")
        fairlens = context.get("fairlens_report")
        sections = []

        sections.append(DocumentSection(
            title="AI System Profile",
            content=self._system_profile(model, pipeline),
        ))
        sections.append(DocumentSection(
            title="Risk Identification (GOVERN)",
            content=self._govern(model),
        ))
        sections.append(DocumentSection(
            title="Risk Assessment (MAP)",
            content=self._map(model, context),
        ))
        sections.append(DocumentSection(
            title="Risk Mitigation (MEASURE)",
            content=self._measure(model, fairlens),
        ))
        sections.append(DocumentSection(
            title="Risk Monitoring (MANAGE)",
            content=self._manage(model, pipeline),
        ))
        sections.append(DocumentSection(
            title="Stakeholder Engagement",
            content=self._stakeholder_engagement(model),
        ))
        sections.append(DocumentSection(
            title="Documentation and Reporting",
            content=self._documentation(model, pipeline),
        ))

        return sections

    def _system_profile(self, model, pipeline) -> str:
        has_model = bool(model)
        has_training = bool(model and model.training_rows > 0)
        has_metrics = bool(model and model.performance_metrics)
        has_pipeline = bool(pipeline)

        lines = [
            "**NIST AI 100-1: AI Risk Management Framework 1.0**\n",
            "This document follows the NIST AI Risk Management Framework (AI RMF 1.0), "
            "published in January 2023, which provides a voluntary framework for managing "
            "risks associated with AI systems throughout their lifecycle. The framework "
            "is structured around four core functions: GOVERN, MAP, MEASURE, and MANAGE.\n",
        ]

        if model:
            lines.append(f"**AI System Name:** {model.name}")
            lines.append(f"**Version:** {model.version}")
            lines.append(f"**Type:** {model.model_type}")
            lines.append(f"**Framework:** {model.framework}")
            lines.append(f"**Description:** {model.description or 'N/A'}")
            lines.append(f"**Intended Use:** {model.intended_use or 'N/A'}")
            lines.append(f"**Known Limitations:** {model.limitations or 'N/A'}")
            lines.append(f"**Owner:** {model.owner or 'N/A'}")
            lines.append(f"**Training Data Size:** {model.training_rows:,} samples")
            lines.append(f"**Feature Count:** {model.feature_count}\n")
        elif pipeline:
            lines.append(f"**Pipeline Name:** {pipeline.name}")
            lines.append(f"**Description:** {pipeline.description or 'N/A'}")
            lines.append(f"**Owner:** {pipeline.owner or 'N/A'}\n")
        else:
            lines.append("No model or pipeline metadata provided.\n")

        # Auto-check lifecycle stages based on available data
        check_plan = "[x]" if has_model or has_pipeline else "[ ]"
        check_data = "[x]" if has_training else "[ ]"
        check_build = "[x]" if has_model else "[ ]"
        check_validate = "[x]" if has_metrics else "[ ]"
        check_deploy = "[ ]"
        check_monitor = "[x]" if has_metrics and has_pipeline else "[ ]"
        check_retire = "[ ]"

        lines.append("**AI System Lifecycle Stage:**")
        lines.append(f"- {check_plan} Plan and Design")
        lines.append(f"- {check_data} Collect and Process Data")
        lines.append(f"- {check_build} Build and Use Model")
        lines.append(f"- {check_validate} Verify and Validate")
        lines.append(f"- {check_deploy} Deploy")
        lines.append(f"- {check_monitor} Operate and Monitor")
        lines.append(f"- {check_retire} Retire")

        completed = sum(1 for c in [check_plan, check_data, check_build, check_validate,
                                     check_deploy, check_monitor, check_retire] if c == "[x]")
        lines.append(f"\n**Lifecycle Completion:** {completed}/7 stages documented")

        return "\n".join(lines)

    def _govern(self, model) -> str:
        has_owner = bool(model and model.owner)
        has_contact = bool(model and model.contact)
        has_description = bool(model and model.description)
        has_limitations = bool(model and model.limitations)
        has_framework = bool(model and model.framework and model.framework != "unknown")

        lines = [
            "**GOVERN Function - Cultivate a Culture of Risk Management:**\n",
            "The GOVERN function establishes the organizational context, culture, and "
            "structures for AI risk management. It is cross-cutting and informs all "
            "other functions.\n",
        ]

        # GOVERN 1 - Policies
        check_policy = "[x]" if has_owner and has_description else "[ ]"
        check_legal = "[x]" if has_limitations else "[ ]"
        lines.append("**GOVERN 1 - Policies:**")
        lines.append("Organizational policies and procedures for AI risk management are established "
                     "and regularly reviewed. Legal and regulatory requirements involving AI are "
                     "understood, managed, and documented.")
        lines.append(f"- {check_policy} AI risk management policy established")
        lines.append(f"- {check_legal} Legal and regulatory AI requirements cataloged\n")

        # GOVERN 2 - Accountability
        check_ownership = "[x]" if has_owner else "[ ]"
        check_roles = "[x]" if has_owner and has_contact else "[ ]"
        lines.append("**GOVERN 2 - Accountability:**")
        lines.append("Accountability structures are in place so that the appropriate teams and "
                     "individuals are empowered, responsible, and trained for mapping, measuring, "
                     "and managing AI risks.")
        lines.append(f"- {check_ownership} AI system ownership assigned")
        lines.append(f"- {check_roles} Roles and responsibilities documented")
        if has_owner:
            lines.append(f"  - System Owner: {model.owner}")
        if has_contact:
            lines.append(f"  - Contact: {model.contact}")
        lines.append("")

        # GOVERN 3 - Workforce
        lines.append("**GOVERN 3 - Workforce:**")
        lines.append("Workforce diversity, equity, inclusion, and accessibility processes are "
                     "prioritized in the mapping, measuring, and managing of AI risks throughout "
                     "the lifecycle.")
        lines.append("- [ ] Diverse development team composition")
        lines.append("- [ ] Inclusive design practices documented\n")

        # GOVERN 4 - Organizational Context
        check_cross_func = "[x]" if has_owner else "[ ]"
        lines.append("**GOVERN 4 - Organizational Context:**")
        lines.append("Organizational teams are committed to a culture that considers and communicates "
                     "AI risk.")
        lines.append(f"- {check_cross_func} Cross-functional risk review process established\n")

        # GOVERN 5 - Engagement
        check_engagement = "[x]" if has_contact else "[ ]"
        lines.append("**GOVERN 5 - Engagement:**")
        lines.append("Processes are in place for robust engagement with relevant AI actors.")
        lines.append(f"- {check_engagement} Stakeholder engagement plan documented\n")

        # GOVERN 6 - Risk Tolerance
        check_third_party = "[x]" if has_framework else "[ ]"
        check_supply = "[x]" if has_framework else "[ ]"
        lines.append("**GOVERN 6 - Risk Tolerance:**")
        lines.append("Policies and procedures are in place to address AI risks and benefits "
                     "arising from third-party software and data and other supply chain issues.")
        lines.append(f"- {check_third_party} Third-party AI risk assessment process established")
        lines.append(f"- {check_supply} Supply chain risk management for AI components documented")

        if has_framework:
            lines.append(f"\n**Third-Party Dependencies:** {model.framework}")
            if model.hyperparameters:
                lines.append(f"**Configuration Parameters:** {len(model.hyperparameters)} hyperparameters documented")

        if has_owner:
            lines.append(f"\n**System Owner:** {model.owner}")

        # Governance completeness summary
        total_checks = 10
        checked = sum(1 for c in [check_policy, check_legal, check_ownership, check_roles,
                                   check_cross_func, check_engagement, check_third_party,
                                   check_supply] if c == "[x]")
        lines.append(f"\n**GOVERN Completeness:** {checked}/{total_checks} governance items addressed")

        return "\n".join(lines)

    def _map(self, model, context) -> str:
        has_model = bool(model)
        has_use = bool(model and model.intended_use)
        has_limitations = bool(model and model.limitations)
        has_description = bool(model and model.description)
        has_metrics = bool(model and model.performance_metrics)
        fairlens = context.get("fairlens_report")
        has_fairlens = bool(fairlens)

        lines = [
            "**MAP Function - Contextualize Risks:**\n",
            "The MAP function establishes the context for framing risks related to an "
            "AI system. It identifies and documents the AI system's purpose, operating "
            "context, and potential impacts.\n",
            "**MAP 1 - Context and Purpose:**",
            "The intended purpose, context of use, deployment setting, and potential "
            "benefits and costs are understood and documented.",
        ]

        if model:
            lines.append(f"- Intended Use: {model.intended_use or 'Not specified'}")
            lines.append(f"- Known Limitations: {model.limitations or 'Not specified'}")

        check_use_cases = "[x]" if has_use else "[ ]"
        check_benefits = "[x]" if has_description else "[ ]"
        check_costs = "[x]" if has_limitations else "[ ]"

        lines.append(f"- {check_use_cases} Use cases and deployment contexts enumerated")
        lines.append(f"- {check_benefits} Potential benefits documented")
        lines.append(f"- {check_costs} Potential costs and negative impacts documented\n")

        # MAP 2 - Categorization
        check_risk_cat = "[x]" if has_fairlens or has_metrics else "[ ]"
        check_impact = "[x]" if has_use else "[ ]"

        lines.append("**MAP 2 - Categorization:**")
        lines.append("AI systems are categorized based on risk levels, considering potential "
                     "impacts to individuals, groups, communities, organizations, and ecosystems.")
        lines.append(f"- {check_risk_cat} Risk categorization completed")
        lines.append(f"- {check_impact} Impact assessment scope defined")

        if has_use:
            use_lower = model.intended_use.lower()
            if any(kw in use_lower for kw in ("credit", "loan", "lending", "mortgage")):
                risk_level = "High"
                impact_area = "Financial decisions affecting individual creditworthiness and access to capital"
            elif any(kw in use_lower for kw in ("fraud", "aml", "anti-money")):
                risk_level = "High"
                impact_area = "Law enforcement and financial crime prevention"
            elif any(kw in use_lower for kw in ("hiring", "recruit")):
                risk_level = "High"
                impact_area = "Employment decisions affecting individual livelihoods"
            elif any(kw in use_lower for kw in ("insurance",)):
                risk_level = "High"
                impact_area = "Insurance access and pricing decisions"
            else:
                risk_level = "Medium"
                impact_area = "General business decisions"
            lines.append(f"\n**Risk Level Assessment:** {risk_level}")
            lines.append(f"**Primary Impact Area:** {impact_area}")

        lines.append("")

        # MAP 3 - Benefits and Costs
        check_cba = "[x]" if has_use and has_limitations else "[ ]"
        lines.append("**MAP 3 - Benefits and Costs:**")
        lines.append("Benefits and costs of the AI system are assessed, including the costs of "
                     "not deploying the system.")
        lines.append(f"- {check_cba} Cost-benefit analysis documented")

        if has_model and has_metrics:
            lines.append(f"\n**Quantified Benefits:** Model performance metrics available "
                        f"({len(model.performance_metrics)} metrics tracked), enabling "
                        f"quantitative assessment of system value.")
        lines.append("")

        # MAP 4 - Risks
        check_risk_id = "[x]" if has_fairlens or has_metrics else "[ ]"
        lines.append("**MAP 4 - Risks:**")
        lines.append("Risks and potential impacts are identified based on the AI system's "
                     "characteristics, operating context, and stakeholder interactions.")
        lines.append(f"- {check_risk_id} Risk identification completed")

        if has_fairlens:
            summary = fairlens.get("summary", {})
            critical = summary.get("critical", 0)
            warnings = summary.get("warnings", 0)
            lines.append(f"\n**Identified Risks from FairLens Analysis:**")
            lines.append(f"- {critical} critical risk(s)")
            lines.append(f"- {warnings} warning-level risk(s)")
        lines.append("")

        # MAP 5 - Impacts
        check_impact_char = "[x]" if has_use and has_limitations else "[ ]"
        lines.append("**MAP 5 - Impacts:**")
        lines.append("Impacts to individuals, groups, communities, organizations, and the "
                     "environment are characterized.")
        lines.append(f"- {check_impact_char} Impact characterization completed")

        dag_nodes = context.get("dag_nodes", [])
        dag_edges = context.get("dag_edges", [])
        if dag_nodes:
            lines.append(f"\n**Data Pipeline Context:**")
            lines.append(f"The AI system processes data through a pipeline with "
                        f"{len(dag_nodes)} nodes and {len(dag_edges)} edges.")
            source_nodes = [n for n in dag_nodes if n.get("type") == "source"]
            transform_nodes = [n for n in dag_nodes if n.get("type") == "transform"]
            model_nodes = [n for n in dag_nodes if n.get("type") == "model"]
            if source_nodes:
                lines.append(f"**Data Sources ({len(source_nodes)}):** "
                            f"{', '.join(n.get('name', 'unknown') for n in source_nodes)}")
            if transform_nodes:
                lines.append(f"**Transformations ({len(transform_nodes)}):** "
                            f"{', '.join(n.get('name', 'unknown') for n in transform_nodes)}")
            if model_nodes:
                lines.append(f"**Output Models ({len(model_nodes)}):** "
                            f"{', '.join(n.get('name', 'unknown') for n in model_nodes)}")

        return "\n".join(lines)

    def _measure(self, model, fairlens) -> str:
        has_metrics = bool(model and model.performance_metrics)
        has_fairlens = bool(fairlens)
        has_owner = bool(model and model.owner)
        has_importances = bool(model and model.feature_importances)

        lines = [
            "**MEASURE Function - Analyze and Quantify Risks:**\n",
            "The MEASURE function employs quantitative, qualitative, or mixed-method "
            "tools, techniques, and methodologies to analyze, assess, benchmark, and "
            "monitor AI risk and related impacts.\n",
            "**MEASURE 1 - Metrics:**",
            "Appropriate methods and metrics are identified and applied to measure "
            "AI risks and trustworthiness characteristics including: validity, "
            "reliability, safety, security, resilience, accountability, transparency, "
            "explainability, interpretability, privacy, and fairness.",
        ]

        if has_metrics:
            lines.append("\n**Performance Metrics:**\n")
            lines.append("| Metric | Value | Assessment |")
            lines.append("|--------|-------|------------|")
            pm = model.performance_metrics
            for metric, value in pm.items():
                if isinstance(value, float):
                    assessment = ""
                    m_lower = metric.lower().replace("-", "_").replace(" ", "_")
                    if m_lower in ("auc", "auc_roc"):
                        assessment = self._rate(value, self.AUC_THRESHOLDS)
                    elif m_lower == "accuracy":
                        assessment = "Adequate" if value >= 0.80 else "Review recommended"
                    elif m_lower == "f1":
                        assessment = "Good" if value >= 0.75 else "Needs improvement"
                    lines.append(f"| {metric} | {value:.4f} | {assessment} |")
                else:
                    lines.append(f"| {metric} | {value} | |")

            # Trustworthiness characteristics assessment
            lines.append("\n**Trustworthiness Characteristics Assessment:**\n")
            lines.append("| Characteristic | Status | Evidence |")
            lines.append("|---------------|--------|----------|")

            validity = "Measured" if has_metrics else "Not measured"
            validity_evidence = f"{len(pm)} metrics" if has_metrics else "No metrics"
            lines.append(f"| Validity & Reliability | {validity} | {validity_evidence} |")

            fairness_status = "Measured" if has_fairlens else "Not measured"
            fairness_evidence = "FairLens analysis" if has_fairlens else "No fairness analysis"
            lines.append(f"| Fairness | {fairness_status} | {fairness_evidence} |")

            explain_status = "Available" if has_importances else "Not available"
            explain_evidence = f"{len(model.feature_importances)} feature importances" if has_importances else "No feature importances"
            lines.append(f"| Explainability | {explain_status} | {explain_evidence} |")

            account_status = "Established" if has_owner else "Not established"
            account_evidence = model.owner if has_owner else "No owner assigned"
            lines.append(f"| Accountability | {account_status} | {account_evidence} |")

            lines.append(f"| Transparency | {'Documented' if has_metrics else 'Not documented'} | This report |")
            lines.append(f"| Security | Assess separately | Requires infrastructure review |")
            lines.append(f"| Privacy | Assess separately | Requires data protection review |")

        # MEASURE 2 - Evaluation
        check_internal = "[x]" if has_metrics else "[ ]"
        check_external = "[x]" if has_fairlens else "[ ]"

        lines.append("\n**MEASURE 2 - Evaluation:**")
        lines.append("AI systems are evaluated for trustworthy characteristics by internal and "
                     "external evaluators.")
        lines.append(f"- {check_internal} Internal evaluation completed")
        lines.append(f"- {check_external} External evaluation completed (where applicable)\n")

        # MEASURE 3 - Tracking
        check_tracking = "[x]" if has_metrics else "[ ]"
        check_dashboards = "[x]" if has_owner and has_metrics else "[ ]"

        lines.append("**MEASURE 3 - Tracking:**")
        lines.append("Mechanisms for tracking identified AI risks over time are in place.")
        lines.append(f"- {check_tracking} Risk tracking system configured")
        lines.append(f"- {check_dashboards} Monitoring dashboards deployed\n")

        # MEASURE 4 - Feedback
        check_feedback = "[x]" if has_owner else "[ ]"

        lines.append("**MEASURE 4 - Feedback:**")
        lines.append("Feedback about efficacy of measurement is collected and integrated into "
                     "improvements.")
        lines.append(f"- {check_feedback} Feedback collection mechanism in place")

        if has_fairlens:
            summary = fairlens.get("summary", {})
            lines.append("\n**Fairness Measurement Results (FairLens):**\n")
            lines.append(f"- Critical findings: {summary.get('critical', 0)}")
            lines.append(f"- Warnings: {summary.get('warnings', 0)}")
            lines.append(f"- Proxy features detected: {summary.get('proxy_features_detected', 0)}")

            di_results = fairlens.get("disparate_impact", [])
            if di_results:
                lines.append("\n**Disparate Impact Measurement:**\n")
                lines.append("| Protected Attribute | DI Ratio | Four-Fifths Rule |")
                lines.append("|--------------------:|:--------:|:----------------:|")
                for di in di_results:
                    attr = di.get("protected_attribute", "unknown")
                    ratio = di.get("worst_ratio", 0)
                    status = "FAIL" if di.get("has_disparate_impact", False) else "PASS"
                    lines.append(f"| {attr} | {ratio:.2f} | {status} |")

            proxy_results = fairlens.get("proxy_detection", [])
            if proxy_results:
                lines.append("\n**Proxy Feature Detection:**\n")
                lines.append("| Feature | Protected Attribute | Correlation |")
                lines.append("|---------|--------------------:|:-----------:|")
                for p in proxy_results:
                    lines.append(f"| {p.get('feature_name', 'unknown')} | "
                                f"{p.get('protected_attribute', 'unknown')} | "
                                f"{p.get('correlation', 0):.2f} |")

            findings = fairlens.get("findings", [])
            if findings:
                lines.append("\n**Detailed Findings:**\n")
                for f in findings:
                    sev = f.get("severity", "info").upper()
                    desc = f.get("description", "")
                    lines.append(f"- [{sev}] {desc}")
        return "\n".join(lines)

    def _manage(self, model, pipeline) -> str:
        has_model = bool(model)
        has_owner = bool(model and model.owner)
        has_metrics = bool(model and model.performance_metrics)
        has_pipeline = bool(pipeline)
        has_schedule = bool(pipeline and pipeline.schedule)
        has_sla = bool(pipeline and pipeline.sla)

        lines = [
            "**MANAGE Function - Allocate Resources and Act:**\n",
            "The MANAGE function allocates risk resources to mapped and measured risks "
            "on a regular basis and as defined by the GOVERN function.\n",
        ]

        # MANAGE 1 - Risk Treatment
        check_response = "[x]" if has_owner else "[ ]"
        check_residual = "[x]" if has_metrics else "[ ]"

        lines.append("**MANAGE 1 - Risk Treatment:**")
        lines.append("AI risks based on assessments and other analytical output from the MAP "
                     "and MEASURE functions are prioritized, responded to, and managed.")
        lines.append(f"- {check_response} Risk response actions assigned")
        lines.append(f"- {check_residual} Residual risk accepted or escalated\n")

        # MANAGE 2 - Deployment
        check_deploy_plan = "[x]" if has_model else "[ ]"
        check_rollback = "[x]" if has_pipeline else "[ ]"
        check_monitoring = "[x]" if has_metrics and has_schedule else "[ ]"

        lines.append("**MANAGE 2 - Deployment:**")
        lines.append("Strategies to maximize AI benefits and minimize negative impacts are "
                     "planned, prepared, and documented, and residual risks are monitored.")
        lines.append(f"- {check_deploy_plan} Deployment plan documented")
        lines.append(f"- {check_rollback} Rollback procedures established")
        lines.append(f"- {check_monitoring} Monitoring plan active\n")

        # MANAGE 3 - Incident Response
        check_incident = "[x]" if has_owner else "[ ]"
        check_classification = "[x]" if has_metrics else "[ ]"
        check_escalation = "[x]" if has_owner else "[ ]"

        lines.append("**MANAGE 3 - Incident Response:**")
        lines.append("Responses to identified AI risks are documented and monitored regularly. "
                     "Processes are in place to identify and respond to AI incidents.")
        lines.append(f"- {check_incident} Incident response plan for AI-specific scenarios")
        lines.append(f"- {check_classification} Incident classification criteria defined")
        lines.append(f"- {check_escalation} Escalation procedures documented\n")

        # MANAGE 4 - Risk Communication
        check_cadence = "[x]" if has_schedule else "[ ]"
        check_comm_plan = "[x]" if has_owner else "[ ]"

        lines.append("**MANAGE 4 - Risk Communication:**")
        lines.append("Residual risk is regularly communicated to relevant AI actors and "
                     "organizational stakeholders.")
        lines.append(f"- {check_cadence} Risk reporting cadence established")
        lines.append(f"- {check_comm_plan} Stakeholder communication plan in place")

        if has_model:
            lines.append(f"\n**Monitoring Configuration:**")
            lines.append(f"- Model: {model.name} v{model.version}")
            if has_metrics:
                lines.append(f"- Tracked metrics: {', '.join(model.performance_metrics.keys())}")
                auc = model.performance_metrics.get("AUC") or model.performance_metrics.get("auc_roc")
                if auc is not None:
                    rating = self._rate(auc, self.AUC_THRESHOLDS)
                    lines.append(f"- Current AUC: {auc:.4f} ({rating})")
                    if auc < 0.70:
                        lines.append(f"- **ALERT:** AUC below acceptable threshold; "
                                    f"enhanced monitoring required")
        if has_pipeline:
            lines.append(f"- Pipeline: {pipeline.name}")
            lines.append(f"- Schedule: {pipeline.schedule or 'N/A'}")
            lines.append(f"- SLA: {pipeline.sla or 'N/A'}")

        return "\n".join(lines)

    def _stakeholder_engagement(self, model) -> str:
        has_owner = bool(model and model.owner)
        has_contact = bool(model and model.contact)
        has_metrics = bool(model and model.performance_metrics)
        has_fairness = bool(model and model.fairness_metrics)

        lines = [
            "**Stakeholder Engagement (NIST AI 100-1, Cross-cutting):**\n",
            "The AI RMF emphasizes that AI risk management is enhanced when a broad "
            "set of perspectives and actors are engaged throughout the AI lifecycle. "
            "Meaningful engagement with diverse stakeholders improves risk identification, "
            "assessment, and mitigation.\n",
            "**Internal Stakeholders:**\n",
        ]

        check_dev = "[x]" if model else "[ ]"
        check_product = "[x]" if has_owner else "[ ]"
        check_legal = "[x]" if has_fairness else "[ ]"
        check_risk = "[x]" if has_metrics else "[ ]"
        check_audit = "[x]" if has_metrics else "[ ]"
        check_exec = "[x]" if has_owner else "[ ]"

        lines.append(f"- {check_dev} AI/ML development team")
        lines.append(f"- {check_product} Product management")
        lines.append(f"- {check_legal} Legal and compliance")
        lines.append(f"- {check_risk} Risk management")
        lines.append(f"- {check_audit} Internal audit")
        lines.append(f"- {check_exec} Executive leadership\n")

        lines.append("**External Stakeholders:**\n")
        lines.append("- [ ] End users and affected individuals")
        lines.append("- [ ] Domain experts")
        lines.append("- [ ] Civil society organizations")
        lines.append("- [ ] Regulators and standards bodies")
        lines.append("- [ ] Academic researchers\n")

        lines.append("**Engagement Methods:**\n")
        lines.append("- Participatory design sessions with affected communities")
        lines.append("- Public comment periods for high-impact AI systems")
        lines.append("- Independent third-party audits")
        lines.append("- Red-teaming exercises")
        lines.append("- Ongoing feedback mechanisms for deployed systems\n")

        lines.append("**Transparency and Communication:**")
        lines.append("Per the AI RMF, organizations should be transparent about AI system "
                     "capabilities and limitations and communicate clearly about risks and "
                     "risk management approaches to all relevant stakeholders.")

        if has_owner:
            lines.append(f"\n**System Owner:** {model.owner}")
        if has_contact:
            lines.append(f"**Contact:** {model.contact}")

        # Engagement completeness
        internal_checked = sum(1 for c in [check_dev, check_product, check_legal,
                                            check_risk, check_audit, check_exec] if c == "[x]")
        lines.append(f"\n**Internal Stakeholder Engagement:** {internal_checked}/6 groups engaged")

        return "\n".join(lines)

    def _documentation(self, model, pipeline) -> str:
        has_model = bool(model)
        has_description = bool(model and model.description)
        has_training = bool(model and model.training_rows > 0)
        has_hyperparams = bool(model and model.hyperparameters)
        has_metrics = bool(model and model.performance_metrics)
        has_owner = bool(model and model.owner)
        has_pipeline = bool(pipeline)
        has_schedule = bool(pipeline and pipeline.schedule)

        lines = [
            "**Documentation and Reporting (NIST AI 100-1):**\n",
            "The AI RMF requires comprehensive documentation throughout the AI system "
            "lifecycle. Documentation supports accountability, transparency, and the "
            "ability to audit and improve AI risk management practices.\n",
            "**Required Documentation:**\n",
        ]

        check_design = "[x]" if has_description else "[ ]"
        check_provenance = "[x]" if has_training else "[ ]"
        check_training = "[x]" if has_hyperparams else "[ ]"
        check_validation = "[x]" if has_metrics else "[ ]"
        check_risk = "[x]" if has_owner else "[ ]"
        check_deploy = "[x]" if has_pipeline else "[ ]"
        check_monitoring = "[x]" if has_schedule else "[ ]"
        check_stakeholder = "[x]" if has_owner else "[ ]"
        check_change = "[x]" if has_model and model.version != "1.0" else "[ ]"

        lines.append(f"- {check_design} AI system design and architecture documentation")
        lines.append(f"- {check_provenance} Data provenance and lineage records")
        lines.append(f"- {check_training} Model training methodology and hyperparameter selection rationale")
        lines.append(f"- {check_validation} Validation and testing results")
        lines.append(f"- {check_risk} Risk assessment and mitigation records")
        lines.append(f"- {check_deploy} Deployment and operational procedures")
        lines.append(f"- {check_monitoring} Monitoring and incident response logs")
        lines.append(f"- {check_stakeholder} Stakeholder engagement records")
        lines.append(f"- {check_change} Change management history")

        doc_checked = sum(1 for c in [check_design, check_provenance, check_training,
                                       check_validation, check_risk, check_deploy,
                                       check_monitoring, check_stakeholder, check_change]
                          if c == "[x]")
        lines.append(f"\n**Documentation Completeness:** {doc_checked}/9 items documented\n")

        lines.append("**Reporting Cadence:**\n")
        lines.append("| Report | Frequency | Audience | Status |")
        lines.append("|--------|-----------|----------|--------|")

        risk_status = "Active" if has_owner else "Not configured"
        perf_status = "Active" if has_metrics else "Not configured"
        fair_status = "Active" if model and model.fairness_metrics else "Not configured"

        lines.append(f"| Risk Assessment Summary | Quarterly | Risk Committee | {risk_status} |")
        lines.append(f"| Performance Monitoring | Monthly | System Owner | {perf_status} |")
        lines.append(f"| Fairness Audit | Semi-annually | Compliance | {fair_status} |")
        lines.append("| Incident Report | As needed | All stakeholders | Standing |")
        lines.append("| Annual Review | Annually | Executive leadership | Standing |\n")

        lines.append("**Version Control and Traceability:**")
        lines.append("All AI system artifacts, including training data, model weights, "
                     "configuration files, and documentation, must be versioned and traceable. "
                     "Changes must be documented with justification and impact assessment.")

        if model:
            lines.append(f"\n**Current System State:**")
            lines.append(f"- Model: {model.name} v{model.version}")
            lines.append(f"- Training Date: {model.training_date or 'N/A'}")
            lines.append(f"- Features: {model.feature_count}")
            lines.append(f"- Training Samples: {model.training_rows:,}")
            if has_metrics:
                lines.append(f"- Performance metrics: {len(model.performance_metrics)} tracked")
        if pipeline:
            lines.append(f"- Pipeline: {pipeline.name}")
            lines.append(f"- Schedule: {pipeline.schedule or 'N/A'}")
        return "\n".join(lines)


TEMPLATE_REGISTRY = {
    TemplateType.SR_11_7: SR117Template,
    TemplateType.EU_AI_ACT: EUAIActTemplate,
    TemplateType.MODEL_CARD: ModelCardTemplate,
    TemplateType.ECOA: ECOATemplate,
    TemplateType.DBT: DbtDocTemplate,
    TemplateType.GDPR: GDPRTemplate,
    TemplateType.NIST_AI_RMF: NISTAIRMFTemplate,
}
