"""
SQLite storage backend for local testing and development.

Drop-in replacement for PostgreSQLStorage that uses SQLite instead.
Perfect for demos, testing, and development without PostgreSQL setup.

Usage:
    from attestant.persistence.sqlite_storage import SQLiteStorage

    storage = SQLiteStorage("./test_provenance.db")
    storage.connect()
"""

import logging
import sqlite3
import json
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path

from .storage import StorageBackend, StoredNode, StoredEdge, StoredRowValue

logger = logging.getLogger(__name__)

# Default SQLite busy timeout in milliseconds for concurrent access
_DEFAULT_BUSY_TIMEOUT_MS = 5000


class SQLiteStorage(StorageBackend):
    """
    SQLite storage backend for local testing.

    Implements the same interface as PostgreSQLStorage but uses SQLite.
    Perfect for development, demos, and CI/CD testing.

    Features:
    - Zero external dependencies (SQLite built into Python)
    - File-based (portable, easy backup)
    - Fast for single-user testing
    - Same schema as PostgreSQL (easy migration)
    """

    def __init__(self, db_path: str = ":memory:"):
        """
        Initialize SQLite storage.

        Args:
            db_path: Path to SQLite database file
                    ":memory:" for in-memory database (default)
                    "./provenance.db" for persistent file
        """
        self.db_path = db_path
        self.conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        """Create database connection and initialize schema.

        Enables WAL mode and sets a busy timeout for concurrent access.
        """
        self.conn = sqlite3.connect(
            self.db_path,
            check_same_thread=False,
            timeout=_DEFAULT_BUSY_TIMEOUT_MS / 1000.0,
        )
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute(f"PRAGMA busy_timeout={_DEFAULT_BUSY_TIMEOUT_MS}")
        self._init_schema()

    def disconnect(self) -> None:
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None

    def __enter__(self):
        """Context manager entry -- connects if not already connected."""
        if self.conn is None:
            self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit -- disconnects."""
        self.disconnect()
        return False

    def __del__(self):
        """Ensure connection is closed on garbage collection."""
        try:
            self.disconnect()
        except Exception:
            pass

    def _init_schema(self) -> None:
        """Initialize database schema (same as PostgreSQL)."""
        if not self.conn:
            raise RuntimeError("Not connected to database")

        # Create tables
        self.conn.executescript("""
            -- DAG nodes
            CREATE TABLE IF NOT EXISTS dag_nodes (
                node_id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint INTEGER NOT NULL,
                node_type TEXT NOT NULL,
                operation TEXT NOT NULL,
                table_name TEXT,
                column_name TEXT,
                pair_id INTEGER,
                is_protected INTEGER DEFAULT 0,
                entity_hash INTEGER,
                chain_hash INTEGER,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                pipeline_id INTEGER,
                tenant_id TEXT,
                UNIQUE(fingerprint, pipeline_id, tenant_id)
            );

            -- DAG edges
            CREATE TABLE IF NOT EXISTS dag_edges (
                edge_id INTEGER PRIMARY KEY AUTOINCREMENT,
                parent_node_id INTEGER NOT NULL,
                child_node_id INTEGER NOT NULL,
                input_position INTEGER DEFAULT 0,
                UNIQUE(parent_node_id, child_node_id, input_position),
                FOREIGN KEY (parent_node_id) REFERENCES dag_nodes(node_id),
                FOREIGN KEY (child_node_id) REFERENCES dag_nodes(node_id)
            );

            -- Source registry
            CREATE TABLE IF NOT EXISTS source_registry (
                pair_id INTEGER PRIMARY KEY,
                table_name TEXT NOT NULL,
                column_name TEXT NOT NULL,
                is_protected INTEGER DEFAULT 0,
                registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(table_name, column_name)
            );

            -- Pipeline metadata
            CREATE TABLE IF NOT EXISTS pipeline_metadata (
                pipeline_id INTEGER PRIMARY KEY AUTOINCREMENT,
                pipeline_name TEXT,
                tenant_id TEXT,
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                status TEXT,
                config TEXT,
                git_commit TEXT,
                environment TEXT
            );

            -- Indexes for performance
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_tenant
                ON dag_nodes(tenant_id);
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_fingerprint
                ON dag_nodes(tenant_id, fingerprint);
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_protected
                ON dag_nodes(tenant_id, is_protected) WHERE is_protected = 1;
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_source
                ON dag_nodes(tenant_id, table_name, column_name)
                WHERE node_type = 'SOURCE';
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_created
                ON dag_nodes(tenant_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_dag_edges_parent
                ON dag_edges(parent_node_id);
            CREATE INDEX IF NOT EXISTS idx_dag_edges_child
                ON dag_edges(child_node_id);

            CREATE INDEX IF NOT EXISTS idx_dag_nodes_fingerprint_only
                ON dag_nodes(fingerprint);

            -- Indexes for dashboard search (LIKE prefix matching)
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_table_name
                ON dag_nodes(table_name) WHERE table_name IS NOT NULL;
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_column_name
                ON dag_nodes(column_name) WHERE column_name IS NOT NULL;
            CREATE INDEX IF NOT EXISTS idx_dag_nodes_operation
                ON dag_nodes(operation);

            -- Pipeline results: links each row's output to its provenance DAG
            CREATE TABLE IF NOT EXISTS pipeline_results (
                result_id INTEGER PRIMARY KEY AUTOINCREMENT,
                pipeline_id INTEGER NOT NULL,
                row_key TEXT NOT NULL,
                output_name TEXT NOT NULL,
                fingerprint INTEGER NOT NULL,
                output_value REAL,
                input_hash TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (pipeline_id) REFERENCES pipeline_metadata(pipeline_id)
            );

            CREATE INDEX IF NOT EXISTS idx_pipeline_results_row
                ON pipeline_results(pipeline_id, row_key);
            CREATE INDEX IF NOT EXISTS idx_pipeline_results_fingerprint
                ON pipeline_results(pipeline_id, fingerprint);

            -- Row values: per-row value at each DAG node
            CREATE TABLE IF NOT EXISTS row_values (
                value_id INTEGER PRIMARY KEY AUTOINCREMENT,
                pipeline_id INTEGER NOT NULL,
                row_index INTEGER NOT NULL,
                fingerprint INTEGER NOT NULL,
                node_operation TEXT NOT NULL,
                column_name TEXT,
                value REAL,
                text_value TEXT,
                tenant_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (pipeline_id) REFERENCES pipeline_metadata(pipeline_id)
            );
            CREATE INDEX IF NOT EXISTS idx_row_values_pipeline_row
                ON row_values(pipeline_id, row_index);
            CREATE INDEX IF NOT EXISTS idx_row_values_tenant_pipeline
                ON row_values(tenant_id, pipeline_id);
        """)
        self.conn.commit()

    def store_nodes(self, nodes: List[StoredNode]) -> None:
        """Store multiple nodes in batch using executemany."""
        if not nodes or not self.conn:
            return

        cursor = self.conn.cursor()
        node_tuples = [
            (
                node.fingerprint,
                node.node_type,
                node.operation,
                node.table_name,
                node.column_name,
                node.pair_id,
                1 if node.is_protected else 0,
                node.entity_hash,
                node.chain_hash,
                json.dumps(node.metadata) if node.metadata else None,
                node.pipeline_id,
                getattr(node, 'tenant_id', None),
            )
            for node in nodes
        ]
        cursor.executemany("""
            INSERT OR IGNORE INTO dag_nodes (
                fingerprint, node_type, operation,
                table_name, column_name, pair_id, is_protected,
                entity_hash, chain_hash, metadata, pipeline_id, tenant_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, node_tuples)

        self.conn.commit()

    def store_edges(self, edges: List[StoredEdge]) -> None:
        """Store multiple edges in batch.

        Pre-builds a fingerprint→node_id lookup map with a single query,
        then resolves all edges in memory and bulk-inserts them.
        """
        if not edges or not self.conn:
            return

        cursor = self.conn.cursor()

        # Collect all unique fingerprints referenced by edges
        fingerprints = set()
        for edge in edges:
            fingerprints.add(edge.parent_fingerprint)
            fingerprints.add(edge.child_fingerprint)

        # Build fingerprint→node_id map with a single query
        placeholders = ','.join('?' * len(fingerprints))
        cursor.execute(
            f"SELECT fingerprint, node_id FROM dag_nodes WHERE fingerprint IN ({placeholders})",
            tuple(fingerprints),
        )
        fp_to_id = dict(cursor.fetchall())

        # Resolve edges to node_ids in memory and bulk insert
        edge_tuples = []
        for edge in edges:
            parent_id = fp_to_id.get(edge.parent_fingerprint)
            child_id = fp_to_id.get(edge.child_fingerprint)
            if parent_id is not None and child_id is not None:
                edge_tuples.append((parent_id, child_id, edge.input_position))

        if edge_tuples:
            cursor.executemany("""
                INSERT OR IGNORE INTO dag_edges (parent_node_id, child_node_id, input_position)
                VALUES (?, ?, ?)
            """, edge_tuples)

        self.conn.commit()

    def store_edges_resolved(self, edges: List[Tuple[int, int, int]]) -> None:
        """Store edges with already-resolved node IDs."""
        if not edges or not self.conn:
            return
        cursor = self.conn.cursor()
        cursor.executemany("""
            INSERT OR IGNORE INTO dag_edges (parent_node_id, child_node_id, input_position)
            VALUES (?, ?, ?)
        """, edges)
        self.conn.commit()

    def get_fingerprint_node_map(self, pipeline_id: int) -> Dict[int, int]:
        """Return {fingerprint: node_id} for all nodes in a pipeline."""
        if not self.conn:
            return {}
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT fingerprint, node_id FROM dag_nodes WHERE pipeline_id = ?",
            (pipeline_id,),
        )
        return dict(cursor.fetchall())

    def register_source(self, pair_id: int, table: str, column: str,
                       is_protected: bool = False) -> None:
        """Register a source pair."""
        if not self.conn:
            return

        self.conn.execute("""
            INSERT OR REPLACE INTO source_registry (pair_id, table_name, column_name, is_protected)
            VALUES (?, ?, ?, ?)
        """, (pair_id, table, column, 1 if is_protected else 0))
        self.conn.commit()

    def get_node_by_fingerprint(self, fingerprint: int,
                                pipeline_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """Retrieve a node by fingerprint."""
        if not self.conn:
            return None

        cursor = self.conn.cursor()
        if pipeline_id is not None:
            cursor.execute("""
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = ? AND pipeline_id = ?
            """, (fingerprint, pipeline_id))
        else:
            cursor.execute("""
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = ?
                ORDER BY created_at DESC
                LIMIT 1
            """, (fingerprint,))

        row = cursor.fetchone()
        if row is None:
            return None

        return {
            'node_id': row[0],
            'fingerprint': row[1],
            'node_type': row[2],
            'operation': row[3],
            'table_name': row[4],
            'column_name': row[5],
            'pair_id': row[6],
            'is_protected': bool(row[7]),
            'entity_hash': row[8],
            'chain_hash': row[9],
            'metadata': json.loads(row[10]) if row[10] else None,
        }

    def get_edges_for_node(self, node_id: int) -> List[Dict[str, Any]]:
        """Get all parent edges for a node."""
        if not self.conn:
            return []

        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT e.parent_node_id, e.input_position, n.fingerprint
            FROM dag_edges e
            JOIN dag_nodes n ON e.parent_node_id = n.node_id
            WHERE e.child_node_id = ?
            ORDER BY e.input_position
        """, (node_id,))

        return [
            {
                'parent_node_id': row[0],
                'input_position': row[1],
                'parent_fingerprint': row[2],
            }
            for row in cursor.fetchall()
        ]

    def get_source_info(self, pair_id: int) -> Optional[Tuple[str, str, bool]]:
        """Get (table, column, is_protected) for a pair_id."""
        if not self.conn:
            return None

        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT table_name, column_name, is_protected
            FROM source_registry
            WHERE pair_id = ?
        """, (pair_id,))

        row = cursor.fetchone()
        if row:
            return (row[0], row[1], bool(row[2]))
        return None

    def create_pipeline(self, pipeline_name: str, config: Optional[Dict[str, Any]] = None,
                       git_commit: Optional[str] = None, tenant_id: Optional[str] = None) -> int:
        """Create a pipeline execution record."""
        if not self.conn:
            raise RuntimeError("Not connected to database")

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO pipeline_metadata (pipeline_name, config, git_commit, status, tenant_id)
            VALUES (?, ?, ?, 'running', ?)
        """, (pipeline_name, json.dumps(config) if config else None, git_commit, tenant_id))
        self.conn.commit()
        return cursor.lastrowid

    def complete_pipeline(self, pipeline_id: int, status: str = 'completed') -> None:
        """Mark a pipeline as completed or failed."""
        if not self.conn:
            return

        self.conn.execute("""
            UPDATE pipeline_metadata
            SET status = ?, completed_at = CURRENT_TIMESTAMP
            WHERE pipeline_id = ?
        """, (status, pipeline_id))
        self.conn.commit()

    def get_all_pipelines(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get all pipelines (for dashboard)."""
        if not self.conn:
            return []

        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT pipeline_id, pipeline_name, tenant_id, started_at,
                   completed_at, status
            FROM pipeline_metadata
            ORDER BY started_at DESC
            LIMIT ?
        """, (limit,))

        return [
            {
                'pipeline_id': row[0],
                'pipeline_name': str(row[1]) if row[1] else None,
                'tenant_id': str(row[2]) if row[2] else None,
                'started_at': str(row[3]) if row[3] else None,
                'completed_at': str(row[4]) if row[4] else None,
                'status': str(row[5]) if row[5] else None,
            }
            for row in cursor.fetchall()
        ]

    def get_recent_nodes(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent nodes (for dashboard)."""
        if not self.conn:
            return []

        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT node_id, fingerprint, node_type, operation,
                   table_name, column_name, is_protected, created_at
            FROM dag_nodes
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))

        return [
            {
                'node_id': row[0],
                'fingerprint': row[1],
                'node_type': str(row[2]) if row[2] else None,
                'operation': str(row[3]) if row[3] else None,
                'table_name': str(row[4]) if row[4] else None,
                'column_name': str(row[5]) if row[5] else None,
                'is_protected': bool(row[6]),
                'created_at': str(row[7]) if row[7] else None,
            }
            for row in cursor.fetchall()
        ]

    def store_row_values(self, values: List[StoredRowValue]) -> None:
        """Store per-row values at DAG nodes."""
        if not values or not self.conn:
            return

        cursor = self.conn.cursor()
        cursor.executemany("""
            INSERT INTO row_values
                (pipeline_id, row_index, fingerprint, node_operation,
                 column_name, value, text_value, tenant_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            (v.pipeline_id, v.row_index, v.fingerprint,
             v.node_operation, v.column_name, v.value, v.text_value, v.tenant_id)
            for v in values
        ])
        self.conn.commit()

    def get_row_values(self, pipeline_id: int,
                       row_index: int) -> List[Dict[str, Any]]:
        """Retrieve all values for a specific row in a pipeline."""
        if not self.conn:
            return []

        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT fingerprint, node_operation, column_name, value, text_value
            FROM row_values
            WHERE pipeline_id = ? AND row_index = ?
            ORDER BY value_id
        """, (pipeline_id, row_index))

        return [
            {
                'fingerprint': row[0],
                'node_operation': row[1],
                'column_name': row[2],
                'value': row[3] if row[3] is not None else row[4],
            }
            for row in cursor.fetchall()
        ]

    def store_results(self, pipeline_id: int,
                      results: List[tuple]) -> None:
        """Store per-row pipeline output fingerprints.

        This is the audit trail that links a specific person/row to the
        provenance DAG. Each row records: for row_key X, output Y was
        produced with fingerprint Z (which maps to a DAG node).

        Args:
            pipeline_id: The pipeline execution that produced these results.
            results: List of (row_key, output_name, fingerprint, output_value,
                     input_hash) tuples. row_key is the business identifier
                     (e.g. applicant_id). input_hash is a SHA-256 of the
                     source row values used to produce this output.
        """
        if not results or not self.conn:
            return

        cursor = self.conn.cursor()
        cursor.executemany("""
            INSERT INTO pipeline_results
                (pipeline_id, row_key, output_name, fingerprint, output_value, input_hash)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [(pipeline_id, *row) for row in results])
        self.conn.commit()

    def get_results_for_row(self, row_key: str,
                            pipeline_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Look up all provenance results for a specific row (e.g. applicant).

        Returns each output produced for this row, its fingerprint, and the
        fingerprint links to the DAG via dag_nodes.fingerprint.
        """
        if not self.conn:
            return []

        cursor = self.conn.cursor()
        if pipeline_id is not None:
            cursor.execute("""
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                WHERE r.row_key = ? AND r.pipeline_id = ?
                ORDER BY r.output_name
            """, (row_key, pipeline_id))
        else:
            cursor.execute("""
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                WHERE r.row_key = ?
                ORDER BY r.pipeline_id DESC, r.output_name
            """, (row_key,))

        return [
            {
                'output_name': row[0],
                'fingerprint': row[1],
                'output_value': row[2],
                'pipeline_id': row[3],
                'node_id': row[4],
                'node_type': row[5],
                'operation': row[6],
                'is_protected': bool(row[7]) if row[7] is not None else None,
            }
            for row in cursor.fetchall()
        ]

    def get_stats(self) -> Dict[str, Any]:
        """Get database statistics (for dashboard)."""
        if not self.conn:
            return {}

        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT
                (SELECT COUNT(*) FROM dag_nodes),
                (SELECT COUNT(*) FROM dag_edges),
                (SELECT COUNT(*) FROM source_registry),
                (SELECT COUNT(*) FROM dag_nodes WHERE is_protected = 1),
                (SELECT COUNT(*) FROM pipeline_metadata),
                (SELECT COUNT(*) FROM pipeline_results)
        """)
        row = cursor.fetchone()

        try:
            cursor.execute("SELECT COUNT(*) FROM row_values")
            row_value_count = cursor.fetchone()[0]
        except Exception:
            row_value_count = 0

        return {
            'nodes': row[0],
            'edges': row[1],
            'sources': row[2],
            'protected_nodes': row[3],
            'pipelines': row[4],
            'results': row[5],
            'row_values': row_value_count,
        }
