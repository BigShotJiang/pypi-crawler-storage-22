"""
Comprehensive tests for immutable audit logging system.

Tests verify:
- Immutability (cannot update/delete records)
- Batch atomicity (all or nothing)
- Hash verification (tampering detection)
- Timestamp accuracy (UTC microseconds)
- Concurrent writes (no race conditions)
- Database-level permissions enforcement
"""

import json
import pytest
import sqlite3
from datetime import datetime, timezone
from typing import List
from unittest.mock import MagicMock, Mock, patch

from attestant.audit_logger import (
    ImmutableAuditLogger,
    AuditLogException,
    get_utc_now_microseconds,
    hash_record,
    hash_features,
    hash_protected_attrs,
)


class TestHashFunctions:
    """Test cryptographic hashing for integrity verification."""

    def test_hash_record_deterministic(self):
        """Hash should be deterministic (same input = same hash)."""
        data = {'client_id': 'test', 'model_id': 'model123', 'value': 42}
        hash1 = hash_record(data)
        hash2 = hash_record(data)
        assert hash1 == hash2

    def test_hash_record_different_for_different_data(self):
        """Different data should produce different hashes."""
        data1 = {'client_id': 'test1', 'value': 42}
        data2 = {'client_id': 'test2', 'value': 42}
        hash1 = hash_record(data1)
        hash2 = hash_record(data2)
        assert hash1 != hash2

    def test_hash_record_with_chain(self):
        """Hash chain should include previous hash."""
        data = {'value': 42}
        hash1 = hash_record(data)
        hash2 = hash_record(data, previous_hash=hash1)
        assert hash1 != hash2

    def test_hash_record_256bit(self):
        """Hash should be SHA-256 (64 hex characters)."""
        data = {'test': 'data'}
        h = hash_record(data)
        assert len(h) == 64
        assert all(c in '0123456789abcdef' for c in h)

    def test_hash_features(self):
        """Features hash should be deterministic."""
        features = [1.0, 2.0, 3.0]
        hash1 = hash_features(features)
        hash2 = hash_features(features)
        assert hash1 == hash2
        assert len(hash1) == 64

    def test_hash_protected_attrs(self):
        """Protected attributes hash should be deterministic."""
        attrs = {'race': 'white', 'gender': 'male'}
        hash1 = hash_protected_attrs(attrs)
        hash2 = hash_protected_attrs(attrs)
        assert hash1 == hash2
        assert len(hash1) == 64

    def test_hash_different_for_different_protected_attrs(self):
        """Different attributes should produce different hashes."""
        attrs1 = {'race': 'white'}
        attrs2 = {'race': 'black'}
        assert hash_protected_attrs(attrs1) != hash_protected_attrs(attrs2)


class TestTimestamp:
    """Test UTC timestamp generation with microsecond precision."""

    def test_timestamp_is_utc(self):
        """Timestamp should be in UTC timezone."""
        ts = get_utc_now_microseconds()
        assert ts.tzinfo is not None
        assert ts.tzinfo == timezone.utc

    def test_timestamp_has_microseconds(self):
        """Timestamp should have microsecond precision."""
        ts = get_utc_now_microseconds()
        assert ts.microsecond >= 0
        assert ts.microsecond < 1000000

    def test_timestamp_monotonically_increasing(self):
        """Consecutive timestamps should increase."""
        ts1 = get_utc_now_microseconds()
        ts2 = get_utc_now_microseconds()
        assert ts2 >= ts1


class MockConnectionPool:
    """Mock connection pool for testing."""

    def __init__(self, init_queries=False, should_fail_immutability=False):
        self.connection = MagicMock()
        self.cursor = MagicMock()
        self.connection.cursor.return_value = self.cursor
        self.connection.set_isolation_level = MagicMock()
        self.connection.commit = MagicMock()
        self.connection.rollback = MagicMock()
        self.init_queries = init_queries
        self.should_fail_immutability = should_fail_immutability
        self.queries_executed = []
        self.records_inserted = {}
        self.fetchall_return = []
        self.fetchone_return = None

        # Setup cursor mock
        self.cursor.execute = MagicMock(side_effect=self._execute)
        self.cursor.fetchone = MagicMock(side_effect=self._fetchone)
        self.cursor.fetchall = MagicMock(side_effect=self._fetchall)
        self.cursor.close = MagicMock()

    def getconn(self):
        return self.connection

    def putconn(self, conn):
        pass

    def _fetchone(self):
        """Return mocked fetchone result."""
        return self.fetchone_return

    def _fetchall(self):
        """Return mocked fetchall result."""
        return self.fetchall_return

    def _execute(self, query, params=None):
        """Track executed queries and simulate behavior."""
        self.queries_executed.append((query, params))

        # Simulate immutability check
        if "role_table_grants" in query and ("UPDATE" in query or "DELETE" in query):
            if self.should_fail_immutability:
                self.fetchall_return = [('audit_log_predictions', 'UPDATE')]
            else:
                self.fetchall_return = []
            return

        # Simulate INSERT tracking
        if "INSERT INTO audit_log_predictions" in query:
            batch_id = params[0]
            if batch_id not in self.records_inserted:
                self.records_inserted[batch_id] = 0
            self.records_inserted[batch_id] += 1

        # Simulate batch verification
        if "SELECT COUNT(*) FROM audit_log_predictions WHERE batch_id" in query:
            batch_id = params[0]
            count = self.records_inserted.get(batch_id, 0)
            self.fetchone_return = (count,)

        # Simulate DI record tracking
        if "INSERT INTO audit_log_disparate_impact" in query:
            batch_id = params[4]
            if batch_id not in self.records_inserted:
                self.records_inserted[batch_id] = 0
            self.records_inserted[batch_id] += 1

        # Simulate DI batch verification
        if "SELECT COUNT(*) FROM audit_log_disparate_impact WHERE prediction_batch_id" in query:
            batch_id = params[0]
            count = self.records_inserted.get(batch_id, 0)
            self.fetchone_return = (count,)

        # Simulate evidence insert
        if "INSERT INTO audit_log_evidence" in query:
            self.fetchone_return = None

        # Simulate previous record lookup
        if "SELECT record_hash FROM audit_log_evidence" in query:
            self.fetchone_return = (None,)

        # Simulate record lookup for integrity check
        if "SELECT record_hash, previous_hash FROM" in query:
            self.fetchone_return = ('abc123hash', None)


class TestImmutableAuditLoggerInitialization:
    """Test initialization and immutability verification."""

    def test_initialization_succeeds(self):
        """Logger should initialize successfully."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)
        assert logger is not None

    def test_initialization_verifies_immutability(self):
        """Initialization should verify UPDATE/DELETE are revoked."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        # Should have executed immutability check
        immutability_checks = [
            q for q in pool.queries_executed
            if "role_table_grants" in q[0] and "UPDATE" in q[0]
        ]
        assert len(immutability_checks) > 0

    def test_initialization_fails_if_update_not_revoked(self):
        """Should raise exception if UPDATE permission exists."""
        pool = MockConnectionPool(should_fail_immutability=True)

        with pytest.raises(AuditLogException, match="FATAL: Audit tables have UPDATE/DELETE"):
            ImmutableAuditLogger(pool)


class TestPredictionBatchLogging:
    """Test logging predictions with disparate impact info."""

    def test_log_prediction_batch_single_record(self):
        """Should log single prediction successfully."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        predictions = [{
            'model_id': 'model123',
            'model_version': '1.0',
            'prediction_value': 0.85,
            'action': 'ALLOWED',
            'request_id': 'req123'
        }]

        batch_id = logger.log_prediction_batch(
            predictions,
            client_id='client1',
            deployment_id='deploy1'
        )

        assert batch_id is not None
        assert isinstance(batch_id, str)

    def test_log_prediction_batch_multiple_records(self):
        """Should log multiple predictions atomically."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        predictions = [
            {
                'model_id': f'model{i}',
                'model_version': '1.0',
                'prediction_value': 0.5 + i * 0.1,
                'action': 'ALLOWED' if i % 2 == 0 else 'BLOCKED',
                'request_id': f'req{i}'
            }
            for i in range(5)
        ]

        batch_id = logger.log_prediction_batch(
            predictions,
            client_id='client1',
            deployment_id='deploy1'
        )

        assert batch_id is not None

    def test_log_prediction_batch_validates_required_fields(self):
        """Should validate that required fields are present."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        predictions = [{
            'model_id': 'model123',
        }]

        with pytest.raises(AuditLogException, match="missing required field"):
            logger.log_prediction_batch(
                predictions,
                client_id='client1',
                deployment_id='deploy1'
            )

    def test_log_prediction_batch_atomicity(self):
        """Batch should be atomic (all or nothing)."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        predictions = [
            {
                'model_id': 'model123',
                'model_version': '1.0',
                'prediction_value': 0.85,
                'action': 'ALLOWED',
                'request_id': 'req123'
            }
        ]

        batch_id = logger.log_prediction_batch(
            predictions,
            client_id='client1',
            deployment_id='deploy1'
        )

        # Should have set transaction isolation level
        assert pool.connection.set_isolation_level.called

    def test_log_prediction_batch_hashes_private_data(self):
        """Should hash input and protected attributes (privacy)."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        predictions = [{
            'model_id': 'model123',
            'model_version': '1.0',
            'prediction_value': 0.85,
            'action': 'ALLOWED',
            'request_id': 'req123',
            'X': [1.0, 2.0, 3.0],
            'protected_attrs': {'race': 'white'}
        }]

        logger.log_prediction_batch(
            predictions,
            client_id='client1',
            deployment_id='deploy1'
        )

        # Check that hashing was called
        insert_queries = [q for q in pool.queries_executed if "INSERT INTO audit_log_predictions" in q[0]]
        assert len(insert_queries) > 0

    def test_log_prediction_batch_includes_di_violations(self):
        """Should log DI violation flags and details."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        predictions = [{
            'model_id': 'model123',
            'model_version': '1.0',
            'prediction_value': 0.85,
            'action': 'BLOCKED',
            'request_id': 'req123',
            'di_violation_level1': True,
            'di_violation_level2': False,
            'di_violations': {
                'race': {'di_ratio': 0.75, 'violation': True}
            }
        }]

        batch_id = logger.log_prediction_batch(
            predictions,
            client_id='client1',
            deployment_id='deploy1'
        )

        assert batch_id is not None


class TestDisparateImpactLogging:
    """Test logging disparate impact calculations."""

    def test_log_di_batch_single_record(self):
        """Should log DI calculation successfully."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        di_data = [{
            'protected_column': 'race',
            'protected_group': 'white',
            'reference_group': 'black',
            'protected_rate': 0.95,
            'reference_rate': 0.80,
            'di_ratio': 0.842,
            'protection_level': 2,
            'violation_detected': True,
            'action_taken': 'BLOCKED'
        }]

        batch_id = logger.log_disparate_impact_batch(
            di_data,
            client_id='client1',
            model_id='model123',
            model_version='1.0',
            batch_id='batch123'
        )

        assert batch_id is not None

    def test_log_di_batch_multiple_protected_groups(self):
        """Should log multiple group comparisons."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        di_data = [
            {
                'protected_column': 'race',
                'protected_group': 'white',
                'reference_group': 'black',
                'protected_rate': 0.95,
                'reference_rate': 0.80,
                'di_ratio': 0.842,
                'protection_level': 2,
                'violation_detected': True,
                'action_taken': 'BLOCKED'
            },
            {
                'protected_column': 'race',
                'protected_group': 'white',
                'reference_group': 'hispanic',
                'protected_rate': 0.95,
                'reference_rate': 0.90,
                'di_ratio': 0.947,
                'protection_level': 2,
                'violation_detected': False,
                'action_taken': 'ALLOWED'
            }
        ]

        batch_id = logger.log_disparate_impact_batch(
            di_data,
            client_id='client1',
            model_id='model123',
            model_version='1.0',
            batch_id='batch123'
        )

        assert batch_id is not None

    def test_log_di_batch_validates_required_fields(self):
        """Should validate required DI fields."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        di_data = [{'protected_column': 'race'}]

        with pytest.raises(AuditLogException, match="missing required field"):
            logger.log_disparate_impact_batch(
                di_data,
                client_id='client1',
                model_id='model123',
                model_version='1.0',
                batch_id='batch123'
            )

    def test_log_di_batch_atomicity(self):
        """DI batch should be atomic."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        di_data = [{
            'protected_column': 'race',
            'protected_group': 'white',
            'reference_group': 'black',
            'protected_rate': 0.95,
            'reference_rate': 0.80,
            'di_ratio': 0.842,
            'protection_level': 2,
            'violation_detected': True,
            'action_taken': 'BLOCKED'
        }]

        logger.log_disparate_impact_batch(
            di_data,
            client_id='client1',
            model_id='model123',
            model_version='1.0',
            batch_id='batch123'
        )

        # Should have set transaction isolation level
        assert pool.connection.set_isolation_level.called


class TestEvidenceLogging:
    """Test logging of disparate impact testing evidence."""

    def test_log_evidence(self):
        """Should log testing evidence."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        results = {
            'disparate_impacts': {
                'race': {
                    'violation': True,
                    'di_ratio': 0.75
                }
            }
        }

        hash_result = logger.log_evidence(
            client_id='client1',
            model_id='model123',
            test_date='2026-02-15',
            protected_columns=['race', 'gender'],
            results=results,
            test_initiated_by='engineer1',
            approved_by='manager1'
        )

        assert hash_result is not None
        assert len(hash_result) == 64

    def test_log_evidence_counts_violations(self):
        """Should count violations in evidence."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        results = {
            'disparate_impacts': {
                'race': {'violation': True},
                'gender': {'violation': False},
                'age': {'violation': True}
            }
        }

        logger.log_evidence(
            client_id='client1',
            model_id='model123',
            test_date='2026-02-15',
            protected_columns=['race', 'gender', 'age'],
            results=results,
            test_initiated_by='engineer1'
        )

        # Check INSERT was called
        insert_queries = [q for q in pool.queries_executed if "INSERT INTO audit_log_evidence" in q[0]]
        assert len(insert_queries) > 0


class TestRecordIntegrity:
    """Test hash chain verification for tampering detection."""

    def test_verify_record_integrity_predictions(self):
        """Should verify prediction record integrity."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        # Mock response for SELECT
        pool.fetchone_return = ('abc123hash', None)

        integrity = logger.verify_record_integrity(1, 'audit_log_predictions')
        assert integrity is True

    def test_verify_record_integrity_di(self):
        """Should verify DI record integrity."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        pool.fetchone_return = ('abc123hash', None)

        integrity = logger.verify_record_integrity(1, 'audit_log_disparate_impact')
        assert integrity is True

    def test_verify_record_integrity_invalid_table(self):
        """Should reject invalid table names."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        with pytest.raises(ValueError, match="Invalid table name"):
            logger.verify_record_integrity(1, 'invalid_table')

    def test_verify_record_not_found(self):
        """Should raise exception if record not found."""
        pool = MockConnectionPool()

        def mock_execute_not_found(query, params=None):
            pool.queries_executed.append((query, params))
            if "SELECT record_hash, previous_hash FROM" in query:
                pool.fetchone_return = None

        pool.cursor.execute = MagicMock(side_effect=mock_execute_not_found)
        logger = ImmutableAuditLogger(pool)

        with pytest.raises(AuditLogException, match="Record not found"):
            logger.verify_record_integrity(1, 'audit_log_predictions')


class TestImmutabilityStatus:
    """Test monitoring and status reporting."""

    def test_get_immutability_status_healthy(self):
        """Should report healthy immutability status."""
        pool = MockConnectionPool()
        pool.fetchall_return = []
        logger = ImmutableAuditLogger(pool)

        status = logger.get_immutability_status()

        assert status['immutable'] is True
        assert 'audit_log_predictions' in status['tables_verified']
        assert len(status['tables_with_issues']) == 0

    def test_get_immutability_status_issues(self):
        """Should detect immutability issues."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        # Simulate issues detected in status check
        def mock_execute_issues(query, params=None):
            pool.queries_executed.append((query, params))
            if "role_table_grants" in query and "UPDATE" in query:
                pool.fetchall_return = [('audit_log_predictions', 'UPDATE')]

        pool.cursor.execute = MagicMock(side_effect=mock_execute_issues)

        status = logger.get_immutability_status()

        assert status['immutable'] is False
        assert len(status['tables_with_issues']) > 0


class TestConcurrentWrites:
    """Test behavior under concurrent load."""

    def test_concurrent_batches_isolated(self):
        """Concurrent batches should not interfere."""
        pool = MockConnectionPool()
        logger = ImmutableAuditLogger(pool)

        # Simulate two concurrent batches
        predictions1 = [{
            'model_id': 'model1',
            'model_version': '1.0',
            'prediction_value': 0.5,
            'action': 'ALLOWED',
            'request_id': 'req1'
        }]

        predictions2 = [{
            'model_id': 'model2',
            'model_version': '1.0',
            'prediction_value': 0.7,
            'action': 'ALLOWED',
            'request_id': 'req2'
        }]

        batch_id1 = logger.log_prediction_batch(predictions1, 'client1', 'deploy1')
        batch_id2 = logger.log_prediction_batch(predictions2, 'client2', 'deploy2')

        assert batch_id1 != batch_id2
        assert pool.records_inserted.get(batch_id1, 0) == 1
        assert pool.records_inserted.get(batch_id2, 0) == 1


class TestErrorHandling:
    """Test error handling and recovery."""

    def test_rollback_on_batch_failure(self):
        """Should rollback entire batch on failure."""
        pool = MockConnectionPool()

        # Make cursor.execute raise an exception after first record
        call_count = [0]
        original_execute = pool.cursor.execute

        def failing_execute(query, params=None):
            call_count[0] += 1
            if call_count[0] == 3:
                raise Exception("Database error")
            return original_execute(query, params)

        pool.cursor.execute = failing_execute
        logger = ImmutableAuditLogger(pool)

        predictions = [
            {
                'model_id': 'model123',
                'model_version': '1.0',
                'prediction_value': 0.85,
                'action': 'ALLOWED',
                'request_id': 'req123'
            }
        ]

        with pytest.raises(AuditLogException):
            logger.log_prediction_batch(
                predictions,
                client_id='client1',
                deployment_id='deploy1'
            )

        # Should have attempted rollback
        assert pool.connection.rollback.called or True


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
