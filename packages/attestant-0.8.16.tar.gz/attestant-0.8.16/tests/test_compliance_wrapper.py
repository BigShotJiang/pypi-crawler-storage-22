"""
Comprehensive unit tests for ComplianceWrapper and immutable audit logging.

Tests cover:
- Two-level protection enforcement (Level 1 blocks, Level 2 monitors)
- Disparate impact calculation
- Audit trail logging
- Protection level validation
- Error handling and edge cases
- Immutability verification
"""

import uuid
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from attestant.compliance.wrapper import (
    ComplianceDecision,
    ComplianceException,
    ComplianceWrapper,
)
from attestant.governance.immutable_audit_logger import (
    AuditLogException,
    ImmutableAuditLogger,
)


class TestComplianceWrapperInitialization:
    """Test ComplianceWrapper initialization and validation."""

    def test_init_valid_configuration(self):
        """Test initialization with valid configuration."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([0, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race", "gender"],
            protection_level={"race": 1, "gender": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        assert wrapper.model_id == "test_model"
        assert wrapper.model_version == "1.0.0"
        assert wrapper.protected_columns == ["race", "gender"]
        assert wrapper.protection_level == {"race": 1, "gender": 2}
        assert wrapper.di_threshold == 0.80

    def test_init_missing_protected_columns(self):
        """Test that empty protected_columns raises ValueError."""
        model = MagicMock()

        with pytest.raises(ValueError, match="protected_columns cannot be empty"):
            ComplianceWrapper(
                model=model,
                model_id="test_model",
                model_version="1.0.0",
                protected_columns=[],
                protection_level={},
                client_id="test_client",
                deployment_id="test_deploy",
            )

    def test_init_missing_protection_level(self):
        """Test that empty protection_level raises ValueError."""
        model = MagicMock()

        with pytest.raises(ValueError, match="protection_level cannot be empty"):
            ComplianceWrapper(
                model=model,
                model_id="test_model",
                model_version="1.0.0",
                protected_columns=["race"],
                protection_level={},
                client_id="test_client",
                deployment_id="test_deploy",
            )

    def test_init_missing_column_in_protection_level(self):
        """Test that column in protected_columns but not in protection_level raises error."""
        model = MagicMock()

        with pytest.raises(
            ValueError, match="in protected_columns but not in protection_level"
        ):
            ComplianceWrapper(
                model=model,
                model_id="test_model",
                model_version="1.0.0",
                protected_columns=["race", "gender"],
                protection_level={"race": 1},  # Missing gender
                client_id="test_client",
                deployment_id="test_deploy",
            )

    def test_init_invalid_protection_level_value(self):
        """Test that invalid protection level (not 1 or 2) raises error."""
        model = MagicMock()

        with pytest.raises(
            ValueError, match="Protection level for 'race' must be 1 or 2, got 3"
        ):
            ComplianceWrapper(
                model=model,
                model_id="test_model",
                model_version="1.0.0",
                protected_columns=["race"],
                protection_level={"race": 3},  # Invalid level
                client_id="test_client",
                deployment_id="test_deploy",
            )


class TestLevel1Protection:
    """Test Level 1 protection (complete block)."""

    def test_level1_blocks_immediately(self):
        """Test that Level 1 protected column always raises exception."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([0, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race"],
            protection_level={"race": 1},  # Level 1 = block
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3]})
        protected = pd.DataFrame({"race": ["White", "Black", "Asian"]})

        # Level 1 should always raise exception
        with pytest.raises(ComplianceException) as exc_info:
            wrapper.predict(X, protected)

        assert exc_info.value.protection_level == 1
        assert exc_info.value.protected_column == "race"
        assert "Level 1" in exc_info.value.message

    def test_level1_exception_details(self):
        """Test that Level 1 exception includes proper details."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="credit_model",
            model_version="2.0.0",
            protected_columns=["race"],
            protection_level={"race": 1},
            client_id="bank_xyz",
            deployment_id="prod",
        )

        X = pd.DataFrame({"income": [50000, 60000, 70000]})
        protected = pd.DataFrame({"race": ["A", "B", "C"]})

        try:
            wrapper.predict(X, protected)
            pytest.fail("Should have raised ComplianceException")
        except ComplianceException as e:
            assert e.protection_level == 1
            assert "cannot be used for any predictions" in e.message


class TestLevel2Protection:
    """Test Level 2 protection (monitor for disparate impact)."""

    def test_level2_allows_no_disparate_impact(self):
        """Test that Level 2 allows predictions when no DI is detected."""
        model = MagicMock()
        # All same predictions - no disparate impact
        model.predict = MagicMock(return_value=np.array([1, 1, 1, 1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["gender"],
            protection_level={"gender": 2},  # Level 2 = monitor
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3, 4, 5, 6]})
        protected = pd.DataFrame({"gender": ["M", "F", "M", "F", "M", "F"]})

        # Should not raise - no disparate impact
        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 6
        assert np.all(predictions == 1)

    def test_level2_blocks_with_disparate_impact(self):
        """Test that Level 2 blocks when disparate impact is detected."""
        model = MagicMock()
        # Males all approved, females all denied - clear disparate impact
        model.predict = MagicMock(
            return_value=np.array([1, 0, 1, 0, 1, 0, 1, 0])  # M:F approval pattern
        )

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["gender"],
            protection_level={"gender": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": range(8)})
        protected = pd.DataFrame(
            {"gender": ["M", "F", "M", "F", "M", "F", "M", "F"]}
        )

        # Should raise due to disparate impact
        with pytest.raises(ComplianceException) as exc_info:
            wrapper.predict(X, protected)

        assert exc_info.value.protection_level == 2
        assert "disparate impact" in exc_info.value.message.lower()

    def test_level2_no_protection_when_all_same_group(self):
        """Test Level 2 when data has only one protected group (no comparison)."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([0, 1, 0]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race"],
            protection_level={"race": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3]})
        protected = pd.DataFrame({"race": ["White", "White", "White"]})

        # Single group: no disparate impact possible, should allow
        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 3


class TestMultipleProtectedColumns:
    """Test with multiple protected columns."""

    def test_multiple_columns_all_pass(self):
        """Test multiple protected columns when all pass."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race", "gender"],
            protection_level={"race": 2, "gender": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3, 4]})
        protected = pd.DataFrame(
            {"race": ["W", "B", "W", "B"], "gender": ["M", "F", "M", "F"]}
        )

        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 4

    def test_multiple_columns_one_fails(self):
        """Test multiple columns where one has disparate impact."""
        model = MagicMock()
        # Gender: equal approval; Race: disparate impact
        model.predict = MagicMock(return_value=np.array([1, 1, 0, 0]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race", "gender"],
            protection_level={"race": 2, "gender": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3, 4]})
        protected = pd.DataFrame(
            {"race": ["W", "W", "B", "B"], "gender": ["M", "F", "M", "F"]}
        )

        with pytest.raises(ComplianceException):
            wrapper.predict(X, protected)

    def test_level1_takes_precedence(self):
        """Test that Level 1 is checked before Level 2."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race", "gender"],
            protection_level={"race": 1, "gender": 2},  # race is Level 1
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3, 4]})
        protected = pd.DataFrame(
            {"race": ["W", "B", "W", "B"], "gender": ["M", "F", "M", "F"]}
        )

        # Should fail on Level 1 (race), not even check Level 2 (gender)
        with pytest.raises(ComplianceException) as exc_info:
            wrapper.predict(X, protected)

        assert exc_info.value.protection_level == 1
        assert exc_info.value.protected_column == "race"


class TestInputValidation:
    """Test input validation."""

    def test_missing_protected_column(self):
        """Test that missing protected column raises ValueError."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race", "gender"],
            protection_level={"race": 2, "gender": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3]})
        protected = pd.DataFrame({"race": ["W", "B", "W"]})  # Missing gender

        with pytest.raises(ValueError, match="Protected attribute columns missing"):
            wrapper.predict(X, protected)

    def test_extra_protected_column(self):
        """Test that extra columns in protected_attributes is OK."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race"],
            protection_level={"race": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3]})
        protected = pd.DataFrame(
            {"race": ["W", "B", "W"], "gender": ["M", "F", "M"]}  # Extra column OK
        )

        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 3


class TestAuditLogging:
    """Test immutable audit logging."""

    def test_audit_logger_called_on_success(self):
        """Test that audit logger is called when predictions succeed."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1]))

        audit_logger = MagicMock(spec=ImmutableAuditLogger)

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["gender"],
            protection_level={"gender": 2},
            client_id="test_client",
            deployment_id="test_deploy",
            audit_logger=audit_logger,
        )

        X = pd.DataFrame({"feature": [1, 2, 3]})
        protected = pd.DataFrame({"gender": ["M", "F", "M"]})

        wrapper.predict(X, protected)

        # Audit logger should be called
        assert audit_logger.log_prediction_batch.called

    def test_audit_logger_called_on_violation(self):
        """Test that audit logger is called when violations occur."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 0, 1, 0]))

        audit_logger = MagicMock(spec=ImmutableAuditLogger)

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["gender"],
            protection_level={"gender": 2},
            client_id="test_client",
            deployment_id="test_deploy",
            audit_logger=audit_logger,
        )

        X = pd.DataFrame({"feature": [1, 2, 3, 4]})
        protected = pd.DataFrame({"gender": ["M", "F", "M", "F"]})

        with pytest.raises(ComplianceException):
            wrapper.predict(X, protected)

        # Audit logger should still be called even on violation
        assert audit_logger.log_prediction_batch.called


class TestComplianceDecision:
    """Test ComplianceDecision dataclass."""

    def test_decision_to_dict(self):
        """Test conversion of ComplianceDecision to dict."""
        decision = ComplianceDecision(
            batch_id="batch123",
            timestamp_utc=datetime(2024, 1, 1, tzinfo=timezone.utc),
            model_id="model1",
            model_version="1.0.0",
            client_id="client1",
            deployment_id="deploy1",
            allowed=True,
            action="ALLOWED",
        )

        decision_dict = decision.to_dict()

        assert decision_dict["batch_id"] == "batch123"
        assert decision_dict["allowed"] is True
        assert decision_dict["action"] == "ALLOWED"
        assert decision_dict["model_id"] == "model1"

    def test_decision_with_violations(self):
        """Test ComplianceDecision with violations."""
        decision = ComplianceDecision(
            batch_id="batch123",
            timestamp_utc=datetime(2024, 1, 1, tzinfo=timezone.utc),
            model_id="model1",
            model_version="1.0.0",
            client_id="client1",
            deployment_id="deploy1",
            allowed=False,
            action="BLOCKED_LEVEL1",
        )

        decision.violations.append(("race", 1, "Level 1 protected column"))

        assert len(decision.violations) == 1
        assert decision.violations[0][0] == "race"
        assert decision.violations[0][1] == 1


class TestExceptionDetails:
    """Test ComplianceException details."""

    def test_exception_attributes(self):
        """Test that ComplianceException stores all required attributes."""
        exc = ComplianceException(
            message="Test violation",
            protection_level=2,
            protected_column="race",
            di_results={"test": "data"},
            batch_id="batch123",
        )

        assert exc.protection_level == 2
        assert exc.protected_column == "race"
        assert exc.di_results == {"test": "data"}
        assert exc.batch_id == "batch123"

    def test_exception_string_representation(self):
        """Test string representation of ComplianceException."""
        exc = ComplianceException(
            message="Disparate impact detected",
            protection_level=2,
            protected_column="gender",
        )

        assert "Disparate impact detected" in str(exc)


class TestImmutableAuditLogger:
    """Test ImmutableAuditLogger functionality."""

    def test_logger_init(self):
        """Test ImmutableAuditLogger initialization."""
        logger = ImmutableAuditLogger(auto_verify=False)

        assert logger.auto_verify is False
        assert logger.retention_days == 3650  # 10 years default

    def test_logger_log_prediction_batch(self):
        """Test logging a prediction batch."""
        logger = ImmutableAuditLogger(auto_verify=False)

        batch_id = logger.log_prediction_batch(
            batch_id="batch123",
            timestamp_utc=datetime.now(timezone.utc),
            model_id="model1",
            model_version="1.0.0",
            client_id="client1",
            deployment_id="deploy1",
            request_id="req123",
            user_id="user1",
            action="ALLOWED",
            compliance_decision={},
        )

        assert batch_id == "batch123"

    def test_logger_log_disparate_impact_event(self):
        """Test logging a disparate impact event."""
        logger = ImmutableAuditLogger(auto_verify=False)

        # Should not raise
        logger.log_disparate_impact_event(
            batch_id="batch123",
            timestamp_utc=datetime.now(timezone.utc),
            model_id="model1",
            model_version="1.0.0",
            client_id="client1",
            protected_column="race",
            protected_group="Black",
            reference_group="White",
            protected_rate=0.5,
            reference_rate=0.8,
            di_ratio=0.625,
            protection_level=2,
            violation_detected=True,
            action_taken="LOGGED",
        )

    def test_logger_verify_immutability(self):
        """Test immutability verification."""
        logger = ImmutableAuditLogger(auto_verify=False)

        result = logger.verify_immutability()
        assert result is True

    def test_logger_generate_compliance_report(self):
        """Test compliance report generation."""
        logger = ImmutableAuditLogger(auto_verify=False)

        report = logger.generate_compliance_report(
            client_id="client1",
            start_date=datetime(2024, 1, 1, tzinfo=timezone.utc),
            end_date=datetime(2024, 1, 31, tzinfo=timezone.utc),
        )

        assert report["client_id"] == "client1"
        assert "compliance_summary" in report
        assert "disparate_impacts" in report


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_empty_dataframe(self):
        """Test prediction with empty DataFrame."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race"],
            protection_level={"race": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": []})
        protected = pd.DataFrame({"race": []})

        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 0

    def test_numpy_array_input(self):
        """Test that numpy arrays work as input."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race"],
            protection_level={"race": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = np.array([[1], [2], [3]])
        protected = pd.DataFrame({"race": ["W", "B", "W"]})

        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 3

    def test_custom_positive_label(self):
        """Test with custom positive label (not 1)."""
        model = MagicMock()
        # All same predictions - no disparate impact
        model.predict = MagicMock(return_value=np.array(["yes", "yes", "yes"]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race"],
            protection_level={"race": 2},
            client_id="test_client",
            deployment_id="test_deploy",
            positive_label="yes",
        )

        X = pd.DataFrame({"feature": [1, 2, 3]})
        protected = pd.DataFrame({"race": ["W", "B", "W"]})

        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 3

    def test_nan_in_protected_attributes(self):
        """Test handling of NaN values in protected attributes."""
        model = MagicMock()
        model.predict = MagicMock(return_value=np.array([1, 1, 1]))

        wrapper = ComplianceWrapper(
            model=model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race"],
            protection_level={"race": 2},
            client_id="test_client",
            deployment_id="test_deploy",
        )

        X = pd.DataFrame({"feature": [1, 2, 3]})
        protected = pd.DataFrame({"race": ["W", np.nan, "W"]})

        # Should handle NaN gracefully
        predictions = wrapper.predict(X, protected)
        assert len(predictions) == 3
