"""
Unit tests for Disparate Impact Calculator (4/5 rule).

Tests the DisparateImpactCalculator against the EEOC 4/5 rule threshold
per 29 CFR 1602.14(c) and SR 11-7 compliance requirements.

Test coverage:
    - Basic violation detection (DI < 0.80)
    - No-violation cases (DI >= 0.80)
    - Edge cases (0%, 100%, NaN)
    - Small sample sizes
    - Unknown/missing values
    - Multiple protected groups
    - Metadata pass-through
    - Performance with large datasets
    - Severity classification
"""

import math
import pytest

from attestant.compliance.disparate_impact import (
    DisparateImpactCalculator,
    ImpactSeverity,
)


class TestBasicViolations:
    """Test basic 4/5 rule violation detection."""

    def test_classic_violation_60_vs_100(self) -> None:
        """Test DI = 0.60 (clear violation)."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 60 + [False] * 40 + [True] * 100 + [False] * 0
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert not result.passed
        assert result.violation_count == 1
        assert result.findings[0].di_ratio == pytest.approx(0.6, abs=0.01)
        assert result.findings[0].severity == ImpactSeverity.SIGNIFICANT

    def test_marginal_violation_75_vs_100(self) -> None:
        """Test DI = 0.75 (violation, marginal)."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 75 + [False] * 25 + [True] * 100
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert not result.passed
        assert result.violation_count == 1
        assert result.findings[0].severity == ImpactSeverity.MARGINAL


class TestNoViolations:
    """Test cases that pass the 4/5 rule."""

    def test_no_violation_at_threshold(self) -> None:
        """Test DI = 0.80 (at threshold, passes)."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 80 + [False] * 20 + [True] * 100
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.passed
        assert result.violation_count == 0

    def test_perfect_parity(self) -> None:
        """Test DI = 1.0 (perfect parity)."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 50 + [False] * 50 + [True] * 50 + [False] * 50
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.passed
        assert result.findings[0].di_ratio == 1.0


class TestEdgeCases:
    """Test edge cases."""

    def test_zero_percent_approval(self) -> None:
        """Test when one group has 0% approval."""
        calc = DisparateImpactCalculator()
        decisions = [False] * 100 + [True] * 100
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.findings[0].di_ratio == 0.0
        assert result.findings[0].severity == ImpactSeverity.SEVERE

    def test_hundred_percent_approval(self) -> None:
        """Test when one group has 100% approval."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 100 + [False] * 100
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.findings[0].di_ratio == 0.0
        assert result.findings[0].severity == ImpactSeverity.SEVERE

    def test_both_zero_percent(self) -> None:
        """Test when both groups have 0% approval."""
        calc = DisparateImpactCalculator()
        decisions = [False] * 200
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.passed
        assert math.isnan(result.findings[0].di_ratio)

    def test_both_hundred_percent(self) -> None:
        """Test when both groups have 100% approval."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 200
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.passed
        assert math.isnan(result.findings[0].di_ratio)


class TestMissingValues:
    """Test handling of missing and unknown values."""

    def test_exclude_unknown_default(self) -> None:
        """Test that unknown/None values are excluded by default."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 50 + [False] * 50 + [True] * 100
        groups = ["Group_A"] * 50 + [None] * 50 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups, exclude_unknown=True)

        assert result.total_records == 150

    def test_include_unknown(self) -> None:
        """Test that unknown values can be included."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 50 + [False] * 50 + [True] * 100
        groups = ["Group_A"] * 50 + [None] * 50 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups, exclude_unknown=False)

        assert result.total_records == 200


class TestBinaryEncoding:
    """Test different decision encodings."""

    def test_boolean_encoding(self) -> None:
        """Test with True/False encoding."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 60 + [False] * 40 + [True] * 100
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.violation_count == 1

    def test_integer_encoding(self) -> None:
        """Test with 1/0 encoding."""
        calc = DisparateImpactCalculator()
        decisions = [1] * 60 + [0] * 40 + [1] * 100
        groups = ["Group_A"] * 100 + ["Group_B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.violation_count == 1


class TestGroupHandling:
    """Test handling of multiple groups."""

    def test_three_groups(self) -> None:
        """Test analysis with three groups."""
        calc = DisparateImpactCalculator()
        decisions = (
            [True] * 50 + [False] * 50 +
            [True] * 70 + [False] * 30 +
            [True] * 100
        )
        groups = ["A"] * 100 + ["B"] * 100 + ["C"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.violation_count == 2

    def test_specified_reference_group(self) -> None:
        """Test with explicit reference group."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 60 + [False] * 40 + [True] * 50 + [False] * 50
        groups = ["A"] * 100 + ["B"] * 100
        result = calc.calculate_di(decisions, groups, reference_group="B")

        assert result.findings[0].group2 == "B"


class TestMetadata:
    """Test metadata handling."""

    def test_metadata_preserved(self) -> None:
        """Test that metadata is preserved."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 50 + [False] * 50 + [True] * 100
        groups = ["A"] * 100 + ["B"] * 100
        metadata = {"model_id": "test", "tenant": "acme"}
        result = calc.calculate_di(decisions, groups, metadata=metadata)

        assert result.metadata == metadata


class TestDataValidation:
    """Test input validation."""

    def test_mismatched_lengths(self) -> None:
        """Test mismatched length raises error."""
        calc = DisparateImpactCalculator()
        with pytest.raises(ValueError, match="same length"):
            calc.calculate_di([True, False], ["A"])

    def test_empty_data(self) -> None:
        """Test empty data raises error."""
        calc = DisparateImpactCalculator()
        with pytest.raises(ValueError, match="empty"):
            calc.calculate_di([], [])

    def test_invalid_decisions(self) -> None:
        """Test invalid decision values raise error."""
        calc = DisparateImpactCalculator()
        with pytest.raises(TypeError, match="Expected bool"):
            calc.calculate_di([True, 2], ["A", "B"])


class TestSeverityClassification:
    """Test severity classification."""

    def test_no_impact(self) -> None:
        """Test NO_IMPACT for DI = 1.0."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 50 + [False] * 50 + [True] * 50 + [False] * 50
        groups = ["A"] * 100 + ["B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.findings[0].severity == ImpactSeverity.NO_IMPACT

    def test_marginal(self) -> None:
        """Test MARGINAL for DI = 0.75."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 75 + [False] * 25 + [True] * 100
        groups = ["A"] * 100 + ["B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.findings[0].severity == ImpactSeverity.MARGINAL

    def test_significant(self) -> None:
        """Test SIGNIFICANT for DI = 0.60."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 60 + [False] * 40 + [True] * 100
        groups = ["A"] * 100 + ["B"] * 100
        result = calc.calculate_di(decisions, groups)

        assert result.findings[0].severity == ImpactSeverity.SIGNIFICANT


class TestPerformance:
    """Test performance at scale."""

    def test_100k_records(self) -> None:
        """Test 100k records performance."""
        import time

        calc = DisparateImpactCalculator()
        decisions = [True] * 50000 + [False] * 50000
        groups = ["A"] * 50000 + ["B"] * 50000

        start = time.perf_counter()
        result = calc.calculate_di(decisions, groups)
        elapsed = time.perf_counter() - start

        assert elapsed < 0.1
        assert result.total_records == 100000


class TestSerialization:
    """Test result serialization."""

    def test_finding_to_dict(self) -> None:
        """Test finding serialization."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 60 + [False] * 40 + [True] * 100
        groups = ["A"] * 100 + ["B"] * 100
        result = calc.calculate_di(decisions, groups)

        d = result.findings[0].to_dict()
        assert d["group1"] == "A"
        assert d["is_violation"] is True

    def test_result_to_dict(self) -> None:
        """Test result serialization."""
        calc = DisparateImpactCalculator()
        decisions = [True] * 60 + [False] * 40 + [True] * 100
        groups = ["A"] * 100 + ["B"] * 100
        result = calc.calculate_di(decisions, groups)

        d = result.to_dict()
        assert d["passed"] is False
        assert d["violation_count"] == 1
        assert "timestamp" in d


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
