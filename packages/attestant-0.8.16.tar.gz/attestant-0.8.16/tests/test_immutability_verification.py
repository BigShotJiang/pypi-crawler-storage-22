"""
Tests for immutability verification and audit trail security.

Ensures that audit logs are write-once, append-only, and tamper-evident.
Critical for legal compliance and regulatory defense.

Coverage:
  - Database-level immutability (no UPDATE/DELETE permissions)
  - Application-level enforcement (no UPDATE in code)
  - Hash chain verification (detect tampering)
  - Transaction integrity (all-or-nothing writes)
  - Access logging (all reads/writes logged)
"""

import sys
from pathlib import Path
from datetime import datetime, timezone
from unittest.mock import Mock, patch, MagicMock
import hashlib
import json
import uuid

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


# ============================================================================
# Mock Database Connection
# ============================================================================

class MockDatabaseConnection:
    """Mock database connection for testing immutability."""

    def __init__(self):
        self.audit_log = []
        self.permissions = {}
        self.failed_updates = []

    def execute(self, sql, params=None):
        """Execute a query and track all operations."""
        if "UPDATE" in sql.upper() or "DELETE" in sql.upper():
            self.failed_updates.append((sql, params))
            raise RuntimeError(f"UPDATE/DELETE forbidden on audit tables: {sql}")

        if "INSERT INTO audit_log" in sql:
            self.audit_log.append({
                "sql": sql,
                "params": params,
                "timestamp": datetime.now(timezone.utc),
            })
            return {"affected_rows": 1}

        return {"rows": []}

    def get_table_permissions(self, table_name):
        """Get permissions for a table."""
        return self.permissions.get(table_name, [])

    def set_permissions(self, table_name, perms):
        """Set permissions for a table."""
        self.permissions[table_name] = perms


# ============================================================================
# Hash Chain Helpers
# ============================================================================

def sha256_hash(data):
    """Compute SHA-256 hash of data."""
    if isinstance(data, dict):
        data = json.dumps(data, sort_keys=True, default=str)
    if isinstance(data, str):
        data = data.encode('utf-8')
    return hashlib.sha256(data).hexdigest()


def create_audit_record(log_id, client_id, model_id, event_type, previous_hash=None):
    """Create an audit log record with hash chain."""
    record = {
        "log_id": log_id,
        "client_id": client_id,
        "model_id": model_id,
        "event_type": event_type,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "data": {"test": True},
    }

    record_hash = sha256_hash(record)

    if previous_hash:
        record["previous_hash"] = previous_hash
        chain_hash = sha256_hash(record)
        return record, chain_hash

    return record, record_hash


# ============================================================================
# Tests: Database-Level Immutability
# ============================================================================

class TestDatabaseImmutability:
    """Tests that database enforces write-once, append-only constraints."""

    def test_update_forbidden_on_audit_tables(self):
        """Verify UPDATE statements are rejected on audit tables."""
        conn = MockDatabaseConnection()

        # Try to update an audit record - should fail
        with pytest.raises(RuntimeError) as exc_info:
            conn.execute(
                "UPDATE audit_log_predictions SET action = %s WHERE id = %s",
                ("MODIFIED", 123)
            )

        assert "UPDATE/DELETE forbidden" in str(exc_info.value)
        assert len(conn.failed_updates) == 1

    def test_delete_forbidden_on_audit_tables(self):
        """Verify DELETE statements are rejected on audit tables."""
        conn = MockDatabaseConnection()

        with pytest.raises(RuntimeError):
            conn.execute(
                "DELETE FROM audit_log_predictions WHERE timestamp < %s",
                ("2025-01-01",)
            )

        assert len(conn.failed_updates) == 1

    def test_insert_allowed_on_audit_tables(self):
        """Verify INSERT statements are allowed."""
        conn = MockDatabaseConnection()

        result = conn.execute(
            "INSERT INTO audit_log_predictions (log_id, action) VALUES (%s, %s)",
            (123, "ALLOWED")
        )

        assert result["affected_rows"] == 1
        assert len(conn.audit_log) == 1
        assert conn.audit_log[0]["params"] == (123, "ALLOWED")

    def test_select_allowed_on_audit_tables(self):
        """Verify SELECT statements are allowed."""
        conn = MockDatabaseConnection()

        # Insert some data first
        conn.execute(
            "INSERT INTO audit_log_predictions (log_id, action) VALUES (%s, %s)",
            (123, "ALLOWED")
        )

        # SELECT should work
        result = conn.execute(
            "SELECT * FROM audit_log_predictions WHERE log_id = %s",
            (123,)
        )

        assert result is not None

    def test_permissions_table_check(self):
        """Test checking permissions on audit tables."""
        conn = MockDatabaseConnection()

        # Set up permissions for audit_log_disparate_impact
        conn.set_permissions("audit_log_disparate_impact", ["SELECT", "INSERT"])

        perms = conn.get_table_permissions("audit_log_disparate_impact")
        assert "SELECT" in perms
        assert "INSERT" in perms
        assert "UPDATE" not in perms
        assert "DELETE" not in perms

    def test_concurrent_inserts_atomic(self):
        """Verify concurrent INSERT operations are atomic."""
        conn = MockDatabaseConnection()

        # Simulate multiple concurrent inserts
        for i in range(10):
            conn.execute(
                "INSERT INTO audit_log_predictions VALUES (%s, %s, %s)",
                (i, f"client_{i}", "ALLOWED")
            )

        # All should succeed
        assert len(conn.audit_log) == 10

        # Order should be preserved
        for i in range(10):
            assert conn.audit_log[i]["params"][0] == i


# ============================================================================
# Tests: Application-Level Immutability
# ============================================================================

class TestApplicationImmutability:
    """Tests that application code enforces immutability constraints."""

    def test_audit_logger_forbids_update(self):
        """Verify audit logger code has no UPDATE statements."""
        # Read the actual audit logger source
        audit_logger_path = Path(__file__).parent.parent / "audit_logger.py"

        if audit_logger_path.exists():
            content = audit_logger_path.read_text()
            # Check for UPDATE statements (should be none)
            assert "UPDATE" not in content or "-- UPDATE" in content
            # Check for forbidden patterns
            assert ".update(" not in content or "dict.update" in content

    def test_immutable_record_cannot_be_modified(self):
        """Test that audit records cannot be modified once written."""
        record, record_hash = create_audit_record(
            log_id=1,
            client_id="client_1",
            model_id="model_1",
            event_type="DI_CHECK",
        )

        # Try to modify the record
        modified_record = record.copy()
        modified_record["action"] = "MODIFIED"

        # Hash should change
        new_hash = sha256_hash(modified_record)
        assert new_hash != record_hash

    def test_hash_chain_prevents_silent_modification(self):
        """Test that hash chain detects any modification in chain."""
        records = []

        # Create a chain of 5 records
        prev_hash = None
        for i in range(5):
            record, chain_hash = create_audit_record(
                log_id=i,
                client_id="client_1",
                model_id="model_1",
                event_type=f"EVENT_{i}",
                previous_hash=prev_hash,
            )
            records.append((record, chain_hash))
            prev_hash = chain_hash

        # Verify the chain
        for i, (record, chain_hash) in enumerate(records):
            recalc_hash = sha256_hash(record)
            # The chain hash should match (includes previous hash)
            if i == 0:
                assert sha256_hash(record) == chain_hash
            else:
                # Multi-record chain hash would be computed differently
                pass

        # Now corrupt the 2nd record
        corrupted_record = records[2][0].copy()
        corrupted_record["data"]["test"] = False

        # The hash no longer matches
        assert sha256_hash(corrupted_record) != records[2][1]

    def test_batch_transaction_all_or_nothing(self):
        """Test that batch operations are atomic (all or nothing)."""
        conn = MockDatabaseConnection()

        # Simulate a batch write
        records = [
            ("INSERT INTO audit_log_predictions VALUES (%s, %s, %s)", (1, "c1", "ALLOWED")),
            ("INSERT INTO audit_log_predictions VALUES (%s, %s, %s)", (2, "c1", "ALLOWED")),
            ("INSERT INTO audit_log_predictions VALUES (%s, %s, %s)", (3, "c1", "ALLOWED")),
        ]

        # All succeed
        for sql, params in records:
            conn.execute(sql, params)

        assert len(conn.audit_log) == 3

        # If one fails, all should be rolled back (in real DB)
        # Here we just verify the pattern
        try:
            conn.execute("UPDATE audit_log SET x = 1 WHERE y = 2")
        except RuntimeError:
            pass  # Transaction would rollback

        # The failed UPDATE didn't create a partial state
        assert len(conn.failed_updates) == 1


# ============================================================================
# Tests: Tamper Detection
# ============================================================================

class TestTamperDetection:
    """Tests that tampering with audit logs is detectable."""

    def test_record_hash_detects_single_field_change(self):
        """Test that changing any field changes the hash."""
        record = {
            "log_id": 1,
            "client_id": "client_1",
            "di_ratio": 0.75,
            "violation": True,
            "timestamp": "2026-02-15T10:00:00Z",
        }

        original_hash = sha256_hash(record)

        # Change each field and verify hash changes
        fields_to_test = ["log_id", "client_id", "di_ratio", "violation"]

        for field in fields_to_test:
            modified = record.copy()

            if field == "log_id":
                modified[field] = 999
            elif field == "client_id":
                modified[field] = "attacker"
            elif field == "di_ratio":
                modified[field] = 0.95  # Change violation from yes to no
            elif field == "violation":
                modified[field] = False

            modified_hash = sha256_hash(modified)
            assert modified_hash != original_hash, f"Hash didn't change for {field}"

    def test_timestamp_tampering_detected(self):
        """Test that changing timestamp is detected."""
        record = {
            "log_id": 1,
            "timestamp": datetime.now(timezone.utc),
            "action": "BLOCKED",
        }

        hash1 = sha256_hash(record)

        # Try to backdate the record
        record["timestamp"] = datetime(2025, 1, 1, tzinfo=timezone.utc)
        hash2 = sha256_hash(record)

        assert hash1 != hash2

    def test_action_tampering_detected(self):
        """Test that changing the action (BLOCKED→ALLOWED) is detected."""
        record = {
            "log_id": 1,
            "model_id": "m1",
            "action": "BLOCKED",
            "reason": "DI < 0.80",
        }

        original_hash = sha256_hash(record)

        # Attacker tries to change BLOCKED to ALLOWED
        record["action"] = "ALLOWED"

        new_hash = sha256_hash(record)
        assert new_hash != original_hash

    def test_batch_integrity_verification(self):
        """Test that batch integrity can be verified."""
        # Create a batch of 100 records
        batch_id = str(uuid.uuid4())
        batch_records = []

        for i in range(100):
            record = {
                "batch_id": batch_id,
                "record_id": i,
                "di_ratio": 0.75 + (i * 0.001),
                "violation": 0.75 + (i * 0.001) < 0.80,
            }
            batch_records.append((record, sha256_hash(record)))

        # Compute batch hash
        batch_data = {
            "batch_id": batch_id,
            "record_count": len(batch_records),
            "record_hashes": [h for _, h in batch_records],
        }
        batch_hash = sha256_hash(batch_data)

        # All records in batch should verify
        for record, record_hash in batch_records:
            assert sha256_hash(record) == record_hash

        # If one record is modified, batch hash changes
        corrupted_records = batch_records.copy()
        corrupted_records[50] = (
            {**corrupted_records[50][0], "violation": False},
            corrupted_records[50][1],  # Wrong hash
        )

        corrupted_data = {
            "batch_id": batch_id,
            "record_count": len(corrupted_records),
            "record_hashes": [h for _, h in corrupted_records],
        }
        corrupted_batch_hash = sha256_hash(corrupted_data)

        assert corrupted_batch_hash != batch_hash


# ============================================================================
# Tests: Access Control & Logging
# ============================================================================

class TestAccessControl:
    """Tests that all access to audit tables is logged."""

    def test_all_reads_logged(self):
        """Test that SELECT operations are logged."""
        conn = MockDatabaseConnection()

        # Insert a record
        conn.execute(
            "INSERT INTO audit_log_predictions VALUES (%s, %s, %s)",
            (1, "c1", "ALLOWED")
        )

        # Read operations should be tracked (in real system)
        # Verify we can query
        result = conn.execute(
            "SELECT * FROM audit_log_predictions WHERE log_id = %s",
            (1,)
        )

        assert result is not None

    def test_failed_operations_logged(self):
        """Test that failed operations are logged."""
        conn = MockDatabaseConnection()

        # Try an UPDATE - should fail
        with pytest.raises(RuntimeError):
            conn.execute("UPDATE audit_log SET x = 1 WHERE y = 2")

        # The failed operation should be recorded
        assert len(conn.failed_updates) == 1
        assert "UPDATE" in conn.failed_updates[0][0]

    def test_access_control_list_enforced(self):
        """Test that access control lists are respected."""
        conn = MockDatabaseConnection()

        # Set restrictive permissions
        conn.set_permissions("audit_log_predictions", ["SELECT", "INSERT"])

        perms = conn.get_table_permissions("audit_log_predictions")

        # Verify enforcement
        assert "UPDATE" not in perms
        assert "DELETE" not in perms
        assert "TRUNCATE" not in perms


# ============================================================================
# Tests: Rollback & Recovery
# ============================================================================

class TestTransactionIntegrity:
    """Tests that incomplete transactions don't leave partial state."""

    def test_rollback_on_constraint_violation(self):
        """Test that constraint violations trigger rollback."""
        conn = MockDatabaseConnection()

        # Insert valid records
        conn.execute(
            "INSERT INTO audit_log_predictions VALUES (%s, %s, %s)",
            (1, "c1", "ALLOWED")
        )

        initial_count = len(conn.audit_log)

        # Try to insert with constraint violation (e.g., duplicate ID)
        # In real system, this would trigger rollback
        # Here we just verify nothing additional was inserted
        try:
            conn.execute(
                "INSERT INTO audit_log_predictions VALUES (%s, %s, %s)",
                (1, "c1", "ALLOWED")  # Duplicate ID
            )
        except Exception:
            pass

        # No partial state
        assert len(conn.audit_log) >= initial_count

    def test_failed_insert_doesnt_corrupt_log(self):
        """Test that a failed INSERT doesn't leave corrupt data."""
        conn = MockDatabaseConnection()

        # Insert valid record
        conn.execute(
            "INSERT INTO audit_log_predictions (id, action) VALUES (%s, %s)",
            (1, "ALLOWED")
        )

        # Now try UPDATE (should fail)
        with pytest.raises(RuntimeError):
            conn.execute(
                "UPDATE audit_log_predictions SET action = %s WHERE id = %s",
                ("MODIFIED", 1)
            )

        # Verify original record is unchanged
        assert len(conn.audit_log) == 1
        assert conn.audit_log[0]["params"][1] == "ALLOWED"


# ============================================================================
# Integration Tests
# ============================================================================

class TestImmutabilityIntegration:
    """Integration tests for immutability across multiple operations."""

    def test_write_once_append_only_workflow(self):
        """Test complete write-once, append-only workflow."""
        conn = MockDatabaseConnection()

        # Simulate a compliance check producing audit records
        batch_id = str(uuid.uuid4())

        for i in range(10):
            conn.execute(
                "INSERT INTO audit_log_predictions "
                "(batch_id, log_id, action, di_ratio) "
                "VALUES (%s, %s, %s, %s)",
                (batch_id, i, "ALLOWED", 0.85)
            )

        # Verify all 10 records are present
        assert len(conn.audit_log) == 10

        # Cannot update any of them
        with pytest.raises(RuntimeError):
            conn.execute(
                "UPDATE audit_log_predictions SET action = %s WHERE batch_id = %s",
                ("BLOCKED", batch_id)
            )

        # Records are still unchanged
        assert len(conn.audit_log) == 10
        for record in conn.audit_log:
            assert record["params"][2] == "ALLOWED"  # Original action

    def test_hash_chain_verification(self):
        """Test hash chain verification for a batch of records."""
        records = []
        prev_hash = None

        # Create 20-record chain
        for i in range(20):
            record = {
                "log_id": i,
                "batch_id": "batch_001",
                "event": f"event_{i}",
                "previous_hash": prev_hash,
            }

            record_hash = sha256_hash(record)
            records.append((record, record_hash))
            prev_hash = record_hash

        # Verify entire chain
        for record, expected_hash in records:
            computed_hash = sha256_hash(record)
            assert computed_hash == expected_hash

        # Corrupt the middle record (index 10)
        corrupted = records[10][0].copy()
        corrupted["event"] = "tampered"

        # Hash doesn't match
        assert sha256_hash(corrupted) != records[10][1]

    def test_immutability_under_load(self):
        """Test immutability with 1000 records."""
        conn = MockDatabaseConnection()

        # Write 1000 records
        for i in range(1000):
            conn.execute(
                "INSERT INTO audit_log_predictions VALUES (%s, %s, %s)",
                (i, f"client_{i % 10}", "ALLOWED")
            )

        # Verify all present
        assert len(conn.audit_log) == 1000

        # Try to modify any of them
        with pytest.raises(RuntimeError):
            conn.execute("UPDATE audit_log_predictions SET x = y LIMIT 1")

        # Still all present and unchanged
        assert len(conn.audit_log) == 1000


# ============================================================================
# Run Tests
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
