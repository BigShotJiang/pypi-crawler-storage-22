"""
Production-grade tests for Attestant.

Tests real data flows, API key gating, config lifecycle, DAG resilience,
and fairness edge cases — areas that the existing test suite (1287 tests)
does not cover because it runs entirely in ATTESTANT_TESTING=1 / demo mode.
"""

import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import warnings

import numpy as np
import pandas as pd
import pytest

# ---------------------------------------------------------------------------
# 1. API Key Gating (subprocess-based to avoid module caching)
# ---------------------------------------------------------------------------

def _run_snippet(code, env_overrides=None):
    """Run a Python snippet in a fresh subprocess with a clean environment."""
    env = os.environ.copy()
    env.pop("ATTESTANT_TESTING", None)
    env.pop("HYDRA24_TESTING", None)
    env.pop("ATTESTANT_API_KEY", None)
    env.pop("ATTESTANT_SKIP_AUTH", None)
    env.pop("HYDRA24_SKIP_AUTH", None)
    if env_overrides:
        env.update(env_overrides)
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True, text=True, timeout=30, env=env,
    )
    return result


class TestAPIKeyGating:
    """Tests that the __getattr__ lazy-import gate in __init__.py works."""

    def test_import_proveit_always_works(self):
        r = _run_snippet("import attestant; print(attestant.__version__)")
        assert r.returncode == 0
        assert r.stdout.strip()

    def test_classes_blocked_without_configure(self):
        r = _run_snippet(
            "import attestant\n"
            "try:\n"
            "    attestant.DAGTracker\n"
            "    print('NO_ERROR')\n"
            "except RuntimeError as e:\n"
            "    print('BLOCKED')\n"
            "    assert 'configure' in str(e).lower()\n"
        )
        assert r.returncode == 0
        assert "BLOCKED" in r.stdout

    def test_simplified_api_blocked_without_configure(self):
        r = _run_snippet(
            "import attestant, pandas as pd\n"
            "try:\n"
            "    attestant.wrap(pd.DataFrame({'a': [1]}), 'test')\n"
            "    print('NO_ERROR')\n"
            "except RuntimeError as e:\n"
            "    print('BLOCKED')\n"
        )
        assert r.returncode == 0
        assert "BLOCKED" in r.stdout

    def test_classes_available_after_configure(self):
        r = _run_snippet(
            "import attestant\n"
            "attestant.configure(api_key='hyd_test_12345678')\n"
            "print(type(attestant.DAGTracker).__name__)\n",
            env_overrides={
                "ATTESTANT_TESTING": "1",
                "ATTESTANT_SKIP_AUTH": "1",
            },
        )
        assert r.returncode == 0
        assert "type" in r.stdout or "DAGTracker" in r.stdout or r.stdout.strip()

    def test_configure_env_var_fallback(self):
        r = _run_snippet(
            "import attestant\n"
            "attestant.configure()\n"
            "print('OK')\n",
            env_overrides={
                "ATTESTANT_API_KEY": "hyd_test_env_key_1234",
                "ATTESTANT_TESTING": "1",
                "ATTESTANT_SKIP_AUTH": "1",
            },
        )
        assert r.returncode == 0
        assert "OK" in r.stdout

    def test_configure_no_key_no_env_raises(self):
        r = _run_snippet(
            "import attestant\n"
            "try:\n"
            "    attestant.configure()\n"
            "    print('NO_ERROR')\n"
            "except ValueError as e:\n"
            "    print('VALUE_ERROR')\n"
            "    assert 'api key' in str(e).lower() or 'API key' in str(e)\n"
        )
        assert r.returncode == 0
        assert "VALUE_ERROR" in r.stdout

    def test_configure_then_reset_blocks_again(self):
        r = _run_snippet(
            "import attestant\n"
            "attestant.configure(api_key='hyd_test_12345678')\n"
            "print(type(attestant.get_tracker()))\n"
            "attestant.reset()\n"
            "try:\n"
            "    attestant.get_tracker()\n"
            "    print('NO_ERROR')\n"
            "except RuntimeError:\n"
            "    print('BLOCKED_AFTER_RESET')\n"
            "attestant.configure(api_key='hyd_test_12345678')\n"
            "print('RECONFIGURED')\n",
            env_overrides={
                "ATTESTANT_TESTING": "1",
                "ATTESTANT_SKIP_AUTH": "1",
            },
        )
        assert r.returncode == 0
        assert "BLOCKED_AFTER_RESET" in r.stdout
        assert "RECONFIGURED" in r.stdout

    def test_testing_env_var_bypasses_gate(self):
        r = _run_snippet(
            "import attestant\n"
            "tracker_cls = attestant.DAGTracker\n"
            "print(tracker_cls.__name__)\n",
            env_overrides={"ATTESTANT_TESTING": "1"},
        )
        assert r.returncode == 0
        assert "DAGTracker" in r.stdout


# ---------------------------------------------------------------------------
# 2. SQLiteDashboardStore Integration
# ---------------------------------------------------------------------------

class TestSQLiteDashboardStoreIntegration:
    """Tests full write/read cycles through SQLiteDashboardStore with real data."""

    @pytest.fixture(autouse=True)
    def store(self):
        from attestant.dashboard.sqlite_dashdb import SQLiteDashboardStore
        s = SQLiteDashboardStore(":memory:")
        s.connect()
        s.ensure_schema()
        yield s
        s.disconnect()

    def test_tenant_lifecycle(self, store):
        store.upsert_tenant("t1", "Acme Bank", "enterprise", {"region": "US"})
        t = store.get_tenant("t1")
        assert t is not None
        assert t["name"] == "Acme Bank"
        assert t["tier"] == "enterprise"
        assert t["config"]["region"] == "US"

        store.upsert_tenant("t1", "Acme Bank Updated", "professional")
        t = store.get_tenant("t1")
        assert t["name"] == "Acme Bank Updated"
        assert t["tier"] == "professional"

    def test_compliance_snapshot_insert_and_retrieve(self, store):
        store.upsert_tenant("t1", "Test Bank")
        store.insert_compliance_snapshot("t1", {
            "score": 85.5,
            "grade": "B",
            "engines_evaluated": 5,
            "critical_findings": 1,
            "warning_findings": 3,
            "total_findings": 7,
            "top_risks": ["Risk A", "Risk B"],
            "breakdowns": [
                {"regulation": "ECOA", "passed": False, "critical_count": 1},
            ],
            "bonuses_applied": {"FairLens": 3.0},
            "trend": "improving",
        })
        comp = store.get_latest_compliance("t1")
        assert comp is not None
        assert comp["score"] == 85.5
        assert comp["grade"] == "B"
        assert comp["critical_findings"] == 1
        assert comp["warning_findings"] == 3
        assert comp["total_findings"] == 7
        assert isinstance(comp["top_risks"], list)
        assert "Risk A" in comp["top_risks"]
        assert isinstance(comp["breakdowns"], list)
        assert comp["breakdowns"][0]["regulation"] == "ECOA"
        assert comp["trend"] == "improving"

    def test_model_snapshot_upsert_and_latest(self, store):
        store.upsert_tenant("t1", "Test Bank")
        # Insert 3 snapshots with distinct timestamps so MAX(snapshot_at) is unambiguous
        for i in range(3):
            ts = f"2026-01-0{i+1}T00:00:00Z"
            store._write(
                """INSERT INTO model_snapshots
                   (tenant_id, model_id, name, version, tier, status,
                    compliance_score, snapshot_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                ("t1", "credit_v1", "Credit Model", f"1.{i}",
                 3, "production", 80.0 + i, ts),
            )
        models = store.get_models("t1")
        assert len(models) == 1
        assert models[0]["version"] == "1.2"
        assert models[0]["compliance_score"] == 82.0

    def test_fairness_snapshot_with_protected_attrs(self, store):
        store.upsert_tenant("t1", "Test Bank")
        store.insert_fairness_snapshot("t1", {
            "model_id": "credit_v1",
            "has_disparate_impact": True,
            "worst_ratio": 0.78,
            "worst_group": "race:Black",
            "p_value": 0.003,
            "statistically_significant": True,
            "protected_attributes": ["race", "sex", "age"],
            "sample_size_warnings": ["age:18-25 (n=12)"],
            "details": {"method": "four_fifths"},
        })
        f = store.get_latest_fairness("t1", "credit_v1")
        assert f is not None
        assert f["has_disparate_impact"] is True
        assert f["worst_ratio"] == 0.78
        assert isinstance(f["protected_attributes"], list)
        assert "race" in f["protected_attributes"]
        assert isinstance(f["sample_size_warnings"], list)
        assert f["details"]["method"] == "four_fifths"

    def test_alert_lifecycle(self, store):
        store.upsert_tenant("t1", "Test Bank")
        alert_id = store.insert_alert("t1", {
            "severity": "critical",
            "source": "FairLens",
            "title": "DI detected",
            "description": "Ratio 0.78",
            "model_id": "credit_v1",
        })
        assert isinstance(alert_id, int)

        alerts = store.get_alerts("t1", unresolved_only=True)
        assert len(alerts) == 1
        assert alerts[0]["severity"] == "critical"

        store.resolve_alert(alert_id)
        alerts = store.get_alerts("t1", unresolved_only=True)
        assert len(alerts) == 0

        all_alerts = store.get_alerts("t1", unresolved_only=False)
        assert len(all_alerts) == 1
        assert all_alerts[0]["resolved"] is True

    def test_certification_upsert_idempotent(self, store):
        store.upsert_tenant("t1", "Test Bank")
        # Insert with distinct timestamps so the latest is unambiguous
        store._write(
            """INSERT INTO certification_snapshots
               (tenant_id, cert_type, status, snapshot_at)
               VALUES (?,?,?,?)""",
            ("t1", "SOC2", "in_progress", "2026-01-01T00:00:00Z"),
        )
        store._write(
            """INSERT INTO certification_snapshots
               (tenant_id, cert_type, status, issued_date, expiry_date, snapshot_at)
               VALUES (?,?,?,?,?,?)""",
            ("t1", "SOC2", "active", "2026-01-01", "2027-01-01",
             "2026-01-02T00:00:00Z"),
        )
        certs = store.get_certifications("t1")
        assert len(certs) == 1
        assert certs[0]["status"] == "active"

    def test_pipeline_stats_and_summary(self, store):
        store.upsert_tenant("t1", "Test Bank")
        for i in range(10):
            status = "completed" if i < 7 else "failed"
            store.insert_pipeline_stat("t1", {
                "pipeline_name": "credit_pipeline",
                "status": status,
                "node_count": 100 + i,
                "edge_count": 200 + i,
                "duration_ms": 1000 + i * 100,
            })
        summary = store.get_pipeline_summary()
        assert summary["total_runs"] == 10
        assert summary["completed"] == 7
        assert summary["failed"] == 3
        assert summary["success_rate"] == 70.0

    def test_multi_tenant_isolation(self, store):
        store.upsert_tenant("t1", "Bank A")
        store.upsert_tenant("t2", "Bank B")
        store.insert_compliance_snapshot("t1", {
            "score": 90.0, "grade": "A",
        })
        store.insert_compliance_snapshot("t2", {
            "score": 60.0, "grade": "C",
        })
        c1 = store.get_latest_compliance("t1")
        c2 = store.get_latest_compliance("t2")
        assert c1["score"] == 90.0
        assert c2["score"] == 60.0

        store.upsert_model_snapshot("t1", {
            "model_id": "m1", "name": "Model A",
        })
        store.upsert_model_snapshot("t2", {
            "model_id": "m2", "name": "Model B",
        })
        assert len(store.get_models("t1")) == 1
        assert len(store.get_models("t2")) == 1
        assert store.get_models("t1")[0]["model_id"] == "m1"

    def test_admin_system_health_aggregation(self, store):
        for tid, name, score in [
            ("t1", "Bank A", 90.0),
            ("t2", "Bank B", 80.0),
            ("t3", "Bank C", 70.0),
        ]:
            store.upsert_tenant(tid, name)
            store.insert_compliance_snapshot(tid, {
                "score": score, "grade": "B",
            })
            store.upsert_model_snapshot(tid, {
                "model_id": f"{tid}_m1", "name": f"Model {tid}",
            })
        health = store.admin_system_health()
        assert health["tenant_count"] == 3
        assert health["total_models"] == 3
        assert health["avg_compliance_score"] == 80.0

    def test_admin_tenant_summary(self, store):
        store.upsert_tenant("t1", "Bank A")
        store.upsert_tenant("t2", "Bank B")
        store.insert_compliance_snapshot("t1", {"score": 85.0, "grade": "B"})
        store.upsert_model_snapshot("t1", {"model_id": "m1", "name": "M1"})
        store.upsert_model_snapshot("t1", {"model_id": "m2", "name": "M2"})
        store.insert_alert("t1", {
            "severity": "warning", "source": "test", "title": "Alert 1",
        })

        summary = store.admin_tenant_summary()
        assert len(summary) == 2
        t1_row = next(r for r in summary if r["tenant_id"] == "t1")
        assert t1_row["latest_score"] == 85.0
        assert t1_row["model_count"] == 2
        assert t1_row["open_alerts"] == 1

    def test_empty_store_returns_safe_defaults(self, store):
        assert store.get_tenant("nonexistent") is None
        assert store.get_latest_compliance("nonexistent") is None
        assert store.get_models("nonexistent") == []
        assert store.get_alerts("nonexistent") == []
        assert store.get_certifications("nonexistent") == []
        health = store.admin_system_health()
        assert health["tenant_count"] == 0
        assert health["total_models"] == 0


# ---------------------------------------------------------------------------
# 3. Dashboard App With Store
# ---------------------------------------------------------------------------

class TestDashboardAppWithStore:
    """Tests Flask routes backed by a real SQLiteDashboardStore."""

    @pytest.fixture(autouse=True)
    def setup_client_app(self, monkeypatch):
        from attestant.dashboard.sqlite_dashdb import SQLiteDashboardStore
        self.store = SQLiteDashboardStore(":memory:")
        self.store.connect()
        self.store.ensure_schema()
        self._seed_data()

        import attestant.dashboard.client_app as client_mod
        monkeypatch.setattr(client_mod, "_store", self.store)
        monkeypatch.setattr(client_mod, "TENANT_ID", "test_tenant")
        client_mod.app.config["TESTING"] = True
        self.client = client_mod.app.test_client()
        yield
        self.store.disconnect()

    def _seed_data(self):
        self.store.upsert_tenant("test_tenant", "Test Bank", "professional")
        self.store.insert_compliance_snapshot("test_tenant", {
            "score": 82.5, "grade": "B",
            "engines_evaluated": 5,
            "critical_findings": 1, "warning_findings": 4,
            "total_findings": 8, "trend": "improving",
            "top_risks": ["Risk A"],
            "breakdowns": [{"regulation": "ECOA", "passed": False}],
        })
        for i in range(5):
            self.store.upsert_model_snapshot("test_tenant", {
                "model_id": f"model_{i}",
                "name": f"Model {i}",
                "version": "1.0",
                "status": "production",
            })
        self.store.insert_alert("test_tenant", {
            "severity": "critical", "source": "FairLens",
            "title": "DI detected", "model_id": "model_0",
        })
        self.store.insert_alert("test_tenant", {
            "severity": "warning", "source": "Registry",
            "title": "Validation overdue", "model_id": "model_1",
        })
        self.store.insert_alert("test_tenant", {
            "severity": "info", "source": "System",
            "title": "Score improved",
        })

    def test_client_compliance_with_real_store(self):
        resp = self.client.get("/api/compliance")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["score"] == 82.5
        assert data["grade"] == "B"

    def test_client_models_with_real_store(self):
        resp = self.client.get("/api/models")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 5

    def test_client_alerts_with_real_store(self):
        resp = self.client.get("/api/alerts")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) >= 3
        severities = [a["severity"] for a in data]
        assert "critical" in severities

    def test_client_empty_store_graceful(self):
        from attestant.dashboard.sqlite_dashdb import SQLiteDashboardStore
        import attestant.dashboard.client_app as client_mod
        empty = SQLiteDashboardStore(":memory:")
        empty.connect()
        empty.ensure_schema()
        empty.upsert_tenant("test_tenant", "Test Bank")
        client_mod._store = empty
        try:
            resp = self.client.get("/api/compliance")
            assert resp.status_code == 200

            resp = self.client.get("/api/models")
            assert resp.status_code == 200
            data = resp.get_json()
            assert data == [] or isinstance(data, list)
        finally:
            client_mod._store = self.store
            empty.disconnect()


class TestAdminDashboardWithStore:
    """Tests admin Flask routes backed by a real SQLiteDashboardStore."""

    @pytest.fixture(autouse=True)
    def setup_admin_app(self, monkeypatch):
        from attestant.dashboard.sqlite_dashdb import SQLiteDashboardStore
        self.store = SQLiteDashboardStore(":memory:")
        self.store.connect()
        self.store.ensure_schema()
        self._seed_data()

        import attestant.dashboard.admin_app as admin_mod
        monkeypatch.setattr(admin_mod, "_store", self.store)
        monkeypatch.setattr(admin_mod, "ADMIN_TOKEN", "test-secret")
        admin_mod.app.config["TESTING"] = True
        self.admin_mod = admin_mod
        self.client = admin_mod.app.test_client()
        yield
        self.store.disconnect()

    def _seed_data(self):
        for tid, name in [("t1", "Bank A"), ("t2", "Bank B")]:
            self.store.upsert_tenant(tid, name)
            self.store.insert_compliance_snapshot(tid, {
                "score": 85.0, "grade": "B",
            })
            self.store.upsert_model_snapshot(tid, {
                "model_id": f"{tid}_m", "name": f"Model {tid}",
            })

    def test_admin_tenants_with_real_store(self):
        resp = self.client.get(
            "/api/tenants",
            headers={"Authorization": "Bearer test-secret"},
        )
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 2

    def test_admin_system_health_with_real_store(self):
        resp = self.client.get(
            "/api/system-health",
            headers={"Authorization": "Bearer test-secret"},
        )
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["tenant_count"] == 2
        assert data["total_models"] == 2

    def test_admin_auth_empty_token_rejected(self):
        resp = self.client.get(
            "/api/tenants",
            headers={
                "Authorization": "Bearer wrong-token",
                "Accept": "application/json",
            },
        )
        assert resp.status_code == 401

    def test_admin_auth_rate_limiting(self):
        self.admin_mod._AUTH_FAILURES.clear()
        for _ in range(6):
            self.client.get(
                "/api/tenants",
                headers={
                    "Authorization": "Bearer wrong-token",
                    "Accept": "application/json",
                },
            )
        resp = self.client.get(
            "/api/tenants",
            headers={
                "Authorization": "Bearer wrong-token",
                "Accept": "application/json",
            },
        )
        assert resp.status_code == 429


# ---------------------------------------------------------------------------
# 4. Config Lifecycle
# ---------------------------------------------------------------------------

class TestConfigLifecycle:
    """Tests configuration edge cases."""

    @pytest.fixture(autouse=True)
    def reset_config(self, monkeypatch):
        monkeypatch.setenv("ATTESTANT_SKIP_AUTH", "1")
        from attestant.config import reset
        yield
        reset()

    def test_configure_twice_without_reset(self):
        from proveit import config as cfg
        cfg.configure(api_key="hyd_test_key1")
        cfg.configure(api_key="hyd_test_key2")
        assert cfg._config.api_key == "hyd_test_key2"
        assert cfg._config._initialized is True

    def test_get_tracker_before_configure_raises(self):
        from attestant.config import reset, get_tracker
        reset()
        with pytest.raises(RuntimeError, match="not configured"):
            get_tracker()

    def test_reset_clears_initialized_flag(self):
        from proveit import config as cfg
        cfg.configure(api_key="hyd_test_key1")
        assert cfg._config._initialized is True
        cfg.reset()
        assert cfg._config._initialized is False

    def test_wrap_calls_get_tracker(self):
        from attestant.config import reset, wrap
        reset()
        with pytest.raises(RuntimeError):
            wrap(pd.DataFrame({"a": [1]}), "test.csv")

    def test_flush_without_configure_raises(self):
        from attestant.config import reset, flush
        reset()
        with pytest.raises(RuntimeError):
            flush()


# ---------------------------------------------------------------------------
# 5. DAGTracker Resilience
# ---------------------------------------------------------------------------

class TestDAGTrackerResilience:
    """Tests failure modes and stress scenarios for DAGTracker."""

    def test_persistence_failure_continues_in_memory(self):
        from attestant.hydra24_dag import DAGTracker
        tracker = DAGTracker(
            api_key="hyd_test_fake",
            service_url="http://localhost:99999",
        )
        nid = tracker.create_source_node("table", "col", provenance=42)
        assert nid is not None
        node = tracker.get_node(nid)
        assert node is not None
        assert node.table == "table"
        assert node.column == "col"

    def test_large_dag_creation(self):
        from attestant.hydra24_dag import DAGTracker
        tracker = DAGTracker()
        node_ids = []
        for i in range(10_000):
            nid = tracker.create_source_node(
                f"table_{i % 100}", f"col_{i}", provenance=i
            )
            node_ids.append(nid)
        stats = tracker.dag_stats()
        assert stats["total_nodes"] >= 10_000
        assert len(set(node_ids)) == 10_000

    def test_concurrent_node_creation(self):
        from attestant.hydra24_dag import DAGTracker
        tracker = DAGTracker()
        results = [[] for _ in range(4)]
        errors = []

        def create_nodes(thread_idx):
            try:
                for i in range(500):
                    nid = tracker.create_source_node(
                        f"t{thread_idx}",
                        f"c{i}",
                        provenance=thread_idx * 10000 + i,
                    )
                    results[thread_idx].append(nid)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=create_nodes, args=(i,))
            for i in range(4)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        assert not errors, f"Thread errors: {errors}"
        all_ids = []
        for r in results:
            all_ids.extend(r)
        assert len(all_ids) == 2000
        assert len(set(all_ids)) == 2000

    def test_flush_without_persistence(self):
        from attestant.hydra24_dag import DAGTracker
        tracker = DAGTracker()
        tracker.create_source_node("t", "c", provenance=1)
        result = tracker.flush(timeout=5.0)
        assert result is True


# ---------------------------------------------------------------------------
# 6. Fairness Edge Cases
# ---------------------------------------------------------------------------

class TestFairnessEdgeCases:
    """Tests production edge cases in the DisparateImpactAnalyzer."""

    @pytest.fixture
    def analyzer(self):
        from attestant.fairness.disparate_impact import DisparateImpactAnalyzer
        return DisparateImpactAnalyzer()

    def test_single_group(self, analyzer):
        n = 100
        predictions = np.array([1] * 80 + [0] * 20)
        protected = pd.DataFrame({"race": ["white"] * n})
        results = analyzer.analyze(predictions, protected, ["race"])
        assert len(results) == 1
        r = results[0]
        assert r.has_disparate_impact is False
        assert r.worst_ratio == 1.0

    def test_all_approved(self, analyzer):
        n = 200
        predictions = np.ones(n, dtype=int)
        protected = pd.DataFrame({
            "race": ["white"] * 100 + ["black"] * 100,
        })
        results = analyzer.analyze(predictions, protected, ["race"])
        r = results[0]
        assert r.reference_rate == 1.0
        assert r.has_disparate_impact is False

    def test_all_denied(self, analyzer):
        n = 200
        predictions = np.zeros(n, dtype=int)
        protected = pd.DataFrame({
            "race": ["white"] * 100 + ["black"] * 100,
        })
        results = analyzer.analyze(predictions, protected, ["race"])
        r = results[0]
        assert r.has_disparate_impact is False

    def test_tiny_group_warning(self, analyzer):
        predictions = np.array([1] * 100 + [1, 0])
        protected = pd.DataFrame({
            "race": ["white"] * 100 + ["other"] * 2,
        })
        results = analyzer.analyze(predictions, protected, ["race"])
        r = results[0]
        assert len(r.sample_size_warnings) > 0
        assert any("n=2" in w for w in r.sample_size_warnings)

    def test_nan_in_protected_column(self, analyzer):
        n = 100
        predictions = np.array([1] * 60 + [0] * 40)
        race_values = (
            ["white"] * 40 + ["black"] * 40 + [np.nan] * 20
        )
        protected = pd.DataFrame({"race": race_values})
        results = analyzer.analyze(predictions, protected, ["race"])
        r = results[0]
        total_in_groups = sum(m.total_count for m in r.group_metrics)
        assert total_in_groups == 80

    def test_missing_outcome_column(self, analyzer):
        predictions = np.array([1, 0, 1])
        protected = pd.DataFrame({"race": ["white", "black", "white"]})
        results = analyzer.analyze(predictions, protected, ["nonexistent"])
        assert len(results) == 0
