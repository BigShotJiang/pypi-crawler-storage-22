"""
Comprehensive SR 11-7 (OCC 2011-12) Model Risk Management Compliance Tests.

Tests every requirement from SR 11-7 and OCC 2011-12 guidance to ensure
complete regulatory compliance for litigation defense.

Coverage:
  - § 3: Development & Implementation (data quality, assumptions)
  - § 4: Model Validation (independent validation, backtesting)
  - § 4.2: Ongoing Monitoring (performance thresholds, frequency)
  - § 5: Governance & Controls (committee, board approval, policies)
  - Additional: Vendor models, challenger models, model tiering

All tests produce evidence for regulatory examiners.
"""

import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
from unittest.mock import Mock, patch
import json

import pytest
import pandas as pd
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from attestant.hydra24_dag import (
    ComputationDAG,
    DAGTracker,
    wrap_dataframe_dag,
    get_dag_for_series,
)
from attestant.compliance.sr117 import SR117Engine
from attestant.compliance.base import ComplianceFinding, Severity


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def sr117_engine():
    """Create an SR 11-7 engine."""
    return SR117Engine()


def _build_clean_dag():
    """Build a simple DAG with no protected data."""
    tracker = DAGTracker()
    df = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "credit_score": [720, 680, 750],
        "annual_income": [85000, 65000, 120000],
    })
    wrapped = wrap_dataframe_dag(df, tracker, "credit_bureau")
    score = wrapped["annual_income"] / wrapped["credit_score"]
    dag = get_dag_for_series(score, row_index=0)
    return tracker, dag


def _build_multioutput_dag():
    """Build a DAG with multiple data sources."""
    tracker = DAGTracker()

    df1 = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "credit_score": [720, 680, 750],
    })

    df2 = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "annual_income": [85000, 65000, 120000],
    })

    wrapped1 = wrap_dataframe_dag(df1, tracker, "credit_bureau")
    wrapped2 = wrap_dataframe_dag(df2, tracker, "income_verification")

    score = (wrapped1["credit_score"] + wrapped2["annual_income"]) / 100000
    dag = get_dag_for_series(score, row_index=0)
    return tracker, dag


# ============================================================================
# § 3: Development & Implementation Tests
# ============================================================================

class TestSR117Section3Development:
    """Tests for SR 11-7 § 3: Development & Implementation."""

    def test_model_id_required(self, sr117_engine):
        """SR 11-7 § 4.1: Model inventory requires unique model_id."""
        _, dag = _build_clean_dag()

        # No model_id
        result = sr117_engine.check(dag, metadata={})

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("model_id" in f.description.lower() for f in critical)

    def test_model_id_present_no_critical(self, sr117_engine):
        """Providing model_id removes CRITICAL finding."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL
                   and "model_id" in f.description.lower()]
        assert len(critical) == 0

    def test_model_version_required(self, sr117_engine):
        """SR 11-7 § 4.1: Version tracking required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("version" in f.description.lower() for f in warnings)

    def test_model_hash_recommended(self, sr117_engine):
        """SR 11-7 § 4.1: Model hash provides tamper-evident proof."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_version": "2.1.0",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("hash" in f.description.lower() for f in warnings)

    def test_model_owner_required(self, sr117_engine):
        """SR 11-7 § 5: Clear accountability requires named owner."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("owner" in f.description.lower() for f in warnings)

    def test_model_purpose_required(self, sr117_engine):
        """SR 11-7 § 3: Documented intended use required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        findings = [f for f in result.findings if "purpose" in f.description.lower()]
        assert len(findings) > 0

    def test_model_assumptions_documentation(self, sr117_engine):
        """SR 11-7 § 3: Key assumptions must be documented."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("assumption" in f.description.lower() for f in warnings)

    def test_model_limitations_documentation(self, sr117_engine):
        """SR 11-7 § 3: Known limitations must be disclosed."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("limitation" in f.description.lower() for f in warnings)

    def test_data_governance_source_documentation(self, sr117_engine):
        """SR 11-7 § 3.2: Training data must be documented."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("training data" in f.description.lower() for f in warnings)

    def test_data_quality_assessment_required(self, sr117_engine):
        """SR 11-7 § 3.2: Data quality and relevance required."""
        _, dag = _build_multioutput_dag()

        # Multi-source DAG
        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "training_data_description": "Loan data from 2023-2024",
        })

        # Should not have critical findings about data sources
        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert not any("source" in f.description.lower() for f in critical)


# ============================================================================
# § 4: Model Validation Tests
# ============================================================================

class TestSR117Section4Validation:
    """Tests for SR 11-7 § 4: Model Validation."""

    def test_validation_date_required(self, sr117_engine):
        """SR 11-7 § 4: Independent validation date is CRITICAL."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("validation date" in f.description.lower() for f in critical)

    def test_validator_independence_required(self, sr117_engine):
        """SR 11-7 § 4: Validator must be independent from developer."""
        _, dag = _build_clean_dag()

        # Developer = Validator (not independent)
        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_validation_date": "2026-01-15",
            "model_validator": "Alice",
            "model_developer": "alice",  # Same person, case-insensitive
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("independent" in f.description.lower() for f in critical)

    def test_validator_independence_satisfied(self, sr117_engine):
        """When validator differs from developer, no critical finding."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_validation_date": "2026-01-15",
            "model_validator": "Alice (Risk Management)",
            "model_developer": "Bob (Engineering)",
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL
                   and "independent" in f.description.lower()]
        assert len(critical) == 0

    def test_backtesting_results_required(self, sr117_engine):
        """SR 11-7 § 4: Backtesting with actual outcomes required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_validation_date": "2026-01-15",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("backtest" in f.description.lower() for f in warnings)

    def test_backtesting_present_no_warning(self, sr117_engine):
        """With backtesting results, no backtesting warning."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_validation_date": "2026-01-15",
            "backtesting_results": {
                "auc": 0.85,
                "ks_statistic": 0.42,
                "brier_score": 0.15,
            },
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING
                   and "backtest" in f.description.lower()]
        assert len(warnings) == 0

    def test_conceptual_soundness_required(self, sr117_engine):
        """SR 11-7 § 4.1: Model design must be sound for intended use."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_validation_date": "2026-01-15",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("conceptual" in f.description.lower() for f in warnings)

    def test_outcomes_analysis_required(self, sr117_engine):
        """SR 11-7 § 4: Outcomes analysis (backtesting) required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_validation_date": "2026-01-15",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("outcome" in f.description.lower() for f in warnings)

    def test_stress_testing_recommended(self, sr117_engine):
        """SR 11-7 § 4: Stress testing recommended (INFO level)."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_validation_date": "2026-01-15",
        })

        info = [f for f in result.findings if f.severity == Severity.INFO]
        assert any("stress" in f.description.lower() for f in info)


# ============================================================================
# § 4.2: Ongoing Monitoring Tests
# ============================================================================

class TestSR117Section42Monitoring:
    """Tests for SR 11-7 § 4.2: Ongoing Monitoring."""

    def test_monitoring_plan_required(self, sr117_engine):
        """SR 11-7 § 4.2: Ongoing monitoring plan is CRITICAL."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("monitoring plan" in f.description.lower() for f in critical)

    def test_monitoring_frequency_required(self, sr117_engine):
        """SR 11-7 § 4.2: Monitoring frequency must be specified."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "monitoring_plan": "Track AUC, KS, DI daily",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("frequency" in f.description.lower() for f in warnings)

    def test_performance_thresholds_required(self, sr117_engine):
        """SR 11-7 § 4.2: Degradation thresholds trigger re-validation."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "monitoring_plan": "Track AUC, KS, DI daily",
            "monitoring_frequency": "daily",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("threshold" in f.description.lower() for f in warnings)

    def test_complete_monitoring_plan(self, sr117_engine):
        """Complete monitoring plan passes all checks."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "monitoring_plan": "AUC >= 0.80, KS >= 0.40, DI >= 0.80",
            "monitoring_frequency": "daily",
            "performance_thresholds": {
                "auc_min": 0.80,
                "ks_min": 0.40,
                "di_min": 0.80,
                "escalation_trigger": "Any threshold exceeded",
            },
        })

        critical_monitoring = [f for f in result.findings
                              if f.severity == Severity.CRITICAL
                              and "monitoring" in f.description.lower()]
        assert len(critical_monitoring) == 0


# ============================================================================
# § 5: Governance & Controls Tests
# ============================================================================

class TestSR117Section5Governance:
    """Tests for SR 11-7 § 5: Governance, Policies, and Controls."""

    def test_model_risk_tiering_required(self, sr117_engine):
        """SR 11-7 § 5: Models must be classified by risk tier."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("tier" in f.description.lower() for f in warnings)

    def test_valid_risk_tiers(self, sr117_engine):
        """Valid tiers: critical, high, medium, low."""
        _, dag = _build_clean_dag()

        for tier in ["critical", "high", "medium", "low"]:
            result = sr117_engine.check(dag, metadata={
                "model_id": "LOAN_SCORING_v2",
                "model_risk_tier": tier,
            })

            tier_warnings = [f for f in result.findings
                           if f.severity == Severity.WARNING
                           and "tier" in f.description.lower()
                           and "invalid" in f.description.lower()]
            assert len(tier_warnings) == 0

    def test_invalid_risk_tier(self, sr117_engine):
        """Invalid tier triggers warning."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_risk_tier": "ultra-critical",  # Invalid
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("invalid" in f.description.lower() for f in warnings)

    def test_monitoring_frequency_aligns_with_tier(self, sr117_engine):
        """Monitoring frequency must match risk tier."""
        _, dag = _build_clean_dag()

        # Critical tier requires at least monthly monitoring
        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_risk_tier": "critical",
            "monitoring_frequency": "annual",  # Too infrequent
            "monitoring_plan": "Monitor quarterly",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("frequency" in f.description.lower() for f in warnings)

    def test_board_approval_for_critical_models(self, sr117_engine):
        """SR 11-7 § 5: Board approval required for critical/high models."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_risk_tier": "critical",
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("board" in f.description.lower() for f in critical)

    def test_board_approval_satisfied(self, sr117_engine):
        """With board approval, no critical finding."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
            "model_risk_tier": "critical",
            "board_approval_date": "2026-01-15",
        })

        critical = [f for f in result.findings
                   if f.severity == Severity.CRITICAL
                   and "board" in f.description.lower()]
        assert len(critical) == 0

    def test_mrm_committee_required(self, sr117_engine):
        """SR 11-7 § 5: Model Risk Management Committee required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("committee" in f.description.lower() for f in warnings)

    def test_board_reporting_frequency_required(self, sr117_engine):
        """SR 11-7 § 5: Board must receive model risk reports."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("reporting" in f.description.lower() for f in warnings)

    def test_escalation_procedures_required(self, sr117_engine):
        """SR 11-7 § 5: Clear escalation paths required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("escalation" in f.description.lower() for f in warnings)

    def test_model_policies_documentation_required(self, sr117_engine):
        """SR 11-7 § 5: Written MRM policies required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "LOAN_SCORING_v2",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("policies" in f.description.lower() for f in warnings)


# ============================================================================
# Vendor Model Tests
# ============================================================================

class TestVendorModels:
    """Tests for vendor model risk management."""

    def test_vendor_model_must_be_validated(self, sr117_engine):
        """Vendor models require independent bank validation."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "VENDOR_SCORE_v1",
            "is_vendor_model": True,
            "vendor_name": "Experian",
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("validation" in f.description.lower() for f in critical)

    def test_vendor_model_validation_evidence_required(self, sr117_engine):
        """Evidence of vendor model validation required."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "VENDOR_SCORE_v1",
            "is_vendor_model": True,
            "vendor_name": "Experian",
            "vendor_model_validation_evidence": {
                "validation_date": "2026-01-15",
                "validator": "Alice",
                "backtesting_auc": 0.85,
            },
        })

        critical = [f for f in result.findings if f.severity == Severity.CRITICAL
                   and "validation" in f.description.lower()]
        assert len(critical) == 0

    def test_vendor_model_contract_terms_required(self, sr117_engine):
        """Contract requirements for vendor models."""
        _, dag = _build_clean_dag()

        result = sr117_engine.check(dag, metadata={
            "model_id": "VENDOR_SCORE_v1",
            "is_vendor_model": True,
            "vendor_name": "Experian",
            "vendor_model_validation_evidence": "...",
        })

        warnings = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("contract" in f.description.lower() for f in warnings)


# ============================================================================
# Integration Tests
# ============================================================================

class TestSR117Integration:
    """Integration tests for complete SR 11-7 compliance."""

    def test_fully_compliant_model_passes(self, sr117_engine):
        """Fully documented model with all requirements passes."""
        _, dag = _build_clean_dag()

        complete_metadata = {
            # Model Inventory (§4.1)
            "model_id": "LOAN_SCORING_v2",
            "model_version": "2.1.0",
            "model_hash": "sha256_abc123...",
            "model_owner": "Alice (Credit Risk)",
            "model_purpose": "Consumer loan credit scoring",

            # Validation (§4)
            "model_validation_date": "2026-01-15",
            "model_validator": "Bob (Independent Validator)",
            "backtesting_results": {
                "auc": 0.85,
                "ks_statistic": 0.42,
                "brier_score": 0.15,
            },
            "validation_conceptual_soundness": True,
            "validation_outcomes_analysis": True,
            "stress_testing": True,

            # Monitoring (§4.2)
            "monitoring_plan": "Daily AUC, KS, DI monitoring",
            "monitoring_frequency": "daily",
            "performance_thresholds": {
                "auc_min": 0.80,
                "ks_min": 0.40,
                "di_min": 0.80,
            },

            # Data Governance (§3.2)
            "training_data_description": "2023-2024 loan origination data",
            "training_data_hash": "sha256_xyz789...",

            # Governance (§5)
            "model_risk_tier": "high",
            "mrm_committee_name": "Model Risk Committee",
            "board_reporting_frequency": "quarterly",
            "board_approval_date": "2026-01-10",
            "model_policies_documentation": "MRM Policy v3.0",
            "escalation_procedures": "Documented in MRM Policy",
            "change_log": "v2.0 → v2.1.0: Feature engineering",
            "approved_by": "CRO",

            # Assumptions & Limitations
            "model_assumptions": "Normal distribution, feature stability",
            "model_limitations": "Out-of-sample performance uncertain",
            "compensating_controls": "Manual review of top 5% scores",
        }

        result = sr117_engine.check(dag, metadata=complete_metadata)

        # Should pass with no critical findings
        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert len(critical) == 0

        # May have some INFO or recommendations, but fundamentally compliant
        assert result.passed

    def test_minimal_compliant_model(self, sr117_engine):
        """Minimal model meeting all critical requirements."""
        _, dag = _build_clean_dag()

        minimal_metadata = {
            # Critical requirements only
            "model_id": "LOAN_SCORING_v1",
            "model_validation_date": "2026-01-15",
            "monitoring_plan": "Monitor performance monthly",
        }

        result = sr117_engine.check(dag, metadata=minimal_metadata)

        # Should have no CRITICAL findings (warnings/info ok)
        critical = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert len(critical) == 0


# ============================================================================
# Evidence Generation
# ============================================================================

def test_generate_sr117_evidence_package(sr117_engine, tmp_path):
    """Generate evidence package for regulatory examination."""

    # Simulate 15 models with various compliance states
    models = []

    for i in range(15):
        _, dag = _build_clean_dag()

        metadata = {
            "model_id": f"MODEL_{i:03d}",
            "model_version": f"1.{i}.0",
            "model_owner": f"Owner_{i}",
            "model_purpose": "Credit scoring",
        }

        # Add varying levels of compliance
        if i < 5:  # Fully compliant
            metadata.update({
                "model_validation_date": "2026-01-15",
                "monitoring_plan": "Daily monitoring",
                "monitoring_frequency": "daily",
                "model_risk_tier": "high",
                "board_approval_date": "2026-01-10",
                "mrm_committee_name": "MRM Committee",
            })
        elif i < 10:  # Partially compliant
            metadata.update({
                "model_validation_date": "2026-01-15",
                "monitoring_plan": "Daily monitoring",
            })

        result = sr117_engine.check(dag, metadata=metadata)
        models.append({
            "model": f"MODEL_{i:03d}",
            "passed": result.passed,
            "critical": result.critical_count,
            "warnings": result.warning_count,
            "findings": len(result.findings),
        })

    # Verify we can generate summary
    passed = sum(1 for m in models if m["passed"])
    assert passed >= 5  # At least 5 models fully compliant


# ============================================================================
# Run Tests
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
