"""
Tests for the unified public API.

Verifies that:
1. All key classes and functions are accessible from the top-level attestant module
2. The new API provides a simple, intuitive interface for compliance monitoring
3. Deprecation warnings work for old imports
4. Constants are correctly defined
"""

import sys
import os
import unittest
from unittest.mock import Mock, patch, MagicMock


class TestUnifiedPublicAPI(unittest.TestCase):
    """Test that the unified public API exports all required symbols."""

    def test_import_compliance_wrapper_from_top_level(self):
        """ComplianceWrapper should be importable from top-level attestant."""
        import attestant

        # Verify ComplianceWrapper is accessible
        self.assertTrue(hasattr(attestant, 'ComplianceWrapper'))
        self.assertIsNotNone(attestant.ComplianceWrapper)

    def test_import_compliance_exception_from_top_level(self):
        """ComplianceException should be importable from top-level attestant."""
        import attestant

        # Verify ComplianceException is accessible
        self.assertTrue(hasattr(attestant, 'ComplianceException'))
        self.assertIsNotNone(attestant.ComplianceException)

        # Verify it's a valid exception class
        self.assertTrue(hasattr(attestant.ComplianceException, '__init__'))

    def test_import_compliance_decision_from_top_level(self):
        """ComplianceDecision should be importable from top-level attestant."""
        import attestant

        # Verify ComplianceDecision is accessible
        self.assertTrue(hasattr(attestant, 'ComplianceDecision'))
        self.assertIsNotNone(attestant.ComplianceDecision)

    def test_import_disparate_impact_analyzer_from_top_level(self):
        """DisparateImpactAnalyzer should be importable from top-level attestant."""
        import attestant

        # Verify DisparateImpactAnalyzer is accessible
        self.assertTrue(hasattr(attestant, 'DisparateImpactAnalyzer'))
        self.assertIsNotNone(attestant.DisparateImpactAnalyzer)

    def test_import_protection_level_constants_from_top_level(self):
        """Protection level constants should be accessible from top-level attestant."""
        import attestant

        # Verify constants are accessible
        self.assertTrue(hasattr(attestant, 'PROTECTION_LEVEL_1'))
        self.assertTrue(hasattr(attestant, 'PROTECTION_LEVEL_2'))

        # Verify correct values
        self.assertEqual(attestant.PROTECTION_LEVEL_1, 1)
        self.assertEqual(attestant.PROTECTION_LEVEL_2, 2)

    def test_get_audit_logger_function_exists(self):
        """get_audit_logger() function should be accessible from top-level attestant."""
        import attestant

        # Verify function is accessible
        self.assertTrue(hasattr(attestant, 'get_audit_logger'))
        self.assertTrue(callable(attestant.get_audit_logger))

    def test_get_audit_logger_connection_function_exists(self):
        """get_audit_logger_connection() function should be accessible."""
        import attestant

        # Verify function is accessible
        self.assertTrue(hasattr(attestant, 'get_audit_logger_connection'))
        self.assertTrue(callable(attestant.get_audit_logger_connection))

    def test_config_class_from_top_level(self):
        """Config class should be accessible from top-level attestant."""
        import attestant

        # Verify Config is accessible
        self.assertTrue(hasattr(attestant, 'Config'))
        self.assertIsNotNone(attestant.Config)

    def test_get_audit_logger_returns_logger_instance(self):
        """get_audit_logger() should return a logger instance."""
        import attestant
        import os

        # Use mock mode for testing (no database)
        os.environ['ATTESTANT_AUDIT_MODE'] = 'mock'

        # Get logger
        logger = attestant.get_audit_logger()

        # Verify we got back a logger with expected methods
        self.assertTrue(hasattr(logger, 'log_prediction_batch'))
        self.assertTrue(hasattr(logger, 'log_disparate_impact_batch'))

    def test_all_compliance_symbols_in_all(self):
        """All compliance symbols should be in __all__."""
        import attestant

        expected_symbols = [
            'ComplianceWrapper',
            'ComplianceException',
            'ComplianceDecision',
            'DisparateImpactAnalyzer',
            'get_audit_logger',
            'get_audit_logger_connection',
            'Config',
            'PROTECTION_LEVEL_1',
            'PROTECTION_LEVEL_2',
        ]

        for symbol in expected_symbols:
            self.assertIn(symbol, attestant.__all__,
                         f"{symbol} should be in attestant.__all__")

    def test_backward_compatibility_old_imports_still_work(self):
        """Old import paths should still work for backward compatibility."""
        # These imports should work even though new unified API is preferred
        from attestant.compliance.wrapper import ComplianceWrapper as OldWrapper
        from attestant.governance.immutable_audit_logger import ImmutableAuditLogger as OldLogger
        from attestant.fairness.disparate_impact import DisparateImpactAnalyzer as OldAnalyzer

        # And new imports should give same classes
        import attestant

        self.assertIs(OldWrapper, attestant.ComplianceWrapper)
        self.assertIs(OldAnalyzer, attestant.DisparateImpactAnalyzer)

    def test_unified_api_example_usage(self):
        """Test the intended usage pattern works."""
        import attestant

        # This is what users should do
        mock_model = MagicMock()
        mock_model.predict = MagicMock(return_value=[1, 0, 1])

        # Create wrapper using unified API
        wrapper = attestant.ComplianceWrapper(
            model=mock_model,
            model_id="test_model",
            model_version="1.0.0",
            protected_columns=["race", "gender"],
            protection_level={"race": 1, "gender": 2},
            client_id="test_company",
            deployment_id="test_deployment",
        )

        # Verify wrapper was created
        self.assertIsNotNone(wrapper)
        self.assertEqual(wrapper.model_id, "test_model")

    def test_protection_level_constants_have_correct_values(self):
        """Protection level constants should have the documented values."""
        import attestant

        # PROTECTION_LEVEL_1 = Block model entirely
        # PROTECTION_LEVEL_2 = Monitor for disparate impact
        self.assertEqual(attestant.PROTECTION_LEVEL_1, 1)
        self.assertEqual(attestant.PROTECTION_LEVEL_2, 2)


class TestAuditLoggerConfiguration(unittest.TestCase):
    """Test audit logger configuration from environment variables."""

    @patch('psycopg2.connect')
    def test_get_audit_logger_connection_reads_env_vars(self, mock_connect):
        """get_audit_logger_connection() should read from environment variables."""
        import attestant
        import os

        # Set environment variables
        os.environ['ATTESTANT_AUDIT_DB_HOST'] = 'localhost'
        os.environ['ATTESTANT_AUDIT_DB_PORT'] = '5432'
        os.environ['ATTESTANT_AUDIT_DB_USER'] = 'postgres'
        os.environ['ATTESTANT_AUDIT_DB_PASSWORD'] = 'password123'
        os.environ['ATTESTANT_AUDIT_DB_NAME'] = 'attestant_audit'

        mock_conn = MagicMock()
        mock_connect.return_value = mock_conn

        try:
            # Call get_audit_logger_connection
            conn = attestant.get_audit_logger_connection()

            # Verify it attempted to connect
            self.assertTrue(mock_connect.called)
        finally:
            # Clean up
            for var in ['ATTESTANT_AUDIT_DB_HOST', 'ATTESTANT_AUDIT_DB_PORT',
                       'ATTESTANT_AUDIT_DB_USER', 'ATTESTANT_AUDIT_DB_PASSWORD',
                       'ATTESTANT_AUDIT_DB_NAME']:
                os.environ.pop(var, None)

    @patch('psycopg2.connect')
    def test_get_audit_logger_uses_defaults_when_env_vars_missing(self, mock_connect):
        """get_audit_logger_connection() should use sensible defaults."""
        import attestant
        import os

        # Clear environment variables
        env_vars = [
            'ATTESTANT_AUDIT_DB_HOST',
            'ATTESTANT_AUDIT_DB_PORT',
            'ATTESTANT_AUDIT_DB_USER',
            'ATTESTANT_AUDIT_DB_PASSWORD',
            'ATTESTANT_AUDIT_DB_NAME',
        ]

        for var in env_vars:
            os.environ.pop(var, None)

        mock_conn = MagicMock()
        mock_connect.return_value = mock_conn

        try:
            # Call get_audit_logger_connection
            conn = attestant.get_audit_logger_connection()

            # Verify connection was called with defaults
            self.assertTrue(mock_connect.called)
        finally:
            # Clean up
            for var in env_vars:
                os.environ.pop(var, None)


class TestExportsInInit(unittest.TestCase):
    """Test that all required exports are present in __init__.py."""

    def test_compliance_exports_present(self):
        """Verify all compliance-related exports are in module."""
        import attestant

        compliance_exports = [
            'ComplianceWrapper',
            'ComplianceException',
            'ComplianceDecision',
            'DisparateImpactAnalyzer',
        ]

        for export in compliance_exports:
            self.assertTrue(
                hasattr(attestant, export),
                f"attestant.{export} not found"
            )

    def test_audit_logger_exports_present(self):
        """Verify all audit logger exports are in module."""
        import attestant

        audit_exports = [
            'get_audit_logger',
            'get_audit_logger_connection',
        ]

        for export in audit_exports:
            self.assertTrue(
                hasattr(attestant, export),
                f"attestant.{export} not found"
            )

    def test_configuration_exports_present(self):
        """Verify all configuration exports are in module."""
        import attestant

        config_exports = [
            'Config',
            'PROTECTION_LEVEL_1',
            'PROTECTION_LEVEL_2',
        ]

        for export in config_exports:
            self.assertTrue(
                hasattr(attestant, export),
                f"attestant.{export} not found"
            )


if __name__ == '__main__':
    unittest.main()
