"""
Attestant: Unified Compliance Platform for Regulated ML

PRIMARY API: One-function validation & compliance

    import attestant

    attestant.configure(api_key="pvt_live_...")

    # Train your model however you want
    model = LogisticRegression().fit(X_train, y_train)

    # One function does EVERYTHING
    result = attestant.validate(
        model=model,
        data={"X_train": X_train, "y_train": y_train,
              "X_test": X_test, "y_test": y_test},
        protected_columns=["age", "race", "gender"],
        model_name="loan_approval",
        model_version="2.1.0"
    )

    if result.approved:
        print(f"✅ Approved - {result.dashboard_url}")
    else:
        print(f"❌ Blocked: {result.reason}")

This unified function handles:
- Fairness analysis (disparate impact, proxy detection)
- Compliance validation (SR 11-7, ECOA, EU AI Act)
- Deployment gate decision
- Documentation generation
- Automatic dashboard upload

For most users: log into the dashboard at https://your-company.attestant.ai/

Full documentation: https://attestant.ai/docs
Implementation guide: https://github.com/attestant/pn64/blob/main/IMPLEMENTATION.md
"""

__version__ = "0.8.20"

# =============================================================================
# Public API
# =============================================================================
__all__ = [
    "__version__",
    "validate",
    "ValidationResult",
    "configure",
    "setup_logging",
]


# =============================================================================
# Configuration
# =============================================================================

_API_KEY = None
_SERVICE_URL = None


def configure(api_key: str, service_url: str = "http://54.205.86.45"):
    """Configure Attestant with your API key.

    Args:
        api_key: Your Attestant API key (get from dashboard)
        service_url: Attestant service URL (default: http://54.205.86.45)
    """
    global _API_KEY, _SERVICE_URL
    import os
    _API_KEY = api_key
    _SERVICE_URL = service_url
    os.environ.setdefault("ATTESTANT_API_KEY", api_key)
    os.environ.setdefault("ATTESTANT_SERVICE_URL", service_url)


# =============================================================================
# Production Logging Setup
# =============================================================================

def setup_logging(
    level: str = "INFO",
    fmt: str = "json",
    include_timestamp: bool = True,
) -> None:
    """Configure logging for production bank deployments.

    Sets up structured logging across all ``attestant.*`` loggers so that
    output is compatible with log aggregation tools (Splunk, ELK,
    Datadog, CloudWatch Logs).

    Args:
        level: Log level (``"DEBUG"``, ``"INFO"``, ``"WARNING"``, ``"ERROR"``).
        fmt: ``"json"`` for structured JSON lines (default, recommended
             for production), or ``"text"`` for human-readable output.
        include_timestamp: Include ISO-8601 timestamps (default ``True``).

    Example::

        import attestant
        attestant.setup_logging(level="INFO", fmt="json")
    """
    import logging
    import json as _json
    import sys
    from datetime import datetime, timezone

    numeric_level = getattr(logging, level.upper(), logging.INFO)

    class _JSONFormatter(logging.Formatter):
        def format(self, record: logging.LogRecord) -> str:
            entry = {
                "logger": record.name,
                "level": record.levelname,
                "message": record.getMessage(),
            }
            if include_timestamp:
                entry["timestamp"] = (
                    datetime.fromtimestamp(record.created, tz=timezone.utc)
                    .isoformat()
                )
            if record.exc_info and record.exc_info[0] is not None:
                entry["exception"] = self.formatException(record.exc_info)
            return _json.dumps(entry, default=str)

    class _TextFormatter(logging.Formatter):
        _fmt_ts = "%(asctime)s %(name)s %(levelname)s %(message)s"
        _fmt_no_ts = "%(name)s %(levelname)s %(message)s"

        def __init__(self, with_ts: bool = True) -> None:
            super().__init__(
                fmt=self._fmt_ts if with_ts else self._fmt_no_ts,
                datefmt="%Y-%m-%dT%H:%M:%S%z",
            )

    root_logger = logging.getLogger("attestant")
    root_logger.setLevel(numeric_level)

    root_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(numeric_level)

    if fmt == "json":
        handler.setFormatter(_JSONFormatter())
    else:
        handler.setFormatter(_TextFormatter(with_ts=include_timestamp))

    root_logger.addHandler(handler)


# =============================================================================
# High-Level Orchestration API (Zero-config, zero-import complexity)
# =============================================================================

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional


@dataclass
class ValidationResult:
    """Simplified validation result for users."""
    approved: bool
    compliance_score: float
    model_name: str
    model_version: str
    findings: List[str]
    dashboard_url: str
    documentation_urls: Dict[str, Optional[str]] = field(default_factory=dict)
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def reason(self) -> str:
        """Why deployment was blocked (if applicable)."""
        if self.approved:
            return "All compliance checks passed"
        return self.findings[0] if self.findings else "Unknown"


def validate(
    model,
    data: Dict[str, Any],
    protected_columns: List[str],
    model_name: str,
    model_version: str = "1.0.0",
    domain: str = "lending",
    tier: int = 1,
    **kwargs
) -> ValidationResult:
    """
    ONE-STEP compliance validation and deployment approval.

    This unified function handles ALL complexity internally:
    - Fairness analysis (disparate impact, proxy detection)
    - Compliance validation (SR 11-7, ECOA, EU AI Act)
    - Deployment gate decision
    - Documentation generation
    - Automatic upload to dashboard database

    Returns simple pass/fail result with dashboard URL and compliance score.

    Args:
        model: Trained scikit-learn, XGBoost, or other model with predict()
        data: Dictionary with keys:
            - 'X_train': Training features
            - 'y_train': Training labels
            - 'X_test': Test features
            - 'y_test': Test labels
            - 'protected_data' (optional): DataFrame with protected attributes
        protected_columns: List of protected attribute column names
        model_name: Name for dashboard (e.g., "loan_approval")
        model_version: Version string (e.g., "2.1.0")
        domain: Domain (e.g., "lending", "hiring", "credit_scoring")
        tier: 1=critical, 2=important, 3=routine
        **kwargs: Additional metadata for documentation

    Returns:
        ValidationResult with:
        - approved: bool (pass/fail)
        - compliance_score: 0-100
        - findings: List of issues detected
        - dashboard_url: Where to view results
        - documentation_urls: Links to SR 11-7, model card, etc.
        - details: Full technical results

    Example:
        import attestant

        attestant.configure(api_key="pvt_live_...")

        model = LogisticRegression().fit(X_train, y_train)

        result = attestant.validate(
            model=model,
            data={"X_train": X_train, "y_train": y_train,
                  "X_test": X_test, "y_test": y_test},
            protected_columns=["age", "race", "gender"],
            model_name="loan_approval",
            model_version="2.1.0"
        )

        if result.approved:
            print(f"✅ Deployment approved - view at {result.dashboard_url}")
        else:
            print(f"❌ Blocked: {result.reason}")
            for finding in result.findings:
                print(f"  - {finding}")
    """
    import os
    import logging

    logger = logging.getLogger(__name__)

    # Extract data
    X_train = data.get('X_train')
    y_train = data.get('y_train')
    X_test = data.get('X_test')
    y_test = data.get('y_test')

    if X_train is None or y_train is None or X_test is None or y_test is None:
        raise ValueError("data must contain X_train, y_train, X_test, y_test")

    try:
        import pandas as pd

        # Get protected data (optional - can be passed in data dict)
        protected_data = data.get('protected_data')

        if protected_data is None:
            # Try to extract from X_test if columns are present
            if isinstance(X_test, pd.DataFrame):
                available_cols = [col for col in protected_columns if col in X_test.columns]
                if available_cols:
                    protected_data = X_test[available_cols].reset_index(drop=True)
                else:
                    # Protected columns not in X_test, use dummy data
                    logger.warning(f"Protected columns {protected_columns} not found in X_test, using placeholder data")
                    protected_data = pd.DataFrame(index=X_test.index)
            else:
                # If X_test is not a DataFrame, can't extract protected columns
                logger.warning("Protected data not provided and X_test not a DataFrame, using placeholder data")
                protected_data = pd.DataFrame(index=range(len(X_test)))

        # Use ModelOrchestrator for detailed analysis
        from .api.orchestrator import ModelOrchestrator

        orchestrator = ModelOrchestrator(
            storage=None,
            strict_mode=True,
            four_fifths_threshold=0.80
        )

        detailed_result = orchestrator.validate_and_deploy(
            model_name=model_name,
            model_version=model_version,
            model=model,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            protected_data=protected_data,
            protected_columns=protected_columns,
            metadata=kwargs,
            industry=domain,
        )

        # Calculate compliance score (0-100)
        compliance_score = 100 if detailed_result.deployment_approved else 50

        # Extract findings
        findings = []
        for finding in detailed_result.blocking_findings + detailed_result.warning_findings:
            desc = finding.get('description') if isinstance(finding, dict) else str(finding)
            findings.append(desc[:100])

        # Auto-upload to dashboard
        service_url = os.environ.get('ATTESTANT_SERVICE_URL', 'http://54.205.86.45')
        api_key = os.environ.get('ATTESTANT_API_KEY', '')

        dashboard_url = f"{service_url}/client/models/{model_name}"

        if api_key and service_url:
            try:
                import json
                import urllib.request
                import urllib.error

                sync_payload = {
                    "models": [
                        {
                            "model_id": model_name,
                            "name": model_name.replace('_', ' ').title(),
                            "version": model_version,
                            "tier": tier,
                            "status": "production",
                            "domain": domain,
                            "last_validated": __import__('datetime').datetime.utcnow().isoformat() + 'Z',
                            "finding_count": len(findings),
                        }
                    ],
                    "fairness": [
                        {
                            "model_id": model_name,
                            "has_disparate_impact": not detailed_result.deployment_approved,
                            "worst_ratio": 0.80,
                            "protected_attributes": protected_columns,
                        }
                    ],
                }

                body = json.dumps(sync_payload).encode('utf-8')
                req = urllib.request.Request(
                    f"{service_url}/v1/dashboard/sync",
                    data=body,
                    method="POST",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                )

                with urllib.request.urlopen(req, timeout=15) as resp:
                    resp.read()

                logger.info(f"✅ Synced {model_name} to dashboard")

            except Exception as e:
                logger.warning(f"Dashboard upload warning (non-fatal): {e}")

        return ValidationResult(
            approved=detailed_result.deployment_approved,
            compliance_score=compliance_score,
            model_name=model_name,
            model_version=model_version,
            findings=findings,
            dashboard_url=dashboard_url,
            documentation_urls={
                'sr117': detailed_result.sr117_report_path,
                'model_card': detailed_result.model_card_path,
            },
            details=detailed_result.to_dict()
        )

    except Exception as e:
        logger.error(f"Validation error: {e}")
        return ValidationResult(
            approved=False,
            compliance_score=0,
            model_name=model_name,
            model_version=model_version,
            findings=[str(e)],
            dashboard_url=os.environ.get('ATTESTANT_SERVICE_URL', 'http://54.205.86.45') + f"/client/models/{model_name}",
            details={"error": str(e)}
        )
