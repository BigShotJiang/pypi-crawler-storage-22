"""
Attestant: Unified Compliance Platform for Regulated ML

PRIMARY API: One-function validation & compliance

    import attestant

    attestant.configure(api_key="pvt_live_...")

    # Train your model however you want (scikit-learn, XGBoost, PyTorch, TensorFlow, etc.)
    model = LogisticRegression().fit(X_train, y_train)

    # One function does EVERYTHING (server-side)
    result = attestant.validate(
        model=model,
        data={"X_train": X_train, "y_train": y_train,
              "X_test": X_test, "y_test": y_test},
        protected_columns=["age", "race", "gender"],
        model_name="loan_approval",
        model_version="2.1.0"
    )

    if result.approved:
        print(f"✅ Approved - {result.dashboard_url}")
    else:
        print(f"❌ Blocked: {result.reason}")

This unified function:
- Works with ALL Python models (scikit-learn, XGBoost, LightGBM, PyTorch, TensorFlow, Keras, custom)
- Works with ALL data types (NumPy, Pandas, lists, sparse matrices, GPU tensors, Polars)
- Uploads model + data to your AWS infrastructure
- Server runs all analysis (fairness, compliance, proxy detection, LDA)
- Returns deployment decision
- Zero local storage - everything on your AWS

For most users: log into the dashboard at https://your-company.attestant.ai/

Full documentation: https://attestant.ai/docs
Implementation guide: https://github.com/attestant/pn64/blob/main/IMPLEMENTATION.md
"""

__version__ = "0.8.22"

# =============================================================================
# Public API
# =============================================================================
__all__ = [
    "__version__",
    "validate",
    "ValidationResult",
    "configure",
    "setup_logging",
]


# =============================================================================
# Configuration
# =============================================================================

_API_KEY = None
_SERVICE_URL = None


def configure(api_key: str, service_url: str = "http://54.205.86.45"):
    """Configure Attestant with your API key.

    Args:
        api_key: Your Attestant API key (get from dashboard)
        service_url: Attestant service URL (default: http://54.205.86.45)
    """
    global _API_KEY, _SERVICE_URL
    import os
    _API_KEY = api_key
    _SERVICE_URL = service_url
    os.environ.setdefault("ATTESTANT_API_KEY", api_key)
    os.environ.setdefault("ATTESTANT_SERVICE_URL", service_url)


# =============================================================================
# Production Logging Setup
# =============================================================================

def setup_logging(
    level: str = "INFO",
    fmt: str = "json",
    include_timestamp: bool = True,
) -> None:
    """Configure logging for production bank deployments.

    Sets up structured logging across all ``attestant.*`` loggers so that
    output is compatible with log aggregation tools (Splunk, ELK,
    Datadog, CloudWatch Logs).

    Args:
        level: Log level (``"DEBUG"``, ``"INFO"``, ``"WARNING"``, ``"ERROR"``).
        fmt: ``"json"`` for structured JSON lines (default, recommended
             for production), or ``"text"`` for human-readable output.
        include_timestamp: Include ISO-8601 timestamps (default ``True``).

    Example::

        import attestant
        attestant.setup_logging(level="INFO", fmt="json")
    """
    import logging
    import json as _json
    import sys
    from datetime import datetime, timezone

    numeric_level = getattr(logging, level.upper(), logging.INFO)

    class _JSONFormatter(logging.Formatter):
        def format(self, record: logging.LogRecord) -> str:
            entry = {
                "logger": record.name,
                "level": record.levelname,
                "message": record.getMessage(),
            }
            if include_timestamp:
                entry["timestamp"] = (
                    datetime.fromtimestamp(record.created, tz=timezone.utc)
                    .isoformat()
                )
            if record.exc_info and record.exc_info[0] is not None:
                entry["exception"] = self.formatException(record.exc_info)
            return _json.dumps(entry, default=str)

    class _TextFormatter(logging.Formatter):
        _fmt_ts = "%(asctime)s %(name)s %(levelname)s %(message)s"
        _fmt_no_ts = "%(name)s %(levelname)s %(message)s"

        def __init__(self, with_ts: bool = True) -> None:
            super().__init__(
                fmt=self._fmt_ts if with_ts else self._fmt_no_ts,
                datefmt="%Y-%m-%dT%H:%M:%S%z",
            )

    root_logger = logging.getLogger("attestant")
    root_logger.setLevel(numeric_level)

    root_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(numeric_level)

    if fmt == "json":
        handler.setFormatter(_JSONFormatter())
    else:
        handler.setFormatter(_TextFormatter(with_ts=include_timestamp))

    root_logger.addHandler(handler)


# =============================================================================
# Lean Upload-Only API (All Analysis Happens Server-Side)
# =============================================================================

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional


@dataclass
class ValidationResult:
    """Simplified validation result for users."""
    approved: bool
    compliance_score: float
    model_name: str
    model_version: str
    findings: List[str]
    dashboard_url: str
    documentation_urls: Dict[str, Optional[str]] = field(default_factory=dict)
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def reason(self) -> str:
        """Why deployment was blocked (if applicable)."""
        if self.approved:
            return "All compliance checks passed"
        return self.findings[0] if self.findings else "Unknown"


def validate(
    model,
    data: Dict[str, Any],
    protected_columns: List[str],
    model_name: str,
    model_version: str = "1.0.0",
    domain: str = "lending",
    tier: int = 1,
    **kwargs
) -> ValidationResult:
    """
    Upload model + data to AWS for server-side compliance validation.

    LEAN CLIENT: This function ONLY uploads data. All analysis happens on your AWS infrastructure.
    - Serializes model (joblib, cloudpickle, or pickle - tries best method automatically)
    - Serializes data (handles NumPy, Pandas, lists, sparse matrices, GPU tensors, Polars)
    - Uploads model + data to your server
    - Server runs fairness/compliance analysis
    - Returns deployment decision
    - ZERO local storage

    Args:
        model: ANY trained Python model with predict() method:
            - scikit-learn (LogisticRegression, RandomForest, etc.)
            - XGBoost, LightGBM, CatBoost
            - PyTorch models
            - TensorFlow/Keras models
            - Custom models (as long as they have .predict())
        data: Dictionary with keys:
            - 'X_train': Training features (NumPy, Pandas, list, sparse, Polars)
            - 'y_train': Training labels (NumPy, Pandas, list)
            - 'X_test': Test features (NumPy, Pandas, list, sparse, Polars)
            - 'y_test': Test labels (NumPy, Pandas, list)
            - 'protected_data' (optional): DataFrame with protected attributes
        protected_columns: List of protected attribute column names
        model_name: Name for dashboard (e.g., "loan_approval")
        model_version: Version string (e.g., "2.1.0")
        domain: Domain (e.g., "lending", "hiring", "credit_scoring")
        tier: 1=critical, 2=important, 3=routine
        **kwargs: Additional metadata for documentation

    Returns:
        ValidationResult with:
        - approved: bool (pass/fail)
        - compliance_score: 0-100
        - findings: List of issues detected
        - dashboard_url: Where to view results
        - documentation_urls: Links to SR 11-7, model card, etc.
        - details: Full technical results

    Example:
        import attestant

        attestant.configure(api_key="pvt_live_...")

        # Works with any model type
        model = LogisticRegression().fit(X_train, y_train)
        # model = XGBClassifier().fit(X_train, y_train)
        # model = torch_model  # PyTorch
        # model = tf_model  # TensorFlow

        result = attestant.validate(
            model=model,
            data={"X_train": X_train, "y_train": y_train,
                  "X_test": X_test, "y_test": y_test},
            protected_columns=["age", "race", "gender"],
            model_name="loan_approval",
            model_version="2.1.0"
        )

        if result.approved:
            print(f"✅ Deployment approved - view at {result.dashboard_url}")
        else:
            print(f"❌ Blocked: {result.reason}")
            for finding in result.findings:
                print(f"  - {finding}")
    """
    import os
    import logging
    import pickle
    import base64
    import json
    import urllib.request
    import urllib.error

    logger = logging.getLogger(__name__)

    # Get config
    service_url = os.environ.get('ATTESTANT_SERVICE_URL', 'http://54.205.86.45')
    api_key = os.environ.get('ATTESTANT_API_KEY', '')

    if not api_key:
        raise ValueError("API key not configured. Call attestant.configure(api_key='...') first")

    # Extract data
    X_train = data.get('X_train')
    y_train = data.get('y_train')
    X_test = data.get('X_test')
    y_test = data.get('y_test')

    if X_train is None or y_train is None or X_test is None or y_test is None:
        raise ValueError("data must contain X_train, y_train, X_test, y_test")

    try:
        import pandas as pd
        import numpy as np

        # Flexible model serialization - tries multiple methods for maximum compatibility
        def serialize_model(model):
            """Serialize model using best available method."""
            serialization_method = None
            model_bytes = None

            # Try joblib first (best for sklearn, XGBoost, LightGBM)
            try:
                import joblib
                import io
                buffer = io.BytesIO()
                joblib.dump(model, buffer)
                model_bytes = buffer.getvalue()
                serialization_method = "joblib"
                logger.info("Serialized model using joblib")
            except Exception as e:
                logger.debug(f"joblib serialization failed: {e}")

            # Try cloudpickle (works for PyTorch, TensorFlow, complex objects)
            if model_bytes is None:
                try:
                    import cloudpickle
                    model_bytes = cloudpickle.dumps(model)
                    serialization_method = "cloudpickle"
                    logger.info("Serialized model using cloudpickle")
                except Exception as e:
                    logger.debug(f"cloudpickle serialization failed: {e}")

            # Fallback to standard pickle
            if model_bytes is None:
                try:
                    model_bytes = pickle.dumps(model)
                    serialization_method = "pickle"
                    logger.info("Serialized model using pickle")
                except Exception as e:
                    raise ValueError(f"Failed to serialize model with any method (joblib, cloudpickle, pickle): {e}")

            return model_bytes, serialization_method

        # Serialize model (NO local storage - goes straight to server)
        model_bytes, serialization_method = serialize_model(model)
        model_b64 = base64.b64encode(model_bytes).decode('utf-8')

        # Flexible data serialization - handles all common data types
        def serialize_array(arr):
            """Serialize data arrays - supports pandas, numpy, sparse, GPU tensors, polars, lists."""
            if arr is None:
                return None

            # Pandas DataFrame
            if isinstance(arr, pd.DataFrame):
                return {"type": "dataframe", "data": arr.to_dict(orient='split')}

            # Pandas Series
            elif isinstance(arr, pd.Series):
                return {"type": "series", "data": arr.tolist()}

            # NumPy array
            elif isinstance(arr, np.ndarray):
                return {"type": "ndarray", "data": arr.tolist()}

            # Sparse matrices (scipy)
            elif hasattr(arr, 'toarray'):  # scipy sparse matrix
                return {"type": "sparse", "data": arr.toarray().tolist()}

            # PyTorch tensors
            elif hasattr(arr, 'cpu') and hasattr(arr, 'numpy'):  # PyTorch tensor
                return {"type": "tensor", "data": arr.cpu().numpy().tolist()}

            # TensorFlow tensors
            elif hasattr(arr, 'numpy') and str(type(arr).__module__).startswith('tensorflow'):
                return {"type": "tensor", "data": arr.numpy().tolist()}

            # Polars DataFrame
            elif hasattr(arr, 'to_pandas'):  # Polars DataFrame
                return {"type": "dataframe", "data": arr.to_pandas().to_dict(orient='split')}

            # Python lists and other iterables
            else:
                return {"type": "list", "data": list(arr)}

        # Get protected data
        protected_data = data.get('protected_data')
        if protected_data is None and isinstance(X_test, pd.DataFrame):
            available_cols = [col for col in protected_columns if col in X_test.columns]
            if available_cols:
                protected_data = X_test[available_cols]

        # Build payload - LEAN, just the data
        payload = {
            "model_name": model_name,
            "model_version": model_version,
            "domain": domain,
            "tier": tier,
            "model_b64": model_b64,
            "model_serialization_method": serialization_method,
            "X_train": serialize_array(X_train),
            "y_train": serialize_array(y_train),
            "X_test": serialize_array(X_test),
            "y_test": serialize_array(y_test),
            "protected_columns": protected_columns,
            "protected_data": serialize_array(protected_data) if protected_data is not None else None,
            "metadata": kwargs
        }

        # Upload to server (server does ALL analysis)
        body = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(
            f"{service_url}/v1/validate",
            data=body,
            method="POST",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )

        logger.info(f"Uploading {model_name} v{model_version} to {service_url} for server-side analysis...")

        with urllib.request.urlopen(req, timeout=300) as resp:  # 5 min timeout for server analysis
            result_data = json.loads(resp.read().decode('utf-8'))

        logger.info(f"✅ Server analysis complete for {model_name}")

        # Parse server response
        return ValidationResult(
            approved=result_data.get('approved', False),
            compliance_score=result_data.get('compliance_score', 0),
            model_name=model_name,
            model_version=model_version,
            findings=result_data.get('findings', []),
            dashboard_url=result_data.get('dashboard_url', f"{service_url}/client/models/{model_name}"),
            documentation_urls=result_data.get('documentation_urls', {}),
            details=result_data.get('details', {})
        )

    except urllib.error.HTTPError as e:
        error_msg = e.read().decode('utf-8') if e.fp else str(e)
        logger.error(f"Server returned error: {e.code} - {error_msg}")
        return ValidationResult(
            approved=False,
            compliance_score=0,
            model_name=model_name,
            model_version=model_version,
            findings=[f"Server error: {e.code} - {error_msg}"],
            dashboard_url=f"{service_url}/client/models/{model_name}",
            details={"error": error_msg}
        )
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return ValidationResult(
            approved=False,
            compliance_score=0,
            model_name=model_name,
            model_version=model_version,
            findings=[str(e)],
            dashboard_url=f"{service_url}/client/models/{model_name}",
            details={"error": str(e)}
        )
