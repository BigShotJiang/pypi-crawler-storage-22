"""
Attestant: Cryptographically Provable AI Compliance for Banks

Tamper-proof data provenance tracking, algorithmic fairness analysis,
and automated compliance documentation for financial institutions.

Quick start (fairness analysis — no API key needed):
    import attestant

    report = attestant.analyze(
        model="credit_model.pkl",
        data="applications.csv",
        protected=["race", "sex", "age"],
        industry="lending",
    )
    report.save("fairness_report.pdf")

Provenance tracking — just set your API key:
    import attestant
    attestant.configure(api_key="pvt_live_...")

    df = attestant.wrap(raw_df, "users.csv")
    dag = attestant.get_dag_simple(df['income'] / df['debt'])
    # Data is persisted automatically — no flush needed on exit
"""

__version__ = "0.8.1"

# =============================================================================
# Configuration API  (always available - these ARE the gate)
# =============================================================================
from .config import (
    configure,
    wrap,
    get_dag as get_dag_simple,
    audit as audit_simple,
    flush,
    reset,
    get_stats,
    tracking,
    get_tracker,
)

# =============================================================================
# Convenience API (no API key needed — works immediately)
# =============================================================================
from .loader import load_model, load_data
from .quick import analyze

# =============================================================================
# Lazy-loaded names: require attestant.configure(api_key=...) before access
# =============================================================================
_LAZY_IMPORTS = {
    # HYDRA-24 DAG System
    "DAGTracker": ("hydra24_dag", "DAGTracker"),
    "DAGTrackedSeries": ("hydra24_dag", "DAGTrackedSeries"),
    "DAGTrackedDataFrame": ("hydra24_dag", "DAGTrackedDataFrame"),
    "wrap_dataframe": ("hydra24_dag", "wrap_dataframe_dag"),
    "get_dag": ("hydra24_dag", "get_dag_for_series"),
    "dag_audit": ("hydra24_dag", "dag_audit"),
    "ComputationDAG": ("hydra24_dag", "ComputationDAG"),
    "DAGNode": ("hydra24_dag", "DAGNode"),
    "DAGEdge": ("hydra24_dag", "DAGEdge"),
    "NodeType": ("hydra24_dag", "NodeType"),

    # HYDRA-24 Enhanced System
    "ProvenanceTracker": ("hydra24_simple", "ProvenanceTracker"),
    "TrackedSeries": ("hydra24_simple", "TrackedSeries"),
    "TrackedDataFrame": ("hydra24_simple", "TrackedDataFrame"),
    "wrap_dataframe_simple": ("hydra24_simple", "wrap_dataframe"),
    "audit": ("hydra24_simple", "audit"),
    "audit_series_diversity": ("hydra24_simple", "audit_series_diversity"),
    "OpCode": ("hydra24_simple", "OpCode"),
    "MAX_PAIRS": ("hydra24_simple", "MAX_PAIRS"),

    # Persistence
    "create_storage": ("persistence.factory", "create_storage"),
    "init_database": ("persistence", "init_database"),
    "get_schema_ddl": ("persistence", "get_schema_ddl"),
    "PostgreSQLStorage": ("persistence", "PostgreSQLStorage"),
    "reconstruct_dag": ("persistence", "reconstruct_dag"),
    "query_by_fingerprint": ("persistence", "query_by_fingerprint"),
    "query_by_source": ("persistence", "query_by_source"),

    # Fairness
    "FairLensEngine": ("fairness", "FairLensEngine"),
    "FairLensConfig": ("fairness", "FairLensConfig"),

    # Documentation
    "AutoDocEngine": ("docs", "AutoDocEngine"),
    "TemplateType": ("docs", "TemplateType"),

    # Vendor Readiness
    "VendorDueDiligencePackage": ("vendor", "VendorDueDiligencePackage"),
    "CertificationTracker": ("vendor", "CertificationTracker"),
    "PlatformHealthCheck": ("vendor", "PlatformHealthCheck"),

    # Governance
    "ModelRecord": ("governance", "ModelRecord"),
    "ModelRegistry": ("governance", "ModelRegistry"),
    "PIIDetector": ("governance", "PIIDetector"),
    "RetentionPolicyEngine": ("governance", "RetentionPolicyEngine"),
    "RegulatoryCalendar": ("governance", "RegulatoryCalendar"),

    # Examiner
    "ExaminerPackage": ("examiner", "ExaminerPackage"),
    "ModelCardGenerator": ("examiner", "ModelCardGenerator"),

    # Compliance
    "ComplianceScorer": ("compliance.score", "ComplianceScorer"),
    "AttestationManager": ("compliance.cro_features", "AttestationManager"),
    "PeerBenchmark": ("compliance.cro_features", "PeerBenchmark"),
    "QuickWinRecommender": ("compliance.cro_features", "QuickWinRecommender"),
    "RegulatoryChangeAssessor": ("compliance.cro_features", "RegulatoryChangeAssessor"),
    "RemediationQueue": ("compliance.cro_features", "RemediationQueue"),
    "RiskHeatmap": ("compliance.cro_features", "RiskHeatmap"),
    "ExceptionTracker": ("governance.exception_tracker", "ExceptionTracker"),
    "ComplianceException": ("governance.exception_tracker", "ComplianceException"),
}


def __getattr__(name: str):
    """Lazy-load proveit classes; require configure() first in production."""
    if name in _LAZY_IMPORTS:
        import os
        from .config import _config

        _testing = (
            os.environ.get("ATTESTANT_TESTING")
            or os.environ.get("HYDRA24_TESTING")
        )
        if not _config._initialized and not _testing:
            raise RuntimeError(
                f"Attestant not configured. Call attestant.configure(api_key='...') "
                f"before accessing attestant.{name}.\n"
                "Get your API key at https://attestant.ai/signup"
            )

        module_name, real_name = _LAZY_IMPORTS[name]
        import importlib
        try:
            mod = importlib.import_module(f".{module_name}", __package__)
        except ImportError as exc:
            raise AttributeError(
                f"attestant.{name} requires an optional dependency: {exc}"
            ) from exc
        obj = getattr(mod, real_name)
        globals()[name] = obj
        return obj

    raise AttributeError(f"module 'proveit' has no attribute {name!r}")


# =============================================================================
# Public API
# =============================================================================
__all__ = [
    # Version
    "__version__",

    # Convenience API (no API key needed)
    "analyze",
    "load_model",
    "load_data",

    # Simplified API (easiest - recommended for new users)
    "configure",
    "wrap",
    "get_dag_simple",
    "audit_simple",
    "flush",
    "reset",
    "get_stats",
    "tracking",
    "get_tracker",

    # HYDRA-24 DAG (advanced API)
    "DAGTracker",
    "DAGTrackedSeries",
    "DAGTrackedDataFrame",
    "wrap_dataframe",
    "get_dag",
    "dag_audit",
    "ComputationDAG",
    "DAGNode",
    "DAGEdge",
    "NodeType",

    # HYDRA-24 Enhanced
    "ProvenanceTracker",
    "TrackedSeries",
    "TrackedDataFrame",
    "wrap_dataframe_simple",
    "audit",
    "audit_series_diversity",
    "OpCode",
    "MAX_PAIRS",

    # Storage factory
    "create_storage",

    # Persistence (optional)
    "init_database",
    "get_schema_ddl",
    "PostgreSQLStorage",
    "reconstruct_dag",
    "query_by_fingerprint",
    "query_by_source",

    # Fairness
    "FairLensEngine",
    "FairLensConfig",

    # Docs
    "AutoDocEngine",
    "TemplateType",

    # Vendor Readiness
    "VendorDueDiligencePackage",
    "CertificationTracker",
    "PlatformHealthCheck",

    # Data Governance & Model Registry
    "ModelRecord",
    "ModelRegistry",
    "PIIDetector",
    "RetentionPolicyEngine",
    "RegulatoryCalendar",

    # Examiner Package
    "ExaminerPackage",
    "ModelCardGenerator",

    # Compliance Scoring
    "ComplianceScorer",

    # CRO Features
    "AttestationManager",
    "ComplianceException",
    "ExceptionTracker",
    "PeerBenchmark",
    "QuickWinRecommender",
    "RegulatoryChangeAssessor",
    "RemediationQueue",
    "RiskHeatmap",

    # Logging
    "setup_logging",
]


# =============================================================================
# Production Logging Setup
# =============================================================================

def setup_logging(
    level: str = "INFO",
    fmt: str = "json",
    include_timestamp: bool = True,
) -> None:
    """Configure logging for production bank deployments.

    Sets up structured logging across all ``attestant.*`` loggers so that
    output is compatible with log aggregation tools (Splunk, ELK,
    Datadog, CloudWatch Logs).

    Args:
        level: Log level (``"DEBUG"``, ``"INFO"``, ``"WARNING"``, ``"ERROR"``).
        fmt: ``"json"`` for structured JSON lines (default, recommended
             for production), or ``"text"`` for human-readable output.
        include_timestamp: Include ISO-8601 timestamps (default ``True``).

    Example::

        import attestant
        attestant.setup_logging(level="INFO", fmt="json")
    """
    import logging
    import json as _json
    import sys
    from datetime import datetime, timezone

    numeric_level = getattr(logging, level.upper(), logging.INFO)

    class _JSONFormatter(logging.Formatter):
        def format(self, record: logging.LogRecord) -> str:
            entry = {
                "logger": record.name,
                "level": record.levelname,
                "message": record.getMessage(),
            }
            if include_timestamp:
                entry["timestamp"] = (
                    datetime.fromtimestamp(record.created, tz=timezone.utc)
                    .isoformat()
                )
            if record.exc_info and record.exc_info[0] is not None:
                entry["exception"] = self.formatException(record.exc_info)
            return _json.dumps(entry, default=str)

    class _TextFormatter(logging.Formatter):
        _fmt_ts = "%(asctime)s %(name)s %(levelname)s %(message)s"
        _fmt_no_ts = "%(name)s %(levelname)s %(message)s"

        def __init__(self, with_ts: bool = True) -> None:
            super().__init__(
                fmt=self._fmt_ts if with_ts else self._fmt_no_ts,
                datefmt="%Y-%m-%dT%H:%M:%S%z",
            )

    root_logger = logging.getLogger("proveit")
    root_logger.setLevel(numeric_level)

    root_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(numeric_level)

    if fmt == "json":
        handler.setFormatter(_JSONFormatter())
    else:
        handler.setFormatter(_TextFormatter(with_ts=include_timestamp))

    root_logger.addHandler(handler)
